import { 
  DiagnosticQuestion, 
  UserResponse, 
  DiagnosticResult, 
  TopicAssessment, 
  MasteryLevel,
  LecturePathStep 
} from './types';
import { IRTEngine } from './irtEngine';
import { DEFAULT_DIAGNOSTIC_BANK, ELECTROMAGNETISM_SUBTOPICS } from './defaultQuestions';

export class QuestionSelector {
  private itemBank: DiagnosticQuestion[];
  private answeredQuestionIds: Set<string>;
  private subtopicFrequencies: Record<string, number>;

  constructor(customBank?: DiagnosticQuestion[]) {
    this.itemBank = customBank && customBank.length > 0 ? customBank : [...DEFAULT_DIAGNOSTIC_BANK];
    this.answeredQuestionIds = new Set();
    this.subtopicFrequencies = {};
  }

  /**
   * Selects the first question: medium difficulty (b ≈ 0.0) from the first subtopic
   */
  public selectInitialQuestion(): DiagnosticQuestion {
    const mediumCandidates = this.itemBank
      .filter(q => !this.answeredQuestionIds.has(q.id))
      .sort((a, b) => Math.abs(a.difficulty - 0.0) - Math.abs(b.difficulty - 0.0));

    const selected = mediumCandidates[0] || this.itemBank[0];
    this.markAsAnswered(selected.id, selected.subtopicId);
    return selected;
  }

  /**
   * Adaptive Item Selection:
   * 1. Prioritizes least-tested subtopics to ensure full chapter coverage.
   * 2. Maximizes Fisher Information at current ability estimate theta.
   * 3. Adapts difficulty: moves up if previous answer was correct, down if wrong.
   */
  public selectNextQuestion(
    currentTheta: number,
    lastResponseCorrect: boolean,
    targetSubtopicId?: string
  ): DiagnosticQuestion | null {
    const available = this.itemBank.filter(q => !this.answeredQuestionIds.has(q.id));
    if (available.length === 0) return null;

    // Find subtopics with minimal exposure
    const subtopicCounts: Record<string, number> = {};
    for (const q of available) {
      if (!subtopicCounts[q.subtopicId]) {
        subtopicCounts[q.subtopicId] = this.subtopicFrequencies[q.subtopicId] || 0;
      }
    }

    const minFreq = Math.min(...Object.values(subtopicCounts));
    const balancedCandidates = available.filter(
      q => (this.subtopicFrequencies[q.subtopicId] || 0) <= minFreq + 1
    );

    const candidates = balancedCandidates.length > 0 ? balancedCandidates : available;

    // Score candidates by Fisher Information and directional difficulty bias
    let bestQuestion: DiagnosticQuestion | null = null;
    let maxUtility = -Infinity;

    for (const candidate of candidates) {
      const info = IRTEngine.calculateInformation(
        currentTheta,
        candidate.difficulty,
        candidate.discrimination,
        candidate.pseudoGuessing
      );

      // Directional bias: if last was correct, reward items with difficulty >= currentTheta
      let directionalBonus = 0;
      if (lastResponseCorrect && candidate.difficulty >= currentTheta - 0.2) {
        directionalBonus = 0.5;
      } else if (!lastResponseCorrect && candidate.difficulty <= currentTheta + 0.2) {
        directionalBonus = 0.5;
      }

      // Coverage penalty if this subtopic was already tested recently
      const freq = this.subtopicFrequencies[candidate.subtopicId] || 0;
      const coveragePenalty = freq * 0.3;

      const utility = info + directionalBonus - coveragePenalty;

      if (utility > maxUtility) {
        maxUtility = utility;
        bestQuestion = candidate;
      }
    }

    const selected = bestQuestion || candidates[0];
    this.markAsAnswered(selected.id, selected.subtopicId);
    return selected;
  }

  private markAsAnswered(questionId: string, subtopicId: string) {
    this.answeredQuestionIds.add(questionId);
    this.subtopicFrequencies[subtopicId] = (this.subtopicFrequencies[subtopicId] || 0) + 1;
  }

  /**
   * Evaluates complete diagnostic session and derives subtopic mastery levels
   */
  public static evaluateSession(
    responses: UserResponse[],
    questions: DiagnosticQuestion[],
    studentId: string = 'student_default',
    chapterId: string = 'electromagnetism',
    chapterTitle: string = 'Electromagnetism & AC Theory',
    subject: string = 'Physics',
    totalTimeTaken: number = 360
  ): DiagnosticResult {
    // 1. Group responses by subtopic
    const subtopicMap: Record<string, {
      title: string;
      correct: number;
      total: number;
      difficulties: number[];
      timeSpent: number;
    }> = {};

    // Initialize with standard subtopics configuration
    ELECTROMAGNETISM_SUBTOPICS.forEach(sub => {
      subtopicMap[sub.id] = {
        title: sub.title,
        correct: 0,
        total: 0,
        difficulties: [],
        timeSpent: 0
      };
    });

    responses.forEach(r => {
      const q = questions.find(item => item.id === r.questionId);
      const subId = r.subtopicId || (q ? q.subtopicId : 'general');
      const subTitle = q ? q.subtopicTitle : subId;

      if (!subtopicMap[subId]) {
        subtopicMap[subId] = {
          title: subTitle,
          correct: 0,
          total: 0,
          difficulties: [],
          timeSpent: 0
        };
      }

      subtopicMap[subId].total += 1;
      if (r.isCorrect) {
        subtopicMap[subId].correct += 1;
      }
      if (q) {
        subtopicMap[subId].difficulties.push(q.difficulty);
      }
      subtopicMap[subId].timeSpent += r.timeSpentSeconds;
    });

    // 2. Final IRT Ability Estimate
    const responseWithQuestions = responses.map(r => ({
      isCorrect: r.isCorrect,
      question: questions.find(q => q.id === r.questionId) || {
        id: r.questionId,
        chapterId,
        subtopicId: r.subtopicId,
        subtopicTitle: r.subtopicId,
        difficulty: 0,
        discrimination: 1,
        pseudoGuessing: 0.25,
        questionText: '',
        options: [],
        correctOptionIndex: 0,
        explanation: ''
      }
    }));

    const finalIRT = IRTEngine.updateAbilityEstimate(responseWithQuestions);
    const overallScore = IRTEngine.thetaToPercentage(finalIRT.theta);

    // 3. Compute topic level mastery and time savings
    const topicScores: Record<string, { score: number; masteryLevel: MasteryLevel }> = {};
    const detailedTopics: Record<string, TopicAssessment> = {};

    let totalMinutesSaved = 0;
    let totalBaseMinutes = 0;

    Object.entries(subtopicMap).forEach(([subId, data]) => {
      const baseConfig = ELECTROMAGNETISM_SUBTOPICS.find(s => s.id === subId) || {
        id: subId,
        title: data.title,
        lectureDurationMinutes: 30,
        weight: 1.0
      };

      totalBaseMinutes += baseConfig.lectureDurationMinutes;

      // Score calculation: combines empirical accuracy with average difficulty cleared
      let rawScore = 50;
      if (data.total > 0) {
        const accuracy = (data.correct / data.total) * 100;
        const avgDifficulty = data.difficulties.length > 0 
          ? data.difficulties.reduce((a, b) => a + b, 0) / data.difficulties.length 
          : 0;
        // Bonus or penalty based on difficulty faced
        const difficultyAdjustment = avgDifficulty * 8;
        rawScore = Math.max(0, Math.min(100, Math.round(accuracy + difficultyAdjustment)));
      } else {
        // Inherit global ability projection if subtopic wasn't directly tested
        rawScore = overallScore;
      }

      // Determine mastery tier:
      // >80%: Mastered (Skip in lectures)
      // 60-80%: Proficient (Quick review only)
      // 40-60%: Developing (Full teaching)
      // <40%: Beginner (Extra foundation)
      let masteryLevel: MasteryLevel = 'developing';
      let adaptedMinutes = baseConfig.lectureDurationMinutes;
      let recommendation = 'Standard full lecture recommended.';

      if (rawScore >= 80) {
        masteryLevel = 'mastered';
        adaptedMinutes = 0; // Skipped completely!
        recommendation = 'Mastered (>80%): Topic will be skipped in lectures. Saves you full lecture time!';
      } else if (rawScore >= 60) {
        masteryLevel = 'proficient';
        adaptedMinutes = Math.round(baseConfig.lectureDurationMinutes * 0.35); // 5-10 min quick review
        recommendation = 'Proficient (60-80%): Accelerated 5-10 min rapid review of edge cases only.';
      } else if (rawScore >= 40) {
        masteryLevel = 'developing';
        adaptedMinutes = baseConfig.lectureDurationMinutes;
        recommendation = 'Developing (40-60%): Full concept derivation and guided problem solving.';
      } else {
        masteryLevel = 'beginner';
        adaptedMinutes = Math.round(baseConfig.lectureDurationMinutes * 1.3); // Extra foundation reinforcement
        recommendation = 'Beginner (<40%): Step-by-step foundation review and visual physical analogies.';
      }

      const savedForTopic = Math.max(0, baseConfig.lectureDurationMinutes - adaptedMinutes);
      totalMinutesSaved += savedForTopic;

      topicScores[subId] = {
        score: rawScore,
        masteryLevel
      };

      detailedTopics[subId] = {
        subtopicId: subId,
        subtopicTitle: data.title,
        score: rawScore,
        masteryLevel,
        totalAsked: data.total,
        correctCount: data.correct,
        standardLectureMinutes: baseConfig.lectureDurationMinutes,
        adaptedLectureMinutes: adaptedMinutes,
        minutesSaved: savedForTopic,
        recommendation
      };
    });

    const masteryPercentage = Math.round(
      (Object.values(topicScores).filter(t => t.masteryLevel === 'mastered').length / 
       Math.max(1, Object.keys(topicScores).length)) * 100
    );

    return {
      studentId,
      chapterId,
      chapterTitle,
      subject,
      topicScores,
      detailedTopics,
      overallScore,
      masteryPercentage,
      abilityTheta: finalIRT.theta,
      standardError: finalIRT.standardError,
      confidenceInterval: finalIRT.confidenceInterval,
      totalQuestionsAnswered: responses.length,
      timeTaken: totalTimeTaken,
      totalMinutesSaved,
      skippedMinutes: totalMinutesSaved,
      isSkipped: false,
      completedAt: new Date().toISOString()
    };
  }

  /**
   * Generates a step-by-step personalized lecture sequence
   */
  public static generateLecturePath(result: DiagnosticResult): LecturePathStep[] {
    const steps: LecturePathStep[] = [];
    let stepNum = 1;

    Object.entries(result.detailedTopics).forEach(([subId, data]) => {
      let action: LecturePathStep['action'] = 'full_teaching';
      let desc = '';

      switch (data.masteryLevel) {
        case 'mastered':
          action = 'skip';
          desc = `Skipped: Student demonstrated >80% proficiency. Saved ${data.standardLectureMinutes} mins.`;
          break;
        case 'proficient':
          action = 'quick_review';
          desc = `Quick Review: 5-minute high-yield summary & key formulas before advancing.`;
          break;
        case 'developing':
          action = 'full_teaching';
          desc = `Standard Lecture: Comprehensive explanation with animated board diagrams.`;
          break;
        case 'beginner':
          action = 'foundation';
          desc = `Foundation Mastery: Deep-dive prerequisite review, visual models, and practice.`;
          break;
      }

      steps.push({
        stepNumber: stepNum++,
        subtopicId: subId,
        subtopicTitle: data.subtopicTitle,
        masteryLevel: data.masteryLevel,
        action,
        durationMinutes: data.adaptedLectureMinutes,
        originalDurationMinutes: data.standardLectureMinutes,
        timeSavedMinutes: data.minutesSaved,
        description: desc
      });
    });

    return steps;
  }
}
