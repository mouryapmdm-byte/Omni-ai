import React, { useEffect, useRef, useState } from "react";
import { cn } from "@/src/lib/utils";

interface Source {
  x: number;
  y: number;
}

export const WaveExplorer: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [frequency, setFrequency] = useState(0.2);
  const [sources, setSources] = useState<Source[]>([{ x: 150, y: 150 }, { x: 250, y: 150 }]);
  const [time, setTime] = useState(0);
  const requestRef = useRef<number>(0);

  const animate = (t: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const imageData = ctx.createImageData(width, height);
    const data = imageData.data;

    const t_scaled = t * 0.005;

    for (let x = 0; x < width; x++) {
      for (let y = 0; y < height; y++) {
        let sum = 0;
        for (const source of sources) {
          const dx = x - source.x;
          const dy = y - source.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          sum += Math.sin(dist * frequency - t_scaled);
        }
        
        // Map sum to color
        const intensity = (Math.sin(sum * 2) + 1) * 128;
        const i = (y * width + x) * 4;
        data[i] = intensity; // R
        data[i + 1] = intensity; // G
        data[i + 2] = intensity; // B
        data[i + 3] = 255; // A
      }
    }
    ctx.putImageData(imageData, 0, 0);
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(requestRef.current!);
  }, [frequency, sources]);

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-2">
      <div className="flex gap-2 p-2 border-b flex-wrap text-sm">
        <label>Frequency: {frequency.toFixed(2)}</label>
        <input type="range" min="0.05" max="0.5" step="0.01" value={frequency} onChange={(e) => setFrequency(parseFloat(e.target.value))} />
      </div>
      <div className="flex-1 border rounded-lg overflow-hidden relative">
        <canvas ref={canvasRef} width={400} height={300} className="w-full h-full" />
      </div>
    </div>
  );
};
