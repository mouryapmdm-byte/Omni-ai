export * from '../../src/modules/wellbeing/ExamCalm';
