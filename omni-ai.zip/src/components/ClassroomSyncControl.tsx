import React, { useState, useEffect, useCallback } from 'react';
import { 
  Radio, 
  Share2, 
  Users, 
  Copy, 
  Check, 
  Zap, 
  RefreshCw, 
  X, 
  Eye, 
  Wifi, 
  Sparkles, 
  Laptop, 
  ChevronRight,
  ShieldAlert,
  Sliders,
  Globe
} from 'lucide-react';
import { cn, getSyncShareUrl } from '@/src/lib/utils';
import { 
  ClassroomSyncState, 
  broadcastClassroomState, 
  subscribeToClassroomSync, 
  getInitialClassCode, 
  DEFAULT_CLASS_CODE 
} from '@/src/lib/classroomSync';
import { playLessonInitializingCue, playChalkSound } from '@/src/lib/chalkAudio';

interface ClassroomSyncControlProps {
  currentBoardContent: string;
  currentTopicTitle?: string;
  currentSlideIndex?: number;
  currentChalkColor?: string;
  onApplySyncedContent?: (syncedState: ClassroomSyncState) => void;
  showNotification?: (message: string, type: 'info' | 'success' | 'warning' | 'error') => void;
  compactButtonOnly?: boolean;
  className?: string;
}

export const ClassroomSyncControl: React.FC<ClassroomSyncControlProps> = ({
  currentBoardContent,
  currentTopicTitle = 'Interactive Classroom Slate',
  currentSlideIndex = 0,
  currentChalkColor = 'white',
  onApplySyncedContent,
  showNotification,
  compactButtonOnly = false,
  className
}) => {
  const [classCode, setClassCode] = useState<string>(() => getInitialClassCode());
  const [isEditingCode, setIsEditingCode] = useState<boolean>(false);
  const [tempCodeInput, setTempCodeInput] = useState<string>(classCode);
  const [syncMode, setSyncMode] = useState<'broadcast' | 'follow' | 'off'>(() => {
    return (localStorage.getItem('omni_sync_mode') as any) || 'broadcast';
  });
  const [isOpenModal, setIsOpenModal] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<number | null>(null);
  const [remoteState, setRemoteState] = useState<ClassroomSyncState | null>(null);
  const [isSyncingNow, setIsSyncingNow] = useState<boolean>(false);

  // Auto-broadcast when slate content changes in 'broadcast' mode
  const handleBroadcastCurrentState = useCallback(async (customCode?: string) => {
    const targetCode = customCode || classCode;
    if (!targetCode) return;

    setIsSyncingNow(true);
    try {
      await broadcastClassroomState(targetCode, {
        content: currentBoardContent,
        topicTitle: currentTopicTitle,
        slideIndex: currentSlideIndex,
        chalkColor: currentChalkColor,
        isBroadcasting: true,
        broadcasterName: 'Prof. Omni AI (Class Host)',
      });
      setLastSyncTime(Date.now());
      playChalkSound('tap', 0.25);
    } catch (err) {
      console.error('Failed to broadcast slate:', err);
    } finally {
      setTimeout(() => setIsSyncingNow(false), 400);
    }
  }, [classCode, currentBoardContent, currentTopicTitle, currentSlideIndex, currentChalkColor]);

  // Subscribe to remote updates
  useEffect(() => {
    if (syncMode === 'off' || !classCode) return;

    const unsubscribe = subscribeToClassroomSync(classCode, (incomingState) => {
      if (!incomingState) return;

      setRemoteState(incomingState);
      setLastSyncTime(incomingState.updatedAt || Date.now());

      // If student is in 'follow' mode, apply incoming slate state automatically
      if (syncMode === 'follow' && incomingState.content && onApplySyncedContent) {
        onApplySyncedContent(incomingState);
      }
    });

    return () => unsubscribe();
  }, [classCode, syncMode, onApplySyncedContent]);

  // Trigger auto-broadcast when slate content or slide index changes if in broadcast mode
  useEffect(() => {
    if (syncMode === 'broadcast' && currentBoardContent) {
      const timer = setTimeout(() => {
        handleBroadcastCurrentState();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [currentBoardContent, currentTopicTitle, currentSlideIndex, currentChalkColor, syncMode, handleBroadcastCurrentState]);

  // Toggle Sync Mode button handler
  const handleToggleSyncButton = () => {
    playLessonInitializingCue(0.35);
    
    if (syncMode === 'off') {
      setSyncMode('broadcast');
      localStorage.setItem('omni_sync_mode', 'broadcast');
      handleBroadcastCurrentState();
      showNotification?.(`🔴 Live Classroom Slate Broadcast active on Class Code: ${classCode}`, 'success');
    } else {
      setIsOpenModal(true);
    }
  };

  const handleSaveClassCode = () => {
    const sanitized = tempCodeInput.trim().toUpperCase().replace(/[^A-Z0-9_\-]/g, '');
    if (!sanitized) {
      showNotification?.('Please enter a valid alphanumeric Class Code', 'warning');
      return;
    }
    setClassCode(sanitized);
    localStorage.setItem('omni_active_class_code', sanitized);
    setIsEditingCode(false);
    playChalkSound('tap', 0.3);
    showNotification?.(`Classroom code updated to: ${sanitized}`, 'info');
    if (syncMode === 'broadcast') {
      handleBroadcastCurrentState(sanitized);
    }
  };

  const handleCopyShareLink = () => {
    try {
      const basePublicUrl = getSyncShareUrl().split('?')[0].replace(/\/$/, '');
      const shareUrl = `${basePublicUrl}?classCode=${encodeURIComponent(classCode)}`;
      navigator.clipboard.writeText(shareUrl);
      setCopiedLink(true);
      playChalkSound('tap', 0.25);
      showNotification?.(`Class Sync Share Link copied! Share with students to follow live on any device.`, 'success');
      setTimeout(() => setCopiedLink(false), 2500);
    } catch (err) {
      showNotification?.(`Code: ${classCode} (Copied to memory)`, 'info');
    }
  };

  return (
    <>
      {/* Main Trigger Button */}
      <button
        onClick={handleToggleSyncButton}
        className={cn(
          "relative group px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-300 flex items-center gap-1 sm:gap-1.5 cursor-pointer border shadow-md active:scale-95 shrink-0 overflow-hidden",
          syncMode === 'broadcast'
            ? "bg-gradient-to-r from-red-600 via-rose-500 to-amber-600 text-white border-rose-400/80 shadow-rose-500/25 ring-2 ring-rose-400/40"
            : syncMode === 'follow'
            ? "bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-600 text-white border-teal-300/80 shadow-teal-500/25 ring-2 ring-teal-400/40"
            : "bg-slate-900/90 text-indigo-300 border-indigo-500/40 hover:bg-indigo-950/80 hover:text-white hover:border-indigo-400",
          className
        )}
        title={
          syncMode === 'broadcast'
            ? `Class Slate Sync: LIVE BROADCASTING on ${classCode}. Click for session controls.`
            : syncMode === 'follow'
            ? `Class Slate Sync: FOLLOWING LIVE CLASS ${classCode}. Click for session controls.`
            : `Synchronize current slate with class for real-time multi-device student viewing.`
        }
      >
        {/* Glow backdrop pulse for active state */}
        {syncMode !== 'off' && (
          <span className="absolute inset-0 bg-white/10 animate-pulse pointer-events-none" />
        )}

        {syncMode === 'broadcast' ? (
          <>
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-200 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
            </span>
            <Radio size={12} className="text-white animate-pulse" />
            <span className="font-extrabold text-white hidden sm:inline">Syncing Class</span>
            <span className="font-extrabold text-white inline sm:hidden">Sync</span>
            <span className="ml-0.5 px-1 py-0.2 rounded bg-black/40 text-[9px] font-mono text-amber-200 border border-white/20">
              {classCode}
            </span>
          </>
        ) : syncMode === 'follow' ? (
          <>
            <Wifi size={12} className="text-emerald-200 animate-pulse" />
            <span className="font-extrabold text-white hidden sm:inline">Follow Class</span>
            <span className="font-extrabold text-white inline sm:hidden">Follow</span>
            <span className="ml-0.5 px-1 py-0.2 rounded bg-black/40 text-[9px] font-mono text-emerald-200 border border-white/20">
              {classCode}
            </span>
          </>
        ) : (
          <>
            <Radio size={12} className="text-indigo-400 group-hover:text-amber-300 transition-colors" />
            <span className="hidden sm:inline">Synchronize with Class</span>
            <span className="inline sm:hidden">Sync Class</span>
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping" />
          </>
        )}
      </button>

      {/* Synchronize with Class Dialog Modal */}
      {isOpenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-slate-900 border border-indigo-500/30 rounded-3xl p-6 shadow-2xl text-slate-100 flex flex-col gap-5 relative overflow-hidden">
            {/* Ambient Top Glow */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-red-500 via-amber-400 to-emerald-500" />

            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-indigo-600 to-rose-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                  <Radio size={18} className="text-white animate-pulse" />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                    Classroom Slate Synchronizer
                    <span className="px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[9px] border border-indigo-400/30 font-bold">
                      Multi-Device
                    </span>
                  </h3>
                  <p className="text-[10px] font-medium text-slate-400">
                    Broadcast or follow the live classroom presentation slate in real-time
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsOpenModal(false)}
                className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Class Code Session Box */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Globe size={13} className="text-indigo-400" /> Active Class Code Channel
                </span>
                <button
                  onClick={handleCopyShareLink}
                  className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 hover:text-white text-[10px] font-bold flex items-center gap-1 transition-all border border-slate-700 cursor-pointer"
                >
                  {copiedLink ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  <span>{copiedLink ? 'Link Copied!' : 'Copy Share Link'}</span>
                </button>
              </div>

              {isEditingCode ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={tempCodeInput}
                    onChange={(e) => setTempCodeInput(e.target.value.toUpperCase())}
                    className="flex-1 bg-slate-900 border border-indigo-500/50 rounded-xl px-3 py-2 text-xs font-mono font-black text-amber-300 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    placeholder="e.g. CLASS-101"
                  />
                  <button
                    onClick={handleSaveClassCode}
                    className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md"
                  >
                    Save
                  </button>
                </div>
              ) : (
                <div className="flex items-center justify-between bg-slate-900 p-3 rounded-xl border border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-950 text-amber-300 font-mono font-black text-sm tracking-widest border border-indigo-500/40">
                      {classCode}
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">
                      (Share this code with students or connect secondary devices)
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setTempCodeInput(classCode);
                      setIsEditingCode(true);
                    }}
                    className="text-[10px] font-bold text-indigo-400 hover:underline cursor-pointer"
                  >
                    Change Code
                  </button>
                </div>
              )}
            </div>

            {/* Sync Mode Selector Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Broadcast Mode (Host/Teacher) */}
              <button
                onClick={() => {
                  setSyncMode('broadcast');
                  localStorage.setItem('omni_sync_mode', 'broadcast');
                  handleBroadcastCurrentState();
                  playChalkSound('tap', 0.3);
                  showNotification?.(`🔴 Broadcast Mode Active: Broadcasting slate updates to ${classCode}`, 'success');
                }}
                className={cn(
                  "p-3.5 rounded-2xl border transition-all text-left flex flex-col gap-2 cursor-pointer relative overflow-hidden",
                  syncMode === 'broadcast'
                    ? "bg-rose-950/40 border-rose-500/80 shadow-lg shadow-rose-950/50 ring-1 ring-rose-400/50"
                    : "bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-rose-300 flex items-center gap-1.5">
                    <Radio size={14} className="text-rose-400 animate-pulse" /> Host Broadcast
                  </span>
                  {syncMode === 'broadcast' && (
                    <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
                  )}
                </div>
                <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                  Broadcast your current classroom slate in real-time so all students on this channel view your derivations live.
                </p>
              </button>

              {/* Follow Mode (Student/Viewer) */}
              <button
                onClick={() => {
                  setSyncMode('follow');
                  localStorage.setItem('omni_sync_mode', 'follow');
                  playChalkSound('tap', 0.3);
                  showNotification?.(`🟢 Student Follow Mode Active: Receiving live slate updates from ${classCode}`, 'success');
                }}
                className={cn(
                  "p-3.5 rounded-2xl border transition-all text-left flex flex-col gap-2 cursor-pointer relative overflow-hidden",
                  syncMode === 'follow'
                    ? "bg-teal-950/40 border-teal-500/80 shadow-lg shadow-teal-950/50 ring-1 ring-teal-400/50"
                    : "bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-teal-300 flex items-center gap-1.5">
                    <Wifi size={14} className="text-teal-400 animate-pulse" /> Follow Class
                  </span>
                  {syncMode === 'follow' && (
                    <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping" />
                  )}
                </div>
                <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                  Follow the live teacher broadcast on your device. Slate automatically synchronizes as the presentation advances.
                </p>
              </button>
            </div>

            {/* Live Telemetry Status Box */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between text-xs font-medium">
              <div className="flex items-center gap-2 text-slate-300">
                <span className={cn(
                  "w-2.5 h-2.5 rounded-full inline-block",
                  syncMode === 'broadcast' ? "bg-rose-500 animate-ping" : syncMode === 'follow' ? "bg-teal-400 animate-pulse" : "bg-slate-600"
                )} />
                <span>
                  {syncMode === 'broadcast' 
                    ? 'Broadcasting Slate Live' 
                    : syncMode === 'follow' 
                    ? 'Connected to Live Broadcast' 
                    : 'Sync Standby'}
                </span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                {lastSyncTime ? `Last sync: ${new Date(lastSyncTime).toLocaleTimeString()}` : 'No sync recorded yet'}
              </div>
            </div>

            {/* Manual Push Button & Close */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => handleBroadcastCurrentState()}
                disabled={isSyncingNow}
                className="px-3.5 py-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md disabled:opacity-50"
              >
                <RefreshCw size={13} className={isSyncingNow ? "animate-spin" : ""} />
                <span>{isSyncingNow ? 'Broadcasting...' : 'Push Slate Now'}</span>
              </button>

              <button
                onClick={() => setIsOpenModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-extrabold transition-all cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
