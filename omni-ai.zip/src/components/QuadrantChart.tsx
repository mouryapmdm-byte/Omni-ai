import React from 'react';
import { QuadrantPoint, QuadrantType } from '../modules/metacognition/types';
import { AlertTriangle, CheckCircle2, HelpCircle, ShieldAlert, Zap } from 'lucide-react';
import { cn } from '../lib/utils';

export interface QuadrantChartProps {
  points: QuadrantPoint[];
  className?: string;
  onSelectQuadrant?: (quadrant: QuadrantType) => void;
}

export const QuadrantChart: React.FC<QuadrantChartProps> = ({
  points,
  className,
  onSelectQuadrant
}) => {
  const counts = {
    mastered: points.filter(p => p.quadrant === 'mastered').length,
    dangerous: points.filter(p => p.quadrant === 'dangerous').length,
    underconfident: points.filter(p => p.quadrant === 'underconfident').length,
    learning: points.filter(p => p.quadrant === 'learning').length
  };

  const total = Math.max(1, points.length);

  return (
    <div className={cn("flex flex-col gap-4 w-full", className)}>
      {/* 2x2 Quadrant Grid */}
      <div className="grid grid-cols-2 gap-3 w-full aspect-[4/3] sm:aspect-[16/9] min-h-[320px] p-2 bg-slate-900 rounded-2xl border border-slate-800 relative overflow-hidden">
        
        {/* Top Left: UNDERCONFIDENT (Low Confidence, Correct) */}
        <div 
          onClick={() => onSelectQuadrant && onSelectQuadrant('underconfident')}
          className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3.5 flex flex-col justify-between hover:bg-amber-500/15 transition cursor-pointer relative group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
              <Zap size={14} />
              Underconfident
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/20 text-amber-300">
              {counts.underconfident} ({Math.round((counts.underconfident / total) * 100)}%)
            </span>
          </div>
          <p className="text-[11px] text-amber-200/80 leading-snug">
            Low confidence, but actually correct! Trust your intuition more.
          </p>
          <div className="text-[10px] text-amber-400/60 font-mono mt-2">
            Confidence &lt; 3.5 • Correct
          </div>
        </div>

        {/* Top Right: MASTERED (High Confidence, Correct) */}
        <div 
          onClick={() => onSelectQuadrant && onSelectQuadrant('mastered')}
          className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3.5 flex flex-col justify-between hover:bg-emerald-500/15 transition cursor-pointer relative group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 size={14} />
              Mastered
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300">
              {counts.mastered} ({Math.round((counts.mastered / total) * 100)}%)
            </span>
          </div>
          <p className="text-[11px] text-emerald-200/80 leading-snug">
            High confidence & correct! Calibrated long-term mastery.
          </p>
          <div className="text-[10px] text-emerald-400/60 font-mono mt-2">
            Confidence ≥ 3.5 • Correct
          </div>
        </div>

        {/* Bottom Left: LEARNING (Low Confidence, Wrong) */}
        <div 
          onClick={() => onSelectQuadrant && onSelectQuadrant('learning')}
          className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-3.5 flex flex-col justify-between hover:bg-blue-500/15 transition cursor-pointer relative group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-blue-400 flex items-center gap-1.5">
              <HelpCircle size={14} />
              Learning Zone
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-blue-500/20 text-blue-300">
              {counts.learning} ({Math.round((counts.learning / total) * 100)}%)
            </span>
          </div>
          <p className="text-[11px] text-blue-200/80 leading-snug">
            Low confidence & wrong. Expected gap during initial study.
          </p>
          <div className="text-[10px] text-blue-400/60 font-mono mt-2">
            Confidence &lt; 3.5 • Incorrect
          </div>
        </div>

        {/* Bottom Right: DANGEROUS (High Confidence, Wrong) */}
        <div 
          onClick={() => onSelectQuadrant && onSelectQuadrant('dangerous')}
          className="bg-rose-500/15 border-2 border-rose-500/60 rounded-xl p-3.5 flex flex-col justify-between hover:bg-rose-500/20 transition cursor-pointer relative group shadow-lg shadow-rose-500/10"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-rose-400 flex items-center gap-1.5">
              <ShieldAlert size={14} className="animate-pulse" />
              DANGEROUS (Overconfident)
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500/30 text-rose-200 border border-rose-500/40">
              {counts.dangerous} ({Math.round((counts.dangerous / total) * 100)}%)
            </span>
          </div>
          <p className="text-[11px] text-rose-200 leading-snug font-medium">
            High confidence, but wrong! Highest priority blind spots.
          </p>
          <div className="text-[10px] text-rose-400 font-mono mt-2">
            Confidence ≥ 3.5 • Incorrect
          </div>
        </div>

      </div>
    </div>
  );
};
