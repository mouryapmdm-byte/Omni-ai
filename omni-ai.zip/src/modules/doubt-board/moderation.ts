export interface ModerationCheckResult {
  isSafe: boolean;
  reason?: 'profanity' | 'spam' | 'rate_limit' | 'too_short' | 'too_long';
  message?: string;
  flaggedWord?: string;
}

const PROFANITY_LIST = [
  'fuck', 'shit', 'asshole', 'bitch', 'cunt', 'dick', 'bastard', 'whore', 'slut',
  'idiot', 'stupid', 'moron', 'dumbass', 'retard', 'scam', 'hate', 'nigger', 'faggot'
];

const SPAM_PATTERNS = [
  /(.)\1{5,}/i, // repeated characters like 'aaaaaaa' or '??????'
  /https?:\/\/[^\s]+/i, // external URLs not allowed in student doubts
  /\b(free robux|crypto|whatsapp|telegram|call me|dm me|buy now|cash app|porn)\b/i
];

export class DoubtModeration {
  /**
   * Validates question text against profanity, spam, and length boundaries
   */
  public static validateContent(text: string): ModerationCheckResult {
    const trimmed = text.trim();

    if (trimmed.length < 5) {
      return {
        isSafe: false,
        reason: 'too_short',
        message: 'Your question is too short. Please provide enough context (at least 5 characters).'
      };
    }

    if (trimmed.length > 500) {
      return {
        isSafe: false,
        reason: 'too_long',
        message: `Questions are limited to 500 characters. Currently at ${trimmed.length} characters.`
      };
    }

    // Check profanity
    const lower = trimmed.toLowerCase();
    for (const word of PROFANITY_LIST) {
      const regex = new RegExp(`\\b${word}\\b`, 'i');
      if (regex.test(lower)) {
        return {
          isSafe: false,
          reason: 'profanity',
          flaggedWord: word,
          message: 'Please keep questions respectful and focused on academic learning.'
        };
      }
    }

    // Check spam patterns
    for (const pattern of SPAM_PATTERNS) {
      if (pattern.test(trimmed)) {
        return {
          isSafe: false,
          reason: 'spam',
          message: 'Spam pattern detected (repeated characters, external links, or promotional text).'
        };
      }
    }

    // Check keyboard smash (high consonant-to-vowel ratio with high length)
    if (this.isGibberish(trimmed)) {
      return {
        isSafe: false,
        reason: 'spam',
        message: 'The text appears to be keyboard mash or unreadable. Please type a clear question.'
      };
    }

    return { isSafe: true };
  }

  private static isGibberish(text: string): boolean {
    const cleaned = text.replace(/[^a-zA-Z]/g, '').toLowerCase();
    if (cleaned.length > 18) {
      const vowels = (cleaned.match(/[aeiou]/g) || []).length;
      const ratio = vowels / cleaned.length;
      if (ratio < 0.12 || ratio > 0.85) {
        return true;
      }
    }
    return false;
  }
}
