export const syncWithLMS = async (lmsType: string) => {
  console.log(`Syncing with ${lmsType}...`);
  return { success: true };
};
