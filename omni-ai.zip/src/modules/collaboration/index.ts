/**
 * Collaboration & Accessibility Module Public API
 * Responsibilities: Collaborative whiteboards, sync rooms, accessibility tools, and multilingual hubs.
 */

export * from '../../components/CollaborativeWhiteboard';
export * from '../../components/CollaborativeRooms';
export * from '../../components/AccessibilitySuite';
export * from '../../components/MultilingualTranslationHub';
export * from '../../components/LiveSeminar';
