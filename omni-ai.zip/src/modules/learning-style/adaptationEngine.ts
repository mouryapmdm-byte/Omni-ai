import { LearningStyleProfile, AdaptationStrategy, VARKStyle } from './types';

/**
 * Derives concrete UI & Content Adaptation Strategies from LearningStyleProfile
 */
export function getAdaptationStrategy(profile: LearningStyleProfile): AdaptationStrategy {
  const { dominantStyle, confidence, isManualOverride } = profile;

  // Determine confidence level
  let confidenceLevel: 'strong' | 'mild' | 'unknown' = 'unknown';
  if (confidence >= 70 || isManualOverride) {
    confidenceLevel = 'strong';
  } else if (confidence >= 40) {
    confidenceLevel = 'mild';
  }

  // Balanced default
  if (dominantStyle === 'balanced' || confidenceLevel === 'unknown') {
    return {
      style: 'balanced',
      confidenceLevel,
      prioritizeDiagramsAnd3D: false,
      prioritizeAudioAndNarration: false,
      prioritizeDetailedNotesAndTranscripts: false,
      prioritizeInteractiveAndHandsOn: false,
      description: 'Multi-Modal Balanced Mode: Content is delivered across visual, auditory, text, and interactive formats equally.',
      teachingPromptInstruction: 'Deliver multi-modal instruction combining clear text explanations, audio-friendly phrasing, visual diagrams, and interactive questions.'
    };
  }

  switch (dominantStyle) {
    case 'visual':
      return {
        style: 'visual',
        confidenceLevel,
        prioritizeDiagramsAnd3D: true,
        prioritizeAudioAndNarration: false,
        prioritizeDetailedNotesAndTranscripts: false,
        prioritizeInteractiveAndHandsOn: false,
        description: 'Visual Learning Mode: Automatically expands 3D diagrams, interactive concept maps, and high-fidelity figure animations.',
        teachingPromptInstruction: 'Emphasize spatial analogies, step-by-step visual diagrams, flowcharts, color coding, and geometry in your explanations.'
      };

    case 'auditory':
      return {
        style: 'auditory',
        confidenceLevel,
        prioritizeDiagramsAnd3D: false,
        prioritizeAudioAndNarration: true,
        prioritizeDetailedNotesAndTranscripts: false,
        prioritizeInteractiveAndHandsOn: false,
        description: 'Auditory Learning Mode: Auto-plays lecture audio narration, voice commands, and conversational dialogue explanations.',
        teachingPromptInstruction: 'Use conversational rhythm, memorable verbal rhymes/mnemonics, voice emphasis, and clear spoken tone.'
      };

    case 'reading':
      return {
        style: 'reading',
        confidenceLevel,
        prioritizeDiagramsAnd3D: false,
        prioritizeAudioAndNarration: false,
        prioritizeDetailedNotesAndTranscripts: true,
        prioritizeInteractiveAndHandsOn: false,
        description: 'Reading/Writing Mode: Formats content into structured textbook notes, comprehensive transcripts, and downloadable templates.',
        teachingPromptInstruction: 'Provide rigorous, structured text with bullet points, numbered formulas, precise terminology, and written summaries.'
      };

    case 'kinaesthetic':
      return {
        style: 'kinaesthetic',
        confidenceLevel,
        prioritizeDiagramsAnd3D: true,
        prioritizeAudioAndNarration: false,
        prioritizeDetailedNotesAndTranscripts: false,
        prioritizeInteractiveAndHandsOn: true,
        description: 'Kinaesthetic Mode: Emphasizes interactive 3D overlays, hands-on virtual lab simulations, and immediate practice drills.',
        teachingPromptInstruction: 'Engage with step-by-step interactive problem solving, real-world physical simulations, and immediate practice challenges.'
      };

    default:
      return {
        style: 'balanced',
        confidenceLevel: 'unknown',
        prioritizeDiagramsAnd3D: false,
        prioritizeAudioAndNarration: false,
        prioritizeDetailedNotesAndTranscripts: false,
        prioritizeInteractiveAndHandsOn: false,
        description: 'Balanced Learning Mode',
        teachingPromptInstruction: 'Provide balanced explanations.'
      };
  }
}
