import React, { useState, useRef, useEffect } from 'react';
import { 
  Maximize2, 
  Minimize2, 
  X, 
  Pipette, 
  Sparkles, 
  Camera, 
  Layers, 
  ExternalLink, 
  Disc, 
  Move,
  Eye,
  Sliders
} from 'lucide-react';
import { cn, downloadFileFromUrl } from '@/src/lib/utils';
import { smartboardRecorder } from '../services/smartboardRecordingEngine';

export interface SmartboardPipOverlayProps {
  isOpen: boolean;
  onClose?: () => void;
  theme?: 'light' | 'dark';
  isRecording?: boolean;
  recordingDuration?: number;
  topicTitle?: string;
  phaseTitle?: string;
  defaultPosition?: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
}

export const SmartboardPipOverlay: React.FC<SmartboardPipOverlayProps> = ({
  isOpen,
  onClose,
  theme = 'dark',
  isRecording = false,
  recordingDuration = 0,
  topicTitle = 'Interactive Smartboard',
  phaseTitle = 'Live Presentation Output',
  defaultPosition = 'bottom-right'
}) => {
  const [position, setPosition] = useState<'bottom-right' | 'bottom-left' | 'top-right' | 'top-left'>(defaultPosition);
  const [size, setSize] = useState<'compact' | 'normal' | 'large'>('normal');
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [opacity, setOpacity] = useState<number>(100);
  const [isNativePipActive, setIsNativePipActive] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pipVideoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Synchronize Live Smartboard Canvas Stream for Web / Native PiP
  useEffect(() => {
    if (!isOpen) {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      return;
    }

    // Connect smartboard canvas stream to video element for native PiP capabilities
    try {
      const stream = smartboardRecorder.getCanvasStream(30);
      if (stream) {
        streamRef.current = stream;
        if (pipVideoRef.current) {
          pipVideoRef.current.srcObject = stream;
          pipVideoRef.current.play().catch(() => {});
        }
      }
    } catch (e) {
      console.warn('PiP video stream attachment:', e);
    }

    // Direct Canvas 2D Blit for crystal-sharp in-app PiP rendering
    const renderLoop = () => {
      const sourceCanvas = smartboardRecorder.getCanvas();
      const targetCanvas = canvasRef.current;
      if (sourceCanvas && targetCanvas) {
        const ctx = targetCanvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(sourceCanvas, 0, 0, targetCanvas.width, targetCanvas.height);
        }
      }
      animFrameRef.current = requestAnimationFrame(renderLoop);
    };

    renderLoop();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isOpen]);

  // Setup native video event listeners for picture-in-picture
  useEffect(() => {
    const videoEl = pipVideoRef.current;
    if (!videoEl) return;

    const handleEnter = () => setIsNativePipActive(true);
    const handleLeave = () => setIsNativePipActive(false);

    videoEl.addEventListener('enterpictureinpicture', handleEnter);
    videoEl.addEventListener('leavepictureinpicture', handleLeave);

    return () => {
      videoEl.removeEventListener('enterpictureinpicture', handleEnter);
      videoEl.removeEventListener('leavepictureinpicture', handleLeave);
    };
  }, []);

  // Request Native Browser Picture-in-Picture
  const toggleNativePip = async () => {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setIsNativePipActive(false);
      } else if (pipVideoRef.current) {
        if (!pipVideoRef.current.srcObject) {
          const stream = smartboardRecorder.getCanvasStream(30);
          if (stream) pipVideoRef.current.srcObject = stream;
        }
        await pipVideoRef.current.play();
        await pipVideoRef.current.requestPictureInPicture();
        setIsNativePipActive(true);
      }
    } catch (err) {
      console.warn('Native Picture-in-Picture request failed:', err);
    }
  };

  // Take quick snapshot of current smartboard frame
  const takeSnapshot = () => {
    const dataUrl = smartboardRecorder.getPreviewDataUrl();
    if (dataUrl) {
      downloadFileFromUrl(dataUrl, `Smartboard_Snapshot_${Date.now()}.jpg`);
    }
  };

  // Cycle position clockwise
  const cyclePosition = () => {
    const positions: Array<'top-right' | 'bottom-right' | 'bottom-left' | 'top-left'> = [
      'top-right',
      'bottom-right',
      'bottom-left',
      'top-left'
    ];
    const currentIndex = positions.indexOf(position);
    const nextIndex = (currentIndex + 1) % positions.length;
    setPosition(positions[nextIndex]);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  // Position Classes
  const positionClasses = {
    'bottom-right': 'bottom-20 right-4 sm:right-6',
    'bottom-left': 'bottom-20 left-4 sm:left-6',
    'top-right': 'top-20 right-4 sm:right-6',
    'top-left': 'top-20 left-4 sm:left-6'
  }[position];

  // Size Classes
  const sizeClasses = {
    compact: 'w-[280px]',
    normal: 'w-[360px] sm:w-[400px]',
    large: 'w-[480px] sm:w-[540px]'
  }[size];

  return (
    <aside 
      aria-label="Smartboard Picture-in-Picture live overlay"
      className={cn(
        "fixed z-40 transition-all duration-300 select-none animate-in fade-in zoom-in-95",
        positionClasses
      )}
      style={{ opacity: opacity / 100 }}
    >
      {/* Hidden video element for native browser PiP integration */}
      <video
        ref={pipVideoRef}
        autoPlay
        playsInline
        muted
        className="hidden"
      />

      {isMinimized ? (
        /* Minimized Floating Pill */
        <div className="flex items-center gap-2.5 bg-slate-950/95 border border-cyan-500/40 backdrop-blur-xl shadow-2xl rounded-2xl px-3.5 py-2 text-white">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setIsMinimized(false)}>
            <div className="relative flex items-center justify-center">
              <Layers size={15} className="text-cyan-400" />
              {isRecording && (
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
              )}
            </div>
            <div>
              <span className="text-xs font-black uppercase tracking-wider text-cyan-300 block leading-tight">
                Smartboard PiP
              </span>
              {isRecording && (
                <span className="text-[10px] font-mono text-rose-400 font-bold">
                  REC {formatDuration(recordingDuration)}
                </span>
              )}
            </div>
          </div>

          <div className="w-[1px] h-4 bg-slate-800 my-auto"></div>

          <button
            type="button"
            onClick={() => setIsMinimized(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Expand Smartboard PiP Preview"
          >
            <Maximize2 size={13} />
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
              title="Close PiP"
            >
              <X size={13} />
            </button>
          )}
        </div>
      ) : (
        /* Full Picture-in-Picture Live Preview Window */
        <div className={cn(
          "bg-slate-950/95 border-2 border-cyan-500/50 rounded-2xl shadow-2xl shadow-cyan-950/50 backdrop-blur-2xl overflow-hidden flex flex-col transition-all",
          sizeClasses
        )}>
          {/* PiP Header Bar */}
          <div className="px-3.5 py-2.5 bg-slate-900/90 border-b border-cyan-500/30 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="p-1 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shrink-0">
                <Layers size={13} />
              </div>
              <div className="truncate">
                <div className="flex items-center gap-1.5">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-cyan-300 truncate">
                    Smartboard Live Output
                  </h4>
                  {isRecording ? (
                    <span className="flex items-center gap-1 px-1.5 py-0.2 rounded-md bg-rose-500/20 border border-rose-500/40 text-[9px] font-black uppercase tracking-wider text-rose-400 shrink-0 animate-pulse">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                      REC
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.2 rounded-md bg-emerald-500/20 text-emerald-400 text-[9px] font-bold uppercase tracking-wider shrink-0">
                      LIVE
                    </span>
                  )}
                </div>
                <p className="text-[9px] text-slate-400 font-mono truncate leading-tight mt-0.5">
                  {phaseTitle || topicTitle}
                </p>
              </div>
            </div>

            {/* PiP Controls */}
            <div className="flex items-center gap-1 shrink-0">
              {/* Cycle Screen Corner */}
              <button
                type="button"
                onClick={cyclePosition}
                className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors cursor-pointer"
                title={`Move Window Corner (Current: ${position})`}
              >
                <Move size={12} />
              </button>

              {/* Native OS Picture-in-Picture Pop-out */}
              <button
                type="button"
                onClick={toggleNativePip}
                className={cn(
                  "p-1.5 rounded-lg transition-colors cursor-pointer",
                  isNativePipActive
                    ? "bg-cyan-500 text-slate-950 font-bold"
                    : "text-slate-400 hover:text-cyan-300 hover:bg-slate-800"
                )}
                title="Pop out to OS Picture-in-Picture window"
              >
                <ExternalLink size={12} />
              </button>

              {/* Snapshot */}
              <button
                type="button"
                onClick={takeSnapshot}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                title="Save High-Res Smartboard Snapshot"
              >
                <Camera size={12} />
              </button>

              {/* Size Switcher */}
              <button
                type="button"
                onClick={() => setSize(s => s === 'compact' ? 'normal' : s === 'normal' ? 'large' : 'compact')}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer text-[10px] font-mono font-bold"
                title={`Resize PiP (Current: ${size})`}
              >
                {size === 'compact' ? 'S' : size === 'normal' ? 'M' : 'L'}
              </button>

              {/* Minimize */}
              <button
                type="button"
                onClick={() => setIsMinimized(true)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                title="Minimize PiP Preview"
              >
                <Minimize2 size={12} />
              </button>

              {/* Close */}
              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Close PiP"
                >
                  <X size={12} />
                </button>
              )}
            </div>
          </div>

          {/* Live Canvas Viewport (16:9 Aspect Ratio) */}
          <div className="relative w-full aspect-video bg-black overflow-hidden group">
            <canvas
              ref={canvasRef}
              width={960}
              height={540}
              className="w-full h-full object-contain"
            />

            {/* Live Recording HUD Stamp */}
            <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-slate-950/80 backdrop-blur-md px-2 py-0.5 rounded-full border border-slate-700/60 pointer-events-none">
              <span className={cn(
                "w-1.5 h-1.5 rounded-full",
                isRecording ? "bg-rose-500 animate-ping" : "bg-emerald-400"
              )}></span>
              <span className="font-mono text-[9px] text-slate-300 font-bold">
                {isRecording ? formatDuration(recordingDuration) : "1080p50 STREAM"}
              </span>
            </div>

            {/* Quick Hover Controls Overlay */}
            <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-slate-950/80 backdrop-blur-md px-2 py-1 rounded-xl border border-slate-700">
              <span className="text-[9px] text-slate-400 font-bold">Opacity:</span>
              {[100, 85, 65].map((op) => (
                <button
                  key={op}
                  type="button"
                  onClick={() => setOpacity(op)}
                  className={cn(
                    "px-1.5 py-0.5 rounded text-[9px] font-bold transition-all cursor-pointer",
                    opacity === op ? "bg-cyan-600 text-white" : "text-slate-400 hover:text-slate-200"
                  )}
                >
                  {op}%
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
