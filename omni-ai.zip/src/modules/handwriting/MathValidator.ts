import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });

export async function validateMath(latex: string, expectedAnswer: string): Promise<{ isCorrect: boolean; explanation: string }> {
  const prompt = `Validate if this LaTeX math expression is correct for the problem: ${expectedAnswer}.
Expression: ${latex}.
Return a JSON object: { "isCorrect": boolean, "explanation": string }.`;
  
  const result = await ai.models.generateContent({
    model: 'gemini-2.0-flash',
    contents: prompt
  });
  return JSON.parse(result.text || '{}');
}
