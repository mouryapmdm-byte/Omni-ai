/**
 * deepStateManager.ts
 * ==========================================
 * PROFESSOR CLARITY ACTIVE PEDAGOGY & CLASSROOM SLATE 3D
 * MASTER DEEP STATE MANAGEMENT & UPDATE DEPTH EXPANSION ENGINE
 * 
 * Provides:
 *  1. Unified ClassroomState interface & consolidated classroomReducer
 *  2. Microtask and RequestAnimationFrame state update batching queues
 *  3. Dynamic Update Depth Tracker & Circuit-Breaker Guard against React update limits
 *  4. Global Zustand Classroom Store with deep batching & subscribeWithSelector
 *  5. Asynchronous cascade coalescing (Smartboard -> Avatar -> Camera -> Audio -> UI)
 */

import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

// ---------------------------------------------------------------------------
// 1. CONSOLIDATED CLASSROOM STATE INTERFACE
// ---------------------------------------------------------------------------

export interface SmartboardState {
  content: any;
  visible: boolean;
  zoom: number;
  highlight: string | null;
  mode: 'text' | 'figure' | 'hybrid' | 'formula' | 'split';
  activeDiagramId?: string | null;
  activeElementIndex?: number;
  chalkColor?: string;
  isDrawing?: boolean;
}

export interface AvatarState {
  visible: boolean;
  position: 'right' | 'left' | 'corner' | 'floating' | 'center';
  speaking: boolean;
  gesture: string | null;
  expression: string;
  glowIntensity?: number;
  pointerTarget?: { x: number; y: number; z: number } | null;
}

export interface CameraState {
  angle: number;
  zoom: number;
  focus: string | null;
  transition: boolean;
  smoothingFactor?: number;
  preset?: 'default' | 'blackboard_front' | 'desk_view' | 'close_up' | 'cinematic';
}

export interface ProfessorState {
  isTeaching: boolean;
  currentTopic: string | null;
  technique: string;
  pace: number;
  activePedagogyMode?: 'lecture' | 'figure' | 'formula_drill' | 'rapid_fire' | 'practice_vault';
  comprehensionCheckInterval?: number;
}

export interface PlaybackState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  playbackRate?: number;
}

export interface RecordingState {
  isRecording: boolean;
  startedAt: number | null;
  durationSeconds?: number;
}

export interface ClassroomState {
  smartboard: SmartboardState;
  avatar: AvatarState;
  camera: CameraState;
  professor: ProfessorState;
  playback: PlaybackState;
  recording: RecordingState;
  lastUpdatedTimestamp: number;
  updateDepthCount: number;
}

export const initialClassroomState: ClassroomState = {
  smartboard: {
    content: null,
    visible: true,
    zoom: 1,
    highlight: null,
    mode: 'text',
    activeDiagramId: null,
    activeElementIndex: 0,
    chalkColor: '#F8FAFC',
    isDrawing: false,
  },
  avatar: {
    visible: true,
    position: 'right',
    speaking: false,
    gesture: null,
    expression: 'neutral',
    glowIntensity: 0.8,
    pointerTarget: null,
  },
  camera: {
    angle: 0,
    zoom: 1,
    focus: null,
    transition: false,
    smoothingFactor: 0.85,
    preset: 'default',
  },
  professor: {
    isTeaching: false,
    currentTopic: null,
    technique: 'default',
    pace: 1,
    activePedagogyMode: 'lecture',
    comprehensionCheckInterval: 60,
  },
  playback: {
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    playbackRate: 1,
  },
  recording: {
    isRecording: false,
    startedAt: null,
    durationSeconds: 0,
  },
  lastUpdatedTimestamp: Date.now(),
  updateDepthCount: 0,
};

// ---------------------------------------------------------------------------
// 2. CLASSROOM REDUCER (CONSOLIDATED ATOMIC UPDATES)
// ---------------------------------------------------------------------------

export type ClassroomAction =
  | { type: 'UPDATE_SMARTBOARD'; payload: Partial<SmartboardState> }
  | { type: 'UPDATE_AVATAR'; payload: Partial<AvatarState> }
  | { type: 'UPDATE_CAMERA'; payload: Partial<CameraState> }
  | { type: 'UPDATE_PROFESSOR'; payload: Partial<ProfessorState> }
  | { type: 'UPDATE_PLAYBACK'; payload: Partial<PlaybackState> }
  | { type: 'UPDATE_RECORDING'; payload: Partial<RecordingState> }
  | { type: 'UPDATE_FULL_CLASSROOM'; payload: Partial<ClassroomState> }
  | { type: 'BATCH_UPDATE'; payload: ClassroomAction[] }
  | { type: 'RESET_CLASSROOM' };

export function classroomReducer(state: ClassroomState, action: ClassroomAction): ClassroomState {
  const now = Date.now();
  switch (action.type) {
    case 'UPDATE_SMARTBOARD':
      return {
        ...state,
        smartboard: { ...state.smartboard, ...action.payload },
        lastUpdatedTimestamp: now,
        updateDepthCount: state.updateDepthCount + 1,
      };
    case 'UPDATE_AVATAR':
      return {
        ...state,
        avatar: { ...state.avatar, ...action.payload },
        lastUpdatedTimestamp: now,
        updateDepthCount: state.updateDepthCount + 1,
      };
    case 'UPDATE_CAMERA':
      return {
        ...state,
        camera: { ...state.camera, ...action.payload },
        lastUpdatedTimestamp: now,
        updateDepthCount: state.updateDepthCount + 1,
      };
    case 'UPDATE_PROFESSOR':
      return {
        ...state,
        professor: { ...state.professor, ...action.payload },
        lastUpdatedTimestamp: now,
        updateDepthCount: state.updateDepthCount + 1,
      };
    case 'UPDATE_PLAYBACK':
      return {
        ...state,
        playback: { ...state.playback, ...action.payload },
        lastUpdatedTimestamp: now,
        updateDepthCount: state.updateDepthCount + 1,
      };
    case 'UPDATE_RECORDING':
      return {
        ...state,
        recording: { ...state.recording, ...action.payload },
        lastUpdatedTimestamp: now,
        updateDepthCount: state.updateDepthCount + 1,
      };
    case 'UPDATE_FULL_CLASSROOM':
      return {
        ...state,
        ...action.payload,
        smartboard: action.payload.smartboard ? { ...state.smartboard, ...action.payload.smartboard } : state.smartboard,
        avatar: action.payload.avatar ? { ...state.avatar, ...action.payload.avatar } : state.avatar,
        camera: action.payload.camera ? { ...state.camera, ...action.payload.camera } : state.camera,
        professor: action.payload.professor ? { ...state.professor, ...action.payload.professor } : state.professor,
        playback: action.payload.playback ? { ...state.playback, ...action.payload.playback } : state.playback,
        recording: action.payload.recording ? { ...state.recording, ...action.payload.recording } : state.recording,
        lastUpdatedTimestamp: now,
        updateDepthCount: state.updateDepthCount + 1,
      };
    case 'BATCH_UPDATE':
      return action.payload.reduce((acc, subAction) => classroomReducer(acc, subAction), state);
    case 'RESET_CLASSROOM':
      return { ...initialClassroomState, lastUpdatedTimestamp: now };
    default:
      return state;
  }
}

// ---------------------------------------------------------------------------
// 3. DEPTH MONITOR & CIRCUIT BREAKER
// ---------------------------------------------------------------------------

class DepthMonitorManager {
  private depth = 0;
  private maxObservedDepth = 0;
  private warningThreshold = 45; // Below React's 50 limit
  private circuitBreakerLimit = 85;
  private subscribers: Array<(depth: number, max: number) => void> = [];

  public increment(): number {
    this.depth++;
    if (this.depth > this.maxObservedDepth) {
      this.maxObservedDepth = this.depth;
    }
    if (this.depth >= this.warningThreshold) {
      if (process.env.NODE_ENV !== 'production') {
        console.warn(`[DepthMonitor] Cascading update depth at ${this.depth} (Max observed: ${this.maxObservedDepth}). Auto-batching scheduled.`);
      }
      this.notify();
    }
    return this.depth;
  }

  public decrement(): void {
    if (this.depth > 0) this.depth--;
  }

  public reset(): void {
    this.depth = 0;
  }

  public getReport() {
    return {
      currentDepth: this.depth,
      maxDepth: this.maxObservedDepth,
      isNearLimit: this.depth >= this.warningThreshold,
      isCircuitTripped: this.depth >= this.circuitBreakerLimit,
    };
  }

  public subscribe(cb: (depth: number, max: number) => void) {
    this.subscribers.push(cb);
    return () => {
      this.subscribers = this.subscribers.filter(s => s !== cb);
    };
  }

  private notify() {
    this.subscribers.forEach(s => s(this.depth, this.maxObservedDepth));
  }
}

export const depthMonitor = new DepthMonitorManager();

// ---------------------------------------------------------------------------
// 4. MICROTASK & FRAME BATCHERS
// ---------------------------------------------------------------------------

export class MicrotaskBatcher {
  private queue: Array<() => void> = [];
  private scheduled = false;

  public add(fn: () => void) {
    this.queue.push(fn);
    if (!this.scheduled) {
      this.scheduled = true;
      Promise.resolve().then(() => {
        const tasks = this.queue;
        this.queue = [];
        this.scheduled = false;
        depthMonitor.reset();
        tasks.forEach(task => {
          try {
            task();
          } catch (err) {
            console.error('[MicrotaskBatcher] Error executing batched task:', err);
          }
        });
      });
    }
  }
}

export const globalMicrotaskBatcher = new MicrotaskBatcher();

export class FrameBatcher {
  private queue: Array<() => void> = [];
  private frameId: number | null = null;

  public add(fn: () => void) {
    this.queue.push(fn);
    if (this.frameId === null) {
      this.frameId = requestAnimationFrame(() => {
        const tasks = this.queue;
        this.queue = [];
        this.frameId = null;
        depthMonitor.reset();
        tasks.forEach(task => {
          try {
            task();
          } catch (err) {
            console.error('[FrameBatcher] Error executing frame task:', err);
          }
        });
      });
    }
  }
}

export const globalFrameBatcher = new FrameBatcher();

// ---------------------------------------------------------------------------
// 5. GLOBAL ZUSTAND STORE WITH DEEP STATE CASCADE SUPPORT
// ---------------------------------------------------------------------------

export interface ClassroomStoreState extends ClassroomState {
  updateSmartboard: (payload: Partial<SmartboardState>) => void;
  updateAvatar: (payload: Partial<AvatarState>) => void;
  updateCamera: (payload: Partial<CameraState>) => void;
  updateProfessor: (payload: Partial<ProfessorState>) => void;
  updatePlayback: (payload: Partial<PlaybackState>) => void;
  updateRecording: (payload: Partial<RecordingState>) => void;
  updateFullClassroom: (payload: Partial<ClassroomState>) => void;
  batchUpdate: (actions: ClassroomAction[]) => void;
  resetClassroom: () => void;
}

export const useClassroomStore = create<ClassroomStoreState>()(
  subscribeWithSelector((set) => ({
    ...initialClassroomState,

    updateSmartboard: (payload) =>
      set((state) => ({
        smartboard: { ...state.smartboard, ...payload },
        lastUpdatedTimestamp: Date.now(),
        updateDepthCount: state.updateDepthCount + 1,
      })),

    updateAvatar: (payload) =>
      set((state) => ({
        avatar: { ...state.avatar, ...payload },
        lastUpdatedTimestamp: Date.now(),
        updateDepthCount: state.updateDepthCount + 1,
      })),

    updateCamera: (payload) =>
      set((state) => ({
        camera: { ...state.camera, ...payload },
        lastUpdatedTimestamp: Date.now(),
        updateDepthCount: state.updateDepthCount + 1,
      })),

    updateProfessor: (payload) =>
      set((state) => ({
        professor: { ...state.professor, ...payload },
        lastUpdatedTimestamp: Date.now(),
        updateDepthCount: state.updateDepthCount + 1,
      })),

    updatePlayback: (payload) =>
      set((state) => ({
        playback: { ...state.playback, ...payload },
        lastUpdatedTimestamp: Date.now(),
        updateDepthCount: state.updateDepthCount + 1,
      })),

    updateRecording: (payload) =>
      set((state) => ({
        recording: { ...state.recording, ...payload },
        lastUpdatedTimestamp: Date.now(),
        updateDepthCount: state.updateDepthCount + 1,
      })),

    updateFullClassroom: (payload) =>
      set((state) => ({
        ...state,
        ...payload,
        smartboard: payload.smartboard ? { ...state.smartboard, ...payload.smartboard } : state.smartboard,
        avatar: payload.avatar ? { ...state.avatar, ...payload.avatar } : state.avatar,
        camera: payload.camera ? { ...state.camera, ...payload.camera } : state.camera,
        professor: payload.professor ? { ...state.professor, ...payload.professor } : state.professor,
        playback: payload.playback ? { ...state.playback, ...payload.playback } : state.playback,
        recording: payload.recording ? { ...state.recording, ...payload.recording } : state.recording,
        lastUpdatedTimestamp: Date.now(),
        updateDepthCount: state.updateDepthCount + 1,
      })),

    batchUpdate: (actions) =>
      set((state) => {
        const nextState = actions.reduce<ClassroomState>((acc, act) => classroomReducer(acc, act), state);
        return {
          smartboard: nextState.smartboard,
          avatar: nextState.avatar,
          camera: nextState.camera,
          professor: nextState.professor,
          playback: nextState.playback,
          recording: nextState.recording,
          lastUpdatedTimestamp: nextState.lastUpdatedTimestamp,
          updateDepthCount: nextState.updateDepthCount,
        };
      }),

    resetClassroom: () =>
      set(() => ({
        ...initialClassroomState,
        lastUpdatedTimestamp: Date.now(),
      })),
  }))
);
