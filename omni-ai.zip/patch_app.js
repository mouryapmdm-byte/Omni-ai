const fs = require('fs');
const file = 'src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

const oldImageParsing = `      const imageRequestMatch = response.match(/<DRAW_IMAGE>(.*?)<\\/DRAW_IMAGE>/is);
      if (imageRequestMatch) {
        const prompt = imageRequestMatch[1].trim();
        imageUrl = await handleGenerateMedia(prompt, 'image');`;

const newImageParsing = `      const imageRequestMatch = response.match(/<DRAW_IMAGE>(.*?)<\\/DRAW_IMAGE>/is);
      let mathGraphFunctions;
      if (imageRequestMatch) {
        const prompt = imageRequestMatch[1].trim();
        
        // Detect if it's a math graph
        if (prompt.toLowerCase().includes('graph') || prompt.toLowerCase().includes('function') || prompt.match(/f\\(x\\)=/i) || prompt.match(/y=/i)) {
            // Attempt to extract functions like f(x)=x^2 or just x^2
            const functionMatches = [...prompt.matchAll(/(?:f\\(x\\)|g\\(x\\)|y)\\s*=\\s*([^\\s,]+)/gi)].map(m => m[1]) || [];
            if (functionMatches.length > 0) {
                mathGraphFunctions = functionMatches;
            } else {
                // If it asks for a graph but regex failed, maybe try to fallback to a simple parse or just generate image anyway
                const possibleFunc = prompt.match(/Graph of ([a-zA-Z0-9_\\-\\+\\*\\/\\^\\(\\)\\. ]+)/i);
                if (possibleFunc && possibleFunc[1]) {
                    mathGraphFunctions = possibleFunc[1].split('and').map(s => s.trim().replace(/^(?:f\\(x\\)|g\\(x\\)|y)\\s*=\\s*/, ''));
                }
            }
        }
        
        if (mathGraphFunctions && mathGraphFunctions.length > 0) {
            // It's a math graph, skip image generation and let Chat handle the MathGraph rendering
        } else {
            imageUrl = await handleGenerateMedia(prompt, 'image');
        }`;

content = content.replace(oldImageParsing, newImageParsing);

const oldFinalContent = `        finalContent = finalContent.replace(/<ANNOTATIONS>.*?<\\/ANNOTATIONS>/s, "").trim();
      }`;
const newFinalContent = `        finalContent = finalContent.replace(/<ANNOTATIONS>.*?<\\/ANNOTATIONS>/s, "").trim();
      }
      
      const newMsgId = generateId('msg_');
`;
// Let's verify and just replace the whole block more safely using string manipulation

