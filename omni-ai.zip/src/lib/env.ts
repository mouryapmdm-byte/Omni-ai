// ==========================================
// ENVIRONMENT CONFIGURATION & VALIDATION
// ==========================================

export interface ProductionEnv {
  firebaseApiKey: string;
  firebaseAuthDomain: string;
  firebaseProjectId: string;
  firebaseStorageBucket: string;
  firebaseMessagingSenderId: string;
  firebaseAppId: string;
  appUrl: string;
  aiApiEndpoint: string;
  env: 'development' | 'staging' | 'production';
}

const requiredEnvVars = [
  'VITE_FIREBASE_API_KEY',
  'VITE_FIREBASE_AUTH_DOMAIN',
  'VITE_FIREBASE_PROJECT_ID',
  'VITE_FIREBASE_STORAGE_BUCKET',
  'VITE_FIREBASE_MESSAGING_SENDER_ID',
  'VITE_FIREBASE_APP_ID',
  'VITE_APP_URL'
];

export function validateEnvironment(): ProductionEnv {
  const missing: string[] = [];

  for (const key of requiredEnvVars) {
    if (!import.meta.env[key] || import.meta.env[key].includes('your_')) {
      missing.push(key);
    }
  }

  if (missing.length > 0) {
    console.warn(
      `[Security Warning] Missing or placeholder environment variables detected: ${missing.join(', ')}. App will run with fallback defaults in development mode.`
    );
  }

  const appUrl = import.meta.env.VITE_APP_URL || window.location.origin;

  // Security guard against localhost in production builds
  if (import.meta.env.MODE === 'production' && appUrl.includes('localhost')) {
    console.error('[Security Error] Localhost URL detected in production build mode!');
  }

  return {
    firebaseApiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
    firebaseAuthDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
    firebaseProjectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
    firebaseStorageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
    firebaseMessagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
    firebaseAppId: import.meta.env.VITE_FIREBASE_APP_ID || '',
    appUrl,
    aiApiEndpoint: import.meta.env.VITE_AI_API_ENDPOINT || 'https://api.omniai.com/v1',
    env: (import.meta.env.MODE as ProductionEnv['env']) || 'development'
  };
}

export const env = validateEnvironment();
