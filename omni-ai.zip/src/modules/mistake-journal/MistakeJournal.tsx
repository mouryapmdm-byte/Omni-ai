import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  AlertTriangle, 
  ChevronRight, 
  Trash2, 
  Sparkles, 
  Award, 
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Zap
} from 'lucide-react';
import { Mistake, MistakeCategory } from './types';
import { MistakeClassifier, MISTAKE_CATEGORY_INFO } from './mistakeClassifier';
import { MistakeFilter } from './MistakeFilter';

interface MistakeJournalProps {
  isDark?: boolean;
  mistakes: Mistake[];
  onLaunchRemediation?: (mistake: Mistake) => void;
  onToggleReviewed?: (id: string, improved: boolean) => void;
}

export const MistakeJournal: React.FC<MistakeJournalProps> = ({
  isDark = true,
  mistakes,
  onLaunchRemediation,
  onToggleReviewed
}) => {
  const [selectedCategory, setSelectedCategory] = useState<MistakeCategory | 'all'>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showOnlyUnresolved, setShowOnlyUnresolved] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'timeline' | 'grouped'>('timeline');

  // Filtered mistakes
  const filteredMistakes = useMemo(() => {
    return mistakes.filter(m => {
      if (selectedCategory !== 'all' && m.mistakeType !== selectedCategory) return false;
      if (selectedSubject !== 'all' && m.subject.toLowerCase() !== selectedSubject.toLowerCase()) return false;
      if (showOnlyUnresolved && m.improved) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          m.questionText.toLowerCase().includes(q) ||
          m.chapterName.toLowerCase().includes(q) ||
          m.topicName.toLowerCase().includes(q) ||
          (m.detailedDiagnosis && m.detailedDiagnosis.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [mistakes, selectedCategory, selectedSubject, showOnlyUnresolved, searchQuery]);

  return (
    <div className="space-y-6">
      {/* Search & Filter Bar */}
      <MistakeFilter
        isDark={isDark}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        selectedSubject={selectedSubject}
        onSelectSubject={setSelectedSubject}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        showOnlyUnresolved={showOnlyUnresolved}
        onToggleUnresolved={setShowOnlyUnresolved}
      />

      {/* View Switcher & Counter */}
      <div className="flex items-center justify-between px-1 text-xs opacity-75">
        <span>
          Showing <strong>{filteredMistakes.length}</strong> logged mistake{filteredMistakes.length !== 1 ? 's' : ''}
        </span>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode('timeline')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
              viewMode === 'timeline' 
                ? 'bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30' 
                : 'opacity-60 hover:opacity-100'
            }`}
          >
            Chronological Timeline
          </button>
          <button
            onClick={() => setViewMode('grouped')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
              viewMode === 'grouped' 
                ? 'bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30' 
                : 'opacity-60 hover:opacity-100'
            }`}
          >
            Group by Mistake Type
          </button>
        </div>
      </div>

      {/* Timeline Stream */}
      {filteredMistakes.length === 0 ? (
        <div className={`p-12 text-center rounded-2xl border ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-3">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-base mb-1">Zero Matching Errors!</h3>
          <p className="text-xs opacity-60">All mistakes in this category are resolved or no entries logged.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMistakes.map(m => {
            const catInfo = MISTAKE_CATEGORY_INFO[m.mistakeType];

            return (
              <div
                key={m.id}
                className={`p-5 rounded-2xl border transition-all ${
                  m.improved
                    ? isDark ? 'bg-slate-900/60 border-slate-800/80 opacity-75' : 'bg-slate-50 border-slate-200 opacity-80'
                    : isDark ? 'bg-slate-900/90 border-slate-800 hover:border-slate-700' : 'bg-white border-slate-200 shadow-sm'
                }`}
              >
                {/* Header row */}
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${catInfo?.badgeColor}`}>
                      {catInfo?.name || m.mistakeType}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                      {m.subject}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300">
                      {m.chapterName}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-xs opacity-70">
                    <span className="flex items-center gap-1 font-mono text-[11px]">
                      <Clock className="w-3 h-3" /> {m.timeSpent}s
                    </span>
                    <span className="flex items-center gap-1 font-mono text-[11px]">
                      <Calendar className="w-3 h-3" /> {new Date(m.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {/* Question text */}
                <p className="text-sm font-semibold leading-relaxed my-3">
                  {m.questionText}
                </p>

                {/* Answers Comparison Box */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-3">
                  <div className={`p-3 rounded-xl border text-xs ${
                    isDark ? 'bg-rose-950/20 border-rose-800/40 text-rose-200' : 'bg-rose-50 border-rose-200 text-rose-900'
                  }`}>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-rose-400 mb-0.5">Your Response</span>
                    <span className="font-mono font-bold text-sm">{m.studentAnswer}</span>
                  </div>

                  <div className={`p-3 rounded-xl border text-xs ${
                    isDark ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-200' : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  }`}>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-emerald-400 mb-0.5">Correct Answer</span>
                    <span className="font-mono font-bold text-sm">{m.correctAnswer}</span>
                  </div>
                </div>

                {/* Error Diagnosis */}
                {m.detailedDiagnosis && (
                  <div className={`p-3 rounded-xl text-xs leading-relaxed mb-3 ${
                    isDark ? 'bg-slate-950/60 border border-slate-800 text-slate-300' : 'bg-slate-100 border border-slate-200 text-slate-700'
                  }`}>
                    <strong className="text-amber-400">Cognitive Diagnosis: </strong>
                    {m.detailedDiagnosis}
                  </div>
                )}

                {/* Action footer */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/40 text-xs">
                  <div className="flex items-center gap-2">
                    {m.improved ? (
                      <span className="flex items-center gap-1 text-emerald-400 font-bold text-xs">
                        <CheckCircle2 className="w-4 h-4" /> Remediation Mastered
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-rose-400 font-semibold text-xs">
                        <AlertTriangle className="w-3.5 h-3.5" /> Action Required
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onToggleReviewed?.(m.id, !m.improved)}
                      className="px-2.5 py-1 rounded-lg border border-slate-700 text-[11px] opacity-70 hover:opacity-100 transition"
                    >
                      {m.improved ? 'Reopen Gap' : 'Mark Resolved'}
                    </button>
                    <button
                      onClick={() => onLaunchRemediation?.(m)}
                      className="px-3 py-1 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1 shadow transition"
                    >
                      <Zap className="w-3 h-3" /> Practice Fix
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
