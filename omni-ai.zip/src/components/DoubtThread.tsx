import React, { useState } from 'react';
import { 
  ArrowLeft, ThumbsUp, ThumbsDown, MessageSquare, ShieldCheck, Sparkles, 
  HelpCircle, BookOpen, Send, CheckCircle2, User, Clock, AlertCircle, HeartHandshake
} from 'lucide-react';
import { Doubt, Answer } from '../modules/doubt-board/types';
import { DoubtService } from '../modules/doubt-board/doubtService';
import { cn } from '../lib/utils';

interface DoubtThreadProps {
  doubt: Doubt;
  onBack: () => void;
  onDoubtUpdated?: () => void;
  isDark?: boolean;
}

export const DoubtThread: React.FC<DoubtThreadProps> = ({
  doubt,
  onBack,
  onDoubtUpdated,
  isDark = true
}) => {
  const [currentDoubt, setCurrentDoubt] = useState<Doubt>(doubt);
  const [answers, setAnswers] = useState<Answer[]>(() => DoubtService.getAnswersForDoubt(doubt.id));
  const [newAnswerText, setNewAnswerText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const handleUpvoteDoubt = () => {
    DoubtService.upvoteDoubt(currentDoubt.id);
    const updated = DoubtService.getAllDoubts().find(d => d.id === currentDoubt.id);
    if (updated) {
      setCurrentDoubt(updated);
      onDoubtUpdated?.();
    }
  };

  const handleToggleConfused = () => {
    const newCount = DoubtService.toggleAlsoConfused(currentDoubt.id);
    setCurrentDoubt(prev => ({
      ...prev,
      confusedCount: newCount,
      userAlsoConfused: !prev.userAlsoConfused
    }));
    onDoubtUpdated?.();
  };

  const handleVoteAnswer = (ansId: string, dir: 'up' | 'down') => {
    DoubtService.voteAnswer(ansId, dir);
    setAnswers(DoubtService.getAnswersForDoubt(currentDoubt.id));
  };

  const handleToggleHelpful = (ansId: string) => {
    DoubtService.toggleHelpful(ansId);
    setAnswers(DoubtService.getAnswersForDoubt(currentDoubt.id));
  };

  const handleSubmitAnswer = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessNotice(null);

    if (!newAnswerText.trim()) return;

    setIsSubmitting(true);
    const res = DoubtService.postAnswer({
      doubtId: currentDoubt.id,
      answerText: newAnswerText.trim(),
      answerType: 'student'
    });

    setIsSubmitting(false);

    if (res.error) {
      setErrorMsg(res.error);
    } else {
      setNewAnswerText('');
      setAnswers(DoubtService.getAnswersForDoubt(currentDoubt.id));
      setSuccessNotice('Your explanation has been posted anonymously!');
      setTimeout(() => setSuccessNotice(null), 4000);
      onDoubtUpdated?.();
    }
  };

  return (
    <div className={cn(
      "w-full rounded-2xl border transition-all p-4 md:p-6 space-y-6",
      isDark ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-900 shadow-sm"
    )}>
      {/* Navigation */}
      <div className="flex items-center justify-between border-b pb-4 border-slate-700/50">
        <button
          onClick={onBack}
          className={cn(
            "flex items-center gap-2 text-sm font-semibold px-3 py-1.5 rounded-lg transition-all",
            isDark ? "text-slate-400 hover:text-white hover:bg-slate-800" : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
          )}
        >
          <ArrowLeft size={16} /> Back to Doubt Board
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs px-2.5 py-1 rounded-full font-medium bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            {currentDoubt.topicTitle || 'General Concept'}
          </span>
          <span className="text-xs text-slate-400 flex items-center gap-1">
            <Clock size={12} /> {new Date(currentDoubt.createdAt).toLocaleDateString()}
          </span>
        </div>
      </div>

      {/* Main Doubt Question Card */}
      <div className={cn(
        "rounded-xl p-5 border relative overflow-hidden",
        isDark ? "bg-slate-800/80 border-slate-700" : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-500 flex items-center justify-center text-xs font-bold text-white shadow-sm">
              <User size={14} />
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-300">
                {currentDoubt.anonId} <span className="text-[10px] text-slate-400 font-normal">(Anonymous Student)</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Chapter: {currentDoubt.chapterTitle || 'Physics'}
              </div>
            </div>
          </div>

          {/* Normalization indicator */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleToggleConfused}
              className={cn(
                "px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 transition-all border",
                currentDoubt.userAlsoConfused
                  ? "bg-rose-500/20 text-rose-300 border-rose-500/30"
                  : isDark ? "bg-slate-700/60 text-slate-300 border-slate-600 hover:bg-slate-700" : "bg-white text-slate-700 border-slate-300 hover:bg-slate-100"
              )}
              title="Click if you also found this confusing (helps normalize questions)"
            >
              <HeartHandshake size={14} className={currentDoubt.userAlsoConfused ? "text-rose-400" : ""} />
              <span>{currentDoubt.confusedCount || 1} also confused</span>
            </button>
          </div>
        </div>

        <h2 className="text-lg md:text-xl font-bold leading-relaxed mb-4 text-slate-100">
          {currentDoubt.questionText}
        </h2>

        {/* Optional Diagram / Image */}
        {currentDoubt.imageUrl && (
          <div className="mb-4 rounded-lg overflow-hidden border border-slate-700/60 max-w-lg bg-black/40">
            <img 
              src={currentDoubt.imageUrl} 
              alt="Doubt diagram" 
              className="max-h-72 w-full object-contain"
            />
          </div>
        )}

        {/* Question actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-700/40 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={handleUpvoteDoubt}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all border",
                currentDoubt.userHasUpvoted
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                  : isDark ? "bg-slate-700/60 text-slate-300 border-slate-600 hover:bg-slate-700" : "bg-white text-slate-700 border-slate-300 hover:bg-slate-100"
              )}
            >
              <ThumbsUp size={13} />
              <span>Upvote ({currentDoubt.upvotes})</span>
            </button>
            <span className="text-slate-400 flex items-center gap-1 ml-2">
              <MessageSquare size={13} /> {answers.length} Answers
            </span>
          </div>

          <div className="text-[11px] text-slate-400 italic">
            Zero judgment zone • 100% Anonymous Q&A
          </div>
        </div>
      </div>

      {/* Answers Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold flex items-center gap-2">
            <span>Answers & Explanations</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
              {answers.length}
            </span>
          </h3>
          <span className="text-xs text-slate-400">
            Verified answers pinned at top
          </span>
        </div>

        {answers.length === 0 ? (
          <div className={cn(
            "p-8 rounded-xl border text-center space-y-2",
            isDark ? "bg-slate-800/40 border-slate-800 text-slate-400" : "bg-slate-50 border-slate-200 text-slate-500"
          )}>
            <HelpCircle size={32} className="mx-auto text-indigo-400 opacity-60" />
            <p className="font-medium text-sm">No answers posted yet.</p>
            <p className="text-xs">Professor Clarity AI is generating an authoritative answer, or be the first classmate to help!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {answers.map((ans) => {
              const isVerified = ans.answerType === 'professor-verified';
              const isAI = ans.answerType === 'ai';

              return (
                <div
                  key={ans.id}
                  className={cn(
                    "rounded-xl p-5 border transition-all space-y-3",
                    isVerified
                      ? isDark 
                        ? "bg-amber-950/20 border-amber-500/40 shadow-sm" 
                        : "bg-amber-50/60 border-amber-200 shadow-sm"
                      : isAI
                        ? isDark 
                          ? "bg-indigo-950/20 border-indigo-500/40" 
                          : "bg-indigo-50/60 border-indigo-200"
                        : isDark ? "bg-slate-800/60 border-slate-700/80" : "bg-slate-50 border-slate-200"
                  )}
                >
                  {/* Answer Header */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      {isVerified ? (
                        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold">
                          <ShieldCheck size={14} className="text-amber-400" />
                          <span>Professor Verified</span>
                        </div>
                      ) : isAI ? (
                        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-bold">
                          <Sparkles size={14} className="text-indigo-400" />
                          <span>AI Auto-Answer (Professor Clarity)</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300">
                          <div className="w-5 h-5 rounded-full bg-slate-700 flex items-center justify-center text-[10px] text-white">
                            P
                          </div>
                          <span>{ans.authorLabel || 'Classmate'}</span>
                        </div>
                      )}
                    </div>

                    <div className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock size={11} /> {new Date(ans.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  {/* Answer Body */}
                  <p className="text-sm leading-relaxed whitespace-pre-wrap text-slate-200 font-normal">
                    {ans.answerText}
                  </p>

                  {/* Reference Citation if available */}
                  {ans.referenceSource && (
                    <div className="flex items-center gap-2 text-xs text-indigo-300/90 bg-indigo-500/10 px-3 py-1.5 rounded-lg border border-indigo-500/20">
                      <BookOpen size={13} className="shrink-0 text-indigo-400" />
                      <span><strong>Reference:</strong> {ans.referenceSource}</span>
                    </div>
                  )}

                  {/* Answer Footer & Feedback */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-700/30 text-xs">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleVoteAnswer(ans.id, 'up')}
                        className={cn(
                          "flex items-center gap-1 px-2.5 py-1 rounded-md transition-all font-medium",
                          ans.userVote === 'up'
                            ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                            : isDark ? "hover:bg-slate-700 text-slate-400" : "hover:bg-slate-200 text-slate-600"
                        )}
                        title="Upvote answer"
                      >
                        <ThumbsUp size={12} />
                        <span>{ans.upvotes}</span>
                      </button>

                      <button
                        onClick={() => handleVoteAnswer(ans.id, 'down')}
                        className={cn(
                          "flex items-center gap-1 px-2 py-1 rounded-md transition-all font-medium",
                          ans.userVote === 'down'
                            ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                            : isDark ? "hover:bg-slate-700 text-slate-400" : "hover:bg-slate-200 text-slate-600"
                        )}
                        title="Downvote answer"
                      >
                        <ThumbsDown size={12} />
                      </button>
                    </div>

                    {/* Helpful indicator for asker */}
                    <button
                      onClick={() => handleToggleHelpful(ans.id)}
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all border",
                        ans.isHelpful
                          ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30 font-semibold"
                          : isDark ? "bg-slate-800 text-slate-400 border-slate-700 hover:text-white" : "bg-white text-slate-600 border-slate-300 hover:text-slate-900"
                      )}
                    >
                      <CheckCircle2 size={13} className={ans.isHelpful ? "text-emerald-400" : "text-slate-400"} />
                      <span>{ans.isHelpful ? 'Marked Helpful' : 'Helpful?'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Answer Submission Form */}
      <div className={cn(
        "rounded-xl p-4 md:p-5 border space-y-3",
        isDark ? "bg-slate-800/40 border-slate-700/80" : "bg-slate-50 border-slate-200"
      )}>
        <h4 className="text-sm font-bold flex items-center gap-2">
          <MessageSquare size={15} className="text-indigo-400" />
          <span>Know the answer? Help a classmate anonymously</span>
        </h4>

        {errorMsg && (
          <div className="flex items-center gap-2 text-xs text-rose-400 bg-rose-500/10 p-2.5 rounded-lg border border-rose-500/20">
            <AlertCircle size={14} className="shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successNotice && (
          <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-500/10 p-2.5 rounded-lg border border-emerald-500/20">
            <CheckCircle2 size={14} className="shrink-0" />
            <span>{successNotice}</span>
          </div>
        )}

        <form onSubmit={handleSubmitAnswer} className="space-y-3">
          <textarea
            value={newAnswerText}
            onChange={(e) => setNewAnswerText(e.target.value)}
            placeholder="Explain step-by-step or share an intuitive analogy (Max 500 chars)..."
            maxLength={500}
            rows={3}
            className={cn(
              "w-full rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 border resize-none transition-all",
              isDark ? "bg-slate-900 border-slate-700 text-slate-100 placeholder:text-slate-500" : "bg-white border-slate-300 text-slate-900 placeholder:text-slate-400"
            )}
          />

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">
              {newAnswerText.length}/500 characters • Posted anonymously
            </span>
            <button
              type="submit"
              disabled={isSubmitting || !newAnswerText.trim()}
              className="px-4 py-2 rounded-lg font-bold bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1.5 transition-all disabled:opacity-50 cursor-pointer shadow-md"
            >
              <Send size={13} />
              <span>{isSubmitting ? 'Posting...' : 'Post Answer'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
