import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });

export async function checkStep(stepLatex: string, prevStepLatex: string | null): Promise<{ isValid: boolean; suggestion: string }> {
  const prompt = `Check if this mathematical step is a valid progression from the previous step.
Previous Step: ${prevStepLatex || "N/A (Start)"}
Current Step: ${stepLatex}
Return a JSON object: { "isValid": boolean, "suggestion": string }.`;
  
  const result = await ai.models.generateContent({
    model: 'gemini-2.0-flash',
    contents: prompt
  });
  return JSON.parse(result.text || '{}');
}
