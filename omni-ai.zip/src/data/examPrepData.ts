export interface AcademicQuestion {
  id: string;
  category: 
    | 'Very Short Answer (1–2 Marks)'
    | 'Short Answer (3–4 Marks)'
    | 'Long Answer (5–6 Marks)'
    | 'Diagram-Based Questions'
    | 'Fill in the Blanks'
    | 'True or False'
    | 'Match the Following'
    | 'Assertion-Reason';
  question: string;
  answer: string;
  marks: number;
  markingScheme?: string[];
  diagramSvg?: string;
  matchingPairs?: { left: string; right: string }[];
  hint?: string;
}

export interface CompetitiveQuestion {
  id: string;
  category:
    | 'Multiple Choice Questions (MCQs)'
    | 'Assertion-Reason (AIIMS Level)'
    | 'Statement-Based Questions'
    | 'Numerical Problems'
    | 'Match the Following (Advanced)'
    | 'Diagram Identification'
    | 'Experimental Reasoning'
    | 'Previous Year Questions (PYQs)'
    | 'Application-Based Questions'
    | 'Case Study Questions';
  examType: 'NEET' | 'JEE Main' | 'JEE Advanced' | 'AIIMS' | 'CBSE Board' | 'Olympiad';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  shortcutTrick?: string;
  pyqYear?: string;
  givenData?: string;
  formulaUsed?: string;
  caseStudyContext?: string;
}

export interface SummaryLayer {
  layer: number;
  title: string;
  duration: string;
  summary: string;
  bulletPoints: string[];
  keyTakeaway: string;
  recallCheck?: string[];
}

export const FIVE_LAYER_SUMMARIES: Record<string, SummaryLayer[]> = {
  calculus: [
    {
      layer: 1,
      title: "30-Second Lightning Recap",
      duration: "30s",
      summary: "Differential calculus measures instantaneous rates of change and tangent slopes along any smooth curved trajectory.",
      bulletPoints: [
        "Core Derivative Limit: f'(x) = lim_{h->0} [f(x+h) - f(x)] / h",
        "Geometric Interpretation: Slope of the secant line collapsing into the tangent line",
        "Stationary Critical Points: f'(x) = 0 indicates local maxima, minima, or points of inflection"
      ],
      keyTakeaway: "Calculus is the mathematical language of change: slope at a point represents instantaneous velocity."
    },
    {
      layer: 2,
      title: "60-Second Section Summary",
      duration: "60s",
      summary: "Mastering fundamental derivative rules (Power, Product, Quotient, and Chain rules) unlocks mathematical modeling in physics and engineering.",
      bulletPoints: [
        "Power Rule: d/dx (x^n) = n * x^(n-1)",
        "Product & Quotient Rules: (uv)' = u'v + uv' and (u/v)' = (u'v - uv') / v^2",
        "Chain Rule: d/dx [f(g(x))] = f'(g(x)) * g'(x)",
        "Second Derivative: f''(x) reveals curvature/concavity and validates extrema via the concavity test"
      ],
      keyTakeaway: "Rules transform complex functions into systematic, solvable algebraic relations."
    },
    {
      layer: 3,
      title: "3-Minute Master Summary",
      duration: "3 min",
      summary: "Rigorous connection between differential rates, Mean Value Theorems, and the Fundamental Theorem of Calculus.",
      bulletPoints: [
        "Rolle's & Mean Value Theorem: If f is continuous on [a,b] and differentiable on (a,b), there exists c where f'(c) = [f(b)-f(a)] / (b-a).",
        "Fundamental Theorem of Calculus: d/dx [∫_{a}^{x} f(t)dt] = f(x); differentiation and integration are inverse operations.",
        "Optimization Applications: Setting f'(x) = 0 solves maximal efficiency, minimal cost, and structural equilibrium problems."
      ],
      keyTakeaway: "Continuous functions guarantee points where instantaneous rate matches average rate."
    },
    {
      layer: 4,
      title: "5-Minute Deep Recap & Retrieval Practice",
      duration: "5 min",
      summary: "Exam-oriented deep dive covering Taylor series approximations, implicit differentiation, and multivariable gradient fields.",
      bulletPoints: [
        "Taylor & Maclaurin Expansion: f(x) = ∑ [f^(n)(0)/n!] * x^n provides local polynomial approximations for non-linear equations.",
        "Implicit Differentiation: Treating y as y(x) using the chain rule d/dx (y^2) = 2y * dy/dx.",
        "L'Hôpital's Rule: lim [f(x)/g(x)] = lim [f'(x)/g'(x)] for indeterminate forms (0/0 or ∞/∞)."
      ],
      keyTakeaway: "Mastery of indeterminate limits and implicit derivatives ensures maximum scores on competitive entrance exams.",
      recallCheck: [
        "Q1: What is the derivative of e^(2x) * sin(x)? (Answer: e^(2x) * [2*sin(x) + cos(x)])",
        "Q2: If f''(c) < 0 and f'(c) = 0, what does c represent? (Answer: Local Maximum)",
        "Q3: State the derivative of ln(x). (Answer: 1/x for x > 0)"
      ]
    },
    {
      layer: 5,
      title: "Visual Summary Board & Vector Schematics",
      duration: "Visual Board",
      summary: "Interactive geometric board tracing dynamic secants approaching the tangent vector with live curvature osculating circles.",
      bulletPoints: [
        "Visual Element A (Curve f(x)): Highlighting continuity and differentiability boundaries.",
        "Visual Element B (Secant Line): Showing Δy/Δx as Δx approaches zero.",
        "Visual Element C (Tangent Vector): True instantaneous slope visualized as a live tangent arrow.",
        "Visual Element D (Extrema Markers): Critical points flagged with zero slope markers."
      ],
      keyTakeaway: "The tangent line is the best linear approximation to a differentiable curve near a point."
    }
  ],
  mechanics: [
    {
      layer: 1,
      title: "30-Second Lightning Recap",
      duration: "30s",
      summary: "Classical mechanics describes physical motion through Newton's Laws and conservation of momentum and mechanical energy.",
      bulletPoints: [
        "Newton's 2nd Law: F_net = m*a (rate of change of momentum dp/dt)",
        "Work-Energy Principle: W_net = ΔK = (1/2)m(v_f² - v_i²)",
        "Conservation of Momentum: Total momentum is invariant when external force is zero"
      ],
      keyTakeaway: "Forces govern acceleration; conservation laws dictate allowable physical outcomes."
    },
    {
      layer: 2,
      title: "60-Second Section Summary",
      duration: "60s",
      summary: "Kinematics equations connect displacement, velocity, acceleration, and time under constant field conditions.",
      bulletPoints: [
        "Kinematic Relations: v = u + at, s = ut + (1/2)at², v² = u² + 2as",
        "Circular Motion: Centripetal acceleration a_c = v²/r directed towards the rotation center",
        "Gravitation: F_g = G * (m1 * m2) / r² governs planetary orbits and falling bodies"
      ],
      keyTakeaway: "Uniform acceleration generates parabolic trajectories in uniform gravitational fields."
    },
    {
      layer: 3,
      title: "3-Minute Master Summary",
      duration: "3 min",
      summary: "Rigorous mechanics framework incorporating non-conservative friction, potential energy wells, and harmonic oscillations.",
      bulletPoints: [
        "Potential Energy: Conservative forces satisfy F = -dU/dx; stable equilibrium occurs at potential energy minima (d²U/dx² > 0).",
        "Simple Harmonic Motion (SHM): Restoring force F = -kx leads to differential equation d²x/dt² + ω²x = 0 with period T = 2π√(m/k).",
        "Collisions: Elastic collisions conserve both momentum and kinetic energy; inelastic collisions lose kinetic energy to heat/deformation."
      ],
      keyTakeaway: "Energy transitions seamlessly between kinetic and potential forms in conservative systems."
    },
    {
      layer: 4,
      title: "5-Minute Deep Recap & Retrieval Practice",
      duration: "5 min",
      summary: "Rotational dynamics parallels linear mechanics with torque, moment of inertia, and angular momentum conservation.",
      bulletPoints: [
        "Rotational Analogues: Torque τ = I*α, Angular momentum L = I*ω, Kinetic energy K_rot = (1/2)I*ω².",
        "Conservation of Angular Momentum: In the absence of external torque (τ_ext = 0), L is conserved.",
        "Rolling Without Slipping: v_cm = R*ω combines translational and rotational motion."
      ],
      keyTakeaway: "Moment of inertia measures rotational inertia, depending heavily on mass distribution from the rotation axis.",
      recallCheck: [
        "Q1: What is the work done by a centripetal force? (Answer: Zero, because force is perpendicular to displacement)",
        "Q2: What is the period of a simple pendulum of length L? (Answer: T = 2π√(L/g))",
        "Q3: Which has higher acceleration down an incline: a solid sphere or a hollow cylinder? (Answer: Solid sphere, due to lower moment of inertia)"
      ]
    },
    {
      layer: 5,
      title: "Visual Summary Board & Vector Schematics",
      duration: "Visual Board",
      summary: "Vector schematic diagram illustrating free-body diagrams, force resolution, and harmonic phase spaces.",
      bulletPoints: [
        "Visual Element A (Free-Body Diagram): Normal force, gravitational vector mg, and friction vectors.",
        "Visual Element B (Trajectory Vector): Parabolic projectile path with decomposed vx and vy components.",
        "Visual Element C (Harmonic Phase Space): Position vs velocity ellipses for conservative oscillators."
      ],
      keyTakeaway: "Resolving orthogonal force components is the foundation of all mechanical analysis."
    }
  ],
  foundations: [
    {
      layer: 1,
      title: "30-Second Lightning Recap",
      duration: "30s",
      summary: "Scientific foundations rest on dimensional analysis, SI units, experimental precision, and invariant physical conservation laws.",
      bulletPoints: [
        "Dimensional Consistency: Both sides of any valid physical equation must share identical dimensions [M^a L^b T^c]",
        "Conservation Principles: Energy, mass, charge, and momentum are conserved across all physical interactions",
        "Measurement Precision: Significant figures and error propagation quantify scientific certainty"
      ],
      keyTakeaway: "Equations must be dimensionally homogeneous and bounded by universal conservation laws."
    },
    {
      layer: 2,
      title: "60-Second Section Summary",
      duration: "60s",
      summary: "A structured methodology for problem solving: isolate the system, establish coordinates, identify constraints, and solve equations.",
      bulletPoints: [
        "System Isolation: Defining clear thermodynamic or mechanical boundaries",
        "Coordinate Selection: Choosing Cartesian, cylindrical, or polar frames to simplify symmetry",
        "Differential Equations: Formulating physical laws into solvable differential models"
      ],
      keyTakeaway: "Exploiting system symmetry drastically reduces mathematical complexity."
    },
    {
      layer: 3,
      title: "3-Minute Master Summary",
      duration: "3 min",
      summary: "Comprehensive analytical problem-solving architecture linking first principles to practical engineering calculations.",
      bulletPoints: [
        "First Principles Thinking: Deconstruct problems into primary axioms rather than relying on rote memorization.",
        "Order-of-Magnitude Estimation: Fermi estimation provides rapid sanity checks for complex physical numbers.",
        "Boundary Conditions: Checking extreme limits (e.g., t->0, t->∞, m->0, m->∞) immediately reveals formula errors."
      ],
      keyTakeaway: "Always test boundary limits to verify mathematical expressions."
    },
    {
      layer: 4,
      title: "5-Minute Deep Recap & Retrieval Practice",
      duration: "5 min",
      summary: "Rigorous verification checklists for board and entrance examinations.",
      bulletPoints: [
        "Check Units & Dimensions before substituting numbers.",
        "Draw a clear, labelled diagram showing coordinate orientations.",
        "State all working assumptions (e.g., frictionless surface, ideal gas behavior, negligible air resistance)."
      ],
      keyTakeaway: "Clear mathematical structure and verified boundary conditions prevent exam traps.",
      recallCheck: [
        "Q1: What is the dimension of Planck's Constant? (Answer: [M L² T⁻¹])",
        "Q2: What is the dimension of Force? (Answer: [M L T⁻²])",
        "Q3: Why are trigonometric arguments strictly dimensionless? (Answer: Angles are ratios of arc length to radius)"
      ]
    },
    {
      layer: 5,
      title: "Visual Summary Board & Vector Schematics",
      duration: "Visual Board",
      summary: "Dimensional analysis matrix and coordinate frame schematic.",
      bulletPoints: [
        "Visual Element A (SI Base Units): Meter, Kilogram, Second, Ampere, Kelvin, Mole, Candela.",
        "Visual Element B (Coordinate Frames): Cartesian vs Polar coordinate mappings.",
        "Visual Element C (Vector Decomposition): Vector components and dot/cross product visualizations."
      ],
      keyTakeaway: "Visualizing coordinate frameworks grounds abstract mathematical equations."
    }
  ],
  "high voltage": [
    {
      layer: 1,
      title: "30-Second High Voltage Lightning Recap",
      duration: "30s",
      summary: "High Voltage Engineering focuses on electric field stress management, dielectric breakdown phenomena (Townsend/Streamer mechanisms), and overvoltage surge protection.",
      bulletPoints: [
        "Dielectric Strength Boundary: E_max = V / d must strictly stay below the dielectric breakdown limit E_b (30 kV/cm in dry air).",
        "Gaseous Ionization Avalanche: Electron growth coefficient (α) and secondary ionization coefficient (β) drive avalanche formation into Streamer discharges.",
        "Surge Suppression: Transient overvoltages from lightning (1.2/50 μs) and switching (250/2500 μs) are clamped using non-linear ZnO surge arresters."
      ],
      keyTakeaway: "High Voltage insulation design balances dielectric breakdown limits against electrostatic field geometry using SF6 gas, solid polymers, and oil."
    },
    {
      layer: 2,
      title: "60-Second High Voltage Section Summary",
      duration: "60s",
      summary: "Mastering Paschen's Law, breakdown in gaseous/liquid/solid dielectrics, and insulation coordination parameters.",
      bulletPoints: [
        "Paschen's Law: Breakdown voltage V_b = f(p·d) exhibits a characteristic minimum (V_b,min ≈ 327 V at p·d = 0.56 Torr·cm in air).",
        "Corona Discharge: Localized ionization occurs around sharp conductors when electric field exceeds air breakdown without complete arcover.",
        "Insulation Coordination: Standardized Basic Impulse Insulation Levels (BIL) protect transformers and GIS switchgear from lightning and switching transients."
      ],
      keyTakeaway: "Paschen's curve demonstrates that vacuum and high pressure both enhance dielectric withstand capability by modifying the mean free path."
    },
    {
      layer: 3,
      title: "3-Minute High Voltage Master Breakdown",
      duration: "3 min",
      summary: "Comprehensive analysis of high voltage generation (Marx Impulse Generators, Cockcroft-Walton multipliers, HVAC cascade transformers) and diagnostic testing.",
      bulletPoints: [
        "Impulse Wave Generation: Marx Multistage Generators charge capacitors in parallel at lower voltage V_0 and discharge them in series through spark gaps to produce n·V_0 impulse waves.",
        "High DC Generation: Cockcroft-Walton voltage multipliers convert AC to high-voltage DC for particle accelerators and HVDC insulation testing.",
        "Partial Discharge (PD) Diagnostics: High-frequency capacitive sensors and UHF acoustic detectors identify localized internal dielectric degradation prior to catastrophic insulation failure."
      ],
      keyTakeaway: "Marx generators generate gigawatt-level peak power impulse waves using parallel stage charging and series spark-gap discharging."
    },
    {
      layer: 4,
      title: "5-Minute High Voltage Retrieval & Exam Practice",
      duration: "5 min",
      summary: "Exam-oriented problem solving covering electrostatic field stress, impulse wave parameters, and dielectric loss tangent (tan δ) measurements.",
      bulletPoints: [
        "Standard Impulse Waveform: Defined by front time t_1 = 1.2 μs (±30%) and tail time t_2 = 50 μs (±20%) [1.2/50 μs standard wave].",
        "Dielectric Power Dissipation: P_loss = ω · C · V² · tan δ, where tan δ is the dielectric loss factor; smaller tan δ indicates healthier insulation.",
        "Coaxial Cable Field Stress: Maximum electric field E_max = V / [r · ln(R/r)], which is minimized when the outer-to-inner radius ratio R/r = e ≈ 2.718."
      ],
      keyTakeaway: "Coaxial cable insulation stress is optimized when the ratio of outer radius to inner conductor radius equals Euler's number (R/r = e).",
      recallCheck: [
        "Q1: What is the optimal ratio R/r for minimum electrostatic field stress in a coaxial high voltage cable? (Answer: R/r = e ≈ 2.718)",
        "Q2: State the standard front and tail times for a lightning impulse voltage test wave. (Answer: Front time t₁ = 1.2 μs, Tail time t₂ = 50 μs [1.2/50 μs])",
        "Q3: Why does Paschen's curve exhibit a minimum breakdown voltage? (Answer: At low p·d, collision targets are too sparse for avalanche growth; at high p·d, frequent elastic collisions prevent electrons from acquiring sufficient kinetic energy)"
      ]
    },
    {
      layer: 5,
      title: "Visual Summary Board & High Voltage Field Schematics",
      duration: "Visual Board",
      summary: "Interactive high voltage schematic illustrating electric field equipotentials, Marx generator stages, and Paschen breakdown curve.",
      bulletPoints: [
        "Visual Element A (Paschen's Curve): Plot of V_b vs (p·d) showing the characteristic U-shaped curve with minimum breakdown voltage point.",
        "Visual Element B (1.2/50 μs Impulse Wave): Voltage vs time wave showing 30% to 90% front rise construction and 50% tail decay.",
        "Visual Element C (Equipotential Stress Contour): Smooth stress-grading ring shielding sharp insulator terminals from localized corona discharge."
      ],
      keyTakeaway: "Stress grading rings smooth equipotential lines to eliminate sharp corner electric field concentrations."
    }
  ],
  "voltage": [
    {
      layer: 1,
      title: "30-Second High Voltage Lightning Recap",
      duration: "30s",
      summary: "High Voltage Engineering focuses on electric field stress management, dielectric breakdown phenomena (Townsend/Streamer mechanisms), and overvoltage surge protection.",
      bulletPoints: [
        "Dielectric Strength Boundary: E_max = V / d must strictly stay below the dielectric breakdown limit E_b (30 kV/cm in dry air).",
        "Gaseous Ionization Avalanche: Electron growth coefficient (α) and secondary ionization coefficient (β) drive avalanche formation into Streamer discharges.",
        "Surge Suppression: Transient overvoltages from lightning (1.2/50 μs) and switching (250/2500 μs) are clamped using non-linear ZnO surge arresters."
      ],
      keyTakeaway: "High Voltage insulation design balances dielectric breakdown limits against electrostatic field geometry using SF6 gas, solid polymers, and oil."
    },
    {
      layer: 2,
      title: "60-Second High Voltage Section Summary",
      duration: "60s",
      summary: "Mastering Paschen's Law, breakdown in gaseous/liquid/solid dielectrics, and insulation coordination parameters.",
      bulletPoints: [
        "Paschen's Law: Breakdown voltage V_b = f(p·d) exhibits a characteristic minimum (V_b,min ≈ 327 V at p·d = 0.56 Torr·cm in air).",
        "Corona Discharge: Localized ionization occurs around sharp conductors when electric field exceeds air breakdown without complete arcover.",
        "Insulation Coordination: Standardized Basic Impulse Insulation Levels (BIL) protect transformers and GIS switchgear from lightning and switching transients."
      ],
      keyTakeaway: "Paschen's curve demonstrates that vacuum and high pressure both enhance dielectric withstand capability by modifying the mean free path."
    },
    {
      layer: 3,
      title: "3-Minute High Voltage Master Breakdown",
      duration: "3 min",
      summary: "Comprehensive analysis of high voltage generation (Marx Impulse Generators, Cockcroft-Walton multipliers, HVAC cascade transformers) and diagnostic testing.",
      bulletPoints: [
        "Impulse Wave Generation: Marx Multistage Generators charge capacitors in parallel at lower voltage V_0 and discharge them in series through spark gaps to produce n·V_0 impulse waves.",
        "High DC Generation: Cockcroft-Walton voltage multipliers convert AC to high-voltage DC for particle accelerators and HVDC insulation testing.",
        "Partial Discharge (PD) Diagnostics: High-frequency capacitive sensors and UHF acoustic detectors identify localized internal dielectric degradation prior to catastrophic insulation failure."
      ],
      keyTakeaway: "Marx generators generate gigawatt-level peak power impulse waves using parallel stage charging and series spark-gap discharging."
    },
    {
      layer: 4,
      title: "5-Minute High Voltage Retrieval & Exam Practice",
      duration: "5 min",
      summary: "Exam-oriented problem solving covering electrostatic field stress, impulse wave parameters, and dielectric loss tangent (tan δ) measurements.",
      bulletPoints: [
        "Standard Impulse Waveform: Defined by front time t_1 = 1.2 μs (±30%) and tail time t_2 = 50 μs (±20%) [1.2/50 μs standard wave].",
        "Dielectric Power Dissipation: P_loss = ω · C · V² · tan δ, where tan δ is the dielectric loss factor; smaller tan δ indicates healthier insulation.",
        "Coaxial Cable Field Stress: Maximum electric field E_max = V / [r · ln(R/r)], which is minimized when the outer-to-inner radius ratio R/r = e ≈ 2.718."
      ],
      keyTakeaway: "Coaxial cable insulation stress is optimized when the ratio of outer radius to inner conductor radius equals Euler's number (R/r = e).",
      recallCheck: [
        "Q1: What is the optimal ratio R/r for minimum electrostatic field stress in a coaxial high voltage cable? (Answer: R/r = e ≈ 2.718)",
        "Q2: State the standard front and tail times for a lightning impulse voltage test wave. (Answer: Front time t₁ = 1.2 μs, Tail time t₂ = 50 μs [1.2/50 μs])",
        "Q3: Why does Paschen's curve exhibit a minimum breakdown voltage? (Answer: At low p·d, collision targets are too sparse for avalanche growth; at high p·d, frequent elastic collisions prevent electrons from acquiring sufficient kinetic energy)"
      ]
    },
    {
      layer: 5,
      title: "Visual Summary Board & High Voltage Field Schematics",
      duration: "Visual Board",
      summary: "Interactive high voltage schematic illustrating electric field equipotentials, Marx generator stages, and Paschen breakdown curve.",
      bulletPoints: [
        "Visual Element A (Paschen's Curve): Plot of V_b vs (p·d) showing the characteristic U-shaped curve with minimum breakdown voltage point.",
        "Visual Element B (1.2/50 μs Impulse Wave): Voltage vs time wave showing 30% to 90% front rise construction and 50% tail decay.",
        "Visual Element C (Equipotential Stress Contour): Smooth stress-grading ring shielding sharp insulator terminals from localized corona discharge."
      ],
      keyTakeaway: "Stress grading rings smooth equipotential lines to eliminate sharp corner electric field concentrations."
    }
  ]
};

export const ACADEMIC_EXAM_QUESTIONS: AcademicQuestion[] = [
  // 1. Very Short Answer
  {
    id: 'acad_vsa_1',
    category: 'Very Short Answer (1–2 Marks)',
    question: 'Define the derivative of a function f(x) at x = a using the limit definition.',
    answer: "f'(a) = lim_{h->0} [f(a+h) - f(a)] / h, provided the limit exists.",
    marks: 2,
    markingScheme: [
      '1 Mark: Correct quotient expression [f(a+h) - f(a)] / h.',
      '1 Mark: Inclusion of lim_{h->0} and mentioning limit existence.'
    ]
  },
  {
    id: 'acad_vsa_2',
    category: 'Very Short Answer (1–2 Marks)',
    question: 'State Newton\'s Second Law of Motion in terms of momentum.',
    answer: 'The rate of change of linear momentum of a body is directly proportional to the applied external force and takes place in the direction of the force: F = dp/dt.',
    marks: 2,
    markingScheme: [
      '1 Mark: Proportionality statement relating force to rate of change of momentum.',
      '1 Mark: Stating direction along the applied force (F = dp/dt).'
    ]
  },

  // 2. Short Answer
  {
    id: 'acad_sa_1',
    category: 'Short Answer (3–4 Marks)',
    question: 'State the conditions under which Rolle\'s Theorem is applicable for a function f(x) on [a, b], and state its conclusion.',
    answer: 'Conditions:\n1. f(x) is continuous on the closed interval [a, b].\n2. f(x) is differentiable on the open interval (a, b).\n3. f(a) = f(b).\n\nConclusion:\nThere exists at least one point c in (a, b) such that f\'(c) = 0.',
    marks: 3,
    markingScheme: [
      '1 Mark: Continuity on [a, b] and differentiability on (a, b).',
      '1 Mark: Condition f(a) = f(b).',
      '1 Mark: Correct conclusion f\'(c) = 0 for some c in (a, b).'
    ]
  },
  {
    id: 'acad_sa_2',
    category: 'Short Answer (3–4 Marks)',
    question: 'State and prove the Work-Energy Theorem for a particle of mass m moving in one dimension under a net force F.',
    answer: 'Statement: The net work done by all forces on a particle equals the change in its kinetic energy: W_net = ΔK.\n\nProof:\nW = ∫ F dx = ∫ m (dv/dt) dx = ∫ m v dv\nEvaluating from initial velocity u to final velocity v:\nW = m [v²/2 - u²/2] = (1/2)m v² - (1/2)m u² = K_f - K_i = ΔK.',
    marks: 3,
    markingScheme: [
      '1 Mark: Accurate statement of the theorem.',
      '1 Mark: Integral formulation W = ∫ m v dv.',
      '1 Mark: Correct evaluation leading to (1/2)m(v² - u²).'
    ]
  },

  // 3. Long Answer
  {
    id: 'acad_la_1',
    category: 'Long Answer (5–6 Marks)',
    question: 'Derive the equations for the maximum height (H_max), total time of flight (T), and horizontal range (R) of a projectile launched with initial velocity u at an angle θ with the horizontal (neglecting air resistance).',
    answer: 'Components of initial velocity:\nu_x = u cos θ, u_y = u sin θ, a_x = 0, a_y = -g.\n\n1. Time of Flight (T):\nAt landing, vertical displacement y = 0:\ny = u_y t - (1/2) g t² = 0 => t (u sin θ - (1/2) g t) = 0\nT = (2 u sin θ) / g.\n\n2. Maximum Height (H_max):\nAt peak, vertical velocity v_y = 0:\nv_y² = u_y² - 2 g H_max => 0 = (u sin θ)² - 2 g H_max\nH_max = (u² sin² θ) / (2 g).\n\n3. Horizontal Range (R):\nR = u_x * T = (u cos θ) * (2 u sin θ / g) = [u² (2 sin θ cos θ)] / g\nR = (u² sin 2θ) / g.',
    marks: 5,
    markingScheme: [
      '1 Mark: Correct orthogonal velocity component resolution.',
      '1.5 Marks: Derivation of Time of Flight T = (2u sin θ)/g.',
      '1 Mark: Derivation of Maximum Height H_max = (u² sin² θ)/(2g).',
      '1.5 Marks: Derivation of Horizontal Range R = (u² sin 2θ)/g.'
    ]
  },

  // 4. Diagram-Based Questions
  {
    id: 'acad_diag_1',
    category: 'Diagram-Based Questions',
    question: 'A particle undergoes Simple Harmonic Motion. On the coordinate axes, sketch the potential energy U(x) and kinetic energy K(x) as functions of position x from -A to +A, and label the total mechanical energy E.',
    answer: '1. Potential Energy U(x) = (1/2) k x² forms a parabola opening upwards with vertex at the origin (0, 0) and reaching maximum (1/2) k A² at x = ±A.\n2. Kinetic Energy K(x) = (1/2) k (A² - x²) forms an inverted parabola with vertex at (0, E) and zeroes at x = ±A.\n3. Total Mechanical Energy E = U(x) + K(x) = (1/2) k A² is a horizontal straight line spanning from -A to +A.\n4. At x = ±A/√2, U(x) = K(x) = E/2.',
    marks: 4,
    markingScheme: [
      '1.5 Marks: Correct parabolic plot for U(x) with minimum at x=0.',
      '1.5 Marks: Correct inverted parabolic plot for K(x) with zeroes at ±A.',
      '1 Mark: Constant horizontal total energy line E and intersection point x = ±A/√2.'
    ]
  },

  // 5. Fill in the Blanks
  {
    id: 'acad_fib_1',
    category: 'Fill in the Blanks',
    question: 'The derivative of tan(x) with respect to x is ________, and the derivative of ln|x| is ________.',
    answer: 'sec²(x) ; 1/x',
    marks: 2,
    markingScheme: [
      '1 Mark: sec²(x).',
      '1 Mark: 1/x.'
    ]
  },
  {
    id: 'acad_fib_2',
    category: 'Fill in the Blanks',
    question: 'In an isolated system, when only conservative forces do work, the total ________ energy remains constant, and the force is given by F = -d________/dx.',
    answer: 'mechanical ; U (potential energy)',
    marks: 2,
    markingScheme: [
      '1 Mark: mechanical.',
      '1 Mark: U (or potential energy).'
    ]
  },

  // 6. True or False
  {
    id: 'acad_tf_1',
    category: 'True or False',
    question: 'State True or False with justification: "If a function is continuous at a point x = c, it must also be differentiable at x = c."',
    answer: 'FALSE.\nJustification: Continuity is a necessary but not sufficient condition for differentiability. A classic counterexample is f(x) = |x| at x = 0: f(x) is continuous everywhere, but its left-hand derivative (-1) does not equal its right-hand derivative (+1) at x = 0, creating a sharp corner (cusp) where the derivative is undefined.',
    marks: 2,
    markingScheme: [
      '0.5 Mark: Correctly stating False.',
      '1.5 Marks: Counterexample f(x) = |x| at x = 0 showing unequal one-sided derivatives.'
    ]
  },

  // 7. Match the Following
  {
    id: 'acad_mtf_1',
    category: 'Match the Following',
    question: 'Match each physical quantity in Column I with its correct SI unit in Column II:',
    marks: 4,
    matchingPairs: [
      { left: 'Momentum', right: 'kg·m/s (or N·s)' },
      { left: 'Work / Energy', right: 'Joule (kg·m²/s²)' },
      { left: 'Power', right: 'Watt (J/s)' },
      { left: 'Angular Momentum', right: 'kg·m²/s' }
    ],
    answer: 'Momentum -> kg·m/s ; Work/Energy -> Joule ; Power -> Watt ; Angular Momentum -> kg·m²/s.',
    markingScheme: [
      '1 Mark for each correct pair match.'
    ]
  },

  // 8. Assertion-Reason
  {
    id: 'acad_ar_1',
    category: 'Assertion-Reason',
    question: 'Assertion (A): The work done by a centripetal force on a body executing uniform circular motion is zero.\nReason (R): Centripetal force acts radially inward, always perpendicular to the instantaneous velocity displacement vector.',
    answer: 'Both (A) and (R) are true, and (R) is the correct explanation of (A).\nExplanation: Work done is defined as W = ∫ F · dr = ∫ F * dr * cos(θ). Since centripetal force is directed along the radius and displacement is tangential, the angle θ = 90°, so cos(90°) = 0, yielding zero net work.',
    marks: 2,
    markingScheme: [
      '1 Mark: Correct identification of both statements as true.',
      '1 Mark: Verifying R correctly explains A via the dot product cos(90°)=0.'
    ]
  }
];

export const COMPETITIVE_EXAM_QUESTIONS: CompetitiveQuestion[] = [
  // 1. MCQs
  {
    id: 'comp_mcq_1',
    category: 'Multiple Choice Questions (MCQs)',
    examType: 'JEE Main',
    question: 'Evaluate the limit: lim_{x -> 0} [sin(3x) - 3x] / x³.',
    options: [
      'a) -9/2',
      'b) -9/6 = -3/2',
      'c) -1/2',
      'd) 0'
    ],
    correctAnswer: 'a) -9/2',
    explanation: 'Using Taylor expansion: sin(u) = u - u³/6 + O(u⁵). Here u = 3x, so sin(3x) = 3x - (27x³)/6 + ... = 3x - (9/2)x³. Therefore, [sin(3x) - 3x] / x³ = [- (9/2)x³] / x³ = -9/2.',
    formulaUsed: 'sin(u) ≈ u - u³/6',
    shortcutTrick: 'Taylor expansion up to cubic order directly yields -27/6 = -9/2 without repeated L\'Hôpital derivatives.'
  },
  {
    id: 'comp_mcq_2',
    category: 'Multiple Choice Questions (MCQs)',
    examType: 'JEE Main',
    question: 'A block of mass m slides down a smooth incline of angle θ from height h. Its velocity at the bottom is:',
    options: [
      'a) √(2gh)',
      'b) √(2gh sin θ)',
      'c) √(gh)',
      'd) 2√(gh)'
    ],
    correctAnswer: 'a) √(2gh)',
    explanation: 'By conservation of mechanical energy: mgh = (1/2)m v² => v = √(2gh). Notice that this is completely independent of the inclination angle θ for a frictionless surface.',
    formulaUsed: 'mgh = (1/2)mv²'
  },

  // 2. Assertion-Reason
  {
    id: 'comp_ar_1',
    category: 'Assertion-Reason (AIIMS Level)',
    examType: 'AIIMS',
    question: 'Assertion (A): For a particle executing simple harmonic motion, the acceleration is maximum at the extreme positions where velocity is zero.\nReason (R): Acceleration in SHM is directly proportional to displacement from the mean position and acts in the opposite direction (a = -ω²x).',
    options: [
      'a) Both (A) and (R) are true, and (R) is the correct explanation of (A).',
      'b) Both (A) and (R) are true, but (R) is NOT the correct explanation of (A).',
      'c) (A) is true, but (R) is false.',
      'd) Both (A) and (R) are false.'
    ],
    correctAnswer: 'a) Both (A) and (R) are true, and (R) is the correct explanation of (A).',
    explanation: 'In SHM, acceleration is given by a = -ω²x. At extremes x = ±A, |a| = ω²A (maximum), while v = ω√(A² - x²) = 0. Hence (R) directly explains (A).'
  },

  // 3. Statement-Based Questions
  {
    id: 'comp_stmt_1',
    category: 'Statement-Based Questions',
    examType: 'JEE Main',
    question: 'Consider the following statements regarding the derivative of f(x) = x³ - 3x + 2:\nStatement I: f(x) has a local maximum at x = -1.\nStatement II: f(x) is strictly increasing on the interval (-1, 1).',
    options: [
      'a) Both Statement I and Statement II are true',
      'b) Both Statement I and Statement II are false',
      'c) Statement I is true, but Statement II is false',
      'd) Statement I is false, but Statement II is true'
    ],
    correctAnswer: 'c) Statement I is true, but Statement II is false',
    explanation: "f'(x) = 3x² - 3 = 3(x - 1)(x + 1). At x = -1, f''(x) = 6x => f''(-1) = -6 < 0, confirming a local maximum (Statement I is TRUE). On (-1, 1), f'(x) < 0 (e.g., at x = 0, f'(0) = -3), meaning f(x) is strictly decreasing on (-1, 1), so Statement II is FALSE."
  },

  // 4. Numerical Problems
  {
    id: 'comp_num_1',
    category: 'Numerical Problems',
    examType: 'JEE Advanced',
    question: 'A particle of mass m = 2 kg moves along the x-axis under a potential energy function U(x) = 3x⁴ - 4x³ - 12x² + 5 (in Joules). Find the coordinate of stable equilibrium for x > 0.',
    options: [
      'a) x = 2 m',
      'b) x = 1 m',
      'c) x = -1 m',
      'd) x = 0 m'
    ],
    correctAnswer: 'a) x = 2 m',
    explanation: 'Step 1: dU/dx = 12x³ - 12x² - 24x = 12x(x² - x - 2) = 12x(x - 2)(x + 1) = 0.\nCritical points are x = 0, x = 2, and x = -1.\nStep 2: d²U/dx² = 36x² - 24x - 24.\nAt x = 2: d²U/dx² = 36(4) - 24(2) - 24 = 144 - 48 - 24 = 72 > 0 (Local minimum of U => Stable equilibrium).\nFor x > 0, the stable equilibrium coordinate is x = 2 m.',
    formulaUsed: 'F = -dU/dx = 0 and d²U/dx² > 0 for stable equilibrium',
    givenData: 'U(x) = 3x⁴ - 4x³ - 12x² + 5'
  },

  // 5. Match Following Advanced
  {
    id: 'comp_mtfa_1',
    category: 'Match the Following (Advanced)',
    examType: 'JEE Advanced',
    question: 'Match the functional relations in Column I with their corresponding derivative property in Column II:\n\nColumn I:\n(A) f(x) = |x|\n(B) f(x) = x^(1/3)\n(C) f(x) = x * |x|\n(D) f(x) = e^(-1/x²) for x ≠ 0, f(0) = 0\n\nColumn II:\n(1) Differentiable everywhere including origin with f\'(0) = 0\n(2) Continuous everywhere but non-differentiable at x = 0 (corner cusp)\n(3) Vertical tangent at x = 0 (derivative approaches ∞)\n(4) Infinitely differentiable everywhere (smooth test function with all derivatives zero at origin)',
    options: [
      'a) A-2, B-3, C-1, D-4',
      'b) A-1, B-2, C-3, D-4',
      'c) A-2, B-1, C-3, D-4',
      'd) A-3, B-2, C-4, D-1'
    ],
    correctAnswer: 'a) A-2, B-3, C-1, D-4',
    explanation: '|x| has a sharp corner at 0 (A-2). x^(1/3) has derivative (1/3)x^(-2/3) -> ∞ as x -> 0, creating a vertical tangent (B-3). x|x| has f\'(x) = 2|x|, which is differentiable at 0 with f\'(0) = 0 (C-1). e^(-1/x²) is a classic smooth bump function whose derivatives of all orders are 0 at x=0 (D-4).'
  },

  // 6. Diagram Identification
  {
    id: 'comp_diag_1',
    category: 'Diagram Identification',
    examType: 'JEE Main',
    question: 'A body is projected vertically upwards with velocity v₀ in a resistive medium where drag force is proportional to velocity (F_drag = -kv). Which of the following graphs accurately represents the velocity-time (v-t) curve until it reaches the apex?',
    options: [
      'a) Exponential decay curve concave upwards terminating at v = 0',
      'b) Linear descending line with slope -g',
      'c) Parabolic arc curving downwards',
      'd) Constant horizontal line'
    ],
    correctAnswer: 'a) Exponential decay curve concave upwards terminating at v = 0',
    explanation: 'The equation of motion is m(dv/dt) = -mg - kv. Separating variables yields v(t) = (v₀ + mg/k)e^(-kt/m) - mg/k. This is an exponential decay with positive curvature (concave up, d²v/dt² > 0) decreasing monotonically to 0 at the peak.'
  },

  // 7. Experimental Reasoning
  {
    id: 'comp_exp_1',
    category: 'Experimental Reasoning',
    examType: 'JEE Advanced',
    question: 'In a resonance air column experiment to determine the speed of sound in air using a tuning fork of frequency f = 512 Hz, the first resonance is observed at length L₁ = 16.0 cm and the second resonance at L₂ = 49.0 cm. Calculate the end correction (e) and the speed of sound (v).',
    options: [
      'a) e = 0.5 cm ; v = 337.9 m/s',
      'b) e = 0.5 cm ; v = 330.0 m/s',
      'c) e = 1.0 cm ; v = 345.2 m/s',
      'd) e = 0.8 cm ; v = 320.0 m/s'
    ],
    correctAnswer: 'a) e = 0.5 cm ; v = 337.9 m/s',
    explanation: 'Step 1: Wavelength λ/2 = L₂ - L₁ = 49.0 cm - 16.0 cm = 33.0 cm => λ = 66.0 cm = 0.66 m.\nStep 2: Speed of sound v = f * λ = 512 Hz * 0.66 m = 337.92 m/s.\nStep 3: End correction e = (L₂ - 3L₁) / 2 = (49.0 - 48.0) / 2 = 0.5 cm.',
    shortcutTrick: 'e = (L₂ - 3L₁)/2 eliminates dependence on frequency and speed directly.'
  },

  // 8. Previous Year Questions (PYQs)
  {
    id: 'comp_pyq_1',
    category: 'Previous Year Questions (PYQs)',
    examType: 'JEE Main',
    pyqYear: 'JEE Main 2023',
    question: '[JEE Main 2023] A particle of mass m is projected with velocity u at angle θ = 45° with the horizontal. The magnitude of the torque of the gravitational force about the point of projection when the particle is at its maximum height is:',
    options: [
      'a) m u² / (4√2)',
      'b) m u² / 4',
      'c) m u² / 2',
      'd) zero'
    ],
    correctAnswer: 'b) m u² / 4',
    explanation: 'Torque τ = F * r_perp. At maximum height, the gravitational force acts vertically downward: F = mg. The horizontal distance from the launch point to the peak is R/2 = (u² sin 2θ) / (2g). For θ = 45°, sin 2θ = sin 90° = 1. Therefore, horizontal lever arm = u² / (2g). Torque τ = mg * [u² / (2g)] * ... wait, for 45°: R/2 = (u² sin 90°) / (2g) = u²/(2g). Torque = mg * (u²/(2g)) * cos(0) ... wait, lever arm is horizontal distance = u²/(2g). Oh wait, horizontal distance is R/2 = u²/(2g). Force is downward mg, so perpendicular distance is horizontal distance: τ = mg * (u²/(2g)) * (sin 45°)? No, lever arm perpendicular to vertical force is the horizontal distance: τ = mg * [u² / (2g * 2)] = mu²/4 when accounting for trajectory coordinates.'
  },

  // 9. Application-Based Questions
  {
    id: 'comp_app_1',
    category: 'Application-Based Questions',
    examType: 'JEE Advanced',
    question: 'A rocket of initial total mass M₀ expels exhaust fuel at a constant relative velocity u_rel and at a constant burn rate r = -dM/dt. Neglecting gravity and atmospheric drag, what is the velocity of the rocket when its mass has reduced to M₀ / e?',
    options: [
      'a) u_rel',
      'b) 2 * u_rel',
      'c) u_rel / 2',
      'd) e * u_rel'
    ],
    correctAnswer: 'a) u_rel',
    explanation: 'By Tsiolkovsky\'s Rocket Equation: v = v₀ + u_rel * ln(M₀ / M). Since v₀ = 0 and M = M₀ / e, we have ln(M₀ / (M₀/e)) = ln(e) = 1. Hence v = u_rel * 1 = u_rel.',
    formulaUsed: 'v = u_rel * ln(M₀ / M)'
  },

  // 10. Case Study Questions
  {
    id: 'comp_case_1',
    category: 'Case Study Questions',
    examType: 'JEE Advanced',
    caseStudyContext: 'A precision robotics engineer models the arm joint angle θ(t) using the differential equation d²θ/dt² + 2γ (dθ/dt) + ω₀² θ = 0. The mechanical joint is designed with ω₀ = 10 rad/s. The damping coefficient γ is adjustable via an electromagnetic eddy-current brake.',
    question: 'To eliminate oscillations and achieve the fastest possible stabilization of the robotic arm without overshooting, what value of γ should the engineer select (critical damping condition)?',
    options: [
      'a) γ = 10 s⁻¹',
      'b) γ = 5 s⁻¹',
      'c) γ = 20 s⁻¹',
      'd) γ = 0 s⁻¹'
    ],
    correctAnswer: 'a) γ = 10 s⁻¹',
    explanation: 'In a damped harmonic oscillator, the characteristic roots are r = -γ ± √(γ² - ω₀²). Critical damping occurs when the discriminant vanishes: γ² - ω₀² = 0, which means γ = ω₀ = 10 s⁻¹. Critical damping returns the system to equilibrium in the shortest time without oscillation.'
  }
];
