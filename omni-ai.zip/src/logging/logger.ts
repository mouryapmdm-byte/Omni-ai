// src/logging/logger.ts
/**
 * Professor Clarity Observability Infrastructure - Logger
 * Layer 1: Detection & Signal Capture
 */

export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
  FATAL = 4,
}

export interface LogEntry {
  id: string;
  timestamp: number;
  level: LogLevel;
  component: string;
  message: string;
  data?: any;
  stackTrace?: string;
  sessionId: string;
  userId?: string;
  context: {
    chapter?: string;
    topic?: string;
    lecture?: number;
    phase?: string;
  };
}

class ProfessorClarityLogger {
  private logs: LogEntry[] = [];
  private maxLogs = 10000;
  private batchQueue: LogEntry[] = [];
  private batchTimer: any = null;
  private listeners: Array<(entry: LogEntry) => void> = [];

  constructor() {
    if (typeof window !== 'undefined') {
      // Set default session ID if not present
      if (!(window as any).__SESSION_ID__) {
        (window as any).__SESSION_ID__ = 'sess_' + Math.random().toString(36).substring(2, 9);
      }
    }
  }

  log(level: LogLevel, component: string, message: string, data?: any) {
    const entry: LogEntry = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: Date.now(),
      level,
      component,
      message,
      data,
      stackTrace: level >= LogLevel.ERROR ? new Error().stack : undefined,
      sessionId: this.getSessionId(),
      userId: this.getUserId(),
      context: this.getCurrentContext(),
    };

    this.logs.push(entry);
    if (this.logs.length > this.maxLogs) {
      this.logs.shift();
    }

    // Notify in-memory listeners (e.g. Debugger UI)
    this.notifyListeners(entry);

    // Emit to console and queue for backend
    this.emit(entry);
  }

  debug(component: string, message: string, data?: any) {
    this.log(LogLevel.DEBUG, component, message, data);
  }

  info(component: string, message: string, data?: any) {
    this.log(LogLevel.INFO, component, message, data);
  }

  warn(component: string, message: string, data?: any) {
    this.log(LogLevel.WARN, component, message, data);
  }

  error(component: string, message: string, data?: any) {
    this.log(LogLevel.ERROR, component, message, data);
  }

  fatal(component: string, message: string, data?: any) {
    this.log(LogLevel.FATAL, component, message, data);
  }

  getLogs(filter?: { component?: string; level?: LogLevel; limit?: number }): LogEntry[] {
    let result = this.logs;
    if (filter?.component) {
      result = result.filter(log => log.component.toLowerCase().includes(filter.component!.toLowerCase()));
    }
    if (filter?.level !== undefined) {
      result = result.filter(log => log.level >= filter.level!);
    }
    if (filter?.limit) {
      result = result.slice(-filter.limit);
    }
    return [...result];
  }

  subscribe(callback: (entry: LogEntry) => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  private notifyListeners(entry: LogEntry) {
    for (const listener of this.listeners) {
      try {
        listener(entry);
      } catch (err) {
        // Safe listener ignore
      }
    }
  }

  private emit(entry: LogEntry) {
    if (typeof window !== 'undefined' && (window as any).__DEV_CONSOLE_LOG__) {
      const levelName = LogLevel[entry.level] || 'LOG';
      const color = entry.level >= LogLevel.ERROR ? '#ef4444' : entry.level === LogLevel.WARN ? '#f59e0b' : '#3b82f6';
      console.log(
        `%c[${levelName}] [${entry.component}] %c${entry.message}`,
        `color: ${color}; font-weight: bold;`,
        'color: inherit;',
        entry.data || ''
      );
    }

    // Queue for backend batched send
    this.batchQueue.push(entry);
    if (!this.batchTimer) {
      this.batchTimer = setTimeout(() => {
        this.flushBatchToBackend();
      }, 2000);
    }
  }

  private flushBatchToBackend() {
    this.batchTimer = null;
    if (this.batchQueue.length === 0 || typeof fetch === 'undefined') return;

    const payload = [...this.batchQueue];
    this.batchQueue = [];

    fetch('/api/logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ logs: payload }),
    }).catch(() => {
      // Silent fail - logging must never crash the host application
    });
  }

  private getSessionId(): string {
    if (typeof window === 'undefined') return 'server';
    return (window as any).__SESSION_ID__ || 'unknown';
  }

  private getUserId(): string | undefined {
    if (typeof window === 'undefined') return undefined;
    return (window as any).__USER_ID__;
  }

  private getCurrentContext() {
    if (typeof window === 'undefined') return {};
    return (window as any).__CONTEXT__ || {};
  }
}

export const logger = new ProfessorClarityLogger();
