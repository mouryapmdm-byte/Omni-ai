import { RenderMode, PerformanceMetrics } from './types';

export class ProgressiveEnhancer {
  private static frameTimes: number[] = [];
  private static lastFrameTimestamp: number = performance.now();
  private static jankCount: number = 0;
  private static animationFrameId: number | null = null;
  private static isMonitoring: boolean = false;
  private static listeners: ((metrics: PerformanceMetrics) => void)[] = [];
  private static frameCounter: number = 0;

  static startFpsMonitoring(): void {
    if (this.isMonitoring || typeof window === 'undefined') return;
    this.isMonitoring = true;
    this.frameTimes = [];
    this.frameCounter = 0;
    this.lastFrameTimestamp = performance.now();

    const loop = (timestamp: number) => {
      const delta = timestamp - this.lastFrameTimestamp;
      this.lastFrameTimestamp = timestamp;

      if (delta > 0) {
        const instantFps = 1000 / delta;
        this.frameTimes.push(instantFps);
        this.frameCounter++;

        // Keep rolling window of last 60 frames
        if (this.frameTimes.length > 60) {
          this.frameTimes.shift();
        }

        // Detect severe jank (frame time > 45ms i.e. < 22 FPS)
        if (delta > 45) {
          this.jankCount++;
        }
      }

      if (this.frameCounter > 0 && this.frameCounter % 120 === 0 && this.listeners.length > 0) {
        const metrics = this.getMetrics();
        this.listeners.forEach(cb => cb(metrics));
      }

      if (this.isMonitoring) {
        this.animationFrameId = requestAnimationFrame(loop);
      }
    };

    this.animationFrameId = requestAnimationFrame(loop);
  }

  static stopFpsMonitoring(): void {
    this.isMonitoring = false;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  static onMetrics(callback: (metrics: PerformanceMetrics) => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  static getMetrics(): PerformanceMetrics {
    if (this.frameTimes.length === 0) {
      return {
        currentFps: 60,
        averageFps: 60,
        jankPercentage: 0,
        frameDropCount: 0,
        memoryUsedMB: 65,
        domNodeCount: typeof document !== 'undefined' ? document.querySelectorAll('*').length : 0,
        isThrottlingRecommended: false
      };
    }

    const currentFps = Math.round(this.frameTimes[this.frameTimes.length - 1]);
    const averageFps = Math.round(
      this.frameTimes.reduce((acc, val) => acc + val, 0) / this.frameTimes.length
    );
    const jankPercentage = Math.round((this.jankCount / Math.max(1, this.frameTimes.length)) * 100);

    let memoryUsedMB = 75;
    if (typeof performance !== 'undefined' && (performance as any).memory) {
      memoryUsedMB = Math.round(((performance as any).memory.usedJSHeapSize || 0) / (1024 * 1024)) || 75;
    }

    // Recommend throttling if average FPS drops below 28 FPS or memory approaches 190MB
    const isThrottlingRecommended = averageFps < 28 || memoryUsedMB > 185;

    return {
      currentFps,
      averageFps,
      jankPercentage,
      frameDropCount: this.jankCount,
      memoryUsedMB,
      domNodeCount: typeof document !== 'undefined' ? document.querySelectorAll('*').length : 0,
      isThrottlingRecommended
    };
  }

  /**
   * Suggests optimal render mode based on live performance feedback
   */
  static evaluateAdaptiveMode(currentMode: RenderMode, metrics: PerformanceMetrics): RenderMode {
    if (metrics.memoryUsedMB > 190 || (metrics.averageFps < 22 && currentMode === 'lite')) {
      return 'audio-only';
    }
    if (metrics.averageFps < 28 && currentMode === 'full') {
      return 'lite';
    }
    return currentMode;
  }
}
