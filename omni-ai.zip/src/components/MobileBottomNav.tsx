import React from 'react';
import { motion } from 'motion/react';
import {
  MessageSquare,
  GraduationCap,
  LayoutGrid,
  Wand2,
  LayoutDashboard,
  Box,
  Compass,
  Sparkles,
  Zap,
  Download,
  X
} from 'lucide-react';
import { cn, triggerHapticFeedback } from '../lib/utils';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface MobileBottomNavProps {
  mode: string;
  setMode: (mode: string) => void;
  showDashboard: boolean;
  onToggleDashboard: () => void;
  onOpenTool: (toolId: string) => void;
  theme: 'light' | 'dark';
  onToggleSidebar?: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  mode,
  setMode,
  showDashboard,
  onToggleDashboard,
  onOpenTool,
  theme,
  onToggleSidebar
}) => {
  const { isInstalled, isInstallable, install } = usePWAInstall();
  const [dismissed, setDismissed] = React.useState(() => {
    return localStorage.getItem('omni_pwa_banner_dismissed') === 'true';
  });

  const handleDismiss = (e: React.MouseEvent) => {
    e.stopPropagation();
    localStorage.setItem('omni_pwa_banner_dismissed', 'true');
    setDismissed(true);
  };

  const showBanner = !isInstalled && !dismissed;

  const navItems = [
    {
      id: 'learn',
      label: 'Tutor Chat',
      shortLabel: 'Tutor',
      icon: MessageSquare,
      active: mode === 'learn' && !showDashboard,
      onClick: () => {
        triggerHapticFeedback(10);
        if (showDashboard) onToggleDashboard();
        setMode('learn');
      },
      color: 'text-indigo-400',
      activeBg: 'bg-indigo-600/20 text-indigo-400 border-indigo-500/30',
    },
    {
      id: '3d_classroom',
      label: 'Virtual 3D',
      shortLabel: '3D Hall',
      icon: Box,
      active: mode === '3d_classroom' && !showDashboard,
      onClick: () => {
        triggerHapticFeedback(12);
        if (showDashboard) onToggleDashboard();
        setMode('3d_classroom');
      },
      color: 'text-emerald-400',
      activeBg: 'bg-emerald-600/20 text-emerald-400 border-emerald-500/30',
      badge: '3D',
    },
    {
      id: 'launchpad',
      label: 'Launchpad',
      shortLabel: 'Explore',
      icon: LayoutGrid,
      active: false,
      onClick: () => {
        triggerHapticFeedback(10);
        onOpenTool('explorer');
      },
      color: 'text-amber-400',
      activeBg: 'bg-amber-600/20 text-amber-400 border-amber-500/30',
      highlight: true,
    },
    {
      id: 'persona_wizard',
      label: 'AI Persona',
      shortLabel: 'Persona',
      icon: Wand2,
      active: false,
      onClick: () => {
        triggerHapticFeedback(10);
        onOpenTool('persona_wizard');
      },
      color: 'text-purple-400',
      activeBg: 'bg-purple-600/20 text-purple-400 border-purple-500/30',
    },
    {
      id: 'dashboard',
      label: 'Dashboard',
      shortLabel: 'Stats',
      icon: LayoutDashboard,
      active: showDashboard,
      onClick: () => {
        triggerHapticFeedback(10);
        onToggleDashboard();
      },
      color: 'text-sky-400',
      activeBg: 'bg-sky-600/20 text-sky-400 border-sky-500/30',
    },
  ];

  return (
    <nav
      aria-label="Mobile Navigation Bar"
      className={cn(
        "fixed bottom-0 inset-x-0 z-[800] md:hidden border-t transition-all duration-300 pointer-events-auto",
        "pb-[env(safe-area-inset-bottom,0px)]",
        theme === 'dark'
          ? "bg-slate-950/95 border-slate-800/80 backdrop-blur-2xl shadow-[0_-8px_30px_rgba(0,0,0,0.6)]"
          : "bg-white/95 border-slate-200/80 backdrop-blur-2xl shadow-[0_-8px_30px_rgba(0,0,0,0.08)]"
      )}
    >
      {/* High-Fidelity Floating Mobile PWA Install Banner */}
      {showBanner && (
        <div className={cn(
          "px-4 py-2.5 border-b flex items-center justify-between gap-3 animate-in slide-in-from-bottom duration-300",
          theme === 'dark'
            ? "bg-gradient-to-r from-indigo-950/90 to-slate-950/90 border-slate-850/60"
            : "bg-gradient-to-r from-indigo-50/90 to-white/90 border-slate-200"
        )}>
          <div className="flex items-center gap-2 max-w-[65%]">
            <div className="w-9 h-9 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shrink-0 shadow-lg shadow-indigo-600/30">
              <Download size={15} className="animate-bounce" />
            </div>
            <div className="truncate">
              <div className={cn("text-[11px] font-black tracking-tight", theme === 'dark' ? "text-indigo-300" : "text-indigo-600")}>
                Experience Omni AI App
              </div>
              <div className="text-[9px] text-slate-400 dark:text-slate-400 truncate">
                Install as a native application
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={async () => {
                triggerHapticFeedback(10);
                if (isInstallable) {
                  await install();
                } else {
                  onOpenTool('pwa_install');
                }
              }}
              className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-[10px] uppercase tracking-wider transition active:scale-95 cursor-pointer min-h-[48px] shadow-md shadow-indigo-600/15 flex items-center justify-center"
            >
              Install
            </button>
            <button
              onClick={handleDismiss}
              className={cn(
                "p-2 rounded-xl transition hover:bg-slate-500/10 cursor-pointer text-slate-400 hover:text-slate-200 min-h-[48px] min-w-[48px] flex items-center justify-center",
              )}
              aria-label="Dismiss banner"
            >
              <X size={15} />
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-5 items-center justify-around px-2 py-1.5 max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = item.active;

          return (
            <button
              key={item.id}
              onClick={item.onClick}
              className={cn(
                "relative flex flex-col items-center justify-center py-1 px-1 rounded-2xl transition-all cursor-pointer select-none active:scale-90",
                isActive
                  ? (theme === 'dark' ? "text-white" : "text-indigo-600")
                  : (theme === 'dark' ? "text-slate-400 hover:text-slate-200" : "text-slate-500 hover:text-slate-800")
              )}
            >
              {/* Highlight background pill for active state */}
              {isActive && (
                <motion.div
                  layoutId="mobileActiveTabPill"
                  transition={{ type: 'spring', stiffness: 450, damping: 35 }}
                  className={cn(
                    "absolute inset-0 rounded-2xl border",
                    theme === 'dark'
                      ? "bg-indigo-600/20 border-indigo-500/40 shadow-sm shadow-indigo-500/20"
                      : "bg-indigo-50 border-indigo-200 shadow-sm"
                  )}
                />
              )}

              {/* Special center Launchpad button styling */}
              {item.highlight && !isActive ? (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/30 mb-0.5">
                  <Icon size={16} />
                </div>
              ) : (
                <div className="relative z-10 flex items-center justify-center w-7 h-7 mb-0.5">
                  <Icon
                    size={18}
                    className={cn(
                      "transition-transform",
                      isActive && "scale-110",
                      isActive ? (theme === 'dark' ? "text-indigo-400" : "text-indigo-600") : ""
                    )}
                  />
                  {item.badge && (
                    <span className="absolute -top-1 -right-2 px-1 py-0.2 rounded-full bg-emerald-500 text-[8px] font-black text-slate-950 uppercase tracking-tighter leading-tight shadow-sm">
                      {item.badge}
                    </span>
                  )}
                </div>
              )}

              <span
                className={cn(
                  "relative z-10 text-[10px] font-bold tracking-tight truncate max-w-[62px] leading-tight",
                  isActive
                    ? (theme === 'dark' ? "text-indigo-300 font-black" : "text-indigo-700 font-black")
                    : (theme === 'dark' ? "text-slate-400" : "text-slate-600")
                )}
              >
                {item.shortLabel}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
