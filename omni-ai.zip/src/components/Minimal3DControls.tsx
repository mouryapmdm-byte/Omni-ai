import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  HelpCircle,
  FileText,
  Volume2,
  VolumeX,
  ArrowLeft,
  Search,
  Mic,
  MicOff,
  Video,
  Disc,
  Square,
  Sparkles,
  Sliders,
  ChevronUp,
  ChevronDown,
  RotateCcw,
  FastForward,
  Maximize2,
  Minimize2,
  ZoomIn,
  Layers,
  ChevronLeft,
  ChevronRight,
  Coffee,
  Award,
  CheckCircle2,
  Clock,
  X,
  Send,
  Camera,
  Trash2,
  MessageSquare,
  Command,
  BookOpen,
  Loader2,
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface Minimal3DControlsProps {
  // Flag to indicate parent handles top unified navigation bar
  embeddedInClassroom?: boolean;

  // 5 Essential Button Callbacks & States
  isPlaying: boolean;
  isInitializingLecture?: boolean;
  onTogglePlay: () => void;
  onAskQuestion: () => void;
  onToggleNotes: () => void;
  isNotesOpen?: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  onBack: () => void;

  // Playback navigation & Timeline Props
  onRewind10s?: () => void;
  onFastForward10s?: () => void;
  onSeekProgress?: (percent: number) => void;
  currentTimeDisplay?: string;
  totalDurationDisplay?: string;

  // Context-Aware States
  isFigureModeActive?: boolean;
  onZoomFigure?: () => void;
  isStageModeActive?: boolean;
  onToggleStageMode?: () => void;
  onPrevFigure?: () => void;
  onNextFigure?: () => void;

  isConfusionDetected?: boolean;
  onReplaySection?: () => void;
  onSlowerPace?: () => void;
  onSimplerExplanation?: () => void;

  isQuizModeActive?: boolean;
  onSubmitQuiz?: () => void;
  onSkipQuiz?: () => void;
  onViewQuizResults?: () => void;

  isBreakSuggested?: boolean;
  onTakeBreak?: () => void;
  onSkipBreak?: () => void;
  onSetBreakTimer?: () => void;

  isSectionCompleted?: boolean;
  onViewAchievements?: () => void;
  onViewProgress?: () => void;
  onContinueSection?: () => void;

  // Additional Smart UI triggers
  onOpenCommandPalette: () => void;
  onOpenRadialMenu?: (e: { clientX: number; clientY: number }) => void;
  onOpenSettings?: () => void;

  // Drawer / Command Bar props
  userPrompt: string;
  setUserPrompt: (val: string) => void;
  onSendPrompt: () => void;
  isLoadingAi?: boolean;
  isListening?: boolean;
  onToggleSpeech?: () => void;
  onClearTopic?: () => void;
  screenRecordingState?: 'idle' | 'recording' | 'paused';
  onStartScreenRecording?: () => void;
  onStopScreenRecording?: () => void;
  onPauseScreenRecording?: () => void;
  onResumeScreenRecording?: () => void;
  screenRecordingDuration?: number;
  formatRecordingTime?: (seconds: number) => string;
  sessionTimerStyle?: 'minimal' | 'digital-clock' | 'progress-bar';
  onCycleTimerStyle?: () => void;
  sessionTimerEnabled?: boolean;
  onToggleTimerEnabled?: () => void;
  cameraFeedEnabled?: boolean;
  onToggleCameraFeed?: () => void;
  onOpenChatControls?: () => void;
  onOpenTopicModal?: () => void;
  isMaximized?: boolean;
  onToggleMaximize?: () => void;

  // Active topic title for status
  activeTopicTitle?: string;
  progressPercent?: number;
}

export const Minimal3DControls: React.FC<Minimal3DControlsProps> = ({
  embeddedInClassroom = false,
  isPlaying,
  isInitializingLecture = false,
  onTogglePlay,
  onAskQuestion,
  onToggleNotes,
  isNotesOpen = false,
  isMuted,
  onToggleMute,
  onBack,

  // Context
  isFigureModeActive = false,
  onZoomFigure,
  isStageModeActive = false,
  onToggleStageMode,
  onPrevFigure,
  onNextFigure,

  isConfusionDetected = false,
  onReplaySection,
  onSlowerPace,
  onSimplerExplanation,

  isQuizModeActive = false,
  onSubmitQuiz,
  onSkipQuiz,
  onViewQuizResults,

  isBreakSuggested = false,
  onTakeBreak,
  onSkipBreak,
  onSetBreakTimer,

  isSectionCompleted = false,
  onViewAchievements,
  onViewProgress,
  onContinueSection,

  onOpenCommandPalette,
  onOpenRadialMenu,
  onOpenSettings,

  userPrompt,
  setUserPrompt,
  onSendPrompt,
  isLoadingAi = false,
  isListening = false,
  onToggleSpeech,
  onClearTopic,
  screenRecordingState = 'idle',
  onStartScreenRecording,
  onStopScreenRecording,
  onPauseScreenRecording,
  onResumeScreenRecording,
  screenRecordingDuration = 0,
  formatRecordingTime,
  sessionTimerStyle = 'digital-clock',
  onCycleTimerStyle,
  sessionTimerEnabled = true,
  onToggleTimerEnabled,
  cameraFeedEnabled = false,
  onToggleCameraFeed,
  onOpenChatControls,
  onOpenTopicModal,
  isMaximized = false,
  onToggleMaximize,
  activeTopicTitle,
  progressPercent = 0,
  onRewind10s,
  onFastForward10s,
  onSeekProgress,
  currentTimeDisplay = '00:00',
  totalDurationDisplay = '00:00',
}) => {
  // Proximity & Inactivity Sensing
  const [isIdle, setIsIdle] = useState(false);
  const [isBottomDrawerOpen, setIsBottomDrawerOpen] = useState(false);
  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Smart Button & Recording States
  const [pressProgress, setPressProgress] = useState(0);
  const [showSavedBadge, setShowSavedBadge] = useState(false);
  const [gestureFeedback, setGestureFeedback] = useState<string | null>(null);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const pressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const isLongPressTriggeredRef = useRef(false);
  const clickCountRef = useRef(0);
  const lastClickTimeRef = useRef(0);
  const touchStartYRef = useRef<number | null>(null);
  const prevRecordingStateRef = useRef(screenRecordingState);

  // Detect transition to idle to show Saved badge
  useEffect(() => {
    if ((prevRecordingStateRef.current === 'recording' || prevRecordingStateRef.current === 'paused') && screenRecordingState === 'idle') {
      setShowSavedBadge(true);
      const timer = setTimeout(() => setShowSavedBadge(false), 2500);
      return () => clearTimeout(timer);
    }
    prevRecordingStateRef.current = screenRecordingState;
  }, [screenRecordingState]);

  // Temporary Gesture Feedback Notification
  const triggerFeedback = (msg: string) => {
    setGestureFeedback(msg);
    setTimeout(() => {
      setGestureFeedback(prev => prev === msg ? null : prev);
    }, 2200);
  };

  const handleRecordingToggle = () => {
    if (screenRecordingState === 'recording') {
      onStopScreenRecording?.();
      triggerFeedback("⏹️ Recording Saved & Processing (1080p50)");
    } else if (screenRecordingState === 'paused') {
      onResumeScreenRecording?.();
      triggerFeedback("▶️ Recording Resumed");
    } else {
      onStartScreenRecording?.();
      triggerFeedback("🔴 Screen Recording Started (Full HD 1080p50)");
    }
  };

  // 1. Long-press handler (2 seconds hold on Play/Pause button)
  const handlePointerDown = () => {
    isLongPressTriggeredRef.current = false;
    setPressProgress(0);
    const startTime = Date.now();
    const duration = 2000;

    pressIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.floor((elapsed / duration) * 100));
      setPressProgress(pct);
    }, 40);

    longPressTimerRef.current = setTimeout(() => {
      isLongPressTriggeredRef.current = true;
      clearInterval(pressIntervalRef.current!);
      setPressProgress(0);
      handleRecordingToggle();
    }, duration);
  };

  const handlePointerUp = () => {
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    if (pressIntervalRef.current) clearInterval(pressIntervalRef.current);
    setPressProgress(0);
  };

  // 2. Click / Triple-click handler on Play/Pause button
  const handlePlayButtonClick = () => {
    if (isLongPressTriggeredRef.current) {
      isLongPressTriggeredRef.current = false;
      return;
    }

    const now = Date.now();
    if (now - lastClickTimeRef.current < 450) {
      clickCountRef.current += 1;
    } else {
      clickCountRef.current = 1;
    }
    lastClickTimeRef.current = now;

    if (clickCountRef.current === 3) {
      clickCountRef.current = 0;
      handleRecordingToggle();
      return;
    }

    // Normal Single Click
    onTogglePlay();
  };

  // 3. Timeline Swipe Gestures (Swipe Up -> Start, Swipe Down -> Stop)
  const handleTimelineTouchStart = (e: React.TouchEvent | React.MouseEvent) => {
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    touchStartYRef.current = clientY;
  };

  const handleTimelineTouchEnd = (e: React.TouchEvent | React.MouseEvent) => {
    if (touchStartYRef.current === null) return;
    const clientY = 'changedTouches' in e ? e.changedTouches[0].clientY : e.clientY;
    const deltaY = clientY - touchStartYRef.current;
    touchStartYRef.current = null;

    if (deltaY < -30) {
      // Swipe Up -> Start Recording
      if (screenRecordingState === 'idle') {
        onStartScreenRecording?.();
        triggerFeedback("🔴 Swipe Up: Screen Recording Started (1080p50)");
      }
    } else if (deltaY > 30) {
      // Swipe Down -> Stop Recording
      if (screenRecordingState === 'recording' || screenRecordingState === 'paused') {
        onStopScreenRecording?.();
        triggerFeedback("⏹️ Swipe Down: Recording Stopped & Saved");
      }
    }
  };

  const resetIdleTimer = () => {
    setIsIdle(false);
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    idleTimerRef.current = setTimeout(() => {
      setIsIdle(true);
    }, 3000);
  };

  useEffect(() => {
    const handleActivity = () => resetIdleTimer();
    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('keydown', handleActivity);
    window.addEventListener('touchstart', handleActivity);

    resetIdleTimer();

    return () => {
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('touchstart', handleActivity);
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, []);

  // Invisible Gesture Zone handlers
  const handleZoneDoubleClick = (zone: 'tl' | 'tr' | 'bl' | 'br') => {
    switch (zone) {
      case 'tl':
        onBack();
        break;
      case 'tr':
        onOpenSettings ? onOpenSettings() : onOpenCommandPalette();
        break;
      case 'bl':
        onToggleMute();
        break;
      case 'br':
        onToggleNotes();
        break;
    }
  };

  return (
    <>
      {/* ========================================================================= */}
      {/* INVISIBLE GESTURE ZONES (PART 5 - FEATURE 3) */}
      {/* ========================================================================= */}
      <div className="absolute inset-0 pointer-events-none z-10 select-none">
        {/* Top-Left: Double tap -> Back */}
        <div
          className="absolute top-0 left-0 w-[18%] h-[18%] pointer-events-auto cursor-default"
          onDoubleClick={() => handleZoneDoubleClick('tl')}
          title="Gesture Zone: Double-click to go Back"
        />
        {/* Top-Right: Double tap -> Settings / Command */}
        <div
          className="absolute top-0 right-0 w-[18%] h-[18%] pointer-events-auto cursor-default"
          onDoubleClick={() => handleZoneDoubleClick('tr')}
          title="Gesture Zone: Double-click for Settings"
        />
        {/* Bottom-Left: Double tap -> Mute */}
        <div
          className="absolute bottom-0 left-0 w-[18%] h-[18%] pointer-events-auto cursor-default"
          onDoubleClick={() => handleZoneDoubleClick('bl')}
          title="Gesture Zone: Double-click to Toggle Audio"
        />
        {/* Bottom-Right: Double tap -> Notes */}
        <div
          className="absolute bottom-0 right-0 w-[18%] h-[18%] pointer-events-auto cursor-default"
          onDoubleClick={() => handleZoneDoubleClick('br')}
          title="Gesture Zone: Double-click to Toggle Notes"
        />
        {/* Center: Tap to wake */}
        <div
          className="absolute inset-[20%] pointer-events-auto cursor-default"
          onClick={() => {
            setIsIdle(false);
            resetIdleTimer();
          }}
          onContextMenu={(e) => {
            e.preventDefault();
            if (onOpenRadialMenu) {
              onOpenRadialMenu({ clientX: e.clientX, clientY: e.clientY });
            }
          }}
        />
      </div>

      {/* ========================================================================= */}
      {/* TOP-BAR MINIMAL STATUS & COMMAND SHORTCUT (HOVER-TO-REVEAL) */}
      {/* (Skipped when embeddedInClassroom=true to prevent button overlapping) */}
      {/* ========================================================================= */}
      {!embeddedInClassroom && (
        <>
          <div
            className={cn(
              "absolute top-4 left-1/2 -translate-x-1/2 z-30 pointer-events-auto transition-all duration-300 ease-out flex items-center gap-2",
              isIdle ? "opacity-35 hover:opacity-100" : "opacity-95 hover:opacity-100"
            )}
          >
            {/* Hidden per user request: open smart command palette */}

            {onToggleMaximize && (
              <button
                onClick={onToggleMaximize}
                className="p-1.5 rounded-full bg-slate-950/85 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
                title={isMaximized ? "Restore Screen" : "Maximize 3D Stage"}
              >
                {isMaximized ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
              </button>
            )}
          </div>

          {/* THE 5 ESSENTIAL ALWAYS-ACCESSIBLE VIRTUAL BUTTONS (PART 2) */}
          {/* BUTTON 5: ← BACK BUTTON (Top-Left, 40x40px, subtle when idle) */}
          <div className="absolute top-4 left-4 sm:top-6 sm:left-6 z-40 pointer-events-auto">
            <button
              onClick={onBack}
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer shadow-lg backdrop-blur-md group",
                isIdle
                  ? "bg-slate-950/40 text-slate-400 border-0 opacity-30 hover:opacity-100 hover:bg-slate-900/90 hover:text-white hover:border hover:border-slate-700"
                  : "bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800/80"
              )}
              title="Exit Virtual Lecture / Back"
              aria-label="Back"
            >
              <ArrowLeft size={18} className="group-hover:-translate-x-0.5 transition-transform" />
            </button>
          </div>

          {/* BUTTON 4: 🔊 VOLUME / MUTE BUTTON (Top-Right, 40x40px, subtle when idle) */}
          <div className="absolute top-4 right-4 sm:top-6 sm:right-6 z-40 pointer-events-auto">
            <button
              onClick={onToggleMute}
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer shadow-lg backdrop-blur-md",
                isIdle
                  ? "bg-slate-950/40 text-slate-400 border-0 opacity-30 hover:opacity-100 hover:bg-slate-900/90 hover:text-white hover:border hover:border-slate-700"
                  : isMuted
                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/40"
                  : "bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800/80"
              )}
              title={isMuted ? "Unmute Audio (Shortcut: M)" : "Mute Audio (Shortcut: M)"}
              aria-label={isMuted ? "Unmute" : "Mute"}
            >
              {isMuted ? <VolumeX size={18} className="text-rose-400" /> : <Volume2 size={18} />}
            </button>
          </div>
        </>
      )}

      {/* ========================================================================= */}
      {/* INTEGRATED PLAYBACK & SMART RECORDING BAR (Part 1 - Smart Button Bar) */}
      {/* [⏪ 10s] [▶️ Play/Pause] [⏭️ 10s] [Timeline] [⏱️ Time] */}
      {/* ========================================================================= */}
      <div
        className={cn(
          "absolute left-1/2 -translate-x-1/2 z-40 pointer-events-auto transition-all duration-300 ease-out flex flex-col items-center gap-1",
          isBottomDrawerOpen ? "bottom-[120px] sm:bottom-[128px]" : "bottom-4 sm:bottom-6",
          isIdle && !isBottomDrawerOpen ? "opacity-35 hover:opacity-100" : "opacity-95 hover:opacity-100"
        )}
      >
        {/* Floating Gesture / Action Feedback Tooltip */}
        {gestureFeedback && (
          <div className="px-3 py-1 rounded-full bg-slate-900/95 border border-slate-700 text-xs font-bold text-white shadow-xl backdrop-blur-md animate-fade-in flex items-center gap-1.5 pointer-events-none">
            <span>{gestureFeedback}</span>
          </div>
        )}

        <div className="flex items-center gap-1.5 sm:gap-2 p-1.5 sm:p-2 rounded-2xl sm:rounded-full bg-slate-950/80 backdrop-blur-xl border border-slate-800/80 shadow-2xl transition-all duration-300">

          {/* [⏪ 10s] REWIND 10 SECONDS BUTTON */}
          <button
            onClick={() => {
              onRewind10s ? onRewind10s() : onTogglePlay();
              triggerFeedback("⏪ Rewind 10s");
            }}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex flex-col items-center justify-center bg-slate-900/70 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800/80 transition-all cursor-pointer shadow-md group relative"
            title="Rewind 10s (Left Arrow)"
            aria-label="Rewind 10 seconds"
          >
            <RotateCcw size={14} className="group-hover:-rotate-12 transition-transform" />
            <span className="text-[9px] font-bold tracking-tight text-slate-400 group-hover:text-slate-200">10s</span>
          </button>

          {/* [▶️ PLAY/PAUSE] SMART RECORDING BUTTON */}
          <div className="relative flex items-center justify-center">
            {/* Long Press Circular Progress Ring */}
            {pressProgress > 0 && (
              <svg className="absolute w-14 h-14 -rotate-90 pointer-events-none z-10">
                <circle
                  cx="28"
                  cy="28"
                  r="24"
                  stroke="#ef4444"
                  strokeWidth="3"
                  fill="transparent"
                  strokeDasharray="150"
                  strokeDashoffset={150 - (150 * pressProgress) / 100}
                  className="transition-all duration-75"
                />
              </svg>
            )}

            <button
              onPointerDown={handlePointerDown}
              onPointerUp={handlePointerUp}
              onPointerLeave={handlePointerUp}
              onClick={handlePlayButtonClick}
              disabled={isInitializingLecture}
              className={cn(
                "w-12 h-12 sm:w-13 sm:h-13 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer shadow-2xl active:scale-95 group relative",
                isInitializingLecture
                  ? "bg-gradient-to-tr from-indigo-700 to-violet-700 text-white shadow-indigo-500/50 border-2 border-indigo-400 animate-pulse cursor-wait"
                  : isPlaying
                  ? "bg-gradient-to-tr from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white shadow-amber-500/30 border-2 border-amber-400/40"
                  : "bg-gradient-to-tr from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-indigo-500/40 border-2 border-indigo-400/40 ring-4 ring-indigo-500/20"
              )}
              title={
                isInitializingLecture
                  ? "Initializing Synchronized Lecture..."
                  : isPlaying
                  ? "Click: Pause (Space) | Hold 2s / Triple-click / Ctrl+R: Toggle 1080p50 Recording"
                  : "Click: Play (Space) | Hold 2s / Triple-click / Ctrl+R: Toggle 1080p50 Recording"
              }
              aria-label={isPlaying ? "Pause Lecture" : "Start Lecture"}
            >
              {isInitializingLecture ? (
                <Loader2 size={20} className="text-white animate-spin" />
              ) : isPlaying ? (
                <Pause size={20} className="fill-white" />
              ) : (
                <Play size={20} className="fill-white ml-0.5" />
              )}

              {/* Red Dot Indicator for Recording State */}
              {screenRecordingState === 'recording' && (
                <span
                  className="absolute top-1 right-1 w-3 h-3 rounded-full bg-red-500 border-2 border-slate-950 shadow-md shadow-red-500 animate-pulse pointer-events-none"
                  title="Screen Recording in Progress (1080p50)"
                />
              )}
              {screenRecordingState === 'paused' && (
                <span
                  className="absolute top-1 right-1 w-3 h-3 rounded-full bg-amber-500 border-2 border-slate-950 shadow-md pointer-events-none"
                  title="Screen Recording Paused"
                />
              )}

              {/* Saved Green Badge Indicator */}
              {showSavedBadge && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center border border-white shadow-lg pointer-events-none animate-bounce">
                  <CheckCircle2 size={12} className="text-white fill-emerald-600" />
                </span>
              )}
            </button>
          </div>

          {/* [⏭️ 10s] FAST FORWARD 10 SECONDS BUTTON */}
          <button
            onClick={() => {
              onFastForward10s ? onFastForward10s() : onTogglePlay();
              triggerFeedback("⏭️ Forward 10s");
            }}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex flex-col items-center justify-center bg-slate-900/70 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800/80 transition-all cursor-pointer shadow-md group relative"
            title="Fast Forward 10s (Right Arrow)"
            aria-label="Forward 10 seconds"
          >
            <FastForward size={14} className="group-hover:translate-x-0.5 transition-transform" />
            <span className="text-[9px] font-bold tracking-tight text-slate-400 group-hover:text-slate-200">10s</span>
          </button>

          {/* [TIMELINE] SCRUB & SWIPE GESTURE BAR */}
          <div
            onTouchStart={handleTimelineTouchStart}
            onTouchEnd={handleTimelineTouchEnd}
            onMouseDown={handleTimelineTouchStart}
            onMouseUp={handleTimelineTouchEnd}
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const clickX = e.clientX - rect.left;
              const pct = Math.max(0, Math.min(100, (clickX / rect.width) * 100));
              onSeekProgress?.(pct);
            }}
            className="flex items-center px-1.5 py-1 rounded-full bg-slate-900/60 border border-slate-800/60 cursor-pointer group relative"
            title="Lecture Timeline (Swipe Up: Record | Swipe Down: Stop | Click: Scrub)"
          >
            <div className="w-20 sm:w-32 h-2 rounded-full bg-slate-800 overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
              />
            </div>
          </div>

          {/* [⏱️ TIME] DURATION DISPLAY */}
          <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/80 border border-slate-800 text-[11px] font-mono font-bold text-slate-300 select-none">
            <Clock size={11} className="text-cyan-400" />
            <span>{currentTimeDisplay}</span>
            <span className="text-slate-500">/</span>
            <span className="text-slate-400">{totalDurationDisplay}</span>
          </div>

        </div>

        {/* Integrated Drawer Pull-Tab — sits neatly below the playback pill with ZERO overlap */}
        <button
          onClick={() => setIsBottomDrawerOpen(!isBottomDrawerOpen)}
          className={cn(
            "px-3 py-0.5 rounded-full bg-slate-950/85 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer backdrop-blur-md shadow-md",
            isIdle && !isBottomDrawerOpen ? "opacity-30 hover:opacity-100" : "opacity-85 hover:opacity-100"
          )}
          title="Toggle Command & Search Drawer"
        >
          {isBottomDrawerOpen ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
          <span className="hidden sm:inline">{isBottomDrawerOpen ? "Close Tools" : "Search & Tools"}</span>
        </button>
      </div>

      {/* BUTTON 2 & 3: 📝 NOTES & ❓ ASK QUESTION BUTTONS (Bottom-Right, Responsive Spacing to prevent overlap) */}
      <div
        className={cn(
          "absolute z-40 pointer-events-auto flex items-center gap-2 sm:gap-2.5 transition-all duration-300 ease-out",
          isBottomDrawerOpen
            ? "bottom-[120px] sm:bottom-[128px] right-3 sm:right-6"
            : "bottom-20 right-3 sm:bottom-6 sm:right-6",
          isIdle && !isBottomDrawerOpen ? "opacity-35 hover:opacity-100" : "opacity-95 hover:opacity-100"
        )}
      >
        {/* BUTTON 3: 📝 NOTES BUTTON (44x44px) */}
        <button
          onClick={onToggleNotes}
          className={cn(
            "w-11 h-11 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer shadow-xl backdrop-blur-md group",
            isIdle
              ? "bg-slate-950/40 text-slate-400 border-0 opacity-30 hover:opacity-100 hover:bg-slate-900/90 hover:text-white hover:border hover:border-slate-700"
              : isNotesOpen
              ? "bg-indigo-600 text-white border border-indigo-400/50 shadow-indigo-500/30"
              : "bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800/80"
          )}
          title="Smartboard Notes (Shortcut: N)"
          aria-label="Notes"
        >
          <FileText size={18} className="group-hover:scale-110 transition-transform" />
        </button>

        {/* BUTTON 2: ❓ ASK QUESTION BUTTON (48x48px, with subtle pulsing) */}
        <button
          onClick={() => {
            setIsBottomDrawerOpen(true);
            onAskQuestion();
          }}
          className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer shadow-2xl backdrop-blur-md active:scale-95 group",
            isIdle
              ? "bg-slate-950/50 text-indigo-300 border-0 opacity-40 hover:opacity-100 hover:bg-indigo-600 hover:text-white hover:shadow-indigo-500/40"
              : "bg-gradient-to-tr from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-indigo-500/40 border-2 border-indigo-400/40 animate-pulse"
          )}
          title="Ask Professor Clarity a Question (Shortcut: Q)"
          aria-label="Ask Question"
        >
          <HelpCircle size={22} className="group-hover:scale-110 transition-transform" />
        </button>
      </div>

      {/* ========================================================================= */}
      {/* PART 3: CONTEXT-AWARE FLOATING ACTION BARS (APPEARS ONLY WHEN RELEVANT) */}
      {/* ========================================================================= */}

      {/* 1. FIGURE DISCUSSION MODE BAR */}
      {isFigureModeActive && (
        <div className="absolute top-20 sm:top-24 left-1/2 -translate-x-1/2 z-40 pointer-events-auto animate-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-slate-950/90 border-2 border-cyan-500/40 shadow-2xl backdrop-blur-xl text-xs font-bold text-white">
            <span className="px-2 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 text-[10px] font-black uppercase tracking-wider">
              Figure Mode
            </span>
            {onPrevFigure && (
              <button
                onClick={onPrevFigure}
                className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                title="Previous Figure Section"
              >
                <ChevronLeft size={15} />
              </button>
            )}
            {onZoomFigure && (
              <button
                onClick={onZoomFigure}
                className="px-2.5 py-1.5 rounded-xl bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-200 flex items-center gap-1 cursor-pointer"
                title="Zoom into Figure Details"
              >
                <ZoomIn size={14} />
                <span>Zoom</span>
              </button>
            )}
            {onToggleStageMode && (
              <button
                onClick={onToggleStageMode}
                className={cn(
                  "px-2.5 py-1.5 rounded-xl flex items-center gap-1 cursor-pointer transition-all",
                  isStageModeActive
                    ? "bg-cyan-600 text-white shadow"
                    : "bg-slate-900 hover:bg-slate-800 text-slate-300"
                )}
                title="Toggle Vector Stage Mode"
              >
                <Layers size={14} />
                <span>{isStageModeActive ? "Stage 80/20" : "Expand"}</span>
              </button>
            )}
            {onNextFigure && (
              <button
                onClick={onNextFigure}
                className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                title="Next Figure Section"
              >
                <ChevronRight size={15} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* 2. STUDENT CONFUSION DETECTED BAR */}
      {isConfusionDetected && (
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 z-40 pointer-events-auto animate-in zoom-in-90 duration-300">
          <div className="flex flex-col sm:flex-row items-center gap-2 p-2.5 rounded-3xl bg-slate-950/95 border-2 border-amber-500/50 shadow-2xl backdrop-blur-2xl">
            <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 text-xs font-black uppercase tracking-wider">
              Need Clarity?
            </span>
            <div className="flex items-center gap-1.5">
              {onReplaySection && (
                <button
                  onClick={onReplaySection}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-amber-500/30"
                >
                  <RotateCcw size={13} />
                  <span>Replay Section</span>
                </button>
              )}
              {onSlowerPace && (
                <button
                  onClick={onSlowerPace}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-slate-800"
                >
                  <span>🐢 Slower Pace</span>
                </button>
              )}
              {onSimplerExplanation && (
                <button
                  onClick={onSimplerExplanation}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Sparkles size={13} />
                  <span>Simpler Analogy</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. QUIZ / ASSESSMENT MODE BAR */}
      {isQuizModeActive && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-40 pointer-events-auto animate-in slide-in-from-bottom-4 duration-300">
          <div className="flex items-center gap-2 p-2 rounded-2xl bg-slate-950/95 border-2 border-emerald-500/50 shadow-2xl backdrop-blur-xl">
            {onSubmitQuiz && (
              <button
                onClick={onSubmitQuiz}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-600/30"
              >
                <CheckCircle2 size={15} />
                <span>Submit Answer</span>
              </button>
            )}
            {onSkipQuiz && (
              <button
                onClick={onSkipQuiz}
                className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-slate-800"
              >
                <FastForward size={14} />
                <span>Skip</span>
              </button>
            )}
            {onViewQuizResults && (
              <button
                onClick={onViewQuizResults}
                className="px-3 py-2 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-indigo-500/30"
              >
                <Award size={14} />
                <span>Results</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* 4. BREAK TIME SUGGESTED BAR */}
      {isBreakSuggested && (
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 z-40 pointer-events-auto animate-in zoom-in-90 duration-300">
          <div className="flex flex-col sm:flex-row items-center gap-2 p-3 rounded-3xl bg-slate-950/95 border-2 border-teal-500/50 shadow-2xl backdrop-blur-2xl">
            <div className="flex items-center gap-2">
              <Coffee size={18} className="text-teal-400 animate-bounce" />
              <span className="text-xs font-bold text-white">Time for a quick recharge?</span>
            </div>
            <div className="flex items-center gap-1.5">
              {onTakeBreak && (
                <button
                  onClick={onTakeBreak}
                  className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md shadow-teal-600/30"
                >
                  <Clock size={13} />
                  <span>Take 5-min Break</span>
                </button>
              )}
              {onSkipBreak && (
                <button
                  onClick={onSkipBreak}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer border border-slate-800"
                >
                  <span>Skip Break</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 5. COMPLETION MOMENT BAR */}
      {isSectionCompleted && (
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 z-40 pointer-events-auto animate-in zoom-in-90 duration-300">
          <div className="flex flex-col items-center gap-2.5 p-4 rounded-3xl bg-slate-950/95 border-2 border-indigo-500/60 shadow-2xl backdrop-blur-2xl text-center max-w-sm">
            <Award size={32} className="text-amber-400 animate-pulse" />
            <h4 className="text-sm font-black text-white">Concept Mastered!</h4>
            <p className="text-xs text-slate-300">You've completed this section with Professor Clarity.</p>
            <div className="flex items-center gap-2 mt-1">
              {onViewAchievements && (
                <button
                  onClick={onViewAchievements}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 text-xs font-bold cursor-pointer border border-indigo-500/40"
                >
                  🏆 Badges
                </button>
              )}
              {onContinueSection && (
                <button
                  onClick={onContinueSection}
                  className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs font-black cursor-pointer shadow-md"
                >
                  Next Concept ➔
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SLIDE-UP BOTTOM DRAWER (SEARCH, DICTATION, SCREEN RECORD, CONTROLS) */}
      {/* ========================================================================= */}
      {isBottomDrawerOpen && (
        <div className="absolute bottom-2 sm:bottom-3 left-2 right-2 sm:left-6 sm:right-6 z-30 pointer-events-auto max-w-4xl mx-auto animate-in slide-in-from-bottom-4 duration-200">
          <div className="bg-slate-950/95 border border-slate-800/90 rounded-2xl sm:rounded-3xl p-2.5 sm:p-3 shadow-2xl backdrop-blur-2xl space-y-2">
            
            {/* Header in Drawer */}
            <div className="flex items-center justify-between px-1 pb-1 border-b border-slate-800/80 text-[11px] text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                <span className="font-bold text-slate-300">Tutor Command & Search</span>
              </div>
              <div className="flex items-center gap-2">
                {/* Syllabus Button - Hidden per user request */}
                {false && onOpenTopicModal && (
                  <button
                    onClick={onOpenTopicModal}
                    className="text-indigo-400 hover:text-indigo-300 font-bold cursor-pointer flex items-center gap-1"
                  >
                    <Sparkles size={12} />
                    <span>Syllabus</span>
                  </button>
                )}
                {/* Tutor Persona Button - Hidden per user request */}
                {false && onOpenChatControls && (
                  <button
                    onClick={onOpenChatControls}
                    className="text-slate-400 hover:text-white font-bold cursor-pointer flex items-center gap-1 ml-2"
                  >
                    <Sliders size={12} />
                    <span>Tutor Persona</span>
                  </button>
                )}
                <button
                  onClick={() => setIsBottomDrawerOpen(false)}
                  className="p-1 rounded text-slate-500 hover:text-white cursor-pointer ml-2"
                  title="Close Drawer"
                >
                  <X size={14} />
                </button>
              </div>
            </div>

            {/* Input Row */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              {onClearTopic && (
                <button
                  onClick={onClearTopic}
                  className="p-2 sm:p-2.5 rounded-xl sm:rounded-2xl bg-slate-900 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-800 transition-all cursor-pointer shrink-0"
                  title="Clear Topic & Reset Board"
                >
                  <Trash2 size={16} />
                </button>
              )}

              <div className="flex-1 relative flex items-center min-w-0">
                <Search size={14} className="absolute left-3 text-slate-500 pointer-events-none" />
                <input
                  type="text"
                  value={userPrompt}
                  onChange={(e) => setUserPrompt(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && onSendPrompt()}
                  placeholder="Ask Professor Clarity anything or search a topic..."
                  className="w-full bg-slate-900/90 border border-slate-800 rounded-xl sm:rounded-2xl pl-9 pr-3 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500/60 font-medium transition-all"
                  disabled={isLoadingAi}
                />
              </div>

              {/* Dictation */}
              {onToggleSpeech && (
                <button
                  onClick={onToggleSpeech}
                  className={cn(
                    "p-2 sm:px-3 sm:py-2.5 rounded-xl sm:rounded-2xl transition-all cursor-pointer shrink-0 border flex items-center gap-1.5 text-xs font-bold",
                    isListening
                      ? "bg-rose-500/20 text-rose-400 animate-pulse border-rose-500/40"
                      : "bg-slate-900 text-slate-300 hover:text-white border-slate-800"
                  )}
                  title={isListening ? "Stop Dictation" : "Voice Dictation"}
                >
                  {isListening ? <Mic size={16} className="text-rose-400 animate-bounce" /> : <MicOff size={16} />}
                </button>
              )}

              {/* Screen Record */}
              {screenRecordingState === 'idle' ? (
                onStartScreenRecording && (
                  <button
                    onClick={onStartScreenRecording}
                    className="p-2 sm:px-3 sm:py-2.5 rounded-xl sm:rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-all cursor-pointer shrink-0 hidden sm:flex items-center gap-1 text-xs font-bold"
                    title="Screen Record Session"
                  >
                    <Video size={16} className="text-emerald-400" />
                  </button>
                )
              ) : (
                <div className="flex items-center gap-1 bg-red-950/80 border border-red-500/50 rounded-2xl px-2 py-1.5 text-xs font-bold text-red-200 shrink-0">
                  <Disc size={14} className="text-red-400 animate-spin" />
                  {formatRecordingTime && (
                    <span className="font-mono text-[10px] text-red-300">{formatRecordingTime(screenRecordingDuration)}</span>
                  )}
                  {screenRecordingState === 'recording' ? (
                    onPauseScreenRecording && (
                      <button onClick={onPauseScreenRecording} className="p-0.5 hover:text-white cursor-pointer">
                        <Pause size={12} />
                      </button>
                    )
                  ) : (
                    onResumeScreenRecording && (
                      <button onClick={onResumeScreenRecording} className="p-0.5 hover:text-white cursor-pointer">
                        <Play size={12} />
                      </button>
                    )
                  )}
                  {onStopScreenRecording && (
                    <button onClick={onStopScreenRecording} className="p-0.5 hover:text-white cursor-pointer">
                      <Square size={12} />
                    </button>
                  )}
                </div>
              )}

              {/* Session Timer Overlay Style Quick Selector */}
              {onCycleTimerStyle && (
                <button
                  type="button"
                  onClick={onCycleTimerStyle}
                  className={cn(
                    "px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer shrink-0 hidden sm:flex items-center gap-1.5 text-[11px] font-bold select-none",
                    sessionTimerEnabled
                      ? "bg-slate-900/90 hover:bg-slate-800 text-slate-200 border-slate-800 hover:border-indigo-500/50"
                      : "bg-slate-950/60 text-slate-500 border-slate-900 line-through"
                  )}
                  title={`Session Timer Overlay: ${sessionTimerStyle} (Click to switch between minimal, digital-clock, progress-bar)`}
                >
                  <Clock size={12} className={sessionTimerEnabled ? "text-cyan-400" : "text-slate-600"} />
                  <span className="font-mono text-[10px]">
                    {sessionTimerStyle === 'digital-clock' ? 'Digital' : sessionTimerStyle === 'progress-bar' ? 'Bar' : 'Minimal'}
                  </span>
                </button>
              )}

              {/* Camera Feed Toggle */}
              {onToggleCameraFeed && (
                <button
                  onClick={onToggleCameraFeed}
                  className={cn(
                    "p-2 sm:p-2.5 rounded-xl sm:rounded-2xl transition-all cursor-pointer shrink-0 border hidden md:flex items-center",
                    cameraFeedEnabled
                      ? "bg-indigo-600/30 text-indigo-300 border-indigo-500"
                      : "bg-slate-900 text-slate-400 hover:text-white border-slate-800"
                  )}
                  title="Webcam Presenter Feed"
                >
                  <Camera size={16} />
                </button>
              )}

              {/* Send Button */}
              <button
                onClick={onSendPrompt}
                disabled={isLoadingAi || !userPrompt.trim()}
                className="p-2 sm:p-2.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white font-bold transition-all shadow-md shadow-indigo-600/30 cursor-pointer shrink-0"
                title="Send Question"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
