import React, { useState, useMemo } from 'react';
import { EDUCATION_BOARDS, EducationBoard } from '../data/boards';
import { cn } from '@/src/lib/utils';
import { Search, Globe, Award, Shield, Landmark, BookOpen, Compass, Info, CheckCircle2, ChevronRight } from 'lucide-react';

interface BoardsExplorerProps {
  onAskTutor: (boardName: string, boardAcronym: string) => void;
  onSelectBoard: (board: EducationBoard) => void;
  activatedBoardAcronym?: string;
  theme: 'light' | 'dark';
}

export const BoardsExplorer: React.FC<BoardsExplorerProps> = ({ onAskTutor, onSelectBoard, activatedBoardAcronym, theme }) => {
  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState<'All' | 'national' | 'state' | 'international' | 'university' | 'technical-university'>('All');
  const [selectedNation, setSelectedNation] = useState<string>('All');
  const [selectedBoard, setSelectedBoard] = useState<EducationBoard>(EDUCATION_BOARDS[0]); // Default first board

  // Get unique nations from local educational board data
  const nationsList = useMemo(() => {
    const nations = new Set<string>();
    EDUCATION_BOARDS.forEach(b => nations.add(b.nation));
    return ['All', ...Array.from(nations)];
  }, []);

  // Filter boards list based on active filters
  const filteredBoards = useMemo(() => {
    return EDUCATION_BOARDS.filter(board => {
      const query = search.toLowerCase();
      const matchesSearch = 
        board.name.toLowerCase().includes(query) || 
        board.acronym.toLowerCase().includes(query) || 
        board.jurisdiction.toLowerCase().includes(query);
      
      const matchesType = selectedType === 'All' || board.type === selectedType;
      const matchesNation = selectedNation === 'All' || board.nation === selectedNation;

      return matchesSearch && matchesType && matchesNation;
    });
  }, [search, selectedType, selectedNation]);

  // Handle re-selection safety when filters change list results
  React.useEffect(() => {
    if (filteredBoards.length > 0 && !filteredBoards.some(b => b.acronym === selectedBoard?.acronym)) {
      setSelectedBoard(filteredBoards[0]);
    }
  }, [filteredBoards, selectedBoard?.acronym]);

  return (
    <div className="flex flex-col md:flex-row h-[550px]" id="boards_explorer_modal">
      {/* Left Column: List, Search, and Filters */}
      <div className={cn(
        "w-full md:w-[380px] border-r flex flex-col h-full",
        theme === 'dark' ? "border-slate-800" : "border-slate-100"
      )}>
         {/* Search controls & filter tabs */}
        <div className="p-4 space-y-2 flex-shrink-0">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} />
            <input 
              type="text"
              placeholder="Search boards or acronyms..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className={cn(
                "w-full pl-9 pr-4 py-2 border rounded-xl text-sm outline-none transition-colors",
                theme === 'dark' 
                  ? "bg-slate-800 border-slate-700 text-white placeholder-slate-500 focus:border-indigo-500" 
                  : "bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500"
              )}
            />
          </div>

          <div className="space-y-2">
            {/* Nation Filter Dropdown */}
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Nation:</span>
              <select
                value={selectedNation}
                onChange={(e) => setSelectedNation(e.target.value)}
                className={cn(
                  "text-xs px-2 py-1 rounded border outline-none font-semibold",
                  theme === 'dark' ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-700"
                )}
              >
                {nationsList.map(nation => (
                  <option key={nation} value={nation}>{nation}</option>
                ))}
              </select>
            </div>

            {/* Type Pills */}
            <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
              {(['All', 'national', 'state', 'international', 'university', 'technical-university'] as const).map(type => (
                <button
                  key={type}
                  onClick={() => setSelectedType(type)}
                  className={cn(
                    "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider whitespace-nowrap transition-colors border",
                    selectedType === type
                      ? (theme === 'dark' ? "bg-indigo-600 border-indigo-500 text-white" : "bg-indigo-600 border-indigo-600 text-white")
                      : (theme === 'dark' ? "bg-slate-800/40 border-slate-700/80 text-slate-400 hover:bg-slate-800" : "bg-slate-50 border-slate-100 text-slate-600 hover:bg-slate-100")
                  )}
                >
                  {type === 'All' ? 'All Types' : type === 'university' ? 'Non-Tech Uni' : type === 'technical-university' ? 'Technical Uni' : type}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Scrollable List of Boards */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/40">
          {filteredBoards.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm">
              <Compass className="mx-auto mb-2 opacity-50 text-indigo-500 animate-spin" size={24} />
              No boards match your filter criteria.
            </div>
          ) : (
            filteredBoards.map(board => (
              <button
                key={board.acronym}
                onClick={() => {
                  setSelectedBoard(board);
                  onSelectBoard(board);
                }}
                className={cn(
                  "w-full p-3 text-left transition-all flex items-center justify-between group",
                  selectedBoard.acronym === board.acronym
                    ? (theme === 'dark' ? "bg-indigo-950/40 hover:bg-indigo-900/40" : "bg-indigo-50/80 hover:bg-indigo-100/60")
                    : (theme === 'dark' ? "hover:bg-slate-800/30" : "hover:bg-slate-50/50")
                )}
              >
                <div className="min-w-0 pr-2">
                  <div className="flex items-center gap-1.5">
                    <span className={cn(
                      "font-bold text-xs px-1.5 py-0.5 rounded text-[10px]",
                      board.type === 'international' ? "bg-purple-100 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 border border-purple-200/50 dark:border-purple-800/40" :
                      board.type === 'national' ? "bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/40" :
                      board.type === 'technical-university' ? "bg-cyan-100 dark:bg-cyan-950/40 text-cyan-600 dark:text-cyan-400 border border-cyan-200/50 dark:border-cyan-800/40" :
                      board.type === 'university' ? "bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200/50 dark:border-rose-800/40" :
                      "bg-blue-100 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-200/50 dark:border-blue-800/40"
                    )}>
                      {board.acronym}
                    </span>
                    <span className={cn(
                      "font-semibold text-xs truncate max-w-[150px]",
                      theme === 'dark' ? "text-slate-300" : "text-slate-700"
                    )}>
                      {board.nation}
                    </span>
                  </div>
                  <div className={cn(
                    "font-bold text-sm truncate mt-1",
                    theme === 'dark' ? "text-white" : "text-slate-900"
                  )}>
                    {board.name}
                  </div>
                  <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 truncate">
                    {board.jurisdiction}
                  </div>
                </div>
                <ChevronRight size={14} className={cn(
                  "opacity-0 transition-all text-indigo-500",
                  selectedBoard.acronym === board.acronym ? "opacity-100 translate-x-1" : "group-hover:opacity-100"
                )} />
              </button>
            ))
          )}
        </div>
      </div>

      {/* Right Column: Detail Content */}
      <div className={cn(
        "flex-1 flex flex-col p-6 overflow-y-auto",
        theme === 'dark' ? "bg-slate-900/40" : "bg-slate-50/30"
      )}>
        {selectedBoard ? (
          <div className="space-y-5 max-w-2xl">
            {/* Header Badge */}
            <div className="pb-4 border-b border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className={cn(
                  "px-2.5 py-1 text-xs font-black uppercase tracking-wider rounded-lg border",
                  selectedBoard.type === 'international' ? "bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800" :
                  selectedBoard.type === 'national' ? "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800" :
                  selectedBoard.type === 'technical-university' ? "bg-cyan-100 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400 border-cyan-200 dark:border-cyan-800" :
                  selectedBoard.type === 'university' ? "bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800" :
                  "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800"
                )}>
                  {selectedBoard.type === 'technical-university' ? 'Technical Uni' : selectedBoard.type === 'university' ? 'Non-Tech Uni' : `${selectedBoard.type} board`}
                </span>
                <span className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-bold px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700">
                  📍 {selectedBoard.nation}
                </span>
                <span className="text-xs bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-bold px-2 py-1 rounded-lg border border-indigo-100 dark:border-indigo-900/30">
                  {selectedBoard.classesCovered}
                </span>
              </div>
              <h2 className={cn(
                "text-2xl font-black tracking-tight",
                theme === 'dark' ? "text-white" : "text-slate-900"
              )}>
                {selectedBoard.name} ({selectedBoard.acronym})
              </h2>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                <Landmark size={12} className="text-slate-400" /> Jurisdiction: {selectedBoard.jurisdiction}
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <h4 className="text-xs font-black tracking-wider text-slate-400 dark:text-slate-500 uppercase flex items-center gap-1">
                <Info size={12} /> Board Overview
              </h4>
              <p className={cn(
                "text-sm leading-relaxed",
                theme === 'dark' ? "text-slate-300" : "text-slate-600"
              )}>
                {selectedBoard.description}
              </p>
            </div>

            {/* Curriculum Focus */}
            <div className="space-y-1.5">
              <h4 className="text-xs font-black tracking-wider text-slate-400 dark:text-slate-500 uppercase flex items-center gap-1">
                <Award size={12} /> Curriculum & Academic Focus
              </h4>
              <p className={cn(
                "text-sm leading-relaxed",
                theme === 'dark' ? "text-slate-300" : "text-slate-600"
              )}>
                {selectedBoard.curriculumFocus}
              </p>
            </div>

            {/* Dynamic Features List */}
            <div className="space-y-2">
              <h4 className="text-xs font-black tracking-wider text-slate-400 dark:text-slate-500 uppercase">
                Key Structural Features
              </h4>
              <div className="grid grid-cols-1 gap-2.5">
                {selectedBoard.keyFeatures.map((feat, i) => (
                  <div 
                    key={i} 
                    className={cn(
                      "p-3 rounded-xl border flex items-start gap-2.5 text-xs font-medium",
                      theme === 'dark' ? "bg-slate-800/20 border-slate-800/60 text-slate-300" : "bg-white border-slate-100 text-slate-700"
                    )}
                  >
                    <CheckCircle2 size={14} className="text-indigo-500 flex-shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Integration Action Button */}
            <div className="pt-4 flex flex-col sm:flex-row gap-3">
              {activatedBoardAcronym === selectedBoard.acronym ? (
                <div className="flex-1 flex items-center justify-center gap-2 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/50 font-bold py-3 px-5 rounded-xl text-sm">
                  <CheckCircle2 size={16} />
                  {selectedBoard.acronym} Board Active
                </div>
              ) : (
                <button
                  onClick={() => onSelectBoard(selectedBoard)}
                  className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-5 rounded-xl shadow-lg cursor-pointer active:scale-95 transition-all text-sm"
                >
                  <CheckCircle2 size={16} />
                  Activate {selectedBoard.acronym} Board
                </button>
              )}
              <button
                onClick={() => {
                  onSelectBoard(selectedBoard);
                  onAskTutor(selectedBoard.name, selectedBoard.acronym);
                }}
                className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-violet-650 to-violet-600 hover:from-violet-600 hover:to-violet-550 text-white font-bold py-3 px-5 rounded-xl shadow-lg shadow-violet-500/10 cursor-pointer active:scale-95 transition-all text-sm group"
              >
                <BookOpen size={16} className="group-hover:rotate-6 transition-transform" />
                Ask Tutor to Teach Syllabus
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
            <Globe className="animate-spin mb-4" size={40} />
            Select a board to view structured information.
          </div>
        )}
      </div>
    </div>
  );
};
