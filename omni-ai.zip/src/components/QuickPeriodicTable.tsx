import React, { useState } from 'react';
import { cn } from '@/src/lib/utils';
import { Atom, Sparkles, BookOpen, ExternalLink, ShieldAlert, Zap, Info } from 'lucide-react';

interface ElementInfo {
  symbol: string;
  name: string;
  atomicNumber: number;
  category: string;
  coordinationRole: string;
  oxidationStates: string[];
  electronicConfig: string;
  color: string;
}

const COORDINATION_ELEMENTS: Record<string, ElementInfo> = {
  'Ti': { symbol: 'Ti', name: 'Titanium', atomicNumber: 22, category: 'Transition Metal', coordinationRole: 'Forms metallocene complexes and TiCl3 Ziegler-Natta catalysts.', oxidationStates: ['+2', '+3', '+4'], electronicConfig: '[Ar] 3d² 4s²', color: 'bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-400' },
  'V': { symbol: 'V', name: 'Vanadium', atomicNumber: 23, category: 'Transition Metal', coordinationRole: 'Used as V2O5 catalyst and in oxovanadium coordination complexes.', oxidationStates: ['+2', '+3', '+4', '+5'], electronicConfig: '[Ar] 3d³ 4s²', color: 'bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-400' },
  'Cr': { symbol: 'Cr', name: 'Chromium', atomicNumber: 24, category: 'Transition Metal', coordinationRole: 'Forms classic Werner coordination complexes like [Cr(NH3)6]Cl3 and [Cr(H2O)6]Cl3.', oxidationStates: ['+2', '+3', '+6'], electronicConfig: '[Ar] 3d⁵ 4s¹', color: 'bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400' },
  'Mn': { symbol: 'Mn', name: 'Manganese', atomicNumber: 25, category: 'Transition Metal', coordinationRole: 'Acts as central metal in bioinorganic cofactors and permanganate oxidation states.', oxidationStates: ['+2', '+4', '+7'], electronicConfig: '[Ar] 3d⁵ 4s²', color: 'bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-400' },
  'Fe': { symbol: 'Fe', name: 'Iron', atomicNumber: 26, category: 'Transition Metal', coordinationRole: 'Forms hexaaquairon(III), ferro/ferricyanide complexes ([Fe(CN)6]3-/[Fe(CN)6]4-), and heme.', oxidationStates: ['+2', '+3', '+6'], electronicConfig: '[Ar] 3d⁶ 4s²', color: 'bg-indigo-500/10 border-indigo-500 text-indigo-600 dark:text-indigo-400' },
  'Co': { symbol: 'Co', name: 'Cobalt', atomicNumber: 27, category: 'Transition Metal', coordinationRole: 'Benchmark metal for coordination chemistry: Hexaamminecobalt(III) chloride, [Co(NH3)6]3+.', oxidationStates: ['+2', '+3'], electronicConfig: '[Ar] 3d⁷ 4s²', color: 'bg-purple-500/10 border-purple-500 text-purple-600 dark:text-purple-400' },
  'Ni': { symbol: 'Ni', name: 'Nickel', atomicNumber: 28, category: 'Transition Metal', coordinationRole: 'Forms square planar [Ni(CN)4]2- (diamagnetic) and tetrahedral [NiCl4]2- (paramagnetic).', oxidationStates: ['+2', '+4'], electronicConfig: '[Ar] 3d⁸ 4s²', color: 'bg-teal-500/10 border-teal-500 text-teal-600 dark:text-teal-400' },
  'Cu': { symbol: 'Cu', name: 'Copper', atomicNumber: 29, category: 'Transition Metal', coordinationRole: 'Forms tetraamminecopper(II) complex [Cu(NH3)4(H2O)2]2+ with deep royal blue color.', oxidationStates: ['+1', '+2'], electronicConfig: '[Ar] 3d¹⁰ 4s¹', color: 'bg-blue-500/10 border-blue-500 text-blue-600 dark:text-blue-400' },
  'Zn': { symbol: 'Zn', name: 'Zinc', atomicNumber: 30, category: 'Transition Metal', coordinationRole: 'Forms tetrahedral ammine and hydroxo complexes in biological carbonic anhydrase.', oxidationStates: ['+2'], electronicConfig: '[Ar] 3d¹⁰ 4s²', color: 'bg-slate-500/10 border-slate-500 text-slate-600 dark:text-slate-400' },
  'Pt': { symbol: 'Pt', name: 'Platinum', atomicNumber: 78, category: 'Transition Metal', coordinationRole: 'Forms square planar complexes including Cisplatin [PtCl2(NH3)2], a potent anticancer drug.', oxidationStates: ['+2', '+4'], electronicConfig: '[Xe] 4f¹⁴ 5d⁹ 6s¹', color: 'bg-amber-600/10 border-amber-600 text-amber-600 dark:text-amber-400' },
  'Pd': { symbol: 'Pd', name: 'Palladium', atomicNumber: 46, category: 'Transition Metal', coordinationRole: 'Catalyzes cross-coupling reactions as organometallic coordination complexes.', oxidationStates: ['+2', '+4'], electronicConfig: '[Kr] 4d¹⁰', color: 'bg-indigo-600/10 border-indigo-600 text-indigo-600 dark:text-indigo-400' },
  'NH3': { symbol: 'NH₃', name: 'Ammonia Ligand', atomicNumber: 0, category: 'Neutral Ligand', coordinationRole: 'Strong-field ammine ligand forming stable Werner coordination complexes with Co, Cr, Cu, Ni.', oxidationStates: ['0'], electronicConfig: 'Lone pair donor', color: 'bg-pink-500/10 border-pink-500 text-pink-600 dark:text-pink-400' },
  'CN': { symbol: 'CN⁻', name: 'Cyanide Ligand', atomicNumber: 0, category: 'Strong Field Ligand', coordinationRole: 'Ambidentate strong field ligand causing large crystal field splitting ($\\Delta_o$).', oxidationStates: ['-1'], electronicConfig: 'Carbon/Nitrogen donor', color: 'bg-rose-500/10 border-rose-500 text-rose-600 dark:text-rose-400' }
};

interface QuickPeriodicTableProps {
  theme: 'light' | 'dark';
  onOpenChapter: (chapterNumber: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const QuickPeriodicTable: React.FC<QuickPeriodicTableProps> = ({
  theme,
  onOpenChapter,
  showNotification
}) => {
  const [selectedSymbol, setSelectedSymbol] = useState<string>('Co');
  const activeElement = COORDINATION_ELEMENTS[selectedSymbol] || COORDINATION_ELEMENTS['Co'];

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-y-auto p-6 md:p-8 selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-slate-50/50 text-slate-900"
    )}>
      {/* Header Banner */}
      <div className={cn(
        "p-6 rounded-3xl border mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl",
        theme === 'dark' ? "bg-gradient-to-r from-blue-950/60 via-slate-900 to-indigo-950/40 border-blue-900/40" : "bg-gradient-to-r from-blue-50 via-white to-indigo-50 border-blue-100"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-500/30">
            <Atom size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                Sidebar & Quick Widget Companion
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Quick Periodic Table of Coordination Elements
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Inspect d-block transition metals and ligands frequently featured in Coordination Compounds (Chapter 9) and inorganic synthesis.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-blue-500/10 text-blue-600 dark:text-blue-400 px-4 py-2 rounded-2xl font-bold text-xs border border-blue-500/20">
          <Sparkles size={16} />
          <span>Chapter 9 Reference</span>
        </div>
      </div>

      {/* Grid of Coordination Elements */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive Elements Grid */}
        <div className={cn(
          "lg:col-span-2 p-6 rounded-3xl border shadow-xl flex flex-col",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div className="text-xs font-black uppercase tracking-wider text-slate-400 mb-4">
            Select d-Block Transition Metal or Ligand:
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
            {Object.entries(COORDINATION_ELEMENTS).map(([sym, el]) => {
              const isSelected = selectedSymbol === sym;
              return (
                <button
                  key={sym}
                  onClick={() => {
                    setSelectedSymbol(sym);
                    showNotification?.(`Selected ${el.name} (${el.symbol})`, 'info');
                  }}
                  className={cn(
                    "p-3 rounded-2xl border transition-all flex flex-col items-center justify-center gap-1 cursor-pointer group",
                    isSelected
                      ? "bg-blue-600 text-white border-blue-500 shadow-lg shadow-blue-500/30 scale-105"
                      : theme === 'dark'
                      ? "bg-slate-900/60 border-slate-700 hover:border-blue-500/50 text-slate-300"
                      : "bg-slate-50 border-slate-200 hover:border-blue-300 text-slate-700"
                  )}
                >
                  <div className="text-[10px] font-mono opacity-70">{el.atomicNumber > 0 ? el.atomicNumber : 'Ligand'}</div>
                  <div className="text-lg font-black tracking-tight group-hover:scale-110 transition-transform">{el.symbol}</div>
                  <div className="text-[10px] font-bold truncate w-full text-center">{el.name}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Col: Detailed Element Inspection Card */}
        <div className={cn(
          "p-6 rounded-3xl border shadow-xl flex flex-col justify-between",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div>
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-100 dark:border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 flex items-center justify-center font-black text-xl">
                  {activeElement.symbol}
                </div>
                <div>
                  <h3 className="text-xl font-black tracking-tight">{activeElement.name}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{activeElement.category}</p>
                </div>
              </div>
              <div className="text-right font-mono text-xs font-bold px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-700">
                Z = {activeElement.atomicNumber || 'N/A'}
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="font-black uppercase tracking-wider text-slate-400 block mb-1">Electronic Configuration</span>
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-900/80 font-mono font-bold text-blue-600 dark:text-blue-400 border border-slate-200 dark:border-slate-700">
                  {activeElement.electronicConfig}
                </div>
              </div>

              <div>
                <span className="font-black uppercase tracking-wider text-slate-400 block mb-1">Common Oxidation States</span>
                <div className="flex flex-wrap gap-1.5">
                  {activeElement.oxidationStates.map((st, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold border border-indigo-500/20">
                      {st}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="font-black uppercase tracking-wider text-slate-400 block mb-1">Coordination Chemistry Role</span>
                <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-900/80 text-slate-700 dark:text-slate-300 leading-relaxed border border-slate-200 dark:border-slate-700">
                  {activeElement.coordinationRole}
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400">
              <BookOpen size={14} />
              <span>Chapter 9: Coordination Compounds</span>
            </div>
            <button
              onClick={() => onOpenChapter(9)}
              className="flex items-center gap-1 bg-blue-50 hover:bg-blue-600 text-blue-600 hover:text-white dark:bg-blue-950/60 dark:hover:bg-blue-600 dark:text-blue-300 text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              <span>Read Chapter</span>
              <ExternalLink size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
