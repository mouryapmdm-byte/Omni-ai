import React, { useState, useEffect } from 'react';
import { Code, Play, Trash2, Copy, CheckCircle2, AlertCircle, Terminal } from 'lucide-react';
import { cn } from '../lib/utils';

export const CodePlayground: React.FC = () => {
  const [code, setCode] = useState(`// JavaScript Math Playground\n\nconst x = 5;\nconst y = 10;\n\nconsole.log("Sum:", x + y);\nconsole.log("Product:", x * y);\nconsole.log("Square root of 25:", Math.sqrt(25));\n\n// Try defining a function\nfunction factorial(n) {\n  if (n === 0) return 1;\n  return n * factorial(n - 1);\n}\n\nconsole.log("Factorial of 5:", factorial(5));`);
  const [output, setOutput] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);

  const runCode = () => {
    setOutput([]);
    setError(null);
    
    const originalLog = console.log;
    const logs: string[] = [];
    
    console.log = (...args) => {
      logs.push(args.map(arg => 
        typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
      ).join(' '));
    };

    try {
      // Use new Function for simplicity in this playground
      new Function(code)();
      setOutput(logs);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      console.log = originalLog;
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const clearOutput = () => setOutput([]);

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="flex items-center justify-between px-2 flex-shrink-0">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider">
          <Code size={14} /> JavaScript Playground
        </div>
        <div className="flex gap-2">
          <button
            onClick={copyCode}
            className="p-2 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-all"
            title="Copy Code"
          >
            {isCopied ? <CheckCircle2 size={16} className="text-green-500" /> : <Copy size={16} />}
          </button>
          <button
            onClick={() => setCode('')}
            className="p-2 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-all text-red-500"
            title="Clear Code"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-[400px]">
        <div className="flex flex-col space-y-2">
          <div className="flex-1 relative font-mono text-sm">
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full h-full p-4 bg-slate-900 text-slate-100 rounded-2xl border-2 border-slate-800 focus:border-indigo-500 focus:ring-0 transition-all resize-none"
              spellCheck={false}
            />
          </div>
          <button
            onClick={runCode}
            className="py-3 bg-indigo-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all"
          >
            <Play size={18} /> Run Code
          </button>
        </div>

        <div className="flex flex-col space-y-2">
          <div className="flex-1 bg-slate-50 rounded-2xl border-2 border-slate-100 overflow-hidden flex flex-col">
            <div className="p-3 border-b border-slate-100 bg-slate-100/50 flex justify-between items-center">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <Terminal size={12} /> Console Output
              </span>
              <button 
                onClick={clearOutput}
                className="text-xs font-bold text-slate-400 hover:text-slate-600 uppercase tracking-widest"
              >
                Clear
              </button>
            </div>
            <div className="flex-1 p-4 font-mono text-sm overflow-y-auto">
              {error ? (
                <div className="flex items-start gap-2 text-red-500">
                  <AlertCircle size={16} className="mt-1 flex-shrink-0" />
                  <pre className="whitespace-pre-wrap">{error}</pre>
                </div>
              ) : output.length > 0 ? (
                <div className="space-y-1">
                  {output.map((line, idx) => (
                    <div key={idx} className="text-slate-700 whitespace-pre-wrap">
                      <span className="text-slate-300 mr-2">{'>'}</span>
                      {line}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="h-full flex items-center justify-center text-slate-400 italic">
                  Run code to see output here
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
