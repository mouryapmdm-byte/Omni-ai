export interface Skill {
  id: string;
  name: string;
  type: 'hard' | 'soft';
  category: string; // e.g. "Industries Skill", "Software Designing"
  description: string;
  earningLevels: string[]; // e.g. ["Junior Earning", "Mid Earning", "Senior Earning"]
  earningRates: Record<string, string>; // e.g. {"Junior Earning": "$18/hr", "Mid Earning": "$40/hr", "Senior Earning": "$85/hr"}
}

export const NATION_SKILLS: Record<string, Skill[]> = {
  "India": [
    {
      id: "ind-automation",
      name: "Industrial Automation & IoT",
      type: "hard",
      category: "Industries Skill",
      description: "PLC programming, SCADA systems, and industrial sensor integration for smart factories.",
      earningLevels: ["Apprentice Earning", "Professional Earning", "Expert Earning"],
      earningRates: { "Apprentice Earning": "₹25,000/mo", "Professional Earning": "₹60,000/mo", "Expert Earning": "₹1,50,000/mo" }
    },
    {
      id: "ind-fullstack",
      name: "Full-Stack Web Development",
      type: "hard",
      category: "Software Designing",
      description: "Building scalable modern web applications using React, Node.js, and databases.",
      earningLevels: ["Junior Dev Earning", "Mid Dev Earning", "Senior Dev Earning"],
      earningRates: { "Junior Dev Earning": "₹35,000/mo", "Mid Dev Earning": "₹80,000/mo", "Senior Dev Earning": "₹2,00,000/mo" }
    },
    {
      id: "ind-uiux",
      name: "UI/UX & Product Design",
      type: "soft",
      category: "Software Designing",
      description: "User research, wireframing, high-fidelity UI layout design, and interactive prototyping in Figma.",
      earningLevels: ["Junior Designer Earning", "Lead Designer Earning", "Director Earning"],
      earningRates: { "Junior Designer Earning": "₹30,000/mo", "Lead Designer Earning": "₹75,000/mo", "Director Earning": "₹1,80,000/mo" }
    },
    {
      id: "ind-writing",
      name: "Technical Writing & Communication",
      type: "soft",
      category: "Professional Services",
      description: "Drafting API documentation, developer guides, and high-quality technical marketing copies.",
      earningLevels: ["Freelancer Earning", "Contractor Earning", "Staff Writer Earning"],
      earningRates: { "Freelancer Earning": "₹20,000/mo", "Contractor Earning": "₹50,000/mo", "Staff Writer Earning": "₹1,10,000/mo" }
    }
  ],
  "USA": [
    {
      id: "usa-cloud",
      name: "Cloud Infrastructure & DevOps",
      type: "hard",
      category: "Industries Skill",
      description: "Designing resilient AWS/GCP cloud environments, Docker containerization, and CI/CD pipelines.",
      earningLevels: ["Associate Earning", "Professional Earning", "Principal Earning"],
      earningRates: { "Associate Earning": "$45/hr", "Professional Earning": "$95/hr", "Principal Earning": "$160/hr" }
    },
    {
      id: "usa-machining",
      name: "CNC & Precision Machining",
      type: "hard",
      category: "Industries Skill",
      description: "Operating CNC mills, G-code computer programming, and high-precision CAD/CAM fabrication.",
      earningLevels: ["Apprentice Earning", "Journeyman Earning", "Master Machinist Earning"],
      earningRates: { "Apprentice Earning": "$22/hr", "Journeyman Earning": "$40/hr", "Master Machinist Earning": "$65/hr" }
    },
    {
      id: "usa-software",
      name: "SaaS Software Designing",
      type: "soft",
      category: "Software Designing",
      description: "Structuring user-centric SaaS interfaces, visual component design systems, and fluid workflows.",
      earningLevels: ["Junior Designer Earning", "Senior Designer Earning", "Principal Designer Earning"],
      earningRates: { "Junior Designer Earning": "$35/hr", "Senior Designer Earning": "$85/hr", "Principal Designer Earning": "$140/hr" }
    },
    {
      id: "usa-pm",
      name: "Agile Product Management",
      type: "soft",
      category: "Management & Strategy",
      description: "Leading cross-functional sprints, drafting product roadmaps, and managing product requirements.",
      earningLevels: ["Junior PM Earning", "Senior PM Earning", "Director PM Earning"],
      earningRates: { "Junior PM Earning": "$40/hr", "Senior PM Earning": "$90/hr", "Director PM Earning": "$150/hr" }
    }
  ],
  "UK": [
    {
      id: "uk-robotics",
      name: "Robotics & Control Systems",
      type: "hard",
      category: "Industries Skill",
      description: "Robot Operating System (ROS) setup, kinematics modeling, and sensor feedback integration.",
      earningLevels: ["Graduate Earning", "Senior Engineer Earning", "Consultant Earning"],
      earningRates: { "Graduate Earning": "£25/hr", "Senior Engineer Earning": "£55/hr", "Consultant Earning": "£95/hr" }
    },
    {
      id: "uk-software",
      name: "User Interface Architecture",
      type: "soft",
      category: "Software Designing",
      description: "Heuristic evaluation, responsive layouts design, accessibility compliance, and digital typography.",
      earningLevels: ["Junior Architect Earning", "Senior Architect Earning", "Lead Architect Earning"],
      earningRates: { "Junior Architect Earning": "£30/hr", "Senior Architect Earning": "£65/hr", "Lead Architect Earning": "£110/hr" }
    }
  ],
  "Canada": [
    {
      id: "can-renewables",
      name: "Renewable Energy Integration",
      type: "hard",
      category: "Industries Skill",
      description: "Grid integration of photovoltaics, wind farm site assessment, and power distribution systems.",
      earningLevels: ["Technician Earning", "Engineer Earning", "Project Lead Earning"],
      earningRates: { "Technician Earning": "$25/hr", "Engineer Earning": "$55/hr", "Project Lead Earning": "$90/hr" }
    },
    {
      id: "can-software",
      name: "UX Research & Design Systems",
      type: "soft",
      category: "Software Designing",
      description: "User interview modeling, design systems specification, and interactive system layout prototyping.",
      earningLevels: ["Junior Researcher Earning", "Senior Researcher Earning", "Research Lead Earning"],
      earningRates: { "Junior Researcher Earning": "$28/hr", "Senior Researcher Earning": "$60/hr", "Research Lead Earning": "$105/hr" }
    }
  ],
  "Singapore": [
    {
      id: "sg-semiconductor",
      name: "Semiconductor Process Lithography",
      type: "hard",
      category: "Industries Skill",
      description: "Photolithography process engineering, yield enhancement analytics, and cleanroom design.",
      earningLevels: ["Associate Engineer Earning", "Senior Process Engineer Earning", "Technical Specialist Earning"],
      earningRates: { "Associate Engineer Earning": "S$30/hr", "Senior Process Engineer Earning": "S$65/hr", "Technical Specialist Earning": "S$110/hr" }
    },
    {
      id: "sg-software",
      name: "UX/UI Design & Micro-interactions",
      type: "soft",
      category: "Software Designing",
      description: "Designing modern micro-animations, fluid state transitions, and responsive component libraries.",
      earningLevels: ["Junior Specialist Earning", "Senior Specialist Earning", "Lead Specialist Earning"],
      earningRates: { "Junior Specialist Earning": "S$35/hr", "Senior Specialist Earning": "S$75/hr", "Lead Specialist Earning": "S$130/hr" }
    }
  ],
  "China": [
    {
      id: "chn-robotics",
      name: "Mechatronics & Drone Fabrication",
      type: "hard",
      category: "Industries Skill",
      description: "Hardware controller design, brushless motor wiring, and autonomous navigation telemetry.",
      earningLevels: ["Apprentice Earning", "Senior Developer Earning", "Expert Earning"],
      earningRates: { "Apprentice Earning": "¥120/hr", "Senior Developer Earning": "¥280/hr", "Expert Earning": "¥550/hr" }
    },
    {
      id: "chn-software",
      name: "Interactive Mobile Layout Design",
      type: "soft",
      category: "Software Designing",
      description: "High-density mobile interface layout design, screen interaction design, and system flowcharts.",
      earningLevels: ["Junior UI Earning", "Senior UI Earning", "Creative Director Earning"],
      earningRates: { "Junior UI Earning": "¥150/hr", "Senior UI Earning": "¥320/hr", "Creative Director Earning": "¥600/hr" }
    }
  ]
};

export const DEFAULT_SKILLS: Skill[] = [
  {
    id: "def-industrial",
    name: "Industrial Machining & Fabrication",
    type: "hard",
    category: "Industries Skill",
    description: "Operating lathes, computer fabrication, hydraulic presses, and machinery safety codes.",
    earningLevels: ["Basic Earning", "Professional Earning", "Master Earning"],
    earningRates: { "Basic Earning": "$20/hr", "Professional Earning": "$45/hr", "Master Earning": "$80/hr" }
  },
  {
    id: "def-software",
    name: "Digital Interface Layout & Design",
    type: "soft",
    category: "Software Designing",
    description: "Structuring digital products, screen planning, wireframes, and interactive mockups.",
    earningLevels: ["Junior Earning", "Intermediate Earning", "Senior Earning"],
    earningRates: { "Junior Earning": "$25/hr", "Intermediate Earning": "$50/hr", "Senior Earning": "$95/hr" }
  }
];

export function getSkillsForNation(nation: string): Skill[] {
  return NATION_SKILLS[nation] || DEFAULT_SKILLS;
}
