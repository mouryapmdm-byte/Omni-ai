import { SupportedLanguageCode, CulturalAdaptationRule } from './types';

export class CulturalAdaptation {
  private static readonly RULES: CulturalAdaptationRule[] = [
    {
      category: 'names',
      westernTerm: 'John and Alice',
      indianEquivalents: {
        en: 'Rahul and Priya',
        hi: 'राहुल और प्रिया',
        ta: 'ராகுல் மற்றும் பிரியா',
        te: 'రాహుల్ మరియు ప్రియ',
        bn: 'রাহুল এবং প্রিয়া',
        mr: 'राहुल आणि प्रिया',
        kn: 'ರಾಹುಲ್ ಮತ್ತು ಪ್ರಿಯಾ',
        ml: 'രാഹുലും പ്രിയയും',
        gu: 'રાહુલ અને પ્રિયા',
        pa: 'ਰਾਹੁਲ ਅਤੇ ਪ੍ਰਿਆ',
        ur: 'راحل اور پریا'
      },
      explanation: 'Replace generic Western names with relatable local student personas'
    },
    {
      category: 'sports',
      westernTerm: 'baseball pitch trajectory',
      indianEquivalents: {
        en: 'cricket ball boundary trajectory (projectile motion)',
        hi: 'क्रिकेट गेंद की बाउंड्री प्रक्षेप्य गति (Projectile Motion)',
        ta: 'கிரிக்கெட் பந்தின் எறிபாதை இயக்கம் (Projectile Motion)',
        te: 'క్రికెట్ బంతి బౌండరీ ప్రक्षेपణ గమనం (Projectile Motion)',
        bn: 'ক্রিকেট বলের বাউন্ডারি প্রজেক্টাইল মোশন',
        mr: 'क्रिकेट बॉलची बाउंड्री प्रक्षेप्य गती',
        kn: 'ಕ್ರಿಕೆಟ್ ಚೆಂಡಿನ ಬೌಂಡರಿ ಪ್ರಕ್ಷೇಪಕ ಚಲನೆ',
        ml: 'ക്രിക്കറ്റ് പന്തിന്റെ പ്രൊജക്റ്റൈൽ ചലനം',
        gu: 'ક્રિકેટ બોલની બાઉન્ડ્રી પ્રક્ષેપ્ય ગતિ',
        pa: 'ਕ੍ਰਿਕੇਟ ਗੇਂਦ ਦੀ ਬਾਊਂਡਰੀ ਪ੍ਰੋਜੈਕਟਾਈਲ ਗਤੀ',
        ur: 'کرکٹ بال کی باؤنڈری پروجیکٹائل موشن'
      },
      explanation: 'Connect projectile kinematics to cricket boundary shots'
    },
    {
      category: 'food',
      westernTerm: 'pancake batter fermentation and thermal baking',
      indianEquivalents: {
        en: 'idli/dosa batter fermentation and tawa thermal conduction',
        hi: 'इडली/डोसा के घोल का किण्वन (Fermentation) और तवे पर ऊष्मा चालन',
        ta: 'இட்லி/தோசை மாவு நொதித்தல் மற்றும் தவா வெப்பக்கடத்தல்',
        te: 'ఇడ్లీ/దోస పిండి పులియబెట్టడం మరియు పెనం ఉష్ణ వాహకత',
        bn: 'ইডলি/দোসা ব্যাটার গাঁজন এবং তাওয়া তাপ সঞ্চালন',
        mr: 'इडली/डोसा पिठाचे किण्वन आणि तव्यावरील उष्णता वहन',
        kn: 'ಇಡ್ಲಿ/ದೋಸೆ ಹಿಟ್ಟಿನ ಹುದುಗುವಿಕೆ ಮತ್ತು ತವಾ ಶಾಖ ವಹನ',
        ml: 'ഇഡ്ഡലി/ദോശ മാവ് പുളിപ്പിക്കലും ചൂട് സംവഹനവും',
        gu: 'ઇડલી/ઢોંસાના ખીરાનું આથો અને તવા ઉષ્મા વહન',
        pa: 'ਇਡਲੀ/ਢੋਸਾ ਦੇ ਘੋਲ ਦਾ ਖਮੀਰਨ ਅਤੇ ਤਵੇ ਉੱਤੇ ਤਾਪ ਸੰਚਾਰ',
        ur: 'ڈوسا بیٹر کا خمیر اور توے پر حرارت کی ترسیل'
      },
      explanation: 'Explain anaerobic respiration & heat transfer using familiar Indian cooking'
    },
    {
      category: 'festivals',
      westernTerm: 'Christmas tree series circuit lights',
      indianEquivalents: {
        en: 'Diwali fairy lights circuit (series vs parallel voltage division)',
        hi: 'दिवाली की लड़ियों का परिपथ (श्रेणीक्रम बनाम समानांतर वोल्टेज विभाजन)',
        ta: 'தீபாவளி அலங்கார விளக்குகள் மின்சுற்று (தொடர் vs பக்க இணைப்பு)',
        te: 'దీపావళి లైట్ల విద్యుత్ వలయం (శ్రేణి vs సమాంతర వోల్టేజ్ విభజన)',
        bn: 'দীপাবলি আলোর সার্কিট (শ্রেণী বনাম সমান্তরাল বিভব বিভাজন)',
        mr: 'दिवाळीच्या दिव्यांची मालिका (श्रेणीबद्ध विरुद्ध समांतर जोडणी)',
        kn: 'ದೀಪಾವಳಿ ದೀಪಗಳ ವಿದ್ಯುತ್ ಮಂಡಲ (ಸರಣಿ vs ಸಮಾಂತರ)',
        ml: 'ദീപാവലി ലൈറ്റ് സർക്യൂട്ട് (സീരീസ് vs പാരലൽ)',
        gu: 'દિવાળી લાઈટ્સ સર્કિટ (શ્રેણી વિરુદ્ધ સમાંતર જોડાણ)',
        pa: 'ਦੀਵਾਲੀ ਲੜੀਆਂ ਦਾ ਸਰਕਟ (ਸੀਰੀਜ਼ ਬਨਾਮ ਸਮਾਨਾਂਤਰ)',
        ur: 'دیوالی اور عید لائٹس سرکٹ (سیریز بمقابلہ متوازی)'
      },
      explanation: 'Illustrate resistor networks and voltage drops using festive lighting circuits'
    }
  ];

  /**
   * Adapts text to culturally relevant Indian examples in the specified language
   */
  static adaptText(text: string, lang: SupportedLanguageCode = 'en'): string {
    let adapted = text;

    for (const rule of this.RULES) {
      const targetEquivalent = rule.indianEquivalents[lang] || rule.indianEquivalents['en'];
      const regex = new RegExp(rule.westernTerm, 'gi');
      adapted = adapted.replace(regex, targetEquivalent);
    }

    return adapted;
  }

  /**
   * Returns list of all cultural adaptation rules
   */
  static getRules(): CulturalAdaptationRule[] {
    return this.RULES;
  }
}
