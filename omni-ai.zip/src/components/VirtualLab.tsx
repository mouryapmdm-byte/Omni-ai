import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { NextGenStemSimulationsHub } from '../modules/virtual-labs/NextGenStemSimulationsHub';
import { 
  Beaker, 
  Orbit, 
  Dna, 
  Zap, 
  Flame, 
  RotateCcw, 
  Play, 
  Pause, 
  Info, 
  Atom, 
  HelpCircle, 
  Thermometer, 
  Sun, 
  Wind, 
  Activity, 
  Eye, 
  EyeOff, 
  Heart,
  Droplet
} from 'lucide-react';

interface ElementNode {
  id: string;
  name: string;
  symbol: string;
  color: string;
  category: string;
  atomicNumber: number;
}

const AVAILABLE_ELEMENTS: ElementNode[] = [
  { id: 'h', name: 'Hydrogen', symbol: 'H', color: '#6366f1', category: 'Non-metal', atomicNumber: 1 },
  { id: 'he', name: 'Helium', symbol: 'He', color: '#ec4899', category: 'Noble Gas', atomicNumber: 2 },
  { id: 'li', name: 'Lithium', symbol: 'Li', color: '#3b82f6', category: 'Alkali Metal', atomicNumber: 3 },
  { id: 'be', name: 'Beryllium', symbol: 'Be', color: '#14b8a6', category: 'Alkaline Earth', atomicNumber: 4 },
  { id: 'c', name: 'Carbon', symbol: 'C', color: '#4b5563', category: 'Non-metal', atomicNumber: 6 },
  { id: 'n', name: 'Nitrogen', symbol: 'N', color: '#8b5cf6', category: 'Non-metal', atomicNumber: 7 },
  { id: 'o', name: 'Oxygen', symbol: 'O', color: '#ef4444', category: 'Non-metal', atomicNumber: 8 },
  { id: 'f', name: 'Fluorine', symbol: 'F', color: '#f59e0b', category: 'Halogen', atomicNumber: 9 },
  { id: 'ne', name: 'Neon', symbol: 'Ne', color: '#f43f5e', category: 'Noble Gas', atomicNumber: 10 },
  { id: 'na', name: 'Sodium', symbol: 'Na', color: '#10b981', category: 'Alkali Metal', atomicNumber: 11 },
  { id: 'mg', name: 'Magnesium', symbol: 'Mg', color: '#06b6d4', category: 'Alkaline Earth', atomicNumber: 12 },
  { id: 'al', name: 'Aluminum', symbol: 'Al', color: '#94a3b8', category: 'Post-transition Metal', atomicNumber: 13 },
  { id: 'si', name: 'Silicon', symbol: 'Si', color: '#78350f', category: 'Metalloid', atomicNumber: 14 },
  { id: 'p', name: 'Phosphorus', symbol: 'P', color: '#dc2626', category: 'Non-metal', atomicNumber: 15 },
  { id: 's', name: 'Sulfur', symbol: 'S', color: '#fbbf24', category: 'Non-metal', atomicNumber: 16 },
  { id: 'cl', name: 'Chlorine', symbol: 'Cl', color: '#a3e635', category: 'Halogen', atomicNumber: 17 },
  { id: 'ar', name: 'Argon', symbol: 'Ar', color: '#d946ef', category: 'Noble Gas', atomicNumber: 18 },
  { id: 'k', name: 'Potassium', symbol: 'K', color: '#059669', category: 'Alkali Metal', atomicNumber: 19 },
  { id: 'ca', name: 'Calcium', symbol: 'Ca', color: '#0d9488', category: 'Alkaline Earth', atomicNumber: 20 },
  { id: 'fe', name: 'Iron', symbol: 'Fe', color: '#b45309', category: 'Transition Metal', atomicNumber: 26 },
  { id: 'cu', name: 'Copper', symbol: 'Cu', color: '#ea580c', category: 'Transition Metal', atomicNumber: 29 },
  { id: 'zn', name: 'Zinc', symbol: 'Zn', color: '#4f46e5', category: 'Transition Metal', atomicNumber: 30 },
  { id: 'ag', name: 'Silver', symbol: 'Ag', color: '#cbd5e1', category: 'Transition Metal', atomicNumber: 47 },
  { id: 'au', name: 'Gold', symbol: 'Au', color: '#eab308', category: 'Transition Metal', atomicNumber: 79 },
];

export const VirtualLab: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [labType, setLabType] = useState<'classic' | 'nextgen'>('nextgen');
  const [activeTab, setActiveTab] = useState<'chemistry' | 'physics' | 'biology'>('chemistry');

  // --- Chemistry Sandbox State ---
  const [beakerContents, setBeakerContents] = useState<ElementNode[]>([]);
  const [reactionResult, setReactionResult] = useState<{
    compound: string;
    formula: string;
    type: string;
    description: string;
    energy: string;
  } | null>(null);
  const [reactionActive, setReactionActive] = useState(false);
  const [chemFilter, setChemFilter] = useState<'All' | 'Non-metals' | 'Metals' | 'Noble Gases & Halogens'>('All');

  // --- Physics Sandbox State ---
  const [gravity, setGravity] = useState<number>(9.81); // m/s^2
  const [velocity, setVelocity] = useState<number>(20); // m/s
  const [angle, setAngle] = useState<number>(45); // degrees
  const [mass, setMass] = useState<number>(5); // kg
  const [magField, setMagField] = useState<number>(0); // Tesla
  const [temperature, setTemperature] = useState<number>(298); // Kelvin
  const [isRunning, setIsRunning] = useState(false);
  const [showVectors, setShowVectors] = useState(true);
  const [trajectory, setTrajectory] = useState<{ x: number; y: number; vx: number; vy: number; t: number }[]>([]);
  const [activePhysicsSubTab, setActivePhysicsSubTab] = useState<'kinematics' | 'orbit' | 'thermo'>('kinematics');

  // --- Biology Anatomy State ---
  const [selectedBioModel, setSelectedBioModel] = useState<'cell' | 'heart' | 'chloroplast'>('cell');
  const [selectedOrganelle, setSelectedOrganelle] = useState<{
    name: string;
    function: string;
    detail: string;
  } | null>(null);
  const [heartRate, setHeartRate] = useState<'resting' | 'cardio' | 'sprint'>('resting');
  const [sunlight, setSunlight] = useState<number>(50); // %
  const [co2Level, setCo2Level] = useState<number>(50); // %

  // THREE.js refs for biology 3D visualizer
  const bioCanvasRef = useRef<HTMLDivElement>(null);
  const bioSceneRef = useRef<THREE.Scene | null>(null);
  const bioCameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const bioRendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const bioMeshRef = useRef<THREE.Group | null>(null);

  // THREE.js refs for chemistry molecular bond visualizer
  const chemCanvasRef = useRef<HTMLDivElement>(null);
  const chemSceneRef = useRef<THREE.Scene | null>(null);
  const chemCameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const chemRendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const chemMeshRef = useRef<THREE.Group | null>(null);

  // --- CHEMISTRY LOGIC ---
  const addElementToBeaker = (elem: ElementNode) => {
    if (beakerContents.length >= 6) return;
    setBeakerContents(prev => [...prev, elem]);
  };

  const clearBeaker = () => {
    setBeakerContents([]);
    setReactionResult(null);
    setReactionActive(false);
  };

  useEffect(() => {
    // Check reactions whenever beaker contents change
    if (beakerContents.length === 0) {
      setReactionResult(null);
      return;
    }

    const symbols = beakerContents.map(e => e.symbol);
    const count = (sym: string) => symbols.filter(s => s === sym).length;

    // Reaction definitions
    if (count('H') >= 2 && count('O') >= 1) {
      setReactionResult({
        compound: 'Water',
        formula: 'H₂O',
        type: 'Polar Covalent Bonding',
        energy: 'Exothermic (ΔH = -286 kJ/mol)',
        description: 'Two hydrogen atoms share electrons with one oxygen atom. Oxygen attracts electrons more strongly, creating a polar molecule with surface tension and high specific heat capacity.'
      });
    } else if (count('Na') >= 1 && count('Cl') >= 1) {
      setReactionResult({
        compound: 'Sodium Chloride (Table Salt)',
        formula: 'NaCl',
        type: 'Ionic Lattice Bonding',
        energy: 'Highly Exothermic (ΔH = -411 kJ/mol)',
        description: 'Sodium transfers its single valence electron to Chlorine. This creates a Na+ cation and Cl- anion which assemble into an incredibly strong 3D cubic crystalline lattice.'
      });
    } else if (count('C') >= 1 && count('O') >= 2) {
      setReactionResult({
        compound: 'Carbon Dioxide',
        formula: 'CO₂',
        type: 'Double Covalent Bonding',
        energy: 'Exothermic (ΔH = -393.5 kJ/mol)',
        description: 'Carbon forms stable double bonds with two oxygen atoms. This linear molecule is a key greenhouse gas produced during fuel combustion and aerobic cellular respiration.'
      });
    } else if (count('H') >= 1 && count('Cl') >= 1) {
      setReactionResult({
        compound: 'Hydrochloric Acid',
        formula: 'HCl',
        type: 'Strong Polar Covalent',
        energy: 'Exothermic (ΔH = -92.3 kJ/mol)',
        description: 'A highly corrosive, strong mineral acid that dissociates completely in water. It plays an essential role in digestive systems.'
      });
    } else if (count('H') >= 3 && count('N') >= 1) {
      setReactionResult({
        compound: 'Ammonia',
        formula: 'NH₃',
        type: 'Trigonal Pyramidal Covalent',
        energy: 'Exothermic (ΔH = -45.9 kJ/mol)',
        description: 'Ammonia is a stable binary hydride of nitrogen. The molecule has a trigonal pyramidal shape with a lone pair, making it alkaline and a vital building block in nitrogenous fertilizers.'
      });
    } else if (count('C') >= 1 && count('H') >= 4) {
      setReactionResult({
        compound: 'Methane',
        formula: 'CH₄',
        type: 'Symmetric Covalent Tetrahedral',
        energy: 'Exothermic (ΔH = -74.87 kJ/mol)',
        description: 'The simplest alkane and the primary component of natural gas. Carbon forms four symmetrical single covalent bonds with hydrogen atoms, aligning in a perfect tetrahedral geometry.'
      });
    } else if (count('C') >= 1 && count('O') === 1) {
      setReactionResult({
        compound: 'Carbon Monoxide',
        formula: 'CO',
        type: 'Triple Covalent Bond',
        energy: 'Exothermic (ΔH = -110.5 kJ/mol)',
        description: 'A toxic, colorless, and odorless gas. Carbon and oxygen share a very short and strong triple bond with a small dipole moment.'
      });
    } else if (count('H') >= 2 && count('S') >= 1 && count('O') >= 4) {
      setReactionResult({
        compound: 'Sulfuric Acid',
        formula: 'H₂SO₄',
        type: 'Diprotic Mineral Covalent',
        energy: 'Highly Exothermic (ΔH = -814 kJ/mol)',
        description: 'An extremely powerful, highly corrosive diprotic mineral acid. It dissociates in water in a highly exothermic reaction, widely used as an industrial chemical standard.'
      });
    } else if (count('Na') >= 1 && count('O') >= 1 && count('H') >= 1) {
      setReactionResult({
        compound: 'Sodium Hydroxide (Lye)',
        formula: 'NaOH',
        type: 'Ionic & Covalent Crystal',
        energy: 'Highly Exothermic (ΔH = -425 kJ/mol)',
        description: 'Also known as caustic soda or lye, this strong metallic base is highly soluble in water and dissociates completely into sodium cations and hydroxide anions.'
      });
    } else if (count('Fe') >= 2 && count('O') >= 3) {
      setReactionResult({
        compound: 'Iron(III) Oxide (Rust)',
        formula: 'Fe₂O₃',
        type: 'Ionic Metal Oxide Lattice',
        energy: 'Exothermic (ΔH = -824.2 kJ/mol)',
        description: 'Commonly known as rust, iron(III) oxide is a reddish-brown inorganic powder that forms naturally when iron metals oxidise in the presence of oxygen and moisture.'
      });
    } else if (count('Cu') >= 1 && count('Cl') >= 2) {
      setReactionResult({
        compound: 'Copper(II) Chloride',
        formula: 'CuCl₂',
        type: 'Ionic Halide Coordination',
        energy: 'Exothermic (ΔH = -220 kJ/mol)',
        description: 'An inorganic salt which exhibits a light brown color in anhydrous form, but becomes a striking blue-green dihydrate upon moisture absorption.'
      });
    } else if (count('Ca') >= 1 && count('C') >= 1 && count('O') >= 3) {
      setReactionResult({
        compound: 'Calcium Carbonate',
        formula: 'CaCO₃',
        type: 'Ionic-Covalent Salt Matrix',
        energy: 'Exothermic (ΔH = -1207 kJ/mol)',
        description: 'A major geological and biological building block, found in limestone, chalk, marble, and the shells of marine organisms and snails.'
      });
    } else if (count('Au') >= 1 && count('Cl') >= 3) {
      setReactionResult({
        compound: 'Gold(III) Chloride',
        formula: 'AuCl₃',
        type: 'Covalent Metal Dimer',
        energy: 'Exothermic (ΔH = -118 kJ/mol)',
        description: 'A highly hygroscopic compound of gold and chlorine. It represents one of the most common gold reagents in chemistry laboratories.'
      });
    } else if (count('K') >= 1 && count('Cl') >= 1) {
      setReactionResult({
        compound: 'Potassium Chloride',
        formula: 'KCl',
        type: 'Ionic Halide Salt',
        energy: 'Exothermic (ΔH = -436.7 kJ/mol)',
        description: 'A metal halide salt that looks identical to table salt but has a slightly bitter taste. Essential for cellular nerve conduction and fluid balance.'
      });
    } else if (count('He') >= 1 || count('Ne') >= 1 || count('Ar') >= 1) {
      setReactionResult({
        compound: 'Inert Gas Drift',
        formula: symbols.join(' + '),
        type: 'No Molecular Bonding',
        energy: 'Inert (ΔH = 0 kJ/mol)',
        description: 'Helium, Neon, and Argon are noble gases with fully completed valence electron shells. They have zero tendency to gain or lose electrons under standard laboratory conditions.'
      });
    } else {
      setReactionResult(null);
    }
  }, [beakerContents]);

  // Render Chemistry 3D molecular structures
  useEffect(() => {
    if (activeTab !== 'chemistry' || !chemCanvasRef.current) return;

    // Clean up previous renderer
    while (chemCanvasRef.current.firstChild) {
      chemCanvasRef.current.removeChild(chemCanvasRef.current.firstChild);
    }

    const width = chemCanvasRef.current.clientWidth || 300;
    const height = chemCanvasRef.current.clientHeight || 250;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(theme === 'dark' ? 0x0f172a : 0xf8fafc);
    chemSceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 100);
    camera.position.z = 6;
    chemCameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    chemCanvasRef.current.appendChild(renderer.domElement);
    chemRendererRef.current = renderer;

    const group = new THREE.Group();
    scene.add(group);
    chemMeshRef.current = group;

    // Add lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(5, 5, 5);
    scene.add(dirLight);

    // Build molecule based on current reaction result
    if (reactionResult) {
      const { formula } = reactionResult;

      if (formula === 'H₂O') {
        // Oxygen (Red sphere in center)
        const oGeom = new THREE.SphereGeometry(0.8, 32, 32);
        const oMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 80 });
        const oMesh = new THREE.Mesh(oGeom, oMat);
        group.add(oMesh);

        // Hydrogens (Blue spheres at angles)
        const hGeom = new THREE.SphereGeometry(0.4, 32, 32);
        const hMat = new THREE.MeshPhongMaterial({ color: 0x6366f1, shininess: 80 });

        const h1Mesh = new THREE.Mesh(hGeom, hMat);
        h1Mesh.position.set(-1.1, -0.6, 0);
        group.add(h1Mesh);

        const h2Mesh = new THREE.Mesh(hGeom, hMat);
        h2Mesh.position.set(1.1, -0.6, 0);
        group.add(h2Mesh);

        // Bonds (Cylinders)
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });
        
        const b1Geom = new THREE.CylinderGeometry(0.12, 0.12, 1.2, 16);
        const b1 = new THREE.Mesh(b1Geom, bondMat);
        b1.position.set(-0.55, -0.3, 0);
        b1.rotation.z = Math.PI / 3;
        group.add(b1);

        const b2Geom = new THREE.CylinderGeometry(0.12, 0.12, 1.2, 16);
        const b2 = new THREE.Mesh(b2Geom, bondMat);
        b2.position.set(0.55, -0.3, 0);
        b2.rotation.z = -Math.PI / 3;
        group.add(b2);

      } else if (formula === 'NaCl') {
        // Create an alternating lattice of green (Na+) and lime (Cl-)
        const naGeom = new THREE.SphereGeometry(0.5, 32, 32);
        const naMat = new THREE.MeshPhongMaterial({ color: 0x10b981, shininess: 100 });
        
        const clGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const clMat = new THREE.MeshPhongMaterial({ color: 0xa3e635, shininess: 100 });

        for (let x = -1; x <= 1; x += 2) {
          for (let y = -1; y <= 1; y += 2) {
            for (let z = -1; z <= 1; z += 2) {
              const isNa = (x + y + z) % 2 === 0;
              const mesh = new THREE.Mesh(isNa ? naGeom : clGeom, isNa ? naMat : clMat);
              mesh.position.set(x * 1.2, y * 1.2, z * 1.2);
              group.add(mesh);
            }
          }
        }
      } else if (formula === 'CO₂') {
        // Carbon in center (Dark Grey)
        const cGeom = new THREE.SphereGeometry(0.8, 32, 32);
        const cMat = new THREE.MeshPhongMaterial({ color: 0x4b5563, shininess: 80 });
        const cMesh = new THREE.Mesh(cGeom, cMat);
        group.add(cMesh);

        // Two Oxygens on left and right (Red)
        const oGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const oMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 80 });

        const o1Mesh = new THREE.Mesh(oGeom, oMat);
        o1Mesh.position.set(-1.6, 0, 0);
        group.add(o1Mesh);

        const o2Mesh = new THREE.Mesh(oGeom, oMat);
        o2Mesh.position.set(1.6, 0, 0);
        group.add(o2Mesh);

        // Double bonds
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });
        const doubleBond1 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 16), bondMat);
        doubleBond1.position.set(-0.8, 0.15, 0);
        doubleBond1.rotation.z = Math.PI / 2;
        group.add(doubleBond1);

        const doubleBond2 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 16), bondMat);
        doubleBond2.position.set(-0.8, -0.15, 0);
        doubleBond2.rotation.z = Math.PI / 2;
        group.add(doubleBond2);

        const doubleBond3 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 16), bondMat);
        doubleBond3.position.set(0.8, 0.15, 0);
        doubleBond3.rotation.z = Math.PI / 2;
        group.add(doubleBond3);

        const doubleBond4 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 16), bondMat);
        doubleBond4.position.set(0.8, -0.15, 0);
        doubleBond4.rotation.z = Math.PI / 2;
        group.add(doubleBond4);
      } else if (formula === 'HCl') {
        // Chlorine (Lime, large)
        const clGeom = new THREE.SphereGeometry(0.8, 32, 32);
        const clMat = new THREE.MeshPhongMaterial({ color: 0xa3e635, shininess: 80 });
        const clMesh = new THREE.Mesh(clGeom, clMat);
        clMesh.position.set(0.6, 0, 0);
        group.add(clMesh);

        // Hydrogen (Blue, small)
        const hGeom = new THREE.SphereGeometry(0.4, 32, 32);
        const hMat = new THREE.MeshPhongMaterial({ color: 0x6366f1, shininess: 80 });
        const hMesh = new THREE.Mesh(hGeom, hMat);
        hMesh.position.set(-0.9, 0, 0);
        group.add(hMesh);

        // Single covalent bond
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });
        const b = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 1.3, 16), bondMat);
        b.position.set(-0.15, 0, 0);
        b.rotation.z = Math.PI / 2;
        group.add(b);
      } else if (formula === 'NH₃') {
        // Nitrogen (Purple, center)
        const nGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const nMat = new THREE.MeshPhongMaterial({ color: 0x8b5cf6, shininess: 80 });
        const nMesh = new THREE.Mesh(nGeom, nMat);
        group.add(nMesh);

        // Three Hydrogens (Blue)
        const hGeom = new THREE.SphereGeometry(0.35, 32, 32);
        const hMat = new THREE.MeshPhongMaterial({ color: 0x6366f1, shininess: 80 });
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });

        const hPositions = [
          new THREE.Vector3(0.9, -0.5, 0.5),
          new THREE.Vector3(-0.9, -0.5, 0.5),
          new THREE.Vector3(0, -0.5, -1.0)
        ];

        hPositions.forEach(pos => {
          const hMesh = new THREE.Mesh(hGeom, hMat);
          hMesh.position.copy(pos);
          group.add(hMesh);

          const direction = pos.clone().normalize();
          const bondGeom = new THREE.CylinderGeometry(0.08, 0.08, pos.length(), 16);
          const bond = new THREE.Mesh(bondGeom, bondMat);
          bond.position.copy(pos).multiplyScalar(0.5);
          bond.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction);
          group.add(bond);
        });
      } else if (formula === 'CH₄') {
        // Carbon (Grey, center)
        const cGeom = new THREE.SphereGeometry(0.75, 32, 32);
        const cMat = new THREE.MeshPhongMaterial({ color: 0x4b5563, shininess: 80 });
        const cMesh = new THREE.Mesh(cGeom, cMat);
        group.add(cMesh);

        // Four Hydrogens (Blue) in tetrahedral symmetry
        const hGeom = new THREE.SphereGeometry(0.35, 32, 32);
        const hMat = new THREE.MeshPhongMaterial({ color: 0x6366f1, shininess: 80 });
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });

        const hPositions = [
          new THREE.Vector3(0.8, 0.8, 0.8),
          new THREE.Vector3(-0.8, -0.8, 0.8),
          new THREE.Vector3(-0.8, 0.8, -0.8),
          new THREE.Vector3(0.8, -0.8, -0.8)
        ];

        hPositions.forEach(pos => {
          const hMesh = new THREE.Mesh(hGeom, hMat);
          hMesh.position.copy(pos);
          group.add(hMesh);

          const direction = pos.clone().normalize();
          const bondGeom = new THREE.CylinderGeometry(0.08, 0.08, pos.length(), 16);
          const bond = new THREE.Mesh(bondGeom, bondMat);
          bond.position.copy(pos).multiplyScalar(0.5);
          bond.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction);
          group.add(bond);
        });
      } else if (formula === 'CO') {
        // Carbon (Grey)
        const cGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const cMat = new THREE.MeshPhongMaterial({ color: 0x4b5563, shininess: 80 });
        const cMesh = new THREE.Mesh(cGeom, cMat);
        cMesh.position.set(-0.8, 0, 0);
        group.add(cMesh);

        // Oxygen (Red)
        const oGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const oMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 80 });
        const oMesh = new THREE.Mesh(oGeom, oMat);
        oMesh.position.set(0.8, 0, 0);
        group.add(oMesh);

        // Triple Bond Representation
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });
        const offsets = [-0.15, 0, 0.15];
        offsets.forEach(offset => {
          const bond = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.4, 16), bondMat);
          bond.position.set(0, offset, 0);
          bond.rotation.z = Math.PI / 2;
          group.add(bond);
        });
      } else if (formula === 'NO₂') {
        // Nitrogen (Purple, center)
        const nGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const nMat = new THREE.MeshPhongMaterial({ color: 0x8b5cf6, shininess: 80 });
        const nMesh = new THREE.Mesh(nGeom, nMat);
        group.add(nMesh);

        // Two Oxygens (Red)
        const oGeom = new THREE.SphereGeometry(0.65, 32, 32);
        const oMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 80 });
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });

        const oPositions = [
          new THREE.Vector3(1.2, 0.6, 0),
          new THREE.Vector3(-1.2, 0.6, 0)
        ];

        oPositions.forEach((pos) => {
          const oMesh = new THREE.Mesh(oGeom, oMat);
          oMesh.position.copy(pos);
          group.add(oMesh);

          // Double bond representation
          for (let s = -1; s <= 1; s += 2) {
            const bond = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.3, 16), bondMat);
            const midPoint = pos.clone().multiplyScalar(0.5);
            const perp = new THREE.Vector3(-pos.y, pos.x, 0).normalize().multiplyScalar(s * 0.1);
            bond.position.copy(midPoint).add(perp);
            bond.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), pos.clone().normalize());
            group.add(bond);
          }
        });
      } else if (formula === 'H₂SO₄') {
        // Sulfur (Yellow, center)
        const sGeom = new THREE.SphereGeometry(0.8, 32, 32);
        const sMat = new THREE.MeshPhongMaterial({ color: 0xfbbf24, shininess: 80 });
        const sMesh = new THREE.Mesh(sGeom, sMat);
        group.add(sMesh);

        // 4 Oxygens (Red) and 2 Hydrogens (Blue)
        const oGeom = new THREE.SphereGeometry(0.5, 32, 32);
        const oMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 80 });
        const hGeom = new THREE.SphereGeometry(0.3, 32, 32);
        const hMat = new THREE.MeshPhongMaterial({ color: 0x6366f1, shininess: 80 });
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });

        const oPositions = [
          new THREE.Vector3(0, 1.2, 0),
          new THREE.Vector3(0, -1.2, 0),
          new THREE.Vector3(1.2, 0, 0.5),
          new THREE.Vector3(-1.2, 0, -0.5)
        ];

        oPositions.forEach((pos, idx) => {
          const oMesh = new THREE.Mesh(oGeom, oMat);
          oMesh.position.copy(pos);
          group.add(oMesh);

          // Sulfur-Oxygen bond
          const b = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.1, 16), bondMat);
          b.position.copy(pos).multiplyScalar(0.5);
          b.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), pos.clone().normalize());
          group.add(b);

          if (idx < 2) {
            const hPos = pos.clone().add(new THREE.Vector3(idx === 0 ? 0.7 : -0.7, idx === 0 ? 0.4 : -0.4, 0.4));
            const hMesh = new THREE.Mesh(hGeom, hMat);
            hMesh.position.copy(hPos);
            group.add(hMesh);

            const subBondVec = hPos.clone().sub(pos);
            const bSub = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, subBondVec.length(), 16), bondMat);
            bSub.position.copy(pos).add(subBondVec.clone().multiplyScalar(0.5));
            bSub.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), subBondVec.clone().normalize());
            group.add(bSub);
          }
        });
      } else if (formula === 'NaOH') {
        // Oxygen (Red, center)
        const oGeom = new THREE.SphereGeometry(0.65, 32, 32);
        const oMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 80 });
        const oMesh = new THREE.Mesh(oGeom, oMat);
        group.add(oMesh);

        // Sodium (Green)
        const naGeom = new THREE.SphereGeometry(0.75, 32, 32);
        const naMat = new THREE.MeshPhongMaterial({ color: 0x10b981, shininess: 80 });
        const naMesh = new THREE.Mesh(naGeom, naMat);
        naMesh.position.set(-1.1, 0, 0);
        group.add(naMesh);

        // Hydrogen (Blue)
        const hGeom = new THREE.SphereGeometry(0.35, 32, 32);
        const hMat = new THREE.MeshPhongMaterial({ color: 0x6366f1, shininess: 80 });
        const hMesh = new THREE.Mesh(hGeom, hMat);
        hMesh.position.set(1.0, 0.4, 0);
        group.add(hMesh);

        // Bonds
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });
        const b1 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.1, 16), bondMat);
        b1.position.set(-0.55, 0, 0);
        b1.rotation.z = Math.PI / 2;
        group.add(b1);

        const b2Vec = new THREE.Vector3(1.0, 0.4, 0);
        const b2 = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, b2Vec.length(), 16), bondMat);
        b2.position.copy(b2Vec).multiplyScalar(0.5);
        b2.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b2Vec.clone().normalize());
        group.add(b2);
      } else if (formula === 'Fe₂O₃') {
        // Iron (Brown/Orange) and Oxygen (Red) rust lattice
        const feGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const feMat = new THREE.MeshPhongMaterial({ color: 0xb45309, shininess: 80 });
        const oGeom = new THREE.SphereGeometry(0.5, 32, 32);
        const oMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 80 });
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xdddddd });

        const positions = [
          { pos: new THREE.Vector3(-1.0, 0.5, 0), isFe: true },
          { pos: new THREE.Vector3(1.0, 0.5, 0), isFe: true },
          { pos: new THREE.Vector3(0, -0.5, 0.5), isFe: false },
          { pos: new THREE.Vector3(-1.0, -0.8, -0.5), isFe: false },
          { pos: new THREE.Vector3(1.0, -0.8, -0.5), isFe: false }
        ];

        positions.forEach(item => {
          const mesh = new THREE.Mesh(item.isFe ? feGeom : oGeom, item.isFe ? feMat : oMat);
          mesh.position.copy(item.pos);
          group.add(mesh);
        });

        const b1 = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.8, 16), bondMat);
        b1.position.set(-0.5, 0, 0.25);
        b1.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(1, -1, 0.5).normalize());
        group.add(b1);

        const b2 = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.8, 16), bondMat);
        b2.position.set(0.5, 0, 0.25);
        b2.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(-1, -1, 0.5).normalize());
        group.add(b2);
      } else if (formula === 'CuCl₂') {
        // Copper (Orange, center)
        const cuGeom = new THREE.SphereGeometry(0.75, 32, 32);
        const cuMat = new THREE.MeshPhongMaterial({ color: 0xea580c, shininess: 80 });
        const cuMesh = new THREE.Mesh(cuGeom, cuMat);
        group.add(cuMesh);

        // Two Chlorines (Lime, large)
        const clGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const clMat = new THREE.MeshPhongMaterial({ color: 0xa3e635, shininess: 80 });
        const cl1 = new THREE.Mesh(clGeom, clMat);
        cl1.position.set(-1.4, 0, 0);
        group.add(cl1);

        const cl2 = new THREE.Mesh(clGeom, clMat);
        cl2.position.set(1.4, 0, 0);
        group.add(cl2);

        // Ionic bonds
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });
        const b1 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 16), bondMat);
        b1.position.set(-0.7, 0, 0);
        b1.rotation.z = Math.PI / 2;
        group.add(b1);

        const b2 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 16), bondMat);
        b2.position.set(0.7, 0, 0);
        b2.rotation.z = Math.PI / 2;
        group.add(b2);
      } else if (formula === 'CaCO₃') {
        // Calcium in center (Teal, large)
        const caGeom = new THREE.SphereGeometry(0.8, 32, 32);
        const caMat = new THREE.MeshPhongMaterial({ color: 0x0d9488, shininess: 80 });
        const caMesh = new THREE.Mesh(caGeom, caMat);
        group.add(caMesh);

        // Carbonate group
        const cGeom = new THREE.SphereGeometry(0.55, 32, 32);
        const cMat = new THREE.MeshPhongMaterial({ color: 0x4b5563, shininess: 80 });
        const cMesh = new THREE.Mesh(cGeom, cMat);
        cMesh.position.set(0, -1.2, 0);
        group.add(cMesh);

        const oGeom = new THREE.SphereGeometry(0.45, 32, 32);
        const oMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 80 });
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });

        const oAngles = [0, (Math.PI * 2) / 3, (Math.PI * 4) / 3];
        oAngles.forEach(angle => {
          const oMesh = new THREE.Mesh(oGeom, oMat);
          const oPos = new THREE.Vector3(Math.cos(angle) * 0.9, -1.2 + Math.sin(angle) * 0.9, 0);
          oMesh.position.copy(oPos);
          group.add(oMesh);

          const subVec = oPos.clone().sub(cMesh.position);
          const b = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, subVec.length(), 16), bondMat);
          b.position.copy(cMesh.position).add(subVec.clone().multiplyScalar(0.5));
          b.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), subVec.clone().normalize());
          group.add(b);
        });

        const ionBond = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.2, 16), bondMat);
        ionBond.position.set(0, -0.6, 0);
        group.add(ionBond);
      } else if (formula === 'AuCl₃') {
        // Gold (Yellow, center)
        const auGeom = new THREE.SphereGeometry(0.8, 32, 32);
        const auMat = new THREE.MeshPhongMaterial({ color: 0xeab308, shininess: 100 });
        const auMesh = new THREE.Mesh(auGeom, auMat);
        group.add(auMesh);

        // Three Chlorines (Lime)
        const clGeom = new THREE.SphereGeometry(0.6, 32, 32);
        const clMat = new THREE.MeshPhongMaterial({ color: 0xa3e635, shininess: 80 });
        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });

        const clAngles = [0, (Math.PI * 2) / 3, (Math.PI * 4) / 3];
        clAngles.forEach(angle => {
          const clMesh = new THREE.Mesh(clGeom, clMat);
          const clPos = new THREE.Vector3(Math.cos(angle) * 1.3, Math.sin(angle) * 1.3, 0);
          clMesh.position.copy(clPos);
          group.add(clMesh);

          const b = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.3, 16), bondMat);
          b.position.copy(clPos).multiplyScalar(0.5);
          b.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), clPos.clone().normalize());
          group.add(b);
        });
      } else if (formula === 'KCl') {
        // Potassium (Dark Green, large)
        const kGeom = new THREE.SphereGeometry(0.75, 32, 32);
        const kMat = new THREE.MeshPhongMaterial({ color: 0x059669, shininess: 80 });
        const kMesh = new THREE.Mesh(kGeom, kMat);
        kMesh.position.set(-0.7, 0, 0);
        group.add(kMesh);

        // Chlorine (Lime, large)
        const clGeom = new THREE.SphereGeometry(0.7, 32, 32);
        const clMat = new THREE.MeshPhongMaterial({ color: 0xa3e635, shininess: 80 });
        const clMesh = new THREE.Mesh(clGeom, clMat);
        clMesh.position.set(0.7, 0, 0);
        group.add(clMesh);

        const bondMat = new THREE.MeshPhongMaterial({ color: 0xcccccc });
        const b = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 16), bondMat);
        b.position.set(0, 0, 0);
        b.rotation.z = Math.PI / 2;
        group.add(b);
      } else {
        // Float inert noble gas atoms
        beakerContents.forEach((elem, index) => {
          const geom = new THREE.SphereGeometry(0.5, 24, 24);
          const mat = new THREE.MeshPhongMaterial({ color: elem.color, shininess: 80 });
          const mesh = new THREE.Mesh(geom, mat);
          const angleVal = (index / beakerContents.length) * Math.PI * 2;
          const radiusVal = 1.6 + (index % 2 === 0 ? 0.3 : -0.3);
          mesh.position.set(Math.cos(angleVal) * radiusVal, Math.sin(angleVal) * radiusVal, (index % 3 - 1) * 0.4);
          group.add(mesh);
        });
      }
    } else {
      // Just floating atomic mix based on Beaker contents
      beakerContents.forEach((elem, index) => {
        const geom = new THREE.SphereGeometry(0.5, 24, 24);
        const mat = new THREE.MeshPhongMaterial({ color: elem.color, shininess: 80 });
        const mesh = new THREE.Mesh(geom, mat);
        
        // Arrange atoms in a circle
        const angleVal = (index / beakerContents.length) * Math.PI * 2;
        mesh.position.set(Math.cos(angleVal) * 1.8, Math.sin(angleVal) * 1.8, 0);
        group.add(mesh);
      });
    }

    let frameId: number;
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      if (group) {
        group.rotation.y += 0.015;
        group.rotation.x += 0.005;
      }
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!chemCanvasRef.current || !renderer || !camera) return;
      const w = chemCanvasRef.current.clientWidth;
      const h = chemCanvasRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [activeTab, beakerContents, reactionResult, theme]);

  // --- PHYSICS ENGINE LOGIC ---
  useEffect(() => {
    if (activeTab !== 'physics' || !isRunning) return;

    let time = 0;
    const interval = setInterval(() => {
      time += 0.08;
      
      if (activePhysicsSubTab === 'kinematics') {
        const angleRad = (angle * Math.PI) / 180;
        const gEff = gravity;
        
        // Basic kinematic projectile equations with electromagnetic lorentz force adjustment
        const vx0 = velocity * Math.cos(angleRad);
        const vy0 = velocity * Math.sin(angleRad);
        
        // Apply secondary electromagnetic acceleration if magnetic field is on
        const magneticForceX = -magField * 0.5 * vx0; 
        
        const x = vx0 * time + 0.5 * magneticForceX * time * time;
        const y = vy0 * time - 0.5 * gEff * time * time;

        const vx = vx0 + magneticForceX * time;
        const vy = vy0 - gEff * time;

        if (y < 0 && time > 0.5) {
          setIsRunning(false);
          clearInterval(interval);
        } else {
          setTrajectory(prev => [...prev, { x, y: Math.max(0, y), vx, vy, t: time }]);
        }
      } else if (activePhysicsSubTab === 'orbit') {
        // Gravitational orbital integration (Euler-Cromer)
        setTrajectory(prev => {
          const last = prev[prev.length - 1] || { x: 3, y: 0, vx: 0, vy: Math.sqrt(gravity * 3), t: 0 };
          const r2 = last.x * last.x + last.y * last.y;
          const r = Math.sqrt(r2);
          
          if (r < 0.4 || r > 12) {
            setIsRunning(false);
            clearInterval(interval);
            return prev;
          }

          // Orbital gravity equation
          const ax = -(gravity * 1.5 * last.x) / (r2 * r);
          const ay = -(gravity * 1.5 * last.y) / (r2 * r);

          const vx = last.vx + ax * 0.1;
          const vy = last.vy + ay * 0.1;
          const x = last.x + vx * 0.1;
          const y = last.y + vy * 0.1;

          return [...prev, { x, y, vx, vy, t: last.t + 0.1 }];
        });
      } else if (activePhysicsSubTab === 'thermo') {
        // Kinetic gas particles simulation bounds
        setTrajectory(prev => {
          const count = 15;
          const items = [];
          for (let i = 0; i < count; i++) {
            // Maxwell-Boltzmann distribution speed scale
            const speedScale = Math.sqrt(temperature / 100);
            const particleAngle = Math.random() * Math.PI * 2;
            items.push({
              x: Math.cos(particleAngle) * speedScale * 2,
              y: Math.sin(particleAngle) * speedScale * 2,
              vx: Math.cos(particleAngle) * speedScale,
              vy: Math.sin(particleAngle) * speedScale,
              t: time
            });
          }
          return items;
        });
      }
    }, 50);

    return () => clearInterval(interval);
  }, [isRunning, activePhysicsSubTab, gravity, velocity, angle, magField, temperature]);

  const startPhysicsSimulation = () => {
    setIsRunning(true);
    setTrajectory([]);
  };

  const resetPhysicsSimulation = () => {
    setIsRunning(false);
    setTrajectory([]);
  };


  // --- BIOLOGY LOGIC & THREE.js VISUALIZATION ---
  useEffect(() => {
    if (activeTab !== 'biology' || !bioCanvasRef.current) return;

    // Clean up previous renderer
    while (bioCanvasRef.current.firstChild) {
      bioCanvasRef.current.removeChild(bioCanvasRef.current.firstChild);
    }

    const width = bioCanvasRef.current.clientWidth || 300;
    const height = bioCanvasRef.current.clientHeight || 300;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(theme === 'dark' ? 0x0f172a : 0xf8fafc);
    bioSceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 100);
    camera.position.z = 5;
    bioCameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    bioCanvasRef.current.appendChild(renderer.domElement);
    bioRendererRef.current = renderer;

    const group = new THREE.Group();
    scene.add(group);
    bioMeshRef.current = group;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight1.position.set(5, 5, 5);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xffffff, 0.3);
    dirLight2.position.set(-5, -5, 5);
    scene.add(dirLight2);

    // Build model based on selected model
    if (selectedBioModel === 'cell') {
      // Cell Membrane (Translucent Sphere cut in half or complete)
      const memGeom = new THREE.SphereGeometry(1.8, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.7);
      const memMat = new THREE.MeshPhongMaterial({ 
        color: 0x38bdf8, 
        transparent: true, 
        opacity: 0.4, 
        side: THREE.DoubleSide 
      });
      const membrane = new THREE.Mesh(memGeom, memMat);
      membrane.rotation.x = Math.PI / 2;
      group.add(membrane);

      // Nucleus (Large Purple sphere in center)
      const nucGeom = new THREE.SphereGeometry(0.6, 32, 32);
      const nucMat = new THREE.MeshPhongMaterial({ color: 0xa855f7, shininess: 80 });
      const nucleus = new THREE.Mesh(nucGeom, nucMat);
      nucleus.position.set(0, 0, 0);
      group.add(nucleus);

      // Mitochondria (Orange oval cylinders)
      const mitoGeom = new THREE.CylinderGeometry(0.2, 0.2, 0.6, 16);
      const mitoMat = new THREE.MeshPhongMaterial({ color: 0xf97316, shininess: 80 });
      
      const mito1 = new THREE.Mesh(mitoGeom, mitoMat);
      mito1.position.set(-1, 0.5, 0);
      mito1.rotation.z = Math.PI / 4;
      group.add(mito1);

      const mito2 = new THREE.Mesh(mitoGeom, mitoMat);
      mito2.position.set(1, -0.6, 0);
      mito2.rotation.z = -Math.PI / 3;
      group.add(mito2);

      // Endoplasmic Reticulum (Curved blue bands)
      const erGeom = new THREE.TorusGeometry(0.9, 0.08, 16, 100, Math.PI * 1.2);
      const erMat = new THREE.MeshPhongMaterial({ color: 0x3b82f6 });
      const er = new THREE.Mesh(erGeom, erMat);
      er.rotation.x = Math.PI / 2;
      group.add(er);

    } else if (selectedBioModel === 'heart') {
      // Create a conceptual anatomical heart model using two intersecting spheres & cylinders
      const bodyGeom = new THREE.SphereGeometry(1.1, 32, 32);
      const bodyMat = new THREE.MeshPhongMaterial({ color: 0xef4444, shininess: 70 });
      const body = new THREE.Mesh(bodyGeom, bodyMat);
      body.scale.set(1, 1.4, 0.9);
      group.add(body);

      // Left Ventricle bulging
      const lVGeom = new THREE.SphereGeometry(0.8, 32, 32);
      const lVMat = new THREE.MeshPhongMaterial({ color: 0xd97706 });
      const lV = new THREE.Mesh(lVGeom, lVMat);
      lV.position.set(-0.3, -0.4, 0.2);
      group.add(lV);

      // Aorta (Blue/Red tubes emerging from top)
      const aortaGeom = new THREE.CylinderGeometry(0.25, 0.25, 1.2, 16);
      const aortaMat = new THREE.MeshPhongMaterial({ color: 0x2563eb });
      const aorta = new THREE.Mesh(aortaGeom, aortaMat);
      aorta.position.set(0.2, 1.1, 0);
      aorta.rotation.z = -0.3;
      group.add(aorta);

      const pulmonaryGeom = new THREE.CylinderGeometry(0.2, 0.2, 1.0, 16);
      const pulmonaryMat = new THREE.MeshPhongMaterial({ color: 0xdc2626 });
      const pul = new THREE.Mesh(pulmonaryGeom, pulmonaryMat);
      pul.position.set(-0.25, 1.0, 0.1);
      pul.rotation.z = 0.2;
      group.add(pul);

    } else if (selectedBioModel === 'chloroplast') {
      // Outer chloroplast envelope (Lime translucent pod)
      const podGeom = new THREE.SphereGeometry(1.6, 32, 16);
      const podMat = new THREE.MeshPhongMaterial({ 
        color: 0x22c55e, 
        transparent: true, 
        opacity: 0.35, 
        side: THREE.DoubleSide 
      });
      const pod = new THREE.Mesh(podGeom, podMat);
      pod.scale.set(1.5, 0.9, 0.9);
      group.add(pod);

      // Thylakoid Stacks (Stacked flat green cylinders - Grana)
      const thyGeom = new THREE.CylinderGeometry(0.35, 0.35, 0.12, 16);
      const thyMat = new THREE.MeshPhongMaterial({ color: 0x15803d, shininess: 60 });

      // Build 3 stacks of Grana
      for (let stackNum = -1; stackNum <= 1; stackNum++) {
        for (let j = 0; j < 4; j++) {
          const thy = new THREE.Mesh(thyGeom, thyMat);
          thy.position.set(stackNum * 0.9, -0.3 + j * 0.18, 0);
          group.add(thy);
        }
      }
    }

    let frameId: number;
    let pulseTime = 0;
    
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      
      if (group) {
        group.rotation.y += 0.01;
        
        if (selectedBioModel === 'heart') {
          // Pulse the heart scale depending on heartRate
          pulseTime += heartRate === 'sprint' ? 0.2 : heartRate === 'cardio' ? 0.12 : 0.06;
          const scaleMod = 1.0 + Math.sin(pulseTime) * 0.08;
          group.scale.set(scaleMod, scaleMod * 1.05, scaleMod);
        } else {
          group.scale.set(1, 1, 1);
        }
      }
      
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!bioCanvasRef.current || !renderer || !camera) return;
      const w = bioCanvasRef.current.clientWidth;
      const h = bioCanvasRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [activeTab, selectedBioModel, heartRate, theme]);

  const selectOrganelleInfo = (name: string) => {
    const data: Record<string, { function: string; detail: string }> = {
      'Nucleus': {
        function: 'Genetic Blueprint Custodian',
        detail: 'Contains the cell\'s chromosomal DNA. Directs all metabolic functions and protein synthesis processes by transcribing RNA blueprints.'
      },
      'Mitochondria': {
        function: 'Powerhouse / Cellular Respiration',
        detail: 'Converts chemical energy from nutrients into Adenosine Triphosphate (ATP) via the Krebs cycle and oxidative phosphorylation pathway.'
      },
      'Ribosome': {
        function: 'Protein Synthesizer',
        detail: 'Translates Messenger RNA (mRNA) genetic codes into polypeptide chains to synthesize structural proteins and functional enzymes.'
      },
      'Golgi Apparatus': {
        function: 'Sorting & Packaging Center',
        detail: 'Modifies, sorts, and packages macromolecules like proteins and lipids into secretory vesicles for transport outside or around the cell.'
      },
      'Thylakoid': {
        function: 'Light-Dependent reactions',
        detail: 'Site of light absorption and energy conversion into chemical intermediate molecules (ATP & NADPH), splitting H2O to release oxygen.'
      },
      'Stroma': {
        function: 'Calvin Cycle Carbon Fixation',
        detail: 'The fluid-filled space surrounding thylakoids. Houses Ribulose-1,5-bisphosphate carboxylase-oxygenase (RuBisCO) to synthesize sugars.'
      }
    };

    if (data[name]) {
      setSelectedOrganelle({
        name,
        function: data[name].function,
        detail: data[name].detail
      });
    }
  };

  return (
    <div id="virtual-lab-container" className="flex flex-col h-full overflow-y-auto pr-1">
      {/* Lab Type Toggle Tabs */}
      <div className="flex border-b border-slate-800 mb-6 p-1 gap-2 bg-slate-950 rounded-xl max-w-md mx-auto w-full shrink-0">
        <button
          onClick={() => setLabType('nextgen')}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
            labType === 'nextgen'
              ? 'bg-gradient-to-r from-sky-500 to-indigo-500 text-white shadow-lg'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          ✨ Next-Gen Virtual Labs
        </button>
        <button
          onClick={() => setLabType('classic')}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
            labType === 'classic'
              ? 'bg-indigo-600 text-white shadow-lg'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          🧪 Classic 3D Sandbox
        </button>
      </div>

      {labType === 'nextgen' ? (
        <NextGenStemSimulationsHub theme={theme} />
      ) : (
        <>
          {/* Tab Navigation */}
          <div id="lab-tab-nav" className="flex border-b border-slate-200 dark:border-slate-800 mb-4 p-1 gap-1">
        <button
          id="tab-btn-chemistry"
          onClick={() => setActiveTab('chemistry')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'chemistry'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Beaker size={15} />
          Chemistry Sandbox
        </button>
        <button
          id="tab-btn-physics"
          onClick={() => setActiveTab('physics')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'physics'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Orbit size={15} />
          Physics Engine Sandbox
        </button>
        <button
          id="tab-btn-biology"
          onClick={() => setActiveTab('biology')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'biology'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Dna size={15} />
          3D Biology Anatomy
        </button>
      </div>

      {/* Chemistry Sandbox View */}
      {activeTab === 'chemistry' && (
        <div id="chem-sandbox-view" className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in fade-in duration-300">
          {/* Elements Selector */}
          <div id="chem-elements-sidebar" className="lg:col-span-4 flex flex-col gap-3">
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                <Atom size={14} className="text-indigo-500" />
                Available Elements
              </h4>

              {/* Category Filter Tabs */}
              <div id="chem-filter-tabs" className="flex flex-wrap gap-1 mb-3">
                {(['All', 'Non-metals', 'Metals', 'Noble Gases & Halogens'] as const).map(cat => (
                  <button
                    id={`chem-tab-filter-${cat.replace(/\s+/g, '-').toLowerCase()}`}
                    key={cat}
                    onClick={() => setChemFilter(cat)}
                    className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider cursor-pointer border transition-all ${
                      chemFilter === cat
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-white dark:bg-slate-850 text-slate-500 border-slate-200 dark:border-slate-800 hover:text-slate-850 dark:hover:text-slate-200'
                    }`}
                  >
                    {cat === 'Noble Gases & Halogens' ? 'Noble/Halogen' : cat}
                  </button>
                ))}
              </div>

              <div id="elements-list-grid" className="grid grid-cols-2 gap-2 max-h-[280px] overflow-y-auto pr-1">
                {AVAILABLE_ELEMENTS.filter(elem => {
                  if (chemFilter === 'All') return true;
                  if (chemFilter === 'Non-metals') {
                    return elem.category === 'Non-metal' || elem.category === 'Metalloid';
                  }
                  if (chemFilter === 'Metals') {
                    return elem.category.includes('Metal') || elem.category.includes('Alkaline') || elem.category.includes('Alkali');
                  }
                  if (chemFilter === 'Noble Gases & Halogens') {
                    return elem.category === 'Noble Gas' || elem.category === 'Halogen';
                  }
                  return true;
                }).map(elem => (
                  <button
                    id={`elem-add-${elem.id}`}
                    key={elem.id}
                    onClick={() => addElementToBeaker(elem)}
                    className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-left hover:border-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-850 transition-all flex items-center gap-2 cursor-pointer group"
                  >
                    <span 
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-white font-black text-xs group-hover:scale-105 transition-transform shrink-0"
                      style={{ backgroundColor: elem.color }}
                    >
                      {elem.symbol}
                    </span>
                    <div className="min-w-0 overflow-hidden">
                      <div className="text-[10px] font-bold dark:text-slate-200 truncate">{elem.name}</div>
                      <div className="text-[8px] text-slate-400 truncate">{elem.category}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex-1 min-h-[160px]">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">Beaker Mix</h4>
                {beakerContents.length > 0 && (
                  <button
                    id="btn-clear-beaker"
                    onClick={clearBeaker}
                    className="text-[10px] text-red-500 font-extrabold flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    <RotateCcw size={10} /> Clear
                  </button>
                )}
              </div>

              {beakerContents.length === 0 ? (
                <div id="empty-beaker-placeholder" className="h-[120px] flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-4">
                  <Beaker size={24} className="mb-1.5 animate-pulse text-indigo-500" />
                  <span className="text-[10px] font-medium text-center">Add elements above to simulate molecular bonding reactions!</span>
                </div>
              ) : (
                <div id="beaker-active-atoms" className="flex flex-wrap gap-1.5 max-h-[140px] overflow-y-auto">
                  {beakerContents.map((elem, idx) => (
                    <span
                      id={`beaker-elem-${idx}`}
                      key={idx}
                      className="px-2.5 py-1.5 rounded-lg text-[10px] font-black text-white flex items-center gap-1.5 shadow"
                      style={{ backgroundColor: elem.color }}
                    >
                      {elem.symbol}
                      <span className="opacity-50 text-[8px] font-normal">#{elem.atomicNumber}</span>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* 3D Structure and Reaction Chamber */}
          <div id="reaction-chamber-area" className="lg:col-span-8 flex flex-col gap-3">
            <div className="bg-slate-100 dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-800 relative overflow-hidden flex flex-col min-h-[300px]">
              <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full bg-slate-900/80 text-white text-[10px] font-black tracking-widest flex items-center gap-1">
                  <Flame size={12} className={reactionResult ? "text-amber-400 animate-bounce" : "text-slate-400"} />
                  REACTION CHAMBER
                </span>
                {reactionResult && (
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-500 border border-emerald-500/20 text-[10px] font-black tracking-widest">
                    {reactionResult.compound}
                  </span>
                )}
              </div>

              <div id="chem-structure-canvas" ref={chemCanvasRef} className="w-full flex-1 min-h-[250px]" />

              {reactionResult && (
                <div id="reaction-result-info" className="p-4 bg-indigo-600 text-white border-t border-indigo-700/50">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-black flex items-center gap-1">
                      {reactionResult.compound} ({reactionResult.formula})
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500 text-indigo-100 font-extrabold uppercase">
                      {reactionResult.type}
                    </span>
                  </div>
                  <div className="text-[10px] text-indigo-200 mb-1 font-bold italic">
                    Enthalpy: {reactionResult.energy}
                  </div>
                  <p className="text-[11px] text-indigo-50 leading-relaxed">
                    {reactionResult.description}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Physics Engine Sandbox View */}
      {activeTab === 'physics' && (
        <div id="physics-sandbox-view" className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in fade-in duration-300">
          {/* Sub Tab selection */}
          <div className="lg:col-span-12 flex bg-slate-50 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 gap-1">
            <button
              onClick={() => { setActivePhysicsSubTab('kinematics'); resetPhysicsSimulation(); }}
              className={`flex-1 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                activePhysicsSubTab === 'kinematics' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-indigo-500'
              }`}
            >
              Kinematics Projectile
            </button>
            <button
              onClick={() => { setActivePhysicsSubTab('orbit'); resetPhysicsSimulation(); }}
              className={`flex-1 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                activePhysicsSubTab === 'orbit' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-indigo-500'
              }`}
            >
              Orbital Gravity
            </button>
            <button
              onClick={() => { setActivePhysicsSubTab('thermo'); resetPhysicsSimulation(); }}
              className={`flex-1 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                activePhysicsSubTab === 'thermo' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-indigo-500'
              }`}
            >
              Thermodynamic Gas Sandbox
            </button>
          </div>

          {/* Physics Parameters Panel */}
          <div id="physics-parameters" className="lg:col-span-4 flex flex-col gap-3">
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                <Activity size={14} className="text-indigo-500" />
                Control Panel
              </h4>

              {activePhysicsSubTab === 'kinematics' && (
                <div id="kinematics-controls" className="flex flex-col gap-3 text-xs">
                  <div>
                    <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                      <span>Gravity: {gravity} m/s²</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="25"
                      step="0.1"
                      value={gravity}
                      onChange={e => setGravity(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                      <span>Velocity: {velocity} m/s</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="40"
                      value={velocity}
                      onChange={e => setVelocity(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                      <span>Launch Angle: {angle}°</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="90"
                      value={angle}
                      onChange={e => setAngle(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                      <span>Magnetic Field: {magField} T</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="5"
                      step="0.1"
                      value={magField}
                      onChange={e => setMagField(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                </div>
              )}

              {activePhysicsSubTab === 'orbit' && (
                <div id="orbit-controls" className="flex flex-col gap-3 text-xs">
                  <div>
                    <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                      <span>Central Mass Gravity Constant (G*M): {gravity}</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="20"
                      step="0.5"
                      value={gravity}
                      onChange={e => setGravity(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                </div>
              )}

              {activePhysicsSubTab === 'thermo' && (
                <div id="thermo-controls" className="flex flex-col gap-3 text-xs">
                  <div>
                    <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                      <span>Temperature: {temperature} K</span>
                    </div>
                    <input
                      type="range"
                      min="100"
                      max="800"
                      value={temperature}
                      onChange={e => setTemperature(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>
                </div>
              )}

              <div className="flex gap-2 mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  id="btn-physics-start"
                  onClick={startPhysicsSimulation}
                  disabled={isRunning}
                  className="flex-1 flex items-center justify-center gap-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[10px] uppercase rounded-xl cursor-pointer disabled:opacity-40"
                >
                  <Play size={12} /> Run
                </button>
                <button
                  id="btn-physics-pause"
                  onClick={() => setIsRunning(false)}
                  disabled={!isRunning}
                  className="flex-1 flex items-center justify-center gap-1 py-2 bg-amber-600 hover:bg-amber-500 text-white font-black text-[10px] uppercase rounded-xl cursor-pointer disabled:opacity-40"
                >
                  <Pause size={12} /> Pause
                </button>
                <button
                  id="btn-physics-reset"
                  onClick={resetPhysicsSimulation}
                  className="px-3 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl cursor-pointer"
                >
                  <RotateCcw size={12} />
                </button>
              </div>
            </div>

            {/* Quick Analytics Card */}
            <div className="p-4 bg-indigo-950/40 text-indigo-200 border border-indigo-500/10 rounded-2xl text-xs">
              <h5 className="font-black uppercase tracking-wider text-indigo-400 mb-2 flex items-center gap-1.5">
                <Info size={12} /> Live Metrics
              </h5>
              {trajectory.length > 0 ? (
                <div id="live-trajectory-metrics" className="flex flex-col gap-1 text-[11px]">
                  <div className="flex justify-between">
                    <span>X Coordinates:</span>
                    <span className="font-bold font-mono text-white">{(trajectory[trajectory.length - 1].x).toFixed(2)} m</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Height (Y):</span>
                    <span className="font-bold font-mono text-white">{(trajectory[trajectory.length - 1].y).toFixed(2)} m</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Horizontal Vel (Vx):</span>
                    <span className="font-bold font-mono text-white">{(trajectory[trajectory.length - 1].vx).toFixed(1)} m/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Vertical Vel (Vy):</span>
                    <span className="font-bold font-mono text-white">{(trajectory[trajectory.length - 1].vy).toFixed(1)} m/s</span>
                  </div>
                  <div className="flex justify-between border-t border-indigo-500/10 mt-1 pt-1">
                    <span>Kinetic Energy (0.5mv²):</span>
                    <span className="font-bold font-mono text-indigo-300">
                      {(0.5 * mass * (Math.pow(trajectory[trajectory.length - 1].vx, 2) + Math.pow(trajectory[trajectory.length - 1].vy, 2))).toFixed(1)} J
                    </span>
                  </div>
                </div>
              ) : (
                <p className="text-[10px] text-slate-500 font-medium">Click Run to visualize the live physics vector paths!</p>
              )}
            </div>
          </div>

          {/* Interactive Physics Canvas */}
          <div id="physics-engine-canvas-area" className="lg:col-span-8">
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 relative overflow-hidden h-[340px] flex items-center justify-center">
              {/* Plot canvas vector grid */}
              <div className="absolute inset-0 bg-slate-950/10 opacity-30 grid grid-cols-12 grid-rows-6 border border-slate-800" />
              
              <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
                {activePhysicsSubTab === 'kinematics' && (
                  <>
                    {/* Launch Point pad */}
                    <circle cx="40" cy="280" r="8" className="fill-slate-700" />
                    
                    {/* Velocity angle vector path overlay */}
                    {showVectors && (
                      <line 
                        x1="40" 
                        y1="280" 
                        x2={40 + velocity * Math.cos((angle * Math.PI) / 180) * 3} 
                        y2={280 - velocity * Math.sin((angle * Math.PI) / 180) * 3} 
                        className="stroke-amber-400 stroke-2" 
                        strokeDasharray="4"
                      />
                    )}

                    {/* Trajectory vector paths */}
                    {trajectory.length > 1 && (
                      <path
                        d={`M 40 280 ${trajectory.map(p => `L ${40 + p.x * 6} ${280 - p.y * 6}`).join(' ')}`}
                        className="stroke-indigo-500 stroke-2 fill-none"
                      />
                    )}

                    {/* Moving Projectile */}
                    {trajectory.length > 0 && (
                      <circle 
                        cx={40 + trajectory[trajectory.length - 1].x * 6} 
                        cy={280 - trajectory[trajectory.length - 1].y * 6} 
                        r="6" 
                        className="fill-red-500 animate-pulse" 
                      />
                    )}
                  </>
                )}

                {activePhysicsSubTab === 'orbit' && (
                  <>
                    {/* Central Celestial Body */}
                    <circle cx="200" cy="170" r="22" className="fill-indigo-600 stroke-indigo-400 stroke-2" />
                    <circle cx="200" cy="170" r="16" className="fill-indigo-700" />
                    
                    {/* Orbit lines */}
                    {trajectory.length > 1 && (
                      <path
                        d={`M ${200 + trajectory[0].x * 30} ${170 - trajectory[0].y * 30} ${trajectory.map(p => `L ${200 + p.x * 30} ${170 - p.y * 30}`).join(' ')}`}
                        className="stroke-slate-500/40 stroke-1 fill-none"
                      />
                    )}

                    {/* Orbiting probe */}
                    {trajectory.length > 0 && (
                      <circle 
                        cx={200 + trajectory[trajectory.length - 1].x * 30} 
                        cy={170 - trajectory[trajectory.length - 1].y * 30} 
                        r="5" 
                        className="fill-amber-400" 
                      />
                    )}
                  </>
                )}

                {activePhysicsSubTab === 'thermo' && (
                  <>
                    {/* Bound volume container */}
                    <rect x="50" y="50" width="300" height="240" className="stroke-slate-700 stroke-2 fill-slate-900/50" />
                    
                    {/* Floating Gas Atoms */}
                    {trajectory.map((p, idx) => (
                      <circle
                        key={idx}
                        cx={200 + p.x * 30}
                        cy={170 + p.y * 30}
                        r="4"
                        className="fill-indigo-400 animate-pulse"
                      />
                    ))}
                  </>
                )}
              </svg>

              {/* Angle scale banner */}
              <div className="absolute bottom-3 right-3 text-[10px] text-slate-500 font-black">
                PHYSICS LAB v2.0
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Biology Anatomy View */}
      {activeTab === 'biology' && (
        <div id="biology-anatomy-view" className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in fade-in duration-300">
          {/* Biology Selection Bar */}
          <div className="lg:col-span-12 flex bg-slate-50 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800 gap-1">
            <button
              onClick={() => { setSelectedBioModel('cell'); setSelectedOrganelle(null); }}
              className={`flex-1 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                selectedBioModel === 'cell' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-indigo-500'
              }`}
            >
              Animal Cell Anatomy
            </button>
            <button
              onClick={() => { setSelectedBioModel('heart'); setSelectedOrganelle(null); }}
              className={`flex-1 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                selectedBioModel === 'heart' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-indigo-500'
              }`}
            >
              Human Heart Model
            </button>
            <button
              onClick={() => { setSelectedBioModel('chloroplast'); setSelectedOrganelle(null); }}
              className={`flex-1 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                selectedBioModel === 'chloroplast' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-indigo-500'
              }`}
            >
              Chloroplast Cell Lab
            </button>
          </div>

          {/* 3D Visualizer and interactives */}
          <div id="bio-visualizer-section" className="lg:col-span-8">
            <div className="bg-slate-100 dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-800 relative overflow-hidden min-h-[300px]">
              <div className="absolute top-3 left-3 z-10">
                <span className="px-2.5 py-1 rounded-full bg-slate-900/80 text-white text-[10px] font-black tracking-widest flex items-center gap-1">
                  <Eye size={12} className="text-emerald-400" />
                  INTERACTIVE 3D EXPLORER
                </span>
              </div>

              <div id="bio-3d-canvas" ref={bioCanvasRef} className="w-full h-[320px]" />

              {/* Anatomy Hotspots Overlay */}
              <div className="absolute bottom-3 left-3 right-3 flex flex-wrap gap-1.5 justify-center z-10">
                {selectedBioModel === 'cell' && (
                  <>
                    <button onClick={() => selectOrganelleInfo('Nucleus')} className="px-2 py-1 rounded-lg bg-purple-500/15 text-purple-400 hover:bg-purple-500/30 border border-purple-500/20 text-[10px] font-black cursor-pointer">Nucleus</button>
                    <button onClick={() => selectOrganelleInfo('Mitochondria')} className="px-2 py-1 rounded-lg bg-orange-500/15 text-orange-400 hover:bg-orange-500/30 border border-orange-500/20 text-[10px] font-black cursor-pointer">Mitochondria</button>
                    <button onClick={() => selectOrganelleInfo('Ribosome')} className="px-2 py-1 rounded-lg bg-blue-500/15 text-blue-400 hover:bg-blue-500/30 border border-blue-500/20 text-[10px] font-black cursor-pointer">Ribosome</button>
                    <button onClick={() => selectOrganelleInfo('Golgi Apparatus')} className="px-2 py-1 rounded-lg bg-pink-500/15 text-pink-400 hover:bg-pink-500/30 border border-pink-500/20 text-[10px] font-black cursor-pointer">Golgi Body</button>
                  </>
                )}

                {selectedBioModel === 'heart' && (
                  <div className="flex items-center gap-3 bg-slate-900/80 p-2 rounded-xl border border-slate-800">
                    <Heart size={14} className="text-red-500 animate-pulse" />
                    <span className="text-[10px] text-white font-extrabold">Beats/Min Cycle:</span>
                    <div className="flex gap-1">
                      <button onClick={() => setHeartRate('resting')} className={`px-2 py-0.5 rounded text-[8px] font-black uppercase cursor-pointer ${heartRate === 'resting' ? 'bg-emerald-600 text-white' : 'bg-slate-850 text-slate-400'}`}>Resting</button>
                      <button onClick={() => setHeartRate('cardio')} className={`px-2 py-0.5 rounded text-[8px] font-black uppercase cursor-pointer ${heartRate === 'cardio' ? 'bg-amber-600 text-white' : 'bg-slate-850 text-slate-400'}`}>Cardio</button>
                      <button onClick={() => setHeartRate('sprint')} className={`px-2 py-0.5 rounded text-[8px] font-black uppercase cursor-pointer ${heartRate === 'sprint' ? 'bg-red-600 text-white' : 'bg-slate-850 text-slate-400'}`}>Sprint</button>
                    </div>
                  </div>
                )}

                {selectedBioModel === 'chloroplast' && (
                  <div className="flex flex-col gap-2 bg-slate-900/85 p-3 rounded-xl border border-slate-800 text-[10px] text-white w-full max-w-sm">
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold flex items-center gap-1"><Sun size={12} className="text-amber-400 animate-spin" /> Sunlight intensity: {sunlight}%</span>
                      <input type="range" min="0" max="100" value={sunlight} onChange={e => setSunlight(parseInt(e.target.value))} className="w-24 h-1 cursor-pointer accent-emerald-500" />
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold flex items-center gap-1"><Droplet size={12} className="text-blue-400" /> CO2 concentration: {co2Level}%</span>
                      <input type="range" min="0" max="100" value={co2Level} onChange={e => setCo2Level(parseInt(e.target.value))} className="w-24 h-1 cursor-pointer accent-emerald-500" />
                    </div>
                    <div className="flex justify-between border-t border-slate-800 pt-1 mt-1 font-bold text-[9px] text-slate-300">
                      <span>Calvin Loop Rate:</span>
                      <span className="text-emerald-400 font-black">{Math.min(100, Math.round((sunlight * co2Level) / 45))}% standard max</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Bio Sidebar Info Panels */}
          <div id="bio-sidebar-section" className="lg:col-span-4 flex flex-col gap-3">
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex-1">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3">Dissection Metadata</h4>

              {selectedOrganelle ? (
                <div id="organelle-detail" className="animate-in fade-in slide-in-from-bottom-2 duration-300">
                  <div className="text-xs font-black dark:text-slate-100 mb-0.5">{selectedOrganelle.name}</div>
                  <div className="text-[10px] font-bold text-indigo-500 dark:text-indigo-400 mb-2">{selectedOrganelle.function}</div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed bg-white dark:bg-slate-850 p-3 rounded-xl border border-slate-150 dark:border-slate-800">
                    {selectedOrganelle.detail}
                  </p>
                </div>
              ) : (
                <div id="empty-organelle-placeholder" className="h-[150px] flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-4">
                  <Eye size={24} className="mb-1.5 animate-pulse text-indigo-500" />
                  <span className="text-[10px] font-medium text-center">Click organelle hotspots below the 3D viewer to dissect their physiological details!</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
};
