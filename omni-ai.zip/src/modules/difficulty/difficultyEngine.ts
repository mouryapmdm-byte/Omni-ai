import { 
  DifficultyLevel, 
  DifficultyState, 
  DifficultyAdjustmentEvent, 
  FlowStateZone, 
  AdaptiveRateTier,
  InterventionType 
} from './types';

export class DifficultyEngine {
  /**
   * Expected accuracy benchmarks per level
   */
  public static readonly EXPECTED_ACCURACY: Record<DifficultyLevel, number> = {
    1: 0.60, // Easy
    2: 0.50, // Medium
    3: 0.40, // Hard
    4: 0.30, // Advanced
    5: 0.20  // Expert
  };

  /**
   * Creates an initial difficulty state for a student on a topic
   */
  public static createInitialState(
    studentId: string = 'student_default',
    topicId: string = 'general',
    initialLevel: DifficultyLevel = 2 // Medium start
  ): DifficultyState {
    return {
      studentId,
      topicId,
      currentLevel: initialLevel,
      fineDifficulty: initialLevel * 1.0,
      rollingAccuracy: 0.75, // Target flow baseline
      rollingWindow: [],
      consecutiveCorrect: 0,
      consecutiveWrong: 0,
      totalQuestions: 0,
      totalCorrect: 0,
      adaptiveRate: 'fast',
      flowState: 'flow',
      intervention: null,
      lastAdjustedAt: new Date().toISOString()
    };
  }

  /**
   * Computes the adaptive rate tier based on experience
   */
  public static getAdaptiveRateTier(totalQuestions: number): AdaptiveRateTier {
    if (totalQuestions < 20) return 'fast';
    if (totalQuestions < 100) return 'medium';
    return 'slow';
  }

  /**
   * Step size multiplier for within-level adjustment based on tier
   */
  private static getFineStepSize(tier: AdaptiveRateTier): number {
    switch (tier) {
      case 'fast': return 0.30;
      case 'medium': return 0.20;
      case 'slow': return 0.10;
    }
  }

  /**
   * Evaluates Flow State Zone based on rolling accuracy (last 5 answers)
   * Target flow band: 70% to 85%
   */
  public static evaluateFlowZone(rollingAccuracy: number, totalInWindow: number): FlowStateZone {
    if (totalInWindow < 3) return 'optimal';
    if (rollingAccuracy < 0.60) return 'frustration';
    if (rollingAccuracy > 0.90) return 'boredom';
    return 'flow';
  }

  /**
   * Main adaptive transition function:
   * Processes a single answer (correct or wrong) and yields the next state,
   * adjustment events, and any active interventions.
   */
  public static processAnswer(
    currentState: DifficultyState,
    isCorrect: boolean
  ): { nextState: DifficultyState; event: DifficultyAdjustmentEvent | null } {
    const prevLevel = currentState.currentLevel;
    const prevFine = currentState.fineDifficulty;

    // 1. Update rolling window (max 5 items)
    const newWindow = [...currentState.rollingWindow, isCorrect].slice(-5);
    const rollingCorrectCount = newWindow.filter(Boolean).length;
    const rollingAcc = rollingCorrectCount / newWindow.length;

    // 2. Streaks
    const newConsecutiveCorrect = isCorrect ? currentState.consecutiveCorrect + 1 : 0;
    const newConsecutiveWrong = !isCorrect ? currentState.consecutiveWrong + 1 : 0;
    const newTotalQuestions = currentState.totalQuestions + 1;
    const newTotalCorrect = currentState.totalCorrect + (isCorrect ? 1 : 0);

    // 3. Adaptive Rate Tier
    const rateTier = this.getAdaptiveRateTier(newTotalQuestions);
    const stepSize = this.getFineStepSize(rateTier);

    let nextLevel = prevLevel;
    let nextFine = prevFine;
    let trigger: DifficultyAdjustmentEvent['trigger'] = 'manual';
    let reason = 'Steady performance in Flow state.';
    let intervention: InterventionType = null;
    let interventionMessage: string | undefined = undefined;

    // --- RULE 2: ADJUSTMENT RULES ---
    // 3+ correct in a row -> level up (max level 5)
    if (newConsecutiveCorrect >= 3 && prevLevel < 5) {
      nextLevel = Math.min(5, (prevLevel + 1) as DifficultyLevel) as DifficultyLevel;
      nextFine = Math.min(5.0, nextLevel * 1.0);
      trigger = 'consecutive_correct';
      reason = `Promoted to Level ${nextLevel}: 3 consecutive correct answers demonstrated mastery.`;
    } 
    // 2+ wrong in a row -> level down (min level 1)
    else if (newConsecutiveWrong >= 2 && prevLevel > 1) {
      nextLevel = Math.max(1, (prevLevel - 1) as DifficultyLevel) as DifficultyLevel;
      nextFine = Math.max(1.0, nextLevel * 1.0);
      trigger = 'consecutive_wrong';
      reason = `Calibrated down to Level ${nextLevel}: 2 consecutive misses detected. Reinforcing fundamentals.`;
    } 
    // Within-level fine difficulty tuning based on single answer
    else {
      if (isCorrect) {
        nextFine = Math.min(nextLevel + 0.45, prevFine + stepSize);
      } else {
        nextFine = Math.max(nextLevel - 0.45, prevFine - stepSize);
      }
    }

    // --- RULE 4: FLOW STATE TARGET ---
    // Goal: Student accuracy 70-85%
    // If <60%: Too hard -> reduce
    // If >90%: Too easy -> increase
    if (newWindow.length >= 4) {
      if (rollingAcc < 0.60 && nextFine > 1.0) {
        nextFine = Math.max(1.0, nextFine - stepSize);
        if (nextFine < nextLevel - 0.4 && nextLevel > 1) {
          nextLevel = (nextLevel - 1) as DifficultyLevel;
        }
        trigger = 'flow_target_low';
        reason = `Flow adjustment: Rolling accuracy (${Math.round(rollingAcc * 100)}%) below 60% threshold. Easing challenge.`;
      } else if (rollingAcc > 0.90 && nextFine < 5.0) {
        nextFine = Math.min(5.0, nextFine + stepSize);
        if (nextFine > nextLevel + 0.4 && nextLevel < 5) {
          nextLevel = (nextLevel + 1) as DifficultyLevel;
        }
        trigger = 'flow_target_high';
        reason = `Flow adjustment: Rolling accuracy (${Math.round(rollingAcc * 100)}%) exceeded 90%. Increasing depth to maintain engagement.`;
      }
    }

    // --- RULE 5: FRUSTRATION PREVENTION ---
    // Never let student get 4+ wrong in a row
    // After 3 wrong: offer hint or easier question
    // After 5 wrong: suggest break or review
    if (newConsecutiveWrong >= 5) {
      intervention = 'suggest_break_review';
      interventionMessage = "You've tackled some tough concepts. Let's take a 2-minute breather or review the foundational summary.";
      // Force clamp to Level 1 if struggling deeply
      nextLevel = 1;
      nextFine = 1.0;
      trigger = 'frustration_prevention';
    } else if (newConsecutiveWrong === 3) {
      intervention = 'offer_hint';
      interventionMessage = "This problem is tricky! Professor Clarity has prepared an interactive hint.";
      // Step down immediately to prevent 4th wrong
      nextLevel = Math.max(1, (nextLevel - 1) as DifficultyLevel) as DifficultyLevel;
      nextFine = Math.max(1.0, nextFine - 0.5);
      trigger = 'frustration_prevention';
    } else if (newConsecutiveWrong >= 4) {
      // Hard guarantee: Never let student get 4+ wrong without easier question intervention
      intervention = 'easier_question';
      interventionMessage = "Calibrating with an intuitive stepping-stone question.";
      nextLevel = Math.max(1, (nextLevel - 1) as DifficultyLevel) as DifficultyLevel;
      nextFine = Math.max(1.0, nextFine - 0.4);
      trigger = 'frustration_prevention';
    }

    // --- RULE 6: BOREDOM PREVENTION ---
    // Never let student get 5+ correct in a row without challenge
    // After 5 correct at same level: introduce harder variant
    if (newConsecutiveCorrect >= 5) {
      intervention = 'harder_variant';
      interventionMessage = "Outstanding streak! Unleashing a multi-step Olympiad challenge variant.";
      nextFine = Math.min(5.0, nextFine + 0.4);
      if (nextLevel < 5) {
        nextLevel = Math.min(5, (nextLevel + 1) as DifficultyLevel) as DifficultyLevel;
      }
      trigger = 'boredom_prevention';
    }

    // Bound fine difficulty to [1.0, 5.0]
    nextFine = Math.max(1.0, Math.min(5.0, parseFloat(nextFine.toFixed(2))));

    const flowZone = this.evaluateFlowZone(rollingAcc, newWindow.length);

    const nextState: DifficultyState = {
      studentId: currentState.studentId,
      topicId: currentState.topicId,
      currentLevel: nextLevel,
      fineDifficulty: nextFine,
      rollingAccuracy: parseFloat(rollingAcc.toFixed(2)),
      rollingWindow: newWindow,
      consecutiveCorrect: newConsecutiveCorrect,
      consecutiveWrong: newConsecutiveWrong,
      totalQuestions: newTotalQuestions,
      totalCorrect: newTotalCorrect,
      adaptiveRate: rateTier,
      flowState: flowZone,
      intervention,
      interventionMessage,
      lastAdjustedAt: new Date().toISOString()
    };

    let event: DifficultyAdjustmentEvent | null = null;
    if (prevLevel !== nextLevel || Math.abs(prevFine - nextFine) >= 0.2 || trigger !== 'manual') {
      event = {
        previousLevel: prevLevel,
        newLevel: nextLevel,
        previousFineDifficulty: prevFine,
        newFineDifficulty: nextFine,
        reason,
        trigger,
        timestamp: new Date().toISOString()
      };
    }

    return { nextState, event };
  }

  /**
   * Level naming labels
   */
  public static getLevelName(level: DifficultyLevel): string {
    switch (level) {
      case 1: return 'Easy';
      case 2: return 'Medium';
      case 3: return 'Hard';
      case 4: return 'Advanced';
      case 5: return 'Expert';
    }
  }

  /**
   * Expected accuracy string for display
   */
  public static getExpectedAccuracyLabel(level: DifficultyLevel): string {
    const acc = Math.round(this.EXPECTED_ACCURACY[level] * 100);
    return `${acc}% expected`;
  }
}
