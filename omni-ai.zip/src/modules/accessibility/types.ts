export interface AccessibilityPreferences {
  studentId: string;
  highContrast: boolean;
  contrastRatio: 'AA' | 'AAA'; // AA (4.5:1) or AAA (7:1)
  dyslexiaFont: boolean;
  dyslexiaTheme: 'default' | 'cream' | 'sepia' | 'dark-slate';
  fontScale: number; // 1.0 (100%) to 2.0 (200%)
  letterSpacing: 'normal' | 'wide' | 'wider'; // normal, 0.08em, 0.14em
  lineSpacing: 'normal' | 'relaxed' | 'loose'; // 1.5, 1.8, 2.2
  reducedMotion: boolean;
  screenReader: boolean;
  captionsEnabled: boolean;
  audioDescriptions: boolean;
  mathMLMode: boolean; // MathML speech translation
  keyboardNavigationHints: boolean;
  updatedAt: string;
}

export interface LiveAnnouncement {
  id: string;
  message: string;
  priority: 'polite' | 'assertive';
  timestamp: number;
}

export interface A11yAuditResult {
  ruleId: string;
  category: 'contrast' | 'aria' | 'keyboard' | 'structure' | 'multimedia';
  title: string;
  description: string;
  impact: 'critical' | 'serious' | 'moderate' | 'minor';
  status: 'passed' | 'failed' | 'warning';
  wcagReference: string; // e.g., 'WCAG 2.1 - 1.4.3 Contrast (Minimum)'
  helpUrl?: string;
  elementSample?: string;
}

export interface MathMLAccessibleEntity {
  id: string;
  latex: string;
  mathML: string;
  speechText: string;
  subject: string;
}
