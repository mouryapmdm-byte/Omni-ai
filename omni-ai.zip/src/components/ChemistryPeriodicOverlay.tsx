import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { 
  Atom, BookOpen, Layers, Sparkles, X, Info, Search, HelpCircle, 
  ExternalLink, Check, Award, Compass, Zap, FlaskConical 
} from 'lucide-react';

export interface ElementDetails {
  symbol: string;
  name: string;
  atomicNumber: number;
  group: number; // 1 to 18
  period: number; // 1 to 6
  block: 's' | 'p' | 'd' | 'f';
  category: 'organic-backbone' | 'organic-modifier' | 'halogen' | 's-block-metal' | 'transition-metal';
  coordinationApplications: string[];
  organicApplications: string[];
  notableComplexesAndReagents: string[];
  summary: string;
}

export const CHEMISTRY_ELEMENTS_DATA: ElementDetails[] = [
  {
    symbol: "H",
    name: "Hydrogen",
    atomicNumber: 1,
    group: 1,
    period: 1,
    block: "s",
    category: "organic-backbone",
    coordinationApplications: [
      "Acts as a ligand in transition metal hydride complexes (e.g., [FeH2(CO)4]), which are crucial intermediates in industrial hydroformylation cycles.",
      "Coordinates in agostic interactions (C-H...Metal), bridging the gap between covalent organic bounds and coordination chemistry."
    ],
    organicApplications: [
      "Fundamental backbone constituent of all organic compounds (hydrocarbons).",
      "Essential for Proton Nuclear Magnetic Resonance (1H-NMR) spectroscopy to determine organic structural environments.",
      "Acts as protons (H+) in organic acid-base reaction mechanisms and dictates hydrogen bonding in DNA pairing."
    ],
    notableComplexesAndReagents: [
      "Lithium Aluminum Hydride (LiAlH4)",
      "Sodium Borohydride (NaBH4)",
      "Wilkinson's Catalyst [RhCl(PPh3)3]"
    ],
    summary: "Though structurally simple, hydrogen underpins both fundamental organic architecture and the pivotal redox steps of transition-metal coordination catalysis."
  },
  {
    symbol: "Li",
    name: "Lithium",
    atomicNumber: 3,
    group: 1,
    period: 2,
    block: "s",
    category: "s-block-metal",
    coordinationApplications: [
      "Coordinates with crown ethers (e.g., 12-crown-4) with high specificity due to its small ionic radius.",
      "Forms oligomeric and polymeric coordination clusters in solution (e.g., tetrameric methyllithium aggregates)."
    ],
    organicApplications: [
      "Alkyllithium reagents (e.g., n-BuLi, t-BuLi) are premier, extremely powerful nucleophiles and bases used to form carbon-carbon bonds.",
      "Lithium diisopropylamide (LDA) acts as a highly sterically hindered non-nucleophilic strong base for quantitative enolate generation."
    ],
    notableComplexesAndReagents: [
      "n-Butyllithium (n-BuLi)",
      "Lithium Diisopropylamide (LDA)",
      "Lithium Aluminum Hydride (LiAlH4)"
    ],
    summary: "Lithium's high charge density polarizes carbanions, making it indispensable for generating strong nucleophiles and basic enolates in organic synthesis."
  },
  {
    symbol: "B",
    name: "Boron",
    atomicNumber: 5,
    group: 13,
    period: 2,
    block: "p",
    category: "organic-modifier",
    coordinationApplications: [
      "Serves as the core for non-coordinating anions like tetraphenylborate [B(C6H5)4]- and BF4- used to stabilize cationic transition metal complexes."
    ],
    organicApplications: [
      "Drives the hydroboration-oxidation reaction of alkenes to yield anti-Markovnikov syn-addition alcohols.",
      "Organoboronic acids serve as the essential transmetallation coupling partners in palladium-catalyzed Suzuki-Miyaura cross-couplings."
    ],
    notableComplexesAndReagents: [
      "Borane-Tetrahydrofuran (BH3·THF)",
      "Phenylboronic Acid [PhB(OH)2]",
      "Sodium Triacetoxyborohydride [NaBH(OAc)3]"
    ],
    summary: "Boron's vacant p-orbital renders it a potent Lewis acid, which chemists exploit for stereoselective hydroborations and modern bioconjugate cross-coupling reactions."
  },
  {
    symbol: "C",
    name: "Carbon",
    atomicNumber: 6,
    group: 14,
    period: 2,
    block: "p",
    category: "organic-backbone",
    coordinationApplications: [
      "Acts as carbon monoxide (CO) in metal carbonyls, displaying strong pi-backbonding with d-block metals to stabilize low oxidation states (e.g., Ni(CO)4).",
      "Forms transition-metal carbene complexes (Schrock and Fischer carbenes) used in metathesis and alkylidene transfer."
    ],
    organicApplications: [
      "The primary elemental scaffold of all organic chemistry.",
      "Capable of sp3, sp2, and sp hybridization, forming single, double, and triple bonds that create endless spatial skeletons."
    ],
    notableComplexesAndReagents: [
      "Nickel Tetracarbonyl [Ni(CO)4]",
      "Grubbs' Ruthenium Alkylidene Catalyst",
      "Tetramethylsilane (TMS)"
    ],
    summary: "Carbon is the ultimate atomic link, serving as both the structural framework of organic compounds and a powerful backbonding ligand in organometallic complexes."
  },
  {
    symbol: "N",
    name: "Nitrogen",
    atomicNumber: 7,
    group: 15,
    period: 2,
    block: "p",
    category: "organic-backbone",
    coordinationApplications: [
      "An exceptionally common sigma-donor ligand. Forms staple amine, pyridine, bipyridine (bipy), phenanthroline, and ethylenediamine (en) complexes.",
      "Constructs the biological porphyrin ring chelating hub in heme and cytochrome enzymes."
    ],
    organicApplications: [
      "Found in amines, amides, imines, nitriles, amino acids, and nitrogenous bases (adenine, guanine, etc.).",
      "Lends basicity and nucleophilicity to organic compounds; controls peptide structure via hydrogen-bonding amide backbones."
    ],
    notableComplexesAndReagents: [
      "Hexaamminecobalt(III) chloride [Co(NH3)6]Cl3",
      "Tris(bipyridine)ruthenium(II) [Ru(bpy)3]2+",
      "Dimethylformamide (DMF) solvent"
    ],
    summary: "Nitrogen's versatile lone pair acts as a fundamental Lewis basic center in organic mechanisms and a preeminent sigma-donor ligand in transition metal complexes."
  },
  {
    symbol: "O",
    name: "Oxygen",
    atomicNumber: 8,
    group: 16,
    period: 2,
    block: "p",
    category: "organic-backbone",
    coordinationApplications: [
      "Coordinates as aqua ligands [M(H2O)6]n+, oxo ligands (M=O), and chelating oxygen donors like acetylacetonate (acac) or oxalate.",
      "Serves as the key coordinating donor in Ethylenediaminetetraacetic acid (EDTA) used in complexometric titrations."
    ],
    organicApplications: [
      "Defines principal functional groups: alcohols, ethers, epoxides, aldehydes, ketones, carboxylic acids, and esters.",
      "Its high electronegativity polarizes carbonyl groups, rendering them highly susceptible to nucleophilic attack."
    ],
    notableComplexesAndReagents: [
      "Ethylenediaminetetraacetic Acid (EDTA)",
      "Chromic Acid (H2CrO4)",
      "Tris(acetylacetonato)iron(III) [Fe(acac)3]"
    ],
    summary: "Oxygen polarizes organic architectures to direct metabolic and synthetic reactions, while simultaneously serving as a robust oxo/chelate binder in coordination rings."
  },
  {
    symbol: "F",
    name: "Fluorine",
    atomicNumber: 9,
    group: 17,
    period: 2,
    block: "p",
    category: "halogen",
    coordinationApplications: [
      "Behaves as a hard weak-field fluoride (F-) ligand, producing high-spin electronic configurations such as octahedral [FeF6]3-."
    ],
    organicApplications: [
      "Introduced into over 25% of modern pharmaceuticals (e.g., Prozac, Lipitor, Pfizer's Paxlovid) to increase metabolic stability, lipophilicity, and target binding.",
      "Forms robust carbon-fluorine bonds that resist thermal and chemical degradation, creating polymer barriers like Teflon."
    ],
    notableComplexesAndReagents: [
      "Diethylaminosulfur Trifluoride (DAST)",
      "Selectfluor",
      "Sodium Hexafluorophosphate [NaPF6]"
    ],
    summary: "As the most electronegative element, Fluorine forms the strongest single bond to carbon in organic molecules, and serves as a hard, weakly-coordinating anion in metals."
  },
  {
    symbol: "Na",
    name: "Sodium",
    atomicNumber: 11,
    group: 1,
    period: 3,
    block: "s",
    category: "s-block-metal",
    coordinationApplications: [
      "Encapsulated inside crown ethers (specifically 15-crown-5) to study size-exclusion host-guest coordination architectures.",
      "Forms coordination lattices that stabilize biologically crucial sodium-potassium ion channels."
    ],
    organicApplications: [
      "Metallic sodium serves as a single-electron donor in Birch reductions to convert benzene rings into 1,4-cyclohexadienes.",
      "Forms sodium enolates and organic salts, stabilizing carboxylates and alkoxide intermediates."
    ],
    notableComplexesAndReagents: [
      "Sodium Metal (Na0)",
      "Sodium Amalgam [Na(Hg)]",
      "Sodium Naphthalene"
    ],
    summary: "Sodium acts as a key counter-cation to organic species, and its elemental form provides the single-electron transfers necessary for dissolved metal reductions."
  },
  {
    symbol: "Mg",
    name: "Magnesium",
    atomicNumber: 12,
    group: 2,
    period: 3,
    block: "s",
    category: "s-block-metal",
    coordinationApplications: [
      "Coordinates as the central magnesium(II) ion in Chlorophyll, surrounded by a chlorin ring system that absorbs solar light.",
      "Stabilizes the complex phosphate backbone folds of RNA and ATP through strong electrostatic coordination."
    ],
    organicApplications: [
      "The irreplaceable engine of Grignard Reagents (RMgX). Inserts directly into carbon-halogen bonds to generate powerful carbanionic nucleophiles."
    ],
    notableComplexesAndReagents: [
      "Methylmagnesium Bromide (CH3MgBr)",
      "Phenylmagnesium Chloride (PhMgCl)",
      "Chlorophyll a"
    ],
    summary: "Magnesium represents a beautiful bridge, acting as the photon-absorber in chlorophyll coordination biology, and the Grignard mediator in organic synthesis."
  },
  {
    symbol: "Si",
    name: "Silicon",
    atomicNumber: 14,
    group: 14,
    period: 3,
    block: "p",
    category: "organic-modifier",
    coordinationApplications: [
      "Forms silicate complexes and acts as bridging atoms in polysiloxane coordination elastomers."
    ],
    organicApplications: [
      "Silyl ethers (e.g., TBS, TMS, TIPS) serve as robust, selectively removable protecting groups for organic alcohols.",
      "Tetramethylsilane (TMS) is the universal, absolute chemical shift reference standard (0 ppm) in 1H and 13C NMR spectroscopy."
    ],
    notableComplexesAndReagents: [
      "Tetramethylsilane (TMS)",
      "tert-Butyldimethylsilyl Chloride (TBSCl)",
      "Tetraethyl Orthosilicate (TEOS)"
    ],
    summary: "With properties similar to carbon but with high silicon-oxygen affinity, silicon provides the primary shielding/protecting reagents used in complex organic multi-step syntheses."
  },
  {
    symbol: "P",
    name: "Phosphorus",
    atomicNumber: 15,
    group: 15,
    period: 3,
    block: "p",
    category: "organic-modifier",
    coordinationApplications: [
      "Phosphine ligands (especially Triphenylphosphine, PPh3) act as powerful soft sigma-donors that stabilize low oxidation-state catalytic transition metals."
    ],
    organicApplications: [
      "Wittig Reaction: Phosphonium ylides (Wittig reagents) react with aldehydes or ketones to construct carbon-carbon double bonds (alkenes) with high regioselectivity.",
      "Forms the structural phosphate diester linkage in the DNA double-helix backbone."
    ],
    notableComplexesAndReagents: [
      "Triphenylphosphine (PPh3)",
      "Methylenetriphenylphosphorane (Wittig Reagent)",
      "Phosphorus Oxychloride (POCl3)"
    ],
    summary: "Phosphorus compounds govern energy transfers in living cells (ATP), act as the foundation of the Wittig alkene synthesis, and stabilize d-block noble catalysts."
  },
  {
    symbol: "S",
    name: "Sulfur",
    atomicNumber: 16,
    group: 16,
    period: 3,
    block: "p",
    category: "organic-modifier",
    coordinationApplications: [
      "Acts as thiolate and thioether donors. Coordinates in iron-sulfur clusters [Fe-S] essential for electron transfer in mitochondrial proteins.",
      "Coordinates as an ambidentate thiocyanate (SCN-) ligand, binding through sulfur (thiocyanato) or nitrogen (isothiocyanato) based on metal hardness."
    ],
    organicApplications: [
      "Found in thiols, thioesters (e.g., Acetyl-CoA), sulfones, and sulfonic acids.",
      "Forms disulfide bridges (Cys-S-S-Cys) that anchor secondary and tertiary protein folding configurations."
    ],
    notableComplexesAndReagents: [
      "Dimethyl Sulfoxide (DMSO) solvent",
      "Lawesson's Reagent (for thiation of carbonyls)",
      "p-Toluenesulfonyl Chloride (TsCl)"
    ],
    summary: "Sulfur serves as a highly polarizable nucleophile in organic substitution, a critical protein-folding bridge, and a soft donor in metalloprotein redox clusters."
  },
  {
    symbol: "Cl",
    name: "Chlorine",
    atomicNumber: 17,
    group: 17,
    period: 3,
    block: "p",
    category: "halogen",
    coordinationApplications: [
      "Acts as a weak-field pi-donor ligand. Frequently used in coordination chemistry studies to create tetrahedral complexes like [CoCl4]2-."
    ],
    organicApplications: [
      "Serves as an excellent leaving group in SN2 and SN1 nucleophilic substitutions (alkyl chlorides).",
      "Constituent of critical polymers like Polyvinyl Chloride (PVC) and chlorinated organic solvents like dichloromethane."
    ],
    notableComplexesAndReagents: [
      "Thionyl Chloride (SOCl2)",
      "Cisplatin [cis-PtCl2(NH3)2]",
      "N-Chlorosuccinimide (NCS)"
    ],
    summary: "Chlorine is a highly common ligand in textbook Werner complexes, and serves as an important electrophilic activator and leaving group in organic mechanisms."
  },
  {
    symbol: "Ti",
    name: "Titanium",
    atomicNumber: 22,
    group: 4,
    period: 4,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "Forms hexaaquatitanium(III) [Ti(H2O)6]3+, the classic textbook example of d1 Jahn-Teller electronic transition spectra yielding a beautiful purple color.",
      "Forms titanocene complexes containing coordinated cyclopentadienyl rings."
    ],
    organicApplications: [
      "Ziegler-Natta Catalyst: Titanium tetrachloride coordinated with triethylaluminum catalyzes the stereoregular polymerization of ethene and propene."
    ],
    notableComplexesAndReagents: [
      "Titanium Tetrachloride (TiCl4)",
      "Ziegler-Natta Catalyst",
      "Tebbe's Reagent"
    ],
    summary: "Titanium is a d-block titan, providing the ultimate catalyst for global plastic manufacture and the textbook model for d-orbital electronic absorption."
  },
  {
    symbol: "Cr",
    name: "Chromium",
    atomicNumber: 24,
    group: 6,
    period: 4,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "An iconic coordination metal. Alfred Werner synthesized hundreds of octahedral chromium(III) complexes (e.g., [Cr(en)3]Cl3) to establish his coordination theory.",
      "Exhibits giant crystal field splitting when coordinated to hard nitrogen and oxygen donors."
    ],
    organicApplications: [
      "Chromic acid (Jones Reagent) oxidizes primary alcohols directly to carboxylic acids, and secondary alcohols to ketones.",
      "Pyridinium chlorochromate (PCC) selectively stops the oxidation of primary alcohols at the aldehyde stage."
    ],
    notableComplexesAndReagents: [
      "Jones Reagent (CrO3 in dilute H2SO4)",
      "Pyridinium Chlorochromate (PCC)",
      "Hexacarbonylchromium [Cr(CO)6]"
    ],
    summary: "Chromium is a foundational pillar of coordination chemistry stoichiometry, as well as a premier reagent for selective oxidation in organic synthesis."
  },
  {
    symbol: "Mn",
    name: "Manganese",
    atomicNumber: 25,
    group: 7,
    period: 4,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "Coordinates as the multi-nuclear manganese cluster in the Oxygen-Evolving Complex (OEC) of Photosystem II, driving biological water oxidation.",
      "Forms beautiful high-spin d5 octahedral complexes with zero crystal field stabilization energy."
    ],
    organicApplications: [
      "Potassium Permanganate (KMnO4) is a powerful oxidant used for the syn-dihydroxylation of alkenes to yield 1,2-diols, and for severe alkyl chain oxidations."
    ],
    notableComplexesAndReagents: [
      "Potassium Permanganate (KMnO4)",
      "Manganese Dioxide (MnO2)",
      "Methylcyclopentadienyl Manganese Tricarbonyl (MMT)"
    ],
    summary: "Manganese leverages a vast span of oxidation states (+2 to +7) to catalyze both metalloenzyme water-splitting and synthetic lab oxidations."
  },
  {
    symbol: "Fe",
    name: "Iron",
    atomicNumber: 26,
    group: 8,
    period: 4,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "Forms Hemoglobin's active heme core, coordinating with oxygen to enable respiration.",
      "Constructs robust cyano complexes: potassium ferrocyanide [Fe(CN)6]4- and ferricyanide [Fe(CN)6]3-."
    ],
    organicApplications: [
      "First metal to construct a stable 'sandwich' metallocene compound: Ferrocene [Fe(C5H5)2], which birthed the entire field of organometallic chemistry.",
      "Acts as a Lewis acid catalyst in electrophilic aromatic substitutions (e.g., bromination of benzene using FeBr3)."
    ],
    notableComplexesAndReagents: [
      "Ferrocene [Fe(η5-C5H5)2]",
      "Iron Pentacarbonyl [Fe(CO)5]",
      "Prussian Blue [Fe4[Fe(CN)6]3]"
    ],
    summary: "Iron is the biological superstar of coordination oxygen-carrying and the historical catalyst of the organometallic revolution (Ferrocene)."
  },
  {
    symbol: "Co",
    name: "Cobalt",
    atomicNumber: 27,
    group: 9,
    period: 4,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "The premier testing ground for Alfred Werner's theories. Hexaamminecobalt(III) [Co(NH3)6]3+ proved octahedral structure, stereoisomerism, and coordination number.",
      "Forms Vitamin B12 (cobalamin), where cobalt is coordinated inside a corrin ring, driving biological methyl transfers."
    ],
    organicApplications: [
      "Cobalt carbonyls catalyze hydroformylation (oxo process) to convert alkenes into aldehydes, and Pauson-Khand cyclopentenone ring closures."
    ],
    notableComplexesAndReagents: [
      "Hexaamminecobalt(III) Chloride [Co(NH3)6]Cl3",
      "Vitamin B12 (Cyanocobalamin)",
      "Dicobalt Octacarbonyl [Co2(CO)8]"
    ],
    summary: "Cobalt stands as coordination chemistry's benchmark metal for isomerism studies and is the central active engine in coenzyme biochemistry."
  },
  {
    symbol: "Ni",
    name: "Nickel",
    atomicNumber: 28,
    group: 10,
    period: 4,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "Demonstrates structural-spin relationship: forms square-planar [Ni(CN)4]2- (diamagnetic, d8) vs tetrahedral [NiCl4]2- (paramagnetic, d8).",
      "Chelates with dimethylglyoxime (dmgH) to form a bright strawberry-red nickel dimethylglyoximate [Ni(dmg)2] complex used in gravimetric analysis."
    ],
    organicApplications: [
      "Raney Nickel is the premier finely divided catalyst for high-pressure hydrogenations of alkenes, alkynes, aromatics, and carbonyls.",
      "Nickel complexes drive modern photoredox/nickel dual catalysis for C-heteroatom bond formations."
    ],
    notableComplexesAndReagents: [
      "Raney Nickel",
      "Nickel Dimethylglyoxime [Ni(dmg)2]",
      "Bis(1,5-cyclooctadiene)nickel(0) [Ni(cod)2]"
    ],
    summary: "Nickel is a powerhouse for organic hydrogenations, structural coordination demonstrations, and gravimetric quantitative metal assays."
  },
  {
    symbol: "Cu",
    name: "Copper",
    atomicNumber: 29,
    group: 11,
    period: 4,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "Forms deep royal-blue tetraamminecopper(II) [Cu(NH3)4(H2O)2]2+, displaying Jahn-Teller tetragonal elongated distortion.",
      "Fehling's Solution coordinates copper(II) with tartrate ligands, which is reduced to copper(I) oxide to detect reducing sugars."
    ],
    organicApplications: [
      "Forms organocuprate 'Gilman Reagents' (R2CuLi) which selectively undergo 1,4-conjugate additions to alpha,beta-unsaturated carbonyls without attacking ketones."
    ],
    notableComplexesAndReagents: [
      "Gilman Reagent [Li(Me2Cu)]",
      "Fehling's Solution",
      "Copper(I) Iodide (CuI) for Sonogashira coupling"
    ],
    summary: "Copper provides the primary soft nucleophile reagents for organic synthesis, and serves as a classic Jahn-Teller structural model in d-block coordination."
  },
  {
    symbol: "Zn",
    name: "Zinc",
    atomicNumber: 30,
    group: 12,
    period: 4,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "As a stable, filled d10 metal, zinc(II) coordinates in a colorless tetrahedral geometry in carbonic anhydrase to catalyze CO2 hydration.",
      "Forms zinc-finger protein coordination motifs that bind specifically to major grooves of DNA."
    ],
    organicApplications: [
      "Used as zinc amalgam (Zn/Hg) in the Clemmensen Reduction to convert ketones directly into alkanes.",
      "Mediates the Reformatsky Reaction, generating nucleophilic organozinc enolates that attack aldehydes."
    ],
    notableComplexesAndReagents: [
      "Zinc Amalgam [Zn(Hg)]",
      "Diethylzinc (Et2Zn)",
      "Carbonic Anhydrase enzyme"
    ],
    summary: "Zinc's filled d10 shell prevents d-d optical absorptions, serving instead as a colorless biochemical anchor and a mild, highly selective organic reducing agent."
  },
  {
    symbol: "Br",
    name: "Bromine",
    atomicNumber: 35,
    group: 17,
    period: 4,
    block: "p",
    category: "halogen",
    coordinationApplications: [
      "Coordinates as a weak-field bromo ligand, useful for forming stereoisomers like [CoBr(NH3)5]2+ to study coordination ligand exchange kinetics."
    ],
    organicApplications: [
      "Addition of Br2 to alkenes (decolorization) serves as the classic diagnostic test for organic unsaturation (double bonds).",
      "N-Bromosuccinimide (NBS) is the premier reagent for selective allylic and benzylic free-radical brominations."
    ],
    notableComplexesAndReagents: [
      "N-Bromosuccinimide (NBS)",
      "Elemental Bromine (Br2)",
      "Triphenylphosphine Dibromide (Ph3PBr2)"
    ],
    summary: "Bromine acts as an exceptional organic leaving group (Br-) and a diagnostic reagent to test for alkene unsaturation through cyclic bromonium intermediates."
  },
  {
    symbol: "Ru",
    name: "Ruthenium",
    atomicNumber: 44,
    group: 8,
    period: 5,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "Forms tris(bipyridine)ruthenium(II) [Ru(bpy)3]2+, the premier, highly photostable luminophore used in light-harvesting solar cells and photoredox assays."
    ],
    organicApplications: [
      "Grubbs' Catalysts: Ruthenium alkylidene complexes catalyze olefin metathesis (swapping alkene substituents), revolutionizing polymer and drug synthesis."
    ],
    notableComplexesAndReagents: [
      "Grubbs' Catalyst 1st/2nd Gen",
      "Tris(bipyridine)ruthenium(II) [Ru(bpy)3]2+",
      "Ruthenium Tetroxide (RuO4)"
    ],
    summary: "Ruthenium is the crown jewel of modern synthetic progress, driving Nobel-prize winning olefin metathesis and cutting-edge visible-light photoredox catalysis."
  },
  {
    symbol: "Pd",
    name: "Palladium",
    atomicNumber: 46,
    group: 10,
    period: 5,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "Forms square-planar complexes that readily cycle between palladium(0) and palladium(II) states during catalytic coupling.",
      "Coordinates with bulky phosphines to prevent catalyst aggregation during industrial synthesis."
    ],
    organicApplications: [
      "The undisputed King of Cross-Coupling. Catalyzes carbon-carbon bond forming reactions including Suzuki-Miyaura, Heck, Negishi, and Sonogashira couplings.",
      "Lindlar's Catalyst (Pd poisoned with Pb) selectively reduces alkynes to cis-alkenes."
    ],
    notableComplexesAndReagents: [
      "Tetrakis(triphenylphosphine)palladium(0) [Pd(PPh3)4]",
      "Palladium on Carbon (Pd/C)",
      "Lindlar's Catalyst"
    ],
    summary: "Palladium is the ultimate synthetic connector, enabling the assembly of incredibly complex organic molecules and pharmaceuticals via selective metal cross-coupling."
  },
  {
    symbol: "I",
    name: "Iodine",
    atomicNumber: 53,
    group: 17,
    period: 5,
    block: "p",
    category: "halogen",
    coordinationApplications: [
      "Acts as a highly polarizable, weak-field iodo ligand (I-) demonstrating a strong nephelauxetic effect (covalent sharing) in metal bonds."
    ],
    organicApplications: [
      "Methyl Iodide (CH3I) serves as the supreme alkylating agent in organic synthesis due to its outstanding SN2 leaving group efficiency.",
      "Iodoform Reaction: identifies methyl ketones by precipitating a bright yellow CHI3 solid.",
      "Hypervalent iodine reagents act as metal-free green oxidants."
    ],
    notableComplexesAndReagents: [
      "Dess-Martin Periodinane (DMP)",
      "Methyl Iodide (CH3I)",
      "Iodoform (CHI3)"
    ],
    summary: "Iodine acts as the premium halide leaving group in organic substitutions, and hypervalent periodinane variants serve as high-performance metal-free oxidants."
  },
  {
    symbol: "Pt",
    name: "Platinum",
    atomicNumber: 78,
    group: 10,
    period: 6,
    block: "d",
    category: "transition-metal",
    coordinationApplications: [
      "Forms square-planar complexes like Cisplatin [cis-PtCl2(NH3)2] which intercalates DNA, acting as one of the world's most vital chemotherapy drugs.",
      "Served as the benchmark metal to discover and map the coordination 'Trans Effect' ligand exchange pathway."
    ],
    organicApplications: [
      "Adams' Catalyst (PtO2) and platinum black drive the complete catalytic hydrogenation of alkenes, alkynes, and nitro functions under mild conditions."
    ],
    notableComplexesAndReagents: [
      "Cisplatin [cis-PtCl2(NH3)2]",
      "Adams' Catalyst (PtO2)",
      "Karstedt's Catalyst"
    ],
    summary: "Platinum's unique d-block coordination geometry produced the world's most famous anticancer drug (Cisplatin) and serves as an exceptional organic hydrogenation agent."
  }
];

// Complete skeleton of first 6 periods for a realistic Periodic Table Grid representation
// Only active ones mapped above will be highly stylized and clickable. Others are displayed for context.
interface GridElement {
  symbol: string;
  atomicNumber: number;
  group: number;
  period: number;
  isActive: boolean;
  block?: 's' | 'p' | 'd' | 'f';
}

const PERIODIC_TABLE_GRID: GridElement[] = [
  // Period 1
  { symbol: "H", atomicNumber: 1, group: 1, period: 1, isActive: true, block: 's' },
  { symbol: "He", atomicNumber: 2, group: 18, period: 1, isActive: false },
  
  // Period 2
  { symbol: "Li", atomicNumber: 3, group: 1, period: 2, isActive: true, block: 's' },
  { symbol: "Be", atomicNumber: 4, group: 2, period: 2, isActive: false },
  { symbol: "B", atomicNumber: 5, group: 13, period: 2, isActive: true, block: 'p' },
  { symbol: "C", atomicNumber: 6, group: 14, period: 2, isActive: true, block: 'p' },
  { symbol: "N", atomicNumber: 7, group: 15, period: 2, isActive: true, block: 'p' },
  { symbol: "O", atomicNumber: 8, group: 16, period: 2, isActive: true, block: 'p' },
  { symbol: "F", atomicNumber: 9, group: 17, period: 2, isActive: true, block: 'p' },
  { symbol: "Ne", atomicNumber: 10, group: 18, period: 2, isActive: false },

  // Period 3
  { symbol: "Na", atomicNumber: 11, group: 1, period: 3, isActive: true, block: 's' },
  { symbol: "Mg", atomicNumber: 12, group: 2, period: 3, isActive: true, block: 's' },
  { symbol: "Al", atomicNumber: 13, group: 13, period: 3, isActive: false },
  { symbol: "Si", atomicNumber: 14, group: 14, period: 3, isActive: true, block: 'p' },
  { symbol: "P", atomicNumber: 15, group: 15, period: 3, isActive: true, block: 'p' },
  { symbol: "S", atomicNumber: 16, group: 16, period: 3, isActive: true, block: 'p' },
  { symbol: "Cl", atomicNumber: 17, group: 17, period: 3, isActive: true, block: 'p' },
  { symbol: "Ar", atomicNumber: 18, group: 18, period: 3, isActive: false },

  // Period 4
  { symbol: "K", atomicNumber: 19, group: 1, period: 4, isActive: false },
  { symbol: "Ca", atomicNumber: 20, group: 2, period: 4, isActive: false },
  { symbol: "Sc", atomicNumber: 21, group: 3, period: 4, isActive: false },
  { symbol: "Ti", atomicNumber: 22, group: 4, period: 4, isActive: true, block: 'd' },
  { symbol: "V", atomicNumber: 23, group: 5, period: 4, isActive: false },
  { symbol: "Cr", atomicNumber: 24, group: 6, period: 4, isActive: true, block: 'd' },
  { symbol: "Mn", atomicNumber: 25, group: 7, period: 4, isActive: true, block: 'd' },
  { symbol: "Fe", atomicNumber: 26, group: 8, period: 4, isActive: true, block: 'd' },
  { symbol: "Co", atomicNumber: 27, group: 9, period: 4, isActive: true, block: 'd' },
  { symbol: "Ni", atomicNumber: 28, group: 10, period: 4, isActive: true, block: 'd' },
  { symbol: "Cu", atomicNumber: 29, group: 11, period: 4, isActive: true, block: 'd' },
  { symbol: "Zn", atomicNumber: 30, group: 12, period: 4, isActive: true, block: 'd' },
  { symbol: "Ga", atomicNumber: 31, group: 13, period: 4, isActive: false },
  { symbol: "Ge", atomicNumber: 32, group: 14, period: 4, isActive: false },
  { symbol: "As", atomicNumber: 33, group: 15, period: 4, isActive: false },
  { symbol: "Se", atomicNumber: 34, group: 16, period: 4, isActive: false },
  { symbol: "Br", atomicNumber: 35, group: 17, period: 4, isActive: true, block: 'p' },
  { symbol: "Kr", atomicNumber: 36, group: 18, period: 4, isActive: false },

  // Period 5
  { symbol: "Rb", atomicNumber: 37, group: 1, period: 5, isActive: false },
  { symbol: "Sr", atomicNumber: 38, group: 2, period: 5, isActive: false },
  { symbol: "Y", atomicNumber: 39, group: 3, period: 5, isActive: false },
  { symbol: "Zr", atomicNumber: 40, group: 4, period: 5, isActive: false },
  { symbol: "Nb", atomicNumber: 41, group: 5, period: 5, isActive: false },
  { symbol: "Mo", atomicNumber: 42, group: 6, period: 5, isActive: false },
  { symbol: "Tc", atomicNumber: 43, group: 7, period: 5, isActive: false },
  { symbol: "Ru", atomicNumber: 44, group: 8, period: 5, isActive: true, block: 'd' },
  { symbol: "Rh", atomicNumber: 45, group: 9, period: 5, isActive: false },
  { symbol: "Pd", atomicNumber: 46, group: 10, period: 5, isActive: true, block: 'd' },
  { symbol: "Ag", atomicNumber: 47, group: 11, period: 5, isActive: false },
  { symbol: "Cd", atomicNumber: 48, group: 12, period: 5, isActive: false },
  { symbol: "In", atomicNumber: 49, group: 13, period: 5, isActive: false },
  { symbol: "Sn", atomicNumber: 50, group: 14, period: 5, isActive: false },
  { symbol: "Sb", atomicNumber: 51, group: 15, period: 5, isActive: false },
  { symbol: "Te", atomicNumber: 52, group: 16, period: 5, isActive: false },
  { symbol: "I", atomicNumber: 53, group: 17, period: 5, isActive: true, block: 'p' },
  { symbol: "Xe", atomicNumber: 54, group: 18, period: 5, isActive: false },

  // Period 6 (Truncated for clean rendering of Platinum Pt Z=78)
  { symbol: "Cs", atomicNumber: 55, group: 1, period: 6, isActive: false },
  { symbol: "Ba", atomicNumber: 56, group: 2, period: 6, isActive: false },
  { symbol: "La", atomicNumber: 57, group: 3, period: 6, isActive: false },
  { symbol: "Lu", atomicNumber: 71, group: 3, period: 6, isActive: false }, // Lanthanides placeholder
  { symbol: "Hf", atomicNumber: 72, group: 4, period: 6, isActive: false },
  { symbol: "Ta", atomicNumber: 73, group: 5, period: 6, isActive: false },
  { symbol: "W", atomicNumber: 74, group: 6, period: 6, isActive: false },
  { symbol: "Re", atomicNumber: 75, group: 7, period: 6, isActive: false },
  { symbol: "Os", atomicNumber: 76, group: 8, period: 6, isActive: false },
  { symbol: "Ir", atomicNumber: 77, group: 9, period: 6, isActive: false },
  { symbol: "Pt", atomicNumber: 78, group: 10, period: 6, isActive: true, block: 'd' },
  { symbol: "Au", atomicNumber: 79, group: 11, period: 6, isActive: false },
  { symbol: "Hg", atomicNumber: 80, group: 12, period: 6, isActive: false },
  { symbol: "Tl", atomicNumber: 81, group: 13, period: 6, isActive: false },
  { symbol: "Pb", atomicNumber: 82, group: 14, period: 6, isActive: false },
  { symbol: "Bi", atomicNumber: 83, group: 15, period: 6, isActive: false },
  { symbol: "Po", atomicNumber: 84, group: 16, period: 6, isActive: false },
  { symbol: "At", atomicNumber: 85, group: 17, period: 6, isActive: false },
  { symbol: "Rn", atomicNumber: 86, group: 18, period: 6, isActive: false }
];

interface ChemistryPeriodicOverlayProps {
  theme: 'light' | 'dark';
  onClose?: () => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const ChemistryPeriodicOverlay: React.FC<ChemistryPeriodicOverlayProps> = ({
  theme,
  onClose,
  showNotification
}) => {
  const [selectedSymbol, setSelectedSymbol] = useState<string>("Fe");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedBlockFilter, setSelectedBlockFilter] = useState<'all' | 's' | 'p' | 'd'>('all');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<'all' | 'organic' | 'coordination'>('all');

  // Selected element lookup
  const activeElement = useMemo(() => {
    return CHEMISTRY_ELEMENTS_DATA.find(el => el.symbol === selectedSymbol) || CHEMISTRY_ELEMENTS_DATA[14]; // Default to Iron
  }, [selectedSymbol]);

  // Filtered elements list for quick lookup pane
  const filteredElementsList = useMemo(() => {
    return CHEMISTRY_ELEMENTS_DATA.filter(el => {
      const matchesSearch = el.symbol.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            el.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            el.summary.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesBlock = selectedBlockFilter === 'all' || el.block === selectedBlockFilter;
      
      let matchesCategory = true;
      if (selectedCategoryFilter === 'organic') {
        matchesCategory = el.category === 'organic-backbone' || el.category === 'organic-modifier' || el.category === 'halogen';
      } else if (selectedCategoryFilter === 'coordination') {
        matchesCategory = el.category === 'transition-metal' || el.category === 's-block-metal';
      }

      return matchesSearch && matchesBlock && matchesCategory;
    });
  }, [searchQuery, selectedBlockFilter, selectedCategoryFilter]);

  // Map the grid matrix (6 periods, 18 columns)
  const gridCells = useMemo(() => {
    const grid: (GridElement | null)[][] = Array(6).fill(null).map(() => Array(18).fill(null));
    
    PERIODIC_TABLE_GRID.forEach(el => {
      const r = el.period - 1;
      const c = el.group - 1;
      if (r >= 0 && r < 6 && c >= 0 && c < 18) {
        grid[r][c] = el;
      }
    });

    return grid;
  }, []);

  return (
    <div className={cn(
      "p-5 md:p-6 rounded-3xl border shadow-2xl flex flex-col space-y-6 animate-fadeIn transition-all max-w-7xl mx-auto w-full",
      theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200/80"
    )}>
      
      {/* Header Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-dashed border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
              Interactive Syllabus Companion
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-black tracking-tight flex items-center gap-2">
            <Atom className="text-indigo-500 animate-spin-slow" size={24} />
            Periodic Table of Real-World Chemistry Applications
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Select elements to instantly reveal their catalytic, biochemical, and synthetic applications in Coordination and Organic Chemistry.
          </p>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-2.5 rounded-full border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 transition active:scale-95 cursor-pointer"
            title="Close periodic overlay"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 dark:bg-slate-900/40 p-3 rounded-2xl border border-slate-200/50 dark:border-slate-800/80">
        <div className="flex flex-wrap items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={13} />
            <input
              type="text"
              placeholder="Search elements..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={cn(
                "pl-8 pr-3 py-1.5 rounded-xl text-xs outline-none border transition-all w-44 font-semibold",
                theme === 'dark' ? "bg-slate-900 border-slate-800 text-white focus:border-indigo-500" : "bg-white border-slate-200 text-slate-800 focus:border-indigo-500"
              )}
            />
          </div>

          {/* Block filter */}
          <div className="flex items-center gap-1 bg-white dark:bg-slate-950 p-1 rounded-xl border border-slate-200/50 dark:border-slate-800/80">
            <span className="text-[10px] font-black text-slate-400 px-1.5 uppercase">Block:</span>
            {(['all', 's', 'p', 'd'] as const).map(bl => (
              <button
                key={bl}
                onClick={() => setSelectedBlockFilter(bl)}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase transition-all cursor-pointer",
                  selectedBlockFilter === bl
                    ? "bg-indigo-600 text-white shadow-sm"
                    : "text-slate-500 hover:text-slate-800 dark:hover:text-white"
                )}
              >
                {bl}
              </button>
            ))}
          </div>

          {/* Core Chemistry Category Filter */}
          <div className="flex items-center gap-1 bg-white dark:bg-slate-950 p-1 rounded-xl border border-slate-200/50 dark:border-slate-800/80">
            <span className="text-[10px] font-black text-slate-400 px-1.5 uppercase">Focus:</span>
            {[
              { id: 'all', label: 'All' },
              { id: 'organic', label: 'Organic Chemistry' },
              { id: 'coordination', label: 'Coordination / Metals' }
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategoryFilter(cat.id as any)}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer",
                  selectedCategoryFilter === cat.id
                    ? "bg-indigo-600 text-white shadow-sm"
                    : "text-slate-500 hover:text-slate-800 dark:hover:text-white"
                )}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div className="text-[11px] font-bold text-indigo-500 flex items-center gap-1 animate-pulse">
          <Sparkles size={12} />
          <span>Click colored elements to view applications</span>
        </div>
      </div>

      {/* Main Grid & Details Section split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left column: Grid of elements */}
        <div className="lg:col-span-8 flex flex-col space-y-4 overflow-x-auto">
          {/* Legend */}
          <div className="flex flex-wrap gap-4 text-[10px] font-bold text-slate-400 bg-slate-50 dark:bg-slate-900/20 p-2 px-3 rounded-xl border border-slate-150 dark:border-slate-850">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-indigo-500" />
              <span>Organic Backbone (C, H, N, O)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-purple-500" />
              <span>Organic Modifier/Reagents (B, Si, P, S)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-emerald-500" />
              <span>s-Block Metal / Grignard (Li, Na, Mg)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-amber-500" />
              <span>Halogens & Leaving Groups (F, Cl, Br, I)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-blue-500 animate-pulse" />
              <span>d-Block Coordination Catalysts (Fe, Co, Pd, Pt...)</span>
            </div>
          </div>

          {/* Interactive Periodic Table Grid of 18 columns */}
          <div className="min-w-[800px] border border-slate-200 dark:border-slate-800 p-4 rounded-3xl bg-slate-900/5 dark:bg-slate-950/40 relative">
            <div className="grid grid-cols-18 gap-2" style={{ gridTemplateColumns: 'repeat(18, minmax(0, 1fr))' }}>
              {gridCells.map((row, rIdx) => (
                <React.Fragment key={rIdx}>
                  {row.map((cell, cIdx) => {
                    if (!cell) {
                      return <div key={`${rIdx}-${cIdx}`} className="aspect-square" />;
                    }

                    // Check if it's currently mapped/active in our database
                    const activeMeta = CHEMISTRY_ELEMENTS_DATA.find(el => el.symbol === cell.symbol);
                    const isSelected = selectedSymbol === cell.symbol;

                    let colorClass = "bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400 opacity-25";
                    let hoverClass = "";

                    if (activeMeta) {
                      colorClass = isSelected
                        ? "bg-indigo-600 border-indigo-600 text-white shadow-lg scale-110 z-10"
                        : activeMeta.category === 'organic-backbone' ? "bg-indigo-500/10 border-indigo-500 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-500/25" :
                          activeMeta.category === 'organic-modifier' ? "bg-purple-500/10 border-purple-500 text-purple-600 dark:text-purple-400 hover:bg-purple-500/25" :
                          activeMeta.category === 's-block-metal' ? "bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/25" :
                          activeMeta.category === 'halogen' ? "bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-400 hover:bg-amber-500/25" :
                          "bg-blue-500/10 border-blue-500 text-blue-600 dark:text-blue-400 hover:bg-blue-500/25";
                      
                      hoverClass = "cursor-pointer active:scale-95";
                    }

                    return (
                      <button
                        key={`${cell.symbol}-${cell.atomicNumber}`}
                        onClick={() => {
                          if (activeMeta) {
                            setSelectedSymbol(cell.symbol);
                            showNotification?.(`Loaded detailed real-world mappings for ${activeMeta.name} (${activeMeta.symbol})`, 'info');
                          }
                        }}
                        disabled={!activeMeta}
                        className={cn(
                          "aspect-square rounded-xl border flex flex-col items-center justify-between p-1 text-[10px] font-black select-none transition-all",
                          colorClass,
                          hoverClass
                        )}
                        title={activeMeta ? `${activeMeta.name} (${activeMeta.symbol})` : `${cell.symbol} - Reference only`}
                      >
                        <div className="w-full flex justify-between items-center px-0.5">
                          <span className="text-[7px] font-mono opacity-60 leading-none">{cell.atomicNumber}</span>
                          {activeMeta && (
                            <span className="w-1 h-1 rounded-full bg-indigo-500 animate-ping block" />
                          )}
                        </div>
                        <span className="text-sm font-black tracking-tight leading-none mb-0.5">{cell.symbol}</span>
                        <span className="text-[7px] opacity-70 font-bold truncate max-w-full leading-none">
                          {activeMeta ? activeMeta.name.substring(0, 5) : cell.symbol}
                        </span>
                      </button>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Quick List for filtered ones (mobile-friendly fallback & robust search helper) */}
          <div className="space-y-2">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Layers size={14} />
              Filtered Chemistry Database ({filteredElementsList.length})
            </h3>
            <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1 bg-slate-50 dark:bg-slate-900/20 rounded-2xl border border-slate-200/50 dark:border-slate-800/80">
              {filteredElementsList.map((el) => {
                const isSelected = selectedSymbol === el.symbol;
                return (
                  <button
                    key={el.symbol}
                    onClick={() => {
                      setSelectedSymbol(el.symbol);
                      showNotification?.(`Loaded detailed real-world mappings for ${el.name} (${el.symbol})`, 'info');
                    }}
                    className={cn(
                      "px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer active:scale-95 flex items-center gap-1.5",
                      isSelected
                        ? "bg-indigo-600 border-indigo-600 text-white shadow-md"
                        : theme === 'dark'
                          ? "bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700"
                          : "bg-white border-slate-200 text-slate-700 hover:border-slate-300"
                    )}
                  >
                    <span className="text-[10px] font-mono opacity-60">Z={el.atomicNumber}</span>
                    <span>{el.symbol}</span>
                    <span className="text-[10px] opacity-60 font-medium">({el.name})</span>
                  </button>
                );
              })}
              {filteredElementsList.length === 0 && (
                <div className="text-center py-4 text-xs text-slate-400 font-bold w-full">
                  No elements match active search filters. Try resetting block or focus.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right column: Interactive real-world application dashboard */}
        <div className="lg:col-span-4 space-y-4">
          <div className={cn(
            "p-5 rounded-3xl border flex flex-col justify-between shadow-md relative overflow-hidden",
            theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
          )}>
            {/* Subtle background decoration */}
            <div className="absolute right-3 top-3 w-20 h-20 bg-indigo-500/5 rounded-full blur-2xl" />

            {/* Element Header */}
            <div className="flex justify-between items-start border-b pb-4 border-dashed border-slate-200 dark:border-slate-800 mb-4">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-14 h-14 rounded-2xl border-2 flex flex-col items-center justify-center font-black relative shadow-sm",
                  activeElement.category === 'organic-backbone' ? "bg-indigo-500/10 border-indigo-500 text-indigo-500" :
                  activeElement.category === 'organic-modifier' ? "bg-purple-500/10 border-purple-500 text-purple-500" :
                  activeElement.category === 's-block-metal' ? "bg-emerald-500/10 border-emerald-500 text-emerald-500" :
                  activeElement.category === 'halogen' ? "bg-amber-500/10 border-amber-500 text-amber-500" :
                  "bg-blue-500/10 border-blue-500 text-blue-500"
                )}>
                  <span className="text-[8px] font-mono absolute top-0.5 left-1 opacity-60">Z={activeElement.atomicNumber}</span>
                  <span className="text-xl tracking-tight leading-none mt-2">{activeElement.symbol}</span>
                  <span className="text-[7px] uppercase font-black tracking-widest opacity-60 mt-0.5 block">{activeElement.block}-block</span>
                </div>
                <div>
                  <h3 className="text-lg font-black tracking-tight">{activeElement.name}</h3>
                  <div className="flex gap-1.5 mt-0.5">
                    <span className={cn(
                      "text-[9px] uppercase font-bold px-1.5 py-0.2 rounded border",
                      theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-100 border-slate-200"
                    )}>
                      Period {activeElement.period}
                    </span>
                    <span className={cn(
                      "text-[9px] uppercase font-bold px-1.5 py-0.2 rounded border",
                      theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-100 border-slate-200"
                    )}>
                      Group {activeElement.group}
                    </span>
                  </div>
                </div>
              </div>

              <span className={cn(
                "text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border leading-none",
                activeElement.category === 'organic-backbone' ? "bg-indigo-500/10 text-indigo-500 border-indigo-500/20" :
                activeElement.category === 'organic-modifier' ? "bg-purple-500/10 text-purple-500 border-purple-500/20" :
                activeElement.category === 's-block-metal' ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" :
                activeElement.category === 'halogen' ? "bg-amber-500/10 text-amber-500 border-amber-500/20" :
                "bg-blue-500/10 text-blue-500 border-blue-500/20"
              )}>
                {activeElement.category.replace(/-/g, ' ')}
              </span>
            </div>

            {/* Applications List */}
            <div className="space-y-4">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-1">
                  Organic Chemistry Applications:
                </span>
                <div className={cn(
                  "p-3 rounded-xl border space-y-2 text-xs",
                  theme === 'dark' ? "bg-slate-900/50 border-slate-850" : "bg-slate-50 border-slate-150"
                )}>
                  {activeElement.organicApplications.map((app, i) => (
                    <div key={i} className="flex gap-2 items-start">
                      <div className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5 flex-shrink-0" />
                      <p className="text-slate-600 dark:text-slate-300 leading-relaxed font-semibold">{app}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-1">
                  Coordination Chemistry Connections:
                </span>
                <div className={cn(
                  "p-3 rounded-xl border space-y-2 text-xs",
                  theme === 'dark' ? "bg-slate-900/50 border-slate-850" : "bg-slate-50 border-slate-150"
                )}>
                  {activeElement.coordinationApplications.map((app, i) => (
                    <div key={i} className="flex gap-2 items-start">
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 flex-shrink-0" />
                      <p className="text-slate-600 dark:text-slate-300 leading-relaxed font-semibold">{app}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-1">
                  Notable Complexes & Reagents:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {activeElement.notableComplexesAndReagents.map((complex, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-xl bg-indigo-500/5 border border-indigo-500/20 text-[11px] font-black font-mono text-indigo-600 dark:text-indigo-400"
                    >
                      {complex}
                    </span>
                  ))}
                </div>
              </div>

              <div className={cn(
                "p-3.5 rounded-2xl border text-xs leading-relaxed font-medium bg-amber-500/5 border-amber-500/10 text-slate-500 dark:text-slate-400 flex gap-2 items-start",
              )}>
                <Info size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
                <p>{activeElement.summary}</p>
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
