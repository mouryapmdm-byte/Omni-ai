import React, { useState } from 'react';
import { 
  Briefcase, TrendingUp, DollarSign, Award, ArrowRight, 
  CheckCircle2, Sparkles, Code, Cpu, ShieldCheck, Compass
} from 'lucide-react';
import { cn } from '../lib/utils';

interface CareerPath {
  id: string;
  title: string;
  industry: string;
  connectedSubjects: string[];
  medianSalaryUsd: string;
  growthRate: string;
  keySkills: string[];
  practicalPortfolioProject: string;
  microCredential: { name: string; issuer: string; badgeCode: string };
}

interface Props {
  theme?: 'light' | 'dark';
  currentSubject?: string;
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  onRewardXp?: (xp: number) => void;
}

export const CareerPathwaysHub: React.FC<Props> = ({
  theme = 'light',
  currentSubject = 'Physics',
  showNotification,
  onRewardXp
}) => {
  const [selectedPathId, setSelectedPathId] = useState('quantum_engineer');

  const careerPaths: CareerPath[] = [
    {
      id: 'quantum_engineer',
      title: 'Quantum Hardware & Algorithm Engineer',
      industry: 'DeepTech & Quantum Computing',
      connectedSubjects: ['Physics: Electromagnetism & Optics', 'Math: Linear Algebra & Complex Numbers', 'Computer Science'],
      medianSalaryUsd: '$165,000 / yr',
      growthRate: '+34% (Next 5 Yrs)',
      keySkills: ['Superconducting Qubits', 'Bloch Sphere Mathematics', 'Qiskit Python', 'Microwave Control Lines'],
      practicalPortfolioProject: 'Simulate a 5-qubit Grover search algorithm or Bell State entanglement circuit using Qiskit.',
      microCredential: {
        name: 'Quantum Foundations Certified Associate',
        issuer: 'Professor Clarity Global Academy',
        badgeCode: 'CLARITY-QC-2026-X89'
      }
    },
    {
      id: 'ai_biomedical',
      title: 'AI Biomedical & Protein Folding Scientist',
      industry: 'Biotech & Computational Medicine',
      connectedSubjects: ['Biology: Molecular Genetics', 'Chemistry: Organic Structures', 'Machine Learning'],
      medianSalaryUsd: '$155,000 / yr',
      growthRate: '+28% (High Demand)',
      keySkills: ['AlphaFold Analysis', 'PyMOL 3D Modeling', 'CRISPR Target Design', 'Pharmacokinetics'],
      practicalPortfolioProject: 'Model a novel small-molecule enzyme inhibitor docking into a targeted viral capsid receptor.',
      microCredential: {
        name: 'Computational Structural Biology Specialist',
        issuer: 'Professor Clarity Global Academy',
        badgeCode: 'CLARITY-BIO-2026-M44'
      }
    },
    {
      id: 'clean_energy_tech',
      title: 'Renewable Photovoltaics & Battery Architect',
      industry: 'Climate Tech & Sustainable Energy',
      connectedSubjects: ['Physics: Thermodynamics & Semiconductors', 'Chemistry: Electrochemistry', 'Material Science'],
      medianSalaryUsd: '$140,000 / yr',
      growthRate: '+32% (Critical Need)',
      keySkills: ['Perovskite Solar Cells', 'Lithium-Ion Cathode Chemistries', 'Grid Scale Inverters', 'Solid-State Electrolytes'],
      practicalPortfolioProject: 'Design an electrochemical model for a high-efficiency sodium-ion cathode battery cell.',
      microCredential: {
        name: 'Clean Energy & Battery Systems Engineer',
        issuer: 'Professor Clarity Global Academy',
        badgeCode: 'CLARITY-ENG-2026-E72'
      }
    }
  ];

  const currentPath = careerPaths.find(p => p.id === selectedPathId) || careerPaths[0];
  const isDark = theme === 'dark';

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Top Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md">
            <Briefcase size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Career & Skill-Based Pathways</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Learn to Earn
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Connecting classroom formulas directly to high-impact 2026+ industry careers & micro-credentials
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            onRewardXp?.(100);
            showNotification?.(`Enrolled in ${currentPath.title} Career Track! (+100 XP)`, "success");
          }}
          className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-lg text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
        >
          <Award size={14} /> Enroll in Track
        </button>
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Career Selection Horizontal Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {careerPaths.map((p) => {
            const isSelected = selectedPathId === p.id;
            return (
              <div
                key={p.id}
                onClick={() => setSelectedPathId(p.id)}
                className={cn(
                  "p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3",
                  isSelected
                    ? (isDark ? "bg-emerald-950/40 border-emerald-500 ring-2 ring-emerald-500/20" : "bg-emerald-50 border-emerald-400 ring-2 ring-emerald-400/20")
                    : (isDark ? "bg-slate-950/60 border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm")
                )}
              >
                <div className="space-y-1">
                  <span className="text-[10px] font-black uppercase text-emerald-400">
                    {p.industry}
                  </span>
                  <h4 className="text-sm font-bold text-slate-100">{p.title}</h4>
                </div>

                <div className="flex items-center justify-between text-xs font-semibold text-slate-300 pt-2 border-t border-slate-800/60">
                  <span className="text-emerald-400 font-bold">{p.medianSalaryUsd}</span>
                  <span className="text-teal-300 font-mono text-[11px]">{p.growthRate}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Detailed Career Specification */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left 2 Cols: Details & Project Brief */}
          <div className="md:col-span-2 space-y-4">
            <div className={cn(
              "p-6 rounded-2xl border space-y-4",
              isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <h3 className="text-sm font-black uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                <Compass size={16} /> Academic Prerequisites & Connected Subjects
              </h3>
              <div className="flex flex-wrap gap-2">
                {currentPath.connectedSubjects.map((sub, sIdx) => (
                  <span key={sIdx} className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-200 font-medium">
                    {sub}
                  </span>
                ))}
              </div>

              <h3 className="text-sm font-black uppercase tracking-wider text-teal-400 flex items-center gap-2 pt-2">
                <Code size={16} /> Required Industry Competencies
              </h3>
              <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                {currentPath.keySkills.map((skill, kIdx) => (
                  <div key={kIdx} className="p-2 rounded-lg bg-slate-900/60 border border-slate-800/80 flex items-center gap-2 text-slate-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                    {skill}
                  </div>
                ))}
              </div>

              {/* Real World Portfolio Project Brief */}
              <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 space-y-2">
                <div className="flex items-center gap-2 text-indigo-300 text-xs font-black uppercase">
                  <Sparkles size={15} /> Real-World Capstone Portfolio Project:
                </div>
                <p className="text-xs sm:text-sm text-slate-200 font-medium leading-relaxed">
                  {currentPath.practicalPortfolioProject}
                </p>
              </div>
            </div>
          </div>

          {/* Right Col: Verifiable Blockchain Micro-Credential Badge */}
          <div className="space-y-4">
            <div className={cn(
              "p-6 rounded-2xl border space-y-4 text-center flex flex-col items-center justify-between",
              isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-xl shadow-emerald-500/20">
                <Award size={32} />
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">
                  Verifiable Micro-Credential
                </span>
                <h4 className="text-sm font-black text-slate-100">{currentPath.microCredential.name}</h4>
                <p className="text-[11px] text-slate-400">{currentPath.microCredential.issuer}</p>
              </div>

              <div className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[10px] text-slate-400 truncate">
                Hash: {currentPath.microCredential.badgeCode}
              </div>

              <button
                onClick={() => showNotification?.("Micro-credential verified on certificate ledger!", "success")}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <ShieldCheck size={14} className="text-emerald-400" /> Verify Authenticity
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
