import React from "react";
import { CollaborativeWhiteboard } from "./CollaborativeWhiteboard";

interface InteractiveDrawingCanvasProps {
  backgroundImageUrl?: string;
  theme: 'light' | 'dark';
}

/**
 * An interactive canvas component for drawing and annotating.
 * Tutors can render diagrams as background, and users can annotate or draw on top.
 */
export const InteractiveDrawingCanvas: React.FC<InteractiveDrawingCanvasProps> = ({ 
  backgroundImageUrl, 
  theme 
}) => {
  return (
    <div className="relative w-full h-full border rounded-lg overflow-hidden">
      {backgroundImageUrl && (
        <img 
          src={backgroundImageUrl} 
          className="absolute inset-0 w-full h-full object-contain pointer-events-none z-0" 
          alt="Visual Explanation" 
        />
      )}
      <div className="relative z-10 w-full h-full">
        <CollaborativeWhiteboard theme={theme} />
      </div>
    </div>
  );
};
