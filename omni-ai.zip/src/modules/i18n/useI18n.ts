import { createContext, useContext } from 'react';
import { SupportedLanguageCode, LanguagePreference, LanguageMetadata } from './types';

export interface I18nContextValue {
  language: SupportedLanguageCode;
  setLanguage: (lang: SupportedLanguageCode) => void;
  languageMetadata: LanguageMetadata;
  t: (key: string) => string;
  bilingualMode: boolean;
  setBilingualMode: (enabled: boolean) => void;
  toggleBilingualMode: () => void;
  prefersRegionalExamples: boolean;
  setPrefersRegionalExamples: (enabled: boolean) => void;
  dir: 'ltr' | 'rtl';
  formatNumber: (num: number) => string;
  formatCurrency: (amount: number) => string;
  formatDate: (date: Date | string | number) => string;
  preference: LanguagePreference;
  updatePreference: (partial: Partial<LanguagePreference>) => void;
}

export const I18nContext = createContext<I18nContextValue | null>(null);

export const useI18n = (): I18nContextValue => {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
};
