import React, { useState, useEffect, useRef } from 'react';
import { 
  CheckCircle2, 
  AlertCircle, 
  HelpCircle, 
  ArrowRight, 
  Brain, 
  Clock, 
  Zap, 
  Sparkles, 
  SkipForward, 
  Award, 
  TrendingUp, 
  TrendingDown, 
  ChevronRight,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { 
  DiagnosticQuestion, 
  UserResponse, 
  DiagnosticResult 
} from '../modules/diagnostic/types';
import { IRTEngine } from '../modules/diagnostic/irtEngine';
import { QuestionSelector } from '../modules/diagnostic/questionSelector';
import { saveDiagnosticResult, markChapterSkipped } from '../modules/diagnostic/storage';
import { cn } from '../lib/utils';

export interface DiagnosticTestProps {
  chapterId?: string;
  chapterTitle?: string;
  subject?: string;
  studentId?: string;
  onComplete?: (result: DiagnosticResult) => void;
  onSkip?: () => void;
  className?: string;
}

export const DiagnosticTest: React.FC<DiagnosticTestProps> = ({
  chapterId = 'electromagnetism',
  chapterTitle = 'Electromagnetism & AC Theory',
  subject = 'Physics',
  studentId = 'student_default',
  onComplete,
  onSkip,
  className
}) => {
  // State variables
  const [hasStarted, setHasStarted] = useState(false);
  const [selector] = useState(() => new QuestionSelector());
  const [currentQuestion, setCurrentQuestion] = useState<DiagnosticQuestion | null>(null);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  
  // History & IRT tracking
  const [responses, setResponses] = useState<UserResponse[]>([]);
  const [questionHistory, setQuestionHistory] = useState<DiagnosticQuestion[]>([]);
  const [currentTheta, setCurrentTheta] = useState<number>(0.0); // Medium ability start
  const [currentSE, setCurrentSE] = useState<number>(1.0);
  const [questionStartTime, setQuestionStartTime] = useState<number>(Date.now());
  const [lastAnswerCorrect, setLastAnswerCorrect] = useState<boolean | null>(null);

  // 10-minute countdown timer (600 seconds)
  const [secondsRemaining, setSecondsRemaining] = useState<number>(600);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const totalTestStartTime = useRef<number>(Date.now());

  // Timer loop
  useEffect(() => {
    if (!hasStarted) return;

    timerRef.current = setInterval(() => {
      setSecondsRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          finishDiagnostic();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [hasStarted, responses]);

  const handleStartTest = () => {
    setHasStarted(true);
    totalTestStartTime.current = Date.now();
    const firstQ = selector.selectInitialQuestion();
    setCurrentQuestion(firstQ);
    setQuestionHistory([firstQ]);
    setQuestionStartTime(Date.now());
  };

  const handleSelectOption = (index: number) => {
    if (isAnswerSubmitted) return;
    setSelectedOptionIndex(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedOptionIndex === null || !currentQuestion || isAnswerSubmitted) return;

    const isCorrect = selectedOptionIndex === currentQuestion.correctOptionIndex;
    const timeSpent = Math.max(1, Math.round((Date.now() - questionStartTime) / 1000));

    // Update IRT ability using 3PL Bayesian EAP
    const newResponsesList = [
      ...responses,
      {
        questionId: currentQuestion.id,
        subtopicId: currentQuestion.subtopicId,
        selectedOptionIndex,
        isCorrect,
        timeSpentSeconds: timeSpent,
        thetaEstimateAfter: currentTheta,
        standardErrorAfter: currentSE
      }
    ];

    const responsesWithItems = newResponsesList.map(r => ({
      isCorrect: r.isCorrect,
      question: questionHistory.find(q => q.id === r.questionId) || currentQuestion
    }));

    const irtUpdate = IRTEngine.updateAbilityEstimate(responsesWithItems);
    setCurrentTheta(irtUpdate.theta);
    setCurrentSE(irtUpdate.standardError);
    setLastAnswerCorrect(isCorrect);
    setIsAnswerSubmitted(true);

    // Record response
    setResponses(newResponsesList);
  };

  const handleNextQuestion = () => {
    const isStopping = IRTEngine.isStoppingConditionMet(
      responses.length,
      currentSE,
      20,
      12
    );

    if (isStopping || responses.length >= 20) {
      finishDiagnostic();
      return;
    }

    // Adaptive Selection: Correct -> Harder, Wrong -> Easier
    const nextQ = selector.selectNextQuestion(currentTheta, !!lastAnswerCorrect);
    if (!nextQ) {
      finishDiagnostic();
      return;
    }

    setCurrentQuestion(nextQ);
    setQuestionHistory(prev => [...prev, nextQ]);
    setSelectedOptionIndex(null);
    setIsAnswerSubmitted(false);
    setLastAnswerCorrect(null);
    setQuestionStartTime(Date.now());
  };

  const finishDiagnostic = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    const totalDurationSeconds = Math.max(10, Math.round((Date.now() - totalTestStartTime.current) / 1000));

    const result = QuestionSelector.evaluateSession(
      responses,
      questionHistory,
      studentId,
      chapterId,
      chapterTitle,
      subject,
      totalDurationSeconds
    );

    saveDiagnosticResult(result);
    onComplete?.(result);
  };

  const handleSkipTest = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    markChapterSkipped(chapterId, studentId);
    onSkip?.();
  };

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // 1. Introductory Screen
  if (!hasStarted) {
    return (
      <div className={cn("flex flex-col items-center justify-center p-6 sm:p-10 max-w-2xl mx-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl", className)}>
        <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-500 mb-6 border border-indigo-500/20">
          <Brain size={36} className="animate-pulse" />
        </div>

        <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 mb-3">
          Adaptive Knowledge Diagnostic (IRT Powered)
        </span>

        <h2 className="text-2xl sm:text-3xl font-black text-center text-slate-800 dark:text-slate-100 mb-3">
          "Before we start, let me see what you already know"
        </h2>

        <p className="text-sm text-slate-600 dark:text-slate-400 text-center max-w-lg mb-6 leading-relaxed">
          Don't waste 15+ hours relearning topics you've already mastered. This 20-question adaptive diagnostic pinpoint your strengths and creates a personalized learning path skipping mastered concepts.
        </p>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full mb-8">
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-700/60 flex flex-col items-center text-center">
            <Clock size={20} className="text-indigo-500 mb-1.5" />
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">&lt; 10 Minutes</span>
            <span className="text-[11px] text-slate-500">Fast, 20 questions max</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-700/60 flex flex-col items-center text-center">
            <Zap size={20} className="text-amber-500 mb-1.5" />
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Adaptive IRT</span>
            <span className="text-[11px] text-slate-500">Difficulty auto-tunes</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-700/60 flex flex-col items-center text-center">
            <Sparkles size={20} className="text-emerald-500 mb-1.5" />
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Skip Mastered</span>
            <span className="text-[11px] text-slate-500">Save 10-20 lecture hours</span>
          </div>
        </div>

        {/* Action CTAs */}
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full">
          <button
            onClick={handleStartTest}
            className="w-full sm:flex-1 py-3.5 px-6 rounded-xl font-bold text-sm bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-lg shadow-indigo-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            Start 10-Min Diagnostic <ArrowRight size={16} />
          </button>

          <button
            onClick={handleSkipTest}
            className="w-full sm:w-auto py-3.5 px-5 rounded-xl font-semibold text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer flex items-center justify-center gap-1.5"
          >
            <SkipForward size={14} /> Skip & Start from Scratch
          </button>
        </div>
      </div>
    );
  }

  // Guard if question not yet loaded
  if (!currentQuestion) return null;

  const currentQuestionNumber = responses.length + 1;
  const progressPercent = Math.round(((currentQuestionNumber - 1) / 20) * 100);

  // 2. Active Adaptive Test View
  return (
    <div className={cn("flex flex-col p-5 sm:p-7 max-w-3xl mx-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl", className)}>
      {/* Top Bar: Progress, Timer, IRT Gauge */}
      <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div>
          <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            {currentQuestion.subtopicTitle}
          </span>
          <h4 className="text-sm font-black text-slate-800 dark:text-slate-200">
            Question {currentQuestionNumber} of 20
          </h4>
        </div>

        <div className="flex items-center gap-3">
          {/* IRT Difficulty Badge */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            {currentQuestion.difficulty > 0.5 ? (
              <span className="text-amber-500 flex items-center gap-1"><TrendingUp size={13} /> Advanced</span>
            ) : currentQuestion.difficulty < -0.5 ? (
              <span className="text-emerald-500 flex items-center gap-1"><ShieldCheck size={13} /> Foundation</span>
            ) : (
              <span className="text-indigo-500 flex items-center gap-1"><Zap size={13} /> Medium</span>
            )}
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-mono font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
            <Clock size={13} />
            <span>{formatTimer(secondsRemaining)}</span>
          </div>

          {/* Skip diagnostic button */}
          <button
            onClick={handleSkipTest}
            title="Skip diagnostic and start lecture from scratch"
            className="text-[11px] font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition cursor-pointer"
          >
            Skip
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden mt-3 mb-6">
        <div 
          className="bg-indigo-600 h-full transition-all duration-300 ease-out"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Question Card */}
      <div className="mb-6">
        <p className="text-base sm:text-lg font-bold text-slate-800 dark:text-slate-100 leading-relaxed mb-3">
          {currentQuestion.questionText}
        </p>

        {currentQuestion.formulaOrCode && (
          <div className="p-3 my-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 font-mono text-xs text-indigo-600 dark:text-indigo-400 text-center">
            {currentQuestion.formulaOrCode}
          </div>
        )}
      </div>

      {/* 4 Multi-Choice Options */}
      <div className="space-y-3 mb-6">
        {currentQuestion.options.map((opt, idx) => {
          const isSelected = selectedOptionIndex === idx;
          const isCorrect = idx === currentQuestion.correctOptionIndex;

          let optionStyle = "bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:border-indigo-400";
          if (isSelected) {
            optionStyle = "bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 text-indigo-900 dark:text-indigo-100 ring-2 ring-indigo-500/20";
          }
          if (isAnswerSubmitted) {
            if (isCorrect) {
              optionStyle = "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-100";
            } else if (isSelected) {
              optionStyle = "bg-rose-50 dark:bg-rose-950/40 border-rose-500 text-rose-900 dark:text-rose-100";
            }
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={isAnswerSubmitted}
              onClick={() => handleSelectOption(idx)}
              className={cn(
                "w-full p-4 rounded-2xl border text-left text-sm font-medium transition-all flex items-center justify-between gap-3 cursor-pointer disabled:cursor-default",
                optionStyle
              )}
            >
              <div className="flex items-center gap-3">
                <span className={cn(
                  "w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center shrink-0",
                  isSelected ? "bg-indigo-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                )}>
                  {String.fromCharCode(65 + idx)}
                </span>
                <span>{opt}</span>
              </div>

              {isAnswerSubmitted && isCorrect && (
                <CheckCircle2 size={18} className="text-emerald-500 shrink-0" />
              )}
              {isAnswerSubmitted && isSelected && !isCorrect && (
                <AlertCircle size={18} className="text-rose-500 shrink-0" />
              )}
            </button>
          );
        })}
      </div>

      {/* Answer Explanation Box (Shown once submitted) */}
      {isAnswerSubmitted && (
        <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-800/40 mb-6 text-xs text-indigo-950 dark:text-indigo-200 leading-relaxed animate-in fade-in duration-300">
          <span className="font-bold flex items-center gap-1.5 mb-1 text-indigo-700 dark:text-indigo-300">
            <Sparkles size={13} />
            {lastAnswerCorrect ? "Correct! IRT difficulty scaling up:" : "Incorrect. IRT difficulty calibrated down:"}
          </span>
          {currentQuestion.explanation}
        </div>
      )}

      {/* Bottom Controls */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
        <span className="text-xs text-slate-400">
          One-way adaptive diagnostic &bull; No going back
        </span>

        {!isAnswerSubmitted ? (
          <button
            type="button"
            disabled={selectedOptionIndex === null}
            onClick={handleSubmitAnswer}
            className="px-6 py-2.5 rounded-xl font-bold text-sm bg-indigo-600 hover:bg-indigo-500 text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md cursor-pointer flex items-center gap-1.5"
          >
            Submit Answer
          </button>
        ) : (
          <button
            type="button"
            onClick={handleNextQuestion}
            className="px-6 py-2.5 rounded-xl font-bold text-sm bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white transition-all shadow-md cursor-pointer flex items-center gap-1.5"
          >
            {responses.length >= 20 ? "View Personalized Path" : "Next Adaptive Question"} <ChevronRight size={16} />
          </button>
        )}
      </div>
    </div>
  );
};
