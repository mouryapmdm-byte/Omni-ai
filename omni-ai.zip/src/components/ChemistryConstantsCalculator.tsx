import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { 
  Calculator, Copy, Check, Scale, Wind, Activity, BookOpen, 
  HelpCircle, Sparkles, RefreshCw, Layers, ArrowRight, Zap, Info 
} from 'lucide-react';

interface PhysicalConstant {
  name: string;
  symbol: string;
  value: string;
  unit: string;
  category: 'quantum' | 'thermo' | 'electro' | 'general';
  description: string;
}

const PHYSICAL_CONSTANTS: PhysicalConstant[] = [
  {
    name: "Avogadro's Number",
    symbol: "N_A",
    value: "6.02214076 × 10²³",
    unit: "mol⁻¹",
    category: "general",
    description: "The number of constituent particles (usually atoms or molecules) per mole of a substance."
  },
  {
    name: "Ideal Gas Constant",
    symbol: "R",
    value: "8.314462618",
    unit: "J · mol⁻¹ · K⁻¹",
    category: "thermo",
    description: "The constant of proportionality in the ideal gas law, representing work per temperature change per mole."
  },
  {
    name: "Ideal Gas Constant (Atmospheric)",
    symbol: "R_atm",
    value: "0.082057338",
    unit: "L · atm · mol⁻¹ · K⁻¹",
    category: "thermo",
    description: "The gas constant expressed in atmospheric pressure units, commonly used in volumetric gas stoichiometry."
  },
  {
    name: "Planck's Constant",
    symbol: "h",
    value: "6.62607015 × 10⁻³⁴",
    unit: "J · s",
    category: "quantum",
    description: "A fundamental constant relating the energy of light photons to their electromagnetic frequency."
  },
  {
    name: "Faraday's Constant",
    symbol: "F",
    value: "96485.33212",
    unit: "C · mol⁻¹",
    category: "electro",
    description: "The total magnitude of electric charge per one mole of electrons, fundamental to electrochemical reactions."
  },
  {
    name: "Speed of Light",
    symbol: "c",
    value: "2.99792458 × 10⁸",
    unit: "m · s⁻¹",
    category: "quantum",
    description: "The absolute speed of electromagnetic waves in a vacuum."
  },
  {
    name: "Boltzmann Constant",
    symbol: "k_B",
    value: "1.380649 × 10⁻²³",
    unit: "J · K⁻¹",
    category: "thermo",
    description: "Relates the mean kinetic energy of individual gas particles to their thermodynamic temperature."
  },
  {
    name: "Rydberg Constant",
    symbol: "R_H",
    value: "1.0973731568 × 10⁷",
    unit: "m⁻¹",
    category: "quantum",
    description: "Relates to the electromagnetic spectrum emission lines of atomic hydrogen."
  }
];

interface ChemistryConstantsCalculatorProps {
  theme: 'light' | 'dark';
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const ChemistryConstantsCalculator: React.FC<ChemistryConstantsCalculatorProps> = ({
  theme,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'constants' | 'moles' | 'concentration' | 'electrochemistry' | 'gas'>('constants');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Moles / Mass Converter state
  const [molarMass, setMolarMass] = useState<number>(18.015); // Default water (H2O)
  const [massInput, setMassInput] = useState<string>("18.015");
  const [molesInput, setMolesInput] = useState<string>("1.0");
  const [particlesInput, setParticlesInput] = useState<string>("6.022e23");
  const [activeFormula, setActiveFormula] = useState<string>("H₂O");

  // Concentration / Density state
  const [densityInput, setDensityInput] = useState<string>("1.0"); // g/mL
  const [densityUnit, setDensityUnit] = useState<string>("g_ml"); // g/mL, kg/m3, g/L
  const [massPercent, setMassPercent] = useState<string>("37.0"); // e.g., 37% HCl
  const [soluteMolarMass, setSoluteMolarMass] = useState<string>("36.46"); // HCl molar mass
  const [calculatedMolarity, setCalculatedMolarity] = useState<string>("");

  // Electrochemistry / Nernst state
  const [standardPotential, setStandardPotential] = useState<string>("1.10"); // e.g. Zn/Cu cell E0
  const [temperature, setTemperature] = useState<string>("298.15"); // K
  const [reactionQuotient, setReactionQuotient] = useState<string>("0.1"); // Q
  const [electronsTransferred, setElectronsTransferred] = useState<string>("2"); // n
  const [calculatedPotential, setCalculatedPotential] = useState<string>("");

  // Gas unit converter state
  const [gasPressure, setGasPressure] = useState<string>("1.0");
  const [gasPressureUnit, setGasPressureUnit] = useState<'atm' | 'kPa' | 'mmHg' | 'bar' | 'psi'>('atm');
  const [gasVolume, setGasVolume] = useState<string>("22.414");
  const [gasVolumeUnit, setGasVolumeUnit] = useState<'L' | 'mL' | 'm3'>('L');

  const popularMolecules = [
    { name: "Water (H₂O)", formula: "H₂O", mass: 18.015 },
    { name: "Carbon Dioxide (CO₂)", formula: "CO₂", mass: 44.009 },
    { name: "Sodium Chloride (NaCl)", formula: "NaCl", mass: 58.44 },
    { name: "Glucose (C₆H₁₂O₆)", formula: "C₆H₁₂O₆", mass: 180.16 },
    { name: "Ethanol (C₂H₅OH)", formula: "C₂H₅OH", mass: 46.07 },
    { name: "Hydrochloric Acid (HCl)", formula: "HCl", mass: 36.46 },
    { name: "Sulfuric Acid (H₂SO₄)", formula: "H₂SO₄", mass: 98.08 }
  ];

  // Avogadro constant for numerical conversions
  const NA = 6.02214076e23;

  // Handle Molecule template load
  const loadMolecule = (formula: string, mass: number) => {
    setActiveFormula(formula);
    setMolarMass(mass);
    const m = parseFloat(massInput);
    if (!isNaN(m)) {
      const moles = m / mass;
      setMolesInput(moles.toFixed(4));
      setParticlesInput((moles * NA).toExponential(4));
    }
    showNotification?.(`Loaded molar mass for ${formula}: ${mass} g/mol`, 'info');
  };

  // Moles tab reactive updates
  const handleMassChange = (val: string) => {
    setMassInput(val);
    const numeric = parseFloat(val);
    if (!isNaN(numeric) && molarMass > 0) {
      const moles = numeric / molarMass;
      setMolesInput(moles.toFixed(5));
      setParticlesInput((moles * NA).toExponential(4));
    } else {
      setMolesInput("");
      setParticlesInput("");
    }
  };

  const handleMolesChange = (val: string) => {
    setMolesInput(val);
    const numeric = parseFloat(val);
    if (!isNaN(numeric) && molarMass > 0) {
      setMassInput((numeric * molarMass).toFixed(4));
      setParticlesInput((numeric * NA).toExponential(4));
    } else {
      setMassInput("");
      setParticlesInput("");
    }
  };

  // Density & Concentration Calculator
  const solveMolarity = () => {
    const density = parseFloat(densityInput);
    const percent = parseFloat(massPercent);
    const soluteMass = parseFloat(soluteMolarMass);

    if (isNaN(density) || isNaN(percent) || isNaN(soluteMass) || soluteMass <= 0) {
      setCalculatedMolarity("Invalid Input");
      return;
    }

    // Convert density to g/L if necessary
    let densityGL = density;
    if (densityUnit === "g_ml") {
      densityGL = density * 1000;
    } else if (densityUnit === "kg_m3") {
      densityGL = density;
    }

    // Molarity (M) = (Density (g/L) * Mass % / 100) / Molar Mass (g/mol)
    const molarity = (densityGL * (percent / 100)) / soluteMass;
    setCalculatedMolarity(molarity.toFixed(4) + " M (mol/L)");
    showNotification?.("Concentration conversion resolved!", "success");
  };

  // Nernst Equation potential solver
  const solveNernst = () => {
    const e0 = parseFloat(standardPotential);
    const t = parseFloat(temperature);
    const q = parseFloat(reactionQuotient);
    const n = parseFloat(electronsTransferred);

    if (isNaN(e0) || isNaN(t) || isNaN(q) || isNaN(n) || n <= 0 || q <= 0) {
      setCalculatedPotential("Invalid Input");
      return;
    }

    // R = 8.314 J/(mol*K), F = 96485 C/mol
    // E = E0 - (R * T / (n * F)) * ln(Q)
    const R = 8.314462618;
    const F = 96485.33212;
    const term = (R * t) / (n * F);
    const pot = e0 - term * Math.log(q);
    setCalculatedPotential(pot.toFixed(5) + " V");
    showNotification?.("Nernst cell potential updated!", "success");
  };

  useEffect(() => {
    solveMolarity();
  }, [densityInput, densityUnit, massPercent, soluteMolarMass]);

  useEffect(() => {
    solveNernst();
  }, [standardPotential, temperature, reactionQuotient, electronsTransferred]);

  const copyConstant = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    showNotification?.(`Copied ${text} to clipboard!`, 'success');
    setTimeout(() => setCopiedIndex(null), 1500);
  };

  // Pressure unit conversion helpers
  const getPressureInAllUnits = (val: string, source: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return {};

    // First convert to ATM
    let atm = num;
    if (source === 'kPa') atm = num / 101.325;
    else if (source === 'mmHg') atm = num / 760;
    else if (source === 'bar') atm = num / 1.01325;
    else if (source === 'psi') atm = num / 14.6959;

    return {
      atm: atm.toFixed(4),
      kPa: (atm * 101.325).toFixed(3),
      mmHg: (atm * 760).toFixed(2),
      bar: (atm * 1.01325).toFixed(4),
      psi: (atm * 14.6959).toFixed(3)
    };
  };

  const pressureConversions = getPressureInAllUnits(gasPressure, gasPressureUnit);

  return (
    <div className={cn(
      "w-full h-full flex flex-col p-6 md:p-8 space-y-6 overflow-y-auto selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-800"
    )}>
      
      {/* Title Header banner */}
      <div className={cn(
        "p-6 rounded-3xl border flex flex-col lg:flex-row lg:items-center justify-between gap-6 shadow-md transition-all",
        theme === 'dark' ? "bg-gradient-to-r from-slate-950/80 via-slate-900 to-indigo-950/50 border-slate-800" : "bg-gradient-to-r from-white via-indigo-50/20 to-indigo-50/40 border-slate-200/80"
      )}>
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-violet-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 flex-shrink-0">
            <Calculator size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                STOICHIOMETRY & ELECTROCHEMICAL CALCULATORS
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Physical Constants & Unit Converters
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Explore molecular weight mole counters, solution density-to-molarity solvers, Nernst equation electrochemistry cells, gas laws, and standard fundamental chemistry constant tables.
            </p>
          </div>
        </div>
      </div>

      {/* Tabs Menu navigation */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        {[
          { id: 'constants', label: 'Physical Constants', icon: BookOpen },
          { id: 'moles', label: 'Moles & Stoichiometry', icon: Scale },
          { id: 'concentration', label: 'Density & Molarity', icon: Layers },
          { id: 'electrochemistry', label: 'Electrochemistry Cell (Nernst)', icon: Zap },
          { id: 'gas', label: 'Gas pressure laws', icon: Wind }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition active:scale-95 cursor-pointer border",
                isActive
                  ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10"
                  : theme === 'dark'
                    ? "bg-slate-900/40 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700"
                    : "bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300"
              )}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Main Sandbox Canvas Workspace Panels */}
      <div className="grid grid-cols-1 gap-6">
        <AnimatePresence mode="wait">
          
          {/* Active Tab: PHYSICAL CONSTANTS TABLE */}
          {activeTab === 'constants' && (
            <motion.div
              key="constants"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4"
            >
              {PHYSICAL_CONSTANTS.map((item, index) => (
                <div 
                  key={index}
                  className={cn(
                    "p-5 rounded-2xl border flex flex-col justify-between gap-4 group transition-all hover:scale-[1.01]",
                    theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className={cn(
                        "text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border leading-none",
                        item.category === 'quantum' ? "bg-purple-500/10 text-purple-500 border-purple-500/20" :
                        item.category === 'thermo' ? "bg-amber-500/10 text-amber-500 border-amber-500/20" :
                        item.category === 'electro' ? "bg-blue-500/10 text-blue-500 border-blue-500/20" :
                        "bg-slate-500/10 text-slate-500 border-slate-500/20"
                      )}>
                        {item.category}
                      </span>
                      <span className="font-mono text-xs font-black text-slate-400 dark:text-slate-500">
                        {item.symbol}
                      </span>
                    </div>

                    <h3 className="text-sm font-black text-slate-800 dark:text-slate-100">{item.name}</h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed min-h-[48px]">
                      {item.description}
                    </p>
                  </div>

                  <div className={cn(
                    "p-3 rounded-xl flex items-center justify-between gap-3 text-xs border border-dashed",
                    theme === 'dark' ? "bg-slate-900/50 border-slate-800/80" : "bg-slate-50 border-slate-150"
                  )}>
                    <div className="truncate">
                      <span className="font-mono font-extrabold text-indigo-600 dark:text-indigo-400 block truncate">{item.value}</span>
                      <span className="text-[10px] text-slate-400 font-medium">{item.unit}</span>
                    </div>
                    <button
                      onClick={() => copyConstant(item.value, index)}
                      className={cn(
                        "p-2 rounded-lg border transition active:scale-95 cursor-pointer flex-shrink-0",
                        theme === 'dark' 
                          ? "border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white" 
                          : "border-slate-200 hover:bg-slate-100 text-slate-500 hover:text-slate-800"
                      )}
                      title="Copy numerical constant value"
                    >
                      {copiedIndex === index ? <Check size={12} className="text-emerald-500" /> : <Copy size={12} />}
                    </button>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {/* Active Tab: MOLAR MASS & MOLAR CONVERSION */}
          {activeTab === 'moles' && (
            <motion.div
              key="moles"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6"
            >
              {/* Left Controls column */}
              <div className="lg:col-span-4 space-y-4">
                <div className={cn(
                  "p-5 rounded-2xl border space-y-4",
                  theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                )}>
                  <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-1.5">
                    <Scale size={16} className="text-indigo-500" />
                    Compound Template Molar Mass
                  </h3>
                  
                  <div className="grid grid-cols-1 gap-1.5">
                    {popularMolecules.map((molecule, i) => (
                      <button
                        key={i}
                        onClick={() => loadMolecule(molecule.formula, molecule.mass)}
                        className={cn(
                          "px-3 py-2 text-xs rounded-xl border text-left flex items-center justify-between transition active:scale-[0.99] cursor-pointer",
                          activeFormula === molecule.formula
                            ? "bg-indigo-600/10 border-indigo-500/50 text-indigo-600 dark:text-indigo-400 font-bold"
                            : theme === 'dark'
                              ? "bg-slate-900/40 border-slate-850 text-slate-300 hover:border-slate-700 hover:bg-slate-800/40"
                              : "bg-slate-50 border-slate-150 text-slate-700 hover:border-slate-300 hover:bg-slate-100"
                        )}
                      >
                        <span>{molecule.name}</span>
                        <span className="font-mono font-extrabold text-[10px] opacity-65">{molecule.mass} g/mol</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Calculator column */}
              <div className="lg:col-span-8 space-y-4">
                <div className={cn(
                  "p-6 rounded-2xl border space-y-6",
                  theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                )}>
                  <div className="flex justify-between items-center border-b pb-4 border-dashed border-slate-200 dark:border-slate-800">
                    <div>
                      <h3 className="text-sm font-black uppercase tracking-wider">Dynamic Moles Converter</h3>
                      <p className="text-xs text-slate-400 mt-0.5">Changing values automatically computes across remaining fields</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 dark:text-indigo-400">
                      <span className="text-[10px] font-bold block uppercase tracking-wider">Active Substance</span>
                      <span className="text-xs font-black block font-mono text-center">{activeFormula}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    
                    {/* Input Substrate Molar Mass */}
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Active Compound Molar Mass (g/mol)
                      </label>
                      <input 
                        type="number"
                        value={molarMass}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          setMolarMass(val || 0);
                          setActiveFormula("Custom");
                        }}
                        className={cn(
                          "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                    </div>

                    {/* Mass weight */}
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Total Mass (grams)
                      </label>
                      <input 
                        type="number"
                        value={massInput}
                        onChange={(e) => handleMassChange(e.target.value)}
                        placeholder="Weight in g"
                        className={cn(
                          "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                    </div>

                    {/* Total Moles */}
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Amount of Substance (moles)
                      </label>
                      <input 
                        type="number"
                        value={molesInput}
                        onChange={(e) => handleMolesChange(e.target.value)}
                        placeholder="Moles in mol"
                        className={cn(
                          "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                    </div>

                    {/* Total molecules */}
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Number of constituent Molecules
                      </label>
                      <div className={cn(
                        "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold font-mono opacity-80 flex items-center justify-between",
                        theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-slate-100 border-slate-200"
                      )}>
                        <span>{particlesInput || "0.0"}</span>
                        <span className="text-[10px] text-slate-400">molecules</span>
                      </div>
                    </div>

                  </div>

                  {/* Calculations breakdown explanations */}
                  <div className={cn(
                    "p-4 rounded-xl border text-xs space-y-2 leading-relaxed",
                    theme === 'dark' ? "bg-slate-900/30 border-slate-800" : "bg-slate-50 border-slate-200"
                  )}>
                    <div className="flex items-center gap-1.5 font-bold text-indigo-600 dark:text-indigo-400">
                      <Info size={14} />
                      <span>Formulations applied:</span>
                    </div>
                    <ul className="list-disc pl-5 space-y-1 font-mono text-slate-500 dark:text-slate-400">
                      <li>Moles = Mass (g) / Molar Mass (g/mol)</li>
                      <li>Constituent Molecules = Moles × (6.022 × 10²³)</li>
                    </ul>
                  </div>

                </div>
              </div>
            </motion.div>
          )}

          {/* Active Tab: DENSITY & CONCENTRATION/MOLARITY */}
          {activeTab === 'concentration' && (
            <motion.div
              key="concentration"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              {/* Density & Concentration Inputs */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-4 shadow-sm",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
              )}>
                <div className="flex items-center gap-2 border-b pb-3 border-dashed border-slate-200 dark:border-slate-800">
                  <Layers size={16} className="text-indigo-500" />
                  <h3 className="text-sm font-black uppercase tracking-wider">Solution Concentration Variables</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Solution Density
                    </label>
                    <div className="flex gap-2">
                      <input 
                        type="number"
                        value={densityInput}
                        onChange={(e) => setDensityInput(e.target.value)}
                        className={cn(
                          "flex-1 px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                      <select
                        value={densityUnit}
                        onChange={(e) => setDensityUnit(e.target.value)}
                        className={cn(
                          "px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      >
                        <option value="g_ml">g/mL (g/cm³)</option>
                        <option value="kg_m3">g/L</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Solute Weight Percentage (w/w %)
                    </label>
                    <input 
                      type="number"
                      value={massPercent}
                      onChange={(e) => setMassPercent(e.target.value)}
                      placeholder="e.g. 37.0"
                      className={cn(
                        "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                        theme === 'dark' 
                          ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                          : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                      )}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Solute Molar Mass (g/mol)
                    </label>
                    <input 
                      type="number"
                      value={soluteMolarMass}
                      onChange={(e) => setSoluteMolarMass(e.target.value)}
                      placeholder="e.g. 36.46"
                      className={cn(
                        "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                        theme === 'dark' 
                          ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                          : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                      )}
                    />
                  </div>
                </div>
              </div>

              {/* Conversion Output display panel */}
              <div className={cn(
                "p-6 rounded-2xl border flex flex-col justify-between gap-6 shadow-sm",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
              )}>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                    Molarity Conversion Results
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Ideal for standard stock solutions preparation in laboratory research.
                  </p>
                </div>

                <div className="py-6 flex flex-col items-center justify-center bg-indigo-500/5 rounded-2xl border border-dashed border-indigo-500/20">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Calculated Molarity</span>
                  <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400 font-mono">
                    {calculatedMolarity}
                  </span>
                </div>

                <div className="space-y-3.5 text-xs">
                  <div className="flex gap-2.5">
                    <div className="w-5 h-5 bg-indigo-500/10 text-indigo-500 rounded-md flex items-center justify-center font-bold font-mono">1</div>
                    <p className="text-slate-500 dark:text-slate-400">
                      <strong>Molarity (M)</strong> measures moles of solute per liter of solution.
                    </p>
                  </div>
                  <div className="flex gap-2.5">
                    <div className="w-5 h-5 bg-indigo-500/10 text-indigo-500 rounded-md flex items-center justify-center font-bold font-mono">2</div>
                    <p className="text-slate-500 dark:text-slate-400">
                      Derived formula: <code className="font-mono text-xs text-indigo-500 bg-indigo-500/5 px-1 py-0.5 rounded">M = (Density × Weight% × 10) / Solute Molar Mass</code>
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Active Tab: NERNST CELL POTENTIAL SOLVER */}
          {activeTab === 'electrochemistry' && (
            <motion.div
              key="electrochemistry"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              {/* Nernst Inputs */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-4 shadow-sm",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
              )}>
                <div className="flex items-center gap-2 border-b pb-3 border-dashed border-slate-200 dark:border-slate-800">
                  <Zap size={16} className="text-indigo-500" />
                  <h3 className="text-sm font-black uppercase tracking-wider">Electrochemical Cell Metrics</h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Standard Potential E⁰ (V)
                    </label>
                    <input 
                      type="number"
                      step="0.01"
                      value={standardPotential}
                      onChange={(e) => setStandardPotential(e.target.value)}
                      className={cn(
                        "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                        theme === 'dark' 
                          ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                          : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                      )}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Electrons Transferred (n)
                    </label>
                    <input 
                      type="number"
                      min="1"
                      value={electronsTransferred}
                      onChange={(e) => setElectronsTransferred(e.target.value)}
                      className={cn(
                        "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                        theme === 'dark' 
                          ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                          : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                      )}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Cell Temperature (K)
                    </label>
                    <input 
                      type="number"
                      value={temperature}
                      onChange={(e) => setTemperature(e.target.value)}
                      className={cn(
                        "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                        theme === 'dark' 
                          ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                          : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                      )}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Reaction Quotient (Q)
                    </label>
                    <input 
                      type="number"
                      value={reactionQuotient}
                      onChange={(e) => setReactionQuotient(e.target.value)}
                      className={cn(
                        "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                        theme === 'dark' 
                          ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                          : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                      )}
                    />
                  </div>
                </div>
              </div>

              {/* Nernst Output displaying formula step details */}
              <div className={cn(
                "p-6 rounded-2xl border flex flex-col justify-between gap-6 shadow-sm",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
              )}>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                    Real-Time Potential (E_cell)
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Computed via the thermodynamic standard Nernst equation loop
                  </p>
                </div>

                <div className="py-6 flex flex-col items-center justify-center bg-amber-500/5 rounded-2xl border border-dashed border-amber-500/20">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Calculated Non-Standard potential</span>
                  <span className="text-2xl font-black text-amber-500 font-mono">
                    {calculatedPotential}
                  </span>
                </div>

                <div className={cn(
                  "p-4 rounded-xl border text-xs font-mono space-y-1 text-slate-500 dark:text-slate-400 leading-normal",
                  theme === 'dark' ? "bg-slate-900/30 border-slate-800" : "bg-slate-50 border-slate-200"
                )}>
                  <div className="font-bold text-slate-700 dark:text-slate-300 border-b pb-1 mb-2 border-dashed border-slate-200 dark:border-slate-800">
                    Nernst Equation Formulation:
                  </div>
                  <div>E = E⁰ - (RT / nF) × ln(Q)</div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    Where R = 8.314 J/(mol·K), F = 96485 C/mol, T is Temperature in K, Q is reaction quotient.
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Active Tab: GAS LAWS AND PRESSURE UNIT CONVERTER */}
          {activeTab === 'gas' && (
            <motion.div
              key="gas"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              <div className={cn(
                "p-6 rounded-2xl border space-y-4 shadow-sm",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
              )}>
                <div className="flex items-center gap-2 border-b pb-3 border-dashed border-slate-200 dark:border-slate-800">
                  <Wind size={16} className="text-indigo-500" />
                  <h3 className="text-sm font-black uppercase tracking-wider">Gas Pressure Parameters</h3>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Enter Pressure Value
                    </label>
                    <div className="flex gap-2">
                      <input 
                        type="number"
                        value={gasPressure}
                        onChange={(e) => setGasPressure(e.target.value)}
                        className={cn(
                          "flex-1 px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                      <select
                        value={gasPressureUnit}
                        onChange={(e) => setGasPressureUnit(e.target.value as any)}
                        className={cn(
                          "px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      >
                        <option value="atm">atm (Atmospheres)</option>
                        <option value="kPa">kPa (Kilopascals)</option>
                        <option value="mmHg">mmHg / Torr</option>
                        <option value="bar">bar</option>
                        <option value="psi">psi (lb/in²)</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Display Conversions */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-4 shadow-sm",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
              )}>
                <h3 className="text-xs font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  Pressure Conversions Across Multi-Units
                </h3>

                <div className="space-y-2.5">
                  {[
                    { unit: 'atm', label: 'Atmospheres (atm)' },
                    { unit: 'kPa', label: 'Kilopascals (kPa)' },
                    { unit: 'mmHg', label: 'Torr / mmHg' },
                    { unit: 'bar', label: 'Bar (bar)' },
                    { unit: 'psi', label: 'Pounds per sq in (psi)' }
                  ].map((target) => (
                    <div 
                      key={target.unit}
                      className={cn(
                        "p-3 rounded-xl border flex items-center justify-between font-mono text-xs font-bold",
                        theme === 'dark' ? "bg-slate-900/60 border-slate-800/80" : "bg-slate-50 border-slate-200"
                      )}
                    >
                      <span className="text-slate-400">{target.label}</span>
                      <span className="text-indigo-600 dark:text-indigo-400">
                        {pressureConversions[target.unit as keyof typeof pressureConversions] || "0.0"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>

    </div>
  );
};
