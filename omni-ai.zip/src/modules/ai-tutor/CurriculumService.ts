// ai-tutor/CurriculumService.ts
import { BoardId, ClassLevel, SubjectId, CurriculumContext, IntentType, ExamPattern } from './types';

export interface CurriculumDatabaseEntry {
  subjectName: string;
  chapterId: string;
  chapterName: string;
  topicId: string;
  topicName: string;
  subtopicId?: string;
  subtopicName?: string;
  learningObjectives: string[];
  prerequisites: string[];
  standardFormulas: string[];
}

export class CurriculumService {
  /**
   * Fast syllabus lookup across major STEM and humanities disciplines
   */
  async getCurriculumContext(
    board: BoardId,
    classLevel: ClassLevel,
    subjectId: SubjectId = 'physics',
    topicQuery?: string
  ): Promise<CurriculumDatabaseEntry> {
    const q = (topicQuery || '').toLowerCase();

    // Mathematics - Quadratic / Calculus / Algebra
    if (subjectId === 'mathematics' || q.includes('quadrat') || q.includes('calculus') || q.includes('trig') || q.includes('matrix')) {
      if (q.includes('quadrat')) {
        return {
          subjectName: 'Mathematics',
          chapterId: 'math_ch4_quadratic',
          chapterName: 'Quadratic Equations',
          topicId: 'quadratic_formula',
          topicName: 'Roots of Quadratic Equations and Discriminant',
          subtopicId: 'nature_of_roots',
          subtopicName: 'Nature of Roots & Discriminant Analysis',
          learningObjectives: [
            'Express standard quadratic equation $ax^2 + bx + c = 0$',
            'Apply discriminant $D = b^2 - 4ac$ to determine root nature',
            'Derive roots via quadratic formula $x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$'
          ],
          prerequisites: ['Linear equations', 'Algebraic factorisation', 'Real numbers'],
          standardFormulas: [
            'ax^2 + bx + c = 0',
            'D = b^2 - 4ac',
            'x = \\frac{-b \\pm \\sqrt{D}}{2a}',
            '\\alpha + \\beta = -\\frac{b}{a}',
            '\\alpha \\beta = \\frac{c}{a}'
          ]
        };
      }
      return {
        subjectName: 'Mathematics',
        chapterId: 'math_calculus_limits',
        chapterName: 'Calculus & Functions',
        topicId: 'derivatives',
        topicName: 'Differentiation & Rate of Change',
        learningObjectives: ['Define first principle of derivatives', 'Compute standard polynomial and trigonometric derivatives'],
        prerequisites: ['Functions and Graphs', 'Limits and Continuity'],
        standardFormulas: ['f\'(x) = \\lim_{h \\to 0} \\frac{f(x+h) - f(x)}{h}', '\\frac{d}{dx}(x^n) = n x^{n-1}']
      };
    }

    // Biology - Photosynthesis / Cells / Genetics
    if (subjectId === 'biology' || q.includes('photo') || q.includes('chlorophyll') || q.includes('cell') || q.includes('mitosis')) {
      return {
        subjectName: 'Biology',
        chapterId: 'bio_plant_physio',
        chapterName: 'Photosynthesis in Higher Plants & Life Processes',
        topicId: 'light_reaction_calvin_cycle',
        topicName: 'Mechanism of Photosynthesis and Chloroplast Pigments',
        subtopicId: 'chloroplast_energy_flow',
        subtopicName: 'Light-Dependent Reactions and Calvin Cycle',
        learningObjectives: [
          'Identify the role of chlorophyll pigments and thylakoid membranes',
          'Understand photolysis of water releasing oxygen',
          'Trace CO2 fixation into glucose through the Calvin Cycle'
        ],
        prerequisites: ['Plant cell structure', 'Stomata function', 'Energy transfer (ATP/NADPH)'],
        standardFormulas: [
          '6CO_2 + 6H_2O + \\text{Sunlight} \\xrightarrow{\\text{Chlorophyll}} C_6H_{12}O_6 + 6O_2',
          '2H_2O \\rightarrow 4H^+ + 4e^- + O_2'
        ]
      };
    }

    // Chemistry - Chemical Bonding / Reactions / Periodic Table
    if (subjectId === 'chemistry' || q.includes('bond') || q.includes('reaction') || q.includes('atom') || q.includes('periodic')) {
      return {
        subjectName: 'Chemistry',
        chapterId: 'chem_bonding_structure',
        chapterName: 'Chemical Bonding and Molecular Structure',
        topicId: 'ionic_covalent_bonding',
        topicName: 'Ionic versus Covalent Bonding and Octet Rule',
        learningObjectives: [
          'Differentiate between electrostatic ionic transfer and electron pair sharing in covalent bonds',
          'Predict bond polarity using electronegativity differences',
          'Illustrate Lewis dot structures'
        ],
        prerequisites: ['Atomic structure', 'Valence electrons', 'Electronegativity'],
        standardFormulas: ['\\Delta EN > 1.7 \\implies \\text{Predominantly Ionic}', '\\Delta EN < 1.7 \\implies \\text{Covalent}']
      };
    }

    // Physics - Mechanics / Optics / Electricity (Default STEM)
    return {
      subjectName: 'Physics',
      chapterId: 'phys_laws_of_motion',
      chapterName: 'Laws of Motion and Work-Energy',
      topicId: 'newtons_laws',
      topicName: 'Newton\'s Laws of Motion & Momentum',
      subtopicId: 'second_law_derivation',
      subtopicName: 'Force, Mass, and Acceleration ($F = ma$)',
      learningObjectives: [
        'State Newton\'s Second Law: Rate of change of momentum is proportional to applied force',
        'Derive $F = ma$ for constant mass systems',
        'Apply momentum conservation in elastic and inelastic collisions'
      ],
      prerequisites: ['Vectors and Scalars', 'Kinematics in 1D', 'Inertia'],
      standardFormulas: ['F = \\frac{dp}{dt} = ma', 'p = mv', 'F_{net} = \\sum F_i']
    };
  }

  /**
   * Deterministic verified fallbacks when offline or network fails
   */
  async getFallbackContent(context: CurriculumContext, intent: IntentType): Promise<string> {
    if (intent === 'summarise') {
      return `### Key Takeaways: ${context.topicName}
- **Core Concept**: Governed by standard curriculum objectives for ${context.board} Class ${context.classLevel}.
- **Formulas**: ${context.standardFormulas.join(', ')}
- **High-Yield Exam Tip**: Always write formulas with explicit SI units and state standard assumptions.`;
    }

    if (intent === 'analogy') {
      return `### Real-World Analogy for ${context.topicName}
Think of this process like a kitchen with active recipes:
- Ingredients enter in measured amounts according to balance.
- Energy fuels the transformation into desired products.
- **Where the analogy breaks down**: In natural microscopic systems, quantum rules and thermodynamic equilibria govern the limits rather than simple culinary mixtures.`;
    }

    return `### ${context.topicName} (${context.board} Class ${context.classLevel})
In ${context.subjectName}, this concept explains how fundamental physical principles behave:
- **Core Law**: ${context.standardFormulas[0] || 'Governed by conservation laws.'}
- **Exam Alignment**: Focus on precise terminology, step-by-step reasoning, and labeling clear diagrams.`;
  }
}
