import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Brain, Code, HelpCircle, CornerDownLeft, ArrowRight } from 'lucide-react';
import { PredictiveTerm } from '../data/predictiveDictionary';
import { cn } from '../lib/utils';

interface PredictiveAutocompleteProps {
  suggestions: PredictiveTerm[];
  inputValue: string;
  selectedIndex: number;
  onSelectSuggestion: (term: PredictiveTerm) => void;
  theme: 'dark' | 'light';
  isVisible: boolean;
  onClose?: () => void;
  subject?: string;
  topic?: string;
}

export const PredictiveAutocomplete: React.FC<PredictiveAutocompleteProps> = ({
  suggestions,
  inputValue,
  selectedIndex,
  onSelectSuggestion,
  theme,
  isVisible,
  subject,
  topic
}) => {
  if (!isVisible || suggestions.length === 0) return null;

  const getCategoryBadge = (category: PredictiveTerm['category']) => {
    switch (category) {
      case 'phrase':
        return {
          label: 'Inquiry',
          icon: <HelpCircle size={11} className="text-amber-400" />,
          color: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
        };
      case 'formula':
        return {
          label: 'Formula',
          icon: <Code size={11} className="text-emerald-400" />,
          color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
        };
      case 'concept':
        return {
          label: 'Concept',
          icon: <Brain size={11} className="text-indigo-400" />,
          color: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'
        };
      default:
        return {
          label: 'Term',
          icon: <Sparkles size={11} className="text-purple-400" />,
          color: 'bg-purple-500/10 text-purple-400 border-purple-500/20'
        };
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 8, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 8, scale: 0.98 }}
        transition={{ duration: 0.15, ease: 'easeOut' }}
        className={cn(
          "absolute bottom-full mb-2 left-0 right-0 z-50 rounded-2xl border shadow-2xl p-2 backdrop-blur-xl overflow-hidden max-w-2xl mx-auto",
          theme === 'dark'
            ? "bg-slate-900/95 border-slate-700/60 text-slate-100 shadow-slate-950/80"
            : "bg-white/95 border-slate-200/80 text-slate-900 shadow-slate-300/50"
        )}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-2 py-1 mb-1 border-b border-slate-800/40 text-[10px] font-bold uppercase tracking-wider opacity-75">
          <div className="flex items-center gap-1.5 text-amber-400">
            <Sparkles size={12} className="animate-pulse" />
            <span>Predictive Autocomplete</span>
            {(subject || topic) && (
              <span className="opacity-60 font-mono text-[9px] lowercase border-l border-slate-700/50 pl-1.5 ml-0.5">
                {subject ? `${subject}` : ''}{topic ? ` › ${topic}` : ''}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 font-mono text-[9px] opacity-60">
            <span className="px-1 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">Tab ↹</span>
            <span>or</span>
            <span className="px-1 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">Click</span>
            <span>to complete</span>
          </div>
        </div>

        {/* Suggestions List */}
        <div className="space-y-1 max-h-[220px] overflow-y-auto custom-scrollbar">
          {suggestions.map((item, idx) => {
            const isSelected = idx === selectedIndex;
            const badge = getCategoryBadge(item.category);

            return (
              <button
                key={item.id}
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onSelectSuggestion(item);
                }}
                className={cn(
                  "w-full text-left px-3 py-2 rounded-xl flex items-center justify-between gap-3 text-xs font-medium transition-all duration-150 cursor-pointer group border",
                  isSelected
                    ? (theme === 'dark'
                        ? "bg-indigo-600/30 border-indigo-500/50 text-white shadow-sm"
                        : "bg-indigo-50 border-indigo-200 text-indigo-950 shadow-sm")
                    : (theme === 'dark'
                        ? "border-transparent hover:bg-slate-800/60 text-slate-300 hover:text-white"
                        : "border-transparent hover:bg-slate-100/80 text-slate-700 hover:text-slate-900")
                )}
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <span className={cn("px-1.5 py-0.5 rounded-md border text-[9px] font-bold uppercase tracking-wider shrink-0 flex items-center gap-1", badge.color)}>
                    {badge.icon}
                    <span>{badge.label}</span>
                  </span>
                  <span className="truncate font-sans leading-snug">
                    {item.text}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                  <span className="text-[10px] font-mono opacity-60">Insert</span>
                  <ArrowRight size={12} className="text-indigo-400 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>
            );
          })}
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
