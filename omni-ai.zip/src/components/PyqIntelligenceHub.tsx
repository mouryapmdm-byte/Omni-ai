import React, { useState } from 'react';
import { 
  Database, 
  Flame, 
  TrendingUp, 
  Target, 
  Search, 
  Filter, 
  Calendar, 
  BookOpen, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp,
  Award,
  Sparkles,
  Download,
  Share2
} from 'lucide-react';
import { Heatmap } from '../modules/pyq-intelligence/Heatmap';
import { TrendReport } from '../modules/pyq-intelligence/TrendReport';
import { PriorityList } from '../modules/pyq-intelligence/PriorityList';
import { PyqDatabaseManager, PYQ_DATABASE } from '../modules/pyq-intelligence/pyqDatabase';
import { PYQRecord } from '../modules/pyq-intelligence/types';

interface PyqIntelligenceHubProps {
  isDark?: boolean;
  theme?: string;
  studentId?: string;
  initialSubject?: string;
  showNotification?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
}

export const PyqIntelligenceHub: React.FC<PyqIntelligenceHubProps> = ({
  isDark = true,
  theme,
  studentId = 'student_alex',
  initialSubject,
  showNotification
}) => {
  const darkMode = theme ? theme === 'dark' : isDark;
  const [activeTab, setActiveTab] = useState<'heatmap' | 'trends' | 'priority' | 'repository'>('heatmap');

  // Repository search & filter state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [examFilter, setExamFilter] = useState<string>('all');
  const [subjectFilter, setSubjectFilter] = useState<string>(initialSubject || 'all');
  const [difficultyFilter, setDifficultyFilter] = useState<number | undefined>(undefined);
  const [expandedQuestionId, setExpandedQuestionId] = useState<string | null>(null);

  const filteredQuestions: PYQRecord[] = PyqDatabaseManager.filter({
    examType: examFilter,
    subject: subjectFilter,
    difficulty: difficultyFilter,
    searchQuery: searchQuery
  });

  return (
    <div className={`flex flex-col h-full ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>
      {/* Top Header Bar */}
      <div className={`p-4 border-b flex flex-wrap items-center justify-between gap-4 ${
        darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold">15+ Years PYQ Intelligence & Weightage Engine</h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                CBSE • JEE • NEET • SAT
              </span>
            </div>
            <p className="text-xs opacity-60">High-yield historical pattern analysis, predictive topic forecasts, and custom priority matrix</p>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className={`flex items-center p-1 rounded-xl border ${darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-100 border-slate-300'}`}>
          <button
            onClick={() => setActiveTab('heatmap')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'heatmap'
                ? 'bg-emerald-600 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            15Y Heatmap
          </button>

          <button
            onClick={() => setActiveTab('trends')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'trends'
                ? 'bg-amber-500 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            Trend Alerts & Predictions
          </button>

          <button
            onClick={() => setActiveTab('priority')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'priority'
                ? 'bg-purple-600 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            Priority Matrix
          </button>

          <button
            onClick={() => setActiveTab('repository')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'repository'
                ? 'bg-indigo-600 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Searchable PYQ Bank ({filteredQuestions.length})
          </button>
        </div>
      </div>

      {/* Main Content Body */}
      <div className="flex-1 p-6 overflow-y-auto">
        {activeTab === 'heatmap' && (
          <Heatmap
            isDark={darkMode}
            onSelectChapter={() => setActiveTab('repository')}
          />
        )}

        {activeTab === 'trends' && (
          <TrendReport
            isDark={darkMode}
          />
        )}

        {activeTab === 'priority' && (
          <PriorityList
            isDark={darkMode}
            studentId={studentId}
            onSelectTopicForPractice={() => {
              setActiveTab('repository');
              showNotification?.('Filtering high-yield questions for your urgent chapter', 'info');
            }}
          />
        )}

        {activeTab === 'repository' && (
          <div className="space-y-6">
            {/* Search & Filter Tool */}
            <div className={`p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-4 ${
              darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'
            }`}>
              <div className="flex items-center gap-2 flex-1 min-w-[240px]">
                <div className="relative w-full">
                  <Search className="w-4 h-4 absolute left-3 top-3 opacity-50" />
                  <input
                    type="text"
                    placeholder="Search past questions, concepts, theorems, equations..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`w-full pl-9 pr-4 py-2 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                      darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                    }`}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <select
                  value={examFilter}
                  onChange={(e) => setExamFilter(e.target.value)}
                  className={`px-3 py-2 rounded-xl border text-xs font-semibold focus:outline-none ${
                    darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                >
                  <option value="all">All Exams</option>
                  <option value="cbse-12">CBSE 12th</option>
                  <option value="jee-main">JEE Main</option>
                  <option value="neet">NEET (UG)</option>
                  <option value="sat">SAT Math</option>
                </select>

                <select
                  value={subjectFilter}
                  onChange={(e) => setSubjectFilter(e.target.value)}
                  className={`px-3 py-2 rounded-xl border text-xs font-semibold focus:outline-none ${
                    darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                >
                  <option value="all">All Subjects</option>
                  <option value="Physics">Physics</option>
                  <option value="Chemistry">Chemistry</option>
                  <option value="Mathematics">Mathematics</option>
                  <option value="Biology">Biology</option>
                </select>
              </div>
            </div>

            {/* Questions List */}
            <div className="space-y-3">
              {filteredQuestions.map(q => {
                const isExpanded = expandedQuestionId === q.id;

                return (
                  <div
                    key={q.id}
                    className={`p-5 rounded-2xl border transition-all ${
                      darkMode ? 'bg-slate-900/80 border-slate-800 hover:border-slate-700' : 'bg-white border-slate-200 shadow-sm'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {q.examType.toUpperCase()} • {q.year}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                          {q.chapterName}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300">
                          {q.topicName}
                        </span>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-xs font-bold font-mono text-amber-400">{q.marks} Marks</span>
                        <span className="text-[10px] block opacity-60">Diff: {q.difficulty}/5</span>
                      </div>
                    </div>

                    <p className="text-sm font-medium leading-relaxed my-3">
                      {q.questionText}
                    </p>

                    {/* Question details button */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/40 text-xs">
                      <span className="opacity-60 text-[11px]">
                        Appeared in {q.frequencyCount || 12}+ variations across 15 years
                      </span>
                      <button
                        onClick={() => setExpandedQuestionId(isExpanded ? null : q.id)}
                        className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-semibold text-xs"
                      >
                        {isExpanded ? (
                          <>Hide Solution & Key <ChevronUp className="w-3.5 h-3.5" /></>
                        ) : (
                          <>View Official Answer & Key <ChevronDown className="w-3.5 h-3.5" /></>
                        )}
                      </button>
                    </div>

                    {/* Expanded solution */}
                    {isExpanded && (
                      <div className={`mt-3 p-4 rounded-xl border text-xs leading-relaxed animate-fadeIn ${
                        darkMode ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-200' : 'bg-emerald-50 border-emerald-200 text-emerald-950'
                      }`}>
                        <div className="font-bold mb-1 flex items-center gap-1.5 text-emerald-400">
                          <CheckCircle2 className="w-4 h-4" /> Official Marking Scheme & Derivation Steps:
                        </div>
                        <p className="font-mono text-[11px] leading-relaxed">
                          {q.answerKey}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
