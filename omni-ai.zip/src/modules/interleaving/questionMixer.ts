import { INTERLEAVED_QUESTIONS, InterleavedQuestion } from './interleavedQuestionsData';

// List of ordered chapter IDs for each subject to determine N-1, N-2 and earlier chapters.
export const ORDERED_CHAPTER_IDS: Record<string, string[]> = {
  Mathematics: [
    'relations_functions',
    'inverse_trig',
    'matrices',
    'determinants',
    'continuity_differentiability',
    'applications_derivatives',
    'integrals',
    'applications_integrals',
    'differential_equations',
    'vector_algebra',
    'three_dimensional_geometry',
    'linear_programming',
    'probability'
  ],
  Physics: [
    'electric_charges_fields',
    'electrostatic_potential_capacitance',
    'current_electricity',
    'moving_charges_magnetism',
    'magnetism_matter',
    'electromagnetic_induction',
    'alternating_current',
    'electromagnetic_waves',
    'ray_optics',
    'wave_optics'
  ]
};

/**
 * Maps a human-readable chapter title to its normalized chapterId
 */
export function mapChapterTitleToId(title: string): string {
  if (!title) return 'relations_functions';
  const normalized = title.toLowerCase();
  if (normalized.includes('relation') || normalized.includes('functions')) return 'relations_functions';
  if (normalized.includes('inverse trig') || normalized.includes('trigonometric')) return 'inverse_trig';
  if (normalized.includes('matrices')) return 'matrices';
  if (normalized.includes('determinant')) return 'determinants';
  if (normalized.includes('continuity') || normalized.includes('differentiability')) return 'continuity_differentiability';
  if (normalized.includes('application') && normalized.includes('deriv')) return 'applications_derivatives';
  if (normalized.includes('integrals') && !normalized.includes('application')) return 'integrals';
  if (normalized.includes('application') && normalized.includes('integral')) return 'applications_integrals';
  if (normalized.includes('differential equation')) return 'differential_equations';
  if (normalized.includes('vector')) return 'vector_algebra';
  if (normalized.includes('probability')) return 'probability';

  // Physics mapping
  if (normalized.includes('charges') && normalized.includes('fields')) return 'electric_charges_fields';
  if (normalized.includes('potential') || normalized.includes('capacitance')) return 'electrostatic_potential_capacitance';
  if (normalized.includes('current electricity') || normalized.includes('current')) return 'current_electricity';
  if (normalized.includes('moving charges') || normalized.includes('magnetism')) return 'moving_charges_magnetism';
  if (normalized.includes('ray optics') || normalized.includes('ray')) return 'ray_optics';
  if (normalized.includes('wave optics') || normalized.includes('wave')) return 'wave_optics';

  // Safe defaults
  return 'relations_functions';
}

/**
 * Checks if a chapter has been studied based on completed lessons.
 * Always returns true for the current chapter focus.
 */
export function isChapterStudied(
  chapterId: string,
  currentChapterId: string,
  completedLessons: Record<string, boolean>
): boolean {
  if (chapterId === currentChapterId) return true;
  
  // A chapter is studied if any key starting with the chapterId is marked completed
  const prefix = `${chapterId}_`;
  return Object.keys(completedLessons).some(
    key => key.startsWith(prefix) && completedLessons[key] === true
  );
}

/**
 * Core mixing algorithm to build an interleaved practice session.
 * 
 * Target ratios:
 * - Tier 1: Current Chapter N (60%)
 * - Tier 2: Chapters N-1, N-2 (25%)
 * - Tier 3: Earlier Chapters (15%)
 * 
 * Weights individual questions by:
 * weight = (exam_weightage * 0.4) + (weakness_score * 0.4) + (recency_weight * 0.2)
 * 
 * Constraints:
 * - Never include questions from unstudied chapters.
 * - No more than 2 consecutive questions from the same chapter.
 * - Return a complete session within < 50ms.
 */
export function generateInterleavedSession(options: {
  subject: string;
  currentChapterId: string;
  completedLessons: Record<string, boolean>;
  weaknessScores: Record<string, number>; // topic/concept -> score (0 to 1)
  examWeightages: Record<string, number>; // chapterId -> score (0 to 1)
  lastPracticedTimes: Record<string, number>; // chapterId/concept -> timestamp MS
  sessionSize?: number; // default 10 or 20
}): InterleavedQuestion[] {
  const start = performance.now();
  const {
    subject,
    currentChapterId,
    completedLessons,
    weaknessScores,
    examWeightages,
    lastPracticedTimes,
    sessionSize = 10
  } = options;

  // Get all pre-calibrated questions for this subject. Default to Math if not found/supported.
  const allQuestions = INTERLEAVED_QUESTIONS[subject] || INTERLEAVED_QUESTIONS.Mathematics;
  const chapterOrder = ORDERED_CHAPTER_IDS[subject] || ORDERED_CHAPTER_IDS.Mathematics;

  const currentIdx = chapterOrder.indexOf(currentChapterId);
  
  // Tiers definition
  const tier1Chapters = [currentChapterId];
  const tier2Chapters: string[] = [];
  const tier3Chapters: string[] = [];

  if (currentIdx !== -1) {
    // Tier 2: Chapters N-1 and N-2
    if (currentIdx - 1 >= 0) tier2Chapters.push(chapterOrder[currentIdx - 1]);
    if (currentIdx - 2 >= 0) tier2Chapters.push(chapterOrder[currentIdx - 2]);
    // Tier 3: Earlier chapters
    for (let i = 0; i < currentIdx - 2; i++) {
      tier3Chapters.push(chapterOrder[i]);
    }
  }

  // Filter questions that the student has studied in each tier
  const tier1Pool = allQuestions.filter(q => q.chapterId === currentChapterId);
  
  const tier2Pool = allQuestions.filter(q => 
    tier2Chapters.includes(q.chapterId) && 
    isChapterStudied(q.chapterId, currentChapterId, completedLessons)
  );

  const tier3Pool = allQuestions.filter(q => 
    tier3Chapters.includes(q.chapterId) && 
    isChapterStudied(q.chapterId, currentChapterId, completedLessons)
  );

  // Helper to compute question weights
  const getQuestionWeight = (q: InterleavedQuestion): number => {
    const examWeight = examWeightages[q.chapterId] !== undefined ? examWeightages[q.chapterId] : 0.5;
    const weakness = weaknessScores[q.conceptTested] !== undefined ? weaknessScores[q.conceptTested] : 0.5;
    
    // Recency: longer time since last practiced = higher weight (spaced repetition effect)
    let recencyWeight = 0.5;
    const lastPracticed = lastPracticedTimes[q.conceptTested] || lastPracticedTimes[q.chapterId];
    if (lastPracticed) {
      const msSincePractice = Date.now() - lastPracticed;
      const daysSincePractice = msSincePractice / (1000 * 60 * 60 * 24);
      // Normalized recency weight between 0 and 1, caps at 30 days
      recencyWeight = Math.min(1, daysSincePractice / 30);
    }

    return (examWeight * 0.4) + (weakness * 0.4) + (recencyWeight * 0.2);
  };

  // Sort pools by weight descending
  const scoreAndSortPool = (pool: InterleavedQuestion[]) => {
    return pool
      .map(q => ({ q, weight: getQuestionWeight(q) }))
      .sort((a, b) => b.weight - a.weight);
  };

  const sortedTier1 = scoreAndSortPool(tier1Pool);
  const sortedTier2 = scoreAndSortPool(tier2Pool);
  const sortedTier3 = scoreAndSortPool(tier3Pool);

  // Adaptive Slot Allocation based on availability
  let t1Target = Math.round(sessionSize * 0.60);
  let t2Target = Math.round(sessionSize * 0.25);
  let t3Target = Math.round(sessionSize * 0.15);

  // Handle rounding to ensure they sum to sessionSize
  const diff = sessionSize - (t1Target + t2Target + t3Target);
  t1Target += diff;

  const selectedQuestions: { q: InterleavedQuestion; weight: number }[] = [];

  // 1. Draw from Tier 1 (Current Chapter)
  const t1Selected = sortedTier1.slice(0, t1Target);
  selectedQuestions.push(...t1Selected);

  // 2. Draw from Tier 2 (N-1, N-2)
  let t2Selected = sortedTier2.slice(0, t2Target);
  selectedQuestions.push(...t2Selected);

  // 3. Draw from Tier 3 (Earlier Chapters)
  let t3Selected = sortedTier3.slice(0, t3Target);
  selectedQuestions.push(...t3Selected);

  // If we couldn't meet the target size due to empty pools (e.g., student is on Chapter 1),
  // pull more from Tier 1 or other available pools
  let attempts = 0;
  while (selectedQuestions.length < sessionSize && attempts < 3) {
    const currentSelectedIds = new Set(selectedQuestions.map(item => item.q.id));
    const remainingNeeded = sessionSize - selectedQuestions.length;

    // Try to fill from Tier 1
    const extraT1 = sortedTier1.filter(item => !currentSelectedIds.has(item.q.id)).slice(0, remainingNeeded);
    selectedQuestions.push(...extraT1);

    if (selectedQuestions.length >= sessionSize) break;

    // Try to fill from Tier 2
    const extraT2 = sortedTier2.filter(item => !currentSelectedIds.has(item.q.id)).slice(0, remainingNeeded);
    selectedQuestions.push(...extraT2);

    if (selectedQuestions.length >= sessionSize) break;

    // Try to fill from Tier 3
    const extraT3 = sortedTier3.filter(item => !currentSelectedIds.has(item.q.id)).slice(0, remainingNeeded);
    selectedQuestions.push(...extraT3);

    attempts++;
  }

  // Format list for arranging
  const candidates = selectedQuestions.map(item => item.q);

  // Constraint Arranger: No more than 2 consecutive questions from the same chapter
  const arranged: InterleavedQuestion[] = [];
  const unplaced = [...candidates];

  while (unplaced.length > 0) {
    let forbiddenChapter: string | null = null;
    
    // Check last two placed elements
    if (arranged.length >= 2) {
      const last1 = arranged[arranged.length - 1].chapterId;
      const last2 = arranged[arranged.length - 2].chapterId;
      if (last1 === last2) {
        forbiddenChapter = last1;
      }
    }

    // Find the best candidate that isn't from the forbidden chapter
    let choiceIdx = unplaced.findIndex(q => q.chapterId !== forbiddenChapter);
    
    // Fallback: if no choice but to break constraint, take the first available
    if (choiceIdx === -1) {
      choiceIdx = 0;
    }

    arranged.push(unplaced[choiceIdx]);
    unplaced.splice(choiceIdx, 1);
  }

  const duration = performance.now() - start;
  // Performance reporting in console for debugging/SRE audit
  console.log(`[InterleavedMixer] Generated ${arranged.length} questions in ${duration.toFixed(2)}ms`);

  return arranged;
}
