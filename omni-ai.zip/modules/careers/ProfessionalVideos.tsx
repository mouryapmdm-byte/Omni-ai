export * from '../../src/modules/careers/ProfessionalVideos';
import { ProfessionalVideos } from '../../src/modules/careers/ProfessionalVideos';
export default ProfessionalVideos;
