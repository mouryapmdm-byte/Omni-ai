import { RecommendedScheduleSlot } from './types';

export class ScheduleRecommender {
  public static getRecommendedSlots(): RecommendedScheduleSlot[] {
    return [
      {
        dayName: 'Monday',
        timeRange: '08:30 AM - 10:30 AM',
        startHour: 8,
        subjectRecommendation: 'Mathematics & Complex Physics',
        energyLevel: 'Peak Focus',
        reasoning: 'Peak morning cognitive bandwidth. High accuracy on algebraic & vector derivations.'
      },
      {
        dayName: 'Tuesday',
        timeRange: '09:00 AM - 11:00 AM',
        startHour: 9,
        subjectRecommendation: 'Organic Chemistry & Biology',
        energyLevel: 'Peak Focus',
        reasoning: 'Optimal memory retention window for structural formulas and cycle pathways.'
      },
      {
        dayName: 'Wednesday',
        timeRange: '02:00 PM - 03:30 PM',
        startHour: 14,
        subjectRecommendation: 'Practice Questions & Mock Quizzes',
        energyLevel: 'Steady Endurance',
        reasoning: 'Post-noon steady state. Excellent for speed testing and active problem solving.'
      },
      {
        dayName: 'Thursday',
        timeRange: '09:00 AM - 11:00 AM',
        startHour: 9,
        subjectRecommendation: 'Calculus & Quadratic Theory',
        energyLevel: 'Peak Focus',
        reasoning: 'Sustained focus scores above 90/100 during Thursday morning sessions.'
      },
      {
        dayName: 'Friday',
        timeRange: '04:00 PM - 05:30 PM',
        startHour: 16,
        subjectRecommendation: 'Weekly Summary & Flashcard Review',
        energyLevel: 'Light Review',
        reasoning: 'Low-friction review session before the weekend to consolidate weak concepts.'
      },
      {
        dayName: 'Saturday',
        timeRange: '10:00 AM - 12:00 PM',
        startHour: 10,
        subjectRecommendation: 'Full-Length Chapter Diagnostics',
        energyLevel: 'Peak Focus',
        reasoning: 'Undistracted weekend block for full exam simulation and deep focus.'
      }
    ];
  }

  public static getSmartBreakSuggestions(): { title: string; category: string; duration: string; description: string }[] {
    return [
      {
        title: 'Desk & Neck Release Stretch',
        category: 'Physical',
        duration: '2 Minutes',
        description: 'Gentle shoulder rolls and neck tilts to release tension from sitting.'
      },
      {
        title: '20-20-20 Eye Strain Prevention',
        category: 'Vision Care',
        duration: '1 Minute',
        description: 'Look at an object 20 feet away for 20 seconds to relax ciliary eye muscles.'
      },
      {
        title: 'Hydration & Water Reset',
        category: 'Wellness',
        duration: '2 Minutes',
        description: 'Drink a full glass of cold water to rehydrate brain cells and boost alertness.'
      },
      {
        title: 'Brisk Walk & Sunlight Exposure',
        category: 'Energy',
        duration: '5 Minutes',
        description: 'Walk around the room or stepped outside to stimulate natural dopamine release.'
      }
    ];
  }

  /**
   * Generates a standard .ics iCalendar file content for calendar integration
   */
  public static generateICSContent(slots: RecommendedScheduleSlot[]): string {
    let ics = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Omni AI Ultimate//Study Coach//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH'
    ].join('\r\n') + '\r\n';

    const now = new Date();
    const dateStr = now.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';

    slots.forEach((slot, index) => {
      ics += [
        'BEGIN:VEVENT',
        `UID:omni_study_slot_${index}_${Date.now()}@omniai.edu`,
        `DTSTAMP:${dateStr}`,
        `SUMMARY:Omni AI Study Block: ${slot.subjectRecommendation}`,
        `DESCRIPTION:Recommended focus session (${slot.energyLevel}). ${slot.reasoning}`,
        `STATUS:CONFIRMED`,
        'END:VEVENT'
      ].join('\r\n') + '\r\n';
    });

    ics += 'END:VCALENDAR';
    return ics;
  }
}
