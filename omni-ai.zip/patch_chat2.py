with open('src/components/Chat.tsx', 'r') as f:
    code = f.read()

target = """export const Chat: React.FC<ChatProps> = ({
  messages,
  onSendMessage,"""

replacement = """export const Chat: React.FC<ChatProps> = ({
  messages,
  zoomLevel,
  setZoomLevel,
  contentWidth,
  setContentWidth,
  onSendMessage,"""

if target in code:
    with open('src/components/Chat.tsx', 'w') as f:
        f.write(code.replace(target, replacement))
    print("Patched!")
else:
    print("Target not found")
