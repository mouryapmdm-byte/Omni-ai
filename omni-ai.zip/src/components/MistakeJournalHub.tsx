import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Brain, 
  Sparkles, 
  TrendingUp, 
  Zap, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  Layers, 
  Award,
  AlertTriangle,
  Plus
} from 'lucide-react';
import { Mistake, MistakeCategory, MistakePattern, WeeklyMistakeReview } from '../modules/mistake-journal/types';
import { MistakeClassifier, MISTAKE_CATEGORY_INFO } from '../modules/mistake-journal/mistakeClassifier';
import { PatternDetector } from '../modules/mistake-journal/patternDetector';
import { MistakeJournal } from '../modules/mistake-journal/MistakeJournal';
import { RemediationAssigner } from '../modules/mistake-journal/RemediationAssigner';

interface MistakeJournalHubProps {
  isDark?: boolean;
  theme?: string;
  studentId?: string;
  showNotification?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
  onRewardXp?: (amount: number) => void;
}

export const MistakeJournalHub: React.FC<MistakeJournalHubProps> = ({
  isDark = true,
  theme,
  studentId = 'student_alex',
  showNotification,
  onRewardXp
}) => {
  const darkMode = theme ? theme === 'dark' : isDark;
  const [mistakes, setMistakes] = useState<Mistake[]>([]);
  const [activeTab, setActiveTab] = useState<'journal' | 'patterns' | 'remediation' | 'weekly_review'>('journal');

  // Load mistakes from storage on mount
  useEffect(() => {
    const list = MistakeClassifier.getAllMistakes();
    setMistakes(list);
  }, []);

  const patterns: MistakePattern[] = React.useMemo(() => {
    return PatternDetector.detectPatterns(mistakes);
  }, [mistakes]);

  const weeklyReview: WeeklyMistakeReview = React.useMemo(() => {
    return PatternDetector.getWeeklyReview(mistakes);
  }, [mistakes]);

  const handleToggleReviewed = (id: string, improved: boolean) => {
    MistakeClassifier.markReviewed(id, improved);
    setMistakes(MistakeClassifier.getAllMistakes());
    showNotification?.(improved ? 'Mistake marked as resolved! Keep it up.' : 'Gap reopened for revision.', 'info');
    if (improved && onRewardXp) {
      onRewardXp(25);
    }
  };

  const handleRemediationComplete = (mistakeId: string, success: boolean) => {
    if (success) {
      handleToggleReviewed(mistakeId, true);
      if (onRewardXp) {
        onRewardXp(50);
      }
    }
  };

  return (
    <div className={`flex flex-col h-full ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>
      {/* Top Navigation Bar */}
      <div className={`p-4 border-b flex flex-wrap items-center justify-between gap-4 ${
        darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-pink-600 flex items-center justify-center text-white shadow-md shadow-rose-500/20">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold">AI Mistake Journal & Cognitive Error Taxonomy</h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                Auto-Capture Active
              </span>
            </div>
            <p className="text-xs opacity-60">Automated mistake diagnosis, pattern detection, and targeted remediation</p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className={`flex items-center p-1 rounded-xl border ${darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-100 border-slate-300'}`}>
          <button
            onClick={() => setActiveTab('journal')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'journal'
                ? 'bg-rose-600 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Mistake Journal ({mistakes.length})
          </button>

          <button
            onClick={() => setActiveTab('patterns')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'patterns'
                ? 'bg-amber-500 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <Brain className="w-3.5 h-3.5" />
            Pattern Alerts ({patterns.length})
          </button>

          <button
            onClick={() => setActiveTab('remediation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'remediation'
                ? 'bg-purple-600 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            Targeted Remediation
          </button>

          <button
            onClick={() => setActiveTab('weekly_review')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'weekly_review'
                ? 'bg-emerald-600 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            Weekly Review
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-6 overflow-y-auto">
        {activeTab === 'journal' && (
          <MistakeJournal
            isDark={darkMode}
            mistakes={mistakes}
            onToggleReviewed={handleToggleReviewed}
            onLaunchRemediation={() => setActiveTab('remediation')}
          />
        )}

        {activeTab === 'patterns' && (
          <div className="space-y-6">
            <div className={`p-4 rounded-2xl border flex items-center justify-between ${
              darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'
            }`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Brain className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold">Detected Error Traps & Fatigue Signals</h2>
                  <p className="text-xs opacity-60">AI continuous pattern analysis identifying systemic traps across your test attempts</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {patterns.map(pat => (
                <div
                  key={pat.id}
                  className={`p-5 rounded-2xl border flex flex-col justify-between ${
                    pat.severity === 'high'
                      ? darkMode ? 'bg-rose-950/20 border-rose-800/40 text-rose-100' : 'bg-rose-50 border-rose-200 text-rose-900'
                      : darkMode ? 'bg-amber-950/20 border-amber-800/40 text-amber-100' : 'bg-amber-50 border-amber-200 text-amber-900'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-900/80 text-slate-300 text-[10px]">
                        {pat.subject} • {pat.count}x Detected
                      </span>
                      <span className={`font-bold text-[10px] uppercase ${pat.severity === 'high' ? 'text-rose-400' : 'text-amber-400'}`}>
                        {pat.severity} Severity
                      </span>
                    </div>

                    <h3 className="font-bold text-sm mb-2">{pat.title}</h3>
                    <p className="text-xs opacity-90 leading-relaxed mb-4">{pat.description}</p>
                  </div>

                  <div className={`p-3 rounded-xl border text-xs leading-relaxed ${
                    darkMode ? 'bg-slate-950/70 border-slate-800 text-slate-300' : 'bg-white border-slate-200 text-slate-800'
                  }`}>
                    <strong className="text-amber-400 flex items-center gap-1 mb-0.5">
                      <Sparkles className="w-3.5 h-3.5" /> Actionable Fix:
                    </strong>
                    {pat.remediationSuggestion}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'remediation' && (
          <RemediationAssigner
            isDark={darkMode}
            mistakes={mistakes}
            onRemediationComplete={handleRemediationComplete}
            showNotification={showNotification}
          />
        )}

        {activeTab === 'weekly_review' && (
          <div className="space-y-6">
            {/* Top Review Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-xs opacity-60 uppercase font-bold">Total Mistakes Logged</span>
                <div className="text-2xl font-black font-mono mt-1 text-rose-400">{weeklyReview.totalMistakes}</div>
                <span className="text-[11px] opacity-60">This week</span>
              </div>

              <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-xs opacity-60 uppercase font-bold">Remediated & Resolved</span>
                <div className="text-2xl font-black font-mono mt-1 text-emerald-400">{weeklyReview.resolvedMistakes}</div>
                <span className="text-[11px] text-emerald-400 font-semibold">
                  {weeklyReview.totalMistakes > 0 ? Math.round((weeklyReview.resolvedMistakes / weeklyReview.totalMistakes) * 100) : 100}% Mastery Rate
                </span>
              </div>

              <div className={`p-5 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-xs opacity-60 uppercase font-bold">Accuracy Trend</span>
                <div className="text-2xl font-black font-mono mt-1 text-indigo-400">+{weeklyReview.accuracyDeltaVsLastWeek}%</div>
                <span className="text-[11px] text-indigo-300">Reduction in repeated slips</span>
              </div>
            </div>

            {/* Top 3 Mistake Categories Breakdown */}
            <div className={`p-6 rounded-2xl border ${darkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h3 className="font-bold text-base mb-4 flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-rose-400" />
                Top 3 Mistake Categories This Week:
              </h3>

              <div className="space-y-4">
                {weeklyReview.top3MistakeTypes.map((t, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-slate-800 text-[11px] flex items-center justify-center font-mono">
                          {idx + 1}
                        </span>
                        {t.displayName}
                      </span>
                      <span className="font-mono text-rose-400">{t.count} times ({t.percentage}%)</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-rose-500 to-amber-500 rounded-full" style={{ width: `${t.percentage}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
