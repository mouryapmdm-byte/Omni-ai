import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { SupportedLanguageCode, LanguagePreference } from './types';
import { 
  SUPPORTED_LANGUAGES, 
  getTranslation, 
  formatLocalizedNumber, 
  formatLocalizedCurrency, 
  formatLocalizedDate 
} from './i18nConfig';
import { I18nContext, I18nContextValue } from './useI18n';

const STORAGE_KEY_LANG = 'omni_language_preference_v2';

const DEFAULT_PREFERENCE: LanguagePreference = {
  studentId: 'student_alex',
  primaryLanguage: 'en',
  secondaryLanguage: 'hi',
  bilingualMode: true,
  prefersRegionalExamples: true,
  numberSystem: 'indian',
  dateFormat: 'DD/MM/YYYY',
  currency: 'INR',
  updatedAt: new Date().toISOString()
};

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [preference, setPreference] = useState<LanguagePreference>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_LANG);
      if (stored) {
        return { ...DEFAULT_PREFERENCE, ...JSON.parse(stored) };
      }
    } catch (e) {
      // ignore
    }
    return DEFAULT_PREFERENCE;
  });

  const updatePreference = useCallback((partial: Partial<LanguagePreference>) => {
    setPreference(prev => {
      const updated = {
        ...prev,
        ...partial,
        updatedAt: new Date().toISOString()
      };
      try {
        localStorage.setItem(STORAGE_KEY_LANG, JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to persist language preference', e);
      }
      return updated;
    });
  }, []);

  const setLanguage = useCallback((lang: SupportedLanguageCode) => {
    updatePreference({ primaryLanguage: lang });
  }, [updatePreference]);

  const setBilingualMode = useCallback((enabled: boolean) => {
    updatePreference({ bilingualMode: enabled });
  }, [updatePreference]);

  const toggleBilingualMode = useCallback(() => {
    updatePreference({ bilingualMode: !preference.bilingualMode });
  }, [preference.bilingualMode, updatePreference]);

  const setPrefersRegionalExamples = useCallback((enabled: boolean) => {
    updatePreference({ prefersRegionalExamples: enabled });
  }, [updatePreference]);

  const currentMeta = useMemo(() => {
    return SUPPORTED_LANGUAGES[preference.primaryLanguage] || SUPPORTED_LANGUAGES['en'];
  }, [preference.primaryLanguage]);

  // Sync RTL / LTR document attributes
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('lang', preference.primaryLanguage);
    root.setAttribute('dir', currentMeta.dir);

    if (currentMeta.dir === 'rtl') {
      root.classList.add('rtl-layout');
    } else {
      root.classList.remove('rtl-layout');
    }
  }, [preference.primaryLanguage, currentMeta.dir]);

  const t = useCallback((key: string): string => {
    return getTranslation(key, preference.primaryLanguage);
  }, [preference.primaryLanguage]);

  const formatNumber = useCallback((num: number): string => {
    return formatLocalizedNumber(num, preference.numberSystem);
  }, [preference.numberSystem]);

  const formatCurrency = useCallback((amount: number): string => {
    return formatLocalizedCurrency(amount, preference.currency);
  }, [preference.currency]);

  const formatDate = useCallback((date: Date | string | number): string => {
    return formatLocalizedDate(date, preference.dateFormat);
  }, [preference.dateFormat]);

  const contextValue: I18nContextValue = {
    language: preference.primaryLanguage,
    setLanguage,
    languageMetadata: currentMeta,
    t,
    bilingualMode: preference.bilingualMode,
    setBilingualMode,
    toggleBilingualMode,
    prefersRegionalExamples: preference.prefersRegionalExamples,
    setPrefersRegionalExamples,
    dir: currentMeta.dir,
    formatNumber,
    formatCurrency,
    formatDate,
    preference,
    updatePreference
  };

  return (
    <I18nContext.Provider value={contextValue}>
      {children}
    </I18nContext.Provider>
  );
};
