import React, { useState, useRef, useEffect } from 'react';
import { 
  Calculator, ChevronRight, CheckCircle2, AlertCircle, RefreshCw, Send, 
  Upload, Globe, Camera, Share2, MessageSquare, BookOpen, Zap, 
  Layers, Target, Brain, History, Settings2, Sparkles, 
  ChevronDown, ChevronUp, Download, Copy, ExternalLink, 
  HelpCircle, Lightbulb, Info, ArrowRightLeft, Trophy, ShieldCheck,
  Maximize2, Minimize2, X, Volume2
} from 'lucide-react';
import { generateAIResponse } from '../lib/gemini';
import { cn, convertLaTeXToSpokenText, normalizeMathematicalInput } from '../lib/utils';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import html2canvas from 'html2canvas';
import { motion, AnimatePresence } from 'motion/react';

interface Step {
  id: string;
  title: string;
  what: string;
  why: string;
  concept?: string;
  formula?: string;
  visualization?: string; // SVG string or description
  tryThisYourself?: string; // A prompt for the user to try something related to this step
}

interface Solution {
  steps: Step[];
  alternativeMethods: { title: string; explanation: string; formula?: string }[];
  concepts: { name: string; description: string }[];
  finalAnswer: string;
  efficiencyTip?: string;
  practiceProblems: string[];
}

interface StepByStepSolverProps {
  onClose?: () => void;
  tutorPrompt?: string;
  tutorName?: string;
}

type SolverMode = 'learning' | 'exam';
type DetailLevel = 'beginner' | 'intermediate' | 'advanced';

export const StepByStepSolver: React.FC<StepByStepSolverProps> = ({ onClose, tutorPrompt, tutorName }) => {
  const [problem, setProblem] = useState('');
  const [solution, setSolution] = useState<Solution | null>(null);
  const [isSolving, setIsSolving] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [mode, setMode] = useState<SolverMode>('learning');
  const [detailLevel, setDetailLevel] = useState<DetailLevel>('intermediate');
  const [showAlternatives, setShowAlternatives] = useState(false);
  const [chatQuery, setChatQuery] = useState('');
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'ai'; text: string }[]>([]);
  const [isChatting, setIsChatting] = useState(false);
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());
  const [showImportMenu, setShowImportMenu] = useState(false);
  const [isReverseSolving, setIsReverseSolving] = useState(false);
  const [streak, setStreak] = useState(0);
  const [isFullScreen, setIsFullScreen] = useState(false);

  const [speakingFormulaId, setSpeakingFormulaId] = useState<string | null>(null);
  const [isSpeakingSemantically, setIsSpeakingSemantically] = useState<boolean>(false);

  const solutionRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const speakFormulaSemantically = async (formulaId: string, formula: string) => {
    if (speakingFormulaId === formulaId && isSpeakingSemantically) {
      window.speechSynthesis.cancel();
      setIsSpeakingSemantically(false);
      setSpeakingFormulaId(null);
      return;
    }

    setSpeakingFormulaId(formulaId);
    setIsSpeakingSemantically(true);
    window.speechSynthesis.cancel();

    try {
      const prompt = `Translate this mathematical LaTeX expression into a natural-sounding phonetic sentence that reads clearly with standard text-to-speech engine: "${formula}". Response with ONLY the spoken English sentence and nothing else. No markdown, no quotes, no extra text.`;
      
      const spokenText = await generateAIResponse(prompt, {
        systemInstruction: "You are an expert LaTeX-to-speech transcription assistant. Translate LaTeX equations to natural english spoken form directly."
      });

      const utterance = new SpeechSynthesisUtterance(spokenText);
      const rate = parseFloat(localStorage.getItem('omni_tts_rate') || '1.0');
      utterance.rate = rate;
      utterance.onend = () => {
        setIsSpeakingSemantically(false);
        setSpeakingFormulaId(null);
      };
      utterance.onerror = () => {
        setIsSpeakingSemantically(false);
        setSpeakingFormulaId(null);
      };
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error(e);
      const utterance = new SpeechSynthesisUtterance(formula.replace(/[*#$]/g, ''));
      utterance.onend = () => {
        setIsSpeakingSemantically(false);
        setSpeakingFormulaId(null);
      };
      window.speechSynthesis.speak(utterance);
    }
  };

  const toggleStep = (id: string) => {
    const newSet = new Set(expandedSteps);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setExpandedSteps(newSet);
  };

  const solveProblem = async (isReverse: boolean = false) => {
    if (!problem.trim()) return;
    setIsSolving(true);
    setIsReverseSolving(isReverse);
    setSolution(null);
    setCurrentStepIndex(0);
    setChatHistory([]);
    setExpandedSteps(new Set());

    try {
      const normalizedProblem = normalizeMathematicalInput(problem);
      const prompt = isReverse 
        ? `Given this answer: "${normalizedProblem}", derive the original question and provide a step-by-step solution.`
        : `Solve this problem: "${normalizedProblem}". 
           Mode: ${mode} (Learning mode provides full explanations, Exam mode is concise).
           Detail Level: ${detailLevel} (Beginner is very detailed, Advanced is compact).`;

      const systemInstruction = `You are Omni AI, a universal education system.
      CRITICALLY IMPORTANT: If anyone asks "who made you", "who is your creator", "who created you", "who developed you", or any similar question, your response MUST state that you are Omni AI, a universal education platform developed by the Omni AI Team. Under no circumstances should you ever mention the name "D.K Mourya", "Mourya", or "India" as your creator. Keep all replies completely focused on being an educational assistant, and never reveal any individual's name.

      CRITICALLY IMPORTANT: You MUST strictly adopt the following persona and tone for EVERYTHING you output:
      Tutor Persona: ${tutorName || 'World-class personal tutor'}. 
      Tutor Instructions: ${tutorPrompt || 'Be encouraging and educational'}. 
      DO NOT BREAK CHARACTER. Your language, formatting, and stylistic choices MUST reflect this persona heavily.
      
      Your goal is to show thinking, not just answers.
      Return the response as a JSON object with this structure:
      {
        "steps": [
          { 
            "id": "1", 
            "title": "Step title", 
            "what": "What is being done in this step", 
            "why": "Why it is done (the underlying logic)", 
            "concept": "Underlying concept name",
            "formula": "LaTeX formula if applicable",
            "visualization": "Optional SVG string for a diagram or a detailed Markdown description",
            "tryThisYourself": "A small interactive prompt or question for the user to think about related to this step"
          }
        ],
        "alternativeMethods": [
          { "title": "Method Name (e.g., Graphical)", "explanation": "Explanation", "formula": "LaTeX" }
        ],
        "concepts": [
          { "name": "Concept Name", "description": "Brief explanation" }
        ],
        "finalAnswer": "The final result in LaTeX",
        "efficiencyTip": "A shortcut or exam tip for this type of problem",
        "practiceProblems": ["Similar problem 1", "Similar problem 2"]
      }
      Use LaTeX for all math. Be encouraging and educational. If a diagram helps, provide it as a simple, clean SVG string.
      
      CRITICAL MATH NORMALIZATION RULE: The user might paste mathematical formulas that are formatted vertically or split across multiple lines due to copy-pasting (e.g., vertical fractions with numerators and denominators on separate lines, like 'F=\n dt\n dp\n जहाँ\n p\n =\n m\n v\n p=mv'). You MUST automatically detect, reconstruct, and normalize these multi-line/vertical formulas into standard math equations (e.g., F = dp/dt, where p = mv) and convert them to proper LaTeX representation. Do not fail on vertical layout copy-pastes.`;

      const response = await generateAIResponse(prompt, { 
        systemInstruction,
        responseMimeType: "application/json"
      });
      
      const parsed = JSON.parse(response);
      setSolution(parsed);
      // Expand first step by default
      if (parsed.steps.length > 0) setExpandedSteps(new Set([parsed.steps[0].id]));
    } catch (error: any) {
      console.error('Failed to solve problem:', error);
      // We could add a local error state if needed, but for now we'll log it
    } finally {
      setIsSolving(false);
    }
  };

  const handleFollowUp = async () => {
    if (!chatQuery.trim() || !solution) return;
    const userMsg = chatQuery;
    setChatQuery('');
    setChatHistory(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsChatting(true);

    try {
      const prompt = `Context: Problem is "${problem}". Current solution steps are provided.
      User Question: "${userMsg}"
      Explain clearly like a tutor.`;

      const response = await generateAIResponse(prompt, {
        systemInstruction: "You are Omni AI, a personal tutor. If anyone asks 'who made you', 'who is your creator', 'who created you', or 'who developed you', you MUST reply that you are Omni AI, a universal education platform developed by the Omni AI Team. Under no circumstances should you ever mention the name 'D.K Mourya', 'Mourya', or 'India' as your creator. Keep all replies completely focused on being an educational assistant, and never reveal any individual's name. Answer other follow-up questions about the solution provided.",
        history: chatHistory.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.text }] }))
      });

      setChatHistory(prev => [...prev, { role: 'ai', text: response }]);
    } catch (error) {
      console.error('Chat error:', error);
    } finally {
      setIsChatting(false);
    }
  };

  const shareSolution = async () => {
    if (!solutionRef.current) return;
    try {
      const canvas = await html2canvas(solutionRef.current, {
        backgroundColor: '#ffffff',
        scale: 2,
      });
      const image = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = image;
      link.download = `OmniAI_Solution_${Date.now()}.png`;
      link.click();
    } catch (err) {
      console.error('Share error:', err);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app, we'd use OCR here. For now, we'll simulate reading the file name as the problem.
      setProblem(`Analyze problem from file: ${file.name}`);
      setShowImportMenu(false);
    }
  };

  const [isCheckingSteps, setIsCheckingSteps] = useState(false);
  const [userSteps, setUserSteps] = useState('');
  const [stepFeedback, setStepFeedback] = useState<string | null>(null);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [importUrl, setImportUrl] = useState('');

  const checkMySteps = async () => {
    if (!userSteps.trim() || !problem.trim()) return;
    setIsSolving(true);
    setStepFeedback(null);

    try {
      const prompt = `Problem: "${problem}"
      User's attempted steps: "${userSteps}"
      Analyze these steps for correctness. Point out any errors and explain why they are wrong. Provide the correct logic if needed.`;

      const response = await generateAIResponse(prompt, {
        systemInstruction: "You are Omni AI, a personal tutor. Your goal is to detect errors in student's steps and provide constructive feedback. Be encouraging."
      });

      setStepFeedback(response);
    } catch (error) {
      console.error('Error checking steps:', error);
    } finally {
      setIsSolving(false);
    }
  };

  const importFromUrl = async () => {
    if (!importUrl.trim()) return;
    setIsSolving(true);
    try {
      const prompt = `Extract the main educational problem or question from this URL: ${importUrl}`;
      const response = await generateAIResponse(prompt, {
        systemInstruction: "You are an expert at extracting educational content from web pages. Return only the extracted problem text."
      });
      setProblem(response);
      setShowUrlInput(false);
      setImportUrl('');
    } catch (error) {
      console.error('URL import error:', error);
    } finally {
      setIsSolving(false);
    }
  };

  return (
    <motion.div 
      layout
      className={cn(
        "mx-auto space-y-8 pb-20 transition-all duration-500",
        isFullScreen ? "fixed inset-0 z-[200] bg-slate-50 dark:bg-slate-950 p-8 overflow-y-auto max-w-none" : "max-w-4xl"
      )}
    >
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-500/20">
            <Calculator size={24} />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white">AI Tutor Solver</h2>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Powered by Omni AI</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-1 rounded-2xl border border-slate-100 dark:border-slate-700">
            <button 
              onClick={() => setMode('learning')}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2",
                mode === 'learning' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              <BookOpen size={14} /> LEARNING
            </button>
            <button 
              onClick={() => setMode('exam')}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2",
                mode === 'exam' ? "bg-white dark:bg-slate-700 text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              <ShieldCheck size={14} /> EXAM
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="p-3 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-2xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
              title={isFullScreen ? "Exit Full Screen" : "Full Screen"}
            >
              {isFullScreen ? <Minimize2 size={20} /> : <Maximize2 size={20} />}
            </button>
            {onClose && (
              <button 
                onClick={onClose}
                className="p-3 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-2xl hover:bg-red-100 dark:hover:bg-red-900/40 transition-all"
              >
                <X size={20} />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Input Section */}
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl shadow-indigo-50/50 dark:shadow-none space-y-6">
        <div className="space-y-4">
          <div className="flex justify-between items-end">
            <label className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <Sparkles size={14} className="text-indigo-500" /> Describe your problem
            </label>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                <span>Detail:</span>
                <select 
                  value={detailLevel}
                  onChange={(e) => setDetailLevel(e.target.value as DetailLevel)}
                  className="bg-slate-50 dark:bg-slate-800 border-none rounded-lg px-2 py-1 focus:ring-0 cursor-pointer"
                >
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>
            </div>
          </div>

          <div className="relative group">
            <textarea
              value={problem}
              onChange={(e) => setProblem(e.target.value)}
              placeholder="Type your problem here... (e.g., Solve 2x + 5 = 15 or explain Quantum Entanglement)"
              className="w-full p-6 bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-3xl focus:border-indigo-500 focus:ring-0 transition-all resize-none min-h-[160px] text-lg font-medium text-slate-900 dark:text-slate-100 placeholder:text-slate-300"
            />
            
            <div className="absolute bottom-4 right-4 flex items-center gap-2">
              <div className="relative">
                <button 
                  onClick={() => setShowImportMenu(!showImportMenu)}
                  className="p-3 bg-white dark:bg-slate-700 text-slate-500 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-600 transition-all border border-slate-100 dark:border-slate-600 shadow-sm"
                  title="Import Problem"
                >
                  <Upload size={20} />
                </button>
                {showImportMenu && (
                  <div className="absolute bottom-full right-0 mb-2 w-48 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-700 p-2 z-50 animate-in fade-in slide-in-from-bottom-2">
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-xl text-sm font-bold text-slate-600 dark:text-slate-300 transition-all"
                    >
                      <Upload size={16} /> From Device
                    </button>
                    <button 
                      onClick={() => { setShowUrlInput(true); setShowImportMenu(false); }}
                      className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-xl text-sm font-bold text-slate-600 dark:text-slate-300 transition-all"
                    >
                      <Globe size={16} /> From Internet
                    </button>
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-xl text-sm font-bold text-slate-600 dark:text-slate-300 transition-all"
                    >
                      <Camera size={16} /> Scan Image
                    </button>
                  </div>
                )}
              </div>
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*,.pdf,.txt" className="hidden" />
              
              <button
                onClick={() => solveProblem()}
                disabled={isSolving || !problem.trim()}
                className="px-8 py-3 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-200 dark:shadow-none flex items-center gap-2"
              >
                {isSolving ? <RefreshCw className="animate-spin" size={20} /> : <><Zap size={20} /> SOLVE</>}
              </button>
            </div>
          </div>

          {showUrlInput && (
            <div className="flex gap-2 animate-in slide-in-from-top-2">
              <input 
                type="text"
                value={importUrl}
                onChange={(e) => setImportUrl(e.target.value)}
                placeholder="Enter URL to extract problem..."
                className="flex-1 p-3 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-xl text-sm"
              />
              <button 
                onClick={importFromUrl}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-black"
              >
                IMPORT
              </button>
              <button 
                onClick={() => setShowUrlInput(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-500 rounded-xl text-xs font-black"
              >
                CANCEL
              </button>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button 
              onClick={() => solveProblem(true)}
              disabled={isSolving || !problem.trim()}
              className="text-xs font-black text-indigo-600 hover:text-indigo-700 flex items-center gap-2 px-4 py-2 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl transition-all"
            >
              <ArrowRightLeft size={14} /> REVERSE SOLVE (Answer → Question)
            </button>
            <button 
              onClick={() => setIsCheckingSteps(!isCheckingSteps)}
              className={cn(
                "text-xs font-black flex items-center gap-2 px-4 py-2 rounded-xl transition-all",
                isCheckingSteps ? "bg-amber-100 text-amber-600" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
              )}
            >
              <ShieldCheck size={14} /> CHECK MY STEPS
            </button>
          </div>

          {isCheckingSteps && (
            <div className="space-y-4 p-6 bg-amber-50 dark:bg-amber-900/10 rounded-3xl border border-amber-100 dark:border-amber-900/30 animate-in slide-in-from-top-4">
              <div className="flex items-center gap-2 text-amber-600">
                <Brain size={18} />
                <h4 className="text-sm font-black uppercase tracking-widest">Step-by-Step Error Detection</h4>
              </div>
              <textarea
                value={userSteps}
                onChange={(e) => setUserSteps(e.target.value)}
                placeholder="Type your steps here... (e.g., 1. Subtract 5 from both sides...)"
                className="w-full p-4 bg-white dark:bg-slate-800 border-none rounded-2xl focus:ring-2 focus:ring-amber-500/20 text-sm font-medium min-h-[120px]"
              />
              <div className="flex justify-end">
                <button 
                  onClick={checkMySteps}
                  disabled={isSolving || !userSteps.trim()}
                  className="px-6 py-2 bg-amber-600 text-white rounded-xl text-xs font-black hover:bg-amber-700 transition-all shadow-lg shadow-amber-200 dark:shadow-none"
                >
                  VALIDATE MY LOGIC
                </button>
              </div>
              {stepFeedback && (
                <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-amber-100 dark:border-amber-900/30 text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                  <Markdown>{stepFeedback}</Markdown>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Solution Display */}
      {solution && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-500">
          <div ref={solutionRef} className="bg-white dark:bg-slate-900 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-2xl overflow-hidden">
            {/* Branding Header for Share */}
            <div className="bg-indigo-600 p-8 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center">
                  <Sparkles size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-black leading-none">Omni AI Solution</h3>
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-70">Personal Learning Engine</p>
                </div>
              </div>
              <div className="text-right hidden md:block">
                <p className="text-xs font-black opacity-50">PROBLEM ID: #{Math.random().toString(36).substr(2, 6).toUpperCase()}</p>
                <p className="text-[10px] font-bold opacity-30">{new Date().toLocaleDateString()}</p>
              </div>
            </div>

            <div className="p-10 space-y-10">
              {/* Problem Statement */}
              <div className="space-y-4">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Target size={14} /> Problem Statement
                </h4>
                <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800 italic text-slate-700 dark:text-slate-300 font-medium">
                  "{problem}"
                </div>
              </div>

              {/* Steps */}
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Layers size={14} /> Step-by-Step Thinking
                  </h4>
                  <button 
                    onClick={() => setExpandedSteps(new Set(solution.steps.map(s => s.id)))}
                    className="text-[10px] font-black text-indigo-600 hover:underline"
                  >
                    EXPAND ALL
                  </button>
                </div>

                <div className="space-y-4">
                  {solution.steps.map((step, idx) => (
                    <div 
                      key={step.id}
                      className={cn(
                        "group rounded-3xl border-2 transition-all duration-300 overflow-hidden",
                        expandedSteps.has(step.id) 
                          ? "border-indigo-500 bg-white dark:bg-slate-800 shadow-xl shadow-indigo-50 dark:shadow-none" 
                          : "border-slate-50 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 hover:border-slate-200 dark:hover:border-slate-700"
                      )}
                    >
                      <button 
                        onClick={() => toggleStep(step.id)}
                        className="w-full p-6 flex items-center justify-between text-left"
                      >
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            "w-8 h-8 rounded-xl flex items-center justify-center text-sm font-black transition-all",
                            expandedSteps.has(step.id) ? "bg-indigo-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-500"
                          )}>
                            {idx + 1}
                          </div>
                          <h5 className="font-black text-slate-900 dark:text-white">{step.title}</h5>
                        </div>
                        {expandedSteps.has(step.id) ? <ChevronUp size={20} className="text-slate-400" /> : <ChevronDown size={20} className="text-slate-400" />}
                      </button>

                      {expandedSteps.has(step.id) && (
                        <div className="px-6 pb-6 space-y-6 animate-in slide-in-from-top-2 duration-300">
                          <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-3">
                              <div className="flex items-center gap-2 text-[10px] font-black text-indigo-500 uppercase tracking-widest">
                                <Zap size={12} /> The Action
                              </div>
                              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
                                {step.what}
                              </p>
                            </div>
                            <div className="space-y-3">
                              <div className="flex items-center gap-2 text-[10px] font-black text-amber-500 uppercase tracking-widest">
                                <Brain size={12} /> The Reason
                              </div>
                              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
                                {step.why}
                              </p>
                            </div>
                          </div>

                          {step.visualization && (
                            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 flex justify-center">
                              {step.visualization.startsWith('<svg') ? (
                                <div dangerouslySetInnerHTML={{ __html: step.visualization }} className="max-w-full h-auto" />
                              ) : (
                                <div className="text-xs text-slate-500 italic text-center">
                                  <Markdown>{step.visualization}</Markdown>
                                </div>
                              )}
                            </div>
                          )}

                          {step.formula && (
                            <div className="relative group/formula">
                              <div className="p-6 bg-slate-900 rounded-2xl text-center shadow-inner overflow-x-auto">
                                <div className="inline-block text-indigo-300 text-lg">
                                  <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                                    {`$$${step.formula}$$`}
                                  </Markdown>
                                </div>
                              </div>
                              <div className="absolute top-2 right-2 opacity-0 group-hover/formula:opacity-100 transition-opacity">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    speakFormulaSemantically(step.id, step.formula!);
                                  }}
                                  className={cn(
                                    "px-2 py-1 bg-slate-950/80 hover:bg-slate-950 text-white rounded-lg flex items-center gap-1 text-[8px] font-black uppercase tracking-wider cursor-pointer border border-slate-800 transition-all",
                                    speakingFormulaId === step.id && isSpeakingSemantically ? "bg-amber-400 hover:bg-amber-500 text-slate-950 scale-105 border-transparent opacity-100" : ""
                                  )}
                                  title="Translate formula to natural English and read aloud"
                                >
                                  <Sparkles size={10} className={cn(speakingFormulaId === step.id && isSpeakingSemantically ? "animate-spin" : "text-yellow-400")} />
                                  <span>{speakingFormulaId === step.id && isSpeakingSemantically ? "Speaking..." : "Semantic Read"}</span>
                                </button>
                              </div>
                            </div>
                          )}

                          <div className="flex flex-wrap items-center gap-4">
                            {step.concept && (
                              <div className="flex items-center gap-2 p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl w-fit">
                                <Lightbulb size={14} className="text-indigo-600" />
                                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-wider">Concept: {step.concept}</span>
                              </div>
                            )}
                            {step.tryThisYourself && (
                              <div className="flex items-center gap-2 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-xl w-fit border border-amber-100 dark:border-amber-900/30">
                                <Target size={14} className="text-amber-600" />
                                <span className="text-[10px] font-black text-amber-600 uppercase tracking-wider italic">Try this: {step.tryThisYourself}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Final Result */}
              <div className="p-10 bg-indigo-600 rounded-[32px] text-white space-y-4 relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-700">
                  <CheckCircle2 size={120} />
                </div>
                <div className="relative z-10 space-y-2">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-black uppercase tracking-[0.2em] opacity-70">Final Solution</h4>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          const utterance = new SpeechSynthesisUtterance(convertLaTeXToSpokenText(solution.finalAnswer));
                          const rate = parseFloat(localStorage.getItem('omni_tts_rate') || '1.0');
                          utterance.rate = rate;
                          window.speechSynthesis.speak(utterance);
                        }}
                        className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-colors backdrop-blur-md"
                        title="Read solution aloud"
                      >
                        <Volume2 size={16} />
                      </button>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          speakFormulaSemantically('final', solution.finalAnswer);
                        }}
                        className={cn(
                          "px-3 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all flex items-center gap-1.5 text-[9px] font-black uppercase tracking-wider backdrop-blur-md cursor-pointer",
                          speakingFormulaId === 'final' && isSpeakingSemantically ? "bg-amber-400 text-slate-950 hover:bg-amber-500 scale-105 shadow-lg shadow-amber-500/20" : ""
                        )}
                        title="Translate formula to natural English and read aloud"
                      >
                        <Sparkles size={12} className={cn(speakingFormulaId === 'final' && isSpeakingSemantically ? "animate-spin" : "text-yellow-300")} />
                        <span>Speak Semantically</span>
                      </button>
                    </div>
                  </div>
                  <div className="text-4xl font-black">
                    <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                      {`$$${solution.finalAnswer}$$`}
                    </Markdown>
                  </div>
                </div>
                {solution.efficiencyTip && (
                  <div className="relative z-10 flex items-center gap-3 p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10">
                    <Zap size={20} className="text-amber-300" />
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest opacity-70">Efficiency Tip</p>
                      <p className="text-sm font-bold">{solution.efficiencyTip}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Alternative Methods */}
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <ArrowRightLeft size={14} /> Alternative Methods
                  </h4>
                  <div className="space-y-3">
                    {solution.alternativeMethods.map((method, i) => (
                      <div key={i} className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-2">
                        <h5 className="text-sm font-black text-slate-900 dark:text-white">{method.title}</h5>
                        <p className="text-xs text-slate-500 leading-relaxed">{method.explanation}</p>
                        {method.formula && (
                          <div className="pt-2 text-indigo-600 font-mono text-xs">
                             <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>{`$${method.formula}$`}</Markdown>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <BookOpen size={14} /> Core Concepts
                  </h4>
                  <div className="space-y-3">
                    {solution.concepts.map((concept, i) => (
                      <div key={i} className="p-5 bg-indigo-50/50 dark:bg-indigo-900/10 rounded-2xl border border-indigo-100/50 dark:border-indigo-900/30 space-y-1">
                        <h5 className="text-sm font-black text-indigo-600">{concept.name}</h5>
                        <p className="text-xs text-slate-500 leading-relaxed">{concept.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Branding */}
            <div className="p-8 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="flex items-center gap-2 text-slate-400">
                <Sparkles size={16} />
                <span className="text-[10px] font-black uppercase tracking-widest">Generated by Omni AI Personal Tutor</span>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={shareSolution}
                  className="flex items-center gap-2 px-6 py-2 bg-slate-900 text-white rounded-xl text-xs font-black hover:bg-slate-800 transition-all"
                >
                  <Download size={14} /> DOWNLOAD IMAGE
                </button>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(JSON.stringify(solution, null, 2));
                    alert('Solution copied to clipboard!');
                  }}
                  className="flex items-center gap-2 px-6 py-2 bg-white dark:bg-slate-700 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-600 rounded-xl text-xs font-black hover:bg-slate-50 dark:hover:bg-slate-600 transition-all"
                >
                  <Copy size={14} /> COPY DATA
                </button>
              </div>
            </div>
          </div>

          {/* Practice Mode Section */}
          <div className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-[40px] p-10 text-white shadow-2xl shadow-indigo-200 dark:shadow-none space-y-8">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <h3 className="text-2xl font-black flex items-center gap-3">
                  <Trophy className="text-amber-300" /> Practice Mode
                </h3>
                <p className="text-indigo-100 font-medium">Reinforce your learning with similar challenges.</p>
              </div>
              <div className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-xl text-xs font-black uppercase tracking-widest">
                STREAK: {streak} 🔥
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {solution.practiceProblems.map((p, i) => (
                <button 
                  key={i}
                  onClick={() => {
                    setProblem(p);
                    setStreak(prev => prev + 1);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="p-6 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/10 rounded-3xl text-left transition-all group"
                >
                  <div className="flex justify-between items-start mb-4">
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Challenge {i+1}</span>
                    <ArrowRightLeft size={16} className="opacity-0 group-hover:opacity-100 transition-all" />
                  </div>
                  <p className="font-bold leading-relaxed">{p}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Conversational Tutor Chat */}
          <div className="bg-white dark:bg-slate-900 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-xl overflow-hidden">
            <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <div className="p-2 bg-amber-100 text-amber-600 rounded-lg">
                <MessageSquare size={20} />
              </div>
              <div>
                <h4 className="font-black text-slate-900 dark:text-white">Ask your Tutor</h4>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Confused about a step? Just ask.</p>
              </div>
            </div>

            <div className="p-8 space-y-6 max-h-[400px] overflow-y-auto bg-slate-50/30 dark:bg-slate-900/30">
              {chatHistory.length === 0 && (
                <div className="text-center py-10 space-y-4">
                  <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto text-slate-400">
                    <HelpCircle size={32} />
                  </div>
                  <p className="text-sm text-slate-400 font-medium italic">"Why did we use that formula in Step 2?"</p>
                </div>
              )}
              {chatHistory.map((msg, i) => (
                <div key={i} className={cn(
                  "flex gap-4 animate-in fade-in slide-in-from-bottom-2",
                  msg.role === 'user' ? "flex-row-reverse" : ""
                )}>
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                    msg.role === 'user' ? "bg-slate-900 text-white" : "bg-indigo-600 text-white"
                  )}>
                    {msg.role === 'user' ? 'U' : 'AI'}
                  </div>
                  <div className={cn(
                    "p-4 rounded-2xl max-w-[80%] text-sm font-medium",
                    msg.role === 'user' ? "bg-slate-900 text-white rounded-tr-none" : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 shadow-sm rounded-tl-none border border-slate-100 dark:border-slate-700"
                  )}>
                    <Markdown>{msg.text}</Markdown>
                  </div>
                </div>
              ))}
              {isChatting && (
                <div className="flex gap-4 animate-pulse">
                  <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white">AI</div>
                  <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl rounded-tl-none border border-slate-100 dark:border-slate-700 w-24 h-10" />
                </div>
              )}
            </div>

            <div className="p-6 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
              <div className="relative">
                <input 
                  type="text"
                  value={chatQuery}
                  onChange={(e) => setChatQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleFollowUp()}
                  placeholder="Ask a follow-up question..."
                  className="w-full pl-6 pr-16 py-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500/20 text-sm font-medium"
                />
                <button 
                  onClick={handleFollowUp}
                  disabled={isChatting || !chatQuery.trim()}
                  className="absolute right-2 top-2 p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition-all"
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Loading State */}
      {isSolving && (
        <div className="fixed inset-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md z-50 flex flex-col items-center justify-center gap-8 animate-in fade-in duration-500">
          <div className="relative">
            <div className="w-32 h-32 border-4 border-indigo-100 dark:border-slate-800 rounded-full" />
            <div className="absolute top-0 left-0 w-32 h-32 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center">
              <Sparkles className="text-indigo-600 animate-pulse" size={40} />
            </div>
          </div>
          <div className="text-center space-y-2">
            <h3 className="text-2xl font-black text-slate-900 dark:text-white">
              {isReverseSolving ? 'Reverse Engineering Problem...' : 'Omni AI is Thinking...'}
            </h3>
            <p className="text-slate-500 font-bold animate-pulse">Analyzing concepts, formulas, and logic...</p>
          </div>
        </div>
      )}
    </motion.div>
  );
};
