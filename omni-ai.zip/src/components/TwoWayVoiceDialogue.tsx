import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, MicOff, Volume2, VolumeX, Pause, Play, RefreshCw, Sparkles, 
  User, Brain, MessageSquare, FastForward, Settings2, Sliders, CheckCircle2, Shield
} from 'lucide-react';
import { generateAIResponse, generateSpeech } from '../lib/gemini';
import { cn, convertLaTeXToSpokenText } from '../lib/utils';
import { PERSONAS } from '../lib/constants';

interface DialogueTurn {
  id: string;
  sender: 'professor' | 'student';
  text: string;
  timestamp: number;
  emotion?: 'encouraging' | 'curious' | 'clarifying' | 'celebratory';
}

interface Props {
  theme?: 'light' | 'dark';
  subject?: string;
  topic?: string;
  userName?: string;
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  onSendMessageToChat?: (text: string) => void;
}

export const TwoWayVoiceDialogue: React.FC<Props> = ({
  theme = 'light',
  subject = 'Physics',
  topic = 'Newtonian Mechanics',
  userName = 'Student',
  showNotification,
  onSendMessageToChat
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [selectedPersonaId, setSelectedPersonaId] = useState('encouraging_coach');
  const [speechRate, setSpeechRate] = useState(1.0);
  const [voiceVolume, setVoiceVolume] = useState(1.0);
  const [interruptSensitivity, setInterruptSensitivity] = useState<'high' | 'normal' | 'strict'>('high');
  const [accentRegion, setAccentRegion] = useState('Indian English');
  
  const [dialogueHistory, setDialogueHistory] = useState<DialogueTurn[]>([
    {
      id: 'd-1',
      sender: 'professor',
      text: `Welcome, ${userName}! I am Professor Clarity. Today we are exploring ${topic}. Speak naturally into your microphone anytime, and feel free to interrupt me if you need me to re-explain a formula or give an analogy. What is on your mind about ${topic}?`,
      timestamp: Date.now(),
      emotion: 'encouraging'
    }
  ]);

  const recognitionRef = useRef<any>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [dialogueHistory, isThinking, isSpeaking]);

  // Speech Recognition Setup
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognizer = new SpeechRecognition();
      recognizer.continuous = true;
      recognizer.interimResults = true;
      recognizer.lang = 'en-US';

      recognizer.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const item = event.results[i];
          currentTranscript += item[0].transcript;
          if (item.isFinal) {
            handleStudentSpoke(currentTranscript);
            currentTranscript = '';
          }
        }
        setTranscript(currentTranscript);

        // Voice Barge-in check: If student speaks while professor is talking, pause/stop audio immediately
        if (isSpeaking && currentAudioRef.current && currentTranscript.trim().length > 3) {
          currentAudioRef.current.pause();
          setIsSpeaking(false);
          showNotification?.("Professor Clarity paused speaking to listen to you.", "info");
        }
      };

      recognizer.onerror = (e: any) => {
        console.warn("Speech recognition error:", e);
      };

      recognitionRef.current = recognizer;
    }
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
      }
    };
  }, [isSpeaking, showNotification]);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      showNotification?.("Microphone muted", "info");
    } else {
      try {
        recognitionRef.current?.start();
        setIsListening(true);
        showNotification?.("Listening... speak your question now!", "success");
      } catch (err) {
        console.warn(err);
        setIsListening(true);
      }
    }
  };

  const handleStudentSpoke = async (spokenText: string) => {
    if (!spokenText.trim()) return;

    const studentMsg: DialogueTurn = {
      id: `turn-${Date.now()}`,
      sender: 'student',
      text: spokenText.trim(),
      timestamp: Date.now()
    };

    setDialogueHistory(prev => [...prev, studentMsg]);
    setTranscript('');
    setIsThinking(true);

    try {
      const persona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[0];
      const prompt = `You are Professor Clarity conducting a real-time conversational two-way voice tutorial with student: "${userName}".
Subject: "${subject}"
Topic: "${topic}"
Tutor Accent & Style: "${accentRegion}" (${persona.name})

CRITICAL 10 HUMAN PEDAGOGY RULES:
1. DELIBERATE THINKING PAUSES: If asking a question, keep it focused and give thinking room.
2. STUDENT AGENCY: Offer choices in examples (e.g., sports vs food vs nature) or pace whenever natural.
3. WRONG ANSWER PROTOCOL: NEVER say "Wrong" or "Incorrect". Say "Let's check that together" or "I see how you got there".
4. EMOTIONAL AWARENESS: Detect if the student sounds confused, frustrated, tired, or confident and adapt with deep empathy.
5. TEACH-BACK: Invite the student to explain things in their own words or Feynman-style.
6. AUTHENTIC WARMTH: Speak naturally, with genuine human warmth and enthusiasm, using brief thinking moments when appropriate.
7. CULTURAL FLEXIBILITY: Use relatable everyday examples (pressure cookers, cricket, tea, smartphones).
8. NO MACHINE SYNTAX: Keep the response concise, punchy, conversational, and conversational-speech friendly (under 3-4 sentences so it sounds natural in audio).
9. Do NOT output markdown code blocks, brackets, asterisks, or bulleted lists, as this will be spoken aloud via text-to-speech.

Student just said: "${spokenText}"
Previous Dialogue:
${dialogueHistory.slice(-3).map(d => `${d.sender.toUpperCase()}: ${d.text}`).join('\n')}

Respond as Professor Clarity:`;

      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      const professorText = response ? response.replace(/[#*`_]/g, '').trim() : "That's a thoughtful question. Let me walk you through the core concept simply.";

      const profMsg: DialogueTurn = {
        id: `turn-prof-${Date.now()}`,
        sender: 'professor',
        text: professorText,
        timestamp: Date.now(),
        emotion: 'clarifying'
      };

      setDialogueHistory(prev => [...prev, profMsg]);

      // Play audio response natively on user client side
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        window.speechSynthesis.resume();

        const cleanSpeech = convertLaTeXToSpokenText(professorText);
        const utterance = new SpeechSynthesisUtterance(cleanSpeech);
        utterance.rate = speechRate;
        utterance.volume = voiceVolume;
        utterance.pitch = 1.0;

        const voices = window.speechSynthesis.getVoices();
        const preferredVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Online') || v.name.includes('Neural')));
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }

        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);

        window.speechSynthesis.speak(utterance);
      } else {
        setIsSpeaking(false);
      }
    } catch (err) {
      console.error(err);
      showNotification?.("Voice response encountered an error. Retrying...", "error");
    } finally {
      setIsThinking(false);
    }
  };

  const isDark = theme === 'dark';

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Top Controls Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-md transition-all",
            isSpeaking 
              ? "bg-emerald-600 ring-4 ring-emerald-500/30 animate-pulse" 
              : "bg-gradient-to-tr from-indigo-600 to-violet-500"
          )}>
            <Volume2 size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Two-Way Voice Dialogue</h2>
              <span className={cn(
                "px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider border",
                isSpeaking ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30" : "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
              )}>
                {isSpeaking ? "Professor Speaking" : isListening ? "Listening to You" : "Ready"}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Low-latency vocal exchange &bull; Voice barge-in enabled &bull; {accentRegion}
            </p>
          </div>
        </div>

        {/* Audio Configuration Controls */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 bg-slate-800/40 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
            <span className="text-slate-400 font-bold">Accent:</span>
            <select
              value={accentRegion}
              onChange={(e) => setAccentRegion(e.target.value)}
              className="bg-transparent text-slate-200 font-semibold outline-none cursor-pointer text-xs"
            >
              <option value="Indian English" className="bg-slate-900">Indian English</option>
              <option value="British RP" className="bg-slate-900">British (Oxford/RP)</option>
              <option value="North American" className="bg-slate-900">North American</option>
              <option value="Australian" className="bg-slate-900">Australian</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-800/40 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
            <span className="text-slate-400 font-bold">Speed:</span>
            <select
              value={speechRate}
              onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
              className="bg-transparent text-slate-200 font-semibold outline-none cursor-pointer text-xs"
            >
              <option value="0.85" className="bg-slate-900">0.85x (Paced)</option>
              <option value="1.0" className="bg-slate-900">1.0x (Normal)</option>
              <option value="1.15" className="bg-slate-900">1.15x (Fast)</option>
              <option value="1.3" className="bg-slate-900">1.3x (Rapid)</option>
            </select>
          </div>

          <button
            onClick={() => {
              if (currentAudioRef.current) {
                currentAudioRef.current.pause();
                setIsSpeaking(false);
              }
            }}
            disabled={!isSpeaking}
            className="px-3 py-1.5 rounded-lg bg-rose-600/20 text-rose-400 hover:bg-rose-600/30 border border-rose-500/30 disabled:opacity-30 font-bold transition cursor-pointer flex items-center gap-1"
          >
            <Pause size={13} /> Interrupt
          </button>
        </div>
      </div>

      {/* Main Dialogue Scroll Window */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4">
        {dialogueHistory.map((turn) => {
          const isProf = turn.sender === 'professor';

          return (
            <div
              key={turn.id}
              className={cn(
                "flex items-start gap-3 max-w-2xl transition-all duration-300",
                isProf ? "mr-auto" : "ml-auto flex-row-reverse"
              )}
            >
              <div className={cn(
                "w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-md font-bold text-xs",
                isProf ? "bg-indigo-600 text-white" : "bg-emerald-600 text-white"
              )}>
                {isProf ? <Brain size={18} /> : <User size={18} />}
              </div>

              <div className={cn(
                "p-4 rounded-2xl border space-y-1 text-xs sm:text-sm leading-relaxed",
                isProf
                  ? (isDark ? "bg-slate-950/80 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-900 shadow-sm")
                  : (isDark ? "bg-indigo-950/40 border-indigo-600/40 text-indigo-100" : "bg-indigo-50 border-indigo-200 text-indigo-950")
              )}>
                <div className="flex items-center justify-between gap-4 text-[10px] text-slate-400 mb-1 font-semibold uppercase">
                  <span>{isProf ? 'Professor Clarity' : userName}</span>
                  <span>{new Date(turn.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <p>{turn.text}</p>
              </div>
            </div>
          );
        })}

        {isThinking && (
          <div className="flex items-center gap-3 mr-auto">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/40 flex items-center justify-center text-white animate-pulse">
              <Sparkles size={16} />
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-800/40 border border-slate-700/60 text-xs text-indigo-300 font-semibold flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
              Professor Clarity is contemplating pedagogical formulation...
            </div>
          </div>
        )}
      </div>

      {/* Live Waveform & Microphone Action Dock */}
      <div className={cn(
        "p-5 border-t space-y-4",
        isDark ? "bg-slate-950/90 border-slate-800" : "bg-white border-slate-200"
      )}>
        {/* Animated Waveform Visualizer simulation */}
        <div className="flex items-center justify-center gap-1.5 h-8">
          {[...Array(24)].map((_, i) => (
            <div
              key={i}
              className={cn(
                "w-1 rounded-full transition-all duration-150",
                isSpeaking 
                  ? "bg-emerald-500 animate-pulse" 
                  : isListening 
                    ? "bg-indigo-500 animate-bounce" 
                    : "bg-slate-700/50 h-2"
              )}
              style={{
                height: (isSpeaking || isListening) ? `${Math.max(6, Math.sin((i + Date.now() / 200) * 0.8) * 28 + 12)}px` : '6px'
              }}
            />
          ))}
        </div>

        {/* Input Bar & Controls */}
        <div className="flex items-center gap-3 max-w-3xl mx-auto">
          <button
            onClick={toggleListening}
            className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-xl transition-all duration-300 cursor-pointer shrink-0",
              isListening
                ? "bg-rose-600 hover:bg-rose-500 ring-4 ring-rose-500/30 scale-105"
                : "bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/30"
            )}
            title={isListening ? "Mute Microphone" : "Unmute and Speak"}
          >
            {isListening ? <Mic size={22} className="animate-pulse" /> : <MicOff size={22} />}
          </button>

          <div className="flex-1 relative">
            <input
              type="text"
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && transcript.trim()) {
                  handleStudentSpoke(transcript);
                }
              }}
              placeholder={isListening ? "Listening... (or type your thought here)" : "Type or turn on microphone to talk..."}
              className={cn(
                "w-full px-4 py-3 rounded-xl border text-xs sm:text-sm outline-none transition font-medium",
                isDark 
                  ? "bg-slate-900 border-slate-750 text-slate-100 placeholder-slate-500 focus:border-indigo-500" 
                  : "bg-slate-100 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500"
              )}
            />
          </div>

          <button
            onClick={() => handleStudentSpoke(transcript)}
            disabled={!transcript.trim()}
            className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-bold shadow-md transition cursor-pointer shrink-0"
          >
            Speak &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
