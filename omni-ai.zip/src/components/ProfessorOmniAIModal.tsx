import React, { useState } from 'react';
import { 
  X, Zap, Sparkles, BookOpen, MessageSquare, Play, Volume2, 
  HelpCircle, CheckCircle2, ArrowRight, Lightbulb, Compass,
  Layers, RefreshCw, Send, Sliders, Award, Target
} from 'lucide-react';
import { cn, triggerHapticFeedback } from '../lib/utils';
import { TEACHER_PEDAGOGY_STYLES, getTeacherStyleById } from '../data/teacherStyles';

// Safe Web Audio feedback helper
const playSoundEffect = (type: 'click' | 'chime') => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    if (type === 'click') {
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
      osc.start();
      osc.stop(ctx.currentTime + 0.05);
    } else {
      osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.08); // E5
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    }
  } catch (e) {}
};

interface ProfessorOmniAIModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicTitle: string;
  onStartLecture: (styleId?: string) => void;
  onAskQuestion: (question: string) => void;
  onRequestDiagram: (prompt: string) => void;
  onFocusProfessorCamera: () => void;
  onSelectTeacherStyle: (styleId: string) => void;
  currentTeacherStyleId: string;
  isSpeaking: boolean;
  showNotification?: (msg: string, type?: 'success' | 'info' | 'error' | 'warning') => void;
}

export const ProfessorOmniAIModal: React.FC<ProfessorOmniAIModalProps> = ({
  isOpen,
  onClose,
  topicTitle,
  onStartLecture,
  onAskQuestion,
  onRequestDiagram,
  onFocusProfessorCamera,
  onSelectTeacherStyle,
  currentTeacherStyleId,
  isSpeaking,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'ask' | 'lecture' | 'diagram' | 'pedagogy'>('ask');
  const [customQuery, setCustomQuery] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const omniStyle = getTeacherStyleById('omni_ai') || TEACHER_PEDAGOGY_STYLES[0];

  const QUICK_PROMPTS = [
    {
      title: 'First-Principles Intuition',
      prompt: `Professor Omni, explain the core physics/intuition behind "${topicTitle}" from absolute first principles before any formulas.`,
      icon: '🌱',
      tag: 'Intuition'
    },
    {
      title: 'Step-by-Step Derivation',
      prompt: `Professor Omni, provide a rigorous step-by-step LaTeX derivation of the governing equations for "${topicTitle}".`,
      icon: '📐',
      tag: 'LaTeX Derivation'
    },
    {
      title: 'Blackboard Schematic Diagram',
      prompt: `Professor Omni, draw a detailed blackboard SVG schematic diagram illustrating the geometry and flow of "${topicTitle}".`,
      icon: '🎨',
      tag: 'Dynamic SVG'
    },
    {
      title: 'Real-World Engineering Analogy',
      prompt: `Professor Omni, what is a vivid real-world engineering or biological analogy for "${topicTitle}"?`,
      icon: '⚡',
      tag: 'Analogy'
    },
    {
      title: '5-Level Formula Practice',
      prompt: `Professor Omni, give me a 5-level progressive practice challenge on "${topicTitle}" from easy substitution to Olympiad exam level.`,
      icon: '🎯',
      tag: 'Practice'
    },
    {
      title: 'Exam Traps & Marking Scheme',
      prompt: `Professor Omni, what are the top 3 critical exam traps and marking rubrics for "${topicTitle}"?`,
      icon: '⚠️',
      tag: 'Exam Strategy'
    }
  ];

  const handleSendQuery = (text: string) => {
    if (!text.trim()) return;
    triggerHapticFeedback(10);
    playSoundEffect('click');
    setIsSubmitting(true);
    
    // Ensure Omni AI is active style
    onSelectTeacherStyle('omni_ai');
    onAskQuestion(text);
    
    showNotification?.(`Professor Omni AI is analyzing: "${text.slice(0, 35)}..."`, 'info');
    setTimeout(() => {
      setIsSubmitting(false);
      onClose();
    }, 400);
  };

  const handleStartOmniLecture = () => {
    triggerHapticFeedback(12);
    playSoundEffect('chime');
    onSelectTeacherStyle('omni_ai');
    onStartLecture('omni_ai');
    showNotification?.(`Professor Omni AI is beginning master lecture on ${topicTitle}!`, 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-3xl max-h-[92vh] flex flex-col bg-slate-900 border-2 border-amber-500/40 rounded-3xl shadow-2xl shadow-amber-500/10 overflow-hidden text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-indigo-950/80 to-slate-950 border-b border-amber-500/30 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 via-indigo-600 to-cyan-500 p-0.5 shadow-lg shadow-amber-500/20 flex items-center justify-center text-xl shrink-0">
              <span className="text-white font-black text-2xl">⚡</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-1.5">
                  Professor Omni AI
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  Universal Master Tutor
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                3D Virtual Classroom & Active Socratic Intelligence • Topic: <span className="text-amber-300 font-semibold">{topicTitle || 'General Science & STEM'}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onFocusProfessorCamera();
                playSoundEffect('click');
              }}
              className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
              title="Focus 3D camera on Professor Omni"
            >
              <Compass size={13} className="text-amber-400" />
              <span>Focus Prof</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-4 pt-3 bg-slate-950/60 border-b border-slate-800 flex items-center gap-2 shrink-0 overflow-x-auto">
          <button
            onClick={() => { setActiveTab('ask'); playSoundEffect('click'); }}
            className={cn(
              "px-3 py-2 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 border-b-2 cursor-pointer shrink-0",
              activeTab === 'ask' 
                ? "bg-slate-800/90 text-amber-300 border-amber-400 shadow-sm" 
                : "text-slate-400 hover:text-slate-200 border-transparent"
            )}
          >
            <MessageSquare size={14} />
            <span>Ask Omni AI</span>
          </button>

          <button
            onClick={() => { setActiveTab('lecture'); playSoundEffect('click'); }}
            className={cn(
              "px-3 py-2 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 border-b-2 cursor-pointer shrink-0",
              activeTab === 'lecture' 
                ? "bg-slate-800/90 text-indigo-300 border-indigo-400 shadow-sm" 
                : "text-slate-400 hover:text-slate-200 border-transparent"
            )}
          >
            <Play size={14} />
            <span>Master Lecture</span>
          </button>

          <button
            onClick={() => { setActiveTab('diagram'); playSoundEffect('click'); }}
            className={cn(
              "px-3 py-2 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 border-b-2 cursor-pointer shrink-0",
              activeTab === 'diagram' 
                ? "bg-slate-800/90 text-cyan-300 border-cyan-400 shadow-sm" 
                : "text-slate-400 hover:text-slate-200 border-transparent"
            )}
          >
            <Sparkles size={14} />
            <span>Blackboard Diagrams</span>
          </button>

          <button
            onClick={() => { setActiveTab('pedagogy'); playSoundEffect('click'); }}
            className={cn(
              "px-3 py-2 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 border-b-2 cursor-pointer shrink-0",
              activeTab === 'pedagogy' 
                ? "bg-slate-800/90 text-emerald-300 border-emerald-400 shadow-sm" 
                : "text-slate-400 hover:text-slate-200 border-transparent"
            )}
          >
            <Sliders size={14} />
            <span>Teaching Profile</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {activeTab === 'ask' && (
            <div className="space-y-4">
              {/* Quick Action Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-indigo-500/10 to-transparent border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Zap size={20} />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Live Socratic Dialogue</h4>
                    <p className="text-xs text-slate-300">
                      Ask any question, request instant derivations, or probe difficult concepts.
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleStartOmniLecture}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
                >
                  <Play size={14} />
                  <span>Deliver Full Lecture</span>
                </button>
              </div>

              {/* Input Box */}
              <div className="relative">
                <textarea
                  value={customQuery}
                  onChange={(e) => setCustomQuery(e.target.value)}
                  placeholder={`Ask Professor Omni AI about ${topicTitle || 'anything in science & math'}... (e.g., "Explain how this formula works", "Draw a force diagram", "Prove this theorem")`}
                  className="w-full h-24 p-3.5 rounded-2xl bg-slate-950 border border-slate-700 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50 resize-none font-sans"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendQuery(customQuery);
                    }
                  }}
                />
                <div className="absolute right-3 bottom-3 flex items-center gap-2">
                  <button
                    onClick={() => handleSendQuery(customQuery)}
                    disabled={!customQuery.trim() || isSubmitting}
                    className={cn(
                      "px-4 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md",
                      customQuery.trim() && !isSubmitting
                        ? "bg-amber-500 hover:bg-amber-400 text-slate-950"
                        : "bg-slate-800 text-slate-500 cursor-not-allowed"
                    )}
                  >
                    <span>Ask Omni</span>
                    <Send size={13} />
                  </button>
                </div>
              </div>

              {/* Starter Quick Inquiry Cards */}
              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">
                  ⚡ Recommended Socratic Inquiries for "{topicTitle || 'Active Topic'}"
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {QUICK_PROMPTS.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSendQuery(item.prompt)}
                      className="p-3 rounded-xl bg-slate-950/70 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/40 text-left transition-all group flex flex-col justify-between cursor-pointer"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="text-base">{item.icon}</span>
                          <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300 transition-colors">
                            {item.title}
                          </span>
                        </div>
                        <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 group-hover:bg-amber-500/20 group-hover:text-amber-300">
                          {item.tag}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                        {item.prompt}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'lecture' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-950 border border-indigo-500/30 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center text-2xl shrink-0">
                    🎓
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-white">Professor Omni AI Master Lecture Pipeline</h4>
                    <p className="text-xs text-slate-300">
                      Delivers a complete, animated multi-step classroom lecture with synced LaTeX math and smartboard diagrams.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-amber-400 font-bold uppercase">Phase 1</span>
                    <h5 className="text-xs font-bold text-slate-200 mt-0.5">Intuition & Hook</h5>
                    <p className="text-[10px] text-slate-400 mt-1">Real-world analogy and the core why behind the concept.</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-indigo-400 font-bold uppercase">Phase 2</span>
                    <h5 className="text-xs font-bold text-slate-200 mt-0.5">Rigorous Boardwork</h5>
                    <p className="text-[10px] text-slate-400 mt-1">Step-by-step LaTeX math with dynamic vector schematics.</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-emerald-400 font-bold uppercase">Phase 3</span>
                    <h5 className="text-xs font-bold text-slate-200 mt-0.5">5-Level Practice</h5>
                    <p className="text-[10px] text-slate-400 mt-1">Direct substitution, unknown isolation & Olympiad traps.</p>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    onClick={handleStartOmniLecture}
                    className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-amber-500 hover:opacity-95 text-white font-black text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Play size={16} />
                    <span>Start Master Lecture on "{topicTitle || 'Active Topic'}"</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'diagram' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                    <Sparkles size={20} />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Dynamic 3D Smartboard Blackboard Schematics</h4>
                    <p className="text-xs text-slate-300">
                      Request custom vector diagrams, coordinate geometries, ray optics, and physical apparatus schematics.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  {[
                    { title: 'Coordinate Vector Geometry', desc: 'Orthogonal axes, force vectors, resolution of components', icon: '📐' },
                    { title: 'Optical Ray Paths & Lenses', desc: 'Incident rays, focal refraction, virtual & real images', icon: '🔍' },
                    { title: 'Circuit & Component Schematics', desc: 'Resistor networks, capacitors, Kirchhoff nodes', icon: '⚡' },
                    { title: 'Thermodynamic PV Diagrams', desc: 'Carnot cycles, isobaric/isothermal state curves', icon: '🔥' },
                  ].map((d, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        const prompt = `Professor Omni, draw a detailed blackboard SVG schematic diagram for ${d.title} on the topic "${topicTitle}".`;
                        handleSendQuery(prompt);
                      }}
                      className="p-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-cyan-500/40 text-left transition-all cursor-pointer flex items-center gap-3"
                    >
                      <span className="text-xl shrink-0">{d.icon}</span>
                      <div>
                        <h6 className="text-xs font-bold text-slate-200">{d.title}</h6>
                        <p className="text-[10px] text-slate-400 mt-0.5">{d.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'pedagogy' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-xl shrink-0">
                      ⚡
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Professor Omni AI Pedagogical Architecture</h4>
                      <p className="text-xs text-slate-400">Universal Socratic Mentor & STEM Visuals</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    Active Profile
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-2">
                  <p><strong className="text-white">• Pacing Rhythm:</strong> Deliberate 5-10s thinking pauses with natural breathing pauses.</p>
                  <p><strong className="text-white">• Derivations:</strong> Zero hand-waving; explicit mathematical steps with unit verification.</p>
                  <p><strong className="text-white">• Visuals:</strong> High-contrast neon chalkboard SVG graphics with real-time highlights.</p>
                  <p><strong className="text-white">• Voice:</strong> Natural scholarly cadence calibrated for immersive 3D learning.</p>
                </div>

                <button
                  onClick={() => {
                    onSelectTeacherStyle('omni_ai');
                    showNotification?.("Professor Omni AI set as active teaching persona!", "success");
                    onClose();
                  }}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
                >
                  <CheckCircle2 size={15} />
                  <span>Activate Professor Omni AI as Primary 3D Tutor</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-[11px]">Classroom Slate 3D Engine • Online</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold transition-all cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
