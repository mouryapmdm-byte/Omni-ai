import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { DeviceProfile, RenderMode, PerformanceMetrics, DataSaverStats } from './types';
import { DeviceDetector } from './deviceDetector';
import { DataSaver } from './DataSaver';
import { ProgressiveEnhancer } from './ProgressiveEnhancer';
import { DeviceTierContext, DeviceTierContextValue } from './useDeviceTier';

const STORAGE_KEY_PROFILE = 'omni_device_profile_v2';

export const DeviceTierProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [profile, setProfile] = useState<DeviceProfile>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_PROFILE);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      // ignore
    }
    return DeviceDetector.detectCapabilities();
  });

  const [metrics, setMetrics] = useState<PerformanceMetrics>(() => ProgressiveEnhancer.getMetrics());
  const [dataSaverStats, setDataSaverStats] = useState<DataSaverStats>(() => DataSaver.getStats());

  // Save profile to storage
  const saveProfile = useCallback((updated: DeviceProfile) => {
    setProfile(updated);
    try {
      localStorage.setItem(STORAGE_KEY_PROFILE, JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to persist device profile', e);
    }
  }, []);

  const setRenderMode = useCallback((mode: RenderMode) => {
    saveProfile({
      ...profile,
      mode,
      autoDetected: false,
      updatedAt: new Date().toISOString()
    });
  }, [profile, saveProfile]);

  const toggleDataSaver = useCallback(() => {
    saveProfile({
      ...profile,
      dataSaverEnabled: !profile.dataSaverEnabled,
      updatedAt: new Date().toISOString()
    });
  }, [profile, saveProfile]);

  const setDataSaverEnabled = useCallback((enabled: boolean) => {
    saveProfile({
      ...profile,
      dataSaverEnabled: enabled,
      updatedAt: new Date().toISOString()
    });
  }, [profile, saveProfile]);

  const reProbeDevice = useCallback(() => {
    const probed = DeviceDetector.detectCapabilities(profile.studentId);
    saveProfile(probed);
  }, [profile.studentId, saveProfile]);

  const profileRef = React.useRef(profile);
  useEffect(() => {
    profileRef.current = profile;
  }, [profile]);

  // Start FPS monitoring and listen to progressive enhancement signals
  useEffect(() => {
    ProgressiveEnhancer.startFpsMonitoring();

    const unsubscribe = ProgressiveEnhancer.onMetrics((latestMetrics) => {
      setMetrics(prev => {
        if (
          prev.averageFps === latestMetrics.averageFps &&
          prev.isThrottlingRecommended === latestMetrics.isThrottlingRecommended &&
          prev.frameDropCount === latestMetrics.frameDropCount
        ) {
          return prev;
        }
        return latestMetrics;
      });

      const currentProfile = profileRef.current;
      // Auto-downgrade if autoDetected was left on and performance is struggling
      if (currentProfile.autoDetected && latestMetrics.isThrottlingRecommended) {
        const adaptiveMode = ProgressiveEnhancer.evaluateAdaptiveMode(currentProfile.mode, latestMetrics);
        if (adaptiveMode !== currentProfile.mode) {
          saveProfile({
            ...currentProfile,
            mode: adaptiveMode,
            measuredFps: latestMetrics.averageFps,
            jankCount: latestMetrics.frameDropCount,
            updatedAt: new Date().toISOString()
          });
        }
      }
    });

    const statsInterval = setInterval(() => {
      setDataSaverStats(DataSaver.getStats());
    }, 5000);

    return () => {
      ProgressiveEnhancer.stopFpsMonitoring();
      unsubscribe();
      clearInterval(statsInterval);
    };
  }, [saveProfile]);

  const isLiteMode = profile.mode === 'lite';
  const isAudioOnly = profile.mode === 'audio-only';
  const isFullMode = profile.mode === 'full';

  const contextValue: DeviceTierContextValue = useMemo(() => ({
    profile,
    setRenderMode,
    toggleDataSaver,
    setDataSaverEnabled,
    metrics,
    dataSaverStats,
    isLiteMode,
    isAudioOnly,
    isFullMode,
    reProbeDevice
  }), [profile, setRenderMode, toggleDataSaver, setDataSaverEnabled, metrics, dataSaverStats, isLiteMode, isAudioOnly, isFullMode, reProbeDevice]);

  return (
    <DeviceTierContext.Provider value={contextValue}>
      {children}
    </DeviceTierContext.Provider>
  );
};
