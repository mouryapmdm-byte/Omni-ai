export const PHYSICS_QUESTIONS = [
  {
    id: 'pq1',
    chapterId: 'electric_charges_fields',
    chapterTitle: '1. Electric Charges and Fields',
    section: 'A',
    marks: 1,
    questionText: 'Which of the following is NOT a property of electric field lines?',
    options: [
      'Field lines never intersect each other',
      'They originate from positive charge and terminate at negative charge',
      'They form closed loops',
      'They are perpendicular to the surface of a charged conductor'
    ],
    correctAnswer: 'They form closed loops',
    solution: 'Electric field lines do not form closed loops; they start from positive charges and end at negative charges. Magnetic field lines, however, form closed loops.',
    subtopicRef: 'Electric field lines'
  },
  {
    id: 'pq2',
    chapterId: 'electrostatic_potential_capacitance',
    chapterTitle: '2. Electrostatic Potential and Capacitance',
    section: 'A',
    marks: 1,
    questionText: 'The capacitance of a parallel plate capacitor is NOT affected by:',
    options: [
      'Area of the plates',
      'Distance between the plates',
      'Dielectric medium between the plates',
      'Charge on the plates'
    ],
    correctAnswer: 'Charge on the plates',
    solution: 'Capacitance C = ε₀A/d (for a vacuum). Charge Q = CV. Capacitance depends on the geometry and the medium, not on the charge or potential itself.',
    subtopicRef: 'Capacitors and capacitance'
  },
  {
    id: 'pq3',
    chapterId: 'current_electricity',
    chapterTitle: '3. Current Electricity',
    section: 'A',
    marks: 1,
    questionText: 'The drift velocity of electrons in a conductor is directly proportional to:',
    options: [
      'The area of cross-section',
      'The length of the conductor',
      'The applied electric field',
      'The temperature of the conductor'
    ],
    correctAnswer: 'The applied electric field',
    solution: 'Drift velocity v_d = e E τ / m, where E is the applied electric field.',
    subtopicRef: 'Drift velocity'
  },
  {
    id: 'pq4',
    chapterId: 'moving_charges_magnetism',
    chapterTitle: '4. Moving Charges and Magnetism',
    section: 'A',
    marks: 1,
    questionText: 'A charged particle moving in a magnetic field experiences a force that is:',
    options: [
      'Parallel to the magnetic field',
      'Parallel to the velocity',
      'Perpendicular to both magnetic field and velocity',
      'Zero at all times'
    ],
    correctAnswer: 'Perpendicular to both magnetic field and velocity',
    solution: 'The magnetic force is F = q(v × B), which is perpendicular to both v and B.',
    subtopicRef: 'Force on a moving charge in magnetic field'
  },
  {
    id: 'pq5',
    chapterId: 'ray_optics',
    chapterTitle: '9. Ray Optics and Optical Instruments',
    section: 'A',
    marks: 1,
    questionText: 'The phenomenon of total internal reflection occurs when light travels from:',
    options: [
      'Rarer to denser medium',
      'Denser to rarer medium at an angle greater than critical angle',
      'Denser to rarer medium at an angle less than critical angle',
      'One medium to another with the same refractive index'
    ],
    correctAnswer: 'Denser to rarer medium at an angle greater than critical angle',
    solution: 'Total internal reflection occurs when light goes from a denser to a rarer medium and the angle of incidence is greater than the critical angle.',
    subtopicRef: 'Total internal reflection'
  }
];
