import { useState, useEffect } from 'react';

export function useOnlineSync(onSyncRelease?: () => Promise<void>) {
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'completed' | 'failed'>('idle');

  useEffect(() => {
    const handleOnline = async () => {
      setIsOnline(true);
      if (onSyncRelease) {
        setSyncStatus('syncing');
        try {
          await onSyncRelease();
          setSyncStatus('completed');
        } catch (error) {
          console.error('[OmniAI Sync Queue] Batch upload failed:', error);
          setSyncStatus('failed');
        }
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      setSyncStatus('idle');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [onSyncRelease]);

  return { isOnline, syncStatus };
}
