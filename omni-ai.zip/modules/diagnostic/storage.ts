export * from '../../src/modules/diagnostic/storage';
