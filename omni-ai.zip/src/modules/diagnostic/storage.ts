import { DiagnosticResult } from './types';

const DIAGNOSTIC_STORAGE_PREFIX = 'omni_diagnostic_res_';
const LISTENERS: Array<() => void> = [];

export function saveDiagnosticResult(result: DiagnosticResult): void {
  try {
    const key = `${DIAGNOSTIC_STORAGE_PREFIX}${result.chapterId}`;
    localStorage.setItem(key, JSON.stringify(result));
    notifyListeners();
  } catch (e) {
    console.error('Error saving diagnostic result:', e);
  }
}

export function getDiagnosticResult(chapterId: string = 'electromagnetism'): DiagnosticResult | null {
  try {
    const key = `${DIAGNOSTIC_STORAGE_PREFIX}${chapterId}`;
    const raw = localStorage.getItem(key);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error reading diagnostic result:', e);
  }
  return null;
}

export function markChapterSkipped(chapterId: string = 'electromagnetism', studentId: string = 'student_default'): DiagnosticResult {
  const dummy: DiagnosticResult = {
    studentId,
    chapterId,
    chapterTitle: 'Electromagnetism & AC Theory',
    subject: 'Physics',
    topicScores: {},
    detailedTopics: {},
    overallScore: 0,
    masteryPercentage: 0,
    abilityTheta: 0,
    standardError: 1.0,
    confidenceInterval: [-1.96, 1.96],
    totalQuestionsAnswered: 0,
    timeTaken: 0,
    totalMinutesSaved: 0,
    skippedMinutes: 0,
    isSkipped: true,
    completedAt: new Date().toISOString()
  };
  saveDiagnosticResult(dummy);
  return dummy;
}

export function clearDiagnosticResult(chapterId: string = 'electromagnetism'): void {
  try {
    const key = `${DIAGNOSTIC_STORAGE_PREFIX}${chapterId}`;
    localStorage.removeItem(key);
    notifyListeners();
  } catch (e) {
    console.error('Error clearing diagnostic result:', e);
  }
}

export function subscribeToDiagnosticUpdates(callback: () => void): () => void {
  LISTENERS.push(callback);
  return () => {
    const idx = LISTENERS.indexOf(callback);
    if (idx !== -1) LISTENERS.splice(idx, 1);
  };
}

function notifyListeners(): void {
  LISTENERS.forEach(cb => {
    try { cb(); } catch {}
  });
}
