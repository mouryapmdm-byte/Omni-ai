const fs = require('fs');
const file = 'src/components/Chat.tsx';
let content = fs.readFileSync(file, 'utf8');

// 1. Add state variable
if (!content.includes('isRecentGraphsModalOpen')) {
    const stateHook = '  const [isCachedFiguresModalOpen, setIsCachedFiguresModalOpen] = useState(false);';
    content = content.replace(stateHook, stateHook + '\n  const [isRecentGraphsModalOpen, setIsRecentGraphsModalOpen] = useState(false);');
}

// 2. Add useMemo for recentGraphs
if (!content.includes('const recentGraphs = useMemo')) {
    const memoTarget = '  const [isCacheStatsModalOpen, setIsCacheStatsModalOpen] = useState<boolean>(false);';
    const memoContent = `
  const recentGraphs = useMemo(() => {
    return localMessages
      .filter(msg => msg.metadata?.mathGraphFunctions && msg.metadata.mathGraphFunctions.length > 0)
      .map(msg => ({
        id: msg.id,
        functions: msg.metadata.mathGraphFunctions,
        timestamp: new Date(msg.timestamp).toLocaleTimeString(),
        preview: msg.content.substring(0, 60) + "..."
      }));
  }, [localMessages]);`;
    content = content.replace(memoTarget, memoTarget + '\n' + memoContent);
}

// 3. Add buttons to open it (at 5918 and 12357ish)
// Let's find the Cache button and add it right after.
const buttonString = `<Database size={14} className="text-cyan-400" />
                    <span>⚡ Cache ({cachedStudyFigures.length})</span>
                  </button>`;

const newButtonString = buttonString + `

                  <button
                    type="button"
                    onClick={() => setIsRecentGraphsModalOpen(true)}
                    className="px-3 py-1.5 rounded-xl bg-indigo-950/90 border border-indigo-500/40 hover:bg-indigo-900 text-indigo-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    title="View recently generated graphs"
                  >
                    <LineChartIcon size={14} className="text-indigo-400" />
                    <span>📈 Graphs ({recentGraphs.length})</span>
                  </button>`;

content = content.split(buttonString).join(newButtonString);

// Also need LineChartIcon from lucide-react
if (!content.includes('LineChartIcon')) {
    content = content.replace('Trash2,', 'Trash2,\n  LineChart as LineChartIcon,');
}

// 4. Add the modal
const modalTarget = '{/* Cached Study Figures Modal */}';
const modalContent = `
      {/* Recent Graphs Modal */}
      {isRecentGraphsModalOpen && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-4xl rounded-3xl p-6 border shadow-2xl space-y-5 bg-slate-900 border-slate-700 text-white animate-in zoom-in-95 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shadow-lg">
                  <LineChartIcon size={22} />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-indigo-50 tracking-tight">Recent Graphs</h2>
                  <p className="text-sm text-slate-400 font-medium">Revisit previously generated mathematical curves</p>
                </div>
              </div>
              <button 
                onClick={() => setIsRecentGraphsModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer border border-slate-700 hover:border-slate-600"
              >
                <X size={20} />
              </button>
            </div>

            {recentGraphs.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-slate-500">
                <LineChartIcon size={48} className="mb-4 opacity-20" />
                <p className="text-lg font-medium">No graphs generated yet</p>
                <p className="text-sm">Ask the AI to plot a function like f(x) = x^2</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto pr-1">
                {recentGraphs.map((graph) => (
                  <div key={graph.id} className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-bold text-sm text-indigo-200">f(x) = {graph.functions.join(', ')}</div>
                        <div className="text-[10px] font-mono text-slate-400">{graph.timestamp}</div>
                      </div>
                      <button 
                        onClick={() => {
                          const el = document.getElementById(\`msg-\${graph.id}\`);
                          if (el) {
                            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            setIsRecentGraphsModalOpen(false);
                          }
                        }}
                        className="text-xs bg-slate-950 text-indigo-300 px-2 py-1 rounded hover:bg-indigo-900 border border-slate-700 hover:border-indigo-500 transition cursor-pointer"
                      >
                        Go to message
                      </button>
                    </div>
                    <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden relative">
                      <div className="absolute inset-0 pointer-events-none z-10" />
                      <MathGraph functions={graph.functions} theme={theme} />
                    </div>
                    <p className="text-xs text-slate-400 line-clamp-2 italic border-l-2 border-slate-700 pl-2">
                      {graph.preview}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
`;

content = content.replace(modalTarget, modalContent + '\n      ' + modalTarget);

fs.writeFileSync(file, content);
console.log("Added Recent Graphs panel");
