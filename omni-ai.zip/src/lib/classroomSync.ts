import { doc, onSnapshot, setDoc, updateDoc, getDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';

export interface ClassroomSyncState {
  classCode: string;
  content: string;
  topicTitle: string;
  slideIndex?: number;
  chalkColor?: string;
  isBroadcasting: boolean;
  broadcasterName?: string;
  updatedAt: number;
  activeFormulaId?: string;
}

export const DEFAULT_CLASS_CODE = 'CLASS-101';

/**
 * Get stored or URL-provided class synchronization code
 */
export function getInitialClassCode(): string {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const codeFromUrl = urlParams.get('classCode') || urlParams.get('syncCode');
    if (codeFromUrl) {
      const sanitized = codeFromUrl.trim().toUpperCase().replace(/[^A-Z0-9_\-]/g, '');
      if (sanitized) {
        localStorage.setItem('omni_active_class_code', sanitized);
        return sanitized;
      }
    }
    const saved = localStorage.getItem('omni_active_class_code');
    if (saved) return saved.trim().toUpperCase();
  } catch (err) {
    console.warn('Failed to read class code from URL/localStorage:', err);
  }
  return DEFAULT_CLASS_CODE;
}

/**
 * Broadcast current classroom slate state to Firestore in real-time
 */
export async function broadcastClassroomState(
  classCode: string,
  data: Partial<ClassroomSyncState>
): Promise<void> {
  if (!classCode) return;
  const sanitizedCode = classCode.trim().toUpperCase();
  const docRef = doc(db, 'classroom_sync', sanitizedCode);
  
  const payload: ClassroomSyncState = {
    classCode: sanitizedCode,
    content: data.content || '',
    topicTitle: data.topicTitle || 'Interactive Classroom Slate',
    slideIndex: data.slideIndex ?? 0,
    chalkColor: data.chalkColor || 'white',
    isBroadcasting: data.isBroadcasting ?? true,
    broadcasterName: data.broadcasterName || 'Prof. Omni AI',
    updatedAt: Date.now(),
    activeFormulaId: data.activeFormulaId || '',
  };

  try {
    await setDoc(docRef, payload, { merge: true });
  } catch (error) {
    console.error('Failed to broadcast classroom state:', error);
    handleFirestoreError(error, OperationType.WRITE, `classroom_sync/${sanitizedCode}`);
  }
}

/**
 * Subscribe to real-time classroom slate state changes for a class code
 */
export function subscribeToClassroomSync(
  classCode: string,
  onUpdate: (state: ClassroomSyncState | null) => void
): () => void {
  if (!classCode) {
    onUpdate(null);
    return () => {};
  }
  
  const sanitizedCode = classCode.trim().toUpperCase();
  const docRef = doc(db, 'classroom_sync', sanitizedCode);

  try {
    const unsubscribe = onSnapshot(
      docRef,
      (docSnap) => {
        if (docSnap.exists()) {
          onUpdate(docSnap.data() as ClassroomSyncState);
        } else {
          onUpdate(null);
        }
      },
      (error) => {
        console.error('Error listening to classroom sync:', error);
        onUpdate(null);
      }
    );
    return unsubscribe;
  } catch (error) {
    console.error('Failed to subscribe to classroom sync:', error);
    return () => {};
  }
}
