const fs = require('fs');
const path = require('path');

const curriculum = {
  board: "CBSE",
  class: 9,
  subjects: [
    {
      name: "Mathematics",
      class: 9,
      board: "CBSE",
      theoryMarks: 80,
      practicalMarks: 0,
      internalMarks: 20,
      duration: "3 Hours",
      components: [
        {
          name: "Unit I: Number Systems",
          marks: 10,
          type: "theory",
          description: "Real numbers, representation, terminating/recurring decimals, irrational numbers, and radical laws.",
          topics: [
            {
              name: "Real Numbers & Radical Laws",
              marks: 10,
              description: "Review of real numbers on the number line, irrational numbers, rationalization, and laws of exponents.",
              examRelevance: "theory",
              tags: ["math-class9-real-numbers", "number-systems"],
              subtopics: [
                {
                  name: "Representation & Decimal Expansions",
                  description: "Representation of natural numbers, integers, and rational numbers on number line. Rational numbers as terminating or recurring decimals.",
                  learningOutcomes: ["Represent real numbers on number line", "Convert terminating and recurring decimals to rational form p/q"],
                  keyConcepts: ["Rational numbers", "Terminating decimals", "Non-terminating recurring decimals"],
                  formulas: ["p/q form where q != 0"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Number line plotting of recurring decimals"],
                  assessmentType: ["objective", "short-answer"]
                },
                {
                  name: "Irrational Numbers",
                  description: "Definition and examples (e.g., √2, √3). Rational and irrational numbers as real numbers. Locating irrational numbers on the number line.",
                  learningOutcomes: ["Define irrational numbers", "Locate square roots of positive integers on number line using Pythagoras spiral"],
                  keyConcepts: ["Irrational numbers", "Real number line completeness", "Square root spiral"],
                  formulas: ["c^2 = a^2 + b^2 (Pythagoras theorem for plotting)"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Constructing the square root spiral"],
                  assessmentType: ["short-answer", "construction"]
                },
                {
                  name: "Radical Laws & Rationalization",
                  description: "Rationalization of real numbers of the type 1/(a + b√x) and 1/(√x + √y). Laws of exponents with integral and rational exponents for real bases.",
                  learningOutcomes: ["Rationalize binomial quadratic surd denominators", "Apply laws of exponents to real numbers with rational exponents"],
                  keyConcepts: ["Conjugate surds", "Rationalizing factor", "Laws of exponents: a^m * a^n = a^(m+n), (a^m)^n = a^(mn)"],
                  formulas: [
                    "1 / (√x + √y) = (√x - √y) / (x - y)",
                    "1 / (a + b√x) = (a - b√x) / (a^2 - b^2 * x)",
                    "a^(p/q) = (a^(1/q))^p"
                  ],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Simplification drills of surd expressions"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Unit II: Algebra",
          marks: 20,
          type: "theory",
          description: "Polynomials, Factor and Remainder theorems, algebraic expansion identities, and linear equations in two variables.",
          topics: [
            {
              name: "Polynomials & Factoring",
              marks: 14,
              description: "Definition of polynomial in one variable, zeros, Remainder and Factor theorems, splitting the middle term, and algebraic identities.",
              examRelevance: "theory",
              tags: ["math-class9-polynomials", "factor-theorem", "algebraic-identities"],
              subtopics: [
                {
                  name: "Polynomial Classification & Zeros",
                  description: "Definition in one variable, coefficients, terms, zero polynomial, degree, constant/linear/quadratic/cubic, monomials/binomials/trinomials, factors and multiples, zeros.",
                  learningOutcomes: ["Classify polynomials by terms and degree", "Find zeros of linear and quadratic polynomials"],
                  keyConcepts: ["Degree of polynomial", "Zero polynomial (degree undefined)", "Roots / Zeros"],
                  formulas: ["p(x) = a_n x^n + ... + a_1 x + a_0"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Evaluating polynomial values p(k)"],
                  assessmentType: ["objective", "short-answer"]
                },
                {
                  name: "Remainder & Factor Theorems",
                  description: "Remainder Theorem statement and proof motivation. Factor Theorem statement and proof execution. Factoring ax² + bx + c (a ≠ 0) by splitting the middle term.",
                  learningOutcomes: ["Apply Remainder Theorem to find remainders without long division", "Factorize quadratic trinomials by splitting middle term and cubic polynomials using Factor Theorem"],
                  keyConcepts: ["Dividend = Divisor * Quotient + Remainder", "Factor Theorem: p(a)=0 <=> (x-a) is a factor"],
                  formulas: ["p(x) = (x - a)q(x) + p(a)"],
                  proofs: ["Factor Theorem statement and proof execution (proof-mandatory)"],
                  derivations: ["Remainder theorem proof motivation"],
                  exclusions: [],
                  activities: ["Splitting middle term factor puzzle cards"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Algebraic Expansion Identities",
                  description: "Proof and application of standard algebraic identities: (x+y+z)², (x±y)³, and x³+y³+z³ - 3xyz.",
                  learningOutcomes: ["Expand trinomial squares and binomial cubes", "Factorize polynomials using three-variable cubic identity"],
                  keyConcepts: ["Trinomial square identity", "Cubic expansion identities", "Conditional identity: if x+y+z=0 then x³+y³+z³=3xyz"],
                  formulas: [
                    "(x + y + z)^2 = x^2 + y^2 + z^2 + 2xy + 2yz + 2zx",
                    "(x ± y)^3 = x^3 ± y^3 ± 3xy(x ± y)",
                    "x^3 + y^3 + z^3 - 3xyz = (x + y + z)(x^2 + y^2 + z^2 - xy - yz - zx)"
                  ],
                  proofs: ["Proof of standard algebraic expansion identities"],
                  derivations: ["Derivation of x³ + y³ + z³ - 3xyz identity"],
                  exclusions: [],
                  activities: ["Geometric verification of (x+y+z)² using paper cutouts"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Linear Equations in Two Variables",
              marks: 6,
              description: "Introduction to ax + by + c = 0, infinitely many solutions, Cartesian graph plotting, and situational word problems.",
              examRelevance: "theory",
              tags: ["math-class9-linear-equations", "graphing"],
              subtopics: [
                {
                  name: "Standard Form & Solutions",
                  description: "Introduction to the equation of the form ax + by + c = 0. Explaining that a linear equation in two variables has infinitely many solutions.",
                  learningOutcomes: ["Express linear equations in standard form ax + by + c = 0", "Find multiple ordered pair solutions (x, y)"],
                  keyConcepts: ["Linear equation in two variables", "Infinite ordered pair solutions"],
                  formulas: ["ax + by + c = 0"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Tabulating ordered pair solution sets"],
                  assessmentType: ["objective", "short-answer"]
                },
                {
                  name: "Graphing & Situational Word Problems",
                  description: "Plotting and graphing a linear equation in two variables on the Cartesian plane. Real-world situational word problems.",
                  learningOutcomes: ["Plot straight line graph of linear equations", "Formulate linear models from real-world situations (fare, speed, distance)"],
                  keyConcepts: ["Straight line graph", "Equations of lines parallel to X and Y axes (x = a, y = b)"],
                  formulas: ["x = a (vertical line), y = b (horizontal line)"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Graphing real-life taxi fare equations on graph paper"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Unit III: Coordinate Geometry",
          marks: 4,
          type: "theory",
          description: "Cartesian plane, coordinate axes, quadrants, plotting points, and abscissa/ordinate identification.",
          topics: [
            {
              name: "Cartesian Grid Mapping",
              marks: 4,
              description: "The Cartesian plane, coordinate axes X and Y, quadrants, coordinates of a point, abscissa and ordinate.",
              examRelevance: "theory",
              tags: ["math-class9-coordinate-geometry", "cartesian-plane"],
              subtopics: [
                {
                  name: "Cartesian Plane & Coordinates",
                  description: "Cartesian plane, coordinate axes (X and Y), quadrants I-IV, naming and plotting points in the plane, identifying abscissa and ordinate.",
                  learningOutcomes: ["Identify quadrants and axes for any point (x, y)", "Locate and plot coordinates accurately on the plane"],
                  keyConcepts: ["Abscissa (x-coordinate)", "Ordinate (y-coordinate)", "Origin (0,0)", "Sign conventions in four quadrants"],
                  formulas: ["Point P = (x, y)"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Plotting geometric figures on coordinate grids"],
                  assessmentType: ["objective", "short-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Unit IV: Geometry",
          marks: 27,
          type: "theory",
          description: "Introduction to Euclid's Geometry, Lines and Angles, Triangles, Quadrilaterals, and Circles.",
          topics: [
            {
              name: "Introduction to Euclid's Geometry",
              marks: 2,
              description: "History of geometry, Euclid's definitions, axioms, postulates, and theorem on intersecting lines.",
              examRelevance: "theory",
              tags: ["math-class9-euclid", "axioms-postulates"],
              subtopics: [
                {
                  name: "Euclid's Axioms & Postulates",
                  description: "Euclid's 5 postulates (specifically Postulate 5 and parallel equivalents), common axioms, and proof that two lines cannot intersect at more than one point.",
                  learningOutcomes: ["State Euclid's 5 postulates", "Apply axioms to deductive geometric reasoning"],
                  keyConcepts: ["Undefined terms: point, line, plane", "Axioms vs Postulates", "Euclid's fifth postulate"],
                  formulas: [],
                  proofs: ["Two distinct lines cannot have more than one point in common"],
                  derivations: [],
                  exclusions: [],
                  activities: ["Historical timeline chart of Greek and Indian mathematicians"],
                  assessmentType: ["objective", "short-answer"]
                }
              ]
            },
            {
              name: "Lines and Angles",
              marks: 6,
              description: "Vertically opposite angles theorem, parallel lines and transversal relationships, angle sum property of triangle.",
              examRelevance: "theory",
              tags: ["math-class9-lines-angles", "proof-mandatory"],
              subtopics: [
                {
                  name: "Intersecting & Parallel Lines",
                  description: "Vertically opposite angles theorem (Proof mandatory). Corresponding angles, alternate interior angles, consecutive interior angles on same side of transversal.",
                  learningOutcomes: ["Prove vertically opposite angles are equal", "Solve angle problems using transversal properties on parallel lines"],
                  keyConcepts: ["Vertically opposite angles", "Alternate interior angles", "Transversal line"],
                  formulas: ["Alternate interior angles are equal", "Co-interior angles sum = 180°"],
                  proofs: ["Vertically opposite angles are equal when two lines intersect (proof-mandatory)"],
                  derivations: [],
                  exclusions: [],
                  activities: ["Verifying transversal angles using dynamic geometry tools"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Angle Sum Property of a Triangle",
                  description: "Sum of angles in a triangle is 180° (Proof mandatory). Exterior angle theorem and applications.",
                  learningOutcomes: ["Prove the angle sum property of triangle", "Apply exterior angle theorem to numerical geometry questions"],
                  keyConcepts: ["Triangle angle sum = 180°", "Exterior angle = sum of interior opposite angles"],
                  formulas: ["∠A + ∠B + ∠C = 180°", "Exterior ∠ = sum of two interior opposite angles"],
                  proofs: ["The sum of the angles of a triangle is 180° (proof-mandatory)"],
                  derivations: [],
                  exclusions: [],
                  activities: ["Paper tearing activity to show three angles form a straight line 180°"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Triangles & Congruence",
              marks: 7,
              description: "SAS, ASA, SSS, RHS congruence criteria, isosceles triangle theorems.",
              examRelevance: "theory",
              tags: ["math-class9-triangles-congruence", "proof-mandatory"],
              subtopics: [
                {
                  name: "Congruence Criteria & Theorems",
                  description: "SAS, ASA, SSS, and RHS congruency conditions. Proving angles opposite to equal sides of an isosceles triangle are equal (Proof mandatory), and its converse.",
                  learningOutcomes: ["Apply SAS, ASA, SSS, RHS congruence criteria in geometric proofs", "Prove that angles opposite to equal sides of isosceles triangle are equal"],
                  keyConcepts: ["Congruent figures", "CPCTC (Corresponding Parts of Congruent Triangles are Congruent)", "Isosceles triangle symmetry"],
                  formulas: ["ΔABC ≅ ΔPQR => AB=PQ, BC=QR, AC=PR, ∠A=∠P, ∠B=∠Q, ∠C=∠R"],
                  proofs: [
                    "Angles opposite to equal sides of an isosceles triangle are equal (proof-mandatory)",
                    "Sides opposite to equal angles of a triangle are equal"
                  ],
                  derivations: [],
                  exclusions: ["Inequalities in a triangle (excluded)"],
                  activities: ["Tracing congruent triangles on tracing paper"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Quadrilaterals & Mid-point Theorem",
              marks: 6,
              description: "Parallelogram properties and proofs, Mid-point Theorem and converse.",
              examRelevance: "theory",
              tags: ["math-class9-quadrilaterals", "mid-point-theorem", "proof-mandatory"],
              subtopics: [
                {
                  name: "Parallelogram Proofs & Properties",
                  description: "A diagonal divides a parallelogram into two congruent triangles (Proof mandatory). In a parallelogram, opposite sides are equal, opposite angles are equal, and diagonals bisect each other.",
                  learningOutcomes: ["Prove diagonal splits parallelogram into two congruent triangles", "Deduce properties of rectangle, rhombus, and square"],
                  keyConcepts: ["Parallelogram", "Diagonal partition", "Bisecting diagonals"],
                  formulas: [],
                  proofs: ["A diagonal divides a parallelogram into two congruent triangles (proof-mandatory)"],
                  derivations: [],
                  exclusions: [],
                  activities: ["Proving rhombus diagonals are perpendicular bisectors"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "The Mid-point Theorem",
                  description: "Proving that the line segment joining the mid-points of two sides of a triangle is parallel to the third side and half of it (Proof mandatory), and its converse.",
                  learningOutcomes: ["Prove and apply the Mid-point Theorem", "Apply converse of mid-point theorem to multi-step proofs"],
                  keyConcepts: ["Mid-point of a line segment", "Parallel mid-segment of triangle"],
                  formulas: ["DE || BC and DE = 1/2 * BC"],
                  proofs: ["The line segment joining mid-points of two sides of a triangle is parallel to the third side and half of it (proof-mandatory)"],
                  derivations: ["Converse of Mid-point Theorem derivation"],
                  exclusions: [],
                  activities: ["Paper folding to demonstrate Mid-point Theorem"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Circles",
              marks: 6,
              description: "Chords, center perpendiculars, subtended arc angle at center vs boundary, cyclic quadrilaterals.",
              examRelevance: "theory",
              tags: ["math-class9-circles", "proof-mandatory"],
              subtopics: [
                {
                  name: "Chord & Center Theorems",
                  description: "Equal chords subtend equal angles at the center (Proof mandatory) and converse. Perpendicular from center to chord bisects the chord and converse. Chords equidistant from center.",
                  learningOutcomes: ["Prove equal chords subtend equal angles at center", "Use perpendicular chord bisection to calculate chord lengths and radii"],
                  keyConcepts: ["Chord", "Subtended angles", "Perpendicular distance from center"],
                  formulas: ["r^2 = d^2 + (chord / 2)^2 (Pythagorean relation)"],
                  proofs: ["Equal chords subtend equal angles at the center (proof-mandatory)"],
                  derivations: [],
                  exclusions: [],
                  activities: ["Paper folding to find center of circular disc"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Arc Subtended Angles & Cyclic Quadrilaterals",
                  description: "Angle subtended by an arc at the center is double the angle subtended at remaining circumference (Proof mandatory). Angles in same segment are equal. Opposite angles of cyclic quadrilateral are supplementary (Proof mandatory).",
                  learningOutcomes: ["Prove central angle is double inscribed angle", "Prove cyclic quadrilaterals have supplementary opposite angles", "Calculate angles subtended in semi-circles and segments"],
                  keyConcepts: ["Inscribed angle theorem", "Angle in semi-circle is 90°", "Cyclic quadrilateral"],
                  formulas: [
                    "∠AOB = 2 * ∠APB",
                    "Opposite angles of cyclic quadrilateral sum to 180°: ∠A + ∠C = 180°"
                  ],
                  proofs: [
                    "Angle subtended by an arc at center is double the angle subtended at any point on remaining part of circle (proof-mandatory)",
                    "Opposite angles of a cyclic quadrilateral are supplementary (proof-mandatory)"
                  ],
                  derivations: [],
                  exclusions: [],
                  activities: ["Verifying cyclic quadrilateral supplementary angles using circular geoboards"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Unit V: Mensuration",
          marks: 13,
          type: "theory",
          description: "Heron's Formula for triangle area without quadrilateral reductions; Surface areas and volumes of cones, cylinders, cubes, cuboids, spheres, hemispheres.",
          topics: [
            {
              name: "Heron's Formula",
              marks: 4,
              description: "Calculation of triangle area using semi-perimeter formula without quadrilateral reductions.",
              examRelevance: "theory",
              tags: ["math-class9-heron-formula", "mensuration"],
              subtopics: [
                {
                  name: "Triangle Area via Semi-Perimeter",
                  description: "Heron's Formula s = (a+b+c)/2 and Area = √[s(s-a)(s-b)(s-c)]. Application of formula directly to scalene and isosceles triangles without quadrilateral reductions.",
                  learningOutcomes: ["Calculate semi-perimeter and triangle area without height given", "Solve practical triangle land area problems"],
                  keyConcepts: ["Semi-perimeter s", "Heron's area formula"],
                  formulas: [
                    "s = (a + b + c) / 2",
                    "Area = sqrt(s * (s - a) * (s - b) * (s - c))"
                  ],
                  proofs: [],
                  derivations: [],
                  exclusions: ["Application of Heron's formula in finding area of quadrilaterals (excluded)"],
                  activities: ["Calculating area of triangular fields from side measurements"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Surface Areas and Volumes",
              marks: 9,
              description: "Surface areas (lateral, total) and volumes of right circular cones, cylinders, cubes, cuboids, spheres, and hemispheres.",
              examRelevance: "theory",
              tags: ["math-class9-surface-areas-volumes", "solids"],
              subtopics: [
                {
                  name: "Surface Areas of 3D Solids",
                  description: "Formula derivations and computation of curved/lateral and total surface areas of cubes, cuboids, cylinders, cones, spheres, and hemispheres.",
                  learningOutcomes: ["Compute CSA, TSA of right circular cones, spheres, cylinders, and cubes", "Differentiate between CSA and TSA in real-world painting/canopy scenarios"],
                  keyConcepts: ["Curved Surface Area", "Total Surface Area", "Slant height l = √(r² + h²)"],
                  formulas: [
                    "Cone CSA = πrl, TSA = πr(l + r)",
                    "Sphere TSA = 4πr²",
                    "Hemisphere CSA = 2πr², TSA = 3πr²",
                    "Cylinder CSA = 2πrh, TSA = 2πr(r + h)",
                    "Cuboid TSA = 2(lb + bh + hl)"
                  ],
                  proofs: [],
                  derivations: ["Derivation of cone slant height l = sqrt(r^2 + h^2)"],
                  exclusions: [],
                  activities: ["Unfolding cone paper nets to derive curved area formula πrl"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Volumes of 3D Solids",
                  description: "Computation of volumes and capacities of right circular cones, cylinders, spheres, and hemispheres.",
                  learningOutcomes: ["Calculate volume and liquid capacity (litres) of 3D solids", "Relate cylinder volume to cone volume (1/3 ratio)"],
                  keyConcepts: ["Volume vs Capacity", "1 m³ = 1000 litres"],
                  formulas: [
                    "Cone Volume = 1/3 * πr²h",
                    "Sphere Volume = 4/3 * πr³",
                    "Hemisphere Volume = 2/3 * πr³",
                    "Cylinder Volume = πr²h"
                  ],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Pouring water from cone into cylinder of same radius and height"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Unit VI: Statistics",
          marks: 6,
          type: "theory",
          description: "Data collection, presentation of raw/grouped data, Bar Graphs, Histograms (uniform & varying widths), Frequency Polygons.",
          topics: [
            {
              name: "Data Visualisation",
              marks: 6,
              description: "Collection of data, ungrouped and grouped tables, Bar Graphs, Histograms (uniform/varying base widths), and Frequency Polygons.",
              examRelevance: "theory",
              tags: ["math-class9-statistics", "histograms", "frequency-polygons"],
              subtopics: [
                {
                  name: "Graphical Representation of Data",
                  description: "Presentation of data in grouped frequency distributions. Constructing statistical diagrams: Bar Graphs, Histograms with uniform and varying base widths, and Frequency Polygons.",
                  learningOutcomes: ["Construct histograms with equal and varying class interval widths", "Draw frequency polygons using class marks"],
                  keyConcepts: ["Class interval", "Class mark = (upper + lower) / 2", "Adjusted frequency for varying widths = (minimum width / class width) * frequency", "Frequency polygon"],
                  formulas: [
                    "Class mark = (Upper Limit + Lower Limit) / 2",
                    "Adjusted Frequency = (Min Class Width / Current Class Width) * Class Frequency"
                  ],
                  proofs: [],
                  derivations: [],
                  exclusions: ["Mean, median, mode of ungrouped data (excluded in latest syllabus)"],
                  activities: ["Drawing frequency polygons superimposed on histograms"],
                  assessmentType: ["objective", "short-answer", "graph-work"]
                }
              ]
            }
          ]
        },
        {
          name: "Internal Assessment: Mathematics",
          marks: 20,
          type: "internal",
          description: "Pen-Paper tests, multiple assessments, portfolio, and Math Lab practical work.",
          topics: [
            {
              name: "Continuous Evaluation Framework",
              marks: 20,
              description: "Pen-Paper Test & Multiple Assessments (10m), Portfolio (5m), Math Lab practical work & viva voce (5m).",
              examRelevance: "internal",
              tags: ["math-class9-internal-assessment"],
              subtopics: [
                {
                  name: "Pen Paper & Multiple Assessments",
                  description: "Periodic term exams (best 2 out of 3), oral quizzes, and math concept reviews.",
                  learningOutcomes: ["Demonstrate consistent problem-solving accuracy throughout the academic term"],
                  keyConcepts: ["Periodic tests", "Diagnostic math quizzes"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Speed math drill and MCQ diagnostic session"],
                  assessmentType: ["internal"]
                },
                {
                  name: "Portfolio & Math Lab Practical",
                  description: "Evaluation of notebook neatness and structural assignment logging (5m). Spatial proof verification exercises using official NCERT Math Lab Manual alongside viva-voce (5m).",
                  learningOutcomes: ["Construct concrete physical geometric models", "Defend mathematical proofs in oral viva"],
                  keyConcepts: ["Lab manual documentation", "Viva-voce reasoning", "Portfolio completeness"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["NCERT Math Lab proof verifications (e.g., angle in semicircle, mid-point theorem paper cutting)"],
                  assessmentType: ["internal", "practical"]
                }
              ]
            }
          ]
        }
      ]
    },
    {
      name: "Science",
      class: 9,
      board: "CBSE",
      theoryMarks: 80,
      practicalMarks: 0,
      internalMarks: 20,
      duration: "3 Hours",
      components: [
        {
          name: "Physics Component",
          marks: 27,
          type: "theory",
          description: "Theme: Motion, Force and Work (~27 Marks). Kinematics equations, Newton's laws, gravitation, flotation, work, energy, power, and acoustics.",
          topics: [
            {
              name: "Motion & Kinematics Equations",
              marks: 8,
              description: "Distance, displacement, speed, velocity, uniform/non-uniform motion, acceleration, graphical derivation of 3 equations of motion, circular motion.",
              examRelevance: "theory",
              tags: ["sci-phy-motion", "kinematics-equations"],
              subtopics: [
                {
                  name: "Kinematics Parameters & Graphs",
                  description: "Distance and displacement; Speed and velocity; Uniform and non-uniform motion along a straight line; Acceleration and retardation. Distance-time and velocity-time graphs for uniform and uniformly accelerated motion.",
                  learningOutcomes: ["Differentiate scalar distance from vector displacement", "Interpret slope of s-t and v-t graphs as speed and acceleration"],
                  keyConcepts: ["Displacement", "Velocity", "Acceleration = (v - u) / t", "Slope of v-t graph = acceleration", "Area under v-t graph = displacement"],
                  formulas: ["v = (s2 - s1) / (t2 - t1)", "a = (v - u) / t"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Plotting distance-time graphs from stop-watch motion logs"],
                  assessmentType: ["objective", "short-answer", "numerical"]
                },
                {
                  name: "Equations of Motion & Circular Motion",
                  description: "Derivation of the three fundamental Equations of Motion by graphical method: v = u + at, s = ut + 1/2 at², v² = u² + 2as. Elementary idea of uniform circular motion (v = 2πr/t).",
                  learningOutcomes: ["Derive the 3 kinematics equations graphically", "Calculate linear velocity in uniform circular motion", "Solve multi-step acceleration and braking numericals"],
                  keyConcepts: ["Graphical derivation", "Area of trapezium under v-t curve", "Centripetal acceleration in uniform circular motion"],
                  formulas: [
                    "v = u + at",
                    "s = ut + (1/2)at^2",
                    "v^2 = u^2 + 2as",
                    "v = (2 * pi * r) / t"
                  ],
                  proofs: [],
                  derivations: [
                    "Graphical derivation of v = u + at",
                    "Graphical derivation of s = ut + (1/2)at^2",
                    "Graphical derivation of v^2 = u^2 + 2as"
                  ],
                  exclusions: [],
                  activities: ["Whirling a stone tied to a string to demonstrate circular motion and tangential release"],
                  assessmentType: ["numerical", "long-answer"]
                }
              ]
            },
            {
              name: "Force and Newton's Laws of Motion",
              marks: 6,
              description: "Newton's First, Second, and Third laws of motion, inertia, momentum, mathematical derivation of F = ma, conservation of momentum.",
              examRelevance: "theory",
              tags: ["sci-phy-force-newton-laws", "momentum-conservation"],
              subtopics: [
                {
                  name: "Inertia, Mass & Newton's First Law",
                  description: "Force and Motion; Newton's First Law of Motion; Qualitative concepts of Inertia and Mass with daily-life examples; Momentum (p = mv).",
                  learningOutcomes: ["State Newton's First Law", "Relate mass as the measure of inertia", "Calculate linear momentum"],
                  keyConcepts: ["Inertia of rest, motion, and direction", "Mass as measure of inertia", "Momentum p = mv"],
                  formulas: ["p = m * v"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Coin flick on card over a glass tumbler demonstration of inertia"],
                  assessmentType: ["objective", "short-answer"]
                },
                {
                  name: "Newton's Second & Third Laws and Momentum Conservation",
                  description: "Newton's Second Law of Motion (mathematical derivation of F = ma); Definition and absolute units of force (Newton); Newton's Third Law (Action and Reaction pairs); Law of Conservation of Momentum (statement, mathematical derivation, and collision numericals).",
                  learningOutcomes: ["Derive F = ma from rate of change of momentum", "State Newton's Third Law and identify action-reaction pairs", "Derive m1u1 + m2u2 = m1v1 + m2v2 and solve recoil/collision problems"],
                  keyConcepts: ["Force F = dp/dt = ma", "1 Newton = 1 kg·m/s²", "Action-reaction simultaneous forces", "Isolated system momentum conservation"],
                  formulas: [
                    "F = (m(v - u)) / t = ma",
                    "F_AB = - F_BA",
                    "m1 * u1 + m2 * u2 = m1 * v1 + m2 * v2"
                  ],
                  proofs: [],
                  derivations: [
                    "Mathematical derivation of F = ma from Newton's Second Law",
                    "Mathematical derivation of Law of Conservation of Momentum using Newton's Third Law"
                  ],
                  exclusions: [],
                  activities: ["Balloon rocket demonstration of action and reaction"],
                  assessmentType: ["short-answer", "long-answer", "numerical"]
                }
              ]
            },
            {
              name: "Gravitation & Fluid Dynamics",
              marks: 5,
              description: "Universal Law of Gravitation, G vs g, free fall, mass vs weight, thrust, pressure, Archimedes' Principle, and relative density.",
              examRelevance: "theory",
              tags: ["sci-phy-gravitation", "archimedes-principle"],
              subtopics: [
                {
                  name: "Universal Gravitation & Free Fall",
                  description: "Universal Law of Gravitation statement and mathematical equation F = GMm/d²; Gravitational constant G; Acceleration due to gravity g; Mass vs Weight comparisons; Free fall dynamics; Variation of g with altitude/depth (qualitative) and equations of motion under gravity.",
                  learningOutcomes: ["State Universal Law of Gravitation and inverse-square relation", "Differentiate mass (scalar, constant) and weight (vector, variable)", "Solve free fall kinematics under g = 9.8 m/s²"],
                  keyConcepts: ["Universal gravitational constant G = 6.67 × 10^-11 N m²/kg²", "g = GM/R²", "Weight W = mg", "Free fall equations"],
                  formulas: [
                    "F = (G * M * m) / d^2",
                    "g = (G * M) / R^2",
                    "W = m * g",
                    "v = u + gt, h = ut + (1/2)gt^2, v^2 = u^2 + 2gh"
                  ],
                  proofs: [],
                  derivations: ["Derivation of acceleration due to gravity g = GM/R²"],
                  exclusions: [],
                  activities: ["Drop sheet of paper vs crumpled paper ball to observe air resistance"],
                  assessmentType: ["short-answer", "numerical"]
                },
                {
                  name: "Thrust, Pressure & Archimedes' Principle",
                  description: "Thrust and Pressure; Pressure in fluids; Archimedes' Principle; Buoyancy and upthrust; Relative density configurations.",
                  learningOutcomes: ["Define thrust and calculate pressure P = F/A", "State Archimedes' Principle and buoyant force conditions for floating", "Compute relative density = density of substance / density of water"],
                  keyConcepts: ["Pressure = Force / Area (Pascal)", "Buoyant force / Upthrust", "Archimedes' Principle: upthrust = weight of displaced fluid", "Condition for flotation: density_body <= density_fluid"],
                  formulas: [
                    "P = F / A",
                    "Upthrust = V * rho * g",
                    "Relative Density = rho_substance / rho_water"
                  ],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Immersing iron nail vs foil boat in water to demonstrate buoyancy"],
                  assessmentType: ["short-answer", "numerical"]
                }
              ]
            },
            {
              name: "Work, Energy, and Power",
              marks: 4,
              description: "Work done by constant force, Kinetic Energy (1/2 mv²), Potential Energy (mgh), conservation of energy for freely falling body, Power, and kWh.",
              examRelevance: "theory",
              tags: ["sci-phy-work-energy-power", "conservation-of-energy"],
              subtopics: [
                {
                  name: "Work, Kinetic & Potential Energy",
                  description: "Work done by a constant force W = F · s; Units of work (Joule); Kinetic Energy (KE = 1/2 mv²) and Potential Energy (PE = mgh) numerical evaluations.",
                  learningOutcomes: ["Define 1 Joule of work", "Derive kinetic energy expression KE = 1/2 mv²", "Calculate gravitational potential energy PE = mgh"],
                  keyConcepts: ["Work W = F * s * cos(theta)", "1 Joule = 1 N * 1 m", "Kinetic energy", "Gravitational potential energy"],
                  formulas: [
                    "W = F * s",
                    "KE = (1/2) * m * v^2",
                    "PE = m * g * h"
                  ],
                  proofs: [],
                  derivations: ["Derivation of Kinetic Energy formula KE = (1/2)mv² from work-energy relation"],
                  exclusions: [],
                  activities: ["Releasing a toy cart on an inclined plane to observe kinetic energy"],
                  assessmentType: ["short-answer", "numerical"]
                },
                {
                  name: "Conservation of Energy & Power",
                  description: "Law of Conservation of Energy (theoretical verification using a freely falling body); Power expression P = W/t and SI unit (Watt); Commercial unit of energy (Kilowatt-hour: kWh).",
                  learningOutcomes: ["Verify total mechanical energy (KE + PE) is constant in free fall", "Calculate power P = W/t and electrical energy units in kWh"],
                  keyConcepts: ["Conservation of mechanical energy", "Power = Work / time (Watt)", "1 kWh = 3.6 × 10^6 Joules"],
                  formulas: [
                    "Total Energy = KE + PE = constant",
                    "P = W / t",
                    "1 kWh = 3.6 * 10^6 J"
                  ],
                  proofs: [],
                  derivations: ["Theoretical verification of conservation of energy for freely falling body"],
                  exclusions: [],
                  activities: ["Calculating household electrical energy consumption from appliance wattage"],
                  assessmentType: ["short-answer", "long-answer", "numerical"]
                }
              ]
            },
            {
              name: "Sound & Acoustics",
              marks: 4,
              description: "Propagation as longitudinal wave, parameters (f, λ, v = fλ), reflection, echoes (d ≈ 17.2m), reverberation, ultrasound, SONAR, and human ear structure.",
              examRelevance: "theory",
              tags: ["sci-phy-sound", "acoustics", "ultrasound"],
              subtopics: [
                {
                  name: "Wave Characteristics & Speed",
                  description: "Production and propagation of sound; Sound as a longitudinal mechanical wave; Wave parameters: Amplitude, Frequency (f), Wavelength (λ), Time Period (T), and Speed (v = fλ); Speed of sound in different media.",
                  learningOutcomes: ["Describe compressions and rarefactions in sound waves", "Relate wavelength, frequency, and wave speed via v = fλ"],
                  keyConcepts: ["Longitudinal mechanical wave", "Compressions and rarefactions", "Wavelength, Frequency, Amplitude", "Wave equation v = fλ"],
                  formulas: [
                    "T = 1 / f",
                    "v = f * lambda"
                  ],
                  proofs: [],
                  derivations: ["Derivation of wave relation v = fλ"],
                  exclusions: [],
                  activities: ["Observing compressions and rarefactions in a slinky"],
                  assessmentType: ["objective", "short-answer", "numerical"]
                },
                {
                  name: "Acoustic Phenomena & Applications",
                  description: "Reflection of sound; Echoes (minimum distance condition d ≈ 17.2 m); Reverberation parameters; Range of hearing in humans (20 Hz to 20,000 Hz); Ultrasound applications (SONAR, medical imaging, echolocation); Structural working layout of the Human Ear.",
                  learningOutcomes: ["Calculate minimum distance for echo hearing at 344 m/s", "Explain SONAR echo-ranging equation 2d = v * t", "Describe auditory mechanisms: pinna, eardrum, ossicles, cochlea"],
                  keyConcepts: ["Echo condition: persistence of hearing = 0.1 s => d >= 17.2 m", "Reverberation reduction in auditoriums", "Ultrasound > 20 kHz", "SONAR: Sound Navigation and Ranging", "Human ear anatomy"],
                  formulas: ["2 * d = v * t (Echo and SONAR equation)"],
                  proofs: [],
                  derivations: ["Calculation of minimum echo distance d = (v * t) / 2 = (344 * 0.1) / 2 = 17.2 m"],
                  exclusions: [],
                  activities: ["Demonstrating reflection of sound using two cardboard tubes and a ticking clock"],
                  assessmentType: ["short-answer", "long-answer", "diagram-work"]
                }
              ]
            }
          ]
        },
        {
          name: "Chemistry Component",
          marks: 24,
          type: "theory",
          description: "Theme: Matter - Its Nature and Behaviour (~24 Marks). States of matter, purity, solutions, colloids, atoms, molecules, chemical combination laws, and atomic structure.",
          topics: [
            {
              name: "Matter in Our Surroundings",
              marks: 6,
              description: "Particulate nature of matter, characteristics, states (solid, liquid, gas), phase changes, latent heat of fusion/vaporization, sublimation, evaporation.",
              examRelevance: "theory",
              tags: ["sci-chem-matter-surroundings", "states-of-matter"],
              subtopics: [
                {
                  name: "Physical Nature & States of Matter",
                  description: "Definition of matter; Physical nature of matter (particulate nature); Characteristics of particles of matter; States of matter: Solids, Liquids, and Gases (properties: shape, volume, density, compressibility).",
                  learningOutcomes: ["State the 4 characteristics of particles of matter", "Compare solids, liquids, and gases based on intermolecular spaces and kinetic energy"],
                  keyConcepts: ["Particulate nature", "Intermolecular force and spacing", "Rigidity vs fluidity", "Compressibility"],
                  formulas: ["Density = Mass / Volume"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Dissolving potassium permanganate crystals in water to demonstrate particle diffusion"],
                  assessmentType: ["objective", "short-answer"]
                },
                {
                  name: "Phase Changes & Evaporation",
                  description: "Effect of temperature and pressure; Melting (fusion), latent heat of fusion, boiling, latent heat of vaporization, sublimation, deposition, solidification; Evaporation: factors affecting evaporation and cooling effect mechanics.",
                  learningOutcomes: ["Explain latent heat of fusion and vaporization", "Differentiate evaporation from boiling", "Explain cooling effect of evaporation in daily life (earthen pot, sweating)"],
                  keyConcepts: ["Latent heat of fusion", "Latent heat of vaporization", "Sublimation (ammonium chloride, camphor)", "Evaporation factors: surface area, temperature, humidity, wind speed"],
                  formulas: ["T(K) = T(°C) + 273.15"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Sublimation of ammonium chloride inside an inverted funnel"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Is Matter Around Us Pure?",
              marks: 6,
              description: "Pure substances vs mixtures, homogeneous vs heterogeneous, true solutions, suspensions, colloids, Tyndall effect, concentration % formulas, physical vs chemical changes.",
              examRelevance: "theory",
              tags: ["sci-chem-pure-matter", "solutions-colloids"],
              subtopics: [
                {
                  name: "Mixtures, Solutions & Colloids",
                  description: "Pure substances vs Mixtures; Homogeneous and Heterogeneous mixtures; Elements, Compounds, and Mixtures. True solutions, suspensions, and colloidal solutions (particle size, stability, Tyndall effect).",
                  learningOutcomes: ["Distinguish solutions, suspensions, and colloids on transparency, particle size, and stability", "Demonstrate the Tyndall effect"],
                  keyConcepts: ["Solute and Solvent", "Suspension (heterogeneous, visible particles)", "Colloid (Tyndall scattering)", "Brownian motion"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: ["Separation techniques of mixtures: chromatography, distillation, fractional distillation (excluded in current syllabus)"],
                  activities: ["Shining a laser pointer through water vs milk solution to observe Tyndall effect"],
                  assessmentType: ["short-answer", "comparative-table"]
                },
                {
                  name: "Solution Concentration & Chemical Changes",
                  description: "Concentration expressions (mass-by-mass and mass-by-volume percentage formulas); Physical vs Chemical changes.",
                  learningOutcomes: ["Calculate mass percent and volume percent of solutions", "Classify processes as physical or chemical changes"],
                  keyConcepts: ["Mass percent", "Volume percent", "Reversibility of physical changes", "New chemical identity in chemical changes"],
                  formulas: [
                    "Mass % = (Mass of Solute / Mass of Solution) * 100",
                    "Mass by Volume % = (Mass of Solute / Volume of Solution) * 100"
                  ],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Preparing a 10% common salt solution by mass in lab"],
                  assessmentType: ["numerical", "short-answer"]
                }
              ]
            },
            {
              name: "Atoms and Molecules",
              marks: 6,
              description: "Laws of Chemical Combination (Conservation of Mass, Constant Proportions), Dalton's theory, atomic/molecular masses, criss-cross valency formula writing.",
              examRelevance: "theory",
              tags: ["sci-chem-atoms-molecules", "chemical-formulae"],
              subtopics: [
                {
                  name: "Laws of Chemical Combination & Dalton's Theory",
                  description: "Laws of Chemical Combination: Law of Conservation of Mass and Law of Constant Proportions (statement, experimental verifications, and numericals); Dalton's Atomic Theory (postulates and limitations).",
                  learningOutcomes: ["State and verify the Law of Conservation of Mass", "State Proust's Law of Constant Proportions and solve mass ratio problems", "List postulates of Dalton's Atomic Theory"],
                  keyConcepts: ["Conservation of mass: m_reactants = m_products", "Law of constant proportions (e.g., H:O = 1:8 in water by mass)", "Indivisible atom postulate of Dalton"],
                  formulas: ["Mass of Reactants = Mass of Products"],
                  proofs: [],
                  derivations: [],
                  exclusions: ["Mole concept (excluded in current revised CBSE syllabus)"],
                  activities: ["Verifying conservation of mass by reacting sodium sulphate and barium chloride solutions"],
                  assessmentType: ["short-answer", "numerical"]
                },
                {
                  name: "Chemical Formulae & Masses",
                  description: "Atoms and Molecules definitions; Atomic mass and molecular mass configurations; Symbols of elements; Writing chemical formulas of simple binary compounds using criss-cross valency method; Formula unit mass.",
                  learningOutcomes: ["Write chemical formulas of binary compounds using criss-cross method", "Calculate molecular mass and formula unit mass in unified mass (u)"],
                  keyConcepts: ["Ions, Cations, and Anions", "Polyatomic ions (SO4^2-, NH4+, NO3-)", "Criss-cross valency rule", "Unified atomic mass unit (u) based on C-12"],
                  formulas: [
                    "Molecular Mass = sum of atomic masses of all atoms in molecule",
                    "Formula Unit Mass = sum of atomic masses in an ionic unit"
                  ],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Creating criss-cross valency flash cards for ionic compounds"],
                  assessmentType: ["short-answer", "formula-writing"]
                }
              ]
            },
            {
              name: "Structure of the Atom",
              marks: 6,
              description: "Discovery of electrons, protons, neutrons; Thomson model, Rutherford scattering & nuclear model, Bohr model, electron distribution (2n²), valency, Z, A, isotopes, isobars.",
              examRelevance: "theory",
              tags: ["sci-chem-structure-of-atom", "bohr-model", "isotopes"],
              subtopics: [
                {
                  name: "Subatomic Particles & Early Models",
                  description: "Discovery of subatomic particles: Electrons (J.J. Thomson), Protons (E. Goldstein), and Neutrons (James Chadwick); Thomson's Model and limitations; Rutherford's Alpha-Particle Scattering Experiment and landmark nuclear model constraints.",
                  learningOutcomes: ["Describe cathode rays (electrons) and canal rays (protons)", "State Rutherford's observations, conclusions, and drawbacks of planetary model"],
                  keyConcepts: ["Electrons, protons, neutrons", "Thomson's plum pudding model", "Rutherford alpha scattering experiment", "Concentrated positive nucleus"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Drawing schematic of alpha-particle scattering experiment"],
                  assessmentType: ["objective", "short-answer"]
                },
                {
                  name: "Bohr Model, Valency & Isotopes",
                  description: "Bohr's Model of the atom; Distribution of electrons in shells (Bohr-Bury scheme, 2n² rule) up to Z = 20 (Calcium); Valency and valence electrons; Atomic Number (Z) and Mass Number (A); Isotopes and Isobars (characteristics and medical/reactor applications).",
                  learningOutcomes: ["Draw Bohr-Bury electron diagrams up to Calcium (Z=20)", "Determine valency from valence shell electrons", "Distinguish isotopes from isobars and name applications of U-235, Co-60, I-131"],
                  keyConcepts: ["Discrete energy levels K, L, M, N", "Bohr-Bury 2n² maximum capacity", "Valency = valence electrons or (8 - valence electrons)", "Atomic number Z = protons", "Mass number A = protons + neutrons", "Isotopes (same Z, different A) vs Isobars (same A, different Z)"],
                  formulas: [
                    "Maximum electrons in nth shell = 2 * n^2",
                    "A = Z + number of neutrons"
                  ],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Constructing 3D Bohr atom models of Carbon, Oxygen, and Sodium"],
                  assessmentType: ["short-answer", "diagram-work"]
                }
              ]
            }
          ]
        },
        {
          name: "Biology Component",
          marks: 26,
          type: "theory",
          description: "Theme: Organization in the Living World (~22 Marks) and Food Production (~04 Marks). Cellular machinery, plant & animal tissues, crop improvement, animal husbandry.",
          topics: [
            {
              name: "Cell - Basic Unit of Life",
              marks: 11,
              description: "Prokaryotic vs eukaryotic, cell membrane/wall, diffusion & osmosis, nucleus, organelles (chloroplast, mitochondria, vacuoles, ER, Golgi, lysosomes, ribosomes), chromosomes, DNA.",
              examRelevance: "theory",
              tags: ["sci-bio-cell-unit-of-life", "cell-organelles"],
              subtopics: [
                {
                  name: "Cell Architecture & Plasma Membrane",
                  description: "Cell as basic unit of life; Prokaryotic and eukaryotic cells, multicellular organisms; Cell membrane and cell wall; Plasma membrane properties (diffusion and osmosis mechanisms in hypotonic, isotonic, and hypertonic solutions).",
                  learningOutcomes: ["Differentiate prokaryotic and eukaryotic cells", "Explain osmosis, endosmosis, exosmosis, and plasmolysis in plant cells"],
                  keyConcepts: ["Prokaryotic vs Eukaryotic", "Lipid-protein bilayer plasma membrane", "Cellulose cell wall", "Osmosis in hypotonic, hypertonic, and isotonic media"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Observing swelling and shrinking of raisins in hypotonic water vs hypertonic salt solution"],
                  assessmentType: ["short-answer", "diagram-work"]
                },
                {
                  name: "Cell Organelles & Genetic Machinery",
                  description: "Structure and major functional profiles of core cellular machinery: Nucleus, chloroplast, mitochondria, vacuoles, endoplasmic reticulum (RER & SER), Golgi apparatus, ribosomes, and lysosomes; Chromosomes, DNA, and protein synthesis frameworks.",
                  learningOutcomes: ["Identify organelle structures in animal vs plant cell diagrams", "Explain why mitochondria are powerhouses and lysosomes are suicide bags", "Describe rough vs smooth ER and membrane biogenesis"],
                  keyConcepts: ["Nucleus and chromatin / DNA", "Mitochondria (ATP generation, own DNA/ribosomes)", "Plastids (Chloroplasts, chromoplasts, leucoplasts)", "Golgi apparatus packaging", "Lysosomes hydrolytic enzymes"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Comparative labeling of plant cell vs animal cell ultrastructure"],
                  assessmentType: ["short-answer", "long-answer", "diagram-work"]
                }
              ]
            },
            {
              name: "Tissues: Plant and Animal Specialization",
              marks: 11,
              description: "Meristematic tissues, simple permanent (parenchyma, collenchyma, sclerenchyma), complex permanent (xylem, phloem), epithelial, connective, muscular, and nervous tissues.",
              examRelevance: "theory",
              tags: ["sci-bio-tissues", "plant-animal-tissues"],
              subtopics: [
                {
                  name: "Plant Tissues: Meristems & Permanent Systems",
                  description: "Meristematic Tissues (apical, intercalary, lateral) and Permanent Tissues (Simple: parenchyma, collenchyma, sclerenchyma; Complex: xylem and phloem vascular systems).",
                  learningOutcomes: ["Distinguish apical, lateral, and intercalary meristems", "Compare parenchyma, collenchyma, and sclerenchyma based on cell walls and lignin", "Describe conducting elements of xylem and phloem"],
                  keyConcepts: ["Apical, intercalary, lateral meristem (cambium)", "Parenchyma (storage/photosynthesis), Collenchyma (flexibility), Sclerenchyma (lignified mechanical support)", "Xylem: tracheids, vessels, xylem parenchyma, xylem fibres", "Phloem: sieve tubes, companion cells, phloem parenchyma, phloem fibres"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Examining cross-section of plant stem under compound microscope"],
                  assessmentType: ["short-answer", "long-answer", "diagram-work"]
                },
                {
                  name: "Animal Tissues: Epithelial, Connective, Muscular & Nervous",
                  description: "Epithelial tissues (squamous, cuboidal, columnar, ciliated, glandular); Connective tissues (areolar, adipose, bone, cartilage, blood, tendons, ligaments); Muscular tissues (striated, unstriated, cardiac); Nervous tissue (neuron structural mechanics).",
                  learningOutcomes: ["Classify epithelial tissues by cell shape and location", "Compare tendons vs ligaments, bone vs cartilage", "Differentiate striated, unstriated, and cardiac muscles", "Draw and label a multipolar neuron"],
                  keyConcepts: ["Protective epithelium", "Matrix in connective tissues: blood (plasma), bone (calcium/phosphorus)", "Involuntary vs voluntary muscle control", "Neuron: cyton, dendrites, axon, synapse"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Drawing and labeling a motor neuron with myelin sheath and dendrites"],
                  assessmentType: ["short-answer", "diagram-work"]
                }
              ]
            },
            {
              name: "Improvement in Food Resources",
              marks: 4,
              description: "Crop variety improvement, fertilizers and manures, pest protection, organic farming, cropping patterns, and animal husbandry.",
              examRelevance: "theory",
              tags: ["sci-bio-food-resources", "sustainable-agriculture"],
              subtopics: [
                {
                  name: "Crop Production & Nutrient Management",
                  description: "Plant breeding and selection for quality improvement; Use of fertilizers and manures; Protection from weeds, pests, and diseases; Organic farming parameters. Nutrient management cycles; Mixed cropping, intercropping, and crop rotation.",
                  learningOutcomes: ["Contrast chemical fertilizers with organic manures", "Differentiate mixed cropping from intercropping", "Explain biological pest control in organic farming"],
                  keyConcepts: ["Macronutrients (NPK) vs Micronutrients", "Green manure and compost", "Intercropping rows", "Crop rotation benefits"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Designing an organic crop rotation calendar"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Animal Husbandry & Allied Agriculture",
                  description: "Cattle farming (milk and draught), poultry farming (layers and broilers), fish production (capture fishery, aquaculture, and mariculture), and Bee-keeping (Apiculture).",
                  learningOutcomes: ["Describe indigenous vs exotic cattle breeds", "Explain management of poultry broilers and layers", "Contrast capture fishing with culture fishery and composite fish culture", "List desirable qualities of Italian bee Apis mellifera"],
                  keyConcepts: ["Roughage and concentrates in cattle feed", "Composite fish culture (surface, middle, bottom feeders)", "Apiculture: honey and bee wax extraction"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Field visit report or schematic layout of composite fish culture pond"],
                  assessmentType: ["short-answer", "case-study"]
                }
              ]
            }
          ]
        },
        {
          name: "Practical and Internal Assessment: Science",
          marks: 20,
          type: "practical",
          description: "Hands-on physics, chemistry, biology experimental verifications and internal continuous evaluation.",
          topics: [
            {
              name: "Prescribed Science Laboratory Practicals",
              marks: 10,
              description: "Core Physics, Chemistry, and Biology laboratory experiments, manual observation logging, and viva voce.",
              examRelevance: "practical",
              tags: ["sci-class9-practicals", "lab-experiments"],
              subtopics: [
                {
                  name: "Physics Practicals",
                  description: "1. Determining solid density using spring balance and graduated cylinder. 2. Establishing relation between weight loss in tap/salty water and displaced water weight (Archimedes' Principle). 3. Verifying Laws of Reflection of Sound. 4. Determining pulse velocity through stretched string/slinky.",
                  learningOutcomes: ["Determine density of insoluble solid", "Validate Archimedes principle experimentally", "Measure sound reflection angles"],
                  keyConcepts: ["Spring balance calibration", "Zero error", "Reflection laws: angle of incidence = angle of reflection"],
                  formulas: ["Density = Mass / Volume", "v = distance / time"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Water displacement volume measurement in graduated cylinder"],
                  assessmentType: ["practical", "viva"]
                },
                {
                  name: "Chemistry Practicals",
                  description: "1. Preparing true solution (salt/sugar), suspension (soil/chalk), colloid (starch) and comparing transparency, filtration, stability. 2. Preparing compound (FeS) vs mixture of iron filings and sulphur powder. 3. Verifying Law of Conservation of Mass in BaCl2 + Na2SO4. 4. Determining melting point of ice and boiling point of water.",
                  learningOutcomes: ["Distinguish solutions, suspensions, colloids by filtration and stability", "Differentiate mixtures and compounds using magnet and dilute HCl", "Confirm conservation of mass during precipitation"],
                  keyConcepts: ["Filtration residue vs filtrate", "Iron sulfide formation Fe + S -> FeS", "Precipitation reaction BaCl2 + Na2SO4 -> BaSO4(s) + 2NaCl"],
                  formulas: ["m_reactants = m_products"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Heating iron filings and sulfur powder in a hard glass test tube"],
                  assessmentType: ["practical", "viva"]
                },
                {
                  name: "Biology Practicals",
                  description: "1. Preparing temporary stained mounts of onion peel and human cheek cells under light microscope. 2. Identifying parenchyma, collenchyma, sclerenchyma plant tissues, and muscle/nerve animal tissues from permanent slides. 3. Qualitative biochemical tests for starch and food adulterants.",
                  learningOutcomes: ["Stain and mount epidermal cells using safranin and methylene blue", "Identify histological features of permanent plant and animal tissues"],
                  keyConcepts: ["Safranin stain for plant cells", "Methylene blue stain for animal cells", "Iodine test for starch"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Mounting onion peel slide and adjusting 10x and 40x microscope lenses"],
                  assessmentType: ["practical", "viva"]
                }
              ]
            },
            {
              name: "Internal Evaluation: Science",
              marks: 10,
              description: "Periodic unit tests (5m), Subject enrichment/Lab manual file (5m), Portfolio assessment (5m), Multiple internal evaluations (5m) normalized to internal total.",
              examRelevance: "internal",
              tags: ["sci-class9-internal-assessment"],
              subtopics: [
                {
                  name: "Continuous Assessment Breakdown",
                  description: "Periodic tests (05 marks), Subject enrichment lab file (05 marks), Portfolio (05 marks), Multiple assessments (05 marks).",
                  learningOutcomes: ["Demonstrate consistent academic and experimental proficiency across science themes"],
                  keyConcepts: ["Periodic tests", "Lab file maintenance", "Portfolio scoring rubrics"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Science project submission and oral presentation"],
                  assessmentType: ["internal"]
                }
              ]
            }
          ]
        }
      ]
    },
    {
      name: "Social Science",
      class: 9,
      board: "CBSE",
      theoryMarks: 80,
      practicalMarks: 0,
      internalMarks: 20,
      duration: "3 Hours",
      components: [
        {
          name: "India and the Contemporary World - I (History)",
          marks: 20,
          type: "theory",
          description: "The French Revolution, Socialism in Europe & Russian Revolution, Nazism & Rise of Hitler, Forest Society & Colonialism, Pastoralists.",
          topics: [
            {
              name: "The French Revolution",
              marks: 7,
              description: "Old Regime crises, outbreak of revolution, constitutional monarchy, First Republic, Reign of Terror, Directory, abolition of slavery.",
              examRelevance: "theory",
              tags: ["sst-hist-french-revolution", "liberty-equality"],
              subtopics: [
                {
                  name: "Old Regime & Outbreak of Revolution",
                  description: "The Old Regime society (Three Estates) and structural crises; Financial crisis and Estates General meeting at Versailles; Tennis Court Oath; Storming of the Bastille on 14 July 1789.",
                  learningOutcomes: ["Analyze feudal privileges of First and Second Estates", "Explain causes leading to the storming of the Bastille"],
                  keyConcepts: ["Three Estates", "Tithe and Taille taxes", "Subsistence crisis", "Estates General voting deadlock"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Creating a chart comparing the Three Estates of French society"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Republic, Reign of Terror & Abolition of Slavery",
                  description: "France becomes a constitutional monarchy; Abolition of monarchy and emergence of Republic; The Jacobins and Robespierre's Reign of Terror; The Directory rules France; Abolition of slavery in French colonies and legacy of revolution.",
                  learningOutcomes: ["Evaluate Jacobin governance and Robespierre's policies", "Trace women's revolutionary participation and abolition of slavery"],
                  keyConcepts: ["Declaration of Rights of Man and Citizen", "Jacobin club", "Guillotine", "Reign of Terror (1793-1794)", "Directory instability leading to Napoleon"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Reading and debating excerpts from Declaration of the Rights of Man"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Socialism in Europe and the Russian Revolution",
              marks: 7,
              description: "Liberals, Radicals, Conservatives, Industrial society, 1905 Revolution, February & October 1917 Revolutions, Civil War, and Stalinism.",
              examRelevance: "theory",
              tags: ["sst-hist-russian-revolution", "socialism", "bolsheviks"],
              subtopics: [
                {
                  name: "Age of Social Change & 1905 Revolution",
                  description: "The age of social change (Liberals, Radicals, Conservatives); Industrial society and socialism (Karl Marx, Friedrich Engels); Russian Empire in 1914; 1905 Revolution and Bloody Sunday; Creation of the Duma.",
                  learningOutcomes: ["Differentiate ideologies of Liberals, Radicals, and Conservatives", "Explain causes and aftermath of Bloody Sunday and 1905 Revolution"],
                  keyConcepts: ["Socialism and collective ownership", "Karl Marx: overthrow of capitalism", "Tsar Nicholas II autocracy", "Bloody Sunday", "Soviet councils"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Timeline construction of events leading from 1905 to 1917 in Russia"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "1917 Revolutions, Civil War & Stalinism",
                  description: "The February Revolution in Petrograd and fall of Tsar; Lenin's April Theses; The October Revolution of 1917; Bolshevik transformations; The Civil War; Making a socialist society; Stalin's collectivisation of agriculture.",
                  learningOutcomes: ["State Lenin's April Theses", "Examine October Revolution led by Bolsheviks", "Analyze consequences of Stalin's forced collectivisation and kulak suppression"],
                  keyConcepts: ["February Revolution vs October Revolution", "April Theses (land, banks, war)", "Petrograd Soviet", "Civil war: Reds vs Whites/Greens", "Kolkhoz collective farms"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Comparing Bolshevik land reforms with Tsarist agricultural policies"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Nazism and the Rise of Hitler",
              marks: 6,
              description: "Weimar Republic flaws, Great Depression impacts, Hitler's rise, destruction of democracy, racial state ideology, and Holocaust.",
              examRelevance: "theory",
              tags: ["sst-hist-nazism-hitler", "weimar-republic", "holocaust"],
              subtopics: [
                {
                  name: "Birth of Weimar Republic & Hitler's Rise",
                  description: "The birth of the Weimar Republic and its systemic flaws; Treaty of Versailles humiliation; Effects of World War I and the Great Depression (hyperinflation 1923); Hitler's rise to power and Nazi party propaganda.",
                  learningOutcomes: ["Analyze economic crisis of Weimar Republic and hyperinflation", "Explain factors enabling Hitler's charismatic mass appeal during Great Depression"],
                  keyConcepts: ["Treaty of Versailles war guilt clause", "Hyperinflation", "Great Depression (1929)", "Article 48 of Weimar Constitution"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Analyzing Nazi propaganda posters and campaign slogans"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Destruction of Democracy, Racial State & Holocaust",
                  description: "The Fire Decree and Enabling Act (1933); Destruction of democracy; Reconstruction and aggressive foreign policy; The Nazi worldview, racial hierarchy, Nuremberg Laws, and the Holocaust.",
                  learningOutcomes: ["Trace steps through which Hitler established totalitarian dictatorship", "Describe Nazi racial ideology, persecution of Jews, and concentration camp system"],
                  keyConcepts: ["Enabling Act (dictatorship)", "Gestapo and SS", "Aryan racial myth", "Nuremberg Laws", "Final Solution / Holocaust"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Reading primary diary excerpts of Holocaust survivors"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Contemporary India - I (Geography)",
          marks: 20,
          type: "theory",
          description: "Size and Location, Physical Features, Drainage basins, Climate & Monsoons, Natural Vegetation & Wildlife, and Population.",
          topics: [
            {
              name: "India - Size and Location",
              marks: 3,
              description: "Location in world, latitudinal/longitudinal extents, Standard Meridian 82°30'E, time zones, and neighboring nations.",
              examRelevance: "theory",
              tags: ["sst-geo-india-size-location", "standard-meridian"],
              subtopics: [
                {
                  name: "Extents, Standard Meridian & Neighbors",
                  description: "India's geographical location in the world; Latitudinal (8°4'N to 37°6'N) and longitudinal (68°7'E to 97°25'E) extents; Standard Meridian (82°30'E passing through Mirzapur) and time zones; Strategic neighboring countries.",
                  learningOutcomes: ["State India's coordinates and boundary extents", "Explain need for Standard Meridian 82°30'E across 30° longitude span"],
                  keyConcepts: ["Latitudinal and longitudinal extent", "Standard Meridian of India 82°30'E", "Indian Ocean strategic significance", "Neighboring countries"],
                  formulas: ["Time difference = 4 minutes per degree longitude"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Calculating local time difference between Arunachal Pradesh and Gujarat"],
                  assessmentType: ["objective", "short-answer"]
                }
              ]
            },
            {
              name: "Physical Features of India",
              marks: 4,
              description: "Plate Tectonics, Himalayas, Northern Plains, Peninsular Plateau, Indian Desert, Coastal Plains, and Islands.",
              examRelevance: "theory",
              tags: ["sst-geo-physical-features", "himalayas", "peninsular-plateau"],
              subtopics: [
                {
                  name: "Plate Tectonics & Himalayan System",
                  description: "Theory of Plate Tectonics; Formation of Himalayas from Tethys Sea; Three longitudinal divisions of Himalayas (Himadri, Himachal, Shiwaliks); Regional divisions from west to east.",
                  learningOutcomes: ["Explain Himalayan fold mountain formation via convergent plate collision", "Contrast Himadri, Himachal, and Shiwalik ranges"],
                  keyConcepts: ["Convergent, divergent, and transform boundaries", "Gondwanaland", "Greater Himalayas (Himadri)", "Lesser Himalayas (Himachal)", "Shiwaliks (duns)"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Labeling mountain peaks and passes on physical map of India"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Northern Plains, Plateau, Desert, Coasts & Islands",
                  description: "Northern Plains (Bhabar, Terai, Bhangar, Khadar); Peninsular Plateau (Central Highlands, Deccan Plateau); Western Ghats vs Eastern Ghats; Indian Desert; Coastal Plains; Andaman & Nicobar and Lakshadweep Islands.",
                  learningOutcomes: ["Differentiate Khadar and Bhangar soils", "Compare Western Ghats with Eastern Ghats", "Identify coral origin of Lakshadweep islands"],
                  keyConcepts: ["Alluvial plains: Bhabar, Terai, Bhangar, Khadar", "Deccan Trap (black soil)", "Western Ghats continuous orographic barrier", "Coral atolls"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Creating comparative table between Western Coastal Plains and Eastern Coastal Plains"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Drainage",
              marks: 4,
              description: "Drainage basins, Himalayan river systems (Indus, Ganga, Brahmaputra), Peninsular river systems, lakes, economic role, pollution.",
              examRelevance: "theory",
              tags: ["sst-geo-drainage", "river-systems"],
              subtopics: [
                {
                  name: "Himalayan vs Peninsular Rivers",
                  description: "Concept of drainage basin and water divide; Himalayan rivers (Indus, Ganga, Brahmaputra systems); Peninsular rivers (Narmada, Tapi, Godavari, Mahanadi, Krishna, Cauvery systems).",
                  learningOutcomes: ["Compare perennial Himalayan rivers with seasonal Peninsular rivers", "Trace courses and major tributaries of Indus, Ganga, and Godavari"],
                  keyConcepts: ["Water divide", "Perennial vs seasonal flow", "Dendritic, trellis, rectangular, radial drainage patterns", "Estuaries vs deltas"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Tracing river courses and identifying west-flowing vs east-flowing rivers on map"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Lakes & River Economy",
                  description: "Natural and man-made lakes; Freshwater vs saltwater lakes (Chilika, Sambhar, Wular, Dal); Role of rivers and lakes in the national economy; Industrial and domestic river pollution.",
                  learningOutcomes: ["Explain ecological and economic importance of freshwater lakes", "Discuss National River Conservation Plan (NRCP) to combat river pollution"],
                  keyConcepts: ["Ox-bow lakes", "Glacial lakes", "Saline lakes (Sambhar)", "Eutrophication and river conservation"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Case analysis of river cleanup initiatives (Ganga Action Plan)"],
                  assessmentType: ["short-answer", "case-study"]
                }
              ]
            },
            {
              name: "Climate",
              marks: 4,
              description: "Weather vs climate, controls, Indian monsoon mechanism (onset, withdrawal, seasons), rainfall distribution.",
              examRelevance: "theory",
              tags: ["sst-geo-climate", "indian-monsoon"],
              subtopics: [
                {
                  name: "Climatic Controls & Monsoon Mechanism",
                  description: "Concept of weather and climate; 6 climatic controls (Latitude, Altitude, Pressure and Winds, Distance from sea, Ocean currents, Relief); The Indian Monsoon mechanism: ITCZ shift, differential heating, jet streams, El Niño.",
                  learningOutcomes: ["Explain 6 major climatic controls", "Explain monsoon onset via low pressure over Tibetan plateau and shift of ITCZ"],
                  keyConcepts: ["Inter Tropical Convergence Zone (ITCZ)", "Subtropical westerly jet streams", "Differential heating of land and sea", "Southern Oscillation and El Niño (ENSO)"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Charting movement of ITCZ during summer and winter seasons"],
                  assessmentType: ["short-answer", "long-answer"]
                },
                {
                  name: "Seasons & Rainfall Distribution",
                  description: "The 4 distinct seasons: Cold weather season, Hot weather season, Advancing Monsoon (South-West), Retreating Monsoon (North-East); Distribution of rainfall across India; Monsoon as a unifying bond.",
                  learningOutcomes: ["Describe characteristics of Advancing and Retreating Monsoons", "Explain why Mawsynram receives world's highest rainfall while western Rajasthan is arid"],
                  keyConcepts: ["Loo and Kalbaisakhi", "Break in monsoon", "October Heat", "Relief rainfall on Western Ghats windward slope", "Monsoon unifying bond"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Color-coding rainfall zones on an outline map of India"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Natural Vegetation and Wildlife",
              marks: 3,
              description: "Factors affecting flora/fauna, vegetation types (Tropical Evergreen, Deciduous, Thorn, Montane, Mangrove), wildlife conservation, biosphere reserves.",
              examRelevance: "theory",
              tags: ["sst-geo-vegetation-wildlife", "forest-types"],
              subtopics: [
                {
                  name: "Vegetation Types & Conservation",
                  description: "Factors affecting flora and fauna (Relief: land, soil; Climate: temperature, photoperiod, precipitation). Types of vegetation: Tropical Evergreen, Tropical Deciduous, Thorn Forests, Montane Forests, and Mangrove forests. Wildlife conservation and Biosphere Reserves in India.",
                  learningOutcomes: ["Characterize 5 forest types by annual rainfall and dominant tree species", "Explain necessity of Project Tiger, National Parks, and Biosphere Reserves"],
                  keyConcepts: ["Flora vs Fauna", "Tropical Evergreen (>200 cm rainfall, mahogany, ebony)", "Tropical Deciduous (teak, sal)", "Mangroves (Sundari trees in tidal delta)", "18 Biosphere Reserves"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Plotting 18 Biosphere Reserves on an outline map of India"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Population",
              marks: 2,
              description: "Size, distribution, processes of change (birth, death, migration), age composition, sex ratio, literacy, National Population Policy.",
              examRelevance: "theory",
              tags: ["sst-geo-population", "demographics"],
              subtopics: [
                {
                  name: "Population Dynamics & Demographics",
                  description: "Population size and distribution (Census); Population growth and processes of change: Birth rate, Death rate, Migration (internal and international); Age composition, sex ratio, literacy rates, and the National Population Policy (NPP 2000).",
                  learningOutcomes: ["Define natural increase rate = Birth Rate - Death Rate", "Analyze causes and impacts of rural-to-urban internal migration", "State objectives of National Population Policy 2000"],
                  keyConcepts: ["Census of India", "Density of population", "Sex ratio (females per 1000 males)", "Age structure (0-14, 15-59, 60+)", "NPP 2000 adolescent health"],
                  formulas: ["Rate of Natural Increase = Birth Rate - Death Rate"],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Interpreting age-sex pyramid diagrams"],
                  assessmentType: ["objective", "short-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Democratic Politics - I (Political Science)",
          marks: 20,
          type: "theory",
          description: "What is Democracy, Constitutional Design, Electoral Politics, Working of Institutions, and Democratic Rights.",
          topics: [
            {
              name: "What is Democracy? Why Democracy?",
              marks: 4,
              description: "Definition, core features with global examples, arguments for and against democracy, broader meanings.",
              examRelevance: "theory",
              tags: ["sst-pol-what-is-democracy", "democratic-principles"],
              subtopics: [
                {
                  name: "Features & Arguments for Democracy",
                  description: "Definition of democracy; Core features (Major decisions by elected leaders, Free and fair electoral competition, One person one vote one value, Rule of law and respect for rights); Global counter-examples (Pakistan under Musharraf, China, Zimbabwe under Mugabe); Arguments for and against democracy.",
                  learningOutcomes: ["Examine why elections in China or Zimbabwe fell short of democratic standards", "Defend democracy as superior in correcting mistakes and enhancing citizen dignity"],
                  keyConcepts: ["Representative democracy", "Universal adult franchise", "Rule of law", "Accountability to citizens", "Deliberative decision-making"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Class debate on 'Democracy is the best form of government'"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Constitutional Design",
              marks: 4,
              description: "South Africa struggle against apartheid, Nelson Mandela, necessity of constitution, Indian Constitution making, guiding values.",
              examRelevance: "theory",
              tags: ["sst-pol-constitutional-design", "indian-constitution"],
              subtopics: [
                {
                  name: "South Africa & Making of Indian Constitution",
                  description: "The struggle against apartheid in South Africa; Nelson Mandela's role and transition to rainbow nation; Why do we need a Constitution? Making of the Indian Constitution (Constituent Assembly); Guiding values and Preamble philosophy.",
                  learningOutcomes: ["Trace South Africa's transition from apartheid to democratic constitution", "Explain why Constituent Assembly represents the collective will of India", "Interpret keywords of Preamble: Sovereign, Socialist, Secular, Democratic, Republic, Justice, Liberty, Equality, Fraternity"],
                  keyConcepts: ["Apartheid racial segregation", "Constituent Assembly of India", "Dr. B.R. Ambedkar Drafting Committee", "Preamble philosophy"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Reciting and analyzing the Preamble to the Indian Constitution"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Electoral Politics",
              marks: 4,
              description: "Need for elections, democratic election criteria, Indian electoral system (constituencies, reserved seats, voters' list, nominations, campaigning), Election Commission.",
              examRelevance: "theory",
              tags: ["sst-pol-electoral-politics", "election-commission"],
              subtopics: [
                {
                  name: "Electoral Process in India",
                  description: "Why do we need elections? What makes an election democratic? System of elections in India: Electoral constituencies (Lok Sabha & Vidhan Sabha), Reserved constituencies, Voters' list, Nomination of candidates, Election campaign and Model Code of Conduct; Independent Election Commission powers.",
                  learningOutcomes: ["Explain why reserved constituencies for SC/ST are necessary", "Evaluate powers of Election Commission of India in conducting free and fair polls", "List violations under Model Code of Conduct"],
                  keyConcepts: ["Universal Adult Franchise", "Electoral Constituencies (543 Lok Sabha seats)", "Reserved constituencies", "Model Code of Conduct", "Independent Election Commission"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Simulating a mock student council election with secret ballots"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Working of Institutions",
              marks: 4,
              description: "Policy decision case studies (Office Memorandum), Parliament (Lok Sabha vs Rajya Sabha), Political Executive, Prime Minister, Council of Ministers, and Judiciary.",
              examRelevance: "theory",
              tags: ["sst-pol-working-of-institutions", "parliament-judiciary"],
              subtopics: [
                {
                  name: "Parliament, Executive & Independent Judiciary",
                  description: "How a major policy decision is taken (Mandal Commission Office Memorandum); The Parliament: Lok Sabha vs Rajya Sabha powers; The Political Executive (Prime Minister, Council of Ministers, Cabinet) vs Permanent Executive (Civil Servants); The Judiciary: Supreme Court independence and Judicial Review.",
                  learningOutcomes: ["Explain why Lok Sabha exercises more power than Rajya Sabha in money bills", "Distinguish political executive from permanent executive", "Define Judicial Review and independence of the Indian Judiciary"],
                  keyConcepts: ["Office Memorandum", "Bicameral legislature (Lok Sabha and Rajya Sabha)", "Prime Minister as head of government", "Cabinet system", "Integrated and independent judiciary", "Judicial Review"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Flowchart of how an ordinary bill becomes an Act through Parliament"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Democratic Rights",
              marks: 4,
              description: "Life without rights case studies (Guantanamo Bay, Kosovo), rights in democracy, Fundamental Rights in Indian Constitution (Part III), expanding scope.",
              examRelevance: "theory",
              tags: ["sst-pol-democratic-rights", "fundamental-rights"],
              subtopics: [
                {
                  name: "Fundamental Rights & Constitutional Remedies",
                  description: "Life without rights case studies; Meaning of rights; Six Fundamental Rights in the Indian Constitution: Right to Equality, Right to Freedom, Right against Exploitation, Right to Freedom of Religion, Cultural and Educational Rights, Right to Constitutional Remedies (Article 32); Expanding scope of rights (RTI, Right to Education).",
                  learningOutcomes: ["List and explain the 6 Fundamental Rights in Part III of Constitution", "Explain why Right to Constitutional Remedies is called 'heart and soul of Constitution'", "Analyze how courts expand the scope of rights"],
                  keyConcepts: ["Fundamental Rights", "Writs under Article 32", "Right to Constitutional Remedies", "National Human Rights Commission (NHRC)"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Creating a poster depicting the 6 Fundamental Rights"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Understanding Economic Development (Economics)",
          marks: 20,
          type: "theory",
          description: "The Story of Village Palampur, People as Resource, Poverty as a Challenge, and Food Security in India.",
          topics: [
            {
              name: "The Story of Village Palampur",
              marks: 5,
              description: "Factors of production, farming in Palampur, Green Revolution, modern farming methods, sustainability, and non-farm activities.",
              examRelevance: "theory",
              tags: ["sst-eco-village-palampur", "factors-of-production"],
              subtopics: [
                {
                  name: "Factors of Production & Farming in Palampur",
                  description: "Organization of production: Land, Labour, Physical Capital (Fixed & Working), Human Capital. Farming in Palampur: Land fixed, multiple cropping, Green Revolution with HYV seeds, chemical fertilizers, tubewell irrigation, soil degradation; Non-farm activities: Dairy, small manufacturing, transport.",
                  learningOutcomes: ["Classify 4 factors of production", "Examine positive and environmental consequences of Green Revolution in Punjab/Haryana", "Identify non-farm rural livelihoods"],
                  keyConcepts: ["Fixed capital (tools, machines) vs Working capital (raw materials, cash)", "HYV seeds and modern irrigation", "Groundwater depletion", "Non-farm rural activities"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Surveying farm vs non-farm occupations in a nearby rural area"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "People as Resource",
              marks: 5,
              description: "Human capital, economic activities, population quality (education & health), unemployment types (seasonal, disguised, educated).",
              examRelevance: "theory",
              tags: ["sst-eco-people-as-resource", "human-capital", "unemployment"],
              subtopics: [
                {
                  name: "Human Capital & Unemployment Types",
                  description: "Overview of human capital; Economic activities by men and women (Market vs Non-market); Quality of population: Education (Sarva Shiksha Abhiyan) and Health infrastructure; Unemployment: Seasonal, disguised, and educated unemployment trends in India and their consequences.",
                  learningOutcomes: ["Differentiate physical capital from human capital", "Distinguish seasonal unemployment from disguised unemployment in agriculture", "Explain how investment in education and healthcare transforms population into asset"],
                  keyConcepts: ["Human capital formation", "Primary, secondary, tertiary economic activities", "Disguised unemployment (surplus agricultural labor)", "Seasonal unemployment"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Analyzing Sakal and Vilas comparative case study"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Poverty as a Challenge",
              marks: 5,
              description: "Poverty line, poverty trends in India, vulnerable groups, causes of poverty, and government anti-poverty programs.",
              examRelevance: "theory",
              tags: ["sst-eco-poverty-challenge", "poverty-line", "mgnrega"],
              subtopics: [
                {
                  name: "Poverty Line & Anti-Poverty Programmes",
                  description: "Poverty line definition and estimation (calorie criteria: 2400 rural / 2100 urban); Social exclusion and vulnerability; Interstate disparities; Causes of poverty; Government anti-poverty measures (MGNREGA 2005, PMEGP, PMGY, AAY); Broader concept of human poverty.",
                  learningOutcomes: ["Define poverty line based on calorie requirements and monthly per capita expenditure", "Identify vulnerable groups (SC/ST, rural landless, women)", "Evaluate performance of MGNREGA 2005"],
                  keyConcepts: ["Calorie norm: 2400 kcal (rural) vs 2100 kcal (urban)", "Social exclusion", "Vulnerability", "MGNREGA 100 days guaranteed wage employment"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Conducting a group discussion on effectiveness of MGNREGA in rural distress relief"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            },
            {
              name: "Food Security in India",
              marks: 5,
              description: "Dimensions of food security, food-insecure groups, Buffer Stock system, Public Distribution System (PDS), and cooperatives.",
              examRelevance: "theory",
              tags: ["sst-eco-food-security", "buffer-stock", "pds"],
              subtopics: [
                {
                  name: "Food Security Framework: Buffer Stock & PDS",
                  description: "Dimensions of food security: Availability, Accessibility, and Affordability; Why food security? Who is food-insecure? Food security framework in India: Buffer Stock systems via FCI (Minimum Support Price, Issue Price) and the Public Distribution System (PDS, Ration Shops, Antyodaya Anna Yojana); Role of cooperatives (Amul, Mother Dairy).",
                  learningOutcomes: ["Explain 3 dimensions of food security", "Describe functioning of FCI Buffer Stock and Minimum Support Price (MSP)", "Evaluate role of PDS and fair price ration shops in food security"],
                  keyConcepts: ["Food security: availability, accessibility, affordability", "Buffer stock maintained by Food Corporation of India (FCI)", "Minimum Support Price (MSP)", "Issue price", "PDS fair price shops", "Cooperatives in milk and grain supply"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Visiting a local Fair Price Shop (Ration Shop) and noting subsidized commodity prices"],
                  assessmentType: ["short-answer", "long-answer"]
                }
              ]
            }
          ]
        },
        {
          name: "Core Map Work Component",
          marks: 5,
          type: "map",
          description: "History Map (2 marks) and Geography Map (3 marks) evaluated within theory paper.",
          topics: [
            {
              name: "Prescribed History & Geography Map Work",
              marks: 5,
              description: "History Map: Allied/Central Powers WWI, Allied/Axis Powers WWII, French Revolution epicenters. Geography Map: Standard Meridian, peaks, plateaus, lakes, national parks, wildlife reserves.",
              examRelevance: "map",
              tags: ["sst-class9-map-work", "history-map", "geography-map"],
              subtopics: [
                {
                  name: "History Map Work",
                  description: "French Revolution epicenters: Paris, Bordeaux, Nantes, Marseilles. Major powers of World War I (Central Powers: Germany, Austria-Hungary, Turkey; Allied Powers: France, Britain, Russia, USA). Major powers of World War II (Axis Powers: Germany, Italy, Japan; Allied Powers: UK, France, USSR, USA).",
                  learningOutcomes: ["Locate and label French Revolution key cities on outline map of France", "Identify Allied and Central powers on world map"],
                  keyConcepts: ["Paris, Bordeaux, Nantes, Marseilles", "Allied vs Central powers", "Allied vs Axis powers"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Plotting European power alliances on outline maps of Europe"],
                  assessmentType: ["map"]
                },
                {
                  name: "Geography Map Work",
                  description: "1. India Standard Meridian (82°30'E), Tropic of Cancer. 2. Mountain peaks: K2, Kanchenjunga, Anai Mudi. 3. Plateaus: Malwa, Chota Nagpur, Deccan. 4. Lakes: Wular, Pulicat, Sambhar, Chilika. 5. Wildlife: Corbett, Kaziranga, Ranthambore, Gir, Kanha, Manas, Bharatpur.",
                  learningOutcomes: ["Plot Standard Meridian 82°30'E and Tropic of Cancer with precision", "Locate major mountain peaks, lakes, and national parks on physical map of India"],
                  keyConcepts: ["Standard Meridian 82°30'E", "Kanchenjunga, K2", "Chilika, Wular, Sambhar lakes", "Corbett, Kaziranga, Gir national parks"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Mapping national parks and wildlife sanctuaries on physical map of India"],
                  assessmentType: ["map"]
                }
              ]
            }
          ]
        },
        {
          name: "Internal Assessment: Social Science",
          marks: 20,
          type: "internal",
          description: "Pen-Paper Tests (5m), Multiple Assessments (5m), Subject Enrichment Activity (5m), Portfolio (5m).",
          topics: [
            {
              name: "Continuous Civic Evaluation",
              marks: 20,
              description: "Pen-Paper & Periodic Tests (5m), Multiple Assessments: quizzes, debates, group projects (5m), Subject Enrichment: maps and project reports (5m), Portfolio submission (5m).",
              examRelevance: "internal",
              tags: ["sst-class9-internal-assessment"],
              subtopics: [
                {
                  name: "Internal Assessment Split",
                  description: "Pen-Paper periodic unit tests (5 marks), Multiple assessments including debates, quizzes, mock parliament (5 marks), Subject enrichment practical map file / project (5 marks), Portfolio notebook maintenance (5 marks).",
                  learningOutcomes: ["Participate in civic debates and democratic simulations", "Maintain a complete geographic and historical map portfolio"],
                  keyConcepts: ["Continuous and comprehensive assessment", "Disaster management / Environmental project", "Civic participation portfolio"],
                  formulas: [],
                  proofs: [],
                  derivations: [],
                  exclusions: [],
                  activities: ["Interdisciplinary project on Disaster Management or Forest Conservation"],
                  assessmentType: ["internal"]
                }
              ]
            }
          ]
        }
      ]
    }
  ]
};

const outputPath = path.join(__dirname, '../src/data/cbse_class9_curriculum.json');
fs.writeFileSync(outputPath, JSON.stringify(curriculum, null, 2), 'utf-8');
console.log('cbse_class9_curriculum.json generated successfully! File size:', fs.statSync(outputPath).size, 'bytes');
