import { DeviceProfile, DeviceTier, RenderMode, NetworkSpeed } from './types';

export class DeviceDetector {
  /**
   * Probes hardware, memory, GPU contexts, and network to build an accurate profile.
   */
  static detectCapabilities(studentId: string = 'student_alex'): DeviceProfile {
    // 1. RAM estimation (navigator.deviceMemory in GB)
    let ramMB = 4096; // fallback 4GB
    if (typeof navigator !== 'undefined' && 'deviceMemory' in navigator) {
      const ramGB = (navigator as any).deviceMemory || 4;
      ramMB = Math.round(ramGB * 1024);
    }

    // 2. CPU Cores
    const cpuCores = typeof navigator !== 'undefined' ? navigator.hardwareConcurrency || 4 : 4;

    // 3. GPU / WebGL probing
    let gpuSupported = false;
    let webgl2Supported = false;
    if (typeof document !== 'undefined') {
      try {
        const canvas = document.createElement('canvas');
        gpuSupported = !!(
          window.WebGLRenderingContext &&
          (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
        );
        webgl2Supported = !!(window.WebGL2RenderingContext && canvas.getContext('webgl2'));
      } catch (e) {
        gpuSupported = false;
        webgl2Supported = false;
      }
    }

    // 4. Network Speed probing (Network Information API)
    let networkSpeed: NetworkSpeed = 'medium';
    if (typeof navigator !== 'undefined' && 'connection' in navigator) {
      const conn = (navigator as any).connection;
      const effectiveType = conn?.effectiveType || '4g';
      const downlink = conn?.downlink || 5;

      if (effectiveType === 'slow-2g' || effectiveType === '2g' || downlink < 1.0) {
        networkSpeed = 'slow';
      } else if (effectiveType === '3g' || downlink < 4.0) {
        networkSpeed = 'medium';
      } else {
        networkSpeed = 'fast';
      }
    }

    // 5. Tier classification logic:
    // Minimal: < 2GB RAM OR no WebGL OR (CPU cores <= 2 AND network slow)
    // Low: 2-3.9GB RAM OR single-threaded/dual-core CPU OR slow network
    // Medium: 4-7.9GB RAM, WebGL2 supported, decent CPU
    // High: 8GB+ RAM, WebGL2, >= 6 cores, fast network
    let deviceTier: DeviceTier = 'medium';
    let mode: RenderMode = 'lite';

    if (ramMB <= 1500 || !gpuSupported) {
      deviceTier = 'minimal';
      mode = 'audio-only';
    } else if (ramMB < 3500 || cpuCores <= 2 || networkSpeed === 'slow') {
      deviceTier = 'low';
      mode = 'lite';
    } else if (ramMB >= 8000 && cpuCores >= 6 && webgl2Supported && networkSpeed === 'fast') {
      deviceTier = 'high';
      mode = 'full';
    } else {
      deviceTier = 'medium';
      mode = 'lite';
    }

    // 6. Memory consumption estimate
    let memoryEstimateMB = 85;
    if (typeof performance !== 'undefined' && (performance as any).memory) {
      memoryEstimateMB = Math.round(((performance as any).memory.usedJSHeapSize || 0) / (1024 * 1024)) || 85;
    }

    return {
      studentId,
      deviceTier,
      ramMB,
      cpuCores,
      gpuSupported,
      webgl2Supported,
      networkSpeed,
      mode,
      autoDetected: true,
      measuredFps: 60,
      jankCount: 0,
      memoryEstimateMB,
      dataUsageBytes: 4200000, // ~4.2MB cached baseline
      dataSaverEnabled: deviceTier === 'low' || deviceTier === 'minimal',
      updatedAt: new Date().toISOString()
    };
  }
}
