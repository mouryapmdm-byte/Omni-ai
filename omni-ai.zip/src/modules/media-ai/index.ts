/**
 * Media & AI Module Public API
 * Responsibilities: Video/Audio recording studios, AI diagram & visual generation, recap video processing, and voice dialogue.
 */

export * from '../../components/YouTubeRecordingStudioModal';
export * from '../../components/RecapVideoGenerator';
export * from '../../components/LessonVideoCompiler';
export * from '../../components/AiDrawStudioModal';
export * from '../../components/VisualMapStudioModal';
export * from '../../components/DiagramAnalyzer';
export * from '../../components/TwoWayVoiceDialogue';
export * from '../../components/ScreenRecorder';
