export * from '../../src/modules/learning-style/signalCollector';
