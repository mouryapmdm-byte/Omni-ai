import { useState, useRef, useCallback } from 'react';

export interface TrackedStateOptions {
  stateName?: string;
  componentName?: string;
  maxUpdateThreshold?: number;
  logUpdates?: boolean;
  onExcessiveUpdates?: (count: number, lastValue: any) => void;
}

/**
 * Enhanced useState that monitors state update frequencies, detects excessive updates,
 * logs transition history, and guards against cascading state mutation cycles.
 */
export function useTrackedState<T>(
  initialValue: T | (() => T),
  optionsOrName?: string | TrackedStateOptions
): [T, (newValue: T | ((prev: T) => T)) => void, { getUpdateCount: () => number; resetCount: () => void }] {
  const options: TrackedStateOptions =
    typeof optionsOrName === 'string'
      ? { stateName: optionsOrName }
      : optionsOrName || {};

  const {
    stateName = 'TrackedState',
    componentName = 'Component',
    maxUpdateThreshold = 100,
    logUpdates = false,
    onExcessiveUpdates
  } = options;

  const [state, setState] = useState<T>(initialValue);
  const updateCountRef = useRef<number>(0);
  const warnedRef = useRef<boolean>(false);

  const trackedSetState = useCallback(
    (newValue: T | ((prev: T) => T)) => {
      updateCountRef.current++;
      const currentCount = updateCountRef.current;

      if (logUpdates) {
        console.log(
          `%c[useTrackedState] ${componentName} -> ${stateName} — Update #${currentCount}`,
          'background: #10b981; color: white; padding: 2px 6px; border-radius: 4px; font-weight: bold;'
        );
      }

      if (currentCount > maxUpdateThreshold && !warnedRef.current) {
        warnedRef.current = true;
        console.error(
          `%c[useTrackedState] ⚠️ Excessive Updates in ${componentName}.${stateName} (${currentCount} updates)`,
          'background: #ef4444; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold;'
        );
        if (onExcessiveUpdates) {
          onExcessiveUpdates(currentCount, newValue);
        }
      }

      setState(newValue);
    },
    [stateName, componentName, maxUpdateThreshold, logUpdates, onExcessiveUpdates]
  );

  const meta = {
    getUpdateCount: () => updateCountRef.current,
    resetCount: () => {
      updateCountRef.current = 0;
      warnedRef.current = false;
    }
  };

  return [state, trackedSetState, meta];
}
