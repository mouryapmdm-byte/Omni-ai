import React, { useState, useEffect, useRef } from 'react';
import { 
  GraduationCap, Clock, Award, CheckCircle2, XCircle, AlertTriangle, 
  HelpCircle, ChevronRight, ChevronLeft, RefreshCw, BarChart3, 
  FileCheck2, ArrowRight, ShieldCheck, Bookmark, Check, X, RotateCcw, Send, FileText
} from 'lucide-react';
import { cn } from '../lib/utils';
import { 
  ExamPatternTemplate, 
  ExamQuestionItem, 
  StudentQuestionResponse, 
  ExamAttempt,
  FullExamEvaluationReport,
  SupportedExamType
} from '../modules/exam-simulator/types';
import { EXAM_PATTERNS, SAMPLE_EXAM_PAPERS } from '../modules/exam-simulator/examTemplates';
import { AutoEvaluator } from '../modules/exam-simulator/AutoEvaluator';
import { Timer } from './Timer';
import { VirtualAnswerSheet } from './VirtualAnswerSheet';
import { ExamReport } from './ExamReport';

interface ExamSessionProps {
  initialExamId?: string;
  initialSubject?: string;
  isDark?: boolean;
  studentId?: string;
  onClose?: () => void;
  onRewardXp?: (xp: number) => void;
}

export const ExamSession: React.FC<ExamSessionProps> = ({
  initialExamId = 'cbse-12-physics',
  initialSubject = 'Physics',
  isDark = true,
  studentId = 'student_alex',
  onClose,
  onRewardXp,
}) => {
  const [selectedExamId, setSelectedExamId] = useState<string>(initialExamId);
  const [template, setTemplate] = useState<ExamPatternTemplate>(() => EXAM_PATTERNS[initialExamId] || EXAM_PATTERNS['cbse-12-physics']);
  const [questions, setQuestions] = useState<ExamQuestionItem[]>(() => SAMPLE_EXAM_PAPERS[initialExamId] || SAMPLE_EXAM_PAPERS['cbse-12-physics']);
  
  // Session states
  const [sessionStarted, setSessionStarted] = useState<boolean>(false);
  const [currentQIndex, setCurrentQIndex] = useState<number>(0);
  const [responses, setResponses] = useState<Record<string, StudentQuestionResponse>>({});
  const [activeSectionId, setActiveSectionId] = useState<string>('');
  
  // Time tracking
  const [startTime] = useState<string>(() => new Date().toISOString());
  const [questionStartTime, setQuestionStartTime] = useState<number>(Date.now());
  const [totalSecondsUsed, setTotalSecondsUsed] = useState<number>(0);
  
  // Modals & Evaluation
  const [showSubmitConfirm, setShowSubmitConfirm] = useState<boolean>(false);
  const [evaluationReport, setEvaluationReport] = useState<FullExamEvaluationReport | null>(null);

  // Load new exam pattern if selected
  const handleSelectExamPattern = (patternId: string) => {
    const tmpl = EXAM_PATTERNS[patternId] || EXAM_PATTERNS['cbse-12-physics'];
    const qs = SAMPLE_EXAM_PAPERS[patternId] || SAMPLE_EXAM_PAPERS['cbse-12-physics'];
    setSelectedExamId(patternId);
    setTemplate(tmpl);
    setQuestions(qs);
    setResponses({});
    setCurrentQIndex(0);
    setActiveSectionId(tmpl.sections[0]?.id || '');
    setEvaluationReport(null);
    setSessionStarted(false);
  };

  useEffect(() => {
    if (template.sections.length > 0 && !activeSectionId) {
      setActiveSectionId(template.sections[0].id);
    }
  }, [template, activeSectionId]);

  // Track time on current question when index changes
  const recordQuestionTime = () => {
    const elapsedSecs = Math.round((Date.now() - questionStartTime) / 1000);
    const currQ = questions[currentQIndex];
    if (currQ) {
      setResponses((prev) => {
        const existing = prev[currQ.id] || {
          questionId: currQ.id,
          timeSpent: 0,
          markedForReview: false,
          visited: true,
        };
        return {
          ...prev,
          [currQ.id]: {
            ...existing,
            timeSpent: existing.timeSpent + elapsedSecs,
            visited: true,
          },
        };
      });
    }
    setQuestionStartTime(Date.now());
  };

  const handleSelectQuestion = (index: number) => {
    if (index === currentQIndex || index < 0 || index >= questions.length) return;
    recordQuestionTime();
    setCurrentQIndex(index);
    const q = questions[index];
    if (q) setActiveSectionId(q.sectionId);
  };

  const handleSelectOption = (option: string) => {
    const q = questions[currentQIndex];
    if (!q) return;
    setResponses((prev) => {
      const existing = prev[q.id] || {
        questionId: q.id,
        timeSpent: 0,
        markedForReview: false,
        visited: true,
      };
      return {
        ...prev,
        [q.id]: {
          ...existing,
          selectedOption: option,
          visited: true,
        },
      };
    });
  };

  const handleSetNumericalAnswer = (val: number | undefined) => {
    const q = questions[currentQIndex];
    if (!q) return;
    setResponses((prev) => {
      const existing = prev[q.id] || {
        questionId: q.id,
        timeSpent: 0,
        markedForReview: false,
        visited: true,
      };
      return {
        ...prev,
        [q.id]: {
          ...existing,
          numericalAnswer: val,
          visited: true,
        },
      };
    });
  };

  const handleSetSubjectiveText = (text: string) => {
    const q = questions[currentQIndex];
    if (!q) return;
    setResponses((prev) => {
      const existing = prev[q.id] || {
        questionId: q.id,
        timeSpent: 0,
        markedForReview: false,
        visited: true,
      };
      return {
        ...prev,
        [q.id]: {
          ...existing,
          answerText: text,
          visited: true,
        },
      };
    });
  };

  const handleClearResponse = () => {
    const q = questions[currentQIndex];
    if (!q) return;
    setResponses((prev) => {
      const existing = prev[q.id];
      if (!existing) return prev;
      return {
        ...prev,
        [q.id]: {
          ...existing,
          selectedOption: undefined,
          answerText: undefined,
          numericalAnswer: undefined,
        },
      };
    });
  };

  const handleToggleMarkForReview = () => {
    const q = questions[currentQIndex];
    if (!q) return;
    setResponses((prev) => {
      const existing = prev[q.id] || {
        questionId: q.id,
        timeSpent: 0,
        markedForReview: false,
        visited: true,
      };
      return {
        ...prev,
        [q.id]: {
          ...existing,
          markedForReview: !existing.markedForReview,
          visited: true,
        },
      };
    });
  };

  const handleSaveAndNext = () => {
    recordQuestionTime();
    if (currentQIndex < questions.length - 1) {
      setCurrentQIndex(currentQIndex + 1);
      const nextQ = questions[currentQIndex + 1];
      if (nextQ) setActiveSectionId(nextQ.sectionId);
    } else {
      setShowSubmitConfirm(true);
    }
  };

  const handleSubmitExam = () => {
    recordQuestionTime();
    setShowSubmitConfirm(false);

    const completedTime = new Date().toISOString();
    const durationSeconds = Math.max(60, Math.round((new Date(completedTime).getTime() - new Date(startTime).getTime()) / 1000));
    setTotalSecondsUsed(durationSeconds);

    const answersArray = questions.map((q) => {
      const resp = responses[q.id];
      return {
        questionId: q.id,
        selectedOption: resp?.selectedOption,
        answerText: resp?.answerText,
        numericalAnswer: resp?.numericalAnswer,
        timeSpent: resp?.timeSpent || 0,
        markedForReview: resp?.markedForReview || false,
      };
    });

    const attempt: ExamAttempt = {
      id: 'attempt_' + Math.random().toString(36).substring(2, 9),
      studentId,
      examType: template.examType,
      examPatternId: template.id,
      examYear: 2026,
      subject: questions[0]?.subject || initialSubject,
      startedAt: startTime,
      completedAt: completedTime,
      durationSecondsUsed: durationSeconds,
      answers: answersArray,
      score: 0,
      maxScore: template.totalMarks,
      percentile: 0,
      accuracyPercentage: 0,
      speedQuestionsPerHour: 0,
    };

    // Instant auto-evaluation
    const report = AutoEvaluator.generateReport(attempt, template, questions);
    setEvaluationReport(report);

    if (onRewardXp) {
      onRewardXp(Math.max(50, Math.round(report.totalScore * 5)));
    }
  };

  // If report is generated, show ExamReport
  if (evaluationReport) {
    return (
      <div className="w-full">
        <ExamReport
          report={evaluationReport}
          questions={questions}
          onRetakeExam={() => handleSelectExamPattern(selectedExamId)}
          onClose={onClose}
          isDark={isDark}
        />
      </div>
    );
  }

  // Pre-Exam Lobby
  if (!sessionStarted) {
    return (
      <div className={cn(
        "w-full rounded-2xl border shadow-xl p-6 sm:p-8 space-y-6",
        isDark ? "bg-slate-950 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
      )}>
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/20">
              <GraduationCap size={24} />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black">Official Exam Simulator</h2>
              <p className="text-xs text-slate-400 mt-0.5">Authentic exam conditions, strict timers & step-wise marking schemes</p>
            </div>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition self-end sm:self-auto cursor-pointer"
            >
              <X size={20} />
            </button>
          )}
        </div>

        {/* Pattern Selector Cards */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
            Select Official Exam Blueprint:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {Object.values(EXAM_PATTERNS).map((pat) => (
              <button
                key={pat.id}
                onClick={() => handleSelectExamPattern(pat.id)}
                className={cn(
                  "p-4 rounded-2xl border text-left transition flex flex-col justify-between cursor-pointer",
                  selectedExamId === pat.id
                    ? "bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-500/10 ring-1 ring-indigo-500"
                    : isDark ? "bg-slate-900/60 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                )}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                      {pat.examType.toUpperCase()}
                    </span>
                    <span className="text-xs font-bold text-slate-400">{pat.durationMinutes} Mins</span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-200 line-clamp-1">{pat.title}</h4>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{pat.subtitle}</p>
                </div>

                <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 border-t border-slate-800/80 pt-2.5 mt-3">
                  <span>{pat.totalMarks} Marks • {pat.totalQuestions} Qs</span>
                  <span className={pat.hasNegativeMarking ? "text-amber-400" : "text-emerald-400"}>
                    {pat.hasNegativeMarking ? 'Negative Marking' : 'No Negative'}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Pattern Blueprint Summary */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
              <FileCheck2 size={16} className="text-indigo-400" /> Exam Rules & Section Structure
            </h3>
            <span className="text-xs font-bold text-indigo-400">{template.durationMinutes} Minutes (Strict Time Limit)</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {template.sections.map((s) => (
              <div key={s.id} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
                <h5 className="font-bold text-slate-200">{s.name}</h5>
                <p className="text-[11px] text-slate-400 mt-0.5">{s.description}</p>
                <div className="flex justify-between text-[10px] font-semibold text-indigo-300 mt-2">
                  <span>{s.totalQuestions} Questions</span>
                  <span>{s.marksPerQuestion}M per Q {s.negativeMarksPerQuestion > 0 ? `(-${s.negativeMarksPerQuestion})` : ''}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Instructions */}
          <div className="space-y-1.5 text-xs text-slate-400">
            <span className="font-bold text-slate-300 uppercase text-[10px] block">Official Instructions:</span>
            {template.instructions.map((inst, idx) => (
              <p key={idx} className="flex items-start gap-1.5">
                <span className="text-indigo-400 font-bold">•</span>
                <span>{inst}</span>
              </p>
            ))}
          </div>
        </div>

        {/* Start Button */}
        <div className="flex justify-end gap-3 pt-2">
          {onClose && (
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-slate-400 hover:text-slate-200 text-xs font-bold transition cursor-pointer"
            >
              Cancel
            </button>
          )}
          <button
            onClick={() => setSessionStarted(true)}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 hover:from-indigo-500 hover:to-pink-400 text-white text-sm font-black shadow-xl shadow-indigo-600/30 flex items-center gap-2 transition cursor-pointer"
          >
            <ShieldCheck size={18} /> Start Exam Simulation (Enter Lock-In)
          </button>
        </div>
      </div>
    );
  }

  // Active Simulation Exam Session
  const currentQuestion = questions[currentQIndex];
  const currentResp = currentQuestion ? responses[currentQuestion.id] : undefined;

  return (
    <div className={cn(
      "w-full rounded-2xl border shadow-2xl flex flex-col h-[90vh] max-h-[850px] overflow-hidden",
      isDark ? "bg-slate-950 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Top Invigilated Header */}
      <div className="p-3 sm:p-4 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
            {template.examType.toUpperCase().slice(0, 3)}
          </div>
          <div>
            <h3 className="font-bold text-xs sm:text-sm text-slate-200 line-clamp-1">{template.title}</h3>
            <span className="text-[10px] text-slate-400">Total: {template.totalMarks} Marks • Negative Marking Active</span>
          </div>
        </div>

        {/* Section Quick Pills */}
        <div className="hidden lg:flex items-center gap-1.5 overflow-x-auto">
          {template.sections.map((sec) => (
            <button
              key={sec.id}
              onClick={() => {
                const firstQIdx = questions.findIndex(q => q.sectionId === sec.id);
                if (firstQIdx !== -1) handleSelectQuestion(firstQIdx);
              }}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer",
                activeSectionId === sec.id
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "bg-slate-800/80 text-slate-400 hover:text-slate-200"
              )}
            >
              {sec.name.split(':')[0]}
            </button>
          ))}
        </div>

        {/* Timer & Submit CTA */}
        <div className="flex items-center gap-2">
          <Timer
            totalSeconds={template.durationMinutes * 60}
            onTimeUp={handleSubmitExam}
            enableInvigilation={true}
            isDark={isDark}
          />
          <button
            onClick={() => setShowSubmitConfirm(true)}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black shadow-lg shadow-emerald-600/20 flex items-center gap-1.5 transition cursor-pointer"
          >
            <Send size={13} /> Submit Test
          </button>
        </div>
      </div>

      {/* Main Simulation Body */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Left / Center: Question & Answer Workspace (2/3) */}
        <div className="flex-1 flex flex-col overflow-y-auto p-4 sm:p-6 bg-slate-950/40">
          {currentQuestion ? (
            <div className="space-y-5 flex-1 flex flex-col justify-between">
              {/* Question Header Bar */}
              <div>
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-4">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-xl bg-indigo-600 text-white font-black text-xs">
                      Question {currentQuestion.questionNumber}
                    </span>
                    <span className="text-xs font-bold text-slate-400">
                      Topic: <span className="text-indigo-400">{currentQuestion.topic}</span>
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      +{currentQuestion.marks} Marks
                    </span>
                    {currentQuestion.negativeMarks > 0 && (
                      <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-rose-500/10 text-rose-400 border border-rose-500/20">
                        -{currentQuestion.negativeMarks} Negative
                      </span>
                    )}
                  </div>
                </div>

                {/* Question Statement */}
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 mb-5">
                  <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-serif">
                    {currentQuestion.questionText}
                  </p>
                </div>

                {/* Answer Inputs based on Question Type */}
                {/* 1. MCQ Options */}
                {currentQuestion.options && currentQuestion.options.length > 0 && (
                  <div className="space-y-2.5">
                    {currentQuestion.options.map((opt, oIdx) => {
                      const optLabel = String.fromCharCode(65 + oIdx); // A, B, C, D
                      const isSelected = currentResp?.selectedOption === opt;

                      return (
                        <button
                          key={oIdx}
                          type="button"
                          onClick={() => handleSelectOption(opt)}
                          className={cn(
                            "w-full p-3.5 rounded-xl border text-left flex items-center gap-3 transition cursor-pointer",
                            isSelected
                              ? "bg-indigo-600/20 border-indigo-500 text-indigo-200 shadow-sm"
                              : "bg-slate-900/40 border-slate-800 text-slate-300 hover:bg-slate-900 hover:border-slate-700"
                          )}
                        >
                          <span className={cn(
                            "w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 transition",
                            isSelected ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400"
                          )}>
                            {optLabel}
                          </span>
                          <span className="text-xs sm:text-sm font-medium">{opt}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 2. Numerical Input */}
                {currentQuestion.questionType === 'numerical' && (
                  <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                      Enter Calculated Numerical Value:
                    </label>
                    <input
                      type="number"
                      step="any"
                      placeholder="e.g. 40 or 3.14"
                      value={currentResp?.numericalAnswer !== undefined ? currentResp.numericalAnswer : ''}
                      onChange={(e) => handleSetNumericalAnswer(e.target.value !== '' ? Number(e.target.value) : undefined)}
                      className="w-full max-w-xs px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm font-mono text-slate-100 outline-none focus:border-indigo-500"
                    />
                    <span className="text-[11px] text-slate-400 block">
                      Use decimal point for non-integers. Decimal places up to 2 digits.
                    </span>
                  </div>
                )}

                {/* 3. Subjective Text Input */}
                {(currentQuestion.questionType === 'subjective_short' || currentQuestion.questionType === 'subjective_long' || currentQuestion.questionType === 'case_study') && (
                  <div className="space-y-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                      Virtual Answer Sheet (Write your step-wise derivation / solution):
                    </label>
                    <textarea
                      rows={6}
                      placeholder="Type your structured solution step by step. Mention key physical laws, formula substitutions, and final units..."
                      value={currentResp?.answerText || ''}
                      onChange={(e) => handleSetSubjectiveText(e.target.value)}
                      className="w-full p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs sm:text-sm font-mono text-slate-200 outline-none focus:border-indigo-500 leading-relaxed resize-none"
                    />
                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>Step-wise evaluation scheme active</span>
                      <span>{(currentResp?.answerText || '').length} characters</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Navigation Toolbar */}
              <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleToggleMarkForReview}
                    className={cn(
                      "px-3.5 py-2 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer",
                      currentResp?.markedForReview
                        ? "bg-purple-600 text-white border-purple-500 shadow-md"
                        : "bg-slate-900 border-slate-800 text-purple-400 hover:bg-slate-800"
                    )}
                  >
                    <Bookmark size={14} />
                    {currentResp?.markedForReview ? 'Marked for Review' : 'Mark for Review'}
                  </button>

                  <button
                    onClick={handleClearResponse}
                    className="px-3.5 py-2 rounded-xl text-xs font-bold border border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw size={13} /> Clear Response
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleSelectQuestion(currentQIndex - 1)}
                    disabled={currentQIndex === 0}
                    className="px-4 py-2 rounded-xl text-xs font-bold border border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 disabled:opacity-40 transition flex items-center gap-1 cursor-pointer"
                  >
                    <ChevronLeft size={16} /> Previous
                  </button>

                  <button
                    onClick={handleSaveAndNext}
                    className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black shadow-md shadow-indigo-600/20 flex items-center gap-1.5 transition cursor-pointer"
                  >
                    {currentQIndex === questions.length - 1 ? 'Save & Review' : 'Save & Next'}
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* Right Sidebar: Virtual Answer Sheet & Question Palette (1/3) */}
        <div className="w-full md:w-80 lg:w-96 border-t md:border-t-0 md:border-l border-slate-800 bg-slate-900/60 p-3 sm:p-4">
          <VirtualAnswerSheet
            questions={questions}
            template={template}
            responses={responses}
            currentQuestionIndex={currentQIndex}
            onSelectQuestion={handleSelectQuestion}
            isDark={isDark}
          />
        </div>
      </div>

      {/* Submission Confirmation Modal */}
      {showSubmitConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 text-slate-100 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <AlertTriangle size={20} />
              </div>
              <div>
                <h4 className="font-bold text-base">Submit Examination?</h4>
                <p className="text-xs text-slate-400">Review your final response summary below.</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 mb-5">
              <div>
                <span className="text-slate-400">Total Questions:</span>
                <span className="font-bold text-slate-200 ml-1.5">{questions.length}</span>
              </div>
              <div>
                <span className="text-slate-400">Answered:</span>
                <span className="font-bold text-emerald-400 ml-1.5">
                  {Object.values(responses).filter(r => r.selectedOption || r.answerText || r.numericalAnswer !== undefined).length}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Marked for Review:</span>
                <span className="font-bold text-purple-400 ml-1.5">
                  {Object.values(responses).filter(r => r.markedForReview).length}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Unattempted:</span>
                <span className="font-bold text-rose-400 ml-1.5">
                  {questions.length - Object.values(responses).filter(r => r.selectedOption || r.answerText || r.numericalAnswer !== undefined).length}
                </span>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowSubmitConfirm(false)}
                className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-slate-200 text-xs font-bold transition cursor-pointer"
              >
                Resume Exam
              </button>
              <button
                onClick={handleSubmitExam}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-lg shadow-emerald-600/20 transition cursor-pointer"
              >
                Confirm & Auto-Evaluate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
