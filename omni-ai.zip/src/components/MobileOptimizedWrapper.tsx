import React, { useState, useEffect, useRef, createContext, useContext, ReactNode, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Smartphone,
  Touchpad,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Move,
  Hand,
  Maximize2,
  Minimize2,
  Compass,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Sliders,
  Volume2,
  Play,
  Pause,
  Eye,
  BookOpen,
  Layers,
  Sparkles,
  HelpCircle,
  Check,
  X,
  Grid,
  Monitor,
  Tablet,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Radio,
  FileText,
  MousePointer
} from 'lucide-react';
import { cn, triggerHapticFeedback } from '../lib/utils';

export interface MobileOptimizationState {
  isMobile: boolean;
  isTablet: boolean;
  isTouchDevice: boolean;
  orientation: 'portrait' | 'landscape';
  touchFirstMode: boolean;
  setTouchFirstMode: (active: boolean) => void;
  scale: number;
  setScale: (scale: number | ((prev: number) => number)) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  resetZoom: () => void;
  panOffset: { x: number; y: number };
  setPanOffset: (offset: { x: number; y: number } | ((prev: { x: number; y: number }) => { x: number; y: number })) => void;
  resetPan: () => void;
  isBlackboardSheetOpen: boolean;
  setIsBlackboardSheetOpen: (open: boolean) => void;
  isJoystickEnabled: boolean;
  setIsJoystickEnabled: (enabled: boolean) => void;
  showGestureGuide: boolean;
  setShowGestureGuide: (show: boolean) => void;
  fontSizeMultiplier: number;
  setFontSizeMultiplier: (val: number | ((prev: number) => number)) => void;
}

const MobileOptimizationContext = createContext<MobileOptimizationState | null>(null);

export const useMobileOptimization = () => {
  const context = useContext(MobileOptimizationContext);
  if (!context) {
    // Return fallback defaults if used outside provider
    return {
      isMobile: false,
      isTablet: false,
      isTouchDevice: false,
      orientation: 'landscape' as const,
      touchFirstMode: false,
      setTouchFirstMode: () => {},
      scale: 1,
      setScale: () => {},
      zoomIn: () => {},
      zoomOut: () => {},
      resetZoom: () => {},
      panOffset: { x: 0, y: 0 },
      setPanOffset: () => {},
      resetPan: () => {},
      isBlackboardSheetOpen: false,
      setIsBlackboardSheetOpen: () => {},
      isJoystickEnabled: false,
      setIsJoystickEnabled: () => {},
      showGestureGuide: false,
      setShowGestureGuide: () => {},
      fontSizeMultiplier: 1,
      setFontSizeMultiplier: () => {},
    };
  }
  return context;
};

export interface MobileOptimizedWrapperProps {
  children: ReactNode;
  className?: string;
  theme?: 'dark' | 'light';
  title?: string;
  topic?: string;
  boardContent?: string;
  onCameraPresetChange?: (preset: string) => void;
  onStartLecture?: () => void;
  onPauseLecture?: () => void;
  isLectureActive?: boolean;
  isLecturePaused?: boolean;
  onJoystickMove?: (direction: { x: number; y: number }) => void;
  onDoubleTapBlackboard?: () => void;
  onLongPressAction?: () => void;
  customHeaderExtra?: ReactNode;
}

export const MobileOptimizedWrapper: React.FC<MobileOptimizedWrapperProps> = ({
  children,
  className,
  theme = 'dark',
  title = '3D Virtual Classroom',
  topic,
  boardContent,
  onCameraPresetChange,
  onStartLecture,
  onPauseLecture,
  isLectureActive = false,
  isLecturePaused = false,
  onJoystickMove,
  onDoubleTapBlackboard,
  onLongPressAction,
  customHeaderExtra
}) => {
  // Device Detection State
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [isTablet, setIsTablet] = useState<boolean>(false);
  const [isTouchDevice, setIsTouchDevice] = useState<boolean>(false);
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('landscape');
  const [touchFirstMode, setTouchFirstMode] = useState<boolean>(false);

  // Gesture Scaling & Panning State
  const [scale, setScale] = useState<number>(1);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [fontSizeMultiplier, setFontSizeMultiplier] = useState<number>(1);

  // Interactive UI Overlays State
  const [isBlackboardSheetOpen, setIsBlackboardSheetOpen] = useState<boolean>(false);
  const [isJoystickEnabled, setIsJoystickEnabled] = useState<boolean>(false);
  const [showGestureGuide, setShowGestureGuide] = useState<boolean>(false);
  const [activeCamera, setActiveCamera] = useState<string>('front_row');
  const [isHudCollapsed, setIsHudCollapsed] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const gestureStateRef = useRef<{
    lastTouchDist: number;
    lastTouchCenter: { x: number; y: number };
    lastTouchTime: number;
    lastTapTime: number;
    tapTimeout: any;
    longPressTimeout: any;
    isPinching: boolean;
    isPanning: boolean;
    startPanPos: { x: number; y: number };
  }>({
    lastTouchDist: 0,
    lastTouchCenter: { x: 0, y: 0 },
    lastTouchTime: 0,
    lastTapTime: 0,
    tapTimeout: null,
    longPressTimeout: null,
    isPinching: false,
    isPanning: false,
    startPanPos: { x: 0, y: 0 },
  });

  // Device & Touch Capability Detector
  useEffect(() => {
    const checkDevice = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const touchSupported =
        'ontouchstart' in window ||
        navigator.maxTouchPoints > 0 ||
        window.matchMedia('(pointer: coarse)').matches;

      const mobileCheck = width < 768 || (touchSupported && width < 900 && height < 1200);
      const tabletCheck = width >= 768 && width <= 1024;
      const orient = height > width ? 'portrait' : 'landscape';

      setIsMobile(mobileCheck);
      setIsTablet(tabletCheck);
      setIsTouchDevice(touchSupported);
      setOrientation(orient);

      // Default to touch-first mode if on mobile or coarse pointer
      if (mobileCheck || touchSupported) {
        setTouchFirstMode(true);
      }
    };

    checkDevice();
    window.addEventListener('resize', checkDevice);
    window.addEventListener('orientationchange', checkDevice);

    return () => {
      window.removeEventListener('resize', checkDevice);
      window.removeEventListener('orientationchange', checkDevice);
    };
  }, []);

  // Zoom Helpers
  const zoomIn = useCallback(() => {
    setScale((prev) => {
      const next = Math.min(prev + 0.25, 2.5);
      triggerHapticFeedback(10);
      return parseFloat(next.toFixed(2));
    });
  }, []);

  const zoomOut = useCallback(() => {
    setScale((prev) => {
      const next = Math.max(prev - 0.25, 0.6);
      triggerHapticFeedback(10);
      return parseFloat(next.toFixed(2));
    });
  }, []);

  const resetZoom = useCallback(() => {
    setScale(1);
    setPanOffset({ x: 0, y: 0 });
    triggerHapticFeedback(15);
  }, []);

  const resetPan = useCallback(() => {
    setPanOffset({ x: 0, y: 0 });
  }, []);

  // Multi-Touch Gesture Handling (Pinch-to-scale, Pan, Tap, Double-Tap, Long-Press)
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    const touches = e.touches;

    if (touches.length === 2) {
      // Pinch / Two-finger Pan start
      const dx = touches[0].clientX - touches[1].clientX;
      const dy = touches[0].clientY - touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const centerX = (touches[0].clientX + touches[1].clientX) / 2;
      const centerY = (touches[0].clientY + touches[1].clientY) / 2;

      gestureStateRef.current.lastTouchDist = dist;
      gestureStateRef.current.lastTouchCenter = { x: centerX, y: centerY };
      gestureStateRef.current.isPinching = true;
      gestureStateRef.current.isPanning = true;

      if (gestureStateRef.current.longPressTimeout) {
        clearTimeout(gestureStateRef.current.longPressTimeout);
      }
    } else if (touches.length === 1) {
      // Single touch tap / pan / double-tap / long-press detection
      const touch = touches[0];
      const now = Date.now();
      const timeSinceLastTap = now - gestureStateRef.current.lastTapTime;

      gestureStateRef.current.startPanPos = { x: touch.clientX, y: touch.clientY };

      // Long press detection (500ms)
      gestureStateRef.current.longPressTimeout = setTimeout(() => {
        triggerHapticFeedback([20, 50, 20]);
        onLongPressAction?.();
        setIsBlackboardSheetOpen(true);
      }, 550);

      // Double tap detection (300ms window)
      if (timeSinceLastTap < 320) {
        clearTimeout(gestureStateRef.current.longPressTimeout);
        triggerHapticFeedback(25);
        if (scale > 1.1) {
          resetZoom();
        } else {
          setScale(1.6);
          onDoubleTapBlackboard?.();
          setIsBlackboardSheetOpen(true);
        }
        gestureStateRef.current.lastTapTime = 0;
      } else {
        gestureStateRef.current.lastTapTime = now;
      }
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const touches = e.touches;

    // Multi-touch pinch-to-zoom & two-finger pan
    if (touches.length === 2 && gestureStateRef.current.isPinching) {
      const dx = touches[0].clientX - touches[1].clientX;
      const dy = touches[0].clientY - touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const centerX = (touches[0].clientX + touches[1].clientX) / 2;
      const centerY = (touches[0].clientY + touches[1].clientY) / 2;

      const lastDist = gestureStateRef.current.lastTouchDist;
      if (lastDist > 0) {
        const factor = dist / lastDist;
        setScale((prev) => {
          const next = Math.max(0.6, Math.min(2.5, prev * factor));
          return parseFloat(next.toFixed(2));
        });

        // 2-finger pan delta
        const deltaX = centerX - gestureStateRef.current.lastTouchCenter.x;
        const deltaY = centerY - gestureStateRef.current.lastTouchCenter.y;
        setPanOffset((prev) => ({
          x: Math.max(-300, Math.min(300, prev.x + deltaX * 0.8)),
          y: Math.max(-300, Math.min(300, prev.y + deltaY * 0.8)),
        }));
      }

      gestureStateRef.current.lastTouchDist = dist;
      gestureStateRef.current.lastTouchCenter = { x: centerX, y: centerY };

      if (gestureStateRef.current.longPressTimeout) {
        clearTimeout(gestureStateRef.current.longPressTimeout);
      }
    } else if (touches.length === 1 && gestureStateRef.current.longPressTimeout) {
      // Cancel long press if moved significantly
      const touch = touches[0];
      const moveDist = Math.hypot(
        touch.clientX - gestureStateRef.current.startPanPos.x,
        touch.clientY - gestureStateRef.current.startPanPos.y
      );
      if (moveDist > 12) {
        clearTimeout(gestureStateRef.current.longPressTimeout);
      }
    }
  };

  const handleTouchEnd = () => {
    gestureStateRef.current.isPinching = false;
    gestureStateRef.current.isPanning = false;
    gestureStateRef.current.lastTouchDist = 0;
    if (gestureStateRef.current.longPressTimeout) {
      clearTimeout(gestureStateRef.current.longPressTimeout);
    }
  };

  const handleCameraChange = (preset: string) => {
    setActiveCamera(preset);
    triggerHapticFeedback(12);
    onCameraPresetChange?.(preset);
  };

  const handleVirtualDpadPress = (dx: number, dy: number) => {
    triggerHapticFeedback(8);
    onJoystickMove?.({ x: dx, y: dy });
  };

  const contextValue: MobileOptimizationState = {
    isMobile,
    isTablet,
    isTouchDevice,
    orientation,
    touchFirstMode,
    setTouchFirstMode,
    scale,
    setScale,
    zoomIn,
    zoomOut,
    resetZoom,
    panOffset,
    setPanOffset,
    resetPan,
    isBlackboardSheetOpen,
    setIsBlackboardSheetOpen,
    isJoystickEnabled,
    setIsJoystickEnabled,
    showGestureGuide,
    setShowGestureGuide,
    fontSizeMultiplier,
    setFontSizeMultiplier,
  };

  return (
    <MobileOptimizationContext.Provider value={contextValue}>
      <div
        ref={containerRef}
        className={cn(
          "relative w-full h-full overflow-hidden select-none touch-none",
          touchFirstMode ? "touch-first-environment" : "standard-desktop-environment",
          className
        )}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* TOP STATUS BAR (Touch Optimized Mobile Header) */}
        <div 
          id="mobile-touch-status-bar"
          className="absolute top-20 sm:top-14 left-2 right-2 z-30 flex items-center justify-between pointer-events-none [&>*]:pointer-events-auto gap-2"
        >
          {/* Left Pill: Touch Mode Indicator & Mode Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-950/90 border border-slate-800/80 rounded-2xl px-2.5 py-1.5 backdrop-blur-xl shadow-xl">
            <button
              onClick={() => {
                setTouchFirstMode(!touchFirstMode);
                triggerHapticFeedback(15);
              }}
              className={cn(
                "flex items-center gap-1.5 px-2 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer",
                touchFirstMode
                  ? "bg-indigo-600/30 text-indigo-300 border border-indigo-500/40"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              )}
              title={touchFirstMode ? "Touch-First Mode Active (Tap to toggle Standard Layout)" : "Standard Mode Active (Tap to toggle Touch-First Layout)"}
            >
              {touchFirstMode ? <Touchpad size={13} className="text-indigo-400 animate-pulse" /> : <MousePointer size={13} />}
              <span className="hidden xs:inline">{touchFirstMode ? "Touch Layout" : "Desktop Layout"}</span>
              <span className="xs:hidden">{touchFirstMode ? "Touch" : "Desk"}</span>
            </button>

            {/* Zoom Badge Indicator */}
            {scale !== 1 && (
              <button
                onClick={resetZoom}
                className="flex items-center gap-1 px-2 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold cursor-pointer animate-in fade-in"
                title="Tap to Reset Zoom to 100%"
              >
                <span>{Math.round(scale * 100)}%</span>
                <RotateCcw size={10} />
              </button>
            )}
          </div>

          {/* Right Controls: Gesture Guide, Virtual Joystick Toggle & HUD Collapse */}
          <div className="flex items-center gap-1.5 bg-slate-950/90 border border-slate-800/80 rounded-2xl p-1 backdrop-blur-xl shadow-xl">
            {/* Blackboard Reader Sheet Toggle */}
            <button
              onClick={() => {
                setIsBlackboardSheetOpen(!isBlackboardSheetOpen);
                triggerHapticFeedback(12);
              }}
              className={cn(
                "p-2 rounded-xl transition-all cursor-pointer flex items-center justify-center",
                isBlackboardSheetOpen
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              )}
              title="Toggle Blackboard Reader & Notes Sheet"
            >
              <FileText size={14} />
            </button>

            {/* Virtual Joystick Toggle */}
            <button
              onClick={() => {
                setIsJoystickEnabled(!isJoystickEnabled);
                triggerHapticFeedback(12);
              }}
              className={cn(
                "p-2 rounded-xl transition-all cursor-pointer flex items-center justify-center",
                isJoystickEnabled
                  ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              )}
              title="Toggle Virtual Thumbstick D-Pad for 3D Camera"
            >
              <Compass size={14} />
            </button>

            {/* Gesture Guide Help Button */}
            <button
              onClick={() => {
                setShowGestureGuide(!showGestureGuide);
                triggerHapticFeedback(10);
              }}
              className={cn(
                "p-2 rounded-xl transition-all cursor-pointer flex items-center justify-center",
                showGestureGuide
                  ? "bg-amber-500/30 text-amber-300 border border-amber-500/40"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              )}
              title="Touch & Gesture Controls Guide"
            >
              <HelpCircle size={14} />
            </button>

            {customHeaderExtra}
          </div>
        </div>

        {/* MAIN 3D / BLACKBOARD CANVAS VIEWPORT (WITH GESTURE ZOOM/PAN TRANSFORM) */}
        <div
          className={cn(
            "w-full h-full transition-transform duration-75 origin-center",
            (scale !== 1 || panOffset.x !== 0 || panOffset.y !== 0) && "will-change-transform"
          )}
          style={{
            transform: (scale !== 1 || panOffset.x !== 0 || panOffset.y !== 0)
              ? `translate3d(${panOffset.x}px, ${panOffset.y}px, 0px) scale(${scale})`
              : undefined,
          }}
        >
          {children}
        </div>

        {/* FLOATING VIRTUAL THUMBSTICK / D-PAD (FOR ONE-HANDED 3D CAMERA ORBIT) */}
        <AnimatePresence>
          {isJoystickEnabled && touchFirstMode && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              className="absolute left-4 bottom-24 z-30 pointer-events-auto bg-slate-950/90 border border-slate-800/90 rounded-full p-2 backdrop-blur-2xl shadow-2xl"
            >
              <div className="relative w-28 h-28 flex items-center justify-center">
                {/* Center Pivot */}
                <button
                  onClick={() => resetZoom()}
                  className="w-9 h-9 rounded-full bg-indigo-600/40 border border-indigo-500/60 text-white flex items-center justify-center text-[10px] font-bold shadow cursor-pointer active:scale-90 transition-transform"
                  title="Reset 3D View"
                >
                  <RotateCcw size={13} />
                </button>

                {/* Up Button */}
                <button
                  onClick={() => handleVirtualDpadPress(0, -1)}
                  className="absolute top-1 left-1/2 -translate-x-1/2 p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 active:bg-indigo-600 active:text-white cursor-pointer transition-colors shadow"
                  title="Orbit Camera Up"
                >
                  <ArrowUp size={14} />
                </button>

                {/* Down Button */}
                <button
                  onClick={() => handleVirtualDpadPress(0, 1)}
                  className="absolute bottom-1 left-1/2 -translate-x-1/2 p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 active:bg-indigo-600 active:text-white cursor-pointer transition-colors shadow"
                  title="Orbit Camera Down"
                >
                  <ArrowDown size={14} />
                </button>

                {/* Left Button */}
                <button
                  onClick={() => handleVirtualDpadPress(-1, 0)}
                  className="absolute left-1 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 active:bg-indigo-600 active:text-white cursor-pointer transition-colors shadow"
                  title="Orbit Camera Left"
                >
                  <ArrowLeft size={14} />
                </button>

                {/* Right Button */}
                <button
                  onClick={() => handleVirtualDpadPress(1, 0)}
                  className="absolute right-1 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 active:bg-indigo-600 active:text-white cursor-pointer transition-colors shadow"
                  title="Orbit Camera Right"
                >
                  <ArrowRight size={14} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* QUICK GESTURE GUIDE MODAL / OVERLAY - Disabled */}
        <AnimatePresence>
          {false && showGestureGuide && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-x-4 top-16 max-w-sm mx-auto z-50 bg-slate-950/95 border border-indigo-500/40 rounded-3xl p-4 shadow-2xl backdrop-blur-2xl pointer-events-auto"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400">
                    <Sparkles size={16} />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">Touch & Gesture Controls</h3>
                    <p className="text-[10px] text-slate-400">Interact smoothly with 3D space & blackboard</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowGestureGuide(false)}
                  className="p-1 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-2.5 text-xs text-slate-300">
                <div className="flex items-center gap-3 p-2 rounded-2xl bg-slate-900/80 border border-slate-800/80">
                  <span className="text-lg">🤏</span>
                  <div>
                    <span className="font-bold text-white">Pinch to Zoom:</span>
                    <p className="text-[11px] text-slate-400">Scale the blackboard equations and 3D classroom from 60% to 250%.</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-2 rounded-2xl bg-slate-900/80 border border-slate-800/80">
                  <span className="text-lg">✌️</span>
                  <div>
                    <span className="font-bold text-white">Two-Finger Pan:</span>
                    <p className="text-[11px] text-slate-400">Swipe with two fingers to glide across equations and diagrams.</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-2 rounded-2xl bg-slate-900/80 border border-slate-800/80">
                  <span className="text-lg">👆</span>
                  <div>
                    <span className="font-bold text-white">Single Finger Drag:</span>
                    <p className="text-[11px] text-slate-400">Orbit the 3D camera 360° around the lecture hall.</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-2 rounded-2xl bg-slate-900/80 border border-slate-800/80">
                  <span className="text-lg">👆👆</span>
                  <div>
                    <span className="font-bold text-white">Double Tap:</span>
                    <p className="text-[11px] text-slate-400">Auto-focus onto Smartboard blackboard notes or reset zoom.</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-2 rounded-2xl bg-slate-900/80 border border-slate-800/80">
                  <span className="text-lg">⏱️</span>
                  <div>
                    <span className="font-bold text-white">Long Press:</span>
                    <p className="text-[11px] text-slate-400">Open blackboard reader sheet with larger text and audio controls.</p>
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-800 flex justify-end">
                <button
                  onClick={() => setShowGestureGuide(false)}
                  className="px-4 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold shadow-md shadow-indigo-600/30 cursor-pointer"
                >
                  Got It!
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* MOBILE BLACKBOARD READER & NOTES BOTTOM SHEET */}
        <AnimatePresence>
          {isBlackboardSheetOpen && touchFirstMode && (
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              className="absolute inset-x-2 bottom-2 max-h-[75vh] z-50 bg-slate-950/98 border border-indigo-500/40 rounded-3xl p-4 shadow-2xl backdrop-blur-2xl pointer-events-auto flex flex-col"
            >
              {/* Sheet Handle */}
              <div className="w-12 h-1.5 rounded-full bg-slate-700 mx-auto mb-3 shrink-0" />

              {/* Sheet Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
                <div className="flex items-center gap-2">
                  <span className={cn(
                    "w-2.5 h-2.5 rounded-full",
                    isLectureActive && !isLecturePaused ? "bg-emerald-400 animate-ping" : isLecturePaused ? "bg-amber-400" : "bg-indigo-500"
                  )} />
                  <div>
                    <h3 className="text-xs font-black uppercase text-indigo-400 tracking-wider">
                      Blackboard Focus View
                    </h3>
                    <p className="text-[11px] text-slate-300 font-bold truncate max-w-[220px]">
                      {topic || title}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* Font Size Adjuster */}
                  <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5">
                    <button
                      onClick={() => setFontSizeMultiplier(prev => Math.max(0.85, prev - 0.15))}
                      className="px-2 py-1 text-[10px] font-bold text-slate-400 hover:text-white"
                      title="Decrease Blackboard Font Size"
                    >
                      A-
                    </button>
                    <button
                      onClick={() => setFontSizeMultiplier(prev => Math.min(1.6, prev + 0.15))}
                      className="px-2 py-1 text-[10px] font-bold text-slate-400 hover:text-white"
                      title="Increase Blackboard Font Size"
                    >
                      A+
                    </button>
                  </div>

                  {/* Play / Pause Lecture Button */}
                  <button
                    onClick={() => {
                      if (isLectureActive && !isLecturePaused) {
                        onPauseLecture?.();
                      } else {
                        onStartLecture?.();
                      }
                      triggerHapticFeedback(12);
                    }}
                    className={cn(
                      "p-2 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer",
                      isLectureActive && !isLecturePaused
                        ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                        : "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                    )}
                    title={isLectureActive && !isLecturePaused ? "Pause Lecture Audio & Typing" : "Play / Resume Synchronized Lecture"}
                  >
                    {isLectureActive && !isLecturePaused ? <Pause size={13} className="fill-amber-300" /> : <Play size={13} className="fill-white" />}
                  </button>

                  <button
                    onClick={() => setIsBlackboardSheetOpen(false)}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>

              {/* Sheet Body: Blackboard Notes Content */}
              <div
                className="flex-1 overflow-y-auto py-3 space-y-2 text-slate-200"
                style={{ fontSize: `${fontSizeMultiplier * 0.875}rem` }}
              >
                {boardContent ? (
                  <div className="prose prose-invert max-w-none text-xs leading-relaxed font-sans whitespace-pre-wrap">
                    {boardContent}
                  </div>
                ) : (
                  <div className="py-8 text-center text-slate-500 text-xs">
                    <p>No active blackboard notes loaded yet.</p>
                    <p className="text-[10px] text-slate-600 mt-1">Select a lecture topic or ask the 3D Tutor to begin.</p>
                  </div>
                )}
              </div>

              {/* Sheet Footer: Camera Presets Quick Switch */}
              <div className="pt-2.5 border-t border-slate-800 shrink-0 flex items-center justify-start gap-1.5 overflow-x-auto no-scrollbar">
                <button
                  onClick={() => handleCameraChange('front_row')}
                  className={cn(
                    "px-2.5 py-1.5 rounded-xl text-[10px] font-bold shrink-0 transition-all cursor-pointer",
                    activeCamera === 'front_row' ? "bg-indigo-600 text-white shadow" : "bg-slate-900 text-slate-400"
                  )}
                >
                  Front
                </button>
                <button
                  onClick={() => handleCameraChange('board_focus')}
                  className={cn(
                    "px-2.5 py-1.5 rounded-xl text-[10px] font-bold shrink-0 transition-all cursor-pointer",
                    activeCamera === 'board_focus' ? "bg-indigo-600 text-white shadow" : "bg-slate-900 text-slate-400"
                  )}
                >
                  Board
                </button>
                <button
                  onClick={() => handleCameraChange('lab_bench')}
                  className={cn(
                    "px-2.5 py-1.5 rounded-xl text-[10px] font-bold shrink-0 transition-all cursor-pointer",
                    activeCamera === 'lab_bench' ? "bg-indigo-600 text-white shadow" : "bg-slate-900 text-slate-400"
                  )}
                >
                  Lab
                </button>
                <button
                  onClick={() => handleCameraChange('overhead')}
                  className={cn(
                    "px-2.5 py-1.5 rounded-xl text-[10px] font-bold shrink-0 transition-all cursor-pointer",
                    activeCamera === 'overhead' ? "bg-indigo-600 text-white shadow" : "bg-slate-900 text-slate-400"
                  )}
                >
                  Overhead
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* TOUCH-FIRST FLOATING ZOOM & CAMERA HUD (Right Side Dock) */}
        {touchFirstMode && (
          <div className="absolute right-2 top-1/2 -translate-y-1/2 z-30 flex flex-col gap-1.5 pointer-events-auto">
            {/* Zoom In */}
            <button
              onClick={zoomIn}
              className="p-2.5 rounded-2xl bg-slate-950/90 border border-slate-800/90 text-slate-300 hover:text-white shadow-xl backdrop-blur-xl active:scale-95 transition-all flex items-center justify-center cursor-pointer"
              title="Zoom In (Pinch In)"
            >
              <ZoomIn size={16} />
            </button>

            {/* Zoom Out */}
            <button
              onClick={zoomOut}
              className="p-2.5 rounded-2xl bg-slate-950/90 border border-slate-800/90 text-slate-300 hover:text-white shadow-xl backdrop-blur-xl active:scale-95 transition-all flex items-center justify-center cursor-pointer"
              title="Zoom Out (Pinch Out)"
            >
              <ZoomOut size={16} />
            </button>

            {/* Reset Zoom */}
            {scale !== 1 && (
              <button
                onClick={resetZoom}
                className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 shadow-xl backdrop-blur-xl active:scale-95 transition-all flex items-center justify-center cursor-pointer animate-in fade-in"
                title="Reset Zoom & Pan"
              >
                <RotateCcw size={14} />
              </button>
            )}

            {/* Focus Blackboard Quick Button */}
            <button
              onClick={() => {
                handleCameraChange('board_focus');
                setIsBlackboardSheetOpen(true);
              }}
              className="p-2.5 rounded-2xl bg-indigo-600/90 hover:bg-indigo-500 border border-indigo-400/40 text-white shadow-xl backdrop-blur-xl active:scale-95 transition-all flex items-center justify-center cursor-pointer mt-1"
              title="Focus Smartboard & Blackboard Notes"
            >
              <BookOpen size={16} />
            </button>
          </div>
        )}
      </div>
    </MobileOptimizationContext.Provider>
  );
};
