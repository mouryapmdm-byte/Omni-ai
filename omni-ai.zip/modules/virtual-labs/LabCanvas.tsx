export * from '../../src/modules/virtual-labs/LabCanvas';
import { LabCanvas } from '../../src/modules/virtual-labs/LabCanvas';
export default LabCanvas;
