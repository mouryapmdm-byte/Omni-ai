import React, { useState, useRef, useEffect, useMemo, useImperativeHandle, forwardRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Brain, Zap, Info, AlertTriangle, ExternalLink, RefreshCw, CheckCircle2, ShieldAlert, FastForward, Bookmark, FileText, Search, Plus, Trash2, Clock, Sliders, X, Maximize2, Minimize2, MoreVertical, MoreHorizontal, HardDrive, Wifi, WifiOff, Keyboard } from 'lucide-react';
import { cn, downloadFileFromUrl, formatDuration } from '@/src/lib/utils';
import { preProcessVideoSource, getPlaybackDiagnostics, PlaybackDiagnostic } from '@/src/lib/videoHealth';
import { useMediaErrorMonitor } from '@/src/lib/mediaErrorMonitor';
import { MediaRecoveryPanel } from './MediaRecoveryPanel';
import { fetchWithOfflineLectureCache, cacheLectureMetadata, getCachedVideoFragment } from '@/src/lib/lectureCache';
import { useAdaptiveBitrate } from '@/src/lib/adaptiveBitrate';

export interface ChapterMarker {
  id: string;
  timestamp: number;
  title: string;
}

interface VideoEvent {
  timestamp: number;
  event: string;
}

export interface VideoPlayerHandle {
  play: () => Promise<void> | void;
  pause: () => void;
  togglePlay: () => void;
  seekTo: (time: number) => void;
  seekBy: (seconds: number) => void;
  setPlaybackSpeed: (speed: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  getVideoElement: () => HTMLVideoElement | null;
  getCurrentTime: () => number;
  getDuration: () => number;
  isPaused: () => boolean;
}

let activeVideoPlayerInstance: VideoPlayerHandle | null = null;

export const setActiveVideoPlayerInstance = (handle: VideoPlayerHandle | null) => {
  activeVideoPlayerInstance = handle;
};

export const getActiveVideoPlayerInstance = (): VideoPlayerHandle | null => {
  return activeVideoPlayerInstance;
};

export interface VideoWithOverlayProps {
  src: string;
  events?: VideoEvent[];
  chapters?: ChapterMarker[];
  className?: string;
  initialTimestamp?: number;
  isPlaying?: boolean;
  onBookmarkCreated?: (timestamp: number, title: string) => void;
  onTimeUpdate?: (currentTime: number) => void;
}

export const VideoWithOverlay = forwardRef<VideoPlayerHandle, VideoWithOverlayProps>(({ 
  src, 
  events = [], 
  chapters = [], 
  className,
  initialTimestamp,
  isPlaying,
  onBookmarkCreated,
  onTimeUpdate
}, ref) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoSrc, setVideoSrc] = useState(src);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentEvent, setCurrentEvent] = useState<string | null>(null);

  // Advanced Interactive Features State
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [activeOverlayModal, setActiveOverlayModal] = useState<'none' | 'speed' | 'search' | 'notes' | 'bookmarks' | 'shortcuts'>('none');
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [bookmarks, setBookmarks] = useState<{ id: string; timestamp: number; title: string }[]>([]);
  const [syncedNotes, setSyncedNotes] = useState<{ id: string; timestamp: number; text: string; createdAt: Date }[]>([]);
  const [noteInput, setNoteInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const handleSetSpeed = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  };

  const playerHandle: VideoPlayerHandle = useMemo(() => ({
    play: () => {
      if (videoRef.current) return videoRef.current.play().catch(() => {});
    },
    pause: () => {
      if (videoRef.current) videoRef.current.pause();
    },
    togglePlay: () => {
      if (videoRef.current) {
        if (videoRef.current.paused) {
          videoRef.current.play().catch(() => {});
        } else {
          videoRef.current.pause();
        }
      }
    },
    seekTo: (time: number) => {
      if (videoRef.current) {
        const dur = videoRef.current.duration || 0;
        videoRef.current.currentTime = Math.max(0, Math.min(dur > 0 ? dur : Infinity, time));
      }
    },
    seekBy: (seconds: number) => {
      if (videoRef.current) {
        const cur = videoRef.current.currentTime;
        const dur = videoRef.current.duration || 0;
        videoRef.current.currentTime = Math.max(0, Math.min(dur > 0 ? dur : Infinity, cur + seconds));
      }
    },
    setPlaybackSpeed: (speed: number) => {
      handleSetSpeed(speed);
    },
    setVolume: (volume: number) => {
      if (videoRef.current) {
        const vol = Math.max(0, Math.min(1, volume));
        videoRef.current.volume = vol;
        if (vol > 0) videoRef.current.muted = false;
      }
    },
    toggleMute: () => {
      if (videoRef.current) {
        videoRef.current.muted = !videoRef.current.muted;
      }
    },
    getVideoElement: () => videoRef.current,
    getCurrentTime: () => videoRef.current?.currentTime || 0,
    getDuration: () => videoRef.current?.duration || 0,
    isPaused: () => videoRef.current ? videoRef.current.paused : true,
  }), [setPlaybackSpeed]);

  useImperativeHandle(ref, () => playerHandle, [playerHandle]);

  useEffect(() => {
    setActiveVideoPlayerInstance(playerHandle);
    return () => {
      if (getActiveVideoPlayerInstance() === playerHandle) {
        setActiveVideoPlayerInstance(null);
      }
    };
  }, [playerHandle]);

  // Auto-seek to initialTimestamp if provided upon metadata loaded or initialTimestamp change
  useEffect(() => {
    if (videoRef.current && initialTimestamp !== undefined && initialTimestamp > 0) {
      videoRef.current.currentTime = initialTimestamp;
    }
  }, [initialTimestamp, videoSrc]);

  // Sync state-based play/pause trigger
  useEffect(() => {
    if (videoRef.current && isPlaying !== undefined) {
      if (isPlaying) {
        videoRef.current.play().catch(() => {});
      } else {
        videoRef.current.pause();
      }
    }
  }, [isPlaying]);

  const handleSeekTo = (time: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      videoRef.current.play().catch(() => {});
    }
  };

  const handleAddBookmark = () => {
    const title = prompt(`Enter bookmark title for timestamp [${formatDuration(currentTime)}]:`, `Key Moment @ ${formatDuration(currentTime)}`);
    if (title && title.trim()) {
      const trimmedTitle = title.trim();
      setBookmarks(prev => [{ id: `bm_${Date.now()}`, timestamp: currentTime, title: trimmedTitle }, ...prev]);
      onBookmarkCreated?.(currentTime, trimmedTitle);
    }
  };

  const handleSyncNote = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!noteInput.trim()) return;
    setSyncedNotes(prev => [{
      id: `note_${Date.now()}`,
      timestamp: currentTime,
      text: noteInput.trim(),
      createdAt: new Date()
    }, ...prev]);
    setNoteInput('');
  };

  // Transcript items generated from events or chapters
  const transcriptList = useMemo(() => {
    if (events && events.length > 0) {
      return events.map(e => ({
        timestamp: e.timestamp,
        text: e.event.replace(/^AI Tutor wrote:\s*/, '')
      }));
    }
    if (chapters && chapters.length > 0) {
      return chapters.map(c => ({
        timestamp: c.timestamp,
        text: c.title
      }));
    }
    return [
      { timestamp: 0, text: "Lesson Introduction and Core Concept Overview" },
      { timestamp: 15, text: "Step-by-Step Visualization and Key Properties" },
      { timestamp: 45, text: "Worked Example Derivation and Practical Application" },
      { timestamp: 90, text: "Summary of Key Takeaways and Problem Verification" }
    ];
  }, [events, chapters]);

  const filteredTranscript = useMemo(() => {
    if (!searchQuery.trim()) return transcriptList;
    const q = searchQuery.toLowerCase();
    return transcriptList.filter(t => t.text.toLowerCase().includes(q) || formatDuration(t.timestamp).includes(q));
  }, [transcriptList, searchQuery]);

  // Playback Health Checker State
  const monitor = useMediaErrorMonitor({
    componentId: 'VideoWithOverlayPlayer',
    initialSrc: src,
    fallbackSrc: "/api/proxy-video",
    onSourceChange: (newSrc) => setVideoSrc(newSrc)
  });

  const abr = useAdaptiveBitrate({
    videoElementRef: videoRef,
    onQualityChange: (quality, streamUrl) => {
      setVideoSrc(streamUrl);
    }
  });

  const diagnosticReport = monitor.diagnosticReport;
  const playbackError = monitor.playbackError;
  const conversionNote = monitor.recoveryNotice;
  const setConversionNote = monitor.setRecoveryNotice;

  const [isProcessingSource, setIsProcessingSource] = useState(false);
  const [isOffline, setIsOffline] = useState<boolean>(typeof navigator !== 'undefined' ? !navigator.onLine : false);
  const [isCachedLocally, setIsCachedLocally] = useState<boolean>(false);
  const [cacheSizeText, setCacheSizeText] = useState<string | null>(null);

  // Monitor network online/offline state
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

    // No global window listener. Use local onKeyDown on the container.

  // Pre-process video source on mount or src change + IndexedDB Local Caching
  useEffect(() => {
    let isMounted = true;
    const process = async () => {
      setIsProcessingSource(true);
      monitor.resetMonitor();

      // Check if fragment is in IndexedDB local cache first
      const cachedFragment = await getCachedVideoFragment(src);
      if (cachedFragment) {
        if (isMounted) {
          setIsCachedLocally(true);
          const megabytes = (cachedFragment.size / (1024 * 1024)).toFixed(1);
          setCacheSizeText(`${megabytes} MB`);
        }
      }

      const result = await preProcessVideoSource(src);
      if (isMounted) {
        setVideoSrc(result.playableUrl);
        if (result.isConverted) {
          setConversionNote("Stream optimized: Pre-processed video container into standard H.264 MP4 blob format.");
        }
        setIsProcessingSource(false);
      }

      // Cache metadata into IndexedDB
      await cacheLectureMetadata(`video_metadata_${src}`, {
        events,
        chapters,
        cachedAt: Date.now()
      });

      // Background video fragment caching into IndexedDB
      try {
        const cachedRes = await fetchWithOfflineLectureCache(result.playableUrl || src);
        if (isMounted && cachedRes) {
          setIsCachedLocally(true);
          if (cachedRes.isFromCache) {
            setVideoSrc(cachedRes.url);
            setConversionNote("IndexedDB Offline Mode: Loaded video fragment directly from local storage.");
          }
        }
      } catch (err) {
        console.warn("[VideoWithOverlay] Background video caching note:", err);
      }
    };

    process();

    return () => {
      isMounted = false;
    };
  }, [src]);

  const handleVideoError = () => {
    const errorObj = videoRef.current?.error || null;
    console.info("VideoWithOverlay playback recovery trigger:", errorObj, "URL:", videoSrc);
    
    monitor.triggerRecovery(
      videoSrc,
      errorObj?.code || 4,
      errorObj?.message || 'Format error'
    );
  };

  useEffect(() => {
    if (!events || events.length === 0 || duration === 0) {
      setCurrentEvent(null);
      return;
    }

    const segmentDuration = duration / events.length;
    const index = Math.floor(currentTime / segmentDuration);
    const safeIndex = Math.min(index, events.length - 1);
    
    if (events[safeIndex]) {
      let displayEvent = events[safeIndex].event;
      if (displayEvent.startsWith('AI Tutor wrote:')) {
        displayEvent = displayEvent.replace('AI Tutor wrote:', '').trim();
      }
      setCurrentEvent(displayEvent);
    }
  }, [currentTime, duration, events]);

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const cur = videoRef.current.currentTime;
      setCurrentTime(cur);
      onTimeUpdate?.(cur);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      monitor.handleSuccessLoad();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    const activeEl = document.activeElement;
    const isInput = activeEl && (
      activeEl.tagName === 'INPUT' || 
      activeEl.tagName === 'TEXTAREA' || 
      activeEl.tagName === 'SELECT' ||
      (activeEl as HTMLElement).isContentEditable
    );
    if (isInput) return;

    if (!videoRef.current) return;

    if (e.key === ' ' || e.key === 'k' || e.key === 'K') {
      e.preventDefault();
      playerHandle.togglePlay();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      playerHandle.seekBy(-5);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      playerHandle.seekBy(5);
    } else if (e.key === 'j' || e.key === 'J') {
      e.preventDefault();
      playerHandle.seekBy(-10);
    } else if (e.key === 'l' || e.key === 'L') {
      e.preventDefault();
      playerHandle.seekBy(10);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      playerHandle.setVolume((videoRef.current.volume || 1) + 0.1);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      playerHandle.setVolume((videoRef.current.volume || 1) - 0.1);
    } else if (e.key === 'm' || e.key === 'M') {
      e.preventDefault();
      playerHandle.toggleMute();
    } else if (e.key === 'f' || e.key === 'F') {
      e.preventDefault();
      if (containerRef.current) {
        if (!document.fullscreenElement) {
          containerRef.current.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
      }
    } else if (/^[0-9]$/.test(e.key)) {
      e.preventDefault();
      const percent = parseInt(e.key, 10) / 10;
      const dur = videoRef.current.duration || 0;
      if (dur > 0) {
        playerHandle.seekTo(dur * percent);
      }
    }
  };

  return (
    <div 
      ref={containerRef}
      className={cn("relative rounded-2xl overflow-hidden bg-black aspect-video focus:outline-none focus:ring-2 focus:ring-indigo-500/80 transition-all", className)}
      tabIndex={0}
      onFocus={() => setActiveVideoPlayerInstance(playerHandle)}
      onKeyDown={handleKeyDown}
    >
      <video
        key={videoSrc}
        ref={videoRef}
        src={videoSrc}
        controls
        playsInline
        preload="auto"
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onError={handleVideoError}
        className="w-full h-full object-contain"
      />

      {/* Pre-processing status toast */}
      {conversionNote && (
        <div className="absolute top-14 right-2 bg-slate-900/90 text-emerald-400 text-[11px] font-bold px-3 py-1.5 rounded-xl border border-emerald-500/30 backdrop-blur-md shadow-lg flex items-center gap-1.5 z-20 animate-in fade-in">
          <CheckCircle2 size={13} />
          <span>{conversionNote}</span>
        </div>
      )}

      {/* IndexedDB Offline Cache & Network Status Badge */}
      <div className="absolute top-2 left-2 flex items-center gap-1.5 z-20 pointer-events-none">
        {isOffline ? (
          <div className="bg-rose-950/90 text-rose-300 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-xl border border-rose-500/40 backdrop-blur-md shadow-lg flex items-center gap-1.5 animate-pulse">
            <WifiOff size={12} />
            <span>Offline (IndexedDB Protection Active)</span>
          </div>
        ) : (
          <div className="bg-slate-900/80 text-cyan-300 text-[10px] font-bold px-2.5 py-1 rounded-xl border border-cyan-500/30 backdrop-blur-md shadow-lg flex items-center gap-1.5">
            <Wifi size={12} className="text-emerald-400" />
            <span>Online</span>
          </div>
        )}

        {isCachedLocally && (
          <div className="bg-indigo-950/90 text-indigo-300 text-[10px] font-bold px-2.5 py-1 rounded-xl border border-indigo-500/40 backdrop-blur-md shadow-lg flex items-center gap-1.5">
            <HardDrive size={12} className="text-indigo-400" />
            <span>IndexedDB Fragment Cached {cacheSizeText ? `(${cacheSizeText})` : ''}</span>
          </div>
        )}
      </div>

      {/* Top-Right Interactive Overlay Action Toolbar */}
      <div className="absolute top-2 right-2 flex flex-wrap items-center justify-end gap-1.5 max-w-[70%] md:max-w-[85%] z-20">
        {/* Adaptive Bitrate Quality Controller */}
        <div className="relative group">
          <button
            type="button"
            className="px-2.5 py-1.5 rounded-xl text-[10px] font-extrabold bg-slate-900/80 text-cyan-300 border border-cyan-500/30 hover:bg-slate-800 hover:text-cyan-200 backdrop-blur-md transition-all shadow-lg flex items-center gap-1.5 cursor-pointer"
          >
            <Sliders size={12} className="text-cyan-400" />
            <span>{abr.selectedQuality === 'auto' ? `Auto (${abr.activeQuality.toUpperCase()})` : abr.activeQuality.toUpperCase()}</span>
          </button>
          
          {/* Dropdown list on Hover */}
          <div className="absolute right-0 top-full mt-1.5 bg-slate-950/95 border border-slate-800 rounded-xl p-1.5 shadow-2xl flex flex-col gap-1 z-30 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none group-hover:pointer-events-auto min-w-[120px]">
            {([
              { key: 'auto', label: 'Auto Stream' },
              { key: 'low', label: '360p (Low)' },
              { key: 'medium', label: '720p (Med)' },
              { key: 'high', label: '1080p (High)' }
            ] as const).map(q => (
              <button
                key={q.key}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  abr.changeQuality(q.key);
                }}
                className={cn(
                  "w-full text-left px-2.5 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all cursor-pointer",
                  abr.selectedQuality === q.key
                    ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/20"
                    : "text-slate-400 hover:text-white hover:bg-slate-900"
                )}
              >
                {q.label}
              </button>
            ))}
            <div className="border-t border-slate-900 pt-1 mt-1 text-[8px] font-mono text-slate-500 text-center">
              {abr.currentBitrate}kbps • {abr.bufferLevel}s buf
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setActiveOverlayModal(prev => prev === 'shortcuts' ? 'none' : 'shortcuts');
          }}
          className={cn(
            "px-2.5 py-1 rounded-xl text-[10px] font-extrabold backdrop-blur-md transition-all cursor-pointer shadow-lg flex items-center gap-1.5 border",
            activeOverlayModal === 'shortcuts'
              ? "bg-amber-400 text-slate-950 border-amber-300 ring-2 ring-amber-400 shadow-amber-500/20"
              : "bg-slate-900/80 text-amber-300 border-amber-500/30 hover:bg-slate-800 hover:text-amber-200"
          )}
          title="Keyboard Hotkey Shortcuts Guide"
        >
          <Keyboard size={12} />
          <span className="hidden sm:inline">Shortcuts ⌨️</span>
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setActiveOverlayModal(prev => prev === 'search' ? 'none' : 'search');
          }}
          className={cn(
            "p-1.5 rounded-xl text-[10px] font-bold backdrop-blur-md transition-all cursor-pointer shadow-lg border",
            activeOverlayModal === 'search'
              ? "bg-rose-600 text-white border-rose-400"
              : "bg-slate-900/80 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white"
          )}
          title="Search Transcript Keywords"
        >
          <Search size={13} />
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setActiveOverlayModal(prev => prev === 'notes' ? 'none' : 'notes');
          }}
          className={cn(
            "p-1.5 rounded-xl text-[10px] font-bold backdrop-blur-md transition-all cursor-pointer shadow-lg border relative",
            activeOverlayModal === 'notes'
              ? "bg-indigo-600 text-white border-indigo-400"
              : "bg-slate-900/80 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white"
          )}
          title="Sync Notes to Timestamp"
        >
          <FileText size={13} />
          {syncedNotes.length > 0 && (
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-indigo-500 text-white rounded-full text-[8px] font-black flex items-center justify-center">
              {syncedNotes.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setActiveOverlayModal(prev => prev === 'bookmarks' ? 'none' : 'bookmarks');
          }}
          className={cn(
            "p-1.5 rounded-xl text-[10px] font-bold backdrop-blur-md transition-all cursor-pointer shadow-lg border relative",
            activeOverlayModal === 'bookmarks'
              ? "bg-amber-600 text-white border-amber-400"
              : "bg-slate-900/80 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white"
          )}
          title="Manage Bookmarks"
        >
          <Bookmark size={13} />
          {bookmarks.length > 0 && (
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 text-slate-950 rounded-full text-[8px] font-black flex items-center justify-center">
              {bookmarks.length}
            </span>
          )}
        </button>
      </div>

      {/* Playback Health Checker Diagnostic Overlay */}
      <AnimatePresence>
        {diagnosticReport && (
          <MediaRecoveryPanel
            diagnosticReport={diagnosticReport}
            playbackError={playbackError}
            currentStrategy={monitor.strategy}
            retryCount={monitor.retryCount}
            isRetrying={monitor.isRetrying}
            src={videoSrc}
            isBlob={Boolean(videoSrc && videoSrc.startsWith('blob:'))}
            onSelectStrategy={monitor.forceStrategy}
            onDismiss={monitor.resetMonitor}
          />
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {currentEvent && !diagnosticReport && (
          <motion.div
            key={currentEvent}
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="absolute top-4 left-4 right-4 pointer-events-none"
          >
            <div className="bg-slate-900/80 backdrop-blur-md border border-white/10 px-4 py-3 rounded-xl shadow-2xl flex items-start gap-3">
              <div className="bg-red-500/20 p-2 rounded-lg mt-0.5">
                <Sparkles size={16} className="text-red-500 animate-pulse" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Active Concept</span>
                  <div className="h-1 flex-1 bg-white/5 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-red-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${(currentTime / duration) * 100}%` }}
                    />
                  </div>
                </div>
                <h4 className="text-white text-sm font-bold line-clamp-2">{currentEvent}</h4>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dynamic Chapter Badges */}
      {chapters && chapters.length > 0 && (
        <div className="absolute bottom-12 left-4 right-4 flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none pointer-events-auto z-20">
          {chapters.map((chap) => {
            const isActive = Math.abs(currentTime - chap.timestamp) < 5;
            return (
              <button
                key={chap.id}
                type="button"
                onClick={() => {
                  if (videoRef.current) {
                    videoRef.current.currentTime = chap.timestamp;
                  }
                }}
                className={cn(
                  "px-2.5 py-1 rounded-lg text-[10px] font-bold backdrop-blur-md transition-all whitespace-nowrap cursor-pointer shadow-lg flex items-center gap-1 border",
                  isActive
                    ? "bg-rose-600 text-white border-rose-400 scale-105"
                    : "bg-slate-900/80 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white"
                )}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                <span>{chap.title}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Interactive Tools Modal Overlay Drawer */}
      <AnimatePresence>
        {activeOverlayModal !== 'none' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="absolute top-14 right-3 bottom-14 w-72 bg-slate-950/95 border border-slate-800 rounded-2xl p-3 backdrop-blur-xl z-30 flex flex-col justify-between shadow-2xl pointer-events-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-white">
                {activeOverlayModal === 'shortcuts' && <Keyboard size={14} className="text-amber-400" />}
                {activeOverlayModal === 'search' && <Search size={14} className="text-rose-500" />}
                {activeOverlayModal === 'notes' && <FileText size={14} className="text-indigo-400" />}
                {activeOverlayModal === 'bookmarks' && <Bookmark size={14} className="text-amber-400" />}
                <span>
                  {activeOverlayModal === 'shortcuts' && 'Keyboard Shortcuts ⌨️'}
                  {activeOverlayModal === 'search' && 'Search Transcript'}
                  {activeOverlayModal === 'notes' && 'Sync Notes to Timestamp'}
                  {activeOverlayModal === 'bookmarks' && 'Manual Bookmarks'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveOverlayModal('none')}
                className="text-slate-500 hover:text-white p-1 cursor-pointer"
              >
                <X size={14} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto py-2 space-y-2">
              {/* Shortcuts Modal */}
              {activeOverlayModal === 'shortcuts' && (
                <div className="space-y-2 text-slate-200">
                  <div className="text-[10px] text-amber-400 font-black uppercase tracking-wider bg-amber-500/10 p-2 rounded-xl border border-amber-500/20">
                    ⚡ Hotkey Controls
                  </div>
                  <div className="space-y-1 text-xs">
                    {[
                      { keys: ['Space', 'K'], label: 'Play / Pause video' },
                      { keys: ['←', '→'], label: 'Rewind / Forward 5s' },
                      { keys: ['J', 'L'], label: 'Rewind / Forward 10s' },
                      { keys: ['↑', '↓'], label: 'Volume Up / Down' },
                      { keys: ['M'], label: 'Mute / Unmute' },
                      { keys: ['F'], label: 'Toggle Fullscreen' },
                      { keys: ['0 - 9'], label: 'Jump to 0% – 90%' },
                    ].map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                        <div className="flex items-center gap-1">
                          {item.keys.map((k, i) => (
                            <React.Fragment key={i}>
                              <kbd className="px-1.5 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-amber-300 font-mono text-[10px] font-black shadow-sm">
                                {k}
                              </kbd>
                              {i < item.keys.length - 1 && <span className="text-[9px] text-slate-500 font-bold">/</span>}
                            </React.Fragment>
                          ))}
                        </div>
                        <span className="text-[11px] font-medium text-slate-300">{item.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {/* Search Modal */}
              {activeOverlayModal === 'search' && (
                <div className="space-y-2">
                  <input
                    type="text"
                    placeholder="Search keywords or MM:SS..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs font-medium text-white placeholder-slate-500 outline-none focus:border-rose-500"
                  />
                  <div className="space-y-1.5">
                    {filteredTranscript.map((t, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleSeekTo(t.timestamp)}
                        className="w-full text-left p-2 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 transition-all cursor-pointer flex items-start gap-2"
                      >
                        <span className="px-1.5 py-0.5 bg-rose-600/20 text-rose-400 border border-rose-500/30 rounded font-mono text-[9px] font-black shrink-0">
                          {formatDuration(t.timestamp)}
                        </span>
                        <span className="font-medium line-clamp-2 leading-tight">
                          {t.text}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Sync Notes Modal */}
              {activeOverlayModal === 'notes' && (
                <div className="space-y-2">
                  <form onSubmit={handleSyncNote} className="space-y-2">
                    <textarea
                      rows={2}
                      placeholder="Type note to link to active timestamp..."
                      value={noteInput}
                      onChange={(e) => setNoteInput(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2 text-xs font-medium text-white placeholder-slate-500 outline-none focus:border-indigo-500 resize-none"
                    />
                    <button
                      type="submit"
                      disabled={!noteInput.trim()}
                      className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl cursor-pointer transition flex items-center justify-center gap-1"
                    >
                      <FileText size={12} /> Sync Note @ {formatDuration(currentTime)}
                    </button>
                  </form>
                  <div className="space-y-1.5 pt-2 border-t border-slate-800">
                    {syncedNotes.map(n => (
                      <div key={n.id} className="p-2 rounded-xl bg-slate-900 border border-slate-800 space-y-1 text-left">
                        <div className="flex items-center justify-between">
                          <button
                            type="button"
                            onClick={() => handleSeekTo(n.timestamp)}
                            className="px-1.5 py-0.5 bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 rounded font-mono text-[9px] font-black cursor-pointer"
                          >
                            Jump {formatDuration(n.timestamp)}
                          </button>
                          <button
                            type="button"
                            onClick={() => setSyncedNotes(prev => prev.filter(x => x.id !== n.id))}
                            className="text-slate-600 hover:text-rose-400 p-0.5 cursor-pointer"
                          >
                            <Trash2 size={11} />
                          </button>
                        </div>
                        <p className="text-xs text-slate-300 font-medium leading-normal">{n.text}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Bookmarks Modal */}
              {activeOverlayModal === 'bookmarks' && (
                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={handleAddBookmark}
                    className="w-full py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-xl cursor-pointer transition flex items-center justify-center gap-1"
                  >
                    <Plus size={12} /> Bookmark @ {formatDuration(currentTime)}
                  </button>
                  <div className="space-y-1.5 pt-2 border-t border-slate-800">
                    {bookmarks.map(bm => (
                      <div key={bm.id} className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => handleSeekTo(bm.timestamp)}
                          className="px-1.5 py-0.5 bg-amber-600/20 text-amber-300 border border-amber-500/30 rounded font-mono text-[9px] font-black cursor-pointer shrink-0"
                        >
                          {formatDuration(bm.timestamp)}
                        </button>
                        <span className="text-xs text-slate-300 font-bold truncate flex-1 text-left">{bm.title}</span>
                        <button
                          type="button"
                          onClick={() => setBookmarks(prev => prev.filter(x => x.id !== bm.id))}
                          className="text-slate-600 hover:text-rose-400 p-0.5 cursor-pointer shrink-0"
                        >
                          <Trash2 size={11} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Real-time scanning effect */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
         <motion.div 
           className="h-full w-1 bg-red-500 blur-sm shadow-[0_0_15px_rgba(239,68,68,0.8)]"
           animate={{ 
             x: ["0%", "100%"]
           }}
           transition={{
             duration: 3,
             repeat: Infinity,
             ease: "linear"
           }}
         />
      </div>
    </div>
  );
});
