import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { 
  Calculator, Table, HelpCircle, BookOpen, RefreshCw, Copy, Check, 
  Info, Activity, Hash, ArrowRight, Star, Minimize2, Maximize2 
} from 'lucide-react';

interface MathematicalTablesProps {
  theme: 'light' | 'dark';
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const MathematicalTables: React.FC<MathematicalTablesProps> = ({
  theme,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'calc' | 'logTable' | 'antiTable' | 'chemistryApplications'>('calc');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // --- Dynamic Calculator State ---
  const [logInput, setLogInput] = useState<string>("2.5");
  const [antiLogInput, setAntiLogInput] = useState<string>("0.3979");

  // --- Chemistry pH & pKa State ---
  const [hConcentration, setHConcentration] = useState<string>("1.0e-3");
  const [phInput, setPhInput] = useState<string>("3.0");
  const [acidConc, setAcidConc] = useState<string>("0.1");
  const [conjugateBaseConc, setConjugateBaseConc] = useState<string>("0.2");
  const [pkaInput, setPkaInput] = useState<string>("4.76");

  // --- 4-Digit Log Table Interactive State ---
  const [logRowHighlight, setLogRowHighlight] = useState<number>(10);
  const [logColHighlight, setLogColHighlight] = useState<number>(0);
  const [logMeanHighlight, setLogMeanHighlight] = useState<number>(0);

  // --- 4-Digit Antilog Table Interactive State ---
  const [antiRowHighlight, setAntiRowHighlight] = useState<number>(0); // e.g. .00 to .99 representing .00 to .99
  const [antiColHighlight, setAntiColHighlight] = useState<number>(0);
  const [antiMeanHighlight, setAntiMeanHighlight] = useState<number>(0);

  // General Log & Antilog values
  const computedLog = useMemo(() => {
    const val = parseFloat(logInput);
    if (isNaN(val) || val <= 0) return { error: "Input must be a positive number." };
    const result = Math.log10(val);
    const characteristic = Math.floor(result);
    const mantissa = result - characteristic;
    return {
      full: result.toFixed(6),
      characteristic,
      mantissa: mantissa.toFixed(6)
    };
  }, [logInput]);

  const computedAntiLog = useMemo(() => {
    const val = parseFloat(antiLogInput);
    if (isNaN(val)) return { error: "Please enter a valid real number." };
    const result = Math.pow(10, val);
    return {
      full: result.toFixed(6),
      scientific: result.toExponential(4)
    };
  }, [antiLogInput]);

  // --- Chemistry Solvers ---
  const computedPhResult = useMemo(() => {
    const val = parseFloat(hConcentration);
    if (isNaN(val) || val <= 0) return "Invalid [H⁺]";
    const ph = -Math.log10(val);
    return ph.toFixed(2);
  }, [hConcentration]);

  const computedHResult = useMemo(() => {
    const val = parseFloat(phInput);
    if (isNaN(val)) return "Invalid pH";
    const h = Math.pow(10, -val);
    return h.toExponential(4) + " M";
  }, [phInput]);

  const computedBufferPh = useMemo(() => {
    const acid = parseFloat(acidConc);
    const base = parseFloat(conjugateBaseConc);
    const pka = parseFloat(pkaInput);
    if (isNaN(acid) || isNaN(base) || isNaN(pka) || acid <= 0 || base <= 0) {
      return "Invalid buffer inputs";
    }
    // Henderson-Hasselbalch equation: pH = pKa + log10([A-]/[HA])
    const ratio = base / acid;
    const logRatio = Math.log10(ratio);
    const ph = pka + logRatio;
    return {
      ph: ph.toFixed(3),
      logRatio: logRatio.toFixed(4)
    };
  }, [acidConc, conjugateBaseConc, pkaInput]);

  // Handle Copy
  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    showNotification?.(`Copied ${label} to clipboard!`, 'success');
    setTimeout(() => setCopiedText(null), 1500);
  };

  // Common logs used in chemistry (quick cards)
  const commonLogs = [
    { num: "1", log: "0.0000", note: "log 1 = 0 (neutral point indicator)" },
    { num: "2", log: "0.3010", note: "Doubling/halving concentration change of 0.3 pH units" },
    { num: "3", log: "0.4771", note: "Commonly used in buffer concentration ratios" },
    { num: "5", log: "0.6990", note: "Calculations of weak acids with Ka ≈ 10⁻⁵" },
    { num: "7", log: "0.8451", note: "Commonly seen in phosphate buffer systems" },
    { num: "10", log: "1.0000", note: "One full order of magnitude change (1.00 pH unit)" }
  ];

  // Helper to generate log table row mantissa
  // log10(row + col/10) - log10(row) approximation to 4-digits
  const getLogTableMantissa = (row: number, col: number) => {
    const value = row + col / 10;
    const logVal = Math.log10(value);
    // extract mantissa part (fractional part of log10)
    const mantissa = logVal - Math.floor(logVal);
    const fourDigit = Math.round(mantissa * 10000);
    return String(fourDigit).padStart(4, '0');
  };

  // Mean difference generation (approximate for demonstration table)
  const getLogMeanDifference = (row: number, meanCol: number) => {
    const v1 = row;
    const v2 = row + meanCol / 100;
    const diff = (Math.log10(v2) - Math.log10(v1)) * 10000;
    return Math.round(diff);
  };

  // Antilog Table Helpers (.00 to .99)
  const getAntiLogMantissaValue = (row: number, col: number) => {
    const exponent = row / 100 + col / 1000;
    const result = Math.pow(10, exponent);
    const digits = Math.round(result * 1000); // Usually represented as four significant figures
    return String(digits).padStart(4, '0');
  };

  const getAntiLogMeanDifference = (row: number, meanCol: number) => {
    const exp1 = row / 100;
    const exp2 = row / 100 + meanCol / 10000;
    const diff = (Math.pow(10, exp2) - Math.pow(10, exp1)) * 1000;
    return Math.max(1, Math.round(diff));
  };

  // Quick preset inputs for calculator
  const loadPresetLog = (val: string) => {
    setLogInput(val);
    showNotification?.(`Loaded logarithm input: ${val}`, 'info');
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col p-6 md:p-8 space-y-6 overflow-y-auto selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-800"
    )}>
      
      {/* Title Header banner */}
      <div className={cn(
        "p-6 rounded-3xl border flex flex-col lg:flex-row lg:items-center justify-between gap-6 shadow-md transition-all",
        theme === 'dark' 
          ? "bg-gradient-to-r from-slate-950/80 via-slate-900 to-indigo-950/50 border-slate-800" 
          : "bg-gradient-to-r from-white via-indigo-50/20 to-indigo-50/40 border-slate-200/80"
      )}>
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-violet-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 flex-shrink-0 animate-pulse">
            <Table size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                CHEMISTRY MATHEMATICS PORTAL
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Mathematical Tables & Logarithmic Tools
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Master rapid chemical calculations using interactive Logarithms and Antilogarithms. Perfect for solving pH equations, weak-acid buffers, Nernst potentials, and rate kinetics.
            </p>
          </div>
        </div>
      </div>

      {/* Tabs Menu navigation */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        {[
          { id: 'calc', label: 'Interactive Calculator', icon: Calculator },
          { id: 'logTable', label: '4-Digit Logarithm Table', icon: Table },
          { id: 'antiTable', label: '4-Digit Antilogarithm Table', icon: Table },
          { id: 'chemistryApplications', label: 'pH & Buffer Applications', icon: Activity }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition active:scale-95 cursor-pointer border",
                isActive
                  ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10"
                  : theme === 'dark'
                    ? "bg-slate-900/40 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700"
                    : "bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300"
              )}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Main Sandbox Workspace Panels */}
      <div className="grid grid-cols-1 gap-6">
        <AnimatePresence mode="wait">
          
          {/* Active Tab: CALCULATOR */}
          {activeTab === 'calc' && (
            <motion.div
              key="calc"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6"
            >
              {/* Left Column: Input Form fields */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Logarithm Solver Card */}
                <div className={cn(
                  "p-6 rounded-2xl border space-y-4 shadow-sm",
                  theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
                )}>
                  <div className="flex items-center gap-2 border-b border-dashed border-slate-200 dark:border-slate-800 pb-3">
                    <Hash size={16} className="text-indigo-500" />
                    <h3 className="text-sm font-black uppercase tracking-wider">Common Logarithm (Base 10)</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Input Value (x &gt; 0)
                      </label>
                      <input 
                        type="number"
                        min="0.000000001"
                        step="any"
                        value={logInput}
                        onChange={(e) => setLogInput(e.target.value)}
                        className={cn(
                          "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                      <p className="text-[10px] text-slate-400 mt-1">
                        Finds <code className="font-mono text-indigo-500">y = log₁₀(x)</code>
                      </p>
                    </div>

                    <div className={cn(
                      "p-4 rounded-xl border space-y-2 font-mono text-xs",
                      theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-indigo-50/20 border-slate-200"
                    )}>
                      {computedLog.error ? (
                        <div className="text-rose-500 font-bold">{computedLog.error}</div>
                      ) : (
                        <>
                          <div className="flex justify-between border-b pb-1 border-dashed border-slate-200 dark:border-slate-850">
                            <span className="text-slate-400">log₁₀({logInput}):</span>
                            <span className="font-extrabold text-indigo-500 flex items-center gap-1.5">
                              {computedLog.full}
                              <button 
                                onClick={() => handleCopy(computedLog.full || "", "Logarithm value")}
                                className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800"
                              >
                                {copiedText === computedLog.full ? <Check size={11} className="text-emerald-500" /> : <Copy size={11} />}
                              </button>
                            </span>
                          </div>
                          <div className="flex justify-between text-[11px]">
                            <span className="text-slate-400">Characteristic (integer):</span>
                            <span className="font-bold text-slate-700 dark:text-slate-300">{computedLog.characteristic}</span>
                          </div>
                          <div className="flex justify-between text-[11px]">
                            <span className="text-slate-400">Mantissa (fraction):</span>
                            <span className="font-bold text-slate-700 dark:text-slate-300">+{computedLog.mantissa}</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Logarithm quick presets */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Common Chemical Concentration Presets</span>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { label: "Acid Rain [H⁺] = 1.5e-5", val: "0.000015" },
                        { label: "Pure Water [H⁺] = 1.0e-7", val: "0.0000001" },
                        { label: "Stomach Acid [H⁺] = 1.0e-2", val: "0.01" },
                        { label: "Bleach [H⁺] = 1.0e-12", val: "0.000000000001" }
                      ].map((preset, idx) => (
                        <button
                          key={idx}
                          onClick={() => loadPresetLog(preset.val)}
                          className={cn(
                            "px-2.5 py-1 text-[10px] rounded-lg border font-bold transition active:scale-95 cursor-pointer",
                            theme === 'dark' 
                              ? "bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700" 
                              : "bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300"
                          )}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Antilogarithm Solver Card */}
                <div className={cn(
                  "p-6 rounded-2xl border space-y-4 shadow-sm",
                  theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
                )}>
                  <div className="flex items-center gap-2 border-b border-dashed border-slate-200 dark:border-slate-800 pb-3">
                    <Hash size={16} className="text-violet-500" />
                    <h3 className="text-sm font-black uppercase tracking-wider">Antilogarithm (10^x)</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Power / Exponent (x)
                      </label>
                      <input 
                        type="number"
                        step="any"
                        value={antiLogInput}
                        onChange={(e) => setAntiLogInput(e.target.value)}
                        className={cn(
                          "w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                      <p className="text-[10px] text-slate-400 mt-1">
                        Calculates <code className="font-mono text-violet-500">y = 10ˣ</code>
                      </p>
                    </div>

                    <div className={cn(
                      "p-4 rounded-xl border space-y-2 font-mono text-xs",
                      theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-indigo-50/20 border-slate-200"
                    )}>
                      {computedAntiLog.error ? (
                        <div className="text-rose-500 font-bold">{computedAntiLog.error}</div>
                      ) : (
                        <>
                          <div className="flex justify-between border-b pb-1 border-dashed border-slate-200 dark:border-slate-850">
                            <span className="text-slate-400">10^({antiLogInput}):</span>
                            <span className="font-extrabold text-violet-500 flex items-center gap-1.5">
                              {computedAntiLog.full}
                              <button 
                                onClick={() => handleCopy(computedAntiLog.full || "", "Antilogarithm value")}
                                className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800"
                              >
                                {copiedText === computedAntiLog.full ? <Check size={11} className="text-emerald-500" /> : <Copy size={11} />}
                              </button>
                            </span>
                          </div>
                          <div className="flex justify-between text-[11px]">
                            <span className="text-slate-400">Scientific Notation:</span>
                            <span className="font-bold text-slate-700 dark:text-slate-300">{computedAntiLog.scientific}</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>

              </div>

              {/* Right Column: Key Common Logs & Guidelines */}
              <div className="lg:col-span-5 space-y-6">
                
                {/* Handy Chemistry Logs Card */}
                <div className={cn(
                  "p-6 rounded-2xl border space-y-4 shadow-sm",
                  theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
                )}>
                  <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400">
                    <Star size={16} />
                    Common Log Estimates
                  </h3>
                  <p className="text-xs text-slate-400">
                    Memorizing these common base-10 log values allows for quick mental approximation of pH and equilibrium constants!
                  </p>

                  <div className="grid grid-cols-2 gap-2">
                    {commonLogs.map((item, idx) => (
                      <div
                        key={idx}
                        className={cn(
                          "p-3 rounded-xl border flex flex-col justify-between gap-1 transition-all hover:scale-[1.01]",
                          theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-slate-50 border-slate-150"
                        )}
                      >
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-mono font-bold">log₁₀({item.num})</span>
                          <span className="text-xs font-mono font-black text-indigo-500">{item.log}</span>
                        </div>
                        <span className="text-[9px] text-slate-400 leading-normal">{item.note}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Helpful log mathematics formulas card */}
                <div className={cn(
                  "p-6 rounded-2xl border space-y-4",
                  theme === 'dark' ? "bg-slate-900/30 border-slate-800" : "bg-slate-100 border-slate-200"
                )}>
                  <div className="flex items-center gap-1.5 font-bold text-indigo-600 dark:text-indigo-400 text-xs">
                    <Info size={15} />
                    <span>Essential Logarithmic Rules:</span>
                  </div>
                  <ul className="list-disc pl-5 space-y-2 font-mono text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                    <li><strong>Product Rule:</strong> log(A × B) = log(A) + log(B)</li>
                    <li><strong>Quotient Rule:</strong> log(A / B) = log(A) - log(B)</li>
                    <li><strong>Power Rule:</strong> log(Aᵇ) = b × log(A)</li>
                    <li><strong>pH Conversion:</strong> pH = -log₁₀[H⁺]</li>
                    <li><strong>Henderson-Hasselbalch:</strong> pH = pKa + log₁₀([Conjugate Base]/[Weak Acid])</li>
                  </ul>
                </div>

              </div>
            </motion.div>
          )}

          {/* Active Tab: LOGARITHM TABLE */}
          {activeTab === 'logTable' && (
            <motion.div
              key="logTable"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-4"
            >
              <div className={cn(
                "p-5 rounded-2xl border space-y-4",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200 shadow-sm"
              )}>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-1.5">
                      <Table size={16} className="text-indigo-500" />
                      Standard 4-Digit Logarithm Table Viewer (Rows 10 - 30)
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Select table cells or set highlights to lookup mantissas. Real 4-digit logs contain mantissas with integer characteristic added back.
                    </p>
                  </div>

                  {/* Highlights controller */}
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200/50 dark:border-slate-800/80">
                      <span className="text-[10px] font-black text-slate-400 uppercase">Row N:</span>
                      <select
                        value={logRowHighlight}
                        onChange={(e) => setLogRowHighlight(parseInt(e.target.value))}
                        className="px-2 py-0.5 rounded text-xs bg-white dark:bg-slate-950 font-bold outline-none"
                      >
                        {Array.from({ length: 21 }, (_, i) => 10 + i).map(n => (
                          <option key={n} value={n}>{n}</option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200/50 dark:border-slate-800/80">
                      <span className="text-[10px] font-black text-slate-400 uppercase">Col:</span>
                      <select
                        value={logColHighlight}
                        onChange={(e) => setLogColHighlight(parseInt(e.target.value))}
                        className="px-2 py-0.5 rounded text-xs bg-white dark:bg-slate-950 font-bold outline-none"
                      >
                        {Array.from({ length: 10 }, (_, i) => i).map(c => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200/50 dark:border-slate-800/80">
                      <span className="text-[10px] font-black text-slate-400 uppercase">Mean Diff:</span>
                      <select
                        value={logMeanHighlight}
                        onChange={(e) => setLogMeanHighlight(parseInt(e.target.value))}
                        className="px-2 py-0.5 rounded text-xs bg-white dark:bg-slate-950 font-bold outline-none"
                      >
                        {Array.from({ length: 10 }, (_, i) => i).map(md => (
                          <option key={md} value={md}>{md === 0 ? "None" : md}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Highlight summary readout */}
                <div className={cn(
                  "p-4 rounded-xl border flex flex-col md:flex-row justify-between items-start md:items-center gap-4 font-mono text-xs",
                  theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-indigo-50/20 border-slate-150"
                )}>
                  <div>
                    <span className="text-slate-400">Current selection: </span>
                    <strong className="text-indigo-600 dark:text-indigo-400">
                      N = {logRowHighlight}.{logColHighlight}{logMeanHighlight > 0 ? ` + (Mean Diff ${logMeanHighlight})` : ""}
                    </strong>
                  </div>
                  <div className="flex items-center gap-3">
                    <div>
                      <span className="text-slate-400">Table Mantissa: </span>
                      <span className="font-extrabold text-slate-800 dark:text-slate-100">
                        {getLogTableMantissa(logRowHighlight, logColHighlight)}
                      </span>
                    </div>
                    {logMeanHighlight > 0 && (
                      <div>
                        <span className="text-slate-400">Mean Add: </span>
                        <span className="font-extrabold text-emerald-500">
                          +{getLogMeanDifference(logRowHighlight, logMeanHighlight)}
                        </span>
                      </div>
                    )}
                    <div>
                      <span className="text-slate-400">Final Log Value: </span>
                      <span className="font-black text-indigo-600 dark:text-indigo-400">
                        {(
                          Math.log10(logRowHighlight + logColHighlight/10 + (logMeanHighlight/100))
                        ).toFixed(4)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Standard grid representation */}
                <div className="overflow-x-auto max-w-full">
                  <table className="w-full text-left font-mono text-xs min-w-[700px]">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-bold">
                        <th className="py-2.5 px-3">N</th>
                        {Array.from({ length: 10 }, (_, i) => i).map(c => (
                          <th key={c} className={cn("py-2.5 px-2 text-center", logColHighlight === c && "text-indigo-500 bg-indigo-500/5")}>
                            {c}
                          </th>
                        ))}
                        <th className="py-2.5 px-2 border-l border-slate-200 dark:border-slate-800 text-center" colSpan={9}>
                          Mean Differences
                        </th>
                      </tr>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-[10px] text-slate-400">
                        <th className="py-1 px-3"></th>
                        {Array.from({ length: 10 }, (_, i) => i).map(c => <th key={c} className="py-1"></th>)}
                        <th className="py-1 px-2 border-l border-slate-200 dark:border-slate-800 text-center">1</th>
                        <th className="py-1 px-2 text-center">2</th>
                        <th className="py-1 px-2 text-center">3</th>
                        <th className="py-1 px-2 text-center">4</th>
                        <th className="py-1 px-2 text-center">5</th>
                        <th className="py-1 px-2 text-center">6</th>
                        <th className="py-1 px-2 text-center">7</th>
                        <th className="py-1 px-2 text-center">8</th>
                        <th className="py-1 px-2 text-center">9</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                      {Array.from({ length: 21 }, (_, i) => 10 + i).map(row => {
                        const isRowSelected = logRowHighlight === row;
                        return (
                          <tr 
                            key={row} 
                            className={cn(
                              "hover:bg-slate-100/50 dark:hover:bg-slate-900/30 transition-all",
                              isRowSelected && "bg-indigo-500/10 hover:bg-indigo-500/15"
                            )}
                          >
                            <td className="py-2.5 px-3 font-bold text-slate-400">{row}</td>
                            
                            {/* Main columns 0-9 */}
                            {Array.from({ length: 10 }, (_, c) => {
                              const isColSelected = logColHighlight === c;
                              const mantissa = getLogTableMantissa(row, c);
                              return (
                                <td 
                                  key={c} 
                                  onClick={() => {
                                    setLogRowHighlight(row);
                                    setLogColHighlight(c);
                                  }}
                                  className={cn(
                                    "py-2.5 px-2 text-center cursor-pointer transition",
                                    isColSelected && "font-black text-indigo-500",
                                    (isRowSelected && isColSelected) && "bg-indigo-500 text-white rounded-md scale-105 shadow"
                                  )}
                                >
                                  {mantissa}
                                </td>
                              );
                            })}

                            {/* Mean Difference columns 1-9 */}
                            {Array.from({ length: 9 }, (_, md) => {
                              const meanCol = md + 1;
                              const isMeanSelected = logMeanHighlight === meanCol;
                              const meanDiff = getLogMeanDifference(row, meanCol);
                              return (
                                <td
                                  key={meanCol}
                                  onClick={() => {
                                    setLogRowHighlight(row);
                                    setLogMeanHighlight(meanCol);
                                  }}
                                  className={cn(
                                    "py-2.5 px-2 text-center cursor-pointer border-l border-slate-100 dark:border-slate-850/50 font-medium text-slate-500",
                                    isMeanSelected && "font-black text-emerald-500",
                                    (isRowSelected && isMeanSelected) && "bg-emerald-500 text-white rounded-md scale-105 shadow"
                                  )}
                                >
                                  {meanDiff}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

              </div>
            </motion.div>
          )}

          {/* Active Tab: ANTILOGARITHM TABLE */}
          {activeTab === 'antiTable' && (
            <motion.div
              key="antiTable"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-4"
            >
              <div className={cn(
                "p-5 rounded-2xl border space-y-4",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200 shadow-sm"
              )}>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-1.5">
                      <Table size={16} className="text-violet-500" />
                      Standard 4-Digit Antilogarithm Table Viewer (.00 - .20)
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Select cells to calculate powers of 10. Direct decimal inputs are matched inside the logarithmic indices.
                    </p>
                  </div>

                  {/* Highlights controller */}
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200/50 dark:border-slate-800/80">
                      <span className="text-[10px] font-black text-slate-400 uppercase">Mantissa Index:</span>
                      <select
                        value={antiRowHighlight}
                        onChange={(e) => setAntiRowHighlight(parseInt(e.target.value))}
                        className="px-2 py-0.5 rounded text-xs bg-white dark:bg-slate-950 font-bold outline-none"
                      >
                        {Array.from({ length: 21 }, (_, i) => i).map(n => {
                          const label = "." + String(n).padStart(2, '0');
                          return <option key={n} value={n}>{label}</option>;
                        })}
                      </select>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200/50 dark:border-slate-800/80">
                      <span className="text-[10px] font-black text-slate-400 uppercase">Col:</span>
                      <select
                        value={antiColHighlight}
                        onChange={(e) => setAntiColHighlight(parseInt(e.target.value))}
                        className="px-2 py-0.5 rounded text-xs bg-white dark:bg-slate-950 font-bold outline-none"
                      >
                        {Array.from({ length: 10 }, (_, i) => i).map(c => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200/50 dark:border-slate-800/80">
                      <span className="text-[10px] font-black text-slate-400 uppercase">Mean Diff:</span>
                      <select
                        value={antiMeanHighlight}
                        onChange={(e) => setAntiMeanHighlight(parseInt(e.target.value))}
                        className="px-2 py-0.5 rounded text-xs bg-white dark:bg-slate-950 font-bold outline-none"
                      >
                        {Array.from({ length: 10 }, (_, i) => i).map(md => (
                          <option key={md} value={md}>{md === 0 ? "None" : md}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Highlight summary readout */}
                <div className={cn(
                  "p-4 rounded-xl border flex flex-col md:flex-row justify-between items-start md:items-center gap-4 font-mono text-xs",
                  theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-violet-50/20 border-slate-150"
                )}>
                  <div>
                    <span className="text-slate-400">Antilog Power Index: </span>
                    <strong className="text-violet-600 dark:text-violet-400">
                      10^(.{String(antiRowHighlight).padStart(2, '0')}{antiColHighlight}{antiMeanHighlight > 0 ? ` + Mean ${antiMeanHighlight}` : ""})
                    </strong>
                  </div>
                  <div className="flex items-center gap-3">
                    <div>
                      <span className="text-slate-400">Base Mantissa: </span>
                      <span className="font-extrabold text-slate-800 dark:text-slate-100">
                        {getAntiLogMantissaValue(antiRowHighlight, antiColHighlight)}
                      </span>
                    </div>
                    {antiMeanHighlight > 0 && (
                      <div>
                        <span className="text-slate-400">Mean Add: </span>
                        <span className="font-extrabold text-emerald-500">
                          +{getAntiLogMeanDifference(antiRowHighlight, antiMeanHighlight)}
                        </span>
                      </div>
                    )}
                    <div>
                      <span className="text-slate-400">Result: </span>
                      <span className="font-black text-violet-600 dark:text-violet-400">
                        {(
                          Math.pow(10, (antiRowHighlight / 100) + (antiColHighlight / 1000) + (antiMeanHighlight / 10000))
                        ).toFixed(4)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Standard grid representation */}
                <div className="overflow-x-auto max-w-full">
                  <table className="w-full text-left font-mono text-xs min-w-[700px]">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-bold">
                        <th className="py-2.5 px-3">Mantissa</th>
                        {Array.from({ length: 10 }, (_, i) => i).map(c => (
                          <th key={c} className={cn("py-2.5 px-2 text-center", antiColHighlight === c && "text-violet-500 bg-violet-500/5")}>
                            {c}
                          </th>
                        ))}
                        <th className="py-2.5 px-2 border-l border-slate-200 dark:border-slate-800 text-center" colSpan={9}>
                          Mean Differences
                        </th>
                      </tr>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-[10px] text-slate-400">
                        <th className="py-1 px-3"></th>
                        {Array.from({ length: 10 }, (_, i) => i).map(c => <th key={c} className="py-1"></th>)}
                        <th className="py-1 px-2 border-l border-slate-200 dark:border-slate-800 text-center">1</th>
                        <th className="py-1 px-2 text-center">2</th>
                        <th className="py-1 px-2 text-center">3</th>
                        <th className="py-1 px-2 text-center">4</th>
                        <th className="py-1 px-2 text-center">5</th>
                        <th className="py-1 px-2 text-center">6</th>
                        <th className="py-1 px-2 text-center">7</th>
                        <th className="py-1 px-2 text-center">8</th>
                        <th className="py-1 px-2 text-center">9</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                      {Array.from({ length: 21 }, (_, i) => i).map(row => {
                        const isRowSelected = antiRowHighlight === row;
                        const decimalLabel = "." + String(row).padStart(2, '0');
                        return (
                          <tr 
                            key={row} 
                            className={cn(
                              "hover:bg-slate-100/50 dark:hover:bg-slate-900/30 transition-all",
                              isRowSelected && "bg-violet-500/10 hover:bg-violet-500/15"
                            )}
                          >
                            <td className="py-2.5 px-3 font-bold text-slate-400">{decimalLabel}</td>
                            
                            {/* Main columns 0-9 */}
                            {Array.from({ length: 10 }, (_, c) => {
                              const isColSelected = antiColHighlight === c;
                              const mantissa = getAntiLogMantissaValue(row, c);
                              return (
                                <td 
                                  key={c} 
                                  onClick={() => {
                                    setAntiRowHighlight(row);
                                    setAntiColHighlight(c);
                                  }}
                                  className={cn(
                                    "py-2.5 px-2 text-center cursor-pointer transition",
                                    isColSelected && "font-black text-violet-500",
                                    (isRowSelected && isColSelected) && "bg-violet-500 text-white rounded-md scale-105 shadow"
                                  )}
                                >
                                  {mantissa}
                                </td>
                              );
                            })}

                            {/* Mean Difference columns 1-9 */}
                            {Array.from({ length: 9 }, (_, md) => {
                              const meanCol = md + 1;
                              const isMeanSelected = antiMeanHighlight === meanCol;
                              const meanDiff = getAntiLogMeanDifference(row, meanCol);
                              return (
                                <td
                                  key={meanCol}
                                  onClick={() => {
                                    setAntiRowHighlight(row);
                                    setAntiMeanHighlight(meanCol);
                                  }}
                                  className={cn(
                                    "py-2.5 px-2 text-center cursor-pointer border-l border-slate-100 dark:border-slate-850/50 font-medium text-slate-500",
                                    isMeanSelected && "font-black text-emerald-500",
                                    (isRowSelected && isMeanSelected) && "bg-emerald-500 text-white rounded-md scale-105 shadow"
                                  )}
                                >
                                  {meanDiff}
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

              </div>
            </motion.div>
          )}

          {/* Active Tab: CHEMISTRY APPLICATION MODULES */}
          {activeTab === 'chemistryApplications' && (
            <motion.div
              key="chemistryApplications"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              {/* Box 1: pH and pKa Interactive Solver */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-6 shadow-sm",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
              )}>
                <div className="flex items-center gap-2 border-b border-dashed border-slate-200 dark:border-slate-800 pb-3">
                  <Activity size={16} className="text-emerald-500" />
                  <h3 className="text-sm font-black uppercase tracking-wider">pH & Hydrogen Ion Concentrations</h3>
                </div>

                <div className="space-y-4">
                  {/* [H+] to pH */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Convert Hydrogen Ion concentration [H⁺] to pH
                    </label>
                    <div className="flex gap-2">
                      <input 
                        type="text"
                        value={hConcentration}
                        onChange={(e) => setHConcentration(e.target.value)}
                        placeholder="e.g. 1.0e-3"
                        className={cn(
                          "flex-1 px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                      <div className={cn(
                        "px-4 py-2.5 rounded-xl border text-xs font-black font-mono flex items-center justify-center min-w-[100px]",
                        theme === 'dark' ? "bg-slate-900 border-slate-850" : "bg-emerald-50 border-slate-200"
                      )}>
                        pH = {computedPhResult}
                      </div>
                    </div>
                  </div>

                  {/* pH to [H+] */}
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Convert pH value back to [H⁺] Concentration
                    </label>
                    <div className="flex gap-2">
                      <input 
                        type="number"
                        step="0.01"
                        value={phInput}
                        onChange={(e) => setPhInput(e.target.value)}
                        placeholder="e.g. 3.00"
                        className={cn(
                          "flex-1 px-3.5 py-2.5 rounded-xl border text-xs font-bold outline-none font-mono transition-all",
                          theme === 'dark' 
                            ? "bg-slate-900 border-slate-800 text-slate-100 focus:border-indigo-500" 
                            : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                        )}
                      />
                      <div className={cn(
                        "px-4 py-2.5 rounded-xl border text-xs font-black font-mono flex items-center justify-center min-w-[150px]",
                        theme === 'dark' ? "bg-slate-900 border-slate-850" : "bg-indigo-50 border-slate-200"
                      )}>
                        [H⁺] = {computedHResult}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Box 2: Henderson-Hasselbalch Buffer Solver */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-6 shadow-sm",
                theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
              )}>
                <div className="flex items-center gap-2 border-b border-dashed border-slate-200 dark:border-slate-800 pb-3">
                  <Calculator size={16} className="text-indigo-500" />
                  <h3 className="text-sm font-black uppercase tracking-wider">Henderson-Hasselbalch Buffer Solver</h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">
                      pKa of Weak Acid
                    </label>
                    <input 
                      type="number"
                      step="0.01"
                      value={pkaInput}
                      onChange={(e) => setPkaInput(e.target.value)}
                      className={cn(
                        "w-full px-3 py-2.5 rounded-xl border text-xs font-bold font-mono outline-none",
                        theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"
                      )}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">
                      [Weak Acid] (HA)
                    </label>
                    <input 
                      type="number"
                      step="any"
                      value={acidConc}
                      onChange={(e) => setAcidConc(e.target.value)}
                      className={cn(
                        "w-full px-3 py-2.5 rounded-xl border text-xs font-bold font-mono outline-none",
                        theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"
                      )}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">
                      [Conj. Base] (A⁻)
                    </label>
                    <input 
                      type="number"
                      step="any"
                      value={conjugateBaseConc}
                      onChange={(e) => setConjugateBaseConc(e.target.value)}
                      className={cn(
                        "w-full px-3 py-2.5 rounded-xl border text-xs font-bold font-mono outline-none",
                        theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"
                      )}
                    />
                  </div>
                </div>

                <div className="py-4 px-6 flex flex-col items-center justify-center bg-indigo-500/5 rounded-2xl border border-dashed border-indigo-500/20">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Calculated Buffer pH</span>
                  <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400 font-mono">
                    {typeof computedBufferPh === 'string' ? computedBufferPh : `pH = ${computedBufferPh.ph}`}
                  </span>
                  {typeof computedBufferPh !== 'string' && (
                    <span className="text-[10px] text-slate-400 mt-1 font-mono">
                      log₁₀([A⁻]/[HA]) ratio factor = {computedBufferPh.logRatio}
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>

    </div>
  );
};
