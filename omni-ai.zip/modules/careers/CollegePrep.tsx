export * from '../../src/modules/careers/CollegePrep';
import { CollegePrep } from '../../src/modules/careers/CollegePrep';
export default CollegePrep;
