import React from 'react';

export const TeacherDashboard: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-bold text-white">Teacher Dashboard</h2>
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
        <h3 className="text-lg font-semibold text-white">Class Roster (45 Students)</h3>
        <button className="bg-indigo-500 text-white px-4 py-2 rounded mt-2">Assign New Task</button>
      </div>
    </div>
  );
};
