import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Info, ZoomIn, RefreshCw, ChevronRight, ChevronLeft, MapPin } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface Hotspot {
  id: string;
  x: number; // percentage
  y: number; // percentage
  title: string;
  description: string;
  details: string[];
}

interface LifeCycle {
  id: string;
  name: string;
  image: string;
  description: string;
  hotspots: Hotspot[];
}

const LIFE_CYCLES: LifeCycle[] = [
  {
    id: 'angiosperm',
    name: 'Angiosperm (Flowering Plant)',
    image: '/src/assets/images/angiosperm_life_cycle_diagram_1786070708377.jpg',
    description: 'The complex reproductive cycle of flowering plants involving alternation of generations and double fertilization.',
    hotspots: [
      {
        id: 'sporophyte',
        x: 50,
        y: 15,
        title: 'Mature Sporophyte (2n)',
        description: 'The visible plant body that produces spores through meiosis in specialized floral organs.',
        details: [
          'Flowers are the reproductive shoots of angiosperms.',
          'Contains androecium (male) and gynoecium (female) parts.',
          'Site of micro and megasporogenesis.'
        ]
      },
      {
        id: 'microsporogenesis',
        x: 20,
        y: 35,
        title: 'Microsporogenesis',
        description: 'Process occurring in the anther where microspore mother cells undergo meiosis to form pollen.',
        details: [
          'Each PMC produces 4 microspores.',
          'Pollen grains develop from microspores.',
          'Represents the male gametophyte generation.'
        ]
      },
      {
        id: 'megasporogenesis',
        x: 80,
        y: 35,
        title: 'Megasporogenesis',
        description: 'Formation of the female gametophyte (embryo sac) within the ovule.',
        details: [
          'Occurs inside the nucellus of the ovule.',
          'Single functional megaspore forms the 7-celled 8-nucleate embryo sac.',
          'Egg cell is located at the micropylar end.'
        ]
      },
      {
        id: 'double_fertilization',
        x: 50,
        y: 65,
        title: 'Double Fertilization',
        description: 'A unique angiosperm process where two male gametes perform different fusion events.',
        details: [
          'Syngamy: 1 male gamete + egg = Zygote (2n).',
          'Triple Fusion: 1 male gamete + 2 polar nuclei = PEN (3n).',
          'PEN develops into nutritive endosperm.'
        ]
      },
      {
        id: 'seed_fruit',
        x: 50,
        y: 85,
        title: 'Seed and Fruit Development',
        description: 'Post-fertilization transformation of ovules into seeds and ovaries into fruits.',
        details: [
          'Ovule becomes the seed coat.',
          'Zygote develops into the embryo.',
          'Fruits aid in seed dispersal.'
        ]
      }
    ]
  },
  {
    id: 'human',
    name: 'Human Reproductive Cycle',
    image: '/src/assets/images/human_life_cycle_diagram_1786070719426.jpg',
    description: 'The biological process involving gamete formation, fertilization, and embryonic development in humans.',
    hotspots: [
      {
        id: 'gametogenesis',
        x: 20,
        y: 20,
        title: 'Gametogenesis',
        description: 'The production of haploid gametes (sperm and egg) via meiosis in gonads.',
        details: [
          'Spermatogenesis occurs in testes (continuous).',
          'Oogenesis occurs in ovaries (cyclic).',
          'Reduces chromosome number from 2n to n.'
        ]
      },
      {
        id: 'fertilization',
        x: 50,
        y: 30,
        title: 'Fertilization',
        description: 'Fusion of sperm and egg in the Fallopian tube to form a diploid zygote.',
        details: [
          'Restores diploidy (2n).',
          'Determines genetic sex of the offspring.',
          'Triggers the start of cleavage.'
        ]
      },
      {
        id: 'cleavage',
        x: 75,
        y: 45,
        title: 'Cleavage & Blastocyst',
        description: 'Rapid mitotic divisions of the zygote without increasing total volume.',
        details: [
          'Forms morula (solid ball of cells).',
          'Develops into blastocyst (hollow ball).',
          'Implantation occurs in the uterine wall around day 7.'
        ]
      },
      {
        id: 'embryogenesis',
        x: 50,
        y: 65,
        title: 'Embryogenesis',
        description: 'Transformation of the blastocyst into a complex organism with distinct organ systems.',
        details: [
          'Gastrulation forms the three germ layers (ecto, meso, endoderm).',
          'Organogenesis is the formation of organs.',
          'Placenta facilitates nutrient and waste exchange.'
        ]
      },
      {
        id: 'fetus',
        x: 50,
        y: 85,
        title: 'Fetal Development',
        description: 'The growth and maturation phase from week 9 until birth.',
        details: [
          'Rapid growth and refinement of body structures.',
          'Reflexes and sensory capabilities develop.',
          'Ends with parturition (birth).'
        ]
      }
    ]
  },
  {
    id: 'frog',
    name: 'Frog (Amphibian) Life Cycle',
    image: '/src/assets/images/frog_life_cycle_diagram_1786071214251.jpg',
    description: 'The metamorphic journey of amphibians from aquatic larvae to terrestrial adults.',
    hotspots: [
      {
        id: 'eggs',
        x: 20,
        y: 20,
        title: 'Egg Mass (Spawn)',
        description: 'Clusters of jelly-coated eggs laid in water.',
        details: [
          'External fertilization in most species.',
          'Jelly provides protection and nutrition.',
          'Hatch into tadpoles within 1-3 weeks.'
        ]
      },
      {
        id: 'tadpole',
        x: 50,
        y: 20,
        title: 'Tadpole (Larva)',
        description: 'Fully aquatic stage with gills and a long tail.',
        details: [
          'Breathes through external gills.',
          'Primarily herbivorous (scrapes algae).',
          'Lacks limbs initially.'
        ]
      },
      {
        id: 'metamorphosis',
        x: 80,
        y: 50,
        title: 'Metamorphosis',
        description: 'The transition where legs develop and gills are replaced by lungs.',
        details: [
          'Hind legs appear first, followed by front legs.',
          'Tail is reabsorbed by apoptosis.',
          'Digestive system changes to carnivorous diet.'
        ]
      },
      {
        id: 'adult',
        x: 50,
        y: 80,
        title: 'Adult Frog',
        description: 'Semi-terrestrial stage capable of lung and skin respiration.',
        details: [
          'Strong hind legs for jumping.',
          'Moist skin for cutaneous respiration.',
          'Returns to water only for breeding.'
        ]
      }
    ]
  },
  {
    id: 'honeybee',
    name: 'Honey Bee Life Cycle',
    image: '/src/assets/images/honey_bee_life_cycle_diagram_1786071229062.jpg',
    description: 'Holometabolous development (complete metamorphosis) of the social honey bee.',
    hotspots: [
      {
        id: 'egg',
        x: 20,
        y: 30,
        title: 'Egg Stage',
        description: 'Laid by the Queen in hexagonal wax cells.',
        details: [
          'Fertilized eggs become females (Workers/Queens).',
          'Unfertilized eggs become males (Drones).',
          'Hatch into larvae after 3 days.'
        ]
      },
      {
        id: 'larva',
        x: 50,
        y: 30,
        title: 'Larval Stage',
        description: 'White, legless, C-shaped grubs that are fed intensely.',
        details: [
          'Fed royal jelly for the first 3 days.',
          'Worker larvae then get "bee bread" (pollen + honey).',
          'Queen larvae get royal jelly exclusively.'
        ]
      },
      {
        id: 'pupa',
        x: 80,
        y: 60,
        title: 'Pupal Stage',
        description: 'The transformation phase inside a capped cell.',
        details: [
          'Tissue reorganization occurs.',
          'Eyes, legs, and wings develop.',
          'Inactive stage (non-feeding).'
        ]
      },
      {
        id: 'adult_emergence',
        x: 50,
        y: 85,
        title: 'Adult Emergence',
        description: 'The mature bee chews its way out of the cell.',
        details: [
          'Workers perform hive duties (cleaning, nursing).',
          'Drones exist solely for mating with virgin queens.',
          'Queens are the reproductive heart of the colony.'
        ]
      }
    ]
  }
];

export const LifeCycleExplorer: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [activeCycleIdx, setActiveCycleIdx] = useState(0);
  const [selectedHotspot, setSelectedHotspot] = useState<Hotspot | null>(null);
  const [imageLoaded, setImageLoaded] = useState(false);

  const cycle = LIFE_CYCLES[activeCycleIdx];

  const handleNext = () => {
    setActiveCycleIdx((prev) => (prev + 1) % LIFE_CYCLES.length);
    setSelectedHotspot(null);
    setImageLoaded(false);
  };

  const handlePrev = () => {
    setActiveCycleIdx((prev) => (prev - 1 + LIFE_CYCLES.length) % LIFE_CYCLES.length);
    setSelectedHotspot(null);
    setImageLoaded(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800">
      {/* Top Header */}
      <div className="p-4 bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-emerald-500" />
            Biological Life Cycle Explorer
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">Interactive diagrams for CBSE Biology Class 12</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrev}
            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition"
          >
            <ChevronLeft size={20} />
          </button>
          <div className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold rounded-full border border-emerald-200 dark:border-emerald-800">
            {activeCycleIdx + 1} / {LIFE_CYCLES.length}
          </div>
          <button
            onClick={handleNext}
            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Diagram Area */}
        <div className="flex-1 relative bg-slate-200 dark:bg-slate-950 overflow-hidden flex items-center justify-center p-4">
          <div className="relative max-w-full max-h-full aspect-square bg-white rounded-lg shadow-2xl overflow-hidden group">
            {!imageLoaded && (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-100 dark:bg-slate-900 animate-pulse">
                <div className="flex flex-col items-center gap-2">
                  <RefreshCw className="w-8 h-8 text-emerald-500 animate-spin" />
                  <span className="text-xs text-slate-400">Loading scientific diagram...</span>
                </div>
              </div>
            )}
            <img
              src={cycle.image}
              alt={cycle.name}
              className={cn(
                "w-full h-full object-contain transition-opacity duration-500",
                imageLoaded ? "opacity-100" : "opacity-0"
              )}
              referrerPolicy="no-referrer"
              onLoad={() => setImageLoaded(true)}
            />

            {/* Hotspots */}
            <AnimatePresence>
              {imageLoaded && cycle.hotspots.map((spot) => (
                <motion.button
                  key={spot.id}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  whileHover={{ scale: 1.2 }}
                  className={cn(
                    "absolute w-6 h-6 -ml-3 -mt-3 rounded-full border-2 flex items-center justify-center transition-all shadow-lg z-20",
                    selectedHotspot?.id === spot.id
                      ? "bg-emerald-500 border-white scale-110"
                      : "bg-white/80 border-emerald-500 hover:bg-emerald-100"
                  )}
                  style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
                  onClick={() => setSelectedHotspot(spot)}
                >
                  <MapPin size={12} className={selectedHotspot?.id === spot.id ? "text-white" : "text-emerald-500"} />
                  
                  {/* Pulse Effect */}
                  <span className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-25 -z-10"></span>
                </motion.button>
              ))}
            </AnimatePresence>

            <div className="absolute bottom-2 left-2 bg-black/50 backdrop-blur-sm px-2 py-1 rounded text-[10px] text-white flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <ZoomIn size={10} /> Click icons to explore stages
            </div>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="w-full lg:w-[400px] bg-white dark:bg-slate-950 border-l border-slate-200 dark:border-slate-800 overflow-y-auto flex flex-col">
          <div className="p-6">
            <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-2">{cycle.name}</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
              {cycle.description}
            </p>

            <div className="space-y-4">
              <AnimatePresence mode="wait">
                {selectedHotspot ? (
                  <motion.div
                    key={selectedHotspot.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/50"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-2">
                        <Info size={16} />
                        {selectedHotspot.title}
                      </h4>
                      <button 
                        onClick={() => setSelectedHotspot(null)}
                        className="text-emerald-600 hover:text-emerald-800 dark:text-emerald-500 text-xs font-bold"
                      >
                        Dismiss
                      </button>
                    </div>
                    <p className="text-sm text-slate-700 dark:text-slate-300 mb-4 leading-relaxed font-medium">
                      {selectedHotspot.description}
                    </p>
                    <div className="space-y-2">
                      <span className="text-[10px] font-bold uppercase text-emerald-600 dark:text-emerald-500 tracking-wider">Detailed Mechanisms</span>
                      {selectedHotspot.details.map((detail, idx) => (
                        <div key={idx} className="flex gap-2 text-xs text-slate-600 dark:text-slate-400">
                          <span className="text-emerald-500 font-bold">•</span>
                          <span>{detail}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="p-8 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl flex flex-col items-center text-center gap-3"
                  >
                    <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-900 flex items-center justify-center text-slate-400">
                      <MapPin size={24} />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300">Select a stage</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-500">Tap on the hotspot icons in the diagram to reveal biological details.</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          <div className="mt-auto p-6 border-t border-slate-100 dark:border-slate-900 bg-slate-50 dark:bg-slate-900/50">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white font-bold text-xs">
                ?
              </div>
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300">Class 12 Exam Concept</h4>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed italic">
              "Understanding the alternation of generations and the transition from diploid to haploid phases is critical for scoring in NCERT-based reproduction units."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
