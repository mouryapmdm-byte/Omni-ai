import React from 'react';
import { Search, Filter, Calendar, Tag, Layers, RefreshCw } from 'lucide-react';
import { MistakeCategory } from './types';
import { MISTAKE_CATEGORY_INFO } from './mistakeClassifier';

interface MistakeFilterProps {
  isDark?: boolean;
  selectedCategory: MistakeCategory | 'all';
  onSelectCategory: (cat: MistakeCategory | 'all') => void;
  selectedSubject: string;
  onSelectSubject: (sub: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  showOnlyUnresolved: boolean;
  onToggleUnresolved: (val: boolean) => void;
}

export const MistakeFilter: React.FC<MistakeFilterProps> = ({
  isDark = true,
  selectedCategory,
  onSelectCategory,
  selectedSubject,
  onSelectSubject,
  searchQuery,
  onSearchChange,
  showOnlyUnresolved,
  onToggleUnresolved
}) => {
  const categories: (MistakeCategory | 'all')[] = [
    'all',
    'sign_error',
    'unit_error',
    'calculation_error',
    'concept_misunderstanding',
    'reading_comprehension',
    'formula_misuse',
    'silly_mistake'
  ];

  return (
    <div className={`p-4 rounded-2xl border space-y-3 ${
      isDark ? 'bg-slate-900/90 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
    }`}>
      {/* Top Search and Subject Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 absolute left-3 top-3 opacity-50" />
          <input
            type="text"
            placeholder="Search mistakes, concepts, formulas, questions..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className={`w-full pl-9 pr-4 py-2 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 ${
              isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={selectedSubject}
            onChange={(e) => onSelectSubject(e.target.value)}
            className={`px-3 py-2 rounded-xl border text-xs font-semibold focus:outline-none ${
              isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          >
            <option value="all">All Subjects</option>
            <option value="Physics">Physics</option>
            <option value="Chemistry">Chemistry</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Biology">Biology</option>
          </select>

          <button
            onClick={() => onToggleUnresolved(!showOnlyUnresolved)}
            className={`px-3 py-2 rounded-xl border text-xs font-semibold transition-all flex items-center gap-1.5 ${
              showOnlyUnresolved
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-bold'
                : isDark ? 'bg-slate-800 border-slate-700 text-slate-400' : 'bg-slate-100 border-slate-300 text-slate-600'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${showOnlyUnresolved ? 'bg-rose-500 animate-pulse' : 'bg-slate-500'}`} />
            Needs Practice Only
          </button>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {categories.map(cat => {
          const isSelected = selectedCategory === cat;
          const label = cat === 'all' ? 'All Mistakes' : MISTAKE_CATEGORY_INFO[cat]?.name || cat;

          return (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-rose-600 text-white shadow-md font-bold'
                  : isDark ? 'bg-slate-800/80 text-slate-400 hover:text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>
    </div>
  );
};
