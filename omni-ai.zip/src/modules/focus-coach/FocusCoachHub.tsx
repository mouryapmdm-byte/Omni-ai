import React, { useState } from 'react';
import { 
  Clock, Flame, Music, Lightbulb, Calendar, ShieldCheck, 
  Download, Sparkles, Coffee, Eye, Heart, ArrowRight, Check 
} from 'lucide-react';
import { FocusTimer } from './FocusTimer';
import { AmbientSounds } from './AmbientSounds';
import { FocusInsights } from './FocusInsights';
import { ScheduleRecommender } from './ScheduleRecommender';
import { RecommendedScheduleSlot, StudySession } from './types';

interface FocusCoachHubProps {
  isDark?: boolean;
}

export const FocusCoachHub: React.FC<FocusCoachHubProps> = ({ isDark = true }) => {
  const [activeTab, setActiveTab] = useState<'timer' | 'ambient' | 'insights' | 'schedule' | 'breaks'>('timer');
  const [scheduleSlots, setScheduleSlots] = useState<RecommendedScheduleSlot[]>(
    ScheduleRecommender.getRecommendedSlots()
  );
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [lastCompletedSession, setLastCompletedSession] = useState<StudySession | null>(null);

  const smartBreaks = ScheduleRecommender.getSmartBreakSuggestions();

  const handleDownloadICS = () => {
    const icsText = ScheduleRecommender.generateICSContent(scheduleSlots);
    const blob = new Blob([icsText], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'OmniAI_Study_Schedule.ics';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className={`w-full max-w-6xl mx-auto space-y-6 ${isDark ? 'text-slate-100' : 'text-slate-900'}`}>
      {/* Top Banner Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -z-10 pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-300 shrink-0 shadow-lg shadow-indigo-500/10">
              <Clock className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-extrabold tracking-tight text-white">Study Environment Coach</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Focus Optimization Engine
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-xl">
                Maximize deep work flow state with real-time distraction tracking, acoustic focus masking, smart break prompts, and personalized energy scheduling.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/80 p-2.5 rounded-2xl border border-slate-800 text-xs shrink-0">
            <div className="px-3 border-r border-slate-800 text-center">
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Focus State</span>
              <span className="font-bold text-emerald-400 text-sm">Active Flow</span>
            </div>
            <div className="px-3 text-center">
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Peak Window</span>
              <span className="font-bold text-indigo-300 text-sm">8:30 AM - 11:30 AM</span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-900/80 rounded-2xl border border-slate-800 overflow-x-auto">
        <button
          onClick={() => setActiveTab('timer')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'timer'
              ? 'bg-indigo-500 text-white shadow-md font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Focus Timer</span>
        </button>

        <button
          onClick={() => setActiveTab('ambient')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'ambient'
              ? 'bg-indigo-500 text-white shadow-md font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Music className="w-4 h-4" />
          <span>Ambient Sounds</span>
        </button>

        <button
          onClick={() => setActiveTab('insights')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'insights'
              ? 'bg-indigo-500 text-white shadow-md font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Lightbulb className="w-4 h-4" />
          <span>Environment Insights</span>
        </button>

        <button
          onClick={() => setActiveTab('breaks')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'breaks'
              ? 'bg-indigo-500 text-white shadow-md font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Coffee className="w-4 h-4" />
          <span>Smart Breaks</span>
        </button>

        <button
          onClick={() => setActiveTab('schedule')}
          className={`flex-1 py-3 px-4 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'schedule'
              ? 'bg-indigo-500 text-white shadow-md font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Personalized Schedule</span>
        </button>
      </div>

      {/* Main Tab Views */}
      <div className="mt-4">
        {activeTab === 'timer' && (
          <FocusTimer
            isDark={isDark}
            onSessionComplete={session => setLastCompletedSession(session)}
          />
        )}

        {activeTab === 'ambient' && (
          <AmbientSounds isDark={isDark} />
        )}

        {activeTab === 'insights' && (
          <FocusInsights isDark={isDark} />
        )}

        {activeTab === 'breaks' && (
          <div className="rounded-2xl p-6 border bg-slate-900 border-slate-800 text-slate-100 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <Coffee className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-slate-100">Smart Rest & Micro-Breaks</h3>
                  <p className="text-xs text-slate-400">Scientifically designed micro-routine activities to restore cognitive focus</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {smartBreaks.map((b, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-emerald-400">{b.category}</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {b.duration}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-100">{b.title}</h4>
                  <p className="text-xs text-slate-400">{b.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'schedule' && (
          <div className="rounded-2xl p-6 border bg-slate-900 border-slate-800 text-slate-100 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-slate-100">Circadian Energy Study Schedule</h3>
                  <p className="text-xs text-slate-400">Custom tailored study windows matched to your historical focus peak hours</p>
                </div>
              </div>

              {/* ICS Export Button */}
              <button
                onClick={handleDownloadICS}
                className="px-4 py-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-400 text-white font-semibold text-xs flex items-center gap-2 shadow-md transition-all cursor-pointer shrink-0"
              >
                {downloadSuccess ? <Check className="w-4 h-4 text-emerald-300" /> : <Download className="w-4 h-4" />}
                <span>{downloadSuccess ? 'iCal File Downloaded!' : 'Export Calendar (.ics)'}</span>
              </button>
            </div>

            {/* Weekly Schedule Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {scheduleSlots.map((slot, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-indigo-300">{slot.dayName} · {slot.timeRange}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                      slot.energyLevel === 'Peak Focus'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : slot.energyLevel === 'Steady Endurance'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                    }`}>
                      {slot.energyLevel}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-100">{slot.subjectRecommendation}</h4>
                  <p className="text-xs text-slate-400">{slot.reasoning}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
