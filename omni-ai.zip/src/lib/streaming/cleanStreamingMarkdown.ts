import { StreamingBuffer } from './StreamingBuffer';

/**
 * High-fidelity mathematical and scientific LaTeX to Unicode symbol dictionary.
 * Converts formulas, Greek letters, operators, calculus notations, and accents into pristine blackboard text.
 */
export function formatLaTeXToUnicode(latex: string): string {
  if (!latex) return '';

  let text = latex;

  // 0. Remove raw math delimiters and environment declarations
  text = text.replace(/\$\$+/g, '');
  text = text.replace(/\\\[|\\\]|\\\(|\\\)/g, '');
  text = text.replace(/(?:\r?\n|^)\s*\$\s*|\s*\$\s*(?:\r?\n|$)/g, '');
  text = text.replace(/\$+/g, '');
  text = text.replace(/\\(?:begin|end)\{[a-zA-Z0-9*]+\}/gi, '');
  text = text.replace(/\\displaystyle\b/gi, '');
  text = text.replace(/\\tag\{[^}]*\}/gi, '');
  text = text.replace(/\\\\/g, '  ');
  text = text.replace(/&/g, ' ');

  // 1. Structural commands & Styles
  text = text.replace(/\\(?:textbf|textit|textsf|texttt|emph|operatorname|mathrm|mathbf|text|mathit|mathcal|boldsymbol|underline|overline)\{([^}]+)\}/gi, '$1');
  text = text.replace(/\\mathbb\{R\}/g, 'ℝ');
  text = text.replace(/\\mathbb\{C\}/g, 'ℂ');
  text = text.replace(/\\mathbb\{Z\}/g, 'ℤ');
  text = text.replace(/\\mathbb\{N\}/g, 'ℕ');
  text = text.replace(/\\mathbb\{Q\}/g, 'ℚ');
  text = text.replace(/\\mathbb\{([^}]+)\}/g, '$1');

  // 2. Fractions (multiple passes to handle nested/adjacent fractions)
  for (let pass = 0; pass < 3; pass++) {
    text = text.replace(/\\(?:frac|dfrac|tfrac)\{([^{}]+)\}\{([^{}]+)\}/g, '($1 / $2)');
  }

  // 3. Roots & Radicals
  text = text.replace(/\\sqrt\[(\d+)\]\{([^}]+)\}/g, '^$1√($2)');
  text = text.replace(/\\sqrt\{([^}]+)\}/g, '√($1)');
  text = text.replace(/\\sqrt/g, '√');

  // 4. Vector & Accent notations
  text = text.replace(/\\vec\{([a-zA-Z0-9]+)\}/g, '$1⃗');
  text = text.replace(/\\vec\s+([a-zA-Z0-9])/g, '$1⃗');
  text = text.replace(/\\hat\{([a-zA-Z0-9]+)\}/g, '$1̂');
  text = text.replace(/\\hat\s+([a-zA-Z0-9])/g, '$1̂');
  text = text.replace(/\\bar\{([a-zA-Z0-9]+)\}/g, '$1̄');
  text = text.replace(/\\dot\{([a-zA-Z0-9]+)\}/g, '$1̇');
  text = text.replace(/\\ddot\{([a-zA-Z0-9]+)\}/g, '$1̈');

  // 5. Greek Letters (Capital first to prevent prefix clashes)
  text = text.replace(/\\Gamma\b/g, 'Γ');
  text = text.replace(/\\Delta\b/g, 'Δ');
  text = text.replace(/\\Theta\b/g, 'Θ');
  text = text.replace(/\\Lambda\b/g, 'Λ');
  text = text.replace(/\\Xi\b/g, 'Ξ');
  text = text.replace(/\\Pi\b/g, 'Π');
  text = text.replace(/\\Sigma\b/g, 'Σ');
  text = text.replace(/\\Upsilon\b/g, 'Υ');
  text = text.replace(/\\Phi\b/g, 'Φ');
  text = text.replace(/\\Psi\b/g, 'Ψ');
  text = text.replace(/\\Omega\b/g, 'Ω');

  // Lowercase Greek Letters
  text = text.replace(/\\nu_0\b/g, 'ν₀');
  text = text.replace(/\\alpha\b/g, 'α');
  text = text.replace(/\\beta\b/g, 'β');
  text = text.replace(/\\gamma\b/g, 'γ');
  text = text.replace(/\\delta\b/g, 'δ');
  text = text.replace(/\\(?:epsilon|varepsilon)\b/g, 'ε');
  text = text.replace(/\\zeta\b/g, 'ζ');
  text = text.replace(/\\eta\b/g, 'η');
  text = text.replace(/\\(?:theta|vartheta)\b/g, 'θ');
  text = text.replace(/\\iota\b/g, 'ι');
  text = text.replace(/\\kappa\b/g, 'κ');
  text = text.replace(/\\lambda\b/g, 'λ');
  text = text.replace(/\\mu\b/g, 'μ');
  text = text.replace(/\\nu\b/g, 'ν');
  text = text.replace(/\\xi\b/g, 'ξ');
  text = text.replace(/\\(?:pi|varpi)\b/g, 'π');
  text = text.replace(/\\(?:rho|varrho)\b/g, 'ρ');
  text = text.replace(/\\(?:sigma|varsigma)\b/g, 'σ');
  text = text.replace(/\\tau\b/g, 'τ');
  text = text.replace(/\\upsilon\b/g, 'υ');
  text = text.replace(/\\(?:phi|varphi)\b/g, 'ϕ');
  text = text.replace(/\\chi\b/g, 'χ');
  text = text.replace(/\\psi\b/g, 'ψ');
  text = text.replace(/\\omega\b/g, 'ω');

  // 6. Calculus, Operators & Symbols
  text = text.replace(/\\partial\b/g, '∂');
  text = text.replace(/\\nabla\b/g, '∇');
  text = text.replace(/\\oint\b/g, '∮');
  text = text.replace(/\\iiint\b/g, '∭');
  text = text.replace(/\\iint\b/g, '∬');
  text = text.replace(/\\int\b/g, '∫');
  text = text.replace(/\\sum\b/g, '∑');
  text = text.replace(/\\prod\b/g, '∏');
  text = text.replace(/\\hbar\b/g, 'ℏ');
  text = text.replace(/\\ell\b/g, 'ℓ');
  text = text.replace(/\\infty\b/g, '∞');

  // 7. Relations & Arrows
  text = text.replace(/\\xrightarrow\{([^}]*)\}/g, '→ ($1)');
  text = text.replace(/\\xleftarrow\{([^}]*)\}/g, '← ($1)');
  text = text.replace(/\\(?:implies|Rightarrow)\b/g, '⟹');
  text = text.replace(/\\(?:iff|Leftrightarrow)\b/g, '⟺');
  text = text.replace(/\\Leftarrow\b/g, '⟸');
  text = text.replace(/\\(?:to|rightarrow)\b/g, '→');
  text = text.replace(/\\leftarrow\b/g, '←');
  text = text.replace(/\\leftrightarrow\b/g, '↔');
  text = text.replace(/\\uparrow\b/g, '↑');
  text = text.replace(/\\downarrow\b/g, '↓');
  text = text.replace(/\\times\b/g, '×');
  text = text.replace(/\\div\b/g, '÷');
  text = text.replace(/\\pm\b/g, '±');
  text = text.replace(/\\mp\b/g, '∓');
  text = text.replace(/\\cdot\b/g, '·');
  text = text.replace(/\\bullet\b/g, '•');
  text = text.replace(/\\approx\b/g, '≈');
  text = text.replace(/\\simeq\b/g, '≃');
  text = text.replace(/\\cong\b/g, '≅');
  text = text.replace(/\\sim\b/g, '∼');
  text = text.replace(/\\propto\b/g, '∝');
  text = text.replace(/\\equiv\b/g, '≡');
  text = text.replace(/\\neq\b/g, '≠');
  text = text.replace(/\\(?:leq|le)\b/g, '≤');
  text = text.replace(/\\(?:geq|ge)\b/g, '≥');
  text = text.replace(/\\ll\b/g, '≪');
  text = text.replace(/\\gg\b/g, '≫');
  text = text.replace(/\\perp\b/g, '⊥');
  text = text.replace(/\\parallel\b/g, '∥');
  text = text.replace(/\\angle\b/g, '∠');
  text = text.replace(/\\(?:circ|degree)\b|\^\\circ/g, '°');
  text = text.replace(/\\in\b/g, '∈');
  text = text.replace(/\\notin\b/g, '∉');
  text = text.replace(/\\subset\b/g, '⊂');
  text = text.replace(/\\subseteq\b/g, '⊆');
  text = text.replace(/\\cap\b/g, '∩');
  text = text.replace(/\\cup\b/g, '∪');
  text = text.replace(/\\forall\b/g, '∀');
  text = text.replace(/\\exists\b/g, '∃');
  text = text.replace(/\\(?:emptyset|varnothing)\b/g, '∅');

  // 8. Functions
  text = text.replace(/\\det\s*\(([^)]+)\)/gi, 'det($1)');
  text = text.replace(/\\det\b/gi, 'det');
  text = text.replace(/\\lim_\{([^}]+)\}/gi, 'lim ($1)');
  text = text.replace(/\\lim\b/gi, 'lim');
  text = text.replace(/\\(?:sin|cos|tan|cot|sec|csc|ln|log|exp|arcsin|arccos|arctan|sinh|cosh|tanh)\b/g, (fn) => fn.slice(1));

  // 9. Spacers & Padding
  text = text.replace(/\\qquad\b/g, '   ');
  text = text.replace(/\\quad\b/g, '  ');
  text = text.replace(/\\[,;: ]/g, ' ');

  // 10. Delimiters
  text = text.replace(/\\left\s*([|()\[\]])/g, '$1');
  text = text.replace(/\\right\s*([|()\[\]])/g, '$1');
  text = text.replace(/\\left\s*\\\{/g, '{');
  text = text.replace(/\\right\s*\\\}/g, '}');
  text = text.replace(/\\left\s*\\\||\\right\s*\\\|/g, '|');
  text = text.replace(/\\left\s*\.|\\right\s*\./g, '');
  text = text.replace(/\\left\b|\\right\b/g, '');

  // 11. Superscripts & Subscripts
  text = text.replace(/\^2\b/g, '²');
  text = text.replace(/\^3\b/g, '³');
  text = text.replace(/\^n\b/g, 'ⁿ');
  text = text.replace(/\^0\b/g, '⁰');
  text = text.replace(/\^1\b/g, '¹');
  text = text.replace(/\^4\b/g, '⁴');
  text = text.replace(/\^5\b/g, '⁵');
  text = text.replace(/\^6\b/g, '⁶');
  text = text.replace(/\^7\b/g, '⁷');
  text = text.replace(/\^8\b/g, '⁸');
  text = text.replace(/\^9\b/g, '⁹');
  text = text.replace(/\^\{\s*-1\s*\}/g, '⁻¹');
  text = text.replace(/\^\{\s*-2\s*\}/g, '⁻²');
  text = text.replace(/\^\{\s*-3\s*\}/g, '⁻³');
  text = text.replace(/\^\{\s*([0-9a-zA-Z+-]+)\s*\}/g, '^($1)');

  text = text.replace(/_0\b/g, '₀');
  text = text.replace(/_1\b/g, '₁');
  text = text.replace(/_2\b/g, '₂');
  text = text.replace(/_3\b/g, '₃');
  text = text.replace(/_4\b/g, '₄');
  text = text.replace(/_5\b/g, '₅');
  text = text.replace(/_6\b/g, '₆');
  text = text.replace(/_7\b/g, '₇');
  text = text.replace(/_8\b/g, '₈');
  text = text.replace(/_9\b/g, '₉');
  text = text.replace(/_i\b/g, 'ᵢ');
  text = text.replace(/_f\b/g, 'բ');
  text = text.replace(/_n\b/g, 'ₙ');
  text = text.replace(/_x\b/g, 'ₓ');
  text = text.replace(/_y\b/g, 'ᵧ');
  text = text.replace(/_z\b/g, '₂');
  text = text.replace(/_\{([a-zA-Z0-9_-]+)\}/g, '($1)');

  // 12. Cleanup any leftover raw backslashes, braces, and LaTeX commands
  text = text.replace(/\\[a-zA-Z]+/g, ' ');
  text = text.replace(/\\+/g, '');
  text = text.replace(/[{}]/g, '');

  return text;
}

/**
 * Rigorous SVG Sanitizer for Virtual 3D & Smartboard Rendering.
 * Strips all raw markdown code fences (```svg, ```xml, ```markdown, ```),
 * removes raw markdown syntax (**, *, _, `, ~~), strips LaTeX delimiters ($$, $, \[, \]),
 * converts LaTeX math tokens (\Phi, \nu, \vec, \to, etc.) into clean Unicode,
 * and ensures all <text>, <tspan>, <title>, <desc> elements within the SVG contain
 * 100% clean, human-readable labels without raw syntax tokens leaking onto the screen.
 */
export function sanitizeSvgDiagramCode(rawSvg: string): string {
  if (!rawSvg) return '';

  let clean = rawSvg.trim();

  // 1. Strip all code fence tags (```svg, ```xml, ```html, ```markdown, ```) from outside
  clean = clean.replace(/^\s*```(?:svg|xml|html|markdown|md|text|txt|latex)?\s*\n?/i, '');
  clean = clean.replace(/\n?\s*```\s*$/i, '');
  clean = clean.replace(/```(?:svg|xml|html|markdown|md|text|txt|latex)?/gi, '');
  clean = clean.replace(/```/g, '');

  // 2. Extract strictly the <svg ... </svg> content
  const svgMatch = clean.match(/<svg[\s\S]*?<\/svg>/i);
  if (svgMatch) {
    clean = svgMatch[0];
  } else {
    // If opening <svg exists without closing </svg> (e.g. streaming), extract from <svg and close it
    const openMatch = clean.match(/<svg[\s\S]*/i);
    if (openMatch) {
      clean = openMatch[0].trim();
      if (!clean.endsWith('</svg>')) {
        clean += '</svg>';
      }
    }
  }

  if (!clean.includes('<svg')) return '';

  // 3. Clean inside <text ...>...</text> and <tspan ...>...</tspan> nodes
  clean = clean.replace(/(<(?:text|tspan|title|desc)\b[^>]*>)([\s\S]*?)(<\/(?:text|tspan|title|desc)>)/gi, (match, openTag, textContent, closeTag) => {
    let sanitizedText = textContent;

    // A. Strip markdown bold, italic, strikethrough, code backticks
    sanitizedText = sanitizedText.replace(/\*\*\*([^*]+)\*\*\*/g, '$1');
    sanitizedText = sanitizedText.replace(/\*\*([^*]+)\*\*/g, '$1');
    sanitizedText = sanitizedText.replace(/\*([^*]+)\*/g, '$1');
    sanitizedText = sanitizedText.replace(/___([^_]+)___/g, '$1');
    sanitizedText = sanitizedText.replace(/__([^_]+)__/g, '$1');
    sanitizedText = sanitizedText.replace(/_([^_]+)_/g, '$1');
    sanitizedText = sanitizedText.replace(/~~([^~]+)~~/g, '$1');
    sanitizedText = sanitizedText.replace(/`([^`]+)`/g, '$1');
    sanitizedText = sanitizedText.replace(/`+/g, '');

    // B. Convert LaTeX math tokens to Unicode
    sanitizedText = formatLaTeXToUnicode(sanitizedText);

    // C. Strip math delimiters $$, $, \[, \], \(, \)
    sanitizedText = sanitizedText.replace(/\$\$+/g, '');
    sanitizedText = sanitizedText.replace(/\$+/g, '');
    sanitizedText = sanitizedText.replace(/\\\[|\\\]|\\\(|\\\)/g, '');

    // D. Clean lone backslashes and excessive spaces
    sanitizedText = sanitizedText.replace(/\\+/g, '');
    sanitizedText = sanitizedText.replace(/\s+/g, ' ').trim();

    return `${openTag}${sanitizedText}${closeTag}`;
  });

  // 4. Strip any stray markdown symbols that might be outside tags
  clean = clean.replace(/`{1,3}/g, '');

  return clean.trim();
}

/**
 * Universal Fail-Safe Markdown & LaTeX Stripper for Canvas and Video Rendering.
 * Guarantees that ZERO raw markdown formatting tokens (#, **, *, _, $, ``, ~, |, >)
 * leak onto any recorded video frame or blackboard canvas context.
 */
export function stripAllRawMarkdown(rawText: string): string {
  if (!rawText) return '';

  let clean = rawText;

  // 0a. Strip Injected Prompt Echoes & Internal System Directives
  clean = clean.replace(/^[ \t]*>?[ \t]*💬?[ \t]*\*{0,2}(?:Selected Prompt|Prompt Selected)[^\n]*\n?/gim, '');
  clean = clean.replace(/^[ \t]*>?[ \t]*\*{0,2}Tutor Rigor Instructions:[^\n]*\n?/gim, '');
  clean = clean.replace(/^[ \t]*>?[ \t]*\*{0,2}Tutor Instructions:[^\n]*\n?/gim, '');
  clean = clean.replace(/^[ \t]*>?[ \t]*\*{0,2}Please proceed to teach[^\n]*\n?/gim, '');
  clean = clean.replace(/^[ \t]*>?[ \t]*\*{0,2}I want to study the lesson[^\n]*\n?/gim, '');
  clean = clean.replace(/^[ \t]*>?[ \t]*\*{0,2}I want to solve numerical problems[^\n]*\n?/gim, '');
  clean = clean.replace(/^[ \t]*>?[ \t]*\*{0,2}STANDARD depth\/rigor[^\n]*\n?/gim, '');
  clean = clean.replace(/^[ \t]*>?[ \t]*\*{0,2}(?:MASTER CURRICULUM|CRITICAL PEDAGOGICAL|MANDATORY NATURAL|STRICT TOPIC|CRITICAL SMARTBOARD|CRITICAL SELECTION|STRICT ZERO)[^\n]*\n?/gim, '');

  // 0b. Strip Horizontal Delimiter Lines (e.g. ===..., ---..., ___..., ***...)
  clean = clean.replace(/^[ \t]*[=\-_*]{3,}[ \t]*$/gm, '');
  clean = clean.replace(/={4,}/g, '');

  // 0c. Strip AI System Directives & Prompt Meta-Tags (e.g. [AVATAR:...], [SMARTBOARD:...], [TEACHING_GOLDEN_RULE], etc.)
  clean = clean.replace(/\[\s*(?:SMARTBOARD|AVATAR|ANIMATION|FIGURE|ELEMENT|COMPLETE|CONNECTION|COMPARATIVE|LAYERED|INTERACTIVE|EXAM|DYNAMIC|STEP|PHASE|STAGE|DRAW|TYPE|SCROLL|PAUSE|LABEL|SPOTLIGHT|HIGHLIGHT|ZOOM|AUDIO|CAMERA|ACTION|SYNC|SCENE|NOTE|DIRECTIVE|PROMPT|TRIGGER|GESTURE|EXPRESSION|ZONE|INSTRUCTION)\b[^\]]*\]/gi, '');
  clean = clean.replace(/\[[A-Z0-9_\-\s]{2,}\]/g, '');
  clean = clean.replace(/\[[^\]\n]{1,120}\|[^\]\n]{1,120}\]/g, '');
  clean = clean.replace(/(?:^|\n)\s*(?:❌\s*READING:[^\n]*|✅\s*TEACHING:\s*)/gi, '$1');
  clean = clean.replace(/(?:^|\n)\s*Directive:\s*[^\n]*/gi, '$1');

  // 1. Remove HTML/XML tags (e.g. <svg>...</svg>, <br>, <span>)
  clean = clean.replace(/<svg[\s\S]*?<\/svg>/gi, '');
  clean = clean.replace(/<\/?(?:svg|defs|linearGradient|radialGradient|stop|pattern|marker|filter|fe[A-Za-z]+|rect|circle|ellipse|line|polyline|polygon|path|text|tspan|g|clipPath|mask|use|symbol|desc|title)[^>]*>/gi, '');
  clean = clean.replace(/<[^>]+>/g, '');

  // 2. Strip code block backtick fences e.g. ```python or ```
  clean = clean.replace(/```[a-zA-Z0-9_-]*\n?/g, '');
  clean = clean.replace(/```/g, '');

  // 3. Remove blockquote markers e.g. "> " or "> [!NOTE]"
  clean = clean.replace(/^>\s*/gm, '');
  clean = clean.replace(/\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]/gi, '');

  // 4. Strip table divider lines e.g. | :--- | :--- | or | --- |
  clean = clean.replace(/^\|\s*[-:|\s]+\|\s*$/gm, '');

  // 5. Clean table row delimiters: "| Col 1 | Col 2 |" -> "Col 1  •  Col 2"
  clean = clean.replace(/^\|\s*|\s*\|$/gm, '');
  clean = clean.replace(/\|\s*/g, '  •  ');
  clean = clean.replace(/\|/g, '');

  // 6. Strip leading and trailing heading hashes: "#### Title" -> "Title"
  clean = clean.replace(/^[ \t]*#{1,6}\s*(?:\([a-zA-Z0-9\u0900-\u097F]*\)?\s*)?/gm, '');
  clean = clean.replace(/^([ \t]*(?:[-*+•]|\d+[.)]|\([a-zA-Z0-9\u0900-\u097F]+\))\s*)#{1,6}\s*/gm, '$1');
  clean = clean.replace(/\s*#{1,6}$/gm, '');
  clean = clean.replace(/#+/g, '');

  // 7. Strip bold, italic, and underline markdown pairs
  clean = clean.replace(/\*\*\*([^*]+)\*\*\*/g, '$1');
  clean = clean.replace(/\*\*([^*]+)\*\*/g, '$1');
  clean = clean.replace(/\*([^*]+)\*/g, '$1');
  clean = clean.replace(/___([^_]+)___/g, '$1');
  clean = clean.replace(/__([^_]+)__/g, '$1');
  clean = clean.replace(/_([^_]+)_/g, '$1');

  // 8. Strip any dangling or unclosed asterisks / underscores (streaming edge cases)
  clean = clean.replace(/\*+/g, '');
  clean = clean.replace(/_{2,}/g, '');

  // 9. Strip strikethrough: ~~text~~
  clean = clean.replace(/~~([^~]+)~~/g, '$1');
  clean = clean.replace(/~~+/g, '');

  // 10. Strip inline code backticks: `code`
  clean = clean.replace(/`([^`]+)`/g, '$1');
  clean = clean.replace(/`+/g, '');

  // 11. Strip links and images: [text](url) -> text, ![alt](url) -> [Visual: alt]
  clean = clean.replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1');
  clean = clean.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
  clean = clean.replace(/<https?:\/\/[^>]+>/g, '$1');

  // 12. Convert LaTeX to clean Unicode symbols
  clean = formatLaTeXToUnicode(clean);

  // 13. Strip math delimiters: $$, $, \[, \], \(, \)
  clean = clean.replace(/\$\$+/g, '');
  clean = clean.replace(/\$+/g, '');
  clean = clean.replace(/\\\[|\\\]|\\\(|\\\)/g, '');

  // 14. Clean any residual braces or lone backslashes
  clean = clean.replace(/\\+/g, '');
  clean = clean.replace(/[{}]/g, '');

  // 15. Absolute Final Fail-Safe Cleanup
  clean = clean.replace(/[`~|]/g, '');
  clean = clean.replace(/\$+/g, '');

  return clean.trim();
}

/**
 * Strips markdown language enclosures (```markdown, ```md, ```text, ```latex)
 * and unwraps SVG code fences (```svg...```) into clean inline SVG, while eliminating
 * trailing or dangling code fence tokens (```) from raw AI streams before passing to 3D visualizers.
 */
export function stripMarkdownCodeFencesAndDelimiters(rawText: string, isLiveStreaming = false): string {
  if (!rawText) return '';

  let text = rawText;

  // 1. Unwrap entire document code block wrappers if wrapped in ```markdown ... ``` or ```md ... ``` or ```text ... ```
  text = text.replace(/^\s*```(?:markdown|md|text|txt|latex)?\s*\n([\s\S]*?)(?:\n\s*```\s*)?$/i, '$1');

  // 2. Detect and unwrap ```svg ... ``` or ```xml ... ``` containing <svg> elements into clean raw SVG
  text = text.replace(/```(?:svg|xml|html)?\s*\n\s*(<svg[\s\S]*?<\/svg>)\s*\n?```/gi, (match, svgContent) => {
    return `\n\n${sanitizeSvgDiagramCode(svgContent)}\n\n`;
  });
  // Handle streaming/partial unclosed ```svg <svg...>
  text = text.replace(/```(?:svg|xml|html)?\s*\n\s*(<svg[\s\S]*?>)/gi, '\n\n$1');

  // 3. Remove standalone opening or closing ```markdown, ```md, ```text, ```latex fence lines
  text = text.replace(/^[ \t]*```(?:markdown|md|text|txt|latex)[ \t]*$/gim, '');

  // 4. Strip trailing code fence markers in live streaming chunks (e.g. trailing "```markdown", "```svg", "```", "``", "`")
  if (isLiveStreaming) {
    text = text.replace(/(?:\r?\n|^)[ \t]*```(?:markdown|md|svg|xml|text|latex)?[ \t]*$/gi, '');
    text = text.replace(/`{1,3}$/g, '');
  } else {
    // Strip trailing dangling code fence if no open code block exists or at the very end of string
    text = text.replace(/(?:\r?\n)[ \t]*```[ \t]*$/g, '');
  }

  // 5. Clean up any lone ``` on a single line that does not enclose valid programming code
  // If the total number of ``` is odd, strip the last dangling ```
  const fenceMatches = text.match(/```/g) || [];
  if (fenceMatches.length % 2 !== 0) {
    const lastFenceIdx = text.lastIndexOf('```');
    if (lastFenceIdx !== -1) {
      text = text.substring(0, lastFenceIdx) + text.substring(lastFenceIdx + 3);
    }
  }

  return text;
}

/**
 * cleanStreamingMarkdown
 * Pre-processes any markdown string before it is rendered on smartboard, canvas recording engine,
 * or ReactMarkdown to completely eliminate raw syntax flashing during streaming and live typewriter updates.
 */
export function cleanStreamingMarkdown(rawText: string, isLiveStreaming = false): string {
  if (!rawText) return '';

  let processed = rawText;

  // 0. Strip markdown code fences, ```markdown, ```svg, and trailing fence characters
  processed = stripMarkdownCodeFencesAndDelimiters(processed, isLiveStreaming);

  // Strip AI internal system directives & prompt tags
  processed = processed.replace(/\[\s*(?:SMARTBOARD|AVATAR|ANIMATION|FIGURE|ELEMENT|COMPLETE|CONNECTION|COMPARATIVE|LAYERED|INTERACTIVE|EXAM|DYNAMIC|STEP|PHASE|STAGE|DRAW|TYPE|SCROLL|PAUSE|LABEL|SPOTLIGHT|HIGHLIGHT|ZOOM|AUDIO|CAMERA|ACTION|SYNC|SCENE|NOTE|DIRECTIVE|PROMPT|TRIGGER|GESTURE|EXPRESSION|ZONE|INSTRUCTION)\b[^\]]*\]/gi, '');
  processed = processed.replace(/\[[A-Z0-9_\-\s]{2,}\]/g, '');
  processed = processed.replace(/\[[^\]\n]{1,120}\|[^\]\n]{1,120}\]/g, '');
  processed = processed.replace(/(?:^|\n)\s*(?:❌\s*READING:[^\n]*|✅\s*TEACHING:\s*)/gi, '$1');
  processed = processed.replace(/(?:^|\n)\s*Directive:\s*[^\n]*/gi, '$1');

  if (isLiveStreaming) {
    processed = StreamingBuffer.sanitizeLiveStreamText(processed);
  }

  // 1. Normalize indented markdown headers so they aren't parsed as raw code fences
  processed = processed.replace(/^[ \t]+(#{1,6})\s+/gm, '$1 ');

  // 2. Remove hashes after bullet points: "- #### Title" -> "- Title"
  processed = processed.replace(/^([ \t]*[-*+•]\s*)#{1,6}\s*/gm, '$1');

  // 3. Remove trailing dangling hashes
  processed = processed.replace(/(?:^|\n)[ \t]*#{1,6}\s*(?:\([a-zA-Z0-9\u0900-\u097F]*\)?\s*)?$/g, '');

  return processed;
}

