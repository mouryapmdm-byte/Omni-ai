import React, { useRef, useState, useEffect, useCallback } from 'react';
import { createWorker } from 'tesseract.js';
import { 
  Eraser, 
  Search, 
  Trash2, 
  Palette, 
  Share2, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Sliders, 
  RotateCcw,
  Layers,
  Wand2,
  Maximize2
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { playChalkSound, playDiagramThud, playEquationChalkScratch, playChalkColorSwitchSound, isChalkSoundEnabled, setChalkSoundEnabled } from '@/src/lib/chalkAudio';
import { ChalkColor, CHALK_COLOR_PALETTES } from '@/src/types';

interface HandwritingRecognizerProps {
  onRecognized: (text: string) => void;
}

interface Point {
  x: number;
  y: number;
  time: number;
  speed: number;
  width: number;
}

interface DustParticle {
  x: number;
  y: number;
  size: number;
  alpha: number;
  color: string;
}

type BoardTheme = 'classroom-slate' | 'vintage-green' | 'midnight-obsidian' | 'clean-whiteboard';

const BOARD_THEMES: { id: BoardTheme; label: string; bg: string; border: string; defaultChalk: string }[] = [
  { 
    id: 'classroom-slate', 
    label: 'Classroom Slate', 
    bg: '#1e293b', 
    border: 'border-slate-700',
    defaultChalk: '#f8fafc' 
  },
  { 
    id: 'vintage-green', 
    label: 'Vintage Green', 
    bg: '#064e3b', 
    border: 'border-emerald-800',
    defaultChalk: '#fef08a' 
  },
  { 
    id: 'midnight-obsidian', 
    label: 'Midnight Obsidian', 
    bg: '#090d16', 
    border: 'border-slate-800',
    defaultChalk: '#38bdf8' 
  },
  { 
    id: 'clean-whiteboard', 
    label: 'Clean Whiteboard', 
    bg: '#ffffff', 
    border: 'border-slate-300',
    defaultChalk: '#1e293b' 
  }
];

const CHALK_COLORS = [
  { name: 'Calcium White', value: '#f8fafc', wbValue: '#0f172a' },
  { name: 'Classroom Yellow', value: '#fde047', wbValue: '#d97706' },
  { name: 'Blackboard Cyan', value: '#38bdf8', wbValue: '#0284c7' },
  { name: 'Soft Mint', value: '#4ade80', wbValue: '#16a34a' },
  { name: 'Coral Orange', value: '#fb923c', wbValue: '#ea580c' },
  { name: 'Pastel Violet', value: '#c084fc', wbValue: '#7c3aed' },
  { name: 'Rose Pink', value: '#f43f5e', wbValue: '#e11d48' }
];

export const HandwritingRecognizer: React.FC<HandwritingRecognizerProps> = ({
  onRecognized
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dustCanvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Interaction State
  const [isDrawing, setIsDrawing] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isEraser, setIsEraser] = useState(false);
  const [selectedBoard, setSelectedBoard] = useState<BoardTheme>('classroom-slate');
  const [selectedColor, setSelectedColor] = useState(CHALK_COLORS[0].value);
  const [baseChalkSize, setBaseChalkSize] = useState<number>(3.5); // 2 to 8 px

  // Physics Simulation Settings
  const [enableChalkPhysics, setEnableChalkPhysics] = useState<boolean>(true);
  const [enableDustArtifacts, setEnableDustArtifacts] = useState<boolean>(true);
  const [enableJitter, setEnableJitter] = useState<boolean>(true);
  const [enableChalkAudio, setEnableChalkAudio] = useState<boolean>(() => isChalkSoundEnabled());
  const [showPhysicsDrawer, setShowPhysicsDrawer] = useState<boolean>(false);
  const [dustIntensity, setDustIntensity] = useState<'subtle' | 'moderate' | 'dense'>('moderate');

  // Stroke Tracking Refs for Physics Engine
  const lastPointRef = useRef<Point | null>(null);
  const strokeLengthRef = useRef<number>(0);
  const soundThrottleRef = useRef<number>(0);
  const dustParticlesRef = useRef<DustParticle[]>([]);

  const isDarkBoard = selectedBoard !== 'clean-whiteboard';

  // Get active stroke color depending on board mode
  const getEffectiveColor = useCallback(() => {
    const colorObj = CHALK_COLORS.find(c => c.value === selectedColor || c.wbValue === selectedColor);
    if (!colorObj) return selectedColor;
    return isDarkBoard ? colorObj.value : colorObj.wbValue;
  }, [selectedColor, isDarkBoard]);

  // Redraw background texture on board change
  const redrawBoardBackground = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const theme = BOARD_THEMES.find(t => t.id === selectedBoard) || BOARD_THEMES[0];
    
    if (theme.id === 'clean-whiteboard') {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);
      // Subtle dry-erase grid
      ctx.strokeStyle = '#f1f5f9';
      ctx.lineWidth = 1;
      const gridSize = 28;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
      return;
    }

    // Classroom Blackboard Background with Authentic Slate Grain
    ctx.fillStyle = theme.bg;
    ctx.fillRect(0, 0, width, height);

    // Blackboard Matte Texture Simulation
    const grainCanvas = document.createElement('canvas');
    grainCanvas.width = 120;
    grainCanvas.height = 120;
    const gCtx = grainCanvas.getContext('2d');
    if (gCtx) {
      const imgData = gCtx.createImageData(120, 120);
      const data = imgData.data;
      for (let i = 0; i < data.length; i += 4) {
        const noise = (Math.random() - 0.5) * 16;
        data[i] = 255;
        data[i + 1] = 255;
        data[i + 2] = 255;
        data[i + 3] = Math.max(0, Math.min(25, noise + 8));
      }
      gCtx.putImageData(imgData, 0, 0);
      const pattern = ctx.createPattern(grainCanvas, 'repeat');
      if (pattern) {
        ctx.fillStyle = pattern;
        ctx.fillRect(0, 0, width, height);
      }
    }

    // Subtle faint chalkboard grid for handwriting alignment
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.035)';
    ctx.lineWidth = 1;
    const lineSpacing = 32;
    for (let y = lineSpacing; y < height; y += lineSpacing) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  }, [selectedBoard]);

  // Initialize Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    redrawBoardBackground(ctx, canvas.width, canvas.height);
  }, [selectedBoard, redrawBoardBackground]);

  // Handle Dynamic Resizing without losing user's handwriting
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    const dustCanvas = dustCanvasRef.current;
    if (!container || !canvas) return;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width <= 0 || height <= 0) continue;

        // Save current drawn content
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        const tempCtx = tempCanvas.getContext('2d');
        if (tempCtx) {
          tempCtx.drawImage(canvas, 0, 0);
        }

        // Apply new dimensions
        canvas.width = width;
        canvas.height = height;
        if (dustCanvas) {
          dustCanvas.width = width;
          dustCanvas.height = height;
        }

        // Restore content on resized board
        const ctx = canvas.getContext('2d');
        if (ctx) {
          redrawBoardBackground(ctx, width, height);
          ctx.drawImage(tempCanvas, 0, 0);
        }
      }
    });

    resizeObserver.observe(container);
    return () => resizeObserver.disconnect();
  }, [redrawBoardBackground]);

  // Chalk Sound Toggle handler
  const handleToggleAudio = () => {
    const nextState = !enableChalkAudio;
    setEnableChalkAudio(nextState);
    setChalkSoundEnabled(nextState);
    if (nextState) {
      playChalkSound('tap', 0.2);
    }
  };

  // CHALKBOARD PHYSICS SIMULATION: Draw chalk stroke with dynamic velocity, jitter, multi-bristle fibers & dust
  const renderChalkPhysicsSegment = (
    ctx: CanvasRenderingContext2D,
    p1: Point,
    p2: Point,
    color: string,
    eraser: boolean
  ) => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 0.5) return;

    // Normal unit vectors
    const nx = -dy / dist;
    const ny = dx / dist;

    // Eraser Physics: Soft felt eraser sweep with fade
    if (eraser) {
      const eraserRadius = baseChalkSize * 5;
      const steps = Math.max(1, Math.floor(dist / 4));
      
      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        const cx = p1.x + dx * t;
        const cy = p1.y + dy * t;

        // Erase area
        ctx.save();
        ctx.beginPath();
        ctx.arc(cx, cy, eraserRadius, 0, Math.PI * 2);
        ctx.clip();
        redrawBoardBackground(ctx, ctx.canvas.width, ctx.canvas.height);
        ctx.restore();
      }
      return;
    }

    // Chalk Writing Physics
    if (!enableChalkPhysics) {
      // Standard smooth pen fallback
      ctx.save();
      ctx.strokeStyle = color;
      ctx.lineWidth = baseChalkSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
      ctx.restore();
      return;
    }

    // 1. Variable Line Weight based on Stroke Speed
    // Slower movements deposit more chalk (thicker), fast flicks taper down
    const avgWidth = (p1.width + p2.width) / 2;
    const steps = Math.max(1, Math.ceil(dist / 2.5));

    ctx.save();
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const curX = p1.x + dx * t;
      const curY = p1.y + dy * t;
      const curWidth = p1.width + (p2.width - p1.width) * t;

      // 2. Micro-Jitter / Tactile Slate Friction
      const jitterFactor = enableJitter ? (Math.random() - 0.5) * (curWidth * 0.22) : 0;
      const jx = curX + nx * jitterFactor;
      const jy = curY + ny * jitterFactor;

      // 3. Multi-Strand Calcium Grain Deposition (Porous Chalk Fibers)
      const numFibers = Math.max(3, Math.min(7, Math.floor(curWidth * 1.2)));
      for (let f = 0; f < numFibers; f++) {
        const fiberOffset = ((f / (numFibers - 1)) - 0.5) * curWidth;
        const fiberJitter = enableJitter ? (Math.random() - 0.5) * 0.8 : 0;
        const fx = jx + nx * (fiberOffset + fiberJitter);
        const fy = jy + ny * (fiberOffset + fiberJitter);

        // Core opacity with organic falloff near edges
        const distFromCenter = Math.abs(fiberOffset) / (curWidth / 2 || 1);
        const opacity = Math.max(0.15, (1 - distFromCenter * 0.55) * (0.65 + Math.random() * 0.35));

        ctx.fillStyle = color;
        ctx.globalAlpha = opacity;
        ctx.beginPath();
        const dotSize = Math.max(0.8, (curWidth / numFibers) * (0.8 + Math.random() * 0.4));
        ctx.arc(fx, fy, dotSize / 2, 0, Math.PI * 2);
        ctx.fill();
      }

      // 4. Subtle Chalk-Dust Artifacts (Calcium Carbonate Particles)
      if (enableDustArtifacts && isDarkBoard && Math.random() < (dustIntensity === 'dense' ? 0.35 : dustIntensity === 'moderate' ? 0.20 : 0.08)) {
        const dustDist = (Math.random() * 2.5 - 1.25) * curWidth;
        const dustX = curX + nx * dustDist + (Math.random() - 0.5) * 3;
        const dustY = curY + ny * dustDist + (Math.random() - 0.5) * 3;
        const dustSize = 0.6 + Math.random() * 1.6;
        const dustAlpha = 0.15 + Math.random() * 0.4;

        ctx.fillStyle = color;
        ctx.globalAlpha = dustAlpha;
        ctx.beginPath();
        ctx.arc(dustX, dustY, dustSize / 2, 0, Math.PI * 2);
        ctx.fill();

        // Register particle
        dustParticlesRef.current.push({
          x: dustX,
          y: dustY,
          size: dustSize,
          alpha: dustAlpha,
          color
        });
      }
    }
    ctx.restore();
  };

  // Start Drawing Contact
  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = ('touches' in e) ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = ('touches' in e) ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    const initialPoint: Point = {
      x,
      y,
      time: performance.now(),
      speed: 0,
      width: baseChalkSize
    };
    lastPointRef.current = initialPoint;
    strokeLengthRef.current = 0;

    // Contact tap: Chalk impulse & audio
    if (enableChalkAudio) {
      playChalkSound(isEraser ? 'dust' : 'tap', 0.2);
    }

    // Initial contact mark
    if (!isEraser) {
      renderChalkPhysicsSegment(
        ctx,
        initialPoint,
        { ...initialPoint, x: x + 0.1, y: y + 0.1 },
        getEffectiveColor(),
        false
      );
    }
  };

  // Continuous Dynamic Stroke with Physics
  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !lastPointRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if ('touches' in e && e.cancelable) {
      e.preventDefault();
    }

    const rect = canvas.getBoundingClientRect();
    const clientX = ('touches' in e) ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = ('touches' in e) ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    const now = performance.now();
    const prev = lastPointRef.current;
    const dt = Math.max(1, now - prev.time);
    const dist = Math.hypot(x - prev.x, y - prev.y);

    if (dist < 1) return;

    // Compute velocity (px/ms)
    const instantaneousSpeed = dist / dt;
    const smoothedSpeed = 0.65 * prev.speed + 0.35 * instantaneousSpeed;

    // Dynamic Line Weight Calculation:
    // Slower speed => thicker, richer deposit. Higher speed => thinner, brittle stroke.
    const speedRatio = Math.min(2.5, smoothedSpeed);
    const targetWidth = enableChalkPhysics 
      ? Math.max(baseChalkSize * 0.6, Math.min(baseChalkSize * 1.65, baseChalkSize * (1.35 - speedRatio * 0.32)))
      : baseChalkSize;
    const smoothedWidth = 0.55 * prev.width + 0.45 * targetWidth;

    const currentPoint: Point = {
      x,
      y,
      time: now,
      speed: smoothedSpeed,
      width: smoothedWidth
    };

    // Render physics-guided chalk segment
    renderChalkPhysicsSegment(ctx, prev, currentPoint, getEffectiveColor(), isEraser);

    lastPointRef.current = currentPoint;
    strokeLengthRef.current += dist;

    // Tactile Chalk Scratch Audio Synthesizer: triggers periodic pitch-shifted micro-scratches during continuous stroke
    if (enableChalkAudio && !isEraser && strokeLengthRef.current - soundThrottleRef.current > 48) {
      soundThrottleRef.current = strokeLengthRef.current;
      playEquationChalkScratch(strokeLengthRef.current, 0.18);
    }
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    lastPointRef.current = null;
  };

  // Clear & Wipe Canvas with Chalk Dust Sweep
  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (enableChalkAudio) {
      playChalkSound('dust', 0.35);
    }
    redrawBoardBackground(ctx, canvas.width, canvas.height);
    dustParticlesRef.current = [];
  };

  // OCR Recognition with High-Contrast Binarization
  const recognize = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    setIsProcessing(true);
    try {
      // Create high-contrast binarized canvas for optimal OCR accuracy
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = canvas.width;
      tempCanvas.height = canvas.height;
      const tempCtx = tempCanvas.getContext('2d');
      if (tempCtx) {
        // Pure white background
        tempCtx.fillStyle = '#ffffff';
        tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
        
        // Extract raw pixel data from original canvas
        const srcCtx = canvas.getContext('2d');
        if (srcCtx) {
          const srcImgData = srcCtx.getImageData(0, 0, canvas.width, canvas.height);
          const srcData = srcImgData.data;
          const dstImgData = tempCtx.createImageData(canvas.width, canvas.height);
          const dstData = dstImgData.data;

          // Binarize: Any chalk stroke becomes solid black, background becomes pure white
          for (let i = 0; i < srcData.length; i += 4) {
            const r = srcData[i];
            const g = srcData[i + 1];
            const b = srcData[i + 2];
            
            // Check if pixel deviates from the background slate
            const isChalkPixel = isDarkBoard 
              ? (r > 65 || g > 85 || b > 75) // Bright chalk on dark slate
              : (r < 220 || g < 220 || b < 220); // Dark ink on whiteboard

            if (isChalkPixel) {
              dstData[i] = 0;     // Black text
              dstData[i + 1] = 0;
              dstData[i + 2] = 0;
              dstData[i + 3] = 255;
            } else {
              dstData[i] = 255;   // White background
              dstData[i + 1] = 255;
              dstData[i + 2] = 255;
              dstData[i + 3] = 255;
            }
          }
          tempCtx.putImageData(dstImgData, 0, 0);
        }
      }

      const worker = await createWorker('eng');
      const { data: { text } } = await worker.recognize(tempCanvas.toDataURL('image/png'));
      await worker.terminate();
      
      const cleaned = text.trim();
      if (enableChalkAudio) {
        playDiagramThud(0.32);
      }
      onRecognized(cleaned);
    } catch (error) {
      console.error('OCR Recognition failed:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  // Share or Copy Board Drawing
  const handleShare = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png'));
      if (!blob) return;

      if (navigator.share && navigator.canShare({ files: [new File([blob], 'classroom-chalkboard.png', { type: 'image/png' })] })) {
        await navigator.share({
          files: [new File([blob], 'classroom-chalkboard.png', { type: 'image/png' })],
          title: 'Classroom Chalkboard Handwriting',
          text: 'Check out my handwritten notes & derivations in Omni AI Classroom!'
        });
      } else {
        const item = new ClipboardItem({ 'image/png': blob });
        await navigator.clipboard.write([item]);
        alert('Chalkboard drawing copied to clipboard!');
      }
    } catch (error) {
      console.error('Sharing failed:', error);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-3 font-sans">
      {/* Top Controls Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-1 flex-shrink-0 bg-slate-900/60 p-2.5 rounded-2xl border border-slate-800 backdrop-blur-md">
        
        {/* Chalk Color Palette */}
        <div className="flex items-center gap-2.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5 pl-1">
            <Palette size={13} />
            <span>Chalk</span>
          </span>
          <div className="flex items-center gap-1.5 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
            {CHALK_COLORS.map((color) => {
              const effectiveVal = isDarkBoard ? color.value : color.wbValue;
              const isSelected = selectedColor === color.value || selectedColor === color.wbValue;
              return (
                <button
                  key={color.name}
                  onClick={() => {
                    setSelectedColor(effectiveVal);
                    setIsEraser(false);
                    if (enableChalkAudio) {
                      playChalkColorSwitchSound(color.name.toLowerCase().includes('yellow') ? 'yellow' : color.name.toLowerCase().includes('cyan') || color.name.toLowerCase().includes('blue') ? 'blue' : color.name.toLowerCase().includes('coral') || color.name.toLowerCase().includes('orange') ? 'red' : 'white');
                    }
                  }}
                  className={cn(
                    "w-5 h-5 rounded-full transition-all border relative flex items-center justify-center",
                    !isEraser && isSelected 
                      ? "scale-125 ring-2 ring-amber-400 border-white shadow-md" 
                      : "border-white/20 hover:scale-110 opacity-80 hover:opacity-100"
                  )}
                  style={{ backgroundColor: effectiveVal }}
                  title={color.name}
                />
              );
            })}
          </div>
        </div>

        {/* Board Surface Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-950/60 p-1 rounded-xl border border-slate-800 text-xs">
          <span className="text-[10px] font-bold text-slate-400 px-1.5 flex items-center gap-1">
            <Layers size={11} /> Board
          </span>
          {BOARD_THEMES.map((theme) => (
            <button
              key={theme.id}
              onClick={() => {
                setSelectedBoard(theme.id);
                setSelectedColor(theme.defaultChalk);
              }}
              className={cn(
                "px-2 py-0.5 rounded-lg text-[11px] font-bold transition-all",
                selectedBoard === theme.id 
                  ? "bg-amber-400 text-slate-950 shadow-sm" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
              )}
            >
              {theme.label.split(' ')[0]}
            </button>
          ))}
        </div>

        {/* Action Tools: Physics Toggle, Sound, Eraser, Share */}
        <div className="flex items-center gap-1.5">
          {/* Chalkboard Physics Toggle */}
          <button
            onClick={() => setShowPhysicsDrawer(!showPhysicsDrawer)}
            className={cn(
              "flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold transition-all border",
              enableChalkPhysics 
                ? "bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-inner" 
                : "bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700"
            )}
            title="Chalkboard Physics Simulation Settings"
          >
            <Sparkles size={13} className={enableChalkPhysics ? "text-amber-400 animate-spin-slow" : ""} />
            <span>Physics</span>
          </button>

          {/* Chalk Audio SFX */}
          <button
            onClick={handleToggleAudio}
            className={cn(
              "p-1.5 rounded-xl text-xs font-bold transition-all border",
              enableChalkAudio 
                ? "bg-sky-500/20 text-sky-300 border-sky-500/40" 
                : "bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700"
            )}
            title={enableChalkAudio ? "Chalk Sound FX Active" : "Chalk Sound Muted"}
          >
            {enableChalkAudio ? <Volume2 size={14} /> : <VolumeX size={14} />}
          </button>

          {/* Eraser */}
          <button
            onClick={() => setIsEraser(!isEraser)}
            className={cn(
              "flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold transition-all border",
              isEraser 
                ? "bg-rose-500 text-white border-rose-400 shadow-md ring-2 ring-rose-300/40" 
                : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
            )}
            title="Classroom Felt Eraser"
          >
            <Eraser size={13} />
            <span>Felt Eraser</span>
          </button>

          {/* Share */}
          <button
            onClick={handleShare}
            className="p-1.5 rounded-xl text-xs font-bold bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 transition-all"
            title="Share or Copy Chalkboard Drawing"
          >
            <Share2 size={14} />
          </button>
        </div>
      </div>

      {/* Chalkboard Physics Tuning Drawer */}
      {showPhysicsDrawer && (
        <div className="bg-slate-900/90 border border-amber-400/30 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs backdrop-blur-md animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-2">
            <span className="font-bold text-amber-300 flex items-center gap-1">
              <Sparkles size={14} /> Physics Simulation:
            </span>
            <button
              onClick={() => setEnableChalkPhysics(!enableChalkPhysics)}
              className={cn(
                "px-2 py-0.5 rounded-lg font-bold border",
                enableChalkPhysics 
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" 
                  : "bg-slate-800 text-slate-400 border-slate-700"
              )}
            >
              {enableChalkPhysics ? 'Authentic Chalk' : 'Standard Smooth'}
            </button>
          </div>

          {/* Jitter Toggle */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Micro-Jitter:</span>
            <button
              onClick={() => setEnableJitter(!enableJitter)}
              disabled={!enableChalkPhysics}
              className={cn(
                "px-2 py-0.5 rounded-lg font-bold border transition-all",
                enableJitter && enableChalkPhysics
                  ? "bg-amber-400/20 text-amber-300 border-amber-400/40" 
                  : "bg-slate-800 text-slate-500 border-slate-700"
              )}
            >
              {enableJitter ? 'Tactile Grit' : 'Disabled'}
            </button>
          </div>

          {/* Chalk-Dust Artifacts Toggle */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Chalk-Dust Artifacts:</span>
            <div className="flex gap-1">
              {(['subtle', 'moderate', 'dense'] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => {
                    setEnableDustArtifacts(true);
                    setDustIntensity(level);
                  }}
                  disabled={!enableChalkPhysics}
                  className={cn(
                    "px-2 py-0.5 rounded-lg text-[10px] font-bold capitalize border transition-all",
                    enableDustArtifacts && dustIntensity === level && enableChalkPhysics
                      ? "bg-sky-400/20 text-sky-300 border-sky-400/40"
                      : "bg-slate-800 text-slate-500 border-slate-700"
                  )}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          {/* Chalk Stick Size */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Chalk Stick:</span>
            <div className="flex gap-1">
              {[
                { size: 2.2, label: 'Fine' },
                { size: 3.8, label: 'Medium' },
                { size: 6.5, label: 'Broad' }
              ].map((s) => (
                <button
                  key={s.label}
                  onClick={() => setBaseChalkSize(s.size)}
                  className={cn(
                    "px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-all",
                    baseChalkSize === s.size 
                      ? "bg-amber-400 text-slate-950 border-amber-400 font-black" 
                      : "bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200"
                  )}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Interactive Chalkboard Canvas Container */}
      <div 
        ref={containerRef}
        className={cn(
          "relative rounded-3xl border-4 overflow-hidden touch-none resize overflow-auto min-h-[340px] flex-1 shadow-2xl transition-all",
          selectedBoard === 'classroom-slate' ? "border-slate-700 bg-slate-900 shadow-slate-950/80" :
          selectedBoard === 'vintage-green' ? "border-emerald-900 bg-emerald-950 shadow-emerald-950/80" :
          selectedBoard === 'midnight-obsidian' ? "border-slate-800 bg-slate-950 shadow-black" :
          "border-slate-300 bg-white shadow-slate-200"
        )}
        style={{ width: '100%' }}
      >
        {/* Blackboard Frame Corner Accents */}
        <div className="absolute top-2 left-2 z-10 pointer-events-none flex items-center gap-2">
          <div className="bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-xl border border-white/10 text-[10px] font-mono text-amber-300 flex items-center gap-1.5 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span>Classroom Chalkboard • {enableChalkPhysics ? 'Physics Active' : 'Standard'}</span>
          </div>
          {enableDustArtifacts && isDarkBoard && enableChalkPhysics && (
            <div className="bg-black/50 px-2 py-0.5 rounded-lg border border-white/5 text-[9px] font-mono text-slate-400">
              Dust Artifacts: {dustIntensity}
            </div>
          )}
        </div>

        {/* Main Canvas */}
        <canvas
          ref={canvasRef}
          className="cursor-crosshair block w-full h-full"
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
        />

        {/* Resize Handle Icon */}
        <div className="absolute bottom-2 right-2 w-6 h-6 pointer-events-none opacity-40 flex items-end justify-end p-1 text-slate-400">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15 1L1 15M15 6L6 15M15 11L11 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>

        {/* OCR Processing Overlay */}
        {isProcessing && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center gap-3 z-30 animate-in fade-in duration-150">
            <div className="relative">
              <div className="w-12 h-12 border-4 border-amber-400 border-t-transparent rounded-full animate-spin" />
              <Sparkles size={16} className="absolute inset-0 m-auto text-amber-300" />
            </div>
            <div className="text-sm font-black text-amber-300 tracking-wide">
              Analyzing Handwritten Chalkboard Symbols...
            </div>
            <div className="text-xs text-slate-400 font-mono">
              Extracting math formulas, equations & text
            </div>
          </div>
        )}
      </div>

      {/* Bottom Action Buttons */}
      <div className="flex gap-3 flex-shrink-0 pt-1">
        <button 
          className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
          onClick={clearCanvas}
          title="Wipe chalkboard clean with felt duster"
        >
          <Trash2 size={16} className="text-rose-400" /> 
          <span>Wipe Board</span>
        </button>

        <button 
          className="flex-[1.5] py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 rounded-2xl font-black flex items-center justify-center gap-2 shadow-lg shadow-amber-900/30 transition-all disabled:opacity-50 active:scale-95"
          onClick={recognize}
          disabled={isProcessing}
        >
          <Search size={18} />
          <span>Recognize Handwriting (OCR)</span>
        </button>
      </div>
    </div>
  );
};
