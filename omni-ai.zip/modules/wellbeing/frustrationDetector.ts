export * from '../../src/modules/wellbeing/frustrationDetector';
