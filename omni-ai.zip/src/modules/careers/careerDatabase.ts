export interface Career {
  id: string;
  title: string;
  description: string;
  requiredSubjects: string[];
  keySkills: string[];
  educationPath: string[];
  entryExams: string[];
  avgSalaryRange: { min: number; max: number; currency: string };
  growthOutlook: 'high' | 'medium' | 'stable' | 'declining';
  chapterConnections: { chapterId: string; application: string }[];
}

export interface VideoQuiz {
  question: string;
  options: string[];
  correctAnswerIdx: number;
  explanation: string;
}

export interface ProfessionalVideo {
  id: string;
  title: string;
  role: string;
  speaker: string;
  duration: string;
  embedUrl: string;
  conceptsTaught: string[];
  description: string;
  transcript: { time: string; text: string }[];
  quiz?: VideoQuiz;
}

export interface College {
  name: string;
  location: string;
  requiredGpa: number;
  entryRequirements: string[];
  notableScholarships: { name: string; amount: string; eligibility: string }[];
}

export const careerDatabase: Career[] = [
  {
    id: 'quantum_architect',
    title: 'Quantum Hardware Architect',
    description: 'Design and fabricate superconducting Josephson-junction qubits, optics systems, and control signals for quantum processors.',
    requiredSubjects: ['Physics', 'Mathematics', 'Computer Science'],
    keySkills: ['Superconductivity', 'Bloch Sphere Linear Algebra', 'Optics Ray Tracing', 'Qiskit Python', 'Cryogenics', 'Cleanroom Protocols', 'RF Engineering', 'Microwave Electronics', 'Thin-Film Deposition', 'Quantum Error Correction'],
    educationPath: ['B.Sc. in Engineering Physics', 'M.Sc. in Applied Physics', 'Ph.D. in Condensed Matter Physics'],
    entryExams: ['GRE Physics', 'Graduate School Admissions Interview', 'FE Electrical'],
    avgSalaryRange: { min: 145000, max: 210000, currency: 'USD' },
    growthOutlook: 'high',
    chapterConnections: [
      { chapterId: 'physics_vectors', application: 'Resolving electromagnetic fields and quantum state vectors on the Bloch sphere.' },
      { chapterId: 'physics_kinematics', application: 'Modeling microwave excitation pulse trajectory intervals.' },
      { chapterId: 'math_vectors', application: 'Using Cartesian coordinate systems to configure quantum state matrices.' },
      { chapterId: 'math_trig', application: 'Formulating alternating RF waves to excite superconducting qubits at exact resonant frequencies.' },
      { chapterId: 'chem_thermo', application: 'Designing dilution refrigerator heat sinks to keep qubits operating at 10 millikelvin.' }
    ]
  },
  {
    id: 'biomedical_engineer',
    title: 'Biomedical & Protein Folding Scientist',
    description: 'Use deep machine learning models and structural biology protocols to predict amino acid configurations and dock therapeutic enzyme inhibitors.',
    requiredSubjects: ['Biology', 'Chemistry', 'Computer Science'],
    keySkills: ['AlphaFold Analysis', 'PyMOL 3D Modeling', 'CRISPR Target Design', 'Spectroscopy', 'Enzyme Kinetics', 'Python Bioinformatics', 'Mass Spectrometry', 'High-Performance Computing', 'Thermodynamic Docking', 'Peptide Synthesis'],
    educationPath: ['B.S. in Bioinformatics or Biotech', 'M.Sc. in Computational Medicine', 'Ph.D. in Biophysics'],
    entryExams: ['MCAT', 'Bioinformatics Entrance Exam', 'GRE Biochemistry'],
    avgSalaryRange: { min: 110000, max: 180000, currency: 'USD' },
    growthOutlook: 'high',
    chapterConnections: [
      { chapterId: 'biology_photosynthesis', application: 'Analyzing electron transport chains to optimize photosynthetic yield in synthetic plants.' },
      { chapterId: 'chem_reactions', application: 'Mapping organic condensation reactions for structural capsid docking and viral neutralization.' },
      { chapterId: 'math_calculus_diff', application: 'Applying logistic differential curves to pharmacokinetic release rates of drug carriers.' },
      { chapterId: 'chem_thermo', application: 'Calculating Gibbs free energy change delta-G to predict spontaneous protein folding pathways.' },
      { chapterId: 'math_vectors', application: 'Using structural atom coordinates as vectors in 3D Euclidean space to analyze bonding angles.' }
    ]
  },
  {
    id: 'renewable_architect',
    title: 'Renewable Photovoltaic Architect',
    description: 'Design high-efficiency crystalline semiconductor grids and perovskite-based solar arrays to maximize photon capture and electrical conversion.',
    requiredSubjects: ['Physics', 'Chemistry', 'Mathematics'],
    keySkills: ['Perovskite Photovoltaics', 'Electrochemistry', 'Sinusoidal Elevation Trig', 'Inverter Grids', 'CAD Solar Modeling', 'Smart-Grid Systems', 'Energy Storage Cathodes', 'Spectroscopic Reflectance', 'P-N Junction Physics', 'Load Balancing'],
    educationPath: ['B.S. in Material Science or Electrical Engineering', 'PE Certification', 'Master of Renewable Energy Systems'],
    entryExams: ['FE (Fundamentals of Engineering)', 'PE (Professional Engineer)'],
    avgSalaryRange: { min: 95000, max: 155000, currency: 'USD' },
    growthOutlook: 'high',
    chapterConnections: [
      { chapterId: 'math_trig', application: 'Using sinusoidal trigonometric functions to calculate seasonally optimal solar panel inclinations.' },
      { chapterId: 'chem_thermo', application: 'Optimizing thermal heat dissipation of high-current power grid inverters.' },
      { chapterId: 'physics_kinematics', application: 'Modeling planetary rotation angles and elevation velocities to program active dual-axis trackers.' },
      { chapterId: 'physics_vectors', application: 'Resolving incident solar radiation vectors into normal and tangential surface components.' },
      { chapterId: 'chem_reactions', application: 'Sustaining reversible electrochemical redox reactions inside high-capacity lithium-sulfur backing batteries.' }
    ]
  },
  {
    id: 'aerospace_navigator',
    title: 'Aerospace Guidance Systems Navigator',
    description: 'Build autopilot navigation algorithms and coordinate projectile trajectory mechanics for commercial satellite carriers.',
    requiredSubjects: ['Physics', 'Mathematics'],
    keySkills: ['Euler Differential Methods', 'Trajectory Mechanics', 'Atmospheric Wind Shear', 'PID Controllers', 'MATLAB Orbit Modeling', 'Kalman Filtering', 'Quaternions Rotation', 'C++ Real-time Systems', 'Orbital Maneuvering', 'Telemetry Telecommunication'],
    educationPath: ['B.S. in Aerospace Engineering', 'M.S. in Guidance, Navigation & Control', 'Ph.D. in Astronautics'],
    entryExams: ['GRE Engineering', 'Flight Physics Assessment'],
    avgSalaryRange: { min: 105000, max: 175000, currency: 'USD' },
    growthOutlook: 'stable',
    chapterConnections: [
      { chapterId: 'physics_kinematics', application: 'Calculating drag-coefficient trajectories of launch rockets through high-altitude atmospheric layers.' },
      { chapterId: 'physics_vectors', application: 'Using force components to balance thrust, lift, drag, and gravity vectors during supersonic ascent.' },
      { chapterId: 'math_vectors', application: 'Utilizing cross-products and dot-products of vectors to calculate angular velocity and orbital planes.' },
      { chapterId: 'math_trig', application: 'Applying spherical trigonometry to resolve satellite GPS geolocation angles.' },
      { chapterId: 'math_calculus_diff', application: 'Using ordinary differential equations (ODEs) to continuously adjust fuel exhaust burn-rates.' }
    ]
  },
  {
    id: 'epidemiological_analyst',
    title: 'Epidemiological Disease Analyst',
    description: 'Model viral and bacterial transmission carrying capacities using differential equation step-rates to support healthcare policies.',
    requiredSubjects: ['Biology', 'Mathematics'],
    keySkills: ['Logistic Differential Equation Modeling', 'Statistical Euler Approximation', 'Data Science', 'R Programming', 'Epidemiology (SIR/SEIR)', 'GIS Spatial Mapping', 'Stochastic Processes', 'Public Health Policy', 'Bio-hazard Protocol', 'Data Visualization'],
    educationPath: ['B.S. in Biostatistics or Public Health', 'M.P.H in Epidemiology', 'Ph.D. in Biostatistics'],
    entryExams: ['GRE Quant', 'Public Health Entry Assessment'],
    avgSalaryRange: { min: 88000, max: 140000, currency: 'USD' },
    growthOutlook: 'high',
    chapterConnections: [
      { chapterId: 'math_calculus_diff', application: 'Predicting viral saturation carrying capacities in densely populated municipal zones.' },
      { chapterId: 'biology_photosynthesis', application: 'Analyzing cellular oxygen replication patterns and energy levels under toxic pathogen attack.' },
      { chapterId: 'chem_reactions', application: 'Studying the binding kinetics of vaccine antibodies with viral spike proteins.' },
      { chapterId: 'math_vectors', application: 'Mapping viral vector transmission corridors using graph theory node arrays.' },
      { chapterId: 'physics_kinematics', application: 'Simulating the physical acceleration and drop-rate trajectories of infectious respiratory aerosols.' }
    ]
  },
  {
    id: 'robotics_engineer',
    title: 'Robotics & Autonomous Systems Engineer',
    description: 'Design and program autonomous warehouse robots and self-driving delivery vehicles incorporating multi-sensor computer vision.',
    requiredSubjects: ['Physics', 'Mathematics', 'Computer Science'],
    keySkills: ['Kinematic Chains', 'LiDAR Data Fusion', 'ROS (Robot Operating System)', 'TensorFlow Vision', 'Path Planning', 'PID Controllers', 'Embedded C++', 'Microcontrollers', 'State-Estimation Algos', '3D CAD Design'],
    educationPath: ['B.S. in Robotics or Mechanical Engineering', 'M.S. in Autonomous Systems'],
    entryExams: ['GRE Engineering', 'ROS Fundamentals Certificate'],
    avgSalaryRange: { min: 115000, max: 185000, currency: 'USD' },
    growthOutlook: 'high',
    chapterConnections: [
      { chapterId: 'physics_vectors', application: 'Resolving torque and joint load force vectors in 6-degree-of-freedom robotic arms.' },
      { chapterId: 'physics_kinematics', application: 'Calculating acceleration limits and braking distances for self-driving vehicles on wet surfaces.' },
      { chapterId: 'math_vectors', application: 'Performing rigid-body transform matrix transformations to calculate camera coordinate alignments.' },
      { chapterId: 'math_trig', application: 'Using inverse trigonometric functions (atan2) to resolve joint angles from target coordinate endpoints.' },
      { chapterId: 'math_calculus_diff', application: 'Utilizing cost-function derivatives to dynamically recalculate collision-free trajectory paths.' }
    ]
  },
  {
    id: 'quantitative_analyst',
    title: 'Quantitative Financial Analyst (Quants)',
    description: 'Develop high-frequency algorithmic models and options pricing structures utilizing advanced mathematical stochastic calculus.',
    requiredSubjects: ['Mathematics', 'Computer Science'],
    keySkills: ['Black-Scholes Modeling', 'Monte Carlo Simulation', 'Stochastic Calculus', 'Python Pandas', 'C++ Low-latency', 'Risk Assessment', 'Machine Learning', 'Linear Algebra', 'Time Series Forecasting', 'Statistical Inference'],
    educationPath: ['B.S. in Financial Mathematics', 'M.S. in Quantitative Finance', 'Ph.D. in Applied Mathematics'],
    entryExams: ['CFA Level I', 'CQF (Certificate in Quantitative Finance)', 'GRE Mathematics'],
    avgSalaryRange: { min: 160000, max: 320000, currency: 'USD' },
    growthOutlook: 'high',
    chapterConnections: [
      { chapterId: 'math_calculus_diff', application: 'Deriving option pricing sensitivity (the Greeks) using the Black-Scholes partial differential equation.' },
      { chapterId: 'math_vectors', application: 'Projecting multi-asset security portfolio matrices onto principal eigen-vectors for risk reduction.' },
      { chapterId: 'physics_kinematics', application: 'Adapting kinematics displacement concepts to describe stock momentum trends and rate of price acceleration.' },
      { chapterId: 'math_trig', application: 'Extracting periodic cyclical wavelengths from historical macroeconomics data using Fourier sine series.' },
      { chapterId: 'physics_vectors', application: 'Modeling supply-demand equilibrium forces as directional vectors.' }
    ]
  },
  {
    id: 'bioinformatics_architect',
    title: 'Bioinformatics Software Architect',
    description: 'Architect big-data genomic processing pipelines that search billions of DNA nucleotides to isolate genetic mutations.',
    requiredSubjects: ['Biology', 'Computer Science', 'Chemistry'],
    keySkills: ['Next-Gen Sequencing (NGS)', 'BLAST Algorithmic Matching', 'Docker/Kubernetes', 'Hadoop/Spark Big Data', 'Python Biopython', 'Sql/NoSQL Database', 'Phylogenetic Tree Modeling', 'Machine Learning', 'Genomic Annotation', 'Restful APIs'],
    educationPath: ['B.S. in Software Engineering or Biotech', 'M.S. in Computational Biology'],
    entryExams: ['Bioinformatics Professional Certification', 'AWS Certified Solutions Architect'],
    avgSalaryRange: { min: 120000, max: 195000, currency: 'USD' },
    growthOutlook: 'high',
    chapterConnections: [
      { chapterId: 'biology_photosynthesis', application: 'Sequencing the chloroplast genomes of engineered algae to maximize bio-fuel carbon capture.' },
      { chapterId: 'chem_reactions', application: 'Mapping biochemical mutation pathways that make cancer cells highly resistant to standard chemotherapy.' },
      { chapterId: 'math_calculus_diff', application: 'Simulating the population growth and selection rates of mutated alleles over multiple generations.' },
      { chapterId: 'math_vectors', application: 'Using multidimensional Euclidean distance vectors to cluster gene expression profiles.' },
      { chapterId: 'chem_thermo', application: 'Calculating DNA hybridization melting temperatures to design sequence primers.' }
    ]
  },
  {
    id: 'clinical_geneticist',
    title: 'Clinical Geneticist & Immunologist',
    description: 'Diagnose hereditary diseases and design targeted personalized gene-replacement immunotherapies to treat rare conditions.',
    requiredSubjects: ['Biology', 'Chemistry'],
    keySkills: ['CAR-T Therapy Engineering', 'Karyotype Cytogenetics', 'PCR & Electrophoresis', 'Pathology Analysis', 'CRISPR Target Design', 'Enzyme Inhibitors', 'In-Vitro Fertilization', 'Pedigree Interpretation', 'Monoclonal Antibody Design', 'Clinical Diagnostics'],
    educationPath: ['B.S. in Genetics or Biochemistry', 'M.D. in Medical Genetics', 'Clinical Residency'],
    entryExams: ['MCAT', 'USMLE Step 1 & 2', 'Board Certification in Medical Genetics'],
    avgSalaryRange: { min: 185000, max: 260000, currency: 'USD' },
    growthOutlook: 'high',
    chapterConnections: [
      { chapterId: 'biology_photosynthesis', application: 'Studying cellular respiration and mitochondrial defects in human genetic metabolic syndromes.' },
      { chapterId: 'chem_reactions', application: 'Formulating precise cross-linking polymers to encapsulate genetic vector packets during cellular injection.' },
      { chapterId: 'chem_thermo', application: 'Monitoring exothermic antigen-antibody complex associations inside thermal-cycled ELISA tests.' },
      { chapterId: 'math_calculus_diff', application: 'Modeling viral capsid replication speeds during initial T-cell activation phases.' },
      { chapterId: 'math_vectors', application: 'Plotting 3D stereotactic structural binding models of CRISPR-Cas9 enzyme-DNA junctions.' }
    ]
  },
  {
    id: 'acoustic_engineer',
    title: 'Acoustic & Vibration Control Engineer',
    description: 'Engineer quiet spaces, noise-canceling headphone structures, and vibration dampeners for architectural or aerospace vehicles.',
    requiredSubjects: ['Physics', 'Mathematics'],
    keySkills: ['Wave Interferometry', 'Finite Element Analysis', 'DSP (Digital Signal Processing)', 'Acoustic Transducers', 'MATLAB Wavelet Modeling', 'Vibration Isolator Gels', 'Fourier Transforms', 'CAD Mechanical Design', 'Anharmonic Resonance', 'Decibel Scaling'],
    educationPath: ['B.S. in Mechanical or Audio Engineering', 'M.S. in Acoustics or Vibration Control'],
    entryExams: ['FE Mechanical', 'INCE Board Certification (Noise Control)'],
    avgSalaryRange: { min: 92000, max: 148000, currency: 'USD' },
    growthOutlook: 'stable',
    chapterConnections: [
      { chapterId: 'math_trig', application: 'Using sinusoidal phase shift transformations to design adaptive noise-canceling anti-waves.' },
      { chapterId: 'physics_kinematics', application: 'Modeling supersonic sound wave propagation speeds across varying air pressure gradients.' },
      { chapterId: 'physics_vectors', application: 'Resolving multi-directional structural vibration stress loads into orthogonal damping vectors.' },
      { chapterId: 'math_vectors', application: 'Applying complex number coordinate vectors to represent acoustic impedance wave phases.' },
      { chapterId: 'math_calculus_diff', application: 'Solving the second-order partial differential wave equation to optimize auditorium resonance.' }
    ]
  }
];

export const professionalVideos: ProfessionalVideo[] = [
  {
    id: 'v1_quantum',
    title: 'Designing Josephson Junctions in Cleanrooms',
    role: 'Lead Quantum Engineer',
    speaker: 'Dr. Evelyn Foster',
    duration: '2:45',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    conceptsTaught: ['Bloch Sphere State Matrices', 'Superconductors', 'Optics Ray Tracing', 'Microwave Resonators'],
    description: 'Join Dr. Foster in the cryogenic laboratory as she shows how linear algebra vector matrices are used to align qubits and program gates.',
    transcript: [
      { time: '0:05', text: "Welcome to the quantum cleanroom. Today, we are assembling superconductor Josephson junctions that serve as our quantum bits, or qubits." },
      { time: '0:45', text: "To manipulate these qubits, we represent their states using three-dimensional coordinate vectors on what is called the Bloch Sphere." },
      { time: '1:20', text: "By sending alternating radio-frequency pulses, modeled exactly as trigonometric sine waves, we can rotate these state vectors." },
      { time: '2:05', text: "A rotation of 90 degrees around the X-axis is equivalent to a square-root-of-NOT gate. Yes, school vectors and trig are the bedrock of quantum computers!" }
    ],
    quiz: {
      question: "How are coordinate vectors used to represent qubits in quantum hardware engineering?",
      options: [
        "They compute the physical mechanical speed of the cleanroom air filters.",
        "They represent the current quantum state on the 3D spherical space of the Bloch Sphere.",
        "They are used to measure the height of the cryogenic liquid nitrogen storage vessels."
      ],
      correctAnswerIdx: 1,
      explanation: "Quantum architects represent qubit superposition states as 3D vectors on the Bloch Sphere. We use linear algebra matrix transformations to execute quantum gates."
    }
  },
  {
    id: 'v2_biotech',
    title: 'Modeling Active Enzyme Inhibition Sites',
    role: 'Computational Biochemist',
    speaker: 'Dr. Aarav Patel',
    duration: '3:15',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    conceptsTaught: ['Carbonyl Condensations', 'Maillard Pyrolysis', 'CRISPR Targets', 'Gibbs Free Energy'],
    description: 'See how molecular structures and chemical reactions are visualized in 3D to construct small-molecule drug target alignments.',
    transcript: [
      { time: '0:10', text: "Hello! In drug discovery, our main goal is to design molecules that bind perfectly into active disease enzyme cavities." },
      { time: '0:50', text: "We analyze these biochemical reactions using vector models to track bond angles and distances in 3D space." },
      { time: '1:35', text: "We must also calculate the thermodynamics. A reaction is only spontaneous if the Gibbs free energy change, delta-G, is negative." },
      { time: '2:20', text: "When we model a condensation reaction, we write chemical equations to predict thermodynamic stability and binding affinity." }
    ],
    quiz: {
      question: "What thermodynamic variable determines if an enzyme-inhibitor docking association is spontaneous?",
      options: [
        "The overall molecular weight of the peptide protein.",
        "The change in Gibbs Free Energy (ΔG) which must be negative.",
        "The physical volume of the cell membrane."
      ],
      correctAnswerIdx: 1,
      explanation: "Gibbs Free Energy (ΔG = ΔH - TΔS) dictates if a bonding reaction occurs spontaneously. Negative ΔG values ensure high enzyme-inhibitor complex stability."
    }
  },
  {
    id: 'v3_solar',
    title: 'Calibrating Perovskite Inverter Arrays',
    role: 'Solar Technologist',
    speaker: 'Marcus Vance',
    duration: '2:30',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    conceptsTaught: ['Thermodynamic Dissipation', 'Sinusoidal Altitudes', 'Electromagnetism', 'P-N Semiconductor Junctions'],
    description: 'Marcus explains how standard trigonometric sine functions map the exact elevation path of the sun to optimize photovoltaic panel efficiency.',
    transcript: [
      { time: '0:05', text: "Hey there! Solar power isn't just about placing panels on a roof; it's about active orientation optimization." },
      { time: '0:45', text: "The sun's position throughout the day follows a sinusoidal curve. We use trigonometry to calculate the optimum tilt angle." },
      { time: '1:15', text: "Inside the semiconductor material, incoming photon vectors excite electrons across the p-n junction, generating a DC current." },
      { time: '2:00', text: "Our inverters then convert this current to AC. We must monitor thermodynamic heat dissipation to protect the grid from burning out." }
    ],
    quiz: {
      question: "Why are trigonometric functions essential when configuring active solar tracker arrays?",
      options: [
        "They determine the chemical formula of the silicon semiconductor crystals.",
        "They model the sinusoidal solar altitude path to calculate optimum real-time tilt angles.",
        "They track the retail market pricing fluctuations of utility grid systems."
      ],
      correctAnswerIdx: 1,
      explanation: "The sun's daily elevation profile follows a sinusoidal coordinate pathway. Dynamic mathematical models use trigonometry to align solar arrays perpendicular to incoming rays, raising output by up to 40%."
    }
  },
  {
    id: 'v4_aerospace',
    title: 'Autopilot Launch Trajectory Dynamics',
    role: 'Aerospace Guidance Specialist',
    speaker: 'Commander Jessica Vance',
    duration: '2:50',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    conceptsTaught: ['Euler Differential Methods', 'Force Vector Resolution', 'Kinematic Drag Profiles'],
    description: 'Jessica shows how autopilot navigation computers continuously solve differential equations to navigate rockets safely through high wind shear.',
    transcript: [
      { time: '0:12', text: "Hi! At liftoff, our guidance systems solve thousands of kinematic equations of motion every single millisecond." },
      { time: '0:55', text: "The rocket is subject to four main vector forces: thrust, gravity, lift, and drag. We resolve these into orthogonal axes." },
      { time: '1:40', text: "As the rocket reaches supersonic speed, wind resistance changes dynamically. We use Euler numerical integration methods to calculate coordinates." },
      { time: '2:15', text: "Differential equation solvers in the autopilot compute exactly when to gimbal the engine nozzles to prevent tumble. High school calculus literally guides spaceships!" }
    ],
    quiz: {
      question: "Which four directional vector forces are balanced to calculate launch vehicle orientation during atmospheric flight?",
      options: [
        "Inverter, reactant, capacitor, and dilution thermal dissipation.",
        "Thrust, lift, drag, and gravitational weight.",
        "Aerosol density, peptide coordinates, CRISPR mutations, and covalent bonds."
      ],
      correctAnswerIdx: 1,
      explanation: "Guidance computers continuously monitor the four primary aerodynamic vector forces: forward thrust, normal lift, opposing drag, and down gravitational weight to execute stable trajectory paths."
    }
  }
];

export const collegePrepDatabase: College[] = [
  {
    name: 'Massachusetts Institute of Technology (MIT)',
    location: 'Cambridge, MA',
    requiredGpa: 3.96,
    entryRequirements: ['SAT Math (780-800)', 'Advanced Placement Calculus BC (Score: 5)', 'AP Physics C (Mechanics & Electromagnetism)', 'AP Chemistry or Computer Science A', 'AP Research Portfolio'],
    notableScholarships: [
      { name: 'MIT Presidential Graduate Scholarship', amount: 'Full Tuition + $42,000 Stipend', eligibility: 'Exemplary STEM profile, recommended by engineering panel' },
      { name: 'National Merit Scholarship Award', amount: '$2,500 / yr', eligibility: 'Top 1% PSAT scorers' },
      { name: 'Undergraduate Research Opportunities Program (UROP) Fund', amount: '$6,000 / Semester', eligibility: 'Active participation in university cleanrooms or computational labs' }
    ]
  },
  {
    name: 'Stanford University',
    location: 'Stanford, CA',
    requiredGpa: 3.95,
    entryRequirements: ['ACT Composite (34-36)', 'AP Chemistry or AP Biology', 'Portfolio of practical capstone projects', 'AP Calculus BC', 'Stanford Bio-Science Entry Interview'],
    notableScholarships: [
      { name: 'Knight-Hennessy Scholars Program', amount: 'Full Fellowship + Travel Stipend', eligibility: 'Outstanding leadership, creative thinkers across disciplines' },
      { name: 'Stanford Bio-X Undergraduate Fellowship', amount: 'Full Research Grant', eligibility: 'Biomedical or protein-folding modeling research project submission' }
    ]
  },
  {
    name: 'California Institute of Technology (Caltech)',
    location: 'Pasadena, CA',
    requiredGpa: 3.98,
    entryRequirements: ['SAT Subject Test Math Level 2 (800)', 'Proven experience with open-source research or science olympiads', 'AP Physics C', 'Multivariable Calculus recommendation letter'],
    notableScholarships: [
      { name: 'Caltech Science Merit Award', amount: '$15,000 / yr', eligibility: 'Exceptional math and chemical olympiad performance' },
      { name: 'Carnation Scholarship', amount: '$10,000 / yr', eligibility: 'Academic performance + leadership excellence' }
    ]
  },
  {
    name: 'ETH Zurich (Swiss Federal Institute of Technology)',
    location: 'Zurich, Switzerland',
    requiredGpa: 3.90,
    entryRequirements: ['Reduced Entrance Examination', 'German Language Competency (C1 level)', 'AP Calculus BC', 'AP Physics C'],
    notableScholarships: [
      { name: 'Excellence Scholarship & Opportunity Programme (ESOP)', amount: 'Full Tuition + CHF 12,000/semester stipend', eligibility: 'Top 5% of incoming master students with strong thesis proposals' }
    ]
  },
  {
    name: 'Indian Institute of Technology Bombay (IITB)',
    location: 'Mumbai, India',
    requiredGpa: 3.92,
    entryRequirements: ['JEE Main (Top 1.5% percentile)', 'JEE Advanced (Rank < 500)', 'Class 12 board marks (Physics, Chemistry, Math) > 75%'],
    notableScholarships: [
      { name: 'IITB Merit-cum-Means Scholarship', amount: 'Full Tuition waiver + monthly stipend', eligibility: 'JEE Rank + household income below 9 LPA' }
    ]
  },
  {
    name: 'National University of Singapore (NUS)',
    location: 'Singapore',
    requiredGpa: 3.94,
    entryRequirements: ['ACT with Writing (32+) or SAT (1450+)', '3 Advanced Placement exams with score of 5', 'Personal statement and academic resume'],
    notableScholarships: [
      { name: 'ASEAN Undergraduate Scholarship', amount: 'Full Tuition + SGD $5,800/yr living allowance', eligibility: 'Citizens of ASEAN nations showing excellent leadership and academic metrics' }
    ]
  }
];
