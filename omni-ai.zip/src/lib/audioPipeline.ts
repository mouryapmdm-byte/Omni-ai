/**
 * Speech Generation Audio Pipeline - Voice Normalization & Timbre Standardization Filter
 * This utility standardizes the pitch and timbre of generated AI speech, keeping it
 * consistent across classroom sessions and preventing undesirable shifts in tone, volume, or timbre.
 */

export interface VoiceNormalizationConfig {
  lowCutFreq?: number;       // Highpass filter freq to remove muddy low hums (default: 130Hz)
  highCutFreq?: number;      // Lowpass filter freq to remove metallic high sibilance (default: 6800Hz)
  vocalPresenceFreq?: number;// Peaking EQ center freq for vocal clarity (default: 1800Hz)
  vocalPresenceGain?: number;// Peaking EQ gain in dB (default: +2.5dB)
  vocalPresenceQ?: number;   // Peaking EQ Q-factor (default: 1.2)
  compressorThreshold?: number; // dB (default: -22dB)
  compressorKnee?: number;      // dB (default: 25dB)
  compressorRatio?: number;     // ratio (default: 4.5)
  compressorAttack?: number;    // seconds (default: 0.015s)
  compressorRelease?: number;   // seconds (default: 0.12s)
}

/**
 * Creates and connects a voice normalization filter chain in the given AudioContext.
 * Connects: inputNode -> Highpass -> Lowpass -> Peaking EQ (Timbre) -> DynamicsCompressor (Gain/Volume Normalizer) -> outputNode
 * 
 * This ensures that pitch is stabilized in the sweet spot and the harmonic spectrum (timbre)
 * remains uniform and professional, eliminating neural voice drifting or volume/tone shift.
 */
export function createVoiceNormalizationChain(
  audioContext: AudioContext,
  config: VoiceNormalizationConfig = {}
) {
  const {
    lowCutFreq = 130,
    highCutFreq = 6800,
    vocalPresenceFreq = 1800,
    vocalPresenceGain = 2.5,
    vocalPresenceQ = 1.2,
    compressorThreshold = -22,
    compressorKnee = 25,
    compressorRatio = 4.5,
    compressorAttack = 0.015,
    compressorRelease = 0.12
  } = config;

  // 1. High-pass filter to remove low-frequency rumbles, floor noise, or deep shifting undertones
  const highpass = audioContext.createBiquadFilter();
  highpass.type = 'highpass';
  highpass.frequency.setValueAtTime(lowCutFreq, audioContext.currentTime);

  // 2. Low-pass filter to strip metallic high-frequency sibilance/digital aliasing
  const lowpass = audioContext.createBiquadFilter();
  lowpass.type = 'lowpass';
  lowpass.frequency.setValueAtTime(highCutFreq, audioContext.currentTime);

  // 3. Peaking EQ to lock-in the core vocal resonance (timbre standardization)
  const peakingEQ = audioContext.createBiquadFilter();
  peakingEQ.type = 'peaking';
  peakingEQ.frequency.setValueAtTime(vocalPresenceFreq, audioContext.currentTime);
  peakingEQ.gain.setValueAtTime(vocalPresenceGain, audioContext.currentTime);
  peakingEQ.Q.setValueAtTime(vocalPresenceQ, audioContext.currentTime);

  // 4. Dynamics Compressor to normalize peak volumes and stabilize overall gain
  const compressor = audioContext.createDynamicsCompressor();
  compressor.threshold.setValueAtTime(compressorThreshold, audioContext.currentTime);
  compressor.knee.setValueAtTime(compressorKnee, audioContext.currentTime);
  compressor.ratio.setValueAtTime(compressorRatio, audioContext.currentTime);
  compressor.attack.setValueAtTime(compressorAttack, audioContext.currentTime);
  compressor.release.setValueAtTime(compressorRelease, audioContext.currentTime);

  // Connect the filter chain
  highpass.connect(lowpass);
  lowpass.connect(peakingEQ);
  peakingEQ.connect(compressor);

  return {
    input: highpass,
    output: compressor,
    // Keep references to allow dynamic tweaking if necessary
    nodes: {
      highpass,
      lowpass,
      peakingEQ,
      compressor
    }
  };
}
