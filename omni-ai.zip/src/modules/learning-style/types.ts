export type VARKStyle = 'visual' | 'auditory' | 'reading' | 'kinaesthetic' | 'balanced';

export interface DiagramInteraction {
  topicId: string;
  duration: number; // seconds spent viewing diagrams
  zoomCount: number;
  replayCount: number;
  timestamp: string;
}

export interface TextInteraction {
  topicId: string;
  scrollDepth: number; // 0 - 100 percentage
  rereadCount: number;
  noteCount: number;
  timestamp: string;
}

export interface AudioInteraction {
  topicId: string;
  listenDuration: number; // seconds spent listening
  voiceCommandCount: number;
  timestamp: string;
}

export interface HandsOnInteraction {
  topicId: string;
  drawCount: number;
  modelInteractionCount: number; // 3D model rotation/click
  timestamp: string;
}

export interface BehavioralSignals {
  diagrams: DiagramInteraction[];
  texts: TextInteraction[];
  audios: AudioInteraction[];
  handsOn: HandsOnInteraction[];
}

export interface LearningStyleProfile {
  studentId: string;
  visualScore: number; // 0 - 100
  auditoryScore: number; // 0 - 100
  readingScore: number; // 0 - 100
  kinaestheticScore: number; // 0 - 100
  dominantStyle: VARKStyle;
  confidence: number; // 0 - 100
  isManualOverride: boolean;
  detectedAt: string;
  updatedAt: string;
}

export interface AdaptationStrategy {
  style: VARKStyle;
  confidenceLevel: 'strong' | 'mild' | 'unknown';
  prioritizeDiagramsAnd3D: boolean;
  prioritizeAudioAndNarration: boolean;
  prioritizeDetailedNotesAndTranscripts: boolean;
  prioritizeInteractiveAndHandsOn: boolean;
  description: string;
  teachingPromptInstruction: string;
}
