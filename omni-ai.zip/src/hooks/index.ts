export { useDebugEffect, type DebugEffectOptions } from './useDebugEffect';
export { useTrackedState, type TrackedStateOptions } from './useTrackedState';
export { useDependencyTracker, type DependencyDiffItem } from './useDependencyTracker';
export { useComponentHealth, type ComponentHealthMetrics } from './useComponentHealth';
export {
  useDeepState,
  useBatchedUpdates,
  useDeferredUpdates,
  useFrameBatchedUpdates,
  useDepthMonitor,
  useAutoDepthManagement,
  useClassroomStateManager,
  useSafeEffect
} from './useDeepState';
export {
  useChunkedGeneration,
  useCancellableChunkedGeneration,
  useBatchedLectureState,
  useLiveMastery,
  useStreamingText,
  use3DAnimation,
  useCompleteQuestionWorkflow,
  useRenderPerformance,
  usePerformanceMark,
  type PerformanceQuestion,
  type LectureState,
  type LectureAction,
  type WorkflowDisplayState
} from './useHighVolumeUpdates';
