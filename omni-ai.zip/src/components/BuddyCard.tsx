import React, { useState } from 'react';
import { 
  Flame, Target, MessageSquare, Calendar, ShieldCheck, 
  ChevronRight, Award, Clock, ArrowUpRight, Zap, CheckCircle2,
  Lock, Unlock, MoreHorizontal, UserX, PauseCircle, PlayCircle, HelpCircle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { StudyBuddyMatch } from '../modules/study-buddies/types';
import { StudyBuddyService } from '../modules/study-buddies/studyBuddyService';

interface BuddyCardProps {
  match: StudyBuddyMatch;
  isDark?: boolean;
  onOpenCheckIn: (match: StudyBuddyMatch) => void;
  onOpenChat: (match: StudyBuddyMatch) => void;
  onOpenScheduler: (match: StudyBuddyMatch) => void;
  onUpdate: () => void;
}

export const BuddyCard: React.FC<BuddyCardProps> = ({
  match,
  isDark = true,
  onOpenCheckIn,
  onOpenChat,
  onOpenScheduler,
  onUpdate,
}) => {
  const [showScoreBreakdown, setShowScoreBreakdown] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const partner = match.partnerProfile;
  const goal = match.sharedGoal;

  const handleIncrementGoal = (amount: number) => {
    StudyBuddyService.updateSharedGoalProgress(match.id, amount);
    onUpdate();
  };

  const handleRevealConsent = () => {
    StudyBuddyService.consentRevealIdentity(match.id);
    onUpdate();
  };

  const handleTogglePause = () => {
    StudyBuddyService.togglePauseMatch(match.id);
    setShowMenu(false);
    onUpdate();
  };

  const handleUnmatch = () => {
    if (window.confirm(`Are you sure you want to unmatch with ${partner?.alias || 'this study buddy'}? You can always match with new peers anytime.`)) {
      StudyBuddyService.unmatch(match.id);
      onUpdate();
    }
  };

  const goalPercentage = goal && goal.targetProblems > 0
    ? Math.min(100, Math.round(((goal.completedProblemsA + goal.completedProblemsB) / goal.targetProblems) * 100))
    : 0;

  return (
    <div className={cn(
      "rounded-2xl border p-5 transition-all shadow-md relative overflow-hidden",
      isDark 
        ? "bg-slate-900/90 border-slate-800 hover:border-slate-700 text-slate-100" 
        : "bg-white border-slate-200 hover:border-indigo-200 text-slate-800"
    )}>
      {/* Top Banner & Status */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white font-black text-lg shadow-md shadow-indigo-500/20">
              {(partner?.alias || 'SB').charAt(0)}
            </div>
            {match.status === 'active' && (
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base flex items-center gap-1.5">
                {partner?.alias || 'Anonymous Buddy'}
                {match.revealConsentA && match.revealConsentB && (
                  <span className="text-[10px] font-normal px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                    <Unlock size={10} /> Verified
                  </span>
                )}
              </h3>
              <span className="text-[11px] px-2 py-0.5 rounded-md font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                {match.subjectFocus}
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
              <span>{partner?.targetExam || 'Target STEM Exam'}</span>
              <span>•</span>
              <span className="text-amber-400 font-semibold flex items-center gap-0.5">
                <Flame size={12} /> {partner?.streakDays || 5}d Streak
              </span>
            </p>
          </div>
        </div>

        {/* Match Score Badge */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowScoreBreakdown(!showScoreBreakdown)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold hover:bg-emerald-500/20 transition cursor-pointer"
            title="Click to view algorithm match breakdown"
          >
            <Zap size={12} className="text-emerald-400" />
            <span>{match.matchScore}% Match</span>
          </button>

          {/* More actions menu */}
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
            >
              <MoreHorizontal size={16} />
            </button>
            {showMenu && (
              <div className="absolute right-0 top-8 z-30 w-48 rounded-xl border border-slate-700 bg-slate-800 shadow-xl py-1 text-xs text-slate-200 animate-in fade-in zoom-in-95">
                <button
                  onClick={handleTogglePause}
                  className="w-full px-3 py-2 text-left hover:bg-slate-700 flex items-center gap-2 cursor-pointer"
                >
                  {match.status === 'active' ? <PauseCircle size={14} className="text-amber-400" /> : <PlayCircle size={14} className="text-emerald-400" />}
                  {match.status === 'active' ? 'Pause Match' : 'Resume Match'}
                </button>
                <button
                  onClick={handleRevealConsent}
                  className="w-full px-3 py-2 text-left hover:bg-slate-700 flex items-center gap-2 cursor-pointer text-indigo-300"
                >
                  <ShieldCheck size={14} /> Consent to Reveal ID
                </button>
                <button
                  onClick={handleUnmatch}
                  className="w-full px-3 py-2 text-left hover:bg-rose-900/40 text-rose-400 flex items-center gap-2 cursor-pointer border-t border-slate-700/50"
                >
                  <UserX size={14} /> Unmatch Buddy
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Match Score Breakdown Details Drawer */}
      {showScoreBreakdown && match.scoreBreakdown && (
        <div className="mb-4 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs space-y-2 animate-in fade-in">
          <div className="flex items-center justify-between font-bold text-slate-300 border-b border-slate-800 pb-1">
            <span>Algorithm Match Weighting</span>
            <span className="text-emerald-400">{match.matchScore} / 100</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
            <div>
              <div className="flex justify-between">
                <span>Pace Velocity (0.30):</span>
                <span className="font-semibold text-slate-200">{match.scoreBreakdown.paceSimilarity}%</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-0.5">
                <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${match.scoreBreakdown.paceSimilarity}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between">
                <span>Complementarity (0.25):</span>
                <span className="font-semibold text-slate-200">{match.scoreBreakdown.complementarityScore}%</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-0.5">
                <div className="bg-purple-500 h-full rounded-full" style={{ width: `${match.scoreBreakdown.complementarityScore}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between">
                <span>Schedule Overlap (0.20):</span>
                <span className="font-semibold text-slate-200">{match.scoreBreakdown.scheduleOverlap}%</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-0.5">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${match.scoreBreakdown.scheduleOverlap}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between">
                <span>Subject Alignment (0.15):</span>
                <span className="font-semibold text-slate-200">{match.scoreBreakdown.subjectAlignment}%</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-0.5">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: `${match.scoreBreakdown.subjectAlignment}%` }} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Strengths & Weaknesses Pill Badges */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-700/50">
          <span className="text-[10px] uppercase font-bold text-emerald-400 block mb-1">
            Partner Excels At:
          </span>
          <div className="flex flex-wrap gap-1">
            {(partner?.strengths || ['Calculus', 'Vectors']).slice(0, 2).map((s, idx) => (
              <span key={idx} className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 font-medium">
                {s}
              </span>
            ))}
          </div>
        </div>
        <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-700/50">
          <span className="text-[10px] uppercase font-bold text-amber-400 block mb-1">
            Needs Help In:
          </span>
          <div className="flex flex-wrap gap-1">
            {(partner?.weaknesses || ['Wave Optics', 'AC']).slice(0, 2).map((w, idx) => (
              <span key={idx} className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 font-medium">
                {w}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Shared Study Goal */}
      {goal && (
        <div className="mb-4 p-3 rounded-xl bg-indigo-950/30 border border-indigo-500/20">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1.5">
              <Target size={14} className="text-indigo-400" />
              <span className="text-xs font-bold text-indigo-200 truncate max-w-[200px] sm:max-w-xs">
                {goal.title}
              </span>
            </div>
            <span className="text-[11px] font-bold text-indigo-400">
              {goal.completedProblemsA + goal.completedProblemsB} / {goal.targetProblems} solved
            </span>
          </div>

          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-2">
            <div 
              className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full transition-all duration-500" 
              style={{ width: `${goalPercentage}%` }} 
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-indigo-400 inline-block" /> You: {goal.completedProblemsA}
              <span className="w-2 h-2 rounded-full bg-purple-400 inline-block ml-2" /> Buddy: {goal.completedProblemsB}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => handleIncrementGoal(1)}
                className="px-2 py-0.5 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[10px] transition cursor-pointer"
              >
                +1 Solved
              </button>
              <button
                onClick={() => handleIncrementGoal(3)}
                className="px-2 py-0.5 rounded-md bg-indigo-600/60 hover:bg-indigo-600 text-white font-bold text-[10px] transition cursor-pointer"
              >
                +3
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-2 pt-1 border-t border-slate-800/80">
        <button
          onClick={() => onOpenCheckIn(match)}
          className="py-2 px-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white text-xs font-bold shadow-sm shadow-amber-500/20 flex items-center justify-center gap-1.5 transition cursor-pointer"
        >
          <Flame size={14} /> Check In
        </button>

        <button
          onClick={() => onOpenChat(match)}
          className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
        >
          <MessageSquare size={14} className="text-indigo-400" /> Chat
        </button>

        <button
          onClick={() => onOpenScheduler(match)}
          className="py-2 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
        >
          <Calendar size={14} className="text-teal-400" /> Session
        </button>
      </div>
    </div>
  );
};
