export type DifficultyLevel = 1 | 2 | 3 | 4 | 5;

export type FlowStateZone = 'boredom' | 'flow' | 'frustration' | 'optimal';

export type AdaptiveRateTier = 'fast' | 'medium' | 'slow';

export type InterventionType = 
  | 'offer_hint' 
  | 'easier_question' 
  | 'suggest_break_review' 
  | 'harder_variant' 
  | null;

export interface DifficultyState {
  studentId: string;
  topicId: string;
  currentLevel: DifficultyLevel;
  fineDifficulty: number; // 1.0 to 5.0 continuous item rating
  rollingAccuracy: number; // 0.0 to 1.0 based on last 5 answers
  rollingWindow: boolean[]; // Array of up to 5 booleans (recent answers)
  consecutiveCorrect: number;
  consecutiveWrong: number;
  totalQuestions: number;
  totalCorrect: number;
  adaptiveRate: AdaptiveRateTier;
  flowState: FlowStateZone;
  intervention: InterventionType;
  interventionMessage?: string;
  lastAdjustedAt: string;
}

export interface QuestionCandidate {
  id: string;
  topicId: string;
  difficultyLevel: DifficultyLevel; // 1 to 5
  itemDifficulty: number; // 1.0 to 5.0
  text: string;
  formulaOrCode?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  hint?: string;
  isChallengeVariant?: boolean;
}

export interface DifficultyAdjustmentEvent {
  previousLevel: DifficultyLevel;
  newLevel: DifficultyLevel;
  previousFineDifficulty: number;
  newFineDifficulty: number;
  reason: string;
  trigger: 
    | 'consecutive_correct' 
    | 'consecutive_wrong' 
    | 'flow_target_high' 
    | 'flow_target_low' 
    | 'frustration_prevention' 
    | 'boredom_prevention' 
    | 'manual';
  timestamp: string;
}
