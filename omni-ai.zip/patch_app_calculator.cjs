const fs = require('fs');
const file = 'src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

const importStatement = `import { MatrixCalculatorModal } from './components/MatrixCalculatorModal';\n`;
if (!content.includes('MatrixCalculatorModal')) {
    content = content.replace("import { AlgebraicPropertiesModal }", importStatement + "import { AlgebraicPropertiesModal }");
    
    const caseStatement = `
      case 'matrix_calculator':
        setModal({
          title: 'Matrix Calculator',
          content: (
            <div className="h-[85vh] -mx-6 -my-4 p-1">
              <MatrixCalculatorModal theme={theme} onClose={() => setModal(null)} />
            </div>
          ),
          size: 'large'
        });
        break;
`;
    content = content.replace("case 'algebraic_properties':", caseStatement + "      case 'algebraic_properties':");
    fs.writeFileSync(file, content);
    console.log("Patched App.tsx successfully");
} else {
    console.log("Already patched");
}
