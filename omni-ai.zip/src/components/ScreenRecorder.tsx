import React, { useState, useRef, useEffect } from 'react';
import { 
  Video, 
  Square, 
  Play, 
  Pause, 
  Download, 
  RotateCcw, 
  Mic, 
  MicOff, 
  Monitor, 
  MonitorOff, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Radio, 
  Clock, 
  Film, 
  Share2,
  X,
  AlignLeft,
  Bookmark,
  Layers,
  Presentation,
  Tv,
  ExternalLink
} from 'lucide-react';
import { cn, downloadFileFromUrl } from '@/src/lib/utils';
import { TeleprompterDock, ChapterMarker } from './TeleprompterDock';
import { smartboardRecorder } from '../services/smartboardRecordingEngine';
import { SmartboardPipOverlay } from './SmartboardPipOverlay';

interface ScreenRecorderProps {
  theme: 'light' | 'dark';
  onClose?: () => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const ScreenRecorder: React.FC<ScreenRecorderProps> = ({
  theme,
  onClose,
  showNotification
}) => {
  const [recordingState, setRecordingState] = useState<'idle' | 'recording' | 'paused' | 'stopped'>('idle');
  const [recordingSource, setRecordingSource] = useState<'screen' | 'camera' | 'smartboard'>('smartboard');
  const [recordSmartboardMode, setRecordSmartboardMode] = useState<boolean>(true);
  const [showPipOverlay, setShowPipOverlay] = useState<boolean>(true);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [includeMic, setIncludeMic] = useState<boolean>(true);
  const [duration, setDuration] = useState<number>(0);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const [mimeTypeUsed, setMimeTypeUsed] = useState<string>('video/webm');
  const [error, setError] = useState<string | null>(null);
  const [isIframePolicyBlocked, setIsIframePolicyBlocked] = useState<boolean>(false);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [videoDuration, setVideoDuration] = useState<number>(0);

  // Teleprompter & Live Chapters State
  const [showPrompterDock, setShowPrompterDock] = useState<boolean>(true);
  const [recordedChapters, setRecordedChapters] = useState<ChapterMarker[]>([]);

  const handleAddChapter = (marker: ChapterMarker) => {
    setRecordedChapters(prev => [...prev, marker]);
    showNotification?.(`Added Chapter: "${marker.title}" at ${formatDuration(marker.timestamp)}`, "info");
  };

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<any>(null);
  const liveVideoRef = useRef<HTMLVideoElement>(null);
  const previewVideoRef = useRef<HTMLVideoElement>(null);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      cleanupStreams();
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, []);

  const cleanupStreams = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const formatDuration = (seconds: number) => {
    if (isNaN(seconds) || !isFinite(seconds)) return '00:00';
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    const pad = (num: number) => String(num).padStart(2, '0');
    if (hrs > 0) {
      return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  };

  const togglePlay = () => {
    if (previewVideoRef.current) {
      if (isPlaying) {
        previewVideoRef.current.pause();
        setIsPlaying(false);
      } else {
        previewVideoRef.current.play().then(() => setIsPlaying(true)).catch(err => console.error("Playback failed:", err));
      }
    }
  };

  const startRecording = async (source: 'screen' | 'camera' | 'smartboard' = recordingSource) => {
    setError(null);
    setIsIframePolicyBlocked(false);
    try {
      let activeStream: MediaStream;

      if (source === 'smartboard' || recordSmartboardMode) {
        // Dedicated Smartboard Display Capture Stream (1080p50 with Audio Synthesis + optional Mic)
        const smartboardStream = await smartboardRecorder.getSmartboardDisplayStream(includeMic);
        if (!smartboardStream) {
          throw new Error("Could not initialize Smartboard display capture stream.");
        }
        activeStream = smartboardStream;
      } else if (source === 'screen') {
        // 1. Attempt display media (Screen capture)
        try {
          const displayStream = await navigator.mediaDevices.getDisplayMedia({
            video: {
              displaySurface: 'monitor',
              width: { ideal: 1920 },
              height: { ideal: 1080 },
              frameRate: { ideal: 30 }
            },
            audio: true
          });

          let combinedTracks = [...displayStream.getTracks()];

          // Combine mic if requested and available
          if (includeMic) {
            try {
              const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
              const micAudioTrack = micStream.getAudioTracks()[0];
              if (micAudioTrack) {
                combinedTracks.push(micAudioTrack);
              }
            } catch (micErr) {
              console.warn("Microphone permission denied:", micErr);
            }
          }

          activeStream = new MediaStream(combinedTracks);

          displayStream.getVideoTracks()[0].onended = () => {
            stopRecording();
          };
        } catch (displayErr: any) {
          const errStr = (displayErr?.message || displayErr?.name || '').toString().toLowerCase();
          if (errStr.includes('display-capture') || errStr.includes('permissions policy') || errStr.includes('disallowed') || displayErr?.name === 'NotAllowedError') {
            setIsIframePolicyBlocked(true);
            setError("Screen capture (`display-capture`) is restricted inside embedded iFrames by browser security policy. Use 'Record Smartboard' mode to capture the classroom presentation smartboard seamlessly.");
            throw displayErr;
          }
          throw displayErr;
        }
      } else {
        // Camera & Audio mode
        activeStream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: includeMic
        });
      }

      setStream(activeStream);

      if (liveVideoRef.current) {
        liveVideoRef.current.srcObject = activeStream;
      }

      // Determine supported MIME type
      const mimeTypes = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm;codecs=h264,opus',
        'video/webm',
        'video/mp4'
      ];
      let selectedMime = mimeTypes.find(type => MediaRecorder.isTypeSupported(type)) || '';
      setMimeTypeUsed(selectedMime);

      // Create MediaRecorder
      const mediaRecorder = new MediaRecorder(activeStream, selectedMime ? { mimeType: selectedMime } : undefined);
      mediaRecorderRef.current = mediaRecorder;
      recordedChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        if (recordedChunksRef.current.length === 0) {
          setError("No video data recorded. Please try recording again.");
          setRecordingState('idle');
          return;
        }
        const blob = new Blob(recordedChunksRef.current, { 
          type: selectedMime || 'video/webm' 
        });
        const url = URL.createObjectURL(blob);
        setRecordedVideoUrl(url);
        setRecordingState('stopped');
        setIsPlaying(true);
        showNotification?.("🎬 Recording saved in 1080p Full HD! Ready to preview & export.", "success");
      };

      // Start recording
      mediaRecorder.start(1000);
      setRecordingState('recording');
      setDuration(0);

      // Start duration timer
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);

      const sourceLabel = (source === 'smartboard' || recordSmartboardMode) 
        ? 'Presentation Smartboard (1080p)' 
        : source === 'screen' ? 'Screen' : 'Camera';
      showNotification?.(`🔴 ${sourceLabel} recording started!`, "info");
    } catch (err: any) {
      console.error("Recording failed to start:", err);
      if (!isIframePolicyBlocked) {
        setError(err.message || "Could not start recording. Please check browser permissions.");
        showNotification?.("Recording failed: " + (err.message || "Permission denied"), "error");
      }
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && recordingState === 'recording') {
      mediaRecorderRef.current.pause();
      setRecordingState('paused');
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      showNotification?.("Recording paused", "info");
    }
  };

  const resumeRecording = () => {
    if (mediaRecorderRef.current && recordingState === 'paused') {
      mediaRecorderRef.current.resume();
      setRecordingState('recording');
      timerIntervalRef.current = setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);
      showNotification?.("Recording resumed", "info");
    }
  };

  const stopRecording = () => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.requestData();
      } catch (e) {
        console.warn("requestData error:", e);
      }
      mediaRecorderRef.current.stop();
    }
    cleanupStreams();
  };

  const handleDownload = () => {
    if (!recordedVideoUrl) return;
    const ext = mimeTypeUsed.includes('mp4') ? 'mp4' : 'webm';
    const filename = `OmniAI_Screen_Recording_${new Date().toISOString().slice(0, 10)}_${Date.now()}.${ext}`;
    downloadFileFromUrl(recordedVideoUrl, filename);
    showNotification?.(`Downloading ${filename}`, "success");
  };

  const handleReset = () => {
    if (recordedVideoUrl) {
      URL.revokeObjectURL(recordedVideoUrl);
    }
    setRecordedVideoUrl(null);
    setDuration(0);
    setRecordingState('idle');
    cleanupStreams();
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-hidden transition-all duration-300 rounded-2xl border shadow-2xl",
      theme === 'dark' ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Header */}
      <div className={cn(
        "px-6 py-4 border-b flex items-center justify-between shrink-0",
        theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center border transition-all duration-500 shadow-md",
            recordingState === 'recording' 
              ? "bg-rose-500/20 text-rose-400 border-rose-500/30 animate-pulse" 
              : "bg-indigo-500/10 text-indigo-400 border-indigo-500/25"
          )}>
            <Film size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black uppercase tracking-wider">Screen Recording Studio</h3>
              {recordingState === 'recording' && (
                <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] font-black uppercase tracking-widest animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                  REC
                </span>
              )}
            </div>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">
              Record lessons, presentations, or quizzes in HD with Audio
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Smartboard PiP Preview Overlay Toggle */}
          <button
            type="button"
            onClick={() => setShowPipOverlay(prev => !prev)}
            className={cn(
              "px-3 py-1.5 rounded-xl border flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shadow-sm",
              showPipOverlay
                ? "bg-cyan-600/30 text-cyan-300 border-cyan-500/50 shadow-cyan-600/20"
                : "bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700"
            )}
            title="Toggle Smartboard Picture-in-Picture Overlay Preview"
          >
            <Layers size={14} className={showPipOverlay ? "text-cyan-400" : ""} />
            <span className="hidden sm:inline">Smartboard PiP</span>
          </button>

          {/* Teleprompter Toggle */}
          <button
            type="button"
            onClick={() => setShowPrompterDock(!showPrompterDock)}
            className={cn(
              "px-3 py-1.5 rounded-xl border flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer shadow-sm",
              showPrompterDock 
                ? "bg-indigo-600 text-white border-indigo-500 shadow-indigo-600/20" 
                : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
            )}
            title="Toggle Smart Teleprompter & Outline Dock"
          >
            <AlignLeft size={14} />
            <span className="hidden sm:inline">Teleprompter Dock</span>
          </button>

          {/* Duration Badge */}
          {(recordingState === 'recording' || recordingState === 'paused' || recordingState === 'stopped') && (
            <div className={cn(
              "px-3.5 py-1.5 rounded-xl border flex items-center gap-2 text-xs font-mono font-bold shadow-inner",
              recordingState === 'recording'
                ? "bg-rose-950/40 border-rose-500/40 text-rose-300"
                : "bg-slate-800 border-slate-700 text-slate-300"
            )}>
              <Clock size={14} className={recordingState === 'recording' ? "text-rose-400 animate-spin" : "text-slate-400"} />
              <span>{formatDuration(duration)}</span>
            </div>
          )}

          {onClose && (
            <button 
              onClick={onClose} 
              className="p-2 rounded-full hover:bg-slate-500/20 text-slate-400 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Picture-in-Picture Floating Window Overlay */}
      <SmartboardPipOverlay
        isOpen={showPipOverlay}
        onClose={() => setShowPipOverlay(false)}
        isRecording={recordingState === 'recording'}
        recordingDuration={duration}
        theme={theme}
      />

      {/* Content Area */}
      <div className="flex-1 p-4 md:p-6 flex flex-col items-center justify-center relative overflow-hidden bg-[radial-gradient(rgba(99,102,241,0.03)_1px,transparent_1px)] bg-[size:20px_20px]">
        {/* State 1: Active Recording / Live Stream Preview */}
        {(recordingState === 'recording' || recordingState === 'paused') && stream && (
          <div className="w-full h-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in fade-in duration-300">
            {/* Video Live Preview & Controls */}
            <div className={cn(
              "flex flex-col items-center justify-between gap-4 h-full",
              showPrompterDock ? "lg:col-span-8" : "lg:col-span-12"
            )}>
              <div className="w-full flex-1 relative rounded-2xl overflow-hidden bg-black shadow-2xl border border-slate-800 group">
                <video 
                  ref={liveVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-contain"
                />
                
                {/* Overlay Status */}
                <div className="absolute top-4 left-4 bg-slate-900/80 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-slate-700/60 flex items-center gap-2.5 shadow-xl">
                  <span className={cn(
                    "w-2.5 h-2.5 rounded-full",
                    recordingState === 'recording' ? "bg-rose-500 animate-ping" : "bg-amber-400"
                  )}></span>
                  <span className="text-[11px] font-black uppercase tracking-wider text-slate-200">
                    {recordingState === 'recording' 
                      ? (recordingSource === 'smartboard' || recordSmartboardMode ? "Recording Live Smartboard Output" : "Recording Live Screen") 
                      : "Recording Paused"}
                  </span>
                </div>

                <div className="absolute top-4 right-4 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-700/60 font-mono text-xs text-rose-400 font-bold">
                  {formatDuration(duration)}
                </div>
              </div>

              {/* Live Controls */}
              <div className="flex items-center gap-3 bg-slate-900/90 backdrop-blur-xl px-6 py-3 rounded-2xl border border-slate-800 shadow-2xl flex-wrap justify-center">
                {/* PiP Overlay Toggle in Live Controls */}
                <button
                  type="button"
                  onClick={() => setShowPipOverlay(prev => !prev)}
                  className={cn(
                    "px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border",
                    showPipOverlay 
                      ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/40" 
                      : "bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700"
                  )}
                  title="Toggle Picture-in-Picture smartboard preview overlay"
                >
                  <Layers size={14} className={showPipOverlay ? "text-cyan-400" : ""} />
                  <span>PiP Live Preview</span>
                </button>

                {recordingState === 'recording' ? (
                  <button
                    type="button"
                    onClick={pauseRecording}
                    className="px-5 py-2.5 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all active:scale-95 cursor-pointer"
                  >
                    <Pause size={15} /> Pause
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={resumeRecording}
                    className="px-5 py-2.5 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all active:scale-95 cursor-pointer"
                  >
                    <Play size={15} /> Resume
                  </button>
                )}

                <button
                  type="button"
                  onClick={stopRecording}
                  className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-lg shadow-rose-600/30 flex items-center gap-2 transition-all active:scale-95 cursor-pointer"
                >
                  <Square size={15} className="fill-current" /> Finish & Save
                </button>
              </div>
            </div>

            {/* Teleprompter & Outline Dock Side Panel */}
            {showPrompterDock && (
              <div className="lg:col-span-4 h-full min-h-[320px]">
                <TeleprompterDock
                  recordingTimeSeconds={duration}
                  isRecording={recordingState === 'recording'}
                  onAddChapter={handleAddChapter}
                  chapters={recordedChapters}
                  theme={theme}
                />
              </div>
            )}
          </div>
        )}

        {/* State 2: Stopped & Reviewing Recorded Video */}
        {recordingState === 'stopped' && recordedVideoUrl && (
          <div className="w-full h-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in zoom-in-95 duration-300">
            <div className={cn(
              "flex flex-col items-center justify-between gap-4 h-full",
              showPrompterDock ? "lg:col-span-8" : "lg:col-span-12"
            )}>
              <div className="w-full flex-1 relative rounded-2xl overflow-hidden bg-black shadow-2xl border border-slate-800 group">
                <video 
                  ref={previewVideoRef}
                  src={recordedVideoUrl}
                  controls
                  autoPlay
                  playsInline
                  preload="auto"
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                  onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                  onLoadedMetadata={(e) => setVideoDuration(e.currentTarget.duration || duration)}
                  className="w-full h-full object-contain"
                />

                {!isPlaying && (
                  <button
                    type="button"
                    onClick={togglePlay}
                    className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-rose-600/90 text-white flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all cursor-pointer z-10"
                  >
                    <Play size={28} className="ml-1 fill-current" />
                  </button>
                )}
              </div>

              {/* Recorded Actions Bar */}
              <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/90 backdrop-blur-xl p-3.5 rounded-2xl border border-slate-800 shadow-2xl">
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={togglePlay}
                    className="p-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white transition-all active:scale-95 cursor-pointer shrink-0 shadow-md shadow-rose-600/20"
                  >
                    {isPlaying ? <Pause size={18} /> : <Play size={18} className="fill-current" />}
                  </button>
                  
                  <div>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={16} className="text-emerald-400" />
                      <h4 className="text-xs font-black text-slate-100">Recorded Video Playable</h4>
                    </div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono mt-0.5">
                      {formatDuration(currentTime)} / {formatDuration(videoDuration || duration)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    type="button"
                    onClick={() => window.open(recordedVideoUrl, '_blank')}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer border border-slate-700"
                    title="Open video in dedicated tab"
                  >
                    <Share2 size={14} /> Open
                  </button>

                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                    title="Discard and record again"
                  >
                    <RotateCcw size={14} /> Re-record
                  </button>

                  <button
                    type="button"
                    onClick={handleDownload}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                  >
                    <Download size={14} /> Download
                  </button>
                </div>
              </div>
            </div>

            {/* Chapters & Outline Review Panel */}
            {showPrompterDock && (
              <div className="lg:col-span-4 h-full min-h-[320px]">
                <TeleprompterDock
                  recordingTimeSeconds={currentTime}
                  isRecording={false}
                  onAddChapter={handleAddChapter}
                  chapters={recordedChapters}
                  onSeekToTimestamp={(sec) => {
                    if (previewVideoRef.current) {
                      previewVideoRef.current.currentTime = sec;
                    }
                  }}
                  theme={theme}
                />
              </div>
            )}
          </div>
        )}

        {/* State 3: Idle / Configuration before starting */}
        {recordingState === 'idle' && (
          <div className="text-center max-w-lg space-y-6">
            <div className="relative">
              <div className="absolute inset-0 bg-cyan-500/20 blur-3xl rounded-full scale-150"></div>
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-cyan-500/20 to-indigo-500/20 border border-cyan-500/30 flex items-center justify-center mx-auto text-cyan-400 relative animate-pulse shadow-xl">
                <Layers size={40} />
              </div>
            </div>

            <div className="space-y-2 relative">
              <h4 className="text-2xl font-black tracking-tight">HD Screen & Smartboard Recorder</h4>
              <p className="text-xs text-slate-400 font-medium leading-relaxed">
                Capture the interactive presentation smartboard with live chalkboard handwriting, LaTeX derivations, diagrams, and clear audio narration.
              </p>
            </div>

            {/* Source Selection Tabs */}
            <div className="flex items-center justify-center p-1 bg-slate-900/80 border border-slate-800 rounded-2xl w-full gap-1">
              <button
                type="button"
                onClick={() => { 
                  setRecordingSource('smartboard'); 
                  setRecordSmartboardMode(true);
                  setError(null); 
                  setIsIframePolicyBlocked(false); 
                }}
                className={cn(
                  "flex-1 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer relative",
                  recordingSource === 'smartboard' 
                    ? "bg-cyan-600 text-white shadow-lg shadow-cyan-600/30" 
                    : "text-slate-400 hover:text-slate-200"
                )}
              >
                <Layers size={14} /> Smartboard (1080p)
              </button>
              <button
                type="button"
                onClick={() => { 
                  setRecordingSource('screen'); 
                  setRecordSmartboardMode(false);
                  setError(null); 
                  setIsIframePolicyBlocked(false); 
                }}
                className={cn(
                  "flex-1 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer",
                  recordingSource === 'screen' ? "bg-rose-600 text-white shadow-lg" : "text-slate-400 hover:text-slate-200"
                )}
              >
                <Monitor size={14} /> Screen & Window
              </button>
              <button
                type="button"
                onClick={() => { 
                  setRecordingSource('camera'); 
                  setRecordSmartboardMode(false);
                  setError(null); 
                  setIsIframePolicyBlocked(false); 
                }}
                className={cn(
                  "flex-1 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer",
                  recordingSource === 'camera' ? "bg-indigo-600 text-white shadow-lg" : "text-slate-400 hover:text-slate-200"
                )}
              >
                <Video size={14} /> Camera & Mic
              </button>
            </div>

            {/* Recording Options & Dedicated Toggles */}
            <div className="space-y-3">
              {/* Dedicated Record Smartboard Toggle */}
              <div className="bg-slate-900/60 border border-cyan-500/30 rounded-2xl p-4 flex items-center justify-between text-left shadow-lg">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "p-2 rounded-xl",
                    recordSmartboardMode ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" : "bg-slate-800 text-slate-500"
                  )}>
                    <Layers size={18} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h5 className="text-xs font-black text-slate-200">Record Presentation Smartboard</h5>
                      <span className="px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 text-[9px] font-bold uppercase tracking-wider">
                        1080p Direct
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400">Activates display capture stream specifically for the smartboard component</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nextVal = !recordSmartboardMode;
                    setRecordSmartboardMode(nextVal);
                    if (nextVal) setRecordingSource('smartboard');
                    else if (recordingSource === 'smartboard') setRecordingSource('screen');
                  }}
                  className={cn(
                    "w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0",
                    recordSmartboardMode ? "bg-cyan-600" : "bg-slate-700"
                  )}
                  title="Toggle Record Smartboard Stream"
                >
                  <span className={cn(
                    "absolute top-1 w-4 h-4 rounded-full bg-white transition-transform",
                    recordSmartboardMode ? "left-7" : "left-1"
                  )} />
                </button>
              </div>

              {/* Picture-in-Picture Live Preview Toggle */}
              <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between text-left shadow-lg">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "p-2 rounded-xl",
                    showPipOverlay ? "bg-indigo-500/20 text-indigo-400" : "bg-slate-800 text-slate-500"
                  )}>
                    <Tv size={18} />
                  </div>
                  <div>
                    <h5 className="text-xs font-black text-slate-200">Picture-in-Picture (PiP) Window Overlay</h5>
                    <p className="text-[10px] text-slate-400">Live floating preview of smartboard output during session</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowPipOverlay(!showPipOverlay)}
                  className={cn(
                    "w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0",
                    showPipOverlay ? "bg-indigo-600" : "bg-slate-700"
                  )}
                  title="Toggle Smartboard Picture-in-Picture Preview"
                >
                  <span className={cn(
                    "absolute top-1 w-4 h-4 rounded-full bg-white transition-transform",
                    showPipOverlay ? "left-7" : "left-1"
                  )} />
                </button>
              </div>

              {/* Microphone Toggle */}
              <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-4 flex items-center justify-between text-left shadow-lg">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "p-2 rounded-xl",
                    includeMic ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-800 text-slate-500"
                  )}>
                    {includeMic ? <Mic size={18} /> : <MicOff size={18} />}
                  </div>
                  <div>
                    <h5 className="text-xs font-black text-slate-200">Include Microphone Audio</h5>
                    <p className="text-[10px] text-slate-400">Record your voice narration along with teacher audio</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIncludeMic(!includeMic)}
                  className={cn(
                    "w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0",
                    includeMic ? "bg-emerald-600" : "bg-slate-700"
                  )}
                >
                  <span className={cn(
                    "absolute top-1 w-4 h-4 rounded-full bg-white transition-transform",
                    includeMic ? "left-7" : "left-1"
                  )} />
                </button>
              </div>
            </div>

            {/* IFrame Security Policy Restriction Warning */}
            {isIframePolicyBlocked ? (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 text-left space-y-3 shadow-xl animate-in fade-in duration-300">
                <div className="flex items-start gap-2.5 text-amber-400">
                  <AlertCircle size={20} className="shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-black uppercase tracking-wider">Browser Preview Sandbox Restriction</h5>
                    <p className="text-[11px] text-slate-300 font-medium leading-relaxed mt-1">
                      Browsers restrict system screen capture (<code className="bg-amber-950/60 px-1 py-0.5 rounded text-amber-300 text-[10px]">display-capture</code>) inside embedded preview iFrames. You can use <strong>Record Smartboard</strong> mode to capture the classroom presentation smartboard directly!
                    </p>
                  </div>
                </div>

                <div className="pt-1 flex flex-col sm:flex-row items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setRecordingSource('smartboard');
                      setRecordSmartboardMode(true);
                      startRecording('smartboard');
                    }}
                    className="w-full sm:flex-1 py-2.5 px-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/20 transition-all active:scale-95 cursor-pointer"
                  >
                    <Layers size={14} /> Record Presentation Smartboard
                  </button>
                  <button
                    type="button"
                    onClick={() => window.open(window.location.href, '_blank')}
                    className="w-full sm:w-auto py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all active:scale-95 cursor-pointer"
                  >
                    <Share2 size={14} /> Open in New Tab
                  </button>
                </div>
              </div>
            ) : error ? (
              <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-3 flex items-center gap-2 text-rose-400 text-xs font-bold text-left">
                <AlertCircle size={16} className="shrink-0" />
                <span>{error}</span>
              </div>
            ) : null}

            <div className="pt-2">
              <button
                onClick={() => startRecording(recordingSource)}
                className="w-full py-4 bg-gradient-to-r from-cyan-600 via-indigo-600 to-rose-600 hover:from-cyan-500 hover:via-indigo-500 hover:to-rose-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-cyan-600/20 transition-all active:scale-95 flex items-center justify-center gap-2.5 cursor-pointer"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping"></span>
                <Film size={18} />
                Start {recordingSource === 'smartboard' || recordSmartboardMode ? 'Presentation Smartboard' : recordingSource === 'screen' ? 'Screen' : 'Camera'} Recording
              </button>
            </div>

            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pt-2">
              Full HD 1080p50 Smartboard Video & Studio Audio Pipeline
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
