import React, { useState, useEffect, useRef } from 'react';
import { cn, downloadElegantQR, triggerHapticFeedback, saveQrHistoryItem, getSyncShareUrl } from '../lib/utils';
import { CONFIG, PERSONAS } from '../lib/constants';
import { generateSpeech, convertPcmToWav } from '../lib/gemini';
import { Brain, Sparkles, Volume2, VolumeX, ShieldAlert, Sun, Moon, Zap, UserCheck, MessageSquare, Info, Sliders, Link, Link2Off, BookOpen, Languages, Scale, Bell, Clock, Bookmark, Trash, Type, AlignLeft, Eye, PenTool, Eraser, Palette, ZoomIn, Mic, Radio, Music, QrCode, Share2, Copy, Download, Check, FileText, X, Camera, Scan, History, Heart } from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';
import { AudioDiagnostics } from './AudioDiagnostics';
import { TermsModal } from './TermsModal';
import { QrCodeScanner } from './QrCodeScanner';
import { QrHistoryTab } from './QrHistoryTab';
import { DeviceSettingsUI } from '../modules/device-tier/DeviceSettingsUI';
import { WellbeingHub } from '../modules/wellbeing/WellbeingHub';
import { FocusCoachHub } from '../modules/focus-coach/FocusCoachHub';
import { BlackboardEraserStyle, BlackboardEraserSpeed, BlackboardDustDensity, ChalkColor, ChalkColorOption, UserProfile } from '../types';
import {
  playChalkSound,
  playDiagramThud,
  playEquationChalkScratch,
  playChalkColorSwitchSound,
  isChalkSoundEnabled,
  setChalkSoundEnabled,
  isEquationChalkSoundEnabled,
  setEquationChalkSoundEnabled,
  isDiagramThudEnabled,
  setDiagramThudEnabled
} from '../lib/chalkAudio';

interface SettingsModalProps {
  theme?: 'light' | 'dark';
  themeMode?: 'light' | 'dark' | 'auto' | 'high-contrast' | 'high-contrast-green';
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  isThinking: boolean;
  setIsThinking: (val: boolean) => void;
  isTTSEnabled: boolean;
  setIsTTSEnabled: (val: boolean) => void;
  isLowLatency: boolean;
  setIsLowLatency: (val: boolean) => void;
  onToggleTheme: (theme: 'light' | 'dark' | 'auto' | 'high-contrast' | 'high-contrast-green') => void;
  showNotification: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  ttsRate?: number;
  setTtsRate?: (val: number) => void;
  typingPace?: string;
  setTypingPace?: (val: string) => void;
  linkSpeeds?: boolean;
  setLinkSpeeds?: (val: boolean) => void;
  selectionColor?: 'default' | 'high-contrast';
  setSelectionColor?: (val: 'default' | 'high-contrast') => void;
  showAudioDiagnostics: boolean;
  setShowAudioDiagnostics: (val: boolean) => void;
  analyser?: AnalyserNode | null;
  audioContext?: AudioContext | null;
  isSpeaking?: boolean;
  pronunciationPrecision?: 'standard' | 'formal';
  setPronunciationPrecision?: (val: 'standard' | 'formal') => void;
  voiceSensitivity?: number;
  setVoiceSensitivity?: (val: number) => void;
  blackboardWritingSpeed?: number;
  setBlackboardWritingSpeed?: (val: number) => void;
  isProfessorMode?: boolean;
  setIsProfessorMode?: (val: boolean) => void;
  onClose?: () => void;
  accessibilityTextSize?: 'sm' | 'md' | 'lg' | 'xl';
  setAccessibilityTextSize?: (val: 'sm' | 'md' | 'lg' | 'xl') => void;
  accessibilityLineSpacing?: 'normal' | 'relaxed' | 'loose';
  setAccessibilityLineSpacing?: (val: 'normal' | 'relaxed' | 'loose') => void;
  accessibilityContrast?: 'normal' | 'high' | 'ultra';
  setAccessibilityContrast?: (val: 'normal' | 'high' | 'ultra') => void;
  selectedPersonaId?: string;
  onSelectPersonaId?: (id: string) => void;
  diagramStyle?: 'clean-academic' | 'hand-drawn';
  setDiagramStyle?: (val: 'clean-academic' | 'hand-drawn') => void;
  silentDraw?: boolean;
  setSilentDraw?: (val: boolean) => void;
  eraserStyle?: BlackboardEraserStyle;
  setEraserStyle?: (val: BlackboardEraserStyle) => void;
  eraserSpeed?: BlackboardEraserSpeed;
  setEraserSpeed?: (val: BlackboardEraserSpeed) => void;
  eraserDustDensity?: BlackboardDustDensity;
  setEraserDustDensity?: (val: BlackboardDustDensity) => void;
  onOpenQuadSpeedSync?: () => void;
}

export interface GlossaryItem {
  symbol: string;
  name: string;
  spokenEnglish: string;
  spokenHinglish: string;
  spokenHindi: string;
}

export const GLOSSARY_ITEMS: GlossaryItem[] = [
  { symbol: 'C/m²', name: 'Coulomb per square meter', spokenEnglish: 'coulomb per square meter', spokenHinglish: 'coulomb prati miter square', spokenHindi: 'कूलम्ब प्रति मीटर स्क्वायर' },
  { symbol: 'C/m³', name: 'Coulomb per cubic meter', spokenEnglish: 'coulomb per cubic meter', spokenHinglish: 'coulomb prati miter cube', spokenHindi: 'कूलम्ब प्रति मीटर क्यूब' },
  { symbol: 'C/m', name: 'Coulomb per meter', spokenEnglish: 'coulomb per meter', spokenHinglish: 'coulomb prati miter', spokenHindi: 'कूलम्ब प्रति मीटर' },
  { symbol: 'kg/m³', name: 'Kilogram per cubic meter', spokenEnglish: 'kilogram per cubic meter', spokenHinglish: 'kilogram prati miter cube', spokenHindi: 'किलोग्राम प्रति मीटर क्यूब' },
  { symbol: 'N/C', name: 'Newton per Coulomb', spokenEnglish: 'Newton per Coulomb', spokenHinglish: 'newton prati coulomb', spokenHindi: 'न्यूटन प्रति कूलम्ब' },
  { symbol: 'V/m', name: 'Volt per meter', spokenEnglish: 'volt per meter', spokenHinglish: 'volt prati miter', spokenHindi: 'वोल्ट प्रति मीटर' },
  { symbol: 'F/m', name: 'Farad per meter', spokenEnglish: 'farad per meter', spokenHinglish: 'farad prati miter', spokenHindi: 'फैराड प्रति मीटर' },
  { symbol: 'J/C', name: 'Joule per Coulomb', spokenEnglish: 'joule per Coulomb', spokenHinglish: 'joule prati coulomb', spokenHindi: 'जूल प्रति कूलम्ब' },
  { symbol: 'N·m', name: 'Newton meter', spokenEnglish: 'Newton meter', spokenHinglish: 'newton miter', spokenHindi: 'न्यूटन मीटर' },
  { symbol: 'm/s²', name: 'Meter per second squared', spokenEnglish: 'meter per second squared', spokenHinglish: 'meter prati second square', spokenHindi: 'मीटर प्रति सेकंड स्क्वायर' }
];

export const GlossaryAccordion: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <div className={cn(
      "border rounded-2xl overflow-hidden transition-all duration-300",
      theme === 'dark' ? "border-slate-800 bg-slate-900/20" : "border-slate-200 bg-slate-50/30"
    )}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-800/10 dark:hover:bg-slate-800/25 transition-colors"
      >
        <div className="flex items-center gap-2.5">
          <BookOpen size={16} className="text-indigo-500" />
          <div>
            <h4 className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100">
              Scientific Unit Pronunciation Glossary
            </h4>
            <p className="text-[10px] text-slate-550 dark:text-slate-400 mt-0.5">
              Review standard spoken formulas utilized by the AI Tutor
            </p>
          </div>
        </div>
        <span className={cn(
          "text-[10px] transition-transform duration-200 text-slate-400",
          isOpen ? "transform rotate-180" : ""
        )}>
          ▼
        </span>
      </button>

      {isOpen && (
        <div className="px-5 pb-5 border-t border-slate-200 dark:border-slate-800 pt-4 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[11px] border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 dark:text-slate-550 font-bold">
                  <th className="pb-2 font-mono text-xs">Symbol</th>
                  <th className="pb-2">Standard Name</th>
                  <th className="pb-2">English Spoken</th>
                  <th className="pb-2 text-indigo-500 dark:text-indigo-400">AI Tutor Spoken (Hinglish)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                {GLOSSARY_ITEMS.map((item, index) => (
                  <tr key={index} className="hover:bg-slate-500/5 transition-colors">
                    <td className="py-2.5 font-mono font-bold text-slate-800 dark:text-slate-200">{item.symbol}</td>
                    <td className="py-2.5 text-slate-600 dark:text-slate-400">{item.name}</td>
                    <td className="py-2.5 font-mono text-slate-450 dark:text-slate-500">{item.spokenEnglish}</td>
                    <td className="py-2.5 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {item.spokenHinglish} <span className="text-[9px] text-slate-400 dark:text-slate-500 block font-normal font-sans">({item.spokenHindi})</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export const SettingsModal: React.FC<SettingsModalProps> = ({
  theme = 'light',
  themeMode = 'auto',
  user,
  setUser,
  isThinking,
  setIsThinking,
  isTTSEnabled,
  setIsTTSEnabled,
  isLowLatency,
  setIsLowLatency,
  onToggleTheme,
  showNotification,
  ttsRate = 1.0,
  setTtsRate = () => {},
  typingPace = 'fluent',
  setTypingPace = () => {},
  linkSpeeds = false,
  setLinkSpeeds = () => {},
  selectionColor = 'default',
  setSelectionColor = () => {},
  showAudioDiagnostics,
  setShowAudioDiagnostics,
  analyser,
  audioContext,
  isSpeaking,
  pronunciationPrecision = 'standard',
  setPronunciationPrecision = () => {},
  voiceSensitivity = 0.5,
  setVoiceSensitivity = () => {},
  blackboardWritingSpeed = 1.0,
  setBlackboardWritingSpeed = () => {},
  isProfessorMode = true,
  setIsProfessorMode = () => {},
  onClose = () => {},
  accessibilityTextSize = 'md',
  setAccessibilityTextSize = () => {},
  accessibilityLineSpacing = 'relaxed',
  setAccessibilityLineSpacing = () => {},
  accessibilityContrast = 'normal',
  setAccessibilityContrast = () => {},
  selectedPersonaId = 'encouraging_coach',
  onSelectPersonaId = () => {},
  diagramStyle: propDiagramStyle,
  setDiagramStyle: propSetDiagramStyle,
  silentDraw: propSilentDraw,
  setSilentDraw: propSetSilentDraw,
  eraserStyle: propEraserStyle,
  setEraserStyle: propSetEraserStyle,
  eraserSpeed: propEraserSpeed,
  setEraserSpeed: propSetEraserSpeed,
  eraserDustDensity: propEraserDustDensity,
  setEraserDustDensity: propSetEraserDustDensity,
  onOpenQuadSpeedSync
}) => {
  const [showTerms, setShowTerms] = useState(false);
  const [activeTab, setActiveTab] = useState<'tutor' | 'accessibility' | 'qr_history' | 'device_tier' | 'wellbeing' | 'focus_coach'>('tutor');
  const currentTutorId = user.tutor;

  const [diagramStyle, setDiagramStyleState] = useState<'clean-academic' | 'hand-drawn'>(() => {
    return propDiagramStyle || (localStorage.getItem('omni_chalkboard_drawing_style') as 'clean-academic' | 'hand-drawn') || 'clean-academic';
  });

  const [silentDraw, setSilentDrawState] = useState<boolean>(() => {
    if (propSilentDraw !== undefined) return propSilentDraw;
    const saved = localStorage.getItem('omni_silent_draw');
    return saved !== null ? saved === 'true' : false;
  });

  const [eraserStyle, setEraserStyleState] = useState<BlackboardEraserStyle>(() => {
    return propEraserStyle || (localStorage.getItem('omni_eraser_style') as BlackboardEraserStyle) || 'classic-felt';
  });

  const [eraserSpeed, setEraserSpeedState] = useState<BlackboardEraserSpeed>(() => {
    return propEraserSpeed || (localStorage.getItem('omni_eraser_speed') as BlackboardEraserSpeed) || 'normal';
  });

  const [eraserDustDensity, setEraserDustDensityState] = useState<BlackboardDustDensity>(() => {
    return propEraserDustDensity || (localStorage.getItem('omni_eraser_dust_density') as BlackboardDustDensity) || 'medium';
  });

  // Chalkboard Audio Effects state hooks
  const [chalkMasterAudio, setChalkMasterAudio] = useState<boolean>(() => isChalkSoundEnabled());
  const [equationPitchShiftAudio, setEquationPitchShiftAudio] = useState<boolean>(() => isEquationChalkSoundEnabled());
  const [diagramThudAudio, setDiagramThudAudio] = useState<boolean>(() => isDiagramThudEnabled());

  // Chalk Color Palette state hook
  const [activeChalkColor, setActiveChalkColorState] = useState<ChalkColor>(() => {
    return (localStorage.getItem('omni_active_chalk_color') as ChalkColor) || 'white';
  });

  // Professor Narrator Lecture Mode Voice & Pacing Synchronizer state hook
  const [professorNarrator, setProfessorNarratorState] = useState<boolean>(() => {
    return localStorage.getItem('omni_professor_narrator') === 'true';
  });

  // Zoom to Focus on Blackboard Slate state hook
  const [autoZoomFocus, setAutoZoomFocusState] = useState<boolean>(() => {
    return localStorage.getItem('omni_auto_zoom_focus') !== 'false';
  });

  const [isTestWiping, setIsTestWiping] = useState(false);

  // Share via QR Code state & handlers
  const [showQrModal, setShowQrModal] = useState<boolean>(false);
  const [qrShareMode, setQrShareMode] = useState<'session' | 'note' | 'custom' | 'scan'>('session');
  const [selectedNoteIndex, setSelectedNoteIndex] = useState<number>(0);
  const [customNoteText, setCustomNoteText] = useState<string>(() => {
    return `Study Note on ${user.topic || 'STEM Topic'} (${user.subject || 'General'}): Key concept summary for level ${user.difficulty || 'standard'}.`;
  });
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const getQrShareValue = () => {
    const origin = getSyncShareUrl().split('?')[0].replace(/\/$/, '');
    if (qrShareMode === 'session') {
      const params = new URLSearchParams({
        subject: user.subject || 'STEM',
        topic: user.topic || 'General',
        difficulty: user.difficulty || 'standard',
        tutor: user.tutor || 'socratic',
        sharedBy: user.name || 'Student'
      });
      return `${origin}?${params.toString()}`;
    } else if (qrShareMode === 'note') {
      const bookmarked = user.bookmarkedLessons && user.bookmarkedLessons[selectedNoteIndex];
      if (bookmarked) {
        const params = new URLSearchParams({
          subject: bookmarked.subject || user.subject || 'STEM',
          topic: bookmarked.title || user.topic || 'General',
          lesson: String(bookmarked.lessonNumber || 1),
          note: 'true'
        });
        return `${origin}?${params.toString()}`;
      } else {
        const params = new URLSearchParams({
          subject: user.subject || 'STEM',
          topic: user.topic || 'General',
          note: 'true'
        });
        return `${origin}?${params.toString()}`;
      }
    } else {
      return customNoteText || `Note on ${user.topic || 'STEM Topic'}`;
    }
  };

  const qrValue = getQrShareValue();

  const handleRecordQrGeneration = (val: string) => {
    const title = qrShareMode === 'session'
      ? `${user.subject || 'STEM'} • ${user.topic || 'General'}`
      : qrShareMode === 'note'
      ? `Lesson Note: ${user.topic || 'General'}`
      : customNoteText.slice(0, 30);

    saveQrHistoryItem({
      type: 'generated',
      title,
      subtitle: qrShareMode === 'session' ? 'Shared Study Session' : 'Shared Note',
      payload: val,
      subject: user.subject,
      topic: user.topic,
      difficulty: user.difficulty,
      tutor: user.tutor
    });
  };

  const handleCopyQrValue = async () => {
    try {
      await navigator.clipboard.writeText(qrValue);
      setIsCopied(true);
      triggerHapticFeedback(20);
      handleRecordQrGeneration(qrValue);
      showNotification(
        qrShareMode === 'custom' ? 'Custom note text copied to clipboard!' : 'Shareable session link copied to clipboard!',
        'success'
      );
      setTimeout(() => setIsCopied(false), 2000);
    } catch {
      showNotification('Failed to copy to clipboard', 'error');
    }
  };

  const handleDownloadQrImage = () => {
    try {
      const filename = qrShareMode === 'session'
        ? `omni-session-${(user.topic || 'study').toLowerCase().replace(/[^a-z0-9]/g, '-')}-qr.png`
        : `omni-note-${(user.topic || 'study').toLowerCase().replace(/[^a-z0-9]/g, '-')}-qr.png`;
      downloadElegantQR('settings-share-qr-canvas', filename);
      triggerHapticFeedback([15, 30, 15]);
      handleRecordQrGeneration(qrValue);
      showNotification('QR Code image downloaded successfully!', 'success');
    } catch {
      showNotification('Failed to download QR code image', 'error');
    }
  };

  useEffect(() => {
    const handleSyncSilentDraw = () => {
      const saved = localStorage.getItem('omni_silent_draw');
      setSilentDrawState(saved !== null ? saved === 'true' : false);
    };
    const handleSyncEraser = () => {
      const savedStyle = localStorage.getItem('omni_eraser_style') as BlackboardEraserStyle;
      if (savedStyle) setEraserStyleState(savedStyle);
      const savedSpeed = localStorage.getItem('omni_eraser_speed') as BlackboardEraserSpeed;
      if (savedSpeed) setEraserSpeedState(savedSpeed);
      const savedDust = localStorage.getItem('omni_eraser_dust_density') as BlackboardDustDensity;
      if (savedDust) setEraserDustDensityState(savedDust);
    };
    const handleSyncChalkSettings = () => {
      setChalkMasterAudio(isChalkSoundEnabled());
      setEquationPitchShiftAudio(isEquationChalkSoundEnabled());
      setDiagramThudAudio(isDiagramThudEnabled());
      const savedColor = (localStorage.getItem('omni_active_chalk_color') as ChalkColor) || 'white';
      setActiveChalkColorState(savedColor);
      setProfessorNarratorState(localStorage.getItem('omni_professor_narrator') === 'true');
      setAutoZoomFocusState(localStorage.getItem('omni_auto_zoom_focus') !== 'false');
    };

    window.addEventListener('omni_silent_draw_changed', handleSyncSilentDraw);
    window.addEventListener('omni_eraser_settings_changed', handleSyncEraser);
    window.addEventListener('omni_chalk_settings_changed', handleSyncChalkSettings);
    window.addEventListener('storage', handleSyncSilentDraw);
    window.addEventListener('storage', handleSyncEraser);
    window.addEventListener('storage', handleSyncChalkSettings);
    return () => {
      window.removeEventListener('omni_silent_draw_changed', handleSyncSilentDraw);
      window.removeEventListener('omni_eraser_settings_changed', handleSyncEraser);
      window.removeEventListener('omni_chalk_settings_changed', handleSyncChalkSettings);
      window.removeEventListener('storage', handleSyncSilentDraw);
      window.removeEventListener('storage', handleSyncEraser);
      window.removeEventListener('storage', handleSyncChalkSettings);
    };
  }, []);

  const handleToggleChalkMasterAudio = (enabled: boolean) => {
    setChalkMasterAudio(enabled);
    setChalkSoundEnabled(enabled);
    window.dispatchEvent(new Event('omni_chalk_settings_changed'));
    if (enabled) playChalkSound('tap', 0.3);
    showNotification(enabled ? 'Chalkboard Audio Effects enabled 🔊' : 'Chalkboard Audio Effects muted 🔇', 'info');
  };

  const handleToggleEquationPitchShift = (enabled: boolean) => {
    setEquationPitchShiftAudio(enabled);
    setEquationChalkSoundEnabled(enabled);
    window.dispatchEvent(new Event('omni_chalk_settings_changed'));
    if (enabled) playEquationChalkScratch(60, 0.3);
    showNotification(enabled ? 'Dynamic Equation Pitch-Shift Audio enabled 📐' : 'Equation Pitch-Shift Audio disabled', 'info');
  };

  const handleToggleDiagramThud = (enabled: boolean) => {
    setDiagramThudAudio(enabled);
    setDiagramThudEnabled(enabled);
    window.dispatchEvent(new Event('omni_chalk_settings_changed'));
    if (enabled) playDiagramThud(0.35);
    showNotification(enabled ? 'Diagram Placement Slate Thud enabled 🪵' : 'Diagram Slate Thud disabled', 'info');
  };

  const handleSelectChalkColor = (color: ChalkColor) => {
    setActiveChalkColorState(color);
    localStorage.setItem('omni_active_chalk_color', color);
    window.dispatchEvent(new Event('omni_chalk_settings_changed'));
    playChalkColorSwitchSound(0.25);
    const colorNames: Record<ChalkColor, string> = {
      white: 'Classic White ⚪',
      yellow: 'Golden Yellow 🟡',
      red: 'Coral Red 🔴',
      blue: 'Cyan Blue 🔵'
    };
    showNotification(`Active Chalk Color: ${colorNames[color]} • Applied to next generated derivations and diagrams`, 'success');
  };

  const handleToggleProfessorNarrator = (enabled: boolean) => {
    setProfessorNarratorState(enabled);
    localStorage.setItem('omni_professor_narrator', enabled ? 'true' : 'false');
    window.dispatchEvent(new Event('omni_chalk_settings_changed'));
    playChalkSound('tap', 0.25);
    showNotification(
      enabled
        ? 'Professor Narrator Active: AI voice switches to formal lecture authority with drawing-cadence synchronized pacing 🎓'
        : 'Professor Narrator Disabled: Standard conversational speech pacing restored',
      'info'
    );
  };

  const handleToggleAutoZoomFocus = (enabled: boolean) => {
    setAutoZoomFocusState(enabled);
    localStorage.setItem('omni_auto_zoom_focus', enabled ? 'true' : 'false');
    window.dispatchEvent(new Event('omni_chalk_settings_changed'));
    playChalkSound('tap', 0.2);
    showNotification(
      enabled
        ? 'Zoom to Focus ON: Smooth auto pan-and-zoom highlights active equations & diagrams for fine detail 🔍'
        : 'Zoom to Focus OFF: Full slate overview maintained',
      'info'
    );
  };

  const handleEraserStyleChange = (style: BlackboardEraserStyle) => {
    setEraserStyleState(style);
    if (propSetEraserStyle) propSetEraserStyle(style);
    localStorage.setItem('omni_eraser_style', style);
    window.dispatchEvent(new Event('omni_eraser_settings_changed'));
    const names = {
      'classic-felt': 'Traditional Wood & Felt 🪵',
      'dry-cloth': 'Dry Cloth Wipe 🧣',
      'sponge-wipe': 'Moist Sponge Wipe 🧽'
    };
    showNotification(`Eraser style updated: ${names[style]}`, 'info');
  };

  const handleEraserSpeedChange = (speed: BlackboardEraserSpeed) => {
    setEraserSpeedState(speed);
    if (propSetEraserSpeed) propSetEraserSpeed(speed);
    localStorage.setItem('omni_eraser_speed', speed);
    window.dispatchEvent(new Event('omni_eraser_settings_changed'));
    const names = {
      'fast': 'Fast (0.7s) ⚡',
      'normal': 'Normal (1.2s) ⏳',
      'slow': 'Deliberate (2.0s) 🧘'
    };
    showNotification(`Wipe transition speed set to ${names[speed]}`, 'info');
  };

  const handleEraserDustDensityChange = (density: BlackboardDustDensity) => {
    setEraserDustDensityState(density);
    if (propSetEraserDustDensity) propSetEraserDustDensity(density);
    localStorage.setItem('omni_eraser_dust_density', density);
    window.dispatchEvent(new Event('omni_eraser_settings_changed'));
    const names = {
      'low': 'Low (Subtle Haze) 🌫️',
      'medium': 'Medium (Authentic Cloud) 💨',
      'high': 'High (Dense Plume) 🌪️'
    };
    showNotification(`Dust particle density set to ${names[density]}`, 'info');
  };

  const triggerTestWipe = () => {
    if (isTestWiping) return;
    setIsTestWiping(true);
    const duration = eraserSpeed === 'fast' ? 700 : eraserSpeed === 'slow' ? 2000 : 1200;
    setTimeout(() => {
      setIsTestWiping(false);
    }, duration + 300);
  };

  const handleSilentDrawChange = (enabled: boolean) => {
    setSilentDrawState(enabled);
    if (propSetSilentDraw) propSetSilentDraw(enabled);
    localStorage.setItem('omni_silent_draw', String(enabled));
    window.dispatchEvent(new Event('omni_silent_draw_changed'));
    showNotification(
      enabled
        ? "Silent-Draw Enabled: AI will automatically render SVG figures & LaTeX diagrams without explicit text triggers in classroom mode."
        : "Silent-Draw Disabled: SVG figures & diagrams will be generated on-demand.",
      'info'
    );
  };

  const handleDiagramStyleChange = (style: 'clean-academic' | 'hand-drawn') => {
    setDiagramStyleState(style);
    if (propSetDiagramStyle) propSetDiagramStyle(style);
    localStorage.setItem('omni_chalkboard_drawing_style', style);
    window.dispatchEvent(new Event('omni_diagram_style_changed'));
    showNotification(
      `Auto-generated diagram style set to ${style === 'hand-drawn' ? 'Hand-Drawn Chalk ✏️' : 'Clean Academic Boardwork 📐'}!`,
      'info'
    );
  };

  const [isPreviewLoading, setIsPreviewLoading] = useState(false);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const handleVoicePreview = async () => {
    // Stop any existing preview audio
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
      setIsPlayingPreview(false);
    }

    const persona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[0];
    const voiceName = persona.voiceName || 'Kore';

    let previewText = "Hello! I am your personal tutor. Let's study today's curriculum with maximum precision.";
    if (persona.id === 'formal_professor') {
      previewText = "Greetings. I am your Formal Professor. Let us study today's curriculum with maximum precision.";
    } else if (persona.id === 'encouraging_coach') {
      previewText = "Hey! It's your coach. You're doing amazing! Let's crush this next lesson together!";
    } else if (persona.id === 'minimalist_mentor') {
      previewText = "Hello. I am your mentor. Let us clear away all distractions and focus on the essence.";
    } else if (persona.id === 'epic_storyteller') {
      previewText = "Welcome, traveler. I am your storyteller. Let us embark on a legendary journey of knowledge!";
    } else if (persona.id === 'axiomatic_mind') {
      previewText = "Greetings. I am the Axiomatic Mind. Let us analyze this concept through strict, elegant logic.";
    }

    setIsPreviewLoading(true);
    try {
      showNotification(`Generating voice preview for ${persona.name}...`, 'info');
      const pcmData = await generateSpeech(previewText, voiceName);
      if (!pcmData) {
        showNotification('Failed to generate speech preview. Please try again.', 'error');
        setIsPreviewLoading(false);
        return;
      }

      const wavBase64 = convertPcmToWav(pcmData);
      const audio = new Audio(`data:audio/wav;base64,${wavBase64}`);
      audioRef.current = audio;
      
      audio.onplay = () => {
        setIsPreviewLoading(false);
        setIsPlayingPreview(true);
      };
      audio.onended = () => {
        setIsPlayingPreview(false);
      };
      audio.onerror = () => {
        showNotification('Audio playback failed.', 'error');
        setIsPreviewLoading(false);
        setIsPlayingPreview(false);
      };

      await audio.play();
    } catch (error) {
      console.error('Failed to play preview:', error);
      showNotification('Voice preview generation failed.', 'error');
      setIsPreviewLoading(false);
      setIsPlayingPreview(false);
    }
  };

  const handleReadingSpeedChange = (rate: number) => {
    setTtsRate(rate);
    localStorage.setItem('omni_tts_rate', String(rate));
    
    if (linkSpeeds) {
      let linkedPace = 'fluent';
      if (rate === 0.5 || rate === 0.75) linkedPace = 'deliberate';
      else if (rate === 1.0) linkedPace = 'fluent';
      else if (rate === 1.2 || rate === 1.5) linkedPace = 'swift';
      else if (rate === 2.0) linkedPace = 'instant';
      
      setTypingPace(linkedPace);
      localStorage.setItem('omni_typing_pace', linkedPace);
    }
  };

  const handleWritingSpeedChange = (pace: string) => {
    setTypingPace(pace);
    localStorage.setItem('omni_typing_pace', pace);
    
    let speedVal = 1.0;
    if (pace === 'deliberate') speedVal = 0.6;
    else if (pace === 'fluent') speedVal = 1.0;
    else if (pace === 'swift') speedVal = 1.6;
    else if (pace === 'instant') speedVal = 3.0;

    setBlackboardWritingSpeed(speedVal);
    localStorage.setItem('omni_blackboard_writing_speed', String(speedVal));
    
    if (linkSpeeds) {
      let linkedRate = 1.0;
      if (pace === 'deliberate') linkedRate = 0.75;
      else if (pace === 'fluent') linkedRate = 1.0;
      else if (pace === 'swift') linkedRate = 1.5;
      else if (pace === 'instant') linkedRate = 2.0;
      
      setTtsRate(linkedRate);
      localStorage.setItem('omni_tts_rate', String(linkedRate));
    }
  };

  const handleBlackboardWritingSpeedChange = (spd: number) => {
    const rounded = Math.round(spd * 100) / 100;
    setBlackboardWritingSpeed(rounded);
    localStorage.setItem('omni_blackboard_writing_speed', String(rounded));

    let pace = 'fluent';
    if (rounded <= 0.65) pace = 'deliberate';
    else if (rounded <= 1.25) pace = 'fluent';
    else if (rounded <= 2.2) pace = 'swift';
    else pace = 'instant';

    setTypingPace(pace);
    localStorage.setItem('omni_typing_pace', pace);

    if (linkSpeeds) {
      const linkedRate = Math.min(2.0, Math.max(0.5, rounded));
      setTtsRate(linkedRate);
      localStorage.setItem('omni_tts_rate', String(linkedRate));
    }
  };

  const handleToggleLinkSpeeds = (checked: boolean) => {
    setLinkSpeeds(checked);
    localStorage.setItem('omni_link_speeds', String(checked));
    
    if (checked) {
      let linkedPace = 'fluent';
      if (ttsRate === 0.5 || ttsRate === 0.75) linkedPace = 'deliberate';
      else if (ttsRate === 1.0) linkedPace = 'fluent';
      else if (ttsRate === 1.2 || ttsRate === 1.5) linkedPace = 'swift';
      else if (ttsRate === 2.0) linkedPace = 'instant';
      
      setTypingPace(linkedPace);
      localStorage.setItem('omni_typing_pace', linkedPace);
    }
  };

  const handleTutorChange = (tutorId: string) => {
    setUser(prev => {
      const updated = { ...prev, tutor: tutorId };
      localStorage.setItem('omni_user', JSON.stringify(updated));
      return updated;
    });
    
    const tutorInfo = CONFIG.TUTORS[tutorId as keyof typeof CONFIG.TUTORS];
    showNotification(`Tutor personality switched to ${tutorInfo?.name || tutorId}! The system prompt has been dynamically updated.`, 'success');
  };

  const primaryTutors = [
    {
      id: 'socratic',
      name: 'Socratic Guide',
      icon: '🤔',
      description: 'Never gives raw answers. Instead, responds with leading questions to help you derive the solution on your own.',
      promptPreview: 'Guide through questions only. Never give direct answers.',
      badge: 'Analytical'
    },
    {
      id: 'direct',
      name: 'Direct Instructor',
      icon: '📝',
      description: 'Clear, concise, and structured. Best for quick reference, step-by-step math breakdowns, and explicit explanations.',
      promptPreview: 'Provide clear, step-by-step explanations.',
      badge: 'Efficient'
    },
    {
      id: 'encouraging',
      name: 'Encouraging Coach',
      icon: '🏆',
      description: 'Highly positive, motivating, and energetic. Perfect for study fatigue, celebrating milestones, and active reinforcement.',
      promptPreview: 'Be highly positive, encouraging, motivating, and provide energetic celebratory feedback.',
      badge: 'Empowering'
    }
  ];

  const secondaryTutors = Object.entries(CONFIG.TUTORS).filter(([id]) => !['socratic', 'direct', 'encouraging'].includes(id));

  return (
    <div className="space-y-6 py-2">
      {/* Intro */}
      <div className="space-y-1.5">
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Customize your AI Study Buddy, toggle cognitive engines, or adjust real-time accessibility parameters dynamically.
        </p>
      </div>

      {/* Quick QR Code Share Banner Card */}
      <div className={cn(
        "p-4 rounded-2xl border transition-all duration-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
        theme === 'dark'
          ? "bg-gradient-to-r from-indigo-950/60 via-slate-900 to-slate-900 border-indigo-800/60 shadow-lg shadow-indigo-950/30"
          : "bg-gradient-to-r from-indigo-50 via-slate-50 to-white border-indigo-200 shadow-md"
      )}>
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-indigo-600 text-white shadow-md flex-shrink-0">
            <QrCode size={22} />
          </div>
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-100">
                Share or Scan Study Session QR Codes
              </h3>
              <span className="text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30">
                Instant QR Studio
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Generate a shareable QR code for your current study session ({user.subject || 'STEM'} • {user.topic || 'General'}) or scan a code to sync across devices.
            </p>
          </div>
        </div>

        <div className="flex gap-2 self-end sm:self-center flex-shrink-0">
          <button
            type="button"
            onClick={() => {
              setQrShareMode('scan');
              setShowQrModal(true);
            }}
            className="px-3 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition cursor-pointer active:scale-95"
          >
            <Camera size={14} />
            <span>Scan QR</span>
          </button>
          <button
            type="button"
            onClick={() => {
              if (qrShareMode === 'scan') setQrShareMode('session');
              setShowQrModal(!showQrModal);
            }}
            className={cn(
              "px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition cursor-pointer shadow-sm active:scale-95",
              showQrModal && qrShareMode !== 'scan'
                ? "bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700"
                : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20"
            )}
          >
            <Share2 size={14} />
            <span>{showQrModal && qrShareMode !== 'scan' ? 'Hide QR Studio' : 'Share QR'}</span>
          </button>
        </div>
      </div>

      {/* Interactive QR Code Share Studio Drawer / Card */}
      {showQrModal && (
        <div className={cn(
          "p-5 rounded-2xl border-2 transition-all duration-300 space-y-5 animate-in fade-in slide-in-from-top-2",
          theme === 'dark'
            ? "bg-slate-900/90 border-indigo-500/60 shadow-2xl shadow-indigo-950/40"
            : "bg-white border-indigo-400 shadow-xl"
        )}>
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <QrCode className="text-indigo-500" size={18} />
              <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider">
                Interactive QR Code Share & Scan Studio
              </h4>
            </div>
            <button
              type="button"
              onClick={() => setShowQrModal(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => setQrShareMode('session')}
              className={cn(
                "py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
                qrShareMode === 'session'
                  ? "bg-indigo-600 text-white shadow-md font-black"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              )}
            >
              <BookOpen size={13} />
              <span>Study Session</span>
            </button>
            <button
              type="button"
              onClick={() => setQrShareMode('note')}
              className={cn(
                "py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
                qrShareMode === 'note'
                  ? "bg-indigo-600 text-white shadow-md font-black"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              )}
            >
              <Bookmark size={13} />
              <span>Lesson Note</span>
            </button>
            <button
              type="button"
              onClick={() => setQrShareMode('custom')}
              className={cn(
                "py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
                qrShareMode === 'custom'
                  ? "bg-indigo-600 text-white shadow-md font-black"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              )}
            >
              <FileText size={13} />
              <span>Custom Text</span>
            </button>
            <button
              type="button"
              onClick={() => setQrShareMode('scan')}
              className={cn(
                "py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer",
                qrShareMode === 'scan'
                  ? "bg-emerald-600 text-white shadow-md font-black"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              )}
            >
              <Camera size={13} />
              <span>Scan QR Code</span>
            </button>
          </div>

          {/* Main Content Area: QR Code on left/top or Scanner */}
          {qrShareMode === 'scan' ? (
            <QrCodeScanner
              theme={theme}
              user={user}
              setUser={setUser}
              showNotification={showNotification}
              onClose={() => setQrShareMode('session')}
            />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
            {/* Left Column: QR Code Render */}
            <div className="md:col-span-5 flex flex-col items-center justify-center space-y-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
              <div className="p-3 bg-white rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 relative group">
                <QRCodeCanvas
                  id="settings-share-qr-canvas"
                  value={qrValue}
                  size={170}
                  level="H"
                  includeMargin={true}
                />
              </div>
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest text-center">
                Scan to Open on Any Device
              </span>
            </div>

            {/* Right Column: Metadata & Controls */}
            <div className="md:col-span-7 space-y-4">
              {qrShareMode === 'session' && (
                <div className="space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                    Session Metadata
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <span className="text-[10px] text-slate-400 block font-bold">Subject</span>
                      <strong className="text-slate-800 dark:text-slate-200 truncate block">{user.subject || 'STEM'}</strong>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <span className="text-[10px] text-slate-400 block font-bold">Topic</span>
                      <strong className="text-slate-800 dark:text-slate-200 truncate block">{user.topic || 'General'}</strong>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <span className="text-[10px] text-slate-400 block font-bold">Difficulty</span>
                      <strong className="text-slate-800 dark:text-slate-200 capitalize truncate block">{user.difficulty || 'Standard'}</strong>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <span className="text-[10px] text-slate-400 block font-bold">Shared By</span>
                      <strong className="text-slate-800 dark:text-slate-200 truncate block">{user.name || 'Student'}</strong>
                    </div>
                  </div>
                </div>
              )}

              {qrShareMode === 'note' && (
                <div className="space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                    Select Note / Lesson
                  </span>
                  {user.bookmarkedLessons && user.bookmarkedLessons.length > 0 ? (
                    <select
                      value={selectedNoteIndex}
                      onChange={(e) => setSelectedNoteIndex(Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700 focus:ring-2 focus:ring-indigo-500"
                    >
                      {user.bookmarkedLessons.map((note, idx) => (
                        <option key={idx} value={idx}>
                          Lesson {note.lessonNumber}: {note.title} ({note.subject})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300">
                      <strong>Current Active Topic Note:</strong> {user.topic || 'General'} ({user.subject || 'STEM'})
                    </div>
                  )}
                </div>
              )}

              {qrShareMode === 'custom' && (
                <div className="space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                    Custom Study Note / Formula
                  </span>
                  <textarea
                    rows={3}
                    value={customNoteText}
                    onChange={(e) => setCustomNoteText(e.target.value)}
                    placeholder="Enter custom note or formula..."
                    className="w-full p-2.5 rounded-xl border bg-white dark:bg-slate-800 text-xs font-mono text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700 focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>
              )}

              {/* Encoded Preview String */}
              <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 text-[11px] font-mono text-slate-600 dark:text-slate-400 truncate">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Encoded Data String</span>
                <span className="truncate block select-all">{qrValue}</span>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleDownloadQrImage}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition cursor-pointer active:scale-95"
                >
                  <Download size={14} />
                  <span>Download QR Image</span>
                </button>
                <button
                  type="button"
                  onClick={handleCopyQrValue}
                  className={cn(
                    "flex-1 py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer active:scale-95 border",
                    isCopied
                      ? "bg-emerald-600 text-white border-emerald-500 font-bold"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700"
                  )}
                >
                  {isCopied ? <Check size={14} /> : <Copy size={14} />}
                  <span>{isCopied ? 'Copied!' : 'Copy Link / Text'}</span>
                </button>
              </div>
            </div>
          </div>
          )}
        </div>
      )}

      {/* Settings Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800">
        <button
          type="button"
          onClick={() => setActiveTab('tutor')}
          className={cn(
            "flex-1 py-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-all cursor-pointer",
            activeTab === 'tutor'
              ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 font-extrabold"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          )}
        >
          🎓 Tutor & System
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('accessibility')}
          className={cn(
            "flex-1 py-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-all cursor-pointer",
            activeTab === 'accessibility'
              ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 font-extrabold"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          )}
        >
          👁️ Accessibility
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('device_tier')}
          className={cn(
            "flex-1 py-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5",
            activeTab === 'device_tier'
              ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 font-extrabold"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          )}
        >
          <span>📱 Lite Mode</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('qr_history')}
          className={cn(
            "flex-1 py-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5",
            activeTab === 'qr_history'
              ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 font-extrabold"
              : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          )}
        >
          <History size={14} />
          <span>QR History</span>
        </button>
      </div>

      {activeTab === 'tutor' ? (
        <>
          {/* Professor Mode Toggle Card */}
      <div className={cn(
        "p-5 rounded-2xl border-2 transition-all duration-300 space-y-4",
        isProfessorMode 
          ? "border-amber-500/80 bg-amber-500/10 dark:bg-amber-950/20 shadow-lg shadow-amber-500/5"
          : "border-indigo-500/80 bg-indigo-500/10 dark:bg-indigo-950/20 shadow-lg shadow-indigo-500/5"
      )}>
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-2xl">{isProfessorMode ? '🎓' : '💬'}</span>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  {isProfessorMode ? 'Professor Clarity Persona' : 'Standard Tutor Persona'}
                  <span className={cn(
                    "text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full border",
                    isProfessorMode 
                      ? "bg-amber-500/20 border-amber-500/40 text-amber-600 dark:text-amber-400" 
                      : "bg-indigo-500/20 border-indigo-500/40 text-indigo-600 dark:text-indigo-400"
                  )}>
                    {isProfessorMode ? 'High Drawing Frequency' : 'Moderate / On-Demand Drawing'}
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                  Persona & Visual Pedagogy Switcher
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mt-2">
              {isProfessorMode ? (
                <>
                  <strong className="text-amber-500 dark:text-amber-400">Professor Clarity Mode Active:</strong> Deliver structured university-level lectures with Active Pedagogy, Dynamic Figure Teaching, analogies, and <strong>autonomously draw visual figures/diagrams at high frequency</strong> for almost every lesson, teaching directly from the generated diagram.
                </>
              ) : (
                <>
                  <strong className="text-indigo-500 dark:text-indigo-400">Standard Tutor Mode Active:</strong> Deliver conversational, direct step-by-step tutoring. <strong>Visual diagrams are generated moderately or on-demand</strong> when explicitly requested.
                </>
              )}
            </p>
          </div>

          {/* Toggle Switch */}
          <div className="flex flex-col items-end gap-1 flex-shrink-0">
            <label className="relative inline-flex items-center cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isProfessorMode}
                onChange={(e) => {
                  const val = e.target.checked;
                  setIsProfessorMode(val);
                  localStorage.setItem('omni_professor_mode', String(val));
                  showNotification(
                    val 
                      ? "Switched to Professor Clarity Mode! AI will deliver active pedagogy lectures & draw figures dynamically." 
                      : "Switched to Standard Tutor Mode! AI will respond conversationally with on-demand drawings.",
                    "info"
                  );
                }}
                className="sr-only peer"
              />
              <div className="w-12 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500" />
            </label>
            <span className="text-[10px] font-mono font-bold text-slate-400">
              {isProfessorMode ? 'Professor Mode' : 'Standard Mode'}
            </span>
          </div>
        </div>

        {/* Quick Persona Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200/60 dark:border-slate-800/80">
          <button
            type="button"
            onClick={() => {
              setIsProfessorMode(false);
              localStorage.setItem('omni_professor_mode', 'false');
              showNotification("Standard Tutor Mode active: Conversational style with moderate figure drawing.", "info");
            }}
            className={cn(
              "p-3 rounded-xl border text-xs font-bold flex items-center justify-between transition cursor-pointer text-left",
              !isProfessorMode
                ? "bg-indigo-600 text-white border-indigo-500 shadow-md"
                : "bg-slate-100 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">💬</span>
              <div>
                <div className="font-extrabold">Standard Tutor</div>
                <div className="text-[10px] opacity-80 font-normal">Conversational • On-Demand Drawing</div>
              </div>
            </div>
            {!isProfessorMode && <span className="text-xs font-black">✓ Active</span>}
          </button>

          <button
            type="button"
            onClick={() => {
              setIsProfessorMode(true);
              localStorage.setItem('omni_professor_mode', 'true');
              showNotification("Professor Clarity Mode active: Active pedagogy lecture style with dynamic figure teaching.", "info");
            }}
            className={cn(
              "p-3 rounded-xl border text-xs font-bold flex items-center justify-between transition cursor-pointer text-left",
              isProfessorMode
                ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md font-black"
                : "bg-slate-100 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">🎓</span>
              <div>
                <div className="font-extrabold">Professor Clarity</div>
                <div className="text-[10px] opacity-90 font-normal">Active Pedagogy • Dynamic Figures</div>
              </div>
            </div>
            {isProfessorMode && <span className="text-xs font-black">✓ Active</span>}
          </button>
        </div>
      </div>

      {/* Primary Tutor Personalities Toggle Cards */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
          <UserCheck size={14} className="text-indigo-500" />
          Primary AI Tutor Personalities
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {primaryTutors.map(t => {
            const isActive = currentTutorId === t.id;
            return (
              <button
                key={t.id}
                onClick={() => handleTutorChange(t.id)}
                className={cn(
                  "p-5 rounded-2xl border-2 text-left flex flex-col justify-between gap-4 transition-all duration-300 relative overflow-hidden group active:scale-98",
                  isActive
                    ? "border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/20 shadow-md shadow-indigo-500/10"
                    : theme === 'dark' 
                      ? "border-slate-800 bg-slate-900/40 hover:border-slate-700 text-slate-300" 
                      : "border-slate-100 bg-slate-50/50 hover:border-slate-200 text-slate-700"
                )}
              >
                {/* Visual Accent */}
                {isActive && (
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-indigo-500/10 to-violet-500/10 rounded-bl-full pointer-events-none" />
                )}

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl">{t.icon}</span>
                    <span className={cn(
                      "px-2 py-0.5 text-[9px] font-black uppercase rounded-full tracking-wider border",
                      isActive
                        ? "bg-indigo-100 dark:bg-indigo-950/60 border-indigo-200 text-indigo-700 dark:text-indigo-300"
                        : theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-400" : "bg-slate-200/50 border-slate-300/40 text-slate-500"
                    )}>
                      {isActive ? 'Active' : t.badge}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 mt-1">
                      {t.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal mt-1 min-h-[50px]">
                      {t.description}
                    </p>
                  </div>
                </div>

                <div className="w-full pt-2.5 border-t border-dashed border-slate-200/60 dark:border-slate-800/80 mt-1">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">
                    Dynamic System Prompt Rule
                  </span>
                  <span className="text-[10px] font-mono text-indigo-600 dark:text-indigo-400 font-semibold block mt-0.5 truncate">
                    "{t.promptPreview}"
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Other Academic Styles */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
          <Brain size={14} className="text-indigo-500" />
          Other Specialty Learning Styles
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {secondaryTutors.map(([id, t]: [string, any]) => {
            const isActive = currentTutorId === id;
            return (
              <button
                key={id}
                onClick={() => handleTutorChange(id)}
                className={cn(
                  "p-3.5 rounded-xl border flex items-center gap-3 transition-all text-left active:scale-95",
                  isActive
                    ? "border-indigo-500 bg-indigo-50/40 dark:bg-indigo-950/10 text-indigo-700 dark:text-indigo-400 font-extrabold"
                    : theme === 'dark' 
                      ? "border-slate-800 bg-slate-900/60 hover:border-slate-700 text-slate-400" 
                      : "border-slate-100 bg-slate-50 hover:border-slate-200 text-slate-600"
                )}
              >
                <span className="text-lg">{t.icon}</span>
                <div className="truncate">
                  <div className="text-xs font-bold leading-none">{t.name}</div>
                  <div className="text-[9px] text-slate-400 dark:text-slate-500 truncate mt-1">
                    {t.prompt.substring(0, 32)}...
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* System Configurations (Theme, Speech, Thinking) */}
      <div className="space-y-3 pt-2">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
          <Sparkles size={14} className="text-indigo-500" />
          AI Engine Preferences
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Deep Thinking and Latency Mode */}
          <div className={cn(
            "p-5 rounded-2xl border space-y-4",
            theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-slate-50/50 border-slate-200"
          )}>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                  <Brain size={14} className="text-indigo-500 animate-pulse" />
                  Cognitive Deep Thinking
                </div>
                <div className="text-[10px] text-slate-450 dark:text-slate-500">
                  Enable chain-of-thought processing for complex STEM problems.
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isThinking}
                  onChange={(e) => setIsThinking(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600" />
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                  <Zap size={14} className="text-amber-500" />
                  Speed Optimization (Lite)
                </div>
                <div className="text-[10px] text-slate-450 dark:text-slate-500">
                  Switch to low-latency model (omni-flash-lite) for instant replies.
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isLowLatency}
                  onChange={(e) => setIsLowLatency(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600" />
              </label>
            </div>
          </div>

          {/* Speech synthesis and appearance */}
          <div className={cn(
            "p-5 rounded-2xl border space-y-4",
            theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-slate-50/50 border-slate-200"
          )}>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                  <Volume2 size={14} className="text-emerald-500" />
                  Dynamic Voice Synthesis (TTS)
                </div>
                <div className="text-[10px] text-slate-450 dark:text-slate-500">
                  Synthesize replies into high-fidelity speech automatically.
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={isTTSEnabled}
                  onChange={(e) => setIsTTSEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600" />
              </label>
            </div>

            {/* Vocal Persona selection with Preview Button */}
            <div className="flex flex-col gap-3 border-t border-dashed border-slate-200/60 dark:border-slate-800/85 pt-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    <Brain size={14} className="text-indigo-500" />
                    Vocal Persona & Voice Agent
                  </div>
                  <div className="text-[10px] text-slate-450 dark:text-slate-500">
                    Select a distinctive voice actor and accent for your tutor.
                  </div>
                </div>
              </div>
              <div className="flex gap-2 items-center">
                <select
                  value={selectedPersonaId}
                  onChange={(e) => onSelectPersonaId?.(e.target.value)}
                  className={cn(
                    "flex-1 p-2 border rounded-xl text-xs cursor-pointer outline-none transition-colors font-semibold h-[38px]",
                    theme === 'dark' 
                      ? "bg-slate-800/60 border-slate-750 text-slate-200 hover:border-indigo-500" 
                      : "bg-white border-slate-200 text-slate-800 hover:border-indigo-300 focus:border-indigo-500"
                  )}
                >
                  {PERSONAS.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.icon} {p.name} ({p.accent} Accent)
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={handleVoicePreview}
                  disabled={isPreviewLoading}
                  className={cn(
                    "px-3 py-2 rounded-xl text-xs font-black uppercase transition-all tracking-wider border h-[38px] cursor-pointer flex items-center justify-center gap-1.5 min-w-[110px] active:scale-95 disabled:opacity-50",
                    theme === 'dark'
                      ? "bg-indigo-600/20 border-indigo-500/30 text-indigo-400 hover:bg-indigo-600/30"
                      : "bg-indigo-50 border-indigo-150 text-indigo-600 hover:bg-indigo-100"
                  )}
                >
                  {isPreviewLoading ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                      <span>Loading...</span>
                    </>
                  ) : (
                    <>
                      <Volume2 size={14} className={cn(isPlayingPreview ? "animate-pulse text-indigo-400" : "")} />
                      <span>{isPlayingPreview ? "Playing" : "Preview"}</span>
                    </>
                  )}
                </button>
              </div>
              {(() => {
                const activeP = PERSONAS.find(p => p.id === selectedPersonaId);
                if (!activeP) return null;
                return (
                  <p className="text-[10px] text-slate-450 dark:text-slate-500 leading-normal pl-0.5 italic">
                    {activeP.description}
                  </p>
                );
              })()}
            </div>

            {/* Pronunciation Precision style toggle */}
            <div className="flex items-center justify-between border-t border-dashed border-slate-200/60 dark:border-slate-800/85 pt-4">
              <div className="space-y-0.5">
                <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                  <Sparkles size={14} className="text-indigo-500" />
                  Pronunciation Precision style
                </div>
                <div className="text-[10px] text-slate-450 dark:text-slate-500">
                  Choose between 'Standard' and 'Formal Scientific' speech.
                </div>
              </div>
              <div className="flex gap-1.5">
                <button
                  onClick={() => setPronunciationPrecision?.('standard')}
                  className={cn(
                    "px-2.5 py-1.5 rounded-lg border text-[10px] font-black uppercase transition-all",
                    pronunciationPrecision === 'standard' 
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-sm shadow-indigo-600/20" 
                      : theme === 'dark' 
                        ? "bg-slate-800 border-slate-700 text-slate-400 hover:text-white" 
                        : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900"
                  )}
                >
                  Standard
                </button>
                <button
                  onClick={() => setPronunciationPrecision?.('formal')}
                  className={cn(
                    "px-2.5 py-1.5 rounded-lg border text-[10px] font-black uppercase transition-all",
                    pronunciationPrecision === 'formal' 
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-sm shadow-indigo-600/20" 
                      : theme === 'dark' 
                        ? "bg-slate-800 border-slate-700 text-slate-400 hover:text-white" 
                        : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900"
                  )}
                >
                  Formal Scientific
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                  {theme === 'dark' ? <Moon size={14} className="text-blue-400" /> : <Sun size={14} className="text-amber-500" />}
                  System Theme Mode
                </div>
                <div className="text-[10px] text-slate-450 dark:text-slate-500">
                  Switch between deep contrast light and dark modes.
                </div>
              </div>
              <div className="flex gap-1.5">
                <button
                  onClick={() => onToggleTheme('auto')}
                  className={cn(
                    "p-1.5 rounded-lg border text-[10px] font-bold uppercase transition-all",
                    themeMode === 'auto' ? "bg-indigo-500 text-white border-indigo-500 shadow-sm" : theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-400 hover:text-white" : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900"
                  )}
                >
                  Auto
                </button>
                <button
                  onClick={() => onToggleTheme('light')}
                  className={cn(
                    "p-1.5 rounded-lg border text-[10px] font-bold uppercase transition-all",
                    themeMode === 'light' ? "bg-indigo-500 text-white border-indigo-500 shadow-sm" : theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-400 hover:text-white" : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900"
                  )}
                >
                  Light
                </button>
                <button
                  onClick={() => onToggleTheme('dark')}
                  className={cn(
                    "p-1.5 rounded-lg border text-[10px] font-bold uppercase transition-all",
                    themeMode === 'dark' ? "bg-indigo-500 text-white border-indigo-500 shadow-sm" : theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-400 hover:text-white" : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900"
                  )}
                >
                  Dark
                </button>
                <button
                  onClick={() => onToggleTheme('high-contrast-green' as any)}
                  className={cn(
                    "p-1.5 rounded-lg border text-[10px] font-bold uppercase transition-all",
                    themeMode === 'high-contrast-green' ? "bg-emerald-500 text-white border-emerald-500 shadow-sm" : theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-400 hover:text-white" : "bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900"
                  )}
                >
                  Green
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="space-y-0.5">
                <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                  Selection Highlight
                </div>
                <div className="text-[10px] text-slate-450 dark:text-slate-500">
                  Switch text selection color.
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={selectionColor === 'high-contrast'}
                  onChange={(e) => setSelectionColor(e.target.checked ? 'high-contrast' : 'default')}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500" />
              </label>
            </div>

            {/* Auto-Generated Diagram Theme & Style Toggle */}
            <div className="pt-3 border-t border-dashed border-slate-200/60 dark:border-slate-800/85 space-y-2">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    <PenTool size={14} className="text-amber-500" />
                    Auto-Generated Diagram Theme & Style
                  </div>
                  <div className="text-[10px] text-slate-450 dark:text-slate-500">
                    Switch between 'Clean Academic' and 'Hand-Drawn Chalk' for all auto-generated diagrams.
                  </div>
                </div>
                <span className={cn(
                  "px-2 py-0.5 text-[9px] font-black uppercase rounded-full border",
                  diagramStyle === 'hand-drawn'
                    ? "bg-amber-500/20 border-amber-500/40 text-amber-600 dark:text-amber-400"
                    : "bg-indigo-500/20 border-indigo-500/40 text-indigo-600 dark:text-indigo-400"
                )}>
                  {diagramStyle === 'hand-drawn' ? '✏️ Hand-Drawn' : '📐 Clean Academic'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => handleDiagramStyleChange('clean-academic')}
                  className={cn(
                    "p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 active:scale-98",
                    diagramStyle === 'clean-academic'
                      ? "border-indigo-500 bg-indigo-500/10 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 shadow-sm ring-2 ring-indigo-500/30"
                      : theme === 'dark'
                        ? "border-slate-800 bg-slate-900/60 hover:border-slate-700 text-slate-400"
                        : "border-slate-200 bg-white hover:border-slate-300 text-slate-600"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-xs flex items-center gap-1.5">
                      📐 Clean Academic
                    </span>
                    {diagramStyle === 'clean-academic' && (
                      <span className="text-[9px] font-black bg-indigo-600 text-white px-2 py-0.5 rounded-full">Active</span>
                    )}
                  </div>
                  <p className="text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
                    Formal structured boardwork with precise geometric diagrams, straight pointer arrows, and crisp high-contrast annotations.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => handleDiagramStyleChange('hand-drawn')}
                  className={cn(
                    "p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 active:scale-98",
                    diagramStyle === 'hand-drawn'
                      ? "border-amber-500 bg-amber-500/10 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 shadow-sm ring-2 ring-amber-500/30"
                      : theme === 'dark'
                        ? "border-slate-800 bg-slate-900/60 hover:border-slate-700 text-slate-400"
                        : "border-slate-200 bg-white hover:border-slate-300 text-slate-600"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-xs flex items-center gap-1.5">
                      ✏️ Hand-Drawn Chalk
                    </span>
                    {diagramStyle === 'hand-drawn' && (
                      <span className="text-[9px] font-black bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full">Active</span>
                    )}
                  </div>
                  <p className="text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
                    Authentic professor lecture sketch with organic chalk strokes, expressive freehand lines, handwritten notes, and chalk smudges.
                  </p>
                </button>
              </div>
            </div>

            {/* Silent-Draw Classroom Mode Toggle */}
            <div className="pt-3 border-t border-dashed border-slate-200/60 dark:border-slate-800/85 space-y-2">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    <Sparkles size={14} className="text-indigo-500" />
                    Silent-Draw (Classroom Mode)
                  </div>
                  <div className="text-[10px] text-slate-450 dark:text-slate-500">
                    Automatically enables or disables AI rendering of inline SVG figures and LaTeX diagrams without explicit text triggers.
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 ml-2">
                  <input
                    type="checkbox"
                    checked={silentDraw}
                    onChange={(e) => handleSilentDrawChange(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600" />
                </label>
              </div>

              <div className="p-3 rounded-xl border bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-[11px] font-medium text-slate-600 dark:text-slate-300">
                  {silentDraw
                    ? "✨ Active: AI auto-renders figures & LaTeX diagrams silently on every classroom lesson."
                    : "⚡ Off: Figures & diagrams are generated only when explicitly requested by user."}
                </span>
                <span className={cn(
                  "px-2 py-0.5 text-[9px] font-black uppercase rounded-full border shrink-0",
                  silentDraw
                    ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
                    : "bg-slate-200 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-500"
                )}>
                  {silentDraw ? 'Silent-Draw ON' : 'Off'}
                </span>
              </div>
            </div>

            {/* Blackboard Eraser Styles, Speeds & Dust Density */}
            <div className="pt-3 border-t border-dashed border-slate-200/60 dark:border-slate-800/85 space-y-4">
              <div className="space-y-0.5">
                <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                  <Eraser size={14} className="text-amber-500" />
                  Classroom Blackboard Eraser Styles & Wipe Dynamics
                </div>
                <div className="text-[10px] text-slate-450 dark:text-slate-500">
                  Customize the tool material, animation transition duration, and chalk dust particulate cloud when wiping clean lecture boards.
                </div>
              </div>

              {/* Eraser Style Cards */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Eraser Material & Tool Style
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {/* Classic Felt */}
                  <button
                    type="button"
                    onClick={() => handleEraserStyleChange('classic-felt')}
                    className={cn(
                      "p-3 rounded-xl border text-left transition-all cursor-pointer space-y-1.5 relative overflow-hidden",
                      eraserStyle === 'classic-felt'
                        ? "border-amber-500/80 bg-amber-500/10 shadow-sm"
                        : theme === 'dark'
                          ? "border-slate-800 bg-slate-900/60 hover:border-slate-700 text-slate-400"
                          : "border-slate-200 bg-white hover:border-slate-300 text-slate-600"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs flex items-center gap-1.5">
                        🪵 Classic Felt
                      </span>
                      {eraserStyle === 'classic-felt' && (
                        <span className="text-[9px] font-black bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full">Active</span>
                      )}
                    </div>
                    <p className="text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
                      Traditional wooden block with dense wool felt pads and authentic sweeping chalk dust plumes.
                    </p>
                  </button>

                  {/* Dry Cloth Wipe */}
                  <button
                    type="button"
                    onClick={() => handleEraserStyleChange('dry-cloth')}
                    className={cn(
                      "p-3 rounded-xl border text-left transition-all cursor-pointer space-y-1.5 relative overflow-hidden",
                      eraserStyle === 'dry-cloth'
                        ? "border-indigo-500/80 bg-indigo-500/10 shadow-sm"
                        : theme === 'dark'
                          ? "border-slate-800 bg-slate-900/60 hover:border-slate-700 text-slate-400"
                          : "border-slate-200 bg-white hover:border-slate-300 text-slate-600"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs flex items-center gap-1.5">
                        🧣 Dry Cloth Wipe
                      </span>
                      {eraserStyle === 'dry-cloth' && (
                        <span className="text-[9px] font-black bg-indigo-500 text-white px-2 py-0.5 rounded-full">Active</span>
                      )}
                    </div>
                    <p className="text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
                      Soft microfiber cloth wipe creating fluid undulating swiping motions and gentle billowing dust edges.
                    </p>
                  </button>

                  {/* Sponge Wipe */}
                  <button
                    type="button"
                    onClick={() => handleEraserStyleChange('sponge-wipe')}
                    className={cn(
                      "p-3 rounded-xl border text-left transition-all cursor-pointer space-y-1.5 relative overflow-hidden",
                      eraserStyle === 'sponge-wipe'
                        ? "border-emerald-500/80 bg-emerald-500/10 shadow-sm"
                        : theme === 'dark'
                          ? "border-slate-800 bg-slate-900/60 hover:border-slate-700 text-slate-400"
                          : "border-slate-200 bg-white hover:border-slate-300 text-slate-600"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs flex items-center gap-1.5">
                        🧽 Sponge Wipe
                      </span>
                      {eraserStyle === 'sponge-wipe' && (
                        <span className="text-[9px] font-black bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full">Active</span>
                      )}
                    </div>
                    <p className="text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
                      Moist cellulose sponge wipe leaving a clean damp sheen streak and minimal airborne dust.
                    </p>
                  </button>
                </div>
              </div>

              {/* Speed & Dust Controls in 2 columns */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Wipe Transition Speed */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center justify-between">
                    <span>Transition Wipe Speed</span>
                    <span className="text-amber-500 font-bold">
                      {eraserSpeed === 'fast' ? '⚡ Fast (0.7s)' : eraserSpeed === 'slow' ? '🧘 Deliberate (2.0s)' : '⏳ Normal (1.2s)'}
                    </span>
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['fast', 'normal', 'slow'] as const).map(spd => (
                      <button
                        key={spd}
                        type="button"
                        onClick={() => handleEraserSpeedChange(spd)}
                        className={cn(
                          "py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer border text-center capitalize",
                          eraserSpeed === spd
                            ? "bg-amber-500 text-slate-950 border-amber-400 font-black shadow-sm"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400"
                        )}
                      >
                        {spd === 'fast' ? '⚡ Fast' : spd === 'normal' ? '⏳ Normal' : '🧘 Slow'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Dust Particle Density */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center justify-between">
                    <span>Dust Particle Density</span>
                    <span className="text-indigo-400 font-bold">
                      {eraserDustDensity === 'low' ? '🌫️ Low Haze' : eraserDustDensity === 'high' ? '🌪️ High Plume' : '💨 Medium Cloud'}
                    </span>
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['low', 'medium', 'high'] as const).map(dst => (
                      <button
                        key={dst}
                        type="button"
                        onClick={() => handleEraserDustDensityChange(dst)}
                        className={cn(
                          "py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer border text-center capitalize",
                          eraserDustDensity === dst
                            ? "bg-indigo-600 text-white border-indigo-500 font-black shadow-sm"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400"
                        )}
                      >
                        {dst === 'low' ? '🌫️ Low' : dst === 'medium' ? '💨 Med' : '🌪️ High'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Interactive Wipe Test Stage */}
              <div className="p-3.5 rounded-xl border bg-slate-950 text-white border-slate-800 relative overflow-hidden space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-[10px] font-black uppercase tracking-widest text-emerald-400 flex items-center gap-1.5">
                    <span>🎓 Live Blackboard Wipe Preview</span>
                  </div>
                  <button
                    type="button"
                    onClick={triggerTestWipe}
                    disabled={isTestWiping}
                    className="px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wide bg-amber-500 hover:bg-amber-400 text-slate-950 transition cursor-pointer flex items-center gap-1 active:scale-95 shadow"
                  >
                    <Eraser size={11} />
                    <span>{isTestWiping ? "Wiping Board..." : "Test Wipe Animation ▶"}</span>
                  </button>
                </div>

                {/* Live Blackboard Wipe Preview */}
                <div className="h-20 rounded-lg bg-emerald-950/40 border border-emerald-500/20 relative overflow-hidden flex items-center justify-center p-3">
                  {/* Sample Chalk Content */}
                  <div className="text-center font-mono text-xs text-emerald-200/90 select-none">
                    <div className="font-bold text-amber-200 tracking-wider">∇ · E = ρ / ε₀</div>
                    <div className="text-[10px] text-slate-300/80 mt-0.5">∮ B · dl = μ₀(I_enc + ε₀ dΦ_E/dt)</div>
                  </div>

                  {/* Sweep Animation Overlay during Test Wipe */}
                  {isTestWiping && (
                    <div className="absolute inset-0 z-30 pointer-events-none overflow-hidden flex items-center">
                      {/* Dark Slate Mask */}
                      <div className={cn(
                        "absolute inset-0 bg-slate-950/95 z-10 border-r-2 border-amber-300/50",
                        eraserSpeed === 'fast' ? "animate-wipe-reveal-fast" : eraserSpeed === 'slow' ? "animate-wipe-reveal-slow" : "animate-wipe-reveal"
                      )} />

                      {/* Moving Tool */}
                      <div className={cn(
                        "absolute top-0 bottom-0 w-16 z-20 flex flex-col justify-center items-center",
                        eraserStyle === 'dry-cloth' 
                          ? (eraserSpeed === 'fast' ? "animate-cloth-sweep-fast" : eraserSpeed === 'slow' ? "animate-cloth-sweep-slow" : "animate-cloth-sweep")
                          : eraserStyle === 'sponge-wipe'
                          ? (eraserSpeed === 'fast' ? "animate-sponge-sweep-fast" : eraserSpeed === 'slow' ? "animate-sponge-sweep-slow" : "animate-sponge-sweep")
                          : (eraserSpeed === 'fast' ? "animate-eraser-sweep-fast" : eraserSpeed === 'slow' ? "animate-eraser-sweep-slow" : "animate-eraser-sweep")
                      )}>
                        {eraserStyle === 'classic-felt' && (
                          <div className="w-10 h-16 rounded-lg bg-gradient-to-r from-amber-800 to-amber-900 border border-amber-950 shadow-lg relative flex flex-col justify-between p-1">
                            <div className="text-[6px] font-black text-amber-100 uppercase tracking-widest text-center select-none">FELT</div>
                            <div className="w-full h-2 rounded bg-slate-900 border border-slate-700" />
                          </div>
                        )}
                        {eraserStyle === 'dry-cloth' && (
                          <div className="w-12 h-16 rounded-2xl bg-gradient-to-br from-indigo-700 via-indigo-600 to-purple-800 border border-indigo-400 shadow-lg flex items-center justify-center">
                            <div className="text-[7px] font-black text-white uppercase tracking-wider">CLOTH</div>
                          </div>
                        )}
                        {eraserStyle === 'sponge-wipe' && (
                          <div className="w-11 h-14 rounded-xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 border border-amber-700 shadow-lg flex items-center justify-center">
                            <div className="text-[7px] font-black text-slate-900 uppercase tracking-wider">SPONGE</div>
                          </div>
                        )}

                        {/* Dust Particles */}
                        {eraserDustDensity !== 'low' && (
                          <div className="absolute -left-6 top-1/4 w-12 h-12 rounded-full bg-white/20 blur-md animate-eraser-dust" />
                        )}
                        {eraserDustDensity === 'high' && (
                          <div className="absolute -left-4 bottom-1/4 w-10 h-10 rounded-full bg-amber-200/25 blur-md animate-eraser-dust" />
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Chalk Color Palette Controls */}
              <div className="p-4 rounded-xl border bg-slate-900/60 border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Palette size={14} className="text-yellow-400" />
                    <div>
                      <div className="text-xs font-bold text-slate-200">Chalk Color Palette</div>
                      <div className="text-[10px] text-slate-400">Choose chalk stick color applied automatically to new SVG derivations & diagrams</div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-black/40 border border-white/10 text-emerald-300">
                    Active: {activeChalkColor.toUpperCase()}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  {[
                    { id: 'white', label: 'Classic White', hex: '#FFFFFF', desc: 'Standard crisp chalkboard white', bg: 'bg-white', text: 'text-slate-900', ring: 'ring-white' },
                    { id: 'yellow', label: 'Golden Yellow', hex: '#FACC15', desc: 'High visibility theorem chalk', bg: 'bg-yellow-400', text: 'text-yellow-950', ring: 'ring-yellow-400' },
                    { id: 'red', label: 'Coral Red', hex: '#F87171', desc: 'Critical vectors & key caveats', bg: 'bg-red-400', text: 'text-red-950', ring: 'ring-red-400' },
                    { id: 'blue', label: 'Cyan Blue', hex: '#60A5FA', desc: 'Auxiliary axes & integrals', bg: 'bg-blue-400', text: 'text-blue-950', ring: 'ring-blue-400' },
                  ].map((c) => {
                    const isSelected = activeChalkColor === c.id;
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => handleSelectChalkColor(c.id as ChalkColor)}
                        className={cn(
                          "p-2.5 rounded-lg border text-left transition relative cursor-pointer group flex flex-col justify-between",
                          isSelected
                            ? "bg-slate-800 border-white/40 ring-2 shadow-lg " + c.ring
                            : "bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900/60"
                        )}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <div className="flex items-center gap-1.5">
                            <span className={cn("w-3.5 h-3.5 rounded-full border border-black/40 shadow-sm", c.bg)} />
                            <span className="text-xs font-bold text-white">{c.label}</span>
                          </div>
                          {isSelected && <span className="text-[10px] text-emerald-400 font-bold">✓</span>}
                        </div>
                        <span className="text-[9px] text-slate-400 leading-tight">{c.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Chalkboard Audio Effects Section */}
              <div className="p-4 rounded-xl border bg-slate-900/60 border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Music size={14} className="text-emerald-400" />
                    <div>
                      <div className="text-xs font-bold text-slate-200">Chalkboard Audio Effects Engine</div>
                      <div className="text-[10px] text-slate-400">Web Audio synthesis for scratching, pitch-shifted equations, and diagram placement thud</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggleChalkMasterAudio(!chalkMasterAudio)}
                    className={cn(
                      "px-2.5 py-1 rounded-lg text-[10px] font-black uppercase transition cursor-pointer border flex items-center gap-1",
                      chalkMasterAudio
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30"
                        : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"
                    )}
                  >
                    {chalkMasterAudio ? <Volume2 size={11} /> : <VolumeX size={11} />}
                    <span>{chalkMasterAudio ? 'Master Audio ON' : 'Audio Muted'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  {/* Equation Pitch-Shift Audio */}
                  <div className={cn(
                    "p-3 rounded-lg border flex flex-col justify-between transition",
                    equationPitchShiftAudio ? "bg-slate-950/80 border-indigo-500/30" : "bg-slate-950/40 border-slate-800"
                  )}>
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-[11px] font-bold text-indigo-200 flex items-center gap-1">
                          <span>📐 Equation Pitch-Shift</span>
                        </div>
                        <div className="text-[9px] text-slate-400 mt-0.5">
                          Pitch-shifts scratch frequency based on equation length & complexity
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={equationPitchShiftAudio}
                        onChange={(e) => handleToggleEquationPitchShift(e.target.checked)}
                        className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-900 border-slate-700 cursor-pointer"
                      />
                    </div>
                    <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-white/5">
                      <button
                        type="button"
                        onClick={() => playEquationChalkScratch(12, 0.35)}
                        className="px-2 py-0.5 rounded text-[9px] font-bold bg-indigo-900/40 hover:bg-indigo-900/70 text-indigo-300 border border-indigo-500/30 transition cursor-pointer"
                        title="Test short equation high-frequency scratch"
                      >
                        🔊 Short: E = mc²
                      </button>
                      <button
                        type="button"
                        onClick={() => playEquationChalkScratch(140, 0.35)}
                        className="px-2 py-0.5 rounded text-[9px] font-bold bg-indigo-900/40 hover:bg-indigo-900/70 text-indigo-300 border border-indigo-500/30 transition cursor-pointer"
                        title="Test long derivation deep resonant scratch"
                      >
                        🔊 Long: ∮∇×B Derivation
                      </button>
                    </div>
                  </div>

                  {/* Diagram Placement Slate Thud */}
                  <div className={cn(
                    "p-3 rounded-lg border flex flex-col justify-between transition",
                    diagramThudAudio ? "bg-slate-950/80 border-amber-500/30" : "bg-slate-950/40 border-slate-800"
                  )}>
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-[11px] font-bold text-amber-200 flex items-center gap-1">
                          <span>🪵 Diagram Slate Thud</span>
                        </div>
                        <div className="text-[9px] text-slate-400 mt-0.5">
                          Soft wooden slate thud when diagrams or geometry figures mount
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={diagramThudAudio}
                        onChange={(e) => handleToggleDiagramThud(e.target.checked)}
                        className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 bg-slate-900 border-slate-700 cursor-pointer"
                      />
                    </div>
                    <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-white/5">
                      <button
                        type="button"
                        onClick={() => playDiagramThud(0.4)}
                        className="px-2 py-0.5 rounded text-[9px] font-bold bg-amber-900/40 hover:bg-amber-900/70 text-amber-300 border border-amber-500/30 transition cursor-pointer"
                        title="Test diagram slate placement thud"
                      >
                        🔊 Play Diagram Thud
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Professor Narrator & Zoom to Focus Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Professor Narrator Lecture Mode */}
                <div className={cn(
                  "p-3.5 rounded-xl border transition flex flex-col justify-between",
                  professorNarrator ? "bg-emerald-950/30 border-emerald-500/40" : "bg-slate-900/50 border-slate-800"
                )}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-2">
                      <Radio size={14} className="text-emerald-400 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-slate-200">Professor Narrator (Lecture Mode)</div>
                        <div className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                          Enforces formal authoritative university professor tone with measured speech pacing synchronized to blackboard drawing cadence
                        </div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={professorNarrator}
                      onChange={(e) => handleToggleProfessorNarrator(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 bg-slate-900 border-slate-700 cursor-pointer mt-0.5"
                    />
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-white/5 flex items-center justify-between text-[9px]">
                    <span className="text-emerald-300 font-semibold">
                      {professorNarrator ? "🎓 Authoritative Lecture Voice Active" : "💬 Standard Conversational Voice"}
                    </span>
                    <span className="text-slate-400 font-mono">Sync: 0.94x Rate</span>
                  </div>
                </div>

                {/* Zoom to Focus on Active Boardwork */}
                <div className={cn(
                  "p-3.5 rounded-xl border transition flex flex-col justify-between",
                  autoZoomFocus ? "bg-indigo-950/30 border-indigo-500/40" : "bg-slate-900/50 border-slate-800"
                )}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-2">
                      <ZoomIn size={14} className="text-indigo-400 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-slate-200">Zoom to Focus (Classroom Slate)</div>
                        <div className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                          Automated smooth pan-and-zoom animation highlighting active equations & diagrams for fine detail on mobile and desktop
                        </div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={autoZoomFocus}
                      onChange={(e) => handleToggleAutoZoomFocus(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-900 border-slate-700 cursor-pointer mt-0.5"
                    />
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-white/5 flex items-center justify-between text-[9px]">
                    <span className="text-indigo-300 font-semibold">
                      {autoZoomFocus ? "🔍 Auto-Pan & Zoom Enabled" : "📐 Static Slate Overview"}
                    </span>
                    <span className="text-slate-400 font-mono">Scale: 1.45x</span>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Study Reminders & Notifications Console */}
      <div className="space-y-4 pt-2">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
          <Bell size={14} className="text-indigo-500" />
          Study Reminders & Notifications Console
        </h3>

        <div className={cn(
          "p-5 rounded-2xl border space-y-5",
          theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-slate-50/50 border-slate-200"
        )}>
          {/* Status of push permission */}
          <div className="flex items-start justify-between pb-4 border-b border-dashed border-slate-200/60 dark:border-slate-800/80">
            <div className="space-y-1">
              <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                Push Notifications
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-500 leading-relaxed max-w-md">
                Enable local browser push notifications to keep you on track.
              </p>
            </div>
            <button
              onClick={async () => {
                if (!('Notification' in window)) {
                  showNotification('Web Notifications are not supported by this browser.', 'warning');
                  return;
                }
                try {
                  const permission = await Notification.requestPermission();
                  if (permission === 'granted') {
                    showNotification('Push notifications successfully enabled!', 'success');
                    new Notification('Omni AI: Reminders Active', {
                      body: 'You will now receive friendly push notifications to keep up your daily streak!',
                    });
                  } else {
                    showNotification(`Permission status: ${permission}`, 'info');
                  }
                } catch (err) {
                  showNotification('Failed to request permission in sandbox environment.', 'error');
                }
              }}
              className={cn(
                "px-3 py-1.5 rounded-lg text-[10px] uppercase tracking-wider font-bold transition-all active:scale-95 cursor-pointer border",
                'Notification' in window && Notification.permission === 'granted'
                  ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400"
                  : "bg-indigo-600 border-indigo-600 text-white hover:bg-indigo-500"
              )}
            >
              {'Notification' in window && Notification.permission === 'granted' ? 'Enabled' : 'Request Permission'}
            </button>
          </div>

          {/* lastStudyDate info and Simulation */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                <Clock size={13} className="text-indigo-500" />
                Study History Status
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                Last Practice: <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                  {user.lastStudyDate 
                    ? new Date(user.lastStudyDate).toLocaleString() 
                    : 'No sessions completed yet'}
                </span>
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  const yesterday = new Date(Date.now() - 25 * 60 * 60 * 1000).toISOString();
                  setUser(prev => ({
                    ...prev,
                    lastStudyDate: yesterday
                  }));
                  showNotification('Simulated 25-hour study gap! Click "Close Settings" to view notification and resume banner.', 'success');
                }}
                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-white font-bold text-[10px] uppercase tracking-wider transition active:scale-95 border border-amber-500 shadow-sm"
              >
                Simulate 24h Gap
              </button>
              
              <button
                onClick={() => {
                  setUser(prev => ({
                    ...prev,
                    lastStudyDate: new Date().toISOString()
                  }));
                  showNotification('Study history updated to current time!', 'success');
                }}
                className={cn(
                  "px-3 py-1.5 rounded-lg font-bold text-[10px] uppercase tracking-wider transition active:scale-95 border",
                  theme === 'dark' 
                    ? "bg-slate-800 border-slate-700 text-slate-300 hover:text-white" 
                    : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-150"
                )}
              >
                Record Active Session
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Saved for Later / Bookmarked Lessons */}
      <div className="space-y-4 pt-2">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
          <Bookmark size={14} className="text-amber-500 fill-current" />
          Saved for Later (Bookmarked Lessons)
        </h3>

        <div className={cn(
          "p-5 rounded-2xl border space-y-4",
          theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-slate-50/50 border-slate-200"
        )}>
          {(!user.bookmarkedLessons || user.bookmarkedLessons.length === 0) ? (
            <div className="text-center py-6">
              <BookOpen size={24} className="text-slate-350 dark:text-slate-600 mx-auto mb-2.5 animate-pulse" />
              <p className="text-xs font-bold text-slate-500 dark:text-slate-400">No bookmarked lessons yet</p>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 max-w-xs mx-auto">
                Bookmark individual lessons in the sidebar to save them here for quick study later.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[260px] overflow-y-auto pr-1">
              {user.bookmarkedLessons.map((item, index) => (
                <div 
                  key={index} 
                  className={cn(
                    "p-3.5 rounded-xl border flex flex-col justify-between gap-3 group/item transition-all hover:scale-[1.01]",
                    theme === 'dark' 
                      ? "bg-slate-900/60 border-slate-800/80 hover:border-amber-500/40" 
                      : "bg-white border-slate-200/80 hover:border-amber-500/40 shadow-sm"
                  )}
                >
                  <div className="space-y-1">
                    <span className={cn(
                      "text-[8px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border leading-none block w-max",
                      theme === 'dark' 
                        ? "bg-indigo-950/40 border-indigo-900/40 text-indigo-400" 
                        : "bg-indigo-50 border-indigo-100 text-indigo-700"
                    )}>
                      {item.subject.replace(/_/g, ' ')}
                    </span>
                    <h4 className="text-xs font-black text-slate-800 dark:text-slate-100 leading-snug line-clamp-2">
                      Lesson {item.lessonNumber}: {item.title}
                    </h4>
                    {item.addedAt && (
                      <span className="text-[9px] text-slate-400 dark:text-slate-500 block">
                        Saved: {new Date(item.addedAt).toLocaleDateString()}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 pt-1.5 border-t border-dashed border-slate-150 dark:border-slate-800/60">
                    <button
                      onClick={() => {
                        setUser(prev => {
                          const updated = {
                            ...prev,
                            subject: item.subject,
                            topic: item.title,
                            lesson: String(item.lessonNumber)
                          };
                          localStorage.setItem('omni_user', JSON.stringify(updated));
                          return updated;
                        });
                        showNotification(`Navigated to Lesson: ${item.title}!`, 'success');
                        onClose(); // Automatically close the SettingsModal
                      }}
                      className="flex-1 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[10px] uppercase tracking-wider transition active:scale-95 cursor-pointer text-center shadow-sm"
                    >
                      Study Now
                    </button>
                    <button
                      onClick={() => {
                        const updated = (user.bookmarkedLessons || []).filter(b => !(b.title === item.title && b.subject === item.subject));
                        setUser(prev => {
                          const updatedProfile = { ...prev, bookmarkedLessons: updated };
                          localStorage.setItem('omni_user', JSON.stringify(updatedProfile));
                          return updatedProfile;
                        });
                        showNotification('Lesson removed from bookmarks.', 'info');
                      }}
                      className={cn(
                        "p-1.5 rounded-lg border transition cursor-pointer active:scale-95 flex items-center justify-center min-w-[28px] min-h-[28px]",
                        theme === 'dark' 
                          ? "border-slate-800 text-slate-400 hover:text-red-400 hover:border-red-900/40 hover:bg-red-950/20" 
                          : "border-slate-200 text-slate-400 hover:text-red-600 hover:border-red-200 hover:bg-red-50"
                      )}
                      title="Remove Bookmark"
                    >
                      <Trash size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Dual Controller Console */}
      <div className="space-y-4 pt-2">
        <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
          <Sliders size={14} className="text-indigo-500" />
          Speed & Pace Controller Console
        </h3>

        <div className={cn(
          "p-5 rounded-2xl border space-y-5",
          theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-slate-50/50 border-slate-200"
        )}>
          {/* Link Speeds Control */}
          <div className="flex items-start justify-between pb-4 border-b border-dashed border-slate-200/60 dark:border-slate-800/80">
            <div className="space-y-1">
              <div className="text-xs font-extrabold uppercase tracking-wide text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                {linkSpeeds ? (
                  <Link size={14} className="text-indigo-500 animate-pulse" />
                ) : (
                  <Link2Off size={14} className="text-slate-400 dark:text-slate-500" />
                )}
                Link Speeds Console
              </div>
              <p className="text-[10px] text-slate-500 dark:text-slate-500 leading-relaxed max-w-md">
                Locks both controllers together so that accelerating response typewriter speed automatically scales vocal lecture pacing, and vice-versa.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer select-none mt-1">
              <input
                type="checkbox"
                checked={linkSpeeds}
                onChange={(e) => handleToggleLinkSpeeds(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600" />
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Reading Speed (TTS Rate) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Volume2 size={13} className="text-indigo-500" />
                  Reading Speed (TTS Rate)
                </span>
                <span className="text-[10px] font-mono font-bold text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-150">
                  {ttsRate.toFixed(2)}x
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[0.5, 0.75, 1.0, 1.2, 1.5, 2.0].map((rate) => {
                  const isActive = ttsRate === rate;
                  return (
                    <button
                      key={rate}
                      onClick={() => handleReadingSpeedChange(rate)}
                      className={cn(
                        "py-2 rounded-xl text-xs font-black uppercase transition-all tracking-wider border text-center active:scale-95",
                        isActive
                          ? "bg-indigo-500 border-indigo-500 text-white shadow-md shadow-indigo-500/10"
                          : theme === 'dark'
                            ? "bg-slate-800 border-slate-700 hover:border-slate-650 text-slate-300"
                            : "bg-slate-100 border-slate-200 hover:border-slate-300 text-slate-700"
                      )}
                    >
                      {rate.toFixed(2)}x
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Writing Speed (Typing Pace) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap size={13} className="text-indigo-500" />
                  Writing Speed (Typing Pace)
                </span>
                <span className="text-[10px] font-bold text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-150 capitalize">
                  {typingPace}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {['deliberate', 'fluent', 'swift', 'instant'].map((pace) => {
                  const isActive = typingPace === pace;
                  return (
                    <button
                      key={pace}
                      onClick={() => handleWritingSpeedChange(pace)}
                      className={cn(
                        "py-2 rounded-xl text-xs font-black uppercase transition-all tracking-wider border text-center capitalize active:scale-95",
                        isActive
                          ? "bg-indigo-500 border-indigo-500 text-white shadow-md shadow-indigo-500/10"
                          : theme === 'dark'
                            ? "bg-slate-800 border-slate-700 hover:border-slate-650 text-slate-300"
                            : "bg-slate-100 border-slate-200 hover:border-slate-300 text-slate-700"
                      )}
                    >
                      {pace}
                    </button>
                  );
                })}
              </div>

              {/* Blackboard Writing Speed Slider */}
              <div className="space-y-2.5 pt-3 border-t border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Sliders size={13} className="text-indigo-500" />
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                      Blackboard Writing Speed
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-150">
                      {blackboardWritingSpeed.toFixed(2)}x
                    </span>
                    <span className="text-[9px] font-semibold text-slate-500 dark:text-slate-400 capitalize">
                      {blackboardWritingSpeed <= 0.65 ? 'Slow & Deliberate' : blackboardWritingSpeed <= 1.25 ? 'Natural Pace' : blackboardWritingSpeed <= 2.2 ? 'Fast Lecture' : 'Ultra Swift'}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <input
                    id="blackboard-writing-speed-slider"
                    type="range"
                    min="0.25"
                    max="3.0"
                    step="0.05"
                    value={blackboardWritingSpeed}
                    onChange={(e) => handleBlackboardWritingSpeedChange(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                    aria-label="Blackboard Writing Speed"
                  />
                  <div className="flex justify-between text-[9px] font-mono text-slate-400">
                    <span>0.25x (Slow)</span>
                    <span>1.0x (Normal)</span>
                    <span>2.0x (Fast)</span>
                    <span>3.0x (Max)</span>
                  </div>
                </div>

                {/* Quick preset buttons */}
                <div className="grid grid-cols-6 gap-1.5 pt-1">
                  {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map((spd) => {
                    const isActive = Math.abs(blackboardWritingSpeed - spd) < 0.04;
                    return (
                      <button
                        key={spd}
                        type="button"
                        id={`blackboard-speed-preset-${spd}`}
                        onClick={() => handleBlackboardWritingSpeedChange(spd)}
                        className={cn(
                          "py-1 rounded-lg text-[10px] font-mono font-bold transition-all text-center border active:scale-95",
                          isActive
                            ? "bg-indigo-500 border-indigo-500 text-white shadow-sm"
                            : theme === 'dark'
                              ? "bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600"
                              : "bg-slate-100 border-slate-200 text-slate-700 hover:border-slate-300"
                        )}
                      >
                        {spd.toFixed(2)}x
                      </button>
                    );
                  })}
                </div>

                {/* Quad-Speed Synchronization Console Link */}
                {onOpenQuadSpeedSync && (
                  <div className="pt-2">
                    <button
                      type="button"
                      id="btn-settings-open-quad-speed-sync"
                      onClick={onOpenQuadSpeedSync}
                      className={cn(
                        "w-full py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-between transition-all cursor-pointer group",
                        theme === 'dark'
                          ? "bg-indigo-950/40 border-indigo-500/30 text-indigo-300 hover:bg-indigo-900/50 hover:border-indigo-400"
                          : "bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100 hover:border-indigo-300"
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <Sliders size={14} className="text-indigo-400 group-hover:scale-110 transition-transform" />
                        <span>Quad-Speed Synchronization Hub</span>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                        Typing · Voice · Visuals · Scroll ➔
                      </span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scientific Unit Pronunciation Glossary */}
      <GlossaryAccordion theme={theme} />

      {/* Safety & Instructions */}
      <div className={cn(
        "p-4.5 rounded-2xl border space-y-2.5",
        theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-indigo-50/30 border-indigo-100"
      )}>
        <h4 className="text-xs font-extrabold uppercase text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
          <Info size={14} className="text-indigo-500" />
          Dynamic State Synchronization
        </h4>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
          The selected AI tutor personality is fed straight into our LLM controller. When you initiate a conversation or solve equations, the system instructions will adopt your preferred teaching methodology, ensuring tailored guidance.
        </p>
      </div>

      {/* Terms & Conditions Section */}
      <div className={cn(
        "p-4.5 rounded-2xl border flex items-center justify-between",
        theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-500">
            <Scale size={20} />
          </div>
          <div>
            <h4 className="text-xs font-extrabold uppercase text-slate-800 dark:text-slate-100">
              Terms & Conditions
            </h4>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
              Review Omni AI legal framework, privacy, and safety protocols
            </p>
          </div>
        </div>
        <button
          onClick={() => setShowTerms(true)}
          className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition cursor-pointer shadow-sm active:scale-95"
        >
          View Terms
        </button>
      </div>
    </>
  ) : activeTab === 'accessibility' ? (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
          {/* Text Size Section */}
          <div className="space-y-3">
            <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
              <Type size={14} className="text-indigo-500" />
              Adjust Text Size
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Increase or decrease the font sizing of paragraphs, lists, and headings inside the chat interface.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { id: 'sm', label: 'Small', desc: '12px Text' },
                { id: 'md', label: 'Medium', desc: '14px Default' },
                { id: 'lg', label: 'Large', desc: '16px Enhanced' },
                { id: 'xl', label: 'Extra Large', desc: '18px Maximum' }
              ].map((size) => (
                <button
                  key={size.id}
                  type="button"
                  onClick={() => {
                    setAccessibilityTextSize(size.id as any);
                    showNotification(`Text size adjusted to ${size.label}`, 'success');
                  }}
                  className={cn(
                    "p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between active:scale-95",
                    accessibilityTextSize === size.id
                      ? "bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-500 shadow-lg font-bold"
                      : "bg-slate-50 dark:bg-slate-850 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                  )}
                >
                  <span className="font-extrabold text-xs">{size.label}</span>
                  <span className={cn("text-[10px] mt-1.5", accessibilityTextSize === size.id ? "text-indigo-100" : "text-slate-400")}>{size.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Line Spacing Section */}
          <div className="space-y-3">
            <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
              <AlignLeft size={14} className="text-indigo-500" />
              Line Spacing
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Adjust the vertical spacing between lines of text to improve readability and reduce reading fatigue.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { id: 'normal', label: 'Normal', desc: 'Compact layout' },
                { id: 'relaxed', label: 'Relaxed', desc: 'Ideal reading comfort' },
                { id: 'loose', label: 'Loose', desc: 'Spacious distance' }
              ].map((spacing) => (
                <button
                  key={spacing.id}
                  type="button"
                  onClick={() => {
                    setAccessibilityLineSpacing(spacing.id as any);
                    showNotification(`Line spacing adjusted to ${spacing.label}`, 'success');
                  }}
                  className={cn(
                    "p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between active:scale-95",
                    accessibilityLineSpacing === spacing.id
                      ? "bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-500 shadow-lg font-bold"
                      : "bg-slate-50 dark:bg-slate-850 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                  )}
                >
                  <span className="font-extrabold text-xs">{spacing.label}</span>
                  <span className={cn("text-[10px] mt-1.5", accessibilityLineSpacing === spacing.id ? "text-indigo-100" : "text-slate-400")}>{spacing.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Contrast Level Section */}
          <div className="space-y-3">
            <h3 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
              <Eye size={14} className="text-indigo-500" />
              Contrast Levels
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Increase color contrast of the chat window for better text-to-background differentiation.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { id: 'normal', label: 'Standard Contrast', desc: 'Default theme colors' },
                { id: 'high', label: 'High Contrast', desc: 'Stark black/white backgrounds' },
                { id: 'ultra', label: 'Ultra Contrast', desc: 'Brilliant yellow on pitch black' }
              ].map((contrast) => (
                <button
                  key={contrast.id}
                  type="button"
                  onClick={() => {
                    setAccessibilityContrast(contrast.id as any);
                    showNotification(`Contrast adjusted to ${contrast.label}`, 'success');
                  }}
                  className={cn(
                    "p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between active:scale-95",
                    accessibilityContrast === contrast.id
                      ? "bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-500 shadow-lg font-bold"
                      : "bg-slate-50 dark:bg-slate-850 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                  )}
                >
                  <span className="font-extrabold text-xs">{contrast.label}</span>
                  <span className={cn("text-[10px] mt-1.5", accessibilityContrast === contrast.id ? "text-indigo-100" : "text-slate-400")}>{contrast.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Preview Box */}
          <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 bg-slate-50 dark:bg-slate-900/40">
            <span className="text-xs font-black uppercase tracking-wider text-slate-400 block">✨ Interactive Preview</span>
            <div className={cn(
              "p-4.5 rounded-xl border transition-all duration-300",
              accessibilityContrast === 'ultra'
                ? theme === 'dark'
                  ? "bg-black border-yellow-400 text-yellow-300"
                  : "bg-white border-indigo-950 text-black"
                : accessibilityContrast === 'high'
                  ? theme === 'dark'
                    ? "bg-black border-slate-500 text-white"
                    : "bg-white border-slate-800 text-black"
                  : theme === 'dark'
                    ? "bg-slate-950 border-slate-800 text-slate-200"
                    : "bg-white border-slate-200 text-slate-850 shadow-sm",
              accessibilityTextSize === 'sm' && "text-xs",
              accessibilityTextSize === 'md' && "text-sm",
              accessibilityTextSize === 'lg' && "text-base",
              accessibilityTextSize === 'xl' && "text-lg",
              accessibilityLineSpacing === 'normal' && "leading-normal",
              accessibilityLineSpacing === 'relaxed' && "leading-relaxed",
              accessibilityLineSpacing === 'loose' && "leading-loose"
            )}>
              <strong className={cn(
                "block mb-1.5",
                accessibilityContrast === 'ultra' ? "text-yellow-400 font-black" : "text-indigo-500 dark:text-indigo-400 font-extrabold"
              )}>
                Omni AI Assistant Tutor:
              </strong>
              <p>
                This preview displays the custom typography, line spacing, and contrast settings you have set for the chat interface. You can adjust them in real-time above to optimize reading clarity.
              </p>
            </div>
          </div>
        </div>
      ) : activeTab === 'device_tier' ? (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
          <DeviceSettingsUI 
            isDark={theme === 'dark'} 
            showNotification={showNotification} 
          />
        </div>
      ) : activeTab === 'wellbeing' ? (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
          <WellbeingHub isDark={theme === 'dark'} />
        </div>
      ) : activeTab === 'focus_coach' ? (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
          <FocusCoachHub isDark={theme === 'dark'} />
        </div>
      ) : (
        <QrHistoryTab
          theme={theme}
          user={user}
          setUser={setUser}
          showNotification={showNotification}
        />
      )}

      <TermsModal 
        isOpen={showTerms}
        onClose={() => setShowTerms(false)}
        theme={theme}
      />

      <AudioDiagnostics 
        isOpen={showAudioDiagnostics}
        onClose={() => setShowAudioDiagnostics(false)}
        analyser={analyser || null}
        audioContext={audioContext || null}
        isSpeaking={!!isSpeaking}
      />
    </div>
  );
};
