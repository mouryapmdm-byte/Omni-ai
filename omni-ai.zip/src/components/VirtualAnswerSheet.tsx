import React from 'react';
import { CheckCircle2, Bookmark, Circle, HelpCircle, Eye, FileText, Check } from 'lucide-react';
import { cn } from '../lib/utils';
import { ExamQuestionItem, ExamPatternTemplate, StudentQuestionResponse } from '../modules/exam-simulator/types';

interface VirtualAnswerSheetProps {
  questions: ExamQuestionItem[];
  template: ExamPatternTemplate;
  responses: Record<string, StudentQuestionResponse>;
  currentQuestionIndex: number;
  onSelectQuestion: (index: number) => void;
  isDark?: boolean;
}

export const VirtualAnswerSheet: React.FC<VirtualAnswerSheetProps> = ({
  questions,
  template,
  responses,
  currentQuestionIndex,
  onSelectQuestion,
  isDark = true,
}) => {
  // Compute counts
  let answeredCount = 0;
  let notAnsweredCount = 0;
  let markedForReviewCount = 0;
  let answeredAndMarkedCount = 0;
  let notVisitedCount = 0;

  questions.forEach((q) => {
    const resp = responses[q.id];
    const hasAnswer = resp && (resp.selectedOption || resp.answerText || resp.numericalAnswer !== undefined);
    const isMarked = resp?.markedForReview;
    const isVisited = resp?.visited;

    if (hasAnswer && isMarked) {
      answeredAndMarkedCount += 1;
    } else if (hasAnswer) {
      answeredCount += 1;
    } else if (isMarked) {
      markedForReviewCount += 1;
    } else if (isVisited) {
      notAnsweredCount += 1;
    } else {
      notVisitedCount += 1;
    }
  });

  return (
    <div className={cn(
      "w-full rounded-2xl border p-4 flex flex-col h-full overflow-hidden",
      isDark ? "bg-slate-900/90 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Header & Title */}
      <div className="border-b border-slate-800 pb-3 mb-3">
        <h3 className="font-bold text-xs uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <FileText size={14} className="text-indigo-400" /> Question Palette
        </h3>
        <p className="text-xs font-semibold text-slate-200 mt-0.5">{template.title}</p>
      </div>

      {/* Legend Grid */}
      <div className="grid grid-cols-2 gap-2 text-[11px] font-medium border-b border-slate-800/80 pb-3 mb-3">
        <div className="flex items-center gap-1.5">
          <span className="w-5 h-5 rounded-md bg-emerald-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
            {answeredCount}
          </span>
          <span className="text-slate-300">Answered</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-5 h-5 rounded-md bg-rose-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
            {notAnsweredCount}
          </span>
          <span className="text-slate-300">Not Answered</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-5 h-5 rounded-md bg-purple-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
            {markedForReviewCount}
          </span>
          <span className="text-slate-300">Marked Review</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-5 h-5 rounded-md bg-purple-700 relative text-white font-bold text-[10px] flex items-center justify-center shrink-0">
            {answeredAndMarkedCount}
            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full absolute -top-0.5 -right-0.5" />
          </span>
          <span className="text-slate-300">Ans & Review</span>
        </div>
        <div className="flex items-center gap-1.5 col-span-2">
          <span className="w-5 h-5 rounded-md bg-slate-700 text-slate-300 font-bold text-[10px] flex items-center justify-center shrink-0">
            {notVisitedCount}
          </span>
          <span className="text-slate-400">Not Visited ({questions.length} Total)</span>
        </div>
      </div>

      {/* Question Number Tiles Matrix */}
      <div className="flex-1 overflow-y-auto pr-1">
        {template.sections.map((sec) => {
          const secQuestions = questions.filter(q => q.sectionId === sec.id);
          if (secQuestions.length === 0) return null;

          return (
            <div key={sec.id} className="mb-4">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                {sec.name}
              </span>
              <div className="grid grid-cols-5 sm:grid-cols-6 gap-2">
                {secQuestions.map((q) => {
                  const globalIdx = questions.findIndex(item => item.id === q.id);
                  const isCurrent = globalIdx === currentQuestionIndex;
                  const resp = responses[q.id];
                  const hasAnswer = resp && (resp.selectedOption || resp.answerText || resp.numericalAnswer !== undefined);
                  const isMarked = resp?.markedForReview;
                  const isVisited = resp?.visited;

                  let tileClass = "bg-slate-800 text-slate-400 hover:bg-slate-700";
                  if (hasAnswer && isMarked) {
                    tileClass = "bg-purple-700 text-white border-2 border-emerald-400 shadow-sm";
                  } else if (hasAnswer) {
                    tileClass = "bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-sm";
                  } else if (isMarked) {
                    tileClass = "bg-purple-600 hover:bg-purple-500 text-white font-bold";
                  } else if (isVisited) {
                    tileClass = "bg-rose-600 hover:bg-rose-500 text-white font-bold";
                  }

                  return (
                    <button
                      key={q.id}
                      onClick={() => onSelectQuestion(globalIdx)}
                      className={cn(
                        "h-9 rounded-xl text-xs font-bold transition flex items-center justify-center relative cursor-pointer",
                        tileClass,
                        isCurrent && "ring-2 ring-indigo-400 ring-offset-2 ring-offset-slate-900 scale-105"
                      )}
                      title={`Question ${q.questionNumber}: ${q.topic} (${q.marks}M)`}
                    >
                      {q.questionNumber}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
