import React from 'react';
import { RecallAttempt } from '../modules/retrieval-practice/types';
import { 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Trophy, 
  ArrowRight, 
  BookOpen, 
  RotateCcw, 
  Sparkles, 
  Target, 
  BrainCircuit, 
  Clock 
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface RecallFeedbackProps {
  attempt: RecallAttempt;
  onRetry: () => void;
  onClose?: () => void;
}

export const RecallFeedback: React.FC<RecallFeedbackProps> = ({
  attempt,
  onRetry,
  onClose
}) => {
  const getScoreBadgeColor = (score: number) => {
    if (score >= 80) return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30';
    if (score >= 60) return 'bg-indigo-500/10 text-indigo-500 border-indigo-500/30';
    if (score >= 40) return 'bg-amber-500/10 text-amber-500 border-amber-500/30';
    return 'bg-rose-500/10 text-rose-500 border-rose-500/30';
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-5xl mx-auto p-1">
      {/* Top Banner Score Summary */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 p-6 rounded-2xl text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Free Recall Evaluation
              </span>
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <Clock size={12} /> {Math.round(attempt.duration)}s spent
              </span>
            </div>
            <h2 className="text-xl font-extrabold tracking-tight text-white mb-1">
              {attempt.topicTitle}
            </h2>
            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              {attempt.feedbackSuggestions[0] || "AI evaluated coverage, accuracy, depth, and logical organization."}
            </p>
          </div>

          {/* Big Score Dial */}
          <div className="flex items-center gap-4 shrink-0">
            <div className="flex flex-col items-center justify-center p-4 rounded-xl bg-slate-800/80 border border-indigo-500/40 min-w-[110px]">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Overall Score</span>
              <span className={cn("text-3xl font-black", attempt.score >= 75 ? "text-emerald-400" : attempt.score >= 50 ? "text-indigo-400" : "text-amber-400")}>
                {attempt.score}<span className="text-sm font-normal text-slate-400">/100</span>
              </span>
            </div>
          </div>
        </div>

        {/* Breakdown Metric Gauges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-indigo-500/20 relative z-10">
          <div className="flex flex-col gap-1 p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <span className="text-[11px] text-slate-400 font-medium">Coverage</span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-indigo-300">{attempt.coverage}%</span>
              <div className="w-16 bg-slate-700 h-1.5 rounded-full overflow-hidden">
                <div className="bg-indigo-400 h-full" style={{ width: `${attempt.coverage}%` }} />
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-1 p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <span className="text-[11px] text-slate-400 font-medium">Accuracy</span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-emerald-300">{attempt.accuracy}%</span>
              <div className="w-16 bg-slate-700 h-1.5 rounded-full overflow-hidden">
                <div className="bg-emerald-400 h-full" style={{ width: `${attempt.accuracy}%` }} />
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-1 p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <span className="text-[11px] text-slate-400 font-medium">Depth</span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-violet-300">{attempt.depth}%</span>
              <div className="w-16 bg-slate-700 h-1.5 rounded-full overflow-hidden">
                <div className="bg-violet-400 h-full" style={{ width: `${attempt.depth}%` }} />
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-1 p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <span className="text-[11px] text-slate-400 font-medium">Organization</span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-cyan-300">{attempt.organization}%</span>
              <div className="w-16 bg-slate-700 h-1.5 rounded-full overflow-hidden">
                <div className="bg-cyan-400 h-full" style={{ width: `${attempt.organization}%` }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Color-Coded Concept Legend & Tags */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm">
        <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
          <BrainCircuit size={15} className="text-indigo-500" />
          Concept Retrieval Matrix
        </h3>

        <div className="flex flex-wrap gap-2">
          {/* Covered (Green) */}
          {attempt.coveredConcepts.map((concept, idx) => (
            <span
              key={`covered_${idx}`}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30"
            >
              <CheckCircle2 size={13} className="text-emerald-500" />
              {concept}
            </span>
          ))}

          {/* Missed (Yellow) */}
          {attempt.missedConcepts.map((concept, idx) => (
            <span
              key={`missed_${idx}`}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30"
            >
              <AlertTriangle size={13} className="text-amber-500" />
              Missed: {concept}
            </span>
          ))}

          {/* Wrong / Misstated (Red) */}
          {attempt.wrongConcepts.map((concept, idx) => (
            <span
              key={`wrong_${idx}`}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30"
            >
              <XCircle size={13} className="text-rose-500" />
              Needs Correction: {concept}
            </span>
          ))}
        </div>
      </div>

      {/* Side-by-Side Comparison: Model Answer vs Student Response */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Student Response Card */}
        <div className="flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
            <span className="text-xs font-bold text-indigo-500 uppercase tracking-wider flex items-center gap-1.5">
              <BookOpen size={14} />
              Your Free Recall Submission
            </span>
            <span className="text-[11px] text-slate-400">
              {attempt.studentResponse.trim().split(/\s+/).length} words
            </span>
          </div>
          <div className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap font-sans overflow-y-auto max-h-[300px]">
            {attempt.studentResponse}
          </div>
        </div>

        {/* Model Answer Card */}
        <div className="flex flex-col bg-indigo-50/30 dark:bg-slate-900/90 border border-indigo-100 dark:border-indigo-950/60 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-indigo-100 dark:border-indigo-950/60">
            <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles size={14} />
              Gold Standard Model Answer
            </span>
            <span className="text-[11px] text-emerald-500 font-semibold">
              Reference Blueprint
            </span>
          </div>
          <div className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap font-sans overflow-y-auto max-h-[300px]">
            {attempt.modelAnswer}
          </div>
        </div>
      </div>

      {/* Actionable Improvement Suggestions */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm">
        <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Target size={15} className="text-indigo-500" />
          Targeted Growth Action Plan
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {attempt.feedbackSuggestions.map((suggestion, i) => (
            <div key={i} className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 text-xs text-slate-700 dark:text-slate-300">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-500 text-white font-bold text-[10px]">
                {i + 1}
              </span>
              <p className="leading-relaxed">{suggestion}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Action Buttons */}
      <div className="flex items-center justify-between pt-2">
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition cursor-pointer"
          >
            Back to Chapter
          </button>
        )}
        <button
          type="button"
          onClick={onRetry}
          className="ml-auto flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-md shadow-indigo-500/20 cursor-pointer"
        >
          <RotateCcw size={14} />
          Try Free Recall Again
        </button>
      </div>
    </div>
  );
};
