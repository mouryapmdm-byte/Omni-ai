import React, { useState, useEffect } from 'react';
import { 
  StudentInterests, 
  INTEREST_CATEGORIES, 
  InterestCategoryDef 
} from '../modules/personalization/types';
import { InterestProfileManager } from '../modules/personalization/interestProfile';
import { 
  Heart, 
  Check, 
  Plus, 
  X, 
  Sparkles, 
  Trophy, 
  Gamepad2, 
  Rocket, 
  Cpu, 
  Music, 
  Utensils, 
  Trees, 
  Film, 
  Palette, 
  Briefcase,
  Save,
  RotateCcw
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface InterestSettingsProps {
  studentId?: string;
  onClose?: () => void;
  onSaved?: (profile: StudentInterests) => void;
  className?: string;
}

export const InterestSettings: React.FC<InterestSettingsProps> = ({
  studentId = 'student_default',
  onClose,
  onSaved,
  className
}) => {
  const [profile, setProfile] = useState(() => InterestProfileManager.getProfile(studentId));
  const [selectedCats, setSelectedCats] = useState<string[]>(() => 
    profile.interests.map(i => i.category)
  );
  const [subInterestsMap, setSubInterestsMap] = useState<Record<string, string[]>>(() => {
    const map: Record<string, string[]> = {};
    profile.interests.forEach(i => {
      map[i.category] = i.subInterests || [];
    });
    return map;
  });
  const [customInput, setCustomInput] = useState<string>('');
  const [customList, setCustomList] = useState<string[]>(() => profile.customInterests || []);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  // Icon mapping
  const renderCategoryIcon = (iconName: string, size = 18) => {
    switch (iconName) {
      case 'Trophy': return <Trophy size={size} />;
      case 'Gamepad2': return <Gamepad2 size={size} />;
      case 'Rocket': return <Rocket size={size} />;
      case 'Cpu': return <Cpu size={size} />;
      case 'Music': return <Music size={size} />;
      case 'Utensils': return <Utensils size={size} />;
      case 'Trees': return <Trees size={size} />;
      case 'Film': return <Film size={size} />;
      case 'Palette': return <Palette size={size} />;
      case 'Briefcase': return <Briefcase size={size} />;
      default: return <Sparkles size={size} />;
    }
  };

  const toggleCategory = (catId: string) => {
    if (selectedCats.includes(catId)) {
      setSelectedCats(prev => prev.filter(c => c !== catId));
    } else {
      if (selectedCats.length >= 5) {
        // Limit to 5 categories
        return;
      }
      setSelectedCats(prev => [...prev, catId]);
      // Initialize subinterests if empty
      const meta = INTEREST_CATEGORIES.find(c => c.id === catId);
      if (meta && !subInterestsMap[catId]) {
        setSubInterestsMap(prev => ({
          ...prev,
          [catId]: meta.subInterests.slice(0, 2)
        }));
      }
    }
  };

  const toggleSubInterest = (catId: string, sub: string) => {
    setSubInterestsMap(prev => {
      const current = prev[catId] || [];
      if (current.includes(sub)) {
        return { ...prev, [catId]: current.filter(s => s !== sub) };
      } else {
        return { ...prev, [catId]: [...current, sub] };
      }
    });
  };

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;
    if (!customList.includes(customInput.trim())) {
      setCustomList(prev => [...prev, customInput.trim()]);
    }
    setCustomInput('');
  };

  const handleRemoveCustom = (item: string) => {
    setCustomList(prev => prev.filter(c => c !== item));
  };

  const handleSave = () => {
    const updated = InterestProfileManager.updateSelectedInterests(
      studentId,
      selectedCats,
      subInterestsMap,
      customList
    );
    setProfile(updated);
    setSavedSuccess(true);
    onSaved?.(updated);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose?.();
    }, 900);
  };

  const handleReset = () => {
    const defaultProfile = InterestProfileManager.getDefaultProfile(studentId);
    InterestProfileManager.saveProfile(defaultProfile);
    setProfile(defaultProfile);
    setSelectedCats(defaultProfile.interests.map(i => i.category));
    setCustomList([]);
  };

  return (
    <div className={cn(
      "p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl max-w-3xl w-full mx-auto space-y-6 relative",
      className
    )}>
      {/* Top Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-500 to-rose-500 text-white flex items-center justify-center shadow-lg shadow-pink-500/25 shrink-0">
            <Heart size={24} className="fill-current" />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
              Interest Profile & Personalization
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-pink-500/10 text-pink-600 dark:text-pink-400 font-bold border border-pink-500/20">
                {selectedCats.length} / 5 Selected
              </span>
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Omni AI re-engineers every scientific equation, proof, and lecture using your passions.
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X size={18} />
          </button>
        )}
      </div>

      {/* Categories Grid */}
      <div className="space-y-3">
        <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
          Choose Up to 5 Primary Categories:
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {INTEREST_CATEGORIES.map((cat) => {
            const isSelected = selectedCats.includes(cat.id);
            const isMaxReached = selectedCats.length >= 5 && !isSelected;

            return (
              <div
                key={cat.id}
                onClick={() => !isMaxReached && toggleCategory(cat.id)}
                className={cn(
                  "p-4 rounded-2xl border transition-all cursor-pointer select-none relative flex flex-col justify-between gap-2.5",
                  isSelected
                    ? "bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-500 shadow-md shadow-indigo-500/10 ring-2 ring-indigo-500/20"
                    : isMaxReached
                      ? "opacity-40 cursor-not-allowed bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800"
                      : "bg-slate-50/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-indigo-400"
                )}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={cn(
                      "w-8 h-8 rounded-xl flex items-center justify-center transition-colors",
                      isSelected ? "bg-indigo-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                    )}>
                      {renderCategoryIcon(cat.icon, 16)}
                    </div>
                    <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
                      {cat.name}
                    </span>
                  </div>

                  <div className={cn(
                    "w-5 h-5 rounded-full border flex items-center justify-center transition-colors",
                    isSelected
                      ? "bg-indigo-600 border-indigo-600 text-white"
                      : "border-slate-300 dark:border-slate-600"
                  )}>
                    {isSelected && <Check size={12} strokeWidth={3} />}
                  </div>
                </div>

                <p className="text-[11px] text-slate-500 leading-tight">
                  {cat.description}
                </p>

                {/* Sub-interests pills if category is selected */}
                {isSelected && (
                  <div className="pt-2 border-t border-indigo-200/50 dark:border-indigo-900/50 flex flex-wrap gap-1.5" onClick={e => e.stopPropagation()}>
                    {cat.subInterests.map(sub => {
                      const activeSub = (subInterestsMap[cat.id] || []).includes(sub);
                      return (
                        <button
                          key={sub}
                          type="button"
                          onClick={() => toggleSubInterest(cat.id, sub)}
                          className={cn(
                            "px-2 py-0.5 rounded-lg text-[10px] font-semibold transition cursor-pointer border",
                            activeSub
                              ? "bg-indigo-600 text-white border-indigo-600"
                              : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700"
                          )}
                        >
                          {sub}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Free-text custom interests */}
      <div className="space-y-3 pt-2">
        <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
          Optional Free-Text Interests:
        </label>

        <form onSubmit={handleAddCustom} className="flex gap-2">
          <input
            type="text"
            placeholder="e.g. Drone Racing, Origami, Rollercoasters, K-Pop..."
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 text-white transition flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <Plus size={14} /> Add
          </button>
        </form>

        {customList.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-1">
            {customList.map(item => (
              <span
                key={item}
                className="px-3 py-1 rounded-xl text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 flex items-center gap-1.5"
              >
                <span>{item}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveCustom(item)}
                  className="hover:text-rose-500 cursor-pointer"
                >
                  <X size={12} />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Footer Actions */}
      <div className="flex items-center justify-between gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
        <button
          type="button"
          onClick={handleReset}
          className="text-xs font-bold text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw size={14} />
          <span>Restore Defaults</span>
        </button>

        <div className="flex items-center gap-3">
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              Cancel
            </button>
          )}

          <button
            type="button"
            onClick={handleSave}
            disabled={selectedCats.length === 0}
            className="px-6 py-2.5 rounded-xl text-xs font-extrabold bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-lg shadow-indigo-600/30 flex items-center gap-2 cursor-pointer transition disabled:opacity-50"
          >
            {savedSuccess ? (
              <>
                <Check size={16} /> Saved!
              </>
            ) : (
              <>
                <Save size={16} /> Save Interests
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
