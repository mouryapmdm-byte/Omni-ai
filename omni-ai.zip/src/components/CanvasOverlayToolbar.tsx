import React, { useState } from 'react';
import { UnifiedCanvasUiManager } from '../types';
import { 
  Eye, 
  Move, 
  BarChart3, 
  Search, 
  Pencil, 
  Grid, 
  RotateCcw, 
  ChevronDown, 
  Sparkles,
  Layers,
  X
} from 'lucide-react';

interface CanvasOverlayToolbarProps {
  manager: UnifiedCanvasUiManager;
  className?: string;
  showNotification?: (msg: string, type: 'info' | 'success' | 'warning' | 'error') => void;
  compact?: boolean;
}

export const CanvasOverlayToolbar: React.FC<CanvasOverlayToolbarProps> = ({
  manager,
  className = '',
  showNotification,
  compact = false,
}) => {
  const { state, toggleHighContrast, toggleDragHandles, toggleVectorStats, toggleMagnifier, toggleChalkDraw, toggleGrid, setGridStyle, resetAllOverlays } = manager;
  const [showGridMenu, setShowGridMenu] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  const gridStyles: Array<{ id: 'graph-grid' | 'fine-mesh' | 'dot-matrix' | 'lines'; label: string; icon: string }> = [
    { id: 'graph-grid', label: 'Graph Grid', icon: '▦' },
    { id: 'fine-mesh', label: 'Fine Mesh', icon: '⩰' },
    { id: 'dot-matrix', label: 'Dot Matrix', icon: '•' },
    { id: 'lines', label: 'Ruled Lines', icon: '≡' },
  ];

  const activeCount = [
    state.highContrast,
    state.dragHandles,
    state.vectorStats,
    state.magnifier,
    state.chalkDraw,
    state.grid
  ].filter(Boolean).length;

  return (
    <div 
      id="unified-canvas-overlay-toolbar" 
      className={`relative select-none flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-xl shadow-xl z-30 transition-all ${className}`}
    >
      {/* Label Badge */}
      <div className="flex items-center gap-1.5 px-2 py-1 bg-slate-800/80 border border-slate-700 rounded-lg text-[11px] font-semibold text-slate-300">
        <Layers size={13} className="text-cyan-400" />
        <span className="hidden sm:inline">Canvas Layers</span>
        {activeCount > 0 && (
          <span className="w-4 h-4 rounded-full bg-cyan-500/20 text-cyan-300 text-[9px] font-black flex items-center justify-center border border-cyan-500/40">
            {activeCount}
          </span>
        )}
      </div>

      {/* 1. High Contrast */}
      <button
        id="btn-toggle-high-contrast"
        type="button"
        onClick={() => {
          toggleHighContrast();
          showNotification?.(state.highContrast ? 'High Contrast Mode Disabled' : 'High Contrast Neon Mode Enabled', 'info');
        }}
        title="High Contrast Neon Mode: Enhanced legibility & accessibility"
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all border ${
          state.highContrast
            ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-sm shadow-cyan-500/20 font-bold'
            : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
        }`}
      >
        <Eye size={13} className={state.highContrast ? 'text-cyan-300' : 'text-slate-400'} />
        <span className={compact ? 'hidden md:inline' : ''}>Contrast</span>
        {state.highContrast && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />}
      </button>

      {/* 2. Drag Handles */}
      <button
        id="btn-toggle-drag-handles"
        type="button"
        onClick={() => {
          toggleDragHandles();
          showNotification?.(state.dragHandles ? 'Vector Drag Handles Hidden' : 'Vector Drag Handles Active', 'info');
        }}
        title="Vector Drag Handles: Manipulate vector endpoints interactively"
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all border ${
          state.dragHandles
            ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm shadow-amber-500/20 font-bold'
            : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
        }`}
      >
        <Move size={13} className={state.dragHandles ? 'text-amber-300' : 'text-slate-400'} />
        <span className={compact ? 'hidden md:inline' : ''}>Handles</span>
        {state.dragHandles && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
      </button>

      {/* 3. Vector Stats */}
      <button
        id="btn-toggle-vector-stats"
        type="button"
        onClick={() => {
          toggleVectorStats();
          showNotification?.(state.vectorStats ? 'Vector Telemetry Stats Hidden' : 'Vector Telemetry Stats Active', 'info');
        }}
        title="Vector Telemetry: Real-time magnitude, angle θ, dot product stats"
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all border ${
          state.vectorStats
            ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200 shadow-sm shadow-emerald-500/20 font-bold'
            : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
        }`}
      >
        <BarChart3 size={13} className={state.vectorStats ? 'text-emerald-300' : 'text-slate-400'} />
        <span className={compact ? 'hidden md:inline' : ''}>Telemetry</span>
        {state.vectorStats && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
      </button>

      {/* 4. Magnifier Loupe */}
      <button
        id="btn-toggle-magnifier"
        type="button"
        onClick={() => {
          toggleMagnifier();
          showNotification?.(state.magnifier ? 'Magnifier Loupe Closed' : '2.8x Magnifier Loupe Active: Hover to zoom', 'info');
        }}
        title="Magnifier Tool: 2.8x optical zoom loupe for dense vector nodes"
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all border ${
          state.magnifier
            ? 'bg-purple-500/20 border-purple-400 text-purple-200 shadow-sm shadow-purple-500/20 font-bold'
            : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
        }`}
      >
        <Search size={13} className={state.magnifier ? 'text-purple-300' : 'text-slate-400'} />
        <span className={compact ? 'hidden md:inline' : ''}>Magnifier</span>
        {state.magnifier && <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />}
      </button>

      {/* 5. Chalk Draw */}
      <button
        id="btn-toggle-chalk-draw"
        type="button"
        onClick={() => {
          toggleChalkDraw();
          showNotification?.(state.chalkDraw ? 'Chalkboard Freehand Drawing Closed' : 'Chalkboard Freehand Drawing Active: Click & drag to sketch', 'info');
        }}
        title="Chalk Draw: Freehand notes & diagram markup overlay"
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all border ${
          state.chalkDraw
            ? 'bg-rose-500/20 border-rose-400 text-rose-200 shadow-sm shadow-rose-500/20 font-bold'
            : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
        }`}
      >
        <Pencil size={13} className={state.chalkDraw ? 'text-rose-300' : 'text-slate-400'} />
        <span className={compact ? 'hidden md:inline' : ''}>Chalk Draw</span>
        {state.chalkDraw && <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />}
      </button>

      {/* 6. Grid & Grid Styles */}
      <div className="relative flex items-center">
        <button
          id="btn-toggle-grid"
          type="button"
          onClick={() => {
            toggleGrid();
            showNotification?.(state.grid ? 'Coordinate Grid Hidden' : 'Coordinate Grid Shown', 'info');
          }}
          title="Coordinate Grid: Align mathematical shapes & curves"
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-l-lg text-xs font-semibold transition-all border-y border-l ${
            state.grid
              ? 'bg-blue-500/20 border-blue-400 text-blue-200 font-bold'
              : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <Grid size={13} className={state.grid ? 'text-blue-300' : 'text-slate-400'} />
          <span className={compact ? 'hidden md:inline' : ''}>Grid</span>
          {state.grid && <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />}
        </button>

        <button
          id="btn-grid-style-dropdown"
          type="button"
          onClick={() => setShowGridMenu(prev => !prev)}
          title="Select Grid Pattern Style"
          className={`px-1.5 py-1 rounded-r-lg text-xs border transition-all ${
            state.grid
              ? 'bg-blue-500/20 border-blue-400 text-blue-200'
              : 'bg-slate-800/60 border-slate-700/80 text-slate-400 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <ChevronDown size={12} />
        </button>

        {/* Dropdown Menu for Grid Style */}
        {showGridMenu && (
          <div 
            id="grid-style-menu"
            className="absolute top-full right-0 mt-1.5 w-36 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl p-1 z-50 flex flex-col gap-0.5"
          >
            {gridStyles.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setGridStyle(item.id);
                  if (!state.grid) toggleGrid(true);
                  setShowGridMenu(false);
                  showNotification?.(`Grid Pattern: ${item.label}`, 'info');
                }}
                className={`flex items-center justify-between px-2.5 py-1.5 rounded text-xs font-medium transition-colors ${
                  state.gridStyle === item.id && state.grid
                    ? 'bg-blue-500/30 text-blue-200 font-bold border border-blue-500/40'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <span className="font-mono">{item.icon}</span>
                  <span>{item.label}</span>
                </span>
                {state.gridStyle === item.id && <span className="text-[10px] text-blue-400 font-bold">✓</span>}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Reset Layers */}
      <button
        id="btn-reset-canvas-overlays"
        type="button"
        onClick={() => {
          resetAllOverlays();
          showNotification?.('Active canvas overlay layers cleared', 'info');
        }}
        title="Reset & Clear Active Overlay Layers"
        className="flex items-center gap-1 px-2 py-1 bg-slate-800/40 border border-slate-700/60 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 text-xs transition-colors ml-auto"
      >
        <RotateCcw size={12} />
        <span className="hidden lg:inline text-[11px]">Reset</span>
      </button>
    </div>
  );
};
