import React, { useEffect, useRef } from 'react';
import { cn } from '../lib/utils';

interface AudioFrequencyVisualizerProps {
  analyser: AnalyserNode | null;
  className?: string;
  isSpeaking: boolean;
}

export const AudioFrequencyVisualizer: React.FC<AudioFrequencyVisualizerProps> = ({ analyser, className, isSpeaking }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>(0);

  useEffect(() => {
    if (!isSpeaking || !analyser) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      requestRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const barWidth = (canvas.width / bufferLength) * 2.5;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * canvas.height;
        ctx.fillStyle = `rgb(99, 102, 241)`; // indigo-500
        ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
        x += barWidth + 1;
      }
    };

    draw();

    return () => cancelAnimationFrame(requestRef.current);
  }, [isSpeaking, analyser]);

  return (
    <canvas 
      ref={canvasRef} 
      width={100} 
      height={30} 
      className={cn("opacity-80", className)} 
    />
  );
};
