// ai-tutor/IntentClassifier.ts
import { IntentType } from './types';

export class IntentClassifier {
  /**
   * Deterministically classifies the student's prompt into one of the canonical intents.
   * Runs in microseconds without extra API calls for fast response.
   */
  async classify(message: string, context?: { topicId?: string; currentLectureId?: string }): Promise<IntentType> {
    const text = (message || '').trim().toLowerCase();

    // 1. Question generation / Practice intent
    if (
      text.includes('practice question') ||
      text.includes('quiz me') ||
      text.includes('test me') ||
      text.includes('give me questions') ||
      text.includes('give me 5 questions') ||
      text.includes('sample question') ||
      text.includes('exam questions') ||
      text.includes('pyq') ||
      text.includes('mcq') ||
      text.startsWith('quiz') ||
      text.startsWith('question') ||
      text.includes('solve this problem') ||
      text.includes('practice problems')
    ) {
      return 'question';
    }

    // 2. Analogy intent
    if (
      text.includes('analogy') ||
      text.includes('like what') ||
      text.includes('compare it to') ||
      text.includes('real world example') ||
      text.includes('relatable example') ||
      text.includes('metaphor') ||
      text.includes('think of it as')
    ) {
      return 'analogy';
    }

    // 3. Summarise / Recap intent
    if (
      text.includes('summarise') ||
      text.includes('summarize') ||
      text.includes('summary') ||
      text.includes('recap') ||
      text.includes('in brief') ||
      text.includes('quick review') ||
      text.includes('key points') ||
      text.includes('cheat sheet') ||
      text.includes('revision notes') ||
      text.includes('formula sheet')
    ) {
      return 'summarise';
    }

    // 4. Clarify / Doubt resolution
    if (
      text.includes('i don\'t understand') ||
      text.includes('confused') ||
      text.includes('what do you mean') ||
      text.includes('could you clarify') ||
      text.includes('still unclear') ||
      text.includes('why does that happen') ||
      text.includes('can you re-explain') ||
      text.includes('step by step')
    ) {
      return 'clarify';
    }

    // 5. Example intent
    if (
      text.includes('show me an example') ||
      text.includes('for instance') ||
      text.includes('give an example') ||
      text.includes('numerical example') ||
      text.includes('sample problem')
    ) {
      return 'example';
    }

    // 6. Check / Validation intent
    if (
      text.includes('is this correct') ||
      text.includes('check my answer') ||
      text.includes('did i do this right') ||
      text.includes('am i right') ||
      text.includes('verify this')
    ) {
      return 'check';
    }

    // 7. General Explanation (Default for "what is", "how does", "explain", "derive", etc.)
    return 'explain';
  }
}
