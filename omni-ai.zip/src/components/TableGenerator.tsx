import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { 
  Table, 
  Copy, 
  Check, 
  Download, 
  Sparkles, 
  FileText, 
  Code, 
  Search, 
  ArrowUpDown, 
  Plus, 
  Trash2, 
  RotateCcw, 
  Maximize2, 
  X, 
  CheckCircle2,
  Wand2,
  SlidersHorizontal,
  ChevronDown,
  ChevronUp,
  LayoutGrid,
  GraduationCap,
  Volume2,
  BookOpen,
  Lightbulb,
  HelpCircle
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

export function getStudentRowExplanation(row: string[], headers: string[]): {
  summary: string;
  analogy: string;
  examTip: string;
} {
  const rowText = row.join(' ').toLowerCase();
  
  if (rowText.includes('ovary') || rowText.includes('अंडाशय')) {
    return {
      summary: 'The Ovary is the swollen female base in flowers. After fertilization, it swells up to form the juicy, delicious fruit flesh you eat!',
      analogy: 'Imagine a protective lunchbox containing fruit seeds. Once fertilized, the lunchbox grows into juicy fruit flesh (like a peach or mango).',
      examTip: 'High-yield Board Question: Ovary is diploid (2n) and turns into Fruit. Ovary wall becomes Pericarp.'
    };
  }
  if (rowText.includes('ovule') || rowText.includes('बीजांड')) {
    return {
      summary: 'The Ovule is the inner egg structure inside the flower ovary. After fertilization, it turns directly into a plant Seed!',
      analogy: 'Think of an ovule as a packed sleeping bag with a baby embryo inside waiting for soil and water to sprout.',
      examTip: 'Ovule (2n) becomes Seed. Double integuments become protective seed coats (Testa & Tegmen).'
    };
  }
  if (rowText.includes('pen') || rowText.includes('endosperm') || rowText.includes('भ्रूणपोष')) {
    return {
      summary: 'PEN (Primary Endosperm Nucleus) is formed when 1 male sperm fuses with 2 polar nuclei (1+2 = 3n triploid). It stores starch food for the growing baby seed!',
      analogy: 'Like a high-energy baby food pantry packed right inside the seed container to nourish the growing plant embryo.',
      examTip: 'PEN is triploid (3n) in angiosperms because of Triple Fusion!'
    };
  }
  if (rowText.includes('integument') || rowText.includes('अध्यावरण')) {
    return {
      summary: 'Integuments are the outer protective envelopes around the ovule. After fertilization, they harden to form seed coats (Testa and Tegmen).',
      analogy: 'Like a waterproof winter jacket protecting a hiker from rain and cold.',
      examTip: 'Outer integument becomes Testa; inner integument becomes Tegmen.'
    };
  }
  if (rowText.includes('zygote') || rowText.includes('युग्मनज')) {
    return {
      summary: 'The Zygote is the single cell formed when sperm meets egg cell. It undergoes mitosis to become the baby plant embryo.',
      analogy: 'The very first brick of a new building from which the entire skyscraper grows.',
      examTip: 'Zygote is diploid (2n).'
    };
  }
  if (rowText.includes('glycolysis') || rowText.includes('cytoplasm')) {
    return {
      summary: 'Glycolysis is the anaerobic breakdown of 1 glucose into 2 pyruvate molecules in cytoplasm yielding net 2 ATP and 2 NADH.',
      analogy: 'Splitting a $10 bill into two $5 bills with a small profit margin.',
      examTip: 'Glycolysis occurs in both aerobic and anaerobic organisms without direct oxygen requirement.'
    };
  }
  if (rowText.includes('krebs') || rowText.includes('mitochondria')) {
    return {
      summary: 'The Krebs citric acid cycle oxidizes acetyl-CoA inside the mitochondrial matrix yielding CO2, ATP/GTP, NADH, and FADH2.',
      analogy: 'A circular rotary disassembly line harvesting high-energy electron carriers.',
      examTip: 'Oxaloacetate (4C) combines with Acetyl-CoA (2C) to form Citrate (6C).'
    };
  }
  if (rowText.includes('mitosis') || rowText.includes('equational')) {
    return {
      summary: 'Mitosis is equational division where 1 parent cell splits into 2 genetically identical twin daughter cells with the exact same chromosome count (2n → 2n).',
      analogy: 'Using a high-definition color scanner to make an exact 1:1 duplicate copy of a document.',
      examTip: 'Mitosis occurs in somatic body cells for growth and tissue repair.'
    };
  }
  if (rowText.includes('meiosis') || rowText.includes('reductional')) {
    return {
      summary: 'Meiosis is reductional division where 1 germ cell splits into 4 unique haploid gamete cells with half the original chromosome count (2n → n).',
      analogy: 'Shuffling a deck of 46 cards, splitting it into two equal halves of 23 cards so children get half from mom and half from dad.',
      examTip: 'Meiosis I reduces chromosome number by half (2n → n); crossing over in Pachytene creates genetic variation!'
    };
  }
  if (rowText.includes('isothermal')) {
    return {
      summary: 'In an Isothermal Process, temperature remains constant ($\Delta T = 0$). Any heat added is instantly converted into mechanical work!',
      analogy: 'Compressing a syringe very slowly in a water bath so heat leaks out and the temperature never rises.',
      examTip: 'Internal energy change $\Delta U = 0$; governed by Boyle\'s Law ($PV = \\text{constant}$).'
    };
  }
  if (rowText.includes('adiabatic')) {
    return {
      summary: 'In an Adiabatic Process, zero heat enters or leaves the system ($\Delta Q = 0$). Work is done purely at the expense of internal energy!',
      analogy: 'Rapidly popping an inflated bicycle tire: air expands so fast that no heat can flow, causing it to cool down instantly.',
      examTip: 'Adiabatic P-V slope is steeper by a factor of $\gamma = C_p / C_v$ compared to Isothermal.'
    };
  }

  const firstCol = row[0] || 'Parameter';
  const secondCol = row[1] || 'Value';
  const thirdCol = row[2] || '';
  return {
    summary: `This row compares "${firstCol}" with key value "${secondCol}" ${thirdCol ? `and "${thirdCol}"` : ''}.`,
    analogy: `Think of "${firstCol}" as a specific property or component in a multi-step system, helping you organize items side-by-side.`,
    examTip: `Master the key differences between ${headers[0] || 'Feature'} and ${headers[1] || 'Values'} for quick 1-mark board exam questions.`
  };
}

export interface TableGeneratorProps {
  isOpen?: boolean;
  onClose?: () => void;
  initialText?: string;
  theme?: 'light' | 'dark' | 'blackboard';
  onInsertToChat?: (markdownTable: string) => void;
  onDeliverToSmartboard?: (markdownTable: string, title?: string) => void;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  className?: string;
  isInline?: boolean;
}

export interface ParsedTableData {
  title: string;
  headers: string[];
  alignments: Array<'left' | 'center' | 'right'>;
  rows: string[][];
  notes?: string[];
}

/**
 * Intelligent ASCII, Unicode box, CSV, TSV, and text parser
 * Converts messy ASCII summary boxes (like ║ ... ║ ╠═══╣) into structured table data
 */
/**
 * Check if input text is a boxed Unicode Blackboard Summary (e.g. ╔════ ... ════╗)
 */
export function isBoxedSummary(text: string): boolean {
  if (!text) return false;
  return (
    (text.includes('╔') && text.includes('╚') && text.includes('║')) ||
    text.includes("PROFESSOR'S BLACKBOARD SUMMARY") ||
    text.includes("मास्टरक्लास ब्लैकबोर्ड सारांश") ||
    (text.includes("BLACKBOARD SUMMARY") && text.includes("║"))
  );
}

export interface BlackboardSummarySection {
  sectionTitle: string;
  items: { label?: string; value: string; full: string }[];
}

export function parseBlackboardSummaryBox(text: string): { title: string; sections: BlackboardSummarySection[]; rawBox: string } {
  if (!text) return { title: "Professor's Blackboard Summary", sections: [], rawBox: "" };

  const lines = text.split('\n');
  let title = "Professor's Blackboard Summary";
  const sections: BlackboardSummarySection[] = [];
  let currentSection: BlackboardSummarySection | null = null;

  for (const rawLine of lines) {
    // Strip outer box borders ║ and spaces
    let line = rawLine.trim();
    if (line.startsWith('║')) line = line.slice(1);
    if (line.endsWith('║')) line = line.slice(0, -1);
    line = line.trim();

    // Ignore horizontal border lines
    if (!line || /^[╔╠╚═]+$/.test(line)) continue;

    // Detect Title Line (e.g. PROFESSOR'S BLACKBOARD SUMMARY: RNAi)
    if (/SUMMARY|BLACKBOARD|मास्टरक्लास|सारांश/i.test(line) && !currentSection) {
      title = line.replace(/^[#*╔║\s]+/, '').trim();
      continue;
    }

    // Detect Section Headers (e.g. "1. CORE DEFINITION:", "2. KEY MOLECULAR PLAYERS:")
    if (/^\d+\.\s+[^:]+:/i.test(line) || /^[A-Z0-9\s—–_-]{3,}:$/i.test(line)) {
      if (currentSection) {
        sections.push(currentSection);
      }
      currentSection = {
        sectionTitle: line,
        items: []
      };
      continue;
    }

    // Detect Bullet Points / Key-Value Pairs
    if (line) {
      if (!currentSection) {
        currentSection = {
          sectionTitle: "1. CORE SUMMARY & OVERVIEW:",
          items: []
        };
      }

      let cleanItem = line.replace(/^[•*\-\s]+/, '').trim();
      let label: string | undefined = undefined;
      let value = cleanItem;

      if (cleanItem.includes(' : ')) {
        const parts = cleanItem.split(' : ');
        label = parts[0].trim();
        value = parts.slice(1).join(' : ').trim();
      } else if (cleanItem.includes(': ') && !cleanItem.startsWith('http')) {
        const firstColon = cleanItem.indexOf(': ');
        label = cleanItem.substring(0, firstColon).trim();
        value = cleanItem.substring(firstColon + 2).trim();
      }

      currentSection.items.push({
        label,
        value,
        full: cleanItem
      });
    }
  }

  if (currentSection) {
    sections.push(currentSection);
  }

  return { title, sections, rawBox: text };
}

/**
 * High-Impact Blackboard Summary Card Component
 */
export const BlackboardSummaryCard: React.FC<{
  rawText: string;
  theme?: 'blackboard' | 'dark' | 'light';
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  onInsertToChat?: (text: string) => void;
}> = ({ rawText, theme = 'blackboard', showNotification, onInsertToChat }) => {
  const [viewFormat, setViewFormat] = useState<'card' | 'raw'>('card');
  const [copied, setCopied] = useState(false);
  const [isSpeakingSummary, setIsSpeakingSummary] = useState(false);
  const [activeSectionIdx, setActiveSectionIdx] = useState<number | null>(null);

  const { title, sections } = useMemo(() => parseBlackboardSummaryBox(rawText), [rawText]);

  // Extract clean topic name from title if formatted like "PROFESSOR'S BLACKBOARD SUMMARY: RNAi"
  const parsedTitleObj = useMemo(() => {
    if (title.includes(':')) {
      const parts = title.split(':');
      return {
        subtitle: parts[0].trim(),
        mainTitle: parts.slice(1).join(':').trim()
      };
    }
    return {
      subtitle: "PROFESSOR'S BLACKBOARD SUMMARY",
      mainTitle: title.replace(/PROFESSOR'S BLACKBOARD SUMMARY:?/i, '').trim() || "Masterclass Topic Summary"
    };
  }, [title]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(rawText);
      setCopied(true);
      showNotification?.("Copied Masterclass Blackboard Summary to clipboard!", "success");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showNotification?.("Failed to copy summary", "error");
    }
  };

  const handleSpeakSummary = () => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeakingSummary) {
      window.speechSynthesis.cancel();
      setIsSpeakingSummary(false);
      return;
    }

    const cleanSpeechText = rawText
      .replace(/[╔╠╚═║]|^\s*║|║\s*$/gm, ' ')
      .replace(/→/g, ' leads to ')
      .replace(/•/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanSpeechText);
    utterance.onend = () => setIsSpeakingSummary(false);
    utterance.onerror = () => setIsSpeakingSummary(false);

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setIsSpeakingSummary(true);
  };

  const renderHighlightedValue = (textStr: string) => {
    // Regex matches arrows, measurements (e.g. 21–23 bp, 50 nm), biological terms in parentheses, and numbers
    const parts = textStr.split(/(→|⇒|↔|\b\d+(?:–\d+)?\s*(?:bp|kDa|nm|µm|mm|cm|m|kg|V|A|Hz|kHz|MHz|GHz|s|ms|min|h|°C|K|mol|L)\b|\(.*?\))/g);
    
    return parts.map((part, pIdx) => {
      if (part === '→' || part === '⇒' || part === '↔') {
        return (
          <span key={pIdx} className="inline-flex items-center justify-center mx-1.5 px-1 py-0.5 text-amber-400 font-extrabold text-xs bg-amber-400/10 rounded border border-amber-400/30">
            {part}
          </span>
        );
      }
      if (/\b\d+(?:–\d+)?\s*(?:bp|kDa|nm|µm|mm|cm|m|kg|V|A|Hz|kHz|MHz|GHz|s|ms|min|h|°C|K|mol|L)\b/.test(part)) {
        return (
          <span key={pIdx} className="font-mono font-bold text-amber-300 bg-amber-950/60 border border-amber-500/40 px-1.5 py-0.5 rounded text-xs shadow-sm">
            {part}
          </span>
        );
      }
      if (/^\(.*?\)$/.test(part)) {
        return (
          <span key={pIdx} className="text-slate-400 italic font-mono text-xs ml-1">
            {part}
          </span>
        );
      }
      return part;
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 12, scale: 0.99 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className="my-5 rounded-2xl overflow-hidden border-2 border-emerald-500/60 bg-gradient-to-b from-slate-950 via-slate-900 to-emerald-950/60 text-emerald-100 shadow-[0_0_35px_rgba(16,185,129,0.22)] backdrop-blur-xl transition-all"
    >
      {/* Blackboard Top Title Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 bg-slate-950/90 border-b border-emerald-500/30 backdrop-blur-md relative overflow-hidden">
        {/* Subtle Decorative Ambient Background Glow */}
        <div className="absolute -top-12 -left-12 w-36 h-36 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center gap-3 relative z-10">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-500/30 to-amber-500/20 text-emerald-300 border border-emerald-400/40 shadow-inner flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-emerald-300 animate-pulse" />
          </div>
          <div>
            <div className="text-[10px] uppercase font-mono font-black tracking-widest text-emerald-400/90 flex items-center gap-1.5">
              <span>🎓 {parsedTitleObj.subtitle}</span>
              <span className="text-amber-400/80">•</span>
              <span className="text-amber-300 font-mono">MASTERCLASS BOARDWORK</span>
            </div>
            <h3 className="text-lg font-black text-white tracking-wide flex items-center gap-2">
              <span>{parsedTitleObj.mainTitle}</span>
            </h3>
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="flex items-center gap-2 relative z-10">
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => setViewFormat(prev => prev === 'card' ? 'raw' : 'card')}
            className={cn(
              "px-3 py-1.5 rounded-xl text-xs font-mono font-extrabold border transition-all flex items-center gap-1.5 shadow-sm cursor-pointer",
              viewFormat === 'raw' 
                ? "bg-amber-500/30 text-amber-200 border-amber-400/60 shadow-[0_0_12px_rgba(245,158,11,0.3)]" 
                : "bg-emerald-950/80 text-emerald-200 border-emerald-500/40 hover:bg-emerald-900/80"
            )}
            title="Toggle between Graphical Cards & Raw Unicode Blackboard Box"
          >
            <Code className="w-3.5 h-3.5 text-amber-400" />
            <span>{viewFormat === 'raw' ? "Visual Cards" : "Chalk Box"}</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleSpeakSummary}
            className={cn(
              "px-3 py-1.5 rounded-xl text-xs font-mono font-bold border transition-all flex items-center gap-1.5 shadow-sm cursor-pointer",
              isSpeakingSummary 
                ? "bg-rose-500/30 text-rose-200 border-rose-500/60 animate-pulse shadow-[0_0_12px_rgba(244,63,94,0.3)]" 
                : "bg-emerald-950/80 text-emerald-200 border-emerald-500/40 hover:bg-emerald-900/80"
            )}
            title={isSpeakingSummary ? "Stop Speech Lecture" : "Listen to Blackboard Summary"}
          >
            <Wand2 className={cn("w-3.5 h-3.5", isSpeakingSummary ? "text-rose-400" : "text-emerald-400")} />
            <span className="hidden sm:inline">{isSpeakingSummary ? "Stop" : "Listen"}</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleCopy}
            className="px-3 py-1.5 rounded-xl text-xs font-mono font-bold bg-emerald-950/80 text-emerald-200 border border-emerald-500/40 hover:bg-emerald-900/80 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            title="Copy Blackboard Summary Box"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            <span className="hidden sm:inline">{copied ? "Copied!" : "Copy"}</span>
          </motion.button>

          {onInsertToChat && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                onInsertToChat(rawText);
                showNotification?.("Inserted Blackboard Summary to Chat!", "success");
              }}
              className="px-3.5 py-1.5 rounded-xl text-xs font-mono font-extrabold bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 hover:from-amber-400 hover:to-amber-300 transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
              title="Insert into Chat"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span className="hidden sm:inline">Insert</span>
            </motion.button>
          )}
        </div>
      </div>

      {/* Main Content Body */}
      <div className="p-4 sm:p-6 relative">
        <AnimatePresence mode="wait">
          {viewFormat === 'raw' ? (
            <motion.div
              key="raw-view"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <pre className="p-4 sm:p-5 rounded-xl bg-slate-950/95 border border-emerald-500/30 text-emerald-300 font-mono text-xs sm:text-sm leading-relaxed overflow-x-auto whitespace-pre shadow-inner select-all">
                {rawText}
              </pre>
            </motion.div>
          ) : (
            <motion.div
              key="card-view"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
              className="space-y-4"
            >
              {sections.map((sec, secIdx) => {
                const stepNumber = String(secIdx + 1).padStart(2, '0');
                const cleanSecTitle = sec.sectionTitle.replace(/^\d+\.\s*/, '').replace(/:$/, '').trim();

                return (
                  <motion.div 
                    key={secIdx}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: secIdx * 0.08, duration: 0.25 }}
                    onMouseEnter={() => setActiveSectionIdx(secIdx)}
                    onMouseLeave={() => setActiveSectionIdx(null)}
                    className={cn(
                      "p-4 sm:p-5 rounded-xl transition-all duration-300 border relative overflow-hidden",
                      activeSectionIdx === secIdx
                        ? "bg-slate-900/95 border-emerald-400/50 shadow-[0_0_20px_rgba(16,185,129,0.15)]"
                        : "bg-slate-950/60 border-emerald-500/20 hover:border-emerald-500/35"
                    )}
                  >
                    {/* Corner accent glow on active */}
                    {activeSectionIdx === secIdx && (
                      <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-bl-full pointer-events-none blur-xl" />
                    )}

                    {/* Section Header */}
                    <div className="flex items-center gap-3 border-b border-emerald-500/20 pb-3 mb-3.5">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-400/30 font-mono text-xs font-extrabold text-emerald-300 tracking-wider">
                        {stepNumber}
                      </span>
                      <h4 className="text-xs sm:text-sm font-mono font-extrabold uppercase tracking-widest text-emerald-300 flex-1">
                        {cleanSecTitle}
                      </h4>
                    </div>

                    {/* Section Items */}
                    <div className="space-y-2.5 pl-1 sm:pl-2">
                      {sec.items.map((item, itemIdx) => (
                        <div key={itemIdx} className="flex items-start gap-3 text-xs sm:text-sm leading-relaxed text-slate-200 group">
                          <span className="text-amber-400 font-bold shrink-0 mt-0.5 group-hover:scale-125 transition-transform">
                            •
                          </span>
                          <div className="flex-1">
                            {item.label ? (
                              <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
                                <strong className="text-cyan-300 font-mono font-extrabold tracking-wide shrink-0">
                                  {item.label}
                                </strong>
                                <span className="text-emerald-400/70 hidden sm:inline">:</span>
                                <span className="text-slate-100 flex-1">
                                  {renderHighlightedValue(item.value)}
                                </span>
                              </div>
                            ) : (
                              <span className="text-slate-100">
                                {renderHighlightedValue(item.full)}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export function parseAsciiOrStructuredText(rawText: string): ParsedTableData {
  if (!rawText || !rawText.trim()) {
    return {
      title: "Educational Summary Matrix",
      headers: ["S.No.", "Concept / Structure", "Type / Ploidy", "Fate / Value", "Academic Notes"],
      alignments: ["center", "left", "center", "left", "left"],
      rows: [],
      notes: []
    };
  }

  const lines = rawText.split('\n').map(l => l.trim()).filter(Boolean);
  let extractedTitle = "";
  const rawRows: string[][] = [];
  const notes: string[] = [];

  // Regex to detect boundary/separator lines in ASCII & Markdown
  const isSeparatorLine = (line: string) => {
    // Check for box-drawing horizontal lines: ╠═══╣, ╔═══╗, ╚═══╝, +---+, |---|
    if (/^[╔╠╚║═╬╦╩▼▲\s\-+|┌┐└┘├┤┬┴┼]+$/.test(line) && line.length > 3) {
      // If it contains only box borders or dashes
      const inner = line.replace(/[║|│]/g, '');
      if (/^[═\-_+\s]+$/.test(inner) || inner.length === 0) return true;
    }
    if (/^\|?[\s:-]+\|[\s:-|]+$/.test(line)) return true; // Markdown separator |---|---|
    return false;
  };

  // Extract title if framed in ║ ... ║ or [ ... ]
  for (const line of lines) {
    if ((line.includes('SUMMARY') || line.includes('MATRIX') || line.includes('PROFESSOR') || line.includes('TABLE') || line.includes('रूपांतरण') || line.includes('सारणी')) && !line.includes('╠') && !line.includes('══')) {
      const cleanLine = line.replace(/[║|│╔╗╚╝╠╣#*]/g, '').trim();
      if (cleanLine && cleanLine.length < 80 && !extractedTitle) {
        extractedTitle = cleanLine;
      }
    }
  }

  // Parse lines into cell arrays
  for (const line of lines) {
    if (isSeparatorLine(line)) continue;

    // Check if line is note or footer
    if (/^(\*|Note:|टिप्पणी:|Takeaway:|सूत्र:)/i.test(line)) {
      notes.push(line.replace(/^[║|│*#\s]+/, '').trim());
      continue;
    }

    // Process box-drawn lines with ║ or │ or |
    if (line.includes('║') || line.includes('│') || line.includes('|')) {
      // Remove leading and trailing border chars
      let content = line;
      if (content.startsWith('║') || content.startsWith('│') || content.startsWith('|')) {
        content = content.substring(1);
      }
      if (content.endsWith('║') || content.endsWith('│') || content.endsWith('|')) {
        content = content.slice(0, -1);
      }

      // Split by internal border chars
      const cells = content.split(/[║│|]/).map(c => c.trim());
      // Ignore if empty or is a title row
      if (cells.length === 1 && (cells[0] === extractedTitle || cells[0].length === 0)) {
        continue;
      }

      if (cells.length >= 2 || (cells.length === 1 && cells[0].length > 0)) {
        // Clean cell values
        const cleanedCells = cells.map(cell => {
          let c = cell.trim();
          // Normalize formatting
          c = c.replace(/\s+/g, ' ');
          return c;
        });
        rawRows.push(cleanedCells);
      }
    } else if (line.includes('\t')) {
      // TSV line
      const cells = line.split('\t').map(c => c.trim()).filter(Boolean);
      if (cells.length > 0) rawRows.push(cells);
    } else if (line.includes(',') && (line.match(/,/g) || []).length >= 2) {
      // CSV line
      const cells = line.split(',').map(c => c.trim());
      if (cells.length > 0) rawRows.push(cells);
    } else if (line.includes(':') || line.includes('->') || line.includes('→') || line.includes('=')) {
      // Key-Value structure: "अंडाशय (Ovary) : फल (Fruit)"
      const parts = line.split(/[:\-=→]+/).map(p => p.trim()).filter(Boolean);
      if (parts.length >= 2) {
        rawRows.push(parts);
      }
    }
  }

  // Determine headers vs body rows
  let headers: string[] = [];
  let bodyRows: string[][] = [];

  if (rawRows.length > 0) {
    // If the first row contains header indicators or is the top row
    const firstRow = rawRows[0];
    const isFirstRowHeader = firstRow.some(c => 
      /पूर्व|पश्च|Structure|Fate|Name|S\.No|Type|Parameter|Ploidy|Value|Category|Function|अंग|रूपांतरण|गुणसूत्र/i.test(c)
    ) || rawRows.length > 1;

    if (isFirstRowHeader) {
      headers = firstRow;
      bodyRows = rawRows.slice(1);
    } else {
      headers = firstRow.map((_, idx) => `Column ${idx + 1}`);
      bodyRows = rawRows;
    }
  }

  // Ensure consistent column counts
  const maxCols = Math.max(headers.length, ...bodyRows.map(r => r.length), 2);
  while (headers.length < maxCols) {
    headers.push(`Column ${headers.length + 1}`);
  }

  bodyRows = bodyRows.map(row => {
    const newRow = [...row];
    while (newRow.length < maxCols) {
      newRow.push('—');
    }
    return newRow.slice(0, maxCols);
  });

  // Enhance ploities and math tokens in cells
  bodyRows = bodyRows.map(row => {
    return row.map(cell => {
      // Convert standalone 2n, 3n, n into neat math tokens
      let enhanced = cell;
      enhanced = enhanced.replace(/\b(2n|3n|1n|n|4n)\b/g, (m) => `$${m}$`);
      enhanced = enhanced.replace(/\$\s*([23]?n)\s*\$/gi, '$$$1$$');
      return enhanced;
    });
  });

  // Auto-detect alignment for each column
  const alignments: Array<'left' | 'center' | 'right'> = headers.map((h, colIdx) => {
    if (/s\.?no|क्र\.?\s*सं|ploidy|गुणसूत्र|unit|no\.|id/i.test(h)) return 'center';
    if (/value|amount|score|cost|rate|%/i.test(h)) return 'right';
    return 'left';
  });

  return {
    title: extractedTitle || "Educational Comparative Matrix",
    headers,
    alignments,
    rows: bodyRows,
    notes
  };
}

/**
 * Generate standard, highly compliant GFM Markdown Table string
 */
export function generateGfmMarkdownTable(data: ParsedTableData): string {
  if (!data.headers || data.headers.length === 0) return "";

  const titleHeader = data.title ? `### 📋 ${data.title}\n\n` : "";
  
  // Header row
  const headerLine = `| ${data.headers.join(' | ')} |`;
  
  // Divider row with alignment
  const dividerLine = `| ${data.alignments.map(align => {
    if (align === 'center') return ':---:';
    if (align === 'right') return '---:';
    return ':---';
  }).join(' | ')} |`;

  // Body rows
  const bodyLines = data.rows.map(row => {
    return `| ${row.map(cell => cell.replace(/\|/g, '\\|') || '—').join(' | ')} |`;
  }).join('\n');

  // Notes footer
  const notesFooter = data.notes && data.notes.length > 0 
    ? `\n\n> **Key Academic Notes:**\n${data.notes.map(n => `> - ${n}`).join('\n')}` 
    : "";

  return `${titleHeader}${headerLine}\n${dividerLine}\n${bodyLines}${notesFooter}`;
}

/**
 * Generate LaTeX Array representation
 */
export function generateLatexTable(data: ParsedTableData): string {
  const colAlignStr = data.alignments.map(a => a[0]).join('|');
  const headerStr = data.headers.map(h => `\\textbf{${h}}`).join(' & ') + ' \\\\ \\hline';
  const bodyStr = data.rows.map(row => row.join(' & ') + ' \\\\').join('\n');

  return `$$\\begin{array}{|${colAlignStr}|}
\\hline
${headerStr}
${bodyStr}
\\hline
\\end{array}$$`;
}

/**
 * Generate CSV string
 */
export function generateCsv(data: ParsedTableData): string {
  const escapeCsv = (str: string) => {
    const clean = str.replace(/"/g, '""');
    return clean.includes(',') || clean.includes('"') || clean.includes('\n') ? `"${clean}"` : clean;
  };

  const headerLine = data.headers.map(escapeCsv).join(',');
  const bodyLines = data.rows.map(row => row.map(escapeCsv).join(',')).join('\n');
  return `${headerLine}\n${bodyLines}`;
}

export const PRESET_TABLE_EXAMPLES = [
  {
    name: "🌿 Plant Reproduction (Botany Fates)",
    description: "Post-Fertilization structural transformation matrix with ploidy levels",
    text: `║ PROFESSOR'S BLACKBOARD SUMMARY: निषेचन पश्च रूपांतरण ║
╠═══════════════════════════════════════════════════════════════════════╣
║ निषेचन पूर्व संरचना (Pre-Fertilization) ║ गुणसूत्र (Ploidy) ║ निषेचन पश्च रूपांतरण (Post-Fate) ║
╠═══════════════════════════════════════════════════════════════════════╣
║ अंडाशय (Ovary) ║ 2n ║ फल (Fruit) ║
║ अंडाशय भित्ति (Ovary Wall) ║ 2n ║ फलभित्ति (Pericarp) ║
║ बीजांड (Ovule) ║ 2n ║ बीज (Seed) ║
║ अध्यावरण (Integuments) ║ 2n ║ बीजचोल (Testa & Tegmen) ║
║ युग्मनज (Zygote) ║ 2n ║ भ्रूण (Embryo) ║
║ प्राथमिक भ्रूणपोष केंद्रक (PEN) ║ 3n ║ भ्रूणपोष (Endosperm) ║
║ सहायक व प्रतिव्यासांत कोशिकाएँ ║ n ║ अपहासित / नष्ट (Degenerated) ║
║ बीजांडकाय (Nucellus) ║ 2n ║ अपहासित (अथवा Perisperm) ║
╚═══════════════════════════════════════════════════════════════════════╝
* Note: Perisperm remains present in Black Pepper and Beetroot.`
  },
  {
    name: "⚡ Cellular Respiration: Aerobic vs Anaerobic Glycolysis",
    description: "Complete comparative matrix: site, ATP yield, pathways & electron acceptor",
    text: `╔═════════════════════════════════════════════════════════════════════════════════════════════════╗
║ COMPARATIVE MATRIX: AEROBIC RESPIRATION VS ANAEROBIC FERMENTATION                               ║
╠═════════════════════════════════════════════════════════════════════════════════════════════════╣
║ Parameter ║ Aerobic Respiration ║ Anaerobic Fermentation (Lactic / Alcohol) ║
╠═════════════════════════════════════════════════════════════════════════════════════════════════╣
║ Cellular Location ║ Cytoplasm + Mitochondria (Matrix & Cristae) ║ Strictly Cytoplasm ║
║ Oxygen Requirement ║ Obligate (Terminal electron acceptor) ║ Absent / Independent of O2 ║
║ Substrate Breakdown ║ Complete oxidation to CO2 and H2O ║ Incomplete oxidation (Lactate / Ethanol + CO2) ║
║ Net ATP Yield ║ 36 to 38 ATP per Glucose molecule ║ Net 2 ATP per Glucose molecule ║
║ End Products ║ 6 CO2 + 6 H2O + 38 ATP ║ Lactic Acid or Ethanol + CO2 + 2 ATP ║
║ Electron Transport Chain ║ Present (Cytochromes & Complex I-IV) ║ Absent ║
║ Energy Efficiency ║ ~40% thermodynamic recovery ║ ~2% recovery (rest trapped in products) ║
╚═════════════════════════════════════════════════════════════════════════════════════════════════╝`
  },
  {
    name: "🧬 Cell Division: Mitosis vs Meiosis I vs Meiosis II",
    description: "Cytological division matrix: ploidy, crossing over, and chromosome disjunction",
    text: `╔═════════════════════════════════════════════════════════════════════════════════════════════════╗
║ CELL DIVISION COMPARATIVE CYTOLOGICAL MATRIX                                                    ║
╠═════════════════════════════════════════════════════════════════════════════════════════════════╣
║ Feature / Stage ║ Mitosis (Equational) ║ Meiosis I (Reductional) ║ Meiosis II (Equational) ║
╠═════════════════════════════════════════════════════════════════════════════════════════════════╣
║ Parent Cell Type ║ Somatic cells (2n or n) ║ Germ cells / Meiocytes (2n) ║ Haploid daughter cells (n) ║
║ Synapsis & Bivalents ║ Absent ║ Present in Zygotene (Synaptonemal complex) ║ Absent ║
║ Genetic Recombination ║ Absent (Identical clones) ║ Present in Pachytene (Crossing over) ║ Absent ║
║ Anaphase Disjunction ║ Sister chromatids separate ║ Homologous chromosomes separate ║ Sister chromatids separate ║
║ Resulting Ploidy ║ 2n → 2n (Identical ploidy) ║ 2n → n (Halved chromosome number) ║ n → n (Maintained haploid) ║
║ Daughter Cells Produced ║ 2 Genetically Identical Cells ║ 2 Haploid Recombinant Cells ║ 4 Genetically Unique Gametes ║
╚═════════════════════════════════════════════════════════════════════════════════════════════════╝`
  },
  {
    name: "⚛️ Electromagnetic Waves & Spectrum",
    description: "Wavelength, frequency, photon energy, and detection methods matrix",
    text: `╔═════════════════════════════════════════════════════════════════════════════════════════════════╗
║ ELECTROMAGNETIC SPECTRUM: WAVELENGTH, FREQUENCY & DETECTION MATRIX                               ║
╠═════════════════════════════════════════════════════════════════════════════════════════════════╣
║ EM Wave Band ║ Wavelength Range (λ) ║ Frequency Range (ν) ║ Production Source ║ Detection Method ║
╠═════════════════════════════════════════════════════════════════════════════════════════════════╣
║ Gamma Rays (γ) ║ < 10^{-12} m (< 1 pm) ║ > 10^{20} Hz ║ Nuclear transitions / Decay ║ Geiger-Müller counter, Scintillator ║
║ X-Rays ║ 1 nm – 1 pm ║ 10^{16} – 10^{20} Hz ║ Heavy target deceleration / Coolidge tube ║ Photographic film, Ionization chamber ║
║ Ultraviolet (UV) ║ 400 nm – 1 nm ║ 10^{15} – 10^{17} Hz ║ Arc lamps, Solar corona, Thermal plasma ║ Photocells, Fluorescence screens ║
║ Visible Light ║ 700 nm – 400 nm ║ 4×10^{14} – 7.5×10^{14} Hz ║ Electron orbital de-excitation ║ Human eye, Photodiodes, CCD sensors ║
║ Infrared (IR) ║ 1 mm – 700 nm ║ 3×10^{11} – 4×10^{14} Hz ║ Molecular vibrations / Thermal radiation ║ Bolometers, Thermopiles, InGaAs sensors ║
║ Microwaves ║ 0.1 m – 1 mm ║ 3×10^{9} – 3×10^{11} Hz ║ Klystron / Magnetron oscillators ║ Point contact diodes, Horn antennas ║
║ Radio Waves ║ > 0.1 m (> 10 cm) ║ < 3×10^{9} Hz (< 3 GHz) ║ Accelerated charges in LC circuits ║ Dipole antennas, Tuned resonant receivers ║
╚═════════════════════════════════════════════════════════════════════════════════════════════════╝`
  },
  {
    name: "🔭 Telescope Optical Comparison",
    description: "Astronomical, Terrestrial & Galilean telescope comparative parameters",
    text: `╔═══════════════════════════════════════════════════════════════════════╗
║ OPTICAL TELESCOPE COMPARATIVE MATRIX                                  ║
╠═══════════════════════════════════════════════════════════════════════╣
║ Telescope Type | Objective Lens | Intermediate Lens | Final Image | Tube Length (L) ║
╠═══════════════════════════════════════════════════════════════════════╣
║ Astronomical   | Convex (+fo)   | None              | Inverted    | fo + fe         ║
║ Terrestrial    | Convex (+fo)   | Erecting (+4f)    | Erect       | fo + 4f + fe    ║
║ Galilean       | Convex (+fo)   | Concave Eyepiece  | Erect       | fo - fe         ║
╚═══════════════════════════════════════════════════════════════════════╝`
  },
  {
    name: "📐 Newton-Raphson Iteration Matrix",
    description: "Convergence iterations for f(x) = x^3 - x - 2",
    text: `Iter | x_n    | f(x_n)  | f'(x_n) | x_{n+1} | Relative Error
1    | 2.0000 | 4.0000  | 11.0000 | 1.6364  | 0.1818
2    | 1.6364 | 0.7513  | 7.0331  | 1.5304  | 0.0648
3    | 1.5304 | 0.0384  | 6.0267  | 1.5214  | 0.0059
4    | 1.5214 | 0.0001  | 5.9442  | 1.5209  | 0.0003`
  }
];

export const TableGenerator: React.FC<TableGeneratorProps> = ({
  isOpen = true,
  onClose,
  initialText = "",
  theme = 'blackboard',
  onInsertToChat,
  onDeliverToSmartboard,
  showNotification,
  className,
  isInline = false
}) => {
  const [inputText, setInputText] = useState<string>(initialText || PRESET_TABLE_EXAMPLES[0].text);
  const [tableData, setTableData] = useState<ParsedTableData>(() => parseAsciiOrStructuredText(initialText || PRESET_TABLE_EXAMPLES[0].text));
  const [viewMode, setViewMode] = useState<'preview' | 'markdown' | 'latex' | 'csv'>('preview');
  const [activeTheme, setActiveTheme] = useState<'blackboard' | 'dark' | 'light'>(
    theme === 'light' ? 'light' : theme === 'dark' ? 'dark' : 'blackboard'
  );
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [sortColIndex, setSortColIndex] = useState<number | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [isEditorExpanded, setIsEditorExpanded] = useState<boolean>(!isInline);
  const [studentMode, setStudentMode] = useState<boolean>(true);
  const [expandedRowIdx, setExpandedRowIdx] = useState<number | null>(null);

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const cleanText = text.replace(/[*_#$`]/g, '');
      const u = new SpeechSynthesisUtterance(cleanText);
      u.rate = 0.95;
      window.speechSynthesis.speak(u);
      showNotification?.("Professor Clarity speaking...", "info");
    }
  };

  // Sync when initial text changes
  useEffect(() => {
    if (initialText) {
      setInputText(initialText);
      setTableData(parseAsciiOrStructuredText(initialText));
    }
  }, [initialText]);

  // Handle parsing from input
  const handleParse = (text: string) => {
    setInputText(text);
    const parsed = parseAsciiOrStructuredText(text);
    setTableData(parsed);
  };

  // Filter and sort rows
  const displayRows = useMemo(() => {
    let rows = [...tableData.rows];

    // Filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      rows = rows.filter(row => row.some(cell => cell.toLowerCase().includes(q)));
    }

    // Sort
    if (sortColIndex !== null && sortColIndex < tableData.headers.length) {
      rows.sort((a, b) => {
        const valA = (a[sortColIndex] || "").replace(/[$*]/g, '').trim();
        const valB = (b[sortColIndex] || "").replace(/[$*]/g, '').trim();
        
        // Try numeric sort
        const numA = parseFloat(valA);
        const numB = parseFloat(valB);
        if (!isNaN(numA) && !isNaN(numB)) {
          return sortDirection === 'asc' ? numA - numB : numB - numA;
        }

        // Locale alphabetical sort
        return sortDirection === 'asc' 
          ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: 'base' })
          : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: 'base' });
      });
    }

    return rows;
  }, [tableData.rows, searchQuery, sortColIndex, sortDirection, tableData.headers.length]);

  // Formatted representations
  const gfmMarkdown = useMemo(() => generateGfmMarkdownTable(tableData), [tableData]);
  const latexCode = useMemo(() => generateLatexTable(tableData), [tableData]);
  const csvCode = useMemo(() => generateCsv(tableData), [tableData]);

  // Copy handler
  const handleCopy = async (text: string, formatName: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedFormat(formatName);
      showNotification?.(`Copied ${formatName} to clipboard!`, 'success');
      setTimeout(() => setCopiedFormat(null), 2000);
    } catch {
      showNotification?.("Failed to copy to clipboard", "error");
    }
  };

  // Download CSV
  const handleDownloadCsv = () => {
    const blob = new Blob([csvCode], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${(tableData.title || "table").toLowerCase().replace(/[^a-z0-9]/gi, '_')}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    showNotification?.("Exported CSV successfully!", "success");
  };

  // Column sort toggle
  const handleSortToggle = (colIdx: number) => {
    if (sortColIndex === colIdx) {
      if (sortDirection === 'asc') {
        setSortDirection('desc');
      } else {
        setSortColIndex(null);
      }
    } else {
      setSortColIndex(colIdx);
      setSortDirection('asc');
    }
  };

  // Cycle alignment
  const handleAlignmentCycle = (colIdx: number) => {
    setTableData(prev => {
      const newAlignments = [...prev.alignments];
      const curr = newAlignments[colIdx] || 'left';
      newAlignments[colIdx] = curr === 'left' ? 'center' : curr === 'center' ? 'right' : 'left';
      return { ...prev, alignments: newAlignments };
    });
  };

  // Row / Col modifications
  const handleAddRow = () => {
    setTableData(prev => ({
      ...prev,
      rows: [...prev.rows, prev.headers.map((_, i) => i === 0 ? `${prev.rows.length + 1}.` : '—')]
    }));
  };

  const handleDeleteRow = (rowIndex: number) => {
    setTableData(prev => ({
      ...prev,
      rows: prev.rows.filter((_, idx) => idx !== rowIndex)
    }));
  };

  // Container styling based on activeTheme
  const containerThemeClass = useMemo(() => {
    if (activeTheme === 'blackboard') {
      return "bg-slate-950 text-slate-100 border-amber-500/30";
    }
    if (activeTheme === 'dark') {
      return "bg-slate-900 text-slate-100 border-slate-700";
    }
    return "bg-white text-slate-900 border-slate-200 shadow-xl";
  }, [activeTheme]);

  const content = (
    <div className={cn("flex flex-col h-full rounded-2xl overflow-hidden border", containerThemeClass, className)}>
      {/* Header Toolbar */}
      <div className={cn(
        "flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b backdrop-blur-md",
        activeTheme === 'blackboard' ? "bg-black/40 border-white/10" : activeTheme === 'dark' ? "bg-slate-800/80 border-slate-700" : "bg-slate-50/90 border-slate-200"
      )}>
        <div className="flex items-center gap-2.5">
          <div className={cn(
            "p-2 rounded-xl flex items-center justify-center",
            activeTheme === 'blackboard' ? "bg-amber-500/20 text-amber-300 border border-amber-500/30" : "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400"
          )}>
            <Table className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold flex items-center gap-2">
              <span>{tableData.title || "Table Generator & Matrix Transformer"}</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full font-mono font-normal bg-amber-500/10 text-amber-400 border border-amber-500/20">
                {tableData.rows.length} rows × {tableData.headers.length} cols
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Converts raw ASCII/Unicode summaries into accessible zebra-striped GFM tables
            </p>
          </div>
        </div>

        {/* View mode & Action Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Student Mode Toggle */}
          <button
            onClick={() => setStudentMode(!studentMode)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-extrabold text-xs transition-all shadow-md cursor-pointer border",
              studentMode 
                ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 border-emerald-400 shadow-emerald-500/20" 
                : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"
            )}
            title="Toggle Student Plain English Mode with everyday analogies and exam tips"
          >
            <GraduationCap className="w-4 h-4" />
            <span>{studentMode ? "🎓 Student Mode: ON" : "🔬 Academic Mode"}</span>
          </button>

          {/* Theme switcher */}
          <div className="flex items-center bg-black/20 p-1 rounded-lg border border-white/5 text-xs">
            <button
              onClick={() => setActiveTheme('blackboard')}
              className={cn("px-2.5 py-1 rounded-md transition-all font-medium", activeTheme === 'blackboard' ? "bg-amber-500/20 text-amber-300 shadow-sm" : "text-slate-400 hover:text-slate-200")}
              title="Classroom Chalkboard Theme"
            >
              Chalkboard
            </button>
            <button
              onClick={() => setActiveTheme('dark')}
              className={cn("px-2.5 py-1 rounded-md transition-all font-medium", activeTheme === 'dark' ? "bg-slate-700 text-white shadow-sm" : "text-slate-400 hover:text-slate-200")}
              title="Dark Mode"
            >
              Dark
            </button>
            <button
              onClick={() => setActiveTheme('light')}
              className={cn("px-2.5 py-1 rounded-md transition-all font-medium", activeTheme === 'light' ? "bg-white text-slate-800 shadow-sm" : "text-slate-400 hover:text-slate-200")}
              title="Light Mode"
            >
              Light
            </button>
          </div>

          {/* Preset Samples Selector */}
          <div className="relative group">
            <button
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Presets</span>
            </button>
            <div className="absolute right-0 mt-1 w-64 p-1.5 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl z-50 hidden group-hover:block transition-all">
              <div className="text-[10px] uppercase font-bold text-slate-400 px-2 py-1">Sample Educational Matrices</div>
              {PRESET_TABLE_EXAMPLES.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleParse(preset.text)}
                  className="w-full text-left px-2 py-1.5 rounded-lg text-xs hover:bg-white/10 text-slate-200 transition-colors"
                >
                  <div className="font-semibold text-amber-300">{preset.name}</div>
                  <div className="text-[10px] text-slate-400 truncate">{preset.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Close button if in modal */}
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Split Layout */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Left Side: Input Transformer / Editor */}
        <AnimatePresence initial={false}>
          {isEditorExpanded && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: isInline ? '100%' : '380px', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className={cn(
                "flex flex-col border-b lg:border-b-0 lg:border-r p-4 shrink-0 transition-all overflow-y-auto",
                activeTheme === 'blackboard' ? "bg-slate-950/80 border-white/10" : activeTheme === 'dark' ? "bg-slate-900 border-slate-700" : "bg-slate-50 border-slate-200"
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Wand2 className="w-3.5 h-3.5 text-amber-400" />
                  Raw ASCII / Text Input
                </label>
                <button
                  onClick={() => handleParse(inputText)}
                  className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30 flex items-center gap-1 font-medium"
                >
                  <RotateCcw className="w-3 h-3" />
                  Re-parse
                </button>
              </div>

              <textarea
                value={inputText}
                onChange={(e) => handleParse(e.target.value)}
                placeholder="Paste ASCII box summary (║ ... ║), TSV, CSV, or colon-separated list here..."
                rows={10}
                className={cn(
                  "w-full flex-1 p-3 rounded-xl font-mono text-xs leading-relaxed resize-none focus:outline-none focus:ring-2 focus:ring-amber-400/50 border transition-all",
                  activeTheme === 'blackboard' 
                    ? "bg-black/50 text-amber-100 border-white/10 placeholder-slate-600" 
                    : activeTheme === 'dark' 
                    ? "bg-slate-950 text-slate-200 border-slate-800 placeholder-slate-500" 
                    : "bg-white text-slate-800 border-slate-300 placeholder-slate-400"
                )}
              />

              <div className="mt-3 text-[11px] text-slate-400 leading-normal flex items-start gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  Auto-detects ASCII box borders (<code className="font-mono text-amber-300">╠═══╣</code>), ploidy notation (<code className="font-mono text-amber-300">2n, 3n</code>), LaTeX math, and headers.
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Right Side: Tabular Preview & Output Modes */}
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          {/* Sub-toolbar: View Modes & Search */}
          <div className={cn(
            "flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b text-xs",
            activeTheme === 'blackboard' ? "bg-black/20 border-white/5" : activeTheme === 'dark' ? "bg-slate-800/50 border-slate-700" : "bg-slate-100 border-slate-200"
          )}>
            {/* View Mode Tabs */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => setViewMode('preview')}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all",
                  viewMode === 'preview' 
                    ? "bg-amber-500 text-slate-950 shadow-sm" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                )}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Live Zebra Table</span>
              </button>

              <button
                onClick={() => setViewMode('markdown')}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all",
                  viewMode === 'markdown' 
                    ? "bg-amber-500 text-slate-950 shadow-sm" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                )}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>GFM Markdown</span>
              </button>

              <button
                onClick={() => setViewMode('latex')}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all",
                  viewMode === 'latex' 
                    ? "bg-amber-500 text-slate-950 shadow-sm" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                )}
              >
                <Code className="w-3.5 h-3.5" />
                <span>LaTeX Array</span>
              </button>

              <button
                onClick={() => setViewMode('csv')}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-all",
                  viewMode === 'csv' 
                    ? "bg-amber-500 text-slate-950 shadow-sm" 
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                )}
              >
                <Table className="w-3.5 h-3.5" />
                <span>CSV</span>
              </button>
            </div>

            {/* Search filter & Table Actions */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search in table..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={cn(
                    "pl-8 pr-3 py-1 rounded-lg text-xs font-medium border focus:outline-none focus:ring-1 focus:ring-amber-400/50 w-36 sm:w-44 transition-all",
                    activeTheme === 'blackboard' ? "bg-black/40 border-white/10 text-white placeholder-slate-500" : activeTheme === 'dark' ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-300 text-slate-800"
                  )}
                />
              </div>

              {/* Copy / Export buttons */}
              <button
                onClick={() => handleCopy(gfmMarkdown, 'GFM Markdown')}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-amber-300 border border-amber-500/20 font-medium transition-all"
                title="Copy standard GFM Markdown table"
              >
                {copiedFormat === 'GFM Markdown' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy MD</span>
              </button>

              <button
                onClick={handleDownloadCsv}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 font-medium transition-all"
                title="Export as CSV spreadsheet"
              >
                <Download className="w-3.5 h-3.5" />
                <span>CSV</span>
              </button>

              {onDeliverToSmartboard && (
                <button
                  onClick={() => {
                    onDeliverToSmartboard(gfmMarkdown, tableData.title);
                    onClose?.();
                    showNotification?.(`Projected "${tableData.title || 'Table Matrix'}" to 3D Smartboard!`, "success");
                  }}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold transition-all shadow-md cursor-pointer"
                  title="Project this table directly onto the 3D Classroom Smartboard"
                >
                  <Sparkles className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Deliver to Smartboard</span>
                </button>
              )}

              {onInsertToChat && (
                <button
                  onClick={() => {
                    onInsertToChat(gfmMarkdown);
                    onClose?.();
                    showNotification?.("Inserted formatted table into chat!", "success");
                  }}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-all shadow-md"
                  title="Insert this table directly into chat prompt"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Insert to Chat</span>
                </button>
              )}
            </div>
          </div>

          {/* Main View Area */}
          <div className="flex-1 p-4 overflow-y-auto min-h-0">
            {viewMode === 'preview' ? (
              <div className="space-y-4">
                {/* Student Mode Banner */}
                {studentMode && (
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-teal-950/60 to-slate-950 border border-emerald-500/30 text-emerald-200 text-xs flex items-start gap-3 shadow-xl">
                    <GraduationCap className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    <div className="flex-1 space-y-1">
                      <div className="font-extrabold text-emerald-300 flex flex-wrap items-center justify-between gap-2">
                        <span>🎓 Student Plain English Mode: Active</span>
                        <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono border border-emerald-500/30">
                          Click any row below for plain analogies & exam tips
                        </span>
                      </div>
                      <p className="text-emerald-100/90 text-[11px] leading-relaxed">
                        Professor Clarity translates scientific terminology into clear, student-friendly analogies. Click any row in the table below to reveal everyday stories, exam tips, and audio narration!
                      </p>
                    </div>
                  </div>
                )}

                {/* Title Box */}
                {tableData.title && (
                  <div className={cn(
                    "px-4 py-2.5 rounded-xl border flex items-center justify-between",
                    activeTheme === 'blackboard' 
                      ? "bg-amber-500/10 border-amber-500/30 text-amber-300" 
                      : activeTheme === 'dark' 
                      ? "bg-slate-800 border-slate-700 text-slate-100" 
                      : "bg-slate-100 border-slate-200 text-slate-900 font-bold"
                  )}>
                    <div className="font-bold text-sm tracking-wide flex items-center gap-2">
                      <BookOpen size={16} className="text-amber-400" />
                      <span>{tableData.title}</span>
                    </div>
                    <div className="text-[11px] opacity-80 font-mono">
                      Student-Friendly Matrix • High Legibility
                    </div>
                  </div>
                )}

                {/* Table Responsive Container */}
                <div className="table-responsive-container shadow-sm border border-white/10 rounded-xl overflow-hidden">
                  <table className="w-full text-left border-collapse text-xs md:text-sm">
                    <thead>
                      <tr className={cn(
                        "border-b font-bold tracking-wider",
                        activeTheme === 'blackboard' 
                          ? "bg-slate-900/90 text-amber-300 border-amber-500/20" 
                          : activeTheme === 'dark' 
                          ? "bg-slate-800 text-slate-200 border-slate-700" 
                          : "bg-slate-100 text-slate-800 border-slate-300"
                      )}>
                        {tableData.headers.map((header, colIdx) => (
                          <th
                            key={colIdx}
                            className="px-4 py-3 cursor-pointer select-none group transition-colors"
                            onClick={() => handleSortToggle(colIdx)}
                          >
                            <div className={cn(
                              "flex items-center gap-1.5",
                              tableData.alignments[colIdx] === 'center' ? "justify-center" : tableData.alignments[colIdx] === 'right' ? "justify-end" : "justify-start"
                            )}>
                              <span>{header}</span>
                              <ArrowUpDown className={cn(
                                "w-3 h-3 opacity-40 group-hover:opacity-100 transition-opacity",
                                sortColIndex === colIdx && "opacity-100 text-amber-400"
                              )} />
                            </div>
                          </th>
                        ))}
                        <th className="w-16 px-2 py-3 text-center">Student Explainer</th>
                      </tr>
                    </thead>
                    <tbody>
                      {displayRows.length === 0 ? (
                        <tr>
                          <td colSpan={tableData.headers.length + 1} className="py-8 text-center text-slate-400">
                            No rows match your filter.
                          </td>
                        </tr>
                      ) : (
                        displayRows.map((row, rowIdx) => {
                          const isExpanded = expandedRowIdx === rowIdx;
                          return (
                            <React.Fragment key={rowIdx}>
                              <tr
                                onClick={() => setExpandedRowIdx(isExpanded ? null : rowIdx)}
                                className={cn(
                                  "border-b border-white/5 transition-colors cursor-pointer select-none",
                                  isExpanded
                                    ? "bg-emerald-950/40 border-emerald-500/30"
                                    : rowIdx % 2 === 0 
                                    ? activeTheme === 'blackboard' ? "bg-white/[0.02]" : activeTheme === 'dark' ? "bg-slate-800/40" : "bg-slate-50/80"
                                    : activeTheme === 'blackboard' ? "bg-transparent" : activeTheme === 'dark' ? "bg-slate-900/40" : "bg-white",
                                  "hover:bg-emerald-500/10"
                                )}
                              >
                                {row.map((cell, colIdx) => (
                                  <td
                                    key={colIdx}
                                    className={cn(
                                      "px-4 py-3 leading-relaxed",
                                      colIdx === 0 && "font-semibold text-amber-200/90",
                                      tableData.alignments[colIdx] === 'center' ? "text-center" : tableData.alignments[colIdx] === 'right' ? "text-right" : "text-left"
                                    )}
                                  >
                                    <ReactMarkdown
                                      remarkPlugins={[remarkGfm, remarkMath]}
                                      rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
                                      components={{
                                        p: ({ children }) => <span>{children}</span>
                                      }}
                                    >
                                      {cell}
                                    </ReactMarkdown>
                                  </td>
                                ))}
                                <td className="px-2 py-3 text-center">
                                  <div className="flex items-center justify-center gap-1">
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setExpandedRowIdx(isExpanded ? null : rowIdx);
                                      }}
                                      className={cn(
                                        "p-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                                        isExpanded
                                          ? "bg-emerald-500 text-slate-950 shadow-md"
                                          : "bg-white/5 hover:bg-white/10 text-emerald-400 border border-emerald-500/20"
                                      )}
                                      title="Toggle Student Plain English Explanation"
                                    >
                                      <GraduationCap className="w-3.5 h-3.5" />
                                      {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                                    </button>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleDeleteRow(rowIdx);
                                      }}
                                      className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                                      title="Delete row"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </td>
                              </tr>

                              {/* Student Row Explainer Expanded Card */}
                              {isExpanded && (
                                <tr className="bg-emerald-950/30 border-b border-emerald-500/30">
                                  <td colSpan={tableData.headers.length + 1} className="p-4">
                                    {(() => {
                                      const exp = getStudentRowExplanation(row, tableData.headers);
                                      return (
                                        <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/40 shadow-2xl space-y-3">
                                          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                                            <div className="flex items-center gap-2 font-extrabold text-emerald-300 text-xs">
                                              <GraduationCap className="w-4 h-4 text-emerald-400" />
                                              <span>Professor Clarity's Student Breakdown for: "{row[0] || 'Row Item'}"</span>
                                            </div>
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                speakText(`${row[0] || 'Item'}. ${exp.summary} ${exp.analogy}`);
                                              }}
                                              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/30 text-xs font-bold transition-all cursor-pointer shadow-sm"
                                            >
                                              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                                              <span>Listen to Explanation</span>
                                            </button>
                                          </div>

                                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                                            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-amber-500/20 space-y-1.5">
                                              <div className="font-extrabold text-amber-300 flex items-center gap-1.5 text-[11px]">
                                                <BookOpen size={14} className="text-amber-400" />
                                                <span>In Plain English:</span>
                                              </div>
                                              <p className="text-slate-200 leading-relaxed text-[11px]">{exp.summary}</p>
                                            </div>

                                            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-cyan-500/20 space-y-1.5">
                                              <div className="font-extrabold text-cyan-300 flex items-center gap-1.5 text-[11px]">
                                                <Lightbulb size={14} className="text-cyan-400" />
                                                <span>Everyday Analogy:</span>
                                              </div>
                                              <p className="text-slate-200 leading-relaxed text-[11px]">{exp.analogy}</p>
                                            </div>

                                            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-rose-500/20 space-y-1.5">
                                              <div className="font-extrabold text-rose-300 flex items-center gap-1.5 text-[11px]">
                                                <Sparkles size={14} className="text-rose-400" />
                                                <span>Board Exam Tip & Trap:</span>
                                              </div>
                                              <p className="text-slate-200 leading-relaxed text-[11px]">{exp.examTip}</p>
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })()}
                                  </td>
                                </tr>
                              )}
                            </React.Fragment>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Add Row and Alignment Controls */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <button
                    onClick={handleAddRow}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white/5 hover:bg-white/10 text-amber-300 border border-white/10 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Row</span>
                  </button>

                  {/* Alignment quick toggles */}
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <span className="text-[11px] uppercase font-bold text-slate-500">Align:</span>
                    {tableData.headers.map((h, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleAlignmentCycle(idx)}
                        className={cn(
                          "px-2 py-0.5 rounded text-[11px] font-mono border transition-all",
                          activeTheme === 'blackboard' ? "bg-black/30 border-white/10 text-amber-300" : "bg-slate-100 border-slate-300 text-slate-700"
                        )}
                        title={`Click to cycle alignment for ${h}`}
                      >
                        {h.slice(0, 8)}: {tableData.alignments[idx]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Notes Block if present */}
                {tableData.notes && tableData.notes.length > 0 && (
                  <div className={cn(
                    "p-3 rounded-xl border text-xs leading-relaxed space-y-1 mt-4",
                    activeTheme === 'blackboard' ? "bg-amber-500/5 border-amber-500/20 text-amber-200/90" : "bg-slate-100 border-slate-200 text-slate-700"
                  )}>
                    <div className="font-bold flex items-center gap-1.5 text-amber-400">
                      <Sparkles className="w-3.5 h-3.5" />
                      Academic Takeaways & Footnotes:
                    </div>
                    {tableData.notes.map((note, idx) => (
                      <div key={idx} className="pl-5 relative">
                        <span className="absolute left-1 top-0 text-amber-400">•</span>
                        {note}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : viewMode === 'markdown' ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase text-slate-400">Standard GFM Markdown Output:</span>
                  <button
                    onClick={() => handleCopy(gfmMarkdown, 'GFM Markdown')}
                    className="flex items-center gap-1 text-xs px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30"
                  >
                    {copiedFormat === 'GFM Markdown' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy Markdown</span>
                  </button>
                </div>
                <pre className="p-4 rounded-xl bg-black/60 border border-white/10 text-amber-100 font-mono text-xs leading-relaxed overflow-x-auto whitespace-pre">
                  {gfmMarkdown}
                </pre>
              </div>
            ) : viewMode === 'latex' ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase text-slate-400">LaTeX Array Output:</span>
                  <button
                    onClick={() => handleCopy(latexCode, 'LaTeX Array')}
                    className="flex items-center gap-1 text-xs px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30"
                  >
                    {copiedFormat === 'LaTeX Array' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy LaTeX</span>
                  </button>
                </div>
                <pre className="p-4 rounded-xl bg-black/60 border border-white/10 text-emerald-300 font-mono text-xs leading-relaxed overflow-x-auto whitespace-pre">
                  {latexCode}
                </pre>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase text-slate-400">CSV Spreadsheet Data:</span>
                  <button
                    onClick={handleDownloadCsv}
                    className="flex items-center gap-1 text-xs px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download CSV</span>
                  </button>
                </div>
                <pre className="p-4 rounded-xl bg-black/60 border border-white/10 text-sky-200 font-mono text-xs leading-relaxed overflow-x-auto whitespace-pre">
                  {csvCode}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  // If used as modal
  if (!isInline && isOpen !== undefined) {
    if (!isOpen) return null;
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
        <div className="w-full max-w-5xl h-[85vh] flex flex-col shadow-2xl">
          {content}
        </div>
      </div>
    );
  }

  return content;
};
