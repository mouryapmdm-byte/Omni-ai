import { LearningStyleProfile, VARKStyle } from './types';
import { getCollectedSignals } from './signalCollector';
import { detectLearningStyle, isRedetectionDue } from './styleDetector';

const PROFILE_STORAGE_KEY = 'omni_learning_style_profile_v1';
const LISTENERS: Array<() => void> = [];

export function getStoredProfile(): LearningStyleProfile {
  try {
    const raw = localStorage.getItem(PROFILE_STORAGE_KEY);
    if (raw) {
      const parsed: LearningStyleProfile = JSON.parse(raw);
      // Re-detect every 2 weeks unless student has explicitly set a manual override
      if (!parsed.isManualOverride && isRedetectionDue(parsed.detectedAt)) {
        const signals = getCollectedSignals();
        const refreshed = detectLearningStyle(signals, parsed.studentId);
        saveProfile(refreshed);
        return refreshed;
      }
      return parsed;
    }
  } catch (e) {
    console.error('Error reading learning style profile:', e);
  }

  // If no stored profile, compute initial from signals or default
  const signals = getCollectedSignals();
  const initial = detectLearningStyle(signals);
  saveProfile(initial);
  return initial;
}

export function saveProfile(profile: LearningStyleProfile): void {
  try {
    localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
    notifyListeners();
  } catch (e) {
    console.error('Error saving learning style profile:', e);
  }
}

export function setManualOverrideStyle(style: VARKStyle): LearningStyleProfile {
  const current = getStoredProfile();

  let v = 25, a = 25, r = 25, k = 25;
  if (style === 'visual') { v = 55; a = 15; r = 15; k = 15; }
  else if (style === 'auditory') { v = 15; a = 55; r = 15; k = 15; }
  else if (style === 'reading') { v = 15; a = 15; r = 55; k = 15; }
  else if (style === 'kinaesthetic') { v = 15; a = 15; r = 15; k = 55; }

  const updated: LearningStyleProfile = {
    ...current,
    visualScore: v,
    auditoryScore: a,
    readingScore: r,
    kinaestheticScore: k,
    dominantStyle: style,
    confidence: 100, // Manual override is 100% confident
    isManualOverride: true,
    updatedAt: new Date().toISOString()
  };

  saveProfile(updated);
  return updated;
}

export function resetToAutoDetection(): LearningStyleProfile {
  const signals = getCollectedSignals();
  const detected = detectLearningStyle(signals);
  saveProfile(detected);
  return detected;
}

export function subscribeToLearningStyleUpdates(callback: () => void): () => void {
  LISTENERS.push(callback);
  return () => {
    const idx = LISTENERS.indexOf(callback);
    if (idx !== -1) LISTENERS.splice(idx, 1);
  };
}

function notifyListeners(): void {
  LISTENERS.forEach(cb => {
    try { cb(); } catch {}
  });
}
