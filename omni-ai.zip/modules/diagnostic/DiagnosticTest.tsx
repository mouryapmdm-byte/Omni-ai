export * from '../../src/components/DiagnosticTest';
export { DiagnosticTest as default } from '../../src/components/DiagnosticTest';
