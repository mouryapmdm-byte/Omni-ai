import React, { useState, useMemo } from 'react';
import { 
  X, 
  GraduationCap, 
  Sparkles, 
  BookOpen, 
  CheckCircle2, 
  HelpCircle, 
  Trophy, 
  Volume2, 
  Copy, 
  FileText, 
  AlertTriangle,
  Zap,
  Target,
  Maximize2,
  Calendar,
  Clock,
  Users,
  Award,
  TrendingUp,
  CheckSquare,
  Layers,
  MessageSquare,
  ChevronRight,
  ChevronDown,
  Star,
  Home,
  Play,
  Activity,
  AlertCircle,
  Filter,
  Eye,
  EyeOff,
  RotateCw,
  Flame,
  Check,
  List,
  Table
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { generateLectureActivitySummary, ActivitySummaryData } from '../lib/activitySummaryGenerator';
import { convertLaTeXToSpokenText, triggerHapticFeedback } from '../lib/utils';
import { TableGenerator, PRESET_TABLE_EXAMPLES } from './TableGenerator';
import { 
  FIVE_LAYER_SUMMARIES, 
  ACADEMIC_EXAM_QUESTIONS, 
  COMPETITIVE_EXAM_QUESTIONS, 
  AcademicQuestion, 
  CompetitiveQuestion, 
  SummaryLayer 
} from '../data/examPrepData';

interface ProfessorSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicTitle: string;
  markdownContent: string;
  initialTab?: 
    | 'activity_summary' 
    | 'summary_layers'
    | 'table_summary'
    | 'overview' 
    | 'formulas' 
    | 'class_exam' 
    | 'competitive_exam' 
    | 'traps' 
    | 'quick_cards'
    | 'self_assessment';
  onReadAloud?: (text: string) => void;
  onFocus3DCamera?: () => void;
  onDeliverToSmartboard?: (markdownTable: string, title?: string) => void;
  showNotification?: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export const ProfessorSummaryModal: React.FC<ProfessorSummaryModalProps> = ({
  isOpen,
  onClose,
  topicTitle,
  markdownContent,
  initialTab = 'activity_summary',
  onReadAloud,
  onFocus3DCamera,
  onDeliverToSmartboard,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<
    | 'activity_summary' 
    | 'summary_layers'
    | 'table_summary'
    | 'overview' 
    | 'formulas' 
    | 'class_exam' 
    | 'competitive_exam' 
    | 'traps' 
    | 'quick_cards'
    | 'self_assessment'
  >(initialTab);

  // Sync active tab when modal is opened with specific initialTab
  React.useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  const [selectedLayer, setSelectedLayer] = useState<number>(1);
  const [selectedAcademicCategory, setSelectedAcademicCategory] = useState<string>('ALL');
  const [selectedCompetitiveCategory, setSelectedCompetitiveCategory] = useState<string>('ALL');
  const [selectedExamTypeFilter, setSelectedExamTypeFilter] = useState<string>('ALL');
  const [revealedAnswers, setRevealedAnswers] = useState<Record<string, boolean>>({});
  const [mcqSelections, setMcqSelections] = useState<Record<string, string>>({});
  const [userRating, setUserRating] = useState<number | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<{ [key: number]: string }>({});
  const [flippedCards, setFlippedCards] = useState<Record<number, boolean>>({});
  const [selectedPresetTableIndex, setSelectedPresetTableIndex] = useState<number>(0);

  // Generate the 20-section Activity Summary dataset
  const summaryData = useMemo(() => {
    return generateLectureActivitySummary(topicTitle, markdownContent);
  }, [topicTitle, markdownContent]);

  // Extract structured summary sections from raw markdown content
  const parsedSections = useMemo(() => {
    if (!markdownContent) return { overview: '', formulas: [], classQuestions: [], compQuestions: [], traps: [] };

    // Extract formulas ($...$ or $$...$$)
    const formulaMatches = [...markdownContent.matchAll(/(?:\$\$([\s\S]*?)\$\$|\$([^$\n]+)\$)/g)];
    const uniqueFormulas = Array.from(new Set(formulaMatches.map(m => m[1] || m[2]))).filter(f => f.trim().length > 1);

    // Extract misconception / traps
    const trapMatches = markdownContent.match(/(?:misconception|trap|warning|alert|caution|pitfall)[\s\S]*?(?=\n\n|\n#|$)/gi) || [];

    // Extract class exam practice block
    const classExamBlockMatch = markdownContent.match(/(?:School|Board|Class)\s*Exam[\s\S]*?(?=\n#|\n###\s*🏆|$)/i);
    const classExamText = classExamBlockMatch ? classExamBlockMatch[0] : '';

    // Extract competitive exam practice block
    const compExamBlockMatch = markdownContent.match(/(?:Competitive|JEE|NEET|SAT|GRE|UPSC|Olympiad)[\s\S]*?(?=\n#|\n###\s*🎓|$)/i);
    const compExamText = compExamBlockMatch ? compExamBlockMatch[0] : '';

    // Extract Summary / Phase 10 block
    const summaryBlockMatch = markdownContent.match(/(?:Summary|Executive Summary|Phase 10)[\s\S]*$/i);
    const summaryText = summaryBlockMatch ? summaryBlockMatch[0] : markdownContent.slice(0, 1500);

    return {
      overview: summaryText,
      formulas: uniqueFormulas,
      classQuestions: classExamText,
      compQuestions: compExamText,
      traps: trapMatches
    };
  }, [markdownContent]);

  // Key topic slug for layer summaries
  const topicLayers: SummaryLayer[] = useMemo(() => {
    const slug = (topicTitle || '').toLowerCase();
    for (const [key, layers] of Object.entries(FIVE_LAYER_SUMMARIES)) {
      if (slug.includes(key) || key.includes(slug)) {
        return layers;
      }
    }
    return FIVE_LAYER_SUMMARIES['high voltage'] || FIVE_LAYER_SUMMARIES['calculus'] || FIVE_LAYER_SUMMARIES['foundations'] || Object.values(FIVE_LAYER_SUMMARIES)[0] || [];
  }, [topicTitle]);

  const academicCategories = [
    'ALL',
    'Very Short Answer (1–2 Marks)',
    'Short Answer (3–4 Marks)',
    'Long Answer (5–6 Marks)',
    'Diagram-Based Questions',
    'Fill in the Blanks',
    'True or False',
    'Match the Following',
    'Assertion-Reason'
  ];

  const competitiveCategories = [
    'ALL',
    'Multiple Choice Questions (MCQs)',
    'Assertion-Reason (AIIMS Level)',
    'Statement-Based Questions',
    'Numerical Problems',
    'Match the Following (Advanced)',
    'Diagram Identification',
    'Experimental Reasoning',
    'Previous Year Questions (PYQs)',
    'Application-Based Questions',
    'Case Study Questions'
  ];

  const filteredAcademicQuestions = useMemo(() => {
    if (selectedAcademicCategory === 'ALL') return ACADEMIC_EXAM_QUESTIONS;
    return ACADEMIC_EXAM_QUESTIONS.filter(q => q.category === selectedAcademicCategory);
  }, [selectedAcademicCategory]);

  const filteredCompetitiveQuestions = useMemo(() => {
    return COMPETITIVE_EXAM_QUESTIONS.filter(q => {
      const matchCat = selectedCompetitiveCategory === 'ALL' || q.category === selectedCompetitiveCategory;
      const matchExam = selectedExamTypeFilter === 'ALL' || q.examType === selectedExamTypeFilter;
      return matchCat && matchExam;
    });
  }, [selectedCompetitiveCategory, selectedExamTypeFilter]);

  const flashcards = useMemo(() => {
    const titleLower = (topicTitle || '').toLowerCase();
    if (titleLower.includes('calculus') || titleLower.includes('deriv') || titleLower.includes('math')) {
      return [
        {
          front: "What is the limit definition of a derivative f'(x)?",
          back: "lim_{h->0} [f(x+h) - f(x)] / h",
          tag: "Calculus Foundation"
        },
        {
          front: "What does f'(x) = 0 indicate about a smooth curve?",
          back: "A stationary critical point (potential local maximum, minimum, or horizontal inflection).",
          tag: "Optimization"
        },
        {
          front: "What is the Chain Rule for differentiation?",
          back: "d/dx [f(g(x))] = f'(g(x)) * g'(x)",
          tag: "Differentiation Rule"
        },
        {
          front: "What does the Second Derivative Test determine?",
          back: "f''(c) > 0 implies local minimum (concave up); f''(c) < 0 implies local maximum (concave down).",
          tag: "Curvature & Extrema"
        },
        {
          front: "What does the Fundamental Theorem of Calculus state?",
          back: "d/dx [∫_{a}^{x} f(t)dt] = f(x) and ∫_{a}^{b} f(x)dx = F(b) - F(a).",
          tag: "Fundamental Theorem"
        }
      ];
    }
    if (titleLower.includes('physic') || titleLower.includes('motion') || titleLower.includes('force') || titleLower.includes('energy')) {
      return [
        {
          front: "What is Newton's Second Law of Motion?",
          back: "F_net = dp/dt = m*a (for constant mass). Net force equals rate of change of momentum.",
          tag: "Classical Mechanics"
        },
        {
          front: "What is the Work-Energy Theorem?",
          back: "W_net = ΔK = (1/2)m(v_f² - v_i²). Net work on a particle equals change in kinetic energy.",
          tag: "Energy Conservation"
        },
        {
          front: "What are the kinematic equations under constant acceleration?",
          back: "v = u + at, s = ut + (1/2)at², v² = u² + 2as.",
          tag: "Kinematics"
        },
        {
          front: "When is linear momentum conserved?",
          back: "When the net external force on the system is zero (ΣF_ext = 0).",
          tag: "Conservation Law"
        }
      ];
    }
    return [
      {
        front: "What is the core definition of the active topic?",
        back: `The fundamental principles and operational mechanisms governing ${topicTitle || 'this subject'}.`,
        tag: "Core Concept"
      },
      {
        front: "What is the essential mathematical or scientific relation?",
        back: "Consistent balance of input parameters, state transformations, and output observables.",
        tag: "Analytical Core"
      },
      {
        front: "How do we avoid common student misconceptions in this topic?",
        back: "Check boundary limits, verify dimensional units, and avoid confusing rate with total accumulated quantity.",
        tag: "Exam Strategy"
      },
      {
        front: "What is the primary real-world engineering application?",
        back: "Applied across advanced systems modeling, experimental science, and computational algorithms.",
        tag: "Application"
      }
    ];
  }, [topicTitle]);

  if (!isOpen) return null;

  const handleCopySummary = () => {
    const textToCopy = `# Professor Executive Summary: ${topicTitle}\n\n${markdownContent}`;
    navigator.clipboard.writeText(textToCopy);
    showNotification?.("Executive Summary copied to clipboard!", "success");
  };

  const toggleRevealAnswer = (id: string) => {
    setRevealedAnswers(prev => ({ ...prev, [id]: !prev[id] }));
    triggerHapticFeedback(10);
  };

  const toggleFlipCard = (index: number) => {
    setFlippedCards(prev => ({ ...prev, [index]: !prev[index] }));
    triggerHapticFeedback(15);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="bg-slate-900/98 border-2 border-amber-500/40 rounded-2xl sm:rounded-3xl w-full max-w-6xl h-[94vh] sm:h-[90vh] overflow-hidden shadow-2xl flex flex-col ring-1 ring-amber-500/20">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-950/60 via-slate-900 to-indigo-950/60 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 sm:p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 shadow-lg shadow-amber-500/10">
              <GraduationCap size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-black uppercase tracking-wider border border-amber-500/30">
                  Professor Clarity Master Hub
                </span>
                <span className="text-xs text-slate-400 font-medium hidden sm:inline">20-Section Activity Report & 5-Layer System</span>
              </div>
              <h2 className="text-sm sm:text-xl font-black text-white tracking-tight mt-0.5 line-clamp-1">
                {topicTitle || "3D Classroom Lecture Summary"}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {onReadAloud && (
              <button
                onClick={() => onReadAloud(markdownContent)}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                title="Read Executive Summary aloud in professor voice"
              >
                <Volume2 size={13} />
                <span className="hidden md:inline">Read Aloud</span>
              </button>
            )}

            <button
              onClick={handleCopySummary}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Copy Summary"
            >
              <Copy size={15} />
            </button>

            {onFocus3DCamera && (
              <button
                onClick={onFocus3DCamera}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer flex items-center justify-center shadow-sm"
                title="Focus 3D Stage"
              >
                <Maximize2 size={15} />
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer ml-1"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Tab Navigation Bar */}
        <div className="px-3 py-2 bg-slate-950/80 border-b border-slate-800/80 flex items-center gap-1.5 overflow-x-auto scrollbar-none shrink-0">
          <button
            onClick={() => setActiveTab('activity_summary')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'activity_summary'
                ? 'bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Activity size={14} />
            <span>📊 20-Point Activity Report</span>
          </button>

          <button
            onClick={() => setActiveTab('summary_layers')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'summary_layers'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Layers size={14} />
            <span>⚡ 5-Layer Summaries</span>
          </button>

          <button
            onClick={() => setActiveTab('table_summary')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'table_summary'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Table size={14} />
            <span>📋 Master Table Summaries</span>
          </button>

          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <BookOpen size={14} />
            <span>Core Thesis & Notes</span>
          </button>

          <button
            onClick={() => setActiveTab('formulas')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'formulas'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Zap size={14} />
            <span>Formulas & Units ({parsedSections.formulas.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('class_exam')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'class_exam'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <CheckCircle2 size={14} />
            <span>Academic Exam Prep (8 Types)</span>
          </button>

          <button
            onClick={() => setActiveTab('competitive_exam')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'competitive_exam'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Trophy size={14} />
            <span>Competitive (NEET/JEE 10 Types)</span>
          </button>

          <button
            onClick={() => setActiveTab('traps')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'traps'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <AlertTriangle size={14} />
            <span>Conceptual Traps</span>
          </button>

          <button
            onClick={() => setActiveTab('quick_cards')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'quick_cards'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Flame size={14} />
            <span>Quick Flashcards</span>
          </button>

          <button
            onClick={() => setActiveTab('self_assessment')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'self_assessment'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Target size={14} />
            <span>Quiz & Rating</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-3 sm:p-6 overflow-y-auto flex-1 space-y-6 text-slate-200 leading-relaxed no-scrollbar bg-slate-900/40">
          
          {/* TAB 0: 20-POINT LECTURE ACTIVITY SUMMARY */}
          {activeTab === 'activity_summary' && (
            <div className="space-y-6 max-w-5xl mx-auto pb-10">
              
              {/* Introduction Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 to-indigo-500/10 border border-amber-500/30 flex items-start gap-3.5">
                <Sparkles className="text-amber-400 shrink-0 mt-0.5 animate-pulse" size={20} />
                <div>
                  <h4 className="text-sm font-black text-amber-200 tracking-tight">Professor Clarity's Complete 20-Point Activity Report</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    An exhaustive record of today's learning session, custom-generated by <strong>Professor Clarity</strong>. Review coverage details, figures, exam preparation items, metrics, and next lecture bridge.
                  </p>
                </div>
              </div>

              {/* 20-Section Dashboard Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                
                {/* COLUMN 1: ADMINISTRATIVE & ATTENDANCE INSIGHTS */}
                <div className="space-y-5">
                  <h3 className="text-xs font-black text-indigo-400 uppercase tracking-widest px-1">1. Administration & Session Overview</h3>
                  
                  {/* Section 1: Lecture Overview */}
                  <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                    <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                      <Calendar size={14} className="text-indigo-400" />
                      <span className="text-xs font-black text-slate-200">1. Session Meta Details</span>
                    </div>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between"><span className="text-slate-400">Main Topic:</span><span className="font-bold text-white">{summaryData.overview.topic}</span></div>
                      <div className="flex justify-between"><span className="text-slate-400">Lecturer:</span><span className="font-bold text-amber-300">{summaryData.overview.professor}</span></div>
                      <div className="flex justify-between"><span className="text-slate-400">Date:</span><span className="font-medium text-slate-300">{summaryData.overview.date}</span></div>
                      <div className="flex justify-between"><span className="text-slate-400">Duration:</span><span className="font-bold text-emerald-400">{summaryData.overview.duration}</span></div>
                      <div className="flex justify-between"><span className="text-slate-400">Delivery Mode:</span><span className="font-medium text-slate-300">{summaryData.overview.mode}</span></div>
                      <div className="flex justify-between items-center"><span className="text-slate-400">Status:</span><span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-bold text-[9px]">{summaryData.overview.status}</span></div>
                    </div>
                  </div>

                  {/* Section 2 & 3: Topics Covered & Key Concepts */}
                  <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800/60 pb-2">
                      <div className="flex items-center gap-2">
                        <CheckSquare size={14} className="text-emerald-400" />
                        <span className="text-xs font-black text-slate-200">2. Topics & Syllabus Check</span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-md border border-emerald-500/20">
                        {summaryData.topicsCovered.rate}%
                      </span>
                    </div>
                    <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1 no-scrollbar text-xs">
                      {summaryData.topicsCovered.items.map((item, i) => (
                        <div key={i} className="flex items-start gap-2">
                          <CheckCircle2 size={12} className="text-emerald-500 shrink-0 mt-0.5" />
                          <span className="text-slate-300 line-clamp-1">{item.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Section 8: Student Questions Answered */}
                  <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                    <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                      <MessageSquare size={14} className="text-indigo-400" />
                      <span className="text-xs font-black text-slate-200">8. Virtual Student Q&A Log</span>
                    </div>
                    <div className="space-y-3 max-h-56 overflow-y-auto pr-1 no-scrollbar text-xs">
                      {summaryData.studentQuestions.map((q, i) => (
                        <div key={i} className="space-y-1 border-b border-slate-900 pb-2 last:border-b-0 last:pb-0">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-indigo-300">{q.student}</span>
                            <span className="text-[9px] text-slate-500 font-mono">Verified Query</span>
                          </div>
                          <p className="text-slate-300 italic bg-slate-900/60 p-2 rounded-lg border border-slate-800/60">" {q.question} "</p>
                          <p className="text-slate-400 text-[11px] mt-1 pl-1 border-l border-amber-500/50"><strong className="text-amber-300 font-bold">Clarity:</strong> {q.answer}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Section 13: Student Engagement Moments */}
                  <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                    <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                      <Users size={14} className="text-purple-400" />
                      <span className="text-xs font-black text-slate-200">13. Student Engagement Logs</span>
                    </div>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between items-center"><span className="text-slate-400">Classroom Size:</span><span className="font-bold text-white">{summaryData.overview.attendance} Active Users</span></div>
                      {summaryData.engagementMoments.map((m, i) => (
                        <div key={i} className="p-2 rounded-xl bg-purple-500/5 border border-purple-500/10 space-y-0.5">
                          <div className="font-bold text-purple-300 text-[11px]">{m.title}</div>
                          <p className="text-[10px] text-slate-400">{m.response}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                {/* COLUMN 2: ACADEMIC CORE, SCHEMATICS & DERIVATIONS */}
                <div className="space-y-5 md:col-span-2">
                  <h3 className="text-xs font-black text-amber-400 uppercase tracking-widest px-1">2. Core Academic Framework & Visual Assets</h3>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    
                    {/* Left Inner Column */}
                    <div className="space-y-5">
                      
                      {/* Section 3: Key Concepts Taught */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <Sparkles size={14} className="text-amber-400 animate-pulse" />
                          <span className="text-xs font-black text-slate-200">3. Key Concepts Explored</span>
                        </div>
                        <div className="space-y-3 text-xs">
                          {summaryData.keyConcepts.map((concept, i) => (
                            <div key={i} className="space-y-1">
                              <h5 className="font-black text-amber-200">{i + 1}. {concept.title}</h5>
                              <p className="text-slate-400 text-[11px]">{concept.description}</p>
                              <ul className="list-disc pl-4 space-y-0.5 text-slate-300 text-[10px]">
                                {concept.points.map((pt, k) => <li key={k}>{pt}</li>)}
                              </ul>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Section 5: Formulas & Equations Presented */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <Zap size={14} className="text-indigo-400" />
                          <span className="text-xs font-black text-slate-200">5. Formula & LaTeX Index</span>
                        </div>
                        <div className="space-y-3 text-xs">
                          {summaryData.formulasPresented.map((formula, i) => (
                            <div key={i} className="space-y-1 border-b border-slate-900 pb-2 last:border-b-0 last:pb-0">
                              <div className="relative group p-2 bg-slate-900 rounded-xl overflow-x-auto text-center">
                                <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                                  {`$$${formula.written}$$`}
                                </ReactMarkdown>
                                <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 bg-slate-950/80 rounded-lg p-1 border border-slate-800">
                                  <button
                                    onClick={() => {
                                      navigator.clipboard.writeText(formula.written);
                                      triggerHapticFeedback();
                                      showNotification?.("LaTeX formula copied!", "success");
                                    }}
                                    className="p-1 text-slate-400 hover:text-amber-400 transition-colors"
                                    title="Copy LaTeX code"
                                  >
                                    <Copy size={12} />
                                  </button>
                                  {onReadAloud && (
                                    <button
                                      onClick={() => {
                                        triggerHapticFeedback();
                                        onReadAloud(formula.spoken);
                                      }}
                                      className="p-1 text-slate-400 hover:text-indigo-400 transition-colors"
                                      title="Read Formula Aloud"
                                    >
                                      <Volume2 size={12} />
                                    </button>
                                  )}
                                </div>
                              </div>
                              <p className="text-[10px] text-slate-400 leading-normal"><strong className="text-slate-300">Spoken Flow:</strong> "{formula.spoken}"</p>
                              <p className="text-[10px] text-indigo-300 font-medium"><strong className="text-slate-400">Application:</strong> {formula.application}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Section 9: Common Misconceptions Addressed */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-rose-500/20 hover:border-rose-500/30 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <AlertTriangle size={14} className="text-rose-400" />
                          <span className="text-xs font-black text-slate-200 text-rose-200">9. Conceptual Traps Remediation</span>
                        </div>
                        <div className="space-y-3 text-xs">
                          {summaryData.misconceptions.map((mis, i) => (
                            <div key={i} className="space-y-1 bg-rose-500/5 p-2.5 rounded-xl border border-rose-500/10">
                              <div className="font-bold text-rose-300 flex items-center gap-1">
                                <span>⚠ Pitfall:</span>
                                <span className="line-through text-slate-400">{mis.issue}</span>
                              </div>
                              <p className="text-emerald-400 font-semibold">✓ Correct: {mis.correction}</p>
                              <p className="text-[10px] text-slate-300 mt-1">{mis.explanation}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>

                    {/* Right Inner Column */}
                    <div className="space-y-5">
                      
                      {/* Section 4: Figures & Diagrams Used */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <FileText size={14} className="text-emerald-400" />
                          <span className="text-xs font-black text-slate-200">4. Interactive Figure Indices</span>
                        </div>
                        <div className="space-y-3 text-xs">
                          {summaryData.figuresUsed.map((fig, i) => (
                            <div key={i} className="space-y-1 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                              <div className="font-black text-slate-200">{fig.title}</div>
                              <p className="text-[10px] text-slate-400"><strong className="text-slate-300">Purpose:</strong> {fig.purpose}</p>
                              <p className="text-[10px] text-slate-400"><strong className="text-slate-300">Key Tags:</strong> {fig.elements.join(', ')}</p>
                              <p className="text-[10px] text-slate-400"><strong className="text-slate-300">Animation:</strong> {fig.animation}</p>
                              <span className="inline-block mt-1 text-[9px] font-bold text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                                Exam Priority: {fig.examRelevance}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Section 6: Examples Worked Through */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <CheckCircle2 size={14} className="text-emerald-400" />
                          <span className="text-xs font-black text-slate-200">6. Worked Board Exemplars</span>
                        </div>
                        <div className="space-y-2 text-xs">
                          {summaryData.examplesWorked.map((ex, i) => (
                            <div key={i} className="space-y-1.5">
                              <div className="font-bold text-slate-200 bg-slate-900 p-2 rounded-xl border border-slate-800">{ex.question}</div>
                              <div className="pl-2 border-l border-emerald-500/40 space-y-1 text-[11px] text-slate-300">
                                {ex.solution.map((solStep, s) => <div key={s}>{solStep}</div>)}
                              </div>
                              <div className="text-[11px] font-bold text-emerald-400 bg-emerald-500/5 p-1.5 rounded-lg border border-emerald-500/10">
                                Final Answer: {ex.answer}
                              </div>
                              <p className="text-[9px] text-slate-500 font-mono italic">Method: {ex.method}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Section 10: Mnemonics & Memory Aids */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <Award size={14} className="text-amber-400" />
                          <span className="text-xs font-black text-slate-200">10. Mnemonics & Revision Keys</span>
                        </div>
                        <div className="space-y-3 text-xs">
                          {summaryData.mnemonics.map((mne, i) => (
                            <div key={i} className="space-y-1.5 bg-amber-500/5 p-2.5 rounded-xl border border-amber-500/10">
                              <div className="font-bold text-amber-200">{mne.name}</div>
                              <p className="text-[10px] text-slate-400 italic">{mne.description}</p>
                              <div className="space-y-0.5 pl-1.5 text-[10px] text-slate-300">
                                {mne.items.map((item, k) => <div key={k}>{item}</div>)}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>

                  </div>

                </div>

              </div>

              {/* SECTION 3: EXAM MATRIX, HOMEWORK & PERFORMANCE RATINGS */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                
                {/* COLUMN 1: EXAM ALIGNMENTS & PERFORMANCE RATINGS */}
                <div className="space-y-5">
                  <h3 className="text-xs font-black text-indigo-400 uppercase tracking-widest px-1">3. Exam Blueprint & Coverage</h3>
                  
                  {/* Section 11 & 12: Exam Prep Blueprint */}
                  <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                    <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                      <Trophy size={14} className="text-emerald-400" />
                      <span className="text-xs font-black text-slate-200">11 & 12. Exam Blueprint Metrics</span>
                    </div>
                    <div className="space-y-3 text-xs">
                      <div>
                        <span className="text-slate-400 font-bold block mb-1">Academic Board Exam Items:</span>
                        <div className="grid grid-cols-2 gap-1.5">
                          {summaryData.examPrep.map((item, i) => (
                            <div key={i} className="bg-slate-900 p-1.5 rounded-lg border border-slate-800 flex flex-col justify-center">
                              <span className="text-[10px] text-slate-400 truncate">{item.type.split(' ')[0]}</span>
                              <span className="text-xs font-black text-emerald-400">{item.count} Covered</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400 font-bold block mb-1">Competitive Entrance Items:</span>
                        <div className="grid grid-cols-2 gap-1.5">
                          {summaryData.compExam.map((item, i) => (
                            <div key={i} className="bg-slate-900 p-1.5 rounded-lg border border-slate-800 flex flex-col justify-center">
                              <span className="text-[10px] text-slate-400 truncate">{item.type.split(' ')[0]}</span>
                              <span className="text-xs font-black text-indigo-400">{item.count} Covered</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Section 18: Performance Metrics */}
                  <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                    <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                      <TrendingUp size={14} className="text-amber-400" />
                      <span className="text-xs font-black text-slate-200">18. Professor Clarity Performance</span>
                    </div>
                    <div className="space-y-2.5 text-xs">
                      {summaryData.performanceMetrics.map((met, i) => (
                        <div key={i} className="space-y-1">
                          <div className="flex justify-between text-[11px] text-slate-400">
                            <span>{met.category}</span>
                            <span className="font-bold text-amber-300">{met.rating} / {met.max}</span>
                          </div>
                          <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                            <div 
                              className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full"
                              style={{ width: `${(met.rating / met.max) * 100}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                {/* COLUMN 2: ANIMATIONS, RECAP LAYERS & HOMEWORK PATHS */}
                <div className="space-y-5 md:col-span-2">
                  <h3 className="text-xs font-black text-amber-400 uppercase tracking-widest px-1">4. Assignments & Path Ahead</h3>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    
                    {/* Inner Column Left */}
                    <div className="space-y-5">
                      
                      {/* Section 7: Questions Asked by Professor */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <HelpCircle size={14} className="text-indigo-400" />
                          <span className="text-xs font-black text-slate-200">7. Socratic Classroom Prompts</span>
                        </div>
                        <div className="space-y-2.5 text-xs">
                          {summaryData.questionsAsked.map((grp, i) => (
                            <div key={i} className="space-y-1">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">{grp.type}</span>
                              {grp.questions.map((q, k) => (
                                <div key={k} className="p-2 bg-slate-900 rounded-xl border border-slate-800/50 text-slate-300">
                                  "{q}"
                                </div>
                              ))}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Section 14: Visual & Animation Highlights */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <Layers size={14} className="text-purple-400" />
                          <span className="text-xs font-black text-slate-200">14 & 15. Summary & Recaps Delivered</span>
                        </div>
                        <div className="space-y-3.5 text-xs">
                          <div>
                            <span className="text-slate-400 font-bold block mb-1.5">Interactive Highlights:</span>
                            <div className="space-y-1.5">
                              {summaryData.animationsUsed.map((anim, i) => (
                                <div key={i} className="flex justify-between items-center text-[11px] bg-slate-900 p-1.5 rounded-lg border border-slate-800">
                                  <span className="font-bold text-slate-300">{anim.name}</span>
                                  <span className="text-[10px] text-purple-400">{anim.duration}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div>
                            <span className="text-slate-400 font-bold block mb-1.5">Multi-Layer Summaries Log:</span>
                            <div className="space-y-1.5">
                              {summaryData.summaryLayers.map((layer, i) => (
                                <div key={i} className="flex items-start gap-2 text-[11px]">
                                  <CheckCircle2 size={12} className="text-emerald-500 shrink-0 mt-0.5" />
                                  <div>
                                    <span className="font-bold text-white block">{layer.name}</span>
                                    <span className="text-slate-400 text-[10px]">{layer.content}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Section 19: Improvement Areas */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <CheckCircle2 size={14} className="text-indigo-400" />
                          <span className="text-xs font-black text-slate-200">19. Educator Self-Reflection</span>
                        </div>
                        <div className="space-y-2 text-xs">
                          {summaryData.improvementAreas.map((imp, i) => (
                            <div key={i} className="p-2 bg-slate-900/60 rounded-xl border border-slate-800 space-y-1">
                              <div className="flex justify-between items-center">
                                <span className="font-bold text-slate-200">Reflection point #{i + 1}</span>
                                <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase ${imp.priority === 'High' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : imp.priority === 'Medium' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-slate-800 text-slate-400'}`}>
                                  {imp.priority} Priority
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-300">"{imp.point}"</p>
                              <p className="text-[10px] text-indigo-300"><strong className="text-slate-400">Execution Plan:</strong> {imp.implementation}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>

                    {/* Inner Column Right */}
                    <div className="space-y-5">
                      
                      {/* Section 16 & 17: Homework & Practice Assigned */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <Home size={14} className="text-amber-400" />
                          <span className="text-xs font-black text-slate-200">16 & 17. Homework Assignments</span>
                        </div>
                        <div className="space-y-3 text-xs">
                          <div>
                            <span className="text-slate-400 font-bold block mb-1">Assigned Tasks:</span>
                            <ul className="list-disc pl-4 space-y-1 text-slate-300 text-[11px]">
                              {summaryData.homework.tasks.map((t, i) => <li key={i}>{t}</li>)}
                            </ul>
                          </div>
                          <div>
                            <span className="text-slate-400 font-bold block mb-1">Target Practice Problems:</span>
                            <div className="space-y-1.5">
                              {summaryData.practiceQuestions.map((q, i) => (
                                <div key={i} className="p-2 bg-slate-900 rounded-xl border border-slate-800/60 text-[11px]">
                                  <div className="flex justify-between mb-0.5">
                                    <span className="text-[9px] font-black uppercase text-indigo-400">{q.level} Level</span>
                                    <span className="text-[9px] text-slate-500 font-mono">Assigned</span>
                                  </div>
                                  <p className="text-slate-300">"{q.question}"</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Section 20: Next Lecture Preview & Bridge */}
                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-indigo-500/20 hover:border-indigo-500/30 transition-all space-y-3">
                        <div className="flex items-center gap-2 border-b border-slate-800/60 pb-2">
                          <Play size={14} className="text-indigo-400 animate-pulse" />
                          <span className="text-xs font-black text-slate-200 text-indigo-200">20. Next Lecture Bridge Card</span>
                        </div>
                        <div className="space-y-2.5 text-xs">
                          <div className="p-2.5 bg-indigo-950/40 rounded-xl border border-indigo-500/10 space-y-1">
                            <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider block">Upcoming Chapter</span>
                            <div className="font-black text-white text-sm">{summaryData.nextPreview.topic}</div>
                          </div>
                          <p className="text-[11px] text-slate-300"><strong className="text-slate-400">Conceptual Bridge:</strong> {summaryData.nextPreview.connection}</p>
                          <p className="text-[11px] text-amber-300 font-medium italic">" {summaryData.nextPreview.bridge} "</p>
                          <div>
                            <span className="text-slate-400 font-bold block mb-1">Required Prerequisites:</span>
                            <div className="flex flex-wrap gap-1">
                              {summaryData.nextPreview.prerequisites.map((pre, i) => (
                                <span key={i} className="text-[9px] font-semibold bg-slate-900 text-slate-300 px-1.5 py-0.5 rounded border border-slate-800">
                                  {pre}
                                </span>
                              ))}
                            </div>
                          </div>
                          <div>
                            <span className="text-slate-400 font-bold block mb-1">What to Bring next time:</span>
                            <ul className="list-disc pl-4 space-y-0.5 text-slate-300 text-[10px]">
                              {summaryData.nextPreview.itemsToBring.map((item, i) => <li key={i}>{item}</li>)}
                            </ul>
                          </div>
                        </div>
                      </div>

                    </div>

                  </div>

                </div>

              </div>

            </div>
          )}

          {/* TAB 1: 5-LAYER SUMMARIES */}
          {activeTab === 'summary_layers' && (
            <div className="space-y-6 max-w-4xl mx-auto">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
                <Layers className="text-amber-400 shrink-0 mt-0.5" size={20} />
                <div>
                  <h4 className="text-sm font-bold text-amber-200">Professor Clarity's 5-Layer Summary Engine</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Select a time-bracket recap layer designed for different study workflows: rapid 30s lightning review, 60s section recap, 3min master summary, 5min deep recall prep, or full visual board schematics.
                  </p>
                </div>
              </div>

              {/* Layer Selection Tabs */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {topicLayers.map((l) => (
                  <button
                    key={l.layer}
                    onClick={() => {
                      setSelectedLayer(l.layer);
                      triggerHapticFeedback();
                    }}
                    className={`p-3 rounded-2xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                      selectedLayer === l.layer
                        ? 'bg-amber-500/20 border-amber-500/60 shadow-lg text-amber-200 scale-[1.02]'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-black uppercase text-amber-400">Layer {l.layer}</span>
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">{l.duration}</span>
                    </div>
                    <span className="text-xs font-bold line-clamp-1">{l.title}</span>
                  </button>
                ))}
              </div>

              {/* Active Layer Display Card */}
              {(() => {
                const currentLayer = topicLayers.find(l => l.layer === selectedLayer) || topicLayers[0];
                if (!currentLayer) return null;
                return (
                  <div className="p-5 sm:p-6 rounded-3xl bg-slate-950/90 border border-amber-500/40 shadow-2xl space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div>
                        <span className="text-xs font-black uppercase tracking-wider text-amber-400">Layer {currentLayer.layer} • {currentLayer.duration}</span>
                        <h3 className="text-base sm:text-lg font-black text-white">{currentLayer.title}</h3>
                      </div>
                      {onReadAloud && (
                        <button
                          onClick={() => onReadAloud(`${currentLayer.title}. ${currentLayer.summary}. Key points: ${currentLayer.bulletPoints.join('. ')}. Key Takeaway: ${currentLayer.keyTakeaway}`)}
                          className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Volume2 size={14} />
                          <span>Listen Layer</span>
                        </button>
                      )}
                    </div>

                    <div className="p-3.5 rounded-2xl bg-amber-500/5 border border-amber-500/10 text-xs sm:text-sm text-amber-100/90 leading-relaxed font-medium">
                      "{currentLayer.summary}"
                    </div>

                    <div className="space-y-2.5">
                      <h5 className="text-xs font-black uppercase tracking-wider text-slate-400">Key Pillar Breakdown:</h5>
                      <div className="space-y-2">
                        {currentLayer.bulletPoints.map((pt, idx) => (
                          <div key={idx} className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs sm:text-sm text-slate-200">
                            <CheckCircle2 size={16} className="text-amber-400 shrink-0 mt-0.5" />
                            <span>{pt}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 flex items-center gap-3">
                      <Zap className="text-indigo-400 shrink-0" size={18} />
                      <div>
                        <span className="text-[10px] font-black uppercase text-indigo-300 block">Core Professor Takeaway</span>
                        <span className="text-xs sm:text-sm font-bold text-white">{currentLayer.keyTakeaway}</span>
                      </div>
                    </div>

                    {currentLayer.recallCheck && (
                      <div className="mt-4 pt-4 border-t border-slate-800 space-y-2">
                        <span className="text-xs font-black uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                          <Target size={14} />
                          <span>Immediate Active Recall Prompts:</span>
                        </span>
                        <div className="space-y-1.5">
                          {currentLayer.recallCheck.map((rc, rIdx) => (
                            <div key={rIdx} className="p-2.5 rounded-xl bg-purple-950/20 border border-purple-500/20 text-xs text-slate-300">
                              {rc}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}

          {/* TAB 1.5: MASTER TABLE SUMMARIES */}
          {activeTab === 'table_summary' && (
            <div className="space-y-6 max-w-5xl mx-auto pb-10">
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3.5 shadow-lg">
                <Table className="text-emerald-400 shrink-0 mt-0.5" size={22} />
                <div>
                  <h4 className="text-sm font-black text-emerald-200">Professor Clarity's Student-Friendly Table Summary Engine</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Every complex scientific matrix, process comparison, and formula table is automatically translated into <strong>Student Plain English</strong> with everyday analogies, exam memory tips, and live audio explanations. Click any row in the table below to reveal Professor Clarity's breakdown!
                  </p>
                </div>
              </div>

              {/* Interactive Table Generator Component */}
              <div className="rounded-3xl border border-emerald-500/30 overflow-hidden shadow-2xl bg-slate-950">
                <TableGenerator
                  initialText={parsedSections.overview.includes('|') ? parsedSections.overview : PRESET_TABLE_EXAMPLES[0].text}
                  theme="blackboard"
                  onDeliverToSmartboard={onDeliverToSmartboard}
                  showNotification={showNotification}
                  isInline={true}
                />
              </div>
            </div>
          )}

          {/* TAB 2: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
                <Sparkles className="text-amber-400 shrink-0 mt-0.5" size={20} />
                <div>
                  <h4 className="text-sm font-bold text-amber-200">Professor's Executive Core Thesis</h4>
                  <p className="text-xs text-amber-100/90 mt-1">
                    Master key principles, mathematical relationships, and high-yield concepts distilled directly from the 3D smartboard lecture.
                  </p>
                </div>
              </div>

              <div className="prose prose-invert prose-amber max-w-none prose-p:leading-relaxed prose-headings:text-amber-300 prose-pre:bg-slate-950">
                <ReactMarkdown
                  remarkPlugins={[remarkGfm, remarkMath]}
                  rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
                >
                  {markdownContent}
                </ReactMarkdown>
              </div>
            </div>
          )}

          {/* TAB 3: FORMULAS & SI UNITS */}
          {activeTab === 'formulas' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Zap className="text-indigo-400" size={20} />
                  <h4 className="text-sm font-bold text-indigo-200">Formula & SI Unit Reference Sheet</h4>
                </div>
                <span className="text-xs text-indigo-300 font-mono font-bold">Natural Spoken Audio Active</span>
              </div>

              {parsedSections.formulas.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {parsedSections.formulas.map((formula, idx) => {
                    const spokenForm = convertLaTeXToSpokenText(formula);
                    return (
                      <div key={idx} className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-3">
                        <div>
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="text-xs text-amber-400 font-mono font-bold">Formula #{idx + 1}</span>
                            <div className="flex gap-1.5">
                              <button
                                onClick={() => {
                                  navigator.clipboard.writeText(formula);
                                  triggerHapticFeedback();
                                  showNotification?.(`Formula LaTeX code copied!`, "success");
                                }}
                                className="p-1 text-slate-400 hover:text-amber-400 transition-colors bg-slate-900 rounded"
                                title="Copy LaTeX code"
                              >
                                <Copy size={12} />
                              </button>
                              {onReadAloud && (
                                <button
                                  onClick={() => {
                                    triggerHapticFeedback();
                                    onReadAloud(spokenForm);
                                  }}
                                  className="p-1 text-slate-400 hover:text-indigo-400 transition-colors bg-slate-900 rounded"
                                  title="Read Formula Aloud"
                                >
                                  <Volume2 size={12} />
                                </button>
                              )}
                            </div>
                          </div>
                          <div className="text-lg font-mono text-white py-2 overflow-x-auto text-center bg-slate-900/40 rounded-xl border border-slate-900 my-1">
                            <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                              {`$$${formula}$$`}
                            </ReactMarkdown>
                          </div>
                          <p className="text-[10px] text-slate-400 leading-normal mt-2">
                            <strong className="text-slate-300">Spoken Flow:</strong> "{spokenForm}"
                          </p>
                        </div>
                        <div className="text-[11px] text-slate-400 border-t border-slate-800/80 pt-2 flex items-center justify-between">
                          <span>LaTeX Symbol Renders Verified</span>
                          <span className="text-indigo-300 font-semibold">SI Unit Compliant</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-6 text-center text-slate-400 bg-slate-950/50 rounded-2xl border border-slate-800">
                  <Zap className="mx-auto mb-2 text-slate-600" size={28} />
                  <p className="text-sm font-medium">Formulas are rendered inline directly within the main lecture notes.</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: CLASS / BOARD EXAM PREP (8 CATEGORIES) */}
          {activeTab === 'class_exam' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="text-emerald-400" size={20} />
                  <div>
                    <h4 className="text-sm font-bold text-emerald-200">School & Board Examination Master Practice (8 Question Types)</h4>
                    <p className="text-xs text-emerald-100/90 mt-0.5">Structured with Step-by-Step Marking Schemes, Derivations, and Diagrams.</p>
                  </div>
                </div>
                <span className="text-xs text-emerald-400 font-bold bg-emerald-500/20 px-2.5 py-1 rounded-xl border border-emerald-500/30">
                  {filteredAcademicQuestions.length} Questions
                </span>
              </div>

              {/* Category Filter Bar */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {academicCategories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedAcademicCategory(cat);
                      triggerHapticFeedback();
                    }}
                    className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                      selectedAcademicCategory === cat
                        ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                        : 'bg-slate-950/80 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Questions List */}
              <div className="space-y-4">
                {filteredAcademicQuestions.map((q, idx) => {
                  const isRevealed = revealedAnswers[q.id];
                  return (
                    <div key={q.id} className="p-4 sm:p-5 rounded-2xl bg-slate-950/90 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-black uppercase tracking-wider border border-emerald-500/30">
                              {q.category}
                            </span>
                            <span className="text-xs font-bold text-amber-300 font-mono">
                              [{q.marks} Mark{q.marks > 1 ? 's' : ''}]
                            </span>
                          </div>
                          <h4 className="text-xs sm:text-sm font-bold text-white mt-1">
                            Q{idx + 1}: {q.question}
                          </h4>
                        </div>

                        <button
                          onClick={() => toggleRevealAnswer(q.id)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                            isRevealed
                              ? 'bg-slate-800 text-slate-300 border border-slate-700'
                              : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20'
                          }`}
                        >
                          {isRevealed ? <EyeOff size={13} /> : <Eye size={13} />}
                          <span>{isRevealed ? 'Hide Solution' : 'View Answer'}</span>
                        </button>
                      </div>

                      {/* Solution Area */}
                      {isRevealed && (
                        <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-3 text-xs sm:text-sm animate-in fade-in duration-200">
                          <div className="p-3.5 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-slate-200 space-y-1">
                            <span className="text-[10px] font-black uppercase text-emerald-400 block">Model Answer & Explanation:</span>
                            <div className="whitespace-pre-line leading-relaxed text-slate-300 font-medium">
                              {q.answer}
                            </div>
                          </div>

                          {q.markingScheme && (
                            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1 text-xs">
                              <span className="text-[10px] font-black uppercase text-amber-400 block">Official Marking Scheme Criteria:</span>
                              <ul className="list-disc pl-4 space-y-0.5 text-slate-300">
                                {q.markingScheme.map((ms, mIdx) => <li key={mIdx}>{ms}</li>)}
                              </ul>
                            </div>
                          )}

                          {q.matchingPairs && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                              {q.matchingPairs.map((pair, pIdx) => (
                                <div key={pIdx} className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex justify-between text-xs text-slate-300">
                                  <span className="font-bold text-amber-300">{pair.left}</span>
                                  <span className="text-emerald-400 font-mono">➔ {pair.right}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: COMPETITIVE EXAMS (JEE / NEET / SAT / GRE - 10 CATEGORIES) */}
          {activeTab === 'competitive_exam' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Trophy className="text-indigo-400" size={20} />
                  <div>
                    <h4 className="text-sm font-bold text-indigo-200">Competitive Entrance Examination Vault (10 High-Yield Categories)</h4>
                    <p className="text-xs text-indigo-100/90 mt-0.5">Includes Option Elimination, Numerical Kinetics, Assertion-Reason, and Speed Shortcut Tricks.</p>
                  </div>
                </div>
                <span className="text-xs text-indigo-400 font-bold bg-indigo-500/20 px-2.5 py-1 rounded-xl border border-indigo-500/30">
                  {filteredCompetitiveQuestions.length} Questions
                </span>
              </div>

              {/* Filter Controls */}
              <div className="flex flex-col sm:flex-row gap-2 justify-between">
                {/* Category Filter Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar flex-1">
                  {competitiveCategories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => {
                        setSelectedCompetitiveCategory(cat);
                        triggerHapticFeedback();
                      }}
                      className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                        selectedCompetitiveCategory === cat
                          ? 'bg-indigo-600 text-white font-black shadow-md'
                          : 'bg-slate-950/80 text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      {cat.split(' (')[0]}
                    </button>
                  ))}
                </div>

                {/* Exam Type Pill Filter */}
                <div className="flex items-center gap-1 shrink-0">
                  {['ALL', 'NEET', 'JEE Main', 'JEE Advanced', 'AIIMS'].map(type => (
                    <button
                      key={type}
                      onClick={() => setSelectedExamTypeFilter(type)}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                        selectedExamTypeFilter === type
                          ? 'bg-amber-500 text-slate-950 font-black'
                          : 'bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Competitive Questions List */}
              <div className="space-y-4">
                {filteredCompetitiveQuestions.map((q, idx) => {
                  const isRevealed = revealedAnswers[q.id];
                  const userChoice = mcqSelections[q.id];
                  return (
                    <div key={q.id} className="p-4 sm:p-5 rounded-2xl bg-slate-950/90 border border-slate-800 hover:border-indigo-500/40 transition-all space-y-3.5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px] font-black uppercase tracking-wider border border-indigo-500/30">
                              {q.examType}
                            </span>
                            <span className="px-2 py-0.5 rounded-md bg-slate-900 text-slate-300 text-[10px] font-bold border border-slate-800">
                              {q.category}
                            </span>
                            {q.pyqYear && (
                              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                                {q.pyqYear}
                              </span>
                            )}
                          </div>
                          <h4 className="text-xs sm:text-sm font-bold text-white mt-1.5">
                            Q{idx + 1}: {q.question}
                          </h4>
                        </div>

                        <button
                          onClick={() => toggleRevealAnswer(q.id)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                            isRevealed
                              ? 'bg-slate-800 text-slate-300 border border-slate-700'
                              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20'
                          }`}
                        >
                          {isRevealed ? <EyeOff size={13} /> : <Eye size={13} />}
                          <span>{isRevealed ? 'Hide Solution' : 'View Reasoning'}</span>
                        </button>
                      </div>

                      {/* Case Study Context if applicable */}
                      {q.caseStudyContext && (
                        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 italic">
                          <strong className="text-amber-300 not-italic">Case Study Context: </strong>
                          {q.caseStudyContext}
                        </div>
                      )}

                      {/* Interactive Options if available */}
                      {q.options && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                          {q.options.map((opt, oIdx) => {
                            const isSelected = userChoice === opt;
                            const isCorrectOpt = isRevealed && opt.startsWith(q.correctAnswer.slice(0, 2));
                            return (
                              <button
                                key={oIdx}
                                onClick={() => {
                                  setMcqSelections(prev => ({ ...prev, [q.id]: opt }));
                                  triggerHapticFeedback(10);
                                }}
                                className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all cursor-pointer flex items-center justify-between ${
                                  isCorrectOpt
                                    ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-200 font-bold'
                                    : isSelected
                                    ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900'
                                }`}
                              >
                                <span>{opt}</span>
                                {isCorrectOpt && <Check size={14} className="text-emerald-400 shrink-0" />}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* Solution and Shortcut Trick */}
                      {isRevealed && (
                        <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2.5 text-xs sm:text-sm animate-in fade-in duration-200">
                          <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-500/30 space-y-1">
                            <span className="text-[10px] font-black uppercase text-indigo-300 block">
                              Correct Answer: <strong className="text-white">{q.correctAnswer}</strong>
                            </span>
                            <div className="whitespace-pre-line text-slate-300 text-xs sm:text-sm leading-relaxed mt-1">
                              {q.explanation}
                            </div>
                          </div>

                          {q.shortcutTrick && (
                            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-2 text-xs">
                              <Zap size={14} className="text-amber-400 shrink-0 mt-0.5" />
                              <div>
                                <strong className="text-amber-300 font-bold">Professor Speed Shortcut Trick: </strong>
                                <span className="text-slate-200">{q.shortcutTrick}</span>
                              </div>
                            </div>
                          )}

                          {q.formulaUsed && (
                            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 flex items-center justify-between">
                              <span className="text-slate-400 font-sans">Formula:</span>
                              <span className="text-indigo-300">{q.formulaUsed}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 6: CONCEPTUAL TRAPS */}
          {activeTab === 'traps' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-2">
                <AlertTriangle className="text-rose-400" size={20} />
                <div>
                  <h4 className="text-sm font-bold text-rose-200">Top Conceptual Traps & Common Student Mistakes</h4>
                  <p className="text-xs text-rose-100/90 mt-0.5">Critical pitfalls to avoid during examinations to secure maximum marks.</p>
                </div>
              </div>

              {parsedSections.traps.length > 0 ? (
                <div className="space-y-3">
                  {parsedSections.traps.map((trap, i) => (
                    <div key={i} className="p-4 rounded-2xl bg-slate-950/90 border border-rose-500/30 text-xs sm:text-sm text-slate-200">
                      <ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                        {trap}
                      </ReactMarkdown>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-3">
                  {summaryData.misconceptions.map((mis, i) => (
                    <div key={i} className="p-4 rounded-2xl bg-slate-950/90 border border-rose-500/30 space-y-2">
                      <div className="flex items-center gap-2 text-rose-300 font-bold text-xs sm:text-sm">
                        <AlertTriangle size={15} />
                        <span>Pitfall #{i + 1}: <span className="line-through text-slate-400">{mis.issue}</span></span>
                      </div>
                      <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 font-semibold">
                        ✓ Scientific Correction: {mis.correction}
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{mis.explanation}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 7: QUICK REVISION FLASHCARDS */}
          {activeTab === 'quick_cards' && (
            <div className="space-y-5 max-w-4xl mx-auto">
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-start gap-3">
                <Flame className="text-cyan-400 shrink-0 mt-0.5 animate-pulse" size={20} />
                <div>
                  <h4 className="text-sm font-bold text-cyan-200">Quick Recall Flashcards</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Click any card to flip and verify your retention before moving to solving exam papers.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {flashcards.map((card, cIdx) => {
                  const isFlipped = flippedCards[cIdx];
                  return (
                    <div
                      key={cIdx}
                      onClick={() => toggleFlipCard(cIdx)}
                      className={`min-h-[160px] p-5 rounded-3xl border transition-all cursor-pointer flex flex-col justify-between select-none ${
                        isFlipped
                          ? 'bg-gradient-to-br from-indigo-950/90 to-slate-950 border-indigo-500/60 shadow-xl scale-[1.01]'
                          : 'bg-slate-950/90 border-slate-800 hover:border-cyan-500/40 hover:bg-slate-900/60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 text-[10px] font-black uppercase">
                          {card.tag}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                          <RotateCw size={11} />
                          {isFlipped ? 'Answer (Click to Front)' : 'Click to Flip'}
                        </span>
                      </div>

                      <div className="my-3 text-xs sm:text-sm font-bold leading-relaxed">
                        {isFlipped ? (
                          <div className="text-emerald-300 whitespace-pre-line font-mono">{card.back}</div>
                        ) : (
                          <div className="text-white">{card.front}</div>
                        )}
                      </div>

                      <div className="text-[10px] text-slate-500 border-t border-slate-900 pt-1.5 flex justify-between">
                        <span>Card #{cIdx + 1} of {flashcards.length}</span>
                        <span className="text-cyan-400 font-bold">{isFlipped ? 'Verified' : 'Test Memory'}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 8: SELF-ASSESSMENT & QUIZ */}
          {activeTab === 'self_assessment' && (
            <div className="space-y-6 max-w-4xl mx-auto">
              <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-start gap-3">
                <Target className="text-purple-400 shrink-0 mt-0.5" size={20} />
                <div>
                  <h4 className="text-sm font-bold text-purple-200">Student Self-Assessment & Instant Recall Check</h4>
                  <p className="text-xs text-purple-100/90 mt-0.5">
                    Evaluate your mastery level (1 to 5 stars) and test your recall key points before taking school exams or entrance tests.
                  </p>
                </div>
              </div>

              {/* 1. Rate Understanding */}
              <div className="p-5 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
                <div className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  1. How well do you understand "{topicTitle}"?
                </div>
                <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => {
                        setUserRating(star);
                        showNotification?.(`Mastery rating set to ${star}/5 stars!`, 'success');
                        triggerHapticFeedback();
                      }}
                      className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                        userRating === star
                          ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-600/30 scale-105'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      <span>★</span>
                      <span>{star} / 5</span>
                    </button>
                  ))}
                </div>
                {userRating !== null && (
                  <div className="p-3 rounded-xl bg-purple-950/50 border border-purple-500/30 text-xs text-purple-200">
                    {userRating >= 4 ? "🌟 Outstanding Mastery! You are ready to solve 5-mark derivations and JEE/NEET MCQs!" : userRating === 3 ? "👍 Good understanding! Review the Formula Sheet and Traps section once more." : "💡 Keep reviewing! Use Professor Clarity's 30s Lightning Recap and Read Aloud tools."}
                  </div>
                )}
              </div>

              {/* 2. Interactive Quick Recall Check */}
              <div className="p-5 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-4">
                <div className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  2. Quick Memory Check (Self-Test)
                </div>
                
                <div className="space-y-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="font-semibold text-white">Q1: What does a first derivative f'(x) = 0 identify on a smooth curve?</div>
                    <div className="flex flex-wrap gap-2">
                      {['a) Inflection point', 'b) Critical stationary point', 'c) Vertical asymptote', 'd) Discontinuity'].map((opt) => (
                        <button
                          key={opt}
                          onClick={() => setQuizAnswers(prev => ({ ...prev, 1: opt }))}
                          className={`px-3 py-1.5 rounded-lg border text-xs cursor-pointer transition-all ${
                            quizAnswers[1] === opt
                              ? opt.startsWith('b') ? 'bg-emerald-600 text-white border-emerald-400' : 'bg-rose-600 text-white border-rose-400'
                              : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                    {quizAnswers[1] && (
                      <div className="text-[11px] text-slate-300 font-mono pt-1">
                        {quizAnswers[1].startsWith('b') ? '✅ Correct! Points where f\'(x) = 0 are critical stationary points.' : '❌ Incorrect. Points where f\'(x) = 0 are critical stationary points.'}
                      </div>
                    )}
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="font-semibold text-white">Q2: What is the SI unit of acceleration or gravitational field strength?</div>
                    <div className="flex flex-wrap gap-2">
                      {['a) m/s', 'b) m/s²', 'c) kg/m³', 'd) N·m'].map((opt) => (
                        <button
                          key={opt}
                          onClick={() => setQuizAnswers(prev => ({ ...prev, 2: opt }))}
                          className={`px-3 py-1.5 rounded-lg border text-xs cursor-pointer transition-all ${
                            quizAnswers[2] === opt
                              ? opt.startsWith('b') ? 'bg-emerald-600 text-white border-emerald-400' : 'bg-rose-600 text-white border-rose-400'
                              : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                    {quizAnswers[2] && (
                      <div className="text-[11px] text-slate-300 font-mono pt-1">
                        {quizAnswers[2].startsWith('b') ? '✅ Correct! Read aloud as "meters per second squared".' : '❌ Incorrect. Acceleration is measured in m/s².'}
                      </div>
                    )}
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950/90 border-t border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Target size={14} className="text-amber-400" />
            <span className="hidden sm:inline">Professor Clarity Real-World Academic & Competitive Pedagogy Engine</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider transition-all cursor-pointer shadow-lg shadow-amber-500/20"
          >
            Close Master Hub
          </button>
        </div>

      </div>
    </div>
  );
};
