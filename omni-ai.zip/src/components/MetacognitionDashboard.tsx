import React, { useState, useEffect } from 'react';
import { 
  getCalibrationRecords, 
  getOverallCalibrationSummary, 
  getTopicCalibrationSummaries, 
  subscribeToCalibrationUpdates 
} from '../modules/metacognition/storage';
import { mapRecordsToQuadrantPoints } from '../modules/metacognition/calibration';
import { generateInstantInsights, generateWeeklyMetacognitionReport, MetacognitionInsight } from '../modules/metacognition/insightsGenerator';
import { QuadrantChart } from './QuadrantChart';
import { 
  BrainCircuit, 
  AlertTriangle, 
  ShieldAlert, 
  Zap, 
  Sparkles, 
  BarChart3, 
  TrendingUp, 
  RotateCcw,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface MetacognitionDashboardProps {
  subject?: string;
  onClose?: () => void;
  onStartTargetedPractice?: (topicId: string) => void;
}

export const MetacognitionDashboard: React.FC<MetacognitionDashboardProps> = ({
  subject,
  onClose,
  onStartTargetedPractice
}) => {
  const [records, setRecords] = useState(getCalibrationRecords());
  const [overall, setOverall] = useState(getOverallCalibrationSummary(subject));
  const [topicSummaries, setTopicSummaries] = useState(getTopicCalibrationSummaries(subject));
  const [weeklyReport, setWeeklyReport] = useState<string | null>(null);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);

  // Subscribe to real-time updates when new confidence ratings are submitted
  useEffect(() => {
    const unsub = subscribeToCalibrationUpdates(() => {
      setRecords(getCalibrationRecords());
      setOverall(getOverallCalibrationSummary(subject));
      setTopicSummaries(getTopicCalibrationSummaries(subject));
    });
    return unsub;
  }, [subject]);

  const quadrantPoints = mapRecordsToQuadrantPoints(subject ? records.filter(r => r.subject === subject) : records);
  const instantInsights = generateInstantInsights(overall, topicSummaries);

  const handleGenerateWeeklyReport = async () => {
    setIsGeneratingReport(true);
    try {
      const reportText = await generateWeeklyMetacognitionReport(overall, topicSummaries);
      setWeeklyReport(reportText);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const calibrationPct = Math.round(overall.calibrationScore * 100);

  return (
    <div className="flex flex-col gap-6 w-full max-w-5xl mx-auto p-1 animate-fadeIn">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 p-6 rounded-2xl text-white shadow-xl relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Metacognition & Self-Calibration Engine
              </span>
              <span className="text-xs text-slate-400">
                {subject || 'All Subjects'} • {records.length} Answers Evaluated
              </span>
            </div>
            <h2 className="text-2xl font-extrabold tracking-tight text-white mb-1 flex items-center gap-2">
              <BrainCircuit className="text-indigo-400" size={26} />
              Metacognitive Calibration Dashboard
            </h2>
            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              Metacognition measures how accurately your self-assessed confidence aligns with actual accuracy. Eliminating overconfidence gaps is the #1 predictor of exam success.
            </p>
          </div>

          {/* Main Calibration Score Dial */}
          <div className="flex items-center gap-4 shrink-0">
            <div className="flex flex-col items-center justify-center p-4 rounded-xl bg-slate-800/90 border border-indigo-500/40 min-w-[140px] text-center shadow-lg">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">Calibration Score</span>
              <span className={cn("text-3xl font-black", calibrationPct >= 80 ? "text-emerald-400" : calibrationPct >= 60 ? "text-indigo-400" : "text-rose-400")}>
                {calibrationPct}%
              </span>
              <span className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 font-semibold">
                <TrendingUp size={11} className="text-emerald-400" /> Perfect = 100%
              </span>
            </div>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-indigo-500/20 relative z-10">
          <div className="flex flex-col gap-0.5 p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <span className="text-[11px] text-slate-400 font-medium">Avg Confidence</span>
            <span className="text-sm font-bold text-indigo-300">{(overall.avgConfidence * 100).toFixed(0)}%</span>
          </div>
          <div className="flex flex-col gap-0.5 p-2.5 rounded-lg bg-slate-800/40 border border-slate-700/50">
            <span className="text-[11px] text-slate-400 font-medium">Actual Accuracy</span>
            <span className="text-sm font-bold text-emerald-300">{(overall.accuracy * 100).toFixed(0)}%</span>
          </div>
          <div className="flex flex-col gap-0.5 p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/30">
            <span className="text-[11px] text-rose-300 font-bold">Dangerous Blind Spots</span>
            <span className="text-sm font-black text-rose-400">{overall.dangerousCount}</span>
          </div>
          <div className="flex flex-col gap-0.5 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30">
            <span className="text-[11px] text-amber-300 font-bold">Underconfident Gems</span>
            <span className="text-sm font-black text-amber-400">{overall.underconfidentCount}</span>
          </div>
        </div>
      </div>

      {/* Instant Actionable Insights */}
      {instantInsights.length > 0 && (
        <div className="flex flex-col gap-3">
          <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles size={14} className="text-indigo-500" />
            Immediate Metacognitive Recommendations
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {instantInsights.map((insight) => (
              <div 
                key={insight.id} 
                className={cn(
                  "p-4 rounded-xl border flex flex-col justify-between gap-3 shadow-sm",
                  insight.type === 'dangerous' ? "bg-rose-500/10 border-rose-500/30 text-rose-900 dark:text-rose-100" :
                  insight.type === 'underconfident' ? "bg-amber-500/10 border-amber-500/30 text-amber-900 dark:text-amber-100" :
                  "bg-indigo-500/10 border-indigo-500/30 text-indigo-900 dark:text-indigo-100"
                )}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold flex items-center gap-1.5">
                      {insight.type === 'dangerous' && <ShieldAlert size={14} className="text-rose-500" />}
                      {insight.type === 'underconfident' && <Zap size={14} className="text-amber-500" />}
                      {insight.type === 'calibrated' && <CheckCircle2 size={14} className="text-emerald-500" />}
                      {insight.title}
                    </span>
                    <span className="text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-black/10 dark:bg-white/10">
                      {insight.priority} priority
                    </span>
                  </div>
                  <p className="text-xs leading-relaxed opacity-90">{insight.message}</p>
                </div>

                {insight.actionableTopicId && onStartTargetedPractice && (
                  <button
                    onClick={() => onStartTargetedPractice(insight.actionableTopicId!)}
                    className="self-start flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/10 dark:bg-white/10 hover:bg-black/20 text-xs font-bold transition cursor-pointer"
                  >
                    Target Practice <ArrowRight size={13} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2x2 Quadrant Analysis Section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <BarChart3 size={15} className="text-indigo-500" />
            2x2 Metacognitive Calibration Matrix
          </h3>
          <span className="text-xs text-slate-400">Confidence (X) vs Correctness (Y)</span>
        </div>

        <QuadrantChart points={quadrantPoints} />
      </div>

      {/* Topic-wise Breakdown Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex flex-col gap-4">
        <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <BookOpen size={15} className="text-indigo-500" />
          Topic-Wise Calibration Breakdown
        </h3>

        {topicSummaries.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400">
            No confidence records collected yet. Practice chapters to auto-populate calibration metrics!
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {topicSummaries.map((topic) => (
              <div 
                key={topic.topicId}
                className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex flex-col gap-1">
                  <span className="font-bold text-slate-800 dark:text-slate-200">{topic.topicTitle}</span>
                  <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400">
                    <span>{topic.totalAnswers} answered</span>
                    <span>•</span>
                    <span>Confidence: <strong>{(topic.avgConfidence * 100).toFixed(0)}%</strong></span>
                    <span>•</span>
                    <span>Accuracy: <strong>{(topic.accuracy * 100).toFixed(0)}%</strong></span>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0 w-full sm:w-auto justify-between sm:justify-end">
                  {topic.dangerousCount > 0 && (
                    <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-rose-500/10 text-rose-500 border border-rose-500/30 flex items-center gap-1">
                      <ShieldAlert size={12} /> {topic.dangerousCount} Dangerous
                    </span>
                  )}
                  <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                    {(topic.calibrationScore * 100).toFixed(0)}% Calibrated
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* AI Weekly Metacognition Report Generator */}
      <div className="bg-indigo-900/30 border border-indigo-500/30 p-5 rounded-2xl flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-indigo-300 font-bold text-xs">
            <Sparkles size={16} className="text-indigo-400" />
            AI Metacognitive Weekly Report
          </div>
          <button
            onClick={handleGenerateWeeklyReport}
            disabled={isGeneratingReport}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-md cursor-pointer disabled:opacity-50"
          >
            {isGeneratingReport ? 'Generating AI Report...' : 'Generate Weekly AI Insight'}
          </button>
        </div>

        {weeklyReport && (
          <div className="p-4 rounded-xl bg-slate-900/90 border border-indigo-500/40 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap font-sans mt-2 animate-fadeIn">
            {weeklyReport}
          </div>
        )}
      </div>
    </div>
  );
};
