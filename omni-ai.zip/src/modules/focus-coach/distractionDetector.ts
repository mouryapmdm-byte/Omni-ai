import { StudySession } from './types';

export type DistractionCallback = (event: {
  type: 'tab-switch' | 'idle-detected' | 'focus-drop';
  tabSwitchCount: number;
  idleSeconds: number;
  currentFocusScore: number;
  message: string;
}) => void;

const SESSION_STORAGE_KEY = 'omni_focus_study_sessions_v1';

export class DistractionDetector {
  private static instance: DistractionDetector;
  private isTracking: boolean = false;
  private tabSwitches: number = 0;
  private idleSeconds: number = 0;
  private lastActivityTime: number = Date.now();
  private sessionStartTime: number = Date.now();
  private callbacks: Set<DistractionCallback> = new Set();
  private idleCheckInterval: number | null = null;
  private tabSwitchTimestamps: number[] = [];

  private constructor() {
    this.setupListeners();
  }

  public static getInstance(): DistractionDetector {
    if (!DistractionDetector.instance) {
      DistractionDetector.instance = new DistractionDetector();
    }
    return DistractionDetector.instance;
  }

  public subscribe(callback: DistractionCallback): () => void {
    this.callbacks.add(callback);
    return () => {
      this.callbacks.delete(callback);
    };
  }

  private setupListeners(): void {
    if (typeof window === 'undefined') return;

    // Visibility change / tab switch listener
    document.addEventListener('visibilitychange', () => {
      if (!this.isTracking) return;

      if (document.hidden) {
        const now = Date.now();
        this.tabSwitches++;
        this.tabSwitchTimestamps.push(now);

        // Keep only switches in last 10 minutes
        const tenMinutesAgo = now - 10 * 60 * 1000;
        this.tabSwitchTimestamps = this.tabSwitchTimestamps.filter(t => t >= tenMinutesAgo);

        const currentScore = this.calculateFocusScore();

        // If >= 3 tab switches in last 10 minutes, trigger gentle notification
        if (this.tabSwitchTimestamps.length >= 3) {
          this.notify({
            type: 'tab-switch',
            tabSwitchCount: this.tabSwitches,
            idleSeconds: this.idleSeconds,
            currentFocusScore: currentScore,
            message: `You switched tabs ${this.tabSwitchTimestamps.length} times in the last 10 minutes.`
          });
        }
      }
    });

    // Activity tracking for idle detection
    const handleActivity = () => {
      if (this.isTracking) {
        this.lastActivityTime = Date.now();
      }
    };

    window.addEventListener('mousemove', handleActivity, { passive: true });
    window.addEventListener('keydown', handleActivity, { passive: true });
    window.addEventListener('scroll', handleActivity, { passive: true });
    window.addEventListener('touchstart', handleActivity, { passive: true });
  }

  public startSession(): void {
    this.isTracking = true;
    this.tabSwitches = 0;
    this.idleSeconds = 0;
    this.tabSwitchTimestamps = [];
    this.lastActivityTime = Date.now();
    this.sessionStartTime = Date.now();

    if (this.idleCheckInterval) clearInterval(this.idleCheckInterval);

    this.idleCheckInterval = window.setInterval(() => {
      if (!this.isTracking) return;

      const idleDuration = (Date.now() - this.lastActivityTime) / 1000;
      if (idleDuration >= 60) {
        this.idleSeconds += 15;
        const currentScore = this.calculateFocusScore();

        if (idleDuration >= 180 && idleDuration % 120 < 15) {
          this.notify({
            type: 'idle-detected',
            tabSwitchCount: this.tabSwitches,
            idleSeconds: Math.round(this.idleSeconds),
            currentFocusScore: currentScore,
            message: `Idle for over ${Math.round(idleDuration / 60)} minutes. Time for a quick stretch?`
          });
        }
      }
    }, 15000);
  }

  public pauseSession(): void {
    this.isTracking = false;
    if (this.idleCheckInterval) {
      clearInterval(this.idleCheckInterval);
      this.idleCheckInterval = null;
    }
  }

  public resetSession(): void {
    this.pauseSession();
    this.tabSwitches = 0;
    this.idleSeconds = 0;
    this.tabSwitchTimestamps = [];
  }

  public calculateFocusScore(): number {
    const elapsedMinutes = Math.max(1, (Date.now() - this.sessionStartTime) / 60000);

    // Base 100
    let score = 100;

    // Deduct 6 points per tab switch
    score -= this.tabSwitches * 6;

    // Deduct for idle time (>2 minutes idle per 10 minutes session)
    const idleMinutes = this.idleSeconds / 60;
    score -= Math.min(30, idleMinutes * 3);

    // Rate penalty per minute if tab switching is excessive
    const switchRatePerTenMin = (this.tabSwitches / elapsedMinutes) * 10;
    if (switchRatePerTenMin > 4) {
      score -= (switchRatePerTenMin - 4) * 4;
    }

    return Math.max(15, Math.min(100, Math.round(score)));
  }

  public getMetrics() {
    return {
      tabSwitches: this.tabSwitches,
      idleMinutes: Math.round(this.idleSeconds / 60),
      focusScore: this.calculateFocusScore(),
      elapsedMinutes: Math.round((Date.now() - this.sessionStartTime) / 60000)
    };
  }

  private notify(event: Parameters<DistractionCallback>[0]): void {
    this.callbacks.forEach(fn => fn(event));
  }

  public static saveCompletedSession(session: StudySession): void {
    try {
      const stored = localStorage.getItem(SESSION_STORAGE_KEY);
      const sessions: StudySession[] = stored ? JSON.parse(stored) : [];
      sessions.unshift(session);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(sessions));
    } catch (e) {
      console.error('Failed to save study session', e);
    }
  }

  public static getSavedSessions(): StudySession[] {
    try {
      const stored = localStorage.getItem(SESSION_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to load study sessions', e);
    }
    return [];
  }
}
