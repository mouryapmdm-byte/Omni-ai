import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { CONFIG } from '../lib/constants';
import { generateAIResponse } from '../lib/gemini';
import { Plus, Trash2, Link as LinkIcon, Sparkles, RefreshCw, ZoomIn, ZoomOut, Maximize2, Layers } from 'lucide-react';
import { cn } from '../lib/utils';

interface MindNode extends d3.SimulationNodeDatum {
  id: string;
  label: string;
  description?: string;
  status?: 'mastered' | 'current' | 'available' | 'locked';
  color?: string;
}

interface MindLink extends d3.SimulationLinkDatum<MindNode> {
  source: string;
  target: string;
  label?: string;
}

interface KnowledgeGraphProps {
  subject: string;
  topic: string;
  theme?: 'light' | 'dark';
  onSelectTopic?: (topicId: string) => void;
  showNotification: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const KnowledgeGraph: React.FC<KnowledgeGraphProps> = ({
  subject,
  topic,
  theme = 'light',
  onSelectTopic,
  showNotification
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // States
  const [nodes, setNodes] = useState<MindNode[]>([]);
  const [links, setLinks] = useState<MindLink[]>([]);
  
  // Custom interactive editing fields
  const [nodeLabel, setNodeLabel] = useState('');
  const [nodeDesc, setNodeDesc] = useState('');
  const [nodeColor, setNodeColor] = useState('#6366f1'); // Indigo

  const [linkSource, setLinkSource] = useState('');
  const [linkTarget, setLinkTarget] = useState('');
  const [linkLabel, setLinkLabel] = useState('explains');

  const [isGeneratingAI, setIsGeneratingAI] = useState(false);

  // Load from localStorage or populate default for current topic
  useEffect(() => {
    const saved = localStorage.getItem(`omni_mindmap_${subject}_${topic}`);
    if (saved) {
      try {
        const { nodes: savedNodes, links: savedLinks } = JSON.parse(saved);
        setNodes(savedNodes.map((n: any) => ({ ...n }))); // clear standard d3 mutated refs
        setLinks(savedLinks.map((l: any) => ({ ...l })));
        return;
      } catch (e) {
        console.warn("Could not load saved mindmap, creating defaults");
      }
    }
    loadDefaultSyllabusMap();
  }, [subject, topic]);

  // Save to localStorage
  const saveMap = (updatedNodes: MindNode[], updatedLinks: MindLink[]) => {
    // Strip d3 simulation metadata to save pure nodes
    const cleanNodes = updatedNodes.map(n => ({
      id: n.id,
      label: n.label,
      description: n.description,
      status: n.status,
      color: n.color
    }));
    const cleanLinks = updatedLinks.map(l => ({
      source: typeof l.source === 'object' ? (l.source as any).id : l.source,
      target: typeof l.target === 'object' ? (l.target as any).id : l.target,
      label: l.label
    }));
    
    setNodes(cleanNodes);
    setLinks(cleanLinks);
    localStorage.setItem(`omni_mindmap_${subject}_${topic}`, JSON.stringify({ nodes: cleanNodes, links: cleanLinks }));
  };

  const loadDefaultSyllabusMap = () => {
    // Build a nice default conceptual structure based on active topic
    const defaultNodes: MindNode[] = [
      { id: '1', label: `${topic.replace(/_/g, ' ').toUpperCase()} Root`, description: 'Core learning foundation concept', color: '#6366f1' },
      { id: '2', label: 'Prerequisites', description: 'Essential entry-level facts', color: '#10b981' },
      { id: '3', label: 'Core Definitions', description: 'Terminology and notations', color: '#3b82f6' },
      { id: '4', label: 'Practical Applications', description: 'Real-world case studies', color: '#f59e0b' },
      { id: '5', label: 'Advanced Theories', description: 'Subtle boundary conditions', color: '#8b5cf6' }
    ];

    const defaultLinks: MindLink[] = [
      { source: '2', target: '1', label: 'enables' },
      { source: '1', target: '3', label: 'comprises' },
      { source: '3', target: '4', label: 'drives' },
      { source: '3', target: '5', label: 'generalizes to' }
    ];

    saveMap(defaultNodes, defaultLinks);
    showNotification('Standard syllabus mind map loaded!', 'info');
  };

  // Force simulation d3 engine
  useEffect(() => {
    if (!svgRef.current || !containerRef.current || nodes.length === 0) return;

    const width = containerRef.current.clientWidth || 600;
    const height = 440;

    // Deep copy to prevent mutating state values during d3 simulation
    const simulationNodes: MindNode[] = nodes.map(n => ({ ...n }));
    const simulationLinks: MindLink[] = links.map(l => ({
      source: typeof l.source === 'object' ? (l.source as any).id : l.source,
      target: typeof l.target === 'object' ? (l.target as any).id : l.target,
      label: l.label
    }));

    const svg = d3.select(svgRef.current)
      .attr('width', '100%')
      .attr('height', height);

    svg.selectAll('*').remove();

    // Create container for zoom support
    const g = svg.append('g');

    // Add marker definitions for arrows
    svg.append('defs').append('marker')
      .attr('id', 'arrow')
      .attr('viewBox', '0 -5 10 10')
      .attr('refX', 22)
      .attr('refY', 0)
      .attr('markerWidth', 6)
      .attr('markerHeight', 6)
      .attr('orient', 'auto')
      .append('path')
      .attr('d', 'M0,-5L10,0L0,5')
      .attr('fill', theme === 'dark' ? '#475569' : '#cbd5e1');

    // Setup zoom
    const zoomBehavior = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.3, 3])
      .on('zoom', (event: any) => {
        g.attr('transform', event.transform);
      });
    
    svg.call(zoomBehavior as any);

    // Layout simulation forces
    const simulation = d3.forceSimulation<MindNode>(simulationNodes)
      .force('link', d3.forceLink<MindNode, MindLink>(simulationLinks).id((d: any) => d.id).distance(140))
      .force('charge', d3.forceManyBody().strength(-220))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide(50));

    // Render connection line strokes
    const linkGroup = g.append('g')
      .selectAll('.link-g')
      .data(simulationLinks)
      .join('g')
      .attr('class', 'link-g');

    const linkLine = linkGroup.append('line')
      .attr('stroke', theme === 'dark' ? '#334155' : '#e2e8f0')
      .attr('stroke-width', 2.5)
      .attr('marker-end', 'url(#arrow)');

    // Add connection labels text
    const linkText = linkGroup.append('text')
      .text((d: any) => d.label || '')
      .attr('font-size', '9px')
      .attr('font-weight', '700')
      .attr('fill', theme === 'dark' ? '#94a3b8' : '#64748b')
      .attr('text-anchor', 'middle')
      .attr('dy', -4)
      .attr('class', 'select-none pointer-events-none');

    // Render concept nodes
    const node = g.append('g')
      .selectAll('.node-g')
      .data(simulationNodes)
      .join('g')
      .attr('class', 'node-g cursor-pointer')
      .call(d3.drag<SVGGElement, MindNode>()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended) as any);

    // Double click to delete concept node
    node.on('dblclick', (event: any, d: any) => {
      handleDeleteNode(d.id);
    });

    // Outer node circle
    node.append('circle')
      .attr('r', 18)
      .attr('fill', (d: any) => d.color || '#6366f1')
      .attr('stroke', theme === 'dark' ? '#1e293b' : '#ffffff')
      .attr('stroke-width', 2.5)
      .attr('class', 'transition-all duration-300 hover:scale-110');

    // Inner glowing ring
    node.append('circle')
      .attr('r', 21)
      .attr('fill', 'none')
      .attr('stroke', (d: any) => d.color || '#6366f1')
      .attr('stroke-width', 1)
      .attr('stroke-dasharray', '2,2')
      .attr('opacity', 0.6);

    // Node Name Tag labels
    const textBg = node.append('g');

    const labels = node.append('text')
      .attr('dx', 0)
      .attr('dy', 34)
      .text((d: any) => d.label)
      .attr('font-size', '10px')
      .attr('font-weight', 'bold')
      .attr('fill', theme === 'dark' ? '#f1f5f9' : '#1e293b')
      .attr('text-anchor', 'middle')
      .attr('class', 'font-sans select-none tracking-tight');

    // Tick layout loop updates
    simulation.on('tick', () => {
      linkLine
        .attr('x1', (d: any) => (d.source as any).x)
        .attr('y1', (d: any) => (d.source as any).y)
        .attr('x2', (d: any) => (d.target as any).x)
        .attr('y2', (d: any) => (d.target as any).y);

      linkText
        .attr('x', (d: any) => ((d.source as any).x + (d.target as any).x) / 2)
        .attr('y', (d: any) => ((d.source as any).y + (d.target as any).y) / 2);

      node
        .attr('transform', (d: any) => `translate(${d.x},${d.y})`);
    });

    // Zoom shortcuts
    d3.select('#btn-zoom-in').on('click', () => {
      svg.transition().duration(250).call(zoomBehavior.scaleBy as any, 1.3);
    });
    d3.select('#btn-zoom-out').on('click', () => {
      svg.transition().duration(250).call(zoomBehavior.scaleBy as any, 0.7);
    });
    d3.select('#btn-zoom-reset').on('click', () => {
      svg.transition().duration(250).call(zoomBehavior.transform as any, d3.zoomIdentity);
    });

    // Drag handlers
    function dragstarted(event: any, d: any) {
      if (!event.active) simulation.alphaTarget(0.2).restart();
      d.fx = d.x;
      d.fy = d.y;
    }

    function dragged(event: any, d: any) {
      d.fx = event.x;
      d.fy = event.y;
    }

    function dragended(event: any, d: any) {
      if (!event.active) simulation.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }

    return () => {
      simulation.stop();
    };
  }, [nodes, links, theme]);

  // Add a concept node manually
  const handleAddNode = () => {
    if (!nodeLabel.trim()) {
      showNotification('Please enter a concept name', 'error');
      return;
    }
    const newId = `node_${Date.now()}`;
    const newNode: MindNode = {
      id: newId,
      label: nodeLabel.trim(),
      description: nodeDesc.trim() || 'Custom brainstorm node',
      color: nodeColor
    };

    const updated = [...nodes, newNode];
    saveMap(updated, links);
    setNodeLabel('');
    setNodeDesc('');
    showNotification(`Concept "${newNode.label}" added!`, 'success');
  };

  // Delete a concept node double click/trigger
  const handleDeleteNode = (id: string) => {
    const deletedLabel = nodes.find(n => n.id === id)?.label;
    const updatedNodes = nodes.filter(n => n.id !== id);
    const updatedLinks = links.filter(l => {
      const srcId = typeof l.source === 'object' ? (l.source as any).id : l.source;
      const tgtId = typeof l.target === 'object' ? (l.target as any).id : l.target;
      return srcId !== id && tgtId !== id;
    });

    saveMap(updatedNodes, updatedLinks);
    showNotification(`Concept "${deletedLabel || 'Node'}" and associated links deleted.`, 'info');
  };

  // Create customized link relationships
  const handleAddLink = () => {
    if (!linkSource || !linkTarget) {
      showNotification('Please select both Source and Target concepts', 'error');
      return;
    }
    if (linkSource === linkTarget) {
      showNotification('Cannot connect a concept node to itself', 'warning');
      return;
    }

    // Check if link exists
    const exists = links.some(l => {
      const s = typeof l.source === 'object' ? (l.source as any).id : l.source;
      const t = typeof l.target === 'object' ? (l.target as any).id : l.target;
      return s === linkSource && t === linkTarget;
    });

    if (exists) {
      showNotification('These concepts are already connected', 'warning');
      return;
    }

    const newLink: MindLink = {
      source: linkSource,
      target: linkTarget,
      label: linkLabel.trim() || 'explains'
    };

    const updated = [...links, newLink];
    saveMap(nodes, updated);
    showNotification('Visual concept connection drawn!', 'success');
  };

  // AI Auto Generator using Gemini API
  const handleAIGenerateConceptMap = async () => {
    setIsGeneratingAI(true);
    showNotification(`Querying syllabus databases for "${topic}" concept frameworks...`, 'info');
    
    try {
      const prompt = `Generate a structured concept mind map for studying "${topic}" in the subject "${subject}".
      Provide exactly 6 to 9 essential concepts and links showing how they connect.
      Return a JSON object matching this schema precisely, with NO markdown backticks, no enclosing text, and no code formatting wrappers:
      {
        "nodes": [
          {"id": "c1", "label": "Main Concept", "description": "High level description", "color": "#6366f1"},
          {"id": "c2", "label": "Sub Concept", "description": "Definitions and formulas", "color": "#10b981"}
        ],
        "links": [
          {"source": "c1", "target": "c2", "label": "proves"}
        ]
      }
      Use diverse high-contrast hex codes for node colors (e.g., violet, emerald, orange, rose, blue, amber). Ensure colors look fantastic.`;

      const responseText = await generateAIResponse(prompt, {
        responseMimeType: 'application/json'
      });

      let parsed: { nodes: any[]; links: any[] } = { nodes: [], links: [] };
      if (responseText) {
        const cleanJson = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
        parsed = JSON.parse(cleanJson);
      }

      if (parsed.nodes && parsed.links && parsed.nodes.length > 0) {
        saveMap(parsed.nodes, parsed.links);
        showNotification(`AI successfully synthesized an expert concept connector map with ${parsed.nodes.length} dimensions!`, 'success');
      } else {
        throw new Error("Invalid structure returned");
      }
    } catch (e) {
      console.error(e);
      showNotification('AI Generation failed. Populating a gorgeous structured syllabus node stack.', 'warning');
      
      // Gorgeous structured mock maps to safeguard UX
      const mockNodes: MindNode[] = [
        { id: 't1', label: `${topic.replace(/_/g, ' ')} Concept Core`, description: 'Crucial starting concept', color: '#8b5cf6' },
        { id: 't2', label: 'Primary Formula', description: 'Mathematical definition equations', color: '#f43f5e' },
        { id: 't3', label: 'Alternative Explanations', description: 'Geometric/physical analogy models', color: '#0ea5e9' },
        { id: 't4', label: 'Test Proof Scenario', description: 'Derivation parameters', color: '#10b981' },
        { id: 't5', label: 'Common Pitfalls', description: 'Exam traps to avoid', color: '#f59e0b' }
      ];
      const mockLinks: MindLink[] = [
        { source: 't1', target: 't2', label: 'formulated by' },
        { source: 't1', target: 't3', label: 'visualized via' },
        { source: 't2', target: 't4', label: 'proven in' },
        { source: 't4', target: 't5', label: 'prevents' }
      ];
      saveMap(mockNodes, mockLinks);
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to clear the entire mind map canvas?')) {
      saveMap([], []);
      showNotification('Mind map canvas cleared.', 'info');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Control Editor Column */}
      <div className="lg:col-span-1 space-y-5 flex flex-col justify-between">
        
        {/* Concept node generator form */}
        <div className={cn(
          "p-4 rounded-2xl border space-y-3.5",
          theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"
        )}>
          <div className="flex items-center gap-1.5 text-xs font-black uppercase text-slate-500 dark:text-slate-400">
            <Layers size={13} className="text-indigo-500" />
            Create Concept Node
          </div>
          <div className="space-y-1.5">
            <input 
              type="text"
              placeholder="Concept Label (e.g. Entropy)"
              value={nodeLabel}
              onChange={(e) => setNodeLabel(e.target.value)}
              className="w-full p-2.5 text-xs bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-indigo-500 font-bold"
            />
            <input 
              type="text"
              placeholder="Quick Definition (optional)"
              value={nodeDesc}
              onChange={(e) => setNodeDesc(e.target.value)}
              className="w-full p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-[11px] outline-none"
            />
            <div className="flex justify-between items-center pt-1.5">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Node Color</span>
              <div className="flex gap-1.5">
                {['#6366f1', '#10b981', '#f59e0b', '#f43f5e', '#0ea5e9'].map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setNodeColor(c)}
                    className={cn(
                      "w-4 h-4 rounded-full border transition-all",
                      nodeColor === c ? "scale-125 border-slate-700 dark:border-white ring-1 ring-slate-400" : "border-transparent"
                    )}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
          </div>
          <button
            onClick={handleAddNode}
            className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1"
          >
            <Plus size={14} /> Add Concept
          </button>
        </div>

        {/* Link connector connector form */}
        <div className={cn(
          "p-4 rounded-2xl border space-y-3.5",
          theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"
        )}>
          <div className="flex items-center gap-1.5 text-xs font-black uppercase text-slate-500 dark:text-slate-400">
            <LinkIcon size={13} className="text-emerald-500" />
            Connect Concept Nodes
          </div>
          <div className="space-y-2">
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase">Source Concept</label>
              <select
                value={linkSource}
                onChange={(e) => setLinkSource(e.target.value)}
                className="w-full p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-xl text-xs outline-none cursor-pointer"
              >
                <option value="">-- Choose Node --</option>
                {nodes.map(n => (
                  <option key={n.id} value={n.id}>{n.label}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase">Relationship Label</label>
              <input 
                type="text"
                value={linkLabel}
                onChange={(e) => setLinkLabel(e.target.value)}
                placeholder="e.g. triggers, defines, proves"
                className="w-full p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-xl text-xs outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase">Target Concept</label>
              <select
                value={linkTarget}
                onChange={(e) => setLinkTarget(e.target.value)}
                className="w-full p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-xl text-xs outline-none cursor-pointer"
              >
                <option value="">-- Choose Node --</option>
                {nodes.map(n => (
                  <option key={n.id} value={n.id}>{n.label}</option>
                ))}
              </select>
            </div>
          </div>
          <button
            onClick={handleAddLink}
            className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1"
          >
            <LinkIcon size={13} /> Connect Nodes
          </button>
        </div>

        {/* Global Toolbar items */}
        <div className="flex gap-2">
          <button
            onClick={loadDefaultSyllabusMap}
            className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1"
            title="Reset to Course syllabus standard tree"
          >
            <RefreshCw size={13} /> Reset Map
          </button>
          <button
            onClick={handleClearAll}
            className="py-2 px-3 bg-red-100 dark:bg-red-950/40 text-red-600 dark:text-red-400 rounded-xl text-xs font-bold transition-colors"
            title="Clear canvas"
          >
            <Trash2 size={13} />
          </button>
        </div>
      </div>

      {/* Main Graph Canvas Area */}
      <div className="lg:col-span-3 flex flex-col space-y-4">
        {/* Title area and AI synthesis trigger */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-0.5">
            <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 uppercase tracking-wide">
              Concept Mind Map Workspace
            </h4>
            <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-normal">
              Active Chapter: <strong className="capitalize text-indigo-500">{topic.replace(/_/g, ' ')}</strong> ({subject}). Double click nodes to delete.
            </p>
          </div>
          
          <button
            onClick={handleAIGenerateConceptMap}
            disabled={isGeneratingAI}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-full text-xs font-bold shadow-md shadow-indigo-150 dark:shadow-none flex items-center gap-1.5 transition-all"
          >
            <Sparkles className={cn("w-3.5 h-3.5", isGeneratingAI && "animate-spin")} />
            {isGeneratingAI ? 'Synthesizing Concept map...' : 'AI Generate Concept Map'}
          </button>
        </div>

        {/* The SVG Mindmap stage container */}
        <div className="relative w-full h-[440px] rounded-3xl border border-slate-150 dark:border-slate-800 overflow-hidden bg-slate-950 shadow-inner">
          <svg ref={svgRef} className="w-full h-full" />
          
          {/* Legend indicator */}
          <div className="absolute bottom-4 left-4 bg-slate-900/80 backdrop-blur-xs border border-slate-800 px-3 py-2 rounded-xl flex gap-3 text-[10px] font-bold text-slate-400 select-none">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-indigo-500" /> Root / Core
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Foundational
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Applications
            </div>
          </div>

          {/* Canvas manipulation controls (zoom/reset) */}
          <div className="absolute top-4 right-4 flex flex-col gap-1">
            <button
              id="btn-zoom-in"
              className="p-2 bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg shadow-sm transition-all hover:scale-105 active:scale-95"
              title="Zoom In"
            >
              <ZoomIn size={14} />
            </button>
            <button
              id="btn-zoom-out"
              className="p-2 bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg shadow-sm transition-all hover:scale-105 active:scale-95"
              title="Zoom Out"
            >
              <ZoomOut size={14} />
            </button>
            <button
              id="btn-zoom-reset"
              className="p-2 bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg shadow-sm transition-all hover:scale-105 active:scale-95"
              title="Reset View"
            >
              <Maximize2 size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
