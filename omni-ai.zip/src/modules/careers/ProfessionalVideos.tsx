import React, { useState } from 'react';
import { 
  professionalVideos, ProfessionalVideo 
} from './careerDatabase';
import { 
  Play, Video, BookOpen, Clock, Award, CheckCircle2, AlertCircle, Info, Sparkles, User, Pause, RotateCcw, Volume2, VolumeX, FastForward, HelpCircle, Flame
} from 'lucide-react';

export const ProfessionalVideos: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [activeVideo, setActiveVideo] = useState<ProfessionalVideo>(professionalVideos[0]);
  
  // Custom interactive video player simulation state
  const [isPlaying, setIsPlaying] = useState(false);
  const [playProgress, setPlayProgress] = useState(35); // Initial simulated percentage
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [activeSubtitle, setActiveSubtitle] = useState<string>("Click 'Simulate Vlog Lecture' to play with interactive text transcripts!");

  // Quiz state
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [scoreEarned, setScoreEarned] = useState(false);

  // Sync subtitle selection
  const handleJumpToSubtitle = (time: string, text: string) => {
    setActiveSubtitle(`[Time: ${time}] - "${text}"`);
    setIsPlaying(true);
    // Move slider arbitrarily matching the timestamps
    if (time.includes('0:')) setPlayProgress(20);
    else if (time.includes('1:')) setPlayProgress(55);
    else if (time.includes('2:')) setPlayProgress(85);
  };

  const handleSelectAnswer = (idx: number) => {
    if (quizSubmitted) return;
    setSelectedAnswer(idx);
  };

  const submitQuiz = () => {
    if (selectedAnswer === null) return;
    setQuizSubmitted(true);
    if (selectedAnswer === activeVideo.quiz?.correctAnswerIdx) {
      setScoreEarned(true);
    }
  };

  const resetQuiz = () => {
    setSelectedAnswer(null);
    setQuizSubmitted(false);
    setScoreEarned(false);
  };

  const handleVideoSelect = (video: ProfessionalVideo) => {
    setActiveVideo(video);
    resetQuiz();
    setIsPlaying(false);
    setPlayProgress(10);
    setActiveSubtitle("Let's watch this dynamic professional vlog! Click play to begin.");
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <div className="space-y-6">
      
      {/* Visual active video player container */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main active video player */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
            
            {/* Embedded player area with custom simulated dashboard overlay */}
            <div className="aspect-video w-full bg-slate-950 relative group">
              {isPlaying ? (
                <div className="absolute inset-0 bg-slate-950 flex flex-col items-center justify-center p-6 text-center transition-all">
                  <div className="w-16 h-16 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin mb-4" />
                  <span className="text-xs text-indigo-400 font-mono animate-pulse">Streaming {playbackSpeed}x Speed Audio Feed...</span>
                  <p className="text-sm font-bold text-slate-100 max-w-md mt-2">
                    {activeVideo.speaker} is currently demonstrating the real-world utility of high school equations.
                  </p>
                  
                  {/* Scrolling simulated live caption banner */}
                  <div className="absolute bottom-16 left-6 right-6 bg-slate-900/95 border border-slate-800 p-3 rounded-xl">
                    <span className="text-[9px] font-mono text-indigo-400 uppercase tracking-widest block mb-0.5">Live Captions</span>
                    <p className="text-xs text-slate-200 italic">
                      {activeSubtitle}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent flex flex-col justify-between p-6">
                  <span className="self-end bg-indigo-950/80 border border-indigo-500/30 px-2.5 py-1 rounded-xl text-[10px] text-indigo-400 font-mono flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 animate-pulse" />
                    Interactive Vlog Mode Enabled
                  </span>

                  <div className="space-y-2 text-left self-start mt-12">
                    <h4 className="text-xl font-extrabold text-white tracking-tight leading-tight">
                      {activeVideo.title}
                    </h4>
                    <p className="text-xs text-slate-400 max-w-lg">
                      Curated 2-3 minute clinical/engineering simulation demonstrating {activeVideo.conceptsTaught.slice(0, 3).join(', ')}.
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setIsPlaying(true);
                      setActiveSubtitle(activeVideo.transcript[0]?.text || "Streaming beginning...");
                    }}
                    className="self-center bg-indigo-500 hover:bg-indigo-400 text-white p-5 rounded-full shadow-lg transition transform hover:scale-105"
                  >
                    <Play className="w-6 h-6 fill-white ml-0.5" />
                  </button>

                  <div />
                </div>
              )}

              {/* Custom Player Controls toolbar */}
              <div className="absolute bottom-0 left-0 right-0 bg-slate-900/90 border-t border-slate-800/80 p-3 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="text-slate-300 hover:text-white transition"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => {
                      setIsPlaying(true);
                      setPlayProgress(0);
                    }}
                    className="text-slate-400 hover:text-slate-200 transition"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>

                {/* Simulated scrubber bar */}
                <div className="flex-1 flex items-center gap-2">
                  <span className="text-[9px] font-mono text-slate-500">0:00</span>
                  <div className="flex-1 h-1.5 bg-slate-850 rounded-full overflow-hidden relative cursor-pointer">
                    <div 
                      className="absolute left-0 top-0 bottom-0 bg-indigo-500 rounded-full" 
                      style={{ width: `${playProgress}%` }}
                    />
                  </div>
                  <span className="text-[9px] font-mono text-slate-500">{activeVideo.duration}</span>
                </div>

                {/* Volume, Speed controls */}
                <div className="flex items-center gap-3">
                  <button onClick={toggleMute} className="text-slate-400 hover:text-slate-200 transition">
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>

                  <select
                    value={playbackSpeed}
                    onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                    className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 text-[10px] font-mono text-slate-400 focus:outline-none"
                  >
                    <option value="0.5">0.5x</option>
                    <option value="1">1.0x</option>
                    <option value="1.5">1.5x</option>
                    <option value="2">2.0x</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Video description and details */}
            <div className="p-6 space-y-5">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold text-sky-400 bg-sky-950/40 border border-sky-900/60 px-2 py-0.5 rounded uppercase">
                    Core Engineering Vlog
                  </span>
                  <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {activeVideo.duration} mins duration
                  </span>
                </div>
                <h3 className="text-2xl font-extrabold text-white tracking-tight">{activeVideo.title}</h3>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <User className="w-4 h-4 text-sky-400" />
                  <span className="font-extrabold text-slate-200">{activeVideo.speaker}</span>
                  <span>•</span>
                  <span className="font-medium text-slate-400">{activeVideo.role}</span>
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed font-medium">
                {activeVideo.description}
              </p>

              {/* Concepts taught */}
              <div className="space-y-2 border-t border-slate-800/60 pt-4">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Key Concepts Covered</span>
                <div className="flex flex-wrap gap-2">
                  {activeVideo.conceptsTaught.map((concept, idx) => (
                    <span key={idx} className="bg-slate-950 border border-slate-800 text-[10px] text-indigo-400 font-mono px-2.5 py-1 rounded-xl font-bold">
                      # {concept}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Comprehension check quiz for requirement validation */}
          {activeVideo.quiz && (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest block">Active Comprehension Check</span>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <HelpCircle className="w-4 h-4 text-emerald-400" />
                    Instantly Check Your Understanding (+50 XP)
                  </h4>
                </div>
                {quizSubmitted && (
                  <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded ${
                    scoreEarned ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-900' : 'bg-red-950/40 text-red-400 border border-red-900'
                  }`}>
                    {scoreEarned ? 'Correct! +50 XP' : 'Try Again'}
                  </span>
                )}
              </div>

              <div className="space-y-3">
                <p className="text-xs font-bold text-slate-200 leading-relaxed">
                  {activeVideo.quiz.question}
                </p>

                <div className="space-y-2">
                  {activeVideo.quiz.options.map((option, idx) => {
                    const isSelected = selectedAnswer === idx;
                    const isCorrect = idx === activeVideo.quiz?.correctAnswerIdx;
                    
                    let cardStyle = "bg-slate-950 border-slate-850 text-slate-300 hover:border-slate-700";
                    if (isSelected) cardStyle = "bg-indigo-950/30 border-indigo-500 text-indigo-200";
                    if (quizSubmitted) {
                      if (isCorrect) cardStyle = "bg-emerald-950/40 border-emerald-500 text-emerald-200";
                      else if (isSelected) cardStyle = "bg-red-950/40 border-red-500 text-red-300";
                    }

                    return (
                      <button
                        key={idx}
                        onClick={() => handleSelectAnswer(idx)}
                        className={`w-full text-left p-3.5 rounded-xl border text-xs font-medium transition flex items-start gap-2.5 ${cardStyle}`}
                      >
                        <span className="w-4 h-4 rounded-full border border-slate-700 flex items-center justify-center font-bold text-[8px] mt-0.5 font-mono">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="leading-snug">{option}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  {quizSubmitted ? (
                    <button
                      onClick={resetQuiz}
                      className="bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-4 py-2 rounded-xl text-xs font-bold transition"
                    >
                      Reset Question
                    </button>
                  ) : (
                    <button
                      onClick={submitQuiz}
                      disabled={selectedAnswer === null}
                      className="bg-emerald-500 hover:bg-emerald-400 text-white font-bold px-5 py-2 rounded-xl text-xs transition disabled:opacity-50"
                    >
                      Submit Answer
                    </button>
                  )}
                </div>

                {quizSubmitted && (
                  <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850 text-[11px] leading-relaxed text-slate-400">
                    <span className="font-bold text-slate-300 block mb-1">Analytical Explanation:</span>
                    {activeVideo.quiz.explanation}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Professional catalog sidebar */}
        <div className="space-y-4">
          
          {/* Dynamic Interactive Transcript Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
            <div className="space-y-1">
              <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-wider block">Interactive Transcript</span>
              <h4 className="text-sm font-bold text-white">Click transcript to navigate video</h4>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 bg-slate-950/40 p-3 rounded-2xl border border-slate-850">
              {activeVideo.transcript.map((line, idx) => (
                <div
                  key={idx}
                  onClick={() => handleJumpToSubtitle(line.time, line.text)}
                  className="p-2 rounded-lg hover:bg-slate-900/60 cursor-pointer transition text-[11px] flex items-start gap-2.5 leading-snug"
                >
                  <span className="font-mono font-bold text-indigo-400 bg-indigo-950/40 border border-indigo-900/40 px-1 py-0.2 rounded shrink-0">
                    {line.time}
                  </span>
                  <span className="text-slate-300">{line.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Video playlist selection card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
            <div className="space-y-1">
              <span className="text-xs font-mono text-sky-400 uppercase tracking-wider block">Professional Playlist</span>
              <h4 className="text-sm font-bold text-white">Select an Industry Expert</h4>
            </div>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {professionalVideos.map((video) => {
                const active = activeVideo.id === video.id;
                return (
                  <div
                    key={video.id}
                    onClick={() => handleVideoSelect(video)}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-start gap-3 ${
                      active
                        ? 'bg-indigo-950/20 border-indigo-500 shadow-md shadow-indigo-500/5'
                        : 'bg-slate-950 border-slate-950 hover:border-slate-800'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-850 flex items-center justify-center text-indigo-400 shrink-0">
                      <Play className="w-4 h-4 fill-indigo-400 text-indigo-400" />
                    </div>
                    <div className="space-y-0.5 overflow-hidden">
                      <h5 className="text-xs font-bold text-white truncate">{video.title}</h5>
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-medium">
                        <span className="truncate max-w-[100px]">{video.speaker}</span>
                        <span>•</span>
                        <span>{video.duration}m</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Note box */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-850 text-slate-400 text-[11px] leading-relaxed flex gap-2">
              <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
              <span>
                These videos show how equations studied in class scale directly to active cryogenic systems, structural medicine folding, and grid inverter calibrations.
              </span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
