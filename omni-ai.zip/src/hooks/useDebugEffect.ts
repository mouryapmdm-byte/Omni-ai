import { useEffect, useRef } from 'react';

export interface DebugEffectOptions {
  componentName?: string;
  maxRunThreshold?: number;
  logDependencyDiff?: boolean;
  onLoopDetected?: (count: number, details: { currentDeps: any[]; prevDeps: any[] }) => void;
}

/**
 * Enhanced useEffect that logs executions, diffs dependencies across render cycles,
 * and actively protects against "Maximum update depth exceeded" / infinite loops.
 */
export function useDebugEffect(
  effect: () => void | (() => void),
  deps?: any[],
  optionsOrName?: string | DebugEffectOptions
) {
  const options: DebugEffectOptions =
    typeof optionsOrName === 'string'
      ? { componentName: optionsOrName }
      : optionsOrName || {};

  const {
    componentName = 'Component',
    maxRunThreshold = 100,
    logDependencyDiff = true,
    onLoopDetected
  } = options;

  const prevDepsRef = useRef<any[] | undefined>(deps);
  const runCountRef = useRef<number>(0);
  const loopAlertedRef = useRef<boolean>(false);

  useEffect(() => {
    runCountRef.current++;
    const runCount = runCountRef.current;

    // Rich styled diagnostic logging in browser console
    if (runCount <= 10 || runCount % 10 === 0) {
      console.log(
        `%c[useDebugEffect] ${componentName} — Run #${runCount}`,
        'background: #3b82f6; color: white; padding: 2px 6px; border-radius: 4px; font-weight: bold;'
      );
    }

    // Active infinite loop threshold interceptor
    if (runCount > maxRunThreshold && !loopAlertedRef.current) {
      loopAlertedRef.current = true;
      console.error(
        `%c[useDebugEffect] ⚠️ Infinite Loop Detected! Effect in <${componentName}> ran ${runCount} times without stabilizing.`,
        'background: #ef4444; color: white; padding: 6px 10px; border-radius: 4px; font-weight: bold; font-size: 13px;'
      );
      console.warn('Component Name:', componentName);
      console.warn('Current Dependencies:', deps);
      console.warn('Previous Dependencies:', prevDepsRef.current);
      console.trace('Effect execution stack trace');

      if (onLoopDetected) {
        onLoopDetected(runCount, {
          currentDeps: deps || [],
          prevDeps: prevDepsRef.current || []
        });
      }
    }

    // Dependency diff analysis
    if (deps && prevDepsRef.current && logDependencyDiff) {
      const changedDeps = deps.map((dep, index) => {
        const prevDep = prevDepsRef.current![index];
        const changed = !Object.is(dep, prevDep);
        return { index, prevDep, dep, changed };
      }).filter(d => d.changed);

      if (changedDeps.length > 0 && runCount <= 20) {
        console.groupCollapsed(
          `%c[useDebugEffect] ${componentName} — ${changedDeps.length} dep(s) changed on Run #${runCount}`,
          'color: #f59e0b; font-weight: bold;'
        );
        console.table(
          deps.map((dep, index) => ({
            Index: index,
            Previous: prevDepsRef.current![index],
            Current: dep,
            Changed: !Object.is(dep, prevDepsRef.current![index]) ? '🔄 YES' : '✅ Stable',
            Type: typeof dep
          }))
        );
        console.groupEnd();
      }
    }

    prevDepsRef.current = deps;

    // Execute the effect safely
    const cleanup = effect();

    return () => {
      if (cleanup && typeof cleanup === 'function') {
        cleanup();
      }
    };
  }, deps);

  // Reset count on unmount
  useEffect(() => {
    return () => {
      runCountRef.current = 0;
      loopAlertedRef.current = false;
    };
  }, []);
}
