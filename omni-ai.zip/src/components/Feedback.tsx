import React, { useState } from 'react';
import { MessageSquare, Star, Send, CheckCircle2, AlertCircle, X, Loader2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { db, auth } from '@/src/lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

interface FeedbackProps {
  theme: 'light' | 'dark';
  onClose: () => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const Feedback: React.FC<FeedbackProps> = ({ theme, onClose, showNotification }) => {
  const [rating, setRating] = useState<number>(0);
  const [hoveredRating, setHoveredRating] = useState<number>(0);
  const [category, setCategory] = useState<string>('general');
  const [message, setMessage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const categories = [
    { id: 'general', label: 'General Feedback', icon: <MessageSquare size={14} /> },
    { id: 'bug', label: 'Bug Report', icon: <AlertCircle size={14} /> },
    { id: 'feature', label: 'Feature Request', icon: <Star size={14} /> },
    { id: 'tutor', label: 'AI Tutor Accuracy', icon: <CheckCircle2 size={14} /> }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rating || !message.trim()) return;

    setIsSubmitting(true);
    try {
      const user = auth.currentUser;
      await addDoc(collection(db, 'feedback'), {
        userId: user?.uid || 'anonymous',
        userEmail: user?.email || 'anonymous',
        rating,
        category,
        message: message.trim(),
        createdAt: serverTimestamp(),
        status: 'new'
      });

      setIsSubmitted(true);
      showNotification?.("Thank you for your feedback!", "success");
      setTimeout(() => onClose(), 2000);
    } catch (err: any) {
      console.error("Error submitting feedback:", err);
      showNotification?.("Failed to submit feedback. Please try again.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center space-y-6 animate-in fade-in zoom-in-95 duration-500">
        <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center text-emerald-500 animate-bounce">
          <CheckCircle2 size={40} />
        </div>
        <div className="space-y-2">
          <h3 className="text-2xl font-black tracking-tight">Feedback Received!</h3>
          <p className="text-sm text-slate-500 font-medium max-w-xs mx-auto">
            Your insights help us build a better learning experience. We appreciate your time!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-hidden animate-in fade-in duration-300",
      theme === 'dark' ? "bg-slate-950 text-slate-100" : "bg-white text-slate-800"
    )}>
      {/* Header */}
      <div className={cn(
        "px-8 py-6 border-b flex items-center justify-between shrink-0",
        theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <MessageSquare size={24} className="text-white" />
          </div>
          <div>
            <h2 className="text-xl font-black tracking-tight">Share Your Thoughts</h2>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">
              Help us improve Omni AI for everyone
            </p>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="p-2 rounded-xl hover:bg-slate-500/20 text-slate-400 transition-colors"
        >
          <X size={24} />
        </button>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
        {/* Rating */}
        <div className="space-y-4">
          <label className="text-xs font-black uppercase tracking-widest text-slate-500">Overall Rating</label>
          <div className="flex items-center gap-3">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                onClick={() => setRating(star)}
                className={cn(
                  "p-2 rounded-xl transition-all duration-200 active:scale-90",
                  (hoveredRating || rating) >= star 
                    ? "text-amber-400 scale-110" 
                    : "text-slate-300 dark:text-slate-700"
                )}
              >
                <Star size={32} fill={(hoveredRating || rating) >= star ? "currentColor" : "transparent"} />
              </button>
            ))}
            <span className="ml-4 text-sm font-black text-slate-400 uppercase tracking-tighter">
              {rating ? `${rating} / 5 Stars` : 'Select a rating'}
            </span>
          </div>
        </div>

        {/* Categories */}
        <div className="space-y-4">
          <label className="text-xs font-black uppercase tracking-widest text-slate-500">What are you sharing?</label>
          <div className="grid grid-cols-2 gap-3">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategory(cat.id)}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-2xl border text-sm font-bold transition-all",
                  category === cat.id
                    ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20"
                    : theme === 'dark' 
                      ? "bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700" 
                      : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
                )}
              >
                <span className={cn(category === cat.id ? "text-white" : "text-indigo-500")}>
                  {cat.icon}
                </span>
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Message */}
        <div className="space-y-4">
          <label className="text-xs font-black uppercase tracking-widest text-slate-500">Your Message</label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Tell us what's on your mind... be as specific as possible!"
            className={cn(
              "w-full h-40 px-5 py-4 rounded-3xl border text-sm font-medium transition-all resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500/50",
              theme === 'dark' 
                ? "bg-slate-900 border-slate-800 text-slate-100 placeholder:text-slate-600" 
                : "bg-slate-50 border-slate-200 text-slate-800 placeholder:text-slate-400"
            )}
            required
          />
        </div>

        {/* Submit */}
        <div className="pt-4">
          <button
            type="submit"
            disabled={isSubmitting || !rating || !message.trim()}
            className={cn(
              "w-full py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3",
              isSubmitting || !rating || !message.trim()
                ? "bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-xl shadow-indigo-500/20 active:scale-[0.98]"
            )}
          >
            {isSubmitting ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <Send size={16} />
                Send Feedback
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
