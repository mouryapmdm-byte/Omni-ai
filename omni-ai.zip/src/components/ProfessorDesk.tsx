import React, { useState, useEffect, useRef, useMemo } from 'react';
import * as THREE from 'three';
import { 
  Laptop, 
  ExternalLink, 
  Maximize2, 
  BookOpen, 
  Sparkles, 
  HelpCircle, 
  FileText, 
  Layers, 
  Activity, 
  Clock, 
  ChevronRight,
  Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { avatarEngine, ProximityState, PROXIMITY_CONFIGS } from '../services/avatarAnimationEngine';

export interface ProfessorDeskProps {
  onOpenLaptopView?: () => void;
  onFocusDeskCamera?: () => void;
  onQuickPreview?: () => void;
  isLaptopOpen?: boolean;
  topicTitle?: string;
  isTypingLive?: boolean;
  isSpeaking?: boolean;
  currentLessonNotes?: string;
  proximityState?: ProximityState;
  showHud?: boolean;
}

// Procedural wood grain canvas texture cache
let cachedWoodTexture: THREE.CanvasTexture | null = null;
export function getProceduralWoodTexture(): THREE.CanvasTexture {
  if (cachedWoodTexture) return cachedWoodTexture;
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Warm rich oak base
  ctx.fillStyle = '#6d4c41';
  ctx.fillRect(0, 0, 512, 512);

  // Grain lines & subtle wear marks
  for (let i = 0; i < 600; i++) {
    const y = Math.random() * 512;
    const thickness = Math.random() * 2.5 + 0.5;
    const alpha = Math.random() * 0.18 + 0.04;
    ctx.strokeStyle = `rgba(46, 26, 17, ${alpha})`;
    ctx.lineWidth = thickness;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(
      150, y + (Math.random() - 0.5) * 15,
      350, y + (Math.random() - 0.5) * 20,
      512, y + (Math.random() - 0.5) * 15
    );
    ctx.stroke();
  }

  // Soft polish sheen gradient
  const sheen = ctx.createLinearGradient(0, 0, 512, 512);
  sheen.addColorStop(0, 'rgba(255, 245, 230, 0.08)');
  sheen.addColorStop(0.5, 'rgba(0, 0, 0, 0.05)');
  sheen.addColorStop(1, 'rgba(255, 245, 230, 0.08)');
  ctx.fillStyle = sheen;
  ctx.fillRect(0, 0, 512, 512);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(2, 2);
  cachedWoodTexture = texture;
  return texture;
}

// Procedural Laptop Screen Display Canvas Texture
export function createLaptopScreenCanvas(title: string, notes: string, isLive: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 320;
  const ctx = canvas.getContext('2d')!;

  // Dark IDE / Classroom Slate Terminal background
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, 512, 320);

  // Top header bar
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, 0, 512, 38);

  // Window dots
  ctx.fillStyle = '#ef4444';
  ctx.beginPath(); ctx.arc(18, 19, 5, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#eab308';
  ctx.beginPath(); ctx.arc(34, 19, 5, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#22c55e';
  ctx.beginPath(); ctx.arc(50, 19, 5, 0, Math.PI * 2); ctx.fill();

  // App Title
  ctx.fillStyle = '#94a3b8';
  ctx.font = '600 13px ui-sans-serif, system-ui, sans-serif';
  ctx.fillText('Classroom Slate • Professor Clarity Workstation', 70, 23);

  // Live badge
  if (isLive) {
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath(); ctx.arc(460, 19, 4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 11px ui-sans-serif, system-ui, sans-serif';
    ctx.fillText('LIVE', 472, 23);
  }

  // Content Area
  ctx.fillStyle = '#38bdf8';
  ctx.font = 'bold 18px ui-sans-serif, system-ui, sans-serif';
  ctx.fillText(title || 'Foundational Calculus & Analytical Geometry', 24, 75);

  ctx.fillStyle = '#cbd5e1';
  ctx.font = '13px ui-monospace, monospace';
  const previewLines = [
    (notes ? notes.split('\n')[0].slice(0, 40) : null) || "f(x) = ∑ a_k x^k  <=>  df/dx = f'(x)",
    '----------------------------------------',
    '• Domain: All real inputs x ∈ ℝ',
    '• Derivative: Instantaneous rate of change',
    '• Stationary Points: Solve f\'(x) = 0',
    '• Integration: Area under curve ∫ f(x) dx'
  ];

  previewLines.forEach((line, idx) => {
    ctx.fillText(line, 24, 110 + idx * 24);
  });

  // Bottom Status Bar
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, 288, 512, 32);
  ctx.fillStyle = '#64748b';
  ctx.font = '11px ui-sans-serif, system-ui, sans-serif';
  ctx.fillText('Press [L] or Click Laptop to Open High-Res Slate View', 24, 308);

  const texture = new THREE.CanvasTexture(canvas);
  return texture;
}

/**
 * Procedurally builds the full 3D Professor Desk & 14-Inch Laptop Model with PBR Materials & LOD
 */
export function buildProfessorDeskThreeModel(): {
  deskGroup: THREE.Group;
  laptopGroup: THREE.Group;
  laptopLidGroup: THREE.Group;
  screenMat: THREE.MeshStandardMaterial;
  drawerGroup: THREE.Group;
  chairGroup: THREE.Group;
  lampLight: THREE.PointLight;
} {
  const deskGroup = new THREE.Group();
  deskGroup.position.set(4.2, 0, -3.85);

  const woodTexture = getProceduralWoodTexture();

  // PBR Wood Material for Desk
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x8d5b4c,
    roughness: 0.35,
    metalness: 0.08,
    map: woodTexture,
    bumpMap: woodTexture,
    bumpScale: 0.02
  });

  // Dark Mahogany / Walnut Trim Material
  const darkWoodMat = new THREE.MeshStandardMaterial({
    color: 0x3e2723,
    roughness: 0.45,
    metalness: 0.1
  });

  // Metal Brushed Chrome Legs / Accents Material
  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xcccccc,
    roughness: 0.25,
    metalness: 0.85
  });

  // Space-Gray Brushed Aluminium Material for Laptop
  const spaceGrayMat = new THREE.MeshStandardMaterial({
    color: 0x374151, // Space gray
    roughness: 0.28,
    metalness: 0.85
  });

  // Black Matte Plastic for Keyboard & Bezel
  const blackMatteMat = new THREE.MeshStandardMaterial({
    color: 0x111827,
    roughness: 0.65,
    metalness: 0.2
  });

  // Backlit Keys Material
  const keyMat = new THREE.MeshStandardMaterial({
    color: 0x1f2937,
    emissive: 0x38bdf8,
    emissiveIntensity: 0.35,
    roughness: 0.4
  });

  // --- 1. DESK TABLETOP (5 ft × 2.5 ft × 3 ft high: 1.52m × 0.76m × 0.91m) ---
  const topGeo = new THREE.BoxGeometry(1.55, 0.08, 0.85);
  const tableTop = new THREE.Mesh(topGeo, woodMat);
  tableTop.position.set(0, 0.88, 0);
  tableTop.castShadow = true;
  tableTop.receiveShadow = true;
  deskGroup.add(tableTop);

  // Beveled Edge Border Trim
  const trimGeo = new THREE.BoxGeometry(1.58, 0.03, 0.88);
  const trimMesh = new THREE.Mesh(trimGeo, darkWoodMat);
  trimMesh.position.set(0, 0.85, 0);
  deskGroup.add(trimMesh);

  // 4 Tapered Modern Desk Legs with Chrome Feet
  const legPositions: [number, number][] = [
    [-0.7, -0.35],
    [0.7, -0.35],
    [-0.7, 0.35],
    [0.7, 0.35]
  ];

  legPositions.forEach(([lx, lz]) => {
    const legGeo = new THREE.CylinderGeometry(0.035, 0.025, 0.85, 16);
    const legMesh = new THREE.Mesh(legGeo, darkWoodMat);
    legMesh.position.set(lx, 0.425, lz);
    legMesh.castShadow = true;
    deskGroup.add(legMesh);

    // Chrome Foot Pad
    const footGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.03, 16);
    const foot = new THREE.Mesh(footGeo, chromeMat);
    foot.position.set(lx, 0.015, lz);
    deskGroup.add(foot);
  });

  // --- 2. STORAGE DRAWER UNIT ---
  const drawerUnitGeo = new THREE.BoxGeometry(0.42, 0.45, 0.75);
  const drawerUnit = new THREE.Mesh(drawerUnitGeo, darkWoodMat);
  drawerUnit.position.set(0.48, 0.58, 0);
  drawerUnit.castShadow = true;
  deskGroup.add(drawerUnit);

  // Pull-Out Drawer Group
  const drawerGroup = new THREE.Group();
  drawerGroup.position.set(0.48, 0.65, 0.02);

  const drawerFaceGeo = new THREE.BoxGeometry(0.38, 0.18, 0.03);
  const drawerFace = new THREE.Mesh(drawerFaceGeo, woodMat);
  drawerFace.position.set(0, 0, 0.36);
  drawerGroup.add(drawerFace);

  const handleGeo = new THREE.BoxGeometry(0.14, 0.02, 0.03);
  const handle = new THREE.Mesh(handleGeo, chromeMat);
  handle.position.set(0, 0, 0.385);
  drawerGroup.add(handle);

  deskGroup.add(drawerGroup);

  // Modesty Privacy Panel
  const modestyGeo = new THREE.BoxGeometry(1.4, 0.45, 0.025);
  const modesty = new THREE.Mesh(modestyGeo, darkWoodMat);
  modesty.position.set(0, 0.58, -0.36);
  deskGroup.add(modesty);

  // --- 3. 14-INCH HIGH-DETAIL LAPTOP MODEL ---
  const laptopGroup = new THREE.Group();
  laptopGroup.position.set(-0.25, 0.925, 0.05);
  laptopGroup.name = 'InteractiveLaptop';

  // Base Deck
  const baseGeo = new THREE.BoxGeometry(0.36, 0.016, 0.25);
  const laptopBase = new THREE.Mesh(baseGeo, spaceGrayMat);
  laptopBase.castShadow = true;
  laptopBase.receiveShadow = true;
  laptopGroup.add(laptopBase);

  // Keyboard Recess Bed
  const keyboardBedGeo = new THREE.BoxGeometry(0.32, 0.004, 0.13);
  const keyboardBed = new THREE.Mesh(keyboardBedGeo, blackMatteMat);
  keyboardBed.position.set(0, 0.009, -0.03);
  laptopGroup.add(keyboardBed);

  // Keyboard Individual Keycaps Grid (Procedural 5 rows x 12 keys)
  const keysGroup = new THREE.Group();
  keysGroup.position.set(-0.14, 0.012, -0.08);
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 12; c++) {
      const keyGeo = new THREE.BoxGeometry(0.022, 0.004, 0.018);
      const key = new THREE.Mesh(keyGeo, keyMat);
      key.position.set(c * 0.0255, 0, r * 0.024);
      keysGroup.add(key);
    }
  }
  laptopGroup.add(keysGroup);

  // Glass Trackpad
  const trackpadGeo = new THREE.BoxGeometry(0.12, 0.002, 0.075);
  const trackpadMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.15,
    metalness: 0.4
  });
  const trackpad = new THREE.Mesh(trackpadGeo, trackpadMat);
  trackpad.position.set(0, 0.009, 0.075);
  laptopGroup.add(trackpad);

  // Laptop Hinge Mechanism
  const hingeGeo = new THREE.CylinderGeometry(0.007, 0.007, 0.28, 16);
  const hinge = new THREE.Mesh(hingeGeo, spaceGrayMat);
  hinge.rotation.z = Math.PI / 2;
  hinge.position.set(0, 0.012, -0.125);
  laptopGroup.add(hinge);

  // Laptop Screen Lid Group (Rotates along Hinge Axis 0° to 110°)
  const laptopLidGroup = new THREE.Group();
  laptopLidGroup.position.set(0, 0.012, -0.125);
  laptopLidGroup.rotation.x = -1.95; // ~110 degrees open default

  // Lid Aluminium Shell
  const lidGeo = new THREE.BoxGeometry(0.36, 0.24, 0.012);
  const lidShell = new THREE.Mesh(lidGeo, spaceGrayMat);
  lidShell.position.set(0, 0.12, -0.006);
  lidShell.castShadow = true;
  laptopLidGroup.add(lidShell);

  // Bezel Border
  const bezelGeo = new THREE.BoxGeometry(0.35, 0.23, 0.003);
  const bezel = new THREE.Mesh(bezelGeo, blackMatteMat);
  bezel.position.set(0, 0.12, 0.001);
  laptopLidGroup.add(bezel);

  // Active Glowing High-Res LCD Screen
  const screenTexture = createLaptopScreenCanvas(
    'Analytical Mathematics & Sciences',
    "f(x) = ∑ a_k x^k  <=>  df/dx = f'(x)",
    true
  );
  const screenGeo = new THREE.PlaneGeometry(0.33, 0.205);
  const screenMat = new THREE.MeshStandardMaterial({
    map: screenTexture,
    roughness: 0.1,
    metalness: 0.05,
    emissive: 0x38bdf8,
    emissiveMap: screenTexture,
    emissiveIntensity: 0.95
  });
  const screenMesh = new THREE.Mesh(screenGeo, screenMat);
  screenMesh.position.set(0, 0.12, 0.0035);
  laptopLidGroup.add(screenMesh);

  // Webcam Dot & Indicator Light
  const camGeo = new THREE.SphereGeometry(0.002, 8, 8);
  const cam = new THREE.Mesh(camGeo, blackMatteMat);
  cam.position.set(0, 0.228, 0.003);
  laptopLidGroup.add(cam);

  laptopGroup.add(laptopLidGroup);
  deskGroup.add(laptopGroup);

  // --- 4. ACCESSORIES ON DESK ---
  // Leather Desk Mat
  const padGeo = new THREE.BoxGeometry(0.85, 0.006, 0.48);
  const padMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
  const deskPad = new THREE.Mesh(padGeo, padMat);
  deskPad.position.set(-0.15, 0.922, 0.05);
  deskGroup.add(deskPad);

  // Modern Gooseneck Desk Lamp
  const lampBaseGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.02, 16);
  const lampBase = new THREE.Mesh(lampBaseGeo, chromeMat);
  lampBase.position.set(-0.55, 0.93, -0.22);
  deskGroup.add(lampBase);

  const lampPoleGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.38, 12);
  const lampPole = new THREE.Mesh(lampPoleGeo, chromeMat);
  lampPole.position.set(-0.55, 1.12, -0.22);
  deskGroup.add(lampPole);

  const lampShadeGeo = new THREE.ConeGeometry(0.09, 0.12, 16, 1, true);
  const lampShade = new THREE.Mesh(lampShadeGeo, spaceGrayMat);
  lampShade.position.set(-0.48, 1.28, -0.15);
  lampShade.rotation.x = Math.PI / 4;
  lampShade.rotation.y = -Math.PI / 4;
  deskGroup.add(lampShade);

  const lampLight = new THREE.PointLight(0xfffaed, 1.2, 3.5, 2.0);
  lampLight.position.set(-0.48, 1.25, -0.15);
  lampLight.castShadow = true;
  deskGroup.add(lampLight);

  // Ceramic Coffee/Water Mug
  const mugGeo = new THREE.CylinderGeometry(0.042, 0.038, 0.095, 16);
  const mugMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.2 });
  const mug = new THREE.Mesh(mugGeo, mugMat);
  mug.position.set(0.42, 0.965, 0.18);
  mug.castShadow = true;
  deskGroup.add(mug);

  // Stack of Textbooks / Spiral Notebooks
  const bookColors = [0x3b82f6, 0x10b981, 0x8b5cf6];
  bookColors.forEach((color, i) => {
    const bookGeo = new THREE.BoxGeometry(0.22, 0.03, 0.16);
    const bookMat = new THREE.MeshStandardMaterial({ color, roughness: 0.7 });
    const book = new THREE.Mesh(bookGeo, bookMat);
    book.position.set(0.45, 0.935 + i * 0.032, -0.2);
    book.rotation.y = (i - 1) * 0.08;
    book.castShadow = true;
    deskGroup.add(book);
  });

  // --- 5. ERGONOMIC PROFESSOR EXECUTIVE CHAIR ---
  const chairGroup = new THREE.Group();
  chairGroup.position.set(0, 0, -0.65);

  // Chair 5-Spoke Star Base
  const baseCenterGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.08, 16);
  const baseCenter = new THREE.Mesh(baseCenterGeo, chromeMat);
  baseCenter.position.set(0, 0.12, 0);
  chairGroup.add(baseCenter);

  for (let s = 0; s < 5; s++) {
    const spokeAngle = (s * Math.PI * 2) / 5;
    const spokeGeo = new THREE.BoxGeometry(0.32, 0.025, 0.04);
    const spoke = new THREE.Mesh(spokeGeo, chromeMat);
    spoke.position.set(Math.cos(spokeAngle) * 0.16, 0.1, Math.sin(spokeAngle) * 0.16);
    spoke.rotation.y = -spokeAngle;
    chairGroup.add(spoke);

    // Caster Wheel
    const wheelGeo = new THREE.SphereGeometry(0.025, 8, 8);
    const wheel = new THREE.Mesh(wheelGeo, blackMatteMat);
    wheel.position.set(Math.cos(spokeAngle) * 0.3, 0.025, Math.sin(spokeAngle) * 0.3);
    chairGroup.add(wheel);
  }

  // Hydraulic Center Cylinder
  const cylGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.35, 16);
  const cyl = new THREE.Mesh(cylGeo, chromeMat);
  cyl.position.set(0, 0.32, 0);
  chairGroup.add(cyl);

  // Mesh Fabric Material
  const meshSeatMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.9,
    metalness: 0.1
  });

  // Contoured Ergonomic Seat Cushion
  const seatGeo = new THREE.BoxGeometry(0.52, 0.08, 0.48);
  const seat = new THREE.Mesh(seatGeo, meshSeatMat);
  seat.position.set(0, 0.52, 0);
  seat.castShadow = true;
  chairGroup.add(seat);

  // High Ergonomic Lumbar Backrest
  const backGeo = new THREE.BoxGeometry(0.48, 0.65, 0.06);
  const back = new THREE.Mesh(backGeo, meshSeatMat);
  back.position.set(0, 0.88, -0.22);
  back.rotation.x = 0.12;
  back.castShadow = true;
  chairGroup.add(back);

  // 3D Armrests
  [-0.28, 0.28].forEach(ax => {
    const armGeo = new THREE.BoxGeometry(0.07, 0.03, 0.26);
    const arm = new THREE.Mesh(armGeo, blackMatteMat);
    arm.position.set(ax, 0.72, -0.02);
    chairGroup.add(arm);

    const postGeo = new THREE.CylinderGeometry(0.018, 0.018, 0.2, 8);
    const post = new THREE.Mesh(postGeo, chromeMat);
    post.position.set(ax, 0.62, -0.02);
    chairGroup.add(post);
  });

  deskGroup.add(chairGroup);

  return {
    deskGroup,
    laptopGroup,
    laptopLidGroup,
    screenMat,
    drawerGroup,
    chairGroup,
    lampLight
  };
}

/**
 * ProfessorDesk HUD Component (Interactive 2D overlay & Quick-Action dock)
 */
export const ProfessorDesk: React.FC<ProfessorDeskProps> = React.memo(({
  onOpenLaptopView,
  onFocusDeskCamera,
  onQuickPreview,
  isLaptopOpen = true,
  topicTitle = 'Foundational Calculus & Analytical Geometry',
  isTypingLive = false,
  isSpeaking = false,
  proximityState = 'ADDRESSING_CLASS',
  showHud = false
}) => {
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [showContextMenu, setShowContextMenu] = useState<boolean>(false);
  const [menuPos, setMenuPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const proxConfig = useMemo(() => PROXIMITY_CONFIGS[proximityState], [proximityState]);

  // Handle right-click context menu
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setMenuPos({ x: e.clientX, y: e.clientY });
    setShowContextMenu(true);
  };

  useEffect(() => {
    const handleGlobalClick = () => setShowContextMenu(false);
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, []);

  if (!showHud) return null;

  return (
    <>
      {/* Floating HUD Widget in Lower Right */}
      <div 
        id="professor-desk-hud-dock"
        className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2.5 pointer-events-auto select-none"
        onContextMenu={handleContextMenu}
      >
        {/* Proximity Ring State Chip */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full backdrop-blur-md shadow-lg border text-xs font-medium"
          style={{
            backgroundColor: 'rgba(15, 23, 42, 0.85)',
            borderColor: proxConfig.colorHex,
            color: '#f8fafc'
          }}
          title={proxConfig.description}
        >
          <span 
            className="w-2.5 h-2.5 rounded-full animate-ping"
            style={{ backgroundColor: proxConfig.colorHex }}
          />
          <span className="font-semibold">{proxConfig.label}</span>
          <span className="text-slate-400 text-[10px]">({proxConfig.name})</span>
        </motion.div>

        {/* Interactive Professor Desk Control Pill */}
        <motion.div
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-slate-900/90 hover:bg-slate-900 border border-sky-500/30 hover:border-sky-400 shadow-2xl backdrop-blur-xl transition-all cursor-pointer group"
          onClick={onOpenLaptopView}
        >
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 group-hover:bg-sky-500 group-hover:text-white transition-colors">
            <Laptop className="w-5 h-5" />
            {isTypingLive && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full animate-bounce ring-2 ring-slate-900" />
            )}
          </div>

          <div className="flex flex-col text-left">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-400">
                Professor Desk
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                Press [L]
              </span>
            </div>
            <span className="text-sm font-semibold text-slate-100 group-hover:text-sky-200 transition-colors">
              Classroom Slate Notes & Lab
            </span>
          </div>

          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white group-hover:translate-x-0.5 transition-all ml-1" />
        </motion.div>

        {/* Hover Tooltip Helper */}
        <AnimatePresence>
          {isHovered && (
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 5 }}
              className="px-3 py-1.5 rounded-lg bg-slate-950/95 border border-slate-700 text-slate-300 text-xs shadow-xl backdrop-blur-md max-w-xs text-right"
            >
              Click laptop to open rich notes, quizzes, formulas & links. Right-click for more actions.
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Right Click Context Menu */}
      <AnimatePresence>
        {showContextMenu && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            style={{ top: Math.min(menuPos.y, window.innerHeight - 240), left: Math.min(menuPos.x, window.innerWidth - 240) }}
            className="fixed z-50 w-56 rounded-xl bg-slate-900/95 border border-slate-700 shadow-2xl backdrop-blur-2xl py-1.5 text-xs text-slate-200 font-medium"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-3 py-2 border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Professor Desk Actions
            </div>

            <button
              onClick={() => { setShowContextMenu(false); onOpenLaptopView?.(); }}
              className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-sky-500/20 hover:text-sky-300 transition-colors text-left"
            >
              <Laptop className="w-4 h-4 text-sky-400" />
              <span>Open Laptop View (L)</span>
            </button>

            <button
              onClick={() => { setShowContextMenu(false); onFocusDeskCamera?.(); }}
              className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-sky-500/20 hover:text-sky-300 transition-colors text-left"
            >
              <Eye className="w-4 h-4 text-amber-400" />
              <span>Focus Camera on Desk</span>
            </button>

            <button
              onClick={() => { setShowContextMenu(false); onQuickPreview?.(); }}
              className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-sky-500/20 hover:text-sky-300 transition-colors text-left"
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>Quick Notes Preview</span>
            </button>

            <button
              onClick={() => { 
                setShowContextMenu(false); 
                avatarEngine.triggerGesture('stick_point_board', 3.0, 'precise', 'focused');
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-sky-500/20 hover:text-sky-300 transition-colors text-left"
            >
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Point Stick at Board</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
});
