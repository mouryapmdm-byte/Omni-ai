/**
 * useHighVolumeUpdates.ts
 * ==========================================
 * PROFESSOR CLARITY PRODUCTION PERFORMANCE ENGINE
 * 
 * Principal React Performance Architecture for High-Volume Updates:
 *  1. Technique 1: setTimeout(..., 0) for Depth Reset in Iterative Loops
 *  2. Technique 2: Batched updates (Array batching, Consolidated State, useReducer)
 *  3. Technique 3: useRef for Background Calculations with Selective useState Rendering
 *  4. Combined Workflow: useCompleteQuestionWorkflow
 *  5. Performance Telemetry: useRenderPerformance & usePerformanceMark
 */

import { useState, useRef, useCallback, useEffect, useReducer } from 'react';
import type { PracticeQuestionItem } from '../lib/practiceQuestionEngine';

// Generic Question structure or fallback for question generation
export interface PerformanceQuestion {
  id: string;
  topic: string;
  index: number;
  type?: string;
  content: string;
  timestamp: number;
}

// ---------------------------------------------------------------------------
// SECTION 2: TECHNIQUE 1 — setTimeout(..., 0) FOR DEPTH RESET
// ---------------------------------------------------------------------------

/**
 * useChunkedGeneration
 * Breaks high-volume generation loops into chunks of 20 with setTimeout(..., 0)
 * to reset React's reconciliation update depth counter back to 0.
 */
export function useChunkedGeneration<T = PerformanceQuestion>(
  createItemFn: (topic: string, index: number) => T
) {
  const [items, setItems] = useState<T[]>([]);
  const [progress, setProgress] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);

  const generate = useCallback((topic: string, total: number) => {
    setIsGenerating(true);
    setItems([]);
    setProgress(0);

    const CHUNK_SIZE = 20;
    let processed = 0;

    const processChunk = () => {
      const end = Math.min(processed + CHUNK_SIZE, total);
      const newItems: T[] = [];

      for (let i = processed; i < end; i++) {
        newItems.push(createItemFn(topic, i));
      }

      // Single state update per chunk
      setItems(prev => [...prev, ...newItems]);
      setProgress((end / total) * 100);

      processed = end;

      if (processed < total) {
        // Reset depth — safe for next chunk
        setTimeout(processChunk, 0);
      } else {
        setIsGenerating(false);
      }
    };

    processChunk();
  }, [createItemFn]);

  return { items, progress, isGenerating, generate };
}

/**
 * useCancellableChunkedGeneration
 * Production-ready cancellable chunked processing that guards against unmounts,
 * user cancellations, and infinite cascading re-renders.
 */
export function useCancellableChunkedGeneration<T = PerformanceQuestion>(
  createItemFn: (topic: string, index: number) => T
) {
  const [items, setItems] = useState<T[]>([]);
  const [progress, setProgress] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);

  const cancelRef = useRef(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const generate = useCallback((topic: string, total: number) => {
    cancelRef.current = false;
    setIsGenerating(true);
    setItems([]);
    setProgress(0);

    const CHUNK_SIZE = 20;
    let processed = 0;

    const processChunk = () => {
      if (cancelRef.current) {
        setIsGenerating(false);
        return;
      }

      const end = Math.min(processed + CHUNK_SIZE, total);
      const newItems: T[] = [];

      for (let i = processed; i < end; i++) {
        newItems.push(createItemFn(topic, i));
      }

      setItems(prev => [...prev, ...newItems]);
      setProgress((end / total) * 100);
      processed = end;

      if (processed < total) {
        timeoutRef.current = setTimeout(processChunk, 0);
      } else {
        setIsGenerating(false);
        timeoutRef.current = null;
      }
    };

    processChunk();
  }, [createItemFn]);

  const cancel = useCallback(() => {
    cancelRef.current = true;
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsGenerating(false);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cancelRef.current = true;
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  return { items, progress, isGenerating, generate, cancel };
}

// ---------------------------------------------------------------------------
// SECTION 3: TECHNIQUE 2 — BATCHED UPDATES
// ---------------------------------------------------------------------------

export interface LectureState<T = PerformanceQuestion> {
  questions: T[];
  progress: number;
  mastery: number;
  currentType: string;
  lastUpdated: number;
}

export type LectureAction<T = PerformanceQuestion> =
  | { type: 'ADD_QUESTIONS'; payload: T[] }
  | { type: 'UPDATE_PROGRESS'; payload: number }
  | { type: 'UPDATE_MASTERY'; payload: number }
  | { type: 'SET_CURRENT_TYPE'; payload: string }
  | { type: 'BATCH_UPDATE'; payload: Partial<LectureState<T>> };

export function lectureReducer<T>(
  state: LectureState<T>,
  action: LectureAction<T>
): LectureState<T> {
  switch (action.type) {
    case 'ADD_QUESTIONS':
      return { ...state, questions: [...state.questions, ...action.payload], lastUpdated: Date.now() };
    case 'UPDATE_PROGRESS':
      return { ...state, progress: action.payload, lastUpdated: Date.now() };
    case 'UPDATE_MASTERY':
      return { ...state, mastery: action.payload, lastUpdated: Date.now() };
    case 'SET_CURRENT_TYPE':
      return { ...state, currentType: action.payload, lastUpdated: Date.now() };
    case 'BATCH_UPDATE':
      return { ...state, ...action.payload, lastUpdated: Date.now() };
    default:
      return state;
  }
}

/**
 * useBatchedLectureState
 * Consolidated single-state reducer eliminating 5x redundant render triggers
 */
export function useBatchedLectureState<T = PerformanceQuestion>(initialData?: Partial<LectureState<T>>) {
  const [state, dispatch] = useReducer(lectureReducer as (state: LectureState<T>, action: LectureAction<T>) => LectureState<T>, {
    questions: [],
    progress: 0,
    mastery: 0,
    currentType: '',
    lastUpdated: 0,
    ...initialData,
  });

  const batchUpdate = useCallback((payload: Partial<LectureState<T>>) => {
    dispatch({ type: 'BATCH_UPDATE', payload });
  }, []);

  return { state, dispatch, batchUpdate };
}

// ---------------------------------------------------------------------------
// SECTION 4: TECHNIQUE 3 — useRef FOR BACKGROUND CALCULATIONS
// ---------------------------------------------------------------------------

/**
 * useLiveMastery
 * Tracks mastery across high-frequency answers without causing 100+ re-renders.
 * Synchronizes to useState only at designated milestones (e.g. every 10 answers).
 */
export function useLiveMastery(syncInterval = 10) {
  const [displayMastery, setDisplayMastery] = useState(0);

  const masteryRef = useRef({
    correct: 0,
    total: 0,
    byType: {} as Record<string, { correct: number; total: number }>,
  });

  // Called on every answer — 0 renders
  const recordAnswer = useCallback((type: string, isCorrect: boolean) => {
    const m = masteryRef.current;
    m.total += 1;
    if (isCorrect) m.correct += 1;

    if (!m.byType[type]) m.byType[type] = { correct: 0, total: 0 };
    m.byType[type].total += 1;
    if (isCorrect) m.byType[type].correct += 1;
  }, []);

  // Called at milestones — 1 render
  const syncDisplay = useCallback(() => {
    const m = masteryRef.current;
    setDisplayMastery(m.total > 0 ? (m.correct / m.total) * 100 : 0);
  }, []);

  // Public method — records and conditionally syncs
  const record = useCallback((type: string, isCorrect: boolean) => {
    recordAnswer(type, isCorrect);
    if (masteryRef.current.total % syncInterval === 0) {
      syncDisplay();
    }
  }, [recordAnswer, syncDisplay, syncInterval]);

  return { displayMastery, record, syncDisplay, masteryRef };
}

/**
 * useStreamingText
 * Handles token-by-token AI streaming without triggering React's update limit.
 * Buffers in useRef and flushes to state at a throttled 100ms interval.
 */
export function useStreamingText(debounceMs = 100) {
  const [displayText, setDisplayText] = useState('');
  const textRef = useRef('');
  const lastSyncRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const appendToken = useCallback((token: string) => {
    textRef.current += token;

    const now = Date.now();
    // Sync to display every debounceMs (not every individual token)
    if (now - lastSyncRef.current > debounceMs) {
      setDisplayText(textRef.current);
      lastSyncRef.current = now;
    } else if (!timerRef.current) {
      // Ensure trailing tokens are not dropped
      timerRef.current = setTimeout(() => {
        setDisplayText(textRef.current);
        lastSyncRef.current = Date.now();
        timerRef.current = null;
      }, debounceMs);
    }
  }, [debounceMs]);

  const finishStream = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    setDisplayText(textRef.current);
    lastSyncRef.current = Date.now();
  }, []);

  const reset = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    textRef.current = '';
    setDisplayText('');
    lastSyncRef.current = 0;
  }, []);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  return { displayText, appendToken, finishStream, reset, textRef };
}

/**
 * use3DAnimation
 * Drives 60fps Three.js transforms purely inside useRef, completely bypassing React renders.
 */
export function use3DAnimation(onFrame?: (rotation: number, zoom: number) => void) {
  const [isReady, setIsReady] = useState(false);

  const sceneRef = useRef({
    rotation: 0,
    zoom: 1,
    targetRotation: 0,
    targetZoom: 1,
    lastFrame: 0,
  });

  useEffect(() => {
    let frameId: number;

    const animate = () => {
      const scene = sceneRef.current;

      // Compute in ref — 0 renders
      scene.rotation += (scene.targetRotation - scene.rotation) * 0.1;
      scene.zoom += (scene.targetZoom - scene.zoom) * 0.1;

      // Apply directly to Three.js canvas / callback
      if (onFrame) {
        onFrame(scene.rotation, scene.zoom);
      }

      frameId = requestAnimationFrame(animate);
    };

    frameId = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(frameId);
  }, [onFrame]);

  return { sceneRef, isReady, setIsReady };
}

// ---------------------------------------------------------------------------
// SECTION 5: COMBINING ALL THREE — COMPLETE WORKFLOW
// ---------------------------------------------------------------------------

export interface WorkflowDisplayState {
  isGenerating: boolean;
  progress: number;
  questionsGenerated: number;
  currentType: string;
}

/**
 * useCompleteQuestionWorkflow
 * Master production hook synthesizing setTimeout depth reset, array batching,
 * and useRef background computation.
 */
export function useCompleteQuestionWorkflow<T = PerformanceQuestion>(
  generatorFn: (topic: string, type: string, index: number) => T
) {
  // Display state — minimal renders
  const [displayState, setDisplayState] = useState<WorkflowDisplayState>({
    isGenerating: false,
    progress: 0,
    questionsGenerated: 0,
    currentType: '',
  });

  const [questions, setQuestions] = useState<T[]>([]);

  // Background computation in ref — no renders
  const workRef = useRef({
    allQuestions: [] as T[],
    startedAt: 0,
    completedAt: 0,
    cancelled: false,
  });

  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const generate = useCallback((
    topic: string,
    questionTypes: string[],
    questionsPerType: number
  ) => {
    workRef.current.cancelled = false;
    workRef.current.startedAt = Date.now();
    workRef.current.allQuestions = [];

    // Single update at start
    setDisplayState({
      isGenerating: true,
      progress: 0,
      questionsGenerated: 0,
      currentType: questionTypes[0] || '',
    });

    const totalQuestions = questionTypes.length * questionsPerType;
    let completed = 0;

    const processType = (typeIndex: number) => {
      if (workRef.current.cancelled) {
        setDisplayState(prev => ({ ...prev, isGenerating: false }));
        return;
      }

      if (typeIndex >= questionTypes.length) {
        // Final update — everything at once
        workRef.current.completedAt = Date.now();

        setDisplayState({
          isGenerating: false,
          progress: 100,
          questionsGenerated: workRef.current.allQuestions.length,
          currentType: '',
        });

        // Push final array in one single batch update
        setQuestions([...workRef.current.allQuestions]);
        return;
      }

      const type = questionTypes[typeIndex];

      // Compute in ref — no renders
      for (let i = 0; i < questionsPerType; i++) {
        workRef.current.allQuestions.push(
          generatorFn(topic, type, i)
        );
      }

      completed += questionsPerType;

      // Single batched update per type
      setDisplayState({
        isGenerating: true,
        progress: totalQuestions > 0 ? (completed / totalQuestions) * 100 : 100,
        questionsGenerated: completed,
        currentType: type,
      });

      // Reset depth before next type with setTimeout(..., 0)
      timeoutRef.current = setTimeout(() => processType(typeIndex + 1), 0);
    };

    processType(0);
  }, [generatorFn]);

  const cancel = useCallback(() => {
    workRef.current.cancelled = true;
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setDisplayState(prev => ({ ...prev, isGenerating: false }));
  }, []);

  useEffect(() => {
    return () => {
      workRef.current.cancelled = true;
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  return { displayState, questions, generate, cancel };
}

// ---------------------------------------------------------------------------
// SECTION 8: MEASURING PERFORMANCE HOOKS
// ---------------------------------------------------------------------------

/**
 * useRenderPerformance
 * Tracks re-render velocity and alerts if render depth approaches danger zones (<16ms, >50 renders)
 */
export function useRenderPerformance(componentName: string) {
  const renderCountRef = useRef(0);
  const lastRenderRef = useRef(Date.now());
  const renderTimesRef = useRef<number[]>([]);

  useEffect(() => {
    renderCountRef.current += 1;
    const now = Date.now();
    const delta = now - lastRenderRef.current;
    lastRenderRef.current = now;
    renderTimesRef.current.push(delta);

    if (renderCountRef.current > 50 && process.env.NODE_ENV !== 'production') {
      console.warn(`[${componentName}] High render count: ${renderCountRef.current}`);
    }

    if (delta < 16 && renderCountRef.current > 10 && process.env.NODE_ENV !== 'production') {
      console.warn(`[${componentName}] Rapid re-render detected: ${delta}ms`);
    }
  });

  return {
    renderCount: renderCountRef.current,
    averageRenderTime:
      renderTimesRef.current.length > 0
        ? renderTimesRef.current.reduce((a, b) => a + b, 0) / renderTimesRef.current.length
        : 0,
  };
}

/**
 * usePerformanceMark
 * High-precision performance.mark / performance.measure wrapper
 */
export function usePerformanceMark(name: string) {
  const start = useCallback((label: string) => {
    if (typeof performance !== 'undefined' && performance.mark) {
      performance.mark(`${name}-${label}-start`);
    }
  }, [name]);

  const end = useCallback((label: string) => {
    if (typeof performance !== 'undefined' && performance.mark && performance.measure) {
      performance.mark(`${name}-${label}-end`);
      try {
        performance.measure(
          `${name}-${label}`,
          `${name}-${label}-start`,
          `${name}-${label}-end`
        );
      } catch {
        // Safe catch if start mark was purged
      }
    }
  }, [name]);

  return { start, end };
}
