import React, { useState } from 'react';
import { 
  Box, Orbit, ShieldCheck, Sparkles, Compass, 
  Atom, Flame, Layers, Maximize2, Minimize2, 
  HelpCircle, Share2, Download, Zap, Eye, BookOpen
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { NextGenStemViewer } from './NextGenStemViewer';
import { AdvancedPhysicsLab } from './AdvancedPhysicsLab';
import { MathematicalProofChecker } from './MathematicalProofChecker';

interface NextGenStemSimulationsHubProps {
  theme: 'light' | 'dark';
  initialTab?: 'spatial_3d' | 'physics_sandbox' | 'proof_checker';
  onSendToChat?: (prompt: string) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const NextGenStemSimulationsHub: React.FC<NextGenStemSimulationsHubProps> = ({
  theme,
  initialTab = 'spatial_3d',
  onSendToChat,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'spatial_3d' | 'physics_sandbox' | 'proof_checker'>(initialTab);
  const [isFullscreen, setIsFullscreen] = useState(false);

  return (
    <div className={cn(
      "w-full h-full flex flex-col transition-all",
      isFullscreen ? "fixed inset-0 z-50 p-4 bg-slate-950" : "h-[85vh] min-h-[580px]"
    )}>
      {/* Top Universal Hub Navigation Bar */}
      <div className={cn(
        "flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl border mb-3 shadow-sm",
        theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
      )}>
        {/* Hub Title & Quick Stats */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-cyan-500 to-emerald-500 text-white flex items-center justify-center shadow-md">
            <Sparkles size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm sm:text-base font-black tracking-tight">Next-Gen STEM Simulation Hub</h1>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                PRO STEM SUITE
              </span>
            </div>
            <p className="text-[11px] opacity-60 hidden sm:block">
              Interactive 3D spatial geometry, molecular lattices, multi-domain physics & deductive proof checker
            </p>
          </div>
        </div>

        {/* Primary Suite Tabs */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/60">
          <button
            onClick={() => {
              setActiveTab('spatial_3d');
              showNotification?.("Switched to 3D Spatial Geometry & Molecular Viewer", "info");
            }}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5",
              activeTab === 'spatial_3d'
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Box size={14} />
            <span>3D Spatial & Molecules</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('physics_sandbox');
              showNotification?.("Switched to Physics Sandbox: Orbits, Optics & Thermo", "info");
            }}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5",
              activeTab === 'physics_sandbox'
                ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Orbit size={14} />
            <span>Physics Engine Lab</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('proof_checker');
              showNotification?.("Switched to Deductive Mathematical Proof Checker", "info");
            }}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5",
              activeTab === 'proof_checker'
                ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <ShieldCheck size={14} />
            <span>Proof Checker (Lean 4)</span>
          </button>
        </div>

        {/* Right Tools: Fullscreen Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
            className={cn(
              "p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer",
              theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700" : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
            )}
          >
            {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
          </button>
        </div>
      </div>

      {/* Main Active Simulation Component */}
      <div className="flex-1 min-h-0 w-full overflow-hidden">
        {activeTab === 'spatial_3d' && (
          <NextGenStemViewer
            theme={theme}
            onSendToChat={onSendToChat}
            showNotification={showNotification}
          />
        )}

        {activeTab === 'physics_sandbox' && (
          <AdvancedPhysicsLab
            theme={theme}
            onSendToChat={onSendToChat}
            showNotification={showNotification}
          />
        )}

        {activeTab === 'proof_checker' && (
          <MathematicalProofChecker
            theme={theme}
            onSendToChat={onSendToChat}
            showNotification={showNotification}
          />
        )}
      </div>
    </div>
  );
};
