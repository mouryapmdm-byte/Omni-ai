import React, { useState, useRef } from 'react';
import { cn, expandAbbreviationsForSpeech } from '@/src/lib/utils';
import { FileText, Upload, Search, FileSearch, CheckCircle2, AlertCircle, Loader2, Trash2, Volume2 } from 'lucide-react';
import { generateAIResponse } from '@/src/lib/gemini';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

interface DocumentAnalyzerProps {
  onAnalyze?: (summary: string) => void;
}

export const DocumentAnalyzer: React.FC<DocumentAnalyzerProps> = ({ onAnalyze }) => {
  const [file, setFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type === 'application/pdf' || selectedFile.type === 'text/plain') {
        setFile(selectedFile);
        setError(null);
        setAnalysis(null);
      } else {
        setError('Please upload a PDF or text file.');
      }
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const content = e.target?.result;
        if (!content) return;

        let prompt = '';
        let fileData = null;

        if (file.type === 'application/pdf') {
          // For PDF, we'll send as base64 to Gemini
          const base64 = (content as string).split(',')[1];
          fileData = {
            inlineData: {
              data: base64,
              mimeType: 'application/pdf'
            }
          };
          prompt = "Please analyze this document. Provide a comprehensive summary, key takeaways, and any important formulas or concepts mentioned.";
        } else {
          // For text files
          prompt = `Please analyze the following text content:\n\n${content}\n\nProvide a comprehensive summary, key takeaways, and any important formulas or concepts mentioned.`;
        }

        const response = await generateAIResponse(prompt, { 
          systemInstruction: "You are a document analyzer.",
          contents: fileData ? { parts: [fileData, { text: prompt }] } : undefined
        });
        setAnalysis(response);
        if (onAnalyze) onAnalyze(response);
      };

      if (file.type === 'application/pdf') {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    } catch (err) {
      console.error('Analysis error:', err);
      setError('Failed to analyze the document. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleQuery = async () => {
    if (!file || !query.trim()) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const content = e.target?.result;
        if (!content) return;

        let prompt = '';
        let fileData = null;

        if (file.type === 'application/pdf') {
          const base64 = (content as string).split(',')[1];
          fileData = {
            inlineData: {
              data: base64,
              mimeType: 'application/pdf'
            }
          };
          prompt = `Based on the attached document, please answer the following question: ${query}`;
        } else {
          prompt = `Based on the following text content:\n\n${content}\n\nAnswer the following question: ${query}`;
        }

        const response = await generateAIResponse(prompt, { 
          systemInstruction: "You are a document analyzer.",
          contents: fileData ? { parts: [fileData, { text: prompt }] } : undefined
        });
        setAnalysis(response);
      };

      if (file.type === 'application/pdf') {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    } catch (err) {
      console.error('Query error:', err);
      setError('Failed to answer the question. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const reset = () => {
    setFile(null);
    setAnalysis(null);
    setError(null);
    setQuery('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 rounded-2xl overflow-hidden">
      <div className="p-6 border-b border-slate-200 dark:border-slate-800 bg-indigo-50 dark:bg-indigo-900/20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg">
            <FileSearch size={24} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Document Analysis</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Upload PDFs or text files for AI-powered insights</p>
          </div>
        </div>
        {file && (
          <button 
            onClick={reset}
            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
            title="Remove file"
          >
            <Trash2 size={20} />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {!file ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-12 flex flex-col items-center justify-center gap-4 cursor-pointer hover:border-indigo-300 dark:hover:border-indigo-500 hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-all group"
          >
            <div className="p-4 bg-slate-50 dark:bg-slate-800 text-slate-400 dark:text-slate-500 rounded-full group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/30 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-all">
              <Upload size={40} />
            </div>
            <div className="text-center">
              <p className="text-lg font-semibold text-slate-700 dark:text-slate-200">Click to upload or drag and drop</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">PDF or TXT files (max 10MB)</p>
            </div>
            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".pdf,.txt"
              className="hidden"
            />
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center gap-4 p-4 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-xl">
              <div className="p-3 bg-white dark:bg-slate-900 rounded-lg shadow-sm text-indigo-600 dark:text-indigo-400">
                <FileText size={24} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{file.name}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-green-500" />
                <span className="text-xs font-medium text-green-600 uppercase tracking-wider">Ready</span>
              </div>
            </div>

            {!analysis && !isAnalyzing && (
              <div className="flex justify-center">
                <button 
                  onClick={handleAnalyze}
                  className="px-8 py-3 bg-indigo-600 text-white rounded-full font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center gap-2"
                >
                  <Search size={18} /> Start Analysis
                </button>
              </div>
            )}

            {isAnalyzing && (
              <div className="flex flex-col items-center justify-center py-12 gap-4">
                <Loader2 size={40} className="text-indigo-600 animate-spin" />
                <p className="text-sm font-medium text-slate-600">Omni AI is reading your document...</p>
              </div>
            )}

            {error && (
              <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3 text-red-600">
                <AlertCircle size={20} />
                <p className="text-sm font-medium">{error}</p>
              </div>
            )}

            {analysis && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                <div className="p-6 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">Analysis Result</h3>
                    <button 
                      onClick={() => {
                        const utterance = new SpeechSynthesisUtterance(expandAbbreviationsForSpeech(analysis.replace(/[*#]/g, '')));
                        const rate = parseFloat(localStorage.getItem('omni_tts_rate') || '1.0');
                        utterance.rate = rate;
                        window.speechSynthesis.speak(utterance);
                      }}
                      className="p-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-200 dark:hover:bg-indigo-900/50 transition-colors"
                      title="Read analysis aloud"
                    >
                      <Volume2 size={20} />
                    </button>
                  </div>
                  <div className="prose prose-slate dark:prose-invert max-w-none markdown-body">
                    <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                      {analysis}
                    </Markdown>
                  </div>
                </div>

                <div className="space-y-3">
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-200 px-1">Ask a specific question about this document:</p>
                  <div className="flex gap-2">
                    <input 
                      type="text"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="e.g., What is the main conclusion?"
                      className="flex-1 px-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                      onKeyDown={(e) => e.key === 'Enter' && handleQuery()}
                    />
                    <button 
                      onClick={handleQuery}
                      disabled={isAnalyzing || !query.trim()}
                      className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all"
                    >
                      Ask
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
