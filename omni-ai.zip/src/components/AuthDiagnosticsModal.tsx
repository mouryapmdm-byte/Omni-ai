import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShieldCheck,
  ShieldAlert,
  Key,
  Database,
  Globe,
  RefreshCw,
  Copy,
  Check,
  LogIn,
  LogOut,
  X,
  Activity,
  AlertCircle,
  CheckCircle2,
  Info,
  Clock,
  ExternalLink,
  Cpu,
  Layers,
  Terminal
} from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { User as FirebaseUser, signInWithPopup, GoogleAuthProvider, signOut, IdTokenResult } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { cn } from '../lib/utils';

export interface AuthDiagnosticData {
  timestamp: string;
  environment: {
    hostname: string;
    origin: string;
    href: string;
    isShared: boolean;
    isPreviewEnv: boolean;
    isIframe: boolean;
    urlQueryParams: Record<string, string>;
  };
  authSession: {
    status: 'authenticated' | 'unauthenticated';
    uid: string | null;
    email: string | null;
    displayName: string | null;
    isAnonymous: boolean;
    emailVerified: boolean;
    providerIds: string[];
    creationTime: string | null;
    lastSignInTime: string | null;
  };
  tokenInfo: {
    accessible: boolean;
    tokenPreview: string;
    tokenLength: number;
    expirationTime: string | null;
    issuedAtTime: string | null;
    authTime: string | null;
    signInProvider: string | null;
    claims: Record<string, any>;
    secondsUntilExpiry: number | null;
    isExpired: boolean;
    error?: string;
  } | null;
  storageMatrix: {
    localStorageAvailable: boolean;
    indexedDbAvailable: boolean;
    firebaseAuthKeys: string[];
    hasPersistedAuthBlob: boolean;
  };
  firestorePing: {
    tested: boolean;
    connected: boolean;
    latencyMs: number | null;
    error: string | null;
  };
}

interface AuthDiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  firebaseUser: FirebaseUser | null;
  theme: 'light' | 'dark';
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const AuthDiagnosticsModal: React.FC<AuthDiagnosticsModalProps> = ({
  isOpen,
  onClose,
  firebaseUser,
  theme,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'token' | 'storage' | 'events'>('overview');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showFullToken, setShowFullToken] = useState(false);
  const [tokenResult, setTokenResult] = useState<IdTokenResult | null>(null);
  const [tokenError, setTokenError] = useState<string | null>(null);
  const [firestoreStatus, setFirestoreStatus] = useState<{
    tested: boolean;
    connected: boolean;
    latencyMs: number | null;
    error: string | null;
  }>({ tested: false, connected: false, latencyMs: null, error: null });

  const [eventLogs, setEventLogs] = useState<Array<{ timestamp: string; message: string; type: 'info' | 'success' | 'warning' | 'error' }>>([
    {
      timestamp: new Date().toLocaleTimeString(),
      message: `Auth Diagnostics View initialized. Target origin: ${window.location.origin}`,
      type: 'info'
    }
  ]);

  const addEventLog = useCallback((message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    setEventLogs(prev => [
      { timestamp: new Date().toLocaleTimeString(), message, type },
      ...prev.slice(0, 49)
    ]);
  }, []);

  // Inspect storage keys
  const inspectStorage = useCallback(() => {
    let localStorageAvailable = false;
    let indexedDbAvailable = typeof window !== 'undefined' && 'indexedDB' in window;
    const firebaseAuthKeys: string[] = [];

    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorageAvailable = true;
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && (key.startsWith('firebase:authUser') || key.startsWith('firebase:') || key.includes('firebase'))) {
            firebaseAuthKeys.push(key);
          }
        }
      }
    } catch (e) {
      localStorageAvailable = false;
    }

    return {
      localStorageAvailable,
      indexedDbAvailable,
      firebaseAuthKeys,
      hasPersistedAuthBlob: firebaseAuthKeys.length > 0
    };
  }, []);

  // Test token accessibility
  const fetchTokenDetails = useCallback(async (forceRefresh = false) => {
    if (!firebaseUser) {
      setTokenResult(null);
      setTokenError(null);
      return;
    }

    setIsRefreshing(true);
    try {
      const result = await firebaseUser.getIdTokenResult(forceRefresh);
      setTokenResult(result);
      setTokenError(null);
      addEventLog(
        `Firebase Auth Token ${forceRefresh ? 'force-refreshed' : 'retrieved'} successfully. Expiry: ${result.expirationTime}`,
        'success'
      );
    } catch (err: any) {
      const errMsg = err?.message || String(err);
      setTokenError(errMsg);
      addEventLog(`Failed to fetch Firebase Auth Token: ${errMsg}`, 'error');
    } finally {
      setIsRefreshing(false);
    }
  }, [firebaseUser, addEventLog]);

  // Test Firestore connectivity
  const runFirestorePing = useCallback(async () => {
    const start = performance.now();
    try {
      // Test read against a diagnostic doc or user doc
      const testDocRef = doc(db, 'users', firebaseUser?.uid || 'anonymous_diagnostic_probe');
      await getDoc(testDocRef);
      const latency = Math.round(performance.now() - start);
      setFirestoreStatus({
        tested: true,
        connected: true,
        latencyMs: latency,
        error: null
      });
      addEventLog(`Firestore connection check succeeded (${latency}ms)`, 'success');
    } catch (err: any) {
      const latency = Math.round(performance.now() - start);
      const isExpectedPermission = err?.message?.includes('Missing or insufficient permissions') || err?.code === 'permission-denied';
      setFirestoreStatus({
        tested: true,
        connected: isExpectedPermission ? true : false,
        latencyMs: latency,
        error: isExpectedPermission ? `Security rules active (${err.message})` : (err?.message || String(err))
      });
      addEventLog(
        isExpectedPermission ? `Firestore reachable (Security rules active): ${err.message}` : `Firestore ping error: ${err.message}`,
        isExpectedPermission ? 'info' : 'warning'
      );
    }
  }, [firebaseUser, addEventLog]);

  useEffect(() => {
    if (isOpen) {
      fetchTokenDetails(false);
      runFirestorePing();
    }
  }, [isOpen, fetchTokenDetails, runFirestorePing]);

  // Compute full diagnostics payload
  const buildDiagnosticPayload = useCallback((): AuthDiagnosticData => {
    const params: Record<string, string> = {};
    new URLSearchParams(window.location.search).forEach((val, key) => {
      params[key] = val;
    });

    const isShared = window.location.hostname.includes('ais-pre-') || params['shared'] === 'true';
    const isPreviewEnv = window.location.hostname.includes('ais-pre-');
    const isIframe = typeof window !== 'undefined' && window.self !== window.top;
    const storage = inspectStorage();

    let secondsUntilExpiry: number | null = null;
    let isExpired = false;
    if (tokenResult?.expirationTime) {
      const expTimestamp = new Date(tokenResult.expirationTime).getTime();
      secondsUntilExpiry = Math.max(0, Math.round((expTimestamp - Date.now()) / 1000));
      isExpired = secondsUntilExpiry === 0;
    }

    return {
      timestamp: new Date().toISOString(),
      environment: {
        hostname: window.location.hostname,
        origin: window.location.origin,
        href: window.location.href,
        isShared,
        isPreviewEnv,
        isIframe,
        urlQueryParams: params
      },
      authSession: {
        status: firebaseUser ? 'authenticated' : 'unauthenticated',
        uid: firebaseUser?.uid || null,
        email: firebaseUser?.email || null,
        displayName: firebaseUser?.displayName || null,
        isAnonymous: firebaseUser?.isAnonymous || false,
        emailVerified: firebaseUser?.emailVerified || false,
        providerIds: firebaseUser?.providerData?.map(p => p.providerId) || [],
        creationTime: firebaseUser?.metadata?.creationTime || null,
        lastSignInTime: firebaseUser?.metadata?.lastSignInTime || null
      },
      tokenInfo: tokenResult ? {
        accessible: true,
        tokenPreview: tokenResult.token ? `${tokenResult.token.substring(0, 14)}...${tokenResult.token.slice(-10)}` : 'N/A',
        tokenLength: tokenResult.token ? tokenResult.token.length : 0,
        expirationTime: tokenResult.expirationTime || null,
        issuedAtTime: tokenResult.issuedAtTime || null,
        authTime: tokenResult.authTime || null,
        signInProvider: tokenResult.signInProvider || null,
        claims: tokenResult.claims || {},
        secondsUntilExpiry,
        isExpired
      } : tokenError ? {
        accessible: false,
        tokenPreview: 'Error',
        tokenLength: 0,
        expirationTime: null,
        issuedAtTime: null,
        authTime: null,
        signInProvider: null,
        claims: {},
        secondsUntilExpiry: null,
        isExpired: true,
        error: tokenError
      } : null,
      storageMatrix: storage,
      firestorePing: firestoreStatus
    };
  }, [firebaseUser, tokenResult, tokenError, firestoreStatus, inspectStorage]);

  const handleCopyReport = () => {
    const data = buildDiagnosticPayload();
    const formatted = JSON.stringify(data, null, 2);
    navigator.clipboard.writeText(formatted);
    setCopied(true);
    showNotification?.("Auth diagnostic report copied to clipboard!", "success");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleGoogleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      showNotification?.("Signed in successfully!", "success");
      addEventLog("Sign-in with Google succeeded.", "success");
      fetchTokenDetails(true);
    } catch (err: any) {
      const msg = err?.message || String(err);
      showNotification?.(`Sign in failed: ${msg}`, "error");
      addEventLog(`Sign in error: ${msg}`, "error");
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      showNotification?.("Signed out successfully", "info");
      addEventLog("User signed out.", "info");
    } catch (err: any) {
      showNotification?.("Sign out failed", "error");
    }
  };

  if (!isOpen) return null;

  const diagData = buildDiagnosticPayload();
  const isSharedDomain = diagData.environment.isShared || diagData.environment.isPreviewEnv;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className={cn(
            "w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden font-sans",
            theme === 'dark'
              ? "bg-slate-900/95 border-slate-800 text-slate-100 shadow-slate-950/90"
              : "bg-white/95 border-slate-200 text-slate-900 shadow-slate-300/60"
          )}
        >
          {/* Header */}
          <div className={cn(
            "px-6 py-5 border-b flex items-center justify-between shrink-0",
            theme === 'dark' ? "border-slate-800 bg-slate-950/50" : "border-slate-100 bg-slate-50/70"
          )}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-inner">
                <Key size={20} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-black tracking-tight">Firebase Auth & Shared Session Monitor</h2>
                  <span className={cn(
                    "px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider border",
                    firebaseUser
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                  )}>
                    {firebaseUser ? "Session Active" : "No Auth Session"}
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-medium">
                  Inspect auth token persistence, origin storage isolation, and shared link connectivity.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => fetchTokenDetails(true)}
                disabled={isRefreshing}
                className={cn(
                  "p-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer",
                  theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200" : "bg-white border-slate-200 hover:bg-slate-100 text-slate-700"
                )}
                title="Force Refresh Auth Token"
              >
                <RefreshCw size={14} className={cn(isRefreshing && "animate-spin text-cyan-400")} />
                <span className="hidden sm:inline">Refresh</span>
              </button>

              <button
                onClick={handleCopyReport}
                className={cn(
                  "px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer",
                  copied
                    ? "bg-emerald-600 text-white border-emerald-500"
                    : theme === 'dark'
                      ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200"
                      : "bg-white border-slate-200 hover:bg-slate-100 text-slate-700"
                )}
                title="Copy Full Diagnostic JSON Report"
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
                <span>{copied ? 'Copied' : 'Copy JSON'}</span>
              </button>

              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-800/60 transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Shared Environment Alert Notice */}
          {isSharedDomain && !firebaseUser && (
            <div className="px-6 py-3.5 bg-amber-500/10 border-b border-amber-500/20 flex items-start gap-3 text-xs text-amber-200">
              <AlertCircle size={18} className="text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-amber-300">Shared Link Origin Notice: </span>
                You are accessing this app from a shared domain (<code className="bg-amber-950/60 px-1 py-0.5 rounded text-amber-200 font-mono text-[11px]">{diagData.environment.hostname}</code>).
                Because browser security isolates <code className="text-amber-300">localStorage</code> and <code className="text-amber-300">IndexedDB</code> per origin, auth credentials from the developer environment are not shared with this link.
                Users in shared links operate in an unauthenticated guest session unless signed in below.
              </div>
            </div>
          )}

          {/* Navigation Tabs */}
          <div className={cn(
            "px-6 pt-3 flex gap-2 border-b shrink-0 text-xs font-bold",
            theme === 'dark' ? "border-slate-800 bg-slate-900" : "border-slate-100 bg-slate-50"
          )}>
            {[
              { id: 'overview', label: 'Session & Origin Overview', icon: <Activity size={14} /> },
              { id: 'token', label: 'Firebase ID Token', icon: <Key size={14} /> },
              { id: 'storage', label: 'Storage & Persistence Matrix', icon: <Database size={14} /> },
              { id: 'events', label: 'Auth Telemetry Log', icon: <Terminal size={14} /> }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={cn(
                  "px-4 py-2.5 rounded-t-xl border-b-2 flex items-center gap-2 transition-all cursor-pointer",
                  activeTab === tab.id
                    ? "border-cyan-500 text-cyan-400 bg-cyan-500/5 font-extrabold"
                    : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/20"
                )}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* OVERVIEW TAB */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* 4 Stat Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div className={cn(
                    "p-4 rounded-2xl border flex flex-col justify-between",
                    theme === 'dark' ? "bg-slate-950/40 border-slate-800/80" : "bg-slate-50 border-slate-200/80"
                  )}>
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                      <span>Auth State</span>
                      {firebaseUser ? <CheckCircle2 size={14} className="text-emerald-400" /> : <AlertCircle size={14} className="text-amber-400" />}
                    </div>
                    <div className="my-2">
                      <div className="text-base font-black truncate text-slate-100">
                        {firebaseUser ? (firebaseUser.displayName || firebaseUser.email || 'Signed In') : 'Guest / Unauthenticated'}
                      </div>
                      <div className="text-xs text-slate-400 font-mono truncate">
                        {firebaseUser ? `UID: ${firebaseUser.uid.substring(0, 12)}...` : 'No UID registered'}
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Provider: {firebaseUser?.providerData?.[0]?.providerId || 'None'}
                    </div>
                  </div>

                  <div className={cn(
                    "p-4 rounded-2xl border flex flex-col justify-between",
                    theme === 'dark' ? "bg-slate-950/40 border-slate-800/80" : "bg-slate-50 border-slate-200/80"
                  )}>
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                      <span>Token Access</span>
                      <Key size={14} className={tokenResult ? "text-cyan-400" : "text-slate-500"} />
                    </div>
                    <div className="my-2">
                      <div className="text-base font-black text-slate-100">
                        {tokenResult ? 'Accessible & Valid' : tokenError ? 'Token Error' : 'No Token'}
                      </div>
                      <div className="text-xs text-slate-400 font-mono">
                        {tokenResult?.expirationTime ? `Exp: ${new Date(tokenResult.expirationTime).toLocaleTimeString()}` : 'N/A'}
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {diagData.tokenInfo?.secondsUntilExpiry ? `${Math.round((diagData.tokenInfo.secondsUntilExpiry) / 60)} min remaining` : 'No active JWT'}
                    </div>
                  </div>

                  <div className={cn(
                    "p-4 rounded-2xl border flex flex-col justify-between",
                    theme === 'dark' ? "bg-slate-950/40 border-slate-800/80" : "bg-slate-50 border-slate-200/80"
                  )}>
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                      <span>Storage Session</span>
                      <Database size={14} className={diagData.storageMatrix.hasPersistedAuthBlob ? "text-emerald-400" : "text-amber-400"} />
                    </div>
                    <div className="my-2">
                      <div className="text-base font-black text-slate-100">
                        {diagData.storageMatrix.hasPersistedAuthBlob ? 'Persisted In Storage' : 'Clean Storage'}
                      </div>
                      <div className="text-xs text-slate-400">
                        {diagData.storageMatrix.firebaseAuthKeys.length} Firebase keys found
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      IndexedDB: {diagData.storageMatrix.indexedDbAvailable ? 'Available' : 'Unavailable'}
                    </div>
                  </div>

                  <div className={cn(
                    "p-4 rounded-2xl border flex flex-col justify-between",
                    theme === 'dark' ? "bg-slate-950/40 border-slate-800/80" : "bg-slate-50 border-slate-200/80"
                  )}>
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                      <span>Environment</span>
                      <Globe size={14} className={isSharedDomain ? "text-amber-400" : "text-indigo-400"} />
                    </div>
                    <div className="my-2">
                      <div className="text-base font-black text-slate-100">
                        {diagData.environment.isPreviewEnv ? 'Shared Preview' : 'Dev / Standard'}
                      </div>
                      <div className="text-xs text-slate-400 truncate font-mono">
                        {diagData.environment.hostname}
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Iframe: {diagData.environment.isIframe ? 'Embedded (Nested)' : 'Top-Level Window'}
                    </div>
                  </div>
                </div>

                {/* Session Actions */}
                <div className={cn(
                  "p-5 rounded-2xl border flex flex-wrap items-center justify-between gap-4",
                  theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-200"
                )}>
                  <div>
                    <h3 className="text-sm font-bold text-slate-200">Interactive Auth Controls</h3>
                    <p className="text-xs text-slate-400">Test authentication flows, trigger login popups, or force token refresh cycles.</p>
                  </div>
                  <div className="flex items-center gap-2.5">
                    {!firebaseUser ? (
                      <button
                        onClick={handleGoogleLogin}
                        className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-indigo-500/20 cursor-pointer transition-all"
                      >
                        <LogIn size={14} />
                        Sign In with Google
                      </button>
                    ) : (
                      <button
                        onClick={handleSignOut}
                        className="px-4 py-2 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all"
                      >
                        <LogOut size={14} />
                        Sign Out
                      </button>
                    )}
                    <button
                      onClick={runFirestorePing}
                      className={cn(
                        "px-4 py-2 rounded-xl text-xs font-bold border flex items-center gap-2 cursor-pointer transition-all",
                        theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200" : "bg-white border-slate-200 hover:bg-slate-100 text-slate-700"
                      )}
                    >
                      <Database size={14} className="text-cyan-400" />
                      Ping Firestore
                    </button>
                  </div>
                </div>

                {/* Environment & Query Details */}
                <div className={cn(
                  "p-5 rounded-2xl border space-y-3 font-mono text-xs",
                  theme === 'dark' ? "bg-slate-950/40 border-slate-800 text-slate-300" : "bg-slate-50 border-slate-200 text-slate-700"
                )}>
                  <div className="font-sans font-bold text-slate-400 text-xs uppercase tracking-wider">
                    Runtime Origin & URL Parameters
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                    <div><span className="text-slate-500">Origin:</span> {diagData.environment.origin}</div>
                    <div><span className="text-slate-500">Host:</span> {diagData.environment.hostname}</div>
                    <div><span className="text-slate-500">Shared Domain Flag:</span> {diagData.environment.isShared ? 'TRUE' : 'FALSE'}</div>
                    <div><span className="text-slate-500">Iframe Sandbox:</span> {diagData.environment.isIframe ? 'YES (Cross-origin)' : 'NO (Top-Level)'}</div>
                  </div>
                  {Object.keys(diagData.environment.urlQueryParams).length > 0 && (
                    <div className="pt-2 border-t border-slate-800/50">
                      <span className="text-slate-500 font-sans">Active Query Params:</span>
                      <div className="mt-1 flex flex-wrap gap-1.5">
                        {Object.entries(diagData.environment.urlQueryParams).map(([k, v]) => (
                          <span key={k} className="px-2 py-0.5 rounded bg-slate-800/80 text-cyan-300 text-[10px] font-mono border border-slate-700">
                            {k}={v}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TOKEN TAB */}
            {activeTab === 'token' && (
              <div className="space-y-4">
                {tokenResult ? (
                  <>
                    <div className={cn(
                      "p-5 rounded-2xl border space-y-4",
                      theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-200"
                    )}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 size={16} className="text-emerald-400" />
                          <h3 className="font-bold text-sm text-slate-100">Active Firebase Auth ID Token</h3>
                        </div>
                        <span className="text-xs text-slate-400 font-mono">
                          {tokenResult.token.length} chars
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/80">
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">Issued At</span>
                          <span className="font-mono text-slate-200">{tokenResult.issuedAtTime || 'N/A'}</span>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/80">
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">Expiration Time</span>
                          <span className="font-mono text-cyan-300">{tokenResult.expirationTime || 'N/A'}</span>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/80">
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">Auth Time</span>
                          <span className="font-mono text-slate-200">{tokenResult.authTime || 'N/A'}</span>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800/80">
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">Sign-In Provider</span>
                          <span className="font-mono text-indigo-300">{tokenResult.signInProvider || 'password / google'}</span>
                        </div>
                      </div>

                      {/* Raw JWT Token Preview */}
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400 font-bold">JWT Token String:</span>
                          <button
                            onClick={() => setShowFullToken(!showFullToken)}
                            className="text-cyan-400 hover:underline cursor-pointer text-[11px]"
                          >
                            {showFullToken ? 'Show Truncated' : 'Show Full String'}
                          </button>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-slate-300 break-all border border-slate-800 select-all">
                          {showFullToken ? tokenResult.token : `${tokenResult.token.substring(0, 32)}...${tokenResult.token.slice(-32)}`}
                        </div>
                      </div>

                      {/* Claims */}
                      <div className="space-y-1.5">
                        <span className="text-slate-400 font-bold text-xs">Token Claims & Metadata:</span>
                        <pre className="p-3 rounded-xl bg-slate-950 text-emerald-400 font-mono text-[11px] overflow-x-auto border border-slate-800">
                          {JSON.stringify(tokenResult.claims, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className={cn(
                    "p-8 rounded-2xl border text-center space-y-3",
                    theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
                  )}>
                    <AlertCircle size={32} className="mx-auto text-amber-400 opacity-80" />
                    <h3 className="font-bold text-base text-slate-100">No Auth Token Available</h3>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      There is currently no active Firebase Authentication session in this environment.
                      To inspect JWT token lifecycles and claims, sign in using Google Auth.
                    </p>
                    <button
                      onClick={handleGoogleLogin}
                      className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold inline-flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20"
                    >
                      <LogIn size={14} />
                      Sign In Now
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* STORAGE TAB */}
            {activeTab === 'storage' && (
              <div className="space-y-4">
                <div className={cn(
                  "p-5 rounded-2xl border space-y-4",
                  theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-200"
                )}>
                  <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                    <Database size={16} className="text-cyan-400" />
                    Origin Storage & Session Persistence Matrix
                  </h3>
                  <p className="text-xs text-slate-400">
                    Firebase Auth relies on browser <code className="text-cyan-300">IndexedDB</code> and <code className="text-cyan-300">localStorage</code>.
                    Browsers enforce the Same-Origin Policy, which means data saved on <code className="text-slate-300">ais-dev-*</code> is completely isolated from <code className="text-slate-300">ais-pre-*</code>.
                  </p>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                      <span className="text-slate-300 font-medium">localStorage Accessibility:</span>
                      <span className={cn(
                        "font-bold font-mono px-2 py-0.5 rounded",
                        diagData.storageMatrix.localStorageAvailable ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"
                      )}>
                        {diagData.storageMatrix.localStorageAvailable ? "OPERATIONAL" : "BLOCKED / UNAVAILABLE"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                      <span className="text-slate-300 font-medium">IndexedDB Support:</span>
                      <span className={cn(
                        "font-bold font-mono px-2 py-0.5 rounded",
                        diagData.storageMatrix.indexedDbAvailable ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"
                      )}>
                        {diagData.storageMatrix.indexedDbAvailable ? "AVAILABLE" : "UNAVAILABLE"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                      <span className="text-slate-300 font-medium">Firebase Auth Storage Blobs Found:</span>
                      <span className="font-bold font-mono text-cyan-300">
                        {diagData.storageMatrix.firebaseAuthKeys.length} items
                      </span>
                    </div>
                  </div>

                  {diagData.storageMatrix.firebaseAuthKeys.length > 0 && (
                    <div className="space-y-1.5 pt-2">
                      <span className="text-xs font-bold text-slate-400">Detected Storage Keys in this Origin:</span>
                      <div className="space-y-1 max-h-36 overflow-y-auto">
                        {diagData.storageMatrix.firebaseAuthKeys.map(k => (
                          <div key={k} className="p-2 rounded bg-slate-950 text-slate-300 font-mono text-[11px] border border-slate-800/80">
                            {k}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* EVENTS TAB */}
            {activeTab === 'events' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Live Auth Telemetry Stream</h3>
                  <span className="text-[10px] text-slate-500">{eventLogs.length} events captured</span>
                </div>
                <div className="space-y-2 max-h-96 overflow-y-auto font-mono text-xs">
                  {eventLogs.map((log, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        "p-3 rounded-xl border flex items-start gap-3",
                        log.type === 'success' ? "bg-emerald-950/20 border-emerald-500/30 text-emerald-300" :
                        log.type === 'error' ? "bg-rose-950/20 border-rose-500/30 text-rose-300" :
                        log.type === 'warning' ? "bg-amber-950/20 border-amber-500/30 text-amber-300" :
                        "bg-slate-950/40 border-slate-800 text-slate-300"
                      )}
                    >
                      <span className="text-slate-500 text-[10px] shrink-0 mt-0.5">{log.timestamp}</span>
                      <div className="flex-1 break-words">{log.message}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className={cn(
            "px-6 py-4 border-t flex items-center justify-between shrink-0 text-xs",
            theme === 'dark' ? "border-slate-800 bg-slate-950/60 text-slate-400" : "border-slate-100 bg-slate-50 text-slate-600"
          )}>
            <div className="flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>Diagnostic Console Active — Call <code className="font-mono text-cyan-300">window.getAuthDiagnostics()</code> in browser console</span>
            </div>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl cursor-pointer transition"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
