import React, { useEffect, useState } from 'react';
import { Clock, AlertTriangle, Maximize2, Minimize2, ShieldAlert } from 'lucide-react';
import { cn } from '../lib/utils';

interface TimerProps {
  totalSeconds: number;
  initialSecondsRemaining?: number;
  onTimeUp: () => void;
  onTick?: (secondsRemaining: number) => void;
  isPaused?: boolean;
  enableInvigilation?: boolean;
  onTabSwitchWarning?: (switchCount: number) => void;
  isDark?: boolean;
}

export const Timer: React.FC<TimerProps> = ({
  totalSeconds,
  initialSecondsRemaining,
  onTimeUp,
  onTick,
  isPaused = false,
  enableInvigilation = true,
  onTabSwitchWarning,
  isDark = true,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(initialSecondsRemaining ?? totalSeconds);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [tabSwitches, setTabSwitches] = useState(0);

  // Countdown effect
  useEffect(() => {
    if (isPaused) return;

    if (secondsLeft <= 0) {
      onTimeUp();
      return;
    }

    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        const next = prev - 1;
        if (onTick) onTick(next);
        if (next <= 0) {
          clearInterval(interval);
          onTimeUp();
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [secondsLeft, isPaused, onTimeUp, onTick]);

  // Tab switch detection (Invigilation)
  useEffect(() => {
    if (!enableInvigilation) return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        setTabSwitches((prev) => {
          const count = prev + 1;
          if (onTabSwitchWarning) onTabSwitchWarning(count);
          return count;
        });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [enableInvigilation, onTabSwitchWarning]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const hours = Math.floor(secondsLeft / 3600);
  const minutes = Math.floor((secondsLeft % 3600) / 60);
  const seconds = secondsLeft % 60;

  const isUrgent = secondsLeft < 300; // < 5 mins
  const isWarning = secondsLeft < 600 && !isUrgent; // < 10 mins

  return (
    <div className="flex items-center gap-2 sm:gap-3">
      {/* Tab Switch Warning Badge */}
      {enableInvigilation && tabSwitches > 0 && (
        <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold animate-pulse">
          <ShieldAlert size={13} />
          <span>{tabSwitches} Warning{tabSwitches > 1 ? 's' : ''} (Tab Switch)</span>
        </div>
      )}

      {/* Main Countdown Display */}
      <div className={cn(
        "flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl border font-mono font-black text-sm sm:text-base tracking-wider transition shadow-sm",
        isUrgent
          ? "bg-rose-950/80 border-rose-500 text-rose-400 animate-pulse shadow-rose-500/20"
          : isWarning
          ? "bg-amber-950/80 border-amber-500 text-amber-400 shadow-amber-500/10"
          : isDark ? "bg-slate-900 border-slate-700 text-slate-200" : "bg-slate-100 border-slate-300 text-slate-800"
      )}>
        <Clock size={16} className={isUrgent ? "text-rose-400 animate-spin" : isWarning ? "text-amber-400" : "text-indigo-400"} />
        <span>
          {hours > 0 ? `${hours.toString().padStart(2, '0')}:` : ''}
          {minutes.toString().padStart(2, '0')}:
          {seconds.toString().padStart(2, '0')}
        </span>
      </div>

      {/* Fullscreen Toggle */}
      <button
        onClick={toggleFullscreen}
        className={cn(
          "p-2 rounded-xl border transition cursor-pointer hidden md:flex items-center justify-center",
          isDark ? "bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200 hover:bg-slate-800" : "bg-slate-100 border-slate-300 text-slate-600 hover:text-slate-800"
        )}
        title={isFullscreen ? "Exit Fullscreen" : "Enter Exam Fullscreen Mode"}
      >
        {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
      </button>
    </div>
  );
};
