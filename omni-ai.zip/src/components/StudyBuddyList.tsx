import React, { useState, useEffect } from 'react';
import { 
  Users, UserPlus, Flame, Target, MessageSquare, Calendar, 
  ShieldCheck, Sparkles, Filter, Search, CheckCircle2, 
  Zap, Clock, BookOpen, Sliders, RefreshCw, X, Award, ChevronRight, HelpCircle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { 
  StudyBuddyMatch, 
  StudentStudyProfile, 
  MatchCandidate,
  StudyTimeSlot 
} from '../modules/study-buddies/types';
import { StudyBuddyService } from '../modules/study-buddies/studyBuddyService';
import { BuddyCard } from './BuddyCard';
import { CheckInFlow } from './CheckInFlow';
import { BuddyChatModal } from './BuddyChatModal';

interface StudyBuddyListProps {
  isDark?: boolean;
  currentSubject?: string;
  onClose?: () => void;
}

export const StudyBuddyList: React.FC<StudyBuddyListProps> = ({
  isDark = true,
  currentSubject = 'Physics',
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'buddies' | 'discover' | 'group' | 'profile'>('buddies');
  const [myProfile, setMyProfile] = useState<StudentStudyProfile>(() => StudyBuddyService.getMyProfile(currentSubject));
  const [activeMatches, setActiveMatches] = useState<StudyBuddyMatch[]>([]);
  const [availableCandidates, setAvailableCandidates] = useState<MatchCandidate[]>([]);
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [checkInMatch, setCheckInMatch] = useState<StudyBuddyMatch | null>(null);
  const [chatMatch, setChatMatch] = useState<StudyBuddyMatch | null>(null);
  const [chatInitialTab, setChatInitialTab] = useState<'chat' | 'scheduler' | 'progress'>('chat');
  const [matchSuccessMsg, setMatchSuccessMsg] = useState<string | null>(null);
  const [matchErrorMsg, setMatchErrorMsg] = useState<string | null>(null);

  // Group Study Room State
  const [groupTimerRunning, setGroupTimerRunning] = useState<boolean>(false);
  const [groupSecondsLeft, setGroupSecondsLeft] = useState<number>(25 * 60);

  const loadData = () => {
    const profile = StudyBuddyService.getMyProfile(currentSubject);
    setMyProfile(profile);
    const matches = StudyBuddyService.getActiveMatches();
    setActiveMatches(matches);
    const candidates = StudyBuddyService.getAvailableBuddies(profile);
    setAvailableCandidates(candidates);
  };

  useEffect(() => {
    loadData();
  }, [currentSubject]);

  // Group Pomodoro timer tick
  useEffect(() => {
    let interval: any;
    if (groupTimerRunning && groupSecondsLeft > 0) {
      interval = setInterval(() => {
        setGroupSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (groupSecondsLeft === 0) {
      setGroupTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [groupTimerRunning, groupSecondsLeft]);

  const handleMatchPeer = (candidate: MatchCandidate) => {
    const result = StudyBuddyService.matchWithBuddy(candidate.profile, candidate.commonSubjects[0]);
    if (result.success && result.match) {
      setMatchSuccessMsg(`Connected with ${candidate.profile.alias}! You now have an accountability buddy for ${result.match.subjectFocus}.`);
      setMatchErrorMsg(null);
      loadData();
      setActiveTab('buddies');
      setTimeout(() => setMatchSuccessMsg(null), 5000);
    } else {
      setMatchErrorMsg(result.error || 'Failed to match.');
      setTimeout(() => setMatchErrorMsg(null), 5000);
    }
  };

  const handleUpdateProfile = (updated: Partial<StudentStudyProfile>) => {
    const newProf = { ...myProfile, ...updated };
    setMyProfile(newProf);
    StudyBuddyService.saveMyProfile(newProf);
    loadData();
  };

  const filteredCandidates = availableCandidates.filter((c) => {
    const matchesSubject = selectedSubjectFilter === 'all' || c.profile.subjectFocus.includes(selectedSubjectFilter);
    const matchesQuery = !searchQuery.trim() || 
      c.profile.alias.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.profile.strengths.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSubject && matchesQuery;
  });

  return (
    <div className={cn(
      "w-full rounded-2xl border shadow-xl flex flex-col min-h-[600px] overflow-hidden",
      isDark ? "bg-slate-950 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Top Banner / Header */}
      <div className="p-5 sm:p-6 border-b border-slate-800/80 bg-slate-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
            <Users size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-lg sm:text-xl font-black tracking-tight">Study Buddy Matching</h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                Mutual Accountability
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Match with peers of similar velocity & complementary strengths. Never study alone.
            </p>
          </div>
        </div>

        {/* Global Action Badges */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs font-semibold">
            <Flame size={14} className="text-amber-400" />
            <span className="text-slate-300">Streak:</span>
            <span className="text-amber-400 font-bold">{myProfile.streakDays || 3} Days</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs font-semibold">
            <Users size={14} className="text-indigo-400" />
            <span className="text-slate-300">Active:</span>
            <span className="text-indigo-300 font-bold">{activeMatches.filter(m => m.status === 'active').length} / 3 Buddies</span>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer ml-1"
            >
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Alerts */}
      {matchSuccessMsg && (
        <div className="mx-6 mt-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={16} />
            <span>{matchSuccessMsg}</span>
          </div>
          <button onClick={() => setMatchSuccessMsg(null)} className="text-emerald-400 hover:text-emerald-200">
            <X size={14} />
          </button>
        </div>
      )}

      {matchErrorMsg && (
        <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <HelpCircle size={16} />
            <span>{matchErrorMsg}</span>
          </div>
          <button onClick={() => setMatchErrorMsg(null)} className="text-rose-400 hover:text-rose-200">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="px-6 pt-3 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
        {[
          { key: 'buddies', label: `My Buddies (${activeMatches.length})`, icon: Users },
          { key: 'discover', label: 'Discover & Match', icon: UserPlus },
          { key: 'group', label: 'Group Study Room', icon: Zap },
          { key: 'profile', label: 'My Matching Preferences', icon: Sliders },
        ].map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key as typeof activeTab)}
              className={cn(
                "px-4 py-2.5 text-xs font-bold border-b-2 transition flex items-center gap-2 whitespace-nowrap cursor-pointer",
                isActive
                  ? "border-indigo-500 text-indigo-400"
                  : "border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700"
              )}
            >
              <Icon size={14} />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Main Tab Content */}
      <div className="p-5 sm:p-6 flex-1 overflow-y-auto">
        {/* TAB 1: MY ACTIVE BUDDIES */}
        {activeTab === 'buddies' && (
          <div>
            {activeMatches.length === 0 ? (
              <div className="py-14 text-center flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-3xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-3">
                  <UserPlus size={28} />
                </div>
                <h3 className="text-base font-bold text-slate-200">No Study Buddies Yet</h3>
                <p className="text-xs text-slate-400 max-w-sm mt-1 mb-5">
                  Research shows students with accountability partners study 3.4x more consistently. Match with peers now!
                </p>
                <button
                  onClick={() => setActiveTab('discover')}
                  className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/20 flex items-center gap-2 transition cursor-pointer"
                >
                  <Sparkles size={14} /> Find My Ideal Study Buddy
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-200">Active Accountability Partnerships</h3>
                    <p className="text-xs text-slate-400">Up to 3 active buddies across different STEM disciplines.</p>
                  </div>
                  {activeMatches.length < 3 && (
                    <button
                      onClick={() => setActiveTab('discover')}
                      className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <UserPlus size={13} /> Add Another Buddy ({3 - activeMatches.length} slots left)
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeMatches.map((match) => (
                    <BuddyCard
                      key={match.id}
                      match={match}
                      isDark={isDark}
                      onOpenCheckIn={(m) => setCheckInMatch(m)}
                      onOpenChat={(m) => {
                        setChatMatch(m);
                        setChatInitialTab('chat');
                      }}
                      onOpenScheduler={(m) => {
                        setChatMatch(m);
                        setChatInitialTab('scheduler');
                      }}
                      onUpdate={loadData}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: DISCOVER & MATCH PEERS */}
        {activeTab === 'discover' && (
          <div className="space-y-4">
            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
              <div className="relative w-full sm:w-72">
                <Search size={14} className="absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by alias or strength..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
                {['all', 'Physics', 'Chemistry', 'Mathematics', 'Biology'].map((subj) => (
                  <button
                    key={subj}
                    onClick={() => setSelectedSubjectFilter(subj)}
                    className={cn(
                      "px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer",
                      selectedSubjectFilter === subj
                        ? "bg-indigo-600 text-white"
                        : "bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200"
                    )}
                  >
                    {subj === 'all' ? 'All Subjects' : subj}
                  </button>
                ))}
              </div>
            </div>

            {/* Candidates Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCandidates.map((candidate) => (
                <div
                  key={candidate.profile.id}
                  className="p-5 rounded-2xl border border-slate-800 bg-slate-900/60 hover:border-slate-700 transition flex flex-col justify-between shadow-md"
                >
                  <div>
                    {/* Top candidate info */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white font-black text-base shadow-md">
                          {candidate.profile.alias.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-100">{candidate.profile.alias}</h4>
                          <p className="text-xs text-slate-400">{candidate.profile.targetExam || 'STEM Scholar'}</p>
                        </div>
                      </div>
                      <div className="px-2.5 py-1 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-black flex items-center gap-1">
                        <Zap size={12} /> {candidate.matchScore}%
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 italic line-clamp-2 mb-3 bg-slate-950/40 p-2 rounded-lg border border-slate-800/80">
                      "{candidate.profile.bio || 'Ready for collaborative study and mutual quizzes!'}"
                    </p>

                    {/* Breakdown Highlights */}
                    <div className="space-y-1.5 mb-4 text-[11px] text-slate-400">
                      <div className="flex justify-between">
                        <span>Pace Alignment:</span>
                        <span className="text-indigo-400 font-semibold">{candidate.scoreBreakdown.paceSimilarity}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Mutual Help Synergy:</span>
                        <span className="text-purple-400 font-semibold">{candidate.scoreBreakdown.complementarityScore}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Schedule Compatibility:</span>
                        <span className="text-emerald-400 font-semibold">{candidate.scoreBreakdown.scheduleOverlap}%</span>
                      </div>
                    </div>

                    {/* Strengths */}
                    <div className="mb-4">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Top Strengths</span>
                      <div className="flex flex-wrap gap-1">
                        {candidate.profile.strengths.slice(0, 3).map((st, i) => (
                          <span key={i} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-medium border border-slate-700">
                            {st}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Connect Action */}
                  <button
                    onClick={() => handleMatchPeer(candidate)}
                    className="w-full py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <UserPlus size={14} /> Connect as Study Buddy
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: GROUP STUDY ROOM */}
        {activeTab === 'group' && (
          <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-950/40 via-purple-950/30 to-slate-900 border border-indigo-500/30 flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 block mb-1">
                  Virtual Study Hall (3+ Buddies)
                </span>
                <h3 className="text-xl font-black text-slate-100">Synchronized Focus Lounge</h3>
                <p className="text-xs text-slate-300 max-w-md mt-1">
                  Host live synchronized Pomodoro sprints with all your study buddies simultaneously. Track group focus minutes!
                </p>
              </div>

              {/* Timer Box */}
              <div className="flex flex-col items-center p-4 rounded-2xl bg-slate-900/90 border border-slate-700 shadow-xl min-w-[200px]">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Pomodoro Sprint</span>
                <span className="text-3xl font-black text-indigo-400 font-mono">
                  {Math.floor(groupSecondsLeft / 60).toString().padStart(2, '0')}:
                  {(groupSecondsLeft % 60).toString().padStart(2, '0')}
                </span>
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={() => setGroupTimerRunning(!groupTimerRunning)}
                    className={cn(
                      "px-4 py-1.5 rounded-xl text-xs font-bold text-white shadow-md transition cursor-pointer",
                      groupTimerRunning ? "bg-rose-600 hover:bg-rose-500" : "bg-indigo-600 hover:bg-indigo-500"
                    )}
                  >
                    {groupTimerRunning ? 'Pause' : 'Start Focus'}
                  </button>
                  <button
                    onClick={() => {
                      setGroupTimerRunning(false);
                      setGroupSecondsLeft(25 * 60);
                    }}
                    className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition cursor-pointer"
                    title="Reset"
                  >
                    <RefreshCw size={14} />
                  </button>
                </div>
              </div>
            </div>

            {/* Active Group Room Members */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
                Current Room Peers
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/40 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white font-bold flex items-center justify-center">
                    {myProfile.alias.charAt(0)}
                  </div>
                  <div>
                    <h5 className="font-bold text-xs text-slate-200">{myProfile.alias} (You)</h5>
                    <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Focused & Ready
                    </span>
                  </div>
                </div>

                {activeMatches.map((m) => (
                  <div key={m.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-600 text-white font-bold flex items-center justify-center">
                      {(m.partnerProfile?.alias || 'P').charAt(0)}
                    </div>
                    <div>
                      <h5 className="font-bold text-xs text-slate-200">{m.partnerProfile?.alias}</h5>
                      <span className="text-[10px] text-indigo-400">
                        {m.subjectFocus} Buddy • {m.partnerProfile?.streakDays || 5}d Streak
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: MY PROFILE & PREFERENCES */}
        {activeTab === 'profile' && (
          <div className="max-w-xl mx-auto space-y-5 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Sliders size={18} className="text-indigo-400" />
                Study Profile & Matching Preferences
              </h3>
              <p className="text-xs text-slate-400">
                Customize your velocity, strengths, and schedule to find the most accurate peer matches.
              </p>
            </div>

            {/* Opt In Toggle */}
            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-xs text-slate-200">Peer Matching Opt-In</h4>
                <p className="text-[11px] text-slate-400">Allow other students to discover your anonymous profile.</p>
              </div>
              <button
                type="button"
                onClick={() => handleUpdateProfile({ isOptedIn: !myProfile.isOptedIn })}
                className={cn(
                  "w-12 h-6 rounded-full transition-colors relative cursor-pointer",
                  myProfile.isOptedIn ? "bg-indigo-600" : "bg-slate-700"
                )}
              >
                <div className={cn(
                  "w-4 h-4 rounded-full bg-white transition-transform absolute top-1",
                  myProfile.isOptedIn ? "right-1" : "left-1"
                )} />
              </button>
            </div>

            {/* Learning Velocity Slider */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-300">Learning Velocity / Pace (0-100)</label>
                <span className="text-xs font-bold text-indigo-400">{myProfile.learningVelocity} / 100</span>
              </div>
              <input
                type="range"
                min={20}
                max={100}
                value={myProfile.learningVelocity}
                onChange={(e) => handleUpdateProfile({ learningVelocity: Number(e.target.value) })}
                className="w-full accent-indigo-500 cursor-pointer"
              />
              <span className="text-[10px] text-slate-500">
                We pair you with peers whose velocity is within 20% of yours for effortless synergy.
              </span>
            </div>

            {/* Target Daily Minutes */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Daily Study Target</label>
              <select
                value={myProfile.dailyTargetMinutes}
                onChange={(e) => handleUpdateProfile({ dailyTargetMinutes: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-200 outline-none focus:border-indigo-500"
              >
                <option value={30}>30 mins / day</option>
                <option value={45}>45 mins / day</option>
                <option value={60}>60 mins / day (Recommended)</option>
                <option value={90}>90 mins / day</option>
                <option value={120}>120 mins / day</option>
              </select>
            </div>

            {/* Time Slot Preferences */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">Preferred Study Hours</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { key: 'morning', label: '🌅 Morning' },
                  { key: 'afternoon', label: '☀️ Afternoon' },
                  { key: 'evening', label: '🌆 Evening' },
                  { key: 'night', label: '🌙 Night' },
                ].map((slot) => {
                  const isSelected = myProfile.preferredTimeSlots.includes(slot.key as StudyTimeSlot);
                  return (
                    <button
                      key={slot.key}
                      type="button"
                      onClick={() => {
                        const next = isSelected
                          ? myProfile.preferredTimeSlots.filter(s => s !== slot.key)
                          : [...myProfile.preferredTimeSlots, slot.key as StudyTimeSlot];
                        handleUpdateProfile({ preferredTimeSlots: next });
                      }}
                      className={cn(
                        "py-2 px-2 rounded-xl text-xs font-semibold border text-center transition cursor-pointer",
                        isSelected
                          ? "bg-indigo-600/30 border-indigo-500 text-indigo-300 shadow-sm"
                          : "bg-slate-800/40 border-slate-700 text-slate-400 hover:bg-slate-800"
                      )}
                    >
                      {slot.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Privacy Shield Info */}
            <div className="p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-500/20 text-xs text-indigo-300 flex items-start gap-2.5">
              <ShieldCheck size={18} className="text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <h5 className="font-bold text-indigo-200">Zero PII Leakage Guarantee</h5>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Your email, phone number, and real name are strictly masked behind pseudonyms. Personal details are never revealed unless both peers explicitly consent.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Daily Check-In Flow Modal */}
      {checkInMatch && (
        <CheckInFlow
          match={checkInMatch}
          isDark={isDark}
          onClose={() => setCheckInMatch(null)}
          onCheckInComplete={loadData}
        />
      )}

      {/* Buddy Chat & Scheduler Modal */}
      {chatMatch && (
        <BuddyChatModal
          match={chatMatch}
          initialTab={chatInitialTab}
          isDark={isDark}
          onClose={() => setChatMatch(null)}
          onUpdate={loadData}
        />
      )}
    </div>
  );
};
