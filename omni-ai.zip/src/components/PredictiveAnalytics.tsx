import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Award, 
  Flame, 
  CheckCircle, 
  XCircle, 
  Sliders, 
  ChevronRight, 
  Play, 
  RotateCcw, 
  Zap, 
  Sparkles, 
  BookOpen, 
  Compass, 
  AlertTriangle, 
  Clock, 
  Target, 
  HelpCircle,
  ThumbsUp,
  BrainCircuit,
  GraduationCap
} from 'lucide-react';

interface ExamConfig {
  id: string;
  name: string;
  maxScore: number;
  passingScore: number;
  unit: string;
  percentileFormula: (score: number) => number;
}

const EXAMS: ExamConfig[] = [
  { 
    id: 'sat', 
    name: 'SAT (Standardized Test)', 
    maxScore: 1600, 
    passingScore: 1000, 
    unit: 'pts',
    percentileFormula: (score) => Math.min(99.9, Math.max(1, Math.round(((score - 400) / 1200) * 100))) 
  },
  { 
    id: 'jee', 
    name: 'IIT-JEE (Advanced)', 
    maxScore: 360, 
    passingScore: 180, 
    unit: 'pts',
    percentileFormula: (score) => Math.min(99.99, Math.max(50, Math.round(50 + ((score / 360) * 49.99) * 100) / 100))
  },
  { 
    id: 'mcat', 
    name: 'MCAT (Medical Admission)', 
    maxScore: 528, 
    passingScore: 500, 
    unit: 'pts',
    percentileFormula: (score) => Math.min(100, Math.max(1, Math.round(((score - 472) / 56) * 100))) 
  },
  { 
    id: 'gaokao', 
    name: 'Gaokao (China National)', 
    maxScore: 750, 
    passingScore: 550, 
    unit: 'pts',
    percentileFormula: (score) => Math.min(99.9, Math.max(1, Math.round(((score - 200) / 550) * 100))) 
  },
  { 
    id: 'ib', 
    name: 'IB Diploma (International)', 
    maxScore: 45, 
    passingScore: 24, 
    unit: 'pts',
    percentileFormula: (score) => Math.min(99.5, Math.max(10, Math.round(((score / 45) * 90) + 9))) 
  },
];

interface TopicMetric {
  id: string;
  name: string;
  subject: string;
  mastery: number; // 0 to 100
  latency: number; // response delay in seconds
  interval: number; // spaced repetition interval in days
  totalAttempts: number;
}

const INITIAL_TOPICS: TopicMetric[] = [
  // Mathematics
  { id: 'm1', name: 'Quadratic Equations', subject: 'Mathematics', mastery: 74, latency: 4.2, interval: 6, totalAttempts: 12 },
  { id: 'm2', name: 'Complex Numbers', subject: 'Mathematics', mastery: 35, latency: 12.8, interval: 1, totalAttempts: 18 },
  { id: 'm3', name: 'Differential Calculus', subject: 'Mathematics', mastery: 88, latency: 3.1, interval: 14, totalAttempts: 25 },
  { id: 'm4', name: 'Probability Distributions', subject: 'Mathematics', mastery: 42, latency: 9.5, interval: 2, totalAttempts: 15 },
  { id: 'm5', name: 'Matrices & Determinants', subject: 'Mathematics', mastery: 92, latency: 2.2, interval: 21, totalAttempts: 30 },
  { id: 'm6', name: 'Trigonometric Identities', subject: 'Mathematics', mastery: 58, latency: 6.7, interval: 4, totalAttempts: 10 },
  // Physics
  { id: 'p1', name: 'Rotational Mechanics', subject: 'Physics', mastery: 28, latency: 15.4, interval: 1, totalAttempts: 22 },
  { id: 'p2', name: 'Electromagnetism', subject: 'Physics', mastery: 64, latency: 5.8, interval: 5, totalAttempts: 14 },
  { id: 'p3', name: 'Thermodynamics', subject: 'Physics', mastery: 82, latency: 3.9, interval: 12, totalAttempts: 19 },
  { id: 'p4', name: 'Wave Optics', subject: 'Physics', mastery: 47, latency: 8.3, interval: 2, totalAttempts: 11 },
  { id: 'p5', name: 'Quantum Mechanics', subject: 'Physics', mastery: 79, latency: 4.6, interval: 9, totalAttempts: 16 },
  // Chemistry
  { id: 'c1', name: 'Chemical Equilibrium', subject: 'Chemistry', mastery: 85, latency: 3.4, interval: 15, totalAttempts: 20 },
  { id: 'c2', name: 'Organic Reaction Mechanisms', subject: 'Chemistry', mastery: 31, latency: 14.1, interval: 1, totalAttempts: 24 },
  { id: 'c3', name: 'Coordination Compounds', subject: 'Chemistry', mastery: 69, latency: 5.2, interval: 7, totalAttempts: 13 },
  { id: 'c4', name: 'Electrochemistry', subject: 'Chemistry', mastery: 53, latency: 7.6, interval: 3, totalAttempts: 9 },
  { id: 'c5', name: 'Thermochemistry', subject: 'Chemistry', mastery: 91, latency: 2.0, interval: 25, totalAttempts: 28 },
  // Biology
  { id: 'b1', name: 'Molecular Genetics', subject: 'Biology', mastery: 77, latency: 4.0, interval: 11, totalAttempts: 17 },
  { id: 'b2', name: 'Cellular Respiration', subject: 'Biology', mastery: 49, latency: 8.1, interval: 3, totalAttempts: 14 },
  { id: 'b3', name: 'Plant Physiology', subject: 'Biology', mastery: 38, latency: 11.2, interval: 1, totalAttempts: 21 },
  { id: 'b4', name: 'Ecology & Ecosystems', subject: 'Biology', mastery: 94, latency: 1.8, interval: 30, totalAttempts: 32 },
  { id: 'b5', name: 'Evolutionary Biology', subject: 'Biology', mastery: 86, latency: 3.2, interval: 18, totalAttempts: 22 }
];

interface QuizQuestion {
  id: number;
  subject: string;
  topicId: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const SIMULATOR_QUESTIONS: QuizQuestion[] = [
  // Maths - Complex Numbers (m2)
  {
    id: 1,
    subject: 'Mathematics',
    topicId: 'm2',
    question: 'What is the principal value of the argument of the complex number z = -1 - i√3?',
    options: ['-2π/3', '2π/3', '-π/3', '5π/6'],
    correctIndex: 0,
    explanation: 'Since z lies in the third quadrant (both real and imaginary parts are negative), the principal argument is Arg(z) = -π + arctan(√3) = -π + π/3 = -2π/3.'
  },
  {
    id: 2,
    subject: 'Mathematics',
    topicId: 'm4',
    question: 'If X is a Poisson random variable such that P(X = 1) = P(X = 2), what is the mean of X?',
    options: ['1', '2', '3', '4'],
    correctIndex: 1,
    explanation: 'For a Poisson distribution, P(X = k) = (e^(-λ) * λ^k) / k!. Setting P(X = 1) = P(X = 2) gives: e^(-λ) * λ = (e^(-λ) * λ^2) / 2. Solving for λ (since λ > 0) yields λ = 2.'
  },
  // Physics - Rotational Mechanics (p1)
  {
    id: 3,
    subject: 'Physics',
    topicId: 'p1',
    question: 'A solid sphere, a thin circular disk, and a hoop, all of same mass and radius, roll down an inclined plane from rest. Which one reaches the bottom first?',
    options: ['Solid sphere', 'Thin circular disk', 'Hoop', 'They reach at the same time'],
    correctIndex: 0,
    explanation: 'The acceleration down the incline is a = g*sin(θ) / (1 + I/(MR²)). The solid sphere has the smallest moment of inertia coefficient (I = 2/5 MR² = 0.4), resulting in the largest acceleration and reaching the bottom first.'
  },
  {
    id: 4,
    subject: 'Physics',
    topicId: 'p4',
    question: 'In a Young’s Double Slit Experiment, if the distance between slits is halved and distance to screen is doubled, what happens to fringe width?',
    options: ['Remains unchanged', 'Halved', 'Doubled', 'Quadrupled'],
    correctIndex: 3,
    explanation: 'Fringe width β is given by λD/d. Halving d (d/2) and doubling D (2D) gives β\' = λ(2D)/(d/2) = 4 * (λD/d) = 4β. The fringe width is quadrupled.'
  },
  // Chemistry - Organic Reaction Mechanisms (c2)
  {
    id: 5,
    subject: 'Chemistry',
    topicId: 'c2',
    question: 'Which of the following undergoes nucleophilic substitution reactions exclusively through the SN1 mechanism?',
    options: ['Methyl chloride', 'Ethyl chloride', 'Isopropyl chloride', 'tert-Butyl chloride'],
    correctIndex: 3,
    explanation: 'tert-Butyl chloride undergoes substitution via SN1 because it forms a highly stable tertiary carbocation intermediate [(CH3)3C+], and steric hindrance prevents the back-attack needed for SN2.'
  },
  {
    id: 6,
    subject: 'Chemistry',
    topicId: 'c4',
    question: 'For a cell reaction involving a two-electron change, the standard EMF of the cell is found to be 0.295 V at 25°C. The equilibrium constant of the reaction is approximately:',
    options: ['1.0 × 10^10', '1.0 × 10^5', '1.0 × 10^15', '2.0 × 10^8'],
    correctIndex: 0,
    explanation: 'Using Nernst equation: E° = (0.0591 / n) * log(K). Here E° = 0.295 V, n = 2. So 0.295 = (0.0591 / 2) * log(K) => 0.295 = 0.02955 * log(K) => log(K) ≈ 10 => K ≈ 10^10.'
  },
  // Biology - Plant Physiology (b3)
  {
    id: 7,
    subject: 'Biology',
    topicId: 'b3',
    question: 'Which hormone is primary responsible for apical dominance, phototropism, and root initiation?',
    options: ['Gibberellin', 'Auxin', 'Cytokinin', 'Abscisic Acid'],
    correctIndex: 1,
    explanation: 'Auxin (principally indole-3-acetic acid) is produced in shoot apices and promotes apical dominance, elongates cells on the shaded side during phototropism, and stimulates adventitious root initiation.'
  },
  {
    id: 8,
    subject: 'Biology',
    topicId: 'b2',
    question: 'During glycolysis, which enzyme catalyzes the key rate-limiting commitment step converting Fructose-6-Phosphate to Fructose-1,6-Bisphosphate?',
    options: ['Hexokinase', 'Phosphofructokinase-1 (PFK-1)', 'Pyruvate Kinase', 'Phosphoglycerate Mutase'],
    correctIndex: 1,
    explanation: 'Phosphofructokinase-1 (PFK-1) is the main rate-limiting, allosterically regulated enzyme of glycolysis that commits the glucose molecule to cellular respiration.'
  }
];

export const PredictiveAnalytics: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [selectedExamId, setSelectedExamId] = useState<string>('sat');
  const [selectedSubject, setSelectedSubject] = useState<string>('Mathematics');
  const [topics, setTopics] = useState<TopicMetric[]>(INITIAL_TOPICS);
  const [selectedTopic, setSelectedTopic] = useState<TopicMetric | null>(null);

  // Simulation Sliders State
  const [studyVelocity, setStudyVelocity] = useState<number>(75); // %
  const [activeRecall, setActiveRecall] = useState<number>(60); // %
  const [quizFrequency, setQuizFrequency] = useState<number>(80); // %

  // Exam Simulator Quiz State
  const [quizActive, setQuizActive] = useState<boolean>(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answeredCount, setAnsweredCount] = useState<number>(0);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);
  const [quizSessionQuestions, setQuizSessionQuestions] = useState<QuizQuestion[]>([]);

  // Selected Exam Config
  const currentExam = EXAMS.find(e => e.id === selectedExamId) || EXAMS[0];

  // Dynamic calculations based on topics and sliders
  const filteredTopics = topics.filter(t => t.subject === selectedSubject);
  
  // Calculate raw performance score based on average mastery
  const averageMastery = filteredTopics.reduce((acc, t) => acc + t.mastery, 0) / filteredTopics.length;
  
  // Calculate multiplier effect from sliders
  const velocityBonus = (studyVelocity - 50) * 0.15;
  const recallBonus = (activeRecall - 50) * 0.25;
  const freqBonus = (quizFrequency - 50) * 0.12;
  const simulatedFactor = (velocityBonus + recallBonus + freqBonus);

  // Estimated Exam Score
  const calculatedScoreRaw = Math.round(
    currentExam.passingScore + 
    ((currentExam.maxScore - currentExam.passingScore) * (averageMastery / 100)) + 
    (simulatedFactor * (currentExam.maxScore / 100))
  );
  
  const predictedScore = Math.min(currentExam.maxScore, Math.max(currentExam.passingScore - 150, calculatedScoreRaw));
  const predictedPercentile = currentExam.percentileFormula(predictedScore);

  // Weakest topics sorted
  const weakestTopics = [...topics]
    .filter(t => t.mastery < 65)
    .sort((a, b) => a.mastery - b.mastery);

  // Spaced repetition scheduler alerts count
  const spacedRepetitionAlerts = topics.filter(t => t.mastery < 50 && t.interval <= 2);

  // Set default selected topic on load or subject change
  useEffect(() => {
    if (filteredTopics.length > 0) {
      setSelectedTopic(filteredTopics[0]);
    }
  }, [selectedSubject]);

  // Launch a localized practice diagnostic session
  const startPracticeQuiz = () => {
    // Pick 3 random questions matching the current subject or general questions
    const matching = SIMULATOR_QUESTIONS.filter(q => q.subject === selectedSubject);
    const selected = matching.length > 0 ? matching : SIMULATOR_QUESTIONS.slice(0, 3);
    
    setQuizSessionQuestions(selected);
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setAnsweredCount(0);
    setCorrectCount(0);
    setShowExplanation(false);
    setQuizActive(true);
  };

  const handleAnswerSubmit = (index: number) => {
    if (selectedAnswer !== null) return; // already answered
    setSelectedAnswer(index);
    setShowExplanation(true);
    setAnsweredCount(prev => prev + 1);

    const currentQ = quizSessionQuestions[currentQuestionIndex];
    const isCorrect = index === currentQ.correctIndex;
    
    if (isCorrect) {
      setCorrectCount(prev => prev + 1);
    }

    // Live update topic mastery in state depending on correct/incorrect response!
    setTopics(prevTopics => {
      return prevTopics.map(t => {
        if (t.id === currentQ.topicId) {
          const rawNewMastery = isCorrect 
            ? Math.min(100, t.mastery + 12) 
            : Math.max(10, t.mastery - 8);
          return {
            ...t,
            mastery: Math.round(rawNewMastery),
            latency: isCorrect ? Math.max(1.5, t.latency * 0.8) : t.latency * 1.2,
            interval: isCorrect ? t.interval + 3 : Math.max(1, Math.round(t.interval / 2)),
            totalAttempts: t.totalAttempts + 1
          };
        }
        return t;
      });
    });
  };

  const nextQuestion = () => {
    if (currentQuestionIndex + 1 < quizSessionQuestions.length) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      // Quiz completed!
      setQuizActive(false);
    }
  };

  // Run the dynamic automatic remediation routine which levels up weakest topics
  const runRemediationRoutine = (topicId: string) => {
    setTopics(prev => prev.map(t => {
      if (t.id === topicId) {
        return {
          ...t,
          mastery: Math.min(100, t.mastery + 15),
          latency: Math.max(2.0, t.latency * 0.75),
          interval: t.interval + 5,
          totalAttempts: t.totalAttempts + 1
        };
      }
      return t;
    }));
    // Re-sync selected topic state
    setSelectedTopic(prev => {
      if (prev && prev.id === topicId) {
        return {
          ...prev,
          mastery: Math.min(100, prev.mastery + 15),
          latency: Math.max(2.0, prev.latency * 0.75),
          interval: prev.interval + 5,
          totalAttempts: prev.totalAttempts + 1
        };
      }
      return prev;
    });
  };

  // Run bulk remediation action plan
  const executeFullActionPlan = () => {
    setTopics(prev => prev.map(t => {
      if (t.mastery < 65) {
        return {
          ...t,
          mastery: Math.min(100, t.mastery + 10),
          latency: Math.max(2.0, t.latency * 0.8),
          interval: t.interval + 3
        };
      }
      return t;
    }));
    
    // Automatically lift user simulation sliders to show success
    setStudyVelocity(prev => Math.min(100, prev + 10));
    setActiveRecall(prev => Math.min(100, prev + 15));
    setQuizFrequency(prev => Math.min(100, prev + 8));
  };

  const resetAllMetrics = () => {
    setTopics(INITIAL_TOPICS);
    setStudyVelocity(75);
    setActiveRecall(60);
    setQuizFrequency(80);
    setSelectedTopic(INITIAL_TOPICS.find(t => t.subject === selectedSubject) || null);
  };

  return (
    <div id="analytics-engine-root" className="flex flex-col h-full overflow-y-auto pr-1">
      {/* Subject and Target Exam selector */}
      <div id="analytics-top-header" className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
        {/* Target National Standardized Exam Selection */}
        <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">
            Target National / Entrance Exam
          </label>
          <div className="relative">
            <select
              id="select-target-exam"
              value={selectedExamId}
              onChange={(e) => setSelectedExamId(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 text-xs font-bold dark:text-white outline-none focus:border-indigo-500 cursor-pointer"
            >
              {EXAMS.map(ex => (
                <option key={ex.id} value={ex.id}>{ex.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Current Academic Subject Scope */}
        <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">
            Academic Topic Scope
          </label>
          <div className="flex gap-1">
            {['Mathematics', 'Physics', 'Chemistry', 'Biology'].map(sub => (
              <button
                id={`btn-scope-sub-${sub}`}
                key={sub}
                onClick={() => setSelectedSubject(sub)}
                className={`flex-1 py-2 text-[10px] font-bold rounded-lg transition-all cursor-pointer ${
                  selectedSubject === sub 
                    ? 'bg-indigo-600 text-white shadow-sm' 
                    : 'bg-white dark:bg-slate-850 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div id="analytics-main-grid" className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left column: Heatmap and Action Plans (Col 7) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          
          {/* Section: Weakness Diagnostic Heatmap */}
          <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <BrainCircuit size={15} className="text-indigo-500" />
                  Weakness Diagnostic Heatmap
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Click any cell to inspect knowledge gaps, recall latency, and spacing schedule</p>
              </div>
              <button 
                id="btn-reset-metrics"
                onClick={resetAllMetrics}
                className="text-[10px] font-extrabold text-slate-400 hover:text-indigo-500 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw size={10} /> Reset
              </button>
            </div>

            {/* The Interactive grid */}
            <div id="heatmap-grid" className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {filteredTopics.map((topic) => {
                // Determine styling category based on mastery score
                const isCritical = topic.mastery < 45;
                const isCaution = topic.mastery >= 45 && topic.mastery < 70;
                const isProficient = topic.mastery >= 70 && topic.mastery < 85;
                const isMastered = topic.mastery >= 85;

                return (
                  <button
                    id={`heatmap-cell-${topic.id}`}
                    key={topic.id}
                    onClick={() => setSelectedTopic(topic)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden group ${
                      selectedTopic?.id === topic.id
                        ? 'border-indigo-600 ring-2 ring-indigo-500/20'
                        : 'border-slate-200 dark:border-slate-800/80 hover:border-indigo-400'
                    } ${
                      isCritical ? 'bg-red-500/5 dark:bg-red-500/10' :
                      isCaution ? 'bg-amber-500/5 dark:bg-amber-500/10' :
                      isProficient ? 'bg-blue-500/5 dark:bg-blue-500/10' :
                      'bg-emerald-500/5 dark:bg-emerald-500/10'
                    }`}
                  >
                    {/* Status Badge Tag */}
                    <div className="flex items-center justify-between gap-1 mb-1.5">
                      <span className={`text-[8px] font-black tracking-widest px-1.5 py-0.5 rounded-md uppercase ${
                        isCritical ? 'bg-red-500/15 text-red-500' :
                        isCaution ? 'bg-amber-500/15 text-amber-500' :
                        isProficient ? 'bg-blue-500/15 text-blue-500' :
                        'bg-emerald-500/15 text-emerald-500'
                      }`}>
                        {isCritical ? 'Critical' : isCaution ? 'Caution' : isProficient ? 'Proficient' : 'Mastered'}
                      </span>
                      <span className="text-[9px] font-black font-mono text-slate-500">{topic.mastery}%</span>
                    </div>

                    <div className="text-xs font-bold text-slate-800 dark:text-slate-100 line-clamp-1 mb-2 group-hover:text-indigo-500 transition-colors">
                      {topic.name}
                    </div>

                    {/* Simple Mini Heatmap Progress Bar */}
                    <div className="w-full bg-slate-200 dark:bg-slate-800 h-1 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${
                          isCritical ? 'bg-red-500' :
                          isCaution ? 'bg-amber-500' :
                          isProficient ? 'bg-blue-500' :
                          'bg-emerald-500'
                        }`}
                        style={{ width: `${topic.mastery}%` }}
                      />
                    </div>

                    <div className="flex justify-between text-[9px] text-slate-400 mt-2 font-mono">
                      <span>Latency: {topic.latency.toFixed(1)}s</span>
                      <span>Next: {topic.interval}d</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Inspected topic detailed drawer / drawer card */}
            {selectedTopic && (
              <div id="inspected-topic-panel" className="mt-4 p-4 rounded-xl border border-indigo-500/20 bg-indigo-500/5 text-slate-800 dark:text-slate-200 text-xs flex flex-col sm:flex-row justify-between gap-4">
                <div className="flex-1">
                  <h4 className="font-black text-xs text-indigo-500 mb-1 flex items-center gap-1.5">
                    <Compass size={14} />
                    Diagnostic Metrics: {selectedTopic.name}
                  </h4>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-3">
                    Active space intervals calculate the probability of retention decaying over time. Faster recall latencies correspond to secure synaptic retrieval.
                  </p>
                  
                  <div className="grid grid-cols-2 gap-3 text-[11px]">
                    <div className="flex items-center gap-2">
                      <Clock size={12} className="text-slate-400" />
                      <span>Recall Latency: <strong className="font-mono">{selectedTopic.latency.toFixed(1)} seconds</strong></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap size={12} className="text-slate-400" />
                      <span>Spacing Interval: <strong className="font-mono">{selectedTopic.interval} days</strong></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target size={12} className="text-slate-400" />
                      <span>Total Drilling Drills: <strong className="font-mono">{selectedTopic.totalAttempts} cycles</strong></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <AlertTriangle size={12} className="text-slate-400" />
                      <span>Current Failure Risk: <strong className={`font-mono ${selectedTopic.mastery < 50 ? 'text-red-500' : 'text-emerald-500'}`}>
                        {selectedTopic.mastery < 45 ? 'HIGH (82%)' : selectedTopic.mastery < 70 ? 'MEDIUM (41%)' : 'NEGLIGIBLE (<5%)'}
                      </strong></span>
                    </div>
                  </div>
                </div>

                <div className="sm:w-40 flex flex-col justify-between border-t sm:border-t-0 sm:border-l border-slate-200 dark:border-slate-800 pt-3 sm:pt-0 sm:pl-4">
                  <div className="mb-2">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">SYNAPTIC STRENGTH</span>
                    <span className="text-lg font-black font-mono text-indigo-500">{selectedTopic.mastery}%</span>
                  </div>
                  <button
                    id={`btn-remediate-${selectedTopic.id}`}
                    onClick={() => runRemediationRoutine(selectedTopic.id)}
                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-black text-[9px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Sparkles size={11} /> Remediate Now
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Section: Custom Diagnostic Action Plans */}
          <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <BookOpen size={15} className="text-indigo-500" />
                  Custom Diagnostic Action Plans
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Automated study schedules customized targeting score maximizers</p>
              </div>
              <button
                id="btn-execute-all-action"
                onClick={executeFullActionPlan}
                className="px-2.5 py-1.5 text-[9px] bg-indigo-500/15 hover:bg-indigo-500/20 text-indigo-500 border border-indigo-500/20 rounded-lg font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all"
              >
                <Zap size={11} /> Execute Plan
              </button>
            </div>

            <div id="remediation-steps-list" className="flex flex-col gap-2.5">
              {weakestTopics.slice(0, 3).map((weak, idx) => (
                <div 
                  id={`action-plan-card-${idx}`}
                  key={weak.id} 
                  className="p-3 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3"
                >
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded bg-red-100 dark:bg-red-950/40 text-red-500 font-mono font-black text-[11px] flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <div>
                      <div className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                        <span>Remediation drill for {weak.name}</span>
                        <span className="px-1.5 py-0.5 rounded text-[8px] font-black bg-red-500/10 text-red-500 border border-red-500/10">Weakest Link</span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1 leading-relaxed">
                        Execute a 15-minute <strong>Feynman Conceptual Drill</strong>, explaining the root mechanics out loud to active voice agents. Follow with mock diagnostic simulations.
                      </p>
                    </div>
                  </div>

                  <button
                    id={`btn-plan-remediate-${weak.id}`}
                    onClick={() => runRemediationRoutine(weak.id)}
                    className="p-1.5 bg-slate-100 hover:bg-indigo-600 dark:bg-slate-800 dark:hover:bg-indigo-600 text-slate-400 hover:text-white rounded-lg transition-all cursor-pointer flex-shrink-0"
                    title="Remediate topic immediately"
                  >
                    <ChevronRight size={14} />
                  </button>
                </div>
              ))}

              {weakestTopics.length === 0 && (
                <div className="py-6 flex flex-col items-center justify-center text-slate-400 bg-white dark:bg-slate-850 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                  <CheckCircle size={24} className="text-emerald-500 mb-1.5" />
                  <span className="text-[10px] font-bold">Excellent! All subject topic mastery scores are above caution thresholds!</span>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Right column: Predictive Grade Engine & Practice Quiz Simulator (Col 5) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          
          {/* Section: Predictive Grade Engine */}
          <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-4">
              <Award size={15} className="text-indigo-500" />
              Predictive Grade Engine
            </h3>

            {/* Score circle visualizer */}
            <div className="flex flex-col items-center justify-center py-4 bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl relative overflow-hidden mb-4">
              <div className="absolute top-2 right-2 text-[9px] font-black uppercase tracking-widest text-slate-400 px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800">
                PROJECTION
              </div>
              
              <span className="text-3xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                {predictedScore} <span className="text-xs text-slate-400 font-bold">{currentExam.unit}</span>
              </span>
              
              <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-1">
                Predicted Exam Score
              </div>

              <div className="flex items-center gap-2 mt-3 text-[11px] font-bold text-slate-600 dark:text-slate-300">
                <span>Percentile: <strong className="text-indigo-500 font-mono">{predictedPercentile}%</strong></span>
                <span className="text-slate-300">•</span>
                <span>Margin: <strong className="text-emerald-500 font-mono">+{predictedScore - currentExam.passingScore}</strong></span>
              </div>
            </div>

            {/* Live simulation toggles */}
            <div id="simulation-sliders" className="flex flex-col gap-3.5 text-xs">
              <div className="flex items-center gap-1 font-black text-[9px] tracking-widest text-indigo-500 uppercase">
                <Sliders size={12} />
                Real-Time Growth Simulator
              </div>

              <div>
                <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                  <span>Weekly Study Velocity</span>
                  <span className="font-mono text-indigo-500">{studyVelocity} h/w</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={studyVelocity}
                  onChange={e => setStudyVelocity(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                  <span>Active Recall Consistency</span>
                  <span className="font-mono text-indigo-500">{activeRecall}%</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={activeRecall}
                  onChange={e => setActiveRecall(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
              </div>

              <div>
                <div className="flex justify-between font-extrabold text-slate-500 mb-1">
                  <span>Mock Quiz Frequency</span>
                  <span className="font-mono text-indigo-500">{quizFrequency}%</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={quizFrequency}
                  onChange={e => setQuizFrequency(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
              </div>
            </div>
          </div>

          {/* Section: Practice Exam Simulator */}
          <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-3">
              <GraduationCap size={15} className="text-indigo-500" />
              Practice Exam Simulator
            </h3>

            {!quizActive ? (
              <div id="quiz-inactive-panel" className="text-center py-5 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col items-center justify-center">
                <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-950/40 text-indigo-500 rounded-full flex items-center justify-center mb-2.5">
                  <HelpCircle size={20} />
                </div>
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 mb-1">Diagnostic Adaptive Assessment</h4>
                <p className="text-[10px] text-slate-500 mb-4 max-w-xs leading-relaxed">
                  Start a micro study simulation targeting <strong>{selectedSubject}</strong>. Scores immediately rewrite weakness diagnostic heatmaps in real-time.
                </p>
                <button
                  id="btn-launch-simulation-quiz"
                  onClick={startPracticeQuiz}
                  className="py-2.5 px-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-md transition-all"
                >
                  <Play size={12} /> Launch Assessment
                </button>
              </div>
            ) : (
              <div id="quiz-active-panel" className="p-4 bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs">
                {/* Header Status bar */}
                <div className="flex justify-between items-center mb-3 text-[10px] text-slate-400 font-extrabold uppercase">
                  <span>Question {currentQuestionIndex + 1} of {quizSessionQuestions.length}</span>
                  <span className="text-indigo-500">Subject: {selectedSubject}</span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-200 dark:bg-slate-800 h-1 rounded-full overflow-hidden mb-4">
                  <div 
                    className="h-full bg-indigo-600 transition-all duration-300" 
                    style={{ width: `${((currentQuestionIndex + 1) / quizSessionQuestions.length) * 100}%` }}
                  />
                </div>

                {/* Question Text */}
                <h4 className="font-bold text-slate-800 dark:text-slate-100 mb-4 leading-relaxed">
                  {quizSessionQuestions[currentQuestionIndex].question}
                </h4>

                {/* Choices list */}
                <div className="flex flex-col gap-2 mb-4">
                  {quizSessionQuestions[currentQuestionIndex].options.map((opt, oIdx) => {
                    const isSelected = selectedAnswer === oIdx;
                    const isCorrect = oIdx === quizSessionQuestions[currentQuestionIndex].correctIndex;
                    const hasAnswered = selectedAnswer !== null;

                    return (
                      <button
                        id={`quiz-option-${oIdx}`}
                        key={oIdx}
                        disabled={hasAnswered}
                        onClick={() => handleAnswerSubmit(oIdx)}
                        className={`p-3 rounded-xl border text-left text-[11px] font-medium transition-all ${
                          hasAnswered
                            ? isCorrect
                              ? 'bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold'
                              : isSelected
                                ? 'bg-red-500/10 border-red-500 text-red-600 dark:text-red-400 font-bold'
                                : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-60'
                            : 'bg-slate-50 hover:bg-indigo-50/50 border-slate-200 hover:border-indigo-500 dark:bg-slate-900 dark:hover:bg-slate-800/50 dark:border-slate-800 cursor-pointer'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className={`w-5 h-5 rounded-md flex items-center justify-center font-mono font-bold text-[10px] ${
                            hasAnswered
                              ? isCorrect
                                ? 'bg-emerald-500 text-white'
                                : isSelected
                                  ? 'bg-red-500 text-white'
                                  : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                              : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                          }`}>
                            {String.fromCharCode(65 + oIdx)}
                          </span>
                          <span>{opt}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Explanatory overlay box */}
                {showExplanation && (
                  <div className="p-3 bg-indigo-500/5 border border-indigo-500/15 rounded-xl mb-4 text-[11px] leading-relaxed">
                    <div className="flex items-center gap-1 font-bold text-indigo-500 mb-1">
                      <Sparkles size={12} className="animate-spin" />
                      Academic Explanation:
                    </div>
                    <p className="text-slate-600 dark:text-slate-300">
                      {quizSessionQuestions[currentQuestionIndex].explanation}
                    </p>
                  </div>
                )}

                {/* Next CTA button */}
                {selectedAnswer !== null && (
                  <button
                    id="btn-quiz-next"
                    onClick={nextQuestion}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-[11px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer shadow-sm"
                  >
                    {currentQuestionIndex + 1 === quizSessionQuestions.length ? 'Finish & Log Results' : 'Next Question'}
                    <ChevronRight size={14} />
                  </button>
                )}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
