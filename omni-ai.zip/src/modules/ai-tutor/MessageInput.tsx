import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Image, Send, X, Keyboard, HelpCircle, FileText, Trash2 } from 'lucide-react';

interface MessageInputProps {
  onSend: (text: string, contentType: 'text' | 'image' | 'latex' | 'voice', imageBase64?: string) => void;
  disabled: boolean;
  currentSubject?: string;
  language?: string;
}

export const MessageInput: React.FC<MessageInputProps> = ({ onSend, disabled, currentSubject, language = 'en' }) => {
  const [inputText, setInputText] = useState('');
  const [showMathSymbols, setShowMathSymbols] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingError, setRecordingError] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Map app language code to SpeechRecognition BCP-47 tag
  const getSpeechLocale = (langCode: string) => {
    switch (langCode) {
      case 'hi':
      case 'hinglish':
        return 'hi-IN';
      case 'ur':
        return 'ur-PK';
      case 'bn':
        return 'bn-IN';
      case 'mr':
        return 'mr-IN';
      case 'te':
        return 'te-IN';
      case 'ta':
        return 'ta-IN';
      case 'gu':
        return 'gu-IN';
      case 'kn':
        return 'kn-IN';
      case 'ml':
        return 'ml-IN';
      case 'pa':
        return 'pa-IN';
      case 'or':
        return 'or-IN';
      case 'as':
        return 'as-IN';
      case 'es':
        return 'es-ES';
      case 'fr':
        return 'fr-FR';
      case 'de':
        return 'de-DE';
      case 'zh':
        return 'zh-CN';
      case 'ja':
        return 'ja-JP';
      case 'ru':
        return 'ru-RU';
      case 'ar':
        return 'ar-SA';
      case 'pt':
        return 'pt-BR';
      case 'it':
        return 'it-IT';
      case 'id':
        return 'id-ID';
      case 'ko':
        return 'ko-KR';
      case 'tr':
        return 'tr-TR';
      case 'vi':
        return 'vi-VN';
      case 'th':
        return 'th-TH';
      case 'fa':
        return 'fa-IR';
      default:
        return 'en-US';
    }
  };

  // LaTeX Shortcut Keys
  const MATH_SHORTCUTS = [
    { label: 'Fraction (a/b)', code: '\\frac{a}{b}' },
    { label: 'Square Root (√)', code: '\\sqrt{x}' },
    { label: 'Power (x²)', code: 'x^{2}' },
    { label: 'Integral (∫)', code: '\\int' },
    { label: 'Sum (∑)', code: '\\sum' },
    { label: 'Delta (Δ)', code: '\\Delta' },
    { label: 'Theta (θ)', code: '\\theta' },
    { label: 'Pi (π)', code: '\\pi' },
    { label: 'Infinity (∞)', code: '\\infty' },
    { label: 'Matrix', code: '\\begin{matrix} a & b \\\\ c & d \\end{matrix}' },
    { label: 'Limit', code: '\\lim_{x \\to \\infty}' },
    { label: 'Sigma (σ)', code: '\\sigma' }
  ];

  // Initialize Speech Recognition with language synchronization
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = getSpeechLocale(language);

      rec.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (finalTranscript) {
          setInputText(prev => prev + (prev ? ' ' : '') + finalTranscript);
        }
      };

      rec.onerror = (event: any) => {
        console.error('Speech recognition error', event);
        setRecordingError('Voice recognition error. Please try speaking clearly or typing.');
        setIsRecording(false);
      };

      rec.onend = () => {
        setIsRecording(false);
      };

      recognitionRef.current = rec;
    }
  }, []);

  const handleSend = () => {
    if (disabled) return;
    
    const trimmedText = inputText.trim();
    if (!trimmedText && !imageBase64) return;

    if (imageBase64) {
      onSend(trimmedText || 'Analyze this problem', 'image', imageBase64);
      // Clean up attachment
      setImagePreview(null);
      setImageBase64(null);
    } else {
      const isLatex = trimmedText.includes('\\') || trimmedText.includes('$');
      onSend(trimmedText, isLatex ? 'latex' : 'text');
    }

    setInputText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputText(e.target.value);
    // Auto-expand height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }
  };

  const insertMathCode = (code: string) => {
    if (!textareaRef.current) return;
    const startPos = textareaRef.current.selectionStart;
    const endPos = textareaRef.current.selectionEnd;
    const text = inputText;
    const valueToInsert = `$${code}$`;

    const newText = text.substring(0, startPos) + valueToInsert + text.substring(endPos, text.length);
    setInputText(newText);
    
    // Focus back on text area and set cursor index
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const cursorPosition = startPos + valueToInsert.length;
        textareaRef.current.setSelectionRange(cursorPosition, cursorPosition);
      }
    }, 50);
  };

  const toggleVoiceRecording = () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      setRecordingError(null);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
          setIsRecording(true);
        } catch (e) {
          console.error(e);
          setRecordingError('Speech system busy. Try clicking again.');
        }
      } else {
        // Fallback or unavailable message
        setRecordingError('Speech recognition is not supported in this browser. Try Chrome/Edge.');
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit (< 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('Problem photo should be less than 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setImagePreview(base64);
      // Strip metadata from raw base64 for API transmission if needed, but we keep full dataUrl for rendering and standard send
      const base64Clean = base64.split(',')[1];
      setImageBase64(base64Clean);
    };
    reader.readAsDataURL(file);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="border-t border-slate-800 bg-slate-950/95 p-3 space-y-2 relative z-10 shadow-2xl">
      {/* Recording indicator & Error Alert */}
      {isRecording && (
        <div className="flex items-center gap-2 text-xs font-bold text-red-400 bg-red-950/50 px-3 py-1.5 rounded-xl border border-red-800/60 animate-pulse">
          <span className="w-2 h-2 rounded-full bg-red-500 inline-block animate-ping"></span>
          <span>Syllabus Mic Active: Speaking to your AI Tutor...</span>
        </div>
      )}
      {recordingError && (
        <div className="text-xs font-semibold text-amber-300 bg-amber-950/50 px-3 py-1.5 rounded-xl border border-amber-800/60 flex items-center justify-between">
          <span>{recordingError}</span>
          <button onClick={() => setRecordingError(null)} className="text-slate-400 hover:text-white text-base">×</button>
        </div>
      )}

      {/* Image Preview attachment */}
      {imagePreview && (
        <div className="relative inline-block border border-slate-750 rounded-xl p-1 bg-slate-900 shadow-md max-w-[120px]">
          <img src={imagePreview} alt="Problem sketch" className="h-16 w-16 object-cover rounded-lg" />
          <button
            onClick={() => { setImagePreview(null); setImageBase64(null); }}
            className="absolute -top-1.5 -right-1.5 bg-red-600 hover:bg-red-700 text-white p-1 rounded-full shadow-md transition-all"
            title="Remove attachment"
          >
            <X className="w-3 h-3" />
          </button>
          <span className="text-[9px] block text-slate-400 text-center font-bold mt-1">Ready to solve 📸</span>
        </div>
      )}

      {/* Math symbols panel */}
      {showMathSymbols && (
        <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 shadow-xl grid grid-cols-3 gap-1.5 animate-fadeIn">
          <div className="col-span-3 flex items-center justify-between border-b border-slate-800 pb-1.5 mb-1.5">
            <span className="text-[10px] font-extrabold text-indigo-400 uppercase tracking-wider flex items-center gap-1">
              <Keyboard className="w-3.5 h-3.5 text-indigo-400" /> LaTeX Math Keyboard Assist
            </span>
            <button 
              onClick={() => setShowMathSymbols(false)}
              className="text-slate-400 hover:text-white font-extrabold text-xs"
            >
              Close
            </button>
          </div>
          {MATH_SHORTCUTS.map((shortcut, idx) => (
            <button
              key={idx}
              onClick={() => insertMathCode(shortcut.code)}
              className="text-left text-slate-200 bg-slate-950 hover:bg-indigo-950/60 border border-slate-800 p-1.5 rounded-lg text-xs font-semibold hover:border-indigo-500 transition-all shadow-sm truncate"
              title={shortcut.label}
            >
              <code className="text-indigo-400 font-mono text-[10px] block font-bold mb-0.5">{shortcut.code}</code>
              <span className="text-[9px] text-slate-400 block font-normal leading-tight">{shortcut.label}</span>
            </button>
          ))}
        </div>
      )}

      {/* Core input field bar */}
      <div className="flex items-end gap-2">
        {/* Helper attachments buttons */}
        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl shadow-inner">
          {/* Delete / Clear Input Button */}
          <button
            type="button"
            onClick={() => {
              setInputText('');
              setImagePreview(null);
              setImageBase64(null);
              if (textareaRef.current) {
                textareaRef.current.style.height = 'auto';
              }
            }}
            disabled={!inputText && !imagePreview}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-all disabled:opacity-30 disabled:hover:text-slate-400 disabled:hover:bg-transparent cursor-pointer disabled:cursor-not-allowed"
            title="Delete / Clear text input and attachments"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          {/* LaTeX Toggle Button */}
          <button
            onClick={() => setShowMathSymbols(!showMathSymbols)}
            className={`p-1.5 rounded-lg transition-all ${
              showMathSymbols 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title="LaTeX Formulas Assist Keyboard"
          >
            <Keyboard className="w-4 h-4" />
          </button>

          {/* Image Uploader Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
            title="Upload Photo of Problem"
          >
            <Image className="w-4 h-4" />
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            className="hidden"
          />

          {/* Voice Input Button */}
          <button
            onClick={toggleVoiceRecording}
            className={`p-1.5 rounded-lg transition-all ${
              isRecording 
                ? 'bg-red-500 text-white animate-pulse shadow-md' 
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title="Dictate with Web Speech Voice API"
          >
            {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
        </div>

        {/* Text Input area */}
        <div className="flex-1 relative bg-slate-900 border border-slate-800 rounded-2xl p-1.5 shadow-inner focus-within:border-indigo-500 focus-within:bg-slate-950 transition-all">
          <textarea
            ref={textareaRef}
            value={inputText}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyPress}
            placeholder={
              imageBase64 
                ? "Describe this problem or ask to solve..." 
                : `Ask your AI Tutor (${currentSubject || 'Syllabus'})`
            }
            className="w-full resize-none bg-transparent outline-none max-h-[140px] min-h-[36px] text-xs font-semibold text-slate-100 placeholder:text-slate-500 px-2 py-1 pr-1"
            disabled={disabled}
            rows={1}
          />
        </div>

        {/* Submit Send Button */}
        <button
          onClick={handleSend}
          disabled={disabled || (!inputText.trim() && !imageBase64)}
          className={`p-3 rounded-2xl text-white shadow-md transition-all shrink-0 ${
            disabled || (!inputText.trim() && !imageBase64)
              ? 'bg-slate-800 text-slate-600 cursor-not-allowed shadow-none'
              : 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/30 active:scale-95 cursor-pointer'
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
