import React, { useState } from 'react';
import { useInterleavedPractice } from '../hooks/useInterleavedPractice';
import { ConfidenceInput } from './ConfidenceInput';
import { saveCalibrationRecord } from '../modules/metacognition/storage';
import { ConfidenceRating } from '../modules/metacognition/types';
import { 
  Brain, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  RotateCcw, 
  Trophy, 
  Target, 
  AlertTriangle, 
  BookOpen, 
  Sparkles, 
  ChevronRight, 
  GraduationCap 
} from 'lucide-react';
import { getConfusionInsights, getTopConfusedPairs } from '../modules/interleaving/confusionMatrix';
import { cn } from '../lib/utils';

export interface MixedPracticeSessionProps {
  subject: string;
  currentChapterId: string;
  onClose?: () => void;
  onRewardXp?: (xp: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const MixedPracticeSession: React.FC<MixedPracticeSessionProps> = ({
  subject,
  currentChapterId,
  onClose,
  onRewardXp,
  showNotification
}) => {
  const sessionSize = 10;
  const {
    questions,
    currentIndex,
    setCurrentIndex,
    userAnswers,
    isSubmitted,
    isLoading,
    score,
    submitAnswer,
    finishSession,
    startNewSession
  } = useInterleavedPractice({
    subject,
    currentChapterId,
    sessionSize
  });

  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);
  const [confidenceRating, setConfidenceRating] = useState<ConfidenceRating>(3);

  // Active question
  const currentQuestion = questions[currentIndex];

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setShowExplanation(false);
      setConfidenceRating(3); // default for next question
    } else {
      // Grade session
      const finalScore = finishSession();
      if (finalScore !== undefined && onRewardXp) {
        const xpEarned = finalScore * 20 + 50; // 20 XP per correct answer + 50 completion bonus
        onRewardXp(xpEarned);
        if (showNotification) {
          showNotification(`Interleaved Practice Complete! Earned ${xpEarned} XP! 🎓`, 'success');
        }
      }
    }
  };

  const handleOptionSelect = (option: string) => {
    if (isSubmitted || showExplanation) return;
    setSelectedOption(option);
    submitAnswer(currentQuestion.id, option);
    setShowExplanation(true);

    // Record metacognition calibration
    if (currentQuestion) {
      saveCalibrationRecord({
        questionId: currentQuestion.id,
        topicId: currentQuestion.chapterId,
        topicTitle: currentQuestion.chapterTitle,
        subject,
        confidenceRating,
        isCorrect: option === currentQuestion.correctAnswer,
        timeSpent: 10,
        timestamp: new Date().toISOString()
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-400">
        <Brain className="w-12 h-12 animate-pulse text-indigo-500 mb-4" />
        <p className="text-sm font-medium">Calibrating cognitive boundaries and mixing questions...</p>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center text-slate-400">
        <BookOpen className="w-12 h-12 text-slate-600 mb-4" />
        <p className="text-sm font-medium mb-4">No practice questions available for this subject yet.</p>
        {onClose && (
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 text-slate-200 hover:bg-slate-750 rounded-lg text-sm transition"
          >
            Close Window
          </button>
        )}
      </div>
    );
  }

  // Session Results Screen
  if (isSubmitted) {
    const xpEarned = score * 20 + 50;
    const insights = getConfusionInsights();
    const topConfusions = getTopConfusedPairs(2);

    return (
      <div className="p-6 bg-slate-900 border border-slate-800/80 rounded-2xl max-w-2xl mx-auto shadow-2xl">
        <div className="text-center mb-8">
          <Trophy className="w-14 h-14 text-yellow-400 mx-auto mb-3 animate-bounce" />
          <h2 className="text-2xl font-black text-white tracking-tight">Practice Session Complete!</h2>
          <p className="text-slate-400 text-sm mt-1">Interleaved practice trains real exam retrieval strength</p>
        </div>

        {/* Score Card */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="p-4 bg-slate-800/55 border border-slate-700/30 rounded-xl text-center">
            <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">Accuracy</div>
            <div className="text-3xl font-black text-indigo-400 mt-1">{Math.round((score / questions.length) * 100)}%</div>
            <div className="text-xs text-slate-500 mt-0.5">{score} of {questions.length} correct</div>
          </div>
          <div className="p-4 bg-slate-800/55 border border-slate-700/30 rounded-xl text-center">
            <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">XP Awarded</div>
            <div className="text-3xl font-black text-emerald-400 mt-1">+{xpEarned}</div>
            <div className="text-xs text-slate-500 mt-0.5">Retrieved successfully</div>
          </div>
        </div>

        {/* Cognitive Insights & Confusion Matrix warnings */}
        <div className="mb-8">
          <h3 className="text-sm font-extrabold text-slate-200 mb-3 flex items-center gap-2">
            <Brain className="w-4 h-4 text-pink-500" />
            Clarity Cognitive Diagnostic Insights
          </h3>
          <div className="space-y-3">
            {topConfusions.length > 0 ? (
              topConfusions.map((pair, idx) => (
                <div key={idx} className="p-4 bg-red-950/20 border border-red-900/30 rounded-xl flex gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-black text-red-300 uppercase tracking-wider">Concept Confusion Active</h4>
                    <p className="text-xs text-slate-300 mt-1">
                      You are confusing <strong className="text-white">"{pair.topicA}"</strong> with <strong className="text-white">"{pair.topicB}"</strong>.
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      This was triggered {pair.confusionCount} times. Try taking a discrimination drill.
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 bg-emerald-950/20 border border-emerald-900/30 rounded-xl flex gap-3">
                <Sparkles className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-emerald-300 uppercase tracking-wider">Excellent Conceptual Discrimination</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    No active confusions found in this subject! Your cognitive boundaries are clean.
                  </p>
                </div>
              </div>
            )}

            {insights.length > 0 && insights[0] && (
              <div className="p-3 bg-indigo-950/10 border border-indigo-900/25 rounded-xl text-xs text-slate-400 leading-relaxed italic">
                💡 {insights[0]}
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <button
            onClick={startNewSession}
            className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-bold rounded-xl text-sm transition shadow-lg shadow-indigo-600/10 flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" /> Start Next Mixed Session
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="px-5 py-3 bg-slate-800 hover:bg-slate-750 active:bg-slate-850 text-slate-300 font-bold rounded-xl text-sm transition"
            >
              Done
            </button>
          )}
        </div>
      </div>
    );
  }

  const progressPercent = Math.round((currentIndex / questions.length) * 100);

  return (
    <div className="p-6 bg-slate-900/90 border border-slate-800 rounded-2xl max-w-2xl mx-auto shadow-2xl relative overflow-hidden">
      {/* Background flare */}
      <div className="absolute top-0 right-0 w-36 h-36 bg-indigo-500/5 blur-3xl rounded-full" />
      
      {/* Session Header */}
      <div className="flex justify-between items-center mb-5 pb-4 border-b border-slate-800/60">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-indigo-400" />
          <div>
            <h2 className="text-sm font-black text-white leading-none">Interleaved Practice</h2>
            <p className="text-[11px] text-slate-400 mt-0.5">Subject: {subject}</p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-[11px] bg-slate-800/80 border border-slate-700/30 text-indigo-400 px-2.5 py-1 rounded-full font-bold">
            60-25-15 Retainer
          </span>
        </div>
      </div>

      {/* Progress Indicator */}
      <div className="mb-6">
        <div className="flex justify-between text-xs text-slate-400 font-semibold mb-2">
          <span>Question {currentIndex + 1} of {questions.length}</span>
          <span>{progressPercent}% Complete</span>
        </div>
        <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Chapter Origin Hint - subtle & educational */}
      <div className="mb-4">
        <span className="text-[10px] text-slate-500 uppercase tracking-wider font-extrabold flex items-center gap-1.5">
          <BookOpen className="w-3.5 h-3.5 text-indigo-400/80" />
          Origin: {currentQuestion.chapterTitle}
        </span>
      </div>

      {/* Question Card */}
      <div className="p-5 bg-slate-800/30 border border-slate-700/20 rounded-xl mb-6">
        <h3 className="text-base font-bold text-white leading-snug">
          {currentQuestion.questionText}
        </h3>
        
        {/* If it is a discrimination question, make it prominent */}
        {currentQuestion.isDiscriminationQuestion && (
          <div className="mt-3 inline-flex items-center gap-1 bg-violet-950/40 border border-violet-800/30 px-2.5 py-1 rounded-md">
            <Target className="w-3 h-3 text-violet-400" />
            <span className="text-[10px] text-violet-300 font-bold uppercase tracking-wide">
              Cognitive Discrimination Challenge
            </span>
          </div>
        )}
      </div>

      {/* Confidence Rating Bar */}
      <ConfidenceInput 
        selectedRating={confidenceRating} 
        onSelectRating={setConfidenceRating} 
        disabled={showExplanation} 
        className="mb-4"
      />

      {/* Options */}
      <div className="space-y-2.5 mb-6">
        {currentQuestion.options.map((option, idx) => {
          const isSelected = selectedOption === option;
          const isCorrect = option === currentQuestion.correctAnswer;
          const hasAnswered = showExplanation;

          let btnStyle = "bg-slate-850/50 border-slate-850 hover:bg-slate-800 hover:border-slate-700/80 text-slate-300";
          if (isSelected) btnStyle = "bg-indigo-950/20 border-indigo-500/80 text-white ring-1 ring-indigo-500/40";

          if (hasAnswered) {
            if (isCorrect) {
              btnStyle = "bg-emerald-950/30 border-emerald-500/80 text-emerald-200 font-medium";
            } else if (isSelected) {
              btnStyle = "bg-red-950/30 border-red-500/80 text-red-200";
            } else {
              btnStyle = "bg-slate-900/20 border-slate-900 text-slate-500 opacity-60";
            }
          }

          return (
            <button
              key={idx}
              onClick={() => handleOptionSelect(option)}
              disabled={hasAnswered}
              className={cn(
                "w-full p-4 border rounded-xl text-left text-sm transition-all flex items-center justify-between",
                btnStyle
              )}
            >
              <span>{option}</span>
              {hasAnswered && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 ml-2" />}
              {hasAnswered && isSelected && !isCorrect && <XCircle className="w-4 h-4 text-red-400 shrink-0 ml-2" />}
            </button>
          );
        })}
      </div>

      {/* Post-Answer Socratic Explanation */}
      {showExplanation && (
        <div className="p-4 bg-slate-800/45 border border-slate-700/35 rounded-xl mb-6 text-xs text-slate-300 leading-relaxed animate-fadeIn">
          <div className="font-extrabold text-white text-xs mb-1.5 flex items-center gap-1.5 text-indigo-400">
            <Brain className="w-4 h-4" />
            Concept tested: {currentQuestion.conceptTested}
          </div>
          <div className="mb-2">
            <span className="font-semibold text-white">Solution: </span>
            {currentQuestion.solution}
          </div>
          {currentQuestion.discriminationTarget && (
            <div className="p-2.5 bg-violet-950/20 border border-violet-900/20 rounded-lg text-[11px] text-slate-400 italic">
              ⭐ <strong>Boundary training:</strong> This teaches you to distinguish between <span className="text-white font-semibold">"{currentQuestion.conceptTested}"</span> and <span className="text-white font-semibold">"{currentQuestion.discriminationTarget}"</span>.
            </div>
          )}
        </div>
      )}

      {/* Controller Area */}
      {showExplanation && (
        <button
          onClick={handleNext}
          className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-bold rounded-xl text-sm transition shadow-lg shadow-indigo-600/10 flex items-center justify-center gap-2"
        >
          {currentIndex < questions.length - 1 ? (
            <>Next Question <ArrowRight className="w-4 h-4" /></>
          ) : (
            <>Finish & Grade Practice <ChevronRight className="w-4 h-4" /></>
          )}
        </button>
      )}
    </div>
  );
};
