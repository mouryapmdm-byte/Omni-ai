import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Zap,
  Trash2,
  Volume2,
  VolumeX,
  Target,
  CloudRain,
  Activity,
  Sliders,
  X,
  Radio,
  Play,
  Maximize2,
  Minimize2,
  ShieldCheck,
  Compass,
  Layers,
  Flame,
  HelpCircle,
  RotateCcw,
  Music
} from 'lucide-react';
import {
  nanoBananaPhysics,
  GravityPreset,
  PhysicsSimulationStats,
  BANANA_PHYSICS_MATERIALS,
  BananaPhysicsMaterial
} from '@/src/services/nanoBananaPhysicsEngine';

interface NanoBananaPhysicsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTossFromCamera: (speed: number) => void;
  onTossAtTarget: (target: 'smartboard' | 'teacher_desk' | 'lab_bench' | 'center_floor') => void;
  onSpawnRain: (count: number) => void;
  onExplosionForce: () => void;
  onClearAll: () => void;
}

export const NanoBananaPhysicsModal: React.FC<NanoBananaPhysicsModalProps> = ({
  isOpen,
  onClose,
  onTossFromCamera,
  onTossAtTarget,
  onSpawnRain,
  onExplosionForce,
  onClearAll
}) => {
  const [gravity, setGravity] = useState<GravityPreset>('earth');
  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('organic_standard');
  const [scale, setScale] = useState<number>(1.0);
  const [launchSpeed, setLaunchSpeed] = useState<number>(14);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [lastAudioFeedback, setLastAudioFeedback] = useState<string>('Idle');
  const [stats, setStats] = useState<PhysicsSimulationStats>({
    count: 0,
    totalCollisions: 0,
    maxSpeed: 0,
    totalKineticEnergy: 0,
    gravityPreset: 'earth',
    gravityY: -9.8,
    activeCollidersCount: 34,
    activeMaterialName: 'Standard Nano Banana (Organic Ripe)'
  });

  // Poll real-time physics telemetry and listen to collision events
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setStats(nanoBananaPhysics.getStats());
    }, 120);

    const unsubscribe = nanoBananaPhysics.onCollision((event) => {
      const icon = event.soundType === 'clink' ? '🔔' : event.soundType === 'thud' ? '🪵' : '🫧';
      setLastAudioFeedback(`${icon} ${event.soundType.toUpperCase()} on ${event.colliderName} (${event.impactSpeed.toFixed(1)} m/s)`);
    });

    return () => {
      clearInterval(interval);
      unsubscribe();
    };
  }, [isOpen]);

  const handleGravityChange = (newGravity: GravityPreset) => {
    setGravity(newGravity);
    nanoBananaPhysics.setGravityPreset(newGravity);
  };

  const handleMaterialChange = (matId: string) => {
    setSelectedMaterialId(matId);
    nanoBananaPhysics.setPhysicsMaterial(matId);
  };

  const handleScaleChange = (val: number) => {
    setScale(val);
    nanoBananaPhysics.setScale(val);
  };

  const handleSoundToggle = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    nanoBananaPhysics.setSoundEnabled(next);
  };

  const testAudioSound = (soundType: 'thud' | 'clink' | 'pop') => {
    nanoBananaPhysics.playCollisionAudio(12, soundType === 'clink' ? 'metal' : soundType === 'thud' ? 'wood' : 'organic', soundType);
    setLastAudioFeedback(`🔊 Tested ${soundType.toUpperCase()} Audio Cue`);
  };

  if (!isOpen) return null;

  const currentMaterial = BANANA_PHYSICS_MATERIALS[selectedMaterialId] || BANANA_PHYSICS_MATERIALS.organic_standard;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-amber-500/30 rounded-3xl max-w-xl w-full p-4 sm:p-6 shadow-2xl shadow-amber-500/10 space-y-4 sm:space-y-5 relative max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 sm:pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 shadow-inner">
              <span className="text-xl">🍌</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-bold text-white">Nano Banana Physics Material &amp; Audio Lab</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Audio &amp; Bounciness
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-400">
                Physics material friction, restitution, and subtle &apos;thud&apos; / &apos;clink&apos; audio feedback
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            aria-label="Close Physics Lab"
          >
            <X size={18} />
          </button>
        </div>

        {/* Live Telemetry & Audio Feedback Status */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-center">
          <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Active Bananas</div>
            <div className="text-lg font-black text-amber-400 flex items-center justify-center gap-1">
              <span>🍌</span>
              <span>{stats.count}</span>
            </div>
          </div>
          <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Collisions</div>
            <div className="text-lg font-black text-emerald-400">
              {stats.totalCollisions}
            </div>
          </div>
          <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Max Speed</div>
            <div className="text-lg font-black text-sky-400">
              {stats.maxSpeed} <span className="text-[10px] text-slate-400 font-normal">m/s</span>
            </div>
          </div>
          <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Kinetic Energy</div>
            <div className="text-lg font-black text-purple-400">
              {stats.totalKineticEnergy} <span className="text-[10px] text-slate-400 font-normal">J</span>
            </div>
          </div>
        </div>

        {/* Live Audio Collision Telemetry Feedback Banner */}
        <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-indigo-950/40 border border-indigo-500/30 text-xs">
          <div className="flex items-center gap-2 text-indigo-300">
            <Volume2 size={15} className="text-indigo-400 shrink-0" />
            <span className="font-semibold text-slate-300">Live Audio Dispatch:</span>
            <span className="font-mono text-indigo-200 text-[11px] truncate max-w-[280px]">
              {lastAudioFeedback}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => testAudioSound('thud')}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-amber-300 font-bold border border-slate-700 cursor-pointer"
              title="Test Wooden / Floor Thud"
            >
              🪵 Thud
            </button>
            <button
              onClick={() => testAudioSound('clink')}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-sky-300 font-bold border border-slate-700 cursor-pointer"
              title="Test Metallic / Glass Clink"
            >
              🔔 Clink
            </button>
          </div>
        </div>

        {/* Physics Material Selection */}
        <div className="space-y-2">
          <label className="text-xs font-black uppercase text-amber-400/90 tracking-wider flex items-center justify-between">
            <span>Banana 3D Physics Material</span>
            <span className="text-[11px] font-normal text-slate-400 font-mono">
              Bounciness: {Math.round(currentMaterial.restitution * 100)}% | Friction: {Math.round(currentMaterial.friction * 100)}%
            </span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {Object.values(BANANA_PHYSICS_MATERIALS).map((mat) => {
              const isSelected = selectedMaterialId === mat.id;
              return (
                <button
                  key={mat.id}
                  onClick={() => handleMaterialChange(mat.id)}
                  className={`p-2.5 rounded-2xl text-left transition-all border cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-500/80 shadow-md shadow-amber-500/10 text-white'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-amber-300">{mat.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                      e={mat.restitution}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-tight mb-2">
                    {mat.description}
                  </p>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                    <span>Bounce: <strong className="text-emerald-400">{Math.round(mat.restitution * 100)}%</strong></span>
                    <span>•</span>
                    <span>Friction: <strong className="text-sky-400">{Math.round(mat.friction * 100)}%</strong></span>
                    <span>•</span>
                    <span>Sound: <strong className="text-purple-300">{mat.soundProfile}</strong></span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Quick Launch & Interaction Actions */}
        <div className="space-y-2">
          <label className="text-xs font-black uppercase text-amber-400/90 tracking-wider flex items-center justify-between">
            <span>Launch &amp; Collision Actions</span>
            <span className="text-[11px] font-normal text-slate-400">Press &apos;B&apos; in 3D scene to quick-toss</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            <button
              onClick={() => onTossFromCamera(launchSpeed)}
              className="p-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/20 active:scale-95 transition-transform cursor-pointer"
            >
              <span>🚀</span>
              <span>Toss From Camera</span>
            </button>

            <button
              onClick={() => onSpawnRain(8)}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 border border-amber-500/30 active:scale-95 transition-all cursor-pointer"
            >
              <CloudRain size={14} className="text-sky-400" />
              <span>Banana Rain (x8)</span>
            </button>

            <button
              onClick={onExplosionForce}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 border border-rose-500/30 active:scale-95 transition-all cursor-pointer"
            >
              <Zap size={14} className="text-rose-400" />
              <span>Shockwave Blast</span>
            </button>

            <button
              onClick={() => onTossAtTarget('smartboard')}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 text-xs flex items-center justify-center gap-1.5 border border-slate-700 active:scale-95 transition-all cursor-pointer"
            >
              <Target size={13} className="text-emerald-400" />
              <span>Target: Smartboard</span>
            </button>

            <button
              onClick={() => onTossAtTarget('teacher_desk')}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 text-xs flex items-center justify-center gap-1.5 border border-slate-700 active:scale-95 transition-all cursor-pointer"
            >
              <Target size={13} className="text-indigo-400" />
              <span>Target: Teacher Desk</span>
            </button>

            <button
              onClick={() => onTossAtTarget('lab_bench')}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 text-xs flex items-center justify-center gap-1.5 border border-slate-700 active:scale-95 transition-all cursor-pointer"
            >
              <Target size={13} className="text-purple-400" />
              <span>Target: Lab Bench</span>
            </button>
          </div>
        </div>

        {/* Gravity Presets */}
        <div className="space-y-2">
          <label className="text-xs font-black uppercase text-slate-400 tracking-wider">
            Planetary Gravity Environment
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
            {[
              { id: 'earth', label: 'Earth', g: '9.8 m/s²', emoji: '🌍' },
              { id: 'moon', label: 'Moon', g: '1.6 m/s²', emoji: '🌙' },
              { id: 'mars', label: 'Mars', g: '3.7 m/s²', emoji: '🔴' },
              { id: 'zero_g', label: 'Zero-G', g: '0 m/s²', emoji: '🛸' },
              { id: 'heavy', label: 'Heavy', g: '22 m/s²', emoji: '🪐' },
              { id: 'inverted', label: 'Inverted', g: '-9.8 m/s²', emoji: '🙃' },
            ].map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleGravityChange(preset.id as GravityPreset)}
                className={`p-2 rounded-xl flex flex-col items-center text-center transition-all cursor-pointer border ${
                  gravity === preset.id
                    ? 'bg-amber-500/20 border-amber-500/60 text-amber-300 font-bold shadow-sm'
                    : 'bg-slate-800/50 border-slate-700/50 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <span className="text-sm">{preset.emoji}</span>
                <span className="text-[11px] mt-0.5">{preset.label}</span>
                <span className="text-[9px] opacity-60 font-mono">{preset.g}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Material Scale & Launch Parameters */}
        <div className="space-y-3 p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300">
            <span className="flex items-center gap-1.5">
              <Sliders size={14} className="text-amber-400" />
              <span>Rigid-Body Simulation Parameters</span>
            </span>
            <button
              onClick={handleSoundToggle}
              className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-semibold border transition-colors cursor-pointer ${
                soundEnabled
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {soundEnabled ? <Volume2 size={12} /> : <VolumeX size={12} />}
              <span>{soundEnabled ? 'Collision Audio On' : 'Muted'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {/* Scale */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>Banana Size / Scale:</span>
                <span className="font-mono text-amber-400 font-bold">{scale.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.2"
                step="0.1"
                value={scale}
                onChange={(e) => handleScaleChange(parseFloat(e.target.value))}
                className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Launch Speed */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>Toss Launch Velocity:</span>
                <span className="font-mono text-amber-400 font-bold">{launchSpeed} m/s</span>
              </div>
              <input
                type="range"
                min="8"
                max="30"
                step="1"
                value={launchSpeed}
                onChange={(e) => setLaunchSpeed(parseInt(e.target.value))}
                className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Classroom Colliders Status Footnote */}
        <div className="p-3 rounded-2xl bg-slate-950/40 border border-slate-800 text-[11px] text-slate-400 space-y-1">
          <div className="font-semibold text-slate-300 flex items-center gap-1.5">
            <ShieldCheck size={13} className="text-emerald-400" />
            <span>Active Physical Colliders &amp; Acoustic Profiles:</span>
          </div>
          <p className="leading-relaxed">
            • <strong>Wood / Soft Surfaces</strong> (Floor, Teacher Desk, Student Desks, Chairs, Podium): Generates warm, velocity-scaled &apos;thud&apos; acoustic feedback.<br />
            • <strong>Metal / Glass / Screen</strong> (Smartboard, Laptop, Newton Cradle, Microscope, Flasks): Generates crisp &apos;clink&apos; harmonic ping.<br />
            • <strong>Banana-to-Banana</strong>: Inter-body momentum exchange and soft rubbery pop.
          </p>
        </div>

        {/* Footer Buttons */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <button
            onClick={onClearAll}
            className="px-3 py-2 rounded-xl bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Trash2 size={14} />
            <span>Clear All Bananas ({stats.count})</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
