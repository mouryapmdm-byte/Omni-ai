const fs = require('fs');
const file = 'src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

const targetStr = `      const imageRequestMatch = response.match(/<DRAW_IMAGE>(.*?)<\\/DRAW_IMAGE>/is);
      if (imageRequestMatch) {
        const prompt = imageRequestMatch[1].trim();
        imageUrl = await handleGenerateMedia(prompt, 'image');`;

const newStr = `      let mathGraphFunctions: string[] | undefined = undefined;
      const imageRequestMatch = response.match(/<DRAW_IMAGE>(.*?)<\\/DRAW_IMAGE>/is);
      if (imageRequestMatch) {
        const prompt = imageRequestMatch[1].trim();
        
        const isGraph = prompt.toLowerCase().includes('graph') || prompt.toLowerCase().includes('plot');
        const funcMatches = [...prompt.matchAll(/(?:f\\(x\\)|g\\(x\\)|h\\(x\\)|y)\\s*=\\s*([a-zA-Z0-9_\\-\\+\\*\\/\\^\\(\\)\\.\\s]+?)(?:\\s+and|\\s+on|\\s+with|$)/gi)].map(m => m[1].trim());
        
        if (isGraph && funcMatches.length > 0) {
            mathGraphFunctions = funcMatches;
        } else if (isGraph) {
            const possible = prompt.match(/Graph of\\s+([a-zA-Z0-9_\\-\\+\\*\\/\\^\\(\\)\\.\\s]+?)\\s+(?:and|with|on)/i);
            if (possible && possible[1]) {
                mathGraphFunctions = [possible[1].trim()];
            } else if (prompt.includes('x^') || prompt.includes('x**')) {
                const eqMatch = prompt.match(/([a-zA-Z0-9_\\-\\+\\*\\/\\^\\(\\)\\.\\s]+)/);
                if (eqMatch) mathGraphFunctions = [eqMatch[1].trim()];
            }
        }
        
        if (mathGraphFunctions && mathGraphFunctions.length > 0) {
            console.log("Graph detected: ", mathGraphFunctions);
        } else {
            imageUrl = await handleGenerateMedia(prompt, 'image');
        }`;

content = content.replace(targetStr, newStr);

const oldMsgStr = `      const newMsgId = generateId('msg_');
      const msg: Message = {
        id: newMsgId,
        content: finalContent,
        sender: 'ai',
        timestamp: Date.now(),
        metadata: {
          image: imageUrl,
          video: videoUrl,
          annotations: annotations.length > 0 ? annotations : undefined
        }
      };`;

const newMsgStr = `      const newMsgId = generateId('msg_');
      const msg: Message = {
        id: newMsgId,
        content: finalContent,
        sender: 'ai',
        timestamp: Date.now(),
        metadata: {
          image: imageUrl,
          video: videoUrl,
          annotations: annotations.length > 0 ? annotations : undefined,
          mathGraphFunctions: mathGraphFunctions
        }
      };`;

content = content.replace(oldMsgStr, newMsgStr);

fs.writeFileSync(file, content);
