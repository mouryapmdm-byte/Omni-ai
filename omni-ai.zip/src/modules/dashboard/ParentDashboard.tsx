import React from 'react';

export const ParentDashboard: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-bold text-white">Parent Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
          <h3 className="text-lg font-semibold text-white">Weekly Progress</h3>
          <p className="text-slate-400">Chapters: 5 | Hours: 12.5 | Avg Score: 88%</p>
        </div>
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
          <h3 className="text-lg font-semibold text-white">Weak Areas</h3>
          <ul className="text-slate-400 list-disc list-inside">
            <li>Quadratic Equations</li>
            <li>Vectors</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
