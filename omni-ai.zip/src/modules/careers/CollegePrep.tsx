import React, { useState } from 'react';
import { 
  collegePrepDatabase, College 
} from './careerDatabase';
import { 
  GraduationCap, Award, MapPin, Landmark, BookOpen, Star, Sparkles, Compass, CheckCircle2, DollarSign, Search, Filter, HelpCircle, ArrowUpRight
} from 'lucide-react';

export const CollegePrep: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [selectedCollege, setSelectedCollege] = useState<College>(collegePrepDatabase[0]);
  const [searchQuery, setSearchQuery] = useState('');

  // Scholarship filter interactive utility state
  const [userGpa, setUserGpa] = useState<number>(3.9);
  const [familyIncome, setFamilyIncome] = useState<number>(65000);
  const [olympiadAward, setOlympiadAward] = useState<boolean>(true);
  const [matchingScholarships, setMatchingScholarships] = useState<any[]>([]);
  const [showScholarshipResults, setShowScholarshipResults] = useState(false);

  // Active exam prep tracker tab
  const [activeExamTab, setActiveExamTab] = useState<'sat' | 'jee' | 'mcat' | 'ap_calc'>('sat');

  const filteredColleges = collegePrepDatabase.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Core scholarship matching algorithm, satisfying College Prep requirements (Requirement 5)
  const calculateScholarshipMatches = () => {
    const list: any[] = [];
    
    collegePrepDatabase.forEach(college => {
      college.notableScholarships.forEach(sch => {
        let isEligible = true;
        let reasons: string[] = [];

        // Custom heuristic matches
        if (sch.eligibility.toLowerCase().includes('income < $75k')) {
          if (familyIncome >= 75000) {
            isEligible = false;
            reasons.push("Family income exceeds the low-income threshold ($75k).");
          } else {
            reasons.push("Meets low-income family target requirements.");
          }
        }
        if (sch.eligibility.toLowerCase().includes('olympiad')) {
          if (!olympiadAward) {
            isEligible = false;
            reasons.push("Requires high chemistry/physics olympiad participation.");
          } else {
            reasons.push("Olympiad or research paper portfolio verified.");
          }
        }
        if (college.requiredGpa > userGpa) {
          isEligible = false;
          reasons.push(`Your GPA (${userGpa}) is slightly below college benchmark (${college.requiredGpa}).`);
        } else {
          reasons.push("Meets or exceeds academic GPA target benchmarks.");
        }

        list.push({
          collegeName: college.name,
          scholarshipName: sch.name,
          amount: sch.amount,
          eligibility: sch.eligibility,
          isEligible,
          reasons: reasons.length > 0 ? reasons : ["General STEM profile match."]
        });
      });
    });

    // Sort matching ones first
    const sorted = list.sort((a, b) => (b.isEligible ? 1 : 0) - (a.isEligible ? 1 : 0));
    setMatchingScholarships(sorted);
    setShowScholarshipResults(true);
  };

  return (
    <div className="space-y-6">
      
      {/* College prep intro header */}
      <div className="flex flex-col lg:flex-row gap-4 items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-xl">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search elite international engineering campuses, GPAs, or location coordinates..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 placeholder:text-slate-600 font-medium"
          />
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono shrink-0 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl">
          <GraduationCap className="w-4 h-4 text-sky-500 animate-pulse" />
          <span>Higher Education Prep Tracker Suite</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left selection list */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-3xl space-y-4 shadow-xl">
            <div className="space-y-1">
              <span className="text-xs text-slate-400 uppercase tracking-widest font-mono">Select Campus</span>
              <h4 className="text-sm font-bold text-white">STEM Target Colleges</h4>
            </div>

            <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
              {filteredColleges.map((college, idx) => {
                const active = selectedCollege.name === college.name;
                return (
                  <div
                    key={idx}
                    onClick={() => setSelectedCollege(college)}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                      active
                        ? 'bg-indigo-950/20 border-indigo-500 shadow-md shadow-indigo-500/5'
                        : 'bg-slate-950 border-slate-950 hover:border-slate-800'
                    }`}
                  >
                    <div className="space-y-1">
                      <h5 className="text-xs font-bold text-white">{college.name}</h5>
                      <div className="flex items-center gap-1 text-[10px] text-slate-500 font-medium">
                        <MapPin className="w-3.5 h-3.5 text-slate-600" />
                        <span className="truncate">{college.location}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active Entrance Exam Milestones Helper */}
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-3xl space-y-4 shadow-xl">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Exam Milestones</span>
              <h4 className="text-sm font-bold text-white">Entrance Preparation Blueprint</h4>
            </div>

            {/* Micro Tabs */}
            <div className="grid grid-cols-4 bg-slate-950 p-1 rounded-xl border border-slate-850">
              {['sat', 'jee', 'mcat', 'ap_calc'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveExamTab(tab as any)}
                  className={`text-[9px] font-bold py-1.5 rounded uppercase font-mono ${
                    activeExamTab === tab ? 'bg-indigo-500 text-white shadow' : 'text-slate-400'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="bg-slate-950/60 border border-slate-850 p-3 rounded-2xl space-y-2 text-xs">
              {activeExamTab === 'sat' && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-mono text-indigo-400 font-bold block uppercase">SAT Math Threshold: 780-800</span>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    Requires rapid precision across algebraic vectors, quadratic polynomial intercepts, and complex numbers coordinates.
                  </p>
                  <span className="text-[9px] font-semibold text-emerald-400 block">✓ Formula Tip: Cartesian slopes m = (y2 - y1) / (x2 - x1)</span>
                </div>
              )}
              {activeExamTab === 'jee' && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-mono text-indigo-400 font-bold block uppercase">JEE Advanced Prep Rank &lt; 500</span>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    Exposes massive mechanics problems. Practice resolving multi-joint dynamic tension force vectors and thermodynamic cycles.
                  </p>
                  <span className="text-[9px] font-semibold text-emerald-400 block">✓ Formula Tip: Carnot Efficiency = 1 - (Tc / Th)</span>
                </div>
              )}
              {activeExamTab === 'mcat' && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-mono text-indigo-400 font-bold block uppercase">MCAT Bio-Chemistry Target</span>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    Focuses on enzyme inhibitor pathways, protein configuration vectors, and cell replication carrying capacity.
                  </p>
                  <span className="text-[9px] font-semibold text-emerald-400 block">✓ Formula Tip: Michaelis-Menten Kinetics: v = (Vmax * [S]) / (Km + [S])</span>
                </div>
              )}
              {activeExamTab === 'ap_calc' && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-mono text-indigo-400 font-bold block uppercase">AP Calculus BC Score: 5 Target</span>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    Master integration parts, Taylor polynomial expansions, and Euler numerical step approximation limits.
                  </p>
                  <span className="text-[9px] font-semibold text-emerald-400 block">✓ Formula Tip: Euler Step: y(n+1) = y(n) + h * f(x(n), y(n))</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Details Panel */}
        {selectedCollege && (
          <div className="lg:col-span-2 space-y-6">
            
            {/* College info summary */}
            <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 space-y-6 shadow-2xl relative overflow-hidden">
              <div className="absolute right-0 top-0 w-32 h-32 bg-sky-500/5 rounded-full blur-3xl pointer-events-none"></div>

              <div className="border-b border-slate-800/80 pb-5 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-mono text-sky-400 bg-sky-950/40 border border-sky-900/60 px-2.5 py-1 rounded-xl w-fit">
                  <Landmark className="w-3.5 h-3.5" />
                  <span>Verified Top Tier Program</span>
                </div>
                <h3 className="text-2xl font-extrabold text-white tracking-tight">{selectedCollege.name}</h3>
                <p className="text-xs text-slate-400 font-medium">Located in {selectedCollege.location}</p>
              </div>

              {/* GPA & Score benchmarks */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 border border-slate-850 p-4 rounded-2xl space-y-1">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block tracking-wider">Average GPA Benchmark</span>
                  <span className="text-lg font-extrabold text-white block">{selectedCollege.requiredGpa} / 4.0</span>
                  <span className="text-[9px] text-slate-400 block">Requires near-perfect high school transcript marks</span>
                </div>

                <div className="bg-slate-900 border border-slate-850 p-4 rounded-2xl space-y-1">
                  <span className="text-[10px] font-mono text-slate-500 uppercase block tracking-wider">AP/IB Prerequisites</span>
                  <span className="text-lg font-extrabold text-white block">Top 1.5% percentile</span>
                  <span className="text-[9px] text-slate-400 block">Exceptional grades in Physics, Chemistry, Calculus</span>
                </div>
              </div>

              {/* Entry requirements */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Recommended Course Prerequisites</span>
                <div className="space-y-2">
                  {selectedCollege.entryRequirements.map((req, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 bg-slate-900/40 p-3 rounded-xl border border-slate-850 text-xs text-slate-300 font-medium">
                      <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
                      <span>{req}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Scholarships opportunities */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Active Scholarship Programs</span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedCollege.notableScholarships.map((sch, idx) => (
                    <div key={idx} className="bg-slate-900 border border-slate-850 p-4 rounded-2xl space-y-2.5 flex flex-col justify-between">
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest block">Award: {sch.amount}</span>
                        <h5 className="text-xs font-extrabold text-white">{sch.name}</h5>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-normal italic bg-slate-950/60 p-2.5 rounded-xl border border-slate-850">
                        "Eligibility: {sch.eligibility}"
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Scholarship eligibility calculator panel */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl">
              <div className="space-y-1">
                <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest block">Interactive Tool</span>
                <h4 className="text-lg font-extrabold text-white flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-400 animate-pulse" />
                  Scholarship Eligibility Matcher
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed max-w-xl">
                  Compare your personal criteria (current high school GPA, estimated annual family income, and extra-curricular project status) against the verified database.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 uppercase tracking-wider font-mono font-bold block">Your Current GPA</label>
                  <input
                    type="number"
                    step="0.05"
                    min="2.0"
                    max="4.0"
                    value={userGpa}
                    onChange={(e) => setUserGpa(parseFloat(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 uppercase tracking-wider font-mono font-bold block">Household Income ($/Yr)</label>
                  <input
                    type="number"
                    step="5000"
                    min="10000"
                    value={familyIncome}
                    onChange={(e) => setFamilyIncome(parseInt(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 uppercase tracking-wider font-mono font-bold block">STEM Portfolio</label>
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="checkbox"
                      id="olympiad_check"
                      checked={olympiadAward}
                      onChange={(e) => setOlympiadAward(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-500 bg-slate-950 border-slate-800 accent-emerald-500 cursor-pointer"
                    />
                    <label htmlFor="olympiad_check" className="text-xs text-slate-300 font-semibold cursor-pointer">
                      Olympiad / Research Paper
                    </label>
                  </div>
                </div>
              </div>

              <button
                onClick={calculateScholarshipMatches}
                className="bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-2.5 px-6 rounded-xl text-xs transition shadow-lg shrink-0 flex items-center gap-1.5"
              >
                <Compass className="w-3.5 h-3.5" />
                Analyze Database Scholarship Matches
              </button>

              {showScholarshipResults && (
                <div className="space-y-3 pt-3 border-t border-slate-800/80">
                  <span className="text-xs font-bold text-slate-300 block">Analysis Matching Results:</span>
                  <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                    {matchingScholarships.map((match, idx) => (
                      <div 
                        key={idx} 
                        className={`p-3 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs ${
                          match.isEligible 
                            ? 'bg-emerald-950/10 border-emerald-500/40 text-slate-200' 
                            : 'bg-slate-950 border-slate-850 text-slate-400'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-extrabold text-white text-[11px]">{match.scholarshipName}</span>
                            <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-900/60 px-1.5 py-0.5 rounded uppercase font-bold">
                              {match.amount}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-500 font-semibold block">{match.collegeName}</span>
                          
                          {/* Reasoning logs */}
                          <div className="space-y-0.5 pt-1">
                            {match.reasons.map((r: string, rIdx: number) => (
                              <span key={rIdx} className="text-[9px] text-slate-400 block font-medium leading-normal">
                                • {r}
                              </span>
                            ))}
                          </div>
                        </div>

                        <span className={`text-[10px] font-mono font-bold uppercase px-2.5 py-1 rounded-xl border shrink-0 w-fit ${
                          match.isEligible 
                            ? 'bg-emerald-950/40 border-emerald-800 text-emerald-400' 
                            : 'bg-red-950/10 border-red-900/40 text-red-400'
                        }`}>
                          {match.isEligible ? "Matching" : "Ineligible"}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
