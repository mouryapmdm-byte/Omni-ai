import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  Map,
  Brain,
  Sparkles,
  Search,
  Filter,
  Layers,
  Zap,
  Activity,
  Maximize2,
  Minimize2,
  Copy,
  Check,
  Play,
  Pause,
  RotateCcw,
  FastForward,
  Download,
  Share2,
  Award,
  AlertTriangle,
  Lightbulb,
  Compass,
  FileText,
  Clock,
  Eye,
  Sliders,
  Radio,
  ChevronRight,
  ChevronLeft,
  Sun,
  Droplets,
  Wind,
  Leaf,
  ShieldCheck,
  Send,
  HelpCircle,
  TrendingUp,
  Cpu,
  RefreshCw,
  Box,
  CornerDownRight,
  Grid
} from 'lucide-react';
import { cn } from '../lib/utils';
import {
  VisualMapType,
  SchematicTechnique,
  SubsystemType,
  VisualMapNode,
  VisualMapEdge,
  VisualMapPackage,
  SchematicBreakdownModel,
  SchematicComponentPart
} from '../types/visualMap';
import { visualMapDataService, CURATED_VISUAL_MAP_PACKAGES } from '../services/visualMapDataService';
import { InteractiveSchematicCanvas } from './InteractiveSchematicCanvas';

interface VisualMapStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicTitle?: string;
  subjectTitle?: string;
  theme?: 'light' | 'dark' | string;
  onDeliverToSmartboard?: (contentMarkdown: string, topicTitle: string) => void;
  onSpeak?: (text: string) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const VisualMapStudioModal: React.FC<VisualMapStudioModalProps> = ({
  isOpen,
  onClose,
  topicTitle = "Electromagnetic Induction & Faraday's Laws",
  subjectTitle = 'Physics / Electrodynamics',
  theme = 'dark',
  onDeliverToSmartboard,
  onSpeak,
  showNotification
}) => {
  // Navigation & Mode
  const [activeTab, setActiveTab] = useState<'visual_maps' | 'schematic_breakdown' | 'progressive_build' | 'exam_matrix' | 'real_world'>('visual_maps');
  const [selectedMapType, setSelectedMapType] = useState<VisualMapType>('concept_map');
  const [selectedTechnique, setSelectedTechnique] = useState<SchematicTechnique>('exploded_view');

  // Package Data
  const [currentPackage, setCurrentPackage] = useState<VisualMapPackage | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSubsystemFilter, setSelectedSubsystemFilter] = useState<SubsystemType | 'all'>('all');

  // Interactive Node Selection
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedPartId, setSelectedPartId] = useState<string | null>(null);

  // Schematic Controls
  const [explodedRatio, setExplodedRatio] = useState<number>(0.6); // 0.0 to 1.0
  const [layerDepthIndex, setLayerDepthIndex] = useState<number>(1); // 0 (outer), 1 (mid), 2 (core)
  const [cutawaySlicePosition, setCutawaySlicePosition] = useState<number>(50); // 0 to 100%
  const [isGhostXRayActive, setIsGhostXRayActive] = useState<boolean>(false);
  const [isFlowAnimationActive, setIsFlowAnimationActive] = useState<boolean>(true);
  const [assemblyStepIndex, setAssemblyStepIndex] = useState<number>(2);

  // Progressive Revelation Player
  const [currentRevelationStep, setCurrentRevelationStep] = useState<number>(0);
  const [isPlayingRevelation, setIsPlayingRevelation] = useState<boolean>(false);
  const [revelationSpeedMs, setRevelationSpeedMs] = useState<number>(4500);

  // Zoom & Pan
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Load package on open or topic change
  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    setIsLoading(true);

    visualMapDataService.getVisualMapPackage(topicTitle, subjectTitle)
      .then(pkg => {
        if (isMounted) {
          setCurrentPackage(pkg);
          if (pkg.preferredType) {
            setSelectedMapType(pkg.preferredType);
          }
          if (pkg.nodes && pkg.nodes.length > 0) {
            setSelectedNodeId(pkg.nodes[0].id);
          }
          if (pkg.schematicModel?.sections?.[0]?.components?.[0]) {
            setSelectedPartId(pkg.schematicModel.sections[0].components[0].id);
          }
          setIsLoading(false);
        }
      })
      .catch(err => {
        console.error('Error fetching visual map package:', err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, topicTitle, subjectTitle]);

  // Progressive Revelation Timer
  useEffect(() => {
    if (!isPlayingRevelation || !currentPackage?.revelationSteps?.length) return;

    const timer = setInterval(() => {
      setCurrentRevelationStep(prev => {
        const next = prev + 1;
        if (next >= currentPackage.revelationSteps.length) {
          setIsPlayingRevelation(false);
          return prev;
        }
        const step = currentPackage.revelationSteps[next];
        if (step?.spokenExplanation && onSpeak) {
          onSpeak(step.spokenExplanation);
        }
        return next;
      });
    }, revelationSpeedMs);

    return () => clearInterval(timer);
  }, [isPlayingRevelation, currentPackage, revelationSpeedMs, onSpeak]);

  // Handle Play/Pause Revelation
  const togglePlayRevelation = () => {
    if (!isPlayingRevelation) {
      setIsPlayingRevelation(true);
      const step = currentPackage?.revelationSteps?.[currentRevelationStep];
      if (step?.spokenExplanation && onSpeak) {
        onSpeak(step.spokenExplanation);
      }
    } else {
      setIsPlayingRevelation(false);
    }
  };

  // Deliver to Smartboard Action
  const handleDeliverToSmartboard = () => {
    if (!currentPackage) return;

    let markdown = `# 🗺️ Human Visual Blueprint & Schematic Walkthrough: ${currentPackage.topic}\n\n`;
    markdown += `> 🗣️ **Professor Clarity's Human Guide**: "${currentPackage.summary}"\n\n`;
    markdown += `---\n\n`;
    markdown += `### 🌟 1. Step-by-Step Visual Concept Flow (Built for Humans)\n\n`;

    currentPackage.nodes.forEach((node, i) => {
      markdown += `#### 📍 Step ${i + 1}: ${node.label}\n`;
      markdown += `- **🗣️ Plain-English Explanation**: ${node.description}\n`;
      if (node.everydayLifeAnalogy) markdown += `- **☕ Everyday Human Metaphor**: *"${node.everydayLifeAnalogy}"*\n`;
      if (node.examWeightageMarks) markdown += `- **🎯 Why It Matters & Exam Value**: **${node.examWeightageMarks} Marks** ${node.isHighWeightage ? '⭐ [MUST MASTER FOR EXAMS]' : ''}\n`;
      if (node.commonMistakeWarning) markdown += `- ⚠️ **Golden Student Trap to Avoid**: ${node.commonMistakeWarning}\n\n`;
    });

    if (currentPackage.schematicModel) {
      markdown += `\n---\n### 🔬 2. Human Schematic Breakdown (How Parts Work Together in Real Life)\n\n`;
      markdown += `> *${currentPackage.schematicModel.overviewDescription}*\n\n`;
      currentPackage.schematicModel.sections.forEach(sec => {
        markdown += `#### 🛠️ Section [${sec.sectionLetter}] — ${sec.name} (${sec.subsystem.replace('_', ' ').toUpperCase()})\n`;
        markdown += `> *${sec.summary}*\n\n`;
        sec.components.forEach(comp => {
          markdown += `- **[${comp.sectionCode}] ${comp.name}**: ${comp.workingFunction}\n`;
          if (comp.operatingPrinciple) markdown += `  - 💡 *Human Metaphor & Principle*: ${comp.operatingPrinciple}\n`;
          if (comp.failureMode) markdown += `  - ⚠️ *What Happens If Broken?*: ${comp.failureMode.systemicConsequence}\n`;
          if (comp.examMarkingTip) markdown += `  - 🎯 *Exam Key*: ${comp.examMarkingTip}\n`;
        });
        markdown += `\n`;
      });
    }

    if (onDeliverToSmartboard) {
      onDeliverToSmartboard(markdown, currentPackage.topic);
      showNotification?.(`Delivered Human Visual Map & Schematic for "${currentPackage.topic}" to 3D Smartboard!`, 'success');
      onClose();
    }
  };

  // Copy Blueprint
  const handleCopyBlueprint = () => {
    if (!currentPackage) return;
    const jsonStr = JSON.stringify(currentPackage, null, 2);
    navigator.clipboard.writeText(jsonStr).then(() => {
      setIsCopied(true);
      showNotification?.('Visual Map blueprint JSON copied to clipboard!', 'info');
      setTimeout(() => setIsCopied(false), 2000);
    });
  };

  // Filtered nodes
  const filteredNodes = useMemo(() => {
    if (!currentPackage?.nodes) return [];
    return currentPackage.nodes.filter(n => {
      const matchesSearch = !searchQuery || 
        n.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.category?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesSubsystem = selectedSubsystemFilter === 'all' || n.subsystem === selectedSubsystemFilter;
      return matchesSearch && matchesSubsystem;
    });
  }, [currentPackage, searchQuery, selectedSubsystemFilter]);

  // Active selected node
  const activeNode = useMemo(() => {
    return currentPackage?.nodes?.find(n => n.id === selectedNodeId) || currentPackage?.nodes?.[0];
  }, [currentPackage, selectedNodeId]);

  // Active selected schematic part
  const activePart = useMemo(() => {
    if (!currentPackage?.schematicModel?.sections) return null;
    for (const sec of currentPackage.schematicModel.sections) {
      const found = sec.components.find(c => c.id === selectedPartId);
      if (found) return { part: found, section: sec };
    }
    return null;
  }, [currentPackage, selectedPartId]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-7xl h-[92vh] flex flex-col bg-slate-900 border-2 border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden text-slate-100">
        
        {/* TOP HEADER BAR */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 bg-slate-950/90 border-b border-cyan-500/30 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 text-white shadow-md shadow-cyan-500/20">
              <Map size={22} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded-full border border-cyan-500/30">
                  Professor Clarity • Visual Learning Architect
                </span>
                <span className="text-[10px] font-bold text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-500/30">
                  8 Map Engines + 8 Schematic Deconstructors
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2 mt-0.5">
                {currentPackage?.title || topicTitle}
              </h3>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleDeliverToSmartboard}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center gap-1.5 cursor-pointer"
              title="Deliver this complete visual map to the 3D Classroom Smartboard"
            >
              <Send size={14} />
              Deliver to Smartboard
            </button>

            <button
              onClick={handleCopyBlueprint}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all border border-slate-700 flex items-center gap-1.5 cursor-pointer"
              title="Copy JSON Blueprint"
            >
              {isCopied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              {isCopied ? 'Copied' : 'Copy JSON'}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-red-900/60 text-slate-400 hover:text-red-200 transition-colors border border-slate-700 cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* PRIMARY NAVIGATION TABS */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-slate-950/60 border-b border-slate-800 overflow-x-auto shrink-0 select-none">
          <button
            onClick={() => setActiveTab('visual_maps')}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer",
              activeTab === 'visual_maps'
                ? "bg-cyan-600 text-white shadow-md shadow-cyan-600/30"
                : "bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            )}
          >
            <Brain size={15} />
            8 Visual Map Types
          </button>

          <button
            onClick={() => setActiveTab('schematic_breakdown')}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer",
              activeTab === 'schematic_breakdown'
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            )}
          >
            <Sliders size={15} />
            Schematic Breakdown & 8 Techniques
          </button>

          <button
            onClick={() => setActiveTab('progressive_build')}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer",
              activeTab === 'progressive_build'
                ? "bg-purple-600 text-white shadow-md shadow-purple-600/30"
                : "bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            )}
          >
            <Sparkles size={15} />
            Progressive Map Revelation
          </button>

          <button
            onClick={() => setActiveTab('exam_matrix')}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer",
              activeTab === 'exam_matrix'
                ? "bg-amber-600 text-white shadow-md shadow-amber-600/30"
                : "bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            )}
          >
            <Award size={15} />
            Exam Weightage & Marking Matrix
          </button>

          <button
            onClick={() => setActiveTab('real_world')}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer",
              activeTab === 'real_world'
                ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                : "bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            )}
          >
            <TrendingUp size={15} />
            Real-World Connections & Careers
          </button>
        </div>

        {/* MAIN BODY WORKSPACE */}
        <div className="flex-1 min-h-0 flex flex-col md:flex-row overflow-hidden">
          
          {/* LEFT SIDEBAR: FILTERS & MAP TYPE SELECTOR */}
          <div className="w-full md:w-72 bg-slate-950/70 border-r border-slate-800 p-3.5 flex flex-col gap-3 overflow-y-auto shrink-0">
            
            {/* Search Input */}
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search concepts, axioms, specs..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X size={12} />
                </button>
              )}
            </div>

            {/* If in Visual Maps Tab: 8 Map Type Selector */}
            {activeTab === 'visual_maps' && (
              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Grid size={12} className="text-cyan-400" />
                  Select Visual Map Engine
                </span>
                <div className="grid grid-cols-1 gap-1.5">
                  {[
                    { type: 'concept_map' as VisualMapType, label: '1. Concept Map', desc: 'Inputs, Catalysts, Outputs & Hierarchy', icon: Brain },
                    { type: 'mind_map' as VisualMapType, label: '2. Mind Map', desc: 'Radiating Branches & Memory Anchors', icon: Sparkles },
                    { type: 'flowchart' as VisualMapType, label: '3. Flowchart', desc: 'Step-by-Step State Transitions', icon: FastForward },
                    { type: 'venn_diagram' as VisualMapType, label: '4. Venn Diagram', desc: 'Comparative Overlapping Dualisms', icon: Layers },
                    { type: 'hierarchy' as VisualMapType, label: '5. Hierarchy Tree', desc: 'Taxonomic Parent-Child Classification', icon: Box },
                    { type: 'cycle' as VisualMapType, label: '6. Closed Cycle', desc: 'Thermodynamic & Bio Loops', icon: RotateCcw },
                    { type: 'timeline' as VisualMapType, label: '7. Epoch Timeline', desc: 'Chronological Historical Discovery', icon: Clock },
                    { type: 'cause_effect' as VisualMapType, label: '8. Cause-Effect Map', desc: 'Input Triggers & Output Consequences', icon: Activity }
                  ].map(m => {
                    const IconComp = m.icon;
                    const isSelected = selectedMapType === m.type;
                    return (
                      <button
                        key={m.type}
                        onClick={() => setSelectedMapType(m.type)}
                        className={cn(
                          "p-2 rounded-xl text-left transition-all border flex items-start gap-2.5 cursor-pointer",
                          isSelected
                            ? "bg-cyan-950/80 border-cyan-500 text-cyan-200 shadow-sm"
                            : "bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-200"
                        )}
                      >
                        <div className={cn(
                          "p-1.5 rounded-lg shrink-0 mt-0.5",
                          isSelected ? "bg-cyan-600 text-white" : "bg-slate-800 text-slate-400"
                        )}>
                          <IconComp size={14} />
                        </div>
                        <div className="overflow-hidden">
                          <h6 className="text-xs font-bold leading-tight">{m.label}</h6>
                          <p className="text-[10px] opacity-70 truncate">{m.desc}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* If in Schematic Tab: 8 Breakdown Techniques Selector */}
            {activeTab === 'schematic_breakdown' && (
              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Sliders size={12} className="text-indigo-400" />
                  Schematic Deconstruction Technique
                </span>
                <div className="grid grid-cols-1 gap-1.5">
                  {[
                    { id: 'exploded_view' as SchematicTechnique, label: '1. Exploded View', desc: 'Separate parts outward with guide lines' },
                    { id: 'layered_reveal' as SchematicTechnique, label: '2. Layered Reveal', desc: 'Peel outer shell to expose inner core' },
                    { id: 'section_cutaway' as SchematicTechnique, label: '3. Section Cutaway', desc: 'Interactive slice cutting plane anatomy' },
                    { id: 'ghost_view' as SchematicTechnique, label: '4. Ghost X-Ray', desc: 'Transparent outer shell visualization' },
                    { id: 'annotated_breakdown' as SchematicTechnique, label: '5. Annotated Callouts', desc: 'Dimensions, materials & specifications' },
                    { id: 'interactive_parts' as SchematicTechnique, label: '6. Part Assembly Mode', desc: 'Step-by-step interactive assembly' },
                    { id: 'color_coded_systems' as SchematicTechnique, label: '7. Subsystem Colors', desc: 'Electrical, Fluid, Thermal, Logic' },
                    { id: 'connection_mapping' as SchematicTechnique, label: '8. Particle Flow Map', desc: 'Trace dynamic matter/energy paths' }
                  ].map(tech => {
                    const isSelected = selectedTechnique === tech.id;
                    return (
                      <button
                        key={tech.id}
                        onClick={() => setSelectedTechnique(tech.id)}
                        className={cn(
                          "p-2 rounded-xl text-left transition-all border flex flex-col gap-0.5 cursor-pointer",
                          isSelected
                            ? "bg-indigo-950/80 border-indigo-500 text-indigo-200 shadow-sm"
                            : "bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-200"
                        )}
                      >
                        <span className="text-xs font-bold">{tech.label}</span>
                        <span className="text-[10px] opacity-70 leading-tight">{tech.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Subsystem Color Legend */}
            <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2 mt-auto">
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                Subsystem Coding
              </span>
              <div className="grid grid-cols-2 gap-1.5 text-[10px] font-semibold">
                <div className="flex items-center gap-1.5 text-red-400">
                  <span className="w-2 h-2 rounded-full bg-red-500" /> Electrical
                </div>
                <div className="flex items-center gap-1.5 text-cyan-400">
                  <span className="w-2 h-2 rounded-full bg-cyan-500" /> Fluid / Ion
                </div>
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" /> Control Logic
                </div>
                <div className="flex items-center gap-1.5 text-amber-400">
                  <span className="w-2 h-2 rounded-full bg-amber-500" /> Thermal / Energy
                </div>
              </div>
            </div>

          </div>

          {/* CENTER VIEWPORT: CANVAS & INTERACTIVE RENDERING */}
          <div className="flex-1 flex flex-col bg-slate-950 min-h-0 overflow-y-auto p-4 md:p-6 relative">
            
            {/* Viewport Control Bar */}
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-cyan-400 bg-cyan-950/60 px-2.5 py-1 rounded-lg border border-cyan-800/60">
                  Active View: {activeTab === 'visual_maps' ? selectedMapType.toUpperCase() : activeTab.toUpperCase()}
                </span>
                <span className="text-xs text-slate-400">
                  {currentPackage?.nodes?.length || 0} Nodes • {currentPackage?.edges?.length || 0} Dynamic Connectors
                </span>
              </div>

              {/* Zoom and Animation Toggles */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsFlowAnimationActive(prev => !prev)}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 cursor-pointer",
                    isFlowAnimationActive
                      ? "bg-cyan-950 border-cyan-500 text-cyan-300"
                      : "bg-slate-900 border-slate-800 text-slate-500"
                  )}
                >
                  <Activity size={12} className={isFlowAnimationActive ? "animate-spin" : ""} />
                  {isFlowAnimationActive ? "Live Flow ON" : "Flow Paused"}
                </button>

                <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setZoomLevel(prev => Math.max(0.7, prev - 0.15))}
                    className="px-2 py-1 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
                  >
                    -
                  </button>
                  <span className="px-2 text-[10px] font-mono text-cyan-400">{Math.round(zoomLevel * 100)}%</span>
                  <button
                    onClick={() => setZoomLevel(prev => Math.min(1.6, prev + 0.15))}
                    className="px-2 py-1 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* TAB 1: 8 VISUAL MAP TYPES RENDERING */}
            {activeTab === 'visual_maps' && (
              <div 
                className="flex-1 flex flex-col items-center justify-center transition-transform duration-200"
                style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'top center' }}
              >
                
                {/* 1. CONCEPT MAP VIEW */}
                {selectedMapType === 'concept_map' && (
                  <div className="w-full max-w-4xl space-y-6">
                    {/* Top Inputs Layer */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {filteredNodes.filter(n => n.level === 1 || n.category?.toLowerCase().includes('input')).map(node => (
                        <div
                          key={node.id}
                          onClick={() => setSelectedNodeId(node.id)}
                          className={cn(
                            "p-3.5 rounded-2xl border-2 transition-all cursor-pointer relative",
                            selectedNodeId === node.id
                              ? "bg-amber-950/60 border-amber-400 shadow-lg shadow-amber-500/20 scale-[1.03]"
                              : "bg-slate-900/80 border-slate-800 hover:border-amber-500/50"
                          )}
                        >
                          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                            <span className="text-[10px] font-black uppercase text-amber-400">
                              Input Layer
                            </span>
                            {node.isHighWeightage && (
                              <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 flex items-center gap-0.5">
                                ⭐ {node.examWeightageMarks}M
                              </span>
                            )}
                          </div>
                          <h5 className="text-sm font-black text-white mt-2">{node.label}</h5>
                          <p className="text-[11px] text-slate-300 mt-1 leading-snug">{node.subtitle || node.description}</p>
                        </div>
                      ))}
                    </div>

                    {/* Dynamic Flow Arrows Down */}
                    <div className="flex items-center justify-center gap-12 py-1">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="flex flex-col items-center">
                          <div className={cn(
                            "w-1 h-8 bg-gradient-to-b from-amber-500 to-emerald-500",
                            isFlowAnimationActive ? "animate-pulse" : ""
                          )} />
                          <ChevronRight size={14} className="rotate-90 text-emerald-400 -mt-1" />
                        </div>
                      ))}
                    </div>

                    {/* Central Catalytic Engine */}
                    {filteredNodes.filter(n => n.level === 2 || n.category?.toLowerCase().includes('engine') || n.shape === 'hexagon').map(node => (
                      <div
                        key={node.id}
                        onClick={() => setSelectedNodeId(node.id)}
                        className={cn(
                          "p-5 rounded-2xl border-2 transition-all cursor-pointer relative bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80",
                          selectedNodeId === node.id
                            ? "border-emerald-400 shadow-xl shadow-emerald-500/20 scale-[1.02]"
                            : "border-emerald-800/80 hover:border-emerald-400"
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black uppercase tracking-wider text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded-lg border border-emerald-500/40">
                            Core Transformation Engine
                          </span>
                          <span className="text-xs font-mono text-emerald-300">
                            ⭐ High Weightage ({node.examWeightageMarks || 5} Marks)
                          </span>
                        </div>
                        <h4 className="text-lg font-black text-white mt-2">{node.label}</h4>
                        <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">{node.description}</p>
                      </div>
                    ))}

                    {/* Dynamic Flow Arrows Down to Outputs */}
                    <div className="flex items-center justify-center gap-16 py-1">
                      {[1, 2].map(i => (
                        <div key={i} className="flex flex-col items-center">
                          <div className={cn(
                            "w-1 h-8 bg-gradient-to-b from-emerald-500 to-cyan-500",
                            isFlowAnimationActive ? "animate-pulse" : ""
                          )} />
                          <ChevronRight size={14} className="rotate-90 text-cyan-400 -mt-1" />
                        </div>
                      ))}
                    </div>

                    {/* Bottom Outputs Layer */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {filteredNodes.filter(n => n.level === 3 || n.category?.toLowerCase().includes('product') || n.category?.toLowerCase().includes('output')).map(node => (
                        <div
                          key={node.id}
                          onClick={() => setSelectedNodeId(node.id)}
                          className={cn(
                            "p-3.5 rounded-2xl border-2 transition-all cursor-pointer relative",
                            selectedNodeId === node.id
                              ? "bg-cyan-950/60 border-cyan-400 shadow-lg shadow-cyan-500/20 scale-[1.03]"
                              : "bg-slate-900/80 border-slate-800 hover:border-cyan-500/50"
                          )}
                        >
                          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                            <span className="text-[10px] font-black uppercase text-cyan-400">
                              Yield & Byproduct
                            </span>
                            {node.isHighWeightage && (
                              <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-cyan-500 text-slate-950">
                                ⭐ {node.examWeightageMarks}M
                              </span>
                            )}
                          </div>
                          <h5 className="text-sm font-black text-white mt-2">{node.label}</h5>
                          <p className="text-[11px] text-slate-300 mt-1 leading-snug">{node.subtitle || node.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 2. MIND MAP VIEW */}
                {selectedMapType === 'mind_map' && (
                  <div className="w-full max-w-4xl flex flex-col items-center justify-center p-4">
                    {/* Central Brain Core */}
                    <div className="p-6 rounded-3xl bg-gradient-to-tr from-purple-900 via-indigo-950 to-cyan-900 border-2 border-purple-400 shadow-2xl text-center max-w-md relative">
                      <div className="w-12 h-12 mx-auto rounded-2xl bg-purple-500/20 text-purple-300 flex items-center justify-center border border-purple-400/40 mb-2">
                        <Brain size={26} className="animate-pulse" />
                      </div>
                      <span className="text-[10px] font-black uppercase text-purple-300 tracking-wider">
                        Central Mind Anchor
                      </span>
                      <h4 className="text-lg font-black text-white mt-1">{currentPackage?.title}</h4>
                      <p className="text-xs text-purple-200/80 mt-1 leading-relaxed">{currentPackage?.summary}</p>
                    </div>

                    {/* Radiating Branches */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 w-full mt-6">
                      {filteredNodes.map((node, i) => (
                        <div
                          key={node.id}
                          onClick={() => setSelectedNodeId(node.id)}
                          className={cn(
                            "p-3.5 rounded-2xl border-2 transition-all cursor-pointer relative",
                            selectedNodeId === node.id
                              ? "bg-purple-950/70 border-purple-400 shadow-lg shadow-purple-500/20 scale-[1.03]"
                              : "bg-slate-900/80 border-slate-800 hover:border-purple-500/50"
                          )}
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 text-xs font-black flex items-center justify-center border border-purple-500/30">
                              {i + 1}
                            </span>
                            <h5 className="text-xs font-black text-white truncate">{node.label}</h5>
                          </div>
                          <p className="text-[11px] text-slate-300 mt-2 line-clamp-2 leading-relaxed">{node.description}</p>
                          {node.everydayLifeAnalogy && (
                            <div className="text-[10px] text-purple-300 bg-purple-950/40 p-1.5 rounded-lg border border-purple-800/40 mt-2 italic">
                              💡 {node.everydayLifeAnalogy}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. FLOWCHART VIEW */}
                {selectedMapType === 'flowchart' && (
                  <div className="w-full max-w-3xl space-y-4">
                    {filteredNodes.map((node, idx) => (
                      <div key={node.id} className="flex flex-col items-center">
                        <div
                          onClick={() => setSelectedNodeId(node.id)}
                          className={cn(
                            "w-full p-4 rounded-2xl border-2 transition-all cursor-pointer relative flex items-center justify-between gap-4",
                            selectedNodeId === node.id
                              ? "bg-indigo-950/80 border-indigo-400 shadow-lg shadow-indigo-500/20 scale-[1.02]"
                              : "bg-slate-900/80 border-slate-800 hover:border-indigo-500/50"
                          )}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-indigo-600/30 text-indigo-300 flex items-center justify-center font-black text-sm border border-indigo-500/40">
                              {idx + 1}
                            </div>
                            <div>
                              <span className="text-[10px] font-black uppercase text-indigo-400">
                                Step {idx + 1} • {node.category || 'Process'}
                              </span>
                              <h5 className="text-sm font-bold text-white">{node.label}</h5>
                              <p className="text-xs text-slate-300 mt-0.5">{node.description}</p>
                            </div>
                          </div>
                          {node.isHighWeightage && (
                            <span className="px-2 py-1 rounded bg-amber-500 text-slate-950 text-[10px] font-black shrink-0">
                              ⭐ {node.examWeightageMarks}M
                            </span>
                          )}
                        </div>

                        {idx < filteredNodes.length - 1 && (
                          <div className="flex flex-col items-center my-1.5">
                            <div className="w-0.5 h-6 bg-indigo-500 animate-pulse" />
                            <ChevronRight size={14} className="rotate-90 text-indigo-400 -mt-1" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* 4. VENN DIAGRAM VIEW */}
                {selectedMapType === 'venn_diagram' && currentPackage?.vennData && (
                  <div className="w-full max-w-4xl space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {currentPackage.vennData.map(set => (
                        <div
                          key={set.id}
                          className="p-4 rounded-2xl bg-slate-900/80 border-2 border-cyan-500/40 space-y-3"
                        >
                          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: set.color }} />
                            <h5 className="text-sm font-black text-white">{set.title}</h5>
                          </div>
                          <div className="space-y-1.5">
                            <span className="text-[10px] font-black uppercase text-cyan-400">Unique Traits:</span>
                            {set.uniqueTraits.map((trait, tIdx) => (
                              <div key={tIdx} className="text-xs text-slate-300 flex items-start gap-2 bg-slate-950/60 p-2 rounded-xl border border-slate-800">
                                <span className="text-cyan-400 font-bold">•</span>
                                <span>{trait}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Shared Intersection Traits Box */}
                    {currentPackage.vennData[0]?.sharedTraitsWithOtherSets?.[0] && (
                      <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/80 via-purple-950/80 to-indigo-950/80 border-2 border-purple-500/50 space-y-2">
                        <div className="flex items-center gap-2">
                          <Layers size={16} className="text-purple-400" />
                          <h5 className="text-sm font-black text-white">Shared Co-Dependent Traits & Intersections</h5>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {currentPackage.vennData[0].sharedTraitsWithOtherSets[0].sharedTraits.map((s, sIdx) => (
                            <div key={sIdx} className="text-xs text-purple-200 bg-purple-950/50 p-2 rounded-xl border border-purple-700/50">
                              ✨ {s}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 5. HIERARCHY TREE VIEW */}
                {selectedMapType === 'hierarchy' && (
                  <div className="w-full max-w-4xl space-y-4">
                    <div className="p-4 rounded-2xl bg-slate-900 border-2 border-cyan-500/50 text-center max-w-md mx-auto">
                      <span className="text-[10px] font-black uppercase text-cyan-400">Root Node</span>
                      <h4 className="text-base font-black text-white mt-1">{currentPackage?.topic}</h4>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {filteredNodes.map(node => (
                        <div
                          key={node.id}
                          onClick={() => setSelectedNodeId(node.id)}
                          className={cn(
                            "p-3 rounded-xl border-2 transition-all cursor-pointer relative",
                            selectedNodeId === node.id
                              ? "bg-cyan-950 border-cyan-400 shadow-md scale-[1.02]"
                              : "bg-slate-900 border-slate-800 hover:border-cyan-500/50"
                          )}
                        >
                          <span className="text-[10px] font-bold text-cyan-400 uppercase">Sub-Branch</span>
                          <h5 className="text-xs font-bold text-white mt-1">{node.label}</h5>
                          <p className="text-[11px] text-slate-300 mt-1">{node.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 6. CLOSED CYCLE VIEW */}
                {selectedMapType === 'cycle' && (
                  <div className="w-full max-w-3xl flex flex-col items-center justify-center p-4">
                    <div className="relative w-80 h-80 rounded-full border-4 border-dashed border-emerald-500/40 flex items-center justify-center animate-spin-slow">
                      <div className="absolute inset-0 rounded-full border-2 border-emerald-500/20" />
                    </div>
                    <div className="absolute grid grid-cols-2 gap-8 max-w-xl">
                      {filteredNodes.slice(0, 4).map((node, i) => (
                        <div
                          key={node.id}
                          onClick={() => setSelectedNodeId(node.id)}
                          className={cn(
                            "p-3 rounded-2xl border-2 transition-all cursor-pointer bg-slate-900/90 shadow-xl",
                            selectedNodeId === node.id ? "border-emerald-400 scale-105" : "border-slate-800"
                          )}
                        >
                          <span className="text-[10px] font-black text-emerald-400 uppercase">Phase {i + 1}</span>
                          <h5 className="text-xs font-bold text-white">{node.label}</h5>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 7. TIMELINE VIEW */}
                {selectedMapType === 'timeline' && currentPackage?.timelineEvents && (
                  <div className="w-full max-w-4xl space-y-3">
                    {currentPackage.timelineEvents.map((evt, idx) => (
                      <div
                        key={evt.id}
                        className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 transition-all flex flex-col sm:flex-row gap-4"
                      >
                        <div className="sm:w-32 shrink-0 flex flex-col justify-center border-b sm:border-b-0 sm:border-r border-slate-800 pb-2 sm:pb-0">
                          <span className="text-sm font-black text-amber-400 font-mono">{evt.yearOrEpoch}</span>
                          <span className="text-xs font-bold text-slate-300 mt-0.5">{evt.scientistOrEntity}</span>
                        </div>
                        <div className="space-y-1">
                          <h5 className="text-sm font-black text-white">{evt.title}</h5>
                          <p className="text-xs text-slate-300 leading-relaxed">{evt.discoverySummary}</p>
                          <div className="text-[10px] text-amber-300/80 pt-1 font-semibold flex items-center gap-1">
                            <Award size={12} /> Exam Context: {evt.examRelevance}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 8. CAUSE-EFFECT VIEW */}
                {selectedMapType === 'cause_effect' && currentPackage?.causeEffectPairs && (
                  <div className="w-full max-w-4xl space-y-3">
                    {currentPackage.causeEffectPairs.map((pair) => (
                      <div
                        key={pair.id}
                        className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4"
                      >
                        <div className="p-3 rounded-xl bg-slate-950/80 border border-red-500/30 space-y-1">
                          <span className="text-[10px] font-black uppercase text-red-400">Trigger Cause</span>
                          <h5 className="text-xs font-black text-white">{pair.cause}</h5>
                          <p className="text-[11px] text-slate-300 leading-snug">{pair.intermediateMechanism}</p>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/30 space-y-1">
                          <span className="text-[10px] font-black uppercase text-emerald-400">Resulting Effect</span>
                          <h5 className="text-xs font-black text-white">{pair.effect}</h5>
                          {pair.examTrapWarning && (
                            <p className="text-[10px] text-amber-300 bg-amber-950/40 p-1.5 rounded-lg border border-amber-800/40 mt-1">
                              ⚠️ {pair.examTrapWarning}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

              </div>
            )}

            {/* TAB 2: SCHEMATIC BREAKDOWN RENDERING */}
            {activeTab === 'schematic_breakdown' && currentPackage?.schematicModel && (
              <div className="w-full max-w-5xl space-y-6">
                
                {/* 1. Dynamic Vector SVG Schematic Blueprint & Interactive Canvas */}
                <InteractiveSchematicCanvas
                  schematicModel={currentPackage.schematicModel}
                  selectedTechnique={selectedTechnique}
                  selectedPartId={selectedPartId}
                  onSelectPart={(partId) => setSelectedPartId(partId)}
                  explodedRatio={explodedRatio}
                  layerDepthIndex={layerDepthIndex}
                  cutawaySlicePosition={cutawaySlicePosition}
                  isGhostXRayActive={isGhostXRayActive}
                  isFlowAnimationActive={isFlowAnimationActive}
                  selectedSubsystemFilter={selectedSubsystemFilter}
                  onSpeak={onSpeak}
                />

                {/* 2. Interactive Technique Fine-Tuning Controls */}
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-indigo-500/40 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                        <Sliders size={14} />
                        Active Technique: {selectedTechnique.replace('_', ' ').toUpperCase()}
                      </span>
                    </div>

                    {/* Exploded Ratio Slider */}
                    {selectedTechnique === 'exploded_view' && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-400 font-bold">Explode Distance:</span>
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step="0.05"
                          value={explodedRatio}
                          onChange={(e) => setExplodedRatio(parseFloat(e.target.value))}
                          className="w-36 accent-indigo-500 cursor-pointer"
                        />
                        <span className="text-xs font-mono text-indigo-300 font-bold">{Math.round(explodedRatio * 100)}%</span>
                      </div>
                    )}

                    {/* Cutaway Position Slider */}
                    {selectedTechnique === 'section_cutaway' && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-400 font-bold">Slice Depth:</span>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={cutawaySlicePosition}
                          onChange={(e) => setCutawaySlicePosition(parseInt(e.target.value))}
                          className="w-36 accent-pink-500 cursor-pointer"
                        />
                        <span className="text-xs font-mono text-pink-300 font-bold">{cutawaySlicePosition}%</span>
                      </div>
                    )}

                    {/* Layer Selector */}
                    {selectedTechnique === 'layered_reveal' && (
                      <div className="flex items-center gap-1.5">
                        {['Outer Shell (0)', 'Internal Layer (1)', 'Core Matrix (2)'].map((l, lIdx) => (
                          <button
                            key={lIdx}
                            onClick={() => setLayerDepthIndex(lIdx)}
                            className={cn(
                              "px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer",
                              layerDepthIndex === lIdx
                                ? "bg-indigo-600 text-white shadow-md"
                                : "bg-slate-800 text-slate-400 hover:text-white"
                            )}
                          >
                            {l}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* 3. Detailed Architectural Sections & Component Breakdown List */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                      <Layers size={14} className="text-indigo-400" />
                      Detailed Section & Component Hierarchy
                    </span>
                    <span className="text-xs text-slate-400">
                      Click any component to inspect specifications
                    </span>
                  </div>

                  {currentPackage.schematicModel.sections.map(section => (
                    <div
                      key={section.id}
                      className="p-4 rounded-2xl bg-slate-900/80 border-2 border-slate-800 hover:border-indigo-500/50 transition-all space-y-3"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white text-xs font-black flex items-center justify-center">
                            {section.sectionLetter}
                          </span>
                          <h4 className="text-sm font-black text-white">{section.name}</h4>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-indigo-400 border border-slate-800 uppercase font-bold">
                          {section.subsystem}
                        </span>
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed">{section.summary}</p>

                      {/* Component Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pt-2">
                        {section.components.map(comp => {
                          const isSelected = selectedPartId === comp.id;
                          return (
                            <div
                              key={comp.id}
                              onClick={() => setSelectedPartId(comp.id)}
                              className={cn(
                                "p-3 rounded-xl border-2 transition-all cursor-pointer relative flex flex-col justify-between gap-2",
                                isSelected
                                  ? "bg-indigo-950 border-indigo-400 shadow-md scale-[1.02]"
                                  : "bg-slate-950/80 border-slate-800 hover:border-indigo-500/40"
                              )}
                              style={{
                                transform: selectedTechnique === 'exploded_view'
                                  ? `translate(${comp.explodedOffsetX * explodedRatio * 0.5}px, ${comp.explodedOffsetY * explodedRatio * 0.5}px)`
                                  : undefined,
                                opacity: selectedTechnique === 'layered_reveal' && comp.layerIndex > layerDepthIndex ? 0.3 : 1.0
                              }}
                            >
                              <div>
                                <div className="flex items-center justify-between">
                                  <span className="text-[10px] font-mono text-indigo-400 font-bold">[{comp.sectionCode}]</span>
                                  <span className="text-[9px] text-slate-400">Layer {comp.layerIndex}</span>
                                </div>
                                <h5 className="text-xs font-bold text-white mt-1 leading-snug">{comp.name}</h5>
                                <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">{comp.workingFunction}</p>
                              </div>

                              {comp.materialOrSpec && (
                                <div className="text-[9px] text-slate-500 truncate pt-1 border-t border-slate-800/80 font-mono">
                                  {comp.materialOrSpec}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                {/* 4. Overall System Flow & Matter/Energy Transfer Path */}
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
                  <span className="text-xs font-black uppercase text-indigo-400 tracking-wider flex items-center gap-1.5">
                    🔄 Overall System Flow & Energy Path
                  </span>
                  <div className="space-y-1.5">
                    {currentPackage.schematicModel.overallSystemFlow.map(flow => (
                      <div key={flow.stepNumber} className="text-xs text-slate-300 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3 flex-wrap">
                        <span><strong>Step {flow.stepNumber}:</strong> {flow.sourceSection} → {flow.destinationSection} ({flow.actionDescription})</span>
                        <span className="text-[10px] text-indigo-300 font-mono bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/50">
                          {flow.energyOrMatterTransferred}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* TAB 3: PROGRESSIVE REVELATION PLAYER */}
            {activeTab === 'progressive_build' && currentPackage?.revelationSteps && (
              <div className="w-full max-w-3xl space-y-6">
                <div className="p-6 rounded-3xl bg-slate-900 border-2 border-purple-500/40 text-center space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider text-purple-400">
                      Progressive Step {currentRevelationStep + 1} of {currentPackage.revelationSteps.length}
                    </span>
                    <span className="text-xs text-slate-400">Synchronized Spoken Pedagogy</span>
                  </div>

                  <h3 className="text-lg font-black text-white">
                    {currentPackage.revelationSteps[currentRevelationStep]?.title}
                  </h3>

                  <div className="p-4 rounded-2xl bg-purple-950/60 border border-purple-800/60 text-sm text-purple-100 italic leading-relaxed">
                    "{currentPackage.revelationSteps[currentRevelationStep]?.spokenExplanation}"
                  </div>

                  {/* Player Controls */}
                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => setCurrentRevelationStep(prev => Math.max(0, prev - 1))}
                      disabled={currentRevelationStep === 0}
                      className="p-2.5 rounded-xl bg-slate-800 text-white disabled:opacity-30 cursor-pointer"
                    >
                      <ChevronLeft size={18} />
                    </button>

                    <button
                      onClick={togglePlayRevelation}
                      className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-purple-600/30 cursor-pointer"
                    >
                      {isPlayingRevelation ? <Pause size={18} /> : <Play size={18} />}
                      {isPlayingRevelation ? 'Pause Revelation' : 'Play Animated Lecture'}
                    </button>

                    <button
                      onClick={() => setCurrentRevelationStep(prev => Math.min(currentPackage.revelationSteps.length - 1, prev + 1))}
                      disabled={currentRevelationStep === currentPackage.revelationSteps.length - 1}
                      className="p-2.5 rounded-xl bg-slate-800 text-white disabled:opacity-30 cursor-pointer"
                    >
                      <ChevronRight size={18} />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: EXAM WEIGHTAGE & MARKING MATRIX */}
            {activeTab === 'exam_matrix' && (
              <div className="w-full max-w-4xl space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentPackage?.nodes?.map(node => (
                    <div
                      key={node.id}
                      className="p-4 rounded-2xl bg-slate-900 border border-amber-500/30 space-y-3"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                        <h5 className="text-sm font-black text-white">{node.label}</h5>
                        <span className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-black text-xs">
                          {node.examWeightageMarks || 2} Marks
                        </span>
                      </div>

                      {node.markingSchemePoints && node.markingSchemePoints.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[10px] font-black uppercase text-amber-400">Marking Scheme Checklist:</span>
                          {node.markingSchemePoints.map((pt, pIdx) => (
                            <div key={pIdx} className="text-xs text-slate-300 flex items-start gap-1.5">
                              <Check size={12} className="text-emerald-400 shrink-0 mt-0.5" />
                              <span>{pt}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {node.commonMistakeWarning && (
                        <div className="p-2.5 rounded-xl bg-red-950/50 border border-red-800/60 text-xs text-red-200">
                          ⚠️ <strong>Common Exam Trap:</strong> {node.commonMistakeWarning}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 5: REAL-WORLD CONNECTIONS */}
            {activeTab === 'real_world' && (
              <div className="w-full max-w-4xl space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentPackage?.nodes?.map(node => (
                    <div
                      key={node.id}
                      className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/30 space-y-3"
                    >
                      <h5 className="text-sm font-black text-white pb-2 border-b border-slate-800">{node.label}</h5>

                      {node.realWorldApplications && node.realWorldApplications.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[10px] font-black uppercase text-emerald-400">Industrial & Engineering Uses:</span>
                          {node.realWorldApplications.map((app, aIdx) => (
                            <div key={aIdx} className="text-xs text-slate-300 bg-slate-950 p-2 rounded-xl border border-slate-800">
                              🚀 {app}
                            </div>
                          ))}
                        </div>
                      )}

                      {node.everydayLifeAnalogy && (
                        <div className="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-800/60 text-xs text-emerald-200 italic">
                          💡 <strong>Daily Life Analogy:</strong> {node.everydayLifeAnalogy}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* RIGHT SIDEBAR: COMPREHENSIVE NODE / PART INSPECTOR */}
          <div className="w-full md:w-80 bg-slate-950/80 border-t md:border-t-0 md:border-l border-slate-800 p-4 flex flex-col gap-3 overflow-y-auto shrink-0">
            <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400 flex items-center gap-1.5 pb-2 border-b border-slate-800">
              <Eye size={14} />
              Deep Concept Inspector
            </span>

            {/* Active Node Details */}
            {activeNode && (
              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-1">
                  <span className="text-[10px] font-black uppercase text-cyan-400">{activeNode.category || 'Node'}</span>
                  <h4 className="text-sm font-black text-white">{activeNode.label}</h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">{activeNode.description}</p>
                </div>

                {activeNode.everydayLifeAnalogy && (
                  <div className="p-3 rounded-xl bg-indigo-950/60 border border-indigo-700/50 text-xs text-indigo-200">
                    <span className="text-[10px] font-black uppercase text-indigo-400 block mb-1">Metaphorical Analogy</span>
                    {activeNode.everydayLifeAnalogy}
                  </div>
                )}

                {activeNode.examWeightageMarks && (
                  <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-700/50 text-xs text-amber-200">
                    <span className="text-[10px] font-black uppercase text-amber-400 block mb-1">
                      Exam Weightage: {activeNode.examWeightageMarks} Marks
                    </span>
                    {activeNode.markingSchemePoints?.map((pt, i) => (
                      <div key={i} className="text-[11px] text-amber-100 flex items-start gap-1 mt-1">
                        <span>•</span> {pt}
                      </div>
                    ))}
                  </div>
                )}

                {activeNode.commonMistakeWarning && (
                  <div className="p-3 rounded-xl bg-red-950/60 border border-red-700/50 text-xs text-red-200">
                    <span className="text-[10px] font-black uppercase text-red-400 block mb-1">Common Trap</span>
                    {activeNode.commonMistakeWarning}
                  </div>
                )}

                {onSpeak && (
                  <button
                    onClick={() => onSpeak(activeNode.description)}
                    className="w-full py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                  >
                    <Volume2Icon size={14} />
                    Narrate Node Explanation
                  </button>
                )}
              </div>
            )}

            {/* Active Schematic Part Details (if any selected) */}
            {activePart && (
              <div className="p-3 rounded-xl bg-slate-900 border border-indigo-500/40 space-y-2 mt-2">
                <span className="text-[10px] font-mono text-indigo-400 font-black">[{activePart.part.sectionCode}] PART SPECIFICATION</span>
                <h5 className="text-xs font-bold text-white">{activePart.part.name}</h5>
                <p className="text-[11px] text-slate-300"><strong>Material/Spec:</strong> {activePart.part.materialOrSpec}</p>
                <p className="text-[11px] text-slate-300"><strong>Operating Law:</strong> {activePart.part.operatingPrinciple}</p>
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};

function Volume2Icon(props: { size?: number; className?: string }) {
  return (
    <svg 
      width={props.size || 16} 
      height={props.size || 16} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={props.className}
    >
      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
      <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
      <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
    </svg>
  );
}
