import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Send, Flame, Calendar, Clock, Target, ShieldCheck, 
  Sparkles, CheckCircle2, MessageSquare, BarChart2, Plus, Zap
} from 'lucide-react';
import { cn } from '../lib/utils';
import { StudyBuddyMatch, BuddyMessage } from '../modules/study-buddies/types';
import { StudyBuddyService } from '../modules/study-buddies/studyBuddyService';

interface BuddyChatModalProps {
  match: StudyBuddyMatch;
  initialTab?: 'chat' | 'scheduler' | 'progress';
  isDark?: boolean;
  onClose: () => void;
  onUpdate: () => void;
}

export const BuddyChatModal: React.FC<BuddyChatModalProps> = ({
  match,
  initialTab = 'chat',
  isDark = true,
  onClose,
  onUpdate,
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'scheduler' | 'progress'>(initialTab);
  const [messages, setMessages] = useState<BuddyMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [partnerAlias] = useState(match.partnerProfile?.alias || 'Study Buddy');
  const myProfile = StudyBuddyService.getMyProfile();

  // Scheduler state
  const [sessionTitle, setSessionTitle] = useState('Sync Physics Numerical Review');
  const [sessionDate, setSessionDate] = useState(() => {
    const d = new Date(Date.now() + 24 * 3600000);
    return d.toISOString().slice(0, 16);
  });
  const [sessionDuration, setSessionDuration] = useState(45);
  const [sessionType, setSessionType] = useState<'pomodoro' | 'problem_solving' | 'quiz_battle' | 'explain_back'>('quiz_battle');
  const [sessionTopic, setSessionTopic] = useState('Gauss Theorem Applications');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const loadMessages = () => {
    const msgs = StudyBuddyService.getMessages(match.id);
    setMessages(msgs);
  };

  useEffect(() => {
    loadMessages();
  }, [match.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeTab]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    StudyBuddyService.sendMessage(
      match.id,
      myProfile.id,
      myProfile.alias,
      inputMessage.trim(),
      'text'
    );
    setInputMessage('');
    loadMessages();
    onUpdate();

    // Trigger realistic peer response after 2 seconds if first question
    if (messages.length < 3) {
      setTimeout(() => {
        StudyBuddyService.sendMessage(
          match.id,
          match.partnerProfile?.id || 'peer_partner',
          partnerAlias,
          `Awesome work! Let's solve 5 more numericals together before our scheduled review session. 🎯`,
          'text'
        );
        loadMessages();
        onUpdate();
      }, 2000);
    }
  };

  const handleCreateSession = (e: React.FormEvent) => {
    e.preventDefault();
    StudyBuddyService.scheduleSession(
      match.id,
      sessionTitle,
      new Date(sessionDate).toISOString(),
      sessionDuration,
      sessionType,
      sessionTopic
    );
    setActiveTab('chat');
    loadMessages();
    onUpdate();
  };

  const weeklyStats = StudyBuddyService.getWeeklyComparison(match);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className={cn(
        "w-full max-w-2xl rounded-2xl border shadow-2xl flex flex-col h-[85vh] max-h-[700px] overflow-hidden animate-in fade-in zoom-in-95",
        isDark ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
      )}>
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white font-bold text-base shadow-md">
              {partnerAlias.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm sm:text-base">{partnerAlias}</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold">
                  {match.matchScore}% Synergy
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-2">
                <span>{match.subjectFocus} Buddy</span>
                <span>•</span>
                <span className="text-amber-400 font-semibold flex items-center gap-0.5">
                  <Flame size={12} /> {match.partnerProfile?.streakDays || 5}d Streak
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <div className="flex p-1 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs">
              <button
                onClick={() => setActiveTab('chat')}
                className={cn(
                  "px-3 py-1 rounded-lg font-bold transition cursor-pointer flex items-center gap-1",
                  activeTab === 'chat' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-400 hover:text-slate-200"
                )}
              >
                <MessageSquare size={13} /> Chat
              </button>
              <button
                onClick={() => setActiveTab('scheduler')}
                className={cn(
                  "px-3 py-1 rounded-lg font-bold transition cursor-pointer flex items-center gap-1",
                  activeTab === 'scheduler' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-400 hover:text-slate-200"
                )}
              >
                <Calendar size={13} /> Schedule
              </button>
              <button
                onClick={() => setActiveTab('progress')}
                className={cn(
                  "px-3 py-1 rounded-lg font-bold transition cursor-pointer flex items-center gap-1",
                  activeTab === 'progress' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-400 hover:text-slate-200"
                )}
              >
                <BarChart2 size={13} /> Progress
              </button>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition ml-2 cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Tab 1: Chat Thread */}
        {activeTab === 'chat' && (
          <div className="flex-1 flex flex-col min-h-0 bg-slate-950/40">
            {/* Safe Privacy Notice */}
            <div className="px-4 py-2 bg-indigo-950/40 border-b border-indigo-500/20 text-[11px] text-indigo-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ShieldCheck size={13} className="text-indigo-400" />
                End-to-End Anonymous Study Channel. Zero personal contact info shared.
              </span>
              <span className="text-[10px] text-indigo-400 font-semibold uppercase">Encrypted</span>
            </div>

            {/* Message Feed */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((msg) => {
                const isMe = msg.senderId === myProfile.id;
                const isAlert = msg.type === 'checkin_alert' || msg.type === 'goal_update' || msg.type === 'session_invite';

                if (isAlert) {
                  return (
                    <div key={msg.id} className="flex justify-center my-2">
                      <div className="px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-slate-300 text-xs flex items-center gap-2 max-w-md text-center shadow-sm">
                        {msg.type === 'checkin_alert' && <Flame size={14} className="text-amber-400 shrink-0" />}
                        {msg.type === 'goal_update' && <Target size={14} className="text-indigo-400 shrink-0" />}
                        {msg.type === 'session_invite' && <Calendar size={14} className="text-teal-400 shrink-0" />}
                        <span>{msg.messageText}</span>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={msg.id}
                    className={cn(
                      "flex flex-col max-w-[80%]",
                      isMe ? "ml-auto items-end" : "mr-auto items-start"
                    )}
                  >
                    <span className="text-[10px] text-slate-500 mb-0.5 px-1 font-semibold">
                      {isMe ? 'You' : msg.senderAlias}
                    </span>
                    <div
                      className={cn(
                        "p-3 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-sm",
                        isMe
                          ? "bg-indigo-600 text-white rounded-br-none"
                          : isDark ? "bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700" : "bg-slate-100 text-slate-800 rounded-bl-none"
                      )}
                    >
                      {msg.messageText}
                    </div>
                    <span className="text-[9px] text-slate-500 mt-0.5 px-1">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input Box */}
            <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800 bg-slate-900 flex gap-2">
              <input
                type="text"
                placeholder={`Encourage ${partnerAlias} or ask about study goals...`}
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                maxLength={400}
                className={cn(
                  "flex-1 px-4 py-2.5 rounded-xl border text-xs sm:text-sm outline-none transition",
                  isDark ? "bg-slate-800 border-slate-700 text-slate-200 focus:border-indigo-500" : "bg-slate-50 border-slate-300 text-slate-800 focus:border-indigo-500"
                )}
              />
              <button
                type="submit"
                disabled={!inputMessage.trim()}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-indigo-600/20 flex items-center gap-1.5 transition cursor-pointer"
              >
                <Send size={15} /> Send
              </button>
            </form>
          </div>
        )}

        {/* Tab 2: Scheduler */}
        {activeTab === 'scheduler' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-5">
            <div>
              <h4 className="text-sm font-bold text-slate-200 mb-1 flex items-center gap-2">
                <Calendar size={16} className="text-indigo-400" />
                Schedule Synchronized Study Session
              </h4>
              <p className="text-xs text-slate-400">
                Plan a joint problem-solving or quiz review sprint with {partnerAlias}.
              </p>
            </div>

            <form onSubmit={handleCreateSession} className="space-y-4 p-4 rounded-xl bg-slate-800/40 border border-slate-700/60">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Session Title</label>
                <input
                  type="text"
                  value={sessionTitle}
                  onChange={(e) => setSessionTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-200 outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Date & Time</label>
                  <input
                    type="datetime-local"
                    value={sessionDate}
                    onChange={(e) => setSessionDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-200 outline-none focus:border-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Duration (Mins)</label>
                  <select
                    value={sessionDuration}
                    onChange={(e) => setSessionDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-200 outline-none focus:border-indigo-500"
                  >
                    <option value={25}>25 mins (Pomodoro Sprint)</option>
                    <option value={45}>45 mins (Deep Problem Solving)</option>
                    <option value={60}>60 mins (Comprehensive Revision)</option>
                    <option value={90}>90 mins (Full Chapter Drill)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Session Type</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { key: 'quiz_battle', label: '⚔️ Quiz Battle' },
                    { key: 'problem_solving', label: '🧩 Problem Solving' },
                    { key: 'pomodoro', label: '🍅 Pomodoro Sync' },
                    { key: 'explain_back', label: '🗣️ Teach Each Other' },
                  ].map((st) => (
                    <button
                      key={st.key}
                      type="button"
                      onClick={() => setSessionType(st.key as typeof sessionType)}
                      className={cn(
                        "py-2 px-2 rounded-xl text-xs font-semibold border text-center transition cursor-pointer",
                        sessionType === st.key
                          ? "bg-indigo-600/30 border-indigo-500 text-indigo-300 shadow-sm"
                          : "bg-slate-800/40 border-slate-700 text-slate-400 hover:bg-slate-800"
                      )}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Topic Focus</label>
                <input
                  type="text"
                  value={sessionTopic}
                  onChange={(e) => setSessionTopic(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-200 outline-none focus:border-indigo-500"
                  placeholder="e.g. Gauss Law & Electric Field Calculations"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20 flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Plus size={14} /> Send Session Invite
                </button>
              </div>
            </form>

            {/* Upcoming Scheduled Sessions */}
            <div>
              <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Upcoming Joint Sessions
              </h5>
              {(match.scheduledSessions || []).length === 0 ? (
                <p className="text-xs text-slate-500 italic">No scheduled sessions yet. Plan one above!</p>
              ) : (
                <div className="space-y-2">
                  {(match.scheduledSessions || []).map((s) => (
                    <div key={s.id} className="p-3 rounded-xl bg-slate-800/60 border border-slate-700 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
                          <Calendar size={16} />
                        </div>
                        <div>
                          <h6 className="font-bold text-xs text-slate-200">{s.title}</h6>
                          <p className="text-[11px] text-slate-400">
                            {new Date(s.dateTime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })} • {s.durationMinutes} mins
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold capitalize">
                        {s.sessionType.replace('_', ' ')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Weekly Progress Comparison */}
        {activeTab === 'progress' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-5">
            <div>
              <h4 className="text-sm font-bold text-slate-200 mb-1 flex items-center gap-2">
                <BarChart2 size={16} className="text-emerald-400" />
                Weekly Progress Comparison
              </h4>
              <p className="text-xs text-slate-400">
                Mutual metrics and accountability trends for the last 7 days.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* My Stats */}
              <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/20">
                <h5 className="text-xs font-bold text-indigo-300 mb-3 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 inline-block" /> You ({myProfile.alias})
                </h5>
                <div className="space-y-3 text-xs">
                  <div>
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>Study Time:</span>
                      <span className="font-bold text-slate-200">{weeklyStats.myTotalMinutes} mins</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-indigo-500 h-full rounded-full" style={{ width: '75%' }} />
                    </div>
                  </div>
                  <div className="flex justify-between border-t border-slate-800/80 pt-2">
                    <span className="text-slate-400">Goal Problems Solved:</span>
                    <span className="font-bold text-indigo-300">{weeklyStats.myCompletedProblems}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-800/80 pt-2">
                    <span className="text-slate-400">Active Streak:</span>
                    <span className="font-bold text-amber-400 flex items-center gap-1">
                      <Flame size={13} /> {weeklyStats.myStreak} days
                    </span>
                  </div>
                </div>
              </div>

              {/* Partner Stats */}
              <div className="p-4 rounded-xl bg-purple-950/30 border border-purple-500/20">
                <h5 className="text-xs font-bold text-purple-300 mb-3 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-500 inline-block" /> Partner ({partnerAlias})
                </h5>
                <div className="space-y-3 text-xs">
                  <div>
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>Study Time:</span>
                      <span className="font-bold text-slate-200">{weeklyStats.partnerTotalMinutes} mins</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-purple-500 h-full rounded-full" style={{ width: '85%' }} />
                    </div>
                  </div>
                  <div className="flex justify-between border-t border-slate-800/80 pt-2">
                    <span className="text-slate-400">Goal Problems Solved:</span>
                    <span className="font-bold text-purple-300">{weeklyStats.partnerCompletedProblems}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-800/80 pt-2">
                    <span className="text-slate-400">Active Streak:</span>
                    <span className="font-bold text-amber-400 flex items-center gap-1">
                      <Flame size={13} /> {weeklyStats.partnerStreak} days
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Motivational Encouragement Box */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/30 via-teal-950/20 to-slate-900 border border-emerald-500/30 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                <Zap size={20} />
              </div>
              <div className="text-xs">
                <h6 className="font-bold text-emerald-300">Synergy Momentum Alert</h6>
                <p className="text-slate-400 mt-0.5">
                  Together, you and {partnerAlias} have completed {weeklyStats.myCompletedProblems + weeklyStats.partnerCompletedProblems} practice questions this week. Keep each other accountable!
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
