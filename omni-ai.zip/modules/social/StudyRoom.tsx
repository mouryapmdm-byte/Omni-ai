export * from '../../src/components/StudyRoom';
export { StudyRoom as default } from '../../src/components/StudyRoom';
