# Security Specification - Firestore

## Data Invariants
- **User Profiles**: A user can only access their own profile document under `/users/{userId}`.
- **Published Guides**:
    - Read: Publicly accessible (allow read).
    - Write: Only the author (`authorId` matches `auth.uid`) can create, update, or delete.
- **Timestamps**: All `timestamp` fields must match `request.time`.
- **Identity Integrity**: `authorId` or `uid` fields must always match the authenticated user's UID.
- **Immutable Fields**: `authorId` and `id` cannot be changed after creation.

## The Dirty Dozen Payloads
1. **Privilege Escalation**: Attempting to set `role: 'admin'` on own user profile.
2. **Identity Spoofing (Profile)**: Attempting to update another user's profile (`/users/attacker-id` -> `/users/victim-id`).
3. **Identity Spoofing (Guide)**: Creating a guide with `authorId` set to a victim's UID.
4. **Unauthorized Update**: Modifying a `PublishedGuide` where the attacker is not the author.
5. **Unauthorized Deletion**: Deleting a `PublishedGuide` where the attacker is not the author.
6. **Resource Exhaustion (String)**: Injecting a 1MB string into the `title` or `summary` field.
7. **Resource Exhaustion (Array)**: Injecting a 10,000-item array into `keyConcepts`.
8. **ID Poisoning**: Using a 2KB junk string as a document ID.
9. **Timestamp Manipulation**: Providing a backdated or future timestamp instead of server time.
10. **State Corruption**: Attempting to change the `authorId` of an existing guide to someone else.
11. **Shadow Update**: Adding a `verified: true` field to a guide to bypass future potential UI filters.
12. **Blanket Read Attack**: Attempting to `list` the entire `/users` collection without a specific UID filter.

## Test Runner Plan
The tests will use `@firebase/rules-unit-testing` to verify that all the above payloads are correctly rejected with `PERMISSION_DENIED`.
