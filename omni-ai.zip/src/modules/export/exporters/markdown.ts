import { saveAs } from 'file-saver';

export async function exportToMarkdown(content: any) {
  const md = `# ${content.title}\n\n${content.body}`;
  const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
  saveAs(blob, `${content.title.replace(/\s+/g, '_')}.md`);
}
