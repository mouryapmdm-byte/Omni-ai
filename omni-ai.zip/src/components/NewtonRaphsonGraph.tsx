import React, { useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';

interface NewtonRaphsonGraphProps {
  funcStr: string;
  derivStr: string;
  x0?: number;
  iterations?: number;
  theme?: 'dark' | 'light';
}

export const NewtonRaphsonGraph: React.FC<NewtonRaphsonGraphProps> = ({
  funcStr,
  derivStr,
  x0 = 2,
  iterations = 3,
  theme = 'dark'
}) => {
  const data = useMemo(() => {
    try {
      const cleanFunc = funcStr
        .replace(/\\text\{[^}]*\}/g, '')
        .replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\b/g, '')
        .replace(/\b(?:cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW|m|s|deg|rad)\b/gi, '')
        .replace(/\^/g, '**')
        .trim();

      const cleanDeriv = derivStr
        .replace(/\\text\{[^}]*\}/g, '')
        .replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\b/g, '')
        .replace(/\b(?:cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW|m|s|deg|rad)\b/gi, '')
        .replace(/\^/g, '**')
        .trim();

      const f = new Function('x', `
        try {
          return ${cleanFunc};
        } catch (err) {
          return NaN;
        }
      `) as (x: number) => number;

      const df = new Function('x', `
        try {
          return ${cleanDeriv};
        } catch (err) {
          return NaN;
        }
      `) as (x: number) => number;
      
      let currentX = x0;
      const points = [];
      const tangentLines = [];
      
      // Compute iterations
      const iterPoints = [];
      for (let i = 0; i <= iterations; i++) {
        const y = f(currentX);
        if (!Number.isFinite(y)) break;
        iterPoints.push({ x: currentX, y, iter: i });
        
        if (i < iterations) {
          const slope = df(currentX);
          if (!Number.isFinite(slope) || Math.abs(slope) < 1e-12) break;
          const nextX = currentX - y / slope;
          
          tangentLines.push({
            m: slope,
            x1: currentX,
            y1: y,
            nextX: nextX
          });
          
          currentX = nextX;
        }
      }

      if (iterPoints.length === 0) return { points: [], iterPoints: [] };
      
      const minX = Math.min(-1, ...iterPoints.map(p => p.x)) - 1;
      const maxX = Math.max(3, ...iterPoints.map(p => p.x)) + 1;
      
      for (let x = minX; x <= maxX; x += 0.1) {
        const point: any = { x: Number(x.toFixed(2)), fx: f(x) };
        
        tangentLines.forEach((t, i) => {
          // Keep tangent line visible in a reasonable domain around the points
          const tMin = Math.min(t.x1, t.nextX) - 0.5;
          const tMax = Math.max(t.x1, t.nextX) + 0.5;
          if (x >= tMin && x <= tMax) {
            point[`tangent${i}`] = t.m * (x - t.x1) + t.y1;
          }
        });
        
        points.push(point);
      }
      
      return { points, iterPoints };
    } catch (e) {
      return { points: [], iterPoints: [] };
    }
  }, [funcStr, derivStr, x0, iterations]);

  const textColor = theme === 'dark' ? '#94a3b8' : '#64748b';
  const gridColor = theme === 'dark' ? '#334155' : '#e2e8f0';

  if (data.points.length === 0) return null;

  return (
    <div className="w-full p-4 rounded-xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 my-4 shadow-sm animate-in fade-in zoom-in-95 duration-500">
      <h3 className="font-bold text-center mb-4 text-slate-800 dark:text-slate-200">
        Newton-Raphson Method Convergence
      </h3>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
          <LineChart data={data.points} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
            <XAxis 
              dataKey="x" 
              stroke={textColor} 
              type="number" 
              domain={['dataMin', 'dataMax']} 
              tickCount={10}
            />
            <YAxis stroke={textColor} domain={['auto', 'auto']} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: theme === 'dark' ? '#1e293b' : '#fff',
                borderColor: theme === 'dark' ? '#334155' : '#e2e8f0',
                color: theme === 'dark' ? '#f8fafc' : '#0f172a'
              }}
            />
            <ReferenceLine y={0} stroke={textColor} />
            <ReferenceLine x={0} stroke={textColor} />
            
            {/* Main function curve */}
            <Line 
              type="monotone" 
              dataKey="fx" 
              stroke="#6366f1" 
              strokeWidth={2} 
              dot={false} 
              name="f(x)"
              isAnimationActive={false}
            />
            
            {/* Tangent lines */}
            {data.iterPoints.slice(0, -1).map((_, i) => (
              <Line 
                key={`tangent${i}`}
                type="linear" 
                dataKey={`tangent${i}`} 
                stroke="#f43f5e" 
                strokeWidth={1.5} 
                strokeDasharray="4 4"
                dot={false} 
                name={`Tangent ${i}`}
                isAnimationActive={false}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 text-xs text-slate-500 dark:text-slate-400 flex flex-wrap gap-4 justify-center">
        <p><strong>f(x) =</strong> {funcStr}</p>
        <p><strong>f'(x) =</strong> {derivStr}</p>
        <div className="w-full text-center mt-2">
          <strong>Iterations:</strong>
          <div className="flex flex-wrap justify-center gap-3 mt-1">
            {data.iterPoints.map(p => (
              <span key={p.iter} className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">
                x<sub>{p.iter}</sub> = {p.x.toFixed(4)}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
