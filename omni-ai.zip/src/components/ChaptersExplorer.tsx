import React, { useState } from 'react';
import { motion } from 'motion/react';
import { cn, getSyncShareUrl } from '@/src/lib/utils';
import { BookOpen, GraduationCap, ArrowRight, Brain, Lightbulb, Sparkles, Trash2, CheckCircle, Clock, Target, FileText, Plus, Minus, Wand2, Globe, ExternalLink, Copy, Check, Share2, Search, Compass, Map, Award, Flame, ChevronDown, ChevronRight, ChevronLeft, RefreshCw, Calendar, Bell, BellRing, GripVertical, ChevronUp, Atom, Dna, Leaf, Sprout, Microscope, HeartPulse, Activity, BarChart3, Sliders, HelpCircle } from 'lucide-react';
import { DoubtBoard } from './DoubtBoard';
import { getBoardCurriculum, getDetailedBoardCurriculum } from '../data/boards';
import { CONFIG, TOPIC_ICONS, ELECTRIC_CHARGES_SUBTOPICS, GAUSS_THEOREM_SUBTOPICS, ELECTRIC_POTENTIAL_SUBTOPICS, CAPACITORS_DIELECTRICS_SUBTOPICS, ELECTRIC_RESISTANCE_SUBTOPICS, DC_CIRCUITS_SUBTOPICS, MOVING_CHARGES_SUBTOPICS, TORQUE_CURRENT_LOOP_SUBTOPICS, EARTH_MAGNETISM_SUBTOPICS, MAGNETIC_SUBSTANCES_SUBTOPICS, ELECTROMAGNETIC_INDUCTION_SUBTOPICS, ALTERNATING_CURRENT_SUBTOPICS, ELECTROMAGNETIC_WAVES_SUBTOPICS, RAY_OPTICS_SUBTOPICS, WAVE_OPTICS_SUBTOPICS, DUAL_NATURE_SUBTOPICS, ATOMS_SUBTOPICS, NUCLEI_SUBTOPICS, SEMICONDUCTOR_ELECTRONICS_SUBTOPICS, COMMUNICATION_SYSTEMS_SUBTOPICS, REFLECTION_OF_LIGHT_SUBTOPICS, REFRACTION_PLANE_INTERFACE_SUBTOPICS, REFRACTION_SPHERICAL_SURFACES_LENSES_SUBTOPICS, REFRACTION_DISPERSION_PRISM_SUBTOPICS, OPTICAL_INSTRUMENTS_SUBTOPICS, WAVE_NATURE_HUYGENS_SUBTOPICS, INTERFERENCE_OF_LIGHT_SUBTOPICS, DIFFRACTION_OF_LIGHT_SUBTOPICS, POLARIZATION_OF_LIGHT_SUBTOPICS, PHOTOELECTRIC_EFFECT_SUBTOPICS, MATTER_WAVES_SUBTOPICS, X_RAYS_SUBTOPICS, ATOMS_BOHR_SPECTRUM_SUBTOPICS, NUCLEAR_STRUCTURE_SUBTOPICS, RADIOACTIVITY_SUBTOPICS, MASS_ENERGY_BINDING_ENERGY_SUBTOPICS, NUCLEAR_FISSION_FUSION_SUBTOPICS, SEMICONDUCTOR_ELECTRONICS_LESSON_SUBTOPICS, SEMICONDUCTOR_DIODES_SUBTOPICS, JUNCTION_TRANSISTORS_SUBTOPICS, LOGIC_GATES_SUBTOPICS, COMMUNICATION_SYSTEMS_LESSON_SUBTOPICS, SOLID_STATE_SUBTOPICS, SOLUTIONS_SUBTOPICS, ELECTROCHEMISTRY_SUBTOPICS, CHEMICAL_KINETICS_SUBTOPICS, SURFACE_CHEMISTRY_SUBTOPICS, ISOLATION_OF_ELEMENTS_SUBTOPICS, P_BLOCK_ELEMENTS_SUBTOPICS, D_AND_F_BLOCK_SUBTOPICS, COORDINATION_COMPOUNDS_SUBTOPICS, HALOALKANES_HALOARENES_SUBTOPICS, ALCOHOLS_PHENOLS_ETHERS_SUBTOPICS, ALDEHYDES_KETONES_CARBOXYLIC_SUBTOPICS, AMINES_NITROGEN_COMPOUNDS_SUBTOPICS, BIOMOLECULES_CHEMISTRY_SUBTOPICS, POLYMERS_SUBTOPICS, CHEMISTRY_EVERYDAY_LIFE_SUBTOPICS,
  SOLUTIONS_CBSE_SUBTOPICS, ELECTROCHEMISTRY_CBSE_SUBTOPICS, CHEMICAL_KINETICS_CBSE_SUBTOPICS, D_AND_F_BLOCK_CBSE_SUBTOPICS, COORDINATION_COMPOUNDS_CBSE_SUBTOPICS, HALOALKANES_HALOARENES_CBSE_SUBTOPICS, ALCOHOLS_PHENOLS_ETHERS_CBSE_SUBTOPICS, ALDEHYDES_KETONES_CARBOXYLIC_CBSE_SUBTOPICS, AMINES_CBSE_SUBTOPICS, BIOMOLECULES_CBSE_SUBTOPICS,
  RELATIONS_FUNCTIONS_SUBTOPICS, INVERSE_TRIGONOMETRIC_FUNCTIONS_SUBTOPICS, MATRICES_SUBTOPICS, DETERMINANTS_SUBTOPICS, CONTINUITY_DIFFERENTIABILITY_SUBTOPICS, EXPONENTIAL_LOGARITHMIC_MEAN_VALUE_SUBTOPICS, APPLICATION_DERIVATIVES_SUBTOPICS, INTEGRATION_SUBTOPICS, DIFFERENTIAL_EQUATIONS_SUBTOPICS, PROBABILITY_SUBTOPICS, VECTORS_SUBTOPICS, THREE_DIMENSIONAL_GEOMETRY_SUBTOPICS, APPLICATIONS_OF_INTEGRALS_SUBTOPICS, APPLICATION_DERIVATIVES_ECONOMICS_SUBTOPICS, REGRESSION_SUBTOPICS, LINEAR_PROGRAMMING_SUBTOPICS, SEXUAL_REPRODUCTION_PLANTS_SUBTOPICS, HUMAN_REPRODUCTION_SUBTOPICS, REPRODUCTIVE_HEALTH_SUBTOPICS, PRINCIPLES_OF_INHERITANCE_SUBTOPICS, MOLECULAR_BASIS_INHERITANCE_SUBTOPICS, EVOLUTION_SUBTOPICS, HUMAN_HEALTH_DISEASE_SUBTOPICS, MICROBES_HUMAN_WELFARE_SUBTOPICS, BIOTECHNOLOGY_PRINCIPLES_SUBTOPICS, BIOTECHNOLOGY_APPLICATIONS_SUBTOPICS, ORGANISMS_POPULATIONS_SUBTOPICS, ECOSYSTEM_SUBTOPICS, BIODIVERSITY_CONSERVATION_SUBTOPICS, PYTHON_REVISION_TOUR_SUBTOPICS, FUNCTIONS_SUBTOPICS, FILE_HANDLING_SUBTOPICS, DATA_STRUCTURES_CS_SUBTOPICS, COMPUTER_NETWORKS_CS_SUBTOPICS, DATABASE_MANAGEMENT_CS_SUBTOPICS, INTERFACE_PYTHON_SQL_SUBTOPICS, SOCIETAL_IMPACTS_SUBTOPICS,
  BRICKS_BEADS_BONES_SUBTOPICS,
  KINGS_FARMERS_TOWNS_SUBTOPICS,
  KINSHIP_CASTE_CLASS_SUBTOPICS,
  THINKERS_BELIEFS_BUILDINGS_SUBTOPICS,
  THROUGH_EYES_TRAVELLERS_SUBTOPICS,
  BHAKTI_SUFI_TRADITIONS_SUBTOPICS,
  VIJAYANAGARA_EMPIRE_SUBTOPICS,
  PEASANTS_ZAMINDARS_STATE_SUBTOPICS,
  COLONIALISM_COUNTRYSIDE_SUBTOPICS,
  REBELS_AND_RAJ_SUBTOPICS,
  MAHATMA_GANDHI_MOVEMENT_SUBTOPICS,
  FRAMING_CONSTITUTION_SUBTOPICS,
  HUMAN_GEOGRAPHY_NATURE_SUBTOPICS,
  WORLD_POPULATION_SUBTOPICS,
  HUMAN_DEVELOPMENT_GEOG_SUBTOPICS,
  PRIMARY_ACTIVITIES_SUBTOPICS,
  SECONDARY_ACTIVITIES_SUBTOPICS,
  TERTIARY_QUATERNARY_SUBTOPICS,
  TRANSPORT_COMMUNICATION_SUBTOPICS,
  INTERNATIONAL_TRADE_GEOG_SUBTOPICS,
  HUMAN_SETTLEMENTS_GEOG_SUBTOPICS,
  INDIA_POPULATION_GEOG_SUBTOPICS,
  END_OF_BIPOLARITY_SUBTOPICS,
  CONTEMPORARY_CENTRES_POWER_SUBTOPICS,
  CONTEMPORARY_SOUTH_ASIA_SUBTOPICS,
  INTERNATIONAL_ORGANIZATIONS_SUBTOPICS,
  SECURITY_CONTEMPORARY_WORLD_SUBTOPICS,
  ENVIRONMENT_NATURAL_RESOURCES_SUBTOPICS,
  GLOBALIZATION_POL_SUBTOPICS,
  CHALLENGES_NATION_BUILDING_SUBTOPICS,
  RECENT_DEVELOPMENTS_POL_SUBTOPICS,
  DEMOGRAPHIC_STRUCTURE_SUBTOPICS,
  SOCIAL_INSTITUTIONS_SUBTOPICS,
  SOCIAL_INEQUALITY_SUBTOPICS,
  CULTURAL_DIVERSITY_SUBTOPICS,
  STRUCTURAL_CHANGE_SUBTOPICS,
  CULTURAL_CHANGE_SUBTOPICS,
  RURAL_SOCIETY_CHANGE_SUBTOPICS,
  INDUSTRIAL_SOCIETY_CHANGE_SUBTOPICS,
  SOCIAL_MOVEMENTS_SUBTOPICS,
  PSYCH_VARIATIONS_SUBTOPICS,
  SELF_PERSONALITY_SUBTOPICS,
  LIFE_CHALLENGES_SUBTOPICS,
  PSYCH_DISORDERS_SUBTOPICS,
  THERAPEUTIC_APPROACHES_SUBTOPICS,
  ATTITUDE_SOCIAL_COGNITION_SUBTOPICS,
  SOCIAL_INFLUENCE_GROUPS_SUBTOPICS,
  MACRO_INTRO_SUBTOPICS,
  NATIONAL_INCOME_SUBTOPICS,
  MONEY_BANKING_SUBTOPICS,
  INCOME_EMPLOYMENT_SUBTOPICS,
  GOVT_BUDGET_SUBTOPICS,
  BALANCE_PAYMENTS_SUBTOPICS,
  INDIAN_ECON_EVE_SUBTOPICS,
  INDIAN_ECON_1950_1990_SUBTOPICS,
  LPG_APPRAISAL_SUBTOPICS,
  HUMAN_CAPITAL_SUBTOPICS,
  RURAL_DEV_ECON_SUBTOPICS,
  EMPLOYMENT_ISSUES_SUBTOPICS,
  SUSTAINABLE_DEV_SUBTOPICS,
  COMPARATIVE_DEV_SUBTOPICS,
  ISC_PSYCH_INTELLIGENCE_SUBTOPICS,
  ISC_PSYCH_PERSONALITY_SUBTOPICS,
  ISC_PSYCH_LIFESPAN_SUBTOPICS,
  ISC_PSYCH_STRESS_HEALTH_SUBTOPICS,
  ISC_PSYCH_DISORDERS_THERAPY_SUBTOPICS,
  ISC_PSYCH_SOCIAL_THOUGHT_SUBTOPICS,
  ISC_PSYCH_SOCIAL_INFLUENCE_SUBTOPICS,
  ISC_BIO_REPRODUCTION_SUBTOPICS,
  ISC_BIO_GENETICS_SUBTOPICS,
  ISC_BIO_WELFARE_SUBTOPICS,
  ISC_BIO_BIOTECH_SUBTOPICS,
  ISC_BIO_ECOLOGY_SUBTOPICS,
  ISC_ECON_MICRO_SUBTOPICS,
  ISC_ECON_MACRO_SUBTOPICS,
  RATIONAL_IRRATIONAL_NUMBERS_ICSE9_SUBTOPICS,
  COMPOUND_INTEREST_ICSE9_SUBTOPICS,
  EXPANSIONS_ICSE9_SUBTOPICS,
  FACTORISATION_ICSE9_SUBTOPICS,
  SIMULTANEOUS_LINEAR_EQUATIONS_ICSE9_SUBTOPICS,
  INDICES_EXPONENTS_ICSE9_SUBTOPICS,
  LOGARITHMS_ICSE9_SUBTOPICS,
  TRIANGLES_GEOMETRY_ICSE9_SUBTOPICS,
  MIDPOINT_INTERCEPT_THEOREMS_ICSE9_SUBTOPICS,
  RECTILINEAR_FIGURES_ICSE9_SUBTOPICS,
  CIRCLES_GEOMETRY_ICSE9_SUBTOPICS,
  AREA_PLANE_FIGURES_ICSE9_SUBTOPICS,
  SURFACE_AREA_VOLUME_ICSE9_SUBTOPICS,
  COORDINATE_GEOMETRY_ICSE9_SUBTOPICS,
  TRIGONOMETRICAL_RATIOS_ICSE9_SUBTOPICS,
  STATISTICS_ICSE9_SUBTOPICS,
  INTERNAL_ASSESSMENT_MATH_ICSE9_SUBTOPICS,
  MEASUREMENTS_EXPERIMENTATION_ICSE9_SUBTOPICS,
  MOTION_ONE_DIMENSION_ICSE9_SUBTOPICS,
  LAWS_OF_MOTION_ICSE9_SUBTOPICS,
  FLUIDS_PRESSURE_ARCHIMEDES_ICSE9_SUBTOPICS,
  HEAT_AND_ENERGY_ICSE9_SUBTOPICS,
  LIGHT_REFLECTION_SPHERICAL_MIRRORS_ICSE9_SUBTOPICS,
  SOUND_PROPAGATION_ULTRASONIC_ICSE9_SUBTOPICS,
  ELECTRICITY_MAGNETISM_ICSE9_SUBTOPICS,
  INTERNAL_ASSESSMENT_PHYSICS_ICSE9_SUBTOPICS,
  LANGUAGE_OF_CHEMISTRY_ICSE9_SUBTOPICS,
  CHEMICAL_CHANGES_REACTIONS_ICSE9_SUBTOPICS,
  WATER_SOLUTIONS_HYDRATION_ICSE9_SUBTOPICS,
  ATOMIC_STRUCTURE_BONDING_ICSE9_SUBTOPICS,
  PERIODIC_TABLE_PROPERTIES_ICSE9_SUBTOPICS,
  HYDROGEN_STUDY_ICSE9_SUBTOPICS,
  GAS_LAWS_BOYLE_CHARLES_ICSE9_SUBTOPICS,
  ATMOSPHERIC_POLLUTION_ICSE9_SUBTOPICS,
  INTERNAL_ASSESSMENT_CHEMISTRY_ICSE9_SUBTOPICS,
  BASIC_BIOLOGY_ICSE9_SUBTOPICS,
  FLOWERING_PLANTS_ICSE9_SUBTOPICS,
  HUMAN_ANATOMY_PHYSIOLOGY_ICSE9_SUBTOPICS,
  HEALTH_HYGIENE_ICSE9_SUBTOPICS,
  WASTE_MANAGEMENT_ICSE9_SUBTOPICS,
  INTERNAL_ASSESSMENT_BIOLOGY_ICSE9_SUBTOPICS,
  OOP_CONCEPTS_ICSE9_SUBTOPICS,
  OBJECTS_CLASSES_ICSE9_SUBTOPICS,
  VALUES_DATA_TYPES_ICSE9_SUBTOPICS,
  OPERATORS_JAVA_ICSE9_SUBTOPICS,
  INPUT_JAVA_ICSE9_SUBTOPICS,
  MATH_LIBRARY_JAVA_ICSE9_SUBTOPICS,
  CONDITIONAL_CONSTRUCTS_ICSE9_SUBTOPICS,
  ITERATIVE_CONSTRUCTS_ICSE9_SUBTOPICS,
  INTERNAL_ASSESSMENT_CS_ICSE9_SUBTOPICS,
  OUR_CONSTITUTION_ICSE9_SUBTOPICS,
  ELECTIONS_ICSE9_SUBTOPICS,
  LOCAL_SELF_GOVERNMENT_ICSE9_SUBTOPICS,
  ANCIENT_INDIA_CIVILISATIONS_ICSE9_SUBTOPICS,
  MEDIEVAL_INDIA_CULTURE_ICSE9_SUBTOPICS,
  MODERN_AGE_EUROPE_ICSE9_SUBTOPICS,
  GEOGRAPHICAL_SKILLS_MAPWORK_ICSE9_SUBTOPICS,
  PHYSICAL_GEOGRAPHY_EARTH_ICSE9_SUBTOPICS,
  ATMOSPHERE_HYDROSPHERE_ICSE9_SUBTOPICS,
  ENVIRONMENT_NATURAL_REGIONS_ICSE9_SUBTOPICS,
  INTERNAL_ASSESSMENT_SOCIAL_SCIENCE_ICSE9_SUBTOPICS,
  GST_ICSE10_SUBTOPICS,
  BANKING_ICSE10_SUBTOPICS,
  LINEAR_INEQUALITIES_ICSE10_SUBTOPICS,
  QUADRATIC_EQUATIONS_ICSE10_SUBTOPICS,
  RATIO_PROPORTION_ICSE10_SUBTOPICS,
  FACTORIZATION_POLYNOMIALS_ICSE10_SUBTOPICS,
  MATRICES_ICSE10_SUBTOPICS,
  PROGRESSIONS_ICSE10_SUBTOPICS,
  REFLECTION_ICSE10_SUBTOPICS,
  SECTION_MIDPOINT_ICSE10_SUBTOPICS,
  EQUATION_LINE_ICSE10_SUBTOPICS,
  SIMILARITY_ICSE10_SUBTOPICS,
  LOCI_ICSE10_SUBTOPICS,
  CIRCLES_PROPERTIES_ICSE10_SUBTOPICS,
  MENSURATION_3D_ICSE10_SUBTOPICS,
  TRIGONOMETRY_IDENTITIES_ICSE10_SUBTOPICS,
  HEIGHTS_DISTANCES_ICSE10_SUBTOPICS,
  STATISTICS_ICSE10_SUBTOPICS,
  PROBABILITY_ICSE10_SUBTOPICS,
  SETS_ICSE11_SUBTOPICS,
  RELATIONS_FUNCTIONS_ICSE11_SUBTOPICS,
  TRIGONOMETRY_ICSE11_SUBTOPICS,
  MATHEMATICAL_INDUCTION_ICSE11_SUBTOPICS,
  COMPLEX_NUMBERS_QUADRATIC_ICSE11_SUBTOPICS,
  LINEAR_INEQUALITIES_ICSE11_SUBTOPICS,
  PERMUTATIONS_COMBINATIONS_ICSE11_SUBTOPICS,
  BINOMIAL_THEOREM_ICSE11_SUBTOPICS,
  SEQUENCE_SERIES_ICSE11_SUBTOPICS,
  STRAIGHT_LINES_ICSE11_SUBTOPICS,
  CIRCLES_ICSE11_SUBTOPICS,
  CALCULUS_LIMITS_DERIVATIVES_ICSE11_SUBTOPICS,
  STATISTICS_ICSE11_SUBTOPICS,
  PROBABILITY_ICSE11_SUBTOPICS,
  CONIC_SECTIONS_ICSE11_SUBTOPICS,
  THREE_DIMENSIONAL_GEOMETRY_ICSE11_SUBTOPICS,
  MATHEMATICAL_REASONING_ICSE11_SUBTOPICS,
  COMMERCIAL_STATISTICS_EXPECTATION_ICSE11_SUBTOPICS,
  CORRELATION_REGRESSION_ICSE11_SUBTOPICS,
  INDEX_NUMBERS_MOVING_AVERAGES_ICSE11_SUBTOPICS,
  PROJECT_WORK_ICSE11_SUBTOPICS,
  PHYSICAL_WORLD_MEASUREMENT_ICSE11_SUBTOPICS,
  KINEMATICS_ICSE11_SUBTOPICS,
  LAWS_OF_MOTION_ICSE11_SUBTOPICS,
  WORK_ENERGY_POWER_ICSE11_SUBTOPICS,
  SYSTEM_PARTICLES_RIGID_BODY_ICSE11_SUBTOPICS,
  GRAVITATION_ICSE11_SUBTOPICS,
  PROPERTIES_BULK_MATTER_ICSE11_SUBTOPICS,
  THERMODYNAMICS_PHYSICS_ICSE11_SUBTOPICS,
  KINETIC_THEORY_GASES_ICSE11_SUBTOPICS,
  OSCILLATIONS_WAVES_ICSE11_SUBTOPICS,
  PRACTICAL_PHYSICS_ICSE11_SUBTOPICS,
  FORCE_WORK_POWER_ENERGY_ICSE11_SUBTOPICS,
  LIGHT_OPTICS_ICSE11_SUBTOPICS,
  SOUND_ACOUSTICS_ICSE11_SUBTOPICS,
  ELECTRICITY_MAGNETISM_ICSE11_SUBTOPICS,
  HEAT_CALORIMETRY_ICSE11_SUBTOPICS,
  MODERN_PHYSICS_NUCLEAR_ICSE11_SUBTOPICS,
  SOME_BASIC_CONCEPTS_CHEM_ICSE11_SUBTOPICS,
  STRUCTURE_OF_ATOM_ICSE11_SUBTOPICS,
  CLASSIFICATION_ELEMENTS_PERIODICITY_ICSE11_SUBTOPICS,
  CHEMICAL_BONDING_MOLECULAR_ICSE11_SUBTOPICS,
  CHEMICAL_THERMODYNAMICS_ICSE11_SUBTOPICS,
  EQUILIBRIUM_ICSE11_SUBTOPICS,
  REDOX_REACTIONS_ICSE11_SUBTOPICS,
  INORGANIC_CHEMISTRY_S_P_BLOCK_ICSE11_SUBTOPICS,
  ORGANIC_CHEMISTRY_HYDROCARBONS_ICSE11_SUBTOPICS,
  ORGANIC_CHEMISTRY_BASIC_ICSE11_SUBTOPICS,
  HYDROCARBONS_ICSE11_SUBTOPICS,
  PRACTICAL_CHEMISTRY_ICSE11_SUBTOPICS,
  DIVERSITY_LIVING_ORGANISMS_ICSE11_SUBTOPICS,
  STRUCTURAL_ORGANISATION_ICSE11_SUBTOPICS,
  CELL_STRUCTURE_FUNCTION_ICSE11_SUBTOPICS,
  PLANT_PHYSIOLOGY_ICSE11_SUBTOPICS,
  HUMAN_PHYSIOLOGY_ICSE11_SUBTOPICS,
  PRACTICAL_BIOLOGY_ICSE11_SUBTOPICS,
  DATA_REP_BOOLEAN_ALG_ICSE11_SUBTOPICS,
  HARDWARE_ARCHITECTURE_ICSE11_SUBTOPICS,
  JAVA_OOP_CONCEPTS_ICSE11_SUBTOPICS,
  CONTROL_STRUCTURES_FUNCTIONS_ICSE11_SUBTOPICS,
  ARRAYS_STRINGS_ICSE11_SUBTOPICS,
  ADVANCED_OOP_FEATURES_ICSE11_SUBTOPICS,
  PRACTICAL_WORK_CS_ICSE11_SUBTOPICS,
  GROWTH_OF_NATIONALISM_ICSE11_SUBTOPICS,
  EMERGENCE_OF_RADICALS_ICSE11_SUBTOPICS,
  WWI_NATIONALIST_POLITICS_ICSE11_SUBTOPICS,
  GANDHIAN_ERA_MASS_NATIONALISM_ICSE11_SUBTOPICS,
  IMPACT_WWI_PEACE_SETTLEMENTS_ICSE11_SUBTOPICS,
  GREAT_DEPRESSION_TOTALITARIANISM_ICSE11_SUBTOPICS,
  WWII_COLLAPSE_COLLECTIVE_SECURITY_ICSE11_SUBTOPICS,
  RISE_OF_COMMUNISM_CHINA_ICSE11_SUBTOPICS,
  PROJECT_WORK_HISTORY_ICSE11_SUBTOPICS,
  EARTH_STRUCTURE_ENDOGENETIC_ICSE11_SUBTOPICS,
  EXOGENETIC_LANDFORMS_ICSE11_SUBTOPICS,
  ATMOSPHERE_HYDROSPHERE_ICSE11_SUBTOPICS,
  POPULATION_SETTLEMENTS_ICSE11_SUBTOPICS,
  PHYSICAL_FRAMEWORK_INDIA_ICSE11_SUBTOPICS,
  RESOURCES_ENVIRONMENT_INDIA_ICSE11_SUBTOPICS,
  PRACTICAL_GEOGRAPHY_ICSE11_SUBTOPICS,
  INTRO_POLITICAL_SCIENCE_ICSE11_SUBTOPICS,
  FUNDAMENTAL_POLITICAL_CONCEPTS_ICSE11_SUBTOPICS,
  FORMS_OF_GOVERNMENT_ICSE11_SUBTOPICS,
  CONSTITUTIONS_ORGANIC_STRUCTURES_ICSE11_SUBTOPICS,
  FRANCHISE_REPRESENTATION_PARTIES_ICSE11_SUBTOPICS,
  PROJECT_WORK_POLITICAL_SCIENCE_ICSE11_SUBTOPICS,
  ORIGIN_DEV_SOCIOLOGY_ICSE11_SUBTOPICS,
  RESEARCH_METHODOLOGY_SOCIOLOGY_ICSE11_SUBTOPICS,
  BASIC_CONCEPTS_SOCIOLOGY_ICSE11_SUBTOPICS,
  SOCIAL_STRUCTURE_SOCIOLOGY_ICSE11_SUBTOPICS,
  SOCIAL_PROBLEMS_SOCIOLOGY_ICSE11_SUBTOPICS,
  INDIAN_SOCIOLOGISTS_ICSE11_SUBTOPICS,
  PRACTICAL_SOCIOLOGY_ICSE11_SUBTOPICS,
  INTRO_PSYCHOLOGY_ICSE11_SUBTOPICS,
  METHODS_PSYCHOLOGY_ICSE11_SUBTOPICS,
  BIOLOGICAL_BASES_PSYCHOLOGY_ICSE11_SUBTOPICS,
  HUMAN_DEVELOPMENT_PSYCHOLOGY_ICSE11_SUBTOPICS,
  SENSORY_PERCEPTUAL_PSYCHOLOGY_ICSE11_SUBTOPICS,
  LEARNING_PSYCHOLOGY_ICSE11_SUBTOPICS,
  MEMORY_PSYCHOLOGY_ICSE11_SUBTOPICS,
  PRACTICAL_PSYCHOLOGY_ICSE11_SUBTOPICS,
  UNDERSTANDING_ECONOMICS_ICSE11_SUBTOPICS,
  CONSUMER_BEHAVIOUR_DEMAND_ICSE11_SUBTOPICS,
  PRODUCER_BEHAVIOUR_SUPPLY_COST_ICSE11_SUBTOPICS,
  MARKET_FORMS_PRICE_DET_ICSE11_SUBTOPICS,
  STRUCTURAL_FEATURES_INDIAN_ECON_ICSE11_SUBTOPICS,
  BASIC_STATISTICS_ECONOMICS_ICSE11_SUBTOPICS,
  PROJECT_WORK_ECONOMICS_ICSE11_SUBTOPICS
} from '../lib/constants';
import { generateAIResponse } from '../lib/gemini';
import { RoadmapCalendarModal } from './RoadmapCalendarModal';
import { ChemistryPeriodicOverlay } from './ChemistryPeriodicOverlay';
import confetti from 'canvas-confetti';
import { MixedPracticeSession } from './MixedPracticeSession';
import { FreeRecall } from './FreeRecall';
import { MetacognitionDashboard } from './MetacognitionDashboard';
import { LearningStyleCard } from './LearningStyleCard';
import { mapChapterTitleToId } from '../modules/interleaving/questionMixer';

interface SavedNote {
  id: string;
  title: string;
  summary: string;
  keyConcepts: string[];
  timestamp: number;
  subject: string;
  topic: string;
}

const getSubtopicPage = (sub: string, lessonDesc: string, sIdx: number, total: number, chapter: string) => {
  // Direct hardcoded overrides first to guarantee exact matches
  if (sub.includes("14.1 Carbohydrates") || (chapter.toLowerCase().includes("biomolecule") && sIdx === 0)) return 894;
  if (sub.includes("14.2 Proteins") || (chapter.toLowerCase().includes("biomolecule") && sIdx === 1)) return 905;
  if (sub.includes("14.3 Enzymes") || (chapter.toLowerCase().includes("biomolecule") && sIdx === 2)) return 914;
  if (sub.includes("14.4 Hormones") || (chapter.toLowerCase().includes("biomolecule") && sIdx === 3)) return 921;
  if (sub.includes("14.5 Nucleic Acids") || (chapter.toLowerCase().includes("biomolecule") && sIdx === 4)) return 928;
  if (sub.includes("14.6 Vitamins") || (chapter.toLowerCase().includes("biomolecule") && sIdx === 5)) return 935;
  if (chapter.toLowerCase().includes("biomolecule") && sIdx === 6) return 942;

  // Chemistry chapter page ranges
  let chStart = 0;
  let chEnd = 0;
  const chLower = chapter.toLowerCase();
  if (chLower.includes("solid state")) { chStart = 1; chEnd = 35; }
  else if (chLower.includes("solution")) { chStart = 36; chEnd = 69; }
  else if (chLower.includes("electrochemistry")) { chStart = 70; chEnd = 107; }
  else if (chLower.includes("kinetics")) { chStart = 108; chEnd = 143; }
  else if (chLower.includes("surface chemistry")) { chStart = 144; chEnd = 171; }
  else if (chLower.includes("isolation")) { chStart = 172; chEnd = 197; }
  else if (chLower.includes("p-block")) { chStart = 198; chEnd = 233; }
  else if (chLower.includes("d- and f-block")) { chStart = 234; chEnd = 265; }
  else if (chLower.includes("coordination")) { chStart = 266; chEnd = 301; }
  else if (chLower.includes("haloalkane")) { chStart = 302; chEnd = 337; }
  else if (chLower.includes("alcohol")) { chStart = 338; chEnd = 377; }
  else if (chLower.includes("aldehyde")) { chStart = 378; chEnd = 415; }
  else if (chLower.includes("amine")) { chStart = 416; chEnd = 442; }
  else if (chLower.includes("polymer")) { chStart = 950; chEnd = 983; }
  else if (chLower.includes("everyday life")) { chStart = 984; chEnd = 1010; }

  if (chStart > 0 && chEnd > 0) {
    if (total > 1) {
      if (sIdx === total - 1) return chEnd;
      const step = (chEnd - 2 - chStart) / Math.max(1, total - 2);
      return Math.min(chEnd - 1, Math.round(chStart + sIdx * step));
    }
    return chStart;
  }

  // Parse from description if available
  if (lessonDesc) {
    const match = lessonDesc.match(/\(Pages\s+(\d+)-(\d+)\)/);
    if (match) {
      const start = parseInt(match[1], 10);
      const end = parseInt(match[2], 10);
      if (total > 1) {
        if (sIdx === total - 1) return end;
        const step = (end - 2 - start) / Math.max(1, total - 2);
        return Math.min(end - 1, Math.round(start + sIdx * step));
      }
      return start;
    }
  }

  // General fallback using a simple deterministic hash of subtopic name
  let hash = 0;
  for (let i = 0; i < sub.length; i++) {
    hash = sub.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash % 100) + 100;
};

interface ChaptersExplorerProps {
  theme: 'light' | 'dark';
  subject: string;
  topic: string;
  difficulty: string;
  setTopic: (topic: string) => void;
  selectedBoard?: {
    nation: string;
    acronym: string;
  } | null;
  onStudyLesson: (lessonTitle: string, chapterTitle: string, depth?: 'quick' | 'standard' | 'deep' | 'academic') => void;
  onGenerateQuiz: (chapterTitle: string) => void;
  savedNotes: SavedNote[];
  onDeleteNote: (id: string) => void;
  onReorderNotes?: (newNotes: SavedNote[]) => void;
  initialTab?: 'syllabus' | 'notes';
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  mode: string;
  selectedEntranceExam: string;
  onRewardXp?: (xp: number) => void;
}

export const ChaptersExplorer: React.FC<ChaptersExplorerProps> = ({
  theme,
  subject,
  topic: activeTopic,
  difficulty,
  setTopic,
  selectedBoard,
  onStudyLesson,
  onGenerateQuiz,
  savedNotes,
  onDeleteNote,
  onReorderNotes,
  initialTab,
  showNotification,
  mode,
  selectedEntranceExam,
  onRewardXp
}) => {
  const [showReviewSession, setShowReviewSession] = useState(false);
  const [activeTab, setActiveTab] = useState<'syllabus' | 'notes' | 'public-seo' | 'roadmap' | 'goals' | 'periodic-table'>(initialTab || 'syllabus');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChapter, setSelectedChapter] = useState<string | null>(activeTopic || null);
  const [readingNote, setReadingNote] = useState<SavedNote | null>(null);
  const [chosenDepth, setChosenDepth] = useState<'quick' | 'standard' | 'deep' | 'academic'>('standard');
  const [expandedSubtopics, setExpandedSubtopics] = useState<Record<string, boolean>>({ l1: true });
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    organic: true,
    biomolecules: true,
    physical_inorganic: true,
    general: true
  });

  const getChapterCategory = (chapterName: string): { id: string; name: string; icon: string } => {
    const nameLower = chapterName.toLowerCase();
    
    // Biology checks
    if (
      nameLower.includes("reproduction") ||
      nameLower.includes("genetic") ||
      nameLower.includes("evolution") ||
      nameLower.includes("health") ||
      nameLower.includes("microbe") ||
      nameLower.includes("biotech") ||
      nameLower.includes("ecology") ||
      nameLower.includes("ecosystem") ||
      nameLower.includes("biodiversity") ||
      nameLower.includes("organism")
    ) {
      if (nameLower.includes("reproduction")) return { id: 'reproduction', name: 'Reproduction', icon: '🌱' };
      if (nameLower.includes("genetic") || nameLower.includes("evolution")) return { id: 'genetics', name: 'Genetics & Evolution', icon: '🧬' };
      if (nameLower.includes("ecology") || nameLower.includes("ecosystem") || nameLower.includes("biodiversity") || nameLower.includes("organism")) return { id: 'ecology', name: 'Ecology & Environment', icon: '🍃' };
      return { id: 'biology', name: 'Biology', icon: '🦠' };
    }

    // Biomolecules checks
    if (
      nameLower.includes("14. biomolecules") || 
      nameLower.includes("biomolecule") || 
      nameLower.includes("biochem") ||
      nameLower.includes("protein") ||
      nameLower.includes("nucleic") ||
      nameLower.includes("carbohydrate")
    ) {
      return { id: 'biomolecules', name: 'Biomolecules', icon: '🧬' };
    }
    
    // Organic Chemistry checks
    if (
      nameLower.includes("10.") || nameLower.includes("haloalkane") || nameLower.includes("haloarene") ||
      nameLower.includes("11.") || nameLower.includes("alcohol") || nameLower.includes("phenol") || nameLower.includes("ether") ||
      nameLower.includes("12.") || nameLower.includes("aldehyde") || nameLower.includes("ketone") || nameLower.includes("carboxylic") ||
      nameLower.includes("13.") || nameLower.includes("amine") || nameLower.includes("nitrogen") ||
      nameLower.includes("15.") || nameLower.includes("polymer") ||
      nameLower.includes("16.") || nameLower.includes("everyday life") ||
      nameLower.includes("organic") || nameLower.includes("hydrocarbon")
    ) {
      return { id: 'organic', name: 'Organic Chemistry', icon: '⚗️' };
    }
    
    // Default to Physical & Inorganic Chemistry for chemistry, or General Syllabus for other subjects
    if (subject.toLowerCase() === 'chemistry') {
      return { id: 'physical_inorganic', name: 'Physical & Inorganic Chemistry', icon: '🧪' };
    }
    
    return { id: 'general', name: 'General Syllabus', icon: '📘' };
  };

  const [localNotes, setLocalNotes] = useState<SavedNote[]>(savedNotes);
  React.useEffect(() => {
    setLocalNotes(savedNotes);
  }, [savedNotes]);

  const handleDragStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    const sourceIndexStr = e.dataTransfer.getData('text/plain');
    if (!sourceIndexStr) return;
    const sourceIndex = parseInt(sourceIndexStr, 10);
    if (isNaN(sourceIndex) || sourceIndex === targetIndex) return;

    const updated = [...localNotes];
    const [movedItem] = updated.splice(sourceIndex, 1);
    updated.splice(targetIndex, 0, movedItem);

    setLocalNotes(updated);
    onReorderNotes?.(updated);
    showNotification?.('Study notes reordered successfully', 'success');
  };

  const handleMoveNote = (e: React.MouseEvent, index: number, direction: 'up' | 'down') => {
    e.stopPropagation();
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= localNotes.length) return;

    const updated = [...localNotes];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;

    setLocalNotes(updated);
    onReorderNotes?.(updated);
    showNotification?.('Study notes reordered successfully', 'success');
  };

  // Study Roadmap States
  const [isGeneratingRoadmapTips, setIsGeneratingRoadmapTips] = useState(false);
  const [roadmapTips, setRoadmapTips] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(`roadmap_tips_${subject}`);
      return saved || '';
    } catch {
      return '';
    }
  });
  const [expandedWeeks, setExpandedWeeks] = useState<Record<number, boolean>>({ 1: true });
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  // Reminders state & persistence
  const [reminders, setReminders] = useState<{
    id: string;
    weekNumber: number;
    weekTitle: string;
    subject: string;
    triggerTime: number;
    isActive: boolean;
  }[]>(() => {
    try {
      const saved = localStorage.getItem(`study_reminders_${subject}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [reminderModalWeek, setReminderModalWeek] = useState<{ weekNumber: number; title: string } | null>(null);
  const [customMinutes, setCustomMinutes] = useState<string>("5");
  const [triggeredReminder, setTriggeredReminder] = useState<{
    weekNumber: number;
    weekTitle: string;
  } | null>(null);

  // Automated Milestones Sync States
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>("Just now");
  const [syncLogs, setSyncLogs] = useState<Array<{ id: string; msg: string; time: string }>>([]);
  const [showSyncLogs, setShowSyncLogs] = useState(false);

  React.useEffect(() => {
    const checkReminders = () => {
      const now = Date.now();
      let updated = false;
      const nextReminders = reminders.map(rem => {
        if (rem.isActive && rem.triggerTime <= now) {
          // Play a beautiful double chime
          try {
            const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
            if (AudioContext) {
              const ctx = new AudioContext();
              const playNote = (freq: number, delay: number, duration: number) => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.value = freq;
                gain.gain.setValueAtTime(0, ctx.currentTime + delay);
                gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + delay + 0.05);
                gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + delay + duration);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(ctx.currentTime + delay);
                osc.stop(ctx.currentTime + delay + duration);
              };
              playNote(523.25, 0, 0.4); // C5
              playNote(659.25, 0.12, 0.5); // E5
              playNote(783.99, 0.24, 0.6); // G5
            }
          } catch (e) {
            console.error('Audio chime failed:', e);
          }

          // Trigger in-app notification!
          if (showNotification) {
            showNotification(`⏰ WEEK REMINDER: Week ${rem.weekNumber} Study Plan is now active! Topic: ${rem.weekTitle} 🎓`, 'success');
          }

          // Set active modal state for high visibility
          setTriggeredReminder({
            weekNumber: rem.weekNumber,
            weekTitle: rem.weekTitle
          });

          updated = true;
          return { ...rem, isActive: false };
        }
        return rem;
      });

      if (updated) {
        setReminders(nextReminders);
        try {
          localStorage.setItem(`study_reminders_${subject}`, JSON.stringify(nextReminders));
        } catch (e) {
          console.error(e);
        }
      }
    };

    const interval = setInterval(checkReminders, 1000);
    return () => clearInterval(interval);
  }, [reminders, subject, showNotification]);

  const handleSetReminder = (weekNumber: number, title: string, delaySeconds: number) => {
    const triggerTime = Date.now() + (delaySeconds * 1000);
    const newReminder = {
      id: Math.random().toString(36).substring(2, 9),
      weekNumber,
      weekTitle: title,
      subject,
      triggerTime,
      isActive: true
    };
    
    // Remove any existing active reminders for same week
    const filtered = reminders.filter(r => !(r.weekNumber === weekNumber && r.isActive));
    const nextReminders = [...filtered, newReminder];
    
    setReminders(nextReminders);
    try {
      localStorage.setItem(`study_reminders_${subject}`, JSON.stringify(nextReminders));
    } catch (e) {
      console.error(e);
    }
    
    if (showNotification) {
      showNotification(`🔔 Reminder set for Week ${weekNumber}! Triggers in ${delaySeconds} seconds.`, 'success');
    }
    setReminderModalWeek(null);
  };

  const handleCancelReminder = (weekNumber: number) => {
    const nextReminders = reminders.map(r => 
      r.weekNumber === weekNumber ? { ...r, isActive: false } : r
    );
    setReminders(nextReminders);
    try {
      localStorage.setItem(`study_reminders_${subject}`, JSON.stringify(nextReminders));
    } catch (e) {
      console.error(e);
    }
    if (showNotification) {
      showNotification(`🔕 Reminder canceled for Week ${weekNumber}.`, 'info');
    }
    setReminderModalWeek(null);
  };

  // Public publishing and SEO landing page states
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishedUrl, setPublishedUrl] = useState<string | null>(null);
  const [copiedItemId, setCopiedItemId] = useState<string | null>(null);
  const [publicGuides, setPublicGuides] = useState<any[]>([]);
  const [loadingPublic, setLoadingPublic] = useState(false);

  const fetchPublicGuides = async () => {
    setLoadingPublic(true);
    try {
      const res = await fetch('/api/published-guides');
      if (res.ok) {
        const data = await res.json();
        setPublicGuides(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingPublic(false);
    }
  };

  React.useEffect(() => {
    if (activeTab === 'public-seo') {
      fetchPublicGuides();
    }
  }, [activeTab]);

  const handlePublishNote = async (note: SavedNote) => {
    setIsPublishing(true);
    setPublishedUrl(null);
    try {
      const res = await fetch('/api/publish-guide', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: note.title,
          subject: note.subject,
          topic: note.topic,
          summary: note.summary,
          keyConcepts: note.keyConcepts,
          author: "OmniTutor Scholar"
        })
      });
      if (res.ok) {
        const data = await res.json();
        setPublishedUrl(data.url);
        showNotification?.('Study guide successfully published as a crawlable SEO web page! 🚀', 'success');
        fetchPublicGuides(); // Refresh listing
      } else {
        showNotification?.('Failed to publish study guide.', 'error');
      }
    } catch (err) {
      console.error(err);
      showNotification?.('Network error during publishing.', 'error');
    } finally {
      setIsPublishing(false);
    }
  };

  const handleCopyLink = (url: string, id: string) => {
    const baseOrigin = getSyncShareUrl().split('?')[0].replace(/\/$/, '');
    const fullUrl = baseOrigin + url;
    navigator.clipboard.writeText(fullUrl).then(() => {
      setCopiedItemId(id);
      showNotification?.('SEO Link copied to clipboard! 📋', 'success');
      setTimeout(() => setCopiedItemId(null), 2500);
    });
  };

  // Dynamic lesson count and custom lessons state for unlimited study lessons
  const [lessonCounts, setLessonCounts] = useState<Record<string, number>>({});
  const [customLessons, setCustomLessons] = useState<Record<string, Array<{
    id: string;
    title: string;
    description: string;
    duration: string;
    level: string;
  }>>>({});

  // Inline custom lesson creation states
  const [isAddingCustom, setIsAddingCustom] = useState(false);
  const [customTitle, setCustomTitle] = useState('');
  const [customDescription, setCustomDescription] = useState('');
  const [customDuration, setCustomDuration] = useState('25 mins');
  const [customLevel, setCustomLevel] = useState('Intermediate');
  const [selectedDoubtChapter, setSelectedDoubtChapter] = useState<string | null>(null);

  const [completedLessons, setCompletedLessons] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('completed_lessons_v1');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const toggleLessonComplete = (lessonId: string) => {
    if (!selectedChapter) return;
    const key = `${selectedChapter}_${lessonId}`;
    setCompletedLessons(prev => {
      const updated = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem('completed_lessons_v1', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      if (showNotification) {
        showNotification(updated[key] ? 'Lesson marked as completed! 🎉' : 'Lesson marked as incomplete.', 'info');
      }
      if (updated[key]) {
        // Cognitive metadata updated; next interleaved practice session loads completed chapters automatically
      }
      return updated;
    });
  };

  // Daily Smart Study Goals State & Logic
  interface SmartGoal {
    id: string;
    title: string;
    description: string;
    type: 'syllabus' | 'quiz' | 'mastery' | 'interactive';
    progress: number;
    max: number;
    xpReward: number;
    status: 'not_started' | 'in_progress' | 'completed' | 'claimed';
    targetChapter?: string;
    targetLesson?: string;
    personalTip?: string;
  }

  const [goals, setGoals] = useState<SmartGoal[]>(() => {
    try {
      const saved = localStorage.getItem(`daily_goals_${subject}`);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  const [totalClaimedGoals, setTotalClaimedGoals] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`total_claimed_goals_${subject}`);
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  const [goalStreak, setGoalStreak] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`goals_streak_${subject}`);
      return saved ? parseInt(saved, 10) : 3;
    } catch {
      return 3;
    }
  });

  const [isGeneratingGoals, setIsGeneratingGoals] = useState(false);

  // Mini Drill states for Interactive/Quiz/Mastery goals
  const [activeDrillGoalId, setActiveDrillGoalId] = useState<string | null>(null);
  const [drillAnswers, setDrillAnswers] = useState<Record<number, number>>({});
  const [drillChecked, setDrillChecked] = useState(false);
  const [drillSuccess, setDrillSuccess] = useState(false);

  const getDrillQuestions = (chapterName: string) => {
    return [
      {
        q: `Which of the following is the standard mathematical discriminant formula for the quadratic equation ax² + bx + c = 0?`,
        options: [
          "a) D = b² + 4ac",
          "b) D = b² - 4ac",
          "c) D = -b ± √(b² - 4ac)",
          "d) D = b² - 2ac"
        ],
        correct: 1 // b
      },
      {
        q: `If the roots of a quadratic equation are real, equal, and rational, then the discriminant D must satisfy:`,
        options: [
          "a) D < 0",
          "b) D > 0 and is a perfect square",
          "c) D = 0",
          "d) D > 0 and is not a perfect square"
        ],
        correct: 2 // c
      },
      {
        q: `What is the product of roots (α · β) of the equation 2x² - 8x + 6 = 0?`,
        options: [
          "a) 4 (which is -b/a)",
          "b) 3 (which is c/a)",
          "c) -4 (which is b/a)",
          "d) 2"
        ],
        correct: 1 // b
      }
    ];
  };

  const generateLocalSmartGoals = (): SmartGoal[] => {
    const list: SmartGoal[] = [];
    
    // 1. Syllabus exploration goal: Find an unchecked lesson
    let targetCh = selectedChapter || (chapters && chapters[0]) || "Core Syllabus";
    let uncheckedLessonId = 'l1';
    let uncheckedLessonTitle = targetCh.toLowerCase().includes('communication') || targetCh.toLowerCase().includes('modulation') || targetCh.toLowerCase().includes('bandwidth')
      ? "Lesson 42 : Communication Systems"
      : targetCh.toLowerCase().includes('logic gate') || targetCh.toLowerCase().includes('de morgan') || targetCh.toLowerCase().includes('boolean')
      ? "Lesson 41 : Logic Gates"
      : targetCh.toLowerCase().includes('transistor') || targetCh.toLowerCase().includes('amplifier') || targetCh.toLowerCase().includes('bjt')
      ? "Lesson 40 : Junction Transistors"
      : targetCh.toLowerCase().includes('diode') || targetCh.toLowerCase().includes('zener') || targetCh.toLowerCase().includes('led') || targetCh.toLowerCase().includes('photodiode')
      ? "Lesson 39 : Semiconductor Diodes"
      : targetCh.toLowerCase().includes('semiconductor') || targetCh.toLowerCase().includes('rectifier')
      ? "Lesson 38 : Semiconductor Electronics"
      : targetCh.toLowerCase().includes('fission') || targetCh.toLowerCase().includes('fusion') || targetCh.toLowerCase().includes('nuclear reactor')
      ? "Lesson 37 : Nuclear Fission and Fusion : Sources of Energy"
      : targetCh.toLowerCase().includes('mass-energy') || targetCh.toLowerCase().includes('pair production')
      ? "Lesson 36 : Mass-Energy Equivalence : Nuclear Binding Energy"
      : targetCh.toLowerCase().includes('radioactivity') || targetCh.toLowerCase().includes('alpha decay') || targetCh.toLowerCase().includes('half-life')
      ? "Lesson 35 : Radioactivity"
      : targetCh.toLowerCase().includes('nuclear structure') || targetCh.toLowerCase().includes('binding energy per nucleon')
      ? "Lesson 34 : Nuclear Structure"
      : targetCh.toLowerCase().includes('bohr') || targetCh.toLowerCase().includes('hydrogen spectrum') || targetCh.toLowerCase().includes('origin of spectra') || targetCh.toLowerCase().includes('lyman') || targetCh.toLowerCase().includes('balmer')
      ? "Lesson 33 : Atom, Origin of Spectra : Bohr's Theory of Hydrogen Atom"
      : targetCh.toLowerCase().includes('x-ray') || targetCh.toLowerCase().includes('coolidge') || targetCh.toLowerCase().includes('moseley')
      ? "Lesson 32 : X-Rays"
      : targetCh.toLowerCase().includes('matter wave') || targetCh.toLowerCase().includes('de broglie') || targetCh.toLowerCase().includes('davisson')
      ? "Lesson 31 : Matter Waves"
      : targetCh.toLowerCase().includes('photoelectric') || targetCh.toLowerCase().includes('work function') || targetCh.toLowerCase().includes('stopping potential')
      ? "Lesson 30 : Photoelectric Effect"
      : targetCh.toLowerCase().includes('polarization') || targetCh.toLowerCase().includes('brewster') || targetCh.toLowerCase().includes('malus') || targetCh.toLowerCase().includes('polaroid')
      ? "Lesson 29 : Polarization of Light"
      : targetCh.toLowerCase().includes('diffraction') || targetCh.toLowerCase().includes('single slit')
      ? "Lesson 28 : Diffraction of Light"
      : targetCh.toLowerCase().includes('interference') || targetCh.toLowerCase().includes('double slit') || targetCh.toLowerCase().includes('ydse') || targetCh.toLowerCase().includes('fringe')
      ? "Lesson 27 : Interference of Light"
      : targetCh.toLowerCase().includes('huygen') || targetCh.toLowerCase().includes('wavefront') || targetCh.toLowerCase().includes('wave nature')
      ? "Lesson 26 : Wave Nature of Light : Huygens' Principle"
      : targetCh.toLowerCase().includes('microscope') || targetCh.toLowerCase().includes('telescope') || targetCh.toLowerCase().includes('optical instrument')
      ? "Lesson 25 : Optical Instruments"
      : targetCh.toLowerCase().includes('prism') || targetCh.toLowerCase().includes('dispersion') || targetCh.toLowerCase().includes('minimum deviation')
      ? "Lesson 24 : Refraction and Dispersion of Light through a Prism"
      : targetCh.toLowerCase().includes('spherical surface') || targetCh.toLowerCase().includes('lenses') || targetCh.toLowerCase().includes('lens maker')
      ? "Lesson 23 : Refraction of Light at Spherical Surfaces : Lenses"
      : targetCh.toLowerCase().includes('refraction') || targetCh.toLowerCase().includes('total internal reflection') || targetCh.toLowerCase().includes('optical fiber') || targetCh.toLowerCase().includes('snell')
      ? "Lesson 22 : Refraction of Light at a Plane Interface : Total Internal Reflection : Optical Fiber"
      : targetCh.toLowerCase().includes('reflection') || targetCh.toLowerCase().includes('spherical mirror') || targetCh.toLowerCase().includes('concave mirror') || targetCh.toLowerCase().includes('convex mirror')
      ? "Lesson 21 : Reflection of Light : Spherical Mirrors"
      : targetCh.toLowerCase().includes('communication') || targetCh.toLowerCase().includes('modulation') || targetCh.toLowerCase().includes('amplitude') || targetCh.toLowerCase().includes('bandwidth')
      ? "Lesson 20 : Communication Systems"
      : targetCh.toLowerCase().includes('semiconductor') || targetCh.toLowerCase().includes('logic gate') || targetCh.toLowerCase().includes('transistor') || targetCh.toLowerCase().includes('diode')
      ? "Lesson 19 : Semiconductor Electronics"
      : targetCh.toLowerCase().includes('nuclei') || targetCh.toLowerCase().includes('radioactivity') || targetCh.toLowerCase().includes('mass defect') || targetCh.toLowerCase().includes('binding energy')
      ? "Lesson 18 : Nuclei"
      : targetCh.toLowerCase().includes('atoms') || targetCh.toLowerCase().includes('rutherford') || targetCh.toLowerCase().includes('bohr') || targetCh.toLowerCase().includes('hydrogen spectrum')
      ? "Lesson 17 : Atoms"
      : targetCh.toLowerCase().includes('dual nature') || targetCh.toLowerCase().includes('radiation') || targetCh.toLowerCase().includes('photoelectric') || targetCh.toLowerCase().includes('matter wave')
      ? "Lesson 16 : Dual Nature of Radiation and Matter"
      : targetCh.toLowerCase().includes('wave optics') || targetCh.toLowerCase().includes('huygen') || targetCh.toLowerCase().includes('interference') || targetCh.toLowerCase().includes('diffraction') || targetCh.toLowerCase().includes('polarization')
      ? "Lesson 15 : Wave Optics"
      : targetCh.toLowerCase().includes('ray optics') || targetCh.toLowerCase().includes('optical instrument') || targetCh.toLowerCase().includes('telescope') || targetCh.toLowerCase().includes('prism')
      ? "Lesson 14 : Ray Optics and Optical Instruments"
      : targetCh.toLowerCase().includes('electromagnetic wave') || targetCh.toLowerCase().includes('em wave') || targetCh.toLowerCase().includes('spectrum')
      ? "Lesson 13 : Electromagnetic Waves"
      : targetCh.toLowerCase().includes('alternating current') || targetCh.toLowerCase().includes('ac circuit') || targetCh.toLowerCase().includes('transformer')
      ? "Lesson 12 : Alternating Current"
      : targetCh.toLowerCase().includes('induction') || targetCh.toLowerCase().includes('faraday')
      ? "Lesson 11 : Electromagnetic Induction"
      : targetCh.toLowerCase().includes('substance') || targetCh.toLowerCase().includes('diamagnetic') || targetCh.toLowerCase().includes('ferromagnetic')
      ? "Lesson 10 : Magnetic Classification of Substances"
      : targetCh.toLowerCase().includes('earth') || targetCh.toLowerCase().includes('terrestrial magnetism')
      ? "Lesson 9 : Magnetic Field and Earth's Magnetism"
      : targetCh.toLowerCase().includes('torque') || targetCh.toLowerCase().includes('galvanometer')
      ? "Lesson 8 : Torque on a Current-Loop : Moving-Coil Galvanometer"
      : targetCh.toLowerCase().includes('moving charge') || targetCh.toLowerCase().includes('magnetic field') || targetCh.toLowerCase().includes('biot')
      ? "Lesson 7 : Moving Charges and Magnetic Field"
      : targetCh.toLowerCase().includes('dc circuit') || targetCh.toLowerCase().includes('kirchhoff') || targetCh.toLowerCase().includes('potentiometer')
      ? "Lesson 6 : DC Circuits and Measurements"
      : targetCh.toLowerCase().includes('resistance') || targetCh.toLowerCase().includes('ohm')
      ? "Lesson 5 : Electric Resistance and Ohm's Law"
      : targetCh.toLowerCase().includes('capacitor') || targetCh.toLowerCase().includes('dielectric')
      ? "Lesson 4 : Capacitors and Dielectrics"
      : targetCh.toLowerCase().includes('potential')
      ? "Lesson 3 : Electric Potential"
      : targetCh.toLowerCase().includes('gauss')
      ? "Lesson 2 : Gauss' Theorem"
      : targetCh.toLowerCase().includes('electric charge') || targetCh.toLowerCase().includes('modern physics')
      ? "Lesson 1 : Electric Charges and Field"
      : "Foundations of " + targetCh;
    
    if (chapters && chapters.length > 0) {
      let found = false;
      for (const ch of chapters) {
        const lessons = getLessonsForChapter(ch, 'standard');
        for (const les of lessons) {
          const key = `${ch}_${les.id}`;
          if (!completedLessons[key]) {
            targetCh = ch;
            uncheckedLessonId = les.id;
            uncheckedLessonTitle = les.title;
            found = true;
            break;
          }
        }
        if (found) break;
      }
    }

    list.push({
      id: 'g-syllabus-1',
      title: `Explore Lesson: "${uncheckedLessonTitle}"`,
      description: `Read the syllabus concepts and complete study tasks for this lesson in Chapters Explorer.`,
      type: 'syllabus',
      progress: completedLessons[`${targetCh}_${uncheckedLessonId}`] ? 1 : 0,
      max: 1,
      xpReward: 150,
      status: completedLessons[`${targetCh}_${uncheckedLessonId}`] ? 'completed' : 'not_started',
      targetChapter: targetCh,
      targetLesson: uncheckedLessonId,
      personalTip: "💡 Tip: Switch to 'Deep' or 'Academic' rigor to clear advanced boundary questions."
    });

    // 2. Practice Quiz Goal
    list.push({
      id: 'g-quiz-1',
      title: `Practice Drill: Complete Quiz in "${targetCh}"`,
      description: `Generate a custom practice quiz for this topic. Clear it with over 70% score to reinforce conceptual memory.`,
      type: 'quiz',
      progress: 0,
      max: 1,
      xpReward: 200,
      status: 'not_started',
      targetChapter: targetCh,
      personalTip: "💡 Tip: Direct practice quizzes trigger neural recall loops, protecting you from passive reading bias."
    });

    // 3. Mastery Refinement Goal
    let weakTopic = targetCh;
    let weakMastery = 48;
    if (chapters && chapters.length > 1) {
      weakTopic = chapters[1];
      weakMastery = 35 + (weakTopic.charCodeAt(0) % 30);
    }

    list.push({
      id: 'g-mastery-1',
      title: `Refine Topic Mastery: "${weakTopic}"`,
      description: `Review equation sheets and derivations to bolster weak areas (current topic diagnostics: ${weakMastery}%).`,
      type: 'mastery',
      progress: 0,
      max: 1,
      xpReward: 250,
      status: 'not_started',
      targetChapter: weakTopic,
      personalTip: "💡 Tip: Practice high-calibration problems in the Practice Simulator to directly upgrade your mastery rating."
    });

    // 4. Interactive Engagement Goal
    list.push({
      id: 'g-interactive-1',
      title: `Deep Focus: 15-Minute Pomodoro Study`,
      description: `Avoid exam fatigue by starting a structured Pomodoro study block. Use alpha-wave binaural beats.`,
      type: 'interactive',
      progress: 0,
      max: 1,
      xpReward: 120,
      status: 'not_started',
      personalTip: "💡 Tip: Sound synthesis block in OmniTutor creates tailored frequencies to hold focus."
    });

    return list;
  };

  const handleAICalibrateGoals = async () => {
    setIsGeneratingGoals(true);
    if (showNotification) {
      showNotification("🧠 Omni AI is analyzing your syllabus completion rates and mastery indexes to draft micro-objectives...", "info");
    }

    const currentLocalList = generateLocalSmartGoals();
    const currentWeeks = generateRoadmapWeeks();
    const completedCount = currentWeeks.filter(w => w.status === 'completed').length;
    const totalCount = currentWeeks.length;
    const completionPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

    const prompt = `You are an expert AI Learning Coach calibrating high-engagement daily study micro-objectives.
Subject: ${subject}
Active Theme: ${activeTopic}
Milestone Progress: ${completionPercent}% (${completedCount}/${totalCount} roadmap weeks cleared)
Rigor: ${difficulty}

Here is a list of recommended baseline goals to customize:
${JSON.stringify(currentLocalList, null, 2)}

Provide a customized, highly encouraging set of exactly 4 daily smart goals in JSON format. Refine the titles and descriptions to align with the subject domain, and add a personalized coaching tip ('personalTip') for each to make it sound extremely motivating and tailored for high-stakes exam preparation.

Return ONLY a valid JSON array of objects conforming to the following TypeScript interface:
interface SmartGoal {
  id: string; // MUST keep baseline IDs: 'g-syllabus-1', 'g-quiz-1', 'g-mastery-1', 'g-interactive-1'
  title: string;
  description: string;
  type: 'syllabus' | 'quiz' | 'mastery' | 'interactive';
  progress: number;
  max: number;
  xpReward: number;
  status: 'not_started' | 'in_progress' | 'completed';
  targetChapter?: string;
  targetLesson?: string;
  personalTip: string;
}

Do not wrap in backticks or markdown, return ONLY the raw JSON array.`;

    try {
      const response = await generateAIResponse(prompt, {
        model: "gemini-3.6-flash",
        responseMimeType: "application/json"
      });

      if (response) {
        let parsed = JSON.parse(response.trim());
        if (Array.isArray(parsed) && parsed.length === 4) {
          const syllabusGoal = parsed.find(g => g.id === 'g-syllabus-1');
          if (syllabusGoal && syllabusGoal.targetChapter && syllabusGoal.targetLesson) {
            const completed = completedLessons[`${syllabusGoal.targetChapter}_${syllabusGoal.targetLesson}`];
            if (completed) {
              syllabusGoal.progress = 1;
              syllabusGoal.status = 'completed';
            }
          }

          setGoals(parsed);
          localStorage.setItem(`daily_goals_${subject}`, JSON.stringify(parsed));
          if (showNotification) {
            showNotification("🎯 Daily goals successfully re-calibrated by Omni AI! Go conquer your session!", "success");
          }
          setIsGeneratingGoals(false);
          return;
        }
      }
    } catch (e) {
      console.error("Gemini goal calibration failed, using robust local baseline:", e);
    }

    const localBaseline = generateLocalSmartGoals();
    setGoals(localBaseline);
    localStorage.setItem(`daily_goals_${subject}`, JSON.stringify(localBaseline));
    setIsGeneratingGoals(false);
  };

  const playClaimRewardSound = () => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContext) {
        const ctx = new AudioContext();
        const playTone = (freq: number, startTime: number, duration: number) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, startTime);
          gain.gain.setValueAtTime(0.08, startTime);
          gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(startTime);
          osc.stop(startTime + duration);
        };

        const now = ctx.currentTime;
        playTone(523.25, now, 0.12);
        playTone(659.25, now + 0.08, 0.12);
        playTone(783.99, now + 0.16, 0.12);
        playTone(1046.50, now + 0.24, 0.35);
      }
    } catch (e) {
      console.error(e);
    }
  };

  React.useEffect(() => {
    if (goals.length === 0) {
      const initial = generateLocalSmartGoals();
      setGoals(initial);
      localStorage.setItem(`daily_goals_${subject}`, JSON.stringify(initial));
    }
  }, [goals, subject]);

  React.useEffect(() => {
    if (goals.length > 0) {
      let changed = false;
      const updatedGoals = goals.map(goal => {
        if (goal.id === 'g-syllabus-1' && goal.targetChapter && goal.targetLesson) {
          const isCompleted = !!completedLessons[`${goal.targetChapter}_${goal.targetLesson}`];
          const newStatus = isCompleted ? 'completed' : 'not_started';
          const newProgress = isCompleted ? 1 : 0;
          
          if (goal.progress !== newProgress || goal.status !== newStatus) {
            changed = true;
            if (isCompleted && showNotification) {
              showNotification("🎉 SMART GOAL COMPLETED: Target lesson explored! Claim your XP in the Goals tab.", "success");
            }
            return {
              ...goal,
              progress: newProgress,
              status: isCompleted ? 'completed' as const : 'not_started' as const
            };
          }
        }
        return goal;
      });

      if (changed) {
        setGoals(updatedGoals);
        localStorage.setItem(`daily_goals_${subject}`, JSON.stringify(updatedGoals));
      }
    }
  }, [completedLessons, subject]);

  // Get current syllabus chapters/lessons based on board/subject
  const boardName = mode === 'entrance' 
    ? (selectedEntranceExam && CONFIG.ENTRANCE_EXAMS_DATA[selectedEntranceExam as keyof typeof CONFIG.ENTRANCE_EXAMS_DATA]
      ? CONFIG.ENTRANCE_EXAMS_DATA[selectedEntranceExam as keyof typeof CONFIG.ENTRANCE_EXAMS_DATA].name
      : selectedEntranceExam || 'Entrance Exam')
    : mode === 'competitive'
    ? 'Olympiad & Jobs Exams Arena'
    : (selectedBoard ? selectedBoard.acronym : 'Standard');
  const curriculum = React.useMemo(() => {
    return selectedBoard 
      ? getBoardCurriculum(selectedBoard.nation, selectedBoard.acronym, difficulty) 
      : null;
  }, [selectedBoard?.nation, selectedBoard?.acronym, difficulty]);

  const chapters = React.useMemo(() => {
    return mode === 'entrance' 
      ? (selectedEntranceExam && (CONFIG.ENTRANCE_EXAMS_DATA as any)[selectedEntranceExam]
        ? ((CONFIG.ENTRANCE_EXAMS_DATA as any)[selectedEntranceExam].topics[subject] || [])
        : (curriculum?.topics[subject] || CONFIG.TOPICS[subject as keyof typeof CONFIG.TOPICS] || []))
      : (curriculum?.topics[subject] || CONFIG.TOPICS[subject as keyof typeof CONFIG.TOPICS] || []);
  }, [mode, selectedEntranceExam, subject, curriculum]);

  const handleSelectChapter = (chapter: string) => {
    setSelectedChapter(chapter);
    const snakeTopic = chapter.toLowerCase().replace(/\s+/g, '_');
    setTopic(snakeTopic);
    setIsAddingCustom(false);
  };

  // Sync selected chapter when activeTopic, subject, or selectedEntranceExam changes
  React.useEffect(() => {
    if (chapters && chapters.length > 0) {
      // Find chapter that matches activeTopic (either as direct string or snake_case)
      const matching = chapters.find((ch: string) => {
        const snake = ch.toLowerCase().replace(/\s+/g, '_');
        const snakeTopic = activeTopic.toLowerCase().replace(/\s+/g, '_');
        return snake === snakeTopic || ch === activeTopic || ch.toLowerCase() === activeTopic.toLowerCase();
      });
      if (matching) {
        setSelectedChapter(prev => (prev === matching ? prev : matching));
      } else {
        setSelectedChapter(prev => (prev === chapters[0] ? prev : chapters[0]));
      }
    } else {
      setSelectedChapter(prev => (prev === null ? prev : null));
    }
  }, [activeTopic, subject, selectedEntranceExam, chapters]);

  const getLessonsForChapter = (chapter: string, depth: 'quick' | 'standard' | 'deep' | 'academic') => {
    const multiplier = depth === 'quick' ? 0.5 : depth === 'standard' ? 1 : depth === 'deep' ? 1.8 : 2.5;
    const rigorText = 
      depth === 'quick' ? " (Review/Recap)" :
      depth === 'standard' ? " (Standard Study)" :
      depth === 'deep' ? " (Axiomatic Proofs)" :
      " (MIT/IIT Graduate Core)";

    const isElectricCharges = 
      chapter.toLowerCase().includes('electric charge') ||
      chapter.toLowerCase().includes('electric charges') ||
      chapter.toLowerCase().includes('modern physics') ||
      chapter === '1. Electric Charges and Field';

    const isGaussTheorem =
      chapter.toLowerCase().includes('gauss') ||
      chapter === "2. Gauss' Theorem";

    const isElectricPotential =
      chapter.toLowerCase().includes('potential') ||
      chapter === "3. Electric Potential";

    const isCapacitors =
      chapter.toLowerCase().includes('capacitor') ||
      chapter.toLowerCase().includes('dielectric') ||
      chapter === "4. Capacitors and Dielectrics";

    const isResistance =
      chapter.toLowerCase().includes('resistance') ||
      chapter.toLowerCase().includes('ohm') ||
      chapter === "5. Electric Resistance and Ohm's Law";

    const isDCCircuits =
      chapter.toLowerCase().includes('dc circuit') ||
      chapter.toLowerCase().includes('kirchhoff') ||
      chapter.toLowerCase().includes('potentiometer') ||
      chapter === "6. DC Circuits and Measurements";

    const isMovingCharges =
      (chapter.toLowerCase().includes('moving charge') ||
      chapter === "7. Moving Charges and Magnetic Field") &&
      !chapter.toLowerCase().includes('earth');

    const isTorqueLoop =
      chapter.toLowerCase().includes('torque') ||
      chapter.toLowerCase().includes('galvanometer') ||
      chapter === "8. Torque on a Current-Loop : Moving-Coil Galvanometer";

    const isEarthMagnetism =
      chapter.toLowerCase().includes('earth') ||
      chapter.toLowerCase().includes('terrestrial magnetism') ||
      chapter === "9. Magnetic Field and Earth's Magnetism";

    const isMagneticSubstances =
      chapter.toLowerCase().includes('substance') ||
      chapter.toLowerCase().includes('diamagnetic') ||
      chapter.toLowerCase().includes('ferromagnetic') ||
      chapter.toLowerCase().includes('hysteresis') ||
      chapter === "10. Magnetic Classification of Substances";

    const isElectromagneticInduction =
      chapter.toLowerCase().includes('induction') ||
      chapter.toLowerCase().includes('faraday') ||
      chapter === "11. Electromagnetic Induction";

    const isAlternatingCurrent =
      chapter.toLowerCase().includes('alternating current') ||
      chapter.toLowerCase().includes('ac circuit') ||
      chapter.toLowerCase().includes('transformer') ||
      chapter === "12. Alternating Current";

    const isElectromagneticWaves =
      chapter.toLowerCase().includes('electromagnetic wave') ||
      chapter.toLowerCase().includes('em wave') ||
      chapter.toLowerCase().includes('spectrum') ||
      chapter === "13. Electromagnetic Waves";

    const isRayOptics =
      chapter.toLowerCase().includes('ray optics') ||
      chapter.toLowerCase().includes('optical instrument') ||
      chapter.toLowerCase().includes('telescope') ||
      chapter.toLowerCase().includes('prism') ||
      chapter === "14. Ray Optics and Optical Instruments";

    const isWaveOptics =
      chapter.toLowerCase().includes('wave optics') ||
      chapter.toLowerCase().includes('huygen') ||
      chapter.toLowerCase().includes('interference') ||
      chapter.toLowerCase().includes('diffraction') ||
      chapter.toLowerCase().includes('polarization') ||
      chapter === "15. Wave Optics";

    const isDualNature =
      chapter.toLowerCase().includes('dual nature') ||
      chapter.toLowerCase().includes('radiation') ||
      chapter.toLowerCase().includes('photoelectric') ||
      chapter.toLowerCase().includes('matter wave') ||
      chapter === "16. Dual Nature of Radiation and Matter";

    const isAtoms =
      chapter.toLowerCase().includes('atoms') ||
      chapter.toLowerCase().includes('rutherford') ||
      chapter.toLowerCase().includes('bohr') ||
      chapter.toLowerCase().includes('hydrogen spectrum') ||
      chapter === "17. Atoms";

    const isNuclei =
      chapter.toLowerCase().includes('nuclei') ||
      chapter.toLowerCase().includes('radioactivity') ||
      chapter.toLowerCase().includes('mass defect') ||
      chapter.toLowerCase().includes('binding energy') ||
      chapter === "18. Nuclei";

    const isCommunicationSystemsLesson =
      chapter.toLowerCase().includes('communication') ||
      chapter.toLowerCase().includes('modulation') ||
      chapter === "42. Communication Systems";

    const isLogicGates =
      !isCommunicationSystemsLesson && (
        chapter.toLowerCase().includes('logic gate') ||
        chapter.toLowerCase().includes('de morgan') ||
        chapter === "41. Logic Gates"
      );

    const isJunctionTransistors =
      !isCommunicationSystemsLesson && !isLogicGates && (
        chapter.toLowerCase().includes('transistor') ||
        chapter.toLowerCase().includes('amplifier') ||
        chapter === "40. Junction Transistors"
      );

    const isSemiconductorDiodes =
      !isCommunicationSystemsLesson && !isLogicGates && !isJunctionTransistors && (
        chapter.toLowerCase().includes('diode') ||
        chapter.toLowerCase().includes('zener') ||
        chapter.toLowerCase().includes('led') ||
        chapter === "39. Semiconductor Diodes"
      );

    const isSemiconductorElectronicsLesson =
      !isCommunicationSystemsLesson && !isLogicGates && !isJunctionTransistors && !isSemiconductorDiodes && (
        chapter.toLowerCase().includes('rectifier') ||
        chapter === "38. Semiconductor Electronics"
      );

    const isFissionFusion =
      !isSemiconductorElectronicsLesson && (
        chapter.toLowerCase().includes('fission') ||
        chapter.toLowerCase().includes('fusion') ||
        chapter === "37. Nuclear Fission and Fusion : Sources of Energy"
      );

    const isMassEnergyBinding =
      !isSemiconductorElectronicsLesson && !isFissionFusion && (
        chapter.toLowerCase().includes('mass-energy equivalence') ||
        chapter.toLowerCase().includes('nuclear binding energy') ||
        chapter === "36. Mass-Energy Equivalence : Nuclear Binding Energy"
      );

    const isRadioactivity =
      !isSemiconductorElectronicsLesson && !isFissionFusion && !isMassEnergyBinding && (
        chapter.toLowerCase().includes('soddy') ||
        chapter.toLowerCase().includes('half-life') ||
        chapter === "35. Radioactivity"
      );

    const isNuclearStructure =
      !isSemiconductorElectronicsLesson && !isFissionFusion && !isMassEnergyBinding && !isRadioactivity && (
        chapter.toLowerCase().includes('nuclear structure') ||
        chapter.toLowerCase().includes('binding energy per nucleon') ||
        chapter === "34. Nuclear Structure"
      );

    const isAtomsBohr =
      !isNuclearStructure && (
        chapter.toLowerCase().includes('origin of spectra') ||
        chapter.toLowerCase().includes('bohr\'s theory') ||
        chapter === "33. Atom, Origin of Spectra : Bohr's Theory of Hydrogen Atom"
      );

    const isXRays =
      !isNuclearStructure && !isAtomsBohr && (
        chapter.toLowerCase().includes('x-ray') ||
        chapter.toLowerCase().includes('coolidge') ||
        chapter.toLowerCase().includes('moseley') ||
        chapter === "32. X-Rays"
      );

    const isMatterWaves =
      !isNuclearStructure && !isAtomsBohr && !isXRays && (
        chapter.toLowerCase().includes('matter wave') ||
        chapter.toLowerCase().includes('de broglie') ||
        chapter.toLowerCase().includes('davisson') ||
        chapter === "31. Matter Waves"
      );

    const isPhotoelectric =
      !isMatterWaves && (
        chapter.toLowerCase().includes('photoelectric') ||
        chapter.toLowerCase().includes('work function') ||
        chapter.toLowerCase().includes('stopping potential') ||
        chapter === "30. Photoelectric Effect"
      );

    const isPolarization =
      !isMatterWaves && !isPhotoelectric && (
        chapter.toLowerCase().includes('polarization') ||
        chapter.toLowerCase().includes('brewster') ||
        chapter.toLowerCase().includes('malus') ||
        chapter.toLowerCase().includes('polaroid') ||
        chapter === "29. Polarization of Light"
      );

    const isDiffraction =
      !isMatterWaves && !isPhotoelectric && !isPolarization && (
        chapter.toLowerCase().includes('diffraction') ||
        chapter.toLowerCase().includes('single slit') ||
        chapter === "28. Diffraction of Light"
      );

    const isInterference =
      !isDiffraction && (
        chapter.toLowerCase().includes('interference') ||
        chapter.toLowerCase().includes('double slit') ||
        chapter.toLowerCase().includes('ydse') ||
        chapter.toLowerCase().includes('fringe') ||
        chapter === "27. Interference of Light"
      );

    const isWaveNatureHuygens =
      !isDiffraction && !isInterference && (
        chapter.toLowerCase().includes('huygen') ||
        chapter.toLowerCase().includes('wavefront') ||
        chapter.toLowerCase().includes('wave nature') ||
        chapter === "26. Wave Nature of Light : Huygens' Principle"
      );

    const isOpticalInstruments =
      !isWaveNatureHuygens && (
        chapter.toLowerCase().includes('microscope') ||
        chapter.toLowerCase().includes('telescope') ||
        chapter.toLowerCase().includes('optical instrument') ||
        chapter === "25. Optical Instruments"
      );

    const isRefractionPrism =
      !isOpticalInstruments && (
        chapter.toLowerCase().includes('prism') ||
        chapter.toLowerCase().includes('dispersion') ||
        chapter.toLowerCase().includes('minimum deviation') ||
        chapter === "24. Refraction and Dispersion of Light through a Prism"
      );

    const isRefractionLenses =
      !isRefractionPrism && (
        chapter.toLowerCase().includes('spherical surface') ||
        chapter.toLowerCase().includes('lenses') ||
        chapter.toLowerCase().includes('lens maker') ||
        chapter === "23. Refraction of Light at Spherical Surfaces : Lenses"
      );

    const isRefractionPlane =
      !isRefractionLenses && (
        chapter.toLowerCase().includes('refraction') ||
        chapter.toLowerCase().includes('total internal reflection') ||
        chapter.toLowerCase().includes('optical fiber') ||
        chapter.toLowerCase().includes('snell') ||
        chapter === "22. Refraction of Light at a Plane Interface : Total Internal Reflection : Optical Fiber"
      );

    const isReflection =
      chapter.toLowerCase().includes('reflection') ||
      chapter.toLowerCase().includes('spherical mirror') ||
      chapter.toLowerCase().includes('concave mirror') ||
      chapter.toLowerCase().includes('convex mirror') ||
      chapter === "21. Reflection of Light : Spherical Mirrors";

    const isCommunication =
      chapter.toLowerCase().includes('communication') ||
      chapter.toLowerCase().includes('modulation') ||
      chapter.toLowerCase().includes('amplitude') ||
      chapter.toLowerCase().includes('bandwidth') ||
      chapter === "20. Communication Systems";

    const isSemiconductor =
      chapter.toLowerCase().includes('semiconductor') ||
      chapter.toLowerCase().includes('logic gate') ||
      chapter.toLowerCase().includes('transistor') ||
      chapter.toLowerCase().includes('diode') ||
      chapter === "19. Semiconductor Electronics";

    const isSexualReproductionPlants =
      chapter.toLowerCase().includes('flowering plant') ||
      chapter.toLowerCase().includes('sexual reproduction in flowering');

    const isHumanReproduction =
      chapter.toLowerCase().includes('human reproduction') && !chapter.toLowerCase().includes('health');

    const isReproductiveHealth =
      chapter.toLowerCase().includes('reproductive health');

    const isPrinciplesInheritance =
      chapter.toLowerCase().includes('principles of inheritance') ||
      chapter.toLowerCase().includes('variation');

    const isMolecularBasis =
      chapter.toLowerCase().includes('molecular basis');

    const isEvolution =
      chapter.toLowerCase().includes('evolution');

    const isHumanHealth =
      chapter.toLowerCase().includes('human health') ||
      chapter.toLowerCase().includes('disease');

    const isMicrobes =
      chapter.toLowerCase().includes('microbes');

    const isBiotechPrinciples =
      chapter.toLowerCase().includes('biotechnology: principles') ||
      chapter.toLowerCase().includes('principles and processes');

    const isBiotechApps =
      chapter.toLowerCase().includes('biotechnology and its applications') ||
      (chapter.toLowerCase().includes('biotechnology') && chapter.toLowerCase().includes('application'));

    const isOrganismsPopulations =
      chapter.toLowerCase().includes('organisms and populations');

    const isEcosystem =
      chapter.toLowerCase().includes('ecosystem');

    const isBiodiversity =
      chapter.toLowerCase().includes('biodiversity');

    const isPythonRevision =
      chapter.toLowerCase().includes('python revision') ||
      chapter.toLowerCase().includes('revision tour');

    const isCSFunctions =
      chapter.toLowerCase().includes('functions') && 
      (subject.toLowerCase().includes('computer') || subject.toLowerCase().includes('cs'));

    const isFileHandling =
      chapter.toLowerCase().includes('file handling');

    const isCSDataStructures =
      chapter.toLowerCase().includes('data structures') && 
      (subject.toLowerCase().includes('computer') || subject.toLowerCase().includes('cs'));

    const isCSComputerNetworks =
      chapter.toLowerCase().includes('computer networks') && 
      (subject.toLowerCase().includes('computer') || subject.toLowerCase().includes('cs'));

    const isDatabaseManagement =
      chapter.toLowerCase().includes('database management') || 
      chapter.toLowerCase().includes('sql');

    const isSocietalImpacts =
      chapter.toLowerCase().includes('societal impacts') ||
      chapter.toLowerCase().includes('cyber ethics');

    const isBricksBeads =
      chapter.toLowerCase().includes('bricks') ||
      chapter.toLowerCase().includes('harappan');

    const isKingsFarmers =
      chapter.toLowerCase().includes('kings, farmers') ||
      chapter.toLowerCase().includes('early states');

    const isKinshipCaste =
      chapter.toLowerCase().includes('kinship') ||
      chapter.toLowerCase().includes('early societies');

    const isThinkersBeliefs =
      chapter.toLowerCase().includes('thinkers') ||
      chapter.toLowerCase().includes('cultural developments');

    const isTravellers =
      chapter.toLowerCase().includes('travellers') ||
      chapter.toLowerCase().includes('perceptions of society');

    const isBhaktiSufi =
      chapter.toLowerCase().includes('bhakti') ||
      chapter.toLowerCase().includes('sufi');

    const isVijayanagara =
      chapter.toLowerCase().includes('vijayanagara') ||
      chapter.toLowerCase().includes('imperial capital');

    const isPeasantsZamindars =
      chapter.toLowerCase().includes('peasants') ||
      chapter.toLowerCase().includes('agrarian society');

    const isColonialismCountryside =
      chapter.toLowerCase().includes('colonialism and the countryside');

    const isRebelsRaj =
      chapter.toLowerCase().includes('rebels and the raj') ||
      chapter.toLowerCase().includes('1857');

    const isGandhiMovement =
      chapter.toLowerCase().includes('mahatma gandhi') ||
      chapter.toLowerCase().includes('nationalist movement');

    const isFramingConstitution =
      chapter.toLowerCase().includes('framing the constitution');

    const isGeogHumanNature =
      chapter.toLowerCase().includes('human geography') && chapter.toLowerCase().includes('nature');

    const isGeogWorldPop =
      chapter.toLowerCase().includes('world population');

    const isGeogHumanDev =
      chapter.toLowerCase().includes('human development') && 
      (subject.toLowerCase().includes('geography') || subject.toLowerCase().includes('geog'));

    const isGeogPrimary =
      chapter.toLowerCase().includes('primary activities');

    const isGeogSecondary =
      chapter.toLowerCase().includes('secondary activities');

    const isGeogTertiary =
      chapter.toLowerCase().includes('tertiary and quaternary') ||
      chapter.toLowerCase().includes('tertiary activities');

    const isGeogTransport =
      chapter.toLowerCase().includes('transport and communication');

    const isGeogInternationalTrade =
      chapter.toLowerCase().includes('international trade');

    const isGeogHumanSettlements =
      chapter.toLowerCase().includes('human settlements');

    const isEndOfBipolarity =
      chapter.toLowerCase().includes('end of bipolarity');

    const isContemporaryCentres =
      chapter.toLowerCase().includes('contemporary centres of power');

    const isContemporarySouthAsia =
      chapter.toLowerCase().includes('contemporary south asia');

    const isIntlOrganizations =
      chapter.toLowerCase().includes('international organizations');

    const isSecurityContemporary =
      chapter.toLowerCase().includes('security in the contemporary world');

    const isEnvironmentResources =
      chapter.toLowerCase().includes('environment and natural resources');

    const isGlobalizationPol =
      chapter.toLowerCase().includes('globalization') && 
      (subject.toLowerCase().includes('political') || subject.toLowerCase().includes('pol'));

    const isChallengesNationBuilding =
      chapter.toLowerCase().includes('challenges of nation-building');

    const isRecentDevelopmentsPol =
      chapter.toLowerCase().includes('recent developments');

    const isSocDemography =
      chapter.toLowerCase().includes('demographic structure');

    const isSocInstitutions =
      chapter.toLowerCase().includes('social institutions');

    const isSocInequality =
      chapter.toLowerCase().includes('patterns of social inequality');

    const isSocDiversity =
      chapter.toLowerCase().includes('challenges of cultural diversity');

    const isSocStructuralChange =
      chapter.toLowerCase().includes('structural change');

    const isSocCulturalChange =
      chapter.toLowerCase().includes('cultural change');

    const isSocRuralSociety =
      chapter.toLowerCase().includes('rural society');

    const isSocIndustrialSociety =
      chapter.toLowerCase().includes('industrial society');

    const isSocSocialMovements =
      chapter.toLowerCase().includes('social movements');

    const isPsychVariations =
      chapter.toLowerCase().includes('variations in psychological attributes');

    const isPsychPersonality =
      chapter.toLowerCase().includes('self and personality');

    const isPsychChallenges =
      chapter.toLowerCase().includes('meeting life challenges');

    const isPsychDisorders =
      chapter.toLowerCase().includes('psychological disorders');

    const isPsychTherapy =
      chapter.toLowerCase().includes('therapeutic approaches');

    const isPsychSocial =
      chapter.toLowerCase().includes('attitude and social cognition');

    const isPsychGroups =
      chapter.toLowerCase().includes('social influence and group processes');

    const isEconMacroIntro =
      chapter.toLowerCase().includes('introduction to macroeconomics');

    const isEconNationalIncome =
      chapter.toLowerCase().includes('national income accounting');

    const isEconMoneyBanking =
      chapter.toLowerCase().includes('money and banking');

    const isEconIncomeEmployment =
      chapter.toLowerCase().includes('determination of income and employment');

    const isEconGovtBudget =
      chapter.toLowerCase().includes('government budget');

    const isEconBOP =
      chapter.toLowerCase().includes('balance of payments');

    const isEconIndiaEve =
      chapter.toLowerCase().includes('eve of independence');

    const isEconIndia1950_1990 =
      chapter.toLowerCase().includes('indian economy 1950-1990');

    const isEconLPG =
      chapter.toLowerCase().includes('liberalisation, privatisation and globalisation');

    const isEconHumanCapital =
      chapter.toLowerCase().includes('human capital formation');

    const isEconRuralDev =
      chapter.toLowerCase().includes('rural development') && (subject.toLowerCase().includes('econ'));

    const isEconEmployment =
      chapter.toLowerCase().includes('employment: growth') || (chapter.toLowerCase().includes('employment') && subject.toLowerCase().includes('econ'));

    const isEconSustainable =
      chapter.toLowerCase().includes('sustainable economic development') || (chapter.toLowerCase().includes('sustainable') && subject.toLowerCase().includes('econ'));

    const isEconComparative =
      chapter.toLowerCase().includes('development experience of india');

    const isISCPsychIntelligence =
      chapter.toLowerCase().includes('intelligence and ability') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCPsychPersonality =
      chapter.toLowerCase().includes('personality') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCPsychLifespan =
      chapter.toLowerCase().includes('lifespan development') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCPsychStress =
      chapter.toLowerCase().includes('stress and health') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCPsychDisorders =
      chapter.toLowerCase().includes('psychological disorders and psychotherapy') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCPsychSocialThought =
      chapter.toLowerCase().includes('social thought and social behaviour') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCPsychSocialInfluence =
      chapter.toLowerCase().includes('attitude and social influence') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCBioReproduction =
      chapter.toLowerCase().includes('reproduction') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCBioGenetics =
      chapter.toLowerCase().includes('genetics and evolution') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCBioWelfare =
      chapter.toLowerCase().includes('biology and human welfare') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCBioBiotech =
      chapter.toLowerCase().includes('biotechnology and its applications') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCBioEcology =
      chapter.toLowerCase().includes('ecology and environment') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCEconMicro =
      chapter.toLowerCase().includes('microeconomics') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isISCEconMacro =
      chapter.toLowerCase().includes('macroeconomics') && (selectedBoard?.acronym.toLowerCase() || '').includes('isc');

    const isSolutions = chapter.toLowerCase().includes('solution');
    const isElectrochemistry = chapter.toLowerCase().includes('electrochemistry');
    const isChemicalKinetics = chapter.toLowerCase().includes('chemical kinetics') || (chapter.toLowerCase().includes('kinetics') && !chapter.toLowerCase().includes('rotational'));
    const isDFBlock = chapter.toLowerCase().includes('d- and f-block') || chapter.toLowerCase().includes('d- & f-block') || chapter.toLowerCase().includes('d-block') || chapter.toLowerCase().includes('f-block');
    const isCoordinationCompounds = chapter.toLowerCase().includes('coordination');
    const isHaloalkanes = chapter.toLowerCase().includes('haloalkane') || chapter.toLowerCase().includes('haloarene');
    const isAlcoholsPhenolsEthers = chapter.toLowerCase().includes('alcohol') || chapter.toLowerCase().includes('phenol') || chapter.toLowerCase().includes('ether');
    const isAldehydesKetonesCarboxylic = chapter.toLowerCase().includes('aldehyde') || chapter.toLowerCase().includes('ketone') || chapter.toLowerCase().includes('carboxylic');
    const isAmines = chapter.toLowerCase().includes('amine') || chapter.toLowerCase().includes('diazonium');
    const isBiomolecules = chapter.toLowerCase().includes('biomolecule');

    const isRationalIrrational9 = chapter.toLowerCase().includes('rational') || chapter.toLowerCase().includes('irrational');
    const isCompoundInterest9 = chapter.toLowerCase().includes('compound interest');
    const isExpansions9 = chapter.toLowerCase().includes('expansion');
    const isFactorisation9 = chapter.toLowerCase().includes('factoris') || chapter.toLowerCase().includes('factoriz');
    const isSimultaneousEquations9 = chapter.toLowerCase().includes('simultaneous') || (chapter.toLowerCase().includes('linear') && chapter.toLowerCase().includes('equation'));
    const isIndicesExponents9 = chapter.toLowerCase().includes('indices') || chapter.toLowerCase().includes('exponent');
    const isLogarithms9 = chapter.toLowerCase().includes('logarithm');
    const isTriangles9 = (chapter.toLowerCase().includes('triangle') || chapter.toLowerCase().includes('congruen')) && !chapter.toLowerCase().includes('inverse');
    const isMidpointIntercept9 = chapter.toLowerCase().includes('mid-point') || chapter.toLowerCase().includes('intercept');
    const isRectilinearFigures9 = chapter.toLowerCase().includes('rectilinear') || chapter.toLowerCase().includes('quadrilateral');
    const isCircles9 = chapter.toLowerCase().includes('circle') && (chapter.toLowerCase().includes('chord') || chapter.toLowerCase().includes('geometry'));
    const isAreaPlaneFigures9 = chapter.toLowerCase().includes('area of plane') || (chapter.toLowerCase().includes('mensuration') && chapter.toLowerCase().includes('plane'));
    const isSurfaceAreaVolume9 = chapter.toLowerCase().includes('surface area and volume') || chapter.toLowerCase().includes('3d solids');
    const isCoordinateGeometry9 = chapter.toLowerCase().includes('coordinate geometry') || chapter.toLowerCase().includes('cartesian');
    const isTrigRatios9 = chapter.toLowerCase().includes('trigonometrical ratios') || (chapter.toLowerCase().includes('trigonometry') && chapter.toLowerCase().includes('ratio'));
    const isStatistics9 = chapter.toLowerCase().includes('statistics') && (chapter.toLowerCase().includes('representation') || chapter.toLowerCase().includes('central tendency'));
    const isInternalAssessmentMath9 = (chapter.toLowerCase().includes('internal assessment') || chapter.toLowerCase().includes('mathematical project')) && (subject.toLowerCase().includes('math') || chapter.toLowerCase().includes('math'));

    const isGST10 = chapter.toLowerCase().includes('goods and services tax') || chapter.toLowerCase().includes('gst');
    const isBanking10 = chapter.toLowerCase().includes('recurring deposit') || (chapter.toLowerCase().includes('banking') && chapter.toLowerCase().includes('commercial math'));
    const isLinearInequalities10 = chapter.toLowerCase().includes('linear ininequalities') || chapter.toLowerCase().includes('linear inequations');
    const isQuadraticEquations10 = chapter.toLowerCase().includes('quadratic equation') && !chapter.toLowerCase().includes('complex numbers');
    const isRatioProportion10 = chapter.toLowerCase().includes('ratio and proportion') || chapter.toLowerCase().includes('ratio & proportion');
    const isFactorization10 = chapter.toLowerCase().includes('factorization of polynomials') || chapter.toLowerCase().includes('remainder & factor') || chapter.toLowerCase().includes('remainder and factor');
    const isMatrices10 = chapter.toLowerCase().includes('matrices') || (chapter.toLowerCase().includes('matrix') && !chapter.toLowerCase().includes('determinant'));
    const isProgressions10 = chapter.toLowerCase().includes('arithmetic & geometric progressions') || chapter.toLowerCase().includes('arithmetic and geometric progressions') || (chapter.toLowerCase().includes('a.p.') && chapter.toLowerCase().includes('g.p.'));
    const isReflection10 = chapter.toLowerCase().includes('reflection & symmetry') || chapter.toLowerCase().includes('reflection and symmetry') || (chapter.toLowerCase().includes('reflection') && chapter.toLowerCase().includes('coordinate'));
    const isSectionMidpoint10 = chapter.toLowerCase().includes('section & midpoint') || chapter.toLowerCase().includes('section and midpoint') || chapter.toLowerCase().includes('section formula');
    const isEquationLine10 = chapter.toLowerCase().includes('equation of a straight line') || chapter.toLowerCase().includes('equation of a line');
    const isSimilarity10 = chapter.toLowerCase().includes('similarity of triangles') || chapter.toLowerCase().includes('scale maps') || (chapter.toLowerCase().includes('similarity') && chapter.toLowerCase().includes('geometry'));
    const isLoci10 = chapter.toLowerCase().includes('loci') || chapter.toLowerCase().includes('locus & constructions') || chapter.toLowerCase().includes('locus and constructions');
    const isCirclesProperties10 = chapter.toLowerCase().includes('circles (angle, cyclic') || (chapter.toLowerCase().includes('circles') && chapter.toLowerCase().includes('tangent'));
    const isMensuration3D10 = chapter.toLowerCase().includes('surface area & volume of 3d solids') || chapter.toLowerCase().includes('surface area and volume of 3d solids') || (chapter.toLowerCase().includes('mensuration') && chapter.toLowerCase().includes('3d solids'));
    const isTrigIdentities10 = chapter.toLowerCase().includes('trigonometrical identities') || chapter.toLowerCase().includes('trigonometric identities');
    const isHeightsDistances10 = chapter.toLowerCase().includes('heights and distances') || chapter.toLowerCase().includes('heights & distances');
    const isStatistics10 = chapter.toLowerCase().includes('measures of central tendency') || chapter.toLowerCase().includes('ogive') || (chapter.toLowerCase().includes('statistics') && chapter.toLowerCase().includes('mean, median, mode'));
    const isProbability10 = chapter.toLowerCase().includes('single event theoretical probability') || (chapter.toLowerCase().includes('probability') && chapter.toLowerCase().includes('single event'));

    const isSets11 = (chapter.toLowerCase().includes('sets') && !chapter.toLowerCase().includes('asset') && !chapter.toLowerCase().includes('subset')) || chapter.includes('Section A: Sets');
    const isRelationsFunctions11 = chapter.toLowerCase().includes('relations and functions') || chapter.toLowerCase().includes('relations & functions');
    const isTrigonometry11 = (chapter.toLowerCase().includes('trigonometry') || chapter.toLowerCase().includes('trigonometric')) && !chapter.toLowerCase().includes('ratios') && !chapter.toLowerCase().includes('icse 9');
    const isMathematicalInduction11 = chapter.toLowerCase().includes('induction');
    const isComplexNumbers11 = chapter.toLowerCase().includes('complex numbers');
    const isLinearInequalities11 = chapter.toLowerCase().includes('linear inequalities');
    const isPermutationsCombinations11 = chapter.toLowerCase().includes('permutations');
    const isBinomialTheorem11 = chapter.toLowerCase().includes('binomial');
    const isSequenceSeries11 = chapter.toLowerCase().includes('sequence and series') || chapter.toLowerCase().includes('sequence & series') || chapter.toLowerCase().includes('progression');
    const isStraightLines11 = chapter.toLowerCase().includes('straight lines');
    const isCircles11 = chapter.toLowerCase().includes('circles') && !chapter.toLowerCase().includes('chord') && !chapter.toLowerCase().includes('geometry - circles');
    const isCalculusLimits11 = chapter.toLowerCase().includes('limits and derivatives') || chapter.toLowerCase().includes('calculus');
    const isStatistics11 = chapter.toLowerCase().includes('statistics') && (chapter.toLowerCase().includes('dispersion') || chapter.toLowerCase().includes('measures of dispersion'));
    const isProbability11 = chapter.toLowerCase().includes('probability') && (chapter.toLowerCase().includes('axiomatic') || chapter.toLowerCase().includes('section a'));
    const isConicSections11 = chapter.toLowerCase().includes('conic sections') || chapter.toLowerCase().includes('parabola');
    const isThreeD11 = chapter.toLowerCase().includes('three-dimensional geometry') || chapter.toLowerCase().includes('3d geometry');
    const isMathematicalReasoning11 = chapter.toLowerCase().includes('mathematical reasoning') || chapter.toLowerCase().includes('reasoning & logic');
    const isCommercialStats11 = chapter.toLowerCase().includes('commercial track') || chapter.toLowerCase().includes('expectation');
    const isCorrelationRegression11 = chapter.toLowerCase().includes('correlation') || chapter.toLowerCase().includes('regression');
    const isIndexNumbersMovingAvg11 = chapter.toLowerCase().includes('index numbers') || chapter.toLowerCase().includes('moving averages');
    const isProjectWorkMath11 = chapter.toLowerCase().includes('mathematical project work') || (chapter.toLowerCase().includes('project work') && subject.toLowerCase().includes('math'));

    const isForceWorkEnergy11ICSE = chapter.toLowerCase().includes('force, work, power') || (chapter.toLowerCase().includes('force') && chapter.toLowerCase().includes('work') && chapter.toLowerCase().includes('energy'));
    const isLightOptics11ICSE = (chapter.toLowerCase().includes('light:') && chapter.toLowerCase().includes('refraction')) || (chapter.toLowerCase().includes('light') && chapter.toLowerCase().includes('prism') && chapter.toLowerCase().includes('lens'));
    const isSoundAcoustics11ICSE = chapter.toLowerCase().includes('sound:') || (chapter.toLowerCase().includes('sound') && (chapter.toLowerCase().includes('echo') || chapter.toLowerCase().includes('resonance') || chapter.toLowerCase().includes('acoustic')));
    const isElectricityMagnetism11ICSE = (chapter.toLowerCase().includes('electricity and magnetism') || (chapter.toLowerCase().includes('electricity') && chapter.toLowerCase().includes('magnetism'))) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('ohm'));
    const isHeatCalorimetry11ICSE = (chapter.toLowerCase().includes('heat:') || chapter.toLowerCase().includes('calorimetry')) && (chapter.toLowerCase().includes('latent') || chapter.toLowerCase().includes('calorimetry'));
    const isModernPhysicsNuclear11ICSE = (chapter.toLowerCase().includes('modern physics:') || chapter.toLowerCase().includes('radioactivity')) && (chapter.toLowerCase().includes('nuclear') || chapter.toLowerCase().includes('radioactivity'));
    const isPracticalPhysics11ICSE = (chapter.toLowerCase().includes('internal assessment') || chapter.toLowerCase().includes('practical physics') || chapter.toLowerCase().includes('paper ii')) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics'));

    const isMeasurements9 = chapter.toLowerCase().includes('measurement') && (chapter.toLowerCase().includes('experiment') || chapter.toLowerCase().includes('length') || chapter.toLowerCase().includes('least count'));
    const isMotion1D9 = chapter.toLowerCase().includes('motion in one dimension') || (chapter.toLowerCase().includes('motion') && chapter.toLowerCase().includes('dimension'));
    const isLawsOfMotion9 = chapter.toLowerCase().includes('laws of motion') || (chapter.toLowerCase().includes('law') && chapter.toLowerCase().includes('motion'));
    const isFluidsArchimedes9 = (chapter.toLowerCase().includes('fluid') || chapter.toLowerCase().includes('pressure in fluid')) && (chapter.toLowerCase().includes('archimedes') || chapter.toLowerCase().includes('floatation') || chapter.toLowerCase().includes('upthrust') || chapter.toLowerCase().includes('relative density'));
    const isHeatEnergy9 = (chapter.toLowerCase().includes('heat') && chapter.toLowerCase().includes('energy')) || chapter.toLowerCase().includes('anomalous expansion');
    const isLightReflection9 = (chapter.toLowerCase().includes('light') && (chapter.toLowerCase().includes('reflection') || chapter.toLowerCase().includes('spherical mirror'))) || (chapter.toLowerCase().includes('reflection of light') && !chapter.toLowerCase().includes('wave optics'));
    const isSoundUltrasonic9 = (chapter.toLowerCase().includes('sound') && (chapter.toLowerCase().includes('propagation') || chapter.toLowerCase().includes('ultrasonic') || chapter.toLowerCase().includes('wave'))) || chapter.toLowerCase().includes('sound: propagation');
    const isElectricityMagnetism9 = chapter.toLowerCase().includes('electricity and magnetism') || (chapter.toLowerCase().includes('electricity') && chapter.toLowerCase().includes('magnetism'));
    const isInternalAssessmentPhysics9 = (chapter.toLowerCase().includes('internal assessment') || chapter.toLowerCase().includes('practical physics')) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics'));

    const isLanguageOfChemistry9 = (chapter.toLowerCase().includes('language of chemistry') || (chapter.toLowerCase().includes('valency') && chapter.toLowerCase().includes('symbol'))) && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem') || !subject);
    const isChemicalChangesReactions9 = chapter.toLowerCase().includes('chemical changes and reactions') || (chapter.toLowerCase().includes('chemical changes') && chapter.toLowerCase().includes('reaction'));
    const isWaterHydration9 = (chapter.toLowerCase().includes('water') && (chapter.toLowerCase().includes('solution') || chapter.toLowerCase().includes('hardness') || chapter.toLowerCase().includes('hydration') || chapter.toLowerCase().includes('crystallization'))) || ((chapter.toLowerCase().trim() === '3. water' || chapter.toLowerCase().trim() === 'water') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem')));
    const isAtomicStructureBonding9 = (chapter.toLowerCase().includes('atomic structure') && chapter.toLowerCase().includes('chemical bonding')) || (chapter.toLowerCase().includes('atomic structure') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem')));
    const isPeriodicTableICSE9 = (chapter.toLowerCase().includes('periodic table') && (chapter.toLowerCase().includes('periodic properties') || chapter.toLowerCase().includes('historical') || chapter.toLowerCase().includes('modern periodic'))) || (chapter.toLowerCase().includes('the periodic table') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem')));
    const isHydrogenStudy9 = chapter.toLowerCase().includes('hydrogen') || chapter.toLowerCase().includes('study of the first element');
    const isGasLawsICSE9 = chapter.toLowerCase().includes('gas law') || (chapter.toLowerCase().includes('boyle') && chapter.toLowerCase().includes('charles'));
    const isAtmosphericPollution9 = chapter.toLowerCase().includes('atmospheric pollution') || (chapter.toLowerCase().includes('pollution') && (chapter.toLowerCase().includes('acid rain') || chapter.toLowerCase().includes('ozone')));
    const isInternalAssessmentChemistry9 = (chapter.toLowerCase().includes('internal assessment') || chapter.toLowerCase().includes('practical chemistry')) && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chemistry'));

    const isBasicBiology9 = (chapter.toLowerCase().includes('basic biology') || (chapter.toLowerCase().includes('cell') && chapter.toLowerCase().includes('tissue'))) || (chapter.toLowerCase().includes('basic biology & cells'));
    const isFloweringPlants9 = chapter.toLowerCase().includes('flowering plant') || (chapter.toLowerCase().includes('flower') && (chapter.toLowerCase().includes('pollination') || chapter.toLowerCase().includes('seed') || chapter.toLowerCase().includes('morphology')));
    const isHumanAnatomyPhysiology9 = chapter.toLowerCase().includes('human anatomy') || (chapter.toLowerCase().includes('anatomy') && (chapter.toLowerCase().includes('digestion') || chapter.toLowerCase().includes('skeleton') || chapter.toLowerCase().includes('respiration')));
    const isHealthHygiene9 = chapter.toLowerCase().includes('health and hygiene') || chapter.toLowerCase().includes('health & hygiene') || (chapter.toLowerCase().includes('health') && (chapter.toLowerCase().includes('disease') || chapter.toLowerCase().includes('immunity')));
    const isWasteManagement9 = chapter.toLowerCase().includes('waste generation') || chapter.toLowerCase().includes('waste management') || (chapter.toLowerCase().includes('waste') && (chapter.toLowerCase().includes('impact') || chapter.toLowerCase().includes('3 rs')));
    const isInternalAssessmentBiology9 = (chapter.toLowerCase().includes('internal assessment') || chapter.toLowerCase().includes('practical biology')) && (subject.toLowerCase().includes('bio') || chapter.toLowerCase().includes('biology'));

    const isOOPConcepts9 = (chapter.toLowerCase().includes('object-oriented') || chapter.toLowerCase().includes('object oriented') || chapter.toLowerCase().includes('oop')) && (chapter.toLowerCase().includes('concept') || chapter.toLowerCase().includes('introduction') || chapter.toLowerCase().includes('principles') || subject.toLowerCase().includes('computer'));
    const isObjectsClasses9 = (chapter.toLowerCase().includes('objects and classes') || chapter.toLowerCase().includes('object and class') || (chapter.toLowerCase().includes('object') && chapter.toLowerCase().includes('class'))) && (chapter.toLowerCase().includes('elementary') || chapter.toLowerCase().includes('blueprint') || subject.toLowerCase().includes('computer'));
    const isValuesDataTypes9 = (chapter.toLowerCase().includes('values and data types') || chapter.toLowerCase().includes('data types') || (chapter.toLowerCase().includes('values') && chapter.toLowerCase().includes('type'))) && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('token') || chapter.toLowerCase().includes('primitive'));
    const isOperatorsJava9 = (chapter.toLowerCase().includes('operators') || chapter.toLowerCase().includes('operator in java')) && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('java') || chapter.toLowerCase().includes('arithmetic') || chapter.toLowerCase().includes('precedence'));
    const isInputJava9 = (chapter.toLowerCase().includes('input in java') || (chapter.toLowerCase().includes('input') && chapter.toLowerCase().includes('scanner'))) && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('java') || chapter.toLowerCase().includes('keyboard'));
    const isMathLibraryJava9 = (chapter.toLowerCase().includes('mathematical library') || chapter.toLowerCase().includes('math library') || chapter.toLowerCase().includes('math methods') || chapter.toLowerCase().includes('math.pow')) && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('java'));
    const isConditionalConstructs9 = (chapter.toLowerCase().includes('conditional construct') || chapter.toLowerCase().includes('if-else') || chapter.toLowerCase().includes('switch')) && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('java') || chapter.toLowerCase().includes('constructs'));
    const isIterativeConstructs9 = (chapter.toLowerCase().includes('iterative construct') || chapter.toLowerCase().includes('loops') || chapter.toLowerCase().includes('nested loops') || chapter.toLowerCase().includes('while loop')) && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('java') || chapter.toLowerCase().includes('constructs'));
    const isInternalAssessmentCS9 = (chapter.toLowerCase().includes('internal assessment') || chapter.toLowerCase().includes('practical lab') || chapter.toLowerCase().includes('practical computer')) && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('cs') || chapter.toLowerCase().includes('java'));

    const isConstitution9 = (chapter.toLowerCase().includes('constitution') || chapter.toLowerCase().includes('our constitution')) && (subject.toLowerCase().includes('civics') || subject.toLowerCase().includes('social') || subject.toLowerCase().includes('history') || chapter.toLowerCase().includes('preamble') || chapter.toLowerCase().includes('salient features') || chapter.toLowerCase().includes('directive principles') || chapter.toLowerCase().includes('rights'));
    const isElections9 = (chapter.toLowerCase().includes('election') || chapter.toLowerCase().includes('electoral')) && (subject.toLowerCase().includes('civics') || subject.toLowerCase().includes('social') || subject.toLowerCase().includes('history') || chapter.toLowerCase().includes('commission') || chapter.toLowerCase().includes('ballot'));
    const isLocalSelfGov9 = (chapter.toLowerCase().includes('local self') || chapter.toLowerCase().includes('panchayati raj') || chapter.toLowerCase().includes('municipal') || chapter.toLowerCase().includes('local government')) && (subject.toLowerCase().includes('civics') || subject.toLowerCase().includes('social') || subject.toLowerCase().includes('history') || chapter.toLowerCase().includes('zila parishad'));
    const isAncientIndia9 = (chapter.toLowerCase().includes('ancient india') || chapter.toLowerCase().includes('harappan') || chapter.toLowerCase().includes('vedic') || (chapter.toLowerCase().includes('ancient') && chapter.toLowerCase().includes('civilisation'))) && (subject.toLowerCase().includes('history') || subject.toLowerCase().includes('social') || chapter.toLowerCase().includes('mauryan') || chapter.toLowerCase().includes('gupta'));
    const isMedievalIndia9 = (chapter.toLowerCase().includes('medieval') || chapter.toLowerCase().includes('chola') || chapter.toLowerCase().includes('delhi sultanate') || chapter.toLowerCase().includes('mughal') || chapter.toLowerCase().includes('bhakti') || chapter.toLowerCase().includes('sufism')) && (subject.toLowerCase().includes('history') || subject.toLowerCase().includes('social') || chapter.toLowerCase().includes('culture'));
    const isModernAgeEurope9 = (chapter.toLowerCase().includes('modern age') || chapter.toLowerCase().includes('renaissance') || chapter.toLowerCase().includes('reformation') || chapter.toLowerCase().includes('industrial revolution')) && (subject.toLowerCase().includes('history') || subject.toLowerCase().includes('social') || chapter.toLowerCase().includes('europe'));
    const isGeographicalSkills9 = (chapter.toLowerCase().includes('geographical skills') || chapter.toLowerCase().includes('map work') || chapter.toLowerCase().includes('world map')) && (subject.toLowerCase().includes('geography') || subject.toLowerCase().includes('social') || chapter.toLowerCase().includes('oceans'));
    const isPhysicalGeography9 = (chapter.toLowerCase().includes('physical earth') || chapter.toLowerCase().includes('physical geography') || chapter.toLowerCase().includes('earth as geoid') || (chapter.toLowerCase().includes('earth') && chapter.toLowerCase().includes('landform')) || (chapter.toLowerCase().includes('latitudes') && chapter.toLowerCase().includes('longitudes'))) && (subject.toLowerCase().includes('geography') || subject.toLowerCase().includes('social'));
    const isAtmosphereHydrosphere9 = (chapter.toLowerCase().includes('atmosphere') || chapter.toLowerCase().includes('hydrosphere') || chapter.toLowerCase().includes('ocean currents') || chapter.toLowerCase().includes('pressure belts')) && (subject.toLowerCase().includes('geography') || subject.toLowerCase().includes('social'));
    const isEnvironmentNaturalRegions9 = (chapter.toLowerCase().includes('environment & natural regions') || chapter.toLowerCase().includes('environment and regions') || chapter.toLowerCase().includes('natural regions') || (chapter.toLowerCase().includes('environment') && chapter.toLowerCase().includes('region'))) && (subject.toLowerCase().includes('geography') || subject.toLowerCase().includes('social'));
    const isInternalAssessmentSocialScience9 = (chapter.toLowerCase().includes('internal assessment') || chapter.toLowerCase().includes('practical project') || chapter.toLowerCase().includes('field projects')) && (subject.toLowerCase().includes('social') || subject.toLowerCase().includes('history') || subject.toLowerCase().includes('geography') || subject.toLowerCase().includes('civics'));
    const isBasicConceptsChem11 = (chapter.toLowerCase().includes('basic concepts of chemistry') || (chapter.toLowerCase().includes('basic concepts') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem')))) && !chapter.toLowerCase().includes('icse 9');
    const isStructureOfAtom11 = (chapter.toLowerCase().includes('structure of atom') || chapter.toLowerCase().includes('atomic structure')) && !chapter.toLowerCase().includes('icse 9') && !chapter.toLowerCase().includes('chemical bonding') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem') || chapter.toLowerCase().includes('unit 2'));
    const isClassificationElements11 = (chapter.toLowerCase().includes('classification of elements') || chapter.toLowerCase().includes('periodicity in properties')) && !chapter.toLowerCase().includes('s-block') && !chapter.toLowerCase().includes('p-block') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem') || chapter.toLowerCase().includes('unit 3'));
    const isChemicalBonding11 = (chapter.toLowerCase().includes('chemical bonding') || chapter.toLowerCase().includes('molecular structure')) && !chapter.toLowerCase().includes('icse 9') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem') || chapter.toLowerCase().includes('unit 4'));
    const isChemicalThermodynamics11 = (chapter.toLowerCase().includes('thermodynamics') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chemical') || chapter.toLowerCase().includes('unit 5')));
    const isEquilibrium11 = chapter.toLowerCase().includes('equilibrium') && !chapter.toLowerCase().includes('rotational') && !chapter.toLowerCase().includes('rigid') && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem') || chapter.toLowerCase().includes('unit 6'));
    const isRedoxReactions11 = chapter.toLowerCase().includes('redox');
    const isInorganicSPBlock11 = (chapter.toLowerCase().includes('inorganic chemistry') || chapter.toLowerCase().includes('s-block') || chapter.toLowerCase().includes('p-block')) && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem') || chapter.toLowerCase().includes('elements'));
    const isOrganicHydrocarbons11 = (chapter.toLowerCase().includes('organic chemistry') || chapter.toLowerCase().includes('hydrocarbons') || chapter.toLowerCase().includes('basic principles, techniques')) && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chem') || chapter.toLowerCase().includes('unit 9'));
    const isPracticalChemistry11 = (chapter.toLowerCase().includes('practical work') || chapter.toLowerCase().includes('practical chemistry') || chapter.toLowerCase().includes('paper ii: practical')) && (subject.toLowerCase().includes('chem') || chapter.toLowerCase().includes('chemistry'));

    // Physics Class 11 Units Detection
    const isPhysicalWorldMeasurement11 = (chapter.toLowerCase().includes('physical world') || (chapter.toLowerCase().includes('measurement') && chapter.toLowerCase().includes('unit 1'))) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics') || chapter.toLowerCase().includes('measurement'));
    const isKinematics11 = chapter.toLowerCase().includes('kinematics') || ((chapter.toLowerCase().includes('straight line') || chapter.toLowerCase().includes('motion in a plane')) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics')));
    const isLawsOfMotion11 = (chapter.toLowerCase().includes('laws of motion') && (chapter.toLowerCase().includes('unit 3') || subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics'))) && !chapter.toLowerCase().includes('icse 9');
    const isWorkEnergyPower11 = (chapter.toLowerCase().includes('work, energy') || chapter.toLowerCase().includes('work, energy, and power') || (chapter.toLowerCase().includes('work') && chapter.toLowerCase().includes('energy') && chapter.toLowerCase().includes('power'))) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics') || chapter.toLowerCase().includes('unit 4'));
    const isSystemParticlesRigidBody11 = chapter.toLowerCase().includes('system of particles') || chapter.toLowerCase().includes('rigid body');
    const isGravitation11 = chapter.toLowerCase().includes('gravitation') && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics') || chapter.toLowerCase().includes('unit 6'));
    const isPropertiesBulkMatter11 = chapter.toLowerCase().includes('properties of bulk matter') || chapter.toLowerCase().includes('bulk matter');
    const isThermodynamicsPhysics11 = (chapter.toLowerCase().includes('heat and thermodynamics') || chapter.toLowerCase().includes('thermodynamics')) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics') || chapter.toLowerCase().includes('unit 8'));
    const isKineticTheoryGases11 = chapter.toLowerCase().includes('kinetic theory') || chapter.toLowerCase().includes('perfect gases');
    const isOscillationsWaves11 = (chapter.toLowerCase().includes('oscillations and waves') || (chapter.toLowerCase().includes('oscillation') && chapter.toLowerCase().includes('wave'))) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics') || chapter.toLowerCase().includes('unit 10'));
    const isPracticalPhysics11 = (chapter.toLowerCase().includes('practical work') || chapter.toLowerCase().includes('paper ii: practical')) && (subject.toLowerCase().includes('physic') || chapter.toLowerCase().includes('physics'));

    // Biology Class 11 Units Detection
    const isDiversityLivingOrganisms11 = chapter.toLowerCase().includes('diversity of living organisms') || (chapter.toLowerCase().includes('living organisms') && (subject.toLowerCase().includes('bio') || chapter.toLowerCase().includes('biology')));
    const isStructuralOrganisation11 = chapter.toLowerCase().includes('structural organisation in animals and plants') || chapter.toLowerCase().includes('structural organisation') || chapter.toLowerCase().includes('structural organization');
    const isCellStructureFunction11 = (chapter.toLowerCase().includes('cell: structure and function') || chapter.toLowerCase().includes('cell structure and function')) && (subject.toLowerCase().includes('bio') || chapter.toLowerCase().includes('biology') || chapter.toLowerCase().includes('unit 3'));
    const isPlantPhysiology11 = chapter.toLowerCase().includes('plant physiology') && (subject.toLowerCase().includes('bio') || chapter.toLowerCase().includes('biology') || chapter.toLowerCase().includes('unit 4'));
    const isHumanPhysiology11 = chapter.toLowerCase().includes('human physiology') && (subject.toLowerCase().includes('bio') || chapter.toLowerCase().includes('biology') || chapter.toLowerCase().includes('unit 5'));
    const isPracticalBiology11 = (chapter.toLowerCase().includes('practical work') || chapter.toLowerCase().includes('paper ii: practical')) && (subject.toLowerCase().includes('bio') || chapter.toLowerCase().includes('biology'));

    // Computer Science Class 11 Units Detection
    const isDataRepBooleanAlg11 = chapter.toLowerCase().includes('data representation and boolean algebra') || chapter.toLowerCase().includes('data representation');
    const isHardwareArchitecture11 = chapter.toLowerCase().includes('computer hardware and basic architecture') || chapter.toLowerCase().includes('computer hardware');
    const isJavaOOPConcepts11 = chapter.toLowerCase().includes('introduction to java and oop concepts') || (chapter.toLowerCase().includes('introduction to java') && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('computer')));
    const isControlStructuresFunctions11 = chapter.toLowerCase().includes('control structures and function design') || chapter.toLowerCase().includes('control structures');
    const isArraysStrings11 = chapter.toLowerCase().includes('primitive data structures: arrays and strings') || chapter.toLowerCase().includes('primitive data structures');
    const isAdvancedOOPFeatures11 = chapter.toLowerCase().includes('advanced object-oriented programming features') || chapter.toLowerCase().includes('advanced object-oriented');
    const isPracticalWorkCS11 = (chapter.toLowerCase().includes('practical work & laboratory assessment') || chapter.toLowerCase().includes('practical work')) && (subject.toLowerCase().includes('computer') || chapter.toLowerCase().includes('computer') || chapter.toLowerCase().includes('cs'));

    // History Class 11 Units Detection
    const isGrowthOfNationalism11 = chapter.toLowerCase().includes('growth of nationalism');
    const isEmergenceOfRadicals11 = chapter.toLowerCase().includes('emergence of the radicals') || chapter.toLowerCase().includes('swadeshi movement');
    const isWWINationalistPolitics11 = chapter.toLowerCase().includes('first world war and nationalist politics');
    const isGandhianEra11 = chapter.toLowerCase().includes('gandhian era') || chapter.toLowerCase().includes('mass nationalism');
    const isImpactWWIPeaceSettlements11 = chapter.toLowerCase().includes('impact of the first world war') || chapter.toLowerCase().includes('peace settlements');
    const isGreatDepressionTotalitarianism11 = chapter.toLowerCase().includes('great depression') || chapter.toLowerCase().includes('rise of totalitarianism');
    const isWWIICollapseCollectiveSecurity11 = chapter.toLowerCase().includes('world war ii and the collapse') || chapter.toLowerCase().includes('collapse of collective security');
    const isRiseOfCommunismChina11 = chapter.toLowerCase().includes('rise of communism in china') || (chapter.toLowerCase().includes('china') && chapter.toLowerCase().includes('1911'));
    const isProjectWorkHistory11 = (chapter.toLowerCase().includes('project work') || chapter.toLowerCase().includes('historical research essay')) && (subject.toLowerCase().includes('history') || chapter.toLowerCase().includes('history') || chapter.toLowerCase().includes('paper ii'));

    // Geography Class 11 Units Detection
    const isEarthStructureEndogenetic11 = chapter.toLowerCase().includes('structure of the earth') || chapter.toLowerCase().includes('endogenetic processes');
    const isExogeneticLandforms11 = chapter.toLowerCase().includes('exogenetic processes') || chapter.toLowerCase().includes('landform development');
    const isAtmosphereHydrosphere11 = chapter.toLowerCase().includes('atmosphere and hydrosphere') || (chapter.toLowerCase().includes('atmosphere') && chapter.toLowerCase().includes('hydrosphere'));
    const isPopulationSettlements11 = chapter.toLowerCase().includes('population dynamics') || chapter.toLowerCase().includes('human settlements');
    const isPhysicalFrameworkIndia11 = chapter.toLowerCase().includes('physical framework and climate of india') || chapter.toLowerCase().includes('physical framework');
    const isResourcesEnvironmentIndia11 = chapter.toLowerCase().includes('resource base and environmental issues') || chapter.toLowerCase().includes('resource base');
    const isPracticalGeography11 = (chapter.toLowerCase().includes('practical work, cartographic skills') || chapter.toLowerCase().includes('practical work') || chapter.toLowerCase().includes('cartographic')) && (subject.toLowerCase().includes('geography') || chapter.toLowerCase().includes('geography') || chapter.toLowerCase().includes('field project'));

    // Political Science Class 11 Units Detection
    const isIntroPolScience11 = chapter.toLowerCase().includes('introduction to political science');
    const isFundamentalPolConcepts11 = chapter.toLowerCase().includes('fundamental political concepts');
    const isFormsOfGovt11 = chapter.toLowerCase().includes('forms of government');
    const isConstitutionsStructures11 = chapter.toLowerCase().includes('constitutions and organic structures');
    const isFranchiseRepresentation11 = chapter.toLowerCase().includes('franchise, representation') || chapter.toLowerCase().includes('pressure groups');
    const isProjectWorkPolScience11 = (chapter.toLowerCase().includes('project work') || chapter.toLowerCase().includes('comparative political analysis')) && (subject.toLowerCase().includes('political') || chapter.toLowerCase().includes('political'));

    // Sociology Class 11 Units Detection
    const isOriginDevSociology11 = chapter.toLowerCase().includes('origin and development of sociology') || (chapter.toLowerCase().includes('sociology') && chapter.toLowerCase().includes('anthropology'));
    const isResearchMethodologySociology11 = chapter.toLowerCase().includes('research methodology') && (subject.toLowerCase().includes('sociology') || chapter.toLowerCase().includes('sociology'));
    const isBasicConceptsSociology11 = chapter.toLowerCase().includes('basic concepts') && (subject.toLowerCase().includes('sociology') || chapter.toLowerCase().includes('sociology') || chapter.toLowerCase().includes('socialization') || chapter.toLowerCase().includes('society'));
    const isSocialStructureSociology11 = chapter.toLowerCase().includes('social structure') && (subject.toLowerCase().includes('sociology') || chapter.toLowerCase().includes('sociology') || chapter.toLowerCase().includes('groups'));
    const isSocialProblemsSociology11 = chapter.toLowerCase().includes('social problems') && (subject.toLowerCase().includes('sociology') || chapter.toLowerCase().includes('sociology') || chapter.toLowerCase().includes('deviance'));
    const isIndianSociologists11 = chapter.toLowerCase().includes('indian sociologists') || chapter.toLowerCase().includes('pioneer perspectives');
    const isPracticalSociology11 = (chapter.toLowerCase().includes('practical work') || chapter.toLowerCase().includes('sociological research') || chapter.toLowerCase().includes('sociological projects')) && (subject.toLowerCase().includes('sociology') || chapter.toLowerCase().includes('sociology'));

    // Psychology Class 11 Units Detection
    const isIntroPsychology11 = chapter.toLowerCase().includes('introduction to psychology');
    const isMethodsPsychology11 = chapter.toLowerCase().includes('methods of psychology');
    const isBiologicalBasesPsychology11 = chapter.toLowerCase().includes('biological bases');
    const isHumanDevelopmentPsychology11 = chapter.toLowerCase().includes('human development');
    const isSensoryPerceptualPsychology11 = chapter.toLowerCase().includes('sensory, attentional');
    const isLearningPsychology11 = chapter.toLowerCase().includes('learning') && (subject.toLowerCase().includes('psychology') || chapter.toLowerCase().includes('psychology'));
    const isMemoryPsychology11 = chapter.toLowerCase().includes('human memory') || (chapter.toLowerCase().includes('memory') && (subject.toLowerCase().includes('psychology') || chapter.toLowerCase().includes('psychology')));
    const isPracticalPsychology11 = (chapter.toLowerCase().includes('practical work') || chapter.toLowerCase().includes('laboratory experiments') || chapter.toLowerCase().includes('practical log')) && (subject.toLowerCase().includes('psychology') || chapter.toLowerCase().includes('psychology'));

    // Economics Class 11 Units Detection
    const isUnderstandingEconomics11 = chapter.toLowerCase().includes('understanding economics') || chapter.toLowerCase().includes('basic concepts') && (subject.toLowerCase().includes('econ') || chapter.toLowerCase().includes('econ'));
    const isConsumerBehaviourDemand11 = chapter.toLowerCase().includes('consumer behaviour');
    const isProducerBehaviourSupplyCost11 = chapter.toLowerCase().includes('producer behaviour');
    const isMarketFormsPriceDet11 = chapter.toLowerCase().includes('market forms');
    const isStructuralFeaturesIndianEcon11 = chapter.toLowerCase().includes('structural features') || chapter.toLowerCase().includes('indian economy');
    const isBasicStatisticsEconomics11 = chapter.toLowerCase().includes('statistics for economics') || chapter.toLowerCase().includes('basic statistics');
    const isProjectWorkEconomics11 = (chapter.toLowerCase().includes('project work') || chapter.toLowerCase().includes('research essay')) && (subject.toLowerCase().includes('economics') || chapter.toLowerCase().includes('economics'));

    const l1Title = isCommunicationSystemsLesson
      ? `Lesson 42 : Communication Systems`
      : isLogicGates
      ? `Lesson 41 : Logic Gates`
      : isJunctionTransistors
      ? `Lesson 40 : Junction Transistors`
      : isSemiconductorDiodes
      ? `Lesson 39 : Semiconductor Diodes`
      : isSemiconductorElectronicsLesson
      ? `Lesson 38 : Semiconductor Electronics`
      : isFissionFusion
      ? `Lesson 37 : Nuclear Fission and Fusion : Sources of Energy`
      : isMassEnergyBinding
      ? `Lesson 36 : Mass-Energy Equivalence : Nuclear Binding Energy`
      : isRadioactivity
      ? `Lesson 35 : Radioactivity`
      : isNuclearStructure
      ? `Lesson 34 : Nuclear Structure`
      : isAtomsBohr
      ? `Lesson 33 : Atom, Origin of Spectra : Bohr's Theory of Hydrogen Atom`
      : isXRays
      ? `Lesson 32 : X-Rays`
      : isMatterWaves
      ? `Lesson 31 : Matter Waves`
      : isPhotoelectric
      ? `Lesson 30 : Photoelectric Effect`
      : isPolarization
      ? `Lesson 29 : Polarization of Light`
      : isDiffraction
      ? `Lesson 28 : Diffraction of Light`
      : isInterference
      ? `Lesson 27 : Interference of Light`
      : isWaveNatureHuygens
      ? `Lesson 26 : Wave Nature of Light : Huygens' Principle`
      : isOpticalInstruments
      ? `Lesson 25 : Optical Instruments`
      : isRefractionPrism
      ? `Lesson 24 : Refraction and Dispersion of Light through a Prism`
      : isRefractionLenses
      ? `Lesson 23 : Refraction of Light at Spherical Surfaces : Lenses`
      : isRefractionPlane
      ? `Lesson 22 : Refraction of Light at a Plane Interface : Total Internal Reflection : Optical Fiber`
      : isReflection
      ? `Lesson 21 : Reflection of Light : Spherical Mirrors`
      : isCommunication
      ? `Lesson 20 : Communication Systems`
      : isSemiconductor
      ? `Lesson 19 : Semiconductor Electronics`
      : isNuclei
      ? `Lesson 18 : Nuclei`
      : isAtoms
      ? `Lesson 17 : Atoms`
      : isDualNature
      ? `Lesson 16 : Dual Nature of Radiation and Matter`
      : isWaveOptics
      ? `Lesson 15 : Wave Optics`
      : isRayOptics
      ? `Lesson 14 : Ray Optics and Optical Instruments`
      : isElectromagneticWaves
      ? `Lesson 13 : Electromagnetic Waves`
      : isAlternatingCurrent
      ? `Lesson 12 : Alternating Current`
      : isElectromagneticInduction
      ? `Lesson 11 : Electromagnetic Induction`
      : isMagneticSubstances
      ? `Lesson 10 : Magnetic Classification of Substances`
      : isEarthMagnetism
      ? `Lesson 9 : Magnetic Field and Earth's Magnetism`
      : isTorqueLoop
      ? `Lesson 8 : Torque on a Current-Loop : Moving-Coil Galvanometer`
      : isMovingCharges
      ? `Lesson 7 : Moving Charges and Magnetic Field`
      : isDCCircuits
      ? `Lesson 6 : DC Circuits and Measurements`
      : isResistance
      ? `Lesson 5 : Electric Resistance and Ohm's Law`
      : isCapacitors
      ? `Lesson 4 : Capacitors and Dielectrics`
      : isElectricPotential
      ? `Lesson 3 : Electric Potential`
      : isGaussTheorem
      ? `Lesson 2 : Gauss' Theorem`
      : isElectricCharges
      ? `Lesson 1 : Electric Charges and Field`
      : isSexualReproductionPlants
      ? `Lesson 1 : Sexual Reproduction in Flowering Plants`
      : isHumanReproduction
      ? `Lesson 2 : Human Reproduction`
      : isReproductiveHealth
      ? `Lesson 3 : Reproductive Health`
      : isPrinciplesInheritance
      ? `Lesson 4 : Principles of Inheritance and Variation`
      : isMolecularBasis
      ? `Lesson 5 : Molecular Basis of Inheritance`
      : isEvolution
      ? `Lesson 6 : Evolution`
      : isHumanHealth
      ? `Lesson 7 : Human Health and Disease`
      : isMicrobes
      ? `Lesson 8 : Microbes in Human Welfare`
      : isBiotechPrinciples
      ? `Lesson 9 : Biotechnology: Principles and Processes`
      : isBiotechApps
      ? `Lesson 10 : Biotechnology and its Applications`
      : isOrganismsPopulations
      ? `Lesson 11 : Organisms and Populations`
      : isEcosystem
      ? `Lesson 12 : Ecosystem`
      : isBiodiversity
      ? `Lesson 13 : Biodiversity and Conservation`
      : isPythonRevision
      ? `Lesson 1 : Python Revision Tour`
      : isCSFunctions
      ? `Lesson 2 : Functions in Python`
      : isFileHandling
      ? `Lesson 3 : File Handling in Python`
      : isCSDataStructures
      ? `Lesson 4 : Data Structures: Stacks`
      : isCSComputerNetworks
      ? `Lesson 5 : Computer Networks`
      : isDatabaseManagement
      ? `Lesson 6 : Database Management & SQL`
      : isSocietalImpacts
      ? `Lesson 7 : Societal Impacts & Cyber Ethics`
      : isBricksBeads
      ? `Lesson 1 : Bricks, Beads and Bones`
      : isKingsFarmers
      ? `Lesson 2 : Kings, Farmers and Towns`
      : isKinshipCaste
      ? `Lesson 3 : Kinship, Caste and Class`
      : isThinkersBeliefs
      ? `Lesson 4 : Thinkers, Beliefs and Buildings`
      : isTravellers
      ? `Lesson 5 : Through the Eyes of Travellers`
      : isBhaktiSufi
      ? `Lesson 6 : Bhakti-Sufi Traditions`
      : isVijayanagara
      ? `Lesson 7 : An Imperial Capital: Vijayanagara`
      : isPeasantsZamindars
      ? `Lesson 8 : Peasants, Zamindars and the State`
      : isColonialismCountryside
      ? `Lesson 10 : Colonialism and the Countryside`
      : isRebelsRaj
      ? `Lesson 11 : Rebels and the Raj`
      : isGandhiMovement
      ? `Lesson 12 : Mahatma Gandhi and the Nationalist Movement`
      : isFramingConstitution
      ? `Lesson 13 : Framing the Constitution`
      : isGeogHumanNature
      ? `Lesson 1 : Human Geography: Nature and Scope`
      : isGeogWorldPop
      ? `Lesson 2 : The World Population`
      : isGeogHumanDev
      ? `Lesson 3 : Human Development`
      : isGeogPrimary
      ? `Lesson 4 : Primary Activities`
      : isGeogSecondary
      ? `Lesson 5 : Secondary Activities`
      : isGeogTertiary
      ? `Lesson 6 : Tertiary and Quaternary Activities`
      : isGeogTransport
      ? `Lesson 7 : Transport and Communication`
      : isGeogInternationalTrade
      ? `Lesson 8 : International Trade`
      : isGeogHumanSettlements
      ? `Lesson 9 : Human Settlements`
      : isEndOfBipolarity
      ? `Lesson 1 : The End of Bipolarity`
      : isContemporaryCentres
      ? `Lesson 2 : Contemporary Centres of Power`
      : isContemporarySouthAsia
      ? `Lesson 3 : Contemporary South Asia`
      : isIntlOrganizations
      ? `Lesson 4 : International Organizations`
      : isSecurityContemporary
      ? `Lesson 5 : Security in the Contemporary World`
      : isEnvironmentResources
      ? `Lesson 6 : Environment and Natural Resources`
      : isGlobalizationPol
      ? `Lesson 7 : Globalization`
      : isChallengesNationBuilding
      ? `Lesson 8 : Challenges of Nation-Building`
      : isRecentDevelopmentsPol
      ? `Lesson 9 : Recent Developments in Indian Politics`
      : isSocDemography
      ? `Lesson 1 : Demographic Structure of Indian Society`
      : isSocInstitutions
      ? `Lesson 2 : Social Institutions: Continuity and Change`
      : isSocInequality
      ? `Lesson 3 : Patterns of Social Inequality and Exclusion`
      : isSocDiversity
      ? `Lesson 4 : The Challenges of Cultural Diversity`
      : isSocStructuralChange
      ? `Lesson 5 : Structural Change`
      : isSocCulturalChange
      ? `Lesson 6 : Cultural Change`
      : isSocRuralSociety
      ? `Lesson 7 : Change and Development in Rural Society`
      : isSocIndustrialSociety
      ? `Lesson 8 : Change and Development in Industrial Society`
      : isSocSocialMovements
      ? `Lesson 9 : Social Movements`
      : isPsychVariations
      ? `Lesson 1 : Variations in Psychological Attributes`
      : isPsychPersonality
      ? `Lesson 2 : Self and Personality`
      : isPsychChallenges
      ? `Lesson 3 : Meeting Life Challenges`
      : isPsychDisorders
      ? `Lesson 4 : Psychological Disorders`
      : isPsychTherapy
      ? `Lesson 5 : Therapeutic Approaches`
      : isPsychSocial
      ? `Lesson 6 : Attitude and Social Cognition`
      : isPsychGroups
      ? `Lesson 7 : Social Influence and Group Processes`
      : isEconMacroIntro
      ? `Lesson 1 : Introduction to Macroeconomics`
      : isEconNationalIncome
      ? `Lesson 2 : National Income Accounting`
      : isEconMoneyBanking
      ? `Lesson 3 : Money and Banking`
      : isEconIncomeEmployment
      ? `Lesson 4 : Determination of Income and Employment`
      : isEconGovtBudget
      ? `Lesson 5 : Government Budget and the Economy`
      : isEconBOP
      ? `Lesson 6 : Balance of Payments`
      : isEconIndiaEve
      ? `Lesson 7 : Indian Economy on the Eve of Independence`
      : isEconIndia1950_1990
      ? `Lesson 8 : Indian Economy 1950-1990`
      : isEconLPG
      ? `Lesson 9 : Liberalisation, Privatisation and Globalisation`
      : isEconHumanCapital
      ? `Lesson 10 : Human Capital Formation in India`
      : isEconRuralDev
      ? `Lesson 11 : Rural Development`
      : isEconEmployment
      ? `Lesson 12 : Employment: Growth, Informalisation and Other Issues`
      : isEconSustainable
      ? `Lesson 13 : Sustainable Economic Development`
      : isEconComparative
      ? `Lesson 14 : Development Experience of India: A Comparison with Neighbours`
      : isISCPsychIntelligence
      ? `Lesson 1 : Intelligence and Ability`
      : isISCPsychPersonality
      ? `Lesson 2 : Personality`
      : isISCPsychLifespan
      ? `Lesson 3 : Lifespan Development`
      : isISCPsychStress
      ? `Lesson 4 : Stress and Health`
      : isISCPsychDisorders
      ? `Lesson 5 : Psychological Disorders and Psychotherapy`
      : isISCPsychSocialThought
      ? `Lesson 6 : Social Thought and Social Behaviour`
      : isISCPsychSocialInfluence
      ? `Lesson 7 : Attitude and Social Influence`
      : isISCBioReproduction
      ? `Lesson 1 : Reproduction`
      : isISCBioGenetics
      ? `Lesson 2 : Genetics and Evolution`
      : isISCBioWelfare
      ? `Lesson 3 : Biology and Human Welfare`
      : isISCBioBiotech
      ? `Lesson 4 : Biotechnology and its Applications`
      : isISCBioEcology
      ? `Lesson 5 : Ecology and Environment`
      : isISCEconMicro
      ? `Lesson 1 : Microeconomics`
      : isISCEconMacro
      ? `Lesson 2 : Macroeconomics`
      : isSolutions
      ? `Lesson 1 : Solutions (7 Marks) - Types, Raoult's Law & Colligative Properties`
      : isElectrochemistry
      ? `Lesson 2 : Electrochemistry (9 Marks) - Galvanic Cells, Nernst Equation & Conductance`
      : isChemicalKinetics
      ? `Lesson 3 : Chemical Kinetics (7 Marks) - Reaction Rates, Rate Laws & Arrhenius Equation`
      : isDFBlock
      ? `Lesson 4 : d- and f-Block Elements (7 Marks) - Transition Metals, KMnO4/K2Cr2O7 & Lanthanoids`
      : isCoordinationCompounds
      ? `Lesson 5 : Coordination Compounds (7 Marks) - Nomenclature, Isomerism & Crystal Field Theory`
      : isHaloalkanes
      ? `Lesson 6 : Haloalkanes and Haloarenes (6 Marks) - Mechanisms (SN1, SN2) & Organometallics`
      : isAlcoholsPhenolsEthers
      ? `Lesson 7 : Alcohols, Phenols and Ethers (6 Marks) - Preparation, Lucas Test & Williamson Synthesis`
      : isAldehydesKetonesCarboxylic
      ? `Lesson 8 : Aldehydes, Ketones and Carboxylic Acids (8 Marks) - Carbonyl Additions & Condensations`
      : isAmines
      ? `Lesson 9 : Amines (6 Marks) - Basicity Trends, Hinsberg Test & Diazonium Salts`
      : isBiomolecules
      ? `Lesson 10 : Biomolecules (7 Marks) - Carbohydrates, Protein Structures & Nucleic Acids`
      : isRationalIrrational9
      ? `Lesson 1 : Pure Arithmetic - Rational and Irrational Numbers`
      : isCompoundInterest9
      ? `Lesson 2 : Commercial Mathematics - Compound Interest`
      : isExpansions9
      ? `Lesson 3 : Algebra - Expansions`
      : isFactorisation9
      ? `Lesson 4 : Algebra - Factorisation`
      : isSimultaneousEquations9
      ? `Lesson 5 : Algebra - Simultaneous Linear Equations`
      : isIndicesExponents9
      ? `Lesson 6 : Algebra - Indices and Exponents`
      : isLogarithms9
      ? `Lesson 7 : Algebra - Logarithms`
      : isTriangles9
      ? `Lesson 8 : Geometry - Triangles (Congruency & Inequalities)`
      : isMidpointIntercept9
      ? `Lesson 9 : Geometry - Mid-point and Intercept Theorems`
      : isRectilinearFigures9
      ? `Lesson 10 : Geometry - Rectilinear Figures (Quadrilaterals)`
      : isCircles9
      ? `Lesson 11 : Geometry - Circles (Chord & Angle Properties)`
      : isAreaPlaneFigures9
      ? `Lesson 12 : Mensuration - Area of Plane Figures`
      : isSurfaceAreaVolume9
      ? `Lesson 13 : Mensuration - Surface Area and Volume of 3D Solids`
      : isCoordinateGeometry9
      ? `Lesson 14 : Coordinate Geometry - Cartesian System & Distance Formula`
      : isTrigRatios9
      ? `Lesson 15 : Trigonometry - Trigonometrical Ratios & Simple Identities`
      : isStatistics9
      ? `Lesson 16 : Statistics - Data Representation & Measures of Central Tendency`
      : isInternalAssessmentMath9
      ? `Lesson 17 : Paper II - Internal Assessment & Mathematical Projects (20 Marks)`
      : isMeasurements9
      ? `Lesson 1 : Measurements and Experimentation (SI Units, Vernier Callipers, Screw Gauge & Simple Pendulum)`
      : isMotion1D9
      ? `Lesson 2 : Motion in One Dimension (Scalars/Vectors, Speed/Velocity, Graphs & Kinematic Equations)`
      : isLawsOfMotion9
      ? `Lesson 3 : Laws of Motion (Newton's Laws, Inertia, Momentum, Gravitation & Free Fall)`
      : isFluidsArchimedes9
      ? `Lesson 4 : Fluids - Pressure in Fluids, Pascal's Law & Archimedes' Principle of Floatation`
      : isHeatEnergy9
      ? `Lesson 5 : Heat and Energy (Anomalous Expansion, Hope's Experiment, Energy Sources & Global Warming)`
      : isLightReflection9
      ? `Lesson 6 : Light - Reflection at Plane Surfaces & Spherical Mirrors (Ray Diagrams & Mirror Formula)`
      : isSoundUltrasonic9
      ? `Lesson 7 : Sound - Propagation of Waves, Speed Factors & Ultrasonic Applications (SONAR)`
      : isElectricityMagnetism9
      ? `Lesson 8 : Electricity and Magnetism (Electrostatics, Simple Circuits, Magnetic Fields & Neutral Points)`
      : isInternalAssessmentPhysics9
      ? `Lesson 9 : Paper II - Internal Assessment & Practical Physics Lab Work (20 Marks)`
      : isLanguageOfChemistry9
      ? `Lesson 1 : The Language of Chemistry (Symbols, Valency, Formulas, Balancing & Relative Masses)`
      : isChemicalChangesReactions9
      ? `Lesson 2 : Chemical Changes and Reactions (Reaction Types, Energy Changes & Catalysis)`
      : isWaterHydration9
      ? `Lesson 3 : Water (Solutions, Solubility Curves, Hydration, Efflorescence & Water Softening)`
      : isAtomicStructureBonding9
      ? `Lesson 4 : Atomic Structure and Chemical Bonding (Bohr's Model, Isotopes, Ionic & Covalent Dot Structures)`
      : isPeriodicTableICSE9
      ? `Lesson 5 : The Periodic Table (Mendeleev vs Modern, Periodic Law & Trends up to Calcium Z=20)`
      : isHydrogenStudy9
      ? `Lesson 6 : Study of the First Element — Hydrogen (Preparation, Bosch Process, Oxidation-Reduction & Properties)`
      : isGasLawsICSE9
      ? `Lesson 7 : Study of Gas Laws (Boyle's Law, Charles' Law, Absolute Zero & Combined Gas Equation)`
      : isAtmosphericPollution9
      ? `Lesson 8 : Atmospheric Pollution (Acid Rain, Global Warming, Greenhouse Gases & Ozone Depletion)`
      : isInternalAssessmentChemistry9
      ? `Lesson 9 : Paper II - Internal Assessment & Practical Chemistry Lab Experiments (20 Marks)`
      : isBasicBiology9
      ? `Lesson 1 : Basic Biology (The Cell as Unit of Life & Plant/Animal Tissues)`
      : isFloweringPlants9
      ? `Lesson 2 : Flowering Plants (Morphology, Flower Anatomy, Pollination, Fertilization & Seed Germination)`
      : isHumanAnatomyPhysiology9
      ? `Lesson 3 : Human Anatomy and Physiology (Digestion, Skeletal System, Skin & Respiration)`
      : isHealthHygiene9
      ? `Lesson 4 : Health and Hygiene (Communicable Diseases, Pathogens, Immunity & First Aid Protocols)`
      : isWasteManagement9
      ? `Lesson 5 : Waste Generation and Management (Sources, Environmental Impacts & The 3 Rs)`
      : isInternalAssessmentBiology9
      ? `Lesson 6 : Paper II - Internal Assessment & Practical Biology Lab Work (20 Marks)`
      : isOOPConcepts9
      ? `Lesson 1 : Introduction to Object-Oriented Programming Concepts (OOP Principles, Abstraction, Encapsulation, Inheritance & Polymorphism)`
      : isObjectsClasses9
      ? `Lesson 2 : Elementary Concept of Objects and Classes (Real-World Entities, Blueprints & Object Instantiation)`
      : isValuesDataTypes9
      ? `Lesson 3 : Values and Data Types (Unicode, Java Tokens, Identifiers, Primitive Data Types & Type Casting)`
      : isOperatorsJava9
      ? `Lesson 4 : Operators in Java (Arithmetic, Relational, Logical, Unary, Ternary & Operator Precedence)`
      : isInputJava9
      ? `Lesson 5 : Input in Java (Scanner Class, System.in, InputMismatchException & Error Types)`
      : isMathLibraryJava9
      ? `Lesson 6 : Mathematical Library Methods (java.lang.Math Functions, Constants & Algebraic Expressions)`
      : isConditionalConstructs9
      ? `Lesson 7 : Conditional Constructs in Java (if-else, Nested if, Switch-Case & Dangling Else)`
      : isIterativeConstructs9
      ? `Lesson 8 : Iterative Constructs in Java (for, while, do-while Loops, Nested Patterns & Number Algorithms)`
      : isInternalAssessmentCS9
      ? `Lesson 9 : Paper II - Internal Assessment & Practical Lab Work (100 Marks)`
      : isConstitution9
      ? `Lesson 1 : Civics - Our Constitution (Foundation, Salient Features, Rights, Duties & Directive Principles)`
      : isElections9
      ? `Lesson 2 : Civics - Elections (Electoral Process, Election Commission & Election Formats)`
      : isLocalSelfGov9
      ? `Lesson 3 : Civics - Local Self-Government (Rural Panchayati Raj & Urban Municipal Governance)`
      : isAncientIndia9
      ? `Lesson 4 : History - Ancient India (Harappan, Vedic Period, Jainism & Buddhism, Mauryas, Sangam & Guptas)`
      : isMedievalIndia9
      ? `Lesson 5 : History - Medieval India & Cultural Shifts (Cholas, Delhi Sultanate, Mughals, Bhakti & Sufism)`
      : isModernAgeEurope9
      ? `Lesson 6 : History - Modern Age in Europe (Renaissance, Reformation & Industrial Revolution)`
      : isGeographicalSkills9
      ? `Lesson 7 : Geography - Geographical Skills & World Map Work (Oceans, Seas, Mountain Ranges, Plateaus & Rivers)`
      : isPhysicalGeography9
      ? `Lesson 8 : Geography - Physical Earth & Landforms (Earth as Geoid, Latitudes-Longitudes, Movements & Internal Structure)`
      : isAtmosphereHydrosphere9
      ? `Lesson 9 : Geography - Atmosphere & Hydrosphere (Composition, Pressure Belts, Winds, Humidity, Tides & Ocean Currents)`
      : isEnvironmentNaturalRegions9
      ? `Lesson 10 : Geography - Environment & Natural Regions (Global Climatic Zones, Pollution & Conservation)`
      : isInternalAssessmentSocialScience9
      ? `Lesson 11 : Paper I & II - Internal Assessment & Practical Project Work (20 Marks Each)`
      : isBasicConceptsChem11
      ? `Unit 1 : Some Basic Concepts of Chemistry (Laws, Stoichiometry & Concentrations)`
      : isStructureOfAtom11
      ? `Unit 2 : Structure of Atom (Dual Nature, Quantum Mechanics & Aufbau Rule)`
      : isClassificationElements11
      ? `Unit 3 : Classification of Elements and Periodicity in Properties (Periodic Trends & IE)`
      : isChemicalBonding11
      ? `Unit 4 : Chemical Bonding and Molecular Structure (VSEPR, Hybridisation & MOT)`
      : isChemicalThermodynamics11
      ? `Unit 5 : Chemical Thermodynamics (First & Second Laws, Enthalpy & Spontaneity)`
      : isEquilibrium11
      ? `Unit 6 : Equilibrium (Chemical & Ionic Equilibria, Le Chatelier & pH Buffers)`
      : isRedoxReactions11
      ? `Unit 7 : Redox Reactions (Oxidation Numbers & Ion-Electron Balancing)`
      : isInorganicSPBlock11
      ? `Unit 8 : Inorganic Chemistry (s-Block & p-Block Group Trends & Reactivity)`
      : isOrganicHydrocarbons11
      ? `Unit 9 : Organic Chemistry (Nomenclature, Isomerism, Mechanisms & Hydrocarbons)`
      : isPracticalChemistry11
      ? `Paper II : Practical Work & Project (Volumetric, Salt Analysis & Viva - 30 Marks)`
      : isPhysicalWorldMeasurement11
      ? `Unit 1 : Physical World and Measurement (SI Units, Dimensions & Error Propagation)`
      : isKinematics11
      ? `Unit 2 : Kinematics (Motion in a Straight Line, Calculus Derivations & Vectors in a Plane)`
      : isLawsOfMotion11
      ? `Unit 3 : Laws of Motion (Newton's Laws, Momentum Conservation, Friction & Banking of Roads)`
      : isWorkEnergyPower11
      ? `Unit 4 : Work, Energy, and Power (Work-Energy Theorem, Potential Energy & Collisions)`
      : isSystemParticlesRigidBody11
      ? `Unit 5 : Motion of System of Particles and Rigid Body (Centre of Mass, Torque & Moment of Inertia)`
      : isGravitation11
      ? `Unit 6 : Gravitation (Kepler's Laws, 'g' Variations, Escape & Orbital Velocities)`
      : isPropertiesBulkMatter11
      ? `Unit 7 : Properties of Bulk Matter (Elastic Moduli, Pascal's & Bernoulli's Theorems, Surface Tension)`
      : isThermodynamicsPhysics11
      ? `Unit 8 : Heat and Thermodynamics (Calorimetry, Thermal Conductivity, First & Second Laws, Heat Engines)`
      : isKineticTheoryGases11
      ? `Unit 9 : Behaviour of Perfect Gases and Kinetic Theory of Gases (Gas Laws, RMS Speed & Equipartition)`
      : isOscillationsWaves11
      ? `Unit 10 : Oscillations and Waves (SHM Equations, Simple Pendulum, Standing Waves & Beats)`
      : isPracticalPhysics11
      ? `Paper II : Practical Work & Project (Laboratory Experiments, Project File & Viva - 30 Marks)`
      : isDiversityLivingOrganisms11
      ? `Unit 1 : Diversity of Living Organisms (Taxonomy, Five Kingdoms, Plant & Animal Kingdoms)`
      : isStructuralOrganisation11
      ? `Unit 2 : Structural Organisation in Animals and Plants (Plant Anatomy, Tissues & Cockroach Systems)`
      : isCellStructureFunction11
      ? `Unit 3 : Cell: Structure and Function (Cell Organelles, Biomolecules & Cell Division)`
      : isPlantPhysiology11
      ? `Unit 4 : Plant Physiology (Photosynthesis, Respiration & Plant Growth Regulators)`
      : isHumanPhysiology11
      ? `Unit 5 : Human Physiology (Respiration, Circulation, Excretion, Locomotion & Neural-Chemical Coordination)`
      : isPracticalBiology11
      ? `Paper II : Practical Work & Project (Plant Anatomy Slides, Physiology Experiments & Viva - 30 Marks)`
      : isDataRepBooleanAlg11
      ? `Unit 1 : Data Representation and Boolean Algebra (Number Systems, Binary Arithmetic, Boolean Laws & K-Maps)`
      : isHardwareArchitecture11
      ? `Unit 2 : Computer Hardware and Basic Architecture (Combinational Circuits, Adders, MUX/DEMUX & Flip-Flops)`
      : isJavaOOPConcepts11
      ? `Unit 3 : Introduction to Java and OOP Concepts (OOP Principles, JVM, Bytecode & Java Language Basics)`
      : isControlStructuresFunctions11
      ? `Unit 4 : Control Structures and Function Design (Branching, Iteration Loops & Method Design)`
      : isArraysStrings11
      ? `Unit 5 : Primitive Data Structures: Arrays and Strings (1D/2D Arrays, Memory Layouts, Sorting/Searching & String/StringBuffer)`
      : isAdvancedOOPFeatures11
      ? `Unit 6 : Advanced Object-Oriented Programming Features (Classes, Constructors, Encapsulation, Static Fields & Garbage Collection)`
      : isPracticalWorkCS11
      ? `Paper II : Practical Work & Laboratory Assessment (Algorithmic Java Programming, Algorithm Design, Lab Record & Viva - 30 Marks)`
      : isGrowthOfNationalism11
      ? `Section A (1) : Growth of Nationalism (Late 19th Century - Western Education, Press, Economic Policies & INC Foundation)`
      : isEmergenceOfRadicals11
      ? `Section A (2) : Emergence of the Radicals & Swadeshi Movement (Assertive Nationalists, Partition of Bengal, Swadeshi & Boycott)`
      : isWWINationalistPolitics11
      ? `Section A (3) : First World War and Nationalist Politics (Ghadar Movement, Home Rule Leagues & Lucknow Pact 1916)`
      : isGandhianEra11
      ? `Section A (4) : The Gandhian Era (Mass Nationalism 1919–1935 - Satyagraha, Rowlatt, NCM, CDM, Simon Commission & Revolutionary Strands)`
      : isImpactWWIPeaceSettlements11
      ? `Section B (5) : Impact of the First World War and the Peace Settlements (Paris Peace Conference, Big Three & Treaty of Versailles)`
      : isGreatDepressionTotalitarianism11
      ? `Section B (6) : The Great Depression and the Rise of Totalitarianism (Wall Street Crash, Fascism in Italy & Nazism in Germany)`
      : isWWIICollapseCollectiveSecurity11
      ? `Section B (7) : World War II and the Collapse of Collective Security (League Weaknesses, Appeasement Policy & Outbreak 1939)`
      : isRiseOfCommunismChina11
      ? `Section B (8) : Rise of Communism in China 1911–1949 (1911 Revolution, KMT vs CCP Civil War, Long March & Mao Zedong)`
      : isProjectWorkHistory11
      ? `Paper II : Project Work & Historical Research Essay (20 Marks - Research Essay Submission & Viva-Voce Examination)`
      : isEarthStructureEndogenetic11
      ? `Section A (1) : Structure of the Earth and Endogenetic Processes (Crust/Mantle/Core, Plate Tectonics, Folding, Faulting, Volcanism & Earthquakes)`
      : isExogeneticLandforms11
      ? `Section A (2) : Exogenetic Processes and Landform Development (Weathering, Mass Wasting, Fluvial, Eolian & Glacial Landforms)`
      : isAtmosphereHydrosphere11
      ? `Section A (3) : Atmosphere and Hydrosphere (Atmospheric Layers, Heat Budget, Winds, Cyclones, Ocean Topography, Currents & Tides)`
      : isPopulationSettlements11
      ? `Section B (4) : Population Dynamics and Human Settlements (Growth, Demographic Transition, Settlement Patterns & Urbanization)`
      : isPhysicalFrameworkIndia11
      ? `Section C (5) : Physical Framework and Climate of India (Physiographic Divisions, Himalayan/Peninsular Drainage & Monsoon Mechanisms)`
      : isResourcesEnvironmentIndia11
      ? `Section C (6) : Resource Base and Environmental Issues (Forests, Soil Types, Soil Erosion & Disaster Management Policies)`
      : isPracticalGeography11
      ? `Paper II : Practical Work, Cartographic Skills & Field Project (30 Marks - Statistical Diagrams, Map Projections, Toposheet Reading & Survey)`
      : isIntroPolScience11
      ? `Section A (1) : Introduction to Political Science & Theory of State (Scope, State Elements & Social Contract Theories)`
      : isFundamentalPolConcepts11
      ? `Section A (2) : Fundamental Political Concepts (Sovereignty, Law, Liberty, Equality & Justice)`
      : isFormsOfGovt11
      ? `Section B (3) : Forms of Government (Unitary vs Federal, Parliamentary vs Presidential - UK, US, India Case Studies)`
      : isConstitutionsStructures11
      ? `Section B (4) : Constitutions and Organic Structures (Written/Unwritten, Legislature, Executive & Judicial Review)`
      : isFranchiseRepresentation11
      ? `Section B (5) : Franchise, Representation, Political Parties & Pressure Groups (Suffrage, PR Systems & Party Dynamics)`
      : isProjectWorkPolScience11
      ? `Paper II : Project Work & Comparative Political Analysis (20 Marks - Research Essay Submission & Viva-Voce Examination)`
      : isOriginDevSociology11
      ? `Unit 1 : Origin and Development of Sociology and Anthropology (Emergence, Classical Thinkers & Scope)`
      : isResearchMethodologySociology11
      ? `Unit 2 : Research Methodology in Sociology (Scientific Method, Research Design & Data Collection Tools)`
      : isBasicConceptsSociology11
      ? `Unit 3 : Basic Concepts (Individual, Society, Socialization, Looking-Glass Self & Culture)`
      : isSocialStructureSociology11
      ? `Unit 4 : Social Structure (Social Groups, Status & Role, Role Conflict & Social Processes)`
      : isSocialProblemsSociology11
      ? `Unit 5 : Social Problems and Deviance (Overpopulation, Poverty, Child Labour & Vulnerable Groups)`
      : isIndianSociologists11
      ? `Unit 6 : Indian Sociologists (Pioneering Perspectives, G.S. Ghurye, M.N. Srinivas & Village Studies)`
      : isPracticalSociology11
      ? `Paper II : Practical Work & Sociological Research Projects (30 Marks - 2 Empirical Projects & Viva-Voce)`
      : isIntroPsychology11
      ? `Chapter 1 : Introduction to Psychology (Foundations, Nature, Historical Schools & Indian Perspective)`
      : isMethodsPsychology11
      ? `Chapter 2 : Methods of Psychology (Scientific Research, Quantitative/Qualitative Methods & Ethics)`
      : isBiologicalBasesPsychology11
      ? `Chapter 3 : Biological Bases of Behaviour (Neuron, CNS/PNS Structure & Endocrine Regulation)`
      : isHumanDevelopmentPsychology11
      ? `Chapter 4 : Human Development (Principles, Developmental Milestones & Theories of Piaget & Erikson)`
      : isSensoryPerceptualPsychology11
      ? `Chapter 5 : Sensory, Attentional, and Perceptual Processes (Sensory Modalities, Attention & Gestalt)`
      : isLearningPsychology11
      ? `Chapter 6 : Learning (Classical & Operant Conditioning, Cognitive & Social Observational Learning)`
      : isMemoryPsychology11
      ? `Chapter 7 : Human Memory (Stage Model, Forgetting Theories & Memory Enhancement)`
      : isPracticalPsychology11
      ? `Paper II : Practical Work (30 Marks - Core Laboratory Experiments, Field Projects & Viva-Voce)`
      : isUnderstandingEconomics11
      ? `Chapter 1 : Understanding Economics & Basic Concepts (Smith/Marshall/Robbins/Samuelson Definitions, Micro/Macro)`
      : isConsumerBehaviourDemand11
      ? `Chapter 2 : Consumer Behaviour and Demand (Cardinal/Ordinal Utility, Demand Law & Elasticity)`
      : isProducerBehaviourSupplyCost11
      ? `Chapter 3 : Producer Behaviour, Supply, and Cost (Variable Proportions, Cost/Revenue & Supply Elasticity)`
      : isMarketFormsPriceDet11
      ? `Chapter 4 : Market Forms and Price Determination (Perfect Competition, Monopoly, Price Ceilings/Floors)`
      : isStructuralFeaturesIndianEcon11
      ? `Chapter 5 : Structural Features of the Indian Economy (Sectors, LPG Reforms of 1991 & Contemporary Challenges)`
      : isBasicStatisticsEconomics11
      ? `Chapter 6 : Basic Statistics for Economics (Data Collection, Dispersion, Correlation & Index Numbers)`
      : isProjectWorkEconomics11
      ? `Paper II : Project Work (20 Marks - Research Proposals, Field Surveys & Viva-Voce Defense)`
      : `Foundations of ${chapter}${rigorText}`;

    const l1Desc = isCommunicationSystemsLesson
      ? `Chapter 42: Communication Systems (Pages 1951-2000). Covers Elements of Communication System (Transmitter, Channel, Receiver, Noise), Signal Bandwidth (Speech, Music, Video), Transmission Media, Ground/Sky/Space Wave Propagation, Ionospheric Layers, Need for Modulation, Amplitude Modulation (AM) Derivation & Sidebands, Frequency Modulation (FM), Diode Detector Demodulation, Optical Fiber & Satellite Communications. Solved Numericals and Competitive Practice.`
      : isLogicGates
      ? `Chapter 41: Logic Gates (Pages 1901-1950). Covers Analog vs Digital Signals, Binary Logic (0 and 1), Basic Gates (OR, AND, NOT), Truth Tables & Symbols, Universal Gates (NAND, NOR) & Proof of Universality, Exclusive Gates (XOR, XNOR), De Morgan's Theorems, Diode & Transistor Logic Realizations, IC Packaging (SSI, LSI, VLSI). Solved Numericals and Competitive Practice.`
      : isJunctionTransistors
      ? `Chapter 40: Junction Transistors (Pages 1851-1900). Covers Bipolar Junction Transistor (BJT) Construction (NPN & PNP), Emitter-Base-Collector Doping, Transistor Action & Currents (I_E = I_B + I_C), Common Emitter (CE) Input/Output Characteristics, Current Gains Alpha (α) & Beta (β), Transistor as CE Amplifier (Voltage Gain, Phase Reversal), Transistor as a Switch & LC Oscillator (Barkhausen Criterion). Solved Numericals and Competitive Practice.`
      : isSemiconductorDiodes
      ? `Chapter 39: Semiconductor Diodes (Pages 1801-1850). Covers P-N Junction Diode V-I Characteristics in Forward & Reverse Bias, Static (R_dc) & Dynamic (r_ac) Resistance, Avalanche vs Zener Breakdown, Zener Diode Voltage Regulator Circuits, Light Emitting Diodes (LED), Photodiodes, Solar Cells (V_oc, I_sc), Schottky Diodes. Solved Numericals and Competitive Practice.`
      : isSemiconductorElectronicsLesson
      ? `Chapter 38: Semiconductor Electronics (Pages 1751-1800). Covers Energy Bands in Solids, Intrinsic & Extrinsic Semiconductors, P-N Junction Formation, Depletion Region, Forward & Reverse Biasing V-I Characteristics, Half-Wave & Full-Wave Rectifiers, Zener Diode Voltage Regulation, LEDs, Photodiodes, Solar Cells. Solved Numericals and Competitive Practice.`
      : isFissionFusion
      ? `Chapter 37: Nuclear Fission and Fusion : Sources of Energy (Pages 1701-1750). Covers Nuclear Fission Discovery, U-235 Fission Reactions, ~200 MeV Energy Release, Liquid Drop Model, Uncontrolled & Controlled Chain Reactions, Multiplication Factor k, Critical Mass, Nuclear Reactor Components (Fuel Rods, Moderator, Control Rods, Coolant), Thermonuclear Fusion, Stellar Proton-Proton Cycle, Tokamak Confinement. Solved Numericals and Competitive Practice.`
      : isMassEnergyBinding
      ? `Chapter 36: Mass-Energy Equivalence : Nuclear Binding Energy (Pages 1651-1700). Covers Einstein's Mass-Energy Equivalence (E = mc²), Atomic Mass Unit Equivalent (1 u = 931.5 MeV), Mass Defect (Δm), Binding Energy Per Nucleon Curve, Nuclear Stability Belt & N/Z Ratio, Reaction Q-Value Calculations, Pair Production (γ → e⁻ + e⁺, 1.02 MeV) & Pair Annihilation. Solved Numericals and Competitive Practice.`
      : isRadioactivity
      ? `Chapter 35: Radioactivity (Pages 1601-1650). Covers Discovery of Radioactivity, Properties of Alpha, Beta, Gamma Radiations, Electric/Magnetic Deflection, Soddy-Russell Group Displacement Laws, Radioactive Decay Law (N = N_0 e^(-λt)), Activity (Bq, Ci), Half-Life (T_1/2 = 0.693/λ), Mean Life (τ = 1/λ), Beta Decay Neutrino Hypothesis, Carbon-14 Dating. Solved Numericals and Competitive Practice.`
      : isNuclearStructure
      ? `Chapter 34: Nuclear Structure (Pages 1551-1600). Covers Nuclear Composition, Protons & Neutrons, Nuclear Radius (R = R_0 A^(1/3)), Constant Density (~2.3×10¹⁷ kg/m³), Isotopes, Isobars, Isotones, Atomic Mass Unit (1 u = 931.5 MeV), Mass Defect, Binding Energy Per Nucleon Curve, Properties of Nuclear Forces (Short Range, Saturation, Charge Independence), Yukawa Meson Theory. Solved Numericals and Competitive Practice.`
      : isAtomsBohr
      ? `Chapter 33: Atom, Origin of Spectra : Bohr's Theory of Hydrogen Atom (Pages 1501-1550). Covers Rutherford's Scattering Experiment & Model, Distance of Closest Approach, Bohr's Postulates & Quantization Condition (L = mvr = nh/2π), Derivations for Radius (r_n ∝ n²), Velocity & Energy (E_n = -13.6/n² eV), Hydrogen Line Spectra (Lyman, Balmer, Paschen, Brackett, Pfund), Rydberg Constant, de Broglie Wave Explanation. Solved Numericals and Competitive Practice.`
      : isXRays
      ? `Chapter 32: X-Rays (Pages 1451-1500). Covers Production of X-Rays, Coolidge Tube Construction & Operation, Continuous X-Ray Spectrum & Duane-Hunt Limit (λ_min = 12400/V Å), Characteristic X-Rays (K_α, K_β, L_α), Moseley's Law (√ν = a(Z - b)), Bragg's Law of X-Ray Diffraction (2d sin θ = nλ), Radiography & Industrial Applications. Solved Numericals and Competitive Practice.`
      : isMatterWaves
      ? `Chapter 31: Matter Waves (Pages 1401-1450). Covers Dual Nature of Radiation & Matter, Photon Momentum (p = h/λ), de Broglie Hypothesis (λ = h/p), de Broglie Wavelength of Accelerated Electrons (λ = 12.27/√V Å), Davisson-Germer Experiment (Nickel Crystal Diffraction), Wave Packet Concept, Heisenberg Uncertainty Principle (Δx·Δp ≥ h/4π). Solved Numericals and Competitive Practice.`
      : isPhotoelectric
      ? `Chapter 30: Photoelectric Effect (Pages 1351-1400). Covers Free Electrons & Work Function (W_0 = hν_0), Emission Types, Hertz & Lenard's Experiments, Effect of Intensity, Potential & Frequency, Concept of Stopping Potential (V_0), Laws of Photoelectric Emission, Einstein's Photoelectric Equation (hν = W_0 + K_max), Determination of Planck's Constant, Photocells & Applications. Solved Numericals and Competitive Practice.`
      : isPolarization
      ? `Chapter 29: Polarization of Light (Pages 1301-1350). Covers Unpolarized vs Plane Polarized Light, Transverse Nature of Light Waves, Plane of Vibration & Polarization, Polarization by Reflection & Brewster's Law (tan i_p = μ), Polarization by Refraction & Double Refraction (Birefringence), Nicol Prism, Malus' Law (I = I_0 cos²θ), Polaroids & Applications, Optical Activity & Specific Rotation. Solved Numericals and Competitive Practice.`
      : isDiffraction
      ? `Chapter 28: Diffraction of Light (Pages 1251-1300). Covers Bending of Light around Obstacles, Fresnel vs Fraunhofer Diffraction, Single Slit Diffraction, Positions of Minima (a sin θ = nλ) & Maxima, Central Maximum Width (2λD/a), Intensity Distribution, Fresnel Distance (Z_f = a²/λ). Solved Numericals and Competitive Practice.`
      : isInterference
      ? `Chapter 27: Interference of Light (Pages 1201-1250). Covers Superposition Principle, Coherent & Incoherent Sources, Young's Double Slit Experiment (YDSE), Mathematical Analysis of Fringe Intensity, Fringe Width Formula (β = λD/d), Shift by Thin Sheet, Thin Film Interference. Solved Numericals and Competitive Practice.`
      : isWaveNatureHuygens
      ? `Chapter 26: Wave Nature of Light : Huygens' Principle (Pages 1151-1200). Covers Wavefronts (Spherical, Plane, Cylindrical), Huygens' Principle of Secondary Wavelets, Proof of Reflection and Refraction Laws using Wave Theory, Speed of Light in Denser Medium, Doppler Effect in Light (Red Shift & Blue Shift). Solved Numericals and Competitive Practice.`
      : isOpticalInstruments
      ? `Chapter 25: Optical Instruments (Pages 1101-1150). Covers Human Eye & Defects of Vision, Simple Microscope, Compound Microscope, Astronomical & Terrestrial Telescopes, Cassegrain Reflecting Telescope, Resolving Power & Rayleigh's Criterion. Solved Numericals and Competitive Practice.`
      : isRefractionPrism
      ? `Chapter 24: Refraction and Dispersion of Light through a Prism (Pages 1051-1100). Covers Refraction through a Triangular Prism, Angle of Deviation, Minimum Deviation (δm), Prism Formula, Dispersion of Light, Angular Dispersion, Dispersive Power (ω), Rayleigh Scattering, Primary & Secondary Rainbows. Solved Numericals and Competitive Practice.`
      : isRefractionLenses
      ? `Chapter 23: Refraction of Light at Spherical Surfaces : Lenses (Pages 1001-1050). Covers Refraction at Single Spherical Surface, Thin Lens Formula (1/f = 1/v - 1/u), Lens Maker's Formula, Power of Lens (Dioptres), Combination of Lenses in Contact, Magnification, Aberrations & Achromatism. Solved Numericals and Competitive Practice.`
      : isRefractionPlane
      ? `Chapter 22: Refraction of Light at a Plane Interface : Total Internal Reflection : Optical Fiber (Pages 951-1000). Covers Laws of Refraction, Snell's Law, Refractive Index, Real and Apparent Depth, Lateral Shift, Critical Angle, Total Internal Reflection (TIR), Optical Fibers, Prisms & Mirage. Solved Numericals and Competitive Practice.`
      : isReflection
      ? `Chapter 21: Reflection of Light : Spherical Mirrors (Pages 901-950). Covers Laws of Reflection, Reflection at Plane & Spherical Surfaces, Sign Convention, Focal Length relation (f = R/2), Mirror Formula (1/f = 1/v + 1/u), Linear Magnification (m = -v/u), Ray Diagrams for Concave & Convex Mirrors, Spherical Aberration, and Practical Applications. Solved Numericals and Competitive Practice.`
      : isCommunication
      ? `Chapter 20: Communication Systems (Pages 851-900). Covers Elements of Communication, Bandwidth, Electromagnetic Wave Propagation (Ground, Sky, Space), Modulation necessity, Amplitude Modulation (AM), Production and Detection of AM Waves. Solved Numericals and Competitive Practice.`
      : isSemiconductor
      ? `Chapter 19: Semiconductor Electronics (Pages 801-850). Covers Energy Bands, Intrinsic/Extrinsic Semiconductors, p-n Junction, Diodes (Zener, LED, Photodiode, Solar Cell), Rectifiers, Junction Transistors, Digital Electronics (Logic Gates). Solved Numericals and Competitive Practice.`
      : isNuclei
      ? `Chapter 18: Nuclei (Pages 751-800). Covers Composition and Size of Nucleus, Mass-Energy Equivalence, Mass Defect, Binding Energy curve, Nuclear Forces, Radioactivity (Alpha, Beta, Gamma decay), Radioactive Decay Law, Half-Life and Mean Life, Fission and Fusion, and Nuclear Reactors. Solved Numericals and Competitive Practice.`
      : isAtoms
      ? `Chapter 17: Atoms (Pages 701-750). Covers Rutherford's Nuclear Model, Alpha-particle Scattering, Distance of Closest Approach, Bohr Model of Hydrogen Atom, Energy Levels (E_n = -13.6/n² eV), Atomic Spectra (Lyman, Balmer, etc.), de Broglie's Explanation of Bohr's Quantisation, Limitations, Solved Numericals and Competitive Practice.`
      : isDualNature
      ? `Chapter 16: Dual Nature of Radiation and Matter (Pages 651-700). Covers Photoelectric Effect, Hertz/Lenard Observations, Work Function, Einstein's Photoelectric Equation (K_max = hν - Φ), Particle Nature (Photon), de Broglie Relation (λ = h/p), Davisson-Germer Experiment, and X-Rays, Solved Numericals and Competitive Practice.`
      : isWaveOptics
      ? `Chapter 15: Wave Optics (Pages 596-650). Covers Huygens' Principle, Refraction & Reflection of Plane Waves, Coherent/Incoherent Sources, Interference (YDSE), Fringe Width β = λD/d, Diffraction at Single Slit (Central Maximum & Intensity), Resolving Power, Polarization, Malus's Law (I = I₀ cos²θ), Brewster's Law (n = tan i_p), Solved Numericals and Competitive Practice.`
      : isRayOptics
      ? `Chapter 14: Ray Optics and Optical Instruments (Pages 546-595). Covers Reflection at Spherical Mirrors, Refraction at Plane & Spherical Surfaces, Snell's Law, Total Internal Reflection & Optical Fibers, Lens Maker's Formula & Thin Lens Formula, Prism Deviation & Dispersion, Scattering of Light, Simple & Compound Microscopes, Astronomical & Reflecting Telescopes, Solved Numericals and Competitive Practice.`
      : isElectromagneticWaves
      ? `Chapter 13: Electromagnetic Waves (Pages 516-545). Covers Inconsistency of Ampere's Law, Displacement Current I_d = ε₀(dΦ_E/dt), Ampere-Maxwell Law, Production & Transverse Nature of EM Waves, Speed in Vacuum (c = 1/√(μ₀ε₀) = 3×10⁸ m/s) & Medium, Ratio E₀/B₀ = c, Energy Density u = ½ε₀E² + ½(B²/μ₀), Poynting Vector S, Electromagnetic Spectrum (Radio, Micro, IR, Visible, UV, X-Rays, Gamma Rays), Solved Numericals and Competitive Practice.`
      : isAlternatingCurrent
      ? `Chapter 12: Alternating Current (Pages 466-515). Covers Average & RMS Values (I_rms = I₀/√2), AC Circuits with R, L, C (Inductive & Capacitive Reactance X_L = ωL, X_C = 1/ωC), L-R, C-R, L-C-R Series Circuits (Impedance Z = √(R² + (X_L - X_C)²)), Electrical Resonance (f_r = 1/(2π√LC)), Power Factor cos φ, Wattless Current, LC Oscillations, Transformers (Principle, Efficiency & Energy Losses), Solved Numericals and Competitive Practice.`
      : isElectromagneticInduction
      ? `Chapter 11: Electromagnetic Induction (Pages 416-465). Covers Magnetic Flux Φ = B · A cos θ, Faraday's Laws of EMI, Lenz's Law & Conservation of Energy, Motional EMF (Translational & Rotational), Eddy Currents, Self-Inductance L, Mutual Inductance M, Energy Stored in Inductor U = ½ L I², Combination of Inductors, AC Generator/Dynamo (e = e₀ sin ωt), Solved Numericals and Competitive Practice.`
      : isMagneticSubstances
      ? `Chapter 10: Magnetic Classification of Substances (Pages 381-415). Covers Intensity of Magnetization M, Magnetic Field Intensity H, Magnetic Susceptibility χ, Relative Permeability μ_r = 1 + χ, Diamagnetic, Paramagnetic & Ferromagnetic Materials (Curie's Law χ = C/T, Weiss Domain Theory), Hysteresis Loop (Retentivity & Coercivity), Hysteresis Loss, Choice of Materials for Permanent Magnets & Electromagnets, Solved Numericals and Competitive Practice.`
      : isEarthMagnetism
      ? `Chapter 9: Magnetic Field and Earth's Magnetism (Pages 346-380). Covers Bar Magnet Dipole, Field Lines, Axial and Equatorial Field Intensity, Gauss's Law in Magnetism ∮ B · dA = 0, Earth's Magnetic Field Elements (Declination θ, Dip/Inclination δ, Horizontal Component H_e), Neutral Points, Tangent Galvanometer & Tangent Law (I = K tan θ), Solved Numericals and Competitive Practice.`
      : isTorqueLoop
      ? `Chapter 8: Torque on a Current-Loop : Moving-Coil Galvanometer (Pages 311-345). Covers Torque on Rectangular Loop τ = NIAB sin θ, Magnetic Dipole Moment M = NIA, Magnetic Moment of Revolving Electron (Bohr Magneton), Moving-Coil Galvanometer (Principle, Soft Iron Core, Radial Field, Current/Voltage Sensitivity), Conversion to Ammeter (Shunt) & Voltmeter, Solved Numericals and Competitive Practice.`
      : isMovingCharges
      ? `Chapter 7: Moving Charges and Magnetic Field (Pages 261-310). Covers Oersted's Experiment, Biot-Savart Law & applications (circular loop, straight conductor), Ampere's Circuital Law, Solenoid & Toroid, Lorentz Magnetic Force F = qvB sin θ, Cyclotron principle & working, Parallel conductors force & Definition of Ampere, Solved Numericals and Competitive Practice.`
      : isDCCircuits
      ? `Chapter 6: DC Circuits and Measurements (Pages 211-260). Covers Electric Energy & Power, EMF & Terminal Voltage, Combination of Cells (Series, Parallel, Mixed), Kirchhoff's Laws (Junction Rule & Loop Rule), Wheatstone Bridge, Meter Bridge, Potentiometer (Principle, Comparison of EMFs, Internal Resistance), Solved Numericals and Competitive Practice.`
      : isResistance
      ? `Chapter 5: Electric Resistance and Ohm's Law (Pages 166-210). Covers Electric Current, Free Electron Model, Drift Velocity & Relaxation Time, Ohm's Law deduction & proof, Electrical Resistance & Resistivity, Conductivity & Current Density j = σE, Temperature Dependence, Ohmic/Non-Ohmic conductors, Carbon Resistors, Thermistors, Superconductors, Internal Resistance of Cell, Solved Numericals and Competitive Practice.`
      : isCapacitors
      ? `Chapter 4: Capacitors and Dielectrics (Pages 120-165). Covers Capacitance of conductors & spherical conductors, Parallel Plate Capacitors, Dielectric constant & slabs, Series and Parallel combinations, Stored Energy, Energy Density, Sharing of charges, Polarization, Van de Graaff Generator, Solved Numericals and Competitive Practice.`
      : isElectricPotential
      ? `Chapter 3: Electric Potential (Pages 86-119). Covers Electric Potential & Potential Difference, Potential due to Point Charge & System of Charges, Dipole Potential, E = -dV/dr relation, Equipotential Surfaces, Potential Energy of System & Dipole in Uniform Field, Work done in Rotation, Corona Discharge, Electron-Volt, Solved Numericals and Competitive Practice.`
      : isGaussTheorem
      ? `Chapter 2: Gauss' Theorem (Pages 50-85). Covers Area Vector, Solid Angle, Electric Flux, Gauss' Theorem statement & proofs, Coulomb's Law deduction, Electric field due to long wire, thin sheet, conducting plate, spherical shell & solid sphere, Mechanical force, Energy density, Solved Numericals and Competitive Exam Practice.`
      : isElectricCharges
      ? `Chapter 1: Electric Charges and Fields (Pages 1-49). Covers Electric Charge, Positive/Negative charges, Electron Theory, Conductors & Insulators, Electrostatic Induction, Coulomb's Law, Superposition Principle, Electric Field & Intensity, Lines of Force, Electric Dipoles & Torque, Solved Numericals and Competitive Exam Practice.`
      : isSexualReproductionPlants
      ? `Chapter 1: Sexual Reproduction in Flowering Plants. Covers Flower Structure, Microsporogenesis, Megasporogenesis, Pollination Dynamics, Double Fertilization, Post-Fertilization development, Seed and Fruit formation, Apomixis and Polyembryony.`
      : isHumanReproduction
      ? `Chapter 2: Human Reproduction. Covers Male and Female Reproductive Systems, Gametogenesis (Spermatogenesis & Oogenesis), Menstrual Cycle, Fertilization, Implantation, Embryonic Development, Parturition and Lactation.`
      : isReproductiveHealth
      ? `Chapter 3: Reproductive Health. Covers Reproductive Health Problems and Strategies, Population Explosion, Birth Control Methods (Natural, Barrier, IUDs, Oral, Surgical), MTP, STIs, and Assisted Reproductive Technologies (ART: IVF, ZIFT, GIFT).`
      : isPrinciplesInheritance
      ? `Chapter 4: Principles of Inheritance and Variation. Covers Mendelian Inheritance, Deviations from Mendelism (Incomplete Dominance, Co-dominance), Chromosomal Theory of Inheritance, Sex Determination, Mutation, and Genetic Disorders.`
      : isMolecularBasis
      ? `Chapter 5: Molecular Basis of Inheritance. Covers Structure of DNA and RNA, DNA Packaging, Replication, Transcription, Genetic Code, Translation, Regulation of Gene Expression (Lac Operon), Human Genome Project, and DNA Fingerprinting.`
      : isEvolution
      ? `Chapter 6: Evolution. Covers Origin of Life, Evidence for Biological Evolution, Adaptive Radiation, Biological Evolution, Mechanism of Evolution (Hardy-Weinberg Principle), and Evolution of Man.`
      : isHumanHealth
      ? `Chapter 7: Human Health and Disease. Covers Common Diseases in Humans, Immunity (Innate & Acquired), Vaccination, AIDS, Cancer, and Drugs & Alcohol Abuse.`
      : isMicrobes
      ? `Chapter 8: Microbes in Human Welfare. Covers Microbes in Household Products, Industrial Products, Sewage Treatment, Biogas Production, Biocontrol Agents, and Biofertilizers.`
      : isBiotechPrinciples
      ? `Chapter 9: Biotechnology: Principles and Processes. Covers Genetic Engineering Principles, Recombinant DNA Technology tools (Restriction Enzymes, Vectors, Competent Host), and Processes of rDNA Technology.`
      : isBiotechApps
      ? `Chapter 10: Biotechnology and its Applications. Covers Applications in Agriculture (Bt Cotton, Pest Resistant Plants), Medicine (Genetically Engineered Insulin, Gene Therapy), Transgenic Animals, and Ethical Issues.`
      : isOrganismsPopulations
      ? `Chapter 11: Organisms and Populations. Covers Organism and its Environment, Major Abiotic Factors, Responses to Abiotic Factors, Adaptations, and Population Attributes, Growth and Interactions.`
      : isEcosystem
      ? `Chapter 12: Ecosystem. Covers Ecosystem Structure and Function, Productivity, Decomposition, Energy Flow, Ecological Pyramids, Ecological Succession, and Nutrient Cycling.`
      : isBiodiversity
      ? `Chapter 13: Biodiversity and Conservation. Covers Biodiversity Levels, Patterns and Importance, Loss of Biodiversity, and Biodiversity Conservation (In-situ and Ex-situ).`
      : isPythonRevision
      ? `Chapter 1: Python Revision Tour. Covers Python basics, variables, data types, operators, flow control, strings, lists, tuples, and dictionaries.`
      : isCSFunctions
      ? `Chapter 2: Functions in Python. Covers Function definition, parameters, arguments (positional, keyword, default), return values, and LEGB scoping rules.`
      : isFileHandling
      ? `Chapter 3: File Handling. Covers Text files, binary files (pickle module), CSV files (csv module), and error handling in file operations.`
      : isCSDataStructures
      ? `Chapter 4: Data Structures. Covers linear data structures, focusing on Stack implementation using Python lists (Push and Pop operations).`
      : isCSComputerNetworks
      ? `Chapter 5: Computer Networks. Covers Evolution of networking, types (LAN/WAN), topologies, network devices, protocols (TCP/IP, HTTP), and security.`
      : isDatabaseManagement
      ? `Chapter 6: Database Management. Covers Relational database concepts, SQL DDL/DML commands, aggregate functions, joins, and Python-SQL connectivity.`
      : isSocietalImpacts
      ? `Chapter 7: Societal Impacts. Covers Digital footprint, netiquettes, data protection, intellectual property rights, cyber crimes, and e-waste management.`
      : isBricksBeads
      ? `Chapter 1: Bricks, Beads and Bones. Covers the Harappan Civilisation, urban planning, subsistence strategies, craft production, trade networks, and theories of decline.`
      : isKingsFarmers
      ? `Chapter 2: Kings, Farmers and Towns. Covers early states and economies (600 BCE-600 CE), the Mauryan Empire, new notions of kingship, and the growth of towns and trade.`
      : isKinshipCaste
      ? `Chapter 3: Kinship, Caste and Class. Covers social histories using the Mahabharata, rules of marriage, the caste system, and social mobility in early societies.`
      : isThinkersBeliefs
      ? `Chapter 4: Thinkers, Beliefs and Buildings. Covers cultural developments, Sanchi Stupa, life and teachings of the Buddha, Mahayana Buddhism, and temple architecture.`
      : isTravellers
      ? `Chapter 5: Through the Eyes of Travellers. Covers perceptions of Indian society by Al-Biruni, Ibn Battuta, and Francois Bernier from the 10th to 17th century.`
      : isBhaktiSufi
      ? `Chapter 6: Bhakti-Sufi Traditions. Covers religious beliefs and devotional texts, the Alvars and Nayanars, growth of Sufism, and teachings of Kabir, Guru Nanak and Mirabai.`
      : isVijayanagara
      ? `Chapter 7: An Imperial Capital: Vijayanagara. Covers the discovery of Hampi, the royal and sacred centres, and the architecture of the Vijayanagara Empire.`
      : isPeasantsZamindars
      ? `Chapter 8: Peasants, Zamindars and the State. Covers agrarian society and the Mughal Empire, the village community, and land revenue systems.`
      : isColonialismCountryside
      ? `Chapter 10: Colonialism and the Countryside. Covers Bengal and the Zamindars, the Santhal rebellion, and the Deccan Riots through official archives.`
      : isRebelsRaj
      ? `Chapter 11: Rebels and the Raj. Covers the Revolt of 1857, its pattern, its spread in Awadh, and how it is represented in historical narratives.`
      : isGandhiMovement
      ? `Chapter 12: Mahatma Gandhi and the Nationalist Movement. Covers the Salt March, Civil Disobedience, and the final stages of the freedom struggle.`
      : isFramingConstitution
      ? `Chapter 13: Framing the Constitution. Covers the tumultuous time of independence, defining rights, and the language of the nation.`
      : isGeogHumanNature
      ? `Chapter 1: Human Geography: Nature and Scope. Covers the dualism in geography, naturalisation of humans, humanisation of nature, and the concept of neo-determinism.`
      : isGeogWorldPop
      ? `Chapter 2: The World Population. Covers population distribution patterns, density, factors affecting population, components of population change, and demographic transition.`
      : isGeogHumanDev
      ? `Chapter 3: Human Development. Covers the four pillars of human development, approaches (income, welfare, basic needs), and international rankings.`
      : isGeogPrimary
      ? `Chapter 4: Primary Activities. Covers subsistence and commercial agriculture, nomadic herding, commercial livestock rearing, and mining.`
      : isGeogSecondary
      ? `Chapter 5: Secondary Activities. Covers types of manufacturing industries based on size, raw materials, and ownership, and modern large-scale manufacturing.`
      : isGeogTertiary
      ? `Chapter 6: Tertiary and Quaternary Activities. Covers trade and commerce, transport, communication, and knowledge-based services like BPO and KPO.`
      : isGeogTransport
      ? `Chapter 7: Transport and Communication. Covers modes of transport (road, rail, water, air), trans-continental railways, and the digital revolution in communication.`
      : isGeogInternationalTrade
      ? `Chapter 8: International Trade. Covers the history of trade, types of trade (bilateral, multilateral), and the role of the WTO.`
      : isGeogHumanSettlements
      ? `Chapter 9: Human Settlements. Covers rural and urban settlement patterns, functional classification of Indian towns, and problems of urbanisation.`
      : isEndOfBipolarity
      ? `Chapter 1: The End of Bipolarity. Covers the disintegration of the Soviet Union, the rise of democratic politics in post-communist states, and the shift to a unipolar world.`
      : isContemporaryCentres
      ? `Chapter 2: Contemporary Centres of Power. Covers the emergence of alternative centres of power like the EU, ASEAN, and the economic rise of China.`
      : isContemporarySouthAsia
      ? `Chapter 3: Contemporary South Asia. Covers the political dynamics of South Asian nations, ethnic conflicts, and India's relations with its neighbours.`
      : isIntlOrganizations
      ? `Chapter 4: International Organizations. Covers the role of the UN, reforms in global governance, and the importance of international cooperation.`
      : isSecurityContemporary
      ? `Chapter 5: Security in the Contemporary World. Covers traditional and non-traditional notions of security, including human security and global threats.`
      : isEnvironmentResources
      ? `Chapter 6: Environment and Natural Resources. Covers global environmental politics, common but differentiated responsibilities, and resource geopolitics.`
      : isGlobalizationPol
      ? `Chapter 7: Globalization. Covers the political, economic, and cultural dimensions of globalization, and its impact on the state and society.`
      : isChallengesNationBuilding
      ? `Chapter 8: Challenges of Nation-Building. Covers the integration of princely states, the process of partition, and the reorganization of states in India.`
      : isRecentDevelopmentsPol
      ? `Chapter 9: Recent Developments in Indian Politics. Covers the era of coalitions, the Mandal issue, and the emergence of a new political consensus in India.`
      : isSocDemography
      ? `Chapter 1: Demographic Structure of Indian Society. Covers demographic theories, population trends, age structure, and literacy variations in India.`
      : isSocInstitutions
      ? `Chapter 2: Social Institutions: Continuity and Change. Covers the caste system, tribal communities, family patterns, and kinship across different cultures.`
      : isSocInequality
      ? `Chapter 3: Patterns of Social Inequality and Exclusion. Covers social stratification, struggles of Dalits and Adivasis, and the quest for gender equality.`
      : isSocDiversity
      ? `Chapter 4: The Challenges of Cultural Diversity. Covers regionalism, communalism, secularism, and the role of the state in managing cultural differences.`
      : isSocStructuralChange
      ? `Chapter 5: Structural Change. Covers the impact of colonialism, the process of industrialization, and the growth of urban centers in India.`
      : isSocCulturalChange
      ? `Chapter 6: Cultural Change. Covers social processes like Sanskritization, Westernization, modernization, and secularization in Indian society.`
      : isSocRuralSociety
      ? `Chapter 7: Change and Development in Rural Society. Covers agrarian structure, land reforms, and the social impact of the Green Revolution.`
      : isSocIndustrialSociety
      ? `Chapter 8: Change and Development in Industrial Society. Covers the organization of work, industrialization patterns, and the home-based work sector.`
      : isSocSocialMovements
      ? `Chapter 9: Social Movements. Covers the features and types of social movements, including environmental, class, caste, and women's movements.`
      : isPsychVariations
      ? `Chapter 1: Variations in Psychological Attributes. Covers individual differences, theories of intelligence, and the assessment of psychological attributes.`
      : isPsychPersonality
      ? `Chapter 2: Self and Personality. Covers the concept of self, major approaches to personality, and techniques for personality assessment.`
      : isPsychChallenges
      ? `Chapter 3: Meeting Life Challenges. Covers the nature of stress, its effects on health, and strategies for coping and promoting well-being.`
      : isPsychDisorders
      ? `Chapter 4: Psychological Disorders. Covers classification, factors underlying abnormal behaviour, and major clinical conditions.`
      : isPsychTherapy
      ? `Chapter 5: Therapeutic Approaches. Covers the process of psychotherapy and various types of therapeutic interventions and rehabilitation.`
      : isPsychSocial
      ? `Chapter 6: Attitude and Social Cognition. Covers attitude formation, social schema, and the dynamics of prejudice and discrimination.`
      : isPsychGroups
      ? `Chapter 7: Social Influence and Group Processes. Covers group formation, influence of groups on behaviour, and social influence processes.`
      : isISCPsychIntelligence
      ? `Chapter 1: Intelligence and Ability. Covers definitions of intelligence, major theories (Spearman, Thurstone, Gardner), and the assessment of emotional and social intelligence.`
      : isISCPsychPersonality
      ? `Chapter 2: Personality. Covers theories of personality (Type and Trait), psychoanalytic approaches, and methods of personality assessment.`
      : isISCPsychLifespan
      ? `Chapter 3: Lifespan Development. Covers stages of human development from infancy to old age, focusing on cognitive and social changes.`
      : isISCPsychStress
      ? `Chapter 4: Stress and Health. Covers the concept of stress, its biological effects, and psychological strategies for health promotion and stress management.`
      : isISCPsychDisorders
      ? `Chapter 5: Psychological Disorders and Psychotherapy. Covers clinical conditions, classification systems (DSM/ICD), and various therapeutic interventions.`
      : isISCPsychSocialThought
      ? `Chapter 6: Social Thought and Social Behaviour. Covers social cognition, schema, attribution processes, and the formation of social attitudes.`
      : isISCPsychSocialInfluence
      ? `Chapter 7: Attitude and Social Influence. Covers social influence processes like conformity and obedience, group dynamics, and leadership styles.`
      : isISCBioReproduction
      ? `Chapter 1: Reproduction. Covers reproduction in organisms, sexual reproduction in flowering plants, human reproduction, and reproductive health.`
      : isISCBioGenetics
      ? `Chapter 2: Genetics and Evolution. Covers principles of inheritance and variation, molecular basis of inheritance, and evolutionary biology.`
      : isISCBioWelfare
      ? `Chapter 3: Biology and Human Welfare. Covers human health, common diseases, and the role of microbes in human welfare.`
      : isISCBioBiotech
      ? `Chapter 4: Biotechnology and its Applications. Covers principles and processes of biotechnology, and its diverse applications in agriculture and medicine.`
      : isISCBioEcology
      ? `Chapter 5: Ecology and Environment. Covers organisms and populations, ecosystem dynamics, biodiversity, and critical environmental issues.`
      : isISCEconMicro
      ? `Chapter 1: Microeconomics. Covers consumer behaviour, production, costs, and market structures.`
      : isISCEconMacro
      ? `Chapter 2: Macroeconomics. Covers national income, determination of income, money, banking, and government budget.`
      : isSolutions
      ? `Chapter 1: Solutions (7 Marks). Covers Binary liquid mixtures, concentration expressions, Henry's Law, Raoult's law for volatile and non-volatile solutes, ideal/non-ideal solutions and deviations, colligative properties (relative lowering of vapour pressure, elevation of boiling point, depression of freezing point, osmotic pressure), molecular mass calculations, abnormal molar mass, and Van't Hoff factor (i).`
      : isElectrochemistry
      ? `Chapter 2: Electrochemistry (9 Marks). Covers Redox reactions, EMF of a cell, standard electrode potential, galvanic/electrolytic cells, Nernst equation and applications to chemical cells, relation between Gibbs energy change (ΔG) and EMF (E_cell), electrolytic conductance, specific and molar conductivity, Kohlrausch's Law, electrolysis laws, dry cells, lead accumulator, fuel cells, and corrosion.`
      : isChemicalKinetics
      ? `Chapter 3: Chemical Kinetics (7 Marks). Covers Rate of reaction (average and instantaneous), factors affecting rates (concentration, temperature, catalyst), rate law, order and molecularity, specific rate constant, integrated rate equations and half-life calculations for zero and first-order reactions, activation energy, Arrhenius equation, and qualitative collision theory.`
      : isDFBlock
      ? `Chapter 4: d- and f-Block Elements (7 Marks). Covers Transition metals (d-block) general properties, periodic trends, electronic configuration, oxidation states, metallic properties, heavy inorganic compounds (Potassium Dichromate K2Cr2O7 and Potassium Permanganate KMnO4), and inner transition metals (f-block) including lanthanoids and actinoids.`
      : isCoordinationCompounds
      ? `Chapter 5: Coordination Compounds (7 Marks). Covers Structural nomenclature, IUPAC rules, ligands, coordination sphere, isomerism configurations (structural and stereoisomerism), bonding theories (Werner's theory, Valence Bond Theory VBT, Crystal Field Theory CFT), and applications in qualitative analysis, metallurgy, and biological systems.`
      : isHaloalkanes
      ? `Chapter 6: Haloalkanes and Haloarenes (6 Marks). Covers Nomenclature, nature of C-X bond, physical and chemical properties, substitution reaction mechanisms (SN1, SN2) with stereochemical aspects, elimination reactions (Saytzeff rule), organometallic reactions, and environmental impacts of polyhalogen compounds.`
      : isAlcoholsPhenolsEthers
      ? `Chapter 7: Alcohols, Phenols and Ethers (6 Marks). Covers Preparation and physical/chemical properties of alcohols, phenols, and ethers, distinct tests like Lucas test and FeCl3 test, named reactions (Kolbe's, Reimer-Tiemann, dehydration), and Williamson synthesis of ethers.`
      : isAldehydesKetonesCarboxylic
      ? `Chapter 8: Aldehydes, Ketones and Carboxylic Acids (8 Marks). Covers Carbonyl group reactions and preparation, nucleophilic additions, named condensations (Aldol, Cross-Aldol, Cannizzaro), Clemmensen and Wolff-Kishner reductions, Tollens' and Fehling's tests, and carboxylic acid acidic strength and reactions.`
      : isAmines
      ? `Chapter 9: Amines (6 Marks). Covers Classifications (1°, 2°, 3°), nomenclature, Gabriel phthalimide and Hoffmann bromamide syntheses, basicity comparisons in gaseous and aqueous phases, Hinsberg's test, and diazonium salt preparation and synthetic replacement reactions.`
      : isBiomolecules
      ? `Chapter 10: Biomolecules (7 Marks). Covers Carbohydrates (aldoses/ketoses, cyclic D-glucose and D-fructose, oligosaccharides, polysaccharides), protein structures (primary to quaternary) and denaturation mechanisms, vitamins classification and deficiency diseases, hormones, and nucleic acids (DNA vs. RNA).`
      : isRationalIrrational9
      ? `Pure Arithmetic: Rational & Irrational Numbers. Covers terminating/repeating decimals, non-terminating non-repeating decimals, simplifying radicals/surds, rationalising the denominator, and real number density properties.`
      : isCompoundInterest9
      ? `Commercial Mathematics: Compound Interest. Covers step-by-step simple interest calculations, annual/semi-annual/quarterly compounding formulas, varying interest rates, dynamic principal/rate/time calculations, and population/depreciation applications.`
      : isExpansions9
      ? `Algebra: Expansions. Covers binomial square and cube expansions, trinomial expansions (a + b + c)², reciprocal identities (x ± 1/x)² & (x ± 1/x)³, and conditional identity deductions.`
      : isFactorisation9
      ? `Algebra: Factorisation. Covers taking out common factors, grouping terms, trinomial factoring (splitting middle term), difference of two squares, and sum/difference of two cubes.`
      : isSimultaneousEquations9
      ? `Algebra: Simultaneous Linear Equations. Covers elimination, substitution, cross-multiplication, equations reducible to linear form, and comprehensive word problems on ages, numbers, speed, and cost.`
      : isIndicesExponents9
      ? `Algebra: Indices and Exponents. Covers fundamental laws of indices, zero/negative/fractional exponents, simplifying radical/exponential expressions, and solving elementary exponential equations.`
      : isLogarithms9
      ? `Algebra: Logarithms. Covers definition (aˣ = b ⇔ logₐ b = x), product/quotient/power rules, change of base rule, common logarithms, and solving logarithmic equations.`
      : isTriangles9
      ? `Geometry: Triangles. Covers congruency criteria (SSS, SAS, ASA, RHS), CPCTC, isosceles triangle theorems, inequalities in triangles, and formal Euclidean deductive proofs.`
      : isMidpointIntercept9
      ? `Geometry: Mid-point and Intercept Theorems. Covers mid-point theorem and its converse, equal intercept theorem across parallel transversals, and applications to quadrilateral configurations.`
      : isRectilinearFigures9
      ? `Geometry: Rectilinear Figures. Covers angle sum property of polygons, properties of parallelograms, rectangles, rhombuses, squares, and trapeziums with rigorous geometric riders.`
      : isCircles9
      ? `Geometry: Circles. Covers chord properties, perpendicular from center bisecting chords, equal chords equidistant from center, angle subtended by arcs, and angles in the same segment.`
      : isAreaPlaneFigures9
      ? `Mensuration: Area of Plane Figures. Covers perimeter and area of triangles (including Heron's formula), quadrilaterals, circles, circular rings, sectors, segments, and combined figures.`
      : isSurfaceAreaVolume9
      ? `Mensuration: Surface Area and Volume of 3D Solids. Covers lateral/total surface area and volume of cubes, cuboids, right circular cylinders, hollow pipes, melting/recasting, and uniform flow problems.`
      : isCoordinateGeometry9
      ? `Coordinate Geometry: Cartesian System & Distance Formula. Covers plotting points in quadrants, equations of lines parallel to axes, distance formula derivation and applications, and midpoint calculations.`
      : isTrigRatios9
      ? `Trigonometry: Trigonometrical Ratios & Simple Identities. Covers six trigonometric ratios in right triangles, standard angles (0°, 30°, 45°, 60°, 90°), fundamental identities, and numerical evaluations.`
      : isStatistics9
      ? `Statistics: Data Representation & Measures of Central Tendency. Covers primary/secondary data, frequency distribution tables, histograms, frequency polygons, and calculating mean, median, and mode.`
      : isInternalAssessmentMath9
      ? `Paper II: Internal Assessment & Mathematical Projects (20 Marks). Covers project assignments on commercial mathematics, geometric tessellations, statistical surveys, class record work (10 marks), and viva-voce presentation (10 marks).`
      : isMeasurements9
      ? `Chapter 1: Measurements and Experimentation. Detailed ICSE Class 9 study of International System of Units (SI units and prefixes), Least Count of instruments, Vernier Callipers (Vernier constant, positive and negative zero errors), Micrometer Screw Gauge (pitch, least count, backlash error), and Measurement of Time using Simple Pendulum (oscillations, amplitude, frequency, time period T = 2π√(l/g), factors affecting T, experimental determination of 'g' using l vs T² linear graphs).`
      : isMotion1D9
      ? `Chapter 2: Motion in One Dimension. Comprehensive ICSE Class 9 curriculum covering Scalar and Vector quantities, Distance and Displacement, Uniform and non-uniform Speed and Velocity, Instantaneous speed, Acceleration and Retardation, Acceleration due to gravity (g), Graphical representation (s-t and v-t graphs, finding slope and area), and algebraic & graphical derivations of kinematic equations of motion (v = u + at, s = ut + ½at², v² = u² + 2as).`
      : isLawsOfMotion9
      ? `Chapter 3: Laws of Motion. Complete ICSE Class 9 treatment of Contact and Non-Contact forces, Newton's First Law and Inertia (rest, motion, direction with everyday demonstrations), Linear Momentum (p = mv) and Newton's Second Law (derivation of F = ma, SI units Newton and Dyne, gravitational units kgf/gf), Newton's Third Law (action-reaction pairs, gun recoil, rocket propulsion), Universal Law of Gravitation (F = G m₁m₂/r²), and acceleration due to gravity (g vs G, free fall, mass vs weight).`
      : isFluidsArchimedes9
      ? `Chapter 4: Fluids - Pressure in Fluids and Archimedes' Principle. Covers Thrust and Pressure, Liquid column pressure formula (P = hρg), Pascal's Principle and hydraulic machines (press, lift, brakes), Atmospheric Pressure (Torricelli's mercury barometer, Fortin's and Aneroid barometers, weather forecasting), Buoyancy & Archimedes' Principle (upthrust F_B = Vρg, apparent loss of weight), Principle of Floatation (W = F_B, submarine and ship buoyancy), and Relative Density determinations.`
      : isHeatEnergy9
      ? `Chapter 5: Heat and Energy. Covers Concepts of Heat vs Temperature (thermal energy, Joules, calories), Kinetic theory interpretation, Thermal expansion in solids/liquids/gases, Anomalous Expansion of Water (0°C to 4°C, Hope's experiment, aquatic life survival), Energy Sources (renewable solar/hydro/wind vs non-renewable fossil/nuclear), Principle of Conservation of Energy, energy degradation, Greenhouse Effect, and Global Warming mitigation.`
      : isLightReflection9
      ? `Chapter 6: Light - Reflection at Plane and Spherical Surfaces. Covers Laws of reflection at plane mirrors, Image characteristics (virtual, erect, lateral inversion, equidistant), Images by inclined plane mirrors (n = 360/θ - 1), Periscope and Kaleidoscope, Spherical mirror terminology (pole, centre of curvature, principal focus, focal length f = R/2), Ray tracing diagrams for concave & convex mirrors for all object positions, New Cartesian sign convention, Mirror Formula (1/f = 1/v + 1/u), and linear magnification.`
      : isSoundUltrasonic9
      ? `Chapter 7: Sound - Waves and Ultrasonic Applications. Covers Nature and propagation of sound as mechanical longitudinal waves (compressions and rarefactions, Bell jar medium requirement), Speed of sound in solids, liquids, and gases, Factors affecting speed (temperature, humidity, density, wind; independence of pressure/amplitude), Audible frequency range (20 Hz - 20 kHz), Infrasonic & Ultrasonic sound waves, and Ultrasound applications (SONAR echo ranging d = vt/2, medical imaging, bat echolocation, flaw detection).`
      : isElectricityMagnetism9
      ? `Chapter 8: Electricity and Magnetism. Covers Static Electricity (charges, electrostatic induction, Gold-leaf electroscope), Atmospheric Electricity (lightning and lightning conductors), Current Electricity fundamentals (current I = Q/t, potential difference V = W/Q), Simple electric circuits (switches, safety fuses, primary and secondary cells), and Magnetism (bar magnets, magnetic field lines, plotting using compass, neutral points B_mag = B_Earth, and electromagnets).`
      : isInternalAssessmentPhysics9
      ? `Chapter 9: Paper II - Internal Assessment & Practical Physics Lab Work (20 Marks). Complete guidance for ICSE Class 9 physics practicals: Vernier callipers & screw gauge dimension measurements, simple pendulum timing & l vs T² graph for determining 'g', reflection verification, focal length of concave mirror, density & relative density measurement via Archimedes' principle, tracing magnetic field lines & neutral points, and lab portfolio/viva-voce preparation.`
      : isLanguageOfChemistry9
      ? `Chapter 1: The Language of Chemistry. Detailed ICSE Class 9 curriculum covering Symbols of elements, Valency and combining capacity, Variable valency of transition metals (Fe²⁺/Fe³⁺, Cu⁺/Cu²⁺, Pb, Sn), Radicals (electropositive & electronegative ions), Writing chemical formulas using Criss-Cross method, Balancing chemical equations by hit-and-trial, Information conveyed & limitations of chemical equations, Relative Atomic Mass (A_r) and Relative Molecular Mass (M_r) based on Carbon-12 standard, Percentage Composition calculations, and chemical nomenclature.`
      : isChemicalChangesReactions9
      ? `Chapter 2: Chemical Changes and Reactions. Comprehensive ICSE Class 9 treatment of Types of Chemical Reactions (Direct combination / synthesis, Decomposition - thermal and electrolytic, Single displacement based on reactivity series, Double decomposition - precipitation and neutralization), Reversible vs Irreversible reactions, Thermal dissociation, Energy changes in chemical reactions (Exothermic ΔH < 0 vs Endothermic ΔH > 0), and Catalysis (positive catalysts, inhibitors, promoters, and industrial examples: Haber's process and Contact process).`
      : isWaterHydration9
      ? `Chapter 3: Water (Solutions, Hydration & Hardness). In-depth ICSE Class 9 study of Water as a universal solvent (high dielectric constant), Solutions (dilute, concentrated, saturated, supersaturated), Solubility & Solubility Curves (temperature/pressure effects, Henry's Law for gases), Crystallization & Water of Crystallization in hydrated salts, Efflorescence, Deliquescence, and Hygroscopic substances, Hard vs Soft water, Causes of temporary (bicarbonates) and permanent (chlorides/sulphates of Ca/Mg) hardness, and softening methods (boiling, Clark's process, washing soda, ion-exchange / Permutit process).`
      : isAtomicStructureBonding9
      ? `Chapter 4: Atomic Structure and Chemical Bonding. Complete ICSE Class 9 treatment of Subatomic Particles (electrons, protons, neutrons; Thomson and Rutherford models), Bohr's Atomic Model and energy shells (K, L, M, N), 2n² electron distribution rule (Z = 1 to 20), Atomic Number (Z) and Mass Number (A), Isotopes (fractional atomic masses) and Isobars, Electrovalent (Ionic) Bonding (electron transfer, lattice, properties), Ionic Electron-Dot Structures (NaCl, MgCl₂, CaO), Covalent Bonding (electron sharing, single/double/triple bonds, polar vs non-polar), and Covalent Electron-Dot Structures (H₂, O₂, N₂, H₂O, NH₃, CH₄).`
      : isPeriodicTableICSE9
      ? `Chapter 5: The Periodic Table & Periodic Properties. Detailed ICSE Class 9 historical and modern periodic classification: Dobereiner's Triads, Newlands' Law of Octaves and their limitations, Mendeleev's Periodic Law and table (achievements and anomalies), Modern Periodic Law (Moseley's atomic number basis), Modern Long Form Periodic Table (18 Groups, 7 Periods, Alkali metals, Alkaline earths, Halogens, Noble gases), Periodic Trends up to Calcium (Z = 1 to 20) including electronic configuration, periodicity in valency across periods and down groups, atomic radius, and metallic/non-metallic character transitions.`
      : isHydrogenStudy9
      ? `Chapter 6: Study of the First Element — Hydrogen. Comprehensive ICSE Class 9 study of the Dual Position of Hydrogen (resemblance with Group 1 alkali metals and Group 17 halogens), Laboratory preparation of hydrogen from granulated zinc and dilute acids (apparatus, collection, impurities removal), Industrial manufacture by the Bosch Process (water gas reaction and catalytic conversion with steam), Physical & Chemical properties (combustion, reaction with non-metals), Classical concepts of Oxidation and Reduction (addition/removal of O and H, reducing action of H₂ with CuO), and industrial uses & confirmatory pop-sound test.`
      : isGasLawsICSE9
      ? `Chapter 7: Study of Gas Laws (Boyle's & Charles' Law). Thorough ICSE Class 9 mathematical and kinetic molecular treatment of Measurable Gas Variables (Pressure, Volume, Absolute Temperature in Kelvin), Boyle's Law (V ∝ 1/P at constant T, P₁V₁ = P₂V₂ = k, isotherms and PV vs P graphs), Charles' Law (V ∝ T at constant P, V₁/T₁ = V₂/T₂, Absolute Zero -273°C / 0 K and linear graphs), Combined Gas Equation (P₁V₁/T₁ = P₂V₂/T₂), Standard Temperature and Pressure (STP / NTP conditions: 273 K, 760 mm Hg / 1 atm), and step-by-step ICSE numerical calculations.`
      : isAtmosphericPollution9
      ? `Chapter 8: Atmospheric Pollution. Covers Primary and secondary atmospheric pollutants (SO₂, NO₂, CO, particulates), Acid Rain (formation chemistry of H₂SO₄ and HNO₃, pH < 5.6, soil/water acidification, and marble cancer of monuments), Global Warming and Enhanced Greenhouse Effect (mechanism, greenhouse gases: CO₂, CH₄, N₂O, tropospheric ozone, CFCs, and climatic impacts), Ozone Layer Depletion (stratospheric O₃ Chapman cycle, catalytic destruction by CFC chlorine free radicals Cl•), effects of UV-B radiation, and global environmental protection protocols (Montreal Protocol).`
      : isInternalAssessmentChemistry9
      ? `Chapter 9: Paper II - Internal Assessment & Practical Chemistry Lab Experiments (20 Marks). Full practical guidelines for ICSE Class 9 chemistry: Action of heat on substances (CuCO₃, ZnCO₃, Pb(NO₃)₂, NH₄Cl), Flame tests for metal cations (Na⁺ golden yellow, K⁺ lilac, Ca²⁺ brick red), Identification and confirmatory tests for gases (H₂, O₂, CO₂, Cl₂, HCl, SO₂, H₂S, NO₂, NH₃), Preparation of saturated solutions and crystallization, Chemical reaction types & precipitate observations, and ICSE practical record book (10 marks) & viva-voce examination (10 marks).`
      : isBasicBiology9
      ? `Chapter 1: Basic Biology (The Cell & Tissues). Comprehensive ICSE Class 9 coverage of the Cell as the fundamental unit of life, Protoplasm, Plant vs Animal cell ultrastructure, Cell organelles and their metabolic functions (Cell wall, membrane, nucleus, mitochondria, chloroplasts, ribosomes, Golgi apparatus, ER, vacuoles, centrosomes, lysosomes), Prokaryotic vs Eukaryotic cells, Plant tissues (Meristematic - apical/lateral; Permanent - parenchyma, collenchyma, sclerenchyma, xylem, phloem), and Animal tissues (Epithelial, Connective - areolar, adipose, bone, cartilage, blood; Muscular - striated, unstriated, cardiac; Nervous tissue - neurons).`
      : isFloweringPlants9
      ? `Chapter 2: Flowering Plants. In-depth ICSE Class 9 treatment of Vegetative morphology (root, stem, leaf venation, fruit structure), Anatomy of a bisexual flower (calyx, corolla, androecium, gynoecium/pistil), Floral types, inflorescence and placentation, Pollination mechanisms (self vs cross-pollination, contrivances, wind/water/insect agents), Fertilization in angiosperms (pollen tube growth, double fertilization and triple fusion), Structure of monocot (maize) and dicot (bean) seeds, Types of seed germination (epigeal vs hypogeal), and Experimental verification of necessary conditions (three-bean experiment).`
      : isHumanAnatomyPhysiology9
      ? `Chapter 3: Human Anatomy and Physiology. Detailed ICSE Class 9 study of Nutrition and balanced diet (macronutrients, vitamins, minerals, roughage, PEM syndromes: Kwashiorkor and Marasmus), Anatomy of the human digestive system and associated glands (teeth, stomach, liver, pancreas, intestines), Mechanism of digestion, enzyme action, absorption and assimilation, Skeletal system (axial and appendicular skeleton, bone/cartilage, joints, ligaments, tendons), Human skin (epidermal layers, dermis, sweat/sebaceous glands, functions, and thermoregulation), and Respiratory system (anatomy of airway and alveoli, breathing mechanics, aerobic vs anaerobic respiration, gas transport, and respiratory disorders).`
      : isHealthHygiene9
      ? `Chapter 4: Health and Hygiene. Comprehensive ICSE Class 9 coverage of Health, hygiene and disease classification, Communicable vs non-communicable diseases, Infectious bacterial diseases (Tuberculosis, Typhoid, Cholera), viral diseases (Common Cold, AIDS, Chickenpox, Hepatitis), protozoan diseases (Malaria, Amoebic dysentery), and fungal infections (Ringworm), Immunity mechanisms (innate vs acquired, active vs passive), Vaccination schedules for infants (BCG, DPT, OPV, MMR), and Emergency first aid protocols for fractures, burns, haemorrhage, and snake bites.`
      : isWasteManagement9
      ? `Chapter 5: Waste Generation and Management. Detailed ICSE Class 9 study of Waste categories (biodegradable vs non-biodegradable), Sources of waste accumulation (domestic, industrial, agricultural, biomedical), Environmental and health impacts of improper disposal (bioaccumulation, toxic gas emission, water eutrophication, vectors), Safe waste disposal methods (segregation, sanitary landfills, composting, vermicomposting, incineration), and Waste minimization strategies (The 3 Rs: Reduce, Reuse, Recycle, circular economy).`
      : isInternalAssessmentBiology9
      ? `Chapter 6: Paper II - Internal Assessment & Practical Biology Lab Work (20 Marks). Full practical guidelines for ICSE Class 9 Biology: Microscopic examination of temporary mounts (onion peel and human cheek epithelial cells), Biochemical food tests (starch, reducing sugars, proteins, lipids), Seed germination physiological experiments (three-bean setup, respiration setups), Flower dissection and floral parts mounting, Specimen spotting of tissue slides, bones and organ models, and Practical record book (10 marks) & viva-voce examination (10 marks).`
      : isOOPConcepts9
      ? `Chapter 1: Introduction to Object-Oriented Programming Concepts. Complete ICSE Class 9 foundational study of OOP principles, comparison between Procedure-Oriented Programming (POP) and Object-Oriented Programming (OOP), the four core OOP pillars (Data Abstraction, Encapsulation, Inheritance, and Polymorphism), real-world software modeling, modularity, code reusability, maintainability, and data security benefits.`
      : isObjectsClasses9
      ? `Chapter 2: Elementary Concept of Objects and Classes. Detailed ICSE Class 9 study of Objects as real-world entities having state (attributes/characteristics) and behavior (methods/actions), Classes as blueprints, templates, and user-defined data types, class as an object factory, and object lifecycle including instantiation via 'new' operator, memory allocation, and member method invocation.`
      : isValuesDataTypes9
      ? `Chapter 3: Values and Data Types. Thorough ICSE Class 9 coverage of Unicode character encoding, Java tokens (Keywords, Identifiers, Literals of all data types, Punctuators/Separators, Operators), Primitive data types (byte, short, int, long, float, double, char, boolean with sizes and ranges), Reference types vs Primitive types, variable declarations, constants using 'final', and Implicit vs Explicit type conversions (type casting rules, precision loss, and truncation).`
      : isOperatorsJava9
      ? `Chapter 4: Operators in Java. Comprehensive ICSE Class 9 coverage of Arithmetic (+, -, *, /, %), Relational (<, <=, >, >=, ==, !=), Logical (&&, ||, ! with short-circuit evaluation), Assignment (=, +=, -=, *=, /=, %=), Unary (+, -, ++, --), Prefix vs Postfix increment/decrement step evaluations, Ternary conditional operator (? :), and operator precedence, associativity rules, and parenthetical overrides.`
      : isInputJava9
      ? `Chapter 5: Input in Java. In-depth ICSE Class 9 treatment of Initialization vs Dynamic keyboard input at runtime, java.util.Scanner class implementation (System.in, next(), nextLine(), nextInt(), nextDouble(), etc.), resolving input buffer anomalies, handling InputMismatchException, and categorizing program errors (Syntax errors, Runtime exceptions, and Logical bugs).`
      : isMathLibraryJava9
      ? `Chapter 6: Mathematical Library Methods. Detailed ICSE Class 9 study of java.lang.Math library functions including Math.sin(), cos(), tan(), asin(), acos(), atan(), pow(), sqrt(), cbrt(), log(), abs(), ceil(), floor(), round(), min(), max(), and random(), mathematical constants (Math.PI and Math.E), and translating standard algebraic and quadratic formulas into syntactically valid Java statements.`
      : isConditionalConstructs9
      ? `Chapter 7: Conditional Constructs in Java. Comprehensive ICSE Class 9 coverage of Decision-making constructs: simple if, if-else, nested if-else, multi-way branching with if-else-if ladder, Switch-case statements (syntax, break statement to prevent fall-through, default label, valid selector types), comparison between switch and if-else-if, dangling else resolution, and program termination using System.exit(0).`
      : isIterativeConstructs9
      ? `Chapter 8: Iterative Constructs in Java. Thorough ICSE Class 9 coverage of Looping constructs (for, while, do-while loops), entry-controlled vs exit-controlled evaluation, jump statements (break and continue), nested loops for 2D coordinate patterns (number grids, triangles, Floyd's triangle), avoiding infinite loops, and classic number algorithms (digit extraction, sum/product of digits, reverse, Prime, Armstrong, Palindrome, Perfect, Automorphic, Neon, and Special numbers).`
      : isInternalAssessmentCS9
      ? `Chapter 9: Paper II - Internal Assessment & Practical Lab Work (100 Marks). Complete ICSE Class 9 practical curriculum: designing, writing, compiling, and executing a minimum of 15-20 Java programs in BlueJ / Eclipse across formula evaluation, menu-driven switch-case programs, number property checks, pattern printing, and character operations, along with Logbook documentation (10 marks) and Viva-voce oral defense (10 marks).`
      : isConstitution9
      ? `Chapter 1: Civics - Our Constitution. In-depth ICSE Class 9 coverage of the definition and historical drafting of the Constitution, dates of adoption (26th Nov 1949) and enforcement (26th Jan 1950), Preamble philosophy, Single citizenship, Universal Adult Franchise, concept of a Welfare State, Fundamental Rights (Equality, Freedom, Against Exploitation, Religion, Culture/Education, Constitutional Remedies via Writs), Fundamental Duties (Article 51A), and Directive Principles of State Policy (DPSP classifications and judicial distinction from Fundamental Rights).`
      : isElections9
      ? `Chapter 2: Civics - Elections. Comprehensive ICSE Class 9 study of the electoral mechanism, purpose of elections in representative democracy, the secret ballot principle, composition, tenure, independence, and powers of the Election Commission of India, preparation of electoral rolls and Model Code of Conduct, Direct vs Indirect election systems, and definitions of General Elections, Mid-term Elections, and By-elections.`
      : isLocalSelfGov9
      ? `Chapter 3: Civics - Local Self-Government. Detailed ICSE Class 9 study of democratic decentralization through the 73rd and 74th Constitutional Amendment Acts: Three-tier Panchayati Raj system (Gram Panchayat, Gram Sabha, Nyaya Panchayat, Panchayat Samiti, and Zila Parishad) and Urban local bodies (Municipal Corporations, Mayor, Municipal Commissioner vs Municipal Committees, revenue sources, and municipal civic responsibilities).`
      : isAncientIndia9
      ? `Chapter 4: History - Ancient India & Civilisations. Exhaustive ICSE Class 9 historical study of the Harappan Civilisation (sources, urban planning, Great Bath, seals, crafts, trade, and decline), the Vedic Period (Early vs Later Vedic society, Epics, caste system, and economy), 6th Century BCE religious movements (Mahavira, Jainism, Buddha, Four Noble Truths, Eightfold Path), the Mauryan Empire (Arthashastra, Indica, Ashokan Edicts, Kalinga War, and Dhamma administration), the Sangam Age (Tirukkural, society), and the Gupta Golden Age (sources, Samudragupta, Chandragupta II, science, and classical art).`
      : isMedievalIndia9
      ? `Chapter 5: History - Medieval India & Cultural Shifts. Detailed ICSE Class 9 coverage of the Cholas (Brihadeeswara Temple, local self-government, village assemblies, and bronze art), the Delhi Sultanate (monumental sources, Slave Dynasty, Alauddin Khalji's military and market reforms, and Muhammad bin Tughlaq's policies), the Mughal Empire (Ain-i-Akbari, monuments, Akbar's Mansabdari and Land Revenue Zabt system, Sulh-i-Kul, and Din-i-Ilahi), and cultural integration via the Bhakti Movement, Sufism, and the advent of Christianity.`
      : isModernAgeEurope9
      ? `Chapter 6: History - Modern Age in Europe. Comprehensive ICSE Class 9 analysis of the Renaissance (causes, fall of Constantinople, humanism, transformations in art, literature, and science), the Reformation (causes, Martin Luther, 95 Theses, Protestantism, and Catholic Counter-Reformation by the Jesuits), and the Industrial Revolution (causes in Britain, major mechanical inventions, growth of capitalism, urbanization, factory system, and social impact).`
      : isGeographicalSkills9
      ? `Chapter 7: Geography - Geographical Skills & World Map Work (10 Marks Compulsory). Master localization of key geographical features on an outline world map: Major Oceans (Pacific, Atlantic, Indian, Arctic, Southern), Seas (Caribbean, Mediterranean, Red, Black, Baltic, Arabian, South China Sea), Gulfs, Bays, Straits, major Mountain Ranges (Himalayas, Rockies, Andes, Alps, Urals, Great Dividing Range), Plateaus (Tibetan, Colorado, Deccan, Brazilian), and global River Systems (Amazon, Nile, Mississippi, Yangtze, Ganges, Danube, Congo, Rhine, Indus).`
      : isPhysicalGeography9
      ? `Chapter 8: Geography - Physical Earth & Landforms. Detailed ICSE Class 9 study of Earth as an oblate spheroid (geoid), proofs of spherical shape, Geographic Grid (Latitudes, Longitudes, Time zones, GMT, Local time and Standard time calculations, International Date Line), Earth movements (Rotation, Coriolis force, Revolution, inclination of axis at 66.5°, equinoxes, solstices, seasons), Internal structure (Crust, Mantle, Core, Mohorovicic and Gutenberg discontinuities), and dynamic landforms (Plate tectonics, volcanism, earthquake focus/epicenter/waves, weathering, denudation, and mass wasting).`
      : isAtmosphereHydrosphere9
      ? `Chapter 9: Geography - Atmosphere & Hydrosphere. Comprehensive ICSE Class 9 study of Atmospheric structure (Troposphere to Exosphere, lapse rate), Solar insolation and heat balance, Global pressure belts and wind systems (Planetary winds, Monsoons, Local winds, Cyclones/Anticyclones), Atmospheric humidity and precipitation types (Convectional, Orographic, Cyclonic), and the Hydrosphere (Ocean currents of Atlantic, Pacific, and Indian Oceans, effects on climate/fisheries, and Spring vs Neap ocean tides).`
      : isEnvironmentNaturalRegions9
      ? `Chapter 10: Geography - Environment & Natural Regions. In-depth ICSE Class 9 coverage of World Natural Regions (Equatorial, Savanna, Deserts, Monsoon, Mediterranean, Steppes, Taiga, Tundra climate, flora, fauna, and human life), Environmental pollution (Air, Water, Soil, Radiation), Global environmental crises (Global warming, Ozone depletion, Acid rain, Desertification), and Sustainable conservation strategies (The 3 Rs: Reduce, Reuse, Recycle, afforestation, water harvesting).`
      : isInternalAssessmentSocialScience9
      ? `Chapter 11: Paper I & II - Internal Assessment & Practical Work (20 Marks Each). Complete guidelines for ICSE Class 9 continuous internal evaluation: Paper I History/Civics project work (historical monuments, local self-governing bodies survey, mock elections) with project file (10 marks) and viva-voce (10 marks); Paper II Geography practical assessment (field surveys, meteorological recording logbook, local environmental issues, map work) with project file (10 marks) and viva-voce examination (10 marks).`
      : isBasicConceptsChem11
      ? `Unit 1: Some Basic Concepts of Chemistry. Comprehensive ICSE Class 11 theory covering Matter and its nature, Laws of chemical combination, Stoichiometry Math (Atomic, molecular, and equivalent masses, Mole concept, Avogadro's number, Empirical and molecular formula, Limiting reagents), and Solution Concentrations (Mass %, Volume %, ppm, Mole fraction, Molarity M, and Molality m).`
      : isStructureOfAtom11
      ? `Unit 2: Structure of Atom. Covers Discovery of fundamental subatomic particles, Thomson/Rutherford/Bohr atomic models, de Broglie dual nature, Heisenberg's Uncertainty Principle, Quantum numbers (n, l, m, s), Orbital shapes (s, p, d), Electronic filling rules (Aufbau, Pauli exclusion, Hund's rule), and electronic configurations up to Z=36 with anomalies of Cr and Cu.`
      : isClassificationElements11
      ? `Unit 3: Classification of Elements and Periodicity in Properties. Modern Periodic Law, long-form periodic table, Nomenclature of elements Z>100, and periodic trends (Atomic/ionic radii, Ionisation Enthalpy, Electron Gain Enthalpy, Electronegativity, Valency, and second-period anomalies).`
      : isChemicalBonding11
      ? `Unit 4: Chemical Bonding and Molecular Structure. Valence electrons, Lewis structures, Formal charge, VSEPR Theory (geometry of H₂O, NH₃, CH₄, PCl₅, SF₆), Hybridisation (sp to sp³d²), Molecular Orbital Theory (homonuclear diatomics, bond order, magnetic character), and Hydrogen bonding.`
      : isChemicalThermodynamics11
      ? `Unit 5: Chemical Thermodynamics. System/surroundings, State/path functions, First Law of Thermodynamics (ΔU = q + w), Enthalpy (ΔH), Heat capacity, Hess's Law, Enthalpies of reactions, Second Law, Entropy (ΔS), Gibbs Free Energy (ΔG) spontaneity criteria, and Third Law introduction.`
      : isEquilibrium11
      ? `Unit 6: Equilibrium. Dynamic equilibrium, Law of Mass Action, Kp and Kc interrelation (Kp = Kc(RT)^Δn), Le Chatelier's Principle, Theories of Acids and Bases (Arrhenius, Bronsted, Lewis), Ostwald's Dilution Law, Kw, pH scale, Common ion effect, Buffer solutions, and Solubility product (Ksp).`
      : isRedoxReactions11
      ? `Unit 7: Redox Reactions. Classical and modern concepts of oxidation and reduction, Oxidation number assignment rules, Balancing redox equations via Ion-Electron and Oxidation Number methods, and reaction types.`
      : isInorganicSPBlock11
      ? `Unit 8: Inorganic Chemistry: Classification of Elements (s-Block & p-Block). Group 1 & Group 2 alkali and alkaline earth metals trends (reactivity, hydration, anomalous Li and Be, diagonal relations), and Group 13 & Group 14 boron and carbon families (inert pair effect, allotropes of carbon).`
      : isOrganicHydrocarbons11
      ? `Unit 9: Organic Chemistry: Some Basic Principles, Techniques, and Hydrocarbons. IUPAC nomenclature, Structural and stereoisomerism, Reaction intermediates and mechanisms (inductive, electromeric, resonance, hyperconjugation), Alkanes (conformations, halogenation), Alkenes (Markovnikov & anti-Markovnikov additions, ozonolysis), Alkynes (acidity, hydration), and Aromatic hydrocarbons (benzene resonance, Huckel rule, electrophilic substitution).`
      : isPracticalChemistry11
      ? `Paper II: Practical Work & Project (30 Marks). Quantitative volumetric analysis (acid-base and redox KMnO₄ titrations - 10 marks), Qualitative inorganic salt analysis for cations and anions (10 marks), and Scientific research project file and viva-voce examination (10 marks).`
      : isPhysicalWorldMeasurement11
      ? `Unit 1: Physical World and Measurement. SI units, fundamental and derived units, dimensional analysis and applications to formula derivation, significant figures, least count, error analysis, and combination/propagation of errors.`
      : isKinematics11
      ? `Unit 2: Kinematics. Motion in a straight line, calculus derivations of kinematic equations, relative velocity, motion in a plane, scalar and vector products, projectile motion trajectory equations, and uniform circular motion with centripetal acceleration.`
      : isLawsOfMotion11
      ? `Unit 3: Laws of Motion. Newton's laws of motion, momentum conservation, impulse-momentum theorem, equilibrium of concurrent forces, static/kinetic/rolling friction, and circular motion dynamics on banked roads.`
      : isWorkEnergyPower11
      ? `Unit 4: Work, Energy, and Power. Work done by constant and variable forces, work-energy theorem, spring potential energy, conservative vs non-conservative forces, conservation of mechanical energy, and elastic/inelastic collisions in 1D and 2D.`
      : isSystemParticlesRigidBody11
      ? `Unit 5: Motion of System of Particles and Rigid Body. Centre of mass of two-particle and rigid systems, torque, conservation of angular momentum, rotational equilibrium, moment of inertia, radius of gyration, and parallel/perpendicular axes theorems.`
      : isGravitation11
      ? `Unit 6: Gravitation. Kepler's laws of planetary motion, universal gravitation, variation of 'g' with altitude, depth, and latitude, gravitational potential energy, escape velocity, and orbital velocity of geostationary satellites.`
      : isPropertiesBulkMatter11
      ? `Unit 7: Properties of Bulk Matter. Stress-strain relationships, Hooke's law, elastic moduli, Pascal's law, fluid viscosity, Stokes' law, terminal velocity, Bernoulli's theorem, surface tension, and capillary rise.`
      : isThermodynamicsPhysics11
      ? `Unit 8: Heat and Thermodynamics. Thermal expansion, specific heat capacity, calorimetry, latent heat, heat transfer modes, Zeroth/First/Second laws of thermodynamics, isothermal and adiabatic processes, and heat engine/refrigerator efficiency.`
      : isKineticTheoryGases11
      ? `Unit 9: Behaviour of Perfect Gases and Kinetic Theory of Gases. Gas laws, kinetic theory assumptions, kinetic interpretation of temperature, RMS speed of gas molecules, degrees of freedom, law of equipartition of energy, and molar specific heats Cp and Cv.`
      : isOscillationsWaves11
      ? `Unit 10: Oscillations and Waves. Periodic and simple harmonic motion (SHM), simple pendulum derivation, energy in SHM, free/forced/damped oscillations, resonance, wave motion, standing waves in strings/organ pipes, and beats.`
      : isPracticalPhysics11
      ? `Paper II: Practical Work & Project (30 Marks). Section A laboratory experiments (Vernier callipers, screw gauge, simple pendulum, Boyle's law, surface tension - 15 marks), Section B project work (10 marks), and Section C practical file and viva-voce (5 marks).`
      : isDiversityLivingOrganisms11
      ? `Unit 1: Diversity of Living Organisms. The Living World, biodiversity, taxonomy and hierarchy, binomial nomenclature, five-kingdom classification (Monera, Protista, Fungi, lichens, viruses), and distinguishing features of Plant and Animal kingdoms.`
      : isStructuralOrganisation11
      ? `Unit 2: Structural Organisation in Animals and Plants. Anatomy and functions of tissue systems in dicot and monocot roots, stems, and leaves; secondary growth mechanisms; and complete morphology and organ systems of an insect (Cockroach).`
      : isCellStructureFunction11
      ? `Unit 3: Cell: Structure and Function. Ultrastructure of prokaryotic and eukaryotic cells, endomembrane system, cell organelles, biomolecules (proteins, carbohydrates, lipids, nucleic acids, enzyme kinetics), and cell cycle stages (Mitosis and Meiosis).`
      : isPlantPhysiology11
      ? `Unit 4: Plant Physiology. Photosynthesis in higher plants (light/dark reactions, cyclic/non-cyclic photophosphorylation, C3 and C4 pathways), cellular respiration (glycolysis, Krebs cycle, ETS, ATP accounting), and plant growth regulators (Auxin, Gibberellin, Cytokinin, Ethylene, ABA).`
      : isHumanPhysiology11
      ? `Unit 5: Human Physiology. Breathing and gas exchange, circulatory system and cardiac cycle, excretory system and nephron counter-current mechanism, locomotion and muscle sliding filament theory, neural control and impulse conduction, and endocrine chemical coordination.`
      : isPracticalBiology11
      ? `Paper II: Practical Work & Project (30 Marks). Section A laboratory temporary slide preparation and physiology experiments (15 marks), Section B biological research project (10 marks), and Section C practical journal and viva-voce examination (5 marks).`
      : isDataRepBooleanAlg11
      ? `Unit 1: Data Representation and Boolean Algebra. Base system conversions (Binary, Octal, Decimal, Hexadecimal), signed integers (Sign-Magnitude, 1's & 2's Complement), binary arithmetic, ASCII/ISCII/Unicode, Boolean algebra, truth tables, logic gates, algebraic laws, De Morgan's laws, SOP/POS canonical forms, and Karnaugh Maps (K-Maps up to 3 variables).`
      : isHardwareArchitecture11
      ? `Unit 2: Computer Hardware and Basic Architecture. Combinational logic circuits, Half Adder and Full Adder, Decoder, Encoder, Multiplexer (MUX), Demultiplexer (DEMUX), sequential circuits, basic SR, JK, D flip-flops, registers, and counters.`
      : isJavaOOPConcepts11
      ? `Unit 3: Introduction to Java and OOP Concepts. Principles of Object-Oriented Programming (Abstraction, Encapsulation, Inheritance, Polymorphism), JVM compilation and execution model, bytecode, JIT compiler, keywords, tokens, primitive/reference data types, operators, and explicit typecasting.`
      : isControlStructuresFunctions11
      ? `Unit 4: Control Structures and Function Design. Decision making (if, if-else, switch-case), iteration loops (for, while, do-while), jump statements (break, continue), method signatures, Call by Value vs Call by Reference, pure/impure functions, and variable scope.`
      : isArraysStrings11
      ? `Unit 5: Primitive Data Structures: Arrays and Strings. 1D array indexing, Linear/Binary Search, Bubble/Selection Sort, 2D arrays, Row-Major and Column-Major memory layouts, String and StringBuffer classes, and character manipulation.`
      : isAdvancedOOPFeatures11
      ? `Unit 6: Advanced Object-Oriented Programming Features. Class definitions, instance/static variables, member methods, this keyword, default/parameterized/copy constructors, constructor overloading, access specifiers (private, protected, public, default), static methods, and garbage collection.`
      : isPracticalWorkCS11
      ? `Paper II: Practical Work & Laboratory Assessment (30 Marks). Machine-based Java algorithmic problem execution (15 marks), algorithm design and variable description table (5 marks), year-long laboratory journal with 20-25 programs (5 marks), and viva-voce examination (5 marks).`
      : isGrowthOfNationalism11
      ? `Section A: Growth of Nationalism (Late 19th Century). Factors shaping nationalist sentiment including Western education, vernacular press, British economic policies, racial discrimination, pre-INC political associations in Bengal, Bombay, and Madras, and the foundation of the Indian National Congress (1885) under A.O. Hume with Early Nationalist (Moderate) constitutional methods.`
      : isEmergenceOfRadicals11
      ? `Section A: Emergence of the Radicals & Swadeshi Movement. Causes for assertive nationalism, Lal-Bal-Pal and Aurobindo Ghosh, Lord Curzon's Partition of Bengal (1905), anti-partition agitation mechanisms, Swadeshi and Boycott, national education schemes, economic impacts, and the Surat Split (1907).`
      : isWWINationalistPolitics11
      ? `Section A: First World War and Nationalist Politics (1914–1918). Outbreak of the Ghadar Movement in North America and Komagata Maru incident, dual Home Rule Leagues led by Tilak and Annie Besant, and the Lucknow Pact (1916) reuniting Moderates, Radicals, and Congress-League unity.`
      : isGandhianEra11
      ? `Section A: The Gandhian Era (Mass Nationalism 1919–1935). Satyagraha philosophy, Champaran, Kheda, Ahmedabad, Rowlatt Act, Jallianwala Bagh Massacre, Khilafat and Non-Cooperation Movements, Chauri Chaura, Civil Disobedience Movement, Dandi March, Simon Commission, Nehru Report, Purna Swaraj, Round Table Conferences, Swaraj Party, revolutionary nationalism (HSRA, Bhagat Singh, Surya Sen), and socialist visions (Nehru & Bose).`
      : isImpactWWIPeaceSettlements11
      ? `Section B: Impact of the First World War and the Peace Settlements. Paris Peace Conference (1919), aims of the Big Three (Wilson, Lloyd George, Clemenceau), Woodrow Wilson's Fourteen Points, detailed analysis of the Treaty of Versailles (territorial redraws, military restrictions, war guilt clause), and brief survey of St. Germain, Trianon, Neuilly, and Sèvres/Lausanne.`
      : isGreatDepressionTotalitarianism11
      ? `Section B: The Great Depression and the Rise of Totalitarianism. 1929 Wall Street Crash causes and global economic impacts, post-war crisis in Italy, rise of Benito Mussolini, Fascist ideology, March on Rome, domestic/foreign policies, Weimar Republic vulnerabilities, rise of Adolf Hitler, Nazi ideology, totalitarian consolidation in the Third Reich, and aggressive foreign policy.`
      : isWWIICollapseCollectiveSecurity11
      ? `Section B: World War II and the Collapse of Collective Security. Structural flaws of the League of Nations, Manchuria and Abyssinia crises, Hitler's expansionist milestones (Rhineland, Anschluss, Munich Pact, Sudetenland), Anglo-French Policy of Appeasement, Nazi-Soviet Pact, and the 1939 invasion of Poland.`
      : isRiseOfCommunismChina11
      ? `Section B: Rise of Communism in China (1911–1949). The 1911 Revolution and collapse of the Qing Dynasty, Sun Yat-sen and Kuomintang (KMT) Principles, KMT-CCP alliance, Chiang Kai-shek's Shanghai Massacre purge, Mao Zedong's leadership, the 1934–35 Long March, peasant mobilization, impact of Second Sino-Japanese War, and the 1949 Communist victory.`
      : isProjectWorkHistory11
      ? `Paper II: Project Work & Historical Research Essay (20 Marks). Independent 2000-word historical research essay on approved themes (e.g., Swadeshi Movement, Fascist Italy, Versailles Treaty), evaluated via Project File & Research Quality (10 Marks Internal) and Viva-Voce Examination (10 Marks External).`
      : isEarthStructureEndogenetic11
      ? `Section A (Physical Geography - 35 Marks): Structure of the Earth and Endogenetic Processes. Internal zoning (Core, mantle, crust), temperature/pressure/density gradients, seismic wave evidence, Wegener's Continental Drift theory vs Modern Plate Tectonics (convergent, divergent, transform boundaries), folding/faulting (fold mountains, rift valleys), volcanism (intrusive/extrusive landforms), and earthquake mechanisms (Richter/Mercalli, tsunamis).`
      : isExogeneticLandforms11
      ? `Section A (Physical Geography - 35 Marks): Exogenetic Processes and Landform Development. Mechanical, chemical, biological weathering, mass wasting (landslides, mudflow, soil creep), and erosional/depositional landforms formed by running water, wind, and glaciers (waterfalls, meanders, floodplains, sand dunes, loess, moraines, U-shaped & hanging valleys).`
      : isAtmosphereHydrosphere11
      ? `Section A (Physical Geography - 35 Marks): Atmosphere and Hydrosphere. Thermal structure of atmospheric layers (troposphere to exosphere), insolation & Earth's heat budget, global pressure belts, planetary/monsoon/local winds, tropical/temperate cyclones, submarine relief (continental shelf/slope/abyssal plains/trenches), ocean salinity/temperature, ocean currents (Atlantic, Pacific, Indian), and spring/neap tide mechanics.`
      : isPopulationSettlements11
      ? `Section B (Principles of Human Geography - 15 Marks): Population Dynamics and Human Settlements. World population growth and density, overpopulation/underpopulation/optimum population concepts, Demographic Transition Model phases, rural settlement classifications (linear, radial, nucleated, dispersed), urbanization trends, town functions, and urban infrastructure issues (slums, congestion).`
      : isPhysicalFrameworkIndia11
      ? `Section C (Geography of India - 20 Marks): Physical Framework and Climate of India. Physiographic regions (Northern Mountains, Great Plains, Peninsular Plateau, Coastal Plains, Islands), comparative drainage of Himalayan vs Peninsular rivers, classical vs jet stream monsoon mechanisms, seasons, rainfall spatial distribution, and flood/drought management.`
      : isResourcesEnvironmentIndia11
      ? `Section C (Geography of India - 20 Marks): Resource Base and Environmental Issues. Forest types and spatial distribution in India, soil classification (Alluvial, Black, Red, Laterite), soil erosion factors and conservation strategies, and natural disaster management (cloudbursts, landslides, earthquakes, cyclones).`
      : isPracticalGeography11
      ? `Paper II: Practical Work & Field Project (30 Marks). Cartographic visualization (line graphs, bar diagrams, pie charts, age-sex pyramids), map projections (Cylindrical Equal-Area, Conical with one standard parallel, Zenithal Equidistant), Survey of India topographical sheet analysis (grid maps, scale, gradient, contours, drainage, land use - 15 marks), 20-25 page field survey project report (10 marks), and practical log & viva-voce (5 marks).`
      : isIntroPolScience11
      ? `Section A (Political Theory - 40 Marks): Introduction to Political Science & Theory of State. Scope and nature of Political Science; evolution from traditional philosophical study to modern behavioral and empirical discipline; state definition and core elements (population, territory, government, sovereignty); distinctions between state/government/nation/society; critical analysis of Social Contract Theory (Hobbes, Locke, Rousseau) and Evolutionary/Historical Theory.`
      : isFundamentalPolConcepts11
      ? `Section A (Political Theory - 40 Marks): Fundamental Political Concepts. Sovereignty (titular, real, legal, political, popular; John Austin's monistic vs. pluralistic theory); Law (definition, sources: custom, judicial decisions, legislation; Law & Liberty relationship); Liberty, Equality, Justice (negative vs positive liberty, legal/political/social/economic dimensions, distributive justice).`
      : isFormsOfGovt11
      ? `Section B (Contemporary Constitutional Systems - 40 Marks): Forms of Government. Unitary vs. Federal systems (features, merits, demerits - UK & US case studies); Parliamentary vs. Presidential systems (executive-legislative coordination, collective responsibility, fixed tenure, Prime Minister vs President role - UK, US, India).`
      : isConstitutionsStructures11
      ? `Section B (Contemporary Constitutional Systems - 40 Marks): Constitutions and Organic Structures. Written vs unwritten, rigid vs flexible constitutions; Legislature (unicameralism vs bicameralism); Executive (nominal/real, single/plural, political/permanent); Judiciary (judicial independence, core functions, Judicial Review significance & safeguards).`
      : isFranchiseRepresentation11
      ? `Section B (Contemporary Constitutional Systems - 40 Marks): Franchise, Representation, Political Parties & Pressure Groups. Universal Adult Franchise; minority representation systems (proportional, cumulative, plural voting); Political Parties (functions, one-party, two-party, multi-party systems); Pressure Groups (techniques, policy influence, party distinctions).`
      : isProjectWorkPolScience11
      ? `Paper II: Project Work & Comparative Political Analysis (20 Marks). Independent 2000-word analytical research essay on approved themes (e.g., US President vs UK Prime Minister powers, Multi-Party vs Two-Party working, Pressure Groups in Indian public policy); evaluated via Project File (10 Marks Internal) and Viva-Voce Presentation (10 Marks External Board Examination).`
      : isOriginDevSociology11
      ? `Unit 1: Origin and Development of Sociology and Anthropology (70 Marks Theory). Historical contexts of emergence (Enlightenment, Industrial Revolution, French Revolution); classical foundational theorists: Auguste Comte (Positivism), Herbert Spencer (Social Darwinism), Émile Durkheim (Structural Functionalism, Social Facts), Max Weber (Interpretive Sociology, Social Action), Karl Marx (Conflict Theory, Class Struggle); interrelationships with Political Science, Economics, and Anthropology.`
      : isResearchMethodologySociology11
      ? `Unit 2: Research Methodology in Sociology (70 Marks Theory). Scientific foundations of sociological inquiry, objectivity, step-by-step procedures from problem identification to hypothesis building; comparative, historical, and case study methods; tools of data collection: questionnaires, schedules, interviews (structured/unstructured), participant and non-participant observation.`
      : isBasicConceptsSociology11
      ? `Unit 3: Basic Concepts (70 Marks Theory). Characteristics of society, rural vs. urban social structures; socialization mechanisms, primary and secondary agencies (Family, Peer group, School, Media), Charles Horton Cooley's Looking-Glass Self theory; material vs. non-material culture, William F. Ogburn's cultural lag, ethnocentrism, cultural diffusion and assimilation.`
      : isSocialStructureSociology11
      ? `Unit 4: Social Structure (70 Marks Theory). Social groups: primary, secondary, in-out, reference groups; Status and role dynamics: ascribed vs. achieved status, role conflict, role strain, role stereotyping; Social processes: associative (co-operation, accommodation, assimilation) and dissociative (competition, conflict).`
      : isSocialProblemsSociology11
      ? `Unit 5: Social Problems and Deviance (70 Marks Theory). Socio-demographic challenges: overpopulation, poverty (absolute vs relative, vicious cycle), unemployment; social deviance and vulnerabilities: child labour causes and legislation, juvenile delinquency and reformatories, challenges of vulnerable groups (elderly, disabled, unorganized sector workers).`
      : isIndianSociologists11
      ? `Unit 6: Indian Sociologists (70 Marks Theory). Pioneering perspectives and fieldwork contributions in India: G.S. Ghurye (Indological approach, caste features and origins, tribal integration); M.N. Srinivas (Structural-Functional approach, Rampura village study, Sanskritization, Westernization, Dominant Caste); contributions of D.P. Mukerji, Radhakamal Mukerjee, and Irawati Karve.`
      : isPracticalSociology11
      ? `Paper II: Practical Work & Sociological Research Projects (30 Marks). Completion of two independent empirical or ethnographic research projects utilizing interviews, questionnaires, or observational fieldwork on approved social topics (15 marks each); evaluated via Project File / Report (10 marks) and Viva-Voce Presentation (5 marks).`
      : isIntroPsychology11
      ? `Chapter 1: Introduction to Psychology (70 Marks Theory). Definition and nature of psychology; its evolution from philosophy to scientific inquiry; branches like cognitive, developmental, social, clinical, and educational. Historical schools of Structuralism, Functionalism, Behaviorism, Gestalt, Psychoanalysis, and Humanistic viewpoints, alongside the rich Indian Perspective of Yoga and Vedanta.`
      : isMethodsPsychology11
      ? `Chapter 2: Methods of Psychology (70 Marks Theory). Goals of psychological inquiry (description, prediction, explanation, control) and indicators of reliability, validity, and objectivity. Core qualitative/quantitative research methods like observational, experimental (variable control), correlational, case studies, surveys, and ethical guidelines.`
      : isBiologicalBasesPsychology11
      ? `Chapter 3: Biological Bases of Behaviour (70 Marks Theory). Biological structures and nerve impulse transmissions including neurons, action potential, and key neurotransmitters (ACh, Dopamine, Serotonin). Structure/function of Central Nervous System (brain and spinal cord) and Peripheral Nervous System (Somatic, Autonomic Sympathetic/Parasympathetic stress responses), plus endocrine hormonal regulation.`
      : isHumanDevelopmentPsychology11
      ? `Chapter 4: Human Development (70 Marks Theory). Defining growth and developmental principles, including nature vs nurture. Major stages from prenatal and infancy to late adulthood, highlighting adolescent identity crises, peer challenges, cognitive stages of Jean Piaget, and psychosocial stages of Erik Erikson.`
      : isSensoryPerceptualPsychology11
      ? `Chapter 5: Sensory, Attentional, and Perceptual Processes (70 Marks Theory). Visual and auditory sensation structures; sensory thresholds (Absolute and Just Noticeable Difference); selective vs sustained attention factors. Principles of Gestalt perceptual organization, monocular/binocular depth cues, size/shape constancies, and Müller-Lyer and Ponzo illusions.`
      : isLearningPsychology11
      ? `Chapter 6: Learning (70 Marks Theory). Nature and methods of learning. Deconstructs Classical Conditioning (Pavlov's stimuli and extinction/generalization phases), Operant Conditioning (Skinner's positive/negative reinforcement, punishment, and interval/ratio schedules), Insight learning (Köhler), Latent learning (Tolman), and Observational learning (Bandura's Bobo doll experiments).`
      : isMemoryPsychology11
      ? `Chapter 7: Human Memory (70 Marks Theory). Stage model of memory (Atkinson-Shiffrin sensory, STM, and LTM systems); declarative semantic/episodic vs non-declarative procedural memory. Forgetting curves of Hermann Ebbinghaus, trace decay, proactive/retroactive interference, motivated forgetting, and memory enhancement mnemonics.`
      : isPracticalPsychology11
      ? `Paper II: Practical Work (30 Marks). Practical methodologies and core laboratory tests: measuring immediate memory span, chunking benefits, bilateral learning transfer via mirror-drawing, division of attention, and drafting formal empirical reports. Case profiling of child development or adolescent stress interviews, and oral viva board defense.`
      : isUnderstandingEconomics11
      ? `Chapter 1: Understanding Economics & Basic Concepts (70 Marks Theory). Structural economic definitions: Smith's Wealth, Marshall's Welfare, Robbins' Scarcity, and Samuelson's Growth models. Micro vs macroeconomics, positive vs normative approaches, scarcity, choice, the central problems (what, how, and for whom to produce), and core terminologies of goods, utility, and wealth.`
      : isConsumerBehaviourDemand11
      ? `Chapter 2: Consumer Behaviour and Demand (70 Marks Theory). Cardinal utility (diminishing marginal utility, single commodity equilibrium) and ordinal utility (indifference curve properties and budget line). Theory of Demand, determinants, demand function, Law of Demand, exceptions, movements vs shifts, and measurement of Price Elasticity (percentage, point, outlay methods).`
      : isProducerBehaviourSupplyCost11
      ? `Chapter 3: Producer Behaviour, Supply, and Cost (70 Marks Theory). Short-run vs long-run production functions, the three stages of the Law of Variable Proportions, and returns to scale. Cost and Revenue curves (TFC, TVC, TC, AC, MC, TR, AR, MR interrelations). Theory of Supply, determinants, Law of Supply, shifts, and elasticity of supply.`
      : isMarketFormsPriceDet11
      ? `Chapter 4: Market Forms and Price Determination (70 Marks Theory). Defining features of Perfect Competition, Monopoly, Monopolistic Competition, and Oligopoly. Price determination under perfect competition, demand/supply shifts, and price ceiling and price floor regulatory controls.`
      : isStructuralFeaturesIndianEcon11
      ? `Chapter 5: Structural Features of the Indian Economy (70 Marks Theory). State of India's post-independence developing economy; sectoral features and bottlenecks in agriculture, industry, and service sectors. Deconstructs the New Economic Policy of 1991 (LPG: Liberalisation, Privatisation, Globalisation), and contemporary challenges of poverty, unemployment, and growth.`
      : isBasicStatisticsEconomics11
      ? `Chapter 6: Basic Statistics for Economics (70 Marks Theory). Role of statistics in economic policy; primary vs secondary data collection, sampling vs census methods, and tabulation. Computation of Mean, Median, and Mode, absolute/relative dispersion (Range, Quartile Deviation, SD, Coefficient of Variation), Karl Pearson's r, and index number formulas (Laspeyres, Paasche, Fisher).`
      : isProjectWorkEconomics11
      ? `Paper II: Project Work (20 Marks). Independent project formulation based on economic surveys, local retail market pricing, or LPG reform appraisals. Students prepare two detailed reports (1000-1500 words each), evaluated via project portfolios (10 marks internal) and viva-voce presentation defense (10 marks external).`
      : depth === 'quick' 
        ? `High-level definitions, summary terminology, and core concepts of ${chapter}.`
        : depth === 'standard'
        ? `Understand the fundamental definitions, core philosophy, and theoretical framework of ${chapter}.`
        : depth === 'deep'
        ? `Formal axiomatic set construction, definition boundaries, historically critical insights, and abstract groundwork of ${chapter}.`
        : `Advanced epistemological framework, historical foundations, multi-disciplinary integrations, and complex analytical formulation of ${chapter}.`;

    const l1Subtopics = isCommunicationSystemsLesson ? COMMUNICATION_SYSTEMS_LESSON_SUBTOPICS : isLogicGates ? LOGIC_GATES_SUBTOPICS : isJunctionTransistors ? JUNCTION_TRANSISTORS_SUBTOPICS : isSemiconductorDiodes ? SEMICONDUCTOR_DIODES_SUBTOPICS : isSemiconductorElectronicsLesson ? SEMICONDUCTOR_ELECTRONICS_LESSON_SUBTOPICS : isFissionFusion ? NUCLEAR_FISSION_FUSION_SUBTOPICS : isMassEnergyBinding ? MASS_ENERGY_BINDING_ENERGY_SUBTOPICS : isRadioactivity ? RADIOACTIVITY_SUBTOPICS : isNuclearStructure ? NUCLEAR_STRUCTURE_SUBTOPICS : isAtomsBohr ? ATOMS_BOHR_SPECTRUM_SUBTOPICS : isXRays ? X_RAYS_SUBTOPICS : isMatterWaves ? MATTER_WAVES_SUBTOPICS : isPhotoelectric ? PHOTOELECTRIC_EFFECT_SUBTOPICS : isPolarization ? POLARIZATION_OF_LIGHT_SUBTOPICS : isDiffraction ? DIFFRACTION_OF_LIGHT_SUBTOPICS : isInterference ? INTERFERENCE_OF_LIGHT_SUBTOPICS : isWaveNatureHuygens ? WAVE_NATURE_HUYGENS_SUBTOPICS : isOpticalInstruments ? OPTICAL_INSTRUMENTS_SUBTOPICS : isRefractionPrism ? REFRACTION_DISPERSION_PRISM_SUBTOPICS : isRefractionLenses ? REFRACTION_SPHERICAL_SURFACES_LENSES_SUBTOPICS : isRefractionPlane ? REFRACTION_PLANE_INTERFACE_SUBTOPICS : isReflection ? REFLECTION_OF_LIGHT_SUBTOPICS : isCommunication ? COMMUNICATION_SYSTEMS_SUBTOPICS : isSemiconductor ? SEMICONDUCTOR_ELECTRONICS_SUBTOPICS : isNuclei ? NUCLEI_SUBTOPICS : isAtoms ? ATOMS_SUBTOPICS : isDualNature ? DUAL_NATURE_SUBTOPICS : isWaveOptics ? WAVE_OPTICS_SUBTOPICS : isRayOptics ? RAY_OPTICS_SUBTOPICS : isElectromagneticWaves ? ELECTROMAGNETIC_WAVES_SUBTOPICS : isAlternatingCurrent ? ALTERNATING_CURRENT_SUBTOPICS : isElectromagneticInduction ? ELECTROMAGNETIC_INDUCTION_SUBTOPICS : isMagneticSubstances ? MAGNETIC_SUBSTANCES_SUBTOPICS : isEarthMagnetism ? EARTH_MAGNETISM_SUBTOPICS : isTorqueLoop ? TORQUE_CURRENT_LOOP_SUBTOPICS : isMovingCharges ? MOVING_CHARGES_SUBTOPICS : isDCCircuits ? DC_CIRCUITS_SUBTOPICS : isResistance ? ELECTRIC_RESISTANCE_SUBTOPICS : isCapacitors ? CAPACITORS_DIELECTRICS_SUBTOPICS : isElectricPotential ? ELECTRIC_POTENTIAL_SUBTOPICS : isGaussTheorem ? GAUSS_THEOREM_SUBTOPICS : isElectricCharges ? ELECTRIC_CHARGES_SUBTOPICS : 
      isSexualReproductionPlants ? SEXUAL_REPRODUCTION_PLANTS_SUBTOPICS :
      isHumanReproduction ? HUMAN_REPRODUCTION_SUBTOPICS :
      isReproductiveHealth ? REPRODUCTIVE_HEALTH_SUBTOPICS :
      isPrinciplesInheritance ? PRINCIPLES_OF_INHERITANCE_SUBTOPICS :
      isMolecularBasis ? MOLECULAR_BASIS_INHERITANCE_SUBTOPICS :
      isEvolution ? EVOLUTION_SUBTOPICS :
      isHumanHealth ? HUMAN_HEALTH_DISEASE_SUBTOPICS :
      isMicrobes ? MICROBES_HUMAN_WELFARE_SUBTOPICS :
      isBiotechPrinciples ? BIOTECHNOLOGY_PRINCIPLES_SUBTOPICS :
      isBiotechApps ? BIOTECHNOLOGY_APPLICATIONS_SUBTOPICS :
      isOrganismsPopulations ? ORGANISMS_POPULATIONS_SUBTOPICS :
      isEcosystem ? ECOSYSTEM_SUBTOPICS :
      isBiodiversity ? BIODIVERSITY_CONSERVATION_SUBTOPICS :
      isPythonRevision ? PYTHON_REVISION_TOUR_SUBTOPICS :
      isCSFunctions ? FUNCTIONS_SUBTOPICS :
      isFileHandling ? FILE_HANDLING_SUBTOPICS :
      isCSDataStructures ? DATA_STRUCTURES_CS_SUBTOPICS :
      isCSComputerNetworks ? COMPUTER_NETWORKS_CS_SUBTOPICS :
      isDatabaseManagement ? DATABASE_MANAGEMENT_CS_SUBTOPICS :
      isSocietalImpacts ? SOCIETAL_IMPACTS_SUBTOPICS :
      isBricksBeads ? BRICKS_BEADS_BONES_SUBTOPICS :
      isKingsFarmers ? KINGS_FARMERS_TOWNS_SUBTOPICS :
      isKinshipCaste ? KINSHIP_CASTE_CLASS_SUBTOPICS :
      isThinkersBeliefs ? THINKERS_BELIEFS_BUILDINGS_SUBTOPICS :
      isTravellers ? THROUGH_EYES_TRAVELLERS_SUBTOPICS :
      isBhaktiSufi ? BHAKTI_SUFI_TRADITIONS_SUBTOPICS :
      isVijayanagara ? VIJAYANAGARA_EMPIRE_SUBTOPICS :
      isPeasantsZamindars ? PEASANTS_ZAMINDARS_STATE_SUBTOPICS :
      isColonialismCountryside ? COLONIALISM_COUNTRYSIDE_SUBTOPICS :
      isRebelsRaj ? REBELS_AND_RAJ_SUBTOPICS :
      isGandhiMovement ? MAHATMA_GANDHI_MOVEMENT_SUBTOPICS :
      isFramingConstitution ? FRAMING_CONSTITUTION_SUBTOPICS :
      isGeogHumanNature ? HUMAN_GEOGRAPHY_NATURE_SUBTOPICS :
      isGeogWorldPop ? WORLD_POPULATION_SUBTOPICS :
      isGeogHumanDev ? HUMAN_DEVELOPMENT_GEOG_SUBTOPICS :
      isGeogPrimary ? PRIMARY_ACTIVITIES_SUBTOPICS :
      isGeogSecondary ? SECONDARY_ACTIVITIES_SUBTOPICS :
      isGeogTertiary ? TERTIARY_QUATERNARY_SUBTOPICS :
      isGeogTransport ? TRANSPORT_COMMUNICATION_SUBTOPICS :
      isGeogInternationalTrade ? INTERNATIONAL_TRADE_GEOG_SUBTOPICS :
      isGeogHumanSettlements ? HUMAN_SETTLEMENTS_GEOG_SUBTOPICS :
      isEndOfBipolarity ? END_OF_BIPOLARITY_SUBTOPICS :
      isContemporaryCentres ? CONTEMPORARY_CENTRES_POWER_SUBTOPICS :
      isContemporarySouthAsia ? CONTEMPORARY_SOUTH_ASIA_SUBTOPICS :
      isIntlOrganizations ? INTERNATIONAL_ORGANIZATIONS_SUBTOPICS :
      isSecurityContemporary ? SECURITY_CONTEMPORARY_WORLD_SUBTOPICS :
      isEnvironmentResources ? ENVIRONMENT_NATURAL_RESOURCES_SUBTOPICS :
      isGlobalizationPol ? GLOBALIZATION_POL_SUBTOPICS :
      isChallengesNationBuilding ? CHALLENGES_NATION_BUILDING_SUBTOPICS :
      isRecentDevelopmentsPol ? RECENT_DEVELOPMENTS_POL_SUBTOPICS :
      isSocDemography ? DEMOGRAPHIC_STRUCTURE_SUBTOPICS :
      isSocInstitutions ? SOCIAL_INSTITUTIONS_SUBTOPICS :
      isSocInequality ? SOCIAL_INEQUALITY_SUBTOPICS :
      isSocDiversity ? CULTURAL_DIVERSITY_SUBTOPICS :
      isSocStructuralChange ? STRUCTURAL_CHANGE_SUBTOPICS :
      isSocCulturalChange ? CULTURAL_CHANGE_SUBTOPICS :
      isSocRuralSociety ? RURAL_SOCIETY_CHANGE_SUBTOPICS :
      isSocIndustrialSociety ? INDUSTRIAL_SOCIETY_CHANGE_SUBTOPICS :
      isSocSocialMovements ? SOCIAL_MOVEMENTS_SUBTOPICS :
      isPsychVariations ? PSYCH_VARIATIONS_SUBTOPICS :
      isPsychPersonality ? SELF_PERSONALITY_SUBTOPICS :
      isPsychChallenges ? LIFE_CHALLENGES_SUBTOPICS :
      isPsychDisorders ? PSYCH_DISORDERS_SUBTOPICS :
      isPsychTherapy ? THERAPEUTIC_APPROACHES_SUBTOPICS :
      isPsychSocial ? ATTITUDE_SOCIAL_COGNITION_SUBTOPICS :
      isPsychGroups ? SOCIAL_INFLUENCE_GROUPS_SUBTOPICS :
      isEconMacroIntro ? MACRO_INTRO_SUBTOPICS :
      isEconNationalIncome ? NATIONAL_INCOME_SUBTOPICS :
      isEconMoneyBanking ? MONEY_BANKING_SUBTOPICS :
      isEconIncomeEmployment ? INCOME_EMPLOYMENT_SUBTOPICS :
      isEconGovtBudget ? GOVT_BUDGET_SUBTOPICS :
      isEconBOP ? BALANCE_PAYMENTS_SUBTOPICS :
      isEconIndiaEve ? INDIAN_ECON_EVE_SUBTOPICS :
      isEconIndia1950_1990 ? INDIAN_ECON_1950_1990_SUBTOPICS :
      isEconLPG ? LPG_APPRAISAL_SUBTOPICS :
      isEconHumanCapital ? HUMAN_CAPITAL_SUBTOPICS :
      isEconRuralDev ? RURAL_DEV_ECON_SUBTOPICS :
      isEconEmployment ? EMPLOYMENT_ISSUES_SUBTOPICS :
      isEconSustainable ? SUSTAINABLE_DEV_SUBTOPICS :
      isEconComparative ? COMPARATIVE_DEV_SUBTOPICS :
      isISCPsychIntelligence ? ISC_PSYCH_INTELLIGENCE_SUBTOPICS :
      isISCPsychPersonality ? ISC_PSYCH_PERSONALITY_SUBTOPICS :
      isISCPsychLifespan ? ISC_PSYCH_LIFESPAN_SUBTOPICS :
      isISCPsychStress ? ISC_PSYCH_STRESS_HEALTH_SUBTOPICS :
      isISCPsychDisorders ? ISC_PSYCH_DISORDERS_THERAPY_SUBTOPICS :
      isISCPsychSocialThought ? ISC_PSYCH_SOCIAL_THOUGHT_SUBTOPICS :
      isISCPsychSocialInfluence ? ISC_PSYCH_SOCIAL_INFLUENCE_SUBTOPICS :
      isISCBioReproduction ? ISC_BIO_REPRODUCTION_SUBTOPICS :
      isISCBioGenetics ? ISC_BIO_GENETICS_SUBTOPICS :
      isISCBioWelfare ? ISC_BIO_WELFARE_SUBTOPICS :
      isISCBioBiotech ? ISC_BIO_BIOTECH_SUBTOPICS :
      isISCBioEcology ? ISC_BIO_ECOLOGY_SUBTOPICS :
      isISCEconMicro ? ISC_ECON_MICRO_SUBTOPICS :
      isISCEconMacro ? ISC_ECON_MACRO_SUBTOPICS :
      isSolutions ? SOLUTIONS_CBSE_SUBTOPICS :
      isElectrochemistry ? ELECTROCHEMISTRY_CBSE_SUBTOPICS :
      isChemicalKinetics ? CHEMICAL_KINETICS_CBSE_SUBTOPICS :
      isDFBlock ? D_AND_F_BLOCK_CBSE_SUBTOPICS :
      isCoordinationCompounds ? COORDINATION_COMPOUNDS_CBSE_SUBTOPICS :
      isHaloalkanes ? HALOALKANES_HALOARENES_CBSE_SUBTOPICS :
      isAlcoholsPhenolsEthers ? ALCOHOLS_PHENOLS_ETHERS_CBSE_SUBTOPICS :
      isAldehydesKetonesCarboxylic ? ALDEHYDES_KETONES_CARBOXYLIC_CBSE_SUBTOPICS :
      isAmines ? AMINES_CBSE_SUBTOPICS :
      isBiomolecules ? BIOMOLECULES_CBSE_SUBTOPICS :
      isRationalIrrational9 ? RATIONAL_IRRATIONAL_NUMBERS_ICSE9_SUBTOPICS :
      isCompoundInterest9 ? COMPOUND_INTEREST_ICSE9_SUBTOPICS :
      isExpansions9 ? EXPANSIONS_ICSE9_SUBTOPICS :
      isFactorisation9 ? FACTORISATION_ICSE9_SUBTOPICS :
      isSimultaneousEquations9 ? SIMULTANEOUS_LINEAR_EQUATIONS_ICSE9_SUBTOPICS :
      isIndicesExponents9 ? INDICES_EXPONENTS_ICSE9_SUBTOPICS :
      isLogarithms9 ? LOGARITHMS_ICSE9_SUBTOPICS :
      isTriangles9 ? TRIANGLES_GEOMETRY_ICSE9_SUBTOPICS :
      isMidpointIntercept9 ? MIDPOINT_INTERCEPT_THEOREMS_ICSE9_SUBTOPICS :
      isRectilinearFigures9 ? RECTILINEAR_FIGURES_ICSE9_SUBTOPICS :
      isCircles9 ? CIRCLES_GEOMETRY_ICSE9_SUBTOPICS :
      isAreaPlaneFigures9 ? AREA_PLANE_FIGURES_ICSE9_SUBTOPICS :
      isSurfaceAreaVolume9 ? SURFACE_AREA_VOLUME_ICSE9_SUBTOPICS :
      isCoordinateGeometry9 ? COORDINATE_GEOMETRY_ICSE9_SUBTOPICS :
      isTrigRatios9 ? TRIGONOMETRICAL_RATIOS_ICSE9_SUBTOPICS :
      isStatistics9 ? STATISTICS_ICSE9_SUBTOPICS :
      isInternalAssessmentMath9 ? INTERNAL_ASSESSMENT_MATH_ICSE9_SUBTOPICS :
      isGST10 ? GST_ICSE10_SUBTOPICS :
      isBanking10 ? BANKING_ICSE10_SUBTOPICS :
      isLinearInequalities10 ? LINEAR_INEQUALITIES_ICSE10_SUBTOPICS :
      isQuadraticEquations10 ? QUADRATIC_EQUATIONS_ICSE10_SUBTOPICS :
      isRatioProportion10 ? RATIO_PROPORTION_ICSE10_SUBTOPICS :
      isFactorization10 ? FACTORIZATION_POLYNOMIALS_ICSE10_SUBTOPICS :
      isMatrices10 ? MATRICES_ICSE10_SUBTOPICS :
      isProgressions10 ? PROGRESSIONS_ICSE10_SUBTOPICS :
      isReflection10 ? REFLECTION_ICSE10_SUBTOPICS :
      isSectionMidpoint10 ? SECTION_MIDPOINT_ICSE10_SUBTOPICS :
      isEquationLine10 ? EQUATION_LINE_ICSE10_SUBTOPICS :
      isSimilarity10 ? SIMILARITY_ICSE10_SUBTOPICS :
      isLoci10 ? LOCI_ICSE10_SUBTOPICS :
      isCirclesProperties10 ? CIRCLES_PROPERTIES_ICSE10_SUBTOPICS :
      isMensuration3D10 ? MENSURATION_3D_ICSE10_SUBTOPICS :
      isTrigIdentities10 ? TRIGONOMETRY_IDENTITIES_ICSE10_SUBTOPICS :
      isHeightsDistances10 ? HEIGHTS_DISTANCES_ICSE10_SUBTOPICS :
      isStatistics10 ? STATISTICS_ICSE10_SUBTOPICS :
      isProbability10 ? PROBABILITY_ICSE10_SUBTOPICS :
      isMeasurements9 ? MEASUREMENTS_EXPERIMENTATION_ICSE9_SUBTOPICS :
      isMotion1D9 ? MOTION_ONE_DIMENSION_ICSE9_SUBTOPICS :
      isLawsOfMotion9 ? LAWS_OF_MOTION_ICSE9_SUBTOPICS :
      isFluidsArchimedes9 ? FLUIDS_PRESSURE_ARCHIMEDES_ICSE9_SUBTOPICS :
      isHeatEnergy9 ? HEAT_AND_ENERGY_ICSE9_SUBTOPICS :
      isLightReflection9 ? LIGHT_REFLECTION_SPHERICAL_MIRRORS_ICSE9_SUBTOPICS :
      isSoundUltrasonic9 ? SOUND_PROPAGATION_ULTRASONIC_ICSE9_SUBTOPICS :
      isElectricityMagnetism9 ? ELECTRICITY_MAGNETISM_ICSE9_SUBTOPICS :
      isInternalAssessmentPhysics9 ? INTERNAL_ASSESSMENT_PHYSICS_ICSE9_SUBTOPICS :
      isLanguageOfChemistry9 ? LANGUAGE_OF_CHEMISTRY_ICSE9_SUBTOPICS :
      isChemicalChangesReactions9 ? CHEMICAL_CHANGES_REACTIONS_ICSE9_SUBTOPICS :
      isWaterHydration9 ? WATER_SOLUTIONS_HYDRATION_ICSE9_SUBTOPICS :
      isAtomicStructureBonding9 ? ATOMIC_STRUCTURE_BONDING_ICSE9_SUBTOPICS :
      isPeriodicTableICSE9 ? PERIODIC_TABLE_PROPERTIES_ICSE9_SUBTOPICS :
      isHydrogenStudy9 ? HYDROGEN_STUDY_ICSE9_SUBTOPICS :
      isGasLawsICSE9 ? GAS_LAWS_BOYLE_CHARLES_ICSE9_SUBTOPICS :
      isAtmosphericPollution9 ? ATMOSPHERIC_POLLUTION_ICSE9_SUBTOPICS :
      isInternalAssessmentChemistry9 ? INTERNAL_ASSESSMENT_CHEMISTRY_ICSE9_SUBTOPICS :
      isBasicBiology9 ? BASIC_BIOLOGY_ICSE9_SUBTOPICS :
      isFloweringPlants9 ? FLOWERING_PLANTS_ICSE9_SUBTOPICS :
      isHumanAnatomyPhysiology9 ? HUMAN_ANATOMY_PHYSIOLOGY_ICSE9_SUBTOPICS :
      isHealthHygiene9 ? HEALTH_HYGIENE_ICSE9_SUBTOPICS :
      isWasteManagement9 ? WASTE_MANAGEMENT_ICSE9_SUBTOPICS :
      isInternalAssessmentBiology9 ? INTERNAL_ASSESSMENT_BIOLOGY_ICSE9_SUBTOPICS :
      isOOPConcepts9 ? OOP_CONCEPTS_ICSE9_SUBTOPICS :
      isObjectsClasses9 ? OBJECTS_CLASSES_ICSE9_SUBTOPICS :
      isValuesDataTypes9 ? VALUES_DATA_TYPES_ICSE9_SUBTOPICS :
      isOperatorsJava9 ? OPERATORS_JAVA_ICSE9_SUBTOPICS :
      isInputJava9 ? INPUT_JAVA_ICSE9_SUBTOPICS :
      isMathLibraryJava9 ? MATH_LIBRARY_JAVA_ICSE9_SUBTOPICS :
      isConditionalConstructs9 ? CONDITIONAL_CONSTRUCTS_ICSE9_SUBTOPICS :
      isIterativeConstructs9 ? ITERATIVE_CONSTRUCTS_ICSE9_SUBTOPICS :
      isInternalAssessmentCS9 ? INTERNAL_ASSESSMENT_CS_ICSE9_SUBTOPICS :
      isConstitution9 ? OUR_CONSTITUTION_ICSE9_SUBTOPICS :
      isElections9 ? ELECTIONS_ICSE9_SUBTOPICS :
      isLocalSelfGov9 ? LOCAL_SELF_GOVERNMENT_ICSE9_SUBTOPICS :
      isAncientIndia9 ? ANCIENT_INDIA_CIVILISATIONS_ICSE9_SUBTOPICS :
      isMedievalIndia9 ? MEDIEVAL_INDIA_CULTURE_ICSE9_SUBTOPICS :
      isModernAgeEurope9 ? MODERN_AGE_EUROPE_ICSE9_SUBTOPICS :
      isGeographicalSkills9 ? GEOGRAPHICAL_SKILLS_MAPWORK_ICSE9_SUBTOPICS :
      isPhysicalGeography9 ? PHYSICAL_GEOGRAPHY_EARTH_ICSE9_SUBTOPICS :
      isAtmosphereHydrosphere9 ? ATMOSPHERE_HYDROSPHERE_ICSE9_SUBTOPICS :
      isEnvironmentNaturalRegions9 ? ENVIRONMENT_NATURAL_REGIONS_ICSE9_SUBTOPICS :
      isInternalAssessmentSocialScience9 ? INTERNAL_ASSESSMENT_SOCIAL_SCIENCE_ICSE9_SUBTOPICS :
      isSets11 ? SETS_ICSE11_SUBTOPICS :
      isRelationsFunctions11 ? RELATIONS_FUNCTIONS_ICSE11_SUBTOPICS :
      isTrigonometry11 ? TRIGONOMETRY_ICSE11_SUBTOPICS :
      isMathematicalInduction11 ? MATHEMATICAL_INDUCTION_ICSE11_SUBTOPICS :
      isComplexNumbers11 ? COMPLEX_NUMBERS_QUADRATIC_ICSE11_SUBTOPICS :
      isLinearInequalities11 ? LINEAR_INEQUALITIES_ICSE11_SUBTOPICS :
      isPermutationsCombinations11 ? PERMUTATIONS_COMBINATIONS_ICSE11_SUBTOPICS :
      isBinomialTheorem11 ? BINOMIAL_THEOREM_ICSE11_SUBTOPICS :
      isSequenceSeries11 ? SEQUENCE_SERIES_ICSE11_SUBTOPICS :
      isStraightLines11 ? STRAIGHT_LINES_ICSE11_SUBTOPICS :
      isCircles11 ? CIRCLES_ICSE11_SUBTOPICS :
      isCalculusLimits11 ? CALCULUS_LIMITS_DERIVATIVES_ICSE11_SUBTOPICS :
      isStatistics11 ? STATISTICS_ICSE11_SUBTOPICS :
      isProbability11 ? PROBABILITY_ICSE11_SUBTOPICS :
      isConicSections11 ? CONIC_SECTIONS_ICSE11_SUBTOPICS :
      isThreeD11 ? THREE_DIMENSIONAL_GEOMETRY_ICSE11_SUBTOPICS :
      isMathematicalReasoning11 ? MATHEMATICAL_REASONING_ICSE11_SUBTOPICS :
      isCommercialStats11 ? COMMERCIAL_STATISTICS_EXPECTATION_ICSE11_SUBTOPICS :
      isCorrelationRegression11 ? CORRELATION_REGRESSION_ICSE11_SUBTOPICS :
      isIndexNumbersMovingAvg11 ? INDEX_NUMBERS_MOVING_AVERAGES_ICSE11_SUBTOPICS :
      isProjectWorkMath11 ? PROJECT_WORK_ICSE11_SUBTOPICS :
      isForceWorkEnergy11ICSE ? FORCE_WORK_POWER_ENERGY_ICSE11_SUBTOPICS :
      isLightOptics11ICSE ? LIGHT_OPTICS_ICSE11_SUBTOPICS :
      isSoundAcoustics11ICSE ? SOUND_ACOUSTICS_ICSE11_SUBTOPICS :
      isElectricityMagnetism11ICSE ? ELECTRICITY_MAGNETISM_ICSE11_SUBTOPICS :
      isHeatCalorimetry11ICSE ? HEAT_CALORIMETRY_ICSE11_SUBTOPICS :
      isModernPhysicsNuclear11ICSE ? MODERN_PHYSICS_NUCLEAR_ICSE11_SUBTOPICS :
      isPracticalPhysics11ICSE ? PRACTICAL_PHYSICS_ICSE11_SUBTOPICS :
      isBasicConceptsChem11 ? SOME_BASIC_CONCEPTS_CHEM_ICSE11_SUBTOPICS :
      isStructureOfAtom11 ? STRUCTURE_OF_ATOM_ICSE11_SUBTOPICS :
      isClassificationElements11 ? CLASSIFICATION_ELEMENTS_PERIODICITY_ICSE11_SUBTOPICS :
      isChemicalBonding11 ? CHEMICAL_BONDING_MOLECULAR_ICSE11_SUBTOPICS :
      isChemicalThermodynamics11 ? CHEMICAL_THERMODYNAMICS_ICSE11_SUBTOPICS :
      isEquilibrium11 ? EQUILIBRIUM_ICSE11_SUBTOPICS :
      isRedoxReactions11 ? REDOX_REACTIONS_ICSE11_SUBTOPICS :
      isInorganicSPBlock11 ? INORGANIC_CHEMISTRY_S_P_BLOCK_ICSE11_SUBTOPICS :
      isOrganicHydrocarbons11 ? ORGANIC_CHEMISTRY_HYDROCARBONS_ICSE11_SUBTOPICS :
      isPracticalChemistry11 ? PRACTICAL_CHEMISTRY_ICSE11_SUBTOPICS :
      isPhysicalWorldMeasurement11 ? PHYSICAL_WORLD_MEASUREMENT_ICSE11_SUBTOPICS :
      isKinematics11 ? KINEMATICS_ICSE11_SUBTOPICS :
      isLawsOfMotion11 ? LAWS_OF_MOTION_ICSE11_SUBTOPICS :
      isWorkEnergyPower11 ? WORK_ENERGY_POWER_ICSE11_SUBTOPICS :
      isSystemParticlesRigidBody11 ? SYSTEM_PARTICLES_RIGID_BODY_ICSE11_SUBTOPICS :
      isGravitation11 ? GRAVITATION_ICSE11_SUBTOPICS :
      isPropertiesBulkMatter11 ? PROPERTIES_BULK_MATTER_ICSE11_SUBTOPICS :
      isThermodynamicsPhysics11 ? THERMODYNAMICS_PHYSICS_ICSE11_SUBTOPICS :
      isKineticTheoryGases11 ? KINETIC_THEORY_GASES_ICSE11_SUBTOPICS :
      isOscillationsWaves11 ? OSCILLATIONS_WAVES_ICSE11_SUBTOPICS :
      isPracticalPhysics11 ? PRACTICAL_PHYSICS_ICSE11_SUBTOPICS :
      isDiversityLivingOrganisms11 ? DIVERSITY_LIVING_ORGANISMS_ICSE11_SUBTOPICS :
      isStructuralOrganisation11 ? STRUCTURAL_ORGANISATION_ICSE11_SUBTOPICS :
      isCellStructureFunction11 ? CELL_STRUCTURE_FUNCTION_ICSE11_SUBTOPICS :
      isPlantPhysiology11 ? PLANT_PHYSIOLOGY_ICSE11_SUBTOPICS :
      isHumanPhysiology11 ? HUMAN_PHYSIOLOGY_ICSE11_SUBTOPICS :
      isPracticalBiology11 ? PRACTICAL_BIOLOGY_ICSE11_SUBTOPICS :
      isDataRepBooleanAlg11 ? DATA_REP_BOOLEAN_ALG_ICSE11_SUBTOPICS :
      isHardwareArchitecture11 ? HARDWARE_ARCHITECTURE_ICSE11_SUBTOPICS :
      isJavaOOPConcepts11 ? JAVA_OOP_CONCEPTS_ICSE11_SUBTOPICS :
      isControlStructuresFunctions11 ? CONTROL_STRUCTURES_FUNCTIONS_ICSE11_SUBTOPICS :
      isArraysStrings11 ? ARRAYS_STRINGS_ICSE11_SUBTOPICS :
      isAdvancedOOPFeatures11 ? ADVANCED_OOP_FEATURES_ICSE11_SUBTOPICS :
      isPracticalWorkCS11 ? PRACTICAL_WORK_CS_ICSE11_SUBTOPICS :
      isGrowthOfNationalism11 ? GROWTH_OF_NATIONALISM_ICSE11_SUBTOPICS :
      isEmergenceOfRadicals11 ? EMERGENCE_OF_RADICALS_ICSE11_SUBTOPICS :
      isWWINationalistPolitics11 ? WWI_NATIONALIST_POLITICS_ICSE11_SUBTOPICS :
      isGandhianEra11 ? GANDHIAN_ERA_MASS_NATIONALISM_ICSE11_SUBTOPICS :
      isImpactWWIPeaceSettlements11 ? IMPACT_WWI_PEACE_SETTLEMENTS_ICSE11_SUBTOPICS :
      isGreatDepressionTotalitarianism11 ? GREAT_DEPRESSION_TOTALITARIANISM_ICSE11_SUBTOPICS :
      isWWIICollapseCollectiveSecurity11 ? WWII_COLLAPSE_COLLECTIVE_SECURITY_ICSE11_SUBTOPICS :
      isRiseOfCommunismChina11 ? RISE_OF_COMMUNISM_CHINA_ICSE11_SUBTOPICS :
      isProjectWorkHistory11 ? PROJECT_WORK_HISTORY_ICSE11_SUBTOPICS :
      isEarthStructureEndogenetic11 ? EARTH_STRUCTURE_ENDOGENETIC_ICSE11_SUBTOPICS :
      isExogeneticLandforms11 ? EXOGENETIC_LANDFORMS_ICSE11_SUBTOPICS :
      isAtmosphereHydrosphere11 ? ATMOSPHERE_HYDROSPHERE_ICSE11_SUBTOPICS :
      isPopulationSettlements11 ? POPULATION_SETTLEMENTS_ICSE11_SUBTOPICS :
      isPhysicalFrameworkIndia11 ? PHYSICAL_FRAMEWORK_INDIA_ICSE11_SUBTOPICS :
      isResourcesEnvironmentIndia11 ? RESOURCES_ENVIRONMENT_INDIA_ICSE11_SUBTOPICS :
      isPracticalGeography11 ? PRACTICAL_GEOGRAPHY_ICSE11_SUBTOPICS :
      isIntroPolScience11 ? INTRO_POLITICAL_SCIENCE_ICSE11_SUBTOPICS :
      isFundamentalPolConcepts11 ? FUNDAMENTAL_POLITICAL_CONCEPTS_ICSE11_SUBTOPICS :
      isFormsOfGovt11 ? FORMS_OF_GOVERNMENT_ICSE11_SUBTOPICS :
      isConstitutionsStructures11 ? CONSTITUTIONS_ORGANIC_STRUCTURES_ICSE11_SUBTOPICS :
      isFranchiseRepresentation11 ? FRANCHISE_REPRESENTATION_PARTIES_ICSE11_SUBTOPICS :
      isProjectWorkPolScience11 ? PROJECT_WORK_POLITICAL_SCIENCE_ICSE11_SUBTOPICS :
      isOriginDevSociology11 ? ORIGIN_DEV_SOCIOLOGY_ICSE11_SUBTOPICS :
      isResearchMethodologySociology11 ? RESEARCH_METHODOLOGY_SOCIOLOGY_ICSE11_SUBTOPICS :
      isBasicConceptsSociology11 ? BASIC_CONCEPTS_SOCIOLOGY_ICSE11_SUBTOPICS :
      isSocialStructureSociology11 ? SOCIAL_STRUCTURE_SOCIOLOGY_ICSE11_SUBTOPICS :
      isSocialProblemsSociology11 ? SOCIAL_PROBLEMS_SOCIOLOGY_ICSE11_SUBTOPICS :
      isIndianSociologists11 ? INDIAN_SOCIOLOGISTS_ICSE11_SUBTOPICS :
      isPracticalSociology11 ? PRACTICAL_SOCIOLOGY_ICSE11_SUBTOPICS :
      isIntroPsychology11 ? INTRO_PSYCHOLOGY_ICSE11_SUBTOPICS :
      isMethodsPsychology11 ? METHODS_PSYCHOLOGY_ICSE11_SUBTOPICS :
      isBiologicalBasesPsychology11 ? BIOLOGICAL_BASES_PSYCHOLOGY_ICSE11_SUBTOPICS :
      isHumanDevelopmentPsychology11 ? HUMAN_DEVELOPMENT_PSYCHOLOGY_ICSE11_SUBTOPICS :
      isSensoryPerceptualPsychology11 ? SENSORY_PERCEPTUAL_PSYCHOLOGY_ICSE11_SUBTOPICS :
      isLearningPsychology11 ? LEARNING_PSYCHOLOGY_ICSE11_SUBTOPICS :
      isMemoryPsychology11 ? MEMORY_PSYCHOLOGY_ICSE11_SUBTOPICS :
      isPracticalPsychology11 ? PRACTICAL_PSYCHOLOGY_ICSE11_SUBTOPICS :
      isUnderstandingEconomics11 ? UNDERSTANDING_ECONOMICS_ICSE11_SUBTOPICS :
      isConsumerBehaviourDemand11 ? CONSUMER_BEHAVIOUR_DEMAND_ICSE11_SUBTOPICS :
      isProducerBehaviourSupplyCost11 ? PRODUCER_BEHAVIOUR_SUPPLY_COST_ICSE11_SUBTOPICS :
      isMarketFormsPriceDet11 ? MARKET_FORMS_PRICE_DET_ICSE11_SUBTOPICS :
      isStructuralFeaturesIndianEcon11 ? STRUCTURAL_FEATURES_INDIAN_ECON_ICSE11_SUBTOPICS :
      isBasicStatisticsEconomics11 ? BASIC_STATISTICS_ECONOMICS_ICSE11_SUBTOPICS :
      isProjectWorkEconomics11 ? PROJECT_WORK_ECONOMICS_ICSE11_SUBTOPICS :
      undefined;

    // Rich predefined database of up to 10 highly structural lessons to scale on demand
    const predefined = [
      {
        id: 'l1',
        title: l1Title,
        description: l1Desc,
        duration: `${Math.round(15 * multiplier)} mins`,
        level: depth === 'quick' ? 'Basic' : depth === 'standard' ? 'Intermediate' : depth === 'deep' ? 'Honors' : 'Graduate / Research',
        subtopics: l1Subtopics
      },
      {
        id: 'l2',
        title: `Core Principles & Formulas of ${chapter}${rigorText}`,
        description: depth === 'quick'
          ? `Interactive formulas checklist and quick memory sheets for ${chapter}.`
          : depth === 'standard'
          ? `Dive deep into key formulations, essential axioms, equations, and visual mappings of ${chapter}.`
          : depth === 'deep'
          ? `Full algebraic derivation of all key formulas, theorem proofs (Q.E.D.), mathematical properties, and physical limits of ${chapter}.`
          : `Symmetric transformations, matrix representations, advanced theoretical derivations, tensor calculus representations, and foundational proofs in ${chapter}.`,
        duration: `${Math.round(25 * multiplier)} mins`,
        level: depth === 'quick' ? 'Basic' : depth === 'standard' ? 'Intermediate' : depth === 'deep' ? 'Honors' : 'Graduate / Research'
      },
      {
        id: 'l3',
        title: `Real-world Applications & Solving of ${chapter}${rigorText}`,
        description: depth === 'quick'
          ? `A quick standard worked-out practice example with instant quiz.`
          : depth === 'standard'
          ? `Solve complex exercises, test case analyses, and practical numerical optimization problems.`
          : depth === 'deep'
          ? `Comprehensive high-dimensional engineering simulation problems, boundary edge cases, and competitive-tier derivation tasks.`
          : `Unsolved research challenges, MIT/Stanford project paradigms, advanced code/numerical solvers, and high-calibration industrial optimization tests for ${chapter}.`,
        duration: `${Math.round(30 * multiplier)} mins`,
        level: depth === 'quick' ? 'Basic' : depth === 'standard' ? 'Intermediate' : depth === 'deep' ? 'Honors' : 'Graduate / Research'
      },
      {
        id: 'l4',
        title: `Advanced Problem Sets & Extreme Edge Cases of ${chapter}${rigorText}`,
        description: `Step-by-step masterclass analyzing extreme boundaries, asymptotic limits, and multi-variable interaction constraints.`,
        duration: `${Math.round(35 * multiplier)} mins`,
        level: 'Honors Prep'
      },
      {
        id: 'l5',
        title: `Common Misconceptions & Cognitive Pitfalls in ${chapter}${rigorText}`,
        description: `Identify and solve standard student traps, tricky exam question patterns, and algebraic/logical shortcuts.`,
        duration: `${Math.round(20 * multiplier)} mins`,
        level: 'Skill Builder'
      },
      {
        id: 'l6',
        title: `Historical Context, Discovery Timeline & Pioneers of ${chapter}${rigorText}`,
        description: `Explore the original historical experiments, correspondence, and evolutionary leaps of thought behind these concepts.`,
        duration: `${Math.round(15 * multiplier)} mins`,
        level: 'Conceptual enrichment'
      },
      {
        id: 'l7',
        title: mode === 'entrance' 
          ? `High-Calibration Entrance Exam Practice of ${chapter}${rigorText}` 
          : mode === 'competitive' 
          ? `Olympiad Speed & Rigor Challenge of ${chapter}${rigorText}` 
          : `High-Calibration Board Exam Practice of ${chapter}${rigorText}`,
        description: mode === 'entrance' 
          ? `Complete entrance-specific mock evaluation patterns, answer rubric breakdowns, and timing/scoring optimization.` 
          : mode === 'competitive' 
          ? `Master speed shortcuts, analytical tricks, alternative proof-paths, and timing optimization for international olympiads.` 
          : `Complete board-specific mock evaluation patterns, answer rubric breakdowns, and timing/scoring optimization.`,
        duration: `${Math.round(45 * multiplier)} mins`,
        level: 'Exam Prep'
      },
      {
        id: 'l8',
        title: `Interdisciplinary Mappings of ${chapter}${rigorText}`,
        description: `Unveil how the mathematics and logic of this topic maps to computer engineering, physical systems, and economics.`,
        duration: `${Math.round(25 * multiplier)} mins`,
        level: 'Graduate / Research'
      },
      {
        id: 'l9',
        title: `Research Frontiers & Modern Unsolved Questions in ${chapter}${rigorText}`,
        description: `An academic survey of the leading edge, open research challenges, and modern journal publications.`,
        duration: `${Math.round(40 * multiplier)} mins`,
        level: 'PhD Research'
      },
      {
        id: 'l10',
        title: `Syllabus Consolidation, Key Formulas & Cheat-sheet for ${chapter}${rigorText}`,
        description: `A fast summary review designed for prompt retention, active recall, and formula memorization.`,
        duration: `${Math.round(20 * multiplier)} mins`,
        level: 'Basic Review'
      }
    ];

    const requestedCount = lessonCounts[chapter] ?? 3;
    let list = [];
    
    // Scale up predefined lessons to match requested count (up to predefined size or dynamically generated)
    for (let i = 0; i < requestedCount; i++) {
      if (i < predefined.length) {
        list.push(predefined[i]);
      } else {
        // If they want more than 10 lessons, dynamically generate fully detailed unique lesson blocks
        list.push({
          id: `l-dynamic-${i + 1}`,
          title: `Specialization Focus Module ${i - 8} on ${chapter}${rigorText}`,
          description: `Custom specialized high-performance study module targeting subtopic dimension ${i - 8} of the active chapter curriculum.`,
          duration: `30 mins`,
          level: 'Advanced Specialty'
        });
      }
    }

    // Append any user-defined custom lessons
    const customList = customLessons[chapter] || [];
    return [...list, ...customList];
  };

  interface RoadmapWeek {
    weekNumber: number;
    title: string;
    chapters: string[];
    lessons: Array<{ id: string; title: string; description: string; duration: string; level: string }>;
    progressPercent: number;
    completedCount: number;
    totalCount: number;
    status: 'completed' | 'in_progress' | 'not_started';
  }

  const generateRoadmapWeeks = (): RoadmapWeek[] => {
    if (!chapters || chapters.length === 0) return [];
    
    const weeksList: RoadmapWeek[] = [];
    
    if (chapters.length === 1) {
      const singleCh = chapters[0];
      const allLessons = getLessonsForChapter(singleCh, chosenDepth);
      const lessonsPerWeek = Math.max(1, Math.ceil(allLessons.length / 3));
      
      for (let i = 0; i < 3; i++) {
        const startIdx = i * lessonsPerWeek;
        const weekLessons = allLessons.slice(startIdx, startIdx + lessonsPerWeek);
        if (weekLessons.length === 0) continue;
        
        let completedCount = 0;
        weekLessons.forEach(les => {
          if (completedLessons[`${singleCh}_${les.id}`]) {
            completedCount++;
          }
        });
        
        const totalCount = weekLessons.length;
        const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
        
        let status: 'completed' | 'in_progress' | 'not_started' = 'not_started';
        if (progressPercent === 100) status = 'completed';
        else if (progressPercent > 0) status = 'in_progress';
        
        weeksList.push({
          weekNumber: i + 1,
          title: `${singleCh} - Phase ${i + 1}`,
          chapters: [singleCh],
          lessons: weekLessons,
          progressPercent,
          completedCount,
          totalCount,
          status
        });
      }
    } else {
      chapters.forEach((chapter: string, index: number) => {
        const weekLessons = getLessonsForChapter(chapter, chosenDepth);
        let completedCount = 0;
        weekLessons.forEach(les => {
          if (completedLessons[`${chapter}_${les.id}`]) {
            completedCount++;
          }
        });
        
        const totalCount = weekLessons.length;
        const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
        
        let status: 'completed' | 'in_progress' | 'not_started' = 'not_started';
        if (progressPercent === 100) status = 'completed';
        else if (progressPercent > 0) status = 'in_progress';
        
        weeksList.push({
          weekNumber: index + 1,
          title: chapter,
          chapters: [chapter],
          lessons: weekLessons,
          progressPercent,
          completedCount,
          totalCount,
          status
        });
      });
    }
    
    return weeksList;
  };

  // Tracking previous week statuses for automated milestone change detection
  const prevWeeksStatusRef = React.useRef<Record<number, 'completed' | 'in_progress' | 'not_started'>>({});
  const isInitialMountRef = React.useRef(true);

  React.useEffect(() => {
    const currentWeeks = generateRoadmapWeeks();
    const prevStatuses = prevWeeksStatusRef.current;
    const nextStatuses: Record<number, 'completed' | 'in_progress' | 'not_started'> = {};

    let hasChanges = false;
    let logsAdded: string[] = [];

    currentWeeks.forEach(week => {
      nextStatuses[week.weekNumber] = week.status;
      const prevStatus = prevStatuses[week.weekNumber];
      
      if (prevStatus !== undefined && prevStatus !== week.status) {
        hasChanges = true;
        if (week.status === 'completed') {
          logsAdded.push(`Week ${week.weekNumber} completed! 🎉`);
          if (showNotification) {
            showNotification(`🏆 AUTO-SYNC: Week ${week.weekNumber} Study Milestone fully cleared!`, 'success');
          }
        } else if (week.status === 'in_progress') {
          logsAdded.push(`Week ${week.weekNumber} in progress (${week.progressPercent}%).`);
        } else {
          logsAdded.push(`Week ${week.weekNumber} set to not started.`);
        }
      }
    });

    prevWeeksStatusRef.current = nextStatuses;

    if (isInitialMountRef.current) {
      isInitialMountRef.current = false;
      return;
    }

    if (hasChanges) {
      setIsSyncing(true);
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastSyncTime(timeStr);

      const completedCount = currentWeeks.filter(w => w.status === 'completed').length;
      const totalCount = currentWeeks.length;
      
      const primaryMsg = logsAdded.length > 0 
        ? logsAdded.join(' | ') 
        : `All milestones in sync with Chapters Explorer. (${completedCount}/${totalCount} weeks cleared)`;

      setSyncLogs(prev => {
        const newLog = {
          id: Math.random().toString(36).substring(2, 9),
          msg: primaryMsg,
          time: timeStr
        };
        return [newLog, ...prev].slice(0, 15);
      });

      const timer = setTimeout(() => {
        setIsSyncing(false);
      }, 500);

      return () => clearTimeout(timer);
    }
  }, [completedLessons, chosenDepth, subject, chapters]);

  const handleGenerateRoadmapTips = async () => {
    setIsGeneratingRoadmapTips(true);
    const weeks = generateRoadmapWeeks();
    const completedWeeks = weeks.filter(w => w.status === 'completed').length;
    const inProgressWeeks = weeks.filter(w => w.status === 'in_progress').length;
    
    const prompt = `You are an expert AI Learning Coach. Provide a highly engaging, custom-tailored study roadmap guidance report based on the following curriculum details and progress:
- Subject: ${subject}
- Difficulty Level/Board: ${boardName} (${difficulty})
- Total Weeks/Stages planned: ${weeks.length}
- Completed Weeks: ${completedWeeks}/${weeks.length}
- In-Progress Weeks: ${inProgressWeeks}/${weeks.length}
- Detailed Progress Breakdown:
${weeks.map(w => `  * Week ${w.weekNumber} ("${w.title}"): ${w.completedCount}/${w.totalCount} lessons completed (${w.progressPercent}%). Status: ${w.status}`).join('\n')}

Please construct:
1. A motivational introductory summary of their progress.
2. 3 actionable tactical advice points on how they can speed up or optimize their learning for the current/next target week.
3. Recommended spacing and review schedule (e.g. Feynman technique or Leitner system suggestions).
4. Focus areas and potential cognitive roadblocks to watch out for based on current topic.

Format your response in a very elegant, professional, and readable way with clear headings and bullet points. Do not include markdown code block syntax. Keep it extremely high value.`;

    try {
      const response = await generateAIResponse(prompt, {
        model: 'gemini-3.6-flash',
        systemInstruction: 'You are an elite academic mentor who designs study roadmaps.'
      });
      if (response) {
        setRoadmapTips(response);
        try {
          localStorage.setItem(`roadmap_tips_${subject}`, response);
        } catch (e) {
          console.error(e);
        }
        showNotification?.('AI Study Roadmap guidance updated successfully! 🎯', 'success');
      } else {
        showNotification?.('Failed to generate study advice.', 'error');
      }
    } catch (error) {
      console.error(error);
      showNotification?.('Error generating roadmap advice.', 'error');
    } finally {
      setIsGeneratingRoadmapTips(false);
    }
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-white text-slate-900"
    )}>
      {/* Tabs Menu */}
      <div className={cn(
        "flex border-b px-6 flex-shrink-0",
        theme === 'dark' ? "border-slate-800" : "border-slate-200"
      )}>
        <button
          onClick={() => { setActiveTab('syllabus'); setReadingNote(null); }}
          className={cn(
            "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer",
            activeTab === 'syllabus' 
              ? "border-indigo-500 text-indigo-500" 
              : "border-transparent opacity-60 hover:opacity-100"
          )}
        >
          <BookOpen size={15} />
          {boardName} Curriculum
        </button>
        <button
          onClick={() => { setActiveTab('notes'); setReadingNote(null); }}
          className={cn(
            "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 relative cursor-pointer",
            activeTab === 'notes' 
              ? "border-indigo-500 text-indigo-500" 
              : "border-transparent opacity-60 hover:opacity-100"
          )}
        >
          <Sparkles size={15} className="text-amber-500" />
          Saved Study Notes
          {savedNotes.length > 0 && (
            <span className="absolute top-2 right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
            </span>
          )}
        </button>
        <button
          onClick={() => { setActiveTab('public-seo'); setReadingNote(null); }}
          className={cn(
            "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 relative cursor-pointer",
            activeTab === 'public-seo' 
              ? "border-indigo-500 text-indigo-550 text-indigo-500" 
              : "border-transparent opacity-60 hover:opacity-100"
          )}
        >
          <Globe size={15} className="text-emerald-500 animate-pulse" />
          Public SEO Landings
          <span className="text-[9px] bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-1.5 py-0.2 rounded-full font-black uppercase hidden md:inline">
            Live
          </span>
        </button>
        <button
          onClick={() => { setActiveTab('roadmap'); setReadingNote(null); }}
          className={cn(
            "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 relative cursor-pointer",
            activeTab === 'roadmap' 
              ? "border-indigo-500 text-indigo-500" 
              : "border-transparent opacity-60 hover:opacity-100"
          )}
        >
          <Compass size={15} className="text-indigo-500" />
          Study Roadmap
          <span className="text-[9px] bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 px-1.5 py-0.2 rounded-full font-black uppercase hidden md:inline">
            Plan
          </span>
        </button>
        <button
          onClick={() => { setActiveTab('goals'); setReadingNote(null); }}
          className={cn(
            "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 relative cursor-pointer",
            activeTab === 'goals' 
              ? "border-indigo-500 text-indigo-500" 
              : "border-transparent opacity-60 hover:opacity-100"
          )}
        >
          <Target size={15} className="text-amber-500 animate-pulse" />
          Daily Smart Goals
          <span className="text-[9px] bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 px-1.5 py-0.2 rounded-full font-black uppercase">
            🎯 New
          </span>
        </button>

        <button
          onClick={() => { setActiveTab('free-recall' as any); setReadingNote(null); }}
          className={cn(
            "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 relative cursor-pointer",
            (activeTab as any) === 'free-recall' 
              ? "border-indigo-500 text-indigo-500" 
              : "border-transparent opacity-60 hover:opacity-100"
          )}
        >
          <Brain size={15} className="text-indigo-500 animate-pulse" />
          Free Recall Practice
          <span className="text-[9px] bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 px-1.5 py-0.2 rounded-full font-black uppercase">
            🧠 Active Retrieval
          </span>
        </button>

        <button
          onClick={() => { setActiveTab('metacognition' as any); setReadingNote(null); }}
          className={cn(
            "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 relative cursor-pointer",
            (activeTab as any) === 'metacognition' 
              ? "border-indigo-500 text-indigo-500" 
              : "border-transparent opacity-60 hover:opacity-100"
          )}
        >
          <BarChart3 size={15} className="text-emerald-500" />
          Metacognition
          <span className="text-[9px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 px-1.5 py-0.2 rounded-full font-black uppercase">
            📊 Calibration
          </span>
        </button>

        <button
          onClick={() => { setActiveTab('learning-style' as any); setReadingNote(null); }}
          className={cn(
            "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 relative cursor-pointer",
            (activeTab as any) === 'learning-style' 
              ? "border-indigo-500 text-indigo-500" 
              : "border-transparent opacity-60 hover:opacity-100"
          )}
        >
          <Sliders size={15} className="text-cyan-500" />
          Learning Style (VARK)
          <span className="text-[9px] bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border border-cyan-500/20 px-1.5 py-0.2 rounded-full font-black uppercase">
            ⚡ Adaptive
          </span>
        </button>

        {subject.toLowerCase() === 'chemistry' && (
          <button
            onClick={() => { setActiveTab('periodic-table'); setReadingNote(null); }}
            className={cn(
              "py-4 px-4 sm:px-6 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 relative cursor-pointer",
              activeTab === 'periodic-table' 
                ? "border-indigo-500 text-indigo-500" 
                : "border-transparent opacity-60 hover:opacity-100"
            )}
          >
            <Atom size={15} className="text-indigo-500 animate-spin-slow" />
            Periodic Table Overlay
            <span className="text-[9px] bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 px-1.5 py-0.2 rounded-full font-black uppercase">
              🔬 Interactive
            </span>
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-6 min-h-0">
        {activeTab === 'syllabus' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
            {/* Chapters Left Rail */}
            <div className="lg:col-span-5 flex flex-col gap-3 overflow-y-auto max-h-[70vh] pr-2">
              {(subject.toLowerCase() === 'mathematics' || subject.toLowerCase() === 'physics') && (
                <div className="p-4 rounded-xl border dark:bg-slate-800/20 dark:border-slate-800 bg-indigo-50/10 border-indigo-100 flex flex-col gap-2 mb-2">
                  <div className="flex items-center gap-1.5">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                    </span>
                    <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                      Mixed Practice Session Ready
                    </span>
                  </div>
                  <p className="text-xs opacity-80 leading-relaxed">
                    Auto-mix concepts from studied chapters to build resilient long-term retrieval strength!
                  </p>
                  <button
                    onClick={() => { setActiveTab('mixed-practice' as any); setReadingNote(null); }}
                    className="w-full py-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-indigo-500/10"
                  >
                    <Brain size={14} />
                    Launch Mixed Practice Exam Prep
                  </button>
                </div>
              )}

              {/* Active Topic Dropdown */}
              <div className="p-4 rounded-xl border mb-2 dark:bg-slate-800/40 dark:border-slate-800/80 bg-slate-50 border-slate-200/60">
                <div className="text-xs font-black uppercase tracking-wider text-indigo-500 mb-2 flex items-center gap-1.5">
                  <FileText size={14} className="animate-pulse text-indigo-500" /> Lessons
                </div>
                <select
                  className={cn(
                    "w-full p-2.5 border rounded-lg text-sm cursor-pointer outline-none transition-all font-bold",
                    theme === 'dark' 
                      ? "bg-slate-800 border-slate-705 text-white hover:border-indigo-505" 
                      : "bg-white border-slate-200 text-slate-800 hover:border-indigo-300 focus:border-indigo-400"
                  )}
                  value={selectedChapter || ''}
                  onChange={(e) => {
                    const selectedVal = e.target.value;
                    handleSelectChapter(selectedVal);
                  }}
                >
                  {chapters.map((t: string) => (
                    <option key={t} value={t}>
                      {TOPIC_ICONS[t] || '📐'} {t.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                    </option>
                  ))}
                </select>

                {/* Linked Topic Navigator (User Request) */}
                {selectedChapter && chapters.length > 0 && (() => {
                  // Helper function to extract subtopics for the given chapter/lesson
                  const getSubtopicsForChapter = (ch: string): string[] | undefined => {
                    if (!ch) return undefined;
                    const lower = ch.toLowerCase();
                    if (lower.includes('relations and functions')) return RELATIONS_FUNCTIONS_SUBTOPICS;
                    if (lower.includes('inverse trigonometric')) return INVERSE_TRIGONOMETRIC_FUNCTIONS_SUBTOPICS;
                    if (lower.includes('matrices')) return MATRICES_SUBTOPICS;
                    if (lower.includes('continuity') || lower.includes('differentiability')) return CONTINUITY_DIFFERENTIABILITY_SUBTOPICS;
                    if (lower.includes('exponential') || lower.includes('logarithmic')) return EXPONENTIAL_LOGARITHMIC_MEAN_VALUE_SUBTOPICS;
                    if (lower.includes('applications of integral') || lower.includes('area under')) return APPLICATIONS_OF_INTEGRALS_SUBTOPICS;
                    if (lower.includes('cost') || lower.includes('revenue') || lower.includes('elasticity') || lower.includes('marginal cost')) return APPLICATION_DERIVATIVES_ECONOMICS_SUBTOPICS;
                    if (lower.includes('application') || lower.includes('derivative')) return APPLICATION_DERIVATIVES_SUBTOPICS;
                    if (lower.includes('integral')) return INTEGRATION_SUBTOPICS;
                    if (lower.includes('differential equation')) return DIFFERENTIAL_EQUATIONS_SUBTOPICS;
                    if (lower.includes('probab')) return PROBABILITY_SUBTOPICS;
                    if (lower.includes('regression') || lower.includes('correlation')) return REGRESSION_SUBTOPICS;
                    if (lower.includes('vector')) return VECTORS_SUBTOPICS;
                    if (lower.includes('linear programming') || lower.includes('lpp')) return LINEAR_PROGRAMMING_SUBTOPICS;
                    if (lower.includes('three dimensional geometry') || lower.includes('three-dimensional') || lower.includes('3d geometry')) return THREE_DIMENSIONAL_GEOMETRY_SUBTOPICS;
                    if (lower.includes('determinant')) return DETERMINANTS_SUBTOPICS;
                    
                    if (lower.includes('python revision')) return PYTHON_REVISION_TOUR_SUBTOPICS;
                    if (lower.includes('functions')) return FUNCTIONS_SUBTOPICS;
                    if (lower.includes('file handling')) return FILE_HANDLING_SUBTOPICS;
                    if (lower.includes('data structures')) return DATA_STRUCTURES_CS_SUBTOPICS;
                    if (lower.includes('computer networks')) return COMPUTER_NETWORKS_CS_SUBTOPICS;
                    if (lower.includes('database management')) return DATABASE_MANAGEMENT_CS_SUBTOPICS;
                    if (lower.includes('interface python sql')) return INTERFACE_PYTHON_SQL_SUBTOPICS;
                    if (lower.includes('societal impacts')) return SOCIETAL_IMPACTS_SUBTOPICS;
                    
                    if (lower.includes('electric charge') || lower.includes('electric charges') || lower === '1. electric charges and field') return ELECTRIC_CHARGES_SUBTOPICS;
                    if (lower.includes('gauss')) return GAUSS_THEOREM_SUBTOPICS;
                    if (lower.includes('potential')) return ELECTRIC_POTENTIAL_SUBTOPICS;
                    if (lower.includes('capacitor') || lower.includes('dielectric')) return CAPACITORS_DIELECTRICS_SUBTOPICS;
                    if (lower.includes('resistance') || lower.includes('ohm')) return ELECTRIC_RESISTANCE_SUBTOPICS;
                    if (lower.includes('dc circuit') || lower.includes('kirchhoff') || lower.includes('potentiometer')) return DC_CIRCUITS_SUBTOPICS;
                    if (lower.includes('moving charge') && !lower.includes('earth')) return MOVING_CHARGES_SUBTOPICS;
                    if (lower.includes('torque') || lower.includes('galvanometer')) return TORQUE_CURRENT_LOOP_SUBTOPICS;
                    if (lower.includes('earth') || lower.includes('terrestrial magnetism')) return EARTH_MAGNETISM_SUBTOPICS;
                    if (lower.includes('substance') || lower.includes('diamagnetic') || lower.includes('ferromagnetic')) return MAGNETIC_SUBSTANCES_SUBTOPICS;
                    if (lower.includes('induction') || lower.includes('faraday')) return ELECTROMAGNETIC_INDUCTION_SUBTOPICS;
                    if (lower.includes('alternating current') || lower.includes('ac circuit') || lower.includes('transformer')) return ALTERNATING_CURRENT_SUBTOPICS;
                    if (lower.includes('electromagnetic wave') || lower.includes('em wave') || lower.includes('spectrum')) return ELECTROMAGNETIC_WAVES_SUBTOPICS;
                    if (lower.includes('ray optics') || lower.includes('optical instrument') || lower.includes('telescope') || lower.includes('prism')) return RAY_OPTICS_SUBTOPICS;
                    if (lower.includes('wave optics') || lower.includes('huygen') || lower.includes('interference') || lower.includes('diffraction') || lower.includes('polarization')) return WAVE_OPTICS_SUBTOPICS;
                    if (lower.includes('dual nature') || lower.includes('radiation') || lower.includes('photoelectric') || lower.includes('matter wave')) return DUAL_NATURE_SUBTOPICS;
                    if (lower.includes('atoms')) return ATOMS_SUBTOPICS;
                    if (lower.includes('nuclei') || lower.includes('radioactivity') || lower.includes('mass defect') || lower.includes('binding energy')) return NUCLEI_SUBTOPICS;
                    if (lower.includes('communication') || lower.includes('bandwidth')) return COMMUNICATION_SYSTEMS_LESSON_SUBTOPICS;
                    if (lower.includes('logic gate') || lower.includes('de morgan')) return LOGIC_GATES_SUBTOPICS;
                    if (lower.includes('transistor') || lower.includes('amplifier')) return JUNCTION_TRANSISTORS_SUBTOPICS;
                    if (lower.includes('diode') || lower.includes('led')) return SEMICONDUCTOR_DIODES_SUBTOPICS;
                    if (lower.includes('rectifier')) return SEMICONDUCTOR_ELECTRONICS_LESSON_SUBTOPICS;
                    if (lower.includes('fission') || lower.includes('fusion')) return NUCLEAR_FISSION_FUSION_SUBTOPICS;
                    if (lower.includes('mass-energy') || lower.includes('pair production')) return MASS_ENERGY_BINDING_ENERGY_SUBTOPICS;
                    if (lower.includes('radioactivity') || lower.includes('half-life')) return RADIOACTIVITY_SUBTOPICS;
                    if (lower.includes('nuclear structure') || lower.includes('binding energy per nucleon')) return NUCLEAR_STRUCTURE_SUBTOPICS;
                    if (lower.includes('bohr') || lower.includes('hydrogen spectrum') || lower.includes('origin of spectra')) return ATOMS_BOHR_SPECTRUM_SUBTOPICS;
                    if (lower.includes('x-ray') || lower.includes('coolidge') || lower.includes('moseley')) return X_RAYS_SUBTOPICS;
                    if (lower.includes('matter wave') || lower.includes('de broglie') || lower.includes('davisson')) return MATTER_WAVES_SUBTOPICS;
                    if (lower.includes('photoelectric') || lower.includes('work function') || lower.includes('stopping potential')) return PHOTOELECTRIC_EFFECT_SUBTOPICS;
                    if (lower.includes('polarization') || lower.includes('brewster') || lower.includes('malus') || lower.includes('polaroid')) return POLARIZATION_OF_LIGHT_SUBTOPICS;
                    if (lower.includes('diffraction') || lower.includes('single slit')) return DIFFRACTION_OF_LIGHT_SUBTOPICS;
                    if (lower.includes('interference') || lower.includes('double slit') || lower.includes('ydse') || lower.includes('fringe')) return INTERFERENCE_OF_LIGHT_SUBTOPICS;
                    if (lower.includes('huygen') || lower.includes('wavefront') || lower.includes('wave nature')) return WAVE_NATURE_HUYGENS_SUBTOPICS;
                    if (lower.includes('microscope') || lower.includes('telescope') || lower.includes('optical instrument')) return OPTICAL_INSTRUMENTS_SUBTOPICS;
                    if (lower.includes('prism') || lower.includes('dispersion') || lower.includes('minimum deviation')) return REFRACTION_DISPERSION_PRISM_SUBTOPICS;
                    if (lower.includes('spherical surface') || lower.includes('lenses') || lower.includes('lens maker')) return REFRACTION_SPHERICAL_SURFACES_LENSES_SUBTOPICS;
                    if (lower.includes('refraction') || lower.includes('total internal reflection') || lower.includes('optical fiber') || lower.includes('snell')) return REFRACTION_PLANE_INTERFACE_SUBTOPICS;
                    if (lower.includes('reflection') || lower.includes('spherical mirror') || lower.includes('concave mirror') || lower.includes('convex mirror')) return REFLECTION_OF_LIGHT_SUBTOPICS;
                    if (lower.includes('communication') || lower.includes('modulation') || lower.includes('amplitude') || lower.includes('bandwidth')) return COMMUNICATION_SYSTEMS_SUBTOPICS;
                    if (lower.includes('semiconductor') || lower.includes('logic gate') || lower.includes('transistor') || lower.includes('diode')) return SEMICONDUCTOR_ELECTRONICS_SUBTOPICS;
                    if (lower.includes('nuclei') || lower.includes('radioactivity') || lower.includes('mass defect') || lower.includes('binding energy')) return NUCLEI_SUBTOPICS;
                    if (lower.includes('atoms') || lower.includes('rutherford') || lower.includes('bohr') || lower.includes('hydrogen spectrum')) return ATOMS_SUBTOPICS;
                    if (lower.includes('dual nature') || lower.includes('radiation') || lower.includes('photoelectric') || lower.includes('matter wave')) return DUAL_NATURE_SUBTOPICS;
                    if (lower.includes('wave optics') || lower.includes('huygen') || lower.includes('interference') || lower.includes('diffraction') || lower.includes('polarization')) return WAVE_OPTICS_SUBTOPICS;
                    if (lower.includes('ray optics') || lower.includes('optical instrument') || lower.includes('telescope') || lower.includes('prism')) return RAY_OPTICS_SUBTOPICS;
                    if (lower.includes('electromagnetic wave') || lower.includes('em wave') || lower.includes('spectrum')) return ELECTROMAGNETIC_WAVES_SUBTOPICS;
                    if (lower.includes('alternating current') || lower.includes('ac circuit') || lower.includes('transformer')) return ALTERNATING_CURRENT_SUBTOPICS;
                    if (lower.includes('induction') || lower.includes('faraday')) return ELECTROMAGNETIC_INDUCTION_SUBTOPICS;
                    if (lower.includes('substance') || lower.includes('diamagnetic') || lower.includes('ferromagnetic')) return MAGNETIC_SUBSTANCES_SUBTOPICS;
                    if (lower.includes('earth') || lower.includes('terrestrial magnetism')) return EARTH_MAGNETISM_SUBTOPICS;
                    if (lower.includes('torque') || lower.includes('galvanometer')) return TORQUE_CURRENT_LOOP_SUBTOPICS;
                    
                    if (lower.includes('bricks') || lower.includes('beads') || lower.includes('bones')) return BRICKS_BEADS_BONES_SUBTOPICS;
                    if (lower.includes('kings') || lower.includes('farmers') || lower.includes('towns')) return KINGS_FARMERS_TOWNS_SUBTOPICS;
                    if (lower.includes('kinship') || lower.includes('caste') || lower.includes('class')) return KINSHIP_CASTE_CLASS_SUBTOPICS;
                    if (lower.includes('thinkers') || lower.includes('beliefs') || lower.includes('buildings')) return THINKERS_BELIEFS_BUILDINGS_SUBTOPICS;
                    if (lower.includes('eyes') || lower.includes('travellers')) return THROUGH_EYES_TRAVELLERS_SUBTOPICS;
                    if (lower.includes('bhakti') || lower.includes('sufi')) return BHAKTI_SUFI_TRADITIONS_SUBTOPICS;
                    if (lower.includes('vijayanagara')) return VIJAYANAGARA_EMPIRE_SUBTOPICS;
                    if (lower.includes('peasants') || lower.includes('zamindars') || lower.includes('state')) return PEASANTS_ZAMINDARS_STATE_SUBTOPICS;
                    if (lower.includes('colonialism') || lower.includes('countryside')) return COLONIALISM_COUNTRYSIDE_SUBTOPICS;
                    if (lower.includes('rebels') || lower.includes('raj')) return REBELS_AND_RAJ_SUBTOPICS;
                    if (lower.includes('mahatma gandhi') || lower.includes('movement')) return MAHATMA_GANDHI_MOVEMENT_SUBTOPICS;
                    if (lower.includes('framing') || lower.includes('constitution')) return FRAMING_CONSTITUTION_SUBTOPICS;
                    
                    if (lower.includes('solution')) return SOLUTIONS_CBSE_SUBTOPICS;
                    if (lower.includes('electrochemistry')) return ELECTROCHEMISTRY_CBSE_SUBTOPICS;
                    if (lower.includes('kinetics')) return CHEMICAL_KINETICS_CBSE_SUBTOPICS;
                    if (lower.includes('d- and f-block') || lower.includes('d- & f-block') || lower.includes('d-block') || lower.includes('f-block')) return D_AND_F_BLOCK_CBSE_SUBTOPICS;
                    if (lower.includes('coordination')) return COORDINATION_COMPOUNDS_CBSE_SUBTOPICS;
                    if (lower.includes('haloalkane') || lower.includes('haloarene')) return HALOALKANES_HALOARENES_CBSE_SUBTOPICS;
                    if (lower.includes('alcohol') || lower.includes('phenol') || lower.includes('ether')) return ALCOHOLS_PHENOLS_ETHERS_CBSE_SUBTOPICS;
                    if (lower.includes('aldehyde') || lower.includes('ketone') || lower.includes('carboxylic')) return ALDEHYDES_KETONES_CARBOXYLIC_CBSE_SUBTOPICS;
                    if (lower.includes('amine')) return AMINES_CBSE_SUBTOPICS;
                    if (lower.includes('biomolecule')) return BIOMOLECULES_CBSE_SUBTOPICS;
                    return undefined;
                  };

                  // Parse the active subtopic name from activeTopic state (format: "SubtopicName - ChapterName")
                  let activeSubName = "";
                  if (activeTopic) {
                    if (activeTopic.includes(' - ')) {
                      activeSubName = activeTopic.split(' - ')[0].trim();
                    } else {
                      activeSubName = activeTopic.trim();
                    }
                  }

                  const activeSubtopics = getSubtopicsForChapter(selectedChapter);
                  let currentIdx = -1;
                  let isSubtopicSelected = false;

                  if (activeSubName && activeSubtopics) {
                    currentIdx = activeSubtopics.findIndex(
                      (sub: string) => sub.toLowerCase() === activeSubName.toLowerCase() ||
                                       sub.toLowerCase().includes(activeSubName.toLowerCase()) ||
                                       activeSubName.toLowerCase().includes(sub.toLowerCase())
                    );
                    if (currentIdx !== -1) {
                      isSubtopicSelected = true;
                    }
                  }

                  let prevCh: string | null = null;
                  let nextCh: string | null = null;
                  const chIdx = chapters.findIndex((ch: string) => ch === selectedChapter);
                  if (chIdx > 0) prevCh = chapters[chIdx - 1];
                  if (chIdx >= 0 && chIdx < chapters.length - 1) nextCh = chapters[chIdx + 1];

                  let hasPrev = false;
                  let hasNext = false;
                  let prevLabel = "";
                  let nextLabel = "";
                  let countText = "";
                  let navigatorTitle = "🔗 Linked Topic Navigator";

                  if (isSubtopicSelected && activeSubtopics) {
                    // Subtopic mode
                    hasPrev = true; // Always allow (wraps to previous chapter's subtopics)
                    hasNext = true; // Always allow (wraps to next chapter's subtopics)
                    prevLabel = currentIdx > 0 ? activeSubtopics[currentIdx - 1] : (prevCh ? `Last of ${prevCh}` : "Start of Syllabus");
                    nextLabel = currentIdx < activeSubtopics.length - 1 ? activeSubtopics[currentIdx + 1] : (nextCh ? `First of ${nextCh}` : "End of Syllabus");
                    navigatorTitle = `🔗 Linked Topic Navigator (${selectedChapter})`;
                    countText = `${currentIdx + 1} of ${activeSubtopics.length} subtopics`;
                    
                    // Disable wraps if there is no prevCh/nextCh
                    if (currentIdx === 0 && !prevCh) hasPrev = false;
                    if (currentIdx === activeSubtopics.length - 1 && !nextCh) hasNext = false;
                  } else {
                    // General chapter mode
                    hasPrev = !!prevCh;
                    hasNext = !!nextCh;
                    prevLabel = prevCh || "";
                    nextLabel = nextCh || "";
                    countText = `${chIdx >= 0 ? chIdx + 1 : 0} of ${chapters.length} chapters`;
                  }

                  return (
                    <div className="mt-3.5 pt-3.5 border-t border-slate-200/60 dark:border-slate-700/50 flex flex-col gap-2">
                      <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider flex items-center justify-between">
                        <span className="truncate max-w-[210px]" title={navigatorTitle}>{navigatorTitle}</span>
                        <span className="font-mono text-indigo-500 dark:text-indigo-400 shrink-0">
                          {countText}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-1.5">
                        <button
                          type="button"
                          disabled={!hasPrev}
                          onClick={() => {
                            if (isSubtopicSelected && activeSubtopics) {
                              if (currentIdx > 0) {
                                // Go to previous subtopic
                                const prevSub = activeSubtopics[currentIdx - 1];
                                onStudyLesson(`${prevSub} - ${selectedChapter}`, selectedChapter, chosenDepth);
                              } else if (prevCh) {
                                // Wrap to previous chapter's last subtopic
                                handleSelectChapter(prevCh);
                                const prevSubs = getSubtopicsForChapter(prevCh);
                                if (prevSubs && prevSubs.length > 0) {
                                  const lastSub = prevSubs[prevSubs.length - 1];
                                  onStudyLesson(`${lastSub} - ${prevCh}`, prevCh, chosenDepth);
                                } else {
                                  onStudyLesson(prevCh, prevCh, chosenDepth);
                                }
                              }
                            } else if (prevCh) {
                              handleSelectChapter(prevCh);
                            }
                          }}
                          className={cn(
                            "flex-1 py-1.5 px-2 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer select-none truncate max-w-[100px]",
                            hasPrev
                              ? "bg-slate-900 dark:bg-slate-800 text-slate-100 border-slate-700/80 hover:bg-indigo-600 hover:text-white hover:border-indigo-500"
                              : "bg-slate-100 dark:bg-slate-900/30 text-slate-300 dark:text-slate-700 border-slate-200 dark:border-slate-800/40 cursor-not-allowed opacity-50"
                          )}
                          title={prevLabel ? `Prev: ${prevLabel}` : 'No previous topic'}
                        >
                          <ChevronLeft size={13} className="shrink-0" />
                          <span>Prev</span>
                        </button>
                        
                        <button
                          type="button"
                          onClick={() => {
                            if (showNotification) {
                              const activeLabelText = isSubtopicSelected ? activeSubName : selectedChapter;
                              showNotification(`Active study unit: ${activeLabelText}`, 'info');
                            }
                          }}
                          className="px-2 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/40 text-[10px] font-extrabold flex-1 truncate select-none text-center"
                        >
                          {isSubtopicSelected ? activeSubName : selectedChapter.replace(/_/g, ' ')}
                        </button>

                        <button
                          type="button"
                          disabled={!hasNext}
                          onClick={() => {
                            if (isSubtopicSelected && activeSubtopics) {
                              if (currentIdx < activeSubtopics.length - 1) {
                                // Go to next subtopic
                                const nextSub = activeSubtopics[currentIdx + 1];
                                onStudyLesson(`${nextSub} - ${selectedChapter}`, selectedChapter, chosenDepth);
                              } else if (nextCh) {
                                // Wrap to next chapter's first subtopic
                                handleSelectChapter(nextCh);
                                const nextSubs = getSubtopicsForChapter(nextCh);
                                if (nextSubs && nextSubs.length > 0) {
                                  const firstSub = nextSubs[0];
                                  onStudyLesson(`${firstSub} - ${nextCh}`, nextCh, chosenDepth);
                                } else {
                                  onStudyLesson(nextCh, nextCh, chosenDepth);
                                }
                              }
                            } else if (nextCh) {
                              handleSelectChapter(nextCh);
                            }
                          }}
                          className={cn(
                            "flex-1 py-1.5 px-2 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer select-none truncate max-w-[100px]",
                            hasNext
                              ? "bg-slate-900 dark:bg-slate-800 text-slate-100 border-slate-700/80 hover:bg-indigo-600 hover:text-white hover:border-indigo-500"
                              : "bg-slate-100 dark:bg-slate-900/30 text-slate-300 dark:text-slate-700 border-slate-200 dark:border-slate-800/40 cursor-not-allowed opacity-50"
                          )}
                          title={nextLabel ? `Next: ${nextLabel}` : 'No next topic'}
                        >
                          <span>Next</span>
                          <ChevronRight size={13} className="shrink-0" />
                        </button>
                      </div>
                    </div>
                  );
                })()}

                {/* Visual Chapter Roadmap Component (User Request) */}
                {selectedChapter && (() => {
                  const roadmapLessons = getLessonsForChapter(selectedChapter, chosenDepth);
                  if (roadmapLessons.length === 0) return null;

                  const completedCount = roadmapLessons.filter(l => !!completedLessons[`${selectedChapter}_${l.id}`]).length;
                  const progressPct = Math.round((completedCount / roadmapLessons.length) * 100);

                  return (
                    <div className="mt-4 p-4 rounded-xl border dark:bg-slate-800/30 dark:border-slate-800/80 bg-slate-50 border-slate-200/60">
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <div className="text-[10px] font-black uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
                          <Compass size={14} className="text-indigo-500" />
                          <span>Chapter Progress Roadmap</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full">
                          {progressPct}% Done
                        </span>
                      </div>

                      {/* Micro Progress Bar */}
                      <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden mb-4">
                        <div 
                          className="h-full bg-indigo-500 transition-all duration-500" 
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>

                      {/* Vertical Node Connection Line */}
                      <div className="relative pl-2 space-y-4">
                        {/* Connecting Line */}
                        <div className="absolute left-[13px] top-2 bottom-6 w-0.5 bg-slate-200 dark:bg-slate-800" />

                        {roadmapLessons.map((les, lIdx) => {
                          const isLesCompleted = !!completedLessons[`${selectedChapter}_${les.id}`];
                          // The "current active" lesson on the roadmap can be the first incomplete lesson
                          const isCurrent = roadmapLessons.findIndex(l => !completedLessons[`${selectedChapter}_${l.id}`]) === lIdx || (completedCount === roadmapLessons.length && lIdx === roadmapLessons.length - 1);

                          return (
                            <div key={les.id} className="relative flex items-start gap-3 group">
                              {/* Node Circle */}
                              <button
                                type="button"
                                onClick={() => {
                                  onStudyLesson(les.title, selectedChapter, chosenDepth);
                                  if (showNotification) {
                                    showNotification(`Switching to Roadmap Study Lesson: ${les.title}`, 'success');
                                  }
                                }}
                                className={cn(
                                  "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all cursor-pointer z-10 shrink-0 select-none shadow-sm",
                                  isLesCompleted
                                    ? "bg-emerald-500 border-emerald-400 text-white hover:bg-emerald-600"
                                    : isCurrent
                                      ? "bg-indigo-600 border-indigo-400 text-white ring-4 ring-indigo-500/20 hover:bg-indigo-700"
                                      : "bg-slate-100 dark:bg-slate-900 border-slate-300 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:border-slate-400"
                                )}
                                title={`Milestone ${lIdx + 1}: ${les.title} (${isLesCompleted ? 'Completed' : isCurrent ? 'Current Active Step' : 'Not Started'})`}
                              >
                                {isLesCompleted ? (
                                  <span className="text-[10px] font-black">✓</span>
                                ) : (
                                  <span className="text-[9px] font-bold">{lIdx + 1}</span>
                                )}
                              </button>

                              {/* Label Details */}
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1">
                                  <button
                                    type="button"
                                    onClick={() => onStudyLesson(les.title, selectedChapter, chosenDepth)}
                                    className={cn(
                                      "text-xs font-bold truncate hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-left cursor-pointer",
                                      isCurrent ? "text-indigo-600 dark:text-indigo-400" : "text-slate-700 dark:text-slate-300"
                                    )}
                                  >
                                    {les.title}
                                  </button>
                                  
                                  {/* Direct Roadmap Quick Complete toggle */}
                                  <button
                                    type="button"
                                    onClick={() => toggleLessonComplete(les.id)}
                                    className={cn(
                                      "w-3.5 h-3.5 rounded border flex items-center justify-center transition-colors shrink-0 cursor-pointer ml-1.5",
                                      isLesCompleted
                                        ? "bg-emerald-500 border-emerald-500 text-white"
                                        : "border-slate-300 dark:border-slate-700 hover:border-slate-400"
                                    )}
                                    title={isLesCompleted ? "Mark incomplete" : "Mark complete"}
                                  >
                                    {isLesCompleted && <span className="text-[8px] font-black">✓</span>}
                                  </button>
                                </div>
                                <p className="text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
                                  {les.description}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })()}
              </div>

              <div className="mb-3">
                <input
                  type="text"
                  placeholder="Filter chapters..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={cn(
                    "w-full p-2.5 rounded-lg text-sm border outline-none transition-all",
                    theme === 'dark'
                      ? "bg-slate-800/60 border-slate-700 text-white placeholder-slate-500"
                      : "bg-white border-slate-200 text-slate-800 placeholder-slate-400"
                  )}
                />
              </div>

              <div className="text-xs font-bold uppercase tracking-wider opacity-60 mb-2">
                Syllabus Chapters ({chapters.filter((c: string) => c.toLowerCase().includes(searchTerm.toLowerCase())).length})
              </div>
              
              {(() => {
                const filtered = chapters.filter((c: string) => c.toLowerCase().includes(searchTerm.toLowerCase()));
                
                // Grouping chapters
                const groups: Record<string, string[]> = {
                  physical_inorganic: [],
                  organic: [],
                  biomolecules: [],
                  reproduction: [],
                  genetics: [],
                  ecology: [],
                  biology: [],
                  general: []
                };

                filtered.forEach((ch: string) => {
                  const cat = getChapterCategory(ch);
                  if (groups[cat.id]) {
                      groups[cat.id].push(ch);
                  } else {
                      groups['general'].push(ch);
                  }
                });

                const categories = [
                  { id: 'reproduction', name: 'Reproduction', icon: '🌱', count: groups.reproduction.length },
                  { id: 'genetics', name: 'Genetics & Evolution', icon: '🧬', count: groups.genetics.length },
                  { id: 'ecology', name: 'Ecology & Environment', icon: '🍃', count: groups.ecology.length },
                  { id: 'biology', name: 'Biology', icon: '🦠', count: groups.biology.length },
                  { id: 'physical_inorganic', name: 'Physical & Inorganic Chemistry', icon: '🧪', count: groups.physical_inorganic.length },
                  { id: 'organic', name: 'Organic Chemistry', icon: '⚗️', count: groups.organic.length },
                  { id: 'biomolecules', name: 'Biomolecules', icon: '🧬', count: groups.biomolecules.length },
                  { id: 'general', name: 'General Syllabus', icon: '📘', count: groups.general.length }
                ].filter(cat => cat.count > 0);

                if (categories.length === 0) {
                  return (
                    <div className="text-center py-6 text-xs text-slate-400 font-semibold">
                      No chapters match the filter.
                    </div>
                  );
                }

                return (
                  <div className="space-y-3">
                    {categories.map(cat => {
                      const isExpanded = expandedCategories[cat.id] !== false;
                      const hasItems = groups[cat.id].length > 0;
                      
                      return (
                        <div 
                          key={cat.id} 
                          className={cn(
                            "rounded-xl border overflow-hidden transition-all shadow-sm",
                            theme === 'dark' 
                              ? "border-slate-800/80 bg-slate-900/30" 
                              : "border-slate-200/80 bg-slate-50/20"
                          )}
                        >
                          {/* Category Header */}
                          <button
                            type="button"
                            onClick={() => setExpandedCategories(prev => ({ ...prev, [cat.id]: !isExpanded }))}
                            className={cn(
                              "w-full flex items-center justify-between p-3 text-xs font-black uppercase tracking-wider transition-colors cursor-pointer select-none border-b",
                              theme === 'dark'
                                ? "bg-slate-900/80 text-slate-300 hover:bg-slate-800/80 border-slate-800/50"
                                : "bg-slate-100/60 text-slate-700 hover:bg-slate-200/50 border-slate-200/50"
                            )}
                          >
                            <div className="flex items-center gap-2">
                              {cat.id === 'reproduction' && <Sprout className="w-4 h-4 text-emerald-500 shrink-0" />}
                              {cat.id === 'genetics' && <Dna className="w-4 h-4 text-indigo-500 shrink-0" />}
                              {cat.id === 'ecology' && <Leaf className="w-4 h-4 text-green-500 shrink-0" />}
                              {cat.id === 'biology' && <Microscope className="w-4 h-4 text-teal-500 shrink-0" />}
                              {cat.id === 'biomolecules' && <Dna className="w-4 h-4 text-purple-500 shrink-0" />}
                              <span className="text-sm leading-none">{cat.icon}</span>
                              <span className="text-left font-bold">{cat.name}</span>
                              <span className={cn(
                                "text-[10px] px-1.5 py-0.5 rounded-full border leading-none font-bold",
                                cat.id === 'organic'
                                  ? "bg-indigo-500/10 text-indigo-500 border-indigo-500/20"
                                  : cat.id === 'biomolecules' || cat.id === 'genetics'
                                    ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                                    : cat.id === 'physical_inorganic'
                                      ? "bg-amber-500/10 text-amber-500 border-amber-500/20"
                                      : "bg-slate-500/10 text-slate-500 border-slate-500/20"
                              )}>
                                {cat.count} Units
                              </span>
                            </div>
                            <div className="text-slate-400 flex-shrink-0 ml-2">
                              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                            </div>
                          </button>

                          {/* Category Children List */}
                          {isExpanded && hasItems && (
                            <div className={cn(
                              "p-2 space-y-1.5",
                              theme === 'dark' ? "bg-slate-950/20" : "bg-white/50"
                            )}>
                              {groups[cat.id].map(chapter => {
                                const isSelected = selectedChapter === chapter;
                                
                                // Calculate Chapter Progress
                                const chapterProgress = (() => {
                                  const curr = getBoardCurriculum(selectedBoard?.nation || 'India', selectedBoard?.acronym || 'CBSE', difficulty) as any;
                                  if (!curr) return 0;
                                  
                                  // Handle both DetailedBoardCurriculum and BoardCurriculum
                                  let chData: any = null;
                                  if (curr.chapters) {
                                    chData = curr.chapters.find((ch: any) => ch.chapterName === chapter || ch.id === chapter);
                                  } else if (curr.subjects && Array.isArray(curr.subjects)) {
                                    const subjData = curr.subjects.find((s: any) => s.subject === subject);
                                    if (subjData && subjData.chapters) {
                                      chData = subjData.chapters.find((ch: any) => ch.chapterName === chapter || ch.id === chapter);
                                    }
                                  }
                                  
                                  if (!chData) return 0;
                                  
                                  const lessons = chData.lessonModules || [];
                                  if (lessons.length === 0) return 0;
                                  
                                  let completedCount = 0;
                                  lessons.forEach((l: any, idx: number) => {
                                    if (completedLessons[`${chapter}_l${idx + 1}`]) {
                                      completedCount++;
                                    }
                                  });
                                  
                                  return Math.round((completedCount / lessons.length) * 100);
                                })();

                                return (
                                  <button
                                    key={chapter}
                                    onClick={() => handleSelectChapter(chapter)}
                                    className={cn(
                                      "w-full text-left p-3 rounded-lg border transition-all flex flex-col gap-2 group cursor-pointer",
                                      isSelected
                                        ? (theme === 'dark' ? "bg-indigo-950/40 border-indigo-500 text-white shadow-sm" : "bg-indigo-50/80 border-indigo-300 text-indigo-900 shadow-sm")
                                        : (theme === 'dark' ? "bg-slate-800/30 border-slate-700/50 hover:bg-slate-800/60 hover:border-slate-600 text-slate-300" : "bg-slate-50/60 border-slate-200/60 hover:bg-slate-100/70 hover:border-slate-300 text-slate-700")
                                    )}
                                  >
                                    <div className="w-full flex items-start justify-between">
                                      <div className="flex-1 pr-2">
                                        <div className="font-bold text-xs leading-tight group-hover:text-indigo-500 transition-colors flex items-center gap-1.5">
                                          {(cat.id === 'reproduction' || chapter.toLowerCase().includes('reproduction')) && <Sprout size={13} className="text-emerald-500 shrink-0" />}
                                          {(cat.id === 'genetics' || chapter.toLowerCase().includes('genetic') || chapter.toLowerCase().includes('evolution')) && <Dna size={13} className="text-indigo-500 shrink-0" />}
                                          {(cat.id === 'ecology' || chapter.toLowerCase().includes('ecology') || chapter.toLowerCase().includes('ecosystem')) && <Leaf size={13} className="text-green-500 shrink-0" />}
                                          {(cat.id === 'biology' || chapter.toLowerCase().includes('biotech') || chapter.toLowerCase().includes('microbe')) && <Microscope size={13} className="text-teal-500 shrink-0" />}
                                          {cat.id === 'biomolecules' && <Dna size={13} className="text-purple-500 shrink-0" />}
                                          <span>{chapter}</span>
                                        </div>
                                        {mode !== 'entrance' && mode !== 'competitive' && (
                                          <div className="text-[10px] opacity-60 mt-1 flex items-center gap-1">
                                            <GraduationCap size={10} />
                                            Level: {difficulty.replace(/_/g, ' ')}
                                          </div>
                                        )}
                                      </div>
                                      <ArrowRight size={13} className={cn(
                                        "transition-transform mt-0.5 opacity-60 flex-shrink-0",
                                        isSelected ? "translate-x-1 opacity-100 text-indigo-500" : "group-hover:translate-x-1 group-hover:opacity-100"
                                      )} />
                                    </div>

                                    {/* Progress Bar */}
                                    <div className="w-full mt-1">
                                      <div className="flex justify-between items-center mb-1">
                                        <span className="text-[9px] font-bold opacity-50 uppercase tracking-tighter">Chapter Progress</span>
                                        <span className="text-[9px] font-black text-indigo-500">{chapterProgress}%</span>
                                      </div>
                                      <div className="w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                                        <motion.div 
                                          initial={{ width: 0 }}
                                          animate={{ width: `${chapterProgress}%` }}
                                          className="h-full bg-indigo-500"
                                        />
                                      </div>
                                    </div>
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>

            {/* Lesson details Right Pane */}
            <div className="lg:col-span-7 flex flex-col gap-4 min-h-0">
              {selectedChapter ? (
                <div className="flex flex-col h-full">
                  <div className="flex flex-wrap justify-between items-center gap-3 border-b pb-4 mb-4 dark:border-slate-800 border-slate-200">
                    <div>
                      <h3 className="text-lg font-bold text-indigo-500 leading-tight">
                        {selectedChapter}
                      </h3>
                      <p className="text-xs opacity-60 mt-0.5">
                        Select a lesson to study or launch an assessment quiz.
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedDoubtChapter(selectedChapter)}
                        className="px-3.5 py-1.5 text-xs bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border border-indigo-500/30 font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
                        title="Open Anonymous Doubt Board for this chapter"
                      >
                        <HelpCircle size={13} />
                        Doubt Board
                      </button>
                      <button
                        onClick={() => onGenerateQuiz(selectedChapter)}
                        className="px-3.5 py-1.5 text-xs bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm shadow-indigo-600/10"
                      >
                        <Lightbulb size={13} />
                        Practice Quiz
                      </button>
                    </div>
                  </div>

                  {/* Study Depth & Rigor Selection */}
                  <div className={cn(
                    "mb-6 p-4 rounded-xl border-2 transition-all space-y-3",
                    theme === 'dark' ? "bg-slate-950/60 border-indigo-950/50" : "bg-indigo-50/20 border-indigo-100/50"
                  )}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Brain className="text-indigo-550 h-4 w-4" />
                        <span className="text-xs font-black uppercase tracking-wider text-indigo-500">
                          Study Session Depth & Rigor Level
                        </span>
                      </div>
                      <span className={cn(
                        "text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border",
                        chosenDepth === 'quick' ? "bg-cyan-50 dark:bg-cyan-950/40 text-cyan-600 dark:text-cyan-400 border-cyan-150" :
                        chosenDepth === 'standard' ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border-indigo-150" :
                        chosenDepth === 'deep' ? "bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 border-purple-150" :
                        "bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border-rose-150 animate-pulse"
                      )}>
                        {chosenDepth === 'quick' && "🚀 Fast Recap / Review"}
                        {chosenDepth === 'standard' && "📘 Full Standard Syllabus"}
                        {chosenDepth === 'deep' && "🧬 Deep Axiomatic Derivation"}
                        {chosenDepth === 'academic' && "👑 MIT/IIT Research Grade"}
                      </span>
                    </div>

                    <p className="text-xs opacity-75 leading-relaxed">
                      {chosenDepth === 'quick' && "Aggregates core definitions, high-level formulae, and dynamic speed quizzing. Perfect for pre-exam cramming/brushing up."}
                      {chosenDepth === 'standard' && "Full-coverage explanations of subject themes, worked examples, and mid-tier quiz checkpoints."}
                      {chosenDepth === 'deep' && "Extracts the complete theoretical foundation, formal algebraic proofs (Q.E.D.), mathematical limits, and rigorous multi-tier solving prompts."}
                      {chosenDepth === 'academic' && "Implements absolute collegiate rigor. Unveils advanced academic research directions, modeling puzzles, and 3 high-intensity exam proofs."}
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                      {(['quick', 'standard', 'deep', 'academic'] as const).map((lvl) => (
                        <button
                          key={lvl}
                          onClick={() => setChosenDepth(lvl)}
                          className={cn(
                            "py-2 px-3 text-xs font-bold rounded-lg border transition-all text-center cursor-pointer capitalize",
                            chosenDepth === lvl
                              ? "bg-indigo-600 text-white border-transparent shadow-sm"
                              : theme === 'dark'
                                ? "bg-slate-800/60 border-slate-705 text-slate-300 hover:bg-slate-800 hover:text-white"
                                : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-850"
                          )}
                        >
                          {lvl === 'quick' ? 'Quick Review' :
                           lvl === 'standard' ? 'Standard Study' :
                           lvl === 'deep' ? 'Deep Proofs' :
                           'Research Grade'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Dynamic lessons control panel */}
                  <div className={cn(
                    "mb-4 p-4 rounded-xl border flex flex-col gap-4",
                    theme === 'dark' ? "bg-slate-905 border-slate-800" : "bg-slate-50 border-slate-200"
                  )}>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-1">
                        <span className="text-xs font-black uppercase tracking-wider text-indigo-500">
                          Syllabus Expansion Controls for {selectedChapter}
                        </span>
                        <p className="text-[11px] opacity-70">
                          The number of study lessons can be scaled as high as you need. Use the controls below to expand or customize the syllabus for {selectedChapter}.
                        </p>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2 border rounded-lg p-1 bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-800">
                          <button
                            onClick={() => {
                              const currentCount = lessonCounts[selectedChapter] ?? 3;
                              if (currentCount > 1) {
                                const newCount = currentCount - 1;
                                setLessonCounts(prev => ({ ...prev, [selectedChapter]: newCount }));
                                showNotification?.(`Reduced course structure to ${newCount} lessons`, 'info');
                              }
                            }}
                            className="p-1 text-slate-400 hover:text-indigo-505 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors cursor-pointer"
                            title="Decrease Lessons"
                            disabled={(lessonCounts[selectedChapter] ?? 3) <= 1}
                          >
                            <Minus size={14} />
                          </button>
                          <span className="text-xs font-black px-2 text-indigo-600 dark:text-indigo-400 min-w-[70px] text-center">
                            {lessonCounts[selectedChapter] ?? 3} Lessons
                          </span>
                          <button
                            onClick={() => {
                              const currentCount = lessonCounts[selectedChapter] ?? 3;
                              const newCount = currentCount + 1;
                              setLessonCounts(prev => ({ ...prev, [selectedChapter]: newCount }));
                              showNotification?.(`Expanded course structure to ${newCount} lessons`, 'success');
                            }}
                            className="p-1 text-slate-400 hover:text-indigo-550 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors cursor-pointer"
                            title="Increase Lessons"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 pt-2 border-t border-dashed border-slate-200 dark:border-slate-800">
                      <button
                        onClick={() => {
                          const currentCount = lessonCounts[selectedChapter] ?? 3;
                          const newCount = currentCount + 1;
                          setLessonCounts(prev => ({ ...prev, [selectedChapter]: newCount }));
                          showNotification?.(`Auto-generated and appended Lesson ${newCount} successfully!`, 'success');
                        }}
                        className="py-1.5 px-3 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Wand2 size={13} />
                        Auto-Generate Lesson
                      </button>

                      <button
                        onClick={() => setIsAddingCustom(!isAddingCustom)}
                        className="py-1.5 px-3 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus size={13} />
                        {isAddingCustom ? 'Cancel Custom Lesson' : 'Add Custom Lesson'}
                      </button>
                    </div>

                    {isAddingCustom && (
                      <div className="p-3 bg-white dark:bg-slate-800 border rounded-xl space-y-3 shadow-inner">
                        <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                          Create Custom Study Lesson for {selectedChapter}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div className="space-y-1">
                            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Lesson Title</label>
                            <input
                              type="text"
                              placeholder="e.g. Core Proof and Lab Simulations"
                              value={customTitle}
                              onChange={(e) => setCustomTitle(e.target.value)}
                              className="w-full p-2 border rounded-lg text-xs bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 focus:outline-indigo-550"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Duration & Difficulty</label>
                            <div className="grid grid-cols-2 gap-2">
                              <input
                                type="text"
                                placeholder="e.g. 25 mins"
                                value={customDuration}
                                onChange={(e) => setCustomDuration(e.target.value)}
                                className="w-full p-2 border rounded-lg text-xs bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 focus:outline-indigo-550"
                              />
                              <select
                                value={customLevel}
                                onChange={(e) => setCustomLevel(e.target.value)}
                                className="w-full p-2 border rounded-lg text-xs bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 focus:outline-indigo-550"
                              >
                                <option>Basic</option>
                                <option>Intermediate</option>
                                <option>Honors</option>
                                <option>Graduate / Research</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Description</label>
                          <textarea
                            placeholder="Detail what concepts, formulations or practices are targeted in this custom syllabus module..."
                            rows={2}
                            value={customDescription}
                            onChange={(e) => setCustomDescription(e.target.value)}
                            className="w-full p-2 border rounded-lg text-xs bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 focus:outline-indigo-550"
                          />
                        </div>
                        <button
                          onClick={() => {
                            if (!customTitle.trim()) {
                              showNotification?.('Please enter a lesson title', 'error');
                              return;
                            }
                            const newLesson = {
                              id: `custom-${Date.now()}`,
                              title: customTitle,
                              description: customDescription || 'Custom structured user-defined lesson module.',
                              duration: customDuration || '25 mins',
                              level: customLevel
                            };
                            setCustomLessons(prev => ({
                              ...prev,
                              [selectedChapter]: [...(prev[selectedChapter] || []), newLesson]
                            }));
                            setCustomTitle('');
                            setCustomDescription('');
                            setIsAddingCustom(false);
                            showNotification?.(`Custom lesson "${customTitle}" added successfully!`, 'success');
                          }}
                          className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer"
                        >
                          Add Custom Lesson to Syllabus
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    {getLessonsForChapter(selectedChapter, chosenDepth).map((lesson, idx) => {
                      const isCompleted = !!completedLessons[`${selectedChapter}_${lesson.id}`];
                      const activeSubtopics = (lesson as any).subtopics || 
                        (selectedChapter.toLowerCase().includes('physical world') || selectedChapter.toLowerCase().includes('measurement') ? PHYSICAL_WORLD_MEASUREMENT_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('kinematics') ? KINEMATICS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('laws of motion') ? LAWS_OF_MOTION_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('work, energy') || selectedChapter.toLowerCase().includes('work, power') ? WORK_ENERGY_POWER_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('system of particles') || selectedChapter.toLowerCase().includes('rigid body') ? SYSTEM_PARTICLES_RIGID_BODY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('gravitation') ? GRAVITATION_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('bulk matter') ? PROPERTIES_BULK_MATTER_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('thermodynamics') ? THERMODYNAMICS_PHYSICS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('kinetic theory') || selectedChapter.toLowerCase().includes('perfect gases') ? KINETIC_THEORY_GASES_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('oscillations') || selectedChapter.toLowerCase().includes('waves') ? OSCILLATIONS_WAVES_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('some basic concepts of chemistry') ? SOME_BASIC_CONCEPTS_CHEM_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('structure of atom') ? STRUCTURE_OF_ATOM_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('classification of elements') || selectedChapter.toLowerCase().includes('periodicity') ? CLASSIFICATION_ELEMENTS_PERIODICITY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('chemical bonding') ? CHEMICAL_BONDING_MOLECULAR_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('chemical thermodynamics') ? CHEMICAL_THERMODYNAMICS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('equilibrium') ? EQUILIBRIUM_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('redox') ? REDOX_REACTIONS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('basic principles and techniques') ? ORGANIC_CHEMISTRY_BASIC_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('hydrocarbon') ? HYDROCARBONS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('data representation') || selectedChapter.toLowerCase().includes('boolean algebra') ? DATA_REP_BOOLEAN_ALG_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('computer hardware') || selectedChapter.toLowerCase().includes('basic architecture') ? HARDWARE_ARCHITECTURE_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('introduction to java') || selectedChapter.toLowerCase().includes('oop concepts') ? JAVA_OOP_CONCEPTS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('control structures') || selectedChapter.toLowerCase().includes('function design') ? CONTROL_STRUCTURES_FUNCTIONS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('primitive data structures') || selectedChapter.toLowerCase().includes('arrays and strings') ? ARRAYS_STRINGS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('advanced object-oriented') || selectedChapter.toLowerCase().includes('advanced oop') ? ADVANCED_OOP_FEATURES_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('growth of nationalism') ? GROWTH_OF_NATIONALISM_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('emergence of the radicals') || selectedChapter.toLowerCase().includes('swadeshi') ? EMERGENCE_OF_RADICALS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('first world war and nationalist politics') ? WWI_NATIONALIST_POLITICS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('gandhian era') || selectedChapter.toLowerCase().includes('mass nationalism') ? GANDHIAN_ERA_MASS_NATIONALISM_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('impact of the first world war') || selectedChapter.toLowerCase().includes('peace settlements') ? IMPACT_WWI_PEACE_SETTLEMENTS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('great depression') || selectedChapter.toLowerCase().includes('totalitarianism') ? GREAT_DEPRESSION_TOTALITARIANISM_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('world war ii and the collapse') || selectedChapter.toLowerCase().includes('collective security') ? WWII_COLLAPSE_COLLECTIVE_SECURITY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('rise of communism in china') || selectedChapter.toLowerCase().includes('china') ? RISE_OF_COMMUNISM_CHINA_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('project work') && selectedChapter.toLowerCase().includes('history') ? PROJECT_WORK_HISTORY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('structure of the earth') || selectedChapter.toLowerCase().includes('endogenetic') ? EARTH_STRUCTURE_ENDOGENETIC_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('exogenetic processes') || selectedChapter.toLowerCase().includes('landform development') ? EXOGENETIC_LANDFORMS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('atmosphere') || selectedChapter.toLowerCase().includes('hydrosphere') ? ATMOSPHERE_HYDROSPHERE_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('population dynamics') || selectedChapter.toLowerCase().includes('human settlements') ? POPULATION_SETTLEMENTS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('physical framework') || selectedChapter.toLowerCase().includes('climate of india') ? PHYSICAL_FRAMEWORK_INDIA_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('resource base') || selectedChapter.toLowerCase().includes('environmental issues') ? RESOURCES_ENVIRONMENT_INDIA_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('cartographic') || (selectedChapter.toLowerCase().includes('practical work') && selectedChapter.toLowerCase().includes('geography')) ? PRACTICAL_GEOGRAPHY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('introduction to political science') ? INTRO_POLITICAL_SCIENCE_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('fundamental political concepts') ? FUNDAMENTAL_POLITICAL_CONCEPTS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('forms of government') ? FORMS_OF_GOVERNMENT_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('constitutions and organic structures') ? CONSTITUTIONS_ORGANIC_STRUCTURES_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('franchise, representation') || selectedChapter.toLowerCase().includes('pressure groups') ? FRANCHISE_REPRESENTATION_PARTIES_ICSE11_SUBTOPICS :
                          (selectedChapter.toLowerCase().includes('project work') || selectedChapter.toLowerCase().includes('comparative political analysis')) && (selectedChapter.toLowerCase().includes('political') || subject.toLowerCase().includes('political')) ? PROJECT_WORK_POLITICAL_SCIENCE_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('origin and development of sociology') || (selectedChapter.toLowerCase().includes('sociology') && selectedChapter.toLowerCase().includes('anthropology')) ? ORIGIN_DEV_SOCIOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('research methodology') && (subject.toLowerCase().includes('sociology') || selectedChapter.toLowerCase().includes('sociology')) ? RESEARCH_METHODOLOGY_SOCIOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('basic concepts') && (subject.toLowerCase().includes('sociology') || selectedChapter.toLowerCase().includes('sociology') || selectedChapter.toLowerCase().includes('socialization') || selectedChapter.toLowerCase().includes('society')) ? BASIC_CONCEPTS_SOCIOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('social structure') && (subject.toLowerCase().includes('sociology') || selectedChapter.toLowerCase().includes('sociology') || selectedChapter.toLowerCase().includes('groups')) ? SOCIAL_STRUCTURE_SOCIOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('social problems') && (subject.toLowerCase().includes('sociology') || selectedChapter.toLowerCase().includes('sociology') || selectedChapter.toLowerCase().includes('deviance')) ? SOCIAL_PROBLEMS_SOCIOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('indian sociologists') || selectedChapter.toLowerCase().includes('pioneer perspectives') ? INDIAN_SOCIOLOGISTS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('introduction to psychology') ? INTRO_PSYCHOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('methods of psychology') ? METHODS_PSYCHOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('biological bases') ? BIOLOGICAL_BASES_PSYCHOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('human development') ? HUMAN_DEVELOPMENT_PSYCHOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('sensory, attentional') ? SENSORY_PERCEPTUAL_PSYCHOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('learning') && (subject.toLowerCase().includes('psychology') || selectedChapter.toLowerCase().includes('psychology')) ? LEARNING_PSYCHOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('human memory') || (selectedChapter.toLowerCase().includes('memory') && (subject.toLowerCase().includes('psychology') || selectedChapter.toLowerCase().includes('psychology'))) ? MEMORY_PSYCHOLOGY_ICSE11_SUBTOPICS :
                          (selectedChapter.toLowerCase().includes('practical work') || selectedChapter.toLowerCase().includes('laboratory experiments') || selectedChapter.toLowerCase().includes('practical log')) && (subject.toLowerCase().includes('psychology') || selectedChapter.toLowerCase().includes('psychology')) ? PRACTICAL_PSYCHOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('understanding economics') || (selectedChapter.toLowerCase().includes('basic concepts') && (subject.toLowerCase().includes('economics') || selectedChapter.toLowerCase().includes('economics'))) ? UNDERSTANDING_ECONOMICS_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('consumer behaviour') ? CONSUMER_BEHAVIOUR_DEMAND_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('producer behaviour') ? PRODUCER_BEHAVIOUR_SUPPLY_COST_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('market forms') ? MARKET_FORMS_PRICE_DET_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('structural features') || selectedChapter.toLowerCase().includes('indian economy') ? STRUCTURAL_FEATURES_INDIAN_ECON_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('statistics for economics') || selectedChapter.toLowerCase().includes('basic statistics') ? BASIC_STATISTICS_ECONOMICS_ICSE11_SUBTOPICS :
                          (selectedChapter.toLowerCase().includes('project work') || selectedChapter.toLowerCase().includes('research essay')) && (subject.toLowerCase().includes('economics') || selectedChapter.toLowerCase().includes('economics')) ? PROJECT_WORK_ECONOMICS_ICSE11_SUBTOPICS :
                          (selectedChapter.toLowerCase().includes('practical work') || selectedChapter.toLowerCase().includes('sociological research') || selectedChapter.toLowerCase().includes('sociological projects')) && (selectedChapter.toLowerCase().includes('sociology') || subject.toLowerCase().includes('sociology')) ? PRACTICAL_SOCIOLOGY_ICSE11_SUBTOPICS :
                          selectedChapter.toLowerCase().includes('microeconomics') ? ISC_ECON_MICRO_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('macroeconomics') ? ISC_ECON_MACRO_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('solid state') ? SOLID_STATE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('solution') ? SOLUTIONS_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('electrochemistry') ? ELECTROCHEMISTRY_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('kinetics') ? CHEMICAL_KINETICS_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('surface chemistry') ? SURFACE_CHEMISTRY_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('isolation') ? ISOLATION_OF_ELEMENTS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('p-block') ? P_BLOCK_ELEMENTS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('d- and f-block') || selectedChapter.toLowerCase().includes('d- & f-block') || selectedChapter.toLowerCase().includes('d-block') || selectedChapter.toLowerCase().includes('f-block') ? D_AND_F_BLOCK_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('coordination') ? COORDINATION_COMPOUNDS_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('haloalkane') || selectedChapter.toLowerCase().includes('haloarene') ? HALOALKANES_HALOARENES_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('alcohol') || selectedChapter.toLowerCase().includes('phenol') || selectedChapter.toLowerCase().includes('ether') ? ALCOHOLS_PHENOLS_ETHERS_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('aldehyde') || selectedChapter.toLowerCase().includes('ketone') || selectedChapter.toLowerCase().includes('carboxylic') ? ALDEHYDES_KETONES_CARBOXYLIC_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('amine') || selectedChapter.toLowerCase().includes('diazonium') ? AMINES_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('biomolecule') ? BIOMOLECULES_CBSE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('polymer') ? POLYMERS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('everyday life') ? CHEMISTRY_EVERYDAY_LIFE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('relations and functions') ? RELATIONS_FUNCTIONS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('inverse trigonometric') ? INVERSE_TRIGONOMETRIC_FUNCTIONS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('matrices') ? MATRICES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('continuity') || selectedChapter.toLowerCase().includes('differentiability') ? CONTINUITY_DIFFERENTIABILITY_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('exponential') || selectedChapter.toLowerCase().includes('logarithmic') ? EXPONENTIAL_LOGARITHMIC_MEAN_VALUE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('applications of integral') || selectedChapter.toLowerCase().includes('application of integral') || selectedChapter.toLowerCase().includes('area under') ? APPLICATIONS_OF_INTEGRALS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('cost') || selectedChapter.toLowerCase().includes('revenue') || selectedChapter.toLowerCase().includes('elasticity') || selectedChapter.toLowerCase().includes('marginal cost') ? APPLICATION_DERIVATIVES_ECONOMICS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('application') || selectedChapter.toLowerCase().includes('derivative') ? APPLICATION_DERIVATIVES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('integral') ? INTEGRATION_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('differential equation') ? DIFFERENTIAL_EQUATIONS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('probab') ? PROBABILITY_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('regression') || selectedChapter.toLowerCase().includes('correlation') ? REGRESSION_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('vector') ? VECTORS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('linear programming') || selectedChapter.toLowerCase().includes('lpp') || selectedChapter.toLowerCase().includes('linear program') ? LINEAR_PROGRAMMING_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('three dimensional geometry') || selectedChapter.toLowerCase().includes('three-dimensional') || selectedChapter.toLowerCase().includes('3d geometry') ? THREE_DIMENSIONAL_GEOMETRY_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('determinant') ? DETERMINANTS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('communication') || selectedChapter.toLowerCase().includes('bandwidth') ? COMMUNICATION_SYSTEMS_LESSON_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('logic gate') || selectedChapter.toLowerCase().includes('de morgan') ? LOGIC_GATES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('transistor') || selectedChapter.toLowerCase().includes('amplifier') ? JUNCTION_TRANSISTORS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('diode') || selectedChapter.toLowerCase().includes('led') ? SEMICONDUCTOR_DIODES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('rectifier') ? SEMICONDUCTOR_ELECTRONICS_LESSON_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('fission') || selectedChapter.toLowerCase().includes('fusion') ? NUCLEAR_FISSION_FUSION_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('mass-energy') || selectedChapter.toLowerCase().includes('pair production') ? MASS_ENERGY_BINDING_ENERGY_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('radioactivity') || selectedChapter.toLowerCase().includes('half-life') ? RADIOACTIVITY_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('nuclear structure') || selectedChapter.toLowerCase().includes('binding energy per nucleon') ? NUCLEAR_STRUCTURE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('bohr') || selectedChapter.toLowerCase().includes('hydrogen spectrum') || selectedChapter.toLowerCase().includes('origin of spectra') ? ATOMS_BOHR_SPECTRUM_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('x-ray') || selectedChapter.toLowerCase().includes('coolidge') || selectedChapter.toLowerCase().includes('moseley') ? X_RAYS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('matter wave') || selectedChapter.toLowerCase().includes('de broglie') || selectedChapter.toLowerCase().includes('davisson') ? MATTER_WAVES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('photoelectric') || selectedChapter.toLowerCase().includes('work function') || selectedChapter.toLowerCase().includes('stopping potential') ? PHOTOELECTRIC_EFFECT_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('polarization') || selectedChapter.toLowerCase().includes('brewster') || selectedChapter.toLowerCase().includes('malus') || selectedChapter.toLowerCase().includes('polaroid') ? POLARIZATION_OF_LIGHT_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('diffraction') || selectedChapter.toLowerCase().includes('single slit') ? DIFFRACTION_OF_LIGHT_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('interference') || selectedChapter.toLowerCase().includes('double slit') || selectedChapter.toLowerCase().includes('ydse') || selectedChapter.toLowerCase().includes('fringe') ? INTERFERENCE_OF_LIGHT_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('huygen') || selectedChapter.toLowerCase().includes('wavefront') || selectedChapter.toLowerCase().includes('wave nature') ? WAVE_NATURE_HUYGENS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('microscope') || selectedChapter.toLowerCase().includes('telescope') || selectedChapter.toLowerCase().includes('optical instrument') ? OPTICAL_INSTRUMENTS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('prism') || selectedChapter.toLowerCase().includes('dispersion') || selectedChapter.toLowerCase().includes('minimum deviation') ? REFRACTION_DISPERSION_PRISM_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('spherical surface') || selectedChapter.toLowerCase().includes('lenses') || selectedChapter.toLowerCase().includes('lens maker') ? REFRACTION_SPHERICAL_SURFACES_LENSES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('refraction') || selectedChapter.toLowerCase().includes('total internal reflection') || selectedChapter.toLowerCase().includes('optical fiber') || selectedChapter.toLowerCase().includes('snell') ? REFRACTION_PLANE_INTERFACE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('reflection') || selectedChapter.toLowerCase().includes('spherical mirror') || selectedChapter.toLowerCase().includes('concave mirror') || selectedChapter.toLowerCase().includes('convex mirror') ? REFLECTION_OF_LIGHT_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('communication') || selectedChapter.toLowerCase().includes('modulation') || selectedChapter.toLowerCase().includes('amplitude') || selectedChapter.toLowerCase().includes('bandwidth') ? COMMUNICATION_SYSTEMS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('semiconductor') || selectedChapter.toLowerCase().includes('logic gate') || selectedChapter.toLowerCase().includes('transistor') || selectedChapter.toLowerCase().includes('diode') ? SEMICONDUCTOR_ELECTRONICS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('nuclei') || selectedChapter.toLowerCase().includes('radioactivity') || selectedChapter.toLowerCase().includes('mass defect') || selectedChapter.toLowerCase().includes('binding energy') ? NUCLEI_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('atoms') || selectedChapter.toLowerCase().includes('rutherford') || selectedChapter.toLowerCase().includes('bohr') || selectedChapter.toLowerCase().includes('hydrogen spectrum') ? ATOMS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('dual nature') || selectedChapter.toLowerCase().includes('radiation') || selectedChapter.toLowerCase().includes('photoelectric') || selectedChapter.toLowerCase().includes('matter wave') ? DUAL_NATURE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('wave optics') || selectedChapter.toLowerCase().includes('huygen') || selectedChapter.toLowerCase().includes('interference') || selectedChapter.toLowerCase().includes('diffraction') || selectedChapter.toLowerCase().includes('polarization') ? WAVE_OPTICS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('ray optics') || selectedChapter.toLowerCase().includes('optical instrument') || selectedChapter.toLowerCase().includes('telescope') || selectedChapter.toLowerCase().includes('prism') ? RAY_OPTICS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('electromagnetic wave') || selectedChapter.toLowerCase().includes('em wave') || selectedChapter.toLowerCase().includes('spectrum') ? ELECTROMAGNETIC_WAVES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('alternating current') || selectedChapter.toLowerCase().includes('ac circuit') || selectedChapter.toLowerCase().includes('transformer') ? ALTERNATING_CURRENT_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('induction') || selectedChapter.toLowerCase().includes('faraday') ? ELECTROMAGNETIC_INDUCTION_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('substance') || selectedChapter.toLowerCase().includes('diamagnetic') || selectedChapter.toLowerCase().includes('ferromagnetic') ? MAGNETIC_SUBSTANCES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('earth') || selectedChapter.toLowerCase().includes('terrestrial magnetism') ? EARTH_MAGNETISM_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('torque') || selectedChapter.toLowerCase().includes('galvanometer') ? TORQUE_CURRENT_LOOP_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('moving charge') || selectedChapter.toLowerCase().includes('magnetic field') || selectedChapter.toLowerCase().includes('biot') ? MOVING_CHARGES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('dc circuit') || selectedChapter.toLowerCase().includes('kirchhoff') || selectedChapter.toLowerCase().includes('potentiometer') ? DC_CIRCUITS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('resistance') || selectedChapter.toLowerCase().includes('ohm') ? ELECTRIC_RESISTANCE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('capacitor') || selectedChapter.toLowerCase().includes('dielectric') ? CAPACITORS_DIELECTRICS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('potential') ? ELECTRIC_POTENTIAL_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('gauss') ? GAUSS_THEOREM_SUBTOPICS : 
                         selectedChapter.toLowerCase().includes('flowering plant') || selectedChapter.toLowerCase().includes('sexual reproduction in flowering') ? SEXUAL_REPRODUCTION_PLANTS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('human reproduction') ? HUMAN_REPRODUCTION_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('reproductive health') ? REPRODUCTIVE_HEALTH_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('principles of inheritance') ? PRINCIPLES_OF_INHERITANCE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('molecular basis') ? MOLECULAR_BASIS_INHERITANCE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('evolution') ? EVOLUTION_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('human health') ? HUMAN_HEALTH_DISEASE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('microbes') ? MICROBES_HUMAN_WELFARE_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('biotechnology: principles') || selectedChapter.toLowerCase().includes('principles and processes') ? BIOTECHNOLOGY_PRINCIPLES_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('biotechnology and its applications') || (selectedChapter.toLowerCase().includes('biotechnology') && selectedChapter.toLowerCase().includes('application')) ? BIOTECHNOLOGY_APPLICATIONS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('organisms and populations') ? ORGANISMS_POPULATIONS_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('ecosystem') ? ECOSYSTEM_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('biodiversity') ? BIODIVERSITY_CONSERVATION_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('rational') || selectedChapter.toLowerCase().includes('irrational') ? RATIONAL_IRRATIONAL_NUMBERS_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('compound interest') ? COMPOUND_INTEREST_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('expansion') ? EXPANSIONS_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('factoris') || selectedChapter.toLowerCase().includes('factoriz') ? FACTORISATION_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('simultaneous') || (selectedChapter.toLowerCase().includes('linear') && selectedChapter.toLowerCase().includes('equation')) ? SIMULTANEOUS_LINEAR_EQUATIONS_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('indices') || selectedChapter.toLowerCase().includes('exponent') ? INDICES_EXPONENTS_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('logarithm') ? LOGARITHMS_ICSE9_SUBTOPICS :
                         (selectedChapter.toLowerCase().includes('triangle') || selectedChapter.toLowerCase().includes('congruen')) && !selectedChapter.toLowerCase().includes('inverse') ? TRIANGLES_GEOMETRY_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('mid-point') || selectedChapter.toLowerCase().includes('intercept') ? MIDPOINT_INTERCEPT_THEOREMS_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('rectilinear') || selectedChapter.toLowerCase().includes('quadrilateral') ? RECTILINEAR_FIGURES_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('circle') && (selectedChapter.toLowerCase().includes('chord') || selectedChapter.toLowerCase().includes('geometry')) ? CIRCLES_GEOMETRY_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('area of plane') || (selectedChapter.toLowerCase().includes('mensuration') && selectedChapter.toLowerCase().includes('plane')) ? AREA_PLANE_FIGURES_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('surface area and volume') || selectedChapter.toLowerCase().includes('3d solids') ? SURFACE_AREA_VOLUME_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('coordinate geometry') || selectedChapter.toLowerCase().includes('cartesian') ? COORDINATE_GEOMETRY_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('trigonometrical ratios') || (selectedChapter.toLowerCase().includes('trigonometry') && selectedChapter.toLowerCase().includes('ratio')) ? TRIGONOMETRICAL_RATIOS_ICSE9_SUBTOPICS :
                         selectedChapter.toLowerCase().includes('statistics') && (selectedChapter.toLowerCase().includes('representation') || selectedChapter.toLowerCase().includes('central tendency')) ? STATISTICS_ICSE9_SUBTOPICS :
                         (selectedChapter.toLowerCase().includes('internal assessment') || selectedChapter.toLowerCase().includes('mathematical project')) && selectedChapter.toLowerCase().includes('math') ? INTERNAL_ASSESSMENT_MATH_ICSE9_SUBTOPICS :
                         (selectedChapter.toLowerCase().includes('measurement') && (selectedChapter.toLowerCase().includes('experiment') || selectedChapter.toLowerCase().includes('length') || selectedChapter.toLowerCase().includes('least count'))) ? MEASUREMENTS_EXPERIMENTATION_ICSE9_SUBTOPICS :
                         (selectedChapter.toLowerCase().includes('motion in one dimension') || (selectedChapter.toLowerCase().includes('motion') && selectedChapter.toLowerCase().includes('dimension'))) ? MOTION_ONE_DIMENSION_ICSE9_SUBTOPICS :
                         (selectedChapter.toLowerCase().includes('laws of motion') || (selectedChapter.toLowerCase().includes('law') && selectedChapter.toLowerCase().includes('motion'))) ? LAWS_OF_MOTION_ICSE9_SUBTOPICS :
                         ((selectedChapter.toLowerCase().includes('fluid') || selectedChapter.toLowerCase().includes('pressure in fluid')) && (selectedChapter.toLowerCase().includes('archimedes') || selectedChapter.toLowerCase().includes('floatation') || selectedChapter.toLowerCase().includes('relative density'))) ? FLUIDS_PRESSURE_ARCHIMEDES_ICSE9_SUBTOPICS :
                         ((selectedChapter.toLowerCase().includes('heat') && selectedChapter.toLowerCase().includes('energy')) || selectedChapter.toLowerCase().includes('anomalous expansion')) ? HEAT_AND_ENERGY_ICSE9_SUBTOPICS :
                         ((selectedChapter.toLowerCase().includes('light') && (selectedChapter.toLowerCase().includes('reflection') || selectedChapter.toLowerCase().includes('spherical mirror'))) || (selectedChapter.toLowerCase().includes('reflection of light') && !selectedChapter.toLowerCase().includes('wave optics'))) ? LIGHT_REFLECTION_SPHERICAL_MIRRORS_ICSE9_SUBTOPICS :
                         ((selectedChapter.toLowerCase().includes('sound') && (selectedChapter.toLowerCase().includes('propagation') || selectedChapter.toLowerCase().includes('ultrasonic') || selectedChapter.toLowerCase().includes('wave'))) || selectedChapter.toLowerCase().includes('sound: propagation')) ? SOUND_PROPAGATION_ULTRASONIC_ICSE9_SUBTOPICS :
                         (selectedChapter.toLowerCase().includes('electricity and magnetism') || (selectedChapter.toLowerCase().includes('electricity') && selectedChapter.toLowerCase().includes('magnetism'))) ? ELECTRICITY_MAGNETISM_ICSE9_SUBTOPICS :
                         ((selectedChapter.toLowerCase().includes('internal assessment') || selectedChapter.toLowerCase().includes('practical physics')) && selectedChapter.toLowerCase().includes('physics')) ? INTERNAL_ASSESSMENT_PHYSICS_ICSE9_SUBTOPICS :
                         (selectedChapter.toLowerCase().includes('electric charge') || selectedChapter.toLowerCase().includes('modern physics') ? ELECTRIC_CHARGES_SUBTOPICS : undefined));
                      return (
                        <div
                          key={lesson.id}
                          className={cn(
                            "p-4 rounded-xl border flex flex-col justify-between gap-4 transition-all",
                            isCompleted
                              ? theme === 'dark'
                                ? "bg-emerald-950/10 border-emerald-900/40 shadow-sm shadow-emerald-950/5"
                                : "bg-emerald-50/15 border-emerald-150 shadow-sm shadow-emerald-50/5"
                              : theme === 'dark'
                                ? "bg-slate-850/60 border-slate-800"
                                : "bg-white border-slate-150 shadow-sm"
                          )}
                        >
                          <div className="flex flex-col md:flex-row justify-between items-start gap-4 w-full">
                            <div className="flex items-start gap-3 flex-1 min-w-0">
                              {/* Toggle/Checkbox Button */}
                              <button
                                id={`check-lesson-${lesson.id}`}
                                onClick={() => toggleLessonComplete(lesson.id)}
                                className={cn(
                                  "mt-1 flex-shrink-0 w-5 h-5 rounded-md border flex items-center justify-center transition-all cursor-pointer",
                                  isCompleted
                                    ? "bg-emerald-500 border-emerald-500 text-white shadow-sm shadow-emerald-500/20"
                                    : theme === 'dark'
                                      ? "border-slate-700 hover:border-slate-500 bg-slate-800"
                                      : "border-slate-300 hover:border-slate-400 bg-slate-50"
                                )}
                                title={isCompleted ? "Mark incomplete" : "Mark complete"}
                              >
                                {isCompleted && (
                                  <CheckCircle size={12} strokeWidth={3} className="text-white" />
                                )}
                              </button>

                              <div className="flex-1 space-y-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className={cn(
                                    "text-[10px] uppercase font-black px-1.5 py-0.5 rounded transition-all",
                                    isCompleted
                                      ? "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400"
                                      : "bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400"
                                  )}>
                                    Lesson {idx + 1}
                                  </span>
                                  <span className="text-xs opacity-50 flex items-center gap-1">
                                    <Clock size={12} /> {lesson.duration}
                                  </span>
                                  <span className="text-[10px] opacity-60 font-medium px-1.5 py-0.2 bg-slate-100 dark:bg-slate-800 rounded">
                                    {lesson.level}
                                  </span>
                                  {isCompleted && (
                                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
                                      ✓ Completed
                                    </span>
                                  )}
                                </div>
                                <h4 className={cn("font-bold text-sm transition-all", isCompleted && "opacity-80 line-through decoration-emerald-500/30")}>{lesson.title}</h4>
                                <p className={cn("text-xs opacity-60 leading-relaxed max-w-lg transition-all", isCompleted && "opacity-40")}>{lesson.description}</p>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 justify-end md:justify-start flex-wrap">
                              {lesson.id.startsWith('custom-') && (
                                <button
                                  onClick={() => {
                                    setCustomLessons(prev => ({
                                      ...prev,
                                      [selectedChapter]: (prev[selectedChapter] || []).filter(l => l.id !== lesson.id)
                                    }));
                                    showNotification?.('Custom lesson removed', 'info');
                                  }}
                                  className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-colors cursor-pointer"
                                  title="Delete Custom Lesson"
                                >
                                  <Trash2 size={14} />
                                </button>
                              )}
                              {activeSubtopics && (
                                <button
                                  onClick={() => {
                                    setExpandedSubtopics(prev => ({
                                      ...prev,
                                      [lesson.id]: !prev[lesson.id]
                                    }));
                                  }}
                                  className={cn(
                                    "px-3 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer border",
                                    expandedSubtopics[lesson.id]
                                      ? "bg-amber-600 text-white border-amber-600 shadow-sm"
                                      : "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 hover:bg-amber-100 dark:hover:bg-amber-900/50"
                                  )}
                                >
                                  <Search size={14} />
                                  {expandedSubtopics[lesson.id] ? "Hide Subtopics" : "Explore Subtopics"}
                                </button>
                              )}
                              <button
                                onClick={() => onStudyLesson(lesson.title, selectedChapter, chosenDepth)}
                                className="px-4 py-2 text-xs font-bold text-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400 border border-indigo-200 hover:border-indigo-400 dark:border-indigo-900/50 dark:hover:border-indigo-800 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                              >
                                <Brain size={14} />
                                Study lesson
                              </button>
                            </div>
                          </div>

                          {/* Sub-topics breakdown section */}
                          {activeSubtopics && expandedSubtopics[lesson.id] && (
                            <div className="w-full mt-3 pt-3 border-t border-slate-200 dark:border-slate-800/80 space-y-3 animate-fadeIn">
                              <div className="flex items-center justify-between flex-wrap gap-2">
                                <div className="text-xs font-black uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
                                  <Sparkles size={14} className="text-amber-500" />
                                  {selectedChapter.toUpperCase().endsWith(':') ? selectedChapter.toUpperCase() : `${selectedChapter.toUpperCase()}:`}
                                </div>
                                <span className="text-[10px] font-bold opacity-70 px-2 py-0.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded">
                                  {activeSubtopics.length} Learning Modules
                                </span>
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                                {activeSubtopics.map((sub: any, sIdx: number) => {
                                  const pageNumber = getSubtopicPage(sub, lesson.description, sIdx, activeSubtopics.length, selectedChapter || '');
                                  return (
                                    <div
                                      key={sIdx}
                                      onClick={() => onStudyLesson(`${sub} - ${selectedChapter}`, selectedChapter, chosenDepth)}
                                      className={cn(
                                        "p-2.5 rounded-lg border transition-all flex items-center justify-between gap-2 group cursor-pointer",
                                        theme === 'dark'
                                          ? "bg-slate-800/80 border-slate-700/80 hover:bg-indigo-950/40 hover:border-indigo-500/60 text-slate-200"
                                          : "bg-slate-50 border-slate-200/80 hover:bg-indigo-50 hover:border-indigo-300 text-slate-800"
                                      )}
                                    >
                                      <div className="flex items-center gap-2 min-w-0">
                                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 flex-shrink-0 group-hover:scale-125 transition-transform" />
                                        <span className="font-semibold text-xs leading-normal">
                                          {sub} <span className="text-indigo-500 font-bold dark:text-indigo-400 ml-1">({pageNumber})</span>
                                        </span>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>
                    );
                  })}
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-6 opacity-60">
                  <div className="p-4 bg-indigo-50 dark:bg-slate-800 text-indigo-500 rounded-full mb-3">
                    <BookOpen size={24} />
                  </div>
                  <h4 className="font-bold text-sm">Select a Syllabus Chapter</h4>
                  <p className="text-xs opacity-80 max-w-xs mt-1">
                    Select a core chapter from the left rail to unlock structured lessons, explanations, and quizzes tailored to your active {mode === 'entrance' ? 'entrance exam' : mode === 'competitive' ? 'Jobs exams target' : 'board'}!
                  </p>
                </div>
              )}
            </div>
          </div>
        ) : activeTab === 'notes' ? (
          /* Notes Tab View */
          <div className="h-full">
            {readingNote ? (
              <div className="flex flex-col h-full animate-fadeIn max-w-4xl mx-auto">
                <button
                  onClick={() => { setReadingNote(null); setPublishedUrl(null); }}
                  className="mb-4 text-xs font-bold text-indigo-500 flex items-center gap-1 hover:underline cursor-pointer"
                >
                  ← Back to saved notes list
                </button>
                <div className={cn(
                  "p-6 rounded-2xl border flex-1 space-y-6",
                  theme === 'dark' ? "bg-slate-850/40 border-slate-800" : "bg-white border-slate-150 shadow-sm"
                )}>
                  <div className="flex justify-between items-start gap-4 pb-4 border-b dark:border-slate-800 border-slate-150">
                    <div>
                      <h3 className="text-xl font-bold tracking-tight text-indigo-500">{readingNote.title}</h3>
                      <p className="text-xs opacity-50 mt-1 flex items-center gap-2">
                        <span>Subject: {readingNote.subject.toUpperCase().replace(/_/g, ' ')}</span>
                        <span>•</span>
                        <span>Saved on: {new Date(readingNote.timestamp).toLocaleDateString()}</span>
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        onDeleteNote(readingNote.id);
                        setReadingNote(null);
                        setPublishedUrl(null);
                      }}
                      className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-colors cursor-pointer"
                      title="Delete Study Note"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>

                  {/* Public SEO Publisher Module */}
                  <div className="p-4 rounded-xl border border-dashed dark:bg-slate-900/40 dark:border-slate-700 bg-slate-50 border-slate-200 space-y-3">
                    <div className="flex items-center gap-2">
                      <Globe size={16} className="text-emerald-500 animate-pulse" />
                      <h4 className="text-xs font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                        Public Search Engine Optimizer (SEO) Publisher
                      </h4>
                    </div>
                    <p className="text-xs opacity-70 leading-relaxed">
                      Publish this study guide recap as an open-access, public web page optimized for search-engine indexing. Students looking for this curriculum will discover your cheatsheets on search engines and launch back into your interactive simulator sandbox!
                    </p>
                    
                    {!publishedUrl ? (
                      <button
                        onClick={() => handlePublishNote(readingNote)}
                        disabled={isPublishing}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-55 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        {isPublishing ? (
                          <>
                            <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                            Generating Public SEO Page...
                          </>
                        ) : (
                          <>
                            <Globe size={13} />
                            Publish to Web & Generate Index Link
                          </>
                        )}
                      </button>
                    ) : (
                      <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl space-y-2.5">
                        <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                          ✓ Successfully Published & Search-Engine Optimized!
                        </div>
                        <div className="flex flex-col sm:flex-row items-center gap-2">
                          <input
                            type="text"
                            readOnly
                            value={getSyncShareUrl().split('?')[0].replace(/\/$/, '') + publishedUrl}
                            className="w-full sm:flex-1 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 p-2 rounded-lg text-xs font-semibold outline-none text-indigo-600 dark:text-indigo-400"
                          />
                          <div className="flex items-center gap-2 w-full sm:w-auto">
                            <button
                              onClick={() => handleCopyLink(publishedUrl, 'published-note')}
                              className="flex-1 sm:flex-initial p-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors cursor-pointer flex justify-center items-center"
                              title="Copy Public URL"
                            >
                              {copiedItemId === 'published-note' ? <Check size={14} /> : <Copy size={14} />}
                            </button>
                            <a
                              href={publishedUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="flex-1 sm:flex-initial p-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors flex items-center justify-center"
                              title="View Public SEO Page"
                            >
                              <ExternalLink size={14} />
                            </a>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="text-xs font-black uppercase text-indigo-400 tracking-wider mb-2">Key Concepts Learned</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {readingNote.keyConcepts.map((concept, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs p-2.5 rounded-lg bg-indigo-500/5 border border-indigo-500/10 dark:text-indigo-300 text-indigo-950">
                            <CheckCircle size={14} className="text-indigo-500 mt-0.5 flex-shrink-0" />
                            <span>{concept}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t dark:border-slate-800 border-slate-150">
                      <h4 className="text-xs font-black uppercase text-indigo-400 tracking-wider mb-2">Conversation Summary</h4>
                      <div className="prose prose-sm dark:prose-invert max-w-none text-sm leading-relaxed whitespace-pre-line opacity-90">
                        {readingNote.summary}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="max-w-4xl mx-auto">
                {localNotes.length > 0 ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="text-xs font-bold uppercase tracking-wider opacity-60">
                        Saved Recap Summaries ({localNotes.length}) — Drag & drop or use arrows to reorder
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {localNotes.map((note, index) => (
                        <div
                          key={note.id}
                          draggable
                          onDragStart={(e) => handleDragStart(e, index)}
                          onDragOver={handleDragOver}
                          onDrop={(e) => handleDrop(e, index)}
                          className={cn(
                            "p-5 rounded-2xl border hover:border-indigo-500 transition-all flex flex-col justify-between group cursor-grab active:cursor-grabbing",
                            theme === 'dark' ? "bg-slate-850/50 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                          )}
                        >
                          <div>
                            <div className="flex justify-between items-start gap-3">
                              <div className="flex items-center gap-2">
                                <span className="p-1 rounded text-slate-400 group-hover:text-indigo-500 transition-colors" title="Drag to reorder">
                                  <GripVertical size={16} />
                                </span>
                                <span className="text-[10px] uppercase font-black tracking-wider bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-md">
                                  {note.subject.replace(/_/g, ' ')}
                                </span>
                              </div>
                              <div className="flex items-center gap-1">
                                <div className="opacity-0 group-hover:opacity-100 flex items-center gap-0.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg transition-all">
                                  <button
                                    onClick={(e) => handleMoveNote(e, index, 'up')}
                                    disabled={index === 0}
                                    className="p-1 text-slate-400 hover:text-indigo-500 disabled:opacity-30 rounded transition-colors cursor-pointer"
                                    title="Move Up"
                                  >
                                    <ChevronUp size={12} />
                                  </button>
                                  <button
                                    onClick={(e) => handleMoveNote(e, index, 'down')}
                                    disabled={index === localNotes.length - 1}
                                    className="p-1 text-slate-400 hover:text-indigo-500 disabled:opacity-30 rounded transition-colors cursor-pointer"
                                    title="Move Down"
                                  >
                                    <ChevronDown size={12} />
                                  </button>
                                </div>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onDeleteNote(note.id);
                                  }}
                                  className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-400 hover:text-red-500 rounded-lg transition-all cursor-pointer"
                                  title="Delete Note"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </div>
                            <h4 className="font-bold text-sm mt-3 leading-snug group-hover:text-indigo-500 transition-colors">
                              {note.title}
                            </h4>
                            <p className="text-xs opacity-60 mt-1 line-clamp-2">
                              {note.keyConcepts?.slice(0, 3).join(', ') || note.summary}
                            </p>
                          </div>
                          
                          <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800/60 pt-3 mt-4">
                            <span className="text-[10px] opacity-40">
                              {new Date(note.timestamp).toLocaleDateString()}
                            </span>
                            <button
                              onClick={() => { setReadingNote(note); setPublishedUrl(null); }}
                              className="text-xs font-bold text-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 cursor-pointer"
                            >
                              Read Notes <ArrowRight size={12} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center text-center py-20 opacity-60">
                    <div className="p-4 bg-indigo-50 dark:bg-slate-800 text-indigo-500 rounded-full mb-3">
                      <Sparkles size={24} className="text-amber-500" />
                    </div>
                    <h4 className="font-bold text-sm">No saved study recap notes yet</h4>
                    <p className="text-xs opacity-80 max-w-xs mt-1">
                      During a tutoring session, use the **Recap Chat** button to summarize your learning, get key facts, and save them permanently to this collections tab!
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : activeTab === 'roadmap' ? (
          /* Study Roadmap Tab View */
          <div className="h-full max-w-5xl mx-auto space-y-8 animate-fadeIn">
            {/* Header Banner */}
            <div className={cn(
              "p-6 rounded-2xl border flex flex-col md:flex-row justify-between items-start md:items-center gap-4",
              theme === 'dark' ? "bg-indigo-950/15 border-indigo-900/50" : "bg-indigo-50/20 border-indigo-100"
            )}>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
                  <Compass size={22} className="animate-spin-slow text-indigo-500" />
                  <h3 className="text-xl font-black tracking-tight">Interactive Study Roadmap</h3>
                </div>
                <p className="text-xs sm:text-sm opacity-80 leading-relaxed max-w-2xl">
                  Your curriculum is dynamically broken down into a weekly target journey. Track your completed lessons in Chapters Explorer to progress through the milestones!
                </p>
              </div>
              <div className="flex items-center gap-4 flex-wrap shrink-0">
                <button
                  onClick={() => setIsCalendarOpen(true)}
                  className="py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-md hover:shadow-lg flex items-center gap-2 transition-all transform hover:-translate-y-0.5 cursor-pointer"
                >
                  <Calendar size={14} className="animate-pulse" />
                  View Calendar Grid
                </button>
                <div className="h-8 w-[1px] bg-slate-200 dark:bg-slate-800 hidden sm:block" />
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-black tracking-wider opacity-50 block">Subject</span>
                    <span className="text-sm font-extrabold text-indigo-500">{subject}</span>
                  </div>
                  <div className="h-8 w-[1px] bg-slate-200 dark:bg-slate-800" />
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-black tracking-wider opacity-50 block">Level</span>
                    <span className="text-sm font-extrabold text-amber-600">{difficulty}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Automated Sync Engine Dashboard Status Bar */}
            <div className={cn(
              "px-5 py-4 rounded-2xl border flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all duration-300",
              theme === 'dark' 
                ? "bg-emerald-950/15 border-emerald-900/30 text-emerald-300" 
                : "bg-emerald-500/5 border-emerald-500/20 text-emerald-850"
            )}>
              <div className="flex items-center gap-3">
                <div className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase tracking-wider">Automated Syllabus Sync</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-extrabold px-1.5 py-0.2 rounded-full">ACTIVE</span>
                  </div>
                  <p className="text-xs opacity-75 mt-0.5">
                    Your Study Roadmap milestones dynamically stay 100% aligned with actual checked progress in Chapters Explorer.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
                <div className="text-left md:text-right">
                  <span className="text-[10px] uppercase font-black tracking-wider opacity-50 block">Last Active Check</span>
                  <span className="text-xs font-mono font-bold">{lastSyncTime || "Just now"}</span>
                </div>
                
                <div className="h-6 w-[1px] bg-slate-200 dark:bg-slate-800" />

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setIsSyncing(true);
                      setTimeout(() => {
                        setIsSyncing(false);
                        const now = new Date();
                        setLastSyncTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
                        if (showNotification) {
                          showNotification("🔄 Syllabus milestone sync complete. All metrics perfectly matched!", "success");
                        }
                      }, 600);
                    }}
                    disabled={isSyncing}
                    className="py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <RefreshCw size={12} className={cn("text-white", isSyncing && "animate-spin")} />
                    {isSyncing ? "Syncing..." : "Force Sync"}
                  </button>

                  <button
                    onClick={() => setShowSyncLogs(!showSyncLogs)}
                    className={cn(
                      "py-1.5 px-3 rounded-xl text-xs font-bold transition-all border cursor-pointer",
                      theme === 'dark'
                        ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200"
                        : "bg-white border-slate-200 hover:bg-slate-50 text-slate-700"
                    )}
                  >
                    {showSyncLogs ? "Hide History" : "View Logs"}
                  </button>
                </div>
              </div>
            </div>

            {/* Sync History Logs Panel */}
            {showSyncLogs && (
              <div className={cn(
                "p-4 rounded-2xl border space-y-2.5 animate-fadeIn max-h-56 overflow-y-auto",
                theme === 'dark' ? "bg-slate-900 border-slate-800 text-slate-300" : "bg-slate-50 border-slate-200 text-slate-700"
              )}>
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/50 dark:border-slate-800/50">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Automated Sync Registry Logs</span>
                  <span className="text-[10px] opacity-50">Showing latest {syncLogs.length} updates</span>
                </div>
                {syncLogs.length === 0 ? (
                  <p className="text-xs opacity-50 italic">No sync logged yet. Change your syllabus checkboxes to trigger automated sync logs.</p>
                ) : (
                  <div className="space-y-1.5 font-mono">
                    {syncLogs.map(log => (
                      <div key={log.id} className="flex justify-between items-start text-xs py-1 border-b border-dashed border-slate-150 dark:border-slate-850 last:border-0">
                        <span className="opacity-80 break-words flex-1 pr-4">⚡ {log.msg}</span>
                        <span className="opacity-50 shrink-0">{log.time}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Study Stats & Progress Grid */}
            {(() => {
              const weeks = generateRoadmapWeeks();
              const totalLessons = weeks.reduce((sum, w) => sum + w.totalCount, 0);
              const completedLessonsCount = weeks.reduce((sum, w) => sum + w.completedCount, 0);
              const totalProgressPercent = totalLessons > 0 ? Math.round((completedLessonsCount / totalLessons) * 100) : 0;
              
              // Find first incomplete week
              const activeWeek = weeks.find(w => w.status !== 'completed') || weeks[weeks.length - 1];
              
              return (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className={cn(
                    "p-5 rounded-2xl border flex flex-col justify-between",
                    theme === 'dark' ? "bg-slate-850/30 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black uppercase tracking-wider text-slate-400">Syllabus Mastery</span>
                      <Award size={18} className="text-emerald-500" />
                    </div>
                    <div className="mt-4">
                      <div className="flex items-end justify-between mb-2">
                        <span className="text-2xl font-black">{totalProgressPercent}%</span>
                        <span className="text-xs font-semibold opacity-60">{completedLessonsCount}/{totalLessons} Lessons</span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                        <div 
                          className="bg-emerald-500 h-full transition-all duration-500"
                          style={{ width: `${totalProgressPercent}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className={cn(
                    "p-5 rounded-2xl border flex flex-col justify-between",
                    theme === 'dark' ? "bg-slate-850/30 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black uppercase tracking-wider text-slate-400">Current Milestone Target</span>
                      <Flame size={18} className="text-amber-500 animate-pulse" />
                    </div>
                    <div className="mt-4">
                      <div className="text-sm font-bold truncate">
                        {activeWeek ? `Week ${activeWeek.weekNumber}: ${activeWeek.title}` : "All Completed! 🏆"}
                      </div>
                      <p className="text-xs opacity-60 mt-1">
                        {activeWeek ? `${activeWeek.totalCount - activeWeek.completedCount} lessons remaining this week` : "Amazing academic effort!"}
                      </p>
                    </div>
                  </div>

                  <div className={cn(
                    "p-5 rounded-2xl border flex flex-col justify-between",
                    theme === 'dark' ? "bg-slate-850/30 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black uppercase tracking-wider text-slate-400">Study Pace Estimator</span>
                      <Clock size={18} className="text-indigo-500" />
                    </div>
                    <div className="mt-4">
                      <div className="text-base font-black">
                        ~{Math.round((totalLessons - completedLessonsCount) * 25 / 60)} Hours Left
                      </div>
                      <p className="text-xs opacity-60 mt-1">
                        Assuming standard 25-minute Pomodoro modules per lesson
                      </p>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Core Columns */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Timeline Column */}
              <div className="lg:col-span-7 space-y-4">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                  <Map size={14} className="text-indigo-500" /> Dynamic Weekly Timeline
                </h4>

                <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-4 pl-6 md:pl-8 space-y-8 py-2">
                  {generateRoadmapWeeks().map((week, idx) => {
                    const isExpanded = !!expandedWeeks[week.weekNumber];
                    return (
                      <div key={week.weekNumber} className="relative group">
                        {/* Bullet Marker */}
                        <span className={cn(
                          "absolute -left-[35px] md:-left-[43px] top-1.5 flex items-center justify-center rounded-full border transition-all duration-300",
                          week.status === 'completed' 
                            ? "h-6 w-6 md:h-8 md:w-8 bg-emerald-500 border-emerald-500 text-white shadow-emerald-500/10 shadow-lg" 
                            : week.status === 'in_progress'
                            ? "h-6 w-6 md:h-8 md:w-8 bg-amber-500 border-amber-500 text-white shadow-amber-500/20 animate-pulse border-2"
                            : "h-6 w-6 md:h-8 md:w-8 bg-slate-100 dark:bg-slate-800 border-slate-250 dark:border-slate-700 text-slate-400 dark:text-slate-500"
                        )}>
                          {week.status === 'completed' ? (
                            <CheckCircle size={14} className="md:size-4 font-black" />
                          ) : week.status === 'in_progress' ? (
                            <Flame size={12} className="md:size-4" />
                          ) : (
                            <span className="text-[10px] md:text-xs font-black">{week.weekNumber}</span>
                          )}
                        </span>

                        {/* Card Component */}
                        <div className={cn(
                          "p-5 rounded-2xl border transition-all duration-300",
                          week.status === 'completed'
                            ? "bg-emerald-50 dark:bg-emerald-950/10 border-emerald-200/50 dark:border-emerald-900/30"
                            : week.status === 'in_progress'
                            ? "bg-amber-50/30 dark:bg-amber-950/5 border-amber-300/40 dark:border-amber-900/20 shadow-md ring-1 ring-amber-500/10"
                            : "bg-white dark:bg-slate-850/30 border-slate-200/70 dark:border-slate-800/80"
                        )}>
                          <div 
                            className="flex items-center justify-between cursor-pointer select-none"
                            onClick={() => setExpandedWeeks(prev => ({ ...prev, [week.weekNumber]: !isExpanded }))}
                          >
                            <div className="space-y-1 pr-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className={cn(
                                  "text-[9px] uppercase font-black px-1.5 py-0.5 rounded",
                                  week.status === 'completed'
                                    ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400"
                                    : week.status === 'in_progress'
                                    ? "bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400"
                                    : "bg-slate-100 dark:bg-slate-850 text-slate-500"
                                )}>
                                  {week.status === 'completed' ? "Milestone Cleared" : week.status === 'in_progress' ? "Active Sprint" : "Locked Block"}
                                </span>
                                <span className="text-[11px] opacity-60 font-bold">
                                  Week {week.weekNumber} Plan
                                </span>
                              </div>
                              <h5 className="font-extrabold text-sm sm:text-base tracking-tight leading-snug">
                                {week.title}
                              </h5>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="text-[11px] font-black opacity-60 hidden sm:inline">
                                {week.completedCount}/{week.totalCount} lessons ({week.progressPercent}%)
                              </span>
                              {isExpanded ? <ChevronDown size={18} className="opacity-60" /> : <ChevronRight size={18} className="opacity-60" />}
                            </div>
                          </div>

                          {/* Expanded Content with Lessons Checklist */}
                          {isExpanded && (
                            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3 animate-fadeIn">
                              <p className="text-xs opacity-75 italic leading-relaxed">
                                Targets the comprehensive subtopics of <strong>{week.chapters.join(', ')}</strong> at chosen study depth level. Complete lessons to update progress indicator.
                              </p>

                              {/* Lesson Items */}
                              <div className="space-y-2 mt-2">
                                {week.lessons.map((les) => {
                                  const isCompleted = !!completedLessons[`${week.chapters[0]}_${les.id}`];
                                  return (
                                    <div 
                                      key={les.id} 
                                      className={cn(
                                        "p-3 rounded-xl border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2",
                                        isCompleted 
                                          ? "bg-emerald-500/5 border-emerald-500/20 text-emerald-800 dark:text-emerald-300"
                                          : theme === 'dark' ? "bg-slate-800/40 border-slate-800" : "bg-slate-50 border-slate-200"
                                      )}
                                    >
                                      <div className="flex items-start gap-2.5">
                                        <button 
                                          onClick={() => {
                                            // Toggle lesson complete state
                                            const key = `${week.chapters[0]}_${les.id}`;
                                            const updated = { ...completedLessons, [key]: !isCompleted };
                                            setCompletedLessons(updated);
                                            try {
                                              localStorage.setItem('completed_lessons_v1', JSON.stringify(updated));
                                            } catch (e) {
                                              console.error(e);
                                            }
                                            showNotification?.(`Updated completion for "${les.title}"!`, 'info');
                                          }}
                                          className={cn(
                                            "mt-0.5 w-4 h-4 rounded border flex items-center justify-center cursor-pointer transition-colors flex-shrink-0",
                                            isCompleted 
                                              ? "bg-emerald-500 border-emerald-500 text-white" 
                                              : "border-slate-350 dark:border-slate-600 hover:border-indigo-500"
                                          )}
                                        >
                                          {isCompleted && <Check size={10} strokeWidth={4} />}
                                        </button>
                                        <div>
                                          <p className="text-xs font-bold leading-tight">{les.title}</p>
                                          <p className="text-[10px] opacity-70 mt-0.5 leading-snug">{les.description}</p>
                                          <div className="flex items-center gap-2 mt-1">
                                            <span className="text-[9px] opacity-60 flex items-center gap-0.5">
                                              <Clock size={10} /> {les.duration}
                                            </span>
                                            <span className="text-[9px] bg-indigo-550/10 text-indigo-500 border border-indigo-550/20 px-1 py-0.2 rounded-full uppercase tracking-wider font-extrabold scale-90">
                                              {les.level}
                                            </span>
                                          </div>
                                        </div>
                                      </div>

                                      <button 
                                        onClick={() => onStudyLesson(les.title, week.chapters[0], chosenDepth)}
                                        className="py-1 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-extrabold cursor-pointer transition-colors flex items-center gap-1 self-end sm:self-auto"
                                      >
                                        Study Lesson <ArrowRight size={10} />
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>

                              {/* Week-level Actions */}
                              <div className="flex items-center justify-end gap-3 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                                <button
                                  onClick={() => setReminderModalWeek({ weekNumber: week.weekNumber, title: week.title })}
                                  className={cn(
                                    "py-1.5 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border",
                                    reminders.some(r => r.weekNumber === week.weekNumber && r.isActive)
                                      ? "bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-400 hover:bg-amber-500/20"
                                      : "bg-slate-100 dark:bg-slate-800 border-slate-200/60 dark:border-slate-700/60 hover:bg-indigo-600 hover:text-white hover:border-indigo-600"
                                  )}
                                >
                                  {reminders.some(r => r.weekNumber === week.weekNumber && r.isActive) ? (
                                    <>
                                      <span className="relative flex h-2 w-2">
                                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                                        <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                                      </span>
                                      Active Reminder
                                    </>
                                  ) : (
                                    <>
                                      <Bell size={13} className="text-slate-400 group-hover:text-white" />
                                      Set Reminder
                                    </>
                                  )}
                                </button>

                                <button
                                  onClick={() => onGenerateQuiz(week.chapters[0])}
                                  className="py-1.5 px-3.5 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                                >
                                  <Brain size={13} className="text-indigo-500 group-hover:text-white" />
                                  Practice Week Quiz
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* AI Coaching Sidebar */}
              <div className="lg:col-span-5 space-y-4">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                  🤖 AI Study Coach & Strategic Advice
                </h4>

                <div className={cn(
                  "p-5 rounded-2xl border space-y-4",
                  theme === 'dark' ? "bg-slate-850/40 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                )}>
                  <div className="flex items-center gap-2 text-indigo-500">
                    <Sparkles className="text-amber-500 animate-pulse" size={18} />
                    <h5 className="font-extrabold text-sm">Dynamic AI Roadmap Coach</h5>
                  </div>
                  <p className="text-xs opacity-75 leading-relaxed">
                    Instantly personalize your study timeline based on current completions, chosen depth, and cognitive spacing models.
                  </p>

                  <button
                    onClick={handleGenerateRoadmapTips}
                    disabled={isGeneratingRoadmapTips}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white disabled:bg-indigo-650 disabled:opacity-50 rounded-xl text-xs font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md hover:shadow-lg"
                  >
                    {isGeneratingRoadmapTips ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" />
                        Analyzing Academic Progress...
                      </>
                    ) : (
                      <>
                        <Wand2 size={14} />
                        Personalize Plan with Omni AI
                      </>
                    )}
                  </button>

                  {/* Advice Text Panel */}
                  <div className={cn(
                    "p-4 rounded-xl border max-h-[450px] overflow-y-auto text-xs leading-relaxed",
                    theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-150"
                  )}>
                    {roadmapTips ? (
                      <div className="prose prose-xs dark:prose-invert space-y-3 whitespace-pre-line font-medium opacity-90">
                        {roadmapTips}
                      </div>
                    ) : (
                      <div className="space-y-4 font-medium">
                        <p className="text-[11px] uppercase tracking-wider font-black text-slate-400 flex items-center gap-1">
                          <Clock size={11} /> Recommended Strategy Fallback:
                        </p>
                        <div className="space-y-2">
                          <p className="flex items-start gap-1.5">
                            <span className="text-indigo-500 mt-0.5">•</span>
                            <span><strong>Spaced Repetition Integration</strong>: Dedicate 15 minutes daily to reviewing completed concepts via active recall techniques. This stabilizes long-term retention.</span>
                          </p>
                          <p className="flex items-start gap-1.5">
                            <span className="text-indigo-500 mt-0.5">•</span>
                            <span><strong>Targeted Testing</strong>: Solve a practice quiz for each chapter immediately after marking its lessons as completed. Benchmark with honors-tier parameters to diagnose weak spots.</span>
                          </p>
                          <p className="flex items-start gap-1.5">
                            <span className="text-indigo-500 mt-0.5">•</span>
                            <span><strong>Active Progression</strong>: Click "Study Lesson" to open an immersive interactive panel, helping clarify any tricky theoretical roadblocks step-by-step.</span>
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="text-[10px] opacity-50 flex items-center gap-1.5 justify-center">
                    <Clock size={11} /> Spaced-repetition & active recall active
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (activeTab as any) === 'learning-style' ? (
          /* VARK Learning Style Adaptive Profile */
          <div className="h-full w-full max-w-4xl mx-auto animate-fadeIn pb-12 pt-4">
            <LearningStyleCard />
          </div>
        ) : (activeTab as any) === 'metacognition' ? (
          /* Metacognition Dashboard Session */
          <div className="h-full w-full animate-fadeIn pb-12">
            <MetacognitionDashboard 
              subject={subject}
              onClose={() => setActiveTab('syllabus')}
              onStartTargetedPractice={() => setActiveTab('mixed-practice' as any)}
            />
          </div>
        ) : (activeTab as any) === 'free-recall' ? (
          /* Free Recall Active Retrieval Session */
          <div className="h-full w-full animate-fadeIn pb-12">
            <FreeRecall 
              subject={subject}
              chapterId={mapChapterTitleToId(selectedChapter || 'relations_functions')}
              chapterTitle={selectedChapter || 'Relations and Functions'}
              onRewardXp={onRewardXp}
              showNotification={showNotification}
              onClose={() => setActiveTab('syllabus')}
            />
          </div>
        ) : (activeTab as any) === 'mixed-practice' ? (
          /* Interleaved Mixed Practice Session */
          <div className="h-full w-full animate-fadeIn pb-12">
            <MixedPracticeSession 
              subject={subject}
              currentChapterId={mapChapterTitleToId(selectedChapter || 'relations_functions')}
              onClose={() => setActiveTab('syllabus')}
              onRewardXp={onRewardXp}
              showNotification={showNotification}
            />
          </div>
        ) : activeTab === 'periodic-table' ? (
          /* Chemistry Interactive Periodic Table Overlay */
          <div className="h-full w-full animate-fadeIn pb-12">
            <ChemistryPeriodicOverlay 
              theme={theme} 
              onClose={() => setActiveTab('syllabus')}
              showNotification={showNotification} 
            />
          </div>
        ) : activeTab === 'goals' ? (
          /* Daily Smart Study Goals Tab View */
          <div className="h-full max-w-5xl mx-auto space-y-8 animate-fadeIn pb-12">
            {/* Header Banner */}
            <div className={cn(
              "p-6 rounded-2xl border flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden",
              theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-gradient-to-r from-indigo-50/10 via-white to-slate-50 border-slate-200/80 shadow-xs"
            )}>
              <div className="absolute top-0 left-0 w-1.5 h-full bg-indigo-500"></div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Target size={24} className="text-indigo-500 animate-pulse" />
                  <h3 className="text-xl font-black tracking-tight">Daily Smart Study Goals</h3>
                </div>
                <p className="text-xs sm:text-sm opacity-80 leading-relaxed max-w-2xl">
                  Conquer micro-objectives dynamically generated from your progress and skill mastery. Claim XP to raise your level!
                </p>
                <p className="text-[10px] text-indigo-500 font-bold flex items-center gap-1.5 uppercase tracking-wide">
                  <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span> 
                  Refreshes every 24 hours • Live Sync Active
                </p>
              </div>
              <div className="flex items-center gap-3 flex-wrap shrink-0">
                <div className="flex items-center gap-1 bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 px-3.5 py-1.5 rounded-full font-black text-xs">
                  <Flame size={14} className="animate-pulse" />
                  {goalStreak} Day Streak
                </div>
                <button
                  onClick={handleAICalibrateGoals}
                  disabled={isGeneratingGoals}
                  className={cn(
                    "py-2 px-4 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shadow-sm border",
                    theme === 'dark' 
                      ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-white" 
                      : "bg-white border-slate-200 hover:bg-slate-50 text-slate-800"
                  )}
                >
                  <Wand2 size={13} className={isGeneratingGoals ? "animate-spin text-indigo-500" : "text-amber-500"} />
                  {isGeneratingGoals ? "Calibrating..." : "AI Re-Calibrate"}
                </button>
              </div>
            </div>

            {/* Overall Completion Dashboard Summary */}
            <div className={cn(
              "p-6 rounded-2xl border grid grid-cols-1 md:grid-cols-3 gap-6 items-center",
              theme === 'dark' ? "bg-slate-850/50 border-slate-800" : "bg-white border-slate-150 shadow-sm"
            )}>
              <div className="space-y-1.5 md:col-span-2">
                <div className="flex justify-between items-center text-xs font-bold">
                  <span>TODAY'S CAMPAIGN PROGRESS</span>
                  <span className="text-indigo-500">
                    {goals.filter(g => g.status === 'claimed' || g.status === 'completed').length} / 4 GOALS CONQUERED
                  </span>
                </div>
                <div className="h-3.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden p-0.5 border dark:border-slate-700">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 via-indigo-600 to-pink-500 rounded-full transition-all duration-700"
                    style={{ width: `${(goals.filter(g => g.status === 'claimed' || g.status === 'completed').length / 4) * 100}%` }}
                  />
                </div>
                <p className="text-[11px] opacity-60">
                  Claim goals to unlock extra profile experience. Complete all 4 daily goals to trigger perfect-day bonus rewards!
                </p>
              </div>
              <div className="flex flex-col items-center justify-center p-4 border-t md:border-t-0 md:border-l border-slate-100 dark:border-slate-800 text-center">
                <div className="text-2xl font-black text-indigo-500">
                  +{goals.filter(g => g.status === 'claimed').reduce((sum, g) => sum + g.xpReward, 0)} XP
                </div>
                <div className="text-[10px] uppercase font-black tracking-wider opacity-60 mt-1">XP Earned Today</div>
                <div className="text-xs font-extrabold mt-2 text-slate-500 dark:text-slate-400">
                  {totalClaimedGoals} total goals claimed
                </div>
              </div>
            </div>

            {/* Core Bento Grid of Micro-Objectives */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {goals.map((goal) => {
                const isClaimed = goal.status === 'claimed';
                const isCompleted = goal.status === 'completed';
                const isPending = goal.status === 'not_started' || goal.status === 'in_progress';
                const IconComponent = 
                  goal.type === 'syllabus' ? BookOpen :
                  goal.type === 'quiz' ? Award :
                  goal.type === 'mastery' ? Brain :
                  Clock;

                return (
                  <div 
                    key={goal.id}
                    className={cn(
                      "p-5 rounded-2xl border flex flex-col justify-between transition-all relative overflow-hidden",
                      isClaimed 
                        ? "opacity-60 bg-slate-100/10 border-slate-200/10"
                        : isCompleted
                        ? "border-emerald-500/40 bg-emerald-500/5 ring-1 ring-emerald-500/20"
                        : theme === 'dark' ? "bg-slate-900 border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 shadow-xs hover:border-slate-300"
                    )}
                  >
                    {isCompleted && (
                      <div className="absolute top-0 right-0 w-24 h-24 overflow-hidden pointer-events-none">
                        <div className="absolute top-3 right-[-30px] bg-emerald-500 text-white text-[9px] font-black py-1 px-8 rotate-45 text-center shadow-xs uppercase tracking-widest animate-pulse">
                          Ready
                        </div>
                      </div>
                    )}

                    <div className="space-y-3.5">
                      {/* Top Row with Type and XP Badge */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className={cn(
                            "p-2 rounded-lg",
                            isCompleted 
                              ? "bg-emerald-500/15 text-emerald-500" 
                              : "bg-indigo-500/10 text-indigo-500"
                          )}>
                            <IconComponent size={16} />
                          </div>
                          <span className="text-[10px] font-black uppercase tracking-wider opacity-60">
                            {goal.type === 'syllabus' ? "Syllabus Explore" :
                             goal.type === 'quiz' ? "Practice Quiz" :
                             goal.type === 'mastery' ? "Mastery Booster" :
                             "Interactive Focus"}
                          </span>
                        </div>
                        <span className="text-xs font-black text-amber-600 dark:text-amber-400 bg-amber-500/10 border border-amber-500/10 px-2 py-0.5 rounded-full">
                          +{goal.xpReward} XP
                        </span>
                      </div>

                      {/* Title and Description */}
                      <div className="space-y-1">
                        <h4 className="font-extrabold text-sm md:text-base leading-tight">
                          {goal.title}
                        </h4>
                        <p className="text-xs opacity-75 leading-relaxed">
                          {goal.description}
                        </p>
                      </div>

                      {/* Progress Line */}
                      <div className="space-y-1">
                        <div className="flex justify-between items-center text-[10px] font-bold opacity-60">
                          <span>PROGRESS</span>
                          <span>{goal.progress} / {goal.max}</span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              "h-full rounded-full transition-all duration-500",
                              isCompleted ? "bg-emerald-500" : "bg-indigo-500"
                            )}
                            style={{ width: `${(goal.progress / goal.max) * 100}%` }}
                          />
                        </div>
                      </div>

                      {/* Personal Coach Tip */}
                      {goal.personalTip && (
                        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-850/60 text-[11px] font-medium opacity-80 border dark:border-slate-800">
                          {goal.personalTip}
                        </div>
                      )}

                      {/* Expanded Mini Quiz Drill */}
                      {activeDrillGoalId === goal.id && (
                        <div className="p-4 rounded-xl border border-indigo-500/30 bg-indigo-500/5 mt-3 space-y-4 animate-fadeIn">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black uppercase text-indigo-500 flex items-center gap-1">
                              <Sparkles size={11} className="animate-spin" /> Concept Quick Evaluation
                            </span>
                            <button 
                              onClick={() => {
                                setActiveDrillGoalId(null);
                                setDrillAnswers({});
                                setDrillChecked(false);
                                setDrillSuccess(false);
                              }}
                              className="text-xs p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded opacity-60"
                            >
                              Cancel
                            </button>
                          </div>
                          
                          <div className="space-y-3.5 divide-y divide-slate-150 dark:divide-slate-800">
                            {getDrillQuestions(goal.targetChapter || "").map((q, idx) => (
                              <div key={idx} className={cn("space-y-2", idx > 0 && "pt-3")}>
                                <p className="text-[11px] font-bold leading-relaxed">{idx + 1}. {q.q}</p>
                                <div className="grid grid-cols-1 gap-1.5">
                                  {q.options.map((opt, optIdx) => {
                                    const isSelected = drillAnswers[idx] === optIdx;
                                    return (
                                      <button
                                        key={optIdx}
                                        onClick={() => {
                                          if (drillChecked) return;
                                          setDrillAnswers(prev => ({ ...prev, [idx]: optIdx }));
                                        }}
                                        disabled={drillChecked}
                                        className={cn(
                                          "w-full text-left p-2 rounded-lg text-[10px] font-medium transition-all cursor-pointer border",
                                          isSelected 
                                            ? "border-indigo-500 bg-indigo-500/10 font-bold" 
                                            : "border-transparent bg-slate-100/40 dark:bg-slate-800/40 hover:bg-slate-200/50"
                                        )}
                                      >
                                        {opt}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            ))}
                          </div>

                          {drillChecked ? (
                            <div className="space-y-2">
                              {drillSuccess ? (
                                <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-500 text-[11px] font-bold text-center">
                                  ✓ Excellent! All answers are correct. Micro-objective completed!
                                </div>
                              ) : (
                                <div className="p-2.5 rounded-lg bg-red-500/10 text-red-500 text-[11px] font-bold text-center space-y-1">
                                  <p>❌ Some answers are incorrect. Review the core concepts and try again!</p>
                                  <button
                                    onClick={() => {
                                      setDrillChecked(false);
                                      setDrillAnswers({});
                                    }}
                                    className="text-[10px] text-indigo-500 hover:underline font-extrabold block mx-auto"
                                  >
                                    Try Again
                                  </button>
                                </div>
                              )}
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                const qList = getDrillQuestions(goal.targetChapter || "");
                                let correctCount = 0;
                                qList.forEach((q, idx) => {
                                  if (drillAnswers[idx] === q.correct) {
                                    correctCount++;
                                  }
                                });

                                setDrillChecked(true);
                                if (correctCount === qList.length) {
                                  setDrillSuccess(true);
                                  const updatedGoals = goals.map(g => {
                                    if (g.id === goal.id) {
                                      return { ...g, progress: 1, status: 'completed' as const };
                                    }
                                    return g;
                                  });
                                  setGoals(updatedGoals);
                                  localStorage.setItem(`daily_goals_${subject}`, JSON.stringify(updatedGoals));
                                  if (showNotification) {
                                    showNotification("🌟 Goal complete! Claim your XP reward!", "success");
                                  }
                                } else {
                                  setDrillSuccess(false);
                                  if (showNotification) {
                                    showNotification("❌ Some answers were incorrect. Give it another shot!", "error");
                                  }
                                }
                              }}
                              disabled={Object.keys(drillAnswers).length < 3}
                              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all disabled:opacity-50"
                            >
                              Verify Solutions & Complete Goal
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Button Segment */}
                    <div className="border-t border-slate-100 dark:border-slate-800 pt-4 mt-4 flex items-center justify-between gap-3">
                      {isClaimed ? (
                        <div className="text-xs font-black text-slate-400 dark:text-slate-500 flex items-center gap-1.5 w-full justify-center py-1 bg-slate-50 dark:bg-slate-900 rounded-xl">
                          <CheckCircle size={14} className="text-amber-500/60" /> Goal Conquered & Claimed
                        </div>
                      ) : isCompleted ? (
                        <button
                          onClick={() => {
                            playClaimRewardSound();
                            confetti({
                              particleCount: 80,
                              spread: 60,
                              origin: { y: 0.7 }
                            });
                            
                            const updatedGoals = goals.map(g => {
                              if (g.id === goal.id) {
                                return { ...g, status: 'claimed' as const };
                              }
                              return g;
                            });
                            setGoals(updatedGoals);
                            localStorage.setItem(`daily_goals_${subject}`, JSON.stringify(updatedGoals));

                            const nextCount = totalClaimedGoals + 1;
                            setTotalClaimedGoals(nextCount);
                            localStorage.setItem(`total_claimed_goals_${subject}`, nextCount.toString());

                            if (showNotification) {
                              showNotification(`🏆 +${goal.xpReward} XP claimed successfully! Keep up the brilliant study sprint!`, "success");
                            }
                          }}
                          className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer transform hover:-translate-y-0.5"
                        >
                          <Sparkles size={14} className="animate-pulse" /> Claim +{goal.xpReward} XP Reward
                        </button>
                      ) : (
                        <div className="flex gap-2 w-full">
                          {goal.type === 'syllabus' ? (
                            <button
                              onClick={() => {
                                setActiveTab('syllabus');
                                if (goal.targetChapter) {
                                  setSelectedChapter(goal.targetChapter);
                                }
                              }}
                              className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all text-center cursor-pointer"
                            >
                              Go Study Lesson 📚
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                setDrillChecked(false);
                                setDrillAnswers({});
                                setDrillSuccess(false);
                                setActiveDrillGoalId(goal.id);
                              }}
                              className="flex-1 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-xs font-bold transition-all text-center cursor-pointer"
                            >
                              Solve Practice Concept ⚡
                            </button>
                          )}
                          <button
                            onClick={() => {
                              const updatedGoals = goals.map(g => {
                                if (g.id === goal.id) {
                                  return { ...g, progress: g.max, status: 'completed' as const };
                                }
                                return g;
                              });
                              setGoals(updatedGoals);
                              localStorage.setItem(`daily_goals_${subject}`, JSON.stringify(updatedGoals));
                              if (showNotification) {
                                showNotification("🎯 Goal checked off manually!", "success");
                              }
                            }}
                            className="py-2 px-3 bg-slate-50 dark:bg-slate-850 hover:bg-emerald-500 hover:text-white rounded-xl text-xs font-bold transition-all border dark:border-slate-800"
                            title="Force Complete Goal"
                          >
                            ✓ Complete
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* Public SEO & Landings Tab View */
          <div className="h-full max-w-5xl mx-auto space-y-8 animate-fadeIn">
            {/* Header Banner */}
            <div className={cn(
              "p-6 rounded-2xl border space-y-3",
              theme === 'dark' ? "bg-indigo-950/15 border-indigo-900/50" : "bg-indigo-50/20 border-indigo-100"
            )}>
              <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
                <Globe size={20} className="animate-pulse" />
                <h3 className="text-lg font-black tracking-tight">Public Curriculum Discovery Engine</h3>
              </div>
              <p className="text-xs sm:text-sm opacity-80 leading-relaxed max-w-3xl">
                Our dynamic index directory generates high-grade search-engine crawlable web pages for queries like <strong>"JNU Foreign Language Syllabus Companion"</strong>, <strong>"AP Calculus Step-by-Step Solver"</strong>, or custom student study guides. When students search for these topics online, they will land on your static cheatsheet notes and can directly discover and launch your interactive board preview!
              </p>
            </div>

            {/* Pre-indexed Curriculums Landings */}
            <div className="space-y-4">
              <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                🎯 Core Pre-Indexed Curriculum Landings
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  {
                    title: "JNU Foreign Language Syllabus Companion",
                    slug: "jnu-foreign-language-syllabus-companion",
                    subject: "Languages",
                    desc: "Geopolitics, historical events, grammatical structures and memory aids.",
                    keywords: "JNU entrance syllabus, French/German exam notes"
                  },
                  {
                    title: "AP Calculus Step-by-Step Solver",
                    slug: "ap-calculus-step-by-step-solver",
                    subject: "Mathematics",
                    desc: "Interactive theorem limits, derivatives list, and solved Riemann sums.",
                    keywords: "AP Calculus limits, derivatives solver"
                  },
                  {
                    title: "CBSE Class XII Physics Companion",
                    slug: "cbse-class-xii-physics-helper",
                    subject: "Physics",
                    desc: "NCERT linear electrostatic flux, Ohm's drift velocity, and loop derivations.",
                    keywords: "CBSE Class 12 electrostatics formulas"
                  }
                ].map((land) => (
                  <div
                    key={land.slug}
                    className={cn(
                      "p-5 rounded-2xl border flex flex-col justify-between group",
                      theme === 'dark' ? "bg-slate-850/50 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    )}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] uppercase font-black bg-indigo-500/10 text-indigo-500 dark:text-indigo-400 px-2 py-0.5 rounded-md">
                          {land.subject}
                        </span>
                        <span className="text-[9px] font-bold text-emerald-650 text-emerald-500 flex items-center gap-1">
                          🟢 Live & Indexed
                        </span>
                      </div>
                      <h4 className="font-extrabold text-sm mt-3 tracking-tight group-hover:text-indigo-500 transition-colors leading-tight">
                        {land.title}
                      </h4>
                      <p className="text-xs opacity-60 mt-1 leading-relaxed">
                        {land.desc}
                      </p>
                      <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-2 italic">
                        SEO Keywords: {land.keywords}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 border-t border-slate-100 dark:border-slate-800 pt-3.5 mt-4">
                      <button
                        onClick={() => handleCopyLink(`/curriculum-landing/${land.slug}`, land.slug)}
                        className="flex-1 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-650 hover:bg-indigo-600 hover:text-white rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        {copiedItemId === land.slug ? <Check size={12} /> : <Copy size={12} />}
                        {copiedItemId === land.slug ? "Copied" : "Copy URL"}
                      </button>
                      <a
                        href={`/curriculum-landing/${land.slug}`}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center"
                        title="View Live Webpage"
                      >
                        <ExternalLink size={14} />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Student Published Guides Directory */}
            <div className="space-y-4">
              <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                📋 Dynamic Student-Published Study Guides
              </h4>

              {loadingPublic ? (
                <div className="py-12 text-center opacity-60 text-xs">
                  <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                  Fetching crawlable study pages...
                </div>
              ) : publicGuides.filter(g => !['ap-calculus-step-by-step-solver', 'jnu-foreign-language-syllabus-companion', 'cbse-class-xii-physics-helper'].includes(g.id)).length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {publicGuides.filter(g => !['ap-calculus-step-by-step-solver', 'jnu-foreign-language-syllabus-companion', 'cbse-class-xii-physics-helper'].includes(g.id)).map((g) => (
                    <div
                      key={g.id}
                      className={cn(
                        "p-4 rounded-xl border flex flex-col justify-between",
                        theme === 'dark' ? "bg-slate-850/40 border-slate-800" : "bg-white border-slate-150 shadow-sm"
                      )}
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] uppercase font-black bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 px-1.5 py-0.5 rounded">
                            {g.subject}
                          </span>
                          <span className="text-[9px] opacity-50 font-semibold">
                            {new Date(g.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <h5 className="font-extrabold text-sm mt-2 leading-tight">{g.title}</h5>
                        <p className="text-xs opacity-60 mt-1 truncate">Topic: {g.topic}</p>
                      </div>

                      <div className="flex items-center gap-2 border-t dark:border-slate-850 pt-3 mt-3">
                        <button
                          onClick={() => handleCopyLink(`/public-guide/${g.id}`, g.id)}
                          className="flex-1 py-1 px-2.5 bg-slate-50 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white rounded-md text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer border border-slate-100 dark:border-slate-700"
                        >
                          {copiedItemId === g.id ? <Check size={12} /> : <Copy size={12} />}
                          {copiedItemId === g.id ? "Copied" : "Copy URL"}
                        </button>
                        <a
                          href={`/public-guide/${g.id}`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-bold transition-colors flex items-center justify-center"
                          title="Open Live Webpage"
                        >
                          <ExternalLink size={13} />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className={cn(
                  "p-8 text-center rounded-2xl border border-dashed",
                  theme === 'dark' ? "border-slate-800/80 text-slate-500" : "border-slate-250 text-slate-400"
                )}>
                  <Globe className="mx-auto opacity-40 mb-2" size={24} />
                  <p className="text-xs font-bold">No dynamic student guides indexed yet</p>
                  <p className="text-[11px] opacity-70 mt-1 max-w-xs mx-auto">
                    Complete learning chats, click "Recap Session" to save your summary note, open it from the "Saved Study Notes" tab, and click <strong>"Publish to Web"</strong> to index your cheatsheet!
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <RoadmapCalendarModal 
        isOpen={isCalendarOpen}
        onClose={() => setIsCalendarOpen(false)}
        weeks={generateRoadmapWeeks()}
        completedLessons={completedLessons}
        onToggleLesson={(chapterTitle, lessonId) => {
          const key = `${chapterTitle}_${lessonId}`;
          setCompletedLessons(prev => {
            const val = !prev[key];
            const updated = { ...prev, [key]: val };
            try {
              localStorage.setItem('completed_lessons_v1', JSON.stringify(updated));
            } catch (e) {
              console.error(e);
            }
            if (showNotification) {
              showNotification(val ? 'Lesson marked as completed! 🎉' : 'Lesson marked as incomplete.', 'info');
            }
            return updated;
          });
        }}
        onStudyLesson={onStudyLesson}
        subject={subject}
        difficulty={difficulty}
        boardName={boardName}
        theme={theme}
        reminders={reminders}
        onOpenReminderModal={(weekNumber, title) => setReminderModalWeek({ weekNumber, title })}
      />

      {/* Set Reminder Modal */}
      {reminderModalWeek && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className={cn(
            "w-full max-w-md p-6 rounded-2xl border shadow-xl animate-scaleIn",
            theme === 'dark' ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-900"
          )}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <BellRing size={20} className="text-indigo-500 animate-pulse" />
                <h4 className="font-extrabold text-base">Schedule Week {reminderModalWeek.weekNumber} Reminder</h4>
              </div>
              <button 
                onClick={() => setReminderModalWeek(null)}
                className="text-xs p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md opacity-60 hover:opacity-100"
              >
                ✕
              </button>
            </div>
            
            <p className="text-xs opacity-70 mb-4">
              Set a study alert for <strong>{reminderModalWeek.title}</strong>. This triggers an in-app audio chime and persistent notification when the study sprint starts!
            </p>

            <div className="space-y-3">
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Fast Simulation Presets</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleSetReminder(reminderModalWeek.weekNumber, reminderModalWeek.title, 5)}
                  className="py-2 px-3 text-left rounded-xl bg-indigo-500/10 hover:bg-indigo-500 text-indigo-600 hover:text-white dark:text-indigo-400 text-xs font-bold transition-all"
                >
                  ⏱️ Immediate (5s)
                </button>
                <button
                  onClick={() => handleSetReminder(reminderModalWeek.weekNumber, reminderModalWeek.title, 30)}
                  className="py-2 px-3 text-left rounded-xl bg-indigo-500/10 hover:bg-indigo-500 text-indigo-600 hover:text-white dark:text-indigo-400 text-xs font-bold transition-all"
                >
                  ⏱️ Spacing (30s)
                </button>
                <button
                  onClick={() => handleSetReminder(reminderModalWeek.weekNumber, reminderModalWeek.title, 120)}
                  className="py-2 px-3 text-left rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white text-xs font-bold transition-all"
                >
                  ⏱️ Quick (2 min)
                </button>
                <button
                  onClick={() => handleSetReminder(reminderModalWeek.weekNumber, reminderModalWeek.title, 600)}
                  className="py-2 px-3 text-left rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white text-xs font-bold transition-all"
                >
                  ⏱️ Medium (10 min)
                </button>
              </div>

              <div className="border-t border-slate-150 dark:border-slate-800 pt-3 mt-2 space-y-2">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Custom Timer (Minutes)</span>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    max="1440"
                    value={customMinutes}
                    onChange={(e) => setCustomMinutes(e.target.value)}
                    className={cn(
                      "flex-1 px-3 py-1.5 rounded-xl border text-xs focus:ring-1 focus:ring-indigo-500 outline-none",
                      theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-200"
                    )}
                  />
                  <button
                    onClick={() => {
                      const mins = parseFloat(customMinutes);
                      if (mins > 0) {
                        handleSetReminder(reminderModalWeek.weekNumber, reminderModalWeek.title, mins * 60);
                      }
                    }}
                    className="py-1.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    Set Custom
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-150 dark:border-slate-800 gap-2">
              {reminders.some(r => r.weekNumber === reminderModalWeek.weekNumber && r.isActive) ? (
                <button
                  onClick={() => handleCancelReminder(reminderModalWeek.weekNumber)}
                  className="py-2 px-4 bg-red-500 hover:bg-red-600 text-white rounded-xl text-xs font-bold transition-colors flex-1"
                >
                  Cancel Active Reminder
                </button>
              ) : (
                <button
                  onClick={() => setReminderModalWeek(null)}
                  className="py-2 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-xs font-bold transition-colors flex-1"
                >
                  Keep Blank
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Triggered Reminder Alert */}
      {triggeredReminder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className={cn(
            "w-full max-w-md p-6 rounded-2xl border border-amber-500/30 shadow-2xl text-center relative overflow-hidden",
            theme === 'dark' ? "bg-slate-900 text-slate-100" : "bg-white text-slate-900"
          )}>
            <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-amber-500 via-indigo-500 to-pink-500"></div>
            
            <div className="mx-auto w-16 h-16 bg-amber-500/10 text-amber-500 rounded-full flex items-center justify-center mb-4 mt-2">
              <BellRing size={32} className="animate-bounce" />
            </div>

            <span className="text-[10px] font-black uppercase text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full">
              Syllabus Study Alert
            </span>

            <h4 className="font-extrabold text-lg mt-3">Study Week {triggeredReminder.weekNumber} Begins!</h4>
            <p className="text-sm font-extrabold text-indigo-500 mt-1">{triggeredReminder.weekTitle}</p>
            
            <p className="text-xs opacity-75 mt-3 px-2 leading-relaxed">
              Your scheduled milestone alert has fired. It's time to unlock this week's active sprint, check off your syllabus topics, and start learning! 🎓🚀
            </p>

            <div className="flex gap-2.5 mt-6">
              <button
                onClick={() => {
                  setTriggeredReminder(null);
                  setExpandedWeeks(prev => ({ ...prev, [triggeredReminder.weekNumber]: true }));
                }}
                className="flex-1 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-500/10"
              >
                Go to Week Timeline 📚
              </button>
              <button
                onClick={() => setTriggeredReminder(null)}
                className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-xs font-bold transition-all"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Anonymous Doubt Board Modal */}
      {selectedDoubtChapter && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="w-full max-w-5xl my-auto animate-in fade-in zoom-in-95 duration-200">
            <DoubtBoard
              chapterId={selectedDoubtChapter.toLowerCase().replace(/[^a-z0-9]/g, '_')}
              chapterTitle={selectedDoubtChapter}
              isDark={theme === 'dark'}
              onClose={() => setSelectedDoubtChapter(null)}
            />
          </div>
        </div>
      )}

    </div>
  );
};
