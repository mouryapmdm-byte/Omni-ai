import { useState, useEffect, useCallback, useRef } from 'react';

export type VideoQuality = 'auto' | 'low' | 'medium' | 'high';

export interface QualityStream {
  quality: 'low' | 'medium' | 'high';
  url: string;
  bitrate: number; // in kbps
  resolution: string;
}

// Default standard educational stream streams for ABR testing
export const DEFAULT_ABR_STREAMS: Record<string, QualityStream[]> = {
  default: [
    {
      quality: 'low',
      url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
      bitrate: 400,
      resolution: '360p (Low Power)'
    },
    {
      quality: 'medium',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      bitrate: 1500,
      resolution: '720p (HD Standard)'
    },
    {
      quality: 'high',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      bitrate: 4500,
      resolution: '1080p (FHD Premium)'
    }
  ]
};

export interface UseAdaptiveBitrateProps {
  videoElementRef: React.RefObject<HTMLVideoElement | null>;
  customStreams?: QualityStream[];
  onQualityChange?: (quality: VideoQuality, streamUrl: string) => void;
}

export function useAdaptiveBitrate({
  videoElementRef,
  customStreams,
  onQualityChange
}: UseAdaptiveBitrateProps) {
  const streams = customStreams || DEFAULT_ABR_STREAMS.default;
  const [selectedQuality, setSelectedQuality] = useState<VideoQuality>('auto');
  const [activeQuality, setActiveQuality] = useState<'low' | 'medium' | 'high'>('medium');
  const [currentBitrate, setCurrentBitrate] = useState<number>(1500); // in kbps
  const [detectedSpeed, setDetectedSpeed] = useState<number>(3500); // in kbps (3.5 Mbps)
  const [isStalling, setIsStalling] = useState(false);
  const [bufferLevel, setBufferLevel] = useState<number>(0); // in seconds

  const lastSpeedCheckRef = useRef<number>(Date.now());
  const stallCountRef = useRef<number>(0);

  // Helper to extract bandwidth using browser network intelligence
  const checkNetworkSpeed = useCallback(() => {
    if (typeof navigator !== 'undefined' && (navigator as any).connection) {
      const conn = (navigator as any).connection;
      // downlink is in Mbps, convert to kbps
      if (conn.downlink) {
        const speedKbps = conn.downlink * 1000;
        setDetectedSpeed(speedKbps);
        return speedKbps;
      }
    }
    return detectedSpeed;
  }, [detectedSpeed]);

  // Performs a quick 100KB fetch test if browser native measurements are stale
  const runActiveSpeedTest = useCallback(async () => {
    const now = Date.now();
    if (now - lastSpeedCheckRef.current < 15000) return; // limit to once every 15 seconds
    lastSpeedCheckRef.current = now;

    try {
      const testFileUrl = 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=200&q=10'; // tiny image
      const startTime = performance.now();
      const response = await fetch(testFileUrl, { cache: 'no-store' });
      const blob = await response.blob();
      const endTime = performance.now();
      
      const durationMs = endTime - startTime;
      const sizeBits = blob.size * 8;
      const speedKbps = sizeBits / durationMs; // bits per ms = kbps
      
      // Set moving average of speed
      setDetectedSpeed(prev => Math.round(prev * 0.4 + speedKbps * 0.6));
    } catch (e) {
      // Fallback silently if speedtest is blocked
    }
  }, []);

  // Buffer health state monitor
  useEffect(() => {
    const video = videoElementRef.current;
    if (!video) return;

    const handleStalled = () => {
      setIsStalling(true);
      stallCountRef.current += 1;
      // Instantly downgrade on multiple stalls to prevent stutter
      if (selectedQuality === 'auto' && stallCountRef.current >= 2) {
        setActiveQuality('low');
      }
    };

    const handleWaiting = () => {
      setIsStalling(true);
    };

    const handlePlaying = () => {
      setIsStalling(false);
      stallCountRef.current = 0;
    };

    const handleProgress = () => {
      if (video.buffered.length > 0) {
        const currentTime = video.currentTime;
        let activeBuffer = 0;
        for (let i = 0; i < video.buffered.length; i++) {
          if (video.buffered.start(i) <= currentTime && video.buffered.end(i) >= currentTime) {
            activeBuffer = video.buffered.end(i) - currentTime;
            break;
          }
        }
        setBufferLevel(Math.round(activeBuffer * 10) / 10);
      }
    };

    video.addEventListener('stalled', handleStalled);
    video.addEventListener('waiting', handleWaiting);
    video.addEventListener('playing', handlePlaying);
    video.addEventListener('progress', handleProgress);
    video.addEventListener('timeupdate', handleProgress);

    return () => {
      video.removeEventListener('stalled', handleStalled);
      video.removeEventListener('waiting', handleWaiting);
      video.removeEventListener('playing', handlePlaying);
      video.removeEventListener('progress', handleProgress);
      video.removeEventListener('timeupdate', handleProgress);
    };
  }, [videoElementRef, selectedQuality]);

  // Core Dynamic Bitrate Decision Loop (Adaptive Heuristics)
  useEffect(() => {
    if (selectedQuality !== 'auto') return;

    const interval = setInterval(() => {
      const speed = checkNetworkSpeed();
      
      // Upgrade/Downgrade decision rules
      let targetQuality: 'low' | 'medium' | 'high' = 'medium';
      
      if (speed < 800 || isStalling || bufferLevel < 2) {
        targetQuality = 'low'; // Low speed or buffer depletion: force 360p
      } else if (speed > 3000 && bufferLevel > 6) {
        targetQuality = 'high'; // High speed + fat buffer: promote to 1080p
      } else {
        targetQuality = 'medium'; // Normal condition: standard 720p
      }

      if (targetQuality !== activeQuality) {
        // Find corresponding stream url
        const targetStream = streams.find(s => s.quality === targetQuality) || streams[0];
        setActiveQuality(targetQuality);
        setCurrentBitrate(targetStream.bitrate);
        
        // Notify handler of adaptive transition
        if (videoElementRef.current) {
          const currentTime = videoElementRef.current.currentTime;
          const isPaused = videoElementRef.current.paused;
          
          onQualityChange?.(targetQuality, targetStream.url);
          
          // Re-sync video playback head position to avoid restarting the lecture
          setTimeout(() => {
            if (videoElementRef.current) {
              videoElementRef.current.currentTime = currentTime;
              if (!isPaused) {
                videoElementRef.current.play().catch(() => {});
              }
            }
          }, 50);
        }
      }
    }, 4000); // Check every 4 seconds for balanced ABR intervals

    return () => clearInterval(interval);
  }, [selectedQuality, activeQuality, isStalling, bufferLevel, checkNetworkSpeed, streams, onQualityChange, videoElementRef]);

  // Change Quality Manually
  const changeQuality = useCallback((quality: VideoQuality) => {
    setSelectedQuality(quality);
    
    let targetQuality: 'low' | 'medium' | 'high' = 'medium';
    if (quality === 'auto') {
      const speed = checkNetworkSpeed();
      targetQuality = speed > 3000 ? 'high' : speed < 800 ? 'low' : 'medium';
    } else {
      targetQuality = quality;
    }

    const targetStream = streams.find(s => s.quality === targetQuality) || streams[0];
    setActiveQuality(targetQuality);
    setCurrentBitrate(targetStream.bitrate);

    if (videoElementRef.current) {
      const currentTime = videoElementRef.current.currentTime;
      const isPaused = videoElementRef.current.paused;
      
      onQualityChange?.(quality, targetStream.url);
      
      setTimeout(() => {
        if (videoElementRef.current) {
          videoElementRef.current.currentTime = currentTime;
          if (!isPaused) {
            videoElementRef.current.play().catch(() => {});
          }
        }
      }, 50);
    }
  }, [streams, onQualityChange, checkNetworkSpeed, videoElementRef]);

  return {
    selectedQuality,
    activeQuality,
    currentBitrate,
    detectedSpeed,
    isStalling,
    bufferLevel,
    changeQuality,
    runActiveSpeedTest
  };
}
