import React, { useState, useEffect } from 'react';
import { cn } from '../lib/utils';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from 'recharts';
import {
  LayoutDashboard,
  Trophy,
  Flame,
  Clock,
  Target,
  Award,
  BookOpen,
  CheckCircle2,
  Circle,
  Plus,
  ChevronRight,
  Play,
  Sparkles,
  TrendingUp,
  BarChart2,
  Calendar,
  ArrowUpRight,
  Zap,
  X,
  Shield,
  Star,
  Check,
  Brain,
  GraduationCap,
  Grid,
  Bot,
  Layers as LayersIcon
} from 'lucide-react';

const SYLLABUS_TOPICS_BY_SUBJECT: Record<
  string,
  Array<{ topic: string; unit: string; mastery: number; status: 'Mastered' | 'Proficient' | 'Developing' | 'Needs Review' }>
> = {
  chemistry: [
    { topic: 'Solutions & Colligative Properties', unit: 'Physical Chemistry', mastery: 95, status: 'Mastered' },
    { topic: 'Electrochemistry & Nernst Equation', unit: 'Physical Chemistry', mastery: 88, status: 'Proficient' },
    { topic: 'Chemical Kinetics & Rate Laws', unit: 'Physical Chemistry', mastery: 92, status: 'Mastered' },
    { topic: 'd- and f-Block Elements', unit: 'Inorganic Chemistry', mastery: 74, status: 'Developing' },
    { topic: 'Coordination Compounds & CFT', unit: 'Inorganic Chemistry', mastery: 82, status: 'Proficient' },
    { topic: 'Haloalkanes & Haloarenes', unit: 'Organic Chemistry', mastery: 96, status: 'Mastered' },
    { topic: 'Alcohols, Phenols & Ethers', unit: 'Organic Chemistry', mastery: 90, status: 'Mastered' },
    { topic: 'Aldehydes, Ketones & Acids', unit: 'Organic Chemistry', mastery: 85, status: 'Proficient' },
    { topic: 'Amines & Diazonium Salts', unit: 'Organic Chemistry', mastery: 78, status: 'Developing' },
    { topic: 'Biomolecules & Polymers', unit: 'Organic Chemistry', mastery: 98, status: 'Mastered' }
  ],
  physics: [
    { topic: 'Electric Charges & Fields', unit: 'Electrostatics', mastery: 94, status: 'Mastered' },
    { topic: 'Electrostatic Potential & Capacitance', unit: 'Electrostatics', mastery: 89, status: 'Proficient' },
    { topic: 'Current Electricity & Circuits', unit: 'Current Electricity', mastery: 91, status: 'Mastered' },
    { topic: 'Moving Charges & Magnetism', unit: 'Magnetic Effects', mastery: 76, status: 'Developing' },
    { topic: 'Electromagnetic Induction', unit: 'EMI & AC', mastery: 84, status: 'Proficient' },
    { topic: 'Ray Optics & Optical Instruments', unit: 'Optics', mastery: 92, status: 'Mastered' },
    { topic: 'Wave Optics & Diffraction', unit: 'Optics', mastery: 80, status: 'Proficient' },
    { topic: 'Dual Nature of Radiation', unit: 'Modern Physics', mastery: 95, status: 'Mastered' },
    { topic: 'Atoms & Nuclei Radioactivity', unit: 'Modern Physics', mastery: 88, status: 'Proficient' },
    { topic: 'Semiconductor Electronics', unit: 'Electronic Devices', mastery: 96, status: 'Mastered' }
  ],
  mathematics: [
    { topic: 'Relations and Functions', unit: 'Relations & Functions', mastery: 95, status: 'Mastered' },
    { topic: 'Inverse Trigonometric Functions', unit: 'Relations & Functions', mastery: 90, status: 'Mastered' },
    { topic: 'Matrices and Determinants', unit: 'Algebra', mastery: 98, status: 'Mastered' },
    { topic: 'Continuity and Differentiability', unit: 'Calculus', mastery: 85, status: 'Proficient' },
    { topic: 'Applications of Derivatives', unit: 'Calculus', mastery: 82, status: 'Proficient' },
    { topic: 'Integrals & Definite Integrals', unit: 'Calculus', mastery: 88, status: 'Proficient' },
    { topic: 'Differential Equations', unit: 'Calculus', mastery: 78, status: 'Developing' },
    { topic: 'Vector Algebra', unit: 'Vectors & 3D', mastery: 94, status: 'Mastered' },
    { topic: 'Three Dimensional Geometry', unit: 'Vectors & 3D', mastery: 81, status: 'Proficient' },
    { topic: 'Linear Programming & Probability', unit: 'Linear Prog & Prob', mastery: 92, status: 'Mastered' }
  ],
  biology: [
    { topic: 'Reproduction in Flowering Plants', unit: 'Reproduction', mastery: 92, status: 'Mastered' },
    { topic: 'Human Reproduction & Health', unit: 'Reproduction', mastery: 88, status: 'Proficient' },
    { topic: 'Principles of Inheritance & Variation', unit: 'Genetics', mastery: 84, status: 'Proficient' },
    { topic: 'Molecular Basis of Inheritance', unit: 'Genetics', mastery: 95, status: 'Mastered' },
    { topic: 'Human Health and Diseases', unit: 'Welfare', mastery: 90, status: 'Mastered' },
    { topic: 'Biotechnology: Principles', unit: 'Biotechnology', mastery: 86, status: 'Proficient' },
    { topic: 'Biotech Applications', unit: 'Biotechnology', mastery: 89, status: 'Proficient' },
    { topic: 'Organisms and Populations', unit: 'Ecology', mastery: 94, status: 'Mastered' },
    { topic: 'Ecosystem and Biodiversity', unit: 'Ecology', mastery: 91, status: 'Mastered' },
    { topic: 'Environmental Issues', unit: 'Ecology', mastery: 96, status: 'Mastered' }
  ]
};
export interface DashboardProps {
  theme?: 'light' | 'dark';
  user?: {
    name: string;
    email?: string;
    subject: string;
    topic: string;
    level?: string | number;
    difficulty: string;
  };
  onClose?: () => void;
  onOpenTool?: (toolId: string) => void;
  onSelectTopic?: (topic: string) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

interface StudySession {
  id: string;
  topic: string;
  subject: string;
  duration: string;
  timestamp: string;
  accuracy: number;
  completed: boolean;
}

interface QuestItem {
  id: string;
  title: string;
  category: string;
  progress: number;
  total: number;
  xpReward: number;
  isClaimed: boolean;
  type: 'daily' | 'boss' | 'streak';
}

interface UpcomingGoal {
  id: string;
  title: string;
  deadline: string;
  completed: boolean;
  category: string;
}

export const Dashboard: React.FC<DashboardProps> = ({
  theme = 'dark',
  user = {
    name: 'Student',
    email: 'student@omniai.edu',
    subject: 'chemistry',
    topic: 'Organic Chemistry & Reaction Mechanisms',
    level: 'College',
    difficulty: 'Advanced'
  },
  onClose,
  onOpenTool,
  onSelectTopic,
  showNotification
}) => {
  const [heatmapSubject, setHeatmapSubject] = useState<string>(() => {
    const s = user?.subject?.toLowerCase() || 'chemistry';
    return SYLLABUS_TOPICS_BY_SUBJECT[s] ? s : 'chemistry';
  });
  const [heatmapViewMode, setHeatmapViewMode] = useState<'chart' | 'grid'>('chart');
  const [autoTutorMode, setAutoTutorMode] = useState<boolean>(() => {
    return localStorage.getItem('omni_auto_tutor_mode') === 'true';
  });

  const toggleAutoTutorMode = () => {
    const next = !autoTutorMode;
    setAutoTutorMode(next);
    localStorage.setItem('omni_auto_tutor_mode', String(next));
    showNotification?.(
      next 
        ? "🤖 Auto-Tutor Mode Enabled: AI is actively analyzing your mastery heatmap to curate targeted study paths." 
        : "Auto-Tutor Mode Disabled.", 
      next ? "success" : "info"
    );
  };

  const currentTopics = SYLLABUS_TOPICS_BY_SUBJECT[heatmapSubject] || SYLLABUS_TOPICS_BY_SUBJECT.chemistry;
  const learningGaps = [...currentTopics].sort((a, b) => a.mastery - b.mastery).slice(0, 3);

  // Local storage state for persistence
  const [xp, setXp] = useState<number>(() => {
    const saved = localStorage.getItem('omni_dashboard_xp');
    return saved ? parseInt(saved, 10) : 4850;
  });

  const [streak, setStreak] = useState<number>(() => {
    const saved = localStorage.getItem('omni_dashboard_streak');
    return saved ? parseInt(saved, 10) : 14;
  });

  const [sessions, setSessions] = useState<StudySession[]>([
    {
      id: 'sess-1',
      topic: 'Organic Reaction Mechanisms: SN1 & SN2 Pathways',
      subject: 'Chemistry',
      duration: '45 mins',
      timestamp: '2 hours ago',
      accuracy: 94,
      completed: true
    },
    {
      id: 'sess-2',
      topic: 'Gauss Law & Electrostatic Potential Integrals',
      subject: 'Physics',
      duration: '38 mins',
      timestamp: 'Yesterday',
      accuracy: 89,
      completed: true
    },
    {
      id: 'sess-3',
      topic: 'Differential Calculus & Chain Rule Applications',
      subject: 'Mathematics',
      duration: '52 mins',
      timestamp: '2 days ago',
      accuracy: 96,
      completed: true
    },
    {
      id: 'sess-4',
      topic: 'Cellular Respiration & Krebs Cycle Enzymes',
      subject: 'Biology',
      duration: '30 mins',
      timestamp: '3 days ago',
      accuracy: 88,
      completed: true
    }
  ]);

  const [quests, setQuests] = useState<QuestItem[]>([
    {
      id: 'quest-1',
      title: 'Daily Catalyst: Complete 5 Organic Reaction Drills',
      category: 'Chemistry',
      progress: 4,
      total: 5,
      xpReward: 300,
      isClaimed: false,
      type: 'daily'
    },
    {
      id: 'quest-2',
      title: 'Concept Boss: Quantum Wave-Particle Duality Mastery',
      category: 'Physics',
      progress: 8,
      total: 10,
      xpReward: 750,
      isClaimed: false,
      type: 'boss'
    },
    {
      id: 'quest-3',
      title: 'Spaced Repetition: Review 15 Recall Flashcards',
      category: 'Memory',
      progress: 15,
      total: 15,
      xpReward: 400,
      isClaimed: false,
      type: 'streak'
    }
  ]);

  const [goals, setGoals] = useState<UpcomingGoal[]>(() => {
    const saved = localStorage.getItem('omni_dashboard_goals');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved goals', e);
      }
    }
    return [
      {
        id: 'goal-1',
        title: 'Complete chapter review on Electrostatic Potential & Capacitance',
        deadline: 'Today, 8:00 PM',
        completed: false,
        category: 'Physics'
      },
      {
        id: 'goal-2',
        title: 'Solve 10 practice problems in Thermodynamics & Entropy',
        deadline: 'Tomorrow, 5:00 PM',
        completed: false,
        category: 'Chemistry'
      },
      {
        id: 'goal-3',
        title: 'Review weekly Spaced Repetition flashcards (30 cards)',
        deadline: 'Friday, 10:00 PM',
        completed: true,
        category: 'General'
      },
      {
        id: 'goal-4',
        title: 'Score 90%+ on NEET/JEE Full Mock Practice Assessment',
        deadline: 'Sunday, 4:00 PM',
        completed: false,
        category: 'Exam Prep'
      }
    ];
  });

  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [newGoalCategory, setNewGoalCategory] = useState('Chemistry');

  useEffect(() => {
    localStorage.setItem('omni_dashboard_xp', String(xp));
  }, [xp]);

  useEffect(() => {
    localStorage.setItem('omni_dashboard_goals', JSON.stringify(goals));
  }, [goals]);

  const handleClaimQuest = (questId: string) => {
    const quest = quests.find(q => q.id === questId);
    if (!quest || quest.isClaimed) return;

    setQuests(prev =>
      prev.map(q => (q.id === questId ? { ...q, isClaimed: true, progress: q.total } : q))
    );
    setXp(prev => prev + quest.xpReward);
    showNotification?.(`Quest completed! Awarded +${quest.xpReward} XP!`, 'success');
  };

  const handleToggleGoal = (goalId: string) => {
    setGoals(prev =>
      prev.map(g => {
        if (g.id === goalId) {
          const nextState = !g.completed;
          if (nextState) {
            setXp(x => x + 100);
            showNotification?.('Goal achieved! +100 XP', 'success');
          }
          return { ...g, completed: nextState };
        }
        return g;
      })
    );
  };

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalTitle.trim()) {
      showNotification?.('Please enter a goal description', 'warning');
      return;
    }

    const newGoal: UpcomingGoal = {
      id: `goal-${Date.now()}`,
      title: newGoalTitle.trim(),
      deadline: 'Upcoming',
      completed: false,
      category: newGoalCategory
    };

    setGoals(prev => [newGoal, ...prev]);
    setNewGoalTitle('');
    showNotification?.('New study goal added!', 'success');
  };

  const handleResumeSession = (session: StudySession) => {
    if (onSelectTopic) {
      onSelectTopic(session.topic);
    }
    showNotification?.(`Resuming session: ${session.topic}`, 'info');
    if (onClose) {
      onClose();
    }
  };

  return (
    <div
      className={cn(
        'w-full min-h-full pb-16 px-4 sm:px-6 lg:px-8 transition-colors',
        theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'
      )}
    >
      {/* Header Bar */}
      <div
        className={cn(
          'sticky top-0 z-40 py-4 mb-6 border-b flex flex-wrap items-center justify-between gap-4 backdrop-blur-md',
          theme === 'dark'
            ? 'bg-slate-950/80 border-slate-800/80'
            : 'bg-slate-50/80 border-slate-200/80'
        )}
      >
        <div className="flex items-center gap-3">
          <div
            className={cn(
              'w-10 h-10 rounded-2xl flex items-center justify-center font-bold shadow-sm',
              theme === 'dark'
                ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                : 'bg-indigo-600 text-white shadow-indigo-200'
            )}
          >
            <LayoutDashboard size={20} />
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
              Learning Dashboard
              <span className="text-xs px-2 py-0.5 rounded-full font-bold uppercase tracking-wider bg-indigo-500/10 text-indigo-500 border border-indigo-500/20">
                Live Overview
              </span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Track your mastery progress, recent study sessions, quests, and smart milestones.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onOpenTool?.('quests')}
            className={cn(
              'px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border',
              theme === 'dark'
                ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
            )}
          >
            <Trophy size={14} className="text-amber-500" />
            <span>Quests Arena</span>
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className={cn(
                'px-4 py-2 rounded-xl text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95',
                'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20'
              )}
            >
              <X size={14} />
              <span>Back to Study</span>
            </button>
          )}
        </div>
      </div>

      {/* Hero Welcome & Stats KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* KPI Card 1: Total XP & Level */}
        <div
          className={cn(
            'p-5 rounded-2xl border transition-all relative overflow-hidden',
            theme === 'dark'
              ? 'bg-slate-900/90 border-slate-800 shadow-lg shadow-slate-950/40'
              : 'bg-white border-slate-200/80 shadow-sm'
          )}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Mastery XP
            </span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500">
              <Award size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black tracking-tight">{xp.toLocaleString()}</span>
            <span className="text-xs font-extrabold text-amber-500">+350 this week</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
            <span>Level 12 Scholar</span>
            <span className="font-bold text-indigo-400">78% to Lvl 13</span>
          </div>
          <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full mt-1.5 overflow-hidden">
            <div className="h-full bg-amber-500 rounded-full" style={{ width: '78%' }} />
          </div>
        </div>

        {/* KPI Card 2: Active Streak */}
        <div
          className={cn(
            'p-5 rounded-2xl border transition-all relative overflow-hidden',
            theme === 'dark'
              ? 'bg-slate-900/90 border-slate-800 shadow-lg shadow-slate-950/40'
              : 'bg-white border-slate-200/80 shadow-sm'
          )}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Study Streak
            </span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-500">
              <Flame size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black tracking-tight">{streak} Days</span>
            <span className="text-xs font-extrabold text-rose-500">🔥 On fire</span>
          </div>
          <p className="mt-3 text-xs text-slate-400">
            2 more days to reach your 16-day streak milestone!
          </p>
        </div>

        {/* KPI Card 3: Total Study Hours */}
        <div
          className={cn(
            'p-5 rounded-2xl border transition-all relative overflow-hidden',
            theme === 'dark'
              ? 'bg-slate-900/90 border-slate-800 shadow-lg shadow-slate-950/40'
              : 'bg-white border-slate-200/80 shadow-sm'
          )}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Study Hours
            </span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
              <Clock size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black tracking-tight">42.5 hrs</span>
            <span className="text-xs font-extrabold text-emerald-500">+6.2 hrs</span>
          </div>
          <p className="mt-3 text-xs text-slate-400">
            Average 1.8 hours per day over the past 30 days.
          </p>
        </div>

        {/* KPI Card 4: Overall Mastery Score */}
        <div
          className={cn(
            'p-5 rounded-2xl border transition-all relative overflow-hidden',
            theme === 'dark'
              ? 'bg-slate-900/90 border-slate-800 shadow-lg shadow-slate-950/40'
              : 'bg-white border-slate-200/80 shadow-sm'
          )}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Average Mastery
            </span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
              <Target size={18} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black tracking-tight">91%</span>
            <span className="text-xs font-extrabold text-emerald-500">Top 5% Tier</span>
          </div>
          <p className="mt-3 text-xs text-slate-400">
            Based on quizzes, solver accuracy, and recall drills.
          </p>
        </div>
      </div>

      {/* Main Content Grid: Left Column (Progress & Recent Sessions) / Right Column (Pending Quests & Upcoming Goals) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns */}
        <div className="lg:col-span-2 space-y-6">
          {/* Practice Exam Module Highlight Card for CBSE Math Class 12 */}
          <div
            className={cn(
              'p-6 rounded-2xl border transition-all relative overflow-hidden',
              theme === 'dark'
                ? 'bg-gradient-to-r from-violet-950/40 via-slate-900 to-slate-900 border-violet-500/30 shadow-xl'
                : 'bg-gradient-to-r from-violet-50 via-white to-white border-violet-200 shadow-sm'
            )}
          >
            <div className="absolute top-0 right-0 transform translate-x-6 -translate-y-6 w-32 h-32 bg-violet-500/10 rounded-full blur-2xl pointer-events-none" />
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-violet-500/10 text-violet-400 border border-violet-500/20">
                    Official CBSE Mock Paper
                  </span>
                  <span className="text-xs text-slate-400 font-bold">Class 12 Mathematics (100 Marks)</span>
                </div>
                <h3 className="text-base font-black tracking-tight text-slate-900 dark:text-slate-100">
                  India-CBSE Mathematics Class 12 Practice Exam
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xl">
                  Simulate a 3-hour board exam paper featuring all 14 units (Calculus, Vectors, 3D Geometry, Linear Programming, Probability, Regression). Get instant scoring and step-by-step curriculum solutions.
                </p>
              </div>

              <button
                type="button"
                onClick={() => onOpenTool?.('practice_exam')}
                className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-black uppercase tracking-wider shadow-lg shadow-violet-600/30 flex items-center gap-2 shrink-0 cursor-pointer active:scale-95 transition"
              >
                <GraduationCap size={15} />
                <span>Take Math Exam</span>
              </button>
            </div>
          </div>

          {/* Practice Exam Module Highlight Card for CBSE Physics Class 12 */}
          <div
            className={cn(
              'p-6 rounded-2xl border transition-all relative overflow-hidden',
              theme === 'dark'
                ? 'bg-gradient-to-r from-indigo-950/40 via-slate-900 to-slate-900 border-indigo-500/30 shadow-xl'
                : 'bg-gradient-to-r from-indigo-50 via-white to-white border-indigo-200 shadow-sm'
            )}
          >
            <div className="absolute top-0 right-0 transform translate-x-6 -translate-y-6 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    Official CBSE Mock Paper
                  </span>
                  <span className="text-xs text-slate-400 font-bold">Class 12 Physics</span>
                </div>
                <h3 className="text-base font-black tracking-tight text-slate-900 dark:text-slate-100">
                  India-CBSE Physics Class 12 Practice Exam
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xl">
                  Simulate an official board exam paper featuring units like Electrostatics, Current Electricity, Magnetism, Optics, and Modern Physics. Get instant scoring and step-by-step curriculum solutions.
                </p>
              </div>

              <button
                type="button"
                onClick={() => onOpenTool?.('practice_exam_physics')}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black uppercase tracking-wider shadow-lg shadow-indigo-600/30 flex items-center gap-2 shrink-0 cursor-pointer active:scale-95 transition"
              >
                <GraduationCap size={15} />
                <span>Take Physics Exam</span>
              </button>
            </div>
          </div>

          {/* Practice Exam Module Highlight Card for CBSE Chemistry Class 12 */}
          <div
            className={cn(
              'p-6 rounded-2xl border transition-all relative overflow-hidden',
              theme === 'dark'
                ? 'bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border-emerald-500/30 shadow-xl'
                : 'bg-gradient-to-r from-emerald-50 via-white to-white border-emerald-200 shadow-sm'
            )}
          >
            <div className="absolute top-0 right-0 transform translate-x-6 -translate-y-6 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Official CBSE Mock Paper
                  </span>
                  <span className="text-xs text-slate-400 font-bold">Class 12 Chemistry</span>
                </div>
                <h3 className="text-base font-black tracking-tight text-slate-900 dark:text-slate-100">
                  India-CBSE Chemistry Class 12 Practice Exam
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xl">
                  Simulate an official board exam paper covering Solutions, Electrochemistry, Kinetics, Elements, Compounds, and Organic Chemistry. Get instant scoring and step-by-step curriculum solutions.
                </p>
              </div>

              <button
                type="button"
                onClick={() => onOpenTool?.('practice_exam_chemistry')}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider shadow-lg shadow-emerald-600/30 flex items-center gap-2 shrink-0 cursor-pointer active:scale-95 transition"
              >
                <GraduationCap size={15} />
                <span>Take Chemistry Exam</span>
              </button>
            </div>
          </div>

          {/* Practice Exam Module Highlight Card for CBSE Biology Class 12 */}
          <div
            className={cn(
              'p-6 rounded-2xl border transition-all relative overflow-hidden',
              theme === 'dark'
                ? 'bg-gradient-to-r from-rose-950/40 via-slate-900 to-slate-900 border-rose-500/30 shadow-xl'
                : 'bg-gradient-to-r from-rose-50 via-white to-white border-rose-200 shadow-sm'
            )}
          >
            <div className="absolute top-0 right-0 transform translate-x-6 -translate-y-6 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-rose-500/10 text-rose-400 border border-rose-500/20">
                    Official CBSE Mock Paper
                  </span>
                  <span className="text-xs text-slate-400 font-bold">Class 12 Biology</span>
                </div>
                <h3 className="text-base font-black tracking-tight text-slate-900 dark:text-slate-100">
                  India-CBSE Biology Class 12 Practice Exam
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xl">
                  Simulate an official board exam paper covering Reproduction, Genetics, Human Health, Biotechnology, and Ecology. Get instant scoring and step-by-step curriculum solutions.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onOpenTool?.('biology_metrics')}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-2 cursor-pointer active:scale-95 transition border border-slate-300 dark:border-slate-700"
                >
                  <BarChart2 size={15} className="text-rose-500" />
                  <span>Lab Metrics & Growth Curves</span>
                </button>
                <button
                  type="button"
                  onClick={() => onOpenTool?.('practice_exam_biology')}
                  className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black uppercase tracking-wider shadow-lg shadow-rose-600/30 flex items-center gap-2 cursor-pointer active:scale-95 transition"
                >
                  <GraduationCap size={15} />
                  <span>Take Biology Exam</span>
                </button>
              </div>
            </div>
          </div>

          {/* Subject Mastery Heatmap & Syllabus Matrix */}
          <div
            className={cn(
              'p-6 rounded-2xl border transition-all space-y-6',
              theme === 'dark'
                ? 'bg-slate-900/90 border-slate-800'
                : 'bg-white border-slate-200/80 shadow-sm'
            )}
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
                  <BarChart2 size={18} />
                </div>
                <div>
                  <h2 className="text-base font-extrabold tracking-tight">Subject Mastery Heatmap</h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Syllabus progress & competency matrix across current board units
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {/* Auto-Tutor Mode Toggle */}
                <button
                  type="button"
                  onClick={toggleAutoTutorMode}
                  className={cn(
                    'px-3 py-2 rounded-xl text-xs font-black uppercase tracking-wider border transition flex items-center gap-2 cursor-pointer shadow-sm',
                    autoTutorMode
                      ? 'bg-emerald-600 text-white border-emerald-500 shadow-emerald-600/20'
                      : 'bg-slate-100 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  )}
                  title="Toggle Auto-Tutor Mode for autonomous AI study path curation"
                >
                  <Bot size={15} className={autoTutorMode ? 'text-white animate-pulse' : 'text-indigo-500'} />
                  <span>Auto-Tutor: {autoTutorMode ? 'ON' : 'OFF'}</span>
                </button>

                {/* Subject Dropdown Filter */}
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Subject:</span>
                  <select
                    value={heatmapSubject}
                    onChange={(e) => setHeatmapSubject(e.target.value)}
                    className="px-3 py-2 rounded-xl text-xs font-black uppercase tracking-wider bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer shadow-sm"
                  >
                    <option value="chemistry">🧪 Chemistry</option>
                    <option value="physics">⚡ Physics</option>
                    <option value="mathematics">📐 Mathematics</option>
                    <option value="biology">🧬 Biology</option>
                  </select>
                </div>

                <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setHeatmapViewMode('chart')}
                    className={cn(
                      'p-1.5 rounded-lg transition cursor-pointer',
                      heatmapViewMode === 'chart' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                    )}
                    title="Bar Chart View"
                  >
                    <BarChart2 size={15} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setHeatmapViewMode('grid')}
                    className={cn(
                      'p-1.5 rounded-lg transition cursor-pointer',
                      heatmapViewMode === 'grid' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                    )}
                    title="Heatmap Matrix Grid View"
                  >
                    <Grid size={15} />
                  </button>
                </div>
              </div>
            </div>

            {/* AI Auto-Tutor Autonomous Study Path Recommendations Card */}
            {autoTutorMode && (
              <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-indigo-950/40 border border-indigo-500/40 shadow-xl space-y-4 animate-in fade-in zoom-in-95 duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                      <Sparkles size={18} className="animate-spin" />
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-indigo-200 uppercase tracking-wider flex items-center gap-2">
                        🤖 AI Auto-Tutor: Autonomous Study Path Curation
                        <span className="text-[9px] font-black px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full border border-emerald-500/30">
                          HEATMAP GAP ANALYSIS ACTIVE
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Autonomous AI engine scanned {heatmapSubject.toUpperCase()} syllabus and identified top concept gaps for prioritized remediation:
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {learningGaps.map((gap, i) => (
                    <div
                      key={i}
                      className={cn(
                        "p-4 rounded-xl border flex flex-col justify-between space-y-3 transition hover:scale-[1.02]",
                        theme === 'dark' ? "bg-slate-950/80 border-indigo-500/30" : "bg-white/80 border-indigo-200"
                      )}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400">
                            {gap.unit}
                          </span>
                          <span className={cn(
                            "text-xs font-black px-2 py-0.5 rounded-full border",
                            gap.mastery < 80 ? "bg-rose-500/10 text-rose-400 border-rose-500/30" : "bg-amber-500/10 text-amber-400 border-amber-500/30"
                          )}>
                            {gap.mastery}% Mastery
                          </span>
                        </div>
                        <h4 className="text-xs font-black text-slate-900 dark:text-slate-100 pt-1">
                          {gap.topic}
                        </h4>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          if (onSelectTopic) {
                            onSelectTopic(gap.topic);
                            showNotification?.(`🤖 Auto-Tutor launched targeted study path for: ${gap.topic}`, 'success');
                            onClose?.();
                          }
                        }}
                        className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold uppercase tracking-wider transition shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Zap size={13} />
                        Launch AI Remedial Drill
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Heatmap Legend */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-slate-500 px-1">
              <span className="uppercase text-[10px] tracking-wider">Competency Heatmap Legend:</span>
              <div className="flex items-center gap-3 flex-wrap">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-emerald-500 inline-block" />
                  <span>Mastered (90-100%)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-indigo-500 inline-block" />
                  <span>Proficient (80-89%)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-amber-500 inline-block" />
                  <span>Developing (70-79%)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-rose-500 inline-block" />
                  <span>Needs Review (&lt;70%)</span>
                </span>
              </div>
            </div>

            {/* Chart or Grid View */}
            {heatmapViewMode === 'chart' ? (
              <div className="h-[320px] w-full pt-2">
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                  <BarChart
                    data={SYLLABUS_TOPICS_BY_SUBJECT[heatmapSubject] || SYLLABUS_TOPICS_BY_SUBJECT.chemistry}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke={theme === 'dark' ? '#1e293b' : '#e2e8f0'} />
                    <XAxis
                      type="number"
                      domain={[0, 100]}
                      unit="%"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 10, fill: '#64748b' }}
                    />
                    <YAxis
                      type="category"
                      dataKey="topic"
                      width={160}
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 11, fontWeight: 'bold', fill: theme === 'dark' ? '#cbd5e1' : '#334155' }}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className={cn(
                              "p-3 rounded-xl border shadow-xl text-xs space-y-1",
                              theme === 'dark' ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-900"
                            )}>
                              <p className="font-black">{data.topic}</p>
                              <p className="text-slate-400 text-[10px] uppercase font-bold">Unit: {data.unit}</p>
                              <div className="flex items-center justify-between gap-4 pt-1 font-bold">
                                <span>Mastery Score:</span>
                                <span className="text-emerald-400 font-extrabold">{data.mastery}% ({data.status})</span>
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar
                      dataKey="mastery"
                      radius={[0, 6, 6, 0]}
                      barSize={16}
                      onClick={(data: any) => {
                        if (onSelectTopic && data && data.topic) {
                          onSelectTopic(data.topic);
                          showNotification?.(`Selected syllabus topic: ${data.topic}`, 'info');
                          onClose?.();
                        }
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      {(SYLLABUS_TOPICS_BY_SUBJECT[heatmapSubject] || SYLLABUS_TOPICS_BY_SUBJECT.chemistry).map((entry, index) => {
                        let color = '#10b981'; // emerald
                        if (entry.mastery < 75) color = '#f43f5e'; // rose
                        else if (entry.mastery < 85) color = '#f59e0b'; // amber
                        else if (entry.mastery < 90) color = '#6366f1'; // indigo
                        return <Cell key={`cell-${index}`} fill={color} />;
                      })}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {(SYLLABUS_TOPICS_BY_SUBJECT[heatmapSubject] || SYLLABUS_TOPICS_BY_SUBJECT.chemistry).map((item, idx) => {
                  let bgCol = 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';
                  let barCol = 'bg-emerald-500';
                  if (item.mastery < 75) {
                    bgCol = 'bg-rose-500/10 border-rose-500/30 text-rose-400';
                    barCol = 'bg-rose-500';
                  } else if (item.mastery < 85) {
                    bgCol = 'bg-amber-500/10 border-amber-500/30 text-amber-400';
                    barCol = 'bg-amber-500';
                  } else if (item.mastery < 90) {
                    bgCol = 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400';
                    barCol = 'bg-indigo-500';
                  }

                  return (
                    <div
                      key={idx}
                      onClick={() => {
                        if (onSelectTopic) {
                          onSelectTopic(item.topic);
                          showNotification?.(`Selected syllabus topic: ${item.topic}`, 'info');
                          onClose?.();
                        }
                      }}
                      className={cn(
                        'p-4 rounded-2xl border transition-all cursor-pointer hover:scale-[1.01] space-y-2.5',
                        theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                      )}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400">
                            {item.unit}
                          </span>
                          <h4 className="text-xs font-extrabold text-slate-900 dark:text-slate-100 mt-1">
                            {item.topic}
                          </h4>
                        </div>
                        <span className={cn('text-xs font-black px-2.5 py-1 rounded-full border', bgCol)}>
                          {item.mastery}%
                        </span>
                      </div>

                      <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div className={cn('h-full rounded-full', barCol)} style={{ width: `${item.mastery}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="p-4 rounded-2xl bg-indigo-500/5 border border-indigo-500/10 flex items-center justify-between">
              <p className="text-xs text-indigo-700 dark:text-indigo-300 leading-relaxed">
                💡 Click any topic bar or grid card above to instantly launch an adaptive practice drill or review session for that syllabus unit.
              </p>
              <button
                type="button"
                onClick={() => onOpenTool?.('analytics')}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shrink-0 transition cursor-pointer"
              >
                Deep Analytics
              </button>
            </div>
          </div>

          {/* Recent Study Sessions */}
          <div
            className={cn(
              'p-6 rounded-2xl border transition-all',
              theme === 'dark'
                ? 'bg-slate-900/90 border-slate-800'
                : 'bg-white border-slate-200/80 shadow-sm'
            )}
          >
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2.5">
                <BookOpen size={18} className="text-indigo-500" />
                <h2 className="text-base font-extrabold tracking-tight">Recent Study Sessions</h2>
              </div>
              <span className="text-xs text-slate-400 font-medium">Last 7 days</span>
            </div>

            <div className="space-y-3">
              {sessions.map(session => (
                <div
                  key={session.id}
                  className={cn(
                    'p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all',
                    theme === 'dark'
                      ? 'bg-slate-950/50 border-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-50/60 border-slate-200 hover:border-slate-300'
                  )}
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-500 border border-indigo-500/20">
                        {session.subject}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">{session.timestamp}</span>
                      <span className="text-xs text-slate-400 font-medium">• {session.duration}</span>
                    </div>
                    <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                      {session.topic}
                    </h3>
                  </div>

                  <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                    <div className="text-right">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">
                        Accuracy
                      </span>
                      <span className="text-sm font-black text-emerald-500">
                        {session.accuracy}%
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleResumeSession(session)}
                      className={cn(
                        'px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95',
                        theme === 'dark'
                          ? 'bg-indigo-600/20 text-indigo-400 hover:bg-indigo-600 hover:text-white border border-indigo-500/30'
                          : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border border-indigo-200'
                      )}
                    >
                      <Play size={12} className="fill-current" />
                      <span>Resume</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Pending Quests & Upcoming Goals */}
        <div className="space-y-6">
          {/* Pending Quests & Gamified Challenges */}
          <div
            className={cn(
              'p-6 rounded-2xl border transition-all',
              theme === 'dark'
                ? 'bg-slate-900/90 border-slate-800'
                : 'bg-white border-slate-200/80 shadow-sm'
            )}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <Trophy size={18} className="text-amber-500" />
                <h2 className="text-base font-extrabold tracking-tight">Pending Quests</h2>
              </div>
              <span className="text-xs font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full">
                Active Rewards
              </span>
            </div>

            <div className="space-y-3">
              {quests.map(quest => {
                const isReady = quest.progress >= quest.total;
                return (
                  <div
                    key={quest.id}
                    className={cn(
                      'p-4 rounded-xl border transition-all space-y-2.5',
                      quest.isClaimed
                        ? 'opacity-60 bg-slate-950/20 border-slate-800'
                        : theme === 'dark'
                        ? 'bg-slate-950/50 border-slate-800'
                        : 'bg-slate-50/70 border-slate-200'
                    )}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-extrabold uppercase text-slate-400">
                          {quest.category}
                        </span>
                        <h3 className="text-xs font-bold leading-snug">{quest.title}</h3>
                      </div>
                      <span className="text-xs font-black text-amber-500 shrink-0">
                        +{quest.xpReward} XP
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
                      <span>Progress</span>
                      <span>
                        {quest.progress} / {quest.total}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={cn(
                          'h-full rounded-full transition-all',
                          isReady ? 'bg-emerald-500' : 'bg-amber-500'
                        )}
                        style={{
                          width: `${Math.min(100, (quest.progress / quest.total) * 100)}%`
                        }}
                      />
                    </div>

                    <div className="pt-1 flex justify-end">
                      {quest.isClaimed ? (
                        <span className="text-[10px] font-black uppercase text-slate-500 flex items-center gap-1">
                          <CheckCircle2 size={12} className="text-emerald-500" />
                          Claimed
                        </span>
                      ) : isReady ? (
                        <button
                          type="button"
                          onClick={() => handleClaimQuest(quest.id)}
                          className="w-full py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider transition cursor-pointer shadow-sm active:scale-95 flex items-center justify-center gap-1"
                        >
                          <Sparkles size={13} />
                          <span>Claim Reward</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleClaimQuest(quest.id)}
                          className={cn(
                            'w-full py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition cursor-pointer',
                            theme === 'dark'
                              ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                              : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                          )}
                        >
                          <span>Complete Quest</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Upcoming Goals Checklist */}
          <div
            className={cn(
              'p-6 rounded-2xl border transition-all',
              theme === 'dark'
                ? 'bg-slate-900/90 border-slate-800'
                : 'bg-white border-slate-200/80 shadow-sm'
            )}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <Target size={18} className="text-indigo-500" />
                <h2 className="text-base font-extrabold tracking-tight">Upcoming Goals</h2>
              </div>
              <span className="text-xs text-slate-400 font-medium">
                {goals.filter(g => g.completed).length} / {goals.length} done
              </span>
            </div>

            {/* Add Goal Form */}
            <form onSubmit={handleAddGoal} className="mb-4 flex gap-2">
              <input
                type="text"
                value={newGoalTitle}
                onChange={e => setNewGoalTitle(e.target.value)}
                placeholder="Add a custom study goal..."
                className={cn(
                  'flex-1 px-3 py-2 rounded-xl text-xs border outline-none font-medium transition-colors',
                  theme === 'dark'
                    ? 'bg-slate-950 border-slate-800 text-slate-200 focus:border-indigo-500'
                    : 'bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500'
                )}
              />
              <button
                type="submit"
                className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition active:scale-95 cursor-pointer flex items-center gap-1"
              >
                <Plus size={14} />
                <span>Add</span>
              </button>
            </form>

            <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
              {goals.map(goal => (
                <div
                  key={goal.id}
                  onClick={() => handleToggleGoal(goal.id)}
                  className={cn(
                    'p-3.5 rounded-xl border flex items-start gap-3 transition-all cursor-pointer select-none',
                    goal.completed
                      ? 'opacity-60 bg-slate-950/20 border-slate-800/60 line-through'
                      : theme === 'dark'
                      ? 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                      : 'bg-slate-50/70 border-slate-200 hover:border-slate-300'
                  )}
                >
                  <div
                    className={cn(
                      'w-5 h-5 rounded-md flex items-center justify-center shrink-0 mt-0.5 transition-colors',
                      goal.completed
                        ? 'bg-emerald-500 text-white'
                        : theme === 'dark'
                        ? 'border-2 border-slate-700'
                        : 'border-2 border-slate-300'
                    )}
                  >
                    {goal.completed && <Check size={12} strokeWidth={3} />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p
                      className={cn(
                        'text-xs font-bold leading-snug',
                        goal.completed
                          ? 'text-slate-400 dark:text-slate-500'
                          : 'text-slate-800 dark:text-slate-200'
                      )}
                    >
                      {goal.title}
                    </p>
                    <div className="flex items-center justify-between mt-1 text-[10px] text-slate-400 font-semibold">
                      <span>{goal.category}</span>
                      <span>{goal.deadline}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
