import React, { useState } from 'react';
import { 
  DebateTopic, 
  DebateTurn, 
  DebateSession 
} from '../modules/social/types';
import { 
  Swords, 
  Scale, 
  Award, 
  Sparkles, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  Brain, 
  ArrowRight,
  RotateCcw
} from 'lucide-react';
import { cn } from '../lib/utils';
import { generateAIResponse } from '../lib/gemini';
import { ModerationEngine } from './ModerationLayer';

const DEBATE_TOPICS: DebateTopic[] = [
  {
    id: 'debate_photo_thermo',
    title: 'Photosynthesis: Endothermic or Exothermic?',
    concept: 'Photosynthesis & Thermodynamics',
    subject: 'Biology / Chemistry',
    sideA: {
      title: 'Side A: Strictly Endothermic',
      stance: 'Photosynthesis overall absorbs solar energy (+2870 kJ/mol) to synthesize glucose, making it an endothermic anabolic process.'
    },
    sideB: {
      title: 'Side B: Contains Exothermic Steps',
      stance: 'While the overall reaction is endergonic, specific intermediary steps (like ATP hydrolysis and electron transport down cytochrome cascades) are strongly exothermic!'
    },
    modelContext: 'Overall reaction 6CO2 + 6H2O -> C6H12O6 + 6O2 has Delta H > 0 (endothermic overall), yet intermediary catabolic energy-coupling steps release free energy.'
  },
  {
    id: 'debate_light_nature',
    title: 'Wave-Particle Duality: Wave or Photon Stream?',
    concept: 'Quantum Mechanics',
    subject: 'Physics',
    sideA: {
      title: 'Side A: Wave Nature Prevails',
      stance: 'Maxwell equations, Young double-slit interference, and diffraction prove light propagates as continuous electromagnetic wavefronts.'
    },
    sideB: {
      title: 'Side B: Particle Nature Prevails',
      stance: 'Einstein photoelectric effect and Compton scattering prove light transfers discrete quantized energy packets (photons: E = hf).'
    },
    modelContext: 'Complementarity principle (Bohr). Light exhibits both natures depending on measurement apparatus: wave in propagation, particle in localized interaction.'
  },
  {
    id: 'debate_entropy_evolution',
    title: 'Entropy vs Biological Complexity',
    concept: 'Second Law of Thermodynamics',
    subject: 'Physics / Biology',
    sideA: {
      title: 'Side A: Apparent Contradiction',
      stance: 'Living organisms spontaneously increase local order and complexity, which on the surface appears to violate non-decreasing entropy (Delta S >= 0).'
    },
    sideB: {
      title: 'Side B: Open System Resolution',
      stance: 'Earth and living cells are non-isolated open systems. Organisms export entropy into their environment (heat dissipation), ensuring total universe entropy increases.'
    },
    modelContext: 'Second law applies strictly to isolated closed systems. Life maintains low internal entropy by consuming free energy and exhausting high-entropy heat.'
  }
];

export interface DebateModeProps {
  currentStudentName?: string;
  className?: string;
}

export const DebateMode: React.FC<DebateModeProps> = ({
  currentStudentName = 'Alex',
  className
}) => {
  const [selectedTopic, setSelectedTopic] = useState<DebateTopic>(DEBATE_TOPICS[0]);
  const [mySide, setMySide] = useState<'A' | 'B'>('A');
  const [argumentInput, setArgumentInput] = useState('');
  const [isJudging, setIsJudging] = useState(false);

  const opponentName = mySide === 'A' ? 'Maya S. (Opponent)' : 'Alex (Opponent)';

  const [turns, setTurns] = useState<DebateTurn[]>([
    {
      id: 'turn_seed_1',
      speaker: 'A',
      studentName: mySide === 'A' ? `${currentStudentName} (You)` : 'Maya S.',
      argumentText: 'Photosynthesis requires continuous input of solar radiation to split water molecules. Without light energy, the reaction stops entirely. Thus by definition, the process is endothermic because it absorbs heat and radiant energy from the surroundings.',
      timestamp: 'Round 1 - Opening',
      aiJudgement: {
        evidenceScore: 88,
        logicalConsistency: 92,
        persuasiveness: 90,
        critique: 'Solid foundational argument linking energy absorption to photolysis.'
      }
    },
    {
      id: 'turn_seed_2',
      speaker: 'B',
      studentName: mySide === 'B' ? `${currentStudentName} (You)` : 'Maya S.',
      argumentText: 'While the net energy balance is positive, you cannot ignore the electron transport chain in the thylakoid membrane! High-energy electrons drop through progressively lower redox potentials, releasing heat and driving proton pumps via exothermic exergonic steps.',
      timestamp: 'Round 1 - Rebuttal',
      aiJudgement: {
        evidenceScore: 94,
        logicalConsistency: 90,
        persuasiveness: 93,
        critique: 'Excellent deep biochemical mechanism citation regarding electron transport cascades.'
      }
    }
  ]);

  const [verdict, setVerdict] = useState<{
    winnerSide: 'A' | 'B' | 'draw';
    synthesis: string;
    keyTakeaways: string[];
    scoreA: number;
    scoreB: number;
  } | null>(null);

  const handleSelectTopic = (topic: DebateTopic) => {
    setSelectedTopic(topic);
    setTurns([]);
    setVerdict(null);
  };

  const handleSubmitArgument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!argumentInput.trim() || isJudging) return;

    // Moderate content
    const mod = ModerationEngine.screenContent(argumentInput);
    if (!mod.isSafe) {
      alert(mod.suggestion || 'Keep debate respectful and scientifically grounded.');
      return;
    }

    const currentTurnSpeaker = mySide;
    const newTurn: DebateTurn = {
      id: `turn_${Date.now()}`,
      speaker: currentTurnSpeaker,
      studentName: `${currentStudentName} (You)`,
      argumentText: argumentInput,
      timestamp: `Round ${Math.floor(turns.length / 2) + 1}`
    };

    setIsJudging(true);
    setTurns(prev => [...prev, newTurn]);
    const studentArg = argumentInput;
    setArgumentInput('');

    try {
      const prompt = `You are an expert STEM Debate Adjudicator.
Topic: "${selectedTopic.title}"
Stance Argued: Side ${mySide} (${mySide === 'A' ? selectedTopic.sideA.title : selectedTopic.sideB.title})
Student Argument: "${studentArg}"
Model Scientific Context: "${selectedTopic.modelContext}"

Evaluate the argument on:
1. Evidence Quality (0-100)
2. Logical Consistency (0-100)
3. Persuasiveness & Scientific Rigor (0-100)
Provide a 1-2 sentence constructive critique.

Return JSON format ONLY:
{
  "evidenceScore": 88,
  "logicalConsistency": 90,
  "persuasiveness": 86,
  "critique": "Brief 1-2 sentence review..."
}`;

      const aiResponse = await generateAIResponse(prompt, {
        responseMimeType: 'application/json'
      });

      const cleaned = aiResponse.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
      let parsed: any;
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        const match = cleaned.match(/\{[\s\S]*\}/);
        if (match) parsed = JSON.parse(match[0]);
      }

      const judgement = {
        evidenceScore: parsed?.evidenceScore || 85,
        logicalConsistency: parsed?.logicalConsistency || 88,
        persuasiveness: parsed?.persuasiveness || 86,
        critique: parsed?.critique || 'Well-structured scientific assertion with clear reasoning.'
      };

      setTurns(prev => prev.map(t => t.id === newTurn.id ? { ...t, aiJudgement: judgement } : t));

      // After 3 or more turns, generate synthesis verdict
      if (turns.length >= 2) {
        generateFinalVerdict();
      }
    } catch (e) {
      console.error('Debate evaluation error:', e);
    } finally {
      setIsJudging(false);
    }
  };

  const generateFinalVerdict = async () => {
    try {
      const prompt = `Synthesize this STEM debate between two students:
Topic: "${selectedTopic.title}"
Side A: ${selectedTopic.sideA.stance}
Side B: ${selectedTopic.sideB.stance}
Model Truth: ${selectedTopic.modelContext}

Provide a synthesis where both students learn from each other:
1. Explain how both sides are scientifically valid under specific physical frames.
2. 3 key takeaways for exam mastery.
Return JSON ONLY:
{
  "winnerSide": "draw",
  "scoreA": 91,
  "scoreB": 93,
  "synthesis": "Both debaters demonstrated sophisticated scientific nuance...",
  "keyTakeaways": ["Point 1...", "Point 2...", "Point 3..."]
}`;

      const res = await generateAIResponse(prompt, { responseMimeType: 'application/json' });
      const cleaned = res.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
      const parsed = JSON.parse(cleaned);

      setVerdict({
        winnerSide: parsed.winnerSide || 'draw',
        scoreA: parsed.scoreA || 90,
        scoreB: parsed.scoreB || 92,
        synthesis: parsed.synthesis || 'Both perspectives unite into a complete scientific picture.',
        keyTakeaways: parsed.keyTakeaways || [
          'Net thermodynamics vs internal intermediary steps.',
          'Open systems exchange matter and energy continuously.',
          'Exam questions frequently test this exact distinction.'
        ]
      });
    } catch {
      setVerdict({
        winnerSide: 'draw',
        scoreA: 90,
        scoreB: 92,
        synthesis: 'Superb debate! Looking at both the global thermodynamic balance and local molecular mechanisms yields true mastery.',
        keyTakeaways: [
          'Overall Delta H is endothermic for glucose synthesis.',
          'Intermediary steps utilize exothermic energy release.',
          'True understanding requires synthesizing both perspectives.'
        ]
      });
    }
  };

  return (
    <div className={cn(
      "rounded-3xl border overflow-hidden shadow-2xl bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100",
      className
    )}>
      {/* Header */}
      <div className="p-5 sm:p-6 bg-gradient-to-r from-purple-900/20 via-indigo-900/10 to-transparent border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-purple-600/30 shrink-0">
            <Swords size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                Academic Debate Mode
              </h3>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20 uppercase tracking-wider">
                AI Evidence Judge
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Argue opposing stances with evidence. Discover that real mastery lies in synthesis.
            </p>
          </div>
        </div>

        {/* Topic Selector dropdown */}
        <select
          value={selectedTopic.id}
          onChange={(e) => {
            const found = DEBATE_TOPICS.find(t => t.id === e.target.value);
            if (found) handleSelectTopic(found);
          }}
          className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-purple-500"
        >
          {DEBATE_TOPICS.map(t => (
            <option key={t.id} value={t.id}>{t.title}</option>
          ))}
        </select>
      </div>

      {/* Opposing Stances Card */}
      <div className="p-5 bg-slate-50 dark:bg-slate-950/40 border-b border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Side A */}
        <div 
          onClick={() => setMySide('A')}
          className={cn(
            "p-4 rounded-2xl border transition cursor-pointer relative",
            mySide === 'A'
              ? "bg-indigo-50/80 dark:bg-indigo-950/50 border-indigo-500 ring-2 ring-indigo-500/30"
              : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-80 hover:opacity-100"
          )}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              {selectedTopic.sideA.title}
            </span>
            {mySide === 'A' && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-600 text-white">
                Your Stance
              </span>
            )}
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            "{selectedTopic.sideA.stance}"
          </p>
        </div>

        {/* Side B */}
        <div 
          onClick={() => setMySide('B')}
          className={cn(
            "p-4 rounded-2xl border transition cursor-pointer relative",
            mySide === 'B'
              ? "bg-purple-50/80 dark:bg-purple-950/50 border-purple-500 ring-2 ring-purple-500/30"
              : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-80 hover:opacity-100"
          )}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black text-purple-600 dark:text-purple-400 uppercase tracking-wider">
              {selectedTopic.sideB.title}
            </span>
            {mySide === 'B' && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-600 text-white">
                Your Stance
              </span>
            )}
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            "{selectedTopic.sideB.stance}"
          </p>
        </div>
      </div>

      {/* Debate Arguments Stream */}
      <div className="p-5 sm:p-6 space-y-4 max-h-[420px] overflow-y-auto">
        {turns.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-xs">
            <Scale size={32} className="mx-auto mb-2 text-purple-400 animate-pulse" />
            No arguments submitted yet. Open the debate with your strongest piece of scientific evidence below!
          </div>
        ) : (
          turns.map((t, idx) => {
            const isSpeakerA = t.speaker === 'A';
            return (
              <div 
                key={t.id}
                className={cn(
                  "p-4 rounded-2xl border transition-all space-y-2.5",
                  isSpeakerA 
                    ? "bg-indigo-50/40 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-900/50"
                    : "bg-purple-50/40 dark:bg-purple-950/20 border-purple-200 dark:border-purple-900/50"
                )}
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "px-2 py-0.5 rounded-md font-black text-[10px] uppercase",
                      isSpeakerA ? "bg-indigo-600 text-white" : "bg-purple-600 text-white"
                    )}>
                      Side {t.speaker}
                    </span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {t.studentName}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{t.timestamp}</span>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
                  "{t.argumentText}"
                </p>

                {/* AI Judge Feedback Box */}
                {t.aiJudgement && (
                  <div className="pt-2 mt-2 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                      ⚖️ <span className="font-semibold text-slate-700 dark:text-slate-300">Judge Note:</span> {t.aiJudgement.critique}
                    </p>
                    <div className="flex items-center gap-3 shrink-0 font-mono text-[11px]">
                      <span className="text-indigo-600 dark:text-indigo-400 font-bold">
                        Evidence: {t.aiJudgement.evidenceScore}/100
                      </span>
                      <span className="text-purple-600 dark:text-purple-400 font-bold">
                        Logic: {t.aiJudgement.logicalConsistency}/100
                      </span>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}

        {/* Final AI Verdict Box (Appears after rounds) */}
        {verdict && (
          <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-purple-500/10 to-indigo-500/10 border border-amber-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-amber-600 dark:text-amber-400 flex items-center gap-2">
                <Award size={16} />
                Final Academic Synthesis & Verdict
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-600 dark:text-amber-300 border border-amber-500/30">
                Mutual Learning Synthesis
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
              {verdict.synthesis}
            </p>

            <div className="pt-2 border-t border-amber-500/20 space-y-1.5">
              <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                Key Exam Takeaways:
              </span>
              {verdict.keyTakeaways.map((point, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-400">
                  <CheckCircle2 size={13} className="text-emerald-500 shrink-0 mt-0.5" />
                  <span>{point}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Input Argument Bar */}
      <form onSubmit={handleSubmitArgument} className="p-4 bg-slate-50 dark:bg-slate-950/70 border-t border-slate-200 dark:border-slate-800 flex gap-2">
        <input
          type="text"
          placeholder={`State your scientific evidence for Side ${mySide} (${mySide === 'A' ? selectedTopic.sideA.title : selectedTopic.sideB.title})...`}
          value={argumentInput}
          onChange={(e) => setArgumentInput(e.target.value)}
          disabled={isJudging}
          className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={!argumentInput.trim() || isJudging}
          className="px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md shadow-purple-600/30 flex items-center gap-1.5 transition cursor-pointer disabled:opacity-40"
        >
          {isJudging ? (
            <>
              <Sparkles size={14} className="animate-spin" /> Judging...
            </>
          ) : (
            <>
              <Send size={14} /> Submit Argument
            </>
          )}
        </button>
      </form>
    </div>
  );
};
