import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Radio, 
  Sparkles, 
  User, 
  Play, 
  Square, 
  MessageSquare, 
  HelpCircle, 
  Users, 
  ChevronRight, 
  Flame, 
  Lightbulb, 
  ShieldAlert, 
  BookOpen, 
  ArrowRight,
  Hand
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { generateAIResponse, generateSpeech } from '../lib/gemini';
import { createVoiceNormalizationChain } from '../lib/audioPipeline';
import { playLessonInitializingCue } from '@/src/lib/chalkAudio';

// Web Speech Recognition Types
interface SpeechRecognitionResult {
  readonly [index: number]: SpeechRecognitionAlternative;
  readonly length: number;
}
interface SpeechRecognitionAlternative {
  readonly transcript: string;
  readonly confidence: number;
}
interface SpeechRecognitionEvent {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
}
interface SpeechRecognitionResultList {
  readonly [index: number]: SpeechRecognitionResult;
  readonly length: number;
}

interface SeminarParticipant {
  id: string;
  name: string;
  role: 'professor' | 'guest' | 'student' | 'user';
  title: string;
  avatar: string;
  voiceName: string; // Gemini voice name
  localVoiceIndex?: number; // Browser speech voice selection
  color: string;
  isSpeaking: boolean;
  statusText: string;
  hasHandRaised: boolean;
}

interface LiveSeminarProps {
  theme: 'light' | 'dark';
  subject: string;
  topic: string;
  duration?: string;
  onClose: () => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

interface SeminarMessage {
  id: string;
  participantId: string;
  participantName: string;
  role: string;
  content: string;
  translations?: Record<string, string>; // Maps language code (e.g. 'es') to translated text
  timestamp: number;
}

export const TRANSLATION_LANGUAGES = [
  { code: 'original', name: 'Original English', flag: '🇺🇸', langCode: 'en-US' },
  { code: 'es', name: 'Spanish (Español)', flag: '🇪🇸', langCode: 'es-ES' },
  { code: 'fr', name: 'French (Français)', flag: '🇫🇷', langCode: 'fr-FR' },
  { code: 'de', name: 'German (Deutsch)', flag: '🇩🇪', langCode: 'de-DE' },
  { code: 'hi', name: 'Hindi (हिन्दी)', flag: '🇮🇳', langCode: 'hi-IN' },
  { code: 'ja', name: 'Japanese (日本語)', flag: '🇯🇵', langCode: 'ja-JP' },
  { code: 'zh', name: 'Chinese (中文)', flag: '🇨🇳', langCode: 'zh-CN' },
  { code: 'ar', name: 'Arabic (العربية)', flag: '🇸🇦', langCode: 'ar-SA' },
];

export const LiveSeminar: React.FC<LiveSeminarProps> = ({
  theme,
  subject,
  topic,
  duration,
  onClose,
  showNotification
}) => {
  // Seminar configuration & active states
  const [isSeminarActive, setIsSeminarActive] = useState(false);
  const [isInitializingSeminar, setIsInitializingSeminar] = useState(false);
  const [seminarMode, setSeminarMode] = useState<'lecture' | 'qa' | 'debate'>('lecture');
  const [audioMode, setAudioMode] = useState<'gemini' | 'browser' | 'muted'>('gemini');
  const [targetLanguage, setTargetLanguage] = useState<string>('original');
  const [speakTranslated, setSpeakTranslated] = useState<boolean>(false);
  const [isUserRecording, setIsUserRecording] = useState(false);
  const [isAITyping, setIsAITyping] = useState(false);
  const [hasUserRaisedHand, setHasUserRaisedHand] = useState(false);
  const [messages, setMessages] = useState<SeminarMessage[]>([]);
  const [activeSpeakerId, setActiveSpeakerId] = useState<string | null>(null);
  
  // Real-time live caption states for active speaker stage
  const [currentSpeakingText, setCurrentSpeakingText] = useState<string>('');
  const [currentSpeakingTranslation, setCurrentSpeakingTranslation] = useState<string>('');

  // Audio elements & speech recognition refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Participants State
  const [participants, setParticipants] = useState<SeminarParticipant[]>([
    {
      id: 'prof_alistair',
      name: 'Professor Alistair',
      role: 'professor',
      title: 'Principal Lecturer',
      avatar: '👨‍🏫',
      voiceName: 'Kore', // Deep, warm, professional
      color: 'border-indigo-500 bg-indigo-500/10 text-indigo-400',
      isSpeaking: false,
      statusText: 'Ready to teach',
      hasHandRaised: false
    },
    {
      id: 'dr_vance',
      name: 'Dr. Evelyn Vance',
      role: 'guest',
      title: 'Visiting Academic',
      avatar: '👩‍🔬',
      voiceName: 'Aoede', // Academic, articulate, female-skewed
      color: 'border-emerald-500 bg-emerald-500/10 text-emerald-400',
      isSpeaking: false,
      statusText: 'Reviewing reference papers',
      hasHandRaised: false
    },
    {
      id: 'peer_leo',
      name: 'Leo',
      role: 'student',
      title: 'Active Peer Student',
      avatar: '👦',
      voiceName: 'Puck', // Energetic, youthful
      color: 'border-amber-500 bg-amber-500/10 text-amber-400',
      isSpeaking: false,
      statusText: 'Taking notes',
      hasHandRaised: false
    },
    {
      id: 'user',
      name: 'You',
      role: 'user',
      title: 'Seminar Participant',
      avatar: '🎓',
      voiceName: 'Charon',
      color: 'border-rose-500 bg-rose-500/10 text-rose-400',
      isSpeaking: false,
      statusText: 'Listening',
      hasHandRaised: false
    }
  ]);

  // Keep a ref of participants to access up-to-date state inside asynchronous timers
  const participantsRef = useRef<SeminarParticipant[]>(participants);
  useEffect(() => {
    participantsRef.current = participants;
  }, [participants]);

  // Scroll to bottom of transcripts
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeSpeakerId]);

  // Translate existing messages when target language changes
  useEffect(() => {
    if (targetLanguage === 'original' || messages.length === 0) return;

    const translateExisting = async () => {
      setIsAITyping(true);
      let updatedAny = false;

      const updatedMessages = await Promise.all(
        messages.map(async (msg) => {
          if (msg.translations?.[targetLanguage]) {
            return msg; // Already translated
          }
          const translated = await translateText(msg.content, targetLanguage);
          updatedAny = true;
          return {
            ...msg,
            translations: {
              ...(msg.translations || {}),
              [targetLanguage]: translated
            }
          };
        })
      );

      if (updatedAny) {
        setMessages(updatedMessages);
        showNotification?.(`Translated transcript into ${TRANSLATION_LANGUAGES.find(l => l.code === targetLanguage)?.name}!`, 'success');
      }
      setIsAITyping(false);
    };

    translateExisting();
  }, [targetLanguage]);

  // Cleanup audio when leaving or shutting down
  useEffect(() => {
    return () => {
      stopAllAudio();
      stopRecognition();
    };
  }, []);

  const stopAllAudio = () => {
    if (activeAudioRef.current) {
      activeAudioRef.current.pause();
      activeAudioRef.current = null;
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    // Reset speaking status for all participants
    setParticipants(prev => prev.map(p => ({ ...p, isSpeaking: false })));
    setActiveSpeakerId(null);
  };

  const stopRecognition = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onend = null;
        recognitionRef.current.stop();
      } catch (e) {
        // Ignore
      }
      recognitionRef.current = null;
    }
    setIsUserRecording(false);
  };

  // Translates text on-the-fly using Gemini
  const translateText = async (text: string, targetLangCode: string): Promise<string> => {
    if (!targetLangCode || targetLangCode === 'original') return text;
    const langObj = TRANSLATION_LANGUAGES.find(l => l.code === targetLangCode);
    if (!langObj) return text;

    const prompt = `You are an elite academic interpreter. Translate the following English statement from an educational seminar into ${langObj.name}.
    Provide ONLY the direct translation, preserving the formal academic tone, clarity, and precision. No explanations, no introductory text, no quote marks around the outside, just the translation.
    
    Text to translate:
    "${text}"`;

    try {
      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      return response.trim().replace(/^"(.*)"$/, '$1'); // Clean wrapping quotes if any
    } catch (e) {
      console.error("Translation error for language " + targetLangCode, e);
      return text;
    }
  };

  // Speaks text aloud using selected audio mode (Gemini Server vs. Browser SpeechSynthesis)
  const speakAloud = async (text: string, voiceName: string, participantId: string, langCode: string = 'original') => {
    stopAllAudio();

    // Mark speaker as active
    setParticipants(prev => prev.map(p => 
      p.id === participantId 
        ? { ...p, isSpeaking: true, statusText: 'Speaking...' } 
        : { ...p, isSpeaking: false, statusText: p.id === 'user' ? 'Listening' : 'Listening attentively' }
    ));
    setActiveSpeakerId(participantId);

    if (audioMode === 'muted') {
      // Simulate speaking time based on word count
      const wordCount = text.split(/\s+/).length;
      const simulateDuration = Math.max(2000, wordCount * 300);
      await new Promise(resolve => setTimeout(resolve, simulateDuration));
      setParticipants(prev => prev.map(p => p.id === participantId ? { ...p, isSpeaking: false, statusText: 'Listening' } : p));
      setActiveSpeakerId(null);
      return;
    }

    if (audioMode === 'gemini') {
      try {
        const cleanedTextForTTS = text.replace(/[*#_`~[\]()]/g, '');
        const audioBase64 = await generateSpeech(cleanedTextForTTS, voiceName);
        if (audioBase64) {
          const audio = new Audio(`data:audio/wav;base64,${audioBase64}`);
          activeAudioRef.current = audio;
          
          // Setup Web Audio pipeline with Voice Normalization and Timbre Standardization
          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          if (AudioContextClass) {
            try {
              if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new AudioContextClass();
              }
              const ctx = audioContextRef.current;
              // Resume if suspended (browser security)
              if (ctx.state === 'suspended') {
                await ctx.resume().catch(() => {});
              }
              
              const source = ctx.createMediaElementSource(audio);
              const filterChain = createVoiceNormalizationChain(ctx);
              
              source.connect(filterChain.input);
              filterChain.output.connect(ctx.destination);
            } catch (webAudioErr) {
              console.warn("Failed to create Web Audio normalization node chain, playing raw audio fallback:", webAudioErr);
            }
          }

          await new Promise<void>((resolve) => {
            audio.onended = () => {
              resolve();
            };
            audio.onerror = () => {
              resolve();
            };
            audio.play().catch(err => {
              console.warn("Audio autoplay blocked or interrupted:", err);
              // Fallback to text timeout on autoplay block
              const wordCount = text.split(/\s+/).length;
              setTimeout(resolve, Math.max(2000, wordCount * 300));
            });
          });
        } else {
          // Fallback to browser speech if Gemini returned empty
          await speakWithBrowserSpeech(text, participantId, langCode);
        }
      } catch (err) {
        console.error("Gemini TTS Error:", err);
        // Fallback to browser speech
        await speakWithBrowserSpeech(text, participantId, langCode);
      }
    } else {
      // Browser Local SpeechSynthesis
      await speakWithBrowserSpeech(text, participantId, langCode);
    }

    // Mark speaker as finished
    setParticipants(prev => prev.map(p => p.id === participantId ? { ...p, isSpeaking: false, statusText: 'Completed turn' } : p));
    setActiveSpeakerId(null);
  };

  const speakWithBrowserSpeech = (text: string, participantId: string, langCode: string = 'original') => {
    return new Promise<void>((resolve) => {
      if (!window.speechSynthesis) {
        resolve();
        return;
      }

      window.speechSynthesis.cancel();
      const cleanedText = text.replace(/[*#_`~[\]()]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanedText);

      // Select voices based on index/role/language
      const voices = window.speechSynthesis.getVoices();
      
      if (langCode !== 'original') {
        // Find language mapping for correct accent/pronunciation
        const langObj = TRANSLATION_LANGUAGES.find(l => l.code === langCode);
        const targetBCP47 = langObj ? langObj.langCode : 'en-US';
        utterance.lang = targetBCP47;
        
        // Try to find a voice that matches target lang code
        const matchingVoice = voices.find(v => v.lang.startsWith(langCode) || v.lang.replace('_', '-').startsWith(targetBCP47.substring(0, 2)));
        if (matchingVoice) {
          utterance.voice = matchingVoice;
        }
      } else if (voices.length > 0) {
        if (participantId === 'prof_alistair') {
          // Prefer a deep male voice (e.g. Google US English, Microsoft David)
          const maleVoice = voices.find(v => v.name.includes('Male') || v.name.includes('David') || v.name.includes('Google US English'));
          if (maleVoice) utterance.voice = maleVoice;
        } else if (participantId === 'dr_vance') {
          // Prefer a female voice (e.g. Google UK English Female, Microsoft Zira)
          const femaleVoice = voices.find(v => v.name.includes('Female') || v.name.includes('Zira') || v.name.includes('Zarvox') || v.lang.startsWith('en-GB'));
          if (femaleVoice) utterance.voice = femaleVoice;
        } else if (participantId === 'peer_leo') {
          // High pitched/energetic voice (e.g. Google UK English Male)
          const highVoice = voices.find(v => v.name.includes('Natural') || v.lang.startsWith('en-IN') || v.lang.startsWith('en-AU'));
          if (highVoice) utterance.voice = highVoice;
        }
      }

      utterance.onend = () => {
        resolve();
      };
      utterance.onerror = (e) => {
        console.error("Browser speech utterance error:", e);
        resolve();
      };

      window.speechSynthesis.speak(utterance);
    });
  };

  // Appends message and speaks it aloud
  const executeParticipantTurn = async (participantId: string, content: string) => {
    const participant = participantsRef.current.find(p => p.id === participantId);
    if (!participant) return;

    let translations: Record<string, string> = {};
    let translatedContent = '';

    if (targetLanguage !== 'original') {
      setIsAITyping(true);
      translatedContent = await translateText(content, targetLanguage);
      translations[targetLanguage] = translatedContent;
      setIsAITyping(false);
    }

    // Set dynamic subtitles on active stage
    setCurrentSpeakingText(content);
    setCurrentSpeakingTranslation(translatedContent);

    const newMsg: SeminarMessage = {
      id: `sem_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      participantId: participant.id,
      participantName: participant.name,
      role: participant.role,
      content,
      translations: targetLanguage !== 'original' ? translations : undefined,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, newMsg]);

    // Choose which text to speak based on toggle
    const speechText = (speakTranslated && translatedContent) ? translatedContent : content;
    const activeLangCode = speakTranslated ? targetLanguage : 'original';

    await speakAloud(speechText, participant.voiceName, participant.id, activeLangCode);

    // Clear stage subtitles
    setCurrentSpeakingText('');
    setCurrentSpeakingTranslation('');
  };

  // Triggers simulated classmates behavior
  const triggerPeerInterruption = async (previousText: string) => {
    setIsAITyping(true);
    setParticipants(prev => prev.map(p => p.id === 'peer_leo' ? { ...p, statusText: 'Formulating a thought...', hasHandRaised: true } : p));
    
    // Quick delay before classmate speaks
    await new Promise(resolve => setTimeout(resolve, 2500));

    const prompt = `You are playing Leo, an enthusiastic, highly engaged peer student in a live seminar about "${topic.replace(/_/g, ' ')}" (Subject: ${subject}).
    The professor/guest just finished discussing this point: "${previousText}".
    
    Chime in with a short, highly natural classmate question, realization, or brief comment. Keep it to 1-2 sentences maximum. Do not say "as a peer student" or over-formalize. Be brief and inquisitive. Speak like a real student.`;

    try {
      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      setParticipants(prev => prev.map(p => p.id === 'peer_leo' ? { ...p, hasHandRaised: false } : p));
      setIsAITyping(false);
      await executeParticipantTurn('peer_leo', response);
      
      // Let professor or guest answer Leo
      await new Promise(resolve => setTimeout(resolve, 1000));
      await triggerExpertAnswer(response, 'peer_leo');
    } catch (e) {
      console.error(e);
      setIsAITyping(false);
      setParticipants(prev => prev.map(p => p.id === 'peer_leo' ? { ...p, hasHandRaised: false, statusText: 'Taking notes' } : p));
    }
  };

  // Experts respond to user/peer
  const triggerExpertAnswer = async (question: string, askerId: string) => {
    setIsAITyping(true);
    
    // Choose which expert responds
    const isDrVanceTurn = Math.random() > 0.5;
    const primaryExpertId = isDrVanceTurn ? 'dr_vance' : 'prof_alistair';
    const secondaryExpertId = isDrVanceTurn ? 'prof_alistair' : 'dr_vance';

    const primaryExpert = participantsRef.current.find(p => p.id === primaryExpertId)!;
    const secondaryExpert = participantsRef.current.find(p => p.id === secondaryExpertId)!;

    setParticipants(prev => prev.map(p => p.id === primaryExpertId ? { ...p, statusText: 'Thinking...' } : p));

    const prompt = `We are conducting a live simulated seminar about "${topic.replace(/_/g, ' ')}" (Subject: ${subject}).
    You are playing ${primaryExpert.name} (${primaryExpert.title}).
    The participant ${askerId === 'user' ? 'the student user' : 'the classmate Leo'} just asked/mentioned this: "${question}".

    Provide a concise, expert answer suitable for a spoken live seminar. Be encouraging, clear, and academically sound. Keep your response under 3-4 sentences so it flows well when spoken. Avoid markdown formatting like bullet points or bold symbols as it is spoken.`;

    try {
      const primaryResponse = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      setIsAITyping(false);
      await executeParticipantTurn(primaryExpertId, primaryResponse);

      // 30% chance for the other expert to chime in with supplementary insight
      if (Math.random() > 0.7) {
        await new Promise(resolve => setTimeout(resolve, 1500));
        setIsAITyping(true);
        setParticipants(prev => prev.map(p => p.id === secondaryExpertId ? { ...p, statusText: 'Adding an insight...' } : p));

        const bouncePrompt = `You are playing ${secondaryExpert.name} (${secondaryExpert.title}). 
        Your colleague ${primaryExpert.name} just explained: "${primaryResponse}" in response to: "${question}".
        
        Add a short, respectful supplementary sentence or quick detail to Dr. Vance's point. Keep it to 1-2 spoken sentences maximum. Do not use formatting.`;
        
        const secondaryResponse = await generateAIResponse(bouncePrompt, { model: 'gemini-3.6-flash' });
        setIsAITyping(false);
        await executeParticipantTurn(secondaryExpertId, secondaryResponse);
      }
    } catch (e) {
      console.error(e);
      setIsAITyping(false);
    }
  };

  // Start Seminar loop
  const handleStartSeminar = async () => {
    playLessonInitializingCue(0.35);
    setIsInitializingSeminar(true);
    setIsSeminarActive(true);
    setMessages([]);
    stopAllAudio();
    
    showNotification?.('Initializing seminar stream... Connecting to virtual lecture hall 🎓', 'info');
    setIsAITyping(true);

    // Initial greeting and brief lecture intro
    const prompt = `You are playing Professor Alistair, the principal lecturer of a live classroom seminar on the topic "${topic.replace(/_/g, ' ')}" in the subject of "${subject}".
    
    Formulate a brief, warm introductory greeting welcoming the user to this interactive voice-enabled seminar, and state what core concept we are going to explore today. Keep it to 3-4 highly engaging, spoken sentences. Do not use formatting (no stars, bolding, or lists).`;

    try {
      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      setIsAITyping(false);
      setIsInitializingSeminar(false);
      await executeParticipantTurn('prof_alistair', response);

      // Now guest scholar introduces herself / adds real world aspect
      await new Promise(resolve => setTimeout(resolve, 1200));
      setIsAITyping(true);
      setParticipants(prev => prev.map(p => p.id === 'dr_vance' ? { ...p, statusText: 'Chiming in...' } : p));

      const guestIntroPrompt = `You are playing Dr. Evelyn Vance, a specialized visiting research academic.
      Professor Alistair just introduced the seminar: "${response}".
      
      Chime in with a short, welcoming response highlighting a fascinating practical or research application of "${topic.replace(/_/g, ' ')}". Keep it under 3 natural spoken sentences.`;

      const guestResponse = await generateAIResponse(guestIntroPrompt, { model: 'gemini-3.6-flash' });
      setIsAITyping(false);
      await executeParticipantTurn('dr_vance', guestResponse);

      // Classmate Leo chimes in to prompt the user
      await new Promise(resolve => setTimeout(resolve, 1500));
      setIsAITyping(true);
      setParticipants(prev => prev.map(p => p.id === 'peer_leo' ? { ...p, statusText: 'Excited' } : p));

      const peerIntro = `Awesome! I was actually reviewing the syllabus on ${topic.replace(/_/g, ' ')} last night. Let's dig into the core details. We can ask questions or do a deep dive!`;
      setIsAITyping(false);
      await executeParticipantTurn('peer_leo', peerIntro);

    } catch (e) {
      console.error(e);
      setIsAITyping(false);
      showNotification?.('Failed to initiate live stream. Retrying connection...', 'error');
    }
  };

  // Stop / Reset Seminar
  const handleStopSeminar = () => {
    setIsSeminarActive(false);
    stopAllAudio();
    stopRecognition();
    showNotification?.('Seminar stream disconnected.', 'info');
  };

  // User speaks / submits a written or voice question
  const handleUserQuestionSubmit = async (text: string) => {
    if (!text.trim()) return;

    stopAllAudio();
    setHasUserRaisedHand(false);

    let translations: Record<string, string> = {};
    if (targetLanguage !== 'original') {
      setIsAITyping(true);
      const translated = await translateText(text, targetLanguage);
      translations[targetLanguage] = translated;
      setIsAITyping(false);
    }

    // Insert user message
    const userMsg: SeminarMessage = {
      id: `sem_user_${Date.now()}`,
      participantId: 'user',
      participantName: 'You',
      role: 'user',
      content: text,
      translations: targetLanguage !== 'original' ? translations : undefined,
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, userMsg]);

    // Set user mic and hand to inactive
    setParticipants(prev => prev.map(p => 
      p.id === 'user' 
        ? { ...p, isSpeaking: false, hasHandRaised: false, statusText: 'Awaiting answers...' } 
        : p
    ));

    // Trigger answers
    await triggerExpertAnswer(text, 'user');

    // 40% chance classmate chimes in after the answer is completed
    if (Math.random() > 0.6) {
      const lastMsg = messages[messages.length - 1]?.content || '';
      await triggerPeerInterruption(lastMsg);
    }
  };

  // Voice handler for the seminar
  const handleToggleVoiceInput = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showNotification?.('Web Speech API is not supported in this browser. Please type your questions.', 'warning');
      return;
    }

    if (isUserRecording) {
      stopRecognition();
      return;
    }

    stopAllAudio();
    setIsUserRecording(true);
    setParticipants(prev => prev.map(p => p.id === 'user' ? { ...p, statusText: 'Speaking...' } : p));

    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = false;
    rec.lang = 'en-US';

    rec.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        showNotification?.(`Transcribed question: "${transcript}"`, 'success');
        handleUserQuestionSubmit(transcript);
      }
    };

    rec.onerror = (e: any) => {
      const errorType = e?.error || '';
      if (errorType === 'no-speech' || errorType === 'aborted') {
        stopRecognition();
        return;
      }
      if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
        showNotification?.('Microphone permission denied.', 'warning');
      } else {
        showNotification?.('Microphone input failed or timed out. Please try again or type.', 'warning');
      }
      stopRecognition();
    };

    rec.onend = () => {
      stopRecognition();
    };

    recognitionRef.current = rec;
    rec.start();
  };

  const handleRaiseHand = () => {
    if (!isSeminarActive) return;
    
    const nextHand = !hasUserRaisedHand;
    setHasUserRaisedHand(nextHand);
    setParticipants(prev => prev.map(p => p.id === 'user' ? { ...p, hasHandRaised: nextHand, statusText: nextHand ? 'Hand raised ✋' : 'Listening' } : p));
    
    if (nextHand) {
      showNotification?.('You raised your hand! The professor will acknowledge you shortly.', 'success');
      
      // Simulate professor calling on you after 2 seconds
      setTimeout(async () => {
        if (!isSeminarActive) return;
        setIsAITyping(true);
        setParticipants(prev => prev.map(p => p.id === 'prof_alistair' ? { ...p, statusText: 'Calling on student' } : p));
        
        const callOut = `Yes, go ahead! We see you have a question. Please unmute your microphone or submit your prompt now. The floor is yours!`;
        setIsAITyping(false);
        await executeParticipantTurn('prof_alistair', callOut);

        // Turn on user voice input automatically to stream voice
        handleToggleVoiceInput();
      }, 2500);
    }
  };

  const handleManualTextSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const text = data.get('questionText') as string;
    if (!text.trim()) return;

    e.currentTarget.reset();
    handleUserQuestionSubmit(text);
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-hidden border-l transition-all duration-300 shadow-2xl",
      theme === 'dark' 
        ? "bg-slate-900 border-slate-800 text-slate-100" 
        : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Top Banner */}
      <div className={cn(
        "px-5 py-4 border-b flex items-center justify-between shrink-0",
        theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/25 relative">
            <Radio size={20} className="animate-pulse" />
            {isSeminarActive && (
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-red-500"></span>
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black uppercase tracking-wider">Live Classroom Seminar</h3>
              {isSeminarActive && (
                <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest bg-red-500/10 text-red-400 border border-red-500/20">
                  LIVE STREAM
                </span>
              )}
            </div>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">
              Subject: {subject} &middot; Topic: {topic.replace(/_/g, ' ')} {duration && `&middot; Duration: ${duration}`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Multilingual Translation Controls */}
          <div className="flex items-center gap-1.5 bg-slate-800/40 dark:bg-slate-950/30 p-1 rounded-xl border border-slate-700/40">
            <span className="text-[9px] pl-1.5 font-black uppercase tracking-widest text-indigo-400">Translate:</span>
            <select
              value={targetLanguage}
              onChange={(e) => {
                const newLang = e.target.value;
                setTargetLanguage(newLang);
                if (newLang === 'original') {
                  setSpeakTranslated(false);
                }
              }}
              className="bg-slate-900 border border-slate-700/50 rounded-lg text-[9px] py-0.5 px-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-black uppercase tracking-wider text-slate-200"
            >
              {TRANSLATION_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.flag} {l.name}
                </option>
              ))}
            </select>

            {targetLanguage !== 'original' && (
              <button
                onClick={() => {
                  const nextSpeak = !speakTranslated;
                  setSpeakTranslated(nextSpeak);
                  showNotification?.(
                    nextSpeak
                      ? 'AI will now synthesize and read lectures aloud in translated language!'
                      : 'AI will read lectures aloud in original English.',
                    'info'
                  );
                }}
                className={cn(
                  "px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer",
                  speakTranslated
                    ? "bg-indigo-600 text-white shadow"
                    : "bg-slate-800/60 text-slate-400 hover:text-slate-200"
                )}
                title="Speak translated text aloud instead of English"
              >
                📣 Voice Trans
              </button>
            )}
            <button
              onClick={handleStartSeminar}
              disabled={isInitializingSeminar}
              className={cn(
                "px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-wider text-white shadow transition-all cursor-pointer flex items-center gap-1 relative overflow-hidden",
                isInitializingSeminar
                  ? "bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600 ring-2 ring-emerald-400/50 animate-pulse cursor-wait"
                  : "bg-emerald-600 hover:bg-emerald-500 active:scale-95"
              )}
              title={isInitializingSeminar ? "Initializing Seminar Environment..." : "Start Lesson Stream"}
            >
              {isInitializingSeminar ? (
                <>
                  <Sparkles size={10} className="text-amber-300 animate-spin" />
                  <span className="animate-pulse">Initializing...</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping ml-0.5" />
                </>
              ) : (
                <>
                  <Play size={10} className="fill-white" /> Start Lesson
                </>
              )}
            </button>
          </div>

          {/* Audio Config Selector */}
          <div className="flex items-center gap-1 bg-slate-800/40 dark:bg-slate-950/30 p-1 rounded-xl border border-slate-700/40">
            <button
              onClick={() => {
                setAudioMode('gemini');
                showNotification?.('Switched to High-Quality Omni AI voices.', 'info');
              }}
              className={cn(
                "px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer",
                audioMode === 'gemini' 
                  ? "bg-indigo-600 text-white shadow" 
                  : "text-slate-400 hover:text-slate-200"
              )}
              title="Speak with server-side natural AI generation"
            >
              🌌 AI Voice
            </button>
            <button
              onClick={() => {
                setAudioMode('browser');
                showNotification?.('Switched to low-latency Browser speech.', 'info');
              }}
              className={cn(
                "px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer",
                audioMode === 'browser' 
                  ? "bg-emerald-600 text-white shadow" 
                  : "text-slate-400 hover:text-slate-200"
              )}
              title="Low-latency client synthesis"
            >
              💻 Browser
            </button>
            <button
              onClick={() => {
                setAudioMode('muted');
                showNotification?.('Live audio muted. Visual log active.', 'warning');
              }}
              className={cn(
                "p-1 rounded-lg transition-all cursor-pointer",
                audioMode === 'muted' 
                  ? "bg-rose-600/20 text-rose-400 border border-rose-500/20" 
                  : "text-slate-400 hover:text-slate-200"
              )}
              title="Silent text-only transcript stream"
            >
              <VolumeX size={12} />
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-400 hover:text-slate-200"
            title="Disconnect Room"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden min-h-0 relative">
        {/* Left pane: Audio Stream Avatars & Grid */}
        <div className={cn(
          "flex-1 p-5 overflow-y-auto flex flex-col justify-between border-b md:border-b-0 md:border-r gap-4",
          theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-slate-50/50 border-slate-200"
        )}>
          {/* Active Speaker Stage / Visual Waveform */}
          <div className={cn(
            "p-5 rounded-2xl border flex flex-col items-center justify-center relative min-h-[160px] overflow-hidden",
            theme === 'dark' ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-200 shadow-sm"
          )}>
            {isSeminarActive ? (
              <div className="text-center z-10 w-full flex flex-col items-center">
                {activeSpeakerId ? (
                  <>
                    <span className="text-4xl mb-3 block animate-bounce">
                      {participants.find(p => p.id === activeSpeakerId)?.avatar}
                    </span>
                    <h4 className="text-sm font-black text-indigo-400 uppercase tracking-widest">
                      {participants.find(p => p.id === activeSpeakerId)?.name}
                    </h4>
                    <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mt-1">
                      {participants.find(p => p.id === activeSpeakerId)?.title} &middot; Speaking
                    </p>
                    
                    {/* Pulsing Visual Waveform */}
                    <div className="flex items-center gap-1.5 justify-center mt-5 h-8">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((bar) => {
                        const delay = bar * 0.1;
                        return (
                          <div
                            key={bar}
                            style={{ animationDelay: `${delay}s` }}
                            className="w-1 bg-indigo-500 rounded-full animate-[pulse_1s_infinite_alternate]"
                          />
                        );
                      })}
                    </div>

                    {/* Live Captions / Dual-Language Subtitles */}
                    {currentSpeakingText && (
                      <div className="mt-4 max-w-md bg-slate-950/60 backdrop-blur border border-slate-800/80 rounded-2xl p-3 text-center shadow-xl space-y-2 animate-fade-in z-20">
                        <p className="text-[11px] text-slate-300 leading-relaxed italic">
                          "{currentSpeakingText}"
                        </p>
                        {targetLanguage !== 'original' && currentSpeakingTranslation && (
                          <div className="text-xs text-indigo-400 dark:text-indigo-300 font-bold leading-relaxed border-t border-dashed border-slate-800 pt-1.5 flex items-center justify-center gap-1.5">
                            <span className="text-[10px]">{TRANSLATION_LANGUAGES.find(l => l.code === targetLanguage)?.flag}</span>
                            <span>"{currentSpeakingTranslation}"</span>
                          </div>
                        )}
                      </div>
                    )}
                  </>
                ) : (
                  <>
                    <span className="text-4xl mb-3 block opacity-35">🎙️</span>
                    <h4 className="text-sm font-black uppercase tracking-widest opacity-40">
                      Seminar Listening Flow
                    </h4>
                    <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mt-1">
                      Waiting for scholar or student to begin next turn
                    </p>
                  </>
                )}
              </div>
            ) : (
              <div className="text-center z-10 p-4">
                <span className="text-4xl mb-4 block">🎓</span>
                <h4 className="text-base font-black uppercase tracking-wider text-indigo-400">
                  Join Interactive Seminar
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-2 leading-relaxed">
                  Connect to a simulated live lecture. Ask questions with real-time speech, receive voiced responses, and collaborate in academic debates!
                </p>
                <button
                  onClick={handleStartSeminar}
                  className="mt-6 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-indigo-600/20 active:scale-95 flex items-center gap-2 mx-auto cursor-pointer"
                >
                  <Play size={13} />
                  Connect to Seminar
                </button>
              </div>
            )}
            
            {/* Ambient chalkboard background grid */}
            <div className="absolute inset-0 bg-[radial-gradient(rgba(99,102,241,0.02)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />
          </div>

          {/* Grid of Seminar Members */}
          <div className="grid grid-cols-2 gap-3">
            {participants.map((person) => {
              const isSpeaker = person.isSpeaking;
              const isAUser = person.role === 'user';
              
              return (
                <div
                  key={person.id}
                  className={cn(
                    "p-3 rounded-2xl border transition-all duration-300 relative flex flex-col justify-between gap-2.5",
                    isSpeaker 
                      ? "border-indigo-500 ring-2 ring-indigo-500/20" 
                      : person.hasHandRaised 
                        ? "border-amber-500 ring-2 ring-amber-500/20"
                        : theme === 'dark' ? "bg-slate-950/20 border-slate-800" : "bg-white border-slate-200"
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{person.avatar}</span>
                      <div>
                        <h5 className="text-xs font-bold leading-none">{person.name}</h5>
                        <span className="text-[9px] text-slate-500 uppercase tracking-wider mt-0.5 block">{person.title}</span>
                      </div>
                    </div>

                    {/* Status Dot */}
                    <div className="flex items-center gap-1 shrink-0">
                      {isSpeaker ? (
                        <span className="flex h-1.5 w-1.5 rounded-full bg-indigo-500 animate-ping" />
                      ) : person.hasHandRaised ? (
                        <Hand size={11} className="text-amber-500" />
                      ) : (
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                      )}
                    </div>
                  </div>

                  {/* Bubble showing individual status */}
                  <div className={cn(
                    "px-2 py-1 rounded-lg text-[9px] font-bold truncate tracking-wide text-left uppercase",
                    isSpeaker 
                      ? "bg-indigo-500/10 text-indigo-400" 
                      : person.hasHandRaised 
                        ? "bg-amber-500/10 text-amber-500"
                        : "bg-slate-800/10 text-slate-500"
                  )}>
                    {person.statusText}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right pane: Real-Time Live Transcript Log */}
        <div className="w-full md:w-[350px] lg:w-[400px] flex flex-col overflow-hidden h-full shrink-0">
          <div className={cn(
            "px-4 py-2 border-b flex items-center justify-between shrink-0",
            theme === 'dark' ? "bg-slate-950/10 border-slate-800/80" : "bg-slate-100 border-slate-200"
          )}>
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Seminar Transcript</span>
            <span className="text-[9px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-bold uppercase tracking-widest">
              Rolling Logs
            </span>
          </div>

          {/* Transcript Scroll Container */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                <MessageSquare size={24} className="opacity-25 mb-2" />
                <p className="text-xs font-bold uppercase tracking-wide opacity-50">Stream Offline</p>
                <p className="text-[10px] mt-1">Connect to the seminar to witness the scholastic panel transcript log in real-time.</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isUser = msg.participantId === 'user';
                const currentParticipant = participants.find(p => p.id === msg.participantId);
                const avatar = currentParticipant?.avatar || '🗣️';

                return (
                  <div
                    key={msg.id}
                    className={cn(
                      "flex gap-2.5 items-start",
                      isUser ? "flex-row-reverse" : ""
                    )}
                  >
                    <span className="text-lg shrink-0 p-1 rounded-lg bg-slate-800/30">{avatar}</span>
                    <div className={cn(
                      "max-w-[80%] p-3 rounded-2xl text-xs leading-relaxed flex flex-col gap-1.5",
                      isUser
                        ? "bg-indigo-600 text-white rounded-tr-none"
                        : theme === 'dark' 
                          ? "bg-slate-850 text-slate-200 rounded-tl-none border border-slate-800" 
                          : "bg-white text-slate-800 rounded-tl-none border border-slate-100 shadow-sm"
                    )}>
                      <div className="flex items-center justify-between mb-0.5 gap-4">
                        <span className="font-extrabold text-[10px] opacity-75">{msg.participantName}</span>
                        <span className="text-[9px] opacity-40 font-mono">
                          {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </span>
                      </div>
                      
                      {/* Original Content */}
                      <p className={cn(
                        "whitespace-pre-wrap",
                        targetLanguage !== 'original' ? "opacity-60 text-[11px]" : ""
                      )}>
                        {msg.content}
                      </p>

                      {/* Multilingual translation section */}
                      {targetLanguage !== 'original' && msg.translations?.[targetLanguage] && (
                        <div className={cn(
                          "pt-1.5 border-t text-[12px] font-medium border-dashed",
                          isUser ? "border-indigo-400 text-indigo-100" : "border-slate-700/65 text-indigo-400 dark:text-indigo-300"
                        )}>
                          <span className="text-[9px] mr-1.5 bg-indigo-500/10 text-indigo-400 dark:text-indigo-300 font-extrabold tracking-widest px-1 py-0.5 rounded uppercase leading-none">
                            {TRANSLATION_LANGUAGES.find(l => l.code === targetLanguage)?.flag} Translated
                          </span>
                          <p className="mt-1 leading-relaxed">{msg.translations[targetLanguage]}</p>
                        </div>
                      )}

                      {/* Translation pending spinner */}
                      {targetLanguage !== 'original' && !msg.translations?.[targetLanguage] && (
                        <div className="text-[10px] text-slate-500 italic animate-pulse flex items-center gap-1.5 pt-1.5 border-t border-dashed border-slate-700/65">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping" />
                          Translating to {TRANSLATION_LANGUAGES.find(l => l.code === targetLanguage)?.name}...
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}

            {isAITyping && (
              <div className="flex items-center gap-2 text-xs text-slate-500 font-bold uppercase tracking-wider animate-pulse py-1">
                <span className="flex h-2 w-2 rounded-full bg-indigo-500" />
                Scholars formulating response...
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* User Active Interactivity Bar */}
          <div className={cn(
            "p-4 border-t shrink-0 flex flex-col gap-2.5",
            theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
          )}>
            <div className="flex items-center justify-between gap-2">
              <button
                onClick={handleRaiseHand}
                disabled={!isSeminarActive}
                className={cn(
                  "flex-1 px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider border flex items-center justify-center gap-1.5 transition-all duration-200 cursor-pointer",
                  !isSeminarActive
                    ? "opacity-35 cursor-not-allowed border-slate-800 text-slate-600"
                    : hasUserRaisedHand
                      ? "bg-amber-600 border-amber-500 text-white shadow-lg shadow-amber-600/10"
                      : "bg-slate-800 hover:bg-slate-700 text-amber-500 border-slate-700 hover:border-slate-600"
                )}
                title="Signal the professor that you have a question"
              >
                <Hand size={13} className={hasUserRaisedHand ? "animate-bounce" : ""} />
                {hasUserRaisedHand ? 'Hand Raised ✋' : 'Raise Hand'}
              </button>

              <button
                onClick={handleToggleVoiceInput}
                disabled={!isSeminarActive}
                className={cn(
                  "flex-1 px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider border flex items-center justify-center gap-1.5 transition-all duration-200 cursor-pointer",
                  !isSeminarActive
                    ? "opacity-35 cursor-not-allowed border-slate-800 text-slate-600"
                    : isUserRecording
                      ? "bg-red-600 border-red-500 text-white animate-pulse shadow-lg shadow-red-600/10"
                      : "bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-500"
                )}
                title="Speak directly using Speech recognition"
              >
                {isUserRecording ? <MicOff size={13} /> : <Mic size={13} />}
                {isUserRecording ? 'Stop Mic' : 'Speak to Panel'}
              </button>
            </div>

            {/* Written Question Fallback */}
            <form onSubmit={handleManualTextSubmit} className="flex gap-1.5 mt-0.5">
              <input
                name="questionText"
                type="text"
                disabled={!isSeminarActive}
                className={cn(
                  "flex-1 px-3.5 py-2 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500/50 border transition-all placeholder-slate-500",
                  theme === 'dark' 
                    ? "bg-slate-900 border-slate-800 text-white" 
                    : "bg-white border-slate-200 text-slate-800"
                )}
                placeholder={isSeminarActive ? "Type seminar question or ask peers..." : "Connect first to join..."}
              />
              <button
                type="submit"
                disabled={!isSeminarActive}
                className="px-3.5 bg-slate-800 hover:bg-slate-700 hover:text-white border border-slate-700 text-slate-300 rounded-xl transition-all cursor-pointer flex items-center justify-center"
              >
                <ArrowRight size={13} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
