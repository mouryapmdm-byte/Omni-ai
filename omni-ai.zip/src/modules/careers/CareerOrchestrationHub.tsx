import React, { useState } from 'react';
import { CareerExplorer } from './CareerExplorer';
import { ProfessionalVideos } from './ProfessionalVideos';
import { CollegePrep } from './CollegePrep';
import { Briefcase, Video, GraduationCap, Sparkles, Award } from 'lucide-react';

export const CareerOrchestrationHub: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [activeTab, setActiveTab] = useState<'explorer' | 'videos' | 'college'>('explorer');
  const [activeTrack, setActiveTrack] = useState<string | null>(null);
  const [unlockedXp, setUnlockedXp] = useState<number>(0);

  const handleEnroll = (careerTitle: string) => {
    setActiveTrack(careerTitle);
    setUnlockedXp(prev => prev + 100);
    alert(`Successfully enrolled in the ${careerTitle} specialized academic pathway track! (+100 XP)`);
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 p-6 space-y-8">
      
      {/* Editorial Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-6 gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-mono tracking-widest text-emerald-400 uppercase bg-emerald-950/40 border border-emerald-800 px-2.5 py-1 rounded-full">
              Syllabus-to-Careers Suite
            </span>
            {activeTrack && (
              <span className="text-[10px] font-mono tracking-widest text-sky-400 uppercase bg-sky-950/40 border border-sky-800 px-2.5 py-1 rounded-full animate-pulse flex items-center gap-1">
                <Award className="w-3 h-3" />
                Active Track: {activeTrack}
              </span>
            )}
            {unlockedXp > 0 && (
              <span className="text-[10px] font-mono tracking-widest text-yellow-400 uppercase bg-yellow-950/40 border border-yellow-800 px-2.5 py-1 rounded-full">
                +{unlockedXp} Career XP
              </span>
            )}
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Career & Skill-Based Pathways</h1>
          <p className="text-slate-400 text-xs max-w-xl font-medium leading-normal">
            Understand the "why" behind school subjects. Map standard textbook curriculum directly into active scientific, hardware, and engineering fields.
          </p>
        </div>

        {/* Horizontal Navigation Control Tab */}
        <div className="flex bg-slate-900 border border-slate-800 p-1.5 rounded-2xl shrink-0">
          {[
            { id: 'explorer', label: 'Career Explorer', icon: Briefcase },
            { id: 'videos', label: 'Professional Vlogs', icon: Video },
            { id: 'college', label: 'College & Prep', icon: GraduationCap }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4.5 py-2.5 text-xs font-bold rounded-xl transition-all ${
                activeTab === tab.id
                  ? 'bg-indigo-500 text-white shadow-lg'
                  : 'text-slate-400 hover:text-white hover:bg-slate-850'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* RENDER THE ACTIVE SUB VIEW */}
      <div className="bg-slate-950/20 border border-slate-900 rounded-3xl min-h-[500px]">
        {activeTab === 'explorer' && (
          <CareerExplorer 
            theme={theme} 
            onEnroll={handleEnroll} 
            onNavigateToTab={(tabId) => setActiveTab(tabId)} 
          />
        )}
        {activeTab === 'videos' && (
          <ProfessionalVideos theme={theme} />
        )}
        {activeTab === 'college' && (
          <CollegePrep theme={theme} />
        )}
      </div>

    </div>
  );
};
export default CareerOrchestrationHub;
