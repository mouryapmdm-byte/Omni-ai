export type DeviceTier = 'high' | 'medium' | 'low' | 'minimal';
export type RenderMode = 'full' | 'lite' | 'audio-only';
export type NetworkSpeed = 'fast' | 'medium' | 'slow';

export interface DeviceProfile {
  studentId: string;
  deviceTier: DeviceTier;
  ramMB: number;
  cpuCores: number;
  gpuSupported: boolean;
  webgl2Supported: boolean;
  networkSpeed: NetworkSpeed;
  mode: RenderMode;
  autoDetected: boolean;
  batterySaverActive?: boolean;
  measuredFps: number;
  jankCount: number;
  memoryEstimateMB: number;
  dataUsageBytes: number;
  dataSaverEnabled: boolean;
  updatedAt: string;
}

export interface PerformanceMetrics {
  currentFps: number;
  averageFps: number;
  jankPercentage: number;
  frameDropCount: number;
  memoryUsedMB: number;
  domNodeCount: number;
  isThrottlingRecommended: boolean;
}

export interface DataSaverStats {
  totalBytesSaved: number;
  totalBytesUsed: number;
  cacheHitRatio: number;
  monthlyBudgetMB: number;
  currentMonthUsageMB: number;
}
