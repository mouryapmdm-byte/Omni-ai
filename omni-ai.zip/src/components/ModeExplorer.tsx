import React from 'react';
import { 
  X, Monitor, Radio, Globe, Layers, PenTool, 
  Brain, Calculator, Timer, FileSearch, Settings,
  Sparkles, Zap, GraduationCap, Video, Coins, Target,
  LayoutGrid, MessageSquare, Play, Box, Maximize2, Boxes, Volume2,
  Orbit, ShieldCheck, Code2
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface ModeExplorerProps {
  theme: 'light' | 'dark';
  onClose: () => void;
  onSelectAction: (id: string) => void;
  onSelectMode: (mode: string) => void;
  currentMode: string;
}

export const ModeExplorer: React.FC<ModeExplorerProps> = ({ 
  theme, 
  onClose, 
  onSelectAction, 
  onSelectMode,
  currentMode 
}) => {
  const categories = [
    {
      title: "Core Experience Modes",
      description: "Switch your primary workspace focus",
      items: [
        { id: 'learn', label: 'Adaptive Learn (Standard)', icon: <GraduationCap />, color: 'text-emerald-400', bg: 'bg-emerald-500/10', desc: 'Standard interactive tutor play mode with AI assistance.', type: 'mode' },
        { id: '3d_classroom', label: 'Virtual 3D (3D Hall & Lab)', icon: <Box />, color: 'text-blue-400', bg: 'bg-blue-500/10', desc: 'Interactive 3D virtual lecture hall & science lab with 3D tutor, holograms & Prof. Omni AI.', type: 'mode' },
        { id: 'entrance', label: 'Entrance Exams', icon: <Target />, color: 'text-amber-500', bg: 'bg-amber-500/10', desc: 'Specialized coaching for high-stakes entrance tests.', type: 'mode' },
        { id: 'competitive', label: 'Jobs & Competitive', icon: <Zap />, color: 'text-emerald-500', bg: 'bg-emerald-500/10', desc: 'Speed drills and optimization for recruitment exams.', type: 'mode' },
        { id: 'videos', label: 'Video Lecture Lab', icon: <Video />, color: 'text-rose-500', bg: 'bg-rose-500/10', desc: 'Watch and dissect lectures with AI insights.', type: 'mode' },
        { id: 'earn', label: 'Learn & Earn', icon: <Coins />, color: 'text-yellow-500', bg: 'bg-yellow-500/10', desc: 'Build skills and earn tokens for your progress.', type: 'mode' },
      ]
    },
    {
      title: "Specialized Studios & STEM Labs",
      description: "Advanced interactive simulations & labs",
      items: [
        { id: 'nextgen_stem', label: 'Next-Gen STEM Suite', icon: <Sparkles />, color: 'text-indigo-400', bg: 'bg-indigo-500/10', desc: 'Comprehensive suite: 3D spatial geometry, molecular lattices, multi-domain physics & Lean4 proofs.', type: 'action' },
        { id: 'spatial_3d', label: '3D Geometry & Molecules', icon: <Box />, color: 'text-purple-400', bg: 'bg-purple-500/10', desc: 'Real-time 3D rotation, crystal lattices (FCC/BCC), quadric surfaces & vector calculus.', type: 'action' },
        { id: 'physics_lab', label: 'Advanced Physics Lab', icon: <Orbit />, color: 'text-cyan-400', bg: 'bg-cyan-500/10', desc: 'N-body gravity orbits, Snell & lens optics, Carnot heat engine & Doppler shock cone.', type: 'action' },
        { id: 'proof_checker', label: 'Mathematical Proof Checker', icon: <ShieldCheck />, color: 'text-emerald-400', bg: 'bg-emerald-500/10', desc: 'Step-by-step deductive theorem prover with Lean 4 code and AI logic verifier.', type: 'action' },
        { id: 'multimodal_study', label: 'Multimodal Materials', icon: <Sparkles />, color: 'text-amber-400', bg: 'bg-amber-500/10', desc: 'Whiteboard OCR, vectorization, KaTeX rendering, and auto-generated SM-2 flashcards.', type: 'action' },
        { id: 'spatialcanvas', label: 'Spatial Lecture Canvas', icon: <Boxes />, color: 'text-indigo-400', bg: 'bg-indigo-500/10', desc: 'Integrated modular canvas with dynamic visual nodes.', type: 'action' },
        { id: 'diagram_analyzer', label: 'Diagram Vision AI', icon: <Maximize2 />, color: 'text-amber-400', bg: 'bg-amber-500/10', desc: 'AI-powered diagram analysis and decoding tool.', type: 'action' },
        { id: 'screenrecord', label: 'Screen Recorder', icon: <Video />, color: 'text-rose-400', bg: 'bg-rose-500/10', desc: 'Record screen & lessons with audio for offline review.', type: 'action' },
        { id: 'screenshare', label: 'Screen Share', icon: <Monitor />, color: 'text-emerald-400', bg: 'bg-emerald-500/10', desc: 'Broadcast your screen for collaborative sessions.', type: 'action' },
        { id: 'seminar', label: 'Live Seminar', icon: <Radio />, color: 'text-indigo-400', bg: 'bg-indigo-500/10', desc: 'Join voice-powered live classroom discussions.', type: 'action' },
        { id: 'virtuallab', label: 'Virtual 3D Lab', icon: <Box />, color: 'text-blue-400', bg: 'bg-blue-500/10', desc: 'Immersive WebXR experiments in 3D.', type: 'action' },
        { id: 'code', label: 'Code Playground', icon: <Code2 />, color: 'text-slate-400', bg: 'bg-slate-500/10', desc: 'Full-stack interactive coding environment.', type: 'action' },
        { id: 'graph', label: 'Knowledge Graph', icon: <Globe />, color: 'text-cyan-400', bg: 'bg-cyan-500/10', desc: 'Visualize concept connections in 2D/3D.', type: 'action' },
      ]
    },
    {
      title: "Productivity & Learning Tools",
      description: "Utility modules for deep study",
      items: [
        { id: 'feedback', label: 'Send Feedback', icon: <MessageSquare />, color: 'text-pink-400', bg: 'bg-pink-500/10', desc: 'Share your thoughts and help us improve.', type: 'action' },
        { id: 'cards', label: 'Flashcards (SM-2)', icon: <Layers />, color: 'text-orange-400', bg: 'bg-orange-500/10', desc: 'Spaced repetition for long-term retention.', type: 'action' },
        { id: 'quiz', label: 'Quiz Generator', icon: <Brain />, color: 'text-pink-400', bg: 'bg-pink-500/10', desc: 'Generate custom tests from any topic.', type: 'action' },
        { id: 'solver', label: 'Smart Solver', icon: <Calculator />, color: 'text-emerald-400', bg: 'bg-emerald-500/10', desc: 'Step-by-step solutions for complex math.', type: 'action' },
        { id: 'latex_tts', label: 'LaTeX TTS Engine', icon: <Volume2 />, color: 'text-indigo-400', bg: 'bg-indigo-500/10', desc: 'Generative semantic LaTeX-to-Speech synthesizer with interactive waveforms.', type: 'action' },
        { id: 'pomodoro', label: 'Focus Timer', icon: <Timer />, color: 'text-red-400', bg: 'bg-red-500/10', desc: 'Study sprints with ambient soundscapes.', type: 'action' },
        { id: 'scratchpad', label: 'State Scratchpad', icon: <PenTool />, color: 'text-purple-400', bg: 'bg-purple-500/10', desc: 'Interactive canvas for conceptual sketching.', type: 'action' },
      ]
    }
  ];

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-300",
      theme === 'dark' ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-800"
    )}>
      {/* Header */}
      <div className={cn(
        "px-8 py-6 border-b flex items-center justify-between shrink-0",
        theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200 shadow-sm"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <LayoutGrid size={24} className="text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-tight">Omni Launchpad</h2>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">
              Explore All Educational Modes & Experimental Tools
            </p>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="p-3 rounded-2xl hover:bg-slate-500/20 text-slate-400 transition-all hover:rotate-90"
        >
          <X size={24} />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
        <div className="max-w-6xl mx-auto space-y-12">
          {categories.map((category, idx) => (
            <div key={idx} className="space-y-6">
              <div className="flex items-baseline gap-4">
                <h3 className="text-lg font-black uppercase tracking-wider">{category.title}</h3>
                <p className="text-xs text-slate-500 font-medium">{category.description}</p>
                <div className="flex-1 border-t border-slate-200 dark:border-slate-800 ml-2"></div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                {category.items.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (item.type === 'mode') {
                        onSelectMode(item.id);
                      } else {
                        onSelectAction(item.id);
                      }
                      onClose();
                    }}
                    className={cn(
                      "group relative p-5 rounded-3xl border transition-all duration-300 text-left flex flex-col gap-4 overflow-hidden",
                      theme === 'dark' 
                        ? "bg-slate-900 border-slate-800 hover:border-indigo-500/50 hover:shadow-2xl hover:shadow-indigo-500/10" 
                        : "bg-white border-slate-200 hover:border-indigo-500 hover:shadow-xl hover:shadow-indigo-500/10",
                      item.type === 'mode' && currentMode === item.id && "ring-2 ring-indigo-500 border-indigo-500"
                    )}
                  >
                    <div className={cn(
                      "w-12 h-12 rounded-2xl flex items-center justify-center transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6 shadow-sm",
                      item.bg, item.color
                    )}>
                      {item.icon}
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-black text-sm uppercase tracking-tight">{item.label}</span>
                        {item.type === 'mode' && currentMode === item.id && (
                          <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium leading-relaxed line-clamp-2">
                        {item.desc}
                      </p>
                    </div>

                    <div className="mt-auto pt-2 flex items-center gap-2">
                       <span className={cn(
                         "text-[9px] font-black uppercase tracking-widest px-2 py-1 rounded-lg",
                         item.type === 'mode' ? "bg-indigo-500/10 text-indigo-500" : "bg-slate-500/10 text-slate-500"
                       )}>
                         {item.type === 'mode' ? 'Primary Mode' : 'Utility Tool'}
                       </span>
                    </div>

                    {/* Decorative element */}
                    <div className={cn(
                      "absolute -right-4 -bottom-4 opacity-0 group-hover:opacity-10 transition-opacity duration-500 scale-150",
                      item.color
                    )}>
                      {item.icon}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className={cn(
        "px-8 py-4 border-t shrink-0 flex items-center justify-center",
        theme === 'dark' ? "bg-slate-950 border-slate-900" : "bg-white border-slate-100"
      )}>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">
          Omni AI Integrated Educational OS v2.0 • Select a mode to begin
        </p>
      </div>
    </div>
  );
};

const Code = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
);
