import { createContext, useContext } from 'react';
import { DeviceProfile, RenderMode, PerformanceMetrics, DataSaverStats } from './types';

export interface DeviceTierContextValue {
  profile: DeviceProfile;
  setRenderMode: (mode: RenderMode) => void;
  toggleDataSaver: () => void;
  setDataSaverEnabled: (enabled: boolean) => void;
  metrics: PerformanceMetrics;
  dataSaverStats: DataSaverStats;
  isLiteMode: boolean;
  isAudioOnly: boolean;
  isFullMode: boolean;
  reProbeDevice: () => void;
}

export const DeviceTierContext = createContext<DeviceTierContextValue | null>(null);

export const useDeviceTier = (): DeviceTierContextValue => {
  const context = useContext(DeviceTierContext);
  if (!context) {
    throw new Error('useDeviceTier must be used within a DeviceTierProvider');
  }
  return context;
};
