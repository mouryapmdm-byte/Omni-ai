import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { cn, downloadElegantQR, triggerHapticFeedback, fetchUniversalShareUrl, getSyncShareUrl } from '@/src/lib/utils';
import { Menu, BookOpen, Video, Trash2, ChevronDown, ChevronLeft, ChevronRight, Wrench, Globe, Box, PenTool, Languages, Sun, Moon, Brain, Calculator, Timer, Code, FileSearch, Volume2, VolumeX, Bolt, Info, Layers, Settings, Coins, Radio, Share2, Printer, X, ExternalLink, QrCode, GraduationCap, Award, Download, LogIn, LogOut, User, Monitor, LayoutGrid, Target, Zap, MessageSquare, Maximize2, FlaskConical, Flame, Atom, FileText, Table, Film, LayoutDashboard, Play, Shield, Wand2, Check, Search, MoreVertical, Sliders, Smartphone, Copy, Key, Activity, HelpCircle, Sparkles, RotateCcw, RefreshCw } from 'lucide-react';
import { LANGUAGES } from '@/src/lib/constants';
import { QRCodeCanvas } from 'qrcode.react';
import { auth } from '@/src/lib/firebase';
import { signInWithPopup, GoogleAuthProvider, signOut, User as FirebaseUser } from 'firebase/auth';
import { PWAInstallButton } from './PWAInstallButton';
import { useIsMaker, setMakerMode } from '@/src/lib/makerDevice';

interface TopNavProps {
  onToggleSidebar: () => void;
  mode: string;
  setMode: (mode: string) => void;
  onClearChat: () => void;
  onSelectTopic: (topic: string) => void;
  onSelectLanguage: (lang: string) => void;
  onOpenTool: (tool: string) => void;
  onToggleTheme: (theme: 'light' | 'dark' | 'auto' | 'high-contrast' | 'high-contrast-green') => void;
  language: string;
  theme: 'light' | 'dark';
  themeMode: 'light' | 'dark' | 'auto' | 'high-contrast' | 'high-contrast-green';
  isThinking: boolean;
  setIsThinking: (val: boolean) => void;
  isTTSEnabled: boolean;
  setIsTTSEnabled: (val: boolean) => void;
  isLowLatency: boolean;
  setIsLowLatency: (val: boolean) => void;
  isShared?: boolean;
  isPreviewEnv?: boolean;
  expiresAt?: number;
  activeViewersCount?: number;
  firebaseUser?: FirebaseUser | null;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  showDashboard?: boolean;
  onToggleDashboard?: () => void;
  onStartTour?: () => void;
  onManualSync?: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  onToggleSidebar,
  mode,
  setMode,
  onClearChat,
  onSelectTopic,
  onSelectLanguage,
  onOpenTool,
  onToggleTheme,
  language,
  theme,
  themeMode,
  isThinking,
  setIsThinking,
  isTTSEnabled,
  setIsTTSEnabled,
  isLowLatency,
  setIsLowLatency,
  isShared = false,
  isPreviewEnv = false,
  expiresAt,
  activeViewersCount = 1,
  firebaseUser = null,
  showNotification,
  showDashboard = false,
  onToggleDashboard,
  onStartTour,
  onManualSync
}) => {
  const [toolsOpen, setToolsOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [langSearch, setLangSearch] = useState('');
  const [modeOpen, setModeOpen] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [showConfirmClear, setShowConfirmClear] = useState(false);
  const [mobileQuickMenuOpen, setMobileQuickMenuOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState<string>(() => getSyncShareUrl());
  const [isShareCopied, setIsShareCopied] = useState(false);
  const [isManualSyncing, setIsManualSyncing] = useState(false);

  const handleManualSyncRefresh = () => {
    triggerHapticFeedback(12);
    if (isManualSyncing) return;
    setIsManualSyncing(true);

    const now = Date.now();
    const lastSync = sessionStorage.getItem('omni_last_manual_sync');
    if (lastSync && now - parseInt(lastSync, 10) < 1500) {
      showNotification?.("Sync already in progress...", "info");
      setTimeout(() => setIsManualSyncing(false), 800);
      return;
    }
    sessionStorage.setItem('omni_last_manual_sync', now.toString());

    try {
      localStorage.setItem('omni_sync_timestamp', now.toString());
    } catch (e) {
      console.warn('Storage sync error:', e);
    }

    // Dispatch custom event for safe state-preserved refresh across components
    window.dispatchEvent(new CustomEvent('omni-manual-sync', { detail: { timestamp: now } }));

    if (onManualSync) {
      onManualSync();
    }

    showNotification?.("UI & state safely refreshed without full browser reload!", "success");

    setTimeout(() => {
      setIsManualSyncing(false);
    }, 1000);
  };

  // Maker Privileges & Controls Visibility
  const isMaker = useIsMaker(firebaseUser);
  const [makerTapCount, setMakerTapCount] = useState(0);

  const handleMakerLogoTap = () => {
    setMakerTapCount((prev) => {
      const next = prev + 1;
      if (next >= 5) {
        const nextState = !isMaker;
        setMakerMode(nextState);
        triggerHapticFeedback(15);
        showNotification?.(
          nextState
            ? '👑 Maker Mode Activated: All controls (Active Users, History, Settings, Install App) are visible on this device.'
            : '🔒 User Mode Active: Maker controls are hidden.',
          'info'
        );
        return 0;
      }
      return next;
    });
  };

  useEffect(() => {
    if (makerTapCount > 0) {
      const timer = setTimeout(() => setMakerTapCount(0), 2500);
      return () => clearTimeout(timer);
    }
  }, [makerTapCount]);

  const langTriggerRef = React.useRef<HTMLButtonElement>(null);
  const [langDropdownCoords, setLangDropdownCoords] = useState({ top: 0, left: 0, width: 0 });

  useEffect(() => {
    const updateCoords = () => {
      if (langOpen && langTriggerRef.current) {
        const rect = langTriggerRef.current.getBoundingClientRect();
        setLangDropdownCoords({
          top: rect.bottom + window.scrollY,
          left: rect.left + window.scrollX,
          width: rect.width
        });
      }
    };
    
    updateCoords();
    if (langOpen) {
      window.addEventListener('resize', updateCoords);
      window.addEventListener('scroll', updateCoords, true);
    }
    return () => {
      window.removeEventListener('resize', updateCoords);
      window.removeEventListener('scroll', updateCoords, true);
    };
  }, [langOpen]);

  const handleOpenShareModal = async () => {
    triggerHapticFeedback(8);
    const resolvedUrl = await fetchUniversalShareUrl();
    setShareUrl(resolvedUrl || getSyncShareUrl());
    setShowQR(true);
  };

  const handleCopyShareLink = async () => {
    triggerHapticFeedback(10);
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(shareUrl);
      } else {
        const textarea = document.createElement("textarea");
        textarea.value = shareUrl;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setIsShareCopied(true);
      setTimeout(() => setIsShareCopied(false), 2200);
      showNotification?.("Public share link copied to clipboard!", "success");
    } catch {
      showNotification?.("Failed to copy automatically. Please select the URL directly.", "warning");
    }
  };

  // TopNav Global Search Bar State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchInputRef = React.useRef<HTMLInputElement>(null);

  // Keyboard shortcut listener for Ctrl+K / Cmd+K / Slash
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
        setIsSearchOpen(true);
      } else if (e.key === 'Escape') {
        setIsSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Search Catalog Index
  const searchItems = [
    { id: 't-1', title: "Electromagnetic Induction & Faraday's Law", type: 'Lesson', category: 'Physics', action: () => onSelectTopic("Electromagnetic Induction & Faraday's Law") },
    { id: 't-2', title: "Photosynthesis & Light Reactions", type: 'Lesson', category: 'Biology', action: () => onSelectTopic("Photosynthesis & Light Reactions") },
    { id: 't-3', title: "Organic Chemistry & Reaction Mechanisms", type: 'Lesson', category: 'Chemistry', action: () => onSelectTopic("Organic Chemistry & Reaction Mechanisms") },
    { id: 't-4', title: "Quadratic Equations & Complex Roots", type: 'Lesson', category: 'Mathematics', action: () => onSelectTopic("Quadratic Equations & Complex Roots") },
    { id: 't-5', title: "Differential Calculus & Derivatives", type: 'Lesson', category: 'Mathematics', action: () => onSelectTopic("Differential Calculus & Derivatives") },
    { id: 't-6', title: "Genetics, DNA Replication & CRISPR", type: 'Lesson', category: 'Biology', action: () => onSelectTopic("Genetics, DNA Replication & CRISPR") },
    { id: 't-7', title: "Newton's Laws of Motion & Dynamics", type: 'Lesson', category: 'Physics', action: () => onSelectTopic("Newton's Laws of Motion & Dynamics") },
    { id: 't-8', title: "Thermodynamics & Heat Engines", type: 'Lesson', category: 'Physics', action: () => onSelectTopic("Thermodynamics & Heat Engines") },
    { id: 't-9', title: "Quantum Mechanics & Wave Functions", type: 'Lesson', category: 'Physics', action: () => onSelectTopic("Quantum Mechanics & Wave Functions") },
    { id: 't-10', title: "Optics, Lenses & Wave Diffraction", type: 'Lesson', category: 'Physics', action: () => onSelectTopic("Optics, Lenses & Wave Diffraction") },
    { id: 't-11', title: "Numerical Problems & Step-by-Step Practice", type: 'Lesson', category: 'Numerical', action: () => onSelectTopic("Numerical Problems & Step-by-Step Practice") },

    { id: 'm-learn', title: "Learn Mode (Interactive 2D Workspace)", type: 'Mode', category: 'View', action: () => setMode('learn') },
    { id: 'm-3d', title: "Virtual 3D Classroom & Prof. Omni AI", type: 'Mode', category: 'View', action: () => setMode('3d_classroom') },
    { id: 'm-diagram', title: "Diagram Play & Visual Grounding", type: 'Mode', category: 'View', action: () => setMode('diagram') },
    { id: 'm-entrance', title: "Entrance Prep & PYQs", type: 'Mode', category: 'View', action: () => setMode('entrance') },
    { id: 'm-competitive', title: "Competitive Exams & Mock Tests", type: 'Mode', category: 'View', action: () => setMode('competitive') },
    { id: 'm-videos', title: "AI Study Recap Video Studio", type: 'Mode', category: 'View', action: () => setMode('videos') },

    { id: 'f-tutor-chat', title: "Universal AI Tutor Chat (Multi-Board & Multilingual)", type: 'Tool', category: 'AI Tutor', action: () => onOpenTool('universal_ai_tutor') },
    { id: 'f-stem', title: "Next-Gen 3D STEM Labs & Sandbox", type: 'Tool', category: 'STEM', action: () => onOpenTool('nextgen_stem') },
    { id: 'f-reaction', title: "Chemical Reaction Mechanism Simulator", type: 'Tool', category: 'Chemistry', action: () => onOpenTool('chemical_reaction_simulator') },
    { id: 'f-atom', title: "Interactive Atom Builder", type: 'Tool', category: 'Chemistry', action: () => onOpenTool('interactive_atom_builder') },
    { id: 'f-veo-video', title: "Veo 3 AI Video Generations & Photo Animator", type: 'Tool', category: 'AI Video', action: () => onOpenTool('veo_video') },
    { id: 'f-calc', title: "Physical Constants & Calculator", type: 'Tool', category: 'Math/Physics', action: () => onOpenTool('constants_calculator') },
    { id: 'f-solver', title: "Step-by-Step Solver", type: 'Tool', category: 'AI Solver', action: () => onOpenTool('solver') },
    { id: 'f-quiz', title: "AI Quiz Generator", type: 'Tool', category: 'Practice', action: () => onOpenTool('quiz') },
    { id: 'f-formula', title: "Formula Architect & Practice", type: 'Tool', category: 'Practice', action: () => onOpenTool('formula_architect') },
    { id: 'f-wizard', title: "AI Socratic Tutor Wizard", type: 'Tool', category: 'Customization', action: () => onOpenTool('persona_wizard') },
    { id: 'f-dashboard', title: "Learning Analytics Dashboard", type: 'Tool', category: 'Analytics', action: () => onOpenTool('dashboard') },
    { id: 'f-cards', title: "Spaced Repetition Flashcards", type: 'Tool', category: 'Study', action: () => onOpenTool('cards') },
    { id: 'f-lab', title: "Chemistry Virtual Lab", type: 'Tool', category: 'Lab', action: () => onOpenTool('chemistry_virtual_lab') },
  ];

  const filteredSearchItems = searchQuery.trim()
    ? searchItems.filter(item => 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.type.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : searchItems.slice(0, 8);

  useEffect(() => {
    fetchUniversalShareUrl().then(url => {
      if (url) setShareUrl(url);
    });
  }, []);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      showNotification?.("Logged in successfully!", "success");
    } catch (error: any) {
      console.error("Login failed:", error);
      if (error.code === 'auth/internal-error') {
        showNotification?.("Login restricted. Check popups & CSP.", "error");
      } else {
        showNotification?.("Login failed. Please try again.", "error");
      }
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      showNotification?.("Logged out successfully!", "info");
    } catch (error) {
      console.error("Logout failed:", error);
      showNotification?.("Logout failed.", "error");
    }
  };

  const handleDownloadQR = () => {
    downloadElegantQR("share-qr-canvas", "omnitutor-share-qr.png");
  };

  const [timeLeft, setTimeLeft] = useState<string>('');

  useEffect(() => {
    if (!isPreviewEnv) return;

    const updateTimer = () => {
      if (!expiresAt) {
        setTimeLeft('Active');
        return;
      }

      const now = Date.now();
      const diff = expiresAt - now;

      if (diff <= 0) {
        setTimeLeft('Expired');
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      if (hours > 24) {
        setTimeLeft(`${Math.floor(hours / 24)}d ${hours % 24}h remaining`);
      } else if (hours > 0) {
        setTimeLeft(`${hours}h ${minutes}m remaining`);
      } else {
        setTimeLeft(`${minutes}m remaining`);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 60000); // Update every minute
    return () => clearInterval(interval);
  }, [isPreviewEnv, expiresAt]);

  const navScrollRef = React.useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const checkScrollLimits = () => {
    if (navScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = navScrollRef.current;
      setCanScrollLeft(scrollLeft > 5);
      setCanScrollRight(scrollLeft + clientWidth < scrollWidth - 5);
    }
  };

  useEffect(() => {
    const el = navScrollRef.current;
    if (!el) return;

    checkScrollLimits();

    const handleScroll = () => checkScrollLimits();
    el.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);

    // Dedicated non-passive wheel listener: turns any mouse wheel movement over the header into smooth horizontal scroll!
    const handleWheel = (e: WheelEvent) => {
      if (el.scrollWidth > el.clientWidth) {
        const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
        if (delta !== 0) {
          e.preventDefault();
          el.scrollLeft += delta * 1.5;
          checkScrollLimits();
        }
      }
    };
    el.addEventListener('wheel', handleWheel, { passive: false });

    // Drag to scroll on desktop
    let isDown = false;
    let startX = 0;
    let initialScroll = 0;
    let dragged = false;

    const onMouseDown = (e: MouseEvent) => {
      if ((e.target as HTMLElement).closest('input, textarea, select')) return;
      isDown = true;
      startX = e.pageX - el.offsetLeft;
      initialScroll = el.scrollLeft;
      dragged = false;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDown) return;
      const x = e.pageX - el.offsetLeft;
      const walk = (x - startX) * 1.3;
      if (Math.abs(walk) > 4) {
        dragged = true;
        el.scrollLeft = initialScroll - walk;
        checkScrollLimits();
      }
    };

    const onMouseUp = () => {
      isDown = false;
    };

    const onClickCapture = (e: MouseEvent) => {
      if (dragged) {
        e.stopPropagation();
        e.preventDefault();
        dragged = false;
      }
    };

    el.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    el.addEventListener('click', onClickCapture, true);

    let resizeObserver: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => {
        checkScrollLimits();
      });
      resizeObserver.observe(el);
      if (el.firstElementChild) {
        resizeObserver.observe(el.firstElementChild);
      }
    }

    const t1 = setTimeout(checkScrollLimits, 100);
    const t2 = setTimeout(checkScrollLimits, 400);
    const t3 = setTimeout(checkScrollLimits, 1000);

    return () => {
      el.removeEventListener('scroll', handleScroll);
      el.removeEventListener('wheel', handleWheel);
      el.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      el.removeEventListener('click', onClickCapture, true);
      window.removeEventListener('resize', handleScroll);
      if (resizeObserver) resizeObserver.disconnect();
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, []);

  const scrollHeader = (direction: 'left' | 'right') => {
    triggerHapticFeedback(8);
    if (navScrollRef.current) {
      const scrollAmount = Math.max(300, Math.floor(navScrollRef.current.clientWidth * 0.7));
      navScrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
      setTimeout(checkScrollLimits, 350);
    }
  };

  const modeNames: Record<string, string> = { 
    learn: 'Learn',
    '3d_classroom': 'Virtual 3D',
    diagram: 'Diagram Play',
    entrance: 'Entrance',
    competitive: 'Competitive',
    videos: 'Videos',
    earn: 'Earn'
  };

  return (
    <>
    <header 
      onMouseEnter={checkScrollLimits}
      className={cn(
        "sticky top-0 z-[100] border-b no-print w-full max-w-full min-w-0 transition-all duration-300 relative group/header",
        theme === 'dark' 
          ? "bg-slate-900/95 border-slate-800/80 text-white shadow-2xl shadow-slate-950/50" 
          : "bg-white/95 border-slate-200/80 text-slate-900 backdrop-blur-xl shadow-lg shadow-slate-200/20"
      )}
    >
      {/* Edge gradient fade left */}
      {canScrollLeft && (
        <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-white dark:from-slate-900 via-white/80 dark:via-slate-900/80 to-transparent pointer-events-none z-[115]" />
      )}

      {/* Edge gradient fade right */}
      {canScrollRight && (
        <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-white dark:from-slate-900 via-white/80 dark:via-slate-900/80 to-transparent pointer-events-none z-[115]" />
      )}

      {/* Scroll Left Button */}
      {canScrollLeft && (
        <button
          type="button"
          onClick={() => scrollHeader('left')}
          className={cn(
            "absolute left-1.5 top-1/2 -translate-y-1/2 z-[130] p-2 rounded-full border shadow-xl backdrop-blur-md transition-all active:scale-90 cursor-pointer flex items-center justify-center animate-in fade-in",
            theme === 'dark'
              ? "bg-indigo-600 text-white border-indigo-400 hover:bg-indigo-500 shadow-indigo-950/80"
              : "bg-indigo-600 text-white border-indigo-500 hover:bg-indigo-700 shadow-indigo-300/80"
          )}
          title="Scroll Header Left"
        >
          <ChevronLeft size={18} />
        </button>
      )}

      {/* Scroll Right Button */}
      {canScrollRight && (
        <button
          type="button"
          onClick={() => scrollHeader('right')}
          className={cn(
            "absolute right-1.5 top-1/2 -translate-y-1/2 z-[130] p-2 rounded-full border shadow-xl backdrop-blur-md transition-all active:scale-90 cursor-pointer flex items-center justify-center animate-in fade-in",
            theme === 'dark'
              ? "bg-indigo-600 text-white border-indigo-400 hover:bg-indigo-500 shadow-indigo-950/80"
              : "bg-indigo-600 text-white border-indigo-500 hover:bg-indigo-700 shadow-indigo-300/80"
          )}
          title="Scroll Header Right"
        >
          <ChevronRight size={18} />
        </button>
      )}

      {/* Horizontally scrollable track */}
      <div 
        ref={navScrollRef}
        className={cn(
          "w-full max-w-full min-w-0 overflow-x-auto header-scrollbar touch-pan-x scroll-smooth overscroll-x-contain px-3 sm:px-6 py-2 sm:py-3 cursor-grab active:cursor-grabbing",
        )}
        style={{
          WebkitOverflowScrolling: 'touch',
          scrollbarWidth: 'thin',
        }}
      >
        <div className="flex items-center justify-between w-max min-w-full gap-2.5 sm:gap-4 flex-nowrap py-0.5">
          {/* Left section: Sidebar menu toggle, Omni AI logo, Title & Mode indicator */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            <button 
              className={cn(
                "p-2 sm:p-2.5 rounded-2xl transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer min-w-[38px] min-h-[38px] flex items-center justify-center shrink-0",
                theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-300" : "bg-slate-100 hover:bg-slate-200 text-slate-700"
              )}
              onClick={() => {
                triggerHapticFeedback(10);
                onToggleSidebar();
              }}
              title="Open Curriculum & Navigation Menu"
            >
              <Menu size={20} className="sm:w-[22px] sm:h-[22px]" />
            </button>

            <div 
              onClick={handleMakerLogoTap}
              className="flex items-center gap-2 sm:gap-3 group cursor-pointer select-none shrink-0"
              title={isMaker ? "Omni AI (Maker Mode Active)" : "Omni AI"}
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl overflow-hidden shadow-lg shadow-indigo-500/20 group-hover:rotate-12 transition-transform duration-500 shrink-0 border border-white/20 bg-slate-950 flex items-center justify-center">
                <img 
                  src="/app-icon.jpg" 
                  alt="Omni AI Icon" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex flex-col shrink-0">
                <h1 className={cn(
                  "font-black text-sm sm:text-xl tracking-tight leading-none flex items-center gap-1 sm:gap-1.5 whitespace-nowrap",
                  theme === 'dark' ? "text-white" : "text-slate-900"
                )}>
                  Omni AI
                  {/* Active Users Badge - Visible on Maker's device */}
                  {isMaker && activeViewersCount > 0 && (
                    <span className="inline-flex items-center gap-1 text-[9px] sm:text-[10px] font-bold tracking-wider px-1.5 sm:px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 ml-1 shrink-0">
                      <span className="relative flex h-1.5 w-1.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                      </span>
                      {activeViewersCount} active
                    </span>
                  )}
                  {isPreviewEnv && (
                    <span className="flex items-center gap-1 text-[9px] sm:text-[10px] uppercase font-bold tracking-wider px-1.5 sm:px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-500 border border-amber-500/20 ml-1 shrink-0">
                      <Globe size={10} />
                      {timeLeft}
                    </span>
                  )}
                </h1>
                <p className="text-[9px] sm:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5 whitespace-nowrap">
                  {modeNames[mode]} Mode
                </p>
              </div>
            </div>
          </div>

          {/* Center section: Global Search Bar - Hidden per user request */}
          {false && (
            <div className="relative w-52 sm:w-64 md:w-80 shrink-0 mx-2">
              <div id="topnav-search-bar" className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all duration-200 shadow-sm",
                theme === 'dark' 
                  ? "bg-slate-800/90 border-slate-700/80 text-white focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20" 
                  : "bg-slate-100/90 border-slate-200/80 text-slate-900 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20"
              )}>
                <Search size={14} className="text-indigo-400 shrink-0" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setIsSearchOpen(true);
                  }}
                  onFocus={() => setIsSearchOpen(true)}
                  placeholder="Search lessons, tools... (Ctrl+K)"
                  className="w-full bg-transparent text-xs font-semibold outline-none placeholder:text-slate-400 border-none p-0 focus:ring-0"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="p-0.5 rounded-full text-slate-400 hover:text-white cursor-pointer shrink-0"
                  >
                    <X size={12} />
                  </button>
                )}
                <kbd className="hidden md:inline-block text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-700/60 text-slate-300 border border-slate-600/50 shrink-0">
                  ⌘K
                </kbd>
              </div>

              {/* Search Results Dropdown */}
              {isSearchOpen && (
                <>
                  <div className="fixed inset-0 z-[140]" onClick={() => setIsSearchOpen(false)} />
                  <div className={cn(
                    "absolute top-full left-0 right-0 mt-2 rounded-2xl border shadow-2xl p-2 z-[150] max-h-80 overflow-y-auto animate-in fade-in slide-in-from-top-2",
                    theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-slate-950/90" : "bg-white border-slate-200 shadow-slate-300/50"
                  )}>
                    <div className="px-2 py-1 text-[9px] font-black uppercase tracking-wider text-slate-400 border-b border-slate-800/20 pb-1.5 mb-1 flex justify-between">
                      <span>Search Results</span>
                      <span className="text-indigo-400 font-bold">{filteredSearchItems.length} matches</span>
                    </div>

                    {filteredSearchItems.length === 0 ? (
                      <div className="p-4 text-center text-xs text-slate-400 italic">
                        No matching lesson, chapter, or feature found.
                      </div>
                    ) : (
                      filteredSearchItems.map(item => (
                        <button
                          key={item.id}
                          onClick={() => {
                            triggerHapticFeedback(8);
                            item.action();
                            setIsSearchOpen(false);
                            setSearchQuery('');
                          }}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors cursor-pointer group mb-0.5",
                            theme === 'dark' ? "hover:bg-indigo-600/20 hover:text-white text-slate-300" : "hover:bg-indigo-50 hover:text-indigo-900 text-slate-700"
                          )}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className={cn(
                              "text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded border shrink-0",
                              item.type === 'Lesson' ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" :
                              item.type === 'Mode' ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" :
                              "bg-amber-500/10 text-amber-400 border-amber-500/20"
                            )}>
                              {item.type}
                            </span>
                            <span className="font-semibold truncate">{item.title}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 shrink-0 font-mono ml-2 opacity-70 group-hover:opacity-100">
                            {item.category}
                          </span>
                        </button>
                      ))
                    )}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Right section: Action controls in scrollable row */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Interactive Onboarding Tour Launcher */}
            <button
              onClick={() => {
                triggerHapticFeedback(8);
                onStartTour?.();
              }}
              className={cn(
                "p-2 rounded-full text-sm font-bold flex items-center justify-center transition-all active:scale-95 min-h-[36px] min-w-[36px] sm:min-h-[38px] sm:min-w-[38px] cursor-pointer border shrink-0",
                theme === 'dark' ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/30 hover:bg-indigo-500/20" : "bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100"
              )}
              title="Interactive Onboarding Tour"
            >
              <HelpCircle size={15} />
            </button>
            {/* Full Language Selector Dropdown */}
            <div className="relative shrink-0">
              <button
                ref={langTriggerRef}
                onClick={() => {
                  triggerHapticFeedback(8);
                  setLangOpen(!langOpen);
                }}
                className={cn(
                  "px-2 sm:px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1 sm:gap-1.5 transition-all active:scale-95 min-h-[36px] sm:min-h-[38px] cursor-pointer border shrink-0",
                  theme === 'dark' ? "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700" : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200"
                )}
                title="Select Translation Language"
              >
                <Languages size={14} className="text-indigo-500 shrink-0" />
                <span className="text-xs whitespace-nowrap flex items-center gap-1 font-bold">
                  {LANGUAGES.find(l => l.code === language)?.flag} {LANGUAGES.find(l => l.code === language)?.name || "English"}
                </span>
                <ChevronDown size={12} className="opacity-70 shrink-0" />
              </button>
              {langOpen && createPortal(
                <>
                  <div className="fixed inset-0 z-[140]" onClick={() => { setLangOpen(false); setLangSearch(''); }} />
                  <div 
                    style={{
                      position: 'absolute',
                      top: `${langDropdownCoords.top + 4}px`,
                      left: `${Math.min(window.innerWidth - 300, Math.max(10, langDropdownCoords.left + langDropdownCoords.width - 240))}px`,
                    }}
                    className={cn(
                      "w-72 sm:w-60 rounded-2xl shadow-2xl border p-2 z-[150] animate-in fade-in slide-in-from-top-2 flex flex-col max-h-[80vh]",
                      theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-slate-950/90 text-white" : "bg-white border-slate-200 shadow-slate-300/50 text-slate-900"
                    )}
                  >
                    <div className="px-2 py-1 text-[9px] font-black uppercase tracking-wider text-slate-400 mb-1.5 flex items-center justify-between border-b border-slate-800/20 pb-1.5">
                      <span>Select Language</span>
                      <span className="text-[10px] text-indigo-400 font-bold">{LANGUAGES.length} Languages</span>
                    </div>

                    {/* Quick Search Input */}
                    <div className="relative mb-2 px-1">
                      <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={langSearch}
                        onChange={(e) => setLangSearch(e.target.value)}
                        placeholder="Search language or script..."
                        className={cn(
                          "w-full pl-7 pr-2 py-1.5 text-xs rounded-xl border outline-none transition-all placeholder:text-slate-400",
                          theme === 'dark' ? "bg-slate-800/80 border-slate-700/80 text-white focus:border-indigo-500" : "bg-slate-100 border-slate-200 text-slate-900 focus:border-indigo-500"
                        )}
                        autoFocus
                      />
                    </div>

                    {/* Scrollable Language List */}
                    <div className="max-h-60 sm:max-h-72 overflow-y-auto overscroll-contain touch-pan-y space-y-0.5 pr-0.5 scroll-smooth">
                      {LANGUAGES.filter(lang => 
                        lang.name.toLowerCase().includes(langSearch.toLowerCase()) || 
                        lang.native?.toLowerCase().includes(langSearch.toLowerCase()) ||
                        lang.code.toLowerCase().includes(langSearch.toLowerCase())
                      ).map(lang => (
                        <button
                          key={lang.code}
                          onClick={() => {
                            onSelectLanguage(lang.code);
                            setLangOpen(false);
                            setLangSearch('');
                          }}
                          className={cn(
                            "w-full text-left px-2.5 py-2 text-xs rounded-xl flex items-center justify-between transition-colors cursor-pointer",
                            language === lang.code
                              ? "bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-600/30"
                              : (theme === 'dark' ? "hover:bg-slate-800/80 text-slate-300" : "hover:bg-slate-100 text-slate-700")
                          )}
                        >
                          <span className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
                            <span className="text-sm shrink-0">{lang.flag}</span>
                            <span className="font-semibold">{lang.name}</span>
                            {lang.native && lang.native !== lang.name && (
                              <span className="text-[10px] opacity-75 font-normal truncate">({lang.native})</span>
                            )}
                          </span>
                          {language === lang.code && <Check size={12} className="text-white shrink-0 ml-1" />}
                        </button>
                      ))}
                      {LANGUAGES.filter(lang => 
                        lang.name.toLowerCase().includes(langSearch.toLowerCase()) || 
                        lang.native?.toLowerCase().includes(langSearch.toLowerCase()) ||
                        lang.code.toLowerCase().includes(langSearch.toLowerCase())
                      ).length === 0 && (
                        <div className="p-3 text-center text-xs text-slate-400 italic">
                          No matching language found
                        </div>
                      )}
                    </div>
                  </div>
                </>
                , document.body
              )}
            </div>

            {/* Virtual 3D button */}
            <button 
              onClick={() => {
                triggerHapticFeedback(12);
                if (mode === '3d_classroom') {
                  setMode('learn');
                } else {
                  setMode('3d_classroom');
                }
              }}
              className={cn(
                "flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full transition-all active:scale-95 cursor-pointer border group font-sans text-xs font-bold min-h-[36px] sm:min-h-[38px] shrink-0",
                mode === '3d_classroom'
                  ? "bg-indigo-600 text-white border-indigo-400 shadow-lg shadow-indigo-500/30 ring-2 ring-indigo-500/20"
                  : theme === 'dark' 
                    ? "bg-indigo-500/10 text-indigo-300 border-indigo-500/30 hover:bg-indigo-500/20" 
                    : "bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100"
              )}
              title="Virtual 3D: 3D Lecture Hall, Science Lab, Animated Smartboard & Prof. Omni AI"
            >
              <Box size={14} className={cn("transition-transform group-hover:scale-110 shrink-0", mode === '3d_classroom' ? "text-white" : "text-indigo-400")} />
              <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">
                Virtual 3D
              </span>
            </button>

            {/* Learning Dashboard Toggle */}
            <button
              type="button"
              onClick={() => {
                triggerHapticFeedback(10);
                if (onToggleDashboard) {
                  onToggleDashboard();
                } else {
                  onOpenTool('dashboard');
                }
              }}
              title="Toggle Learning Dashboard"
              className={cn(
                "px-2.5 sm:px-3 py-1.5 rounded-full text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-sm border min-h-[36px] sm:min-h-[38px] shrink-0",
                showDashboard
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-indigo-500/30"
                  : theme === 'dark' 
                  ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-indigo-400" 
                  : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200 hover:text-indigo-600"
              )}
            >
              <LayoutDashboard size={14} className={cn("shrink-0", showDashboard ? "text-white" : "text-indigo-500")} />
              <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">Dashboard</span>
            </button>

            {/* Chat History & Saved Sessions Button - Visible on Maker's device */}
            {isMaker && (
            <button
              type="button"
              onClick={() => {
                triggerHapticFeedback(10);
                onOpenTool('chat_history');
              }}
              title="Chat History & Saved Firestore Sessions"
              className={cn(
                "px-2.5 sm:px-3 py-1.5 rounded-full text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-sm border min-h-[36px] sm:min-h-[38px] shrink-0",
                theme === 'dark' 
                  ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-indigo-400" 
                  : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200 hover:text-indigo-600"
              )}
            >
              <MessageSquare size={14} className="shrink-0 text-indigo-500" />
              <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">History</span>
            </button>
            )}

            {/* Launchpad Mode Button */}
            <button 
              className={cn(
                "p-2 rounded-full transition-all active:scale-95 flex items-center justify-center min-w-[36px] min-h-[36px] sm:min-w-[38px] sm:min-h-[38px] cursor-pointer shrink-0",
                "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/30"
              )}
              onClick={() => {
                triggerHapticFeedback(10);
                onOpenTool('explorer');
              }}
              title="Launchpad: Show All Study Modes"
            >
              <LayoutGrid size={15} />
            </button>

            {/* Theme Mode Toggle Button */}
            <button 
              className={cn(
                "p-2 rounded-full text-sm font-bold flex items-center justify-center transition-all active:scale-95 min-h-[36px] min-w-[36px] sm:min-h-[38px] sm:min-w-[38px] cursor-pointer border shrink-0",
                theme === 'dark' ? "bg-slate-800 text-yellow-400 border-slate-700 hover:bg-slate-700" : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200"
              )}
              onClick={() => {
                triggerHapticFeedback(8);
                const modes: ('light' | 'dark' | 'auto')[] = ['light', 'dark', 'auto'];
                const currentIndex = modes.indexOf(themeMode as any);
                const nextMode = modes[(currentIndex !== -1 ? currentIndex + 1 : 0) % modes.length];
                onToggleTheme(nextMode as any);
                showNotification?.(`Theme mode: ${nextMode.toUpperCase()}`, 'info');
              }}
              title={`Theme Mode: ${themeMode?.toUpperCase() || 'AUTO'} (Click to toggle Light, Dark, Auto)`}
            >
              {themeMode === 'light' ? <Sun size={15} /> : themeMode === 'dark' ? <Moon size={15} /> : <Monitor size={15} />}
            </button>

            {/* Mute All Audio Button */}
            <button 
              onClick={() => {
                triggerHapticFeedback(8);
                window.dispatchEvent(new CustomEvent('omni-audio-stop'));
                showNotification?.("All audio and speech stopped", "info");
              }}
              className={cn(
                "flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full transition-all active:scale-95 cursor-pointer border group shrink-0 min-h-[36px] sm:min-h-[38px]",
                theme === 'dark' ? "bg-red-500/10 text-red-400 border-red-500/20 hover:bg-red-500/20" : "bg-red-50 text-red-600 border-red-100 hover:bg-red-100"
              )}
              title="Mute All: Stop all ongoing speech"
            >
              <VolumeX size={14} className="group-hover:scale-110 transition-transform shrink-0" />
              <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">Mute</span>
            </button>

            {/* AI Tutor Chat - Hidden per user request */}
            {false && (
              <button 
                onClick={() => {
                  triggerHapticFeedback(10);
                  onOpenTool('universal_ai_tutor');
                }}
                className={cn(
                  "flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full transition-all active:scale-95 cursor-pointer border group font-sans text-xs font-bold shrink-0 min-h-[36px] sm:min-h-[38px]",
                  theme === 'dark' ? "bg-gradient-to-r from-indigo-600/20 to-purple-600/20 text-indigo-300 border-indigo-500/40 hover:border-indigo-400" : "bg-gradient-to-r from-indigo-50 to-purple-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100"
                )}
                title="Universal Multi-Board AI Tutor Chat with Socratic Calibration"
              >
                <Sparkles size={14} className="text-indigo-400 group-hover:scale-110 transition-transform shrink-0 animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">AI Tutor Chat</span>
              </button>
            )}

            {/* AI Tutor Wizard */}
            <button 
              onClick={() => {
                triggerHapticFeedback(10);
                onOpenTool('persona_wizard');
              }}
              className={cn(
                "flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full transition-all active:scale-95 cursor-pointer border group font-sans text-xs font-bold shrink-0 min-h-[36px] sm:min-h-[38px]",
                theme === 'dark' ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20" : "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100"
              )}
              title="AI Tutor Persona & Socratic Customization Wizard"
            >
              <Wand2 size={14} className="text-emerald-400 group-hover:rotate-12 transition-transform shrink-0" />
              <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">Tutor Wizard</span>
            </button>

            {/* STEM Labs - Hidden per user request */}
            {false && (
              <button 
                onClick={() => {
                  triggerHapticFeedback(10);
                  onOpenTool('nextgen_stem');
                }}
                className={cn(
                  "flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full transition-all active:scale-95 cursor-pointer border group font-sans text-xs font-bold shrink-0 min-h-[36px] sm:min-h-[38px]",
                  theme === 'dark' ? "bg-indigo-500/10 text-indigo-300 border-indigo-500/30 hover:bg-indigo-500/20" : "bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100"
                )}
                title="Next-Gen STEM 3D Simulations, Physics Sandbox & Proof Checker"
              >
                <Box size={14} className="text-indigo-400 group-hover:scale-110 transition-transform shrink-0" />
                <span className="text-[10px] font-black uppercase tracking-wider whitespace-nowrap">STEM Labs</span>
              </button>
            )}

            {/* Discreet Manual Sync & Refresh Button */}
            <button 
              type="button"
              onClick={handleManualSyncRefresh}
              disabled={isManualSyncing}
              className={cn(
                "p-2 rounded-full text-xs font-bold flex items-center justify-center transition-all active:scale-95 min-h-[36px] min-w-[36px] sm:min-h-[38px] sm:min-w-[38px] cursor-pointer border shrink-0 relative group",
                theme === 'dark' 
                  ? "bg-slate-800/90 text-cyan-400 border-slate-700/80 hover:bg-slate-700 hover:text-cyan-300 shadow-sm" 
                  : "bg-slate-100/90 text-cyan-700 border-slate-200/80 hover:bg-slate-200 hover:text-cyan-800 shadow-sm"
              )}
              title="Manual Sync & Refresh: Safely reload UI & preserve application state without page reloads"
            >
              <RotateCcw 
                size={15} 
                className={cn(
                  "shrink-0 transition-transform duration-700",
                  isManualSyncing ? "animate-spin text-cyan-400" : "group-hover:-rotate-90 text-cyan-500"
                )} 
              />
            </button>

            {/* QR Code Share Button */}
            <button 
              className={cn(
                "p-2 rounded-full text-sm font-bold flex items-center justify-center transition-all active:scale-95 min-h-[36px] min-w-[36px] sm:min-h-[38px] sm:min-w-[38px] cursor-pointer border shrink-0",
                theme === 'dark' ? "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700 hover:text-indigo-400" : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200 hover:text-indigo-600"
              )}
              onClick={handleOpenShareModal}
              title="QR Code & Mobile Companion Link"
            >
              <QrCode size={15} />
            </button>

            {/* Clear Chat History */}
            <button 
              className={cn(
                "p-2 rounded-full text-sm font-bold flex items-center justify-center transition-all active:scale-95 min-h-[36px] min-w-[36px] sm:min-h-[38px] sm:min-w-[38px] cursor-pointer border shrink-0",
                theme === 'dark' ? "bg-slate-800 text-rose-400 border-slate-700 hover:bg-rose-950/40" : "bg-slate-100 text-rose-600 border-slate-200 hover:bg-rose-50"
              )}
              onClick={() => {
                triggerHapticFeedback(10);
                setShowConfirmClear(true);
              }}
              title="Clear Chat History"
            >
              <Trash2 size={15} />
            </button>

            {/* Settings Button - Visible on Maker's device */}
            {isMaker && (
            <button 
              className={cn(
                "p-2 rounded-full text-sm font-bold flex items-center justify-center transition-all active:scale-95 min-h-[36px] min-w-[36px] sm:min-h-[38px] sm:min-w-[38px] cursor-pointer border shrink-0",
                theme === 'dark' ? "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700 hover:text-indigo-400" : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200 hover:text-indigo-600"
              )}
              onClick={() => {
                triggerHapticFeedback(8);
                onOpenTool('settings');
              }}
              title="AI & System Settings"
            >
              <Settings size={15} />
            </button>
            )}

            {/* PWA Install Button - Visible on Maker's device */}
            {isMaker && (
            <div className="shrink-0">
              <PWAInstallButton theme={theme} onOpenTool={onOpenTool} />
            </div>
            )}

            {/* Tools Dropdown Menu */}
            <div className="relative shrink-0">
              <button 
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 min-h-[36px] sm:min-h-[38px] cursor-pointer border shrink-0",
                  theme === 'dark' ? "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700" : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200"
                )}
                onClick={() => {
                  triggerHapticFeedback(8);
                  setToolsOpen(!toolsOpen);
                }}
              >
                <Wrench size={13} className="shrink-0 text-indigo-400" /> 
                <span className="whitespace-nowrap">Tools</span> 
                <ChevronDown size={12} className="shrink-0 opacity-70" />
              </button>
              
              {toolsOpen && (
                  <>
                    <div className="fixed inset-0 z-[140]" onClick={() => setToolsOpen(false)} />
                    <div className={cn(
                      "fixed md:absolute top-14 md:top-full right-2 md:right-0 mt-2 border rounded-2xl shadow-2xl p-3 w-72 md:min-w-[260px] max-h-[80vh] overflow-y-auto z-[150] animate-in fade-in slide-in-from-top-2",
                      theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-slate-950/80" : "bg-white border-slate-200/80 shadow-slate-200/50"
                    )}>
                      {[
                        { id: 'veo_video', label: 'Veo 3 AI Video Studio & Animator', icon: <Film size={14} className="text-purple-400" /> },
                        { id: 'dashboard', label: 'Learning Dashboard', icon: <LayoutDashboard size={14} className="text-indigo-500" /> },
                        { id: 'explorer', label: 'Explore All Modes', icon: <LayoutGrid size={14} className="text-indigo-500" /> },
                        { id: 'chemistry_glossary', label: 'Chemistry Glossary', icon: <FlaskConical size={14} className="text-emerald-500" /> },
                        { id: 'constants_calculator', label: 'Physical Constants & Calc', icon: <Calculator size={14} className="text-indigo-500" /> },
                        { id: 'algebraic_properties', label: 'Algebraic Properties', icon: <Calculator size={14} className="text-amber-500" /> },
                        { id: 'math_tables', label: 'Mathematical Tables', icon: <Table size={14} className="text-indigo-500" /> },
                        { id: 'matrix_calculator', label: 'Matrix Calculator', icon: <Calculator size={14} className="text-indigo-400" /> },
                        { id: 'recap_video', label: 'AI Study Recap Video', icon: <Film size={14} className="text-rose-500" /> },
                        { id: 'smart_glossary', label: 'Smart Concept Glossary', icon: <BookOpen size={14} className="text-emerald-400" /> },
                        { id: 'dynamic_lab_report', label: 'Dynamic Lab Report', icon: <FileText size={14} className="text-cyan-500" /> },
                        { id: 'chemical_reaction_simulator', label: 'Reaction Mechanism Simulator', icon: <Flame size={14} className="text-amber-500" /> },
                        { id: 'reaction_drill', label: 'Reaction Mechanism Drill', icon: <Flame size={14} className="text-amber-500" /> },
                        { id: 'chemistry_virtual_lab', label: 'Chemistry Virtual Lab', icon: <FlaskConical size={14} className="text-teal-500" /> },
                        { id: 'quick_periodic_table', label: 'Quick Periodic Table', icon: <Atom size={14} className="text-blue-500" /> },
                        { id: 'interactive_atom_builder', label: 'Interactive Atom Builder', icon: <Atom size={14} className="text-violet-500" /> },
                        { id: 'settings', label: 'AI & System Settings', icon: <Settings size={14} /> },
                        { id: 'feedback', label: 'Send Feedback', icon: <MessageSquare size={14} className="text-pink-500" /> },
                        { id: 'table_generator', label: 'Table & Matrix Generator', icon: <Table size={14} className="text-amber-400" /> },
                        { id: 'diagram', label: 'Diagram Vision AI', icon: <Maximize2 size={14} className="text-amber-500" /> },
                        { id: 'screenrecord', label: 'Screen Recording Studio', icon: <Video size={14} className="text-rose-500" /> },
                        { id: 'screenshare', label: 'Screen Share Studio', icon: <Monitor size={14} className="text-emerald-500" /> },
                        { id: 'seminar', label: 'Live Classroom Seminar', icon: <Radio size={14} className="text-indigo-500" /> },
                        { id: 'graph', label: 'Knowledge Graph', icon: <Globe size={14} /> },
                        { id: 'cards', label: 'Spaced Repetition', icon: <Layers size={14} /> },
                        { id: 'handwriting', label: 'Handwriting OCR', icon: <PenTool size={14} /> },
                        { id: 'quiz', label: 'AI Quiz Generator', icon: <Brain size={14} /> },
                        { id: 'solver', label: 'Step-by-Step Solver', icon: <Calculator size={14} /> },
                        { id: 'pomodoro', label: 'Study Timer', icon: <Timer size={14} /> },
                        { id: 'document', label: 'Document Analysis', icon: <FileSearch size={14} /> },
                        { id: 'biometric_vault', label: 'Biometric & Firebase Vault', icon: <Shield size={14} className="text-cyan-400" /> },
                        { id: 'auth_diagnostics', label: 'Auth & Shared Session Monitor', icon: <Key size={14} className="text-cyan-400" /> },
                        { id: 'debugger', label: 'Professor Clarity Debugger', icon: <Activity size={14} className="text-rose-400" /> },
                        { id: 'socratic_orchestrator', label: 'Socratic Lesson Orchestrator', icon: <GraduationCap size={14} className="text-indigo-400" /> },
                        { id: 'persona_wizard', label: 'Tutor Persona & Socratic Wizard', icon: <Wand2 size={14} className="text-emerald-400" /> },
                        { id: 'light', label: 'Light Mode', icon: <Sun size={14} />, action: () => onToggleTheme('light') },
                        { id: 'dark', label: 'Dark Mode', icon: <Moon size={14} />, action: () => onToggleTheme('dark') },
                        { id: 'auto', label: 'System/Auto', icon: <Monitor size={14} />, action: () => onToggleTheme('auto') }
                      ].map(tool => (
                        <div 
                          key={tool.id}
                          className={cn(
                            "p-2.5 cursor-pointer rounded-xl text-xs flex items-center gap-2.5 transition-colors font-semibold active:bg-indigo-600 active:text-white",
                            theme === 'dark' ? "hover:bg-slate-800 text-slate-300" : "hover:bg-slate-50 text-slate-700"
                          )}
                          onClick={() => {
                            if (tool.action) {
                              tool.action();
                            } else {
                              onOpenTool(tool.id);
                            }
                            setToolsOpen(false);
                          }}
                        >
                          <span className="text-slate-400 shrink-0">{tool.icon}</span>
                          <span className="truncate">{tool.label}</span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>

            {/* Authentication / Profile */}
            <div className="shrink-0">
              {firebaseUser ? (
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <div className="flex flex-col items-end mr-1">
                    <span className={cn("text-[11px] font-bold truncate max-w-[90px]", theme === 'dark' ? "text-white" : "text-slate-900")}>
                      {firebaseUser.displayName}
                    </span>
                    <span className="text-[9px] text-slate-500 font-medium">Logged In</span>
                  </div>
                  {firebaseUser.photoURL ? (
                    <img 
                      src={firebaseUser.photoURL} 
                      alt="Profile" 
                      className="w-8 h-8 rounded-full border-2 border-indigo-500 shadow-sm shrink-0"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 border border-indigo-200 shrink-0">
                      <User size={16} />
                    </div>
                  )}
                  <button 
                    onClick={handleLogout}
                    className={cn(
                      "p-2 rounded-full transition-all active:scale-95 flex items-center justify-center min-w-[36px] min-h-[36px] sm:min-w-[38px] sm:min-h-[38px] cursor-pointer shrink-0 border",
                      theme === 'dark' ? "bg-red-500/10 text-red-400 border-red-500/20 hover:bg-red-500/20" : "bg-red-50 text-red-600 border-red-100 hover:bg-red-100"
                    )}
                    title="Logout"
                  >
                    <LogOut size={15} />
                  </button>
                </div>
              ) : (
                <button 
                  onClick={handleLogin}
                  className={cn(
                    "px-3.5 py-1.5 rounded-full text-xs font-black flex items-center gap-1.5 transition-all active:scale-95 min-h-[36px] sm:min-h-[38px] cursor-pointer shadow-md shrink-0",
                    theme === 'dark' 
                      ? "bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-900/40" 
                      : "bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200/50"
                  )}
                >
                  <LogIn size={14} className="shrink-0" />
                  <span className="whitespace-nowrap">Login</span>
                </button>
              )}
            </div>

            {/* Mobile Quick Action Menu Button */}
            <button
              onClick={() => {
                triggerHapticFeedback(10);
                setMobileQuickMenuOpen(true);
              }}
              className={cn(
                "md:hidden p-2 rounded-full transition-all active:scale-95 flex items-center justify-center min-w-[36px] min-h-[36px] cursor-pointer border shrink-0",
                theme === 'dark' 
                  ? "bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700" 
                  : "bg-slate-100 text-slate-800 border-slate-200 hover:bg-slate-200"
              )}
              title="Quick Controls Menu"
            >
              <Sliders size={15} className="text-indigo-500" />
            </button>
          </div>
        </div>
      </div>
    </header>

    {/* MOBILE QUICK ACTION BOTTOM SHEET */}
    {mobileQuickMenuOpen && (
      <>
        <div 
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-[900] md:hidden animate-in fade-in"
          onClick={() => setMobileQuickMenuOpen(false)}
        />
        <div className={cn(
          "fixed bottom-0 inset-x-0 z-[950] md:hidden rounded-t-3xl border-t p-4 max-h-[85vh] overflow-y-auto overscroll-contain animate-in slide-in-from-bottom duration-300 pb-[calc(1.5rem+env(safe-area-inset-bottom,0px))]",
          theme === 'dark' ? "bg-slate-950 border-slate-800 text-white shadow-2xl" : "bg-white border-slate-200 text-slate-900 shadow-2xl"
        )}>
          {/* Handle bar */}
          <div className="w-12 h-1.5 bg-slate-400/40 rounded-full mx-auto mb-4" />

          <div className="flex items-center justify-between pb-3 border-b border-slate-800/40 mb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400">
                <Sliders size={16} />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider">Quick Controls</h3>
                <p className="text-[10px] text-slate-400">Fast access to tools, settings & modes</p>
              </div>
            </div>
            <button
              onClick={() => setMobileQuickMenuOpen(false)}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/60 cursor-pointer min-w-[36px] min-h-[36px] flex items-center justify-center"
            >
              <X size={18} />
            </button>
          </div>

          {/* Quick 2x2 Feature Cards - Install Omni AI App (Visible on Maker's device) */}
          {isMaker && (
          <div className="flex items-center justify-between p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 mb-3">
            <div className="flex items-center gap-2">
              <Smartphone size={16} className="text-indigo-400" />
              <div>
                <div className="text-xs font-black">Install Omni AI App</div>
                <div className="text-[10px] text-slate-400">Add to home screen on any phone/tablet</div>
              </div>
            </div>
            <PWAInstallButton theme={theme} onOpenTool={onOpenTool} compact />
          </div>
          )}

          <div className="grid grid-cols-2 gap-2 mb-4">
            <button
              onClick={() => {
                triggerHapticFeedback(10);
                setMobileQuickMenuOpen(false);
                onOpenTool('explorer');
              }}
              className={cn(
                "p-3 rounded-2xl border text-left flex items-center gap-2.5 transition-all active:scale-95 cursor-pointer",
                theme === 'dark' ? "bg-slate-900/80 border-slate-800 hover:border-indigo-500/50" : "bg-slate-50 border-slate-200 hover:border-indigo-400"
              )}
            >
              <div className="p-2 rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-600/30">
                <LayoutGrid size={16} />
              </div>
              <div>
                <div className="text-xs font-black">Launchpad</div>
                <div className="text-[10px] text-slate-400">All study modes</div>
              </div>
            </button>

            <button
              onClick={() => {
                triggerHapticFeedback(10);
                setMobileQuickMenuOpen(false);
                onOpenTool('persona_wizard');
              }}
              className={cn(
                "p-3 rounded-2xl border text-left flex items-center gap-2.5 transition-all active:scale-95 cursor-pointer",
                theme === 'dark' ? "bg-slate-900/80 border-slate-800 hover:border-emerald-500/50" : "bg-slate-50 border-slate-200 hover:border-emerald-400"
              )}
            >
              <div className="p-2 rounded-xl bg-emerald-600 text-white shadow-md shadow-emerald-600/30">
                <Wand2 size={16} />
              </div>
              <div>
                <div className="text-xs font-black">AI Persona</div>
                <div className="text-[10px] text-slate-400">Voice & tutor style</div>
              </div>
            </button>

            <button
              onClick={() => {
                triggerHapticFeedback(10);
                setMobileQuickMenuOpen(false);
                onOpenTool('nextgen_stem');
              }}
              className={cn(
                "p-3 rounded-2xl border text-left flex items-center gap-2.5 transition-all active:scale-95 cursor-pointer",
                theme === 'dark' ? "bg-slate-900/80 border-slate-800 hover:border-purple-500/50" : "bg-slate-50 border-slate-200 hover:border-purple-400"
              )}
            >
              <div className="p-2 rounded-xl bg-purple-600 text-white shadow-md shadow-purple-600/30">
                <Box size={16} />
              </div>
              <div>
                <div className="text-xs font-black">STEM Labs</div>
                <div className="text-[10px] text-slate-400">3D simulations</div>
              </div>
            </button>

            {/* Mobile Chat History - Visible on Maker's device */}
            {isMaker && (
            <button
              onClick={() => {
                triggerHapticFeedback(10);
                setMobileQuickMenuOpen(false);
                onOpenTool('chat_history');
              }}
              className={cn(
                "p-3 rounded-2xl border text-left flex items-center gap-2.5 transition-all active:scale-95 cursor-pointer",
                theme === 'dark' ? "bg-slate-900/80 border-slate-800 hover:border-indigo-500/50" : "bg-slate-50 border-slate-200 hover:border-indigo-400"
              )}
            >
              <div className="p-2 rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-600/30">
                <MessageSquare size={16} />
              </div>
              <div>
                <div className="text-xs font-black">Chat History</div>
                <div className="text-[10px] text-slate-400">Saved sessions</div>
              </div>
            </button>
            )}

            <button
              onClick={() => {
                triggerHapticFeedback(10);
                setMobileQuickMenuOpen(false);
                if (onToggleDashboard) onToggleDashboard();
                else onOpenTool('dashboard');
              }}
              className={cn(
                "p-3 rounded-2xl border text-left flex items-center gap-2.5 transition-all active:scale-95 cursor-pointer",
                theme === 'dark' ? "bg-slate-900/80 border-slate-800 hover:border-sky-500/50" : "bg-slate-50 border-slate-200 hover:border-sky-400"
              )}
            >
              <div className="p-2 rounded-xl bg-sky-600 text-white shadow-md shadow-sky-600/30">
                <LayoutDashboard size={16} />
              </div>
              <div>
                <div className="text-xs font-black">Dashboard</div>
                <div className="text-[10px] text-slate-400">Learning analytics</div>
              </div>
            </button>
          </div>

          {/* Quick System Action Toggles */}
          <div className="space-y-1.5 mb-4">
            <div className="px-1 text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Preferences & Audio</div>
            
            {/* Theme Toggle Button */}
            <div className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-900/50 border border-slate-800/80">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
                {themeMode === 'light' ? <Sun size={14} className="text-yellow-400" /> : themeMode === 'dark' ? <Moon size={14} className="text-indigo-400" /> : <Monitor size={14} className="text-slate-400" />}
                Theme: <span className="uppercase text-indigo-400">{themeMode || 'auto'}</span>
              </span>
              <div className="flex gap-1">
                {(['light', 'dark', 'auto'] as const).map(m => (
                  <button
                    key={m}
                    onClick={() => {
                      triggerHapticFeedback(8);
                      onToggleTheme(m);
                    }}
                    className={cn(
                      "px-2.5 py-1 rounded-xl text-[11px] font-bold uppercase transition-all",
                      themeMode === m ? "bg-indigo-600 text-white shadow-sm" : "bg-slate-800/80 text-slate-400"
                    )}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Mute Button */}
            <button
              onClick={() => {
                triggerHapticFeedback(10);
                window.dispatchEvent(new CustomEvent('omni-audio-stop'));
                showNotification?.('All ongoing speech muted', 'info');
              }}
              className="w-full p-2.5 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-between text-xs font-bold active:scale-98 transition-all"
            >
              <div className="flex items-center gap-2">
                <VolumeX size={16} />
                <span>Mute All Audio / Speech</span>
              </div>
              <span className="text-[10px] opacity-70">Tap to Stop</span>
            </button>

            {/* QR Code */}
            <button
              onClick={() => {
                setMobileQuickMenuOpen(false);
                handleOpenShareModal();
              }}
              className="w-full p-2.5 rounded-2xl bg-slate-900/50 border border-slate-800/80 text-slate-300 flex items-center justify-between text-xs font-bold active:scale-98 transition-all"
            >
              <div className="flex items-center gap-2">
                <QrCode size={16} className="text-indigo-400" />
                <span>Show QR Code & Share</span>
              </div>
              <span className="text-[10px] text-slate-400">Share Link</span>
            </button>

            {/* Settings (Mobile) - Visible on Maker's device */}
            {isMaker && (
            <button
              onClick={() => {
                triggerHapticFeedback(8);
                setMobileQuickMenuOpen(false);
                onOpenTool('settings');
              }}
              className="w-full p-2.5 rounded-2xl bg-slate-900/50 border border-slate-800/80 text-slate-300 flex items-center justify-between text-xs font-bold active:scale-98 transition-all"
            >
              <div className="flex items-center gap-2">
                <Settings size={16} className="text-indigo-400" />
                <span>AI & System Settings</span>
              </div>
              <span className="text-[10px] text-slate-400">Configure</span>
            </button>
            )}

            {/* Clear Chat */}
            <button
              onClick={() => {
                triggerHapticFeedback(10);
                setMobileQuickMenuOpen(false);
                setShowConfirmClear(true);
              }}
              className="w-full p-2.5 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-between text-xs font-bold active:scale-98 transition-all"
            >
              <div className="flex items-center gap-2">
                <Trash2 size={16} />
                <span>Clear Chat History</span>
              </div>
              <span className="text-[10px] opacity-70">Reset</span>
            </button>
          </div>

          {/* User Account / Auth Section on Mobile */}
          <div className="pt-2 border-t border-slate-800/40">
            {firebaseUser ? (
              <div className="flex items-center justify-between p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
                <div className="flex items-center gap-2.5">
                  {firebaseUser.photoURL ? (
                    <img src={firebaseUser.photoURL} alt="Profile" className="w-8 h-8 rounded-full border border-indigo-500" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-indigo-600/20 flex items-center justify-center text-indigo-400">
                      <User size={14} />
                    </div>
                  )}
                  <div>
                    <div className="text-xs font-bold text-white">{firebaseUser.displayName || 'Learner'}</div>
                    <div className="text-[10px] text-emerald-400">Signed In</div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    handleLogout();
                    setMobileQuickMenuOpen(false);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-bold flex items-center gap-1"
                >
                  <LogOut size={12} />
                  <span>Logout</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  handleLogin();
                  setMobileQuickMenuOpen(false);
                }}
                className="w-full py-3 rounded-2xl bg-indigo-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 active:scale-98"
              >
                <LogIn size={16} />
                <span>Sign In with Google</span>
              </button>
            )}
          </div>
        </div>
      </>
    )}

    {showQR && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 sm:p-6 animate-in fade-in duration-200">
          <div className={cn(
            "p-6 rounded-2xl flex flex-col items-center gap-4 shadow-2xl max-w-md w-full border",
            theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
          )}>
            <div className="flex justify-between w-full items-center">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-500">
                  <Share2 size={18} />
                </div>
                <h2 className="text-lg font-bold">Share to Any Device</h2>
              </div>
              <button onClick={() => setShowQR(false)} className="p-1.5 rounded-full hover:bg-slate-500/20 transition">
                <X size={20} />
              </button>
            </div>
            
            <p className="text-xs text-slate-400 text-center">
              Scan this QR code with any phone/tablet camera, or copy the link below. Works anywhere without localhost errors.
            </p>

            <div className="p-4 bg-white rounded-xl shadow-inner border border-slate-100 flex flex-col items-center">
              <QRCodeCanvas id="share-qr-canvas" value={shareUrl} size={190} />
            </div>

            <div className="w-full bg-slate-500/10 rounded-lg p-2.5 flex items-center justify-between gap-2 border border-slate-500/20 text-xs">
              <span className="truncate select-all font-mono opacity-80" title={shareUrl}>
                {shareUrl}
              </span>
              <button
                onClick={handleCopyShareLink}
                className={cn(
                  "shrink-0 px-2.5 py-1 text-white rounded font-medium transition cursor-pointer flex items-center gap-1",
                  isShareCopied ? "bg-emerald-600 hover:bg-emerald-500" : "bg-indigo-600 hover:bg-indigo-500"
                )}
              >
                <Copy size={12} />
                {isShareCopied ? "Copied!" : "Copy"}
              </button>
            </div>

            <div className="flex gap-3 w-full">
              <button
                onClick={handleDownloadQR}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-500 font-semibold text-sm transition shadow-sm active:scale-98 cursor-pointer"
                title="Download high-res printable QR card"
              >
                <Download size={16} />
                Save QR Card
              </button>
              <button
                onClick={handleCopyShareLink}
                className={cn(
                  "flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-white rounded-xl font-semibold text-sm transition shadow-sm active:scale-98 cursor-pointer",
                  isShareCopied ? "bg-emerald-600 hover:bg-emerald-500" : "bg-slate-700 hover:bg-slate-600"
                )}
                title="Copy share link"
              >
                <Share2 size={16} />
                {isShareCopied ? "Link Copied!" : "Share Link"}
              </button>
            </div>
            <p className="text-xs text-slate-500 text-center">Ready for phones, tablets, Google Classroom, & Canvas</p>
          </div>
        </div>
      )}

    {showConfirmClear && (
      <div className="fixed inset-0 z-[250] flex items-center justify-center bg-black/60 backdrop-blur-sm p-6 animate-in fade-in duration-200">
        <div className={cn(
          "p-6 rounded-2xl flex flex-col gap-4 shadow-2xl max-w-sm w-full border animate-in zoom-in-95 duration-200",
          theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
        )}>
          <div className="flex items-center gap-3 text-rose-500">
            <div className="w-10 h-10 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-500">
              <Trash2 size={20} />
            </div>
            <h3 className="text-base font-black uppercase tracking-wider">Clear Chat?</h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-semibold">
            Are you absolutely sure you want to clear your chat history? This action is irreversible and your progress for the current session will be reset.
          </p>
          <div className="flex gap-3 justify-end pt-2">
            <button
              type="button"
              onClick={() => setShowConfirmClear(false)}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer active:scale-95",
                theme === 'dark' ? "bg-slate-800 hover:bg-slate-750 text-slate-300" : "bg-slate-100 hover:bg-slate-200 text-slate-700"
              )}
            >
              Cancel, Keep
            </button>
            <button
              type="button"
              onClick={() => {
                onClearChat();
                setShowConfirmClear(false);
                showNotification?.("Chat history cleared.", "success");
              }}
              className="px-4 py-2 rounded-xl text-xs font-black bg-rose-600 hover:bg-rose-500 text-white transition cursor-pointer active:scale-95 shadow-lg shadow-rose-600/20"
            >
              Yes, Clear Chat
            </button>
          </div>
        </div>
      </div>
    )}
    </>
  );
};
