import React, { useState } from 'react';
import {
  X,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Download,
  Copy,
  Check,
  Sparkles,
  Volume2,
  VolumeX,
  ShieldCheck,
  Layers,
  Info,
  Image as ImageIcon,
  Code
} from 'lucide-react';
import { AiDrawResult } from '../services/virtual3dBackendService';

interface AiDrawStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  drawing: AiDrawResult | null;
  isLoading?: boolean;
  onRegenerate?: () => void;
  topicTitle?: string;
  onExplainFigure?: (res: AiDrawResult | any) => void;
  onSpeak?: (text: string) => void;
  isSpeaking?: boolean;
  onStopSpeaking?: () => void;
}

export const AiDrawStudioModal: React.FC<AiDrawStudioModalProps> = ({
  isOpen,
  onClose,
  drawing,
  isLoading = false,
  onRegenerate,
  topicTitle = 'Curriculum Figure',
  onSpeak,
  isSpeaking = false,
  onStopSpeaking
}) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [copied, setCopied] = useState(false);
  const [activeElementId, setActiveElementId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'svg' | 'nanobanana'>('nanobanana');

  if (!isOpen) return null;

  const handleCopySvg = () => {
    if (!drawing?.svg) return;
    navigator.clipboard.writeText(drawing.svg);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSvg = () => {
    if (!drawing?.svg) return;
    const blob = new Blob([drawing.svg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${(drawing.title || 'figure').toLowerCase().replace(/\s+/g, '_')}_diagram.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadImage = () => {
    if (!drawing?.imageUrl) return;
    const link = document.createElement('a');
    link.href = drawing.imageUrl;
    link.download = `${(drawing.title || 'figure').toLowerCase().replace(/\s+/g, '_')}_nanobanana2.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePlayVoice = () => {
    if (isSpeaking && onStopSpeaking) {
      onStopSpeaking();
      return;
    }
    if (!drawing || !onSpeak) return;
    const voiceScript = `Let us examine this dynamic figure for ${drawing.title} generated with Nano Banana 2. ${drawing.caption}. ${
      drawing.elements.map(e => `Part ${e.id}: ${e.label}, ${e.description}.`).join(' ')
    }`;
    onSpeak(voiceScript);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-5xl bg-slate-900 border border-cyan-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950/80 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-100">
                  AI Figure &amp; Diagram Studio
                </h3>
                <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  Nano Banana 2 Engine
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {drawing?.title || topicTitle} • Professor Clarity Dynamic Visual Anchor
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Toggle */}
            {drawing?.imageUrl && (
              <div className="flex items-center bg-slate-800/80 p-0.5 rounded-lg border border-slate-700 mr-1">
                <button
                  onClick={() => setActiveTab('nanobanana')}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 transition-all ${
                    activeTab === 'nanobanana'
                      ? 'bg-cyan-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="View Nano Banana 2 High-Definition Figure"
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Nano Banana 2 HD</span>
                </button>
                <button
                  onClick={() => setActiveTab('svg')}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 transition-all ${
                    activeTab === 'svg'
                      ? 'bg-cyan-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="View Interactive Vector SVG Schematic"
                >
                  <Code className="w-3.5 h-3.5" />
                  <span>Vector SVG</span>
                </button>
              </div>
            )}

            {onSpeak && (
              <button
                onClick={handlePlayVoice}
                className={`p-2 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition-all ${
                  isSpeaking
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                }`}
                title={isSpeaking ? 'Stop Professor Voice' : 'Explain Diagram with Professor Voice'}
              >
                {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
                <span>{isSpeaking ? 'Stop Voice' : 'Explain Aloud'}</span>
              </button>
            )}

            {activeTab === 'svg' ? (
              <>
                <button
                  onClick={handleCopySvg}
                  disabled={!drawing?.svg}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-all"
                  title="Copy SVG XML code"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-400" />}
                  <span>{copied ? 'Copied!' : 'Copy SVG'}</span>
                </button>

                <button
                  onClick={handleDownloadSvg}
                  disabled={!drawing?.svg}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-all"
                  title="Download vector graphic"
                >
                  <Download className="w-4 h-4 text-cyan-400" />
                  <span>Download SVG</span>
                </button>
              </>
            ) : (
              <button
                onClick={handleDownloadImage}
                disabled={!drawing?.imageUrl}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-all"
                title="Download Nano Banana 2 Figure"
              >
                <Download className="w-4 h-4 text-cyan-400" />
                <span>Download Figure</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-2"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Studio Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
              <div className="relative">
                <div className="w-16 h-16 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                <Sparkles className="w-6 h-6 text-cyan-400 absolute inset-0 m-auto animate-pulse" />
              </div>
              <div>
                <h4 className="text-base font-semibold text-slate-200">
                  Synthesizing Figure via Nano Banana 2...
                </h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  Executing Nano Banana 2 visual engine with semantic color coding, flow balance, and textbook clarity.
                </p>
              </div>
            </div>
          ) : (drawing?.svg || drawing?.imageUrl) ? (
            <div className="space-y-6">
              {/* Canvas Area with Zoom Controls */}
              <div className="relative rounded-xl bg-slate-950 border border-slate-800 overflow-hidden shadow-inner flex flex-col items-center">
                {/* Floating Zoom Toolbar */}
                <div className="absolute top-3 right-3 z-10 flex items-center gap-1 bg-slate-900/90 border border-slate-700/80 rounded-lg p-1 backdrop-blur-sm shadow-md">
                  <button
                    onClick={() => setZoomLevel(prev => Math.max(0.6, prev - 0.15))}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <span className="text-[11px] font-mono font-medium text-cyan-400 px-2 min-w-[48px] text-center">
                    {Math.round(zoomLevel * 100)}%
                  </span>
                  <button
                    onClick={() => setZoomLevel(prev => Math.min(2.0, prev + 0.15))}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setZoomLevel(1)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors ml-0.5"
                    title="Reset Zoom"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Render Container: Nano Banana 2 HD Figure or Vector SVG */}
                {activeTab === 'nanobanana' && drawing.imageUrl ? (
                  <div 
                    className="w-full flex items-center justify-center p-6 overflow-auto transition-transform duration-150 min-h-[360px]"
                    style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center center' }}
                  >
                    <img 
                      src={drawing.imageUrl} 
                      alt={drawing.title || 'Nano Banana 2 Scientific Figure'}
                      className="max-h-[460px] w-auto rounded-xl object-contain shadow-2xl border border-slate-800"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                ) : (
                  <div 
                    className="w-full flex items-center justify-center p-6 overflow-auto transition-transform duration-150 min-h-[360px]"
                    style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center center' }}
                    dangerouslySetInnerHTML={{ __html: drawing.svg || '<p class="text-slate-400">Vector SVG not loaded</p>' }}
                  />
                )}
              </div>

              {/* Pedagogical Caption & Scientific Analysis */}
              <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-4 flex items-start gap-3.5">
                <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 shrink-0 mt-0.5">
                  <Info className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                      Scientific Caption &amp; Pedagogy Note
                    </h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      Nano Banana 2 Active
                    </span>
                  </div>
                  <p className="text-sm text-slate-200 leading-relaxed">
                    {drawing.caption}
                  </p>
                  {drawing.pedagogyNotes && (
                    <p className="text-xs text-slate-400 italic">
                      {drawing.pedagogyNotes}
                    </p>
                  )}
                </div>
              </div>

              {/* Elements Breakdown List */}
              {drawing.elements && drawing.elements.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-cyan-400" />
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      Diagram Semantic Components ({drawing.elements.length})
                    </h4>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    {drawing.elements.map((el) => (
                      <div
                        key={el.id}
                        onMouseEnter={() => setActiveElementId(el.id)}
                        onMouseLeave={() => setActiveElementId(null)}
                        className={`p-3 rounded-xl border transition-all cursor-pointer ${
                          activeElementId === el.id
                            ? 'bg-slate-800 border-cyan-400 shadow-md ring-1 ring-cyan-400/40'
                            : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1.5">
                          <span 
                            className="w-3 h-3 rounded-full shrink-0 shadow-sm"
                            style={{ backgroundColor: el.color }}
                          />
                          <span className="text-xs font-bold text-slate-100">
                            ({el.id}) {el.label}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 line-clamp-2">
                          {el.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="py-12 text-center text-slate-400 space-y-3">
              <p>No visual illustration loaded yet.</p>
              {onRegenerate && (
                <button
                  onClick={onRegenerate}
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs rounded-xl shadow transition-colors"
                >
                  Generate Nano Banana 2 Figure
                </button>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 bg-slate-950/90 border-t border-slate-800 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Nano Banana 2 Figure &amp; Diagram Engine Connected • High-Resolution Render</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors font-medium"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

