// ai-tutor/AIService.ts
import { generateAIResponse } from '@/src/lib/gemini';

export interface AIServiceOptions {
  model?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface AIGeneratedResult {
  text: string;
  model: string;
  tokensUsed: number;
  latencyMs: number;
}

export class AIService {
  async generate(prompt: string, options: AIServiceOptions = {}): Promise<AIGeneratedResult> {
    const startTime = Date.now();
    const model = options.model || 'gemini-3.8-flash';
    const temperature = options.temperature ?? 0.3;

    let lastError: any = null;
    const maxRetries = 3;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const rawText = await generateAIResponse(prompt, {
          model,
          responseMimeType: 'application/json',
        });

        const latencyMs = Date.now() - startTime;
        // Estimate token count (~4 chars per token)
        const estimatedTokens = Math.round((prompt.length + (rawText || '').length) / 4);

        return {
          text: rawText || '',
          model,
          tokensUsed: estimatedTokens,
          latencyMs,
        };
      } catch (err: any) {
        lastError = err;
        console.warn(`[AIService] Generation attempt ${attempt} failed:`, err?.message || err);
        if (attempt < maxRetries) {
          await new Promise((resolve) => setTimeout(resolve, attempt * 500));
        }
      }
    }

    throw new Error(`AIService failed after ${maxRetries} attempts: ${lastError?.message || 'Unknown error'}`);
  }
}
