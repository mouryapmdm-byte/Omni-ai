const fs = require('fs');
const file = 'src/components/Chat.tsx';
let content = fs.readFileSync(file, 'utf8');

// Ensure MathGraph is imported
if (!content.includes('import { MathGraph }')) {
    content = content.replace('import { NewtonRaphsonGraph } from "./NewtonRaphsonGraph";', 
    'import { NewtonRaphsonGraph } from "./NewtonRaphsonGraph";\nimport { MathGraph } from "./MathGraph";');
}

// Find the image rendering block for regular messages (line ~5732)
const targetBlock1 = `{msg.metadata?.image && (
                      <div className={cn(
                        "space-y-3",
                        activeAnchor === 'bottom' ? "order-3 mt-4 mb-2" : activeAnchor === 'middle' ? "order-2 my-4" : "order-1 mb-4"
                      )}>`;
                      
const replacementBlock1 = `{msg.metadata?.mathGraphFunctions && (
                      <div className={cn("space-y-3", activeAnchor === 'bottom' ? "order-3 mt-4 mb-2" : activeAnchor === 'middle' ? "order-2 my-4" : "order-1 mb-4")}>
                        <MathGraph functions={msg.metadata.mathGraphFunctions} theme={theme} />
                      </div>
                    )}
                    {msg.metadata?.image && (
                      <div className={cn(
                        "space-y-3",
                        activeAnchor === 'bottom' ? "order-3 mt-4 mb-2" : activeAnchor === 'middle' ? "order-2 my-4" : "order-1 mb-4"
                      )}>`;

// Find the image rendering block for maximized messages (line ~8062)
const targetBlock2 = `{msg.metadata?.image && (
                      <div className="mb-3.5 rounded-2xl overflow-hidden max-w-sm border border-slate-200/20 shadow-md">
                        <img `;

const replacementBlock2 = `{msg.metadata?.mathGraphFunctions && (
                      <MathGraph functions={msg.metadata.mathGraphFunctions} theme={theme} />
                    )}
                    {msg.metadata?.image && (
                      <div className="mb-3.5 rounded-2xl overflow-hidden max-w-sm border border-slate-200/20 shadow-md">
                        <img `;

content = content.replace(targetBlock1, replacementBlock1);
content = content.replace(targetBlock2, replacementBlock2);

fs.writeFileSync(file, content);
console.log("Patched Chat.tsx rendering");
