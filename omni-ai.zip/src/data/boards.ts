import { PHYSICS_ICSE_LESSONS, CHEMISTRY_ICSE_LESSONS, CHEMISTRY_CBSE_LESSONS, MATHEMATICS_ICSE_LESSONS, MATHEMATICS_CBSE_LESSONS, PHYSICS_CBSE_LESSONS, MATHEMATICS_ICSE_CLASS9_LESSONS, MATHEMATICS_ICSE_CLASS10_LESSONS, MATHEMATICS_ICSE_CLASS11_LESSONS, PHYSICS_ICSE_CLASS9_LESSONS, PHYSICS_ICSE_CLASS11_LESSONS, CHEMISTRY_ICSE_CLASS9_LESSONS, CHEMISTRY_ICSE_CLASS11_LESSONS, BIOLOGY_ICSE_CLASS9_LESSONS, BIOLOGY_ICSE_CLASS11_LESSONS, COMPUTER_SCIENCE_ICSE_CLASS9_LESSONS, COMPUTER_SCIENCE_ICSE_CLASS11_LESSONS, SOCIAL_SCIENCE_ICSE_CLASS9_LESSONS, HISTORY_CIVICS_ICSE_CLASS9_LESSONS, HISTORY_ICSE_CLASS11_LESSONS, GEOGRAPHY_ICSE_CLASS9_LESSONS, GEOGRAPHY_ICSE_CLASS11_LESSONS, POLITICAL_SCIENCE_ICSE_CLASS11_LESSONS, SOCIOLOGY_ICSE_CLASS11_LESSONS, PSYCHOLOGY_ICSE_CLASS11_LESSONS, ECONOMICS_ICSE_CLASS11_LESSONS } from '../lib/constants';
import cbseClass10Curriculum from './cbse_class10_curriculum.json';
import cbseClass9Curriculum from './cbse_class9_curriculum.json';

export interface EducationBoard {
  acronym: string;
  name: string;
  type: 'national' | 'state' | 'international' | 'university' | 'technical-university';
  nation: string;
  jurisdiction: string;
  description: string;
  curriculumFocus: string;
  keyFeatures: string[];
  classesCovered: string;
}

export const EDUCATION_BOARDS: EducationBoard[] = [
  // --- INDIA ---
  {
    acronym: "CBSE",
    name: "Central Board of Secondary Education",
    type: "national",
    nation: "India",
    jurisdiction: "All India / National",
    description: "The primary national education board of India for public and private schools, controlled and managed by the Government of India. It uses the nationwide NCERT syllabus.",
    curriculumFocus: "Science & Mathematics focus with high emphasis on national competitive entrance exams like JEE and NEET.",
    keyFeatures: [
      "Standardized national syllabus",
      "Syllabus aligned with national level competitive exams",
      "Strong emphasis on skill development & active learning methodology",
      "Socio-cultural and scientific competency building"
    ],
    classesCovered: "Class 1 to 12"
  },
  {
    acronym: "CISCE / ICSE",
    name: "Council for the Indian School Certificate Examinations",
    type: "national",
    nation: "India",
    jurisdiction: "All India / National",
    description: "A prestigious, private national-level board of school education in India known for its extensive and detailed curriculum, culminating in Class 10 (ICSE) and Class 12 (ISC) examinations.",
    curriculumFocus: "Comprehensive language arts (English), humanities, science, and practical applications aiming for global standards.",
    keyFeatures: [
      "Rigorous and highly detailed comprehensive syllabus",
      "Very high emphasis on English language proficiency and literature",
      "Equal recognition of science, commerce, and humanities streams",
      "Excellent preparation for international higher education"
    ],
    classesCovered: "Class 1 to 12"
  },
  {
    acronym: "MSBSHSE",
    name: "Maharashtra State Board of Secondary and Higher Secondary Education",
    type: "state",
    nation: "India",
    jurisdiction: "Maharashtra State Government",
    description: "The state board of Maharashtra, conducting SSC (Class 10) and HSC (Class 12) examinations across one of India's most populous states.",
    curriculumFocus: "Balanced state interest, regional language development (Marathi), and structured core subjects.",
    keyFeatures: [
      "Affordable quality state educational framework",
      "Special emphasis on Marathi and state cultural history",
      "Gradual alignment with NCERT standards for science topics"
    ],
    classesCovered: "Class 1 to 12"
  },
  {
    acronym: "UPMSP",
    name: "Uttar Pradesh Madhyamik Shiksha Parishad",
    type: "state",
    nation: "India",
    jurisdiction: "Uttar Pradesh State Government",
    description: "World's largest school board in terms of active students registered, conducting examinations for millions in Uttar Pradesh.",
    curriculumFocus: "Linguistic competency, mathematical proficiency and comprehensive humanities.",
    keyFeatures: [
      "Extremely vast network of state-recognized institutions",
      "Curriculum newly aligned with standard modern NCERT guidelines",
      "Strong cultural focus along with rigorous quantitative methods"
    ],
    classesCovered: "Class 1 to 12"
  },
  {
    acronym: "WBBSE / WBCHSE",
    name: "West Bengal Board of Secondary & Higher Secondary Education",
    type: "state",
    nation: "India",
    jurisdiction: "West Bengal State Government",
    description: "The official state board of West Bengal, known for producing deep analytical learning tracks with excellent humanities and vernacular literature programs.",
    curriculumFocus: "Deep literary heritage (Bengali/English), logical/mathematical training and robust physical sciences.",
    keyFeatures: [
      "Strong historical foundation since colonial-era educational reforms",
      "Distinct emphasis on literature, critical thinking, and social history",
      "Wide choice of elective vernacular and modern science subjects"
    ],
    classesCovered: "Class 1 to 12"
  },
  {
    acronym: "BSEB",
    name: "Bihar School Examination Board",
    type: "state",
    nation: "India",
    jurisdiction: "Bihar State Government",
    description: "Conducts secondary and senior secondary school examinations across Bihar with a highly structured syllabus designed to empower local rural and urban students.",
    curriculumFocus: "General knowledge foundation, fundamental mathematics, and state vernacular languages.",
    keyFeatures: [
      "Large-scale state centralized examinations",
      "Affordable study structures aligned with modern public exams",
      "Growing initiatives to digitize academic validation and resources"
    ],
    classesCovered: "Class 1 to 12"
  },
  {
    acronym: "APSBSE",
    name: "Andhra Pradesh Board of Secondary Education",
    type: "state",
    nation: "India",
    jurisdiction: "Andhra Pradesh State Government",
    description: "Highly rigorous state education system of Andhra Pradesh, famous for its mathematically strong student body and competitive local structures.",
    curriculumFocus: "High-level quantitative skills, IT integration, and Telugu language pride.",
    keyFeatures: [
      "Pioneering technical and mathematical course standards",
      "Early introduction to digital skills and technological frameworks",
      "Extremely robust practice-sheet models and assessment tests"
    ],
    classesCovered: "Class 1 to 12"
  },
  {
    acronym: "TNSBSE",
    name: "Tamil Nadu State Board of School Examination",
    type: "state",
    nation: "India",
    jurisdiction: "Tamil Nadu State Government",
    description: "The state board of Tamil Nadu, famous for its comprehensive Samacheer Kalvi (unified) system designed to ensure visual parity and educational equality across all sectors.",
    curriculumFocus: "Equal weightage to languages, pure sciences, analytical math and cultural focus on Tamil legacy.",
    keyFeatures: [
      "Samacheer Kalvi (Unified School Education System)",
      "Highly innovative textbooks with QR-code links and visual graphics",
      "Progressive social equity driven curricula"
    ],
    classesCovered: "Class 1 to 12"
  },
  {
    acronym: "NIOS",
    name: "National Institute of Open Schooling",
    type: "national",
    nation: "India",
    jurisdiction: "All India / National",
    description: "An elegant initiative of the Ministry of Education, Government of India, to provide flexible distance learning models to diverse individuals.",
    curriculumFocus: "Flexible, vocational, and customized academic combinations.",
    keyFeatures: [
      "Self-paced learning structure perfect for nontraditional learners",
      "Extensive list of vocational and academic options",
      "On-demand examinations giving complete flexibility to participants"
    ],
    classesCovered: "Class 1 to 12"
  },

  // --- UNITED STATES ---
  {
    acronym: "CCSS",
    name: "Common Core State Standards",
    type: "state",
    nation: "United States (America)",
    jurisdiction: "State-by-State Adoption (41 States)",
    description: "A set of high-quality, national educational standards in mathematics and English language arts/literacy (ELA). It outlines what a student should know and be able to do at the end of each grade.",
    curriculumFocus: "Critical-thinking, problem-solving, and analytical skills in English language arts and Mathematics.",
    keyFeatures: [
      "Consistent learning goals across participating US states",
      "Preparation for modern universities and dynamic global workplaces",
      "Evidence-based tracking of early literacy and numerical skills"
    ],
    classesCovered: "Kindergarten to Grade 12"
  },
  {
    acronym: "AP / College Board",
    name: "Advanced Placement (College Board)",
    type: "national",
    nation: "United States (America)",
    jurisdiction: "National / College Board Consortium",
    description: "A prestigious program offering college-level curricula and examinations to high school students, highly recognized by US universities for granting credit and advanced placement.",
    curriculumFocus: "In-depth undergraduate level study across sciences, mathematics, history, and languages.",
    keyFeatures: [
      "Rigorous coursework designed by college faculties",
      "Standardized national AP exam scoring system (1 to 5 scale)",
      "Empowers college credentials early during high school enrollment"
    ],
    classesCovered: "Grade 9 to Grade 12"
  },
  {
    acronym: "TEKS",
    name: "Texas Essential Knowledge and Skills (Texas Education Agency)",
    type: "state",
    nation: "United States (America)",
    jurisdiction: "Texas State Government",
    description: "The state curriculum standard for all public schools in Texas, setting highly detailed academic standards for students.",
    curriculumFocus: "Comprehensive grade-specific objectives with robust emphasis on math and career readiness.",
    keyFeatures: [
      "Independently designed Texas state standardized tests (STAAR)",
      "Strict state-level accountability and high performance goals",
      "Very extensive career and technical education (CTE) pathways"
    ],
    classesCovered: "Kindergarten to Grade 12"
  },
  {
    acronym: "NYSED / Regents",
    name: "New York State Education Department (Regents Standards)",
    type: "state",
    nation: "United States (America)",
    jurisdiction: "New York State Government",
    description: "Standardized state-level examinations in core high school subjects, required for students to receive a high school diploma in New York State.",
    curriculumFocus: "Comprehensive and structured baseline in history, mathematics, science, and English.",
    keyFeatures: [
      "Historical Regents exams dating back to the 19th century",
      "Differentiated 'Regents' and 'Advanced Regents' diploma awards",
      "Statewide consistency and rigorous scoring matrices"
    ],
    classesCovered: "Grade 9 to Grade 12"
  },

  // --- UNITED KINGDOM ---
  {
    acronym: "GCSE / AQA",
    name: "Assessment and Qualifications Alliance (AQA)",
    type: "national",
    nation: "United Kingdom",
    jurisdiction: "England, Wales & Northern Ireland",
    description: "The UK's largest exam board, administering GCSEs and A-Levels taken by English high school students under the national curriculum.",
    curriculumFocus: "Rigorous academic subjects, heavy application of principles and analytical essay writing.",
    keyFeatures: [
      "Leading research-backed educational assessment design",
      "Structured A-Level courses serving university entry criteria",
      "Wide choice of vocational and general academic disciplines"
    ],
    classesCovered: "Key Stage 3 to Key Stage 5 (A-Levels)"
  },
  {
    acronym: "Edexcel / Pearson",
    name: "Pearson Edexcel Examinations Bureau",
    type: "national",
    nation: "United Kingdom",
    jurisdiction: "England / Global Network",
    description: "A prominent multinational education and exam board under Pearson, delivering both local GCSEs/A-Levels and International versions globally.",
    curriculumFocus: "Practical and business-applicable competencies alongside science and humanities.",
    keyFeatures: [
      "Extensive global footprint in international schools and academies",
      "Comprehensive digital assessment portals and tools",
      "Pioneering coursework modules combined with standardized final exams"
    ],
    classesCovered: "Primary down to International A-Levels"
  },

  // --- AUSTRALIA ---
  {
    acronym: "VCAA",
    name: "Victorian Curriculum and Assessment Authority",
    type: "state",
    nation: "Australia",
    jurisdiction: "Victoria State Government",
    description: "Manages the curriculum and conducts the VCE (Victorian Certificate of Education) examinations for students in Victoria.",
    curriculumFocus: "Aesthetic, physical, and cognitive development paired with deep subject mastery.",
    keyFeatures: [
      "VCE (Victorian Certificate of Education) qualification framework",
      "Staged internal assessments alongside final external examinations",
      "Highly regarded globally for research science standards"
    ],
    classesCovered: "Prep to Year 12"
  },
  {
    acronym: "NESA",
    name: "New South Wales Education Standards Authority",
    type: "state",
    nation: "Australia",
    jurisdiction: "New South Wales State Government",
    description: "Sets the educational standards and conducts the prestigious Higher School Certificate (HSC) examinations for schools in NSW.",
    curriculumFocus: "Holistic development, literacy, engineering science, and strong moral reasoning.",
    keyFeatures: [
      "Highly respected HSC (Higher School Certificate) credentials",
      "Deep student-led inquiry modules and vocational units",
      "Extensive indigenous cultural history perspectives"
    ],
    classesCovered: "Kindergarten to Year 12"
  },

  // --- CANADA ---
  {
    acronym: "Ontario Curriculum",
    name: "Ontario Ministry of Education Curriculum Board",
    type: "state",
    nation: "Canada",
    jurisdiction: "Ontario Provincial Government",
    description: "The official curriculum framework of Canada's most populous province, focusing on continuous growth, collaboration, and equity.",
    curriculumFocus: "Inclusive education, modern digital literacy, financial literacy, and holistic scientific investigation.",
    keyFeatures: [
      "No single final province-wide high school exit credential exam (uses active teacher assessment and EQAO milestone testing)",
      "High level of integration for student mental wellness and diversity",
      "Strong coding, STEM, and practical household skills embedded in math streams"
    ],
    classesCovered: "Kindergarten to Grade 12"
  },

  // --- GERMANY ---
  {
    acronym: "Abitur / KMK",
    name: "Kultusministerkonferenz (KMK Standing Conference)",
    type: "national",
    nation: "Germany",
    jurisdiction: "Germany National & Federal States",
    description: "Provides the overarching framework for Germany's secondary school leaving certificate (Abitur), qualifying students for university studies across Europe.",
    curriculumFocus: "High analytical depth across multi-subject profiles, including foreign languages, sciences, literature, and social sciences.",
    keyFeatures: [
      "Extremely rigorous oral and written examinations",
      "High focus on independent critical analysis",
      "Broad subject requirements encompassing both humanities and hard sciences"
    ],
    classesCovered: "Grade 11 to Grade 12"
  },

  // --- FRANCE ---
  {
    acronym: "Le Bac",
    name: "Baccalauréat (French Ministry of National Education)",
    type: "national",
    nation: "France",
    jurisdiction: "French Republic & Overseas Territory",
    description: "The comprehensive national academic qualification students obtain at the end of French secondary education to grant university-level entry.",
    curriculumFocus: "Deep philosophical analysis, mathematics, languages, and specialized core divisions.",
    keyFeatures: [
      "Mandatory general philosophy oral and written exams",
      "Extensive argumentative essay requirements",
      "Highly academic and state-centralized assessment standards"
    ],
    classesCovered: "Troisième to Terminale"
  },

  // --- SINGAPORE ---
  {
    acronym: "SEAB",
    name: "Singapore Examinations and Assessment Board (GCE A/O-Levels)",
    type: "national",
    nation: "Singapore",
    jurisdiction: "Republic of Singapore",
    description: "Collaborates with the Ministry of Education and Cambridge to design extremely rigorous local GCE Ordinary and Advanced Level academic curricula.",
    curriculumFocus: "Uncompromised excellence in mathematics, pure sciences, bilingualism, and problem solving.",
    keyFeatures: [
      "Consistently ranked #1 globally in PISA assessments",
      "Advanced mathematical concepts introduced earlier than global baselines",
      "Rigorous multi-stage logical and scientific validation criteria"
    ],
    classesCovered: "Secondary 1 to Pre-University 2"
  },

  // --- JAPAN ---
  {
    acronym: "MEXT",
    name: "Ministry of Education, Culture, Sports, Science and Technology",
    type: "national",
    nation: "Japan",
    jurisdiction: "Japan National Curriculum Standard",
    description: "Sets the national Course of Study specifying precise academic subjects and standards for elementary, junior high, and high schools across Japan.",
    curriculumFocus: "High arithmetic competency, moral education, English mastery, and collaborative societal integration.",
    keyFeatures: [
      "Standardized country-wide textbook guidelines",
      "Rigorous university admission center exams",
      "Balanced physical education, music, ethics, and science integration"
    ],
    classesCovered: "Grade 1 to Grade 12"
  },

  // --- CHINA ---
  {
    acronym: "NEEA (Gaokao)",
    name: "National Education Examinations Authority",
    type: "national",
    nation: "China",
    jurisdiction: "People's Republic of China Board",
    description: "Organizes the highly competitive Gaokao (National College Entrance Examination) and designs standardized public educational parameters.",
    curriculumFocus: "Extremely advanced mathematics, native Chinese literature, and choice between comprehensive sciences or humanities.",
    keyFeatures: [
      "Most populated standardized educational exit test system worldwide",
      "Exceptional emphasis on mental resilience and mathematical logic",
      "Deep classical literary culture requirements"
    ],
    classesCovered: "Primary to Senior High school"
  },

  // --- SOUTH AFRICA ---
  {
    acronym: "Umalusi NSC",
    name: "Council for Quality Assurance in General and Further Education",
    type: "national",
    nation: "South Africa",
    jurisdiction: "Republic of South Africa Government",
    description: "The national body that monitors and verifies the curriculum and ensures standard validity of the National Senior Certificate (NSC) Matric examinations.",
    curriculumFocus: "Multilingual capability, mathematical literacy, and life-skills readiness.",
    keyFeatures: [
      "NSC Matric examinations verifying general senior status",
      "Promotion of early economic literacy and scientific concepts",
      "Vibrant multilingual and diverse social awareness guidelines"
    ],
    classesCovered: "Grade 1 to Grade 12"
  },

  // --- NIGERIA ---
  {
    acronym: "WAEC",
    name: "West African Examinations Council",
    type: "national",
    nation: "Nigeria",
    jurisdiction: "Federal Republic of Nigeria & West African Region",
    description: "The premium exam board administering the West African Senior School Certificate Examination (WASSCE) for high school seniors across Nigeria.",
    curriculumFocus: "Practical sciences, local trade competencies, English literature, and robust mathematical bases.",
    keyFeatures: [
      "Internationally standardized regional education certificate",
      "Comprehensive practical biology, physics, and agricultural requirements",
      "Strong preparation for tertiary university entry exams"
    ],
    classesCovered: "Junior Secondary 1 to Senior Secondary 3"
  },

  // --- PAKISTAN ---
  {
    acronym: "BISE (Federal Board)",
    name: "Board of Intermediate and Secondary Education",
    type: "national",
    nation: "Pakistan",
    jurisdiction: "Federal Capital and Cantonments Jurisdiction",
    description: "The premier board administering intermediate college (HSSC) and matriculation (SSC) programs with high conceptual accuracy and standard syllabus books.",
    curriculumFocus: "Core scientific principles, Islamic/Civic studies, and Urdu/English language fluency.",
    keyFeatures: [
      "Uniform and objective marking methodology",
      "Pre-medical, Pre-engineering, and computer science structural divisions",
      "Thorough coverage of text-book exercises and proofs"
    ],
    classesCovered: "Grade 9 to Grade 12"
  },

  // --- BRAZIL ---
  {
    acronym: "INEP (ENEM)",
    name: "National Institute for Educational Studies and Research",
    type: "national",
    nation: "Brazil",
    jurisdiction: "Federative Republic of Brazil Board",
    description: "Administers ENEM (National High School Exam), one of the largest high school evaluation exams in Latin America, used for direct admittance into federal universities.",
    curriculumFocus: "Interdisciplinary learning, essay writing, nature sciences, human sciences, and mathematics.",
    keyFeatures: [
      "Real-world socio-economic problem essay challenge requirements",
      "Highly modern interdisciplinary diagnostic question framework",
      "Inclusive design tailored to general high school feedback"
    ],
    classesCovered: "Elementary Cycle to High School"
  },

  // --- SOUTH KOREA ---
  {
    acronym: "KICE (Suneung)",
    name: "Korea Institute for Curriculum and Evaluation",
    type: "national",
    nation: "South Korea",
    jurisdiction: "Republic of Korea Education",
    description: "Sets the national school curriculum standards and is responsible for administering the Suneung (College Scholastic Ability Test).",
    curriculumFocus: "Intense mathematical agility, active logical reading comprehension, and Korean/English linguistic perfection.",
    keyFeatures: [
      "World-famous standardized evaluation speed and precision",
      "Strong focus on informational extraction and logic analysis",
      "Systematically structured textbook alignment and research metrics"
    ],
    classesCovered: "Grade 1 to Grade 12"
  },

  // --- SAUDI ARABIA ---
  {
    acronym: "MoE (Qiyas)",
    name: "Ministry of Education & ETEC Qiyas Board",
    type: "national",
    nation: "Saudi Arabia",
    jurisdiction: "Kingdom of Saudi Arabia Government",
    description: "Supervises general and higher education, introducing state-of-the-art technological curricula, while ETEC manages Qiyas cognitive evaluations.",
    curriculumFocus: "Integrated Islamic culture, classical Arabic literacy, modern STEM science, and digital coding.",
    keyFeatures: [
      "Vision 2030 educational transformation with early coding skills",
      "High-quality scientific and analytical resources provided nationally",
      "Qiyas cognitive aptitude assessment alignment"
    ],
    classesCovered: "Elementary to Secondary Grades"
  },

  // --- NEW ZEALAND ---
  {
    acronym: "NZQA (NCEA)",
    name: "New Zealand Qualifications Authority",
    type: "national",
    nation: "New Zealand",
    jurisdiction: "New Zealand Government System",
    description: "Manages the National Certificate of Educational Achievement (NCEA), New Zealand's main qualification for secondary school students.",
    curriculumFocus: "Critical thinking, independent inquiry, physical sciences, and rich Maori culture integration.",
    keyFeatures: [
      "Flexible structure allowing standard credits via internal/external reviews",
      "High customization matching individual careers and pathways",
      "Strong emphasis on experiential environmental learning"
    ],
    classesCovered: "Year 11 to Year 13"
  },

  // --- MEXICO ---
  {
    acronym: "SEP",
    name: "Secretaría de Educación Pública (Secretariat of Public Education)",
    type: "national",
    nation: "Mexico",
    jurisdiction: "Mexican United States Federal Government",
    description: "Defines the mandatory national curriculum for all primary and secondary schools in Mexico, publishing unified national educational guides.",
    curriculumFocus: "Cultural diversity, scientific principles, civic responsibilities, and Spanish fluency.",
    keyFeatures: [
      "Free standardized textbook distribution throughout the federation",
      "Strong scientific reasoning paired with deep historical awareness",
      "Inclusive models serving rural and metropolitan centers"
    ],
    classesCovered: "Primaria to Preparatoria (Grades 1-12)"
  },

  // --- INTERNATIONAL ---
  {
    acronym: "IB",
    name: "International Baccalaureate Organisation",
    type: "international",
    nation: "International / Global",
    jurisdiction: "Worldwide Consortium of Schools",
    description: "Headquartered in Geneva, Switzerland, the IB offers four highly respected global education programs designed to develop multilingual, inquisitive, and caring global citizens.",
    curriculumFocus: "Interdisciplinary learning, critical global citizenship, and independent analytical research.",
    keyFeatures: [
      "Diploma Program (DP) requiring Theory of Knowledge (TOK) and a 4,000-word Extended Essay",
      "Highly respected by top-tier universities worldwide",
      "Requires active community, action, and social service (CAS)"
    ],
    classesCovered: "Primary Years (PYP) through Diploma Program (DP)"
  },
  {
    acronym: "CAIE",
    name: "Cambridge Assessment International Education",
    type: "international",
    nation: "International / United Kingdom",
    jurisdiction: "Worldwide Schools Network",
    description: "Part of the University of Cambridge, CAIE is the world's largest provider of international education programs and qualifications, including IGCSE and Cambridge International AS & A Levels.",
    curriculumFocus: "Subject depth, linguistic precision, practical intelligence, and scientific experimentation.",
    keyFeatures: [
      "Rigorous linear, exam-focused international assessment pathways",
      "Widely taken Cambridge IGCSE qualification representing gold-standard Class 10 assessment",
      "Unparalleled academic recognition across hundreds of years of university heritage"
    ],
    classesCovered: "Cambridge Primary to Cambridge Advanced (A-Levels)"
  },
  // --- UNIVERSITIES & COLLEGES ---
  {
    acronym: "IITs",
    name: "Indian Institutes of Technology (IITs)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "All India (IIT Council)",
    description: "The highest-ranked and most prestigious technical institutions in India, including IIT Madras, IIT Delhi, IIT Bombay, IIT Kharagpur, and IIT Kanpur, renowned globally for elite engineering education and research.",
    curriculumFocus: "Heavy mathematical analytical derivation, high-dimensional data processing, applied chemistry, and system energy analytics.",
    keyFeatures: [
      "Rigorous core research-aligned engineering curriculums",
      "Elite international industrial collaborations and funding",
      "Premier incubation centers and cutting-edge laboratory facilities"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "BITS-PILANI",
    name: "Birla Institute of Technology and Science (BITS Pilani)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Pilani, Rajasthan",
    description: "One of the premier private de-facto technical universities in India, famous for its rigorous curriculum, unique zero-attendance policy, and stellar industry-aligned Practice School internship system.",
    curriculumFocus: "Micro-electronics, data structures and algorithms, chemical process engineering, and financial engineering.",
    keyFeatures: [
      "No reservation system and fully merit-based entrance (BITSAT)",
      "Practice School (PS-I & PS-II) structured industry internship programs",
      "Flexible curriculum structure allowing dual degrees and electives"
    ],
    classesCovered: "B.E. (Hons.), M.Sc., and PhD Research"
  },
  {
    acronym: "NITs",
    name: "National Institutes of Technology (NITs)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "All India (NIT Council)",
    description: "A prestigious group of public technical universities focusing on applied sciences, technology, and engineering, featuring top-tier campuses such as NIT Trichy, NIT Surathkal, and NIT Warangal.",
    curriculumFocus: "Applied thermal engineering, power electronics, structural analysis, VLSI design, and system optimization.",
    keyFeatures: [
      "Highly competitive national selection via JEE Main",
      "Extensive state-of-the-art regional research facilities",
      "Strong placement record and industry-aligned technical curriculum"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "IIITs",
    name: "Indian Institutes of Information Technology (IIITs)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "All India (IIIT Council)",
    description: "Public-private partnership institutions of national importance specializing in computer science, software engineering, and information technology, including IIIT Hyderabad and IIIT Allahabad.",
    curriculumFocus: "Artificial intelligence, computer vision, natural language processing, computer networks, and full-stack software architectures.",
    keyFeatures: [
      "Unmatched focus on coding, computational research, and algorithms",
      "Direct corporate and government joint venture backing",
      "Strong developer culture and open-source contributions"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "DTU",
    name: "Delhi Technological University (DTU)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "New Delhi",
    description: "Formerly known as Delhi College of Engineering (DCE), it is one of India's oldest and most respected engineering public universities with legendary alumni and outstanding corporate placements.",
    curriculumFocus: "Automobile engineering, environmental engineering, software design, polymer science, and industrial engineering.",
    keyFeatures: [
      "Incredible industrial legacy spanning over eight decades",
      "Renowned student-led engineering research groups (e.g., UAV and solar passenger car)",
      "Massive campus with top-tier technical labs"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "JU",
    name: "Jadavpur University (JU)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Kolkata, West Bengal",
    description: "An elite state research university, internationally celebrated for its exceptional engineering, technological innovation, and deep literary research departments.",
    curriculumFocus: "High-performance software and mechanical engineering, fluid mechanics, comparative literature, and analytical physics.",
    keyFeatures: [
      "Top ranked state university in India for engineering & science",
      "Active student research and incubation laboratories",
      "Excellent reputation for social and political humanities research"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "NSUT",
    name: "Netaji Subhas University of Technology (NSUT)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "New Delhi",
    description: "A premier public technical university in Delhi, formerly known as NSIT, celebrated for its rigorous computer science, electronics, and instrumentation engineering programs.",
    curriculumFocus: "Digital signal processing, embedded systems, microprocessors, network security, and machine learning.",
    keyFeatures: [
      "Exceptionally competitive admission criteria and prime Delhi location",
      "Vibrant competitive coding culture and tech incubation cells",
      "Close partnerships with global technology giants"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "ANNA-UNI",
    name: "Anna University",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Chennai, Tamil Nadu",
    description: "A prominent public state university of Tamil Nadu, serving as a global powerhouse of engineering education with world-class constituent colleges like CEG, ACT, and MIT Chennai.",
    curriculumFocus: "Aeronautical engineering, automobile system design, leather technology, biotechnology, and power systems.",
    keyFeatures: [
      "One of the largest technical university affiliations in the world",
      "Deeply rooted research traditions in manufacturing and chemical industries",
      "Houses prestigious historical engineering colleges like College of Engineering, Guindy"
    ],
    classesCovered: "B.E. / B.Tech, M.E. / M.Tech, and PhD Research"
  },
  {
    acronym: "TIET",
    name: "Thapar Institute of Engineering & Technology",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Patiala, Punjab",
    description: "A highly-ranked, premier private technical institution recognized for academic excellence, state-of-the-art infrastructure, and strong research collaborations with international universities like Trinity College Dublin.",
    curriculumFocus: "Materials science, digital communication, structural dynamics, computer science engineering, and bio-medical engineering.",
    keyFeatures: [
      "Global academic synergy with premium international credit transfer models",
      "Exceptional student-led technical clubs and hackathons",
      "Outstanding campus placement rates in multinational engineering firms"
    ],
    classesCovered: "B.E. / B.Tech, M.E. / M.Tech, and PhD Research"
  },
  {
    acronym: "VIT",
    name: "Vellore Institute of Technology (VIT)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Vellore, Tamil Nadu",
    description: "A top-ranked private technical university, celebrated for its innovative Flexible Choice Based Credit System (FFCS), high international standards, and exceptional research output.",
    curriculumFocus: "Cyber-security, information technology, biomedical sensors, nanotechnology, and automotive engineering.",
    keyFeatures: [
      "Highly adaptable Flexible Choice Based Credit System (FFCS)",
      "Strong focus on international research publications and patents",
      "Vast campus with students hailing from over 50 countries"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "MAHE",
    name: "Manipal Institute of Technology (MAHE)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Manipal, Karnataka",
    description: "A premier private technical institution under Manipal Academy of Higher Education, famous for producing legendary tech leaders and offering modern, research-driven engineering education.",
    curriculumFocus: "Mechatronics, aeronautical engineering, media technology, computer science, and microelectronics.",
    keyFeatures: [
      "Pioneering research projects in robotics and autonomous systems",
      "Prestigious global alumni network including top-tier tech executives",
      "Elite student-led Formula student and astronomy clubs"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "SRM",
    name: "SRM Institute of Science and Technology",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Kattankulathur, Tamil Nadu",
    description: "One of the largest private multi-campus universities in India, offering cutting-edge engineering disciplines, space technology programs, and collaborative research with foreign universities.",
    curriculumFocus: "Cloud computing, genetic engineering, nanotechnology, space-craft systems, and artificial intelligence.",
    keyFeatures: [
      "Successfully designed and launched a student satellite (SRMSAT) with ISRO",
      "Extensive semesters-abroad program partnerships with elite institutions",
      "Ultra-modern research and development infrastructure"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "AKTU",
    name: "Dr. A.P.J. Abdul Kalam Technical University (AKTU)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Lucknow, Uttar Pradesh",
    description: "The largest technical affiliate state university in Asia, coordinating technical education, computer applications, and pharmaceutical studies across hundreds of colleges in Uttar Pradesh.",
    curriculumFocus: "Industrial automation, textile technology, thermal design, software engineering, and pharmaceutical sciences.",
    keyFeatures: [
      "Massive network of engineering and technical colleges across Uttar Pradesh",
      "Standardized regional technical syllabi aligned with modern industrial demands",
      "Strong emphasis on incubation of startups in tier-2 and tier-3 cities"
    ],
    classesCovered: "B.Tech, M.Tech, MCA, and PhD"
  },
  {
    acronym: "MAKAUT",
    name: "Maulana Abul Kalam Azad University of Technology (MAKAUT)",
    type: "technical-university",
    nation: "India",
    jurisdiction: "Kolkata, West Bengal",
    description: "Formerly known as West Bengal University of Technology (WBUT), it is the primary state-run technical university coordinating engineering, technology, and management courses across West Bengal.",
    curriculumFocus: "Information technology, industrial biotechnology, marine engineering, and power generation systems.",
    keyFeatures: [
      "Standardized technical curriculum for West Bengal state-affiliated colleges",
      "Pioneering courses in renewable energy and green technology",
      "Focus on skill-based vocational and professional certifications"
    ],
    classesCovered: "B.Tech, M.Tech, and PhD Research"
  },
  {
    acronym: "IISc",
    name: "Indian Institute of Science (IISc)",
    type: "university",
    nation: "India",
    jurisdiction: "Bengaluru, Karnataka",
    description: "The premier research-focused university in India, offering deep theoretical and experimental exploration into advanced physical, mathematical, chemical, and biological sciences.",
    curriculumFocus: "Mathematical rigour, experimental laboratory analysis, and open research problems in modern science.",
    keyFeatures: [
      "Interdisciplinary scientific investigation projects",
      "Direct guidance by leading international researchers",
      "State-of-the-art computational and physics facilities"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "JNU",
    name: "Jawaharlal Nehru University (JNU)",
    type: "university",
    nation: "India",
    jurisdiction: "New Delhi",
    description: "One of India's premier public research universities, famous for its world-class social sciences, international studies, humanities, and basic sciences curricula.",
    curriculumFocus: "Interdisciplinary research, critical thinking, global policy, and theoretical sciences.",
    keyFeatures: [
      "Renowned humanities & social sciences research paradigms",
      "Dynamic school of international studies",
      "Emphasis on democratic debate, critical analysis, and modern research"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "DU",
    name: "University of Delhi (DU)",
    type: "university",
    nation: "India",
    jurisdiction: "New Delhi",
    description: "A premier public central collegiate university, recognized for high scholastic standards across sciences, humanities, and commerce streams.",
    curriculumFocus: "Structured academic syllabus, extensive laboratory training, and diverse arts and humanities pathways.",
    keyFeatures: [
      "Vast and highly competitive undergraduate college ecosystem",
      "Rigorous core curriculum in physical, mathematical, and social sciences",
      "Distinguished alumni network and research hubs"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "BHU",
    name: "Banaras Hindu University (BHU)",
    type: "university",
    nation: "India",
    jurisdiction: "Varanasi, Uttar Pradesh",
    description: "One of the largest residential universities in Asia, famous for integrating traditional Sanskrit and cultural studies with cutting-edge engineering, medicine, and pure sciences.",
    curriculumFocus: "Classical literature, modern medical science, advanced agriculture, and technical engineering.",
    keyFeatures: [
      "Vast majestic residential campus with deep cultural history",
      "Renowned Institute of Technology (IIT-BHU) and Medical Sciences",
      "Strong emphasis on holistic research and national development"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "JMI",
    name: "Jamia Millia Islamia (JMI)",
    type: "university",
    nation: "India",
    jurisdiction: "New Delhi",
    description: "A prestigious central university offering highly ranked professional, engineering, natural science, and humanities education.",
    curriculumFocus: "Applied sciences, communication/media studies, political dynamics, and modern engineering.",
    keyFeatures: [
      "Award-winning media and mass communication research program",
      "Elite engineering, technology, and basic science laboratories",
      "Active international research collaborations"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "UoH",
    name: "University of Hyderabad (UoH)",
    type: "university",
    nation: "India",
    jurisdiction: "Hyderabad, Telangana",
    description: "A premier central research university highly regarded for post-graduate education and elite research output in science, technology, and humanities.",
    curriculumFocus: "Interdisciplinary science streams, high-energy physics, computational linguistics, and biotechnology.",
    keyFeatures: [
      "Consistent NIRF top-ranking university in India",
      "Deeply specialized labs for neuroscience and life sciences",
      "Strong publication records in international journals"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "AMU",
    name: "Aligarh Muslim University (AMU)",
    type: "university",
    nation: "India",
    jurisdiction: "Aligarh, Uttar Pradesh",
    description: "A historic public central university offering a diverse blend of modern scientific disciplines, medicine, law, and classical language research.",
    curriculumFocus: "Advanced materials science, historical research, engineering principles, and comparative linguistics.",
    keyFeatures: [
      "Rich academic heritage and iconic modern scientific labs",
      "Pioneering research in history, agricultural sciences, and law",
      "Strong culture of scholarly publication and global alumni"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "Visva-Bharati",
    name: "Visva-Bharati University",
    type: "university",
    nation: "India",
    jurisdiction: "Santiniketan, West Bengal",
    description: "Founded by Nobel Laureate Rabindranath Tagore, this central university integrates nature-centric education, fine arts, music, humanities, and agricultural sciences.",
    curriculumFocus: "Fine arts, classical Indian music, rural reconstruction, and core world literature.",
    keyFeatures: [
      "Open-air classroom legacy in harmony with nature",
      "World-class school of fine arts (Kala Bhavana) and music (Sangit Bhavana)",
      "Strong roots in cultural preservation and humanities research"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "NEHU",
    name: "North-Eastern Hill University (NEHU)",
    type: "university",
    nation: "India",
    jurisdiction: "Shillong, Meghalaya",
    description: "A key central university in Northeast India, driving high-altitude agricultural studies, indigenous linguistic research, and general sciences.",
    curriculumFocus: "Biodiversity conservation, tribal culture studies, mountain ecology, and standard sciences.",
    keyFeatures: [
      "Pioneering research in mountain and high-altitude ecology",
      "Strong programs in anthropology, regional history, and biotechnology",
      "Dynamic educational hub for northeastern states"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "UGC",
    name: "University Grants Commission (UGC)",
    type: "university",
    nation: "India",
    jurisdiction: "New Delhi",
    description: "The premier statutory body of the Government of India responsible for maintaining standards of university education, defining benchmark national syllabi and credit systems.",
    curriculumFocus: "National Choice Based Credit System (CBCS), benchmark core science, and qualitative research guidelines.",
    keyFeatures: [
      "Standard setter for all Indian state and central universities",
      "Highly structured Choice Based Credit System (CBCS) model",
      "Extensive guidelines for research fellowship and curriculum excellence"
    ],
    classesCovered: "Undergraduate to PhD Standards"
  },
  {
    acronym: "CU",
    name: "University of Calcutta",
    type: "university",
    nation: "India",
    jurisdiction: "Kolkata, West Bengal",
    description: "One of the oldest modern universities in South Asia, historically home to multiple Nobel Laureates and legendary physicists like Satyendra Nath Bose.",
    curriculumFocus: "Theoretical physics, biochemistry, ancient Indian history, and botanical sciences.",
    keyFeatures: [
      "Incredible legacy of producing Nobel laureates and legendary scientists",
      "Rigorous science and mathematics theoretical tracks",
      "Renowned libraries, botanical collections, and archaeological archives"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "MU",
    name: "University of Mumbai",
    type: "university",
    nation: "India",
    jurisdiction: "Mumbai, Maharashtra",
    description: "A premier central-state university of India, offering an expansive and diverse curriculum in financial modeling, information technology, and chemistry.",
    curriculumFocus: "Finance/applied economics, chemical engineering, industrial technology, and law.",
    keyFeatures: [
      "Deep industry connections in the financial capital of India",
      "Distinguished schools of chemical technology and computer science",
      "Expansive affiliated college system with high standards"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "UNIMAD",
    name: "University of Madras",
    type: "university",
    nation: "India",
    jurisdiction: "Chennai, Tamil Nadu",
    description: "A highly prestigious and historic university of South India, famous for producing legendary mathematical geniuses like Srinivasa Ramanujan.",
    curriculumFocus: "Mathematical analysis, theoretical physics, biochemistry, and Dravidian linguistics.",
    keyFeatures: [
      "Historic educational cradle of modern South Indian academia",
      "Elite centers for molecular biology and nuclear physics",
      "Proud association with mathematical genius Srinivasa Ramanujan"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "OU",
    name: "Osmania University",
    type: "university",
    nation: "India",
    jurisdiction: "Hyderabad, Telangana",
    description: "A legendary and massive public university, highly regarded for engineering, technology, chemistry, and socio-economic research.",
    curriculumFocus: "Telecommunication systems, mineralogy, modern pharmaceutical science, and business management.",
    keyFeatures: [
      "Iconic grand administrative and educational heritage architecture",
      "Pioneering research in mining, geology, and pharmacy",
      "Robust state-level collegiate network with strong technical output"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "BU",
    name: "Bangalore University",
    type: "university",
    nation: "India",
    jurisdiction: "Bengaluru, Karnataka",
    description: "Located in India's high-tech capital, Bangalore University offers cutting-edge courses in software engineering, biotechnology, and management sciences.",
    curriculumFocus: "Software development, micro-biology, advanced aerospace mechanics, and corporate finance.",
    keyFeatures: [
      "Positioned in the heart of the Silicon Valley of India",
      "Modern curriculum aligning with IT and biotechnology industry demands",
      "Strong centers for physical science and space research"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "ISI",
    name: "Indian Statistical Institute (ISI)",
    type: "university",
    nation: "India",
    jurisdiction: "Kolkata, Wardha, and Bengaluru",
    description: "A globally renowned institution of national importance dedicated to statistics, mathematics, computer science, and quantitative economics.",
    curriculumFocus: "Theoretical statistics, probability theory, abstract logic, data mining, and econometrics.",
    keyFeatures: [
      "World-class training under the legacy of Prasanta Chandra Mahalanobis",
      "Incredibly competitive elite academic selection process",
      "Global benchmark for statistical research and artificial intelligence foundations"
    ],
    classesCovered: "B.Stat / M.Stat & PhD Research"
  },
  {
    acronym: "TIFR",
    name: "Tata Institute of Fundamental Research (TIFR)",
    type: "university",
    nation: "India",
    jurisdiction: "Mumbai, Maharashtra",
    description: "A premier public research institution and deemed university dedicated to basic research in physics, chemistry, biology, mathematics, and computer science.",
    curriculumFocus: "Theoretical high-energy physics, astrophysics, pure mathematics proofs, and computational neuroscience.",
    keyFeatures: [
      "Elite research laboratories and top-tier computational clusters",
      "Direct academic mentorship with leading international scientists",
      "Pioneering works in cosmic rays, quantum materials, and string theory"
    ],
    classesCovered: "Integrated MSc-PhD & Doctoral Core"
  },
  {
    acronym: "ASHOKA",
    name: "Ashoka University",
    type: "university",
    nation: "India",
    jurisdiction: "Sonipat, Haryana",
    description: "A pioneering private liberal arts university, world-renowned for combining rigorous mathematical/computational disciplines with critical thinking humanities.",
    curriculumFocus: "Critical writing, multi-disciplinary sciences, quantitative economics, and philosophy.",
    keyFeatures: [
      "Premier modern liberal arts education model in India",
      "Distinguished faculty hailing from elite global institutions",
      "Emphasis on analytical writing, civic engagement, and ethical leadership"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "TISS",
    name: "Tata Institute of Social Sciences (TISS)",
    type: "university",
    nation: "India",
    jurisdiction: "Mumbai, Maharashtra",
    description: "A highly respected premier institute of social sciences, renowned for social work, human resources, public health, and developmental economics.",
    curriculumFocus: "Human rights, public health epidemiology, developmental sociology, and organizational behavior.",
    keyFeatures: [
      "Vanguard institution for social research and policy advocacy",
      "Elite postgraduate human resources and labor studies curriculum",
      "Strong field-action research projects for national growth"
    ],
    classesCovered: "Post-Graduate & PhD Research"
  },
  {
    acronym: "MIT",
    name: "Massachusetts Institute of Technology (MIT)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "Cambridge, Massachusetts",
    description: "The world's premier technical university, renowned for pioneering research in artificial intelligence, robotics, quantum computing, and engineering sciences.",
    curriculumFocus: "Advanced numerical computing, multi-agent AI, quantum mechanics, and rigorous research laboratory practices.",
    keyFeatures: [
      "Pioneering artificial intelligence and computer science models",
      "Rigorous mathematical proofing and high-level experimental simulations",
      "World-class innovation ecosystem with unmatched industrial research funding"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "STANFORD",
    name: "Stanford University",
    type: "university",
    nation: "United States (America)",
    jurisdiction: "Stanford, California",
    description: "A world-renowned research university in Silicon Valley, famous for its entrepreneurial culture, top-ranked computer science, engineering, and humanities programs.",
    curriculumFocus: "Machine learning, design thinking, entrepreneurship, statistical modeling, and political science.",
    keyFeatures: [
      "Stellar startup incubation and direct proximity to Silicon Valley giants",
      "Interdisciplinary flexibility across technical and liberal arts programs",
      "Leading research centers in artificial intelligence and energy engineering"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "HARVARD",
    name: "Harvard University",
    type: "university",
    nation: "United States (America)",
    jurisdiction: "Cambridge, Massachusetts",
    description: "The oldest and one of the most prestigious Ivy League universities in the world, combining rigorous academic inquiry with premier leadership in sciences, humanities, and law.",
    curriculumFocus: "Data representation, algorithmic problem solving, secure system architectures, quantum physics, and economics.",
    keyFeatures: [
      "Eminent research faculty including Nobel laureates and world leaders",
      "Vast interdisciplinary curriculum pairing engineering with liberal arts",
      "World-class libraries, archives, and cutting-edge laboratory resources"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "CALTECH",
    name: "California Institute of Technology (Caltech)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "Pasadena, California",
    description: "An elite, highly selective private research university that manages NASA's Jet Propulsion Laboratory, celebrated for its extraordinary intensity in natural sciences and engineering.",
    curriculumFocus: "Quantum physics, astrophysics, chemical engineering, computational mathematics, and molecular biology.",
    keyFeatures: [
      "Extremely low student-to-faculty ratio with highly personalized research mentorship",
      "Manages the world-famous NASA Jet Propulsion Laboratory (JPL)",
      "Deeply rigorous academic culture focusing on fundamental scientific breakthroughs"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "UCB",
    name: "University of California, Berkeley (UC Berkeley)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "Berkeley, California",
    description: "Widely regarded as the world's premier public university, boasting a legendary engineering division that has birthed numerous computer languages, open-source projects, and chemical elements.",
    curriculumFocus: "Distributed computer systems, VLSI design, thermodynamics, organic chemistry, and biotechnology.",
    keyFeatures: [
      "Historic birthplace of UNIX, Berkeley Software Distribution (BSD), and RISC architecture",
      "Unmatched public research engine with over 100 Nobel laureates",
      "Close-knit collaboration with Lawrence Berkeley National Laboratory"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "CMU",
    name: "Carnegie Mellon University (CMU)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "Pittsburgh, Pennsylvania",
    description: "A private research university globally recognized as a powerhouse in computer science, robotics, artificial intelligence, and software engineering.",
    curriculumFocus: "Machine learning, software engineering, cyber-security, human-computer interaction, and robotics system design.",
    keyFeatures: [
      "Home to the world's first university Robotics Institute",
      "Pioneering research in software architecture and cybersecurity (SEI/CERT)",
      "Highly interdisciplinary programs combining technology with fine arts and drama"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "GEORGIA-TECH",
    name: "Georgia Institute of Technology (Georgia Tech)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "Atlanta, Georgia",
    description: "A leading public research university and institute of technology, consistently ranked among the top engineering colleges in the United States.",
    curriculumFocus: "Industrial engineering, biomedical systems, aerospace design, digital signal processing, and cybersecurity.",
    keyFeatures: [
      "Largest industrial engineering program and co-op education model in the US",
      "State-of-the-art research institute (GTRI) solving real-world defense and industrial problems",
      "Pioneering online and on-campus masters programs in computer science and analytics"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "UIUC",
    name: "University of Illinois Urbana-Champaign (UIUC)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "Urbana, Illinois",
    description: "A massive public research university legendary for its computer science, supercomputing, and engineering legacies, contributing to the creation of the modern web browser.",
    curriculumFocus: "Parallel programming, semiconductor physics, structural mechanics, digital hardware systems, and data mining.",
    keyFeatures: [
      "Birthplace of Mosaic, the first popular web browser, and the LLVM compiler infrastructure",
      "Houses the National Center for Supercomputing Applications (NCSA)",
      "Top-tier materials science and civil engineering departments"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "U-MICHIGAN",
    name: "University of Michigan, Ann Arbor",
    type: "university",
    nation: "United States (America)",
    jurisdiction: "Ann Arbor, Michigan",
    description: "One of the top-tier public research universities in the world, renowned for its massive research expenditures and elite engineering, medicine, and social science programs.",
    curriculumFocus: "Automotive engineering, aerospace systems, data science, bioengineering, and industrial operations.",
    keyFeatures: [
      "Consistent leader in national public research funding and patent generation",
      "State-of-the-art Mcity test facility for connected and autonomous vehicle research",
      "Vast, influential global alumni network of over half a million graduates"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "UT-AUSTIN",
    name: "University of Texas at Austin",
    type: "university",
    nation: "United States (America)",
    jurisdiction: "Austin, Texas",
    description: "A major public research university located in the tech hub of Austin, celebrated for its highly ranked Cockrell School of Engineering and computer science programs.",
    curriculumFocus: "Petroleum engineering, software engineering, microelectronics, power grids, and hardware acceleration.",
    keyFeatures: [
      "Direct pipeline to Austin's thriving 'Silicon Hills' technology ecosystem",
      "Top-tier Texas Advanced Computing Center (TACC) housing elite supercomputers",
      "Stellar research in energy systems and nanotechnology"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "U-WASHINGTON",
    name: "University of Washington",
    type: "university",
    nation: "United States (America)",
    jurisdiction: "Seattle, Washington",
    description: "A preeminent public research university located in Seattle, heavily supported by the local tech giants and renowned for its computer science, medicine, and oceanography programs.",
    curriculumFocus: "Cloud computing, computer vision, molecular engineering, marine sciences, and biomedical device design.",
    keyFeatures: [
      "Unmatched tech industry connection to Seattle giants like Microsoft and Amazon",
      "Home to the Paul G. Allen School of Computer Science & Engineering",
      "Leading recipient of federal research funding among US public universities"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "RPI",
    name: "Rensselaer Polytechnic Institute (RPI)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "Troy, New York",
    description: "The oldest technological university in the English-speaking world, famous for pioneering engineering disciplines and highly hands-on research laboratory curriculums.",
    curriculumFocus: "Mechanical engineering, lighting systems, computer systems, nuclear engineering, and environmental systems.",
    keyFeatures: [
      "Incredible legacy as America's first technological research institute",
      "Houses the highly advanced Center for Biotechnology and Interdisciplinary Studies",
      "Strong emphasis on low-altitude fluid dynamics and polymer synthesis research"
    ],
    classesCovered: "Undergraduate to PhD Research"
  },
  {
    acronym: "CAL-POLY",
    name: "California Polytechnic State University (Cal Poly)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "San Luis Obispo, California",
    description: "A highly prestigious public polytechnic university renowned for its 'Learn by Doing' philosophy, producing industry-ready, highly skilled engineers.",
    curriculumFocus: "Mechanical design, electrical power grids, civil construction, food sciences, and computer graphics.",
    keyFeatures: [
      "Acclaimed 'Learn by Doing' educational philosophy with mandatory senior design projects",
      "Consistently ranked as the top public undergraduate engineering program in the West",
      "Exceptional partnerships with California's aerospace and technology industries"
    ],
    classesCovered: "Undergraduate & Masters"
  },
  {
    acronym: "AFIT",
    name: "Air Force Institute of Technology (AFIT)",
    type: "technical-university",
    nation: "United States (America)",
    jurisdiction: "Wright-Patterson AFB, Ohio",
    description: "The United States Air Force's graduate school of engineering and management, delivering defense-focused, cutting-edge technical education to military and civilian personnel.",
    curriculumFocus: "Aerospace engineering, cyber warfare, logistics management, nuclear science, and radar systems.",
    keyFeatures: [
      "Specialized, mission-critical defense and national security research programs",
      "Unmatched expertise in low-observable technology and satellite communication systems",
      "Fully integrated with the Air Force Research Laboratory (AFRL)"
    ],
    classesCovered: "Masters & PhD Research"
  },
  {
    acronym: "CAM-TRIPOS",
    name: "University of Cambridge (Mathematical Tripos Syllabus)",
    type: "university",
    nation: "United Kingdom",
    jurisdiction: "University of Cambridge Senate",
    description: "The world's most historic and prestigious mathematical teaching syllabus. Renowned for supreme analytical precision and deep contributions to historical science.",
    curriculumFocus: "Theoretical celestial physics, deep abstract geometry, fluid dynamics, analysis proofs, and complex statistical mathematics.",
    keyFeatures: [
      "Direct personalized supervision mentorship method",
      "Extremely deep historical context and rigorous classical mathematical logic",
      "Supreme preparation for globally recognized academic and industrial research paths"
    ],
    classesCovered: "Tripos Part IA / IB / II"
  },
  {
    acronym: "OXFORD-PPE",
    name: "University of Oxford (Philosophy, Politics & Economics Core)",
    type: "university",
    nation: "United Kingdom",
    jurisdiction: "Oxford University Congregation",
    description: "The legendary Oxford syllabus that has produced eminent global leaders, politicians, and philosophers. Integrates deep analytical theory with qualitative and quantitative methods.",
    curriculumFocus: "Formal moral philosophy, modern micro/macro-economic indicators, political theory, and critical essay composition.",
    keyFeatures: [
      "Interdisciplinary analytical synthesis of societal structures",
      "Weekly rigorous tutorial essays and active dialectical arguments",
      "Robust quantitative economic modeling combined with ethical inquiry"
    ],
    classesCovered: "PPE Honours (Years 1 to 3)"
  },
  {
    acronym: "MELBOURNE-UG",
    name: "University of Melbourne (Undergraduate Science & Biomedicine Core)",
    type: "university",
    nation: "Australia",
    jurisdiction: "Melbourne Academic Board",
    description: "The prestigious multi-pathway core curriculum of Melbourne University, emphasizing comprehensive inquiry across pure sciences, engineering, and physiology.",
    curriculumFocus: "Analytical modeling, cell signaling, molecular structures, and qualitative critical argument construction.",
    keyFeatures: [
      "Innovative 'Melbourne Model' of broad foundational education",
      "State-of-the-art laboratory and virtual simulation facilities",
      "Integrated capstone industry and research partnerships"
    ],
    classesCovered: "Bachelor of Science (Years 1 to 3)"
  },
  {
    acronym: "TORONTO-CS",
    name: "University of Toronto (Graduate-Aligned Computer Science Core)",
    type: "university",
    nation: "Canada",
    jurisdiction: "U of T Governing Council",
    description: "Canada's foremost information science curriculum, famous for pioneer research in deep learning, artificial intelligence, and operating systems.",
    curriculumFocus: "Data structures, computability theory, neural networks, computer graphics, and concurrent system architecture.",
    keyFeatures: [
      "Rigorous math preparation focusing on discrete mathematics and calculus",
      "Practical programming projects utilizing modern languages and environments",
      "Exceptional synergy with Toronto's high-tech startup ecosystem"
    ],
    classesCovered: "Undergraduate Computer Science (Years 1 to 4)"
  },
  {
    acronym: "TUM-CSE",
    name: "Technical University of Munich (Computational Science & Engineering Core)",
    type: "technical-university",
    nation: "Germany",
    jurisdiction: "TUM University Council",
    description: "The elite technological curriculum core from Germany's highest-ranking technical university, covering advanced numerical simulations and scientific computing.",
    curriculumFocus: "Computational thermodynamics, fluid mechanics, linear systems solver development, and high-performance parallel computing.",
    keyFeatures: [
      "Advanced mathematical modeling of physical processes",
      "Industry-tied project seminars with European high-tech manufacturers",
      "Rigorous standards in software engineering practices"
    ],
    classesCovered: "B.Sc. / M.Sc. Computational sciences"
  },
  {
    acronym: "POLYTECH-MATH",
    name: "École Polytechnique (Ingénieur Polytechnicien Applied Math Core)",
    type: "technical-university",
    nation: "France",
    jurisdiction: "Polytechnique Ecole Council",
    description: "The historical and highly competitive math-physics core of France's premier engineering Grande École.",
    curriculumFocus: "Functional analysis, stochastic differential equations, quantum field theory, and structural economy models.",
    keyFeatures: [
      "Intense mathematical abstraction combined with national leadership training",
      "Exceptional preparation for academic research and economic analysis",
      "Prestigious historical heritage of engineering excellence"
    ],
    classesCovered: "Polytechnique Cycle Ingénieur (Years 1 to 3)"
  },
  {
    acronym: "NUS-CS",
    name: "National University of Singapore (Computing & Algorithmic Core)",
    type: "university",
    nation: "Singapore",
    jurisdiction: "NUS Senate Council",
    description: "The gold-standard computer science curriculum of Asia, highly acclaimed for preparing students in advanced algorithmic design and intelligent systems.",
    curriculumFocus: "Analysis of algorithms, machine intelligence, distributed databases, cyber-security, and high-dimensional optimization.",
    keyFeatures: [
      "Rigorous practical lab systems and programming assessments",
      "Extensive theoretical proofs for data structures and algorithms",
      "Unparalleled alignment with modern global technology hubs"
    ],
    classesCovered: "B.Comp. Computer Science (Years 1 to 4)"
  },
  {
    acronym: "TOKYO-STEM",
    name: "University of Tokyo (Rigorous Engineering & Pure Science Core)",
    type: "university",
    nation: "Japan",
    jurisdiction: "UTokyo Board of Directors",
    description: "Japan's primary undergraduate curriculum, known for unparalleled academic standards and intensive training in physical and mathematical principles.",
    curriculumFocus: "Theoretical physics, advanced calculus, physical chemistry, and molecular electronics research.",
    keyFeatures: [
      "Historically respected rigorous theoretical basis",
      "World-class laboratory instrumentation and research papers",
      "High emphasis on logical structural integrity in scientific explanations"
    ],
    classesCovered: "Senior Division Science & Engineering (Years 3 & 4)"
  },
  {
    acronym: "TSINGHUA-CS",
    name: "Tsinghua University (Specialized Computer Science & AI Core)",
    type: "university",
    nation: "China",
    jurisdiction: "Tsinghua Academic Senate",
    description: "The legendary, highly competitive undergraduate academic computer science program of Tsinghua, leading international research in AI and cryptography.",
    curriculumFocus: "Machine learning, neural networks, discrete math structures, network security, and graph theory algorithms.",
    keyFeatures: [
      "Highly selected peer group with peak mathematical skill levels",
      "Intense practical coding projects and system architecture development",
      "Strong alignment with state-of-the-art computational intelligence labs"
    ],
    classesCovered: "Undergraduate Computer Science (Years 1 to 4)"
  },
  {
    acronym: "UCT-ENG",
    name: "University of Cape Town (Undergraduate Engineering & Physics Core)",
    type: "university",
    nation: "South Africa",
    jurisdiction: "UCT Senate",
    description: "Africa's top-tier engineering curriculum, delivering highly structured analytical pathways across electrical, mechanical, and physical sciences.",
    curriculumFocus: "Signals and systems, classical thermodynamics, computational math, and structural load analysis.",
    keyFeatures: [
      "Rigorous adherence to international Washington Accord academic standards",
      "Comprehensive research thesis requirement for final-year students",
      "Deep focus on sustainable resource engineering solutions"
    ],
    classesCovered: "B.Sc. Eng. Undergraduate (Years 1 to 4)"
  },
  {
    acronym: "UI-MED",
    name: "University of Ibadan (Undergraduate Medical & Health Sciences Core)",
    type: "university",
    nation: "Nigeria",
    jurisdiction: "UI College Council",
    description: "The distinguished and highly rigorous medical curriculum of West Africa's educational pioneer. Provides elite training in biomedical research, anatomy, and clinical diagnostics.",
    curriculumFocus: "Anatomy dissection, pathophysiological mechanisms, clinical pharmacology, and molecular medicine.",
    keyFeatures: [
      "Extensive clinical rotation and laboratory diagnostics",
      "Strong emphasis on tropical medicine and public health policy",
      "Rigorous preparation for global medical licensing certifications"
    ],
    classesCovered: "MBBS Undergraduate (Years 1 to 6)"
  },
  {
    acronym: "LUMS-MATH",
    name: "Lahore University of Management Sciences (Quantitative Economics & Pure Math)",
    type: "university",
    nation: "Pakistan",
    jurisdiction: "LUMS Academic Council",
    description: "Pakistan's premier liberal arts and sciences curriculum, combining rigorous mathematical analysis with macroeconomic modeling.",
    curriculumFocus: "Differential equations, econometric forecasting, abstract algebra, and computational mathematics.",
    keyFeatures: [
      "Rigorous mathematical homework structures and assignments",
      "Active research projects in economic analysis and scientific computing",
      "Superb preparation for elite international graduate studies"
    ],
    classesCovered: "B.Sc. Honors (Years 1 to 4)"
  },
  {
    acronym: "USP-ENG",
    name: "University of São Paulo (Poli-USP Polytechnic Engineering Core)",
    type: "university",
    nation: "Brazil",
    jurisdiction: "USP Polytechnic Council",
    description: "Latin America's leading technical engineering curriculum, emphasizing mathematical modeling, structural materials science, and numerical analysis.",
    curriculumFocus: "Vector mathematics, fluid dynamics, system engineering, mechanics, and advanced thermodynamic processes.",
    keyFeatures: [
      "Extensive history of engineering and technology leadership in Brazil",
      "Deep mathematical analytical background and requirements",
      "Direct cooperation with industrial complexes and manufacturing sectors"
    ],
    classesCovered: "Polytechnic Engineering (Years 1 to 5)"
  },
  {
    acronym: "SNU-MATH",
    name: "Seoul National University (Theoretical Mathematics & Statistics Core)",
    type: "university",
    nation: "South Korea",
    jurisdiction: "SNU Academic Board",
    description: "South Korea's top-ranked higher education curriculum, specializing in advanced abstract mathematics, structural statistics, and theory of computing.",
    curriculumFocus: "Real numbers analysis, linear systems structures, statistical learning, and game theory.",
    keyFeatures: [
      "Advanced theoretical formulation and rigorous proofs",
      "Exceptional preparation for international academic research tracks",
      "Excellent integration with state-of-the-art digital technology labs"
    ],
    classesCovered: "Undergraduate Sci (Years 1 to 4)"
  },
  {
    acronym: "KAUST-RES",
    name: "King Abdullah University of Science and Technology (Advanced STEM Core)",
    type: "university",
    nation: "Saudi Arabia",
    jurisdiction: "KAUST Graduate Council",
    description: "The ultra-modern, high-funding research curriculum of KAUST, focused on next-generation computing, clean energy science, and materials bio-engineering.",
    curriculumFocus: "Statistical physics, bio-informatics computing, advanced chemical kinetics, and machine learning models.",
    keyFeatures: [
      "State-of-the-art supercomputing facilities (Shaheen)",
      "Fully funded international collaborative research projects",
      "High intensity graduate-aligned research training"
    ],
    classesCovered: "M.S. / Ph.D. Preparatory Core"
  },
  {
    acronym: "AUCKLAND-MED",
    name: "University of Auckland (Undergraduate Medicine & Clinical Science)",
    type: "university",
    nation: "New Zealand",
    jurisdiction: "Auckland Medical Council",
    description: "New Zealand's leading clinical healthcare curriculum, celebrated for deep integration of anatomy, clinical pharmacology, and molecular medical science.",
    curriculumFocus: "Anatomical dissection, metabolic pathways, clinical pathology, and holistic healthcare research.",
    keyFeatures: [
      "World-class simulation laboratories and clinical training",
      "Deep integration of indigenous health perspectives and ethics",
      "High global placement rate in international hospital programs"
    ],
    classesCovered: "MBChB Medical Core (Years 1 to 6)"
  },
  {
    acronym: "UNAM-SCI",
    name: "National Autonomous University of Mexico (Advanced Physics & Math Core)",
    type: "university",
    nation: "Mexico",
    jurisdiction: "UNAM Science Council",
    description: "The historical and largest higher education framework in Mexico, renowned for outstanding contributions to astrophysics, abstract mathematics, and chemical sciences.",
    curriculumFocus: "Quantum mechanics, electromagnetic theory, abstract algebraic topology, and organic chemical synthesis.",
    keyFeatures: [
      "Stellar research observatories and computing centers",
      "Broad-scope interdisciplinary research groups",
      "Rich history of scientific publishing and national discoveries"
    ],
    classesCovered: "Licenciatura en Ciencias (Years 1 to 4)"
  },
  {
    acronym: "IB-HLCP",
    name: "International Baccalaureate (Pre-College Advanced Level Preparation)",
    type: "university",
    nation: "International / Global",
    jurisdiction: "IB Academic Senate",
    description: "The highly advanced collegiate preparatory curriculum taken by secondary school students globally to achieve immediate advanced standing in world-class universities.",
    curriculumFocus: "Higher Level (HL) Mathematics Analysis, advanced physics theories, and qualitative world history models.",
    keyFeatures: [
      "Extended academic research essay requirements",
      "Advanced analytical and critical logic assessment criteria",
      "Worldwide recognition as college-equivalent credit courses"
    ],
    classesCovered: "IB Diploma Year 1 & 2 (HL)"
  },
  {
    acronym: "CAM-LEVELS",
    name: "Cambridge International (AS & A Levels Advanced Collegiate Core)",
    type: "university",
    nation: "International / United Kingdom",
    jurisdiction: "CAIE Academic Senate",
    description: "The elite international A-Level syllabus administered by Cambridge to select and prepare high-performing high school graduates for world-class university entrance.",
    curriculumFocus: "Further Mathematics proofing, organic chemistry kinetics, wave-particle duality physics, and macro-economics models.",
    keyFeatures: [
      "Highly rigorous linear exam structure and grading metrics",
      "Recognized globally as equivalent to university-freshman entry level",
      "Focus on deep analytical mastery and step-by-step problem-solving proofs"
    ],
    classesCovered: "A-Level Year 1 & 2"
  }
];

export interface BoardCurriculum {
  levels: string[];
  subjects: string[];
  topics: Record<string, string[]>;
}

export interface ChapterCurriculum {
  id: string;
  chapterNumber: number;
  title: string;
  chapterName: string;
  topics: string[];
  subtopics: string[];
  lessonModules?: {
    title: string;
    description: string;
    duration?: string;
    level?: string;
  }[];
  practiceGoals?: {
    conceptual: string[];
    numerical: string[];
  };
}

export interface DetailedBoardCurriculum {
  boardAcronym: string;
  boardName: string;
  nation: string;
  classLevel: string;
  subject: string;
  chapters: ChapterCurriculum[];
}

export const INDIA_CBSE_MATH_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Mathematics",
  chapters: [
    {
      id: "relations_functions",
      chapterNumber: 1,
      title: "1. Relations and Functions",
      chapterName: "Relations and Functions",
      topics: [
        "Types of Relations (Reflexive, Symmetric, Transitive, Equivalence)",
        "Types of Functions (One-One/Injective, Onto/Surjective, Bijective)",
        "Composition of Functions & Invertible Functions",
        "Binary Operations & Properties"
      ],
      subtopics: [
        "Reflexive, symmetric, transitive and equivalence relations",
        "One to one (injective) and onto (surjective) functions, bijective functions",
        "Composite functions g(f(x)), inverse of a function",
        "Binary operations, commutativity, associativity, and identity element"
      ]
    },
    {
      id: "inverse_trig",
      chapterNumber: 2,
      title: "2. Inverse Trigonometric Functions - Definition, domain, range, principal value branch, Graphs, Elementary properties",
      chapterName: "Inverse Trigonometric Functions",
      topics: [
        "Definitions, Domains & Ranges",
        "Principal Value Branches",
        "Graphs of Inverse Functions",
        "Elementary Properties & Transformations"
      ],
      subtopics: [
        "Definition, domain, range, and principal value branch of sin⁻¹x, cos⁻¹x, tan⁻¹x, cosec⁻¹x, sec⁻¹x, cot⁻¹x",
        "Graphs of inverse trigonometric functions",
        "Elementary properties of inverse trigonometric functions"
      ]
    },
    {
      id: "matrices",
      chapterNumber: 3,
      title: "3. Matrices",
      chapterName: "Matrices",
      topics: [
        "Concept, Order & Equality of Matrices",
        "Types of Matrices (Zero, Identity, Symmetric, Skew-Symmetric)",
        "Operations on Matrices (Addition, Subtraction, Multiplication, Scalar)",
        "Elementary Row and Column Operations & Invertible Matrices"
      ],
      subtopics: [
        "Concept, notation, order, equality, types of matrices (zero, identity, diagonal, scalar, square)",
        "Transpose of a matrix, symmetric and skew-symmetric matrices",
        "Matrix operations: addition, subtraction, multiplication, scalar multiplication and non-commutativity",
        "Concept of elementary row and column operations",
        "Invertible matrices and uniqueness of inverse"
      ]
    },
    {
      id: "determinants",
      chapterNumber: 4,
      title: "4. Determinants",
      chapterName: "Determinants",
      topics: [
        "Determinants Evaluation & Properties",
        "Minors, Cofactors & Area of Triangle",
        "Adjoint & Inverse of a Square Matrix",
        "Solving System of Linear Equations (Matrix Method)"
      ],
      subtopics: [
        "Determinant of a square matrix (up to 3x3)",
        "Properties of determinants and expansion",
        "Minors, cofactors, area of a triangle using determinants",
        "Adjoint and inverse of a square matrix using determinants",
        "Consistency, inconsistency and number of solutions of linear equations; matrix method for solving system of linear equations in 2 or 3 variables"
      ]
    },
    {
      id: "continuity_differentiability",
      chapterNumber: 5,
      title: "5. Continuity and Differentiability",
      chapterName: "Continuity and Differentiability",
      topics: [
        "Continuity & Differentiability",
        "Chain Rule & Implicit Differentiation",
        "Exponential & Logarithmic Functions & Differentiation",
        "Parametric Forms & Second Order Derivatives",
        "Mean Value Theorems (Rolle's & Lagrange's)"
      ],
      subtopics: [
        "Continuity of functions at a point and in an interval, differentiability",
        "Derivative of composite functions and chain rule",
        "Derivatives of inverse trigonometric functions and implicit functions",
        "Exponential and logarithmic functions, logarithmic differentiation",
        "Derivatives of functions in parametric form and second order derivatives",
        "Rolle's and Lagrange's Mean Value Theorems"
      ]
    },
    {
      id: "applications_derivatives",
      chapterNumber: 6,
      title: "6. Applications of Derivatives",
      chapterName: "Applications of Derivatives",
      topics: [
        "Rate of Change & Monotonicity",
        "Tangents & Normals",
        "Approximations using Differentials",
        "Maxima and Minima (First & Second Derivative Tests)",
        "Marginal Cost & Marginal Revenue in Economics"
      ],
      subtopics: [
        "Rate of change of quantities",
        "Increasing and decreasing functions",
        "Tangents and normals to curves",
        "Approximations using differentials",
        "Maxima and minima (First and Second Derivative Tests)",
        "Applied problems on maxima and minima in real life",
        "Marginal cost (MC), marginal revenue (MR), profit maximization, price elasticity of demand"
      ]
    },
    {
      id: "integrals",
      chapterNumber: 7,
      title: "7. Integrals",
      chapterName: "Integrals",
      topics: [
        "Integration as Inverse of Differentiation",
        "Methods: Substitution, Partial Fractions & Parts",
        "Evaluation of Standard Integral Forms",
        "Definite Integrals & Fundamental Theorem of Calculus"
      ],
      subtopics: [
        "Integration as inverse process of differentiation",
        "Integration by substitution, partial fractions, and integration by parts",
        "Evaluation of simple integrals of standard types",
        "Fundamental Theorem of Calculus",
        "Properties of definite integrals and evaluation of definite integrals"
      ]
    },
    {
      id: "applications_integrals",
      chapterNumber: 8,
      title: "8. Applications of Integrals",
      chapterName: "Applications of Integrals",
      topics: [
        "Area Under Simple Curves (Lines, Circles, Parabolas, Ellipses)",
        "Area Enclosed by Bounded Regions",
        "Area Bounded Between Two Curves"
      ],
      subtopics: [
        "Area under simple curves (lines, circles, standard parabolas y² = 4ax, ellipses x²/a² + y²/b² = 1)",
        "Evaluating bounded regions enclosed by simple algebraic curves",
        "Area bounded between any of the two above-mentioned curves"
      ]
    },
    {
      id: "differential_equations",
      chapterNumber: 9,
      title: "9. Differential Equations",
      chapterName: "Differential Equations",
      topics: [
        "Definition, Order & Degree",
        "Formation of Differential Equations",
        "Separation of Variables Method",
        "Homogeneous Differential Equations",
        "First Order Linear Differential Equations (dy/dx + Py = Q)"
      ],
      subtopics: [
        "Definition, order and degree of a differential equation",
        "General and particular solutions",
        "Formation of differential equations whose general solution is given",
        "Solutions by separation of variables method",
        "Solutions of homogeneous differential equations of first order and first degree",
        "Linear differential equations dy/dx + Py = Q and dx/dy + Px = Q"
      ]
    },
    {
      id: "vectors",
      chapterNumber: 10,
      title: "10. Vectors",
      chapterName: "Vectors",
      topics: [
        "Vectors, Position Vectors & Direction Ratios",
        "Addition, Scalar Multiplication & Section Formula",
        "Scalar (Dot) Product & Geometrical Interpretation",
        "Vector (Cross) Product & Scalar Triple Product"
      ],
      subtopics: [
        "Scalar and vector quantities, magnitude and direction",
        "Position vector, direction cosines and direction ratios",
        "Types of vectors (equal, unit, zero, parallel, collinear)",
        "Addition of vectors and multiplication by a scalar",
        "Section formula",
        "Scalar (dot) product of vectors and geometrical interpretation",
        "Vector (cross) product of vectors and scalar triple product"
      ]
    },
    {
      id: "three_dimensional_geometry",
      chapterNumber: 11,
      title: "11. Three Dimensional Geometry",
      chapterName: "Three Dimensional Geometry",
      topics: [
        "Direction Cosines & Equations of Line in 3D Space",
        "Shortest Distance & Skew Lines",
        "Cartesian and Vector Equations of a Plane",
        "Angles between Lines/Planes & Distance of Point from Plane"
      ],
      subtopics: [
        "Direction cosines and direction ratios of a line joining two points",
        "Cartesian and vector equations of a line",
        "Coplanar and skew lines, shortest distance between two lines",
        "Cartesian and vector equations of a plane",
        "Angle between two lines, two planes, a line and a plane",
        "Distance of a point from a plane"
      ]
    },
    {
      id: "linear_programming",
      chapterNumber: 12,
      title: "12. Linear Programming",
      chapterName: "Linear Programming",
      topics: [
        "Mathematical Formulation of L.P. Problems",
        "Graphical Method & Feasible / Infeasible Regions",
        "Corner Point Method for Optimal Solutions"
      ],
      subtopics: [
        "Terminology: constraints, objective function, optimization",
        "Mathematical formulation of L.P. problems",
        "Graphical method of solution for problems in two variables",
        "Feasible and infeasible regions, feasible and infeasible solutions",
        "Optimal feasible solutions (up to three non-trivial constraints)"
      ]
    },
    {
      id: "probability",
      chapterNumber: 13,
      title: "13. Probability",
      chapterName: "Probability",
      topics: [
        "Conditional Probability & Multiplication Theorem",
        "Independent Events & Total Probability",
        "Bayes' Theorem & Applications",
        "Random Variables, Probability Distributions & Binomial Distribution"
      ],
      subtopics: [
        "Conditional probability P(A|B) and multiplication theorem",
        "Independent events and theorem of total probability",
        "Bayes' Theorem and applications",
        "Random variable and its probability distribution, mean and variance",
        "Bernoulli trials and Binomial distribution"
      ]
    },
    {
      id: "linear_regression",
      chapterNumber: 14,
      title: "14. Linear Regression and Correlation",
      chapterName: "Linear Regression and Correlation",
      topics: [
        "Derivation of Regression Lines (y on x, x on y)",
        "Calculation of Regression Coefficients (byx, bxy)",
        "Intersection Point (x̄, ȳ) & Properties",
        "Correlation Coefficient r = ±√(byx · bxy)"
      ],
      subtopics: [
        "Deriving the regression line of y on x and the regression line of x on y",
        "Calculation of coefficients (byx and bxy)",
        "Properties of regression lines and identifying intersection point (x̄, ȳ)",
        "Calculating correlation coefficient (r = ±√(byx · bxy))"
      ]
    }
  ]
};

export const INDIA_ICSE_MATH_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "ICSE",
  boardName: "Indian Certificate of Secondary Education (ICSE / CISCE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Mathematics",
  chapters: [
    {
      id: "rational_irrational_numbers",
      chapterNumber: 1,
      title: "1. Pure Arithmetic: Rational and Irrational Numbers",
      chapterName: "Rational and Irrational Numbers",
      topics: [
        "Rational numbers as terminating or repeating decimals",
        "Irrational numbers as non-terminating, non-repeating decimals",
        "Simplifying radical expressions (surds)",
        "Rationalising the denominator",
        "Real number properties"
      ],
      subtopics: [
        "Rational numbers as terminating or repeating decimals",
        "Irrational numbers as non-terminating, non-repeating decimals",
        "Simplifying radical expressions; Rationalising the denominator",
        "Real number properties and ordering on the number line"
      ]
    },
    {
      id: "compound_interest",
      chapterNumber: 2,
      title: "2. Commercial Mathematics: Compound Interest",
      chapterName: "Compound Interest",
      topics: [
        "Step-by-step Simple Interest calculations",
        "Formulas for annual, semi-annual, and quarterly interest",
        "Varying rates of interest across successive periods",
        "Finding rate, time, and principal dynamically",
        "Applications to population growth and asset depreciation"
      ],
      subtopics: [
        "Computing compound interest using step-by-step simple interest calculations",
        "Formulas for annual, semi-annual, and quarterly interest application",
        "Finding rate, time, and principal dynamically given CI or Amount",
        "Real-world applications to population growth and asset depreciation"
      ]
    },
    {
      id: "expansions",
      chapterNumber: 3,
      title: "3. Algebra: Expansions",
      chapterName: "Expansions",
      topics: [
        "Binomial square expansions (x ± y)²",
        "Trinomial square expansions (a + b + c)²",
        "Binomial cube expansions (x ± y)³",
        "Reciprocal expansions (x ± 1/x)² and (x ± 1/x)³",
        "Conditional identities and value evaluation"
      ],
      subtopics: [
        "Square and cube expansions of algebraic binomials and trinomials",
        "Expansions including (x ± y)², (x ± y)³, (a + b + c)², (x ± 1/x)², (x ± 1/x)³",
        "Conditional identities (if a + b + c = 0 then a³ + b³ + c³ = 3abc)",
        "Evaluation of algebraic expressions without finding isolated variables"
      ]
    },
    {
      id: "factorisation",
      chapterNumber: 4,
      title: "4. Algebra: Factorisation",
      chapterName: "Factorisation",
      topics: [
        "Factorising by grouping terms",
        "Trinomial factoring of the form ax² + bx + c",
        "Factorising difference of two squares (a² - b²)",
        "Factorising sum and difference of two cubes (a³ ± b³)",
        "Multi-step complete factorisation"
      ],
      subtopics: [
        "Factorising by grouping terms",
        "Trinomial factoring of the form ax² + bx + c (splitting the middle term)",
        "Factorising differences of two squares (a² - b²)",
        "Factorising sums and differences of two cubes (a³ ± b³)",
        "Multi-stage complete factorisation and symmetric polynomial reductions"
      ]
    },
    {
      id: "simultaneous_linear_equations",
      chapterNumber: 5,
      title: "5. Algebra: Simultaneous Linear Equations",
      chapterName: "Simultaneous Linear Equations",
      topics: [
        "Elimination method",
        "Substitution method",
        "Cross-multiplication method",
        "Equations reducible to linear form",
        "Real-world word problems"
      ],
      subtopics: [
        "Solving systems of linear equations in two variables using elimination, substitution, and cross-multiplication methods",
        "Equations reducible to linear form with variable denominators",
        "Setting up and solving real-world word problems on numbers, ages, and fractions",
        "Word problems on speed, distance, time, and commercial applications"
      ]
    },
    {
      id: "indices_exponents",
      chapterNumber: 6,
      title: "6. Algebra: Indices / Exponents",
      chapterName: "Indices / Exponents",
      topics: [
        "Laws of indices for positive, negative, and zero exponents",
        "Fractional exponents and radical forms",
        "Simplifying complex exponential expressions",
        "Solving elementary exponential equations (aˣ = b)",
        "Simultaneous equations involving indices"
      ],
      subtopics: [
        "Laws of indices for positive, negative, zero, and fractional exponents",
        "Simplifying exponential expressions by prime factorisation of bases",
        "Solving elementary exponential equations (aˣ = b and aᶠ⁽ˣ⁾ = aᵍ⁽ˣ⁾)",
        "Simultaneous equations with exponential terms"
      ]
    },
    {
      id: "logarithms",
      chapterNumber: 7,
      title: "7. Algebra: Logarithms",
      chapterName: "Logarithms",
      topics: [
        "Fundamental definition (aˣ = b ⇔ logₐ b = x)",
        "Product, quotient, and power laws of logarithms",
        "Special values (logₐ 1 = 0, logₐ a = 1)",
        "Change of base rule",
        "Common logarithms and logarithmic equations"
      ],
      subtopics: [
        "Fundamental definition (aˣ = b ⇔ logₐ b = x where a > 0, a ≠ 1, b > 0)",
        "Standard laws of logarithms (product, quotient, and power rules)",
        "Change of base rule (logₐ b = log_c b / log_c a) and reciprocal rule",
        "Common logarithms (base 10) and solving logarithmic equations"
      ]
    },
    {
      id: "triangles_geometry",
      chapterNumber: 8,
      title: "8. Geometry: Triangles (Congruency & Inequalities)",
      chapterName: "Triangles",
      topics: [
        "Congruency conditions (SSS, SAS, ASA, RHS)",
        "Isosceles triangle theorems and converses",
        "Equilateral triangle properties",
        "Inequalities in a triangle (side-angle relationships)",
        "Triangle inequality theorem"
      ],
      subtopics: [
        "Congruency conditions (SSS, SAS, ASA, RHS) and CPCTC applications",
        "Isosceles triangle theorems and their converses",
        "Inequalities in a triangle (side-angle relationships: longer side opposite greater angle)",
        "Sum of any two sides of a triangle is greater than the third side"
      ]
    },
    {
      id: "midpoint_intercept_theorems",
      chapterNumber: 9,
      title: "9. Geometry: Mid-point and Intercept Theorems",
      chapterName: "Mid-point and Intercept Theorems",
      topics: [
        "Mid-point theorem for triangles",
        "Converse of the mid-point theorem",
        "Intercept theorem on transversal across parallel lines",
        "Equal intercepts on any transversal",
        "Applications to quadrilaterals and geometric riders"
      ],
      subtopics: [
        "Mid-point theorem for triangles and its converse",
        "Intercept theorem proving equal intercepts on transversals across parallel lines",
        "Applications to quadrilaterals (midpoints of sides form a parallelogram)",
        "Multi-step deductive geometric riders and theorem proofs"
      ]
    },
    {
      id: "rectilinear_figures",
      chapterNumber: 10,
      title: "10. Geometry: Rectilinear Figures (Quadrilaterals)",
      chapterName: "Rectilinear Figures",
      topics: [
        "Angle sum property of quadrilaterals and polygons",
        "Properties of Parallelograms (sides, angles, diagonals)",
        "Properties of Rectangles, Rhombuses, and Squares",
        "Properties of Trapeziums and Isosceles Trapeziums",
        "Structural geometric proofs"
      ],
      subtopics: [
        "Properties of quadrilaterals (Parallelogram, Rectangle, Rhombus, Square, Trapezium)",
        "Necessary and sufficient conditions for special quadrilaterals",
        "Structural geometric proofs based on quadrilateral properties",
        "Deductive riders on diagonals, perpendicular bisectors, and angle bisectors"
      ]
    },
    {
      id: "circles_geometry",
      chapterNumber: 11,
      title: "11. Geometry: Circles (Chord & Angle Properties)",
      chapterName: "Circles",
      topics: [
        "Perpendicular from center bisects a chord and converse",
        "Equal chords equidistant from center and converse",
        "Angles subtended by chords at center and circumference",
        "Angles in the same segment and semicircle right angle",
        "Cyclic quadrilateral properties introduction"
      ],
      subtopics: [
        "Chord properties: Perpendicular from the center bisects a chord (and converse)",
        "Equal chords are equidistant from the center (and converse)",
        "Angles subtended by chords at the center and circumference (center angle is double)",
        "Angles in the same segment of a circle are equal; Angle in a semicircle is a right angle"
      ]
    },
    {
      id: "area_plane_figures",
      chapterNumber: 12,
      title: "12. Mensuration: Area of Plane Figures",
      chapterName: "Area of Plane Figures",
      topics: [
        "Perimeter and area of triangles (including Heron's formula)",
        "Rectangles, squares, and parallelograms",
        "Rhombuses and trapeziums",
        "Circles, circular rings, sectors, and segments",
        "Combined figures and regular polygons"
      ],
      subtopics: [
        "Perimeter and area of triangles (including Heron's formula for scalene triangles)",
        "Area of rectangles, squares, parallelograms, rhombuses, and trapeziums",
        "Circumference and area of circles, circular rings, and regular polygons",
        "Area of sectors and segments; Shaded regions of combined plane figures"
      ]
    },
    {
      id: "surface_area_volume",
      chapterNumber: 13,
      title: "13. Mensuration: Surface Area and Volume of 3D Solids",
      chapterName: "Surface Area and Volume",
      topics: [
        "Lateral and total surface area of cubes and cuboids",
        "Volume and diagonals of cubes and cuboids",
        "Curved and total surface area of right circular cylinders",
        "Volume of right circular cylinders and hollow pipes",
        "Melting, recasting, and applied flow problems"
      ],
      subtopics: [
        "Surface areas (lateral, total) and volumes of three-dimensional solids including cubes and cuboids",
        "Curved surface area, total surface area, and volume of right circular cylinders",
        "Hollow cylinders and cylindrical pipes with thickness calculations",
        "Conservation of volume in melting, casting, and uniform fluid flow problems"
      ]
    },
    {
      id: "coordinate_geometry",
      chapterNumber: 14,
      title: "14. Coordinate Geometry: Cartesian System & Distance Formula",
      chapterName: "Coordinate Geometry",
      topics: [
        "Cartesian coordinate system and quadrants",
        "Plotting points with coordinates (x, y)",
        "Equations of lines parallel to coordinate axes",
        "Distance formula derivation and applications",
        "Mid-point formula and verification of geometric shapes"
      ],
      subtopics: [
        "Cartesian coordinate system; Plotting points in the 4 quadrants",
        "Finding the distance between two points using the Distance Formula d = √[(x₂ - x₁)² + (y₂ - y₁)²]",
        "Finding mid-points using the Mid-point Formula M = ((x₁ + x₂)/2, (y₁ + y₂)/2)",
        "Geometric verification of collinearity, triangles, and quadrilaterals using coordinate algebra"
      ]
    },
    {
      id: "trigonometrical_ratios",
      chapterNumber: 15,
      title: "15. Trigonometry: Trigonometrical Ratios & Simple Identities",
      chapterName: "Trigonometrical Ratios",
      topics: [
        "Definitions of six ratios: sin θ, cos θ, tan θ, cot θ, sec θ, csc θ",
        "Reciprocal and quotient relations",
        "T-Ratios for standard angles (0°, 30°, 45°, 60°, 90°)",
        "Simple trigonometric identities (sin²θ + cos²θ = 1, etc.)",
        "Evaluating trigonometric expressions and proofs"
      ],
      subtopics: [
        "Definitions of sin θ, cos θ, tan θ, cot θ, sec θ, csc θ in a right-angled triangle",
        "Standard angles (0°, 30°, 45°, 60°, 90°) exact value derivations",
        "Simple trigonometric identities: sin²θ + cos²θ = 1, 1 + tan²θ = sec²θ, 1 + cot²θ = csc²θ",
        "Proving trigonometric identities and numerical evaluation of expressions"
      ]
    },
    {
      id: "statistics_icse9",
      chapterNumber: 16,
      title: "16. Statistics: Data Representation & Measures of Central Tendency",
      chapterName: "Statistics",
      topics: [
        "Grouped and ungrouped data",
        "Frequency distributions and tally marks",
        "Cumulative frequency tables",
        "Histograms and frequency polygons",
        "Measures of central tendency (Mean, Median, Mode)"
      ],
      subtopics: [
        "Grouped and ungrouped data; Class intervals, class limits, and class marks",
        "Constructing frequency distributions and cumulative frequency tables",
        "Drawing histograms and frequency polygons on graph grids",
        "Computing basic measures of central tendency (Mean, Median, Mode) for raw and grouped data"
      ]
    },
    {
      id: "internal_assessment_math9",
      chapterNumber: 17,
      title: "17. Paper II: Internal Assessment & Mathematical Projects (20 Marks)",
      chapterName: "Internal Assessment",
      topics: [
        "Mathematical Projects (Minimum two assignments)",
        "Commercial & applied mathematics projects",
        "Geometric tessellations & theorem model verification",
        "Statistical field surveys",
        "Class Record Work & Viva-Voce"
      ],
      subtopics: [
        "Mathematical Projects: Students must complete a minimum of two comprehensive assignments or practical projects",
        "Assessment Framework: Class Record Work & Assignment Submission (10 Marks)",
        "Viva-Voce / Project Presentation: Conceptual defense and oral questions (10 Marks)",
        "School-supervised coursework evaluation rubrics and presentation guidelines"
      ]
    }
  ]
};

export const INDIA_CBSE_PHYSICS_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Physics",
  chapters: [
    {
      id: "electric_charges_fields",
      chapterNumber: 1,
      title: "1. Electric Charges and Fields",
      chapterName: "Electric Charges and Fields",
      topics: [
        "Electric charges, Coulomb's Law, forces between multiple charges",
        "Electric field, electric field lines, electric dipole, dipole in a uniform external field",
        "Electric flux, Gauss's theorem and its applications"
      ],
      subtopics: [
        "Electric charges, conductors and insulators, charging by induction, Coulomb's Law",
        "Electric field, electric field due to a point charge, electric dipole, electric field due to a dipole, torque on a dipole in a uniform electric field",
        "Electric flux, statement of Gauss's theorem and its applications to find field due to infinitely long straight wire, uniformly charged infinite plane sheet and uniformly charged thin spherical shell"
      ]
    },
    {
      id: "electrostatic_potential_capacitance",
      chapterNumber: 2,
      title: "2. Electrostatic Potential and Capacitance",
      chapterName: "Electrostatic Potential and Capacitance",
      topics: ["Electric potential, potential difference, electric potential due to a point charge, a dipole and system of charges", "Equipotential surfaces, electrical potential energy", "Conductors and insulators, free charges and bound charges inside a conductor", "Dielectrics and electric polarisation, capacitors and capacitance, combination of capacitors in series and in parallel", "Capacitance of a parallel plate capacitor with and without dielectric medium between the plates, energy stored in a capacitor"],
      subtopics: ["Electric potential, potential difference, electric potential due to a point charge, a dipole and system of charges; equipotential surfaces, electrical potential energy of a system of two point charges and of electric dipole in an electrostatic field", "Conductors and insulators, free charges and bound charges inside a conductor", "Dielectrics and electric polarisation, capacitors and capacitance, combination of capacitors in series and in parallel, capacitance of a parallel plate capacitor with and without dielectric medium between the plates, energy stored in a capacitor"]
    },
    {
      id: "current_electricity",
      chapterNumber: 3,
      title: "3. Current Electricity",
      chapterName: "Current Electricity",
      topics: ["Electric current, flow of electric charges in a metallic conductor, drift velocity, mobility and their relation with electric current", "Ohm's law, electrical resistance, V-I characteristics (linear and non-linear), electrical energy and power", "Electrical resistivity and conductivity, carbon resistors, colour code for carbon resistors; series and parallel combinations of resistors; temperature dependence of resistance", "Internal resistance of a cell, potential difference and emf of a cell, combination of cells in series and in parallel", "Kirchhoff's laws and simple applications, Wheatstone bridge, metre bridge", "Potentiometer - principle and applications to measure potential difference and for comparing emf of two cells; measurement of internal resistance of a cell"],
      subtopics: ["Electric current, flow of electric charges in a metallic conductor, drift velocity, mobility and their relation with electric current; Ohm's law, electrical resistance, V-I characteristics (linear and non-linear), electrical energy and power, electrical resistivity and conductivity", "Carbon resistors, colour code for carbon resistors; series and parallel combinations of resistors; temperature dependence of resistance", "Internal resistance of a cell, potential difference and emf of a cell, combination of cells in series and in parallel; Kirchhoff's laws and simple applications, Wheatstone bridge, metre bridge", "Potentiometer - principle and applications to measure potential difference and for comparing emf of two cells; measurement of internal resistance of a cell"]
    },
    {
      id: "moving_charges_magnetism",
      chapterNumber: 4,
      title: "4. Moving Charges and Magnetism",
      chapterName: "Moving Charges and Magnetism",
      topics: ["Concept of magnetic field, Oersted's experiment", "Biot - Savart law and its application to current carrying circular loop", "Ampere's law and its applications to infinitely long straight wire, straight and toroidal solenoids", "Force on a moving charge in uniform magnetic and electric fields, cyclotron", "Force on a current-carrying conductor in a uniform magnetic field", "Force between two parallel current-carrying conductors, definition of ampere", "Torque experienced by a current loop in a uniform magnetic field; moving coil galvanometer - its current sensitivity and conversion to ammeter and voltmeter"],
      subtopics: ["Concept of magnetic field, Oersted's experiment; Biot - Savart law and its application to current carrying circular loop", "Ampere's law and its applications to infinitely long straight wire, straight and toroidal solenoids", "Force on a moving charge in uniform magnetic and electric fields, cyclotron", "Force on a current-carrying conductor in a uniform magnetic field, force between two parallel current-carrying conductors, definition of ampere", "Torque experienced by a current loop in a uniform magnetic field; moving coil galvanometer - its current sensitivity and conversion to ammeter and voltmeter"]
    },
    {
      id: "magnetism_matter",
      chapterNumber: 5,
      title: "5. Magnetism and Matter",
      chapterName: "Magnetism and Matter",
      topics: ["Current loop as a magnetic dipole and its magnetic dipole moment", "Magnetic dipole moment of a revolving electron", "Magnetic field intensity due to a magnetic dipole (bar magnet) along its axis and perpendicular to its axis", "Torque on a magnetic dipole (bar magnet) in a uniform magnetic field; bar magnet as an equivalent solenoid, magnetic field lines; earth's magnetic field and magnetic elements", "Para-, dia- and ferromagnetic substances, with examples", "Electromagnets and factors affecting their strengths, permanent magnets"],
      subtopics: ["Current loop as a magnetic dipole and its magnetic dipole moment, magnetic dipole moment of a revolving electron; magnetic field intensity due to a magnetic dipole (bar magnet) along its axis and perpendicular to its axis; torque on a magnetic dipole (bar magnet) in a uniform magnetic field", "Bar magnet as an equivalent solenoid, magnetic field lines; earth's magnetic field and magnetic elements", "Para-, dia- and ferromagnetic substances, with examples; electromagnets and factors affecting their strengths, permanent magnets"]
    },
    {
      id: "electromagnetic_induction",
      chapterNumber: 6,
      title: "6. Electromagnetic Induction",
      chapterName: "Electromagnetic Induction",
      topics: ["Electromagnetic induction; Faraday's laws, induced emf and current; Lenz's Law, Eddy currents", "Self and mutual induction"],
      subtopics: ["Electromagnetic induction; Faraday's laws, induced emf and current; Lenz's Law, Eddy currents; Self and mutual induction"]
    },
    {
      id: "alternating_current",
      chapterNumber: 7,
      title: "7. Alternating Current",
      chapterName: "Alternating Current",
      topics: ["Alternating currents, peak and rms value of alternating current/voltage; reactance and impedance; LC oscillations (qualitative treatment only), LCR series circuit, resonance; power in AC circuits, wattless current", "AC generator and transformer"],
      subtopics: ["Alternating currents, peak and rms value of alternating current/voltage; reactance and impedance; LC oscillations (qualitative treatment only), LCR series circuit, resonance; power in AC circuits, wattless current; AC generator and transformer"]
    },
    {
      id: "electromagnetic_waves",
      chapterNumber: 8,
      title: "8. Electromagnetic Waves",
      chapterName: "Electromagnetic Waves",
      topics: ["Basic idea of displacement current, Electromagnetic waves, their characteristics, their Transverse nature (qualitative idea only)", "Electromagnetic spectrum (radio waves, microwaves, infrared, visible, ultraviolet, x-rays, gamma rays) including elementary facts about their uses"],
      subtopics: ["Basic idea of displacement current, Electromagnetic waves, their characteristics, their Transverse nature (qualitative idea only); Electromagnetic spectrum (radio waves, microwaves, infrared, visible, ultraviolet, x-rays, gamma rays) including elementary facts about their uses"]
    },
    {
      id: "ray_optics",
      chapterNumber: 9,
      title: "9. Ray Optics and Optical Instruments",
      chapterName: "Ray Optics and Optical Instruments",
      topics: ["Reflection of light, spherical mirrors, mirror formula", "Refraction of light, total internal reflection and its applications, optical fibres, refraction at spherical surfaces, lenses, thin lens formula, lensmaker's formula, magnification, power of a lens, combination of thin lenses in contact, combination of a lens and a mirror", "Refraction and dispersion of light through a prism", "Scattering of light - blue colour of sky and reddish appearance of the sun at sunrise and sunset", "Optical instruments: Human eye, image formation and accommodation, correction of eye defects (myopia, hypermetropia, presbyopia and astigmatism) using lenses; Microscopes and astronomical telescopes (reflecting and refracting) and their magnifying powers"],
      subtopics: ["Reflection of light, spherical mirrors, mirror formula; refraction of light, total internal reflection and its applications, optical fibres, refraction at spherical surfaces, lenses, thin lens formula, lensmaker's formula, magnification, power of a lens, combination of thin lenses in contact, combination of a lens and a mirror, refraction and dispersion of light through a prism", "Scattering of light - blue colour of sky and reddish appearance of the sun at sunrise and sunset; optical instruments: Human eye, image formation and accommodation, correction of eye defects (myopia, hypermetropia, presbyopia and astigmatism) using lenses; Microscopes and astronomical telescopes (reflecting and refracting) and their magnifying powers"]
    },
    {
      id: "wave_optics",
      chapterNumber: 10,
      title: "10. Wave Optics",
      chapterName: "Wave Optics",
      topics: ["Wavefront and Huygen's principle, reflection and refraction of plane wave at a plane surface using wavefronts", "Proof of laws of reflection and refraction using Huygen's principle", "Interference, Young's double hole experiment and expression for fringe width (qualitative treatment only), coherent sources and sustained interference of light", "Diffraction due to a single slit, width of central maximum", "Resolving power of microscope and astronomical telescope, Polarisation, plane polarised light; Brewster's law, uses of plane polarised light and Polaroids"],
      subtopics: ["Wavefront and Huygen's principle, reflection and refraction of plane wave at a plane surface using wavefronts; proof of laws of reflection and refraction using Huygen's principle", "Interference, Young's double hole experiment and expression for fringe width (qualitative treatment only), coherent sources and sustained interference of light; diffraction due to a single slit, width of central maximum", "Resolving power of microscope and astronomical telescope, Polarisation, plane polarised light; Brewster's law, uses of plane polarised light and Polaroids"]
    },
    {
      id: "dual_nature",
      chapterNumber: 11,
      title: "11. Dual Nature of Radiation and Matter",
      chapterName: "Dual Nature of Radiation and Matter",
      topics: ["Dual nature of radiation, Photoelectric effect, Hertz and Lenard's observations; Einstein's photoelectric equation-particle nature of light", "Matter waves-wave nature of particles, de Broglie relation, Davisson-Germer experiment (experimental details should be omitted; only conclusion should be explained)"],
      subtopics: ["Dual nature of radiation, Photoelectric effect, Hertz and Lenard's observations; Einstein's photoelectric equation-particle nature of light; Matter waves-wave nature of particles, de Broglie relation, Davisson-Germer experiment (experimental details should be omitted; only conclusion should be explained)"]
    },
    {
      id: "atoms",
      chapterNumber: 12,
      title: "12. Atoms",
      chapterName: "Atoms",
      topics: ["Alpha-particle scattering experiment; Rutherford's model of atom; Bohr model, energy levels, hydrogen spectrum"],
      subtopics: ["Alpha-particle scattering experiment; Rutherford's model of atom; Bohr model, energy levels, hydrogen spectrum"]
    },
    {
      id: "nuclei",
      chapterNumber: 13,
      title: "13. Nuclei",
      chapterName: "Nuclei",
      topics: ["Composition and size of nucleus, atomic masses, isotopes, isobars; isotones", "Radioactivity-alpha, beta and gamma particles/rays and their properties; radioactive decay law", "Mass-energy relation, mass defect; binding energy per nucleon and its variation with mass number, nuclear fission and nuclear fusion"],
      subtopics: ["Composition and size of nucleus, atomic masses, isotopes, isobars; isotones; Radioactivity-alpha, beta and gamma particles/rays and their properties; radioactive decay law", "Mass-energy relation, mass defect; binding energy per nucleon and its variation with mass number, nuclear fission and nuclear fusion"]
    },
    {
      id: "semiconductor",
      chapterNumber: 14,
      title: "14. Semiconductor Electronics: Materials, Devices and Simple Circuits",
      chapterName: "Semiconductor Electronics: Materials, Devices and Simple Circuits",
      topics: ["Energy bands in conductors, semiconductors and insulators (qualitative ideas only)", "Semiconductor diode: I-V characteristics in forward and reverse bias, diode as a rectifier; Special purpose p-n junction diodes: LED, photodiode, solar cell and Zener diode and their characteristics, zener diode as a voltage regulator", "Junction transistor, transistor action, characteristics of a transistor; transistor as an amplifier (common emitter configuration) and oscillator (qualitative idea only)", "Logic gates (OR, AND, NOT, NAND and NOR)"],
      subtopics: ["Energy bands in conductors, semiconductors and insulators (qualitative ideas only); Semiconductor diode: I-V characteristics in forward and reverse bias, diode as a rectifier", "Special purpose p-n junction diodes: LED, photodiode, solar cell and Zener diode and their characteristics, zener diode as a voltage regulator", "Junction transistor, transistor action, characteristics of a transistor; transistor as an amplifier (common emitter configuration) and oscillator (qualitative idea only); Logic gates (OR, AND, NOT, NAND and NOR)"]
    }
  ]
};

export const INDIA_CBSE_CHEMISTRY_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Chemistry",
  chapters: [
    {
      id: "solutions",
      chapterNumber: 1,
      title: "1. Solutions (7 Marks)",
      chapterName: "Solutions",
      topics: [
        "Types & Concentrations",
        "Vapour Pressure",
        "Colligative Properties",
        "Molar Mass Determinations"
      ],
      subtopics: [
        "Types & Concentrations: Binary liquid mixtures, expressions of concentration of solutions of solids in liquids, solubility of gases in liquids (Henry's Law)",
        "Vapour Pressure: Liquid-liquid solutions, Raoult's law for volatile and non-volatile solutes, ideal and non-ideal solutions, deviations (positive and negative) from Raoult's law",
        "Colligative Properties: Relative lowering of vapour pressure, elevation of boiling point, depression of freezing point, osmotic pressure",
        "Molar Mass Determinations: Calculation of molecular mass using colligative properties, abnormal molecular mass, Van't Hoff factor (i) and its relation to degree of association and dissociation"
      ]
    },
    {
      id: "electrochemistry",
      chapterNumber: 2,
      title: "2. Electrochemistry (9 Marks)",
      chapterName: "Electrochemistry",
      topics: [
        "Redox & Galvanic Systems",
        "Thermodynamics & Kinetics",
        "Conductance & Electrolysis",
        "Applied Electrochemistry"
      ],
      subtopics: [
        "Redox & Galvanic Systems: Redox reactions, EMF of a cell, standard electrode potential, galvanic cells, electrolytic cells",
        "Thermodynamics & Kinetics: Nernst equation and its applications to chemical cells, relation between Gibbs energy change (Δ G) and EMF of a cell (E_cell)",
        "Conductance & Electrolysis: Conductance in electrolytic solutions, specific and molar conductivity, variations of conductivity with concentration, Kohlrausch's Law and its applications",
        "Applied Electrochemistry: Electrolysis and laws of electrolysis (elementary idea), dry cell- electrolytic cells and Galvanic cells, lead accumulator, fuel cells, corrosion"
      ]
    },
    {
      id: "chemical_kinetics",
      chapterNumber: 3,
      title: "3. Chemical Kinetics (7 Marks)",
      chapterName: "Chemical Kinetics",
      topics: [
        "Reaction Rates",
        "Rate Laws",
        "Integrated Rate Expressions",
        "Collision Dynamic Models"
      ],
      subtopics: [
        "Reaction Rates: Rate of a reaction (average and instantaneous), factors affecting rates of reaction: concentration, temperature, catalyst",
        "Rate Laws: Order and molecularity of a reaction, rate law and specific rate constant",
        "Integrated Rate Expressions: Integrated rate equations and half-life calculations (restricted strictly to zero and first-order reactions)",
        "Collision Dynamic Models: Mathematical introduction to activation energy, Arrhenius equation, concept of collision theory (elementary qualitative idea, no mathematical treatment)"
      ]
    },
    {
      id: "d_f_block",
      chapterNumber: 4,
      title: "4. d- and f-Block Elements (7 Marks)",
      chapterName: "d- and f-Block Elements",
      topics: [
        "Transition Metals (d-block) Properties",
        "Periodic Trends & Oxidation States",
        "Heavy Inorganic Compounds (K2Cr2O7 & KMnO4)",
        "Inner Transition Metals (Lanthanoids & Actinoids)"
      ],
      subtopics: [
        "Transition Metals (d-Block) Properties: Transition metals (d-block) properties, periodic trends, electronic configurations, oxidation states, and metallic properties",
        "Heavy Inorganic Compounds: Heavy inorganic compounds like Potassium Dichromate (K2Cr2O7) and Potassium Permanganate (KMnO4) preparation, properties, and oxidizing actions",
        "Inner Transition Metals (f-Block) - Lanthanoids: Electronic configuration, oxidation states, chemical reactivity, and lanthanoid contraction consequences",
        "Inner Transition Metals (f-Block) - Actinoids: Electronic configuration, oxidation states, and comparative study with lanthanoids"
      ]
    },
    {
      id: "coordination_compounds",
      chapterNumber: 5,
      title: "5. Coordination Compounds (7 Marks)",
      chapterName: "Coordination Compounds",
      topics: [
        "Structural Nomenclature & Ligands",
        "Isomerism Configurations",
        "Bonding Theories (Werner's, VBT, CFT)",
        "Applications in Analysis & Biology"
      ],
      subtopics: [
        "Structural Nomenclature: Structural nomenclature, ligands, coordination number, coordination sphere, and IUPAC nomenclature rules",
        "Isomerism Configurations: Structural isomerism (linkage, ionization, coordination, hydrate) and stereoisomerism (geometrical and optical)",
        "Bonding Theories: Werner's theory, Valence Bond Theory (VBT - hybridization, geometry, magnetic nature), and Crystal Field Theory (CFT - d-orbital splitting, CFSE)",
        "Applications: Stability of complexes, applications in qualitative analysis, extraction of metals, and biological systems (chlorophyll, hemoglobin, vitamin B12)"
      ]
    },
    {
      id: "haloalkanes_haloarenes",
      chapterNumber: 6,
      title: "6. Haloalkanes and Haloarenes (6 Marks)",
      chapterName: "Haloalkanes and Haloarenes",
      topics: [
        "Nomenclature & Nature of C-X Bond",
        "Substitution Reaction Mechanisms (SN1, SN2)",
        "Elimination & Organometallic Reactions",
        "Environmental Impacts & Polyhalogen Compounds"
      ],
      subtopics: [
        "Nomenclature & Properties: Examines nomenclature, nature of C-X bond, dipole moments, physical and chemical properties",
        "Substitution Reaction Mechanisms: Nucleophilic substitution mechanisms (SN1, SN2) with stereochemical aspects (retention, inversion, racemization)",
        "Elimination & Metal Reactions: Elimination reactions (Saytzeff's rule) and organometallic reactions (Grignard reagent, Wurtz, Fittig, Wurtz-Fittig)",
        "Environmental Impacts: Uses and environmental impacts of polyhalogen compounds (dichloromethane, chloroform, iodoform, CCl4, freons, DDT)"
      ]
    },
    {
      id: "alcohols_phenols_ethers",
      chapterNumber: 7,
      title: "7. Alcohols, Phenols and Ethers (6 Marks)",
      chapterName: "Alcohols, Phenols and Ethers",
      topics: [
        "Preparation & Properties of Alcohols/Phenols",
        "Distinct Tests (Lucas & FeCl3 Tests)",
        "Named Reactions (Kolbe's & Reimer-Tiemann)",
        "Williamson Synthesis & Ether Cleavage"
      ],
      subtopics: [
        "Preparation and Properties: Focuses on preparation and properties of alcohols, phenols, and ethers, physical properties and hydrogen bonding",
        "Distinct Tests: Distinct tests like the Lucas test (distinction between primary, secondary, and tertiary alcohols) and neutral FeCl3 test for phenols",
        "Named Reactions: Kolbe's reaction, Reimer-Tiemann reaction, acid-catalyzed dehydration of alcohols, and esterification",
        "Williamson Synthesis: Williamson synthesis of symmetrical and unsymmetrical ethers, physical properties, and cleavage of C-O bond by HI"
      ]
    },
    {
      id: "aldehydes_ketones_carboxylic",
      chapterNumber: 8,
      title: "8. Aldehydes, Ketones and Carboxylic Acids (8 Marks)",
      chapterName: "Aldehydes, Ketones and Carboxylic Acids",
      topics: [
        "Carbonyl Group Reactions & Preparation",
        "Nucleophilic Additions Across Carbonyl",
        "Named Condensations (Aldol & Cannizzaro)",
        "Carboxylic Acid Strength & Reactions"
      ],
      subtopics: [
        "Carbonyl Group Reactions: Details carbonyl group reactions, nomenclature, dipolar structure, and methods of preparation",
        "Nucleophilic Additions: Nucleophilic additions across carbonyl bonds (HCN, NaHSO3, Grignard, alcohols) and addition-elimination with ammonia derivatives",
        "Named Condensations & Reductions: Aldol condensations, Cross-Aldol condensations, Cannizzaro reactions, Clemmensen and Wolff-Kishner reductions, Tollens' and Fehling's tests",
        "Carboxylic Acid Strength: Acidity of carboxylic acids and substituent effects (inductive/resonance), Hell-Volhard-Zelinsky reaction, and decarboxylation"
      ]
    },
    {
      id: "amines",
      chapterNumber: 9,
      title: "9. Amines (6 Marks)",
      chapterName: "Amines",
      topics: [
        "Classifications & Nomenclature",
        "Basicity Comparisons (Inductive, Steric, Solvation)",
        "Hinsberg's Test & Chemical Distinction",
        "Diazonium Salt Reactions & Syntheses"
      ],
      subtopics: [
        "Classifications & Nomenclature: Reviews classifications (1°, 2°, 3° amines), IUPAC nomenclature, Gabriel phthalimide synthesis, and Hoffmann bromamide reaction",
        "Basicity Comparisons: Basicity comparisons of aliphatic and aromatic amines in gaseous and aqueous phases, inductive, steric, and solvation factors",
        "Hinsberg's Test: Distinction between primary, secondary, and tertiary amines using Hinsberg's reagent (benzenesulphonyl chloride) and carbylamine test",
        "Diazonium Salt Reactions: Preparation of diazonium salts, physical properties, Sandmeyer, Gattermann, azo coupling reactions, and synthetic applications"
      ]
    },
    {
      id: "biomolecules",
      chapterNumber: 10,
      title: "10. Biomolecules (7 Marks)",
      chapterName: "Biomolecules",
      topics: [
        "Carbohydrates (Mono, Oligo, Polysaccharides)",
        "Protein Structures & Denaturation",
        "Vitamins & Hormones",
        "Nucleic Acids (DNA vs. RNA)"
      ],
      subtopics: [
        "Carbohydrates: Summarizes carbohydrates, aldoses/ketoses, monosaccharides (cyclic structures of D-glucose and D-fructose), oligosaccharides, and polysaccharides",
        "Protein Structures & Denaturation: Amino acids, peptide bonds, levels of protein structure (primary, secondary alpha-helix/beta-sheet, tertiary, quaternary), and denaturation",
        "Vitamins & Hormones: Classification of vitamins (fat vs water soluble), deficiency diseases, and physiological functions of hormones",
        "Nucleic Acids: Chemical composition, nucleotides, Watson-Crick double-helix structure of DNA, RNA types (mRNA, tRNA, rRNA), biological roles, and DNA vs. RNA"
      ]
    }
  ]
};

export const INDIA_ISC_CHEMISTRY_CLASS11_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CISCE / ICSE (ISC)",
  boardName: "Council for the Indian School Certificate Examinations (ISC Class 11)",
  nation: "India",
  classLevel: "Class 11",
  subject: "Chemistry",
  chapters: [
    {
      id: "some_basic_concepts_chem11",
      chapterNumber: 1,
      title: "Unit 1: Some Basic Concepts of Chemistry",
      chapterName: "Some Basic Concepts of Chemistry",
      topics: [
        "General Foundations",
        "Stoichiometry Math",
        "Solution Concentrations"
      ],
      subtopics: [
        "General Foundations: Matter and its nature; Laws of chemical combination (Definite proportions, Multiple proportions, Reciprocal proportions, Gay Lussac's Law)",
        "Stoichiometry Math: Atomic, molecular, and equivalent masses; Mole concept, Avogadro's number, and molar mass; Percentage composition, empirical formula, and molecular formula; Stoichiometric calculations involving limiting reagents, mass-mass, mass-volume, and volume-volume relationships",
        "Solution Concentrations: Concentrations expressed as mass percentage, volume percentage, parts per million (ppm), mole fraction, molarity (M), and molality (m)"
      ]
    },
    {
      id: "structure_of_atom11",
      chapterNumber: 2,
      title: "Unit 2: Structure of Atom",
      chapterName: "Structure of Atom",
      topics: [
        "Subatomic Evolution",
        "Quantum Mechanics"
      ],
      subtopics: [
        "Subatomic Evolution: Discovery of fundamental particles; Thomson’s, Rutherford’s, and Bohr’s atomic models (achievements and limitations); Dual nature of matter and light (de Broglie relationship); Heisenberg’s Uncertainty Principle",
        "Quantum Mechanics: Quantum numbers (principal, azimuthal, magnetic, spin); Shapes of s, p, and d orbitals; Rules for filling electrons in orbitals: Aufbau Principle, Pauli’s Exclusion Principle, and Hund’s Rule of Maximum Multiplicity; Electronic configuration of elements up to Atomic Number 36 (Krypton), highlighting anomalous configurations of Chromium and Copper"
      ]
    },
    {
      id: "classification_periodicity11",
      chapterNumber: 3,
      title: "Unit 3: Classification of Elements and Periodicity in Properties",
      chapterName: "Classification of Elements and Periodicity in Properties",
      topics: [
        "Periodic Table Development",
        "Periodic Trends"
      ],
      subtopics: [
        "Periodic Table Development: Modern Periodic Law and the present form of the long-form periodic table; Nomenclature of elements with atomic numbers > 100",
        "Periodic Trends: Detailed analysis of variations across periods and down groups for: Atomic and ionic radii, Ionisation Enthalpy (ΔHi), Electron Gain Enthalpy (ΔHeg), Electronegativity, Valency, and Anomalous properties of second-period elements"
      ]
    },
    {
      id: "chemical_bonding_molecular11",
      chapterNumber: 4,
      title: "Unit 4: Chemical Bonding and Molecular Structure",
      chapterName: "Chemical Bonding and Molecular Structure",
      topics: [
        "Valence Bonding",
        "Molecular Orbital Theory (MOT)",
        "Intermolecular Forces"
      ],
      subtopics: [
        "Valence Bonding: Valence electrons, ionic bond, covalent bond, and coordinate bond parameters; Lewis structures and formal charge; VSEPR Theory and geometric shapes of regular and distorted molecules (H₂O, NH₃, CH₄, PCl₅, SF₆); Orbital overlap, hybridization involving s, p, and d orbitals (sp, sp², sp³, dsp², sp³d, sp³d²)",
        "Molecular Orbital Theory (MOT): Homonuclear diatomic molecules (H₂, He₂, Li₂, B₂, C₂, N₂, O₂, F₂); Bonding and antibonding molecular orbitals; Molecular orbital electronic configurations, bond order calculations, and magnetic properties",
        "Intermolecular Forces: Coordinate dipole moments; Hydrogen bonding (intermolecular and intramolecular forces) and its structural impacts on physical states"
      ]
    },
    {
      id: "chemical_thermodynamics11",
      chapterNumber: 5,
      title: "Unit 5: Chemical Thermodynamics",
      chapterName: "Chemical Thermodynamics",
      topics: [
        "Thermodynamic Systems",
        "First Law and Enthalpy",
        "Second Law and Spontaneity"
      ],
      subtopics: [
        "Thermodynamic Systems: System and surroundings; Closed, open, and isolated systems; State functions and path functions; Extensive and intensive properties; Isothermal, adiabatic, isobaric, and isochoric processes; Work, heat, and internal energy (U)",
        "First Law and Enthalpy: Statement of the First Law (ΔU = q + w); Enthalpy (H) and enthalpy changes (ΔH); Heat capacity and specific heat; Hess’s Law of Constant Heat Summation; Enthalpies of bond dissociation, combustion, formation, atomization, sublimation, phase transition, ionization, and dilution",
        "Second Law and Spontaneity: Spontaneous and non-spontaneous processes; Entropy (S) as a state function (ΔS = q_rev / T); Gibbs Free Energy Change (ΔG) as a driving criterion for spontaneity; Standard free energy changes and relation to chemical equilibrium constant (ΔG° = -RT ln K); Third Law of Thermodynamics (elementary introduction)"
      ]
    },
    {
      id: "equilibrium11",
      chapterNumber: 6,
      title: "Unit 6: Equilibrium",
      chapterName: "Equilibrium",
      topics: [
        "Physical & Chemical Equilibrium",
        "Ionic Equilibrium"
      ],
      subtopics: [
        "Physical & Chemical Equilibrium: Dynamic nature of equilibrium; Law of Mass Action and equilibrium constant (Kp, Kc) along with their mathematical interrelation (Kp = Kc(RT)^Δn); Le Chatelier’s Principle and its industrial application to temperature, pressure, concentration changes, and inert gas additions",
        "Ionic Equilibrium: Theories of Acids and Bases (Arrhenius, Brønsted-Lowry, Lewis); Ionization of weak acids and bases; Ostwald’s Dilution Law; Ionic product of water (Kw); pH scale and its calculations; Common ion effect; Buffer solutions (acidic and basic buffer mechanisms); Solubility product (Ksp) and its application in qualitative inorganic salt separation schemes"
      ]
    },
    {
      id: "redox_reactions11",
      chapterNumber: 7,
      title: "Unit 7: Redox Reactions",
      chapterName: "Redox Reactions",
      topics: [
        "Oxidation-Reduction Dynamics",
        "Redox Balancing"
      ],
      subtopics: [
        "Oxidation-Reduction Dynamics: Classical, electronic, and oxidation-number concepts of redox reactions; Rules for assigning oxidation numbers",
        "Redox Balancing: Balancing redox equations by the Ion-Electron (Half-Reaction) method and Oxidation Number method across acidic and basic mediums; Types of redox reactions (combination, decomposition, displacement, disproportionation)"
      ]
    },
    {
      id: "inorganic_s_p_block11",
      chapterNumber: 8,
      title: "Unit 8: Inorganic Chemistry: Classification of Elements (s-Block & p-Block)",
      chapterName: "Inorganic Chemistry: Classification of Elements (s-Block & p-Block)",
      topics: [
        "s-Block Group Trends",
        "p-Block Group Trends"
      ],
      subtopics: [
        "s-Block Group Trends: Group 1 (Alkali Metals) and Group 2 (Alkaline Earth Metals) trends in electronic configuration, atomic/ionic radii, ionization enthalpy, hydration enthalpy, and chemical reactivity with oxygen, water, hydrogen, and halogens; Anomalous behaviour of Lithium and Beryllium; Diagonal relationships",
        "p-Block Group Trends: General introduction, configurations, and oxidation states of Group 13 (Boron family) and Group 14 (Carbon family); Inert pair effect; Anomalous properties of Boron and Carbon; Allotropes of Carbon (diamond, graphite, fullerenes)"
      ]
    },
    {
      id: "organic_chemistry_hydrocarbons11",
      chapterNumber: 9,
      title: "Unit 9: Organic Chemistry: Some Basic Principles, Techniques, and Hydrocarbons",
      chapterName: "Organic Chemistry: Some Basic Principles, Techniques, and Hydrocarbons",
      topics: [
        "Foundations and Nomenclature",
        "Isomerism",
        "Reaction Mechanisms",
        "Hydrocarbons — Alkanes",
        "Hydrocarbons — Alkenes",
        "Hydrocarbons — Alkynes",
        "Hydrocarbons — Aromatic Hydrocarbons"
      ],
      subtopics: [
        "Foundations and Nomenclature: Tetravalency and catenation of carbon; Shapes of organic molecules based on hybridisation; IUPAC systematic nomenclature of mono- and poly-functional aliphatic and aromatic organic compounds",
        "Isomerism: Structural isomerism (chain, position, functional, metamerism) and Stereo-isomerism (geometrical and optical configurations in brief)",
        "Reaction Mechanisms: Fission of a covalent bond (homolytic and heterolytic cleavage); Electrophiles, Nucleophiles, and Free Radicals; Electron displacement effects: Inductive effect, Electromeric effect, Resonance/Mesomeric effect, and Hyperconjugation; Carbocations and Carbanions stability trends",
        "Hydrocarbons — Alkanes: Nomenclature, isomerism, conformation of ethane (Sawhorse and Newman projections); Preparation (Wurtz reaction, Kolbe's electrolysis, decarboxylation); Free radical halogenation mechanism",
        "Hydrocarbons — Alkenes: Nomenclature, structural isomerism, geometrical (cis-trans) isomerism; Preparation via dehydration of alcohols and dehydrohalogenation; Addition reactions, Markovnikov's Rule and its peroxide effect mechanism (Anti-Markovnikov addition), Ozonolysis, and Polymerization",
        "Hydrocarbons — Alkynes: Nomenclature, acidic character; Preparation via calcium carbide and vicinal dihalides; Addition reactions with hydrogen, halogens, hydrogen halides, and water",
        "Hydrocarbons — Aromatic Hydrocarbons: Benzene structure, resonance, and aromaticity (Hückel's Rule); Mechanism of electrophilic substitution reactions: Nitration, Sulphonation, Halogenation, and Friedel-Crafts Alkylation/Acylation; Directive influence of functional groups in monosubstituted benzenes"
      ]
    },
    {
      id: "practical_chemistry11",
      chapterNumber: 10,
      title: "Paper II: Practical Work & Project (30 Marks)",
      chapterName: "Practical Work & Project",
      topics: [
        "Section A: Quantitative Volumetric Analysis (10 Marks)",
        "Section B: Qualitative Inorganic Salt Analysis (10 Marks)",
        "Section C: Scientific Project & Viva-Voce (10 Marks)"
      ],
      subtopics: [
        "Section A: Quantitative Volumetric Analysis (10 Marks): Acid-Base titrations using standard solutions and indicators (phenolphthalein/methyl orange) to find molarity and strength parameters; Redox titrations involving Potassium Permanganate (KMnO₄) against oxalic acid or Mohr’s salt",
        "Section B: Qualitative Inorganic Salt Analysis (10 Marks): Identifying one cation and one anion from an unknown water-soluble or acid-soluble salt batch; Target Anions: CO₃²⁻, S²⁻, SO₃²⁻, NO₂⁻, NO₃⁻, Cl⁻, Br⁻, I⁻, SO₄²⁻, CH₃COO⁻; Target Cations: NH₄⁺, Pb²⁺, Cu²⁺, Al³⁺, Fe²⁺, Fe³⁺, Zn²⁺, Mn²⁺, Ni²⁺, Co²⁺, Ba²⁺, Sr²⁺, Ca²⁺, Mg²⁺",
        "Section C: Scientific Project & Viva-Voce (10 Marks): Execution of an independent experimental project (e.g., analyzing water purification, foaming capacity of soaps, or extracting natural indicators) combined with an oral laboratory exam (5 Marks Project File + 5 Marks Viva-Voce)"
      ]
    }
  ]
};

export const INDIA_ISC_BIOLOGY_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "ISC",
  boardName: "Council for the Indian School Certificate Examinations (ISC)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Biology",
  chapters: [
    {
      id: "reproduction",
      chapterNumber: 1,
      title: "1. Reproduction (16 Marks)",
      chapterName: "Reproduction",
      topics: ["Plant Reproduction", "Human Reproduction", "Reproductive Health"],
      subtopics: [
        "T.S. anther (4 layers, tapetum); microsporogenesis (pollen walls, exine, germ pores); megasporogenesis (anatropous ovule, 7-celled/8-nucleate embryo sac); pollination (autogamy, geitonogamy, xenogamy, outbreeding devices); double fertilisation (syngamy, triple fusion); endosperm/embryo development; apomixis, polyembryony, parthenocarpy.",
        "Testis (Sertoli, Leydig cells); ovary (Graafian follicle); spermatogenesis vs. oogenesis; menstrual cycle hormonal shifts (LH surge, FSH, estrogen, progesterone); fertilisation (acrosome/cortical reactions); blastocyst implantation; placenta hormones (hCG, hPL); parturition and lactation.",
        "Amniocentesis limits; contraceptive variants (Lippes Loop, CuT, LNG-20, pills, sterilization); MTP; STDs; ART systems (IVF, ZIFT, GIFT, ICSI, IUI)."
      ],
      lessonModules: [],
      practiceGoals: { conceptual: [], numerical: [] }
    },
    {
      id: "genetics_evolution",
      chapterNumber: 2,
      title: "2. Genetics and Evolution (15 Marks)",
      chapterName: "Genetics and Evolution",
      topics: ["Mendelian Deviations", "Chromosomes & Disorders", "Molecular Basis", "Evolution"],
      subtopics: [
        "Incomplete dominance (Mirabilis jalapa); co-dominance/multiple alleles (ABO blood groups); pleiotropy (PKU); polygenic inheritance (skin colour).",
        "Chromosomal Theory; Drosophila linkage/crossing over; sex determination (XY, ZW, XO); sex-linked traits (Haemophilia); pedigree charts; point mutations (Sickle cell); frameshift (Thalassemia); aneuploidy (Down's, Klinefelter's, Turner's).",
        "DNA/RNA traits; Griffith, Avery, Hershey-Chase experiments; nucleosome packaging; Meselson-Stahl replication fork enzymes; transcription unit (splicing, capping, tailing); genetic code; Lac Operon; HGP; DNA Fingerprinting (VNTR).",
        "Miller-Urey experiment; homologous (divergent/adaptive radiation) vs. analogous (convergent) organs; Natural Selection; Hardy-Weinberg formula; human evolution lineage (Habilis, Erectus, Neanderthal, Sapiens)."
      ],
      lessonModules: [],
      practiceGoals: { conceptual: [], numerical: [] }
    },
    {
      id: "biology_welfare",
      chapterNumber: 3,
      title: "3. Biology and Human Welfare (14 Marks)",
      chapterName: "Biology and Human Welfare",
      topics: ["Health & Disease", "Microbes"],
      subtopics: [
        "Lifecycles/transmission of Malaria (Plasmodium multi-host tracks), Typhoid, Pneumonia, Elephantiasis, Dengue, Chikungunya; innate vs. acquired immunity; antibody structure (H2L2 chain); active/passive immunization; AIDS (TH cell replication); cancer oncogenes; drug abuse.",
        "Household/industrial uses (fermentation, organic acids); bioactive tools (Cyclosporin A, Statins); sewage treatment phases (BOD tracking); biocontrol (Bt, NPV); biofertilisers (Rhizobium, Mycorrhizae)."
      ],
      lessonModules: [],
      practiceGoals: { conceptual: [], numerical: [] }
    },
    {
      id: "biotechnology",
      chapterNumber: 4,
      title: "4. Biotechnology and Its Applications (10 Marks)",
      chapterName: "Biotechnology and Its Applications",
      topics: ["Principles & Processes", "Applications"],
      subtopics: [
        "Restriction enzymes (EcoRI); pBR322 plasmid map; blue-white screening (insertional inactivation); PCR steps (Denaturation, Annealing, Extension); bioreactors.",
        "GM crops; Bt cotton insect-midgut activation; RNA Interference (dsRNA silencing); synthetic insulin (Humulin chains A & B); ADA gene therapy; molecular tests (ELISA, PCR); biopiracy."
      ],
      lessonModules: [],
      practiceGoals: { conceptual: [], numerical: [] }
    },
    {
      id: "ecology",
      chapterNumber: 5,
      title: "5. Ecology and Environment (15 Marks)",
      chapterName: "Ecology and Environment",
      topics: ["Populations", "Ecosystems", "Biodiversity"],
      subtopics: [
        "Regulators, conformers, adaptors (Allen’s Rule, xerophytes, halophytes); growth charts (Exponential, Logistic); interactions (Mutualism, Gause competition, Predation, Brood Parasitism, Commensalism, Amensalism).",
        "Productivity (NPP, GPP, R); decomposition steps (fragmentation, leaching, catabolism, humification, mineralisation); energy flow; pyramids; succession (hydrarch and xerarch).",
        "Humboldt equation; 'Evil Quartet' threats; In-situ (National Parks, Biosphere Reserves) vs. Ex-situ (Gene banks, Cryopreservation) conservation; Earth/World Summits."
      ],
      lessonModules: [],
      practiceGoals: { conceptual: [], numerical: [] }
    },
    {
      id: "practical_work",
      chapterNumber: 6,
      title: "Paper II: Practical Evaluation Work (30 Marks)",
      chapterName: "Practical Evaluation Work",
      topics: ["Core Experiments", "Spotting Exam", "Project & File"],
      subtopics: [
        "Floral dissections/diagrams (Malvaceae, Solanaceae, etc.); in-vitro pollen growth; enzyme activity vs. pH/temp; plant pigment chromatography; mitotic index via Allium cepa root tip squashes; plant DNA spooling.",
        "Identifying 13 permanent slides/specimens (Meiosis stages, mammalian testis/ovary histology, disease pathogens, xerophytic/hydrophytic setups).",
        "Certified research project report and complete laboratory logbook."
      ],
      lessonModules: [],
      practiceGoals: { conceptual: [], numerical: [] }
    }
  ]
};

export const INDIA_CBSE_BIOLOGY_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Biology",
  chapters: [
    {
      id: "sexual_reproduction_plants",
      chapterNumber: 1,
      title: "1. Sexual Reproduction in Flowering Plants",
      chapterName: "Sexual Reproduction in Flowering Plants",
      topics: [
        "Flower Structure & Pre-fertilization Events",
        "Microsporogenesis & Stamen Architecture",
        "Megasporogenesis & Embryo Sac Formation",
        "Pollination Mechanisms, Agents & Adaptations",
        "Outbreeding Devices & Pollen-Pistil Interaction",
        "Double Fertilization & Triple Fusion",
        "Post-Fertilization: Endosperm & Embryo Development",
        "Seed Development, Fruit Formation & Apomixis"
      ],
      subtopics: [
        "Anatomy of flower and reproductive whorls (androecium and gynoecium)",
        "Structure of stamen, microsporangium, and pollen grain development",
        "Pollen viability, allergy, and cryopreservation in pollen banks",
        "Structure of megasporogenesis, ovule types, and female gametophyte (embryo sac)",
        "Autogamy, geitonogamy, and xenogamy pollination mechanisms",
        "Abiotic (wind, water) and biotic (insects, birds, bats) pollinating agents",
        "Contrivances for cross-pollination and self-incompatibility mechanisms",
        "Pollen-pistil interaction, pollen tube growth, and artificial hybridization",
        "Syngamy and triple fusion yielding zygote and primary endosperm nucleus (PEN)",
        "Free-nuclear and cellular endosperm development and nutrition",
        "Dicotyledonous and monocotyledonous embryo development stages",
        "Seed structure, albuminous vs non-albuminous seeds, and seed dormancy",
        "Pericarp development, true fruits, false fruits (apple, strawberry), and parthenocarpy",
        "Apomixis and polyembryony significance in agriculture and hybrid seed industry"
      ],
      lessonModules: [
        {
          title: "Module 1: Pre-Fertilization Structures & Microsporogenesis",
          description: "Stamen structure, microsporangium wall layers, pollen grain architecture (exine sporopollenin & intine cellulose), pollen allergy & viability.",
          duration: "45 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Megasporogenesis & Female Gametophyte Architecture",
          description: "Anatropous ovule anatomical organization, megaspore mother cell meiosis, functional megaspore, 7-celled 8-nucleate Polygonum type embryo sac.",
          duration: "50 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Pollination Dynamics, Outbreeding & Double Fertilization",
          description: "Pollination modes, self-incompatibility, pollen-pistil recognition, filiform apparatus guide, syngamy & triple fusion.",
          duration: "55 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Post-Fertilization, Seed Mechanics & Apomixis",
          description: "Free-nuclear coconut endosperm vs cellular endosperm, dicot/monocot embryogeny, seed structure, apomixis & polyembryony.",
          duration: "50 mins",
          level: "Advanced"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain why 8 nuclei in the female gametophyte of angiosperms are distributed into a 7-celled organization.",
          "Differentiate autogamy, geitonogamy, and xenogamy on genetic and functional grounds.",
          "Analyze the significance of outbreeding devices and self-incompatibility in plant evolution.",
          "Compare apomixis with parthenocarpy and discuss their commercial applications in hybrid seed production."
        ],
        numerical: [
          "Calculate the minimum number of meiotic divisions required to produce 100 viable seeds in a dicotyledonous plant.",
          "Determine the ploidy level of aleurone layer, endosperm, zygote, integuments, and synergids given diploid 2n=24.",
          "Calculate the number of pollen grains and megaspores produced from 50 microspore mother cells and 50 megaspore mother cells."
        ]
      }
    },
    {
      id: "human_reproduction",
      chapterNumber: 2,
      title: "2. Human Reproduction",
      chapterName: "Human Reproduction",
      topics: [
        "Male Reproductive System Anatomy",
        "Female Reproductive System Anatomy",
        "Spermatogenesis & Sperm Structure",
        "Oogenesis & Folliculogenesis",
        "Menstrual Cycle & Hormonal Regulation",
        "Fertilization & Cleavage",
        "Blastocyst Formation & Implantation",
        "Pregnancy, Placenta & Embryonic Development",
        "Parturition & Lactation Mechanics"
      ],
      subtopics: [
        "Testes structure, seminiferous tubules, Sertoli cells, and Leydig interstitial cells",
        "Male accessory ducts (epididymis, vas deferens) and glands (seminal vesicles, prostate)",
        "Ovaries, fallopian tubes (oviducts), uterus, cervix, and vagina histology",
        "Mammary gland structure and hormonal control of lactation",
        "Spermatogenesis stages: spermatogonia, primary/secondary spermatocytes, spermatids, spermiogenesis",
        "Sperm anatomy: head, acrosome, neck, middle piece (mitochondria), and tail",
        "Oogenesis stages: oogonia, primary oocyte arrest, secondary oocyte, and polar bodies",
        "Follicular development: primordial, primary, secondary, tertiary (antrum), and Graafian follicle",
        "Hormonal cascade: GnRH, LH, FSH, estrogen, and progesterone interaction",
        "Menstrual cycle phases: menstrual, follicular/proliferative, ovulatory surge, and luteal/secretory",
        "Capacitation, acrosomal reaction, cortical reaction, and prevention of polyspermy",
        "Morula, blastocyst inner cell mass, trophoblast, and implantation in endometrium",
        "Placenta formation, chorionic villi, and placental hormones (hCG, hPL, estrogen, progesterone, relaxin)",
        "Gastrulation, germ layer differentiation (ectoderm, mesoderm, endoderm), and organogenesis",
        "Parturition reflexes (fetal ejection reflex, oxytocin stimulation) and colostrum benefits"
      ],
      lessonModules: [
        {
          title: "Module 1: Male & Female Reproductive Histology & Anatomy",
          description: "Seminiferous tubules, interstitial Leydig cells, Sertoli nurse cells, ovarian follicles, uterine wall endometrium layers.",
          duration: "50 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Gametogenesis: Spermatogenesis vs Oogenesis",
          description: "Comparison of mitotic phase, meiotic arrests (prophase-I dictyotene stage & metaphase-II arrest), polar body formation, and spermiogenesis.",
          duration: "55 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Hormonal Cascade & Menstrual Cycle Phases",
          description: "Pituitary LH/FSH surge, ovarian estrogen and corpus luteum progesterone feedback loop, endometrial proliferation and breakdown.",
          duration: "60 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Fertilization, Implantation & Gestation Endocrinology",
          description: "Acrosome reaction, fast/slow block to polyspermy, blastocyst implantation, placental hCG, hPL, relaxin, oxytocin fetal ejection reflex.",
          duration: "50 mins",
          level: "Advanced"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain the physiological rationale behind LH surge causing ovulation during day 14 of the human menstrual cycle.",
          "Describe the mechanism preventing polyspermy during human fertilization at the zona pellucida level.",
          "Differentiate between primary spermatocytes and secondary spermatocytes regarding chromosome number and DNA content.",
          "Detail the endocrine role of the placenta during gestation and contrast hCG with progesterone functions."
        ],
        numerical: [
          "Calculate the total number of functional sperms and functional ova produced from 100 primary spermatocytes and 100 primary oocytes.",
          "Determine the chromosome count and chromatid count at Metaphase-I, Metaphase-II, and telophase stages of human gametogenesis.",
          "Calculate the expected duration of the luteal phase in a standardized 28-day vs a 35-day human menstrual cycle."
        ]
      }
    },
    {
      id: "reproductive_health",
      chapterNumber: 3,
      title: "3. Reproductive Health",
      chapterName: "Reproductive Health",
      topics: [
        "Reproductive Health Problems & National Strategies",
        "Population Explosion & Birth Control Methods",
        "Contraceptive Measures & Mechanism of Action",
        "Medical Termination of Pregnancy (MTP)",
        "Sexually Transmitted Infections (STIs)",
        "Infertility & Assisted Reproductive Technologies (ART)"
      ],
      subtopics: [
        "Reproductive and Child Health Care (RCH) programmes and awareness goals",
        "Amniocentesis technique, legal bans, and detection of chromosomal abnormalities",
        "Demographic trends, population explosion causes, and urbanization impacts",
        "Natural birth control: periodic abstinence, coitus interruptus, and lactational amenorrhea",
        "Barrier methods: condoms, diaphragms, cervical caps, and spermicidal jellies",
        "Intrauterine Devices (IUDs): non-medicated, copper-releasing (CuT, Cu7, Multiload 375), and hormone-releasing (Progestasert, LNG-20)",
        "Oral contraceptives: combined pills, mini-pills, and Saheli (non-steroidal once-a-week pill)",
        "Injectables, implants, emergency contraceptives, and surgical sterilization (vasectomy & tubectomy)",
        "MTP Act provisions, safety timelines, and ethical/social considerations",
        "STIs transmission: Gonorrhea, Syphilis, Genital Herpes, Chlamydiasis, Hepatitis-B, and Trichomoniasis",
        "Infertility etiologies in males and females",
        "In Vitro Fertilization (IVF) and Embryo Transfer (ET: ZIFT, IUT)",
        "Gamete Intra-Fallopian Transfer (GIFT) and Intra-Cytoplasmic Sperm Injection (ICSI)",
        "Intra-Uterine Insemination (IUI) and artificial insemination procedures"
      ],
      lessonModules: [
        {
          title: "Module 1: Population Demographics & Natural Contraceptive Methods",
          description: "RCH goals, amniocentesis ethics, demographic indicators, rhythmic periodic abstinence, lactational amenorrhea window.",
          duration: "40 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Medical Contraceptives & Sterilization Techniques",
          description: "Copper-releasing vs hormone-releasing IUDs mechanism, Saheli non-steroidal SERM mechanism, vasectomy and tubectomy efficacy.",
          duration: "45 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: STIs, MTP Act & Reproductive Epidemiology",
          description: "Bacterial, viral and protozoan STIs, early diagnosis, MTP Act 2017 amendments, legal safety limits and ethical safeguards.",
          duration: "45 mins",
          level: "Intermediate"
        },
        {
          title: "Module 4: Infertility Management & Assisted Reproductive Technologies (ART)",
          description: "IVF-ET, ZIFT (zygote intrafallopian transfer), IUT (intrauterine transfer), GIFT, ICSI, and IUI application protocols.",
          duration: "50 mins",
          level: "Advanced"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Evaluate why hormone-releasing IUDs like LNG-20 are considered highly effective in preventing both fertilization and implantation.",
          "Distinguish between ZIFT and IUT based on embryo blastomere stage during embryo transfer.",
          "Analyze the biological mechanisms behind lactational amenorrhea and its natural limitation timeframe.",
          "Explain the principle and clinical process of Intra-Cytoplasmic Sperm Injection (ICSI) for low sperm count cases."
        ],
        numerical: [
          "Calculate birth rate, death rate, and growth rate per 1000 individuals given population demographic change data.",
          "Determine the failure rate (Pearl Index equivalent) comparing barrier vs hormonal contraceptive options in demographic scenarios.",
          "Calculate the blastomere threshold (8-cell limit) for choosing ZIFT versus IUT in IVF clinical workflows."
        ]
      }
    },
    {
      id: "principles_inheritance",
      chapterNumber: 4,
      title: "4. Principles of Inheritance and Variation",
      chapterName: "Principles of Inheritance and Variation",
      topics: [
        "Mendel's Laws of Inheritance & Monohybrid Cross",
        "Dihybrid Cross & Law of Independent Assortment",
        "Incomplete Dominance, Co-dominance & Multiple Alleles",
        "Pleiotropy & Polygenic Inheritance",
        "Chromosomal Theory of Inheritance & Linkage",
        "Sex Determination Systems in Organisms",
        "Mutation Types & Pedigree Analysis",
        "Mendelian & Chromosomal Genetic Disorders"
      ],
      subtopics: [
        "Gregor Mendel's experiments on Pisum sativum and monohybrid cross analysis",
        "Law of Dominance, Law of Segregation, Punnett square, and test cross ratio",
        "Dihybrid cross, phenotypic (9:3:3:1) and genotypic ratios, and Law of Independent Assortment",
        "Incomplete dominance in Antirrhinum majus (Snapdragon) and 1:2:1 phenotypic ratio",
        "Co-dominance in ABO blood grouping and human erythrocyte antigen expression",
        "Multiple allelism (IA, IB, i) and starch synthesis gene expression in pea seeds",
        "Polygenic inheritance (human skin color) and pleiotropy (Phenylketonuria, sickle-cell trait)",
        "Sutton and Boveri's Chromosomal Theory of Inheritance and experimental proof by T.H. Morgan",
        "Morgan's Drosophila experiments, linkage groups, recombinant frequency, and chromosome mapping by Alfred Sturtevant",
        "Sex determination mechanisms: XX-XO (grasshopper), XX-XY (human/Drosophila), ZZ-ZW (birds), and haplodiploidy (honey bees)",
        "Gene mutation, frame-shift, substitution, and chromosomal aberrations",
        "Pedigree analysis symbols, autosomal dominant/recessive, and sex-linked inheritance traits",
        "Mendelian disorders: Haemophilia, Sickle-cell anemia, Phenylketonuria, Thalassemia, and Cystic Fibrosis",
        "Chromosomal disorders: Down's syndrome (Trisomy 21), Klinefelter's syndrome (47, XXY), and Turner's syndrome (45, XO)"
      ],
      lessonModules: [
        {
          title: "Module 1: Mendelian Genetics & Monohybrid/Dihybrid Ratios",
          description: "Mendel's laws, Punnett square analysis, test cross principles, 3:1 monohybrid & 9:3:3:1 dihybrid cross probability calculations.",
          duration: "55 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Non-Mendelian Inheritance & Gene Interactions",
          description: "Incomplete dominance (1:2:1), co-dominance in ABO blood grouping, multiple alleles, pleiotropy vs polygenic inheritance.",
          duration: "50 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Chromosomal Theory, Linkage & Recombination Mapping",
          description: "Sutton-Boveri hypothesis, T.H. Morgan Drosophila linkage experiments, parental vs recombinant frequencies, genetic map units (centiMorgans).",
          duration: "60 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Pedigree Analysis, Sex Determination & Genetic Disorders",
          description: "Pedigree symbol decoding, autosomal vs X-linked inheritance, Down's, Klinefelter's, Turner's syndromes and point mutations.",
          duration: "55 mins",
          level: "Advanced"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain why T.H. Morgan chose Drosophila melanogaster for his experimental linkage studies.",
          "Differentiate between complete linkage and incomplete linkage using F2 offspring phenotypic ratios.",
          "Formulate rules to identify Autosomal Dominant, Autosomal Recessive, and X-Linked Recessive traits in human pedigrees.",
          "Contrast the genetic etiology and clinical manifestations of Thalassemia with Sickle-cell anemia."
        ],
        numerical: [
          "Calculate recombinant frequency percentage and distance in map units (cM) given parental and recombinant offspring counts.",
          "Determine the probability of a child inheriting hemophilia or color blindness from a carrier mother and normal/affected father.",
          "Calculate the number of gamete types and offspring genotypes produced in a trihybrid cross AaBbCc x AaBbCc.",
          "Determine the phenotypic and genotypic ratios expected in a test cross of a plant heterozygous for two independently assorting genes."
        ]
      }
    },
    {
      id: "molecular_basis_inheritance",
      chapterNumber: 5,
      title: "5. Molecular Basis of Inheritance",
      chapterName: "Molecular Basis of Inheritance",
      topics: [
        "DNA Structure, Nucleosome & Chromatin Packaging",
        "Search for Genetic Material: Transforming Principle & Hershey-Chase",
        "RNA World Hypothesis & Types of RNA",
        "DNA Replication Mechanism & Meselson-Stahl Experiment",
        "Transcription Unit, RNA Polymerases & Post-Transcriptional Processing",
        "Genetic Code Characteristics & tRNA Adaptor Molecule",
        "Translation & Protein Synthesis Machinery",
        "Regulation of Gene Expression: Lac Operon",
        "Human Genome Project (HGP) & DNA Fingerprinting"
      ],
      subtopics: [
        "Polynucleotide chain structure, 5' to 3' polarity, phosphodiester and hydrogen bonding",
        "Watson-Crick B-DNA double helix model, Chargaff's rules, and pitch measurement",
        "Packaging of DNA in prokaryotes and eukaryotes: histones, nucleosomes, euchromatin, and heterochromatin",
        "Griffith's transformation experiment with Streptococcus pneumoniae (S-strain and R-strain)",
        "Avery, MacLeod, and McCarty biochemical characterization of transforming principle",
        "Hershey and Chase bacteriophage experiment using 35S and 32P radioactive isotopes",
        "RNA as first genetic material, catalytic RNA (ribozymes), mRNA, tRNA, and rRNA functions",
        "Semiconservative replication proof by Meselson and Stahl using 15N/14N and CsCl density gradient",
        "Replication fork, origin of replication, DNA polymerase III, leading/lagging strands, and Okazaki fragments",
        "Transcription unit: promoter, structural gene, terminator, and template vs coding strand",
        "Transcription in prokaryotes vs eukaryotes: RNA Polymerases I, II, III, introns, exons, splicing, capping, and tailing",
        "Genetic code properties: triplet, degenerate, unambiguous, non-overlapping, universal, and AUG dual function",
        "tRNA secondary clover-leaf and tertiary L-shaped structure, anticodon loop, and amino acid acceptor end",
        "Translation process: aminoacylation of tRNA, ribosome assembly, initiation, elongation, peptide bond, and termination",
        "Jacob and Monod Lac Operon model: regulatory gene (i), promoter (p), operator (o), structural genes (z, y, a), and allolactose inducer",
        "Human Genome Project goals, methodology (ESTs & Sequence Annotation), key findings, and applications",
        "DNA Fingerprinting principles: VNTRs, satellite DNA, restriction digestion, Southern blotting, and PCR amplification"
      ],
      lessonModules: [
        {
          title: "Module 1: Nucleic Acid Architecture & Chromatin Packaging",
          description: "DNA double helix geometry, Chargaff's rules, histone octamer structure, 200 bp nucleosome core, euchromatin vs heterochromatin.",
          duration: "50 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Historical Proofs of Genetic Material & Replication Mechanics",
          description: "Griffith, Avery-MacLeod-McCarty, Hershey-Chase, Meselson-Stahl 15N/14N experiment, replication fork enzymes.",
          duration: "55 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Transcription, RNA Processing & The Genetic Code",
          description: "Prokaryotic vs eukaryotic transcription, hnRNA 5'-capping, 3'-polyadenylation, splicing, degenerate genetic code, tRNA wobble hypothesis.",
          duration: "60 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Translation, Lac Operon Regulation & DNA Fingerprinting",
          description: "Ribosomal P and A sites, peptidyl transferase, Lac Operon negative/inducible regulation, VNTR loci & Southern blot DNA profiling.",
          duration: "60 mins",
          level: "Advanced"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain why DNA replication proceeds strictly in the 5' to 3' direction, leading to continuous and discontinuous strand synthesis.",
          "Compare the transcription process in prokaryotes and eukaryotes, highlighting RNA polymerases and post-transcriptional processing.",
          "Describe how the Lac Operon functions under presence and absence of lactose (allolactose inducer).",
          "Discuss the biochemical basis of DNA fingerprinting using Variable Number of Tandem Repeats (VNTRs)."
        ],
        numerical: [
          "Calculate the length of double-stranded DNA in meters given a total genome size of 6.6 x 10⁹ base pairs (base pair distance 0.34 nm).",
          "Apply Chargaff's rule: if adenine constitutes 20% of DNA bases, calculate the percentages of guanine, cytosine, and thymine.",
          "Determine the heavy (15N-15N), hybrid (15N-14N), and light (14N-14N) DNA ratio after 1, 2, and 3 generations of Meselson-Stahl replication.",
          "Calculate the number of amino acids in a polypeptide chain encoded by an mRNA sequence of 303 nucleotides, accounting for initiation and stop codons."
        ]
      }
    },
    {
      id: "evolution",
      chapterNumber: 6,
      title: "6. Evolution",
      chapterName: "Evolution",
      topics: [
        "Origin of Life & Chemical Evolution Theory",
        "Miller-Urey Experiment & Prebiotic Earth",
        "Evidences of Evolution: Morphological, Anatomical & Embryological",
        "Palaeontological Evidence & Fossil Records",
        "Adaptive Radiation & Convergent Evolution",
        "Biological Evolution: Lamarckism vs Darwinism",
        "Mechanism of Evolution: Mutation Theory & Natural Selection",
        "Hardy-Weinberg Principle & Evolutionary Forces",
        "Geological Time Scale & Evolutionary History",
        "Origin and Evolution of Humans"
      ],
      subtopics: [
        "Big Bang theory, stellar evolution, and primitive Earth conditions (reducing atmosphere)",
        "Oparin-Haldane hypothesis of abiogenesis and chemical evolution of macromolecules",
        "Miller-Urey spark discharge apparatus experiment synthesizing amino acids",
        "Homologous organs, divergent evolution (forelimbs of mammals, bougainvillea thorn vs cucurbita tendril)",
        "Analogous organs, convergent evolution (wings of butterfly and bird, sweet potato and potato)",
        "Biochemical evidences, vestigial organs, and embryological evidence (Karl Ernst von Baer critique of Haeckel)",
        "Adaptive radiation in Darwin's finches and Australian marsupials",
        "Industrial melanism in Biston betularia and drug/pesticide resistance as anthropogenic selection",
        "Lamarckism (use and disuse of organs) vs Darwin's Theory of Natural Selection (survival of the fittest)",
        "Hugo de Vries Mutation Theory: saltation (single step large mutation) vs Darwinian gradual variation",
        "Hardy-Weinberg equilibrium equation (p² + 2pq + q² = 1) and factors affecting it (gene flow, genetic drift, mutation, recombination, natural selection)",
        "Types of natural selection: stabilizing, directional, and disruptive selection",
        "Genetic drift: Founder effect and Bottleneck effect",
        "Geological time scale eras (Palaeozoic, Mesozoic, Cenozoic), periods, and evolution of plants and vertebrates",
        "Human evolutionary lineage: Dryopithecus, Ramapithecus, Australopithecus, Homo habilis, Homo erectus, Neanderthal man, and Homo sapiens"
      ],
      lessonModules: [
        {
          title: "Module 1: Prebiotic Earth & Miller-Urey Chemical Evolution",
          description: "Oparin-Haldane abiogenesis hypothesis, spark discharge experiment conditions (CH4, NH3, H2, H2O vapor at 800°C), coacervates.",
          duration: "45 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Morphological, Anatomical & Adaptive Radiation Evidences",
          description: "Homology vs analogy, divergent vs convergent evolution, Darwin's Galapagos finches & Australian marsupial radiations.",
          duration: "50 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Evolutionary Theories & Hardy-Weinberg Population Genetics",
          description: "Darwinian fitness, Hugo de Vries saltation, Hardy-Weinberg equilibrium p² + 2pq + q² = 1, stabilizing, directional & disruptive selection.",
          duration: "60 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Geological Epochs & Human Evolutionary Lineage",
          description: "Geological eras, fossil hominid traits: Dryopithecus, Ramapithecus, Australopithecus (brain capacity 500cc), H. habilis (650-800cc), H. erectus (900cc), Neanderthal (1400cc).",
          duration: "55 mins",
          level: "Advanced"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Contrast homologous organs with analogous organs, giving anatomical examples from plants and animals.",
          "Explain how industrial melanism in peppered moths demonstrates natural selection in response to anthropogenic environmental changes.",
          "Describe the key factors that disrupt Hardy-Weinberg equilibrium in a natural biological population.",
          "Trace the cranial capacity progression and major cultural milestones across human ancestors from Homo habilis to Homo sapiens."
        ],
        numerical: [
          "Calculate allele frequencies p and q in a population of 1000 individuals given 360 AA, 480 Aa, and 160 aa genotypes.",
          "Determine the expected number of carrier heterozygous individuals in a Hardy-Weinberg population where the recessive allele frequency q = 0.2.",
          "Calculate the change in allele frequency resulting from a genetic drift event reducing population size from 10,000 to 50 individuals."
        ]
      }
    },
    {
      id: "human_health_disease",
      chapterNumber: 7,
      title: "7. Human Health and Disease",
      chapterName: "Human Health and Disease",
      topics: [
        "Bacterial, Viral & Protozoan Human Diseases",
        "Fungal & Helminthic Infections in Humans",
        "Innate & Acquired Immunity Systems",
        "Humoral vs Cell-Mediated Immune Responses",
        "Active & Passive Immunity, Vaccines & Immunization",
        "Allergies, Autoimmunity & Immune System Organs",
        "AIDS & Human Immunodeficiency Virus (HIV)",
        "Cancer Causes, Diagnosis & Treatment Therapies",
        "Drugs, Alcohol & Opioid/Cannabinoid Abuse"
      ],
      subtopics: [
        "Typhoid (Salmonella typhi, Widal test) and Pneumonia (Streptococcus pneumoniae, Haemophilus influenzae)",
        "Common Cold (Rhinovirus) symptoms and transmission mode",
        "Malaria (Plasmodium vivax/falciparum life cycle in human and Female Anopheles mosquito)",
        "Amoebiasis (Entamoeba histolytica) symptoms and mechanical vectors",
        "Ringworm (Microsporum, Trichophyton, Epidermophyton) fungal conditions",
        "Ascariasis (Ascaris lumbricoides) and Filariasis/Elephantiasis (Wuchereria bancrofti/malayi)",
        "Innate immunity barriers: physical (skin, mucus), physiological (acid, tears), cellular (PMNL, macrophages), and cytokine (interferons)",
        "Acquired immunity characteristics: memory, specificity, B-lymphocytes, and T-lymphocytes",
        "Antibody (Immunoglobulin) structure: light and heavy chains (H₂L₂), IgG, IgA, IgM, IgE, IgD",
        "Humoral immune response vs Cell-Mediated Immunity (CMI) in organ graft rejection",
        "Active vs passive immunity, colostrum IgA protection, and antivenom administration",
        "Allergies mechanism, histamine/serotonin release, mast cells, and anti-histamine treatment",
        "Autoimmune diseases (Rheumatoid arthritis) etiology and tissue self-destruction",
        "Primary lymphoid organs (bone marrow, thymus) and secondary lymphoid organs (spleen, lymph nodes, MALT)",
        "AIDS etiology (HIV retrovirus), reverse transcriptase, infection of helper T-cells, diagnosis (ELISA), and prevention",
        "Cancer benign vs malignant tumors, contact inhibition loss, metastasis, oncogenes, carcinogens, detection (MRI, CT, biopsy), and therapies (chemo, radio, immunotherapy)",
        "Opioids (morphine, heroin/smack, diacetylmorphine), Cannabinoids (marijuana, hashish, charas, ganja), and Coca alkaloids (cocaine, crack)",
        "Hallucinogens (Atropa belladonna, Datura, LSD), tobacco/nicotine addiction, and adolescent abuse prevention"
      ],
      lessonModules: [
        {
          title: "Module 1: Pathogens, Vector Borne Diseases & Life Cycles",
          description: "Typhoid, pneumonia, Plasmodium lifecycle (sporozoite stage in mosquito salivary glands, merozoite schizogony in liver/RBCs), elephantiasis.",
          duration: "50 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Innate & Acquired Immunology, Antibody Structure",
          description: "Innate 4 barriers, H2L2 immunoglobulin structure, IgG, IgA colostrum passive transfer, cell-mediated graft rejection.",
          duration: "55 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: AIDS Pathogenesis & Oncology (Cancer Biology)",
          description: "HIV retroviral reverse transcription in CD4+ helper T-cells, ELISA test, oncogenic transformation, metastasis, CT/MRI diagnostics.",
          duration: "55 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Neuropharmacology: Drugs, Alcohol & Substance Abuse",
          description: "Opioid CNS receptors, Cannabinoid brain receptors, Erythroxylum coca dopamine transport interference, LSD hallucinogens.",
          duration: "45 mins",
          level: "Intermediate"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Diagram the life cycle of Plasmodium vivax, clearly delineating sexual reproduction in mosquito host and asexual reproduction in human host.",
          "Differentiate between Humoral Immunity and Cell-Mediated Immunity, explaining why CMI is responsible for organ transplant rejection.",
          "Explain the retroviral replication cycle of HIV inside human T-helper cells and why it causes immunodeficiency.",
          "Distinguish benign tumors from malignant tumors, highlighting loss of contact inhibition and metastasis."
        ],
        numerical: [
          "Calculate the proportion of helper T-cell decline per microliter of blood over time in an AIDS patient scenario.",
          "Determine antibody molecular weight based on heavy chain (50 kDa each) and light chain (25 kDa each) composition in an H₂L₂ monomer.",
          "Calculate false positive and false negative rate estimations in ELISA vs Western Blot diagnostic testing workflows."
        ]
      }
    },
    {
      id: "microbes_human_welfare",
      chapterNumber: 8,
      title: "8. Microbes in Human Welfare",
      chapterName: "Microbes in Human Welfare",
      topics: [
        "Microbes in Household Products & Fermentation",
        "Microbes in Industrial Products & Bioactive Molecules",
        "Microbes in Sewage Treatment Plants (STPs)",
        "Microbes in Biogas Plant Production",
        "Microbes as Biocontrol Agents",
        "Microbes as Biofertilizers in Agriculture"
      ],
      subtopics: [
        "Lactic Acid Bacteria (LAB) in milk curdling, vitamin B12 enhancement, and stomach pathogen check",
        "Baker's yeast (Saccharomyces cerevisiae) in bread making and Toddy drink fermentation",
        "Cheese varieties: Swiss cheese (Propionibacterium shermanii) and Roquefort cheese (fungus)",
        "Fermented beverages: malted cereals, fruit juices, distilled (whisky, brandy, rum) vs non-distilled (wine, beer)",
        "Antibiotics discovery: Alexander Fleming, Penicillium notatum, Howard Florey, and Ernst Chain",
        "Industrial organic acid producers: Aspergillus niger (citric acid), Acetobacter aceti (acetic acid), Clostridium butylicum (butyric acid), Lactobacillus (lactic acid)",
        "Enzyme production: Lipases (detergents), Pectinases/Proteases (bottled juice clarification), Streptokinase (Streptococcus, clot buster)",
        "Bioactive molecules: Cyclosporin A (Trichoderma polysporum, immunosuppressant) and Statins (Monascus purpureus, blood cholesterol lowering)",
        "Sewage treatment primary (physical filtration & sedimentation) vs secondary (biological aeration tanks, flocs, BOD calculation)",
        "Anaerobic sludge digesters, biogas production (methane, H2S, CO2), and effluent discharge",
        "Biogas plant structure (concrete tank, floating cover) and methanogenic bacteria (Methanobacterium) role",
        "Biological pest control: Ladybird beetle (aphids), Dragonflies (mosquitoes), Bacillus thuringiensis (Bt cotton/spores), Trichoderma fungus, and Baculoviruses (Nucleopolyhedrovirus)",
        "Biofertilizer microorganisms: Rhizobium (legume symbiosis), Azospirillum, Azotobacter (free-living nitrogen fixers)",
        "Mycorrhiza (Glomus fungal association, phosphorus absorption) and Cyanobacteria (Anabaena, Nostoc, Oscillatoria in paddy fields)"
      ],
      lessonModules: [
        {
          title: "Module 1: Household Fermentation & Industrial Fermenters",
          description: "LAB curd conversion, yeast dough rising, fermented beverages, antibiotics history, citric acid and lipase production.",
          duration: "45 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Bioactive Metabolites & Sewage Treatment Bio-Process",
          description: "Cyclosporin A, statins, streptokinase, primary settling vs secondary biological aeration tanks, BOD determination & flocs.",
          duration: "50 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Biogas Digestion & Methanogenic Ecosystems",
          description: "Biogas concrete tank floating cover mechanics, Methanobacterium anaerobic digestion producing CH4, H2S, CO2.",
          duration: "40 mins",
          level: "Intermediate"
        },
        {
          title: "Module 4: Biocontrol Agents & Biofertilizer Symbiosis",
          description: "Bacillus thuringiensis, Nucleopolyhedrovirus, Glomus mycorrhizae phosphorus mobilization, Rhizobium & cyanobacteria.",
          duration: "45 mins",
          level: "Intermediate"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Differentiate between primary and secondary sewage treatment, emphasizing the role of microbial flocs in reducing Biological Oxygen Demand (BOD).",
          "Explain the physiological mechanism of Statins from Monascus purpureus in lowering blood cholesterol levels.",
          "Describe why Baculoviruses (Nucleopolyhedrovirus) are ideal biocontrol agents in Integrated Pest Management (IPM) programs.",
          "Contrast the nitrogen-fixing mechanisms of symbiotic Rhizobium with free-living Azotobacter and cyanobacteria."
        ],
        numerical: [
          "Calculate the percentage reduction in Biological Oxygen Demand (BOD) across primary settling and secondary aeration stages.",
          "Determine the biogas yield volume (cubic meters) produced per ton of cattle dung processed in anaerobic methanogenic digesters."
        ]
      }
    },
    {
      id: "biotechnology_principles",
      chapterNumber: 9,
      title: "9. Biotechnology: Principles and Processes",
      chapterName: "Biotechnology: Principles and Processes",
      topics: [
        "Core Principles of Biotechnology & Genetic Engineering",
        "Restriction Enzymes (Endonucleases) & Cleavage Mechanics",
        "Cloning Vectors: Plasmids, Bacteriophages & Selection",
        "Insertional Inactivation & Selectable Markers",
        "Competent Host Cells & DNA Transformation Methods",
        "Recombinant DNA Technology Process Steps",
        "Polymerase Chain Reaction (PCR) Amplification",
        "Bioreactors & Downstream Processing"
      ],
      subtopics: [
        "Genetic engineering definitions, chemical engineering sterility, and recombinant DNA creation",
        "First recombinant DNA molecule by Stanley Cohen and Herbert Boyer (1972) using Salmonella typhimurium plasmid",
        "Restriction endonucleases vs exonucleases, restriction site recognition, palindromic nucleotide sequences, and sticky ends",
        "EcoRI restriction enzyme isolation, nomenclature, and DNA fragment ligation by DNA ligase",
        "Agarose gel electrophoresis, ethidium bromide staining, UV visualization, and elution process",
        "Cloning vector features: Origin of replication (ori), selectable markers (ampR, tetR), and cloning sites",
        "pBR322 plasmid map, restriction sites (BamHI, SalI, PstI, EcoRI), and insertional inactivation with β-galactosidase (chromogenic substrate)",
        "Vectors for cloning in plants (Agrobacterium tumefaciens Ti plasmid) and animals (Disarmed retroviruses)",
        "Competent host preparation: divalent cation (CaCl₂) treatment, heat shock method, microinjection, and biolistics/gene gun",
        "Isolation of genetic material (DNA) using lysozyme, cellulase, chitinase, RNAse, protease, and chilled ethanol precipitation",
        "Cutting DNA at specific locations, PCR amplification steps: Denaturation (94°C), Annealing (54°C), Extension (72°C) with Taq Polymerase",
        "Insertion of rDNA into host cell and selection of recombinants",
        "Obtaining foreign gene product, continuous culture system, and biomass yield optimization",
        "Bioreactors architecture: Stirred-tank bioreactor and sparged stirred-tank bioreactor parameters (temperature, pH, aeration, foam control)",
        "Downstream processing components: separation, purification, formulation with preservatives, and clinical quality control trials"
      ],
      lessonModules: [
        {
          title: "Module 1: Restriction Enzymes, Palindromes & Gel Electrophoresis",
          description: "EcoRI recognition site 5'-GAATTC-3', 3'-CTTAAG-5', sticky ends, agarose matrix size separation, ethidium bromide UV visualization.",
          duration: "50 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Plasmid Vector Architecture & Selection Strategies",
          description: "pBR322 ori control, ampR/tetR selectable markers, insertional inactivation, chromogenic X-gal blue/white screening.",
          duration: "55 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Transformation Techniques & PCR Amplification Cycle",
          description: "CaCl2 heat shock 42°C, biolistic gene gun, microinjection, PCR denaturation 94°C, annealing 54°C, Taq extension 72°C.",
          duration: "55 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Bioreactor Engineering & Downstream Processing",
          description: "Stirred-tank vs sparged bioreactor impeller aeration, pH control, foam control, cell lysis, downstream isolation & formulation.",
          duration: "50 mins",
          level: "Advanced"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain why palindromic nucleotide sequences are necessary for restriction endonuclease action.",
          "Compare insertional inactivation using antibiotic resistance genes vs beta-galactosidase chromogenic substrate screening.",
          "Detail the temperature profile and enzymatic reaction conditions for each of the three steps in PCR.",
          "Describe the components and operational parameters of a stirred-tank bioreactor vs a sparged stirred-tank bioreactor."
        ],
        numerical: [
          "Calculate the total number of DNA copies synthesized after 30 cycles of PCR amplification starting from a single target template molecule.",
          "Determine the gel migration distance ratio of 1 kb vs 5 kb DNA fragments on a 1% agarose gel based on logarithmic molecular weight separation.",
          "Calculate bioreactor oxygen transfer rate and doubling time for a recombinant bacterial population expanding exponentially."
        ]
      }
    },
    {
      id: "biotechnology_applications",
      chapterNumber: 10,
      title: "10. Biotechnology and its Applications",
      chapterName: "Biotechnology and its Applications",
      topics: [
        "Biotechnology Applications in Agriculture & Transgenic Crops",
        "Bt Cotton & Pest Resistance Mechanisms",
        "RNA Interference (RNAi) & Nematode Protection",
        "Biotechnology Applications in Medicine & Genetically Engineered Insulin",
        "Gene Therapy & Adenosine Deaminase (ADA) Deficiency",
        "Molecular Diagnosis: PCR, ELISA & Recombinant Probes",
        "Transgenic Animals & Model Organisms",
        "Ethical Issues, GEAC, Biopiracy & Patent Policies"
      ],
      subtopics: [
        "Green Revolution limitations, agrochemical hazards, and Genetically Modified Organisms (GMOs) benefits",
        "Bacillus thuringiensis cry genes (cryIAc, cryIIAb, cryIAb), protoxin activation in alkaline insect gut, and bollworm/corn borer control",
        "Pest resistant plants: RNA interference (RNAi) gene silencing mechanism using Agrobacterium vectors against Meloidegyne incognita nematode",
        "Genetically Engineered Insulin production by Eli Lilly (1983): A and B chains synthesis in E. coli and disulfide bond linkage",
        "Gene therapy clinical trial (1990) for 4-year-old girl with Adenosine Deaminase (ADA) deficiency using retroviral vector and lymphocyte culture",
        "Molecular diagnostic techniques vs conventional methods: PCR detection of HIV and mutations, ELISA antigen-antibody principle, single-stranded radioactive probes",
        "Transgenic animals definition (mice, rats, rabbits, pigs, sheep, cows, fish)",
        "Uses of transgenic animals: normal physiology/development, disease models (cancer, Alzheimer's), biological products (Rosie cow α-lactalbumin milk, α-1-antitrypsin for emphysema), vaccine safety testing (polio), toxicity testing",
        "Genetic Engineering Approval Committee (GEAC) regulatory framework and public safety evaluation",
        "Biopiracy cases: Basmati rice patenting controversy, Turmeric, and Neem exploitation",
        "Traditional knowledge protection, Indian Patent Bill amendments, and bio-resources sharing equity"
      ],
      lessonModules: [
        {
          title: "Module 1: Agricultural Biotechnology: Bt Cotton & RNAi",
          description: "Bt protoxin solubilization in alkaline gut pH, midgut epithelial cell lysis, dsRNA mediated RNA interference gene silencing.",
          duration: "55 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Medical Biotechnology: Humulin & ADA Gene Therapy",
          description: "Eli Lilly recombinant insulin A/B chains, disulfide bond assembly, ex-vivo retroviral ADA gene transfection into T-lymphocytes.",
          duration: "55 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Molecular Diagnostics & Transgenic Organisms",
          description: "Recombinant radioactive probes, autoradiography, transgenic Rosie cow alpha-lactalbumin milk, emphysema alpha-1-antitrypsin.",
          duration: "50 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Bioethics, GEAC Regulation & Biopiracy",
          description: "GEAC safety protocols, Basmati rice bio-patenting dispute, neem/turmeric traditional knowledge biopiracy protection.",
          duration: "45 mins",
          level: "Intermediate"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain the activation mechanism of Bt toxin in cotton bollworm midgut and why Bt spores do not kill Bacillus thuringiensis itself.",
          "Describe the steps involved in RNA interference (RNAi) gene silencing targeting Meloidogyne incognita.",
          "Contrast natural pro-insulin processing in human pancreas with Eli Lilly's recombinant production of Humulin in E. coli.",
          "Discuss why lymphocyte-based gene therapy for ADA deficiency requires periodic infusions unless bone marrow stem cells are transfected."
        ],
        numerical: [
          "Calculate recombinant Humulin yield in grams per liter of culture given recombinant E. coli expression rate data.",
          "Determine the protein yield enrichment ratio of human alpha-lactalbumin in transgenic Rosie cow milk (2.4 g/L) versus standard cow milk."
        ]
      }
    },
    {
      id: "organisms_populations",
      chapterNumber: 11,
      title: "11. Organisms and Populations",
      chapterName: "Organisms and Populations",
      topics: [
        "Organism and Environment: Major Abiotic Factors",
        "Responses to Abiotic Factors: Regulators, Conformers & Migration",
        "Adaptations: Morphological, Physiological & Behavioral",
        "Population Attributes: Density, Natality, Mortality & Sex Ratio",
        "Population Age Pyramids & Growth Models",
        "Exponential vs Logistic Growth Curves",
        "Population Interactions: Predation, Competition & Parasitism",
        "Commensalism, Mutualism & Amensalism"
      ],
      subtopics: [
        "Major biomes (Tropical rain forest, Desert, Deciduous forest, Sea coast) and climate drivers",
        "Abiotic factors influence: Temperature (eurythermal vs stenothermal), Water (euryhaline vs stenohaline), Light, and Soil features",
        "Organism responses: Regulate (homeostasis), Conform, Migrate (Keoladeo National Park bird migration), and Suspend (diapause, hibernation, aestivation)",
        "Adaptations examples: Kangaroo rat water conservation, Allen's rule in polar mammals, altitude sickness physiological compensation, desert plant CAM pathway",
        "Population attributes: birth rate (natality), death rate (mortality), sex ratio, and age distribution pyramids (expanding, stable, declining)",
        "Population density measurement methods (direct count, percentage cover, fecal pellets, pug marks)",
        "Exponential growth equation (dN/dt = rN) and integral form (Nt = N₀ eʳᵗ) under unlimited resources",
        "Logistic growth equation (dN/dt = rN[(K-N)/K]) and Verhulst-Pearl logistic curve under carrying capacity (K)",
        "Life history variation strategies (r-selected vs K-selected species)",
        "Predation interaction: ecological roles, biological pest control, predator regulation, and prey defenses (monarch butterfly, camouflage)",
        "Competition interaction: Gause's Competitive Exclusion Principle, interference competition, and MacArther's resource partitioning in warblers",
        "Parasitism interaction: ectoparasites, endoparasites, life cycle complexity, host specificity, and brood parasitism in cuckoos",
        "Commensalism examples: Orchid on mango branch, barnacles on whale, cattle egret and grazing cattle, sea anemone and clown fish",
        "Mutualism examples: Lichens (fungus + alga), Mycorrhizae, fig tree and wasp co-evolution, pseudocopulation in Ophrys orchid and bee"
      ],
      lessonModules: [
        {
          title: "Module 1: Environmental Abiotic Drivers & Organismal Adaptation",
          description: "Thermal eurythermal vs stenothermal thresholds, Allen's rule, altitude sickness acclimatization, CAM desert adaptations.",
          duration: "50 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Population Metrics & Growth Kinetics Equations",
          description: "Age pyramid profiles, exponential growth Nt = N0 e^rt, logistic growth dN/dt = rN((K-N)/K), carrying capacity K limit.",
          duration: "55 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Interspecific Interactions: Predation, Competition & Parasitism",
          description: "Prickly pear cactus & Cactoblastis moth biocontrol, Gause competitive exclusion principle, MacArthur warbler resource partitioning.",
          duration: "55 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Mutualism Dynamics & Co-Evolutionary Mechanics",
          description: "Orchid pseudocopulation with Colpa wasp, fig-fig wasp obligate mutualism, cuckoo brood parasitism.",
          duration: "45 mins",
          level: "Intermediate"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Differentiate between exponential and logistic growth models, explaining the biological significance of carrying capacity (K).",
          "Explain Gause's Competitive Exclusion Principle and describe how MacArthur's resource partitioning allows coexistence.",
          "Analyze the physiological adaptations shown by human bodies during high-altitude sickness acclimatization.",
          "Describe co-evolutionary relationships in mutualism using the fig tree and wasp example."
        ],
        numerical: [
          "Calculate population density Nt after time t given N0 = 100, intrinsic growth rate r = 0.02, and exponential growth duration t = 10 years.",
          "Determine the intrinsic rate of natural increase (r) given birth rate b = 0.034 and death rate d = 0.014 per capita per year.",
          "Calculate population growth rate dN/dt using logistic equation given N = 500, K = 1000, and r = 0.1."
        ]
      }
    },
    {
      id: "ecosystem",
      chapterNumber: 12,
      title: "12. Ecosystem",
      chapterName: "Ecosystem",
      topics: [
        "Ecosystem Structure, Components & Abiotic-Biotic Dynamics",
        "Primary Productivity & Net Primary Productivity (NPP)",
        "Decomposition Process & Soil Humification/Mineralization",
        "Energy Flow, Trophic Levels & 10 Percent Law",
        "Food Chains, Food Webs & Ecological Pyramids",
        "Ecological Succession: Primary vs Secondary Succession",
        "Hydrarch & Xerarch Plant Succession Stages",
        "Nutrient Cycling (Biogeochemical) & Ecosystem Services"
      ],
      subtopics: [
        "Ecosystem definition, biotic and abiotic components, and pond ecosystem as a self-sustaining microcosm",
        "Primary productivity: Gross Primary Productivity (GPP) vs Net Primary Productivity (NPP = GPP - R) and factors influencing it",
        "Decomposition stages: fragmentation, leaching, catabolism, humification, and mineralization by detritivores",
        "Decomposition rate factors: oxygen availability, temperature, moisture, and chemical composition of detritus (lignin/chitin vs nitrogen)",
        "Energy flow dynamics: Photosynthetically Active Radiation (PAR, 50%), capture efficiency (2-10%), and unidirectional flow",
        "Grazing Food Chain (GFC) vs Detritus Food Chain (DFC) linkages",
        "Trophic level positioning, standing crop biomass measurement, and Lindeman's 10% energy transfer law",
        "Ecological pyramids: Pyramid of Numbers, Pyramid of Biomass (upright vs inverted in sea), and Pyramid of Energy (always upright)",
        "Limitations of ecological pyramids (simple food chain assumption, saprophytes exclusion)",
        "Ecological succession concepts: sere, seral communities, pioneer species, and climax community",
        "Primary succession on bare rock/water vs secondary succession on burned forest/abandoned farmland",
        "Hydrarch succession stages: phytoplankton, submerged, free-floating, reed-swamp, marsh-meadow, scrub, forest climax",
        "Xerarch succession stages: lichens, mosses, annual grasses, perennial herbs, shrubs, mesic forest climax",
        "Nutrient cycling: gaseous (carbon, nitrogen) vs sedimentary (phosphorus) biogeochemical cycles",
        "Carbon cycle reservoir dynamics and human impacts",
        "Phosphorus cycle dynamics, rock weathering, and differences from carbon cycle",
        "Ecosystem services: Robert Costanza valuation studies, oxygen production, pollination, climate regulation, and aesthetic values"
      ],
      lessonModules: [
        {
          title: "Module 1: Productivity Kinetics & Decomposition Cascades",
          description: "Gross vs Net Primary Productivity (NPP = GPP - R), 5 steps of detritus decomposition: fragmentation, leaching, catabolism, humification, mineralization.",
          duration: "50 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Energy Transfer Dynamics & Ecological Pyramids",
          description: "Lindeman 10% energy law, PAR capture (2-10%), inverted biomass pyramid in marine ecosystems, upright energy pyramid.",
          duration: "50 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Seral Succession: Hydrarch vs Xerarch Trajectories",
          description: "Pioneer lichen/phytoplankton colonization, seral stages transition to mesic forest climax community.",
          duration: "55 mins",
          level: "Advanced"
        },
        {
          title: "Module 4: Biogeochemical Cycles & Ecosystem Services",
          description: "Atmospheric carbon cycle vs sedimentary rock weathering phosphorus cycle, Robert Costanza ecosystem service valuation.",
          duration: "45 mins",
          level: "Intermediate"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Differentiate between Gross Primary Productivity (GPP) and Net Primary Productivity (NPP).",
          "Explain why the Pyramid of Energy is always upright, whereas the Pyramid of Biomass in a sea ecosystem can be inverted.",
          "Trace the seral stages of primary succession starting on a bare rock (Xerarch succession).",
          "Compare the carbon cycle (gaseous) with the phosphorus cycle (sedimentary) regarding inputs and reservoirs."
        ],
        numerical: [
          "Calculate energy available at tertiary consumer level (T4) starting from 10,000 Joules of solar energy fixed at producer level (T1) using 10% law.",
          "Calculate Net Primary Productivity (NPP) in kcal/m²/yr given Gross Primary Productivity GPP = 20,000 and Respiration loss R = 8,000.",
          "Determine percent energy loss at each trophic level transition in a 4-step grazing food chain."
        ]
      }
    },
    {
      id: "biodiversity_conservation",
      chapterNumber: 13,
      title: "13. Biodiversity and Conservation",
      chapterName: "Biodiversity and Conservation",
      topics: [
        "Levels of Biodiversity: Genetic, Species & Ecological",
        "Global & Indian Biodiversity Patterns & Gradients",
        "Species-Area Relationship & Alexander von Humboldt Curve",
        "Importance of Biodiversity: Rivet Popper Hypothesis",
        "Loss of Biodiversity & 'The Evil Quartet'",
        "Reasons for Conserving Biodiversity: Narrowly, Broadly & Ethical",
        "In-situ Conservation: National Parks, Sanctuaries & Hotspots",
        "Ex-situ Conservation: Botanical Gardens, Seed Banks & Cryopreservation"
      ],
      subtopics: [
        "Biodiversity term coined by Edward Wilson and 3 levels: Genetic diversity (Rauwolfia vomitoria reserpine potency), Species diversity (Western Ghats amphibians), Ecological diversity (India's biomes)",
        "Global species estimation by Robert May (7 million species) and proportion of insects (>70% animals)",
        "India as 12 megadiversity countries of the world with ~8.1% of global species diversity",
        "Latitudinal gradients in species diversity: high tropical diversity explanations (constant environment, evolutionary time, solar radiation)",
        "Species-Area Relationship equation log S = log C + Z log R by Alexander von Humboldt and Z-value slopes (0.1-0.2 to 0.6-1.2)",
        "Ecosystem stability and species richness correlation (David Tilman experiments)",
        "Rivet Popper Hypothesis by Paul Ehrlich comparing ecosystem species to airplane rivets",
        "IUCN Red List extinction statistics (784 species in last 500 years, Dodo, Quagga, Thylacine, Steller's Sea Cow, 3 tiger subspecies)",
        "The Evil Quartet causes of extinction: 1. Habitat loss and fragmentation (Amazon rain forest 'lungs of the planet'), 2. Over-exploitation (Steller's sea cow, passenger pigeon), 3. Alien species invasions (Nile perch in Lake Victoria, Lantana, Eichhornia, Parthenium), 4. Co-extinctions (co-evolved host-parasite and plant-pollinator)",
        "Narrowly utilitarian reasons (food, medicine, industrial products, bioprospecting)",
        "Broadly utilitarian reasons (20% Amazonian oxygen, pollination, cultural pleasure) and Ethical reasons (stewardship of life)",
        "In-situ conservation: Biosphere Reserves (14 in India), National Parks (90+), Wildlife Sanctuaries (448+), Sacred Groves (Khasi/Jaintia hills Meghalaya, Aravalli Rajasthan, Western Ghats)",
        "Biodiversity Hotspots criteria and 3 hotpots covering India (Western Ghats-Sri Lanka, Indo-Burma, Himalaya)",
        "Ex-situ conservation: Zoological parks, Botanical gardens, Wildlife safari parks, Cryopreservation (-196°C liquid nitrogen) of gametes, In vitro tissue culture, and Seed banks",
        "International conventions: The Earth Summit (Rio de Janeiro, 1992) and World Summit on Sustainable Development (Johannesburg, 2002)"
      ],
      lessonModules: [
        {
          title: "Module 1: Biodiversity Hierarchy & Species Area Curves",
          description: "Genetic, species and ecological diversity, Robert May 7 million global estimation, Alexander von Humboldt log S = log C + Z log A curve.",
          duration: "50 mins",
          level: "Fundamental"
        },
        {
          title: "Module 2: Ecosystem Stability & The Evil Quartet Extinction",
          description: "Tilman long-term plot experiments, Paul Ehrlich Rivet Popper hypothesis, habitat fragmentation, alien invasive Nile perch/Eichhornia.",
          duration: "55 mins",
          level: "Intermediate"
        },
        {
          title: "Module 3: Conservation Utilitarianism & In-situ Protection",
          description: "Narrowly vs broadly utilitarian ecosystem values, Biosphere Reserves, National Parks, Wildlife Sanctuaries, Sacred Groves.",
          duration: "50 mins",
          level: "Intermediate"
        },
        {
          title: "Module 4: Ex-situ Cryopreservation & Global Summit Frameworks",
          description: "Liquid nitrogen -196°C cryopreservation, pollen banks, Earth Summit Rio 1992, World Summit Johannesburg 2002 protocols.",
          duration: "45 mins",
          level: "Advanced"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain the species-area relationship described by Alexander von Humboldt and interpret the significance of Z-values for small vs large continental areas.",
          "Describe 'The Evil Quartet' causes of biodiversity loss with specific real-world species examples.",
          "Contrast in-situ conservation with ex-situ conservation, listing three distinct institutional strategies for each.",
          "Explain Paul Ehrlich's Rivet Popper hypothesis and its implication for ecosystem stability."
        ],
        numerical: [
          "Calculate total estimated species count S using log S = log C + Z log A given C = 10, Z = 0.5, and land area A = 10,000 sq km.",
          "Calculate global insect species count based on Robert May's estimate of 7 million total species (>70% animals, >70% animal species are insects).",
          "Determine species richness proportion contribution of India (~8.1% of global species diversity) relative to land area (2.4% world area)."
        ]
      }
    }
  ]
};

export const INDIA_CBSE_COMPUTER_SCIENCE_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Computer Science",
  chapters: [
    {
      id: "cs_computational_thinking",
      chapterNumber: 1,
      title: "1. Computational Thinking and Programming - 2",
      chapterName: "Python Advanced & File Handling",
      topics: [
        "Python Revision Tour & Functions",
        "Introduction to Files & Text Files",
        "Binary File Handling (Pickle)",
        "CSV File Handling",
        "Data Structures: Stacks"
      ],
      subtopics: [
        "Python basics: data types, mutable/immutable, flow control",
        "Functions: arguments, parameters, scope (LEGB), return values",
        "Text files: open(), close(), read(), write(), append(), with statement",
        "Binary files: Serialization using pickle module (dump/load)",
        "CSV files: Reading and writing using csv.reader/csv.writer",
        "Data structures: Stack operations (Push, Pop) using lists"
      ]
    },
    {
      id: "cs_computer_networks",
      chapterNumber: 2,
      title: "2. Computer Networks",
      chapterName: "Evolution of Networking & Protocols",
      topics: [
        "Evolution of Networking & Types",
        "Network Devices & Topologies",
        "Network Protocols (TCP/IP, HTTP)",
        "Web Services & Security"
      ],
      subtopics: [
        "Evolution: ARPANET, Internet, Interspace",
        "Types: PAN, LAN, MAN, WAN; Topologies: Star, Bus, Tree, Mesh",
        "Devices: Modem, Hub, Switch, Repeater, Router, Gateway",
        "Protocols: TCP/IP, FTP, PPP, HTTP, SMTP, POP3",
        "Security: Firewall, Cookies, Hacking vs Cracking"
      ]
    },
    {
      id: "cs_database_management",
      chapterNumber: 3,
      title: "3. Database Management",
      chapterName: "SQL & Python-SQL Integration",
      topics: [
        "Database Concepts & Keys",
        "SQL: DDL & DML Commands",
        "Aggregate Functions & Joins",
        "Python Integration with SQL"
      ],
      subtopics: [
        "Relational model: Candidate key, Primary key, Alternate key, Foreign key",
        "SQL: SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, ALTER",
        "Clauses: WHERE, GROUP BY, HAVING, ORDER BY",
        "Interface: mysql-connector, connect(), cursor(), execute(), commit()"
      ]
    },
    {
      id: "cs_data_structures",
      chapterNumber: 4,
      title: "4. Data Structures",
      chapterName: "Stack Implementation",
      topics: ["Introduction to Stacks", "Push and Pop Operations", "Implementation using Lists"],
      subtopics: [
        "LIFO principle",
        "Stack operations: Push, Pop, Peek, isEmpty",
        "Python list-based stack implementation"
      ]
    },
    {
      id: "cs_societal_impacts",
      chapterNumber: 5,
      title: "5. Societal Impacts",
      chapterName: "Digital Ethics & Cyber Law",
      topics: ["Digital Footprint", "Cyber Crimes", "IT Act", "E-waste"],
      subtopics: [
        "Netiquettes and communication ethics",
        "Intellectual Property Rights (IPR)",
        "Open Source Software (OSS) vs Proprietary",
        "Prevention of cyber crimes"
      ]
    }
  ]
};

export const INDIA_CBSE_HISTORY_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "History",
  chapters: [
    {
      id: "hist_harappan",
      chapterNumber: 1,
      title: "1. Bricks, Beads and Bones",
      chapterName: "The Harappan Civilisation",
      topics: ["Subsistence Strategies", "Craft Production", "Trade & Communication", "Authority & Decline"],
      subtopics: ["Early vs Mature Harappan", "City planning & drainage", "Agriculture & technology", "Social differences from burials", "Script and seals"]
    },
    {
      id: "hist_early_states",
      chapterNumber: 2,
      title: "2. Kings, Farmers and Towns",
      chapterName: "Early States and Economies",
      topics: ["Mahajanapadas", "Mauryan Empire", "Kingship", "Towns & Trade"],
      subtopics: ["Sixteen Mahajanapadas", "Ashokan inscriptions", "Administrative structure", "Gold and copper coinage", "Land grants and new rural elites"]
    },
    {
      id: "hist_social_histories",
      chapterNumber: 3,
      title: "3. Kinship, Caste and Class",
      chapterName: "Early Societies",
      topics: ["Marriage Rules", "Caste & Varna", "Mahabharata", "Beyond Varna"],
      subtopics: ["Endogamy and Exogamy", "Dharma Sutras & Shastras", "Manusmriti analysis", "Social mobility of Jatis", "Literary sources and social history"]
    },
    {
      id: "hist_cultural_dev",
      chapterNumber: 4,
      title: "4. Thinkers, Beliefs and Buildings",
      chapterName: "Cultural Developments",
      topics: ["Buddhism", "Jainism", "Puranic Hinduism", "Architecture"],
      subtopics: ["Life of Buddha", "Four Noble Truths", "Sanchi Stupa preservation", "Mahayana vs Hinayana", "Avataras of Vishnu"]
    },
    {
      id: "hist_travellers",
      chapterNumber: 5,
      title: "5. Through the Eyes of Travellers",
      chapterName: "Perceptions of Society",
      topics: ["Al-Biruni", "Ibn Battuta", "Francois Bernier"],
      subtopics: ["Kitab-ul-Hind on India", "Rihla and the travel world", "Comparative history with Europe", "Caste and Sati perceptions"]
    },
    {
      id: "hist_bhakti_sufi",
      chapterNumber: 6,
      title: "6. Bhakti-Sufi Traditions",
      chapterName: "Religious Beliefs",
      topics: ["Alvars & Nayanars", "Sufism", "Devotional Paths"],
      subtopics: ["Integration of cults", "Dargahs and Pilgrimage", "Ziyarat and Qawwali", "Teachings of Guru Nanak and Kabir"]
    }
  ]
};

export const INDIA_CBSE_GEOGRAPHY_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Geography",
  chapters: [
    {
      id: "geog_human_nature",
      chapterNumber: 1,
      title: "1. Human Geography: Nature and Scope",
      chapterName: "Nature and Scope",
      topics: ["Nature of Human Geography", "Naturalisation of Humans", "Humanisation of Nature"],
      subtopics: ["Determinism", "Possibilism", "Neo-determinism"]
    },
    {
      id: "geog_world_pop",
      chapterNumber: 2,
      title: "2. The World Population",
      chapterName: "Distribution, Density and Growth",
      topics: ["Density Patterns", "Components of Growth", "Demographic Transition"],
      subtopics: ["Migration types", "Pull and Push factors", "Malthusian theory"]
    },
    {
      id: "geog_human_dev",
      chapterNumber: 3,
      title: "3. Human Development",
      chapterName: "Pillars and Approaches",
      topics: ["HDI Indicators", "Approaches to Development", "International Comparisons"],
      subtopics: ["Equity, Sustainability, Productivity, Empowerment", "Mahbub-ul-Haq contributions"]
    },
    {
      id: "geog_primary",
      chapterNumber: 4,
      title: "4. Primary Activities",
      chapterName: "Agriculture and Mining",
      topics: ["Hunting & Gathering", "Pastoralism", "Agricultural Systems"],
      subtopics: ["Subsistence vs Commercial", "Plantation farming", "Mediterranean agriculture"]
    },
    {
      id: "geog_secondary",
      chapterNumber: 5,
      title: "5. Secondary Activities",
      chapterName: "Manufacturing Industries",
      topics: ["Industry Classification", "Industrial Location", "Modern Manufacturing"],
      subtopics: ["Raw material based", "Market based", "Footloose industries"]
    },
    {
      id: "geog_tertiary",
      chapterNumber: 6,
      title: "6. Tertiary and Quaternary Activities",
      chapterName: "Services and Communication",
      topics: ["Trade & Commerce", "Tourism", "Quaternary Activities"],
      subtopics: ["BPO and KPO", "Digital Divide", "Medical Tourism"]
    }
  ]
};

export const INDIA_CBSE_POLITICAL_SCIENCE_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Political Science",
  chapters: [
    {
      id: "pol_bipolarity",
      chapterNumber: 1,
      title: "1. The End of Bipolarity",
      chapterName: "Soviet Disintegration",
      topics: ["Soviet System", "Gorbachev's Reforms", "Consequences of Disintegration"],
      subtopics: ["Collapse of Berlin Wall", "Shock Therapy", "New entities (CIS)"]
    },
    {
      id: "pol_power_centres",
      chapterNumber: 2,
      title: "2. Contemporary Centres of Power",
      chapterName: "New Centres of Power",
      topics: ["European Union", "ASEAN", "Rise of China"],
      subtopics: ["EU expansion", "ASEAN Way", "China's Open Door Policy"]
    },
    {
      id: "pol_south_asia",
      chapterNumber: 3,
      title: "3. Contemporary South Asia",
      chapterName: "South Asian Politics",
      topics: ["Pakistan & Bangladesh", "Nepal & Sri Lanka", "India-Neighbours Relations"],
      subtopics: ["Democracy vs Military", "Ethnic conflict", "SAARC and SAPTA"]
    },
    {
      id: "pol_int_org",
      chapterNumber: 4,
      title: "4. International Organizations",
      chapterName: "UN and Beyond",
      topics: ["United Nations", "UN Reforms", "Global Agencies"],
      subtopics: ["Security Council reform", "IMF and World Bank", "Human Rights Watch"]
    },
    {
      id: "pol_security",
      chapterNumber: 5,
      title: "5. Security in the Contemporary World",
      chapterName: "Global Security",
      topics: ["Traditional Security", "Non-Traditional Security", "New Threats"],
      subtopics: ["Disarmament", "Human security", "Global poverty and health"]
    },
    {
      id: "pol_env_resources",
      chapterNumber: 6,
      title: "6. Environment and Natural Resources",
      chapterName: "Global Commons",
      topics: ["Environmental Politics", "Common Responsibilities", "Resource Geopolitics"],
      subtopics: ["Kyoto Protocol", "Indigenous rights", "Water wars"]
    },
    {
      id: "pol_globalization",
      chapterNumber: 7,
      title: "7. Globalization",
      chapterName: "Global Integration",
      topics: ["Concept and Causes", "Political & Economic Impacts", "Resistance"],
      subtopics: ["Cultural homogenization", "Digital divide", "WSF (World Social Forum)"]
    }
  ]
};

export const INDIA_CBSE_SOCIOLOGY_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Sociology",
  chapters: [
    {
      id: "soc_demography",
      chapterNumber: 1,
      title: "1. Demographic Structure of Indian Society",
      chapterName: "Demography & India",
      topics: ["Theories of Demography", "Population Growth", "Age Structure", "Sex Ratio"],
      subtopics: ["Malthusian theory", "Demographic Transition theory", "Fertility and Mortality", "Child sex ratio issues"]
    },
    {
      id: "soc_institutions",
      chapterNumber: 2,
      title: "2. Social Institutions: Continuity and Change",
      chapterName: "Caste, Tribe & Family",
      topics: ["Caste System", "Tribal Communities", "Family and Kinship"],
      subtopics: ["Sanskritization and Caste", "Tribal classifications", "Nuclear and Joint family"]
    },
    {
      id: "soc_inequality",
      chapterNumber: 3,
      title: "3. Patterns of Social Inequality and Exclusion",
      chapterName: "Social Stratification",
      topics: ["Social Exclusion", "Dalit Movements", "OBCs", "Adivasi Struggles", "Women's Equality"],
      subtopics: ["Untouchability", "State initiatives", "Gender inequality", "Disability challenges"]
    },
    {
      id: "soc_diversity",
      chapterNumber: 4,
      title: "4. The Challenges of Cultural Diversity",
      chapterName: "Diversity & Integration",
      topics: ["Cultural Diversity", "Communalism", "Secularism", "Regionalism"],
      subtopics: ["Minority rights", "Civil society roles", "Nation-state challenges"]
    },
    {
      id: "soc_structural_change",
      chapterNumber: 5,
      title: "5. Structural Change",
      chapterName: "Colonialism & Urbanization",
      topics: ["Colonialism", "Industrialization", "Urbanization"],
      subtopics: ["British impact on economy", "Rise of new cities", "Plantation economy"]
    },
    {
      id: "soc_cultural_change",
      chapterNumber: 6,
      title: "6. Cultural Change",
      chapterName: "Social Processes",
      topics: ["Sanskritization", "Westernization", "Modernization", "Secularization"],
      subtopics: ["M.N. Srinivas concepts", "Elite westernization", "Religious reforms"]
    },
    {
      id: "soc_rural_society",
      chapterNumber: 7,
      title: "7. Change and Development in Rural Society",
      chapterName: "Rural Transformation",
      topics: ["Agrarian Structure", "Land Reforms", "Green Revolution"],
      subtopics: ["Zamindari abolition", "Impact on classes", "Migrant labour"]
    }
  ]
};

export const INDIA_CBSE_PSYCHOLOGY_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Psychology",
  chapters: [
    {
      id: "psych_variations",
      chapterNumber: 1,
      title: "1. Variations in Psychological Attributes",
      chapterName: "Intelligence & Attributes",
      topics: ["Individual Differences", "Theories of Intelligence", "Assessment"],
      subtopics: ["Psychometric vs Information-processing", "Gardner's Multiple Intelligences", "IQ and Mental Age"]
    },
    {
      id: "psych_personality",
      chapterNumber: 2,
      title: "2. Self and Personality",
      chapterName: "Identity & Personality",
      topics: ["Concept of Self", "Type & Trait Approaches", "Psychodynamic Theory"],
      subtopics: ["Self-esteem and Self-efficacy", "Big Five Model", "Projective techniques"]
    },
    {
      id: "psych_challenges",
      chapterNumber: 3,
      title: "3. Meeting Life Challenges",
      chapterName: "Stress & Coping",
      topics: ["Nature of Stress", "GAS Model", "Coping Strategies"],
      subtopics: ["Eustress vs Distress", "Appraisal theory", "Lifestyle and health"]
    },
    {
      id: "psych_disorders",
      chapterNumber: 4,
      title: "4. Psychological Disorders",
      chapterName: "Abnormality & Classification",
      topics: ["Anxiety Disorders", "Mood Disorders", "Schizophrenia"],
      subtopics: ["DSM and ICD", "Obsessive-compulsive disorder", "Eating disorders"]
    },
    {
      id: "psych_therapy",
      chapterNumber: 5,
      title: "5. Therapeutic Approaches",
      chapterName: "Healing & Psychotherapy",
      topics: ["CBT", "Humanistic Therapy", "Biomedical Therapy"],
      subtopics: ["Client-centred approach", "Behaviour modifications", "Alternative therapies"]
    },
    {
      id: "psych_social",
      chapterNumber: 6,
      title: "6. Attitude and Social Cognition",
      chapterName: "Social Behaviour",
      topics: ["Attitude Formation", "Social Schema", "Prejudice"],
      subtopics: ["Attribution process", "Balance and Cognitive Dissonance", "Stereotypes"]
    }
  ]
};

export const INDIA_CBSE_ECONOMICS_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Economics",
  chapters: [
    {
      id: "econ_macro_intro",
      chapterNumber: 1,
      title: "1. Introduction to Macroeconomics",
      chapterName: "Macro Fundamentals",
      topics: ["Emergence of Macroeconomics", "Great Depression", "Keynesian Economics"],
      subtopics: ["Micro vs Macro", "Capitalist economy features", "Economic agents"]
    },
    {
      id: "econ_national_income",
      chapterNumber: 2,
      title: "2. National Income Accounting",
      chapterName: "National Income",
      topics: ["Circular Flow", "Basic Aggregates", "GDP Calculation"],
      subtopics: ["Value added method", "Income and Expenditure methods", "Real vs Nominal GDP"]
    },
    {
      id: "econ_money_banking",
      chapterNumber: 3,
      title: "3. Money and Banking",
      chapterName: "Financial Systems",
      topics: ["Functions of Money", "Credit Creation", "Central Banking"],
      subtopics: ["M1, M2, M3, M4", "RBI functions", "Repo and Reverse Repo"]
    },
    {
      id: "econ_income_employment",
      chapterNumber: 4,
      title: "4. Determination of Income and Employment",
      chapterName: "Aggregate Demand",
      topics: ["Propensity to Consume", "Investment Multiplier", "Excess Demand"],
      subtopics: ["AD-AS approach", "S-I approach", "Fiscal and Monetary measures"]
    },
    {
      id: "econ_govt_budget",
      chapterNumber: 5,
      title: "5. Government Budget and the Economy",
      chapterName: "Public Finance",
      topics: ["Budget Components", "Revenue & Capital", "Budget Deficits"],
      subtopics: ["Objectives of budget", "Direct and Indirect taxes", "Fiscal policy"]
    },
    {
      id: "econ_bop",
      chapterNumber: 6,
      title: "6. Balance of Payments",
      chapterName: "International Finance",
      topics: ["Current Account", "Capital Account", "Foreign Exchange"],
      subtopics: ["BOP surplus and deficit", "Fixed vs Flexible rates", "Managed floating"]
    },
    {
      id: "econ_india_eve",
      chapterNumber: 7,
      title: "7. Indian Economy on the Eve of Independence",
      chapterName: "Colonial Economy",
      topics: ["Agricultural Sector", "Industrial Sector", "Foreign Trade"],
      subtopics: ["Zamindari system", "Handicraft decline", "Drain of wealth"]
    },
    {
      id: "econ_india_1950_1990",
      chapterNumber: 8,
      title: "8. Indian Economy 1950-1990",
      chapterName: "Planning Era",
      topics: ["Five Year Plans", "Agriculture Reforms", "Industrial Policy"],
      subtopics: ["Land ceiling", "Green revolution", "IPR 1956"]
    },
    {
      id: "econ_lpg",
      chapterNumber: 9,
      title: "9. Liberalisation, Privatisation and Globalisation",
      chapterName: "Economic Reforms",
      topics: ["1991 Crisis", "Reform Policies", "Globalisation Impact"],
      subtopics: ["Financial sector reforms", "Tax reforms", "WTO"]
    },
    {
      id: "econ_human_capital",
      chapterNumber: 10,
      title: "10. Human Capital Formation in India",
      chapterName: "Human Resources",
      topics: ["Sources of Human Capital", "Education Sector", "Economic Growth"],
      subtopics: ["Health and migration", "Right to Education", "Gender equity"]
    },
    {
      id: "econ_rural_dev",
      chapterNumber: 11,
      title: "11. Rural Development",
      chapterName: "Rural Transformation",
      topics: ["Rural Credit", "Agricultural Marketing", "Organic Farming"],
      subtopics: ["SHGs and Microcredit", "Diversification", "Sustainable livelihood"]
    },
    {
      id: "econ_employment",
      chapterNumber: 12,
      title: "12. Employment: Growth, Informalisation and Other Issues",
      chapterName: "Workforce",
      topics: ["Workforce Participation", "Informalisation", "Unemployment"],
      subtopics: ["Casualisation", "MGNREGA", "Labour force indicators"]
    },
    {
      id: "econ_sustainable",
      chapterNumber: 13,
      title: "13. Sustainable Economic Development",
      chapterName: "Environment",
      topics: ["Environmental Functions", "Global Warming", "Sustainable Strategies"],
      subtopics: ["Absorptive capacity", "Pollution types", "Non-conventional energy"]
    },
    {
      id: "econ_comparative",
      chapterNumber: 14,
      title: "14. Development Experience of India: A Comparison with Neighbours",
      chapterName: "Regional Comparison",
      topics: ["India vs China", "India vs Pakistan", "Growth Indicators"],
      subtopics: ["Great Leap Forward", "Economic reforms in China", "Human development ranking"]
    }
  ]
};

export const INDIA_ISC_PSYCHOLOGY_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "ISC",
  boardName: "Council for the Indian School Certificate Examinations (ISC)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Psychology",
  chapters: [
    {
      id: "isc_psych_intelligence",
      chapterNumber: 1,
      title: "1. Intelligence and Ability",
      chapterName: "Intelligence",
      topics: ["Theories of Intelligence", "Assessment", "Aptitude"],
      subtopics: ["Spearman & Thurstone", "Sternberg & Gardner", "Emotional Intelligence"]
    },
    {
      id: "isc_psych_personality",
      chapterNumber: 2,
      title: "2. Personality",
      chapterName: "Personality",
      topics: ["Trait & Type Approaches", "Psychoanalysis", "Humanistic"],
      subtopics: ["Big Five", "Freud's Structure", "Self-report & Projective"]
    },
    {
      id: "isc_psych_lifespan",
      chapterNumber: 3,
      title: "3. Lifespan Development",
      chapterName: "Development",
      topics: ["Prenatal to Old Age", "Adolescence", "Heredity & Env"],
      subtopics: ["Cognitive development", "Social development", "Physical changes"]
    },
    {
      id: "isc_psych_stress",
      chapterNumber: 4,
      title: "4. Stress and Health",
      chapterName: "Stress",
      topics: ["Nature of Stress", "Effects on Health", "Coping"],
      subtopics: ["Types of stressors", "GAS model", "Resilience"]
    },
    {
      id: "isc_psych_disorders",
      chapterNumber: 5,
      title: "5. Psychological Disorders and Psychotherapy",
      chapterName: "Disorders & Therapy",
      topics: ["Abnormality", "Major Disorders", "Therapies"],
      subtopics: ["DSM Classification", "Anxiety & Mood disorders", "CBT & Humanistic therapy"]
    },
    {
      id: "isc_psych_social_thought",
      chapterNumber: 6,
      title: "6. Social Thought and Social Behaviour",
      chapterName: "Social Cognition",
      topics: ["Attitude Formation", "Attribution", "Prejudice"],
      subtopics: ["Social Schema", "Heuristics", "Stereotypes"]
    },
    {
      id: "isc_psych_social_influence",
      chapterNumber: 7,
      title: "7. Attitude and Social Influence",
      chapterName: "Social Influence",
      topics: ["Group Dynamics", "Conformity", "Leadership"],
      subtopics: ["Compliance & Obedience", "Cooperation & Conflict", "Social Facilitation"]
    }
  ]
};

export const INDIA_ISC_PSYCHOLOGY_CLASS11_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CISCE / ICSE (ISC)",
  boardName: "Council for the Indian School Certificate Examinations (ISC Class 11)",
  nation: "India",
  classLevel: "Class 11",
  subject: "Psychology",
  chapters: [
    {
      id: "intro_psychology_icse11",
      chapterNumber: 1,
      title: "1. Introduction to Psychology",
      chapterName: "Introduction to Psychology",
      topics: ["Foundations & Nature", "Historical Schools", "The Indian Perspective"],
      subtopics: [
        "Foundations & Nature: Definition of psychology; Evolution from a philosophical branch to an empirical science; Scope and branches of psychology (cognitive, developmental, social, clinical, industrial, and educational).",
        "Historical Schools: Structuralism (Wilhelm Wundt), Functionalism (William James), Behaviorism (John B. Watson, B.F. Skinner), Gestalt Psychology, Psychoanalysis (Sigmund Freud), and Humanistic Perspective (Carl Rogers, Abraham Maslow).",
        "The Indian Perspective: Ancient Indian roots of psychological thought (Yoga, Vedanta, and Sufi influences); The development of modern scientific psychology in India."
      ],
      lessonModules: [
        {
          title: "Foundations & Evolution of Psychology",
          description: "Definition of psychology; evolution from a philosophical branch to an empirical science; scope and branches (cognitive, developmental, social, clinical, industrial, and educational).",
          duration: "25 mins",
          level: "Foundational"
        },
        {
          title: "Historical Schools of Psychological Thought",
          description: "Structuralism (Wundt), Functionalism (James), Behaviorism (Watson, Skinner), Gestalt Psychology, Psychoanalysis (Freud), and Humanistic Perspective (Rogers, Maslow).",
          duration: "30 mins",
          level: "Theoretical"
        },
        {
          title: "The Indian Perspective & Modern Developments",
          description: "Ancient Indian roots of psychological thought including Yoga, Vedanta, and Sufi influences; the development of modern scientific psychology in India.",
          duration: "20 mins",
          level: "Historical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Differentiate between Structuralism and Functionalism with focus on introspection vs consciousness utility.",
          "Explain the ancient Indian roots of psychological thought in Yoga and Vedanta.",
          "Classify the major branches of contemporary psychology and their scopes."
        ],
        numerical: [
          "Analyze the structural division of marking patterns for introductory ISC board exam theory questions."
        ]
      }
    },
    {
      id: "methods_psychology_icse11",
      chapterNumber: 2,
      title: "2. Methods of Psychology",
      chapterName: "Methods of Psychology",
      topics: ["Scientific Research", "Research Methods", "Ethical Issues"],
      subtopics: [
        "Scientific Research: Goals of psychological inquiry (description, prediction, explanation, and control); Objectivity, reliability, and validity parameters.",
        "Research Methods: Observational method (naturalistic vs participant), Experimental method (independent, dependent, extraneous variables; experimental vs control groups), Correlational method (positive, negative, zero correlation; correlation vs causation), Case study and Survey method.",
        "Ethical Issues: Informed consent, confidentiality, debriefing, and minimizing harm to human and animal subjects."
      ],
      lessonModules: [
        {
          title: "Goals of Psychological Inquiry & Scientific Parameters",
          description: "Goals of psychological inquiry (description, prediction, explanation, and control); understanding scientific parameters of objectivity, reliability, and validity.",
          duration: "25 mins",
          level: "Methodological"
        },
        {
          title: "Quantitative & Qualitative Research Methods",
          description: "Observational (naturalistic vs participant), Experimental (independent/dependent/extraneous variables, control/experimental groups), Correlational (positive/negative/zero correlation, correlation vs causation), and Case study/Survey methods.",
          duration: "30 mins",
          level: "Practical"
        },
        {
          title: "Ethical Standards in Psychological Research",
          description: "Analysis of crucial ethical issues: informed consent, confidentiality, debriefing, and minimizing harm to human and animal subjects.",
          duration: "20 mins",
          level: "Applied"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain why correlation does not imply causation with classic psychological examples.",
          "Design a mock psychology experiment identifying independent, dependent, and extraneous variables.",
          "Outline the core ethical requirements of informed consent and debriefing in research."
        ],
        numerical: [
          "Calculate basic reliability indices and correlation coefficients for survey response sets."
        ]
      }
    },
    {
      id: "biological_bases_psychology_icse11",
      chapterNumber: 3,
      title: "3. Biological Bases of Behaviour",
      chapterName: "Biological Bases of Behaviour",
      topics: ["The Neuron & Neurotransmitters", "The Nervous System", "The Endocrine System"],
      subtopics: [
        "The Neuron: Structure of a neuron (dendrites, cell body, axon, myelin sheath, terminal buttons); Nerve impulse transmission (action potential and synaptic transmission); Major neurotransmitters (Acetylcholine, Dopamine, Serotonin) and their behavioral impacts.",
        "The Nervous System: Central Nervous System (CNS) brain structures (hindbrain, midbrain, forebrain - cerebral cortex/limbic system) and spinal cord; Peripheral Nervous System (PNS) Somatic and Autonomic systems (Sympathetic/Parasympathetic stress profiles).",
        "The Endocrine System: Major endocrine glands (Pituitary, Thyroid, Adrenals, Gonads) and physiological/behavioral effects of hormones."
      ],
      lessonModules: [
        {
          title: "Neural Structure & Nerve Impulse Transmission",
          description: "Structure of a neuron (dendrites, cell body, axon, myelin sheath, terminal buttons); nerve impulse transmission (action potential and synaptic transmission) and neurotransmitters (ACh, Dopamine, Serotonin).",
          duration: "30 mins",
          level: "Neurobiological"
        },
        {
          title: "CNS & PNS Functional Architecture",
          description: "Structure/functions of brain (hindbrain, midbrain, forebrain including cerebral cortex and limbic system) and Spinal Cord; lateralization/hemispheric specialization; Somatic & Autonomic system activation profiles.",
          duration: "30 mins",
          level: "Neuroanatomical"
        },
        {
          title: "Endocrine Regulation of Behaviour",
          description: "Major endocrine glands (Pituitary, Thyroid, Adrenals, Gonads) and physiological/behavioral effects of hormones.",
          duration: "20 mins",
          level: "Physiological"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Describe step-by-step nerve impulse transmission through the action potential and synaptic gap.",
          "Compare the activation profiles of Sympathetic and Parasympathetic nervous systems during high-stress encounters.",
          "Analyze the behavioral impacts of Acetylcholine, Dopamine, and Serotonin deficits."
        ],
        numerical: [
          "Trace neurotransmitter binding percentages and action potential thresholds in millivolts (e.g. -55mV to +40mV)."
        ]
      }
    },
    {
      id: "human_development_psychology_icse11",
      chapterNumber: 4,
      title: "4. Human Development",
      chapterName: "Human Development",
      topics: ["Growth and Development", "Stages of Development", "Theories of Development"],
      subtopics: [
        "Growth and Development: Meaning and principles of development; interaction of heredity (nature) and environment (nurture).",
        "Stages of Development: Physical, cognitive, and socio-emotional changes across prenatal, infancy, childhood, adolescence (identity crisis, peer pressure, challenges), adulthood, and old age aging processes.",
        "Theories of Development: Piaget's Theory of Cognitive Development (four stages) and Erikson's Theory of Psychosocial Development (eight stages)."
      ],
      lessonModules: [
        {
          title: "Principles of Development & Heredity vs Environment",
          description: "Meaning/principles of development; interaction of heredity (nature) and environment (nurture).",
          duration: "25 mins",
          level: "Conceptual"
        },
        {
          title: "Developmental Milestones: Infancy to Adulthood",
          description: "Physical, cognitive, and socio-emotional changes across prenatal, infancy, childhood, adolescence (identity crisis, peer pressure, challenges), adulthood, and old age coping mechanisms.",
          duration: "30 mins",
          level: "Developmental"
        },
        {
          title: "Piaget & Erikson's Theories of Development",
          description: "Comprehensive study of Piaget's Theory of Cognitive Development (four stages) and Erikson's Theory of Psychosocial Development (eight stages).",
          duration: "30 mins",
          level: "Theoretical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Illustrate the major cognitive milestones in Piaget's four stages of cognitive development.",
          "Analyze Erikson's stage of 'Identity vs Role Confusion' in modern adolescent contexts.",
          "Evaluate how nature and nurture interact to shape psychological development."
        ],
        numerical: [
          "Tabulate developmental milestones, age ranges, and conflict themes in Erikson's eight stages."
        ]
      }
    },
    {
      id: "sensory_perceptual_psychology_icse11",
      chapterNumber: 5,
      title: "5. Sensory, Attentional, and Perceptual Processes",
      chapterName: "Sensory, Attentional, and Perceptual Processes",
      topics: ["Sensory Modalities", "Attentional Processes", "Perceptual Organisation"],
      subtopics: [
        "Sensory Modalities: Structure and working of human eye (visual sensation) and ear (auditory sensation); absolute and differential thresholds (Just Noticeable Difference).",
        "Attentional Processes: Selective and sustained attention; internal/subjective vs external/objective factors influencing attention.",
        "Perceptual Organisation: Gestalt principles (Proximity, Similarity, Continuity, Closure); depth perception (monocular/binocular cues); perceptual constancies (size, shape); illusions (Müller-Lyer, Ponzo)."
      ],
      lessonModules: [
        {
          title: "Visual and Auditory Sensation & Thresholds",
          description: "Structure and working of the human eye and ear; understanding Absolute Threshold and Differential Threshold (Just Noticeable Difference).",
          duration: "25 mins",
          level: "Physiological"
        },
        {
          title: "Selective & Sustained Attention Dynamics",
          description: "Selective vs sustained attention; factors influencing attention (internal/subjective factors vs external/objective factors).",
          duration: "25 mins",
          level: "Cognitive"
        },
        {
          title: "Gestalt Principles, Depth Perception & Illusions",
          description: "Gestalt principles of organization; depth perception (monocular & binocular cues); perceptual constancies; Müller-Lyer and Ponzo illusions.",
          duration: "30 mins",
          level: "Perceptual"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Contrast Absolute Threshold with Differential Threshold / Just Noticeable Difference.",
          "Explain the Gestalt principles of Proximity, Similarity, Continuity, and Closure with real examples.",
          "Differentiate between monocular and binocular cues in visual depth perception."
        ],
        numerical: [
          "Apply Weber's Law (ΔI/I = k) to calculate just noticeable differences across stimulus intensities."
        ]
      }
    },
    {
      id: "learning_psychology_icse11",
      chapterNumber: 6,
      title: "6. Learning",
      chapterName: "Learning",
      topics: ["Classical Conditioning", "Operant Conditioning", "Cognitive & Observational Learning"],
      subtopics: [
        "Classical Conditioning: Ivan Pavlov's experiments; Concepts of US, UR, CS, CR; acquisition, extinction, spontaneous recovery, generalization, and discrimination.",
        "Operant Conditioning: B.F. Skinner's box experiments; types of reinforcement (positive vs negative); punishment vs negative reinforcement; schedules of reinforcement (fixed, variable, interval, ratio).",
        "Cognitive & Observational Learning: Insight learning (Köhler's chimpanzee experiments); Latent learning (Tolman); Observational/Social learning (Bandura's Bobo doll experiments)."
      ],
      lessonModules: [
        {
          title: "Classical Conditioning & Pavlovian Principles",
          description: "Ivan Pavlov's classical conditioning experiments; understanding US, UR, CS, CR; phenomena of acquisition, extinction, spontaneous recovery, generalization, and discrimination.",
          duration: "25 mins",
          level: "Behavioral"
        },
        {
          title: "Operant Conditioning & Reinforcement Schedules",
          description: "B.F. Skinner's box experiments; positive/negative reinforcement; punishment vs negative reinforcement; schedules of reinforcement (fixed, variable, interval, ratio).",
          duration: "30 mins",
          level: "Behavioral"
        },
        {
          title: "Insight, Latent & Social Observational Learning",
          description: "Insight learning (Köhler's chimpanzees); latent learning (Tolman); social/observational learning (Bandura's Bobo doll experiments).",
          duration: "25 mins",
          level: "Cognitive-Behavioral"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Deconstruct a daily scenario into Pavlov's classical conditioning parameters (US, UR, CS, CR).",
          "Distinguish negative reinforcement from punishment with clear behavioral outcomes.",
          "Describe Bandura's observational learning theory and the Bobo doll experiment results."
        ],
        numerical: [
          "Compare behavioral response rates across Fixed Ratio, Variable Ratio, Fixed Interval, and Variable Interval reinforcement schedules."
        ]
      }
    },
    {
      id: "memory_psychology_icse11",
      chapterNumber: 7,
      title: "7. Human Memory",
      chapterName: "Human Memory",
      topics: ["Stage Model of Memory", "Forgetting Theories", "Memory Enhancement"],
      subtopics: [
        "Stage Model of Memory: Atkinson and Shiffrin model; sensory memory (iconic, echoic), short-term memory (STM / Working Memory), and long-term memory (LTM). LTM classifications: declarative (semantic/episodic) vs non-declarative/procedural.",
        "Forgetting: Ebbinghaus' forgetting curve; theories of forgetting (trace decay/disuse, proactive/retroactive interference, motivated forgetting/repression).",
        "Memory Enhancement: Mnemonics, method of loci, chunking, organization, and deep-level processing."
      ],
      lessonModules: [
        {
          title: "Atkinson-Shiffrin Stage Model & LTM Classifications",
          description: "Atkinson-Shiffrin stage model (Sensory, Short-Term, Long-Term memory); declarative (semantic, episodic) vs non-declarative (procedural) memory systems.",
          duration: "25 mins",
          level: "Cognitive"
        },
        {
          title: "Ebbinghaus Curve & Theories of Forgetting",
          description: "Ebbinghaus' forgetting curve; theories of forgetting: trace decay, proactive/retroactive interference, and motivated forgetting/repression.",
          duration: "25 mins",
          level: "Cognitive"
        },
        {
          title: "Mnemonics & Cognitive Memory Enhancement",
          description: "Cognitive strategies for memory enhancement: mnemonics, method of loci, chunking, structural organization, and Craik & Lockhart's deep-level processing.",
          duration: "25 mins",
          level: "Applied Cognitive"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Illustrate the flow of information through the sensory, short-term, and long-term memory registers.",
          "Differentiate proactive interference from retroactive interference with memory retrieval examples.",
          "Explain Craik & Lockhart's levels of processing framework and its implications for studying."
        ],
        numerical: [
          "Calculate percentage recall over time to plot a typical Ebbinghaus Forgetting Curve."
        ]
      }
    },
    {
      id: "practical_psychology_icse11",
      chapterNumber: 8,
      title: "Paper II: Practical Work (30 Marks)",
      chapterName: "Practical Work & Research Projects",
      topics: ["Laboratory Experiments & Testing", "Case Profile or Field Project", "Practical Log and Viva-Voce"],
      subtopics: [
        "Section A: Laboratory Experiments / Testing (15 Marks): Minimum 4-5 practical evaluations (span of immediate memory, effect of chunking, bilateral transfer, part vs whole learning, division of attention).",
        "Section B: Case Profile / Field Project (10 Marks): Basic field profile, developmental milestones observation, or adolescents academic stress interviews.",
        "Section C: Practical Log & Viva-Voce (5 Marks): Lab notebook structural review and board oral examination."
      ],
      lessonModules: [
        {
          title: "Laboratory Testing & Core Experiments",
          description: "Detailed methodologies for immediate memory span, chunking benefits, bilateral learning transfer (mirror drawing), and division of attention.",
          duration: "30 mins",
          level: "Hands-on Practical"
        },
        {
          title: "Designing Field Projects & Case Profiles",
          description: "Practical guide to empirical field projects, structured interview guides for academic stress, and childhood milestone observation checklists.",
          duration: "25 mins",
          level: "Field Practical"
        },
        {
          title: "Laboratory Notebooks & Viva-Voce Preparation",
          description: "Standard reporting format for laboratory experiments, data tabulation, and oral board defense under external review.",
          duration: "20 mins",
          level: "Viva & Evaluation"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Draft a complete psychological report format with introduction, method, results, discussion, and conclusion.",
          "Design an experiment using a mirror-drawing apparatus to demonstrate bilateral transfer of learning.",
          "Prepare answers for typical examiner questions regarding independent variables in laboratory tests."
        ],
        numerical: [
          "Tabulate trial-by-trial errors, calculate mean memory spans, and plot learning curves for mirror-drawing trials."
        ]
      }
    }
  ]
};

export const INDIA_ISC_ECONOMICS_CLASS11_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CISCE / ICSE (ISC)",
  boardName: "Council for the Indian School Certificate Examinations (ISC Class 11)",
  nation: "India",
  classLevel: "Class 11",
  subject: "Economics",
  chapters: [
    {
      id: "understanding_economics_icse11",
      chapterNumber: 1,
      title: "1. Understanding Economics & Basic Concepts",
      chapterName: "Understanding Economics & Basic Concepts",
      topics: ["Definitions of Economics", "Core Concepts", "Basic Terminology"],
      subtopics: [
        "Definitions of Economics: Wealth definition (Adam Smith), Welfare definition (Alfred Marshall), Scarcity definition (Lionel Robbins), and Growth definition (Paul Samuelson).",
        "Core Concepts: Micro vs. Macroeconomics; Positive vs. Normative economics; Concept of scarcity, choice, and central problems of an economy (What, How, and For Whom to produce).",
        "Basic Terminology: Definition and classification of Goods (economic, free, consumer, capital, intermediate); Utility, Value, Price, Wealth, Welfare, Production, and Consumption."
      ],
      lessonModules: [
        {
          title: "Classical to Modern Definitions of Economics",
          description: "Exploration of foundational economic thoughts: Smith's Wealth, Marshall's Welfare, Robbins' Scarcity, and Samuelson's Growth definitions.",
          duration: "25 mins",
          level: "Foundational"
        },
        {
          title: "Micro vs Macro & Central Problems of an Economy",
          description: "Socio-economic choices under scarcity; what, how, and for whom to produce; micro vs macroeconomics and positive vs normative sciences.",
          duration: "25 mins",
          level: "Theoretical"
        },
        {
          title: "Basic Terminology: Goods, Value, and Utility",
          description: "Classification of goods; concepts of utility, exchange value, market price, wealth, welfare, and production-consumption cycles.",
          duration: "20 mins",
          level: "Conceptual"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Compare Alfred Marshall's Welfare definition with Lionel Robbins' Scarcity definition of Economics.",
          "Contrast Positive Economics with Normative Economics with relevant structural examples.",
          "Analyze the central problems of an economy and how different economic systems resolve them."
        ],
        numerical: [
          "Differentiate and categorize lists of items into economic goods, free goods, consumer goods, and capital goods."
        ]
      }
    },
    {
      id: "consumer_behaviour_demand_icse11",
      chapterNumber: 2,
      title: "2. Consumer Behaviour and Demand",
      chapterName: "Consumer Behaviour and Demand",
      topics: ["Utility Analysis", "Theory of Demand", "Elasticity of Demand"],
      subtopics: [
        "Utility Analysis: Cardinal utility approach; Law of Diminishing Marginal Utility; Consumer’s equilibrium (Single commodity case); Ordinal utility approach: Indifference curves, properties, and consumer's budget line.",
        "Theory of Demand: Meaning and determinants of demand; Demand function; Law of Demand (statement, assumptions, and reasons for its operation); Exceptions to the Law of Demand. Movements vs. Shifts of demand curve.",
        "Elasticity of Demand: Price elasticity of demand (meaning and degrees: perfectly elastic, perfectly inelastic, unitary, elastic, inelastic); Methods of measurement: Percentage method, Point method, and Total Outlay method; Factors affecting price elasticity of demand."
      ],
      lessonModules: [
        {
          title: "Cardinal & Ordinal Utility Analysis",
          description: "Law of Diminishing Marginal Utility, single commodity consumer equilibrium; Indifference curve properties and budget line.",
          duration: "30 mins",
          level: "Theoretical"
        },
        {
          title: "Theory of Demand: Law, Shifts and Exceptions",
          description: "Determinants of demand, demand function; Law of Demand, extension/contraction of demand (movements) vs increase/decrease (shifts).",
          duration: "25 mins",
          level: "Conceptual"
        },
        {
          title: "Elasticity of Demand: Measurement & Degrees",
          description: "Degrees of price elasticity of demand; calculation via Percentage, Point, and Total Outlay methods; key determinants of elasticity.",
          duration: "30 mins",
          level: "Analytical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain why the indifference curve is always convex to the origin using the Marginal Rate of Substitution (MRS).",
          "Distinguish clearly between a movement along a demand curve and a shift of the demand curve.",
          "Describe how a consumer attains equilibrium under the Cardinal Utility approach for a single commodity."
        ],
        numerical: [
          "Calculate Price Elasticity of Demand using the Percentage Method and Total Outlay Method based on tabular demand schedules."
        ]
      }
    },
    {
      id: "producer_behaviour_supply_cost_icse11",
      chapterNumber: 3,
      title: "3. Producer Behaviour, Supply, and Cost",
      chapterName: "Producer Behaviour, Supply, and Cost",
      topics: ["Production Function", "Cost and Revenue Concepts", "Theory of Supply"],
      subtopics: [
        "Production Function: Short-run vs. Long-run production function; Law of Variable Proportions (three stages, assumptions, and reasons for operation); Returns to scale (brief qualitative overview).",
        "Cost and Revenue Concepts: Meaning of Total Cost (TC), Total Fixed Cost (TFC), Total Variable Cost (TVC), Average Cost (AC), and Marginal Cost (MC) along with their mathematical interrelations and U-shaped curves; Total Revenue (TR), Average Revenue (AR), and Marginal Revenue (MR) under perfect and imperfect competition.",
        "Theory of Supply: Meaning and determinants of supply; Law of Supply; Movements vs. shifts of the supply curve; Price elasticity of supply (meaning and measurement via percentage method)."
      ],
      lessonModules: [
        {
          title: "Law of Variable Proportions & Production Function",
          description: "Short-run vs long-run production; in-depth look at the three stages of the Law of Variable Proportions and returns to scale.",
          duration: "25 mins",
          level: "Microeconomic"
        },
        {
          title: "Cost and Revenue Structures & Interrelations",
          description: "TC, TFC, TVC, AC, MC relations and U-shaped curves; TR, AR, MR curves under perfect and imperfect market structures.",
          duration: "30 mins",
          level: "Analytical"
        },
        {
          title: "Theory of Supply & Elasticity of Supply",
          description: "Determinants of supply, Law of Supply; movements along vs shifts of supply curve; price elasticity of supply calculations.",
          duration: "25 mins",
          level: "Conceptual"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain the economic reasons behind the three stages of the Law of Variable Proportions.",
          "Analyze why the short-run Average Cost (AC) curve is U-shaped in modern production theory.",
          "Differentiate between contraction of supply and decrease in supply with diagrammatic representations."
        ],
        numerical: [
          "Given a cost table with TFC and TVC, calculate TC, AC, and MC for different levels of output.",
          "Calculate the price elasticity of supply when price increases and supply expands by a given percentage."
        ]
      }
    },
    {
      id: "market_forms_price_det_icse11",
      chapterNumber: 4,
      title: "4. Market Forms and Price Determination",
      chapterName: "Market Forms and Price Determination",
      topics: ["Main Market Forms", "Equilibrium Price"],
      subtopics: [
        "Main Market Forms: Meaning and unique characteristics of Perfect Competition, Monopoly, Monopolistic Competition, and Oligopoly.",
        "Equilibrium Price: Price determination under Perfect Competition; Effects of shifts in demand and supply on the equilibrium price and quantity; Concept of price ceiling and price floor."
      ],
      lessonModules: [
        {
          title: "Perfect Competition, Monopoly, and Imperfect Markets",
          description: "Defining characteristics, entry barriers, price control power, and structural features of Perfect Competition, Monopoly, Monopolistic Competition, and Oligopoly.",
          duration: "25 mins",
          level: "Structural"
        },
        {
          title: "Price Determination under Perfect Competition",
          description: "How demand and supply forces determine equilibrium price and quantity; analyzing shifts in demand/supply, and regulatory price ceilings and price floors.",
          duration: "30 mins",
          level: "Analytical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Compare the product differentiation characteristics of Monopolistic Competition with Perfect Competition.",
          "Explain the socio-economic purpose and consequences of enforcing a Rent Ceiling (Price Ceiling) or Minimum Support Price (Price Floor).",
          "Show diagrammatically how simultaneous increases in both demand and supply affect the equilibrium price."
        ],
        numerical: [
          "Determine equilibrium price and quantity from demand and supply equations (e.g. Qd = 100 - 2P, Qs = 20 + 2P)."
        ]
      }
    },
    {
      id: "structural_features_indian_econ_icse11",
      chapterNumber: 5,
      title: "5. Structural Features of the Indian Economy",
      chapterName: "Structural Features of the Indian Economy",
      topics: ["Post-Independence Overview", "Economic Sectors", "Economic Reforms & Challenges"],
      subtopics: [
        "Post-Independence Overview: Indian economy at the time of Independence; Nature and features of the Indian economy as a developing economy.",
        "Economic Sectors: Role and problems of Agriculture, Industry, and the Services sector in Indian economic development.",
        "Economic Reforms: Economic policies up to 1991; The New Economic Policy of 1991 (Liberalisation, Privatisation, and Globalisation - LPG). Current Challenges: Absolute vs. relative poverty, unemployment trends, human capital formation, and sustainable economic growth."
      ],
      lessonModules: [
        {
          title: "Features of Developing India Post-Independence",
          description: "State of the Indian economy in 1947; structural features of India as a developing economy; national income indices.",
          duration: "20 mins",
          level: "Historical"
        },
        {
          title: "Sectoral Dynamics: Agriculture, Industry & Services",
          description: "Inter-sectoral shifts, low agricultural productivity reasons, industrial stagnation, and the rapid growth of the services sector in India.",
          duration: "25 mins",
          level: "Developmental"
        },
        {
          title: "LPG Reforms of 1991 & Contemporary Challenges",
          description: "Causes of the 1991 Balance of Payments crisis; New Economic Policy (NEP) pillars: LPG; assessing modern hurdles like poverty, jobless growth, and environment.",
          duration: "25 mins",
          level: "Applied Economics"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain the macroeconomic crises that forced the Indian government to adopt the 1991 Economic Reforms.",
          "Evaluate the role and modern bottlenecks of the agricultural sector in Indian economic development.",
          "Distinguish absolute poverty from relative poverty and describe the vicious cycle of poverty."
        ],
        numerical: [
          "Interpret and analyze sector-wise GDP contribution percentages in India over different decades."
        ]
      }
    },
    {
      id: "basic_statistics_economics_icse11",
      chapterNumber: 6,
      title: "6. Basic Statistics for Economics",
      chapterName: "Basic Statistics for Economics",
      topics: ["Data Collection & Organisation", "Measures of Central Tendency & Dispersion", "Correlation & Index Numbers"],
      subtopics: [
        "Data Collection & Organisation: Meaning, scope, and importance of statistics in economics; Primary vs. secondary data; Methods of data collection; Sampling vs. Census methods; Classification and tabular presentation of data.",
        "Measures of Central Tendency & Dispersion: Calculation of Mean, Median, and Mode for ungrouped and grouped continuous data; Absolute and relative dispersion measures: Range, Quartile Deviation, Mean Deviation, Standard Deviation, and Coefficient of Variation.",
        "Correlation & Index Numbers: Karl Pearson’s Coefficient of Correlation (scatter diagrams and numerical calculation); Meaning, types, and construction of Index Numbers (Wholesale Price Index, Consumer Price Index, Laspeyres’, Paasche’s, and Fisher’s methods)."
      ],
      lessonModules: [
        {
          title: "Statistical Data Collection, Sampling & Tabulation",
          description: "Importance of statistics in economic policy; primary vs secondary data; questionnaire construction, census vs sampling methods; data classification.",
          duration: "25 mins",
          level: "Statistical"
        },
        {
          title: "Measures of Central Tendency & Dispersion (Mean, SD)",
          description: "Mean, Median, and Mode formulas for grouped continuous frequencies; calculating Standard Deviation (SD) and Coefficient of Variation.",
          duration: "30 mins",
          level: "Quantitative"
        },
        {
          title: "Karl Pearson Correlation & Index Numbers (Laspeyres, Paasche, Fisher)",
          description: "Calculating Karl Pearson's r; Index numbers construction using Laspeyres', Paasche's, and Fisher's Ideal Index methods; CPI and WPI scales.",
          duration: "30 mins",
          level: "Quantitative"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain why Fisher's index number is called an 'Ideal Index Number' and how it satisfies time and factor reversal tests.",
          "Discuss the relative merits and demerits of the Census method versus the Sampling method of data collection.",
          "Interpret a Karl Pearson correlation coefficient of r = -0.85 in an economic study context."
        ],
        numerical: [
          "Calculate the Arithmetic Mean, Median, and Standard Deviation for a given grouped continuous frequency distribution of household incomes.",
          "Given base and current year prices and quantities, compute the Laspeyres', Paasche's, and Fisher's price index numbers."
        ]
      }
    },
    {
      id: "project_work_economics_icse11",
      chapterNumber: 7,
      title: "Paper II: Project Work (20 Marks)",
      chapterName: "Practical Work & Research Projects",
      topics: ["Research Essay Submission", "Sample Project Directions", "Assessment Framework"],
      subtopics: [
        "Research Essay Submission: Select and draft two detailed project reports (approx. 1000-1500 words each) based on curriculum parameters.",
        "Sample Project Directions: Comparative price studies of consumer goods, analytical case studies on 1991 reforms, or community sample surveys.",
        "Assessment Framework: Evaluated via a project file/academic content (10 marks internal) and viva-voce presentation (10 marks external)."
      ],
      lessonModules: [
        {
          title: "Formulating Research Proposals & Raw Data Tracking",
          description: "Choosing economic themes, setting hypotheses, framing sample questionnaires, and conducting qualitative/quantitative surveys.",
          duration: "30 mins",
          level: "Practical Research"
        },
        {
          title: "Analyzing Local Markets & Surveys",
          description: "Tabulating collected survey responses, generating price elasticity indices, and drawing comparative charts.",
          duration: "25 mins",
          level: "Data Analysis"
        },
        {
          title: "Drafting Project Reports & Viva-Voce Defense",
          description: "Structuring the final reports, bibliography citations, academic integrity, and oral defense before external board examiners.",
          duration: "20 mins",
          level: "Viva & Presentation"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Draft a structured project proposal detailing research methodology and expected economic outcomes.",
          "Outline the standard formatting for a bibliography section in an academic economic report.",
          "Prepare concise oral responses to defend sample survey findings during board examinations."
        ],
        numerical: [
          "Tabulate raw pricing data across three different retail markets and compute average market variance."
        ]
      }
    }
  ]
};

export const INDIA_ISC_SOCIOLOGY_CLASS11_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CISCE / ICSE (ISC)",
  boardName: "Council for the Indian School Certificate Examinations (ISC Class 11)",
  nation: "India",
  classLevel: "Class 11",
  subject: "Sociology",
  chapters: [
    {
      id: "origin_dev_sociology_icse11",
      chapterNumber: 1,
      title: "1. Origin and Development of Sociology and Anthropology",
      chapterName: "Origin and Scope of Sociology",
      topics: [
        "Emergence & Scope",
        "Classical Thinkers",
        "Interrelationships"
      ],
      subtopics: [
        "Emergence & Scope: Historical contexts leading to the growth of both disciplines and the dynamic scope of sociology.",
        "Classical Thinkers: Foundational theories by Auguste Comte (Positivism), Herbert Spencer (Social Darwinism), Émile Durkheim (Structural Functionalism), Max Weber (Interpretive Sociology), and Karl Marx (Conflict Theory).",
        "Interrelationships: Comparisons between sociology and other social sciences like political science, economics, and anthropology."
      ],
      lessonModules: [
        {
          title: "Emergence and Scope of Sociology and Anthropology",
          description: "Historical contexts of the Enlightenment, French Revolution, and Industrial Revolution leading to the growth of sociology and anthropology; dynamic scope and boundary of sociological inquiry.",
          duration: "25 mins",
          level: "Foundational"
        },
        {
          title: "Classical Foundational Theorists & Positivism",
          description: "In-depth analysis of Auguste Comte's Law of Three Stages and Positivism, Herbert Spencer's Social Darwinism and Organic Analogy, Émile Durkheim's Social Facts and Structural Functionalism, Max Weber's Social Action and Verstehen, and Karl Marx's Historical Materialism and Conflict Theory.",
          duration: "30 mins",
          level: "Theoretical"
        },
        {
          title: "Interdisciplinary Comparisons with Other Social Sciences",
          description: "Comparative study and boundaries of Sociology with Political Science, Economics, Social Anthropology, and History.",
          duration: "20 mins",
          level: "Comparative"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Explain how the Industrial Revolution and the Enlightenment catalyzed the emergence of sociology.",
          "Compare Auguste Comte's Positivism with Max Weber's Interpretive Sociology and Verstehen.",
          "Analyze the structural relationship between Sociology and Social Anthropology."
        ],
        numerical: [
          "Identify marking criteria and key analytical points for 3-mark and 7-mark ISC board exam theory questions."
        ]
      }
    },
    {
      id: "research_methodology_sociology_icse11",
      chapterNumber: 2,
      title: "2. Research Methodology",
      chapterName: "Research Methodology",
      topics: [
        "Foundations & Scientific Methods",
        "Tools of Data Collection"
      ],
      subtopics: [
        "Foundations & Scientific Methods: Importance of scientific methodology, step-by-step procedures from observation to hypothesis building, and comparative or historical approaches.",
        "Tools of Data Collection: Exploration of primary and secondary tools including questionnaires, interviews, and observations."
      ],
      lessonModules: [
        {
          title: "Scientific Method & Sociological Research Design",
          description: "Scientific rigor, objectivity vs subjectivity, problem formulation, hypothesis building, research design, and comparative/historical approaches.",
          duration: "25 mins",
          level: "Methodological"
        },
        {
          title: "Primary and Secondary Data Collection Tools",
          description: "Construction and administration of Questionnaires, Structured vs Unstructured Interviews, Participant and Non-Participant Observation techniques.",
          duration: "25 mins",
          level: "Practical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Differentiate between participant and non-participant observation with real fieldwork examples.",
          "Formulate a valid sociological hypothesis and identify independent vs dependent variables.",
          "Evaluate the merits and limitations of questionnaires versus semi-structured interviews."
        ],
        numerical: [
          "Analyze sample size distribution and quantitative response percentage tables in sociological surveys."
        ]
      }
    },
    {
      id: "basic_concepts_sociology_icse11",
      chapterNumber: 3,
      title: "3. Basic Concepts",
      chapterName: "Society, Socialization & Culture",
      topics: [
        "Individual, Society & Socialization",
        "Culture"
      ],
      subtopics: [
        "Individual, Society & Socialization: Characteristics of society, rural vs. urban differences, and the socialization process involving primary/secondary agencies and theories like Cooley's Looking-Glass Self.",
        "Culture: Material vs. non-material culture, cultural lag, and ethnocentrism."
      ],
      lessonModules: [
        {
          title: "Society, Community & Socialization Agencies",
          description: "Characteristics of human society; rural vs urban community differences; primary and secondary agencies of socialization (Family, Peer Group, School, Media, Religion).",
          duration: "25 mins",
          level: "Conceptual"
        },
        {
          title: "Theories of Self & Cultural Dynamics",
          description: "Charles Horton Cooley's Looking-Glass Self; material vs non-material culture; William F. Ogburn's Cultural Lag; Ethnocentrism vs Cultural Relativism.",
          duration: "25 mins",
          level: "Theoretical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Illustrate the three stages of Cooley's Looking-Glass Self theory.",
          "Provide contemporary real-world examples of William F. Ogburn's Cultural Lag.",
          "Distinguish between ethnocentrism and cultural relativism in global societies."
        ],
        numerical: [
          "Tabulate differences between primary and secondary agencies of socialization with scoring rubrics."
        ]
      }
    },
    {
      id: "social_structure_sociology_icse11",
      chapterNumber: 4,
      title: "4. Social Structure",
      chapterName: "Social Structure & Processes",
      topics: [
        "Social Groups & Processes",
        "Status and Role"
      ],
      subtopics: [
        "Social Groups & Processes: Primary, secondary, in-out, and reference groups alongside status, role conflict, and basic social processes like co-operation and conflict.",
        "Status and Role: Ascribed vs. achieved status and role stereotyping."
      ],
      lessonModules: [
        {
          title: "Social Groups and Reference Group Dynamics",
          description: "Classification of groups (Primary, Secondary, In-groups, Out-groups, Reference Groups) and associative/dissociative social processes (Co-operation, Accommodation, Assimilation, Competition, Conflict).",
          duration: "25 mins",
          level: "Structural"
        },
        {
          title: "Status, Role Set & Role Conflict",
          description: "Ascribed vs achieved status, role set, multiple roles, role conflict, role strain, and role stereotyping in modern society.",
          duration: "25 mins",
          level: "Analytical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Examine role conflict in working parents and dual-earner families.",
          "Compare Merton's Reference Group theory with Sumner's In-group/Out-group dynamics.",
          "Differentiate between associative and dissociative social processes."
        ],
        numerical: [
          "Categorize sociological status attributes into ascribed vs achieved classification matrices."
        ]
      }
    },
    {
      id: "social_problems_sociology_icse11",
      chapterNumber: 5,
      title: "5. Social Problems",
      chapterName: "Social Problems & Deviance",
      topics: [
        "Issues & Deviance",
        "Vulnerable Groups"
      ],
      subtopics: [
        "Issues & Deviance: Demographic challenges like overpopulation, poverty, child labour, juvenile delinquency, and hurdles faced by vulnerable groups."
      ],
      lessonModules: [
        {
          title: "Demographic Challenges & Poverty",
          description: "Socio-economic impact of overpopulation; absolute vs relative poverty; vicious cycle of poverty and Indian alleviation schemes.",
          duration: "25 mins",
          level: "Applied"
        },
        {
          title: "Deviance, Child Labour & Juvenile Delinquency",
          description: "Sociological causes of child labour; juvenile delinquency legal framework and reformatories; challenges of marginalized vulnerable groups.",
          duration: "25 mins",
          level: "Critical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Assess the systemic causes and rehabilitation strategies for child labour in India.",
          "Explain the difference between absolute and relative poverty with socio-economic indicators.",
          "Discuss institutional and community mechanisms for reforming juvenile delinquents."
        ],
        numerical: [
          "Interpret demographic dependency ratios and poverty line headcount metrics."
        ]
      }
    },
    {
      id: "indian_sociologists_icse11",
      chapterNumber: 6,
      title: "6. Indian Sociologists",
      chapterName: "Indian Thinkers & Fieldwork",
      topics: [
        "Pioneering Perspectives",
        "Field-Work Profiles"
      ],
      subtopics: [
        "Pioneering Perspectives: Contributions and field-work profiles of thinkers such as G.S. Ghurye, M.N. Srinivas, and others."
      ],
      lessonModules: [
        {
          title: "G.S. Ghurye and Indological Perspectives",
          description: "Pioneering role of G.S. Ghurye in Indian sociology, six features and origins of the caste system, and tribal integration vs isolation.",
          duration: "25 mins",
          level: "Biographical & Theoretical"
        },
        {
          title: "M.N. Srinivas and Fieldwork Perspectives",
          description: "M.N. Srinivas's structural-functional approach, Rampura village study, Sanskritization, Westernization, and Dominant Caste.",
          duration: "25 mins",
          level: "Fieldwork & Analytical"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Detail G.S. Ghurye's six core characteristics of the Indian caste system.",
          "Critique M.N. Srinivas's concept of Sanskritization as an avenue of social mobility.",
          "Identify the essential attributes of a 'Dominant Caste' in Indian village structure."
        ],
        numerical: [
          "Map field research methodology used in classical Indian village ethnographies."
        ]
      }
    },
    {
      id: "practical_work_sociology_icse11",
      chapterNumber: 7,
      title: "Paper II: Practical Work (30 Marks)",
      chapterName: "Practical Work & Research Projects",
      topics: [
        "Sociological Projects",
        "Assessment Framework"
      ],
      subtopics: [
        "Sociological Projects: Completion of two independent empirical or ethnographic research projects utilizing interviews or surveys (15 marks each).",
        "Assessment Framework: Evaluated via a project file/report (10 marks) and a viva-voce/presentation (5 marks)."
      ],
      lessonModules: [
        {
          title: "Designing Independent Empirical Projects",
          description: "Step-by-step guidance for choosing two social themes, crafting survey questionnaires, conducting structured interviews, and assembling empirical data.",
          duration: "30 mins",
          level: "Hands-on Practical"
        },
        {
          title: "Project Report Preparation & Viva-Voce Defense",
          description: "Structure of the 10-mark project report file, bibliography, ethical fieldwork standards, and preparation for the 5-mark viva-voce presentation.",
          duration: "20 mins",
          level: "Viva & Evaluation"
        }
      ],
      practiceGoals: {
        conceptual: [
          "Formulate a complete interview guide and survey protocol for an empirical research topic.",
          "Structure a compliant ISC Class 11 Sociological Project File with introduction, methodology, data presentation, findings, and bibliography.",
          "Prepare concise oral responses for external examiner viva-voce defense."
        ],
        numerical: [
          "Calculate sample percentage breakdowns, frequency distribution tables, and pie chart representations for empirical field data."
        ]
      }
    }
  ]
};

export const INDIA_ISC_ECONOMICS_CLASS12_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "ISC",
  boardName: "Council for the Indian School Certificate Examinations (ISC)",
  nation: "India",
  classLevel: "Class 12",
  subject: "Economics",
  chapters: [
    {
      id: "isc_econ_micro",
      chapterNumber: 1,
      title: "1. Microeconomics",
      chapterName: "Microeconomics",
      topics: ["Consumer Behaviour", "Production", "Competition"],
      subtopics: ["Theory of Consumer Behaviour", "Production and Costs", "Perfect Competition", "Imperfect Competition"]
    },
    {
      id: "isc_econ_macro",
      chapterNumber: 2,
      title: "2. Macroeconomics",
      chapterName: "Macroeconomics",
      topics: ["National Income", "Income & Employment", "Banking"],
      subtopics: ["National Income Aggregates", "Determination of Income and Employment", "Money and Banking", "Government Budget", "Balance of Payments"]
    }
  ]
};

export const INDIA_CBSE_MATH_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Mathematics",
  chapters: [
    {
      id: "real_numbers_10",
      chapterNumber: 1,
      title: "1. Real Numbers",
      chapterName: "Real Numbers",
      topics: ["Fundamental Theorem of Arithmetic", "Revisiting Irrational Numbers", "Decimal Expansions"],
      subtopics: [
        "Fundamental Theorem of Arithmetic and illustrative examples",
        "Proofs of irrationality of √2, √3, √5",
        "Revisiting rational numbers in terms of terminating/non-terminating recurring decimal expansions"
      ],
      lessonModules: [
        { title: "Fundamental Theorem of Arithmetic", description: "Prime factorization and HCF/LCM relationship", duration: "25 mins", level: "Foundational" },
        { title: "Irrationality Proofs", description: "Proving √2 and √3 irrational", duration: "30 mins", level: "Core Formulation" }
      ],
      practiceGoals: { conceptual: ["Prime Factorization", "Irrational Proofs"], numerical: ["HCF & LCM Computations"] }
    },
    {
      id: "polynomials_10",
      chapterNumber: 2,
      title: "2. Polynomials",
      chapterName: "Polynomials",
      topics: ["Geometrical Meaning of Zeros", "Relationship between Zeros and Coefficients", "Division Algorithm"],
      subtopics: [
        "Geometrical meaning of zeroes of a polynomial",
        "Relationship between zeroes and coefficients of quadratic polynomials",
        "Division algorithm for polynomials with real coefficients"
      ],
      lessonModules: [
        { title: "Zeros & Graph Interpretation", description: "Number of zeros from graph intersections", duration: "25 mins", level: "Foundational" },
        { title: "Coefficients & Zeros Relationship", description: "Sum and product of quadratic zeros", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Geometric Zeros", "Coefficients Relations"], numerical: ["Finding Zeros", "Polynomial Division"] }
    },
    {
      id: "pair_linear_equations_10",
      chapterNumber: 3,
      title: "3. Pair of Linear Equations in Two Variables",
      chapterName: "Pair of Linear Equations in Two Variables",
      topics: ["Graphical Method", "Algebraic Methods (Substitution, Elimination)", "Equations Reducible to Linear Form"],
      subtopics: [
        "Pair of linear equations in two variables and graphical method of solution",
        "Algebraic methods of solving linear equations: Substitution and Elimination methods",
        "Equations reducible to a pair of linear equations in two variables"
      ],
      lessonModules: [
        { title: "Graphical Consistency", description: "Intersecting, parallel, and coincident lines", duration: "30 mins", level: "Foundational" },
        { title: "Algebraic Methods", description: "Substitution and elimination techniques", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Consistency Conditions", "Algebraic Solution Methods"], numerical: ["Simultaneous Equations", "Word Problems"] }
    },
    {
      id: "quadratic_equations_10",
      chapterNumber: 4,
      title: "4. Quadratic Equations",
      chapterName: "Quadratic Equations",
      topics: ["Standard Form", "Factorization Method", "Quadratic Formula", "Discriminant"],
      subtopics: [
        "Standard form of quadratic equation ax² + bx + c = 0 (a ≠ 0)",
        "Solution of quadratic equations by factorization and by quadratic formula",
        "Relationship between discriminant and nature of roots"
      ],
      lessonModules: [
        { title: "Solving Quadratics", description: "Factorization and completing the square", duration: "30 mins", level: "Foundational" },
        { title: "Discriminant & Nature of Roots", description: "Using b² - 4ac to determine root types", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Discriminant Significance"], numerical: ["Quadratic Formula Calculations", "Word Problem Modeling"] }
    },
    {
      id: "arithmetic_progressions_10",
      chapterNumber: 5,
      title: "5. Arithmetic Progressions",
      chapterName: "Arithmetic Progressions",
      topics: ["AP Definition", "nth Term of an AP", "Sum of First n Terms"],
      subtopics: [
        "Motivation for studying Arithmetic Progression",
        "Derivation of nth term and sum of first n terms of AP and applications"
      ],
      lessonModules: [
        { title: "nth Term of AP", description: "Calculating common difference and term values", duration: "25 mins", level: "Foundational" },
        { title: "Sum Formula Applications", description: "Sum of first n terms in AP", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Common Difference Concept"], numerical: ["AP Term & Sum Problems"] }
    },
    {
      id: "triangles_10",
      chapterNumber: 6,
      title: "6. Triangles",
      chapterName: "Triangles",
      topics: ["Similar Figures", "Similarity Criteria (AA, SSS, SAS)", "Basic Proportionality Theorem"],
      subtopics: [
        "Definitions of similar figures, similarity of triangles",
        "Proofs of Basic Proportionality Theorem and similarity criteria (AA, SSS, SAS)"
      ],
      lessonModules: [
        { title: "Thales Theorem (BPT)", description: "Proving basic proportionality theorem", duration: "35 mins", level: "Foundational" },
        { title: "Similarity Criteria", description: "AA, SSS, and SAS similarity proofs", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Similarity Postulates", "Thales Theorem Proofs"], numerical: ["Proportional Side Calculations"] }
    },
    {
      id: "coordinate_geometry_10",
      chapterNumber: 7,
      title: "7. Coordinate Geometry",
      chapterName: "Coordinate Geometry",
      topics: ["Distance Formula", "Section Formula", "Area of Triangle"],
      subtopics: [
        "Review of coordinate geometry",
        "Distance formula and Section formula (internal division)",
        "Area of a triangle"
      ],
      lessonModules: [
        { title: "Distance & Section Formulae", description: "Calculating distance and division points", duration: "30 mins", level: "Foundational" },
        { title: "Area of Coordinate Triangle", description: "Shoelace and standard triangle area formula", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Coordinate Geometry Applications"], numerical: ["Distance Computations", "Collinearity Proofs"] }
    },
    {
      id: "introduction_trigonometry_10",
      chapterNumber: 8,
      title: "8. Introduction to Trigonometry",
      chapterName: "Introduction to Trigonometry",
      topics: ["Trigonometric Ratios", "Values at Specific Angles", "Trigonometric Identities"],
      subtopics: [
        "Trigonometric ratios of an acute angle of a right-angled triangle",
        "Values of trigonometric ratios of 30°, 45°, and 60°",
        "Trigonometric identities: sin²θ + cos²θ = 1 and applications"
      ],
      lessonModules: [
        { title: "Trig Ratios & Table Values", description: "Defining sin, cos, tan and standard angles", duration: "30 mins", level: "Foundational" },
        { title: "Trigonometric Identities", description: "Proving and applying Pythagorean identities", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Right Triangle Ratios", "Identity Transformations"], numerical: ["Ratio Evaluations", "Identity Proofs"] }
    },
    {
      id: "some_applications_trigonometry_10",
      chapterNumber: 9,
      title: "9. Some Applications of Trigonometry",
      chapterName: "Some Applications of Trigonometry",
      topics: ["Heights and Distances", "Angle of Elevation and Depression"],
      subtopics: [
        "Heights and distances: angle of elevation, angle of depression",
        "Simple problems on heights and distances involving right triangles"
      ],
      lessonModules: [
        { title: "Elevation & Depression Angles", description: "Visualizing line of sight and angles", duration: "30 mins", level: "Foundational" },
        { title: "Solving Height Problems", description: "Real-world building and tower height calculations", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Line of Sight Visualization"], numerical: ["Tower/Tree Height Calculations"] }
    },
    {
      id: "circles_10",
      chapterNumber: 10,
      title: "10. Circles",
      chapterName: "Circles",
      topics: ["Tangent to a Circle", "Properties of Tangents"],
      subtopics: [
        "Tangent to a circle at point of contact",
        "Proof that tangent at any point is perpendicular to radius through point of contact",
        "Proof that lengths of tangents drawn from external point are equal"
      ],
      lessonModules: [
        { title: "Tangent Theorems", description: "Perpendicular radius property and tangent lengths", duration: "30 mins", level: "Foundational" },
        { title: "Tangent Problem Solving", description: "Advanced circle geometry proofs", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Tangent Properties"], numerical: ["External Tangent Length Calculations"] }
    },
    {
      id: "areas_related_circles_10",
      chapterNumber: 11,
      title: "11. Areas Related to Circles",
      chapterName: "Areas Related to Circles",
      topics: ["Perimeter and Area of Circle", "Area of Sector and Segment"],
      subtopics: [
        "Area of sectors and segments of a circle",
        "Problems based on areas and perimeter of plane figures (central angle up to 120°)"
      ],
      lessonModules: [
        { title: "Sector & Segment Areas", description: "Calculating arc length and sector area", duration: "25 mins", level: "Foundational" },
        { title: "Composite Figure Areas", description: "Areas of shaded regions in combined figures", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Sector Area Derivations"], numerical: ["Segment Area Calculations", "Shaded Region Problems"] }
    },
    {
      id: "surface_areas_volumes_10",
      chapterNumber: 12,
      title: "12. Surface Areas and Volumes",
      chapterName: "Surface Areas and Volumes",
      topics: ["Combination of Solids", "Conversion of Solids"],
      subtopics: [
        "Surface area and volume of combinations of cubes, cuboids, spheres, hemispheres, right circular cylinders/cones",
        "Problems involving converting one type of metallic solid into another"
      ],
      lessonModules: [
        { title: "Combined Solid Surface Area", description: "Total surface area of joined solids", duration: "30 mins", level: "Foundational" },
        { title: "Solid Conversions", description: "Conservation of volume during melting/recasting", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Volume Conservation Principles"], numerical: ["Recasting Solid Problems", "Combined Container Volumes"] }
    },
    {
      id: "statistics_10",
      chapterNumber: 13,
      title: "13. Statistics",
      chapterName: "Statistics",
      topics: ["Mean, Median, Mode of Grouped Data", "Cumulative Frequency Graphs"],
      subtopics: [
        "Mean, median and mode of grouped data",
        "Cumulative frequency graph (ogive)"
      ],
      lessonModules: [
        { title: "Grouped Mean, Median, Mode", description: "Formula application for grouped frequency tables", duration: "35 mins", level: "Foundational" },
        { title: "Ogive Construction", description: "Less than and more than cumulative frequency curves", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Empirical Relationship between Mean, Median, Mode"], numerical: ["Grouped Data Calculations", "Ogive Median Extraction"] }
    },
    {
      id: "probability_10",
      chapterNumber: 14,
      title: "14. Probability",
      chapterName: "Probability",
      topics: ["Classical Definition", "Simple Events"],
      subtopics: [
        "Classical definition of probability",
        "Simple problems on finding probability of an event"
      ],
      lessonModules: [
        { title: "Classical Probability", description: "Sample space and favorable outcomes", duration: "25 mins", level: "Foundational" }
      ],
      practiceGoals: { conceptual: ["Probability Axioms"], numerical: ["Dice, Card, and Coin Probability Problems"] }
    }
  ]
};

export const INDIA_CBSE_PHYSICS_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Physics",
  chapters: [
    {
      id: "light_reflection_refraction_10",
      chapterNumber: 1,
      title: "1. Light - Reflection and Refraction",
      chapterName: "Light - Reflection and Refraction",
      topics: ["Spherical Mirrors", "Refraction & Refractive Index", "Spherical Lenses & Power"],
      subtopics: [
        "Reflection of light by spherical mirrors, mirror formula and magnification",
        "Refraction of light, laws of refraction, refractive index",
        "Refraction by spherical lenses, lens formula, power of a lens"
      ],
      lessonModules: [
        { title: "Spherical Mirrors & Ray Diagrams", description: "Concave and convex mirror reflections", duration: "30 mins", level: "Foundational" },
        { title: "Refraction & Lenses", description: "Snell's law, lens formula, and optical power", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Mirror/Lens Sign Conventions"], numerical: ["Mirror & Lens Formula Problems", "Refractive Index Calculations"] }
    },
    {
      id: "human_eye_colorful_world_10",
      chapterNumber: 2,
      title: "2. Human Eye and the Colorful World",
      chapterName: "Human Eye and the Colorful World",
      topics: ["Human Eye Accommodation", "Vision Defects & Correction", "Prism Dispersion & Scattering"],
      subtopics: [
        "Human eye, power of accommodation, defects of vision (myopia, hypermetropia, presbyopia) and correction",
        "Refraction through a prism, dispersion, atmospheric refraction, and scattering of light"
      ],
      lessonModules: [
        { title: "Eye Accommodation & Defects", description: "Myopia and hypermetropia correction with lenses", duration: "30 mins", level: "Foundational" },
        { title: "Prism & Scattering Phenomena", description: "Rainbow formation, blue sky, and red sunset", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Vision Correction Principles", "Rayleigh Scattering"], numerical: ["Spectacle Power Calculations"] }
    },
    {
      id: "electricity_10",
      chapterNumber: 3,
      title: "3. Electricity",
      chapterName: "Electricity",
      topics: ["Electric Current & Potential", "Ohm's Law & Resistance", "Series/Parallel Resistors", "Heating Effect of Current"],
      subtopics: [
        "Electric current, potential difference, Ohm's law, resistance, resistivity",
        "Series and parallel combination of resistors",
        "Heating effect of electric current and electric power"
      ],
      lessonModules: [
        { title: "Ohm's Law & Resistance", description: "V = IR and factors affecting resistance", duration: "30 mins", level: "Foundational" },
        { title: "Resistor Circuits & Joule Heating", description: "Equivalent resistance and electric power", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Resistivity vs Resistance"], numerical: ["Circuit Equivalent Resistance", "Electrical Energy Billing"] }
    },
    {
      id: "magnetic_effects_electric_current_10",
      chapterNumber: 4,
      title: "4. Magnetic Effects of Electric Current",
      chapterName: "Magnetic Effects of Electric Current",
      topics: ["Magnetic Fields & Field Lines", "Force on Current Conductor", "Electromagnetic Induction", "Electric Motor & Generator"],
      subtopics: [
        "Magnetic field, field lines, field due to current-carrying conductor, right hand rule",
        "Fleming's Left Hand Rule, electric motor, electromagnetic induction, generator",
        "Domestic electric circuits: overloading and earthing"
      ],
      lessonModules: [
        { title: "Magnetic Field & Lorentz Force", description: "Field lines and Fleming's left hand rule", duration: "30 mins", level: "Foundational" },
        { title: "EMI & Domestic Circuits", description: "Faraday's induction and household wiring", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Electromagnetic Induction Principles", "Household Safety Fuses"], numerical: [] }
    },
    {
      id: "sources_energy_10",
      chapterNumber: 5,
      title: "5. Sources of Energy",
      chapterName: "Sources of Energy",
      topics: ["Conventional & Non-Conventional Sources", "Solar & Nuclear Energy"],
      subtopics: ["Conventional and non-conventional energy sources: fossil fuels, solar, wind, hydro, and nuclear energy"]
    }
  ]
};

export const INDIA_CBSE_CHEMISTRY_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Chemistry",
  chapters: [
    {
      id: "chemical_reactions_equations_10",
      chapterNumber: 1,
      title: "1. Chemical Reactions and Equations",
      chapterName: "Chemical Reactions and Equations",
      topics: ["Chemical Equations & Balancing", "Types of Chemical Reactions", "Oxidation and Reduction"],
      subtopics: [
        "Chemical equation, balancing chemical equations",
        "Types of reactions: combination, decomposition, displacement, double displacement, oxidation and reduction"
      ],
      lessonModules: [
        { title: "Balancing Chemical Equations", description: "Law of conservation of mass in reactions", duration: "25 mins", level: "Foundational" },
        { title: "Reaction Types & Redox", description: "Identifying redox and precipitation reactions", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Redox Definitions"], numerical: ["Equation Balancing"] }
    },
    {
      id: "acids_bases_salts_10",
      chapterNumber: 2,
      title: "2. Acids, Bases and Salts",
      chapterName: "Acids, Bases and Salts",
      topics: ["Chemical Properties", "pH Scale", "Industrial Salts"],
      subtopics: [
        "Chemical properties of acids and bases, reaction with metals and carbonates",
        "pH scale, importance in digestion and soil, preparation of sodium hydroxide, bleaching powder, baking soda, washing soda, plaster of paris"
      ],
      lessonModules: [
        { title: "Acids, Bases & pH", description: "Hydrogen ions and pH scale applications", duration: "30 mins", level: "Foundational" },
        { title: "Industrial Salts Preparation", description: "Chlor-alkali process and salt properties", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["pH Significance"], numerical: ["Salt Water of Crystallization Calculations"] }
    },
    {
      id: "metals_non_metals_10",
      chapterNumber: 3,
      title: "3. Metals and Non-metals",
      chapterName: "Metals and Non-metals",
      topics: ["Properties & Reactivity Series", "Ionic Bonds", "Metallurgy & Corrosion"],
      subtopics: [
        "Properties of metals and non-metals, reactivity series, ionic bonding, metallurgy, and corrosion prevention"
      ]
    },
    {
      id: "carbon_compounds_10",
      chapterNumber: 4,
      title: "4. Carbon and its Compounds",
      chapterName: "Carbon and its Compounds",
      topics: ["Covalent Bonding", "Homologous Series", "Ethanol, Ethanoic Acid", "Soaps & Detergents"],
      subtopics: [
        "Covalent bonding, versatile carbon, homologous series, ethanol, ethanoic acid, soaps and detergents"
      ]
    },
    {
      id: "periodic_classification_10",
      chapterNumber: 5,
      title: "5. Periodic Classification of Elements",
      chapterName: "Periodic Classification of Elements",
      topics: ["Early Attempts & Mendeleev", "Modern Periodic Table"],
      subtopics: ["Early classification attempts, Mendeleev's table, Modern periodic table and trends"]
    }
  ]
};

export const INDIA_CBSE_BIOLOGY_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Biology",
  chapters: [
    {
      id: "life_processes_10",
      chapterNumber: 1,
      title: "1. Life Processes",
      chapterName: "Life Processes",
      topics: ["Nutrition", "Respiration", "Transportation", "Excretion"],
      subtopics: [
        "Nutrition in plants and animals, respiration, human circulatory and excretory systems, plant transport"
      ],
      lessonModules: [
        { title: "Human Nutrition & Respiration", description: "Alimentary canal and cellular respiration", duration: "35 mins", level: "Foundational" },
        { title: "Circulation & Excretion", description: "Double circulation and nephron function", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: { conceptual: ["Nephron Filtration", "Double Circulation"], numerical: [] }
    },
    {
      id: "control_coordination_10",
      chapterNumber: 2,
      title: "2. Control and Coordination",
      chapterName: "Control and Coordination",
      topics: ["Nervous System & Reflex Action", "Plant Hormones", "Animal Endocrine System"],
      subtopics: ["Reflex arc, human brain, plant tropic movements, and animal endocrine hormones"]
    },
    {
      id: "reproduce_organisms_10",
      chapterNumber: 3,
      title: "3. How do Organisms Reproduce?",
      chapterName: "How do Organisms Reproduce?",
      topics: ["Asexual & Sexual Reproduction", "Reproductive Health"],
      subtopics: ["Reproductive methods in plants and animals, human reproductive system, and health"]
    },
    {
      id: "heredity_evolution_10",
      chapterNumber: 4,
      title: "4. Heredity and Evolution",
      chapterName: "Heredity and Evolution",
      topics: ["Mendel's Laws", "Sex Determination"],
      subtopics: ["Mendel's monohybrid and dihybrid crosses, inheritance laws, and sex determination"]
    },
    {
      id: "our_environment_10",
      chapterNumber: 5,
      title: "5. Our Environment",
      chapterName: "Our Environment",
      topics: ["Ecosystems", "Food Chains & Trophic Levels", "Waste Management"],
      subtopics: ["Ecosystem components, food chains, biological magnification, and ozone layer protection"]
    }
  ]
};

export const INDIA_CBSE_COMPUTER_SCIENCE_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Computer Science",
  chapters: [
    {
      id: "digital_documentation_10",
      chapterNumber: 1,
      title: "1. Digital Documentation (Advanced)",
      chapterName: "Digital Documentation",
      topics: ["Styles & Templates", "Mail Merge"],
      subtopics: ["Working with styles, templates, and advanced mail merge"]
    },
    {
      id: "electronic_spreadsheet_10",
      chapterNumber: 2,
      title: "2. Electronic Spreadsheet (Advanced)",
      chapterName: "Electronic Spreadsheet",
      topics: ["Consolidation & Macros"],
      subtopics: ["Consolidating spreadsheet data, scenario analysis, and macros"]
    },
    {
      id: "database_management_10",
      chapterNumber: 3,
      title: "3. Database Management Systems",
      chapterName: "Database Management Systems",
      topics: ["Relational DBMS & Queries"],
      subtopics: ["Primary/foreign keys, tables, and database queries in Base"]
    },
    {
      id: "web_applications_security_10",
      chapterNumber: 4,
      title: "4. Web Applications & Security",
      chapterName: "Web Applications & Security",
      topics: ["Internet Security & Safety"],
      subtopics: ["Networking fundamentals, malware protection, and workplace safety"]
    }
  ]
};

export const INDIA_CBSE_HISTORY_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "History",
  chapters: [
    {
      id: "rise_nationalism_europe_10",
      chapterNumber: 1,
      title: "1. The Rise of Nationalism in Europe",
      chapterName: "The Rise of Nationalism in Europe",
      topics: ["French Revolution", "Unification of Italy and Germany"],
      subtopics: ["Nationalism in Europe, 1848 revolutions, and unification of Italy and Germany"]
    },
    {
      id: "nationalism_india_10",
      chapterNumber: 2,
      title: "2. Nationalism in India",
      chapterName: "Nationalism in India",
      topics: ["Non-Cooperation", "Civil Disobedience"],
      subtopics: ["Gandhi's movements, Non-Cooperation, Civil Disobedience, and national awakening"]
    },
    {
      id: "making_global_world_10",
      chapterNumber: 3,
      title: "3. The Making of a Global World",
      chapterName: "The Making of a Global World",
      topics: ["Silk Routes", "Global Economy & Depression"],
      subtopics: ["Pre-modern trade, 19th-century economy, and Great Depression"]
    },
    {
      id: "age_industrialisation_10",
      chapterNumber: 4,
      title: "4. The Age of Industrialisation",
      chapterName: "The Age of Industrialisation",
      topics: ["Industrial Growth", "Indian Markets"],
      subtopics: ["Industrial revolution in Britain and impact on Indian textile industries"]
    },
    {
      id: "print_culture_modern_world_10",
      chapterNumber: 5,
      title: "5. Print Culture and the Modern World",
      chapterName: "Print Culture and the Modern World",
      topics: ["Print Revolution", "Indian Print Culture"],
      subtopics: ["Print technology evolution and role in Indian social reform and nationalism"]
    }
  ]
};

export const INDIA_CBSE_GEOGRAPHY_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Geography",
  chapters: [
    {
      id: "resources_development_10",
      chapterNumber: 1,
      title: "1. Resources and Development",
      chapterName: "Resources and Development",
      topics: ["Resource Planning", "Soil Types"],
      subtopics: ["Resource planning, land use, and major soil types in India"]
    },
    {
      id: "forest_wildlife_resources_10",
      chapterNumber: 2,
      title: "2. Forest and Wildlife Resources",
      chapterName: "Forest and Wildlife Resources",
      topics: ["Biodiversity & Conservation"],
      subtopics: ["Flora and fauna depletion, conservation initiatives, and community forestry"]
    },
    {
      id: "water_resources_10",
      chapterNumber: 3,
      title: "3. Water Resources",
      chapterName: "Water Resources",
      topics: ["Dams & Rainwater Harvesting"],
      subtopics: ["Water scarcity, multipurpose dams, and traditional rainwater harvesting"]
    },
    {
      id: "agriculture_10",
      chapterNumber: 4,
      title: "4. Agriculture",
      chapterName: "Agriculture",
      topics: ["Farming Types & Crops"],
      subtopics: ["Types of farming, major crops, and agricultural technological reforms"]
    },
    {
      id: "minerals_energy_resources_10",
      chapterNumber: 5,
      title: "5. Minerals and Energy Resources",
      chapterName: "Minerals and Energy Resources",
      topics: ["Mineral Belts & Energy"],
      subtopics: ["Mineral distribution and conventional/non-conventional energy sources"]
    },
    {
      id: "manufacturing_industries_10",
      chapterNumber: 6,
      title: "6. Manufacturing Industries",
      chapterName: "Manufacturing Industries",
      topics: ["Industrial Location & Pollution"],
      subtopics: ["Industrial classification, location factors, and pollution abatement"]
    },
    {
      id: "lifelines_national_economy_10",
      chapterNumber: 7,
      title: "7. Lifelines of National Economy",
      chapterName: "Lifelines of National Economy",
      topics: ["Transport & Trade"],
      subtopics: ["Roadways, railways, waterways, airways, and international trade"]
    }
  ]
};

export const INDIA_CBSE_POLITICAL_SCIENCE_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Political Science",
  chapters: [
    {
      id: "power_sharing_10",
      chapterNumber: 1,
      title: "1. Power Sharing",
      chapterName: "Power Sharing",
      topics: ["Belgium & Sri Lanka", "Forms of Power Sharing"],
      subtopics: ["Power sharing models and importance in democracies"]
    },
    {
      id: "federalism_10",
      chapterNumber: 2,
      title: "2. Federalism",
      chapterName: "Federalism",
      topics: ["Federal System & Decentralization"],
      subtopics: ["Indian federalism, linguistic states, and local self-government"]
    },
    {
      id: "gender_religion_caste_10",
      chapterNumber: 3,
      title: "3. Gender, Religion and Caste",
      chapterName: "Gender, Religion and Caste",
      topics: ["Social Cleavages & Politics"],
      subtopics: ["Gender, religion, communalism, and caste in Indian politics"]
    },
    {
      id: "political_parties_10",
      chapterNumber: 4,
      title: "4. Political Parties",
      chapterName: "Political Parties",
      topics: ["National & State Parties"],
      subtopics: ["Party systems, national/regional parties, and electoral reforms"]
    },
    {
      id: "outcomes_democracy_10",
      chapterNumber: 5,
      title: "5. Outcomes of Democracy",
      chapterName: "Outcomes of Democracy",
      topics: ["Democratic Quality & Rights"],
      subtopics: ["Assessing democracy's success in accountability, equality, and freedom"]
    }
  ]
};

export const INDIA_CBSE_ECONOMICS_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Economics",
  chapters: [
    {
      id: "development_10",
      chapterNumber: 1,
      title: "1. Development",
      chapterName: "Development",
      topics: ["Development Indicators & Sustainability"],
      subtopics: ["Development goals, national income, HDI, and sustainable development"]
    },
    {
      id: "sectors_indian_economy_10",
      chapterNumber: 2,
      title: "2. Sectors of the Indian Economy",
      chapterName: "Sectors of the Indian Economy",
      topics: ["Primary, Secondary, Tertiary Sectors"],
      subtopics: ["Economic sectors, organized/unorganized employment, and public/private sectors"]
    },
    {
      id: "money_credit_10",
      chapterNumber: 3,
      title: "3. Money and Credit",
      chapterName: "Money and Credit",
      topics: ["Currency & Formal/Informal Credit"],
      subtopics: ["Medium of exchange, bank credit, formal/informal loans, and SHGs"]
    },
    {
      id: "globalisation_indian_economy_10",
      chapterNumber: 4,
      title: "4. Globalisation and the Indian Economy",
      chapterName: "Globalisation and the Indian Economy",
      topics: ["MNCs & WTO"],
      subtopics: ["MNCs, globalization drivers, WTO role, and impact on India"]
    },
    {
      id: "consumer_rights_10",
      chapterNumber: 5,
      title: "5. Consumer Rights",
      chapterName: "Consumer Rights",
      topics: ["COPRA & Consumer Awareness"],
      subtopics: ["Consumer exploitation, COPRA act, and consumer awareness"]
    }
  ]
};

export const INDIA_CBSE_SST_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Social Science",
  chapters: [
    ...INDIA_CBSE_HISTORY_CLASS10_CURRICULUM.chapters,
    ...INDIA_CBSE_GEOGRAPHY_CLASS10_CURRICULUM.chapters,
    ...INDIA_CBSE_POLITICAL_SCIENCE_CLASS10_CURRICULUM.chapters,
    ...INDIA_CBSE_ECONOMICS_CLASS10_CURRICULUM.chapters
  ]
};

export const INDIA_CBSE_SCIENCE_CLASS10_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 10",
  subject: "Science",
  chapters: [
    ...INDIA_CBSE_PHYSICS_CLASS10_CURRICULUM.chapters,
    ...INDIA_CBSE_CHEMISTRY_CLASS10_CURRICULUM.chapters,
    ...INDIA_CBSE_BIOLOGY_CLASS10_CURRICULUM.chapters
  ]
};

export const INDIA_CBSE_IT_CLASS10_CURRICULUM = INDIA_CBSE_COMPUTER_SCIENCE_CLASS10_CURRICULUM;

export const INDIA_CBSE_MATH_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Mathematics",
  chapters: [
    {
      id: "real_numbers_9",
      chapterNumber: 1,
      title: "1. Real Numbers",
      chapterName: "Real Numbers",
      topics: ["Rational Numbers", "Irrational Numbers", "Decimal Expansions", "Operations on Real Numbers", "Laws of Exponents"],
      subtopics: [
        "Review of number line, rational numbers as terminating/recurring decimals",
        "Irrational numbers, representation on number line, existence of √2, √3",
        "Real numbers and their decimal expansions",
        "Operations on real numbers and rationalization of denominators",
        "Laws of exponents for real numbers with rational powers"
      ],
      lessonModules: [
        { title: "Number Line & Rational Numbers", description: "Review of number line representation and decimal conversions", duration: "25 mins", level: "Foundational" },
        { title: "Irrational Numbers & Surds", description: "Proving irrationality and plotting on number line", duration: "30 mins", level: "Core Formulation" },
        { title: "Rationalization & Exponents", description: "Simplifying radical expressions and exponent laws", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Rational vs Irrational Distinction", "Decimal Expansion Patterns", "Surd Simplification"],
        numerical: ["p/q Conversion", "Denominator Rationalization", "Exponent Laws Evaluation"]
      }
    },
    {
      id: "polynomials_9",
      chapterNumber: 2,
      title: "2. Polynomials",
      chapterName: "Polynomials",
      topics: ["Polynomials in One Variable", "Zeroes of a Polynomial", "Remainder Theorem", "Factorization", "Algebraic Identities"],
      subtopics: [
        "Definition of polynomial in one variable, coefficients, degree, zeros",
        "Remainder Theorem and statement/proof for linear divisors",
        "Factor Theorem and factorization of quadratic and cubic polynomials",
        "Algebraic identities: (x+y+z)², (x+y)³, (x-y)³, x³+y³+z³-3xyz"
      ],
      lessonModules: [
        { title: "Polynomial Basics & Zeros", description: "Degrees, coefficients, and evaluating zeros", duration: "25 mins", level: "Foundational" },
        { title: "Remainder & Factor Theorems", description: "Applying remainder theorem and factoring polynomials", duration: "30 mins", level: "Core Formulation" },
        { title: "Algebraic Identities Expansion", description: "Mastering standard algebraic expansion identities", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Degree & Coefficient Identification", "Factor Theorem Proofs"],
        numerical: ["Remainder Evaluation", "Cubic Polynomial Factorization", "Identity Application"]
      }
    },
    {
      id: "coordinate_geometry_9",
      chapterNumber: 3,
      title: "3. Coordinate Geometry",
      chapterName: "Coordinate Geometry",
      topics: ["Cartesian System", "Plotting Points", "Coordinates (x, y)"],
      subtopics: [
        "Cartesian system, Cartesian plane, axes, origin, quadrants",
        "Plotting points in the plane whose coordinates are given",
        "Abscissa and ordinate terminology"
      ],
      lessonModules: [
        { title: "Cartesian Plane Introduction", description: "Axes, quadrants, and coordinate pairs", duration: "20 mins", level: "Foundational" },
        { title: "Plotting & Reading Points", description: "Locating points on coordinate plane", duration: "25 mins", level: "Core Formulation" }
      ],
      practiceGoals: {
        conceptual: ["Quadrant Sign Conventions", "Axis Projections"],
        numerical: ["Point Plotting", "Distance Coordinates"]
      }
    },
    {
      id: "linear_equations_two_variables_9",
      chapterNumber: 4,
      title: "4. Linear Equations in Two Variables",
      chapterName: "Linear Equations in Two Variables",
      topics: ["Linear Equations ax + by + c = 0", "Solutions", "Graph of Linear Equations", "Parallel Lines"],
      subtopics: [
        "Introduction to linear equation in two variables ax + by + c = 0",
        "Solutions of linear equation and geometrical representation on graph",
        "Equations of lines parallel to x-axis and y-axis"
      ],
      lessonModules: [
        { title: "Formulating Linear Equations", description: "Writing real-life problems as equations", duration: "25 mins", level: "Foundational" },
        { title: "Graphical Solutions", description: "Plotting lines and finding solutions", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Infinite Solutions Concept", "Geometric Representation"],
        numerical: ["Graph Plotting", "Intercept Calculations"]
      }
    },
    {
      id: "lines_and_angles_9",
      chapterNumber: 5,
      title: "5. Lines and Angles",
      chapterName: "Lines and Angles",
      topics: ["Basic Terms", "Intersecting & Parallel Lines", "Angle Sum Property"],
      subtopics: [
        "Basic terms: line, ray, line segment, vertically opposite angles, linear pair",
        "Parallel lines and transversal, corresponding, alternate interior angles",
        "Lines parallel to same line, angle sum property of triangle"
      ],
      lessonModules: [
        { title: "Angle Pairs & Transversals", description: "Corresponding and alternate angles", duration: "30 mins", level: "Foundational" },
        { title: "Triangle Angle Sum Theorem", description: "Proving angle sum and exterior angle properties", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Transversal Axioms", "Exterior Angle Theorem"],
        numerical: ["Angle Chasing Problems", "Parallel Line Proofs"]
      }
    },
    {
      id: "triangles_9",
      chapterNumber: 6,
      title: "6. Triangles",
      chapterName: "Triangles",
      topics: ["Congruence Criteria (SAS, ASA, SSS, RHS)", "Properties of Triangles", "Inequalities"],
      subtopics: [
        "Congruence of triangles, SAS, ASA, AAS, SSS criteria with proofs",
        "Properties of isosceles triangles",
        "Inequalities in a triangle"
      ],
      lessonModules: [
        { title: "Congruence Criteria", description: "SAS, ASA, and SSS proofs", duration: "35 mins", level: "Foundational" },
        { title: "Isosceles & Inequalities", description: "Properties of side-angle relationships", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Congruence Postulates", "Triangle Inequality Proofs"],
        numerical: ["Congruence Proof Deductions", "Side Length Bounds"]
      }
    },
    {
      id: "quadrilaterals_9",
      chapterNumber: 7,
      title: "7. Quadrilaterals",
      chapterName: "Quadrilaterals",
      topics: ["Angle Sum Property", "Parallelograms", "Mid-Point Theorem"],
      subtopics: [
        "Angle sum property of quadrilateral, types: parallelogram, rhombus, rectangle, square",
        "Properties of parallelogram and conditions for quadrilaterals",
        "Mid-point Theorem and its converse"
      ],
      lessonModules: [
        { title: "Parallelogram Properties", description: "Diagonals and opposite sides/angles", duration: "30 mins", level: "Foundational" },
        { title: "Mid-Point Theorem Proof", description: "Proving mid-point theorem and applications", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Parallelogram Characterization", "Mid-Point Geometry"],
        numerical: ["Quadrilateral Proofs", "Intercept Calculations"]
      }
    },
    {
      id: "circles_9",
      chapterNumber: 8,
      title: "8. Circles",
      chapterName: "Circles",
      topics: ["Chords & Arcs", "Perpendicular from Center", "Equal Chords", "Cyclic Quadrilaterals"],
      subtopics: [
        "Angle subtended by chord at point, perpendicular from center to chord",
        "Equal chords and distances from center",
        "Angle subtended by arc at center vs remaining part, cyclic quadrilaterals"
      ],
      lessonModules: [
        { title: "Chord Theorems", description: "Perpendicular bisector of chords", duration: "30 mins", level: "Foundational" },
        { title: "Cyclic Quadrilaterals", description: "Opposite angles sum to 180°", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Arc-Angle Relations", "Cyclic Properties"],
        numerical: ["Angle Subtense Calculations", "Radius-Chord Problems"]
      }
    },
    {
      id: "herons_formula_9",
      chapterNumber: 9,
      title: "9. Heron's Formula",
      chapterName: "Heron's Formula",
      topics: ["Area of Triangle", "Applications in Quadrilaterals"],
      subtopics: [
        "Area of triangle given three sides using Heron's formula: √(s(s-a)(s-b)(s-c))",
        "Applications in finding areas of quadrilaterals and polygons"
      ],
      lessonModules: [
        { title: "Heron's Formula Derivation", description: "Semi-perimeter and area formula", duration: "25 mins", level: "Foundational" },
        { title: "Polygon Area Applications", description: "Dividing complex shapes into triangles", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Semi-Perimeter Concept", "Triangle Decomposition"],
        numerical: ["Scalene Triangle Area", "Quadrilateral Field Area"]
      }
    },
    {
      id: "surface_areas_volumes_9",
      chapterNumber: 10,
      title: "10. Surface Areas and Volumes",
      chapterName: "Surface Areas and Volumes",
      topics: ["Cuboid & Cube", "Cylinder, Cone & Sphere"],
      subtopics: [
        "Surface area and volume of cuboid and cube",
        "Surface area and volume of right circular cylinder, cone, sphere and hemisphere"
      ],
      lessonModules: [
        { title: "Prism & Cylinder Formulas", description: "Surface area and volume calculations", duration: "30 mins", level: "Foundational" },
        { title: "Sphere & Cone Mensuration", description: "Curved surface area and volume of spheres/cones", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Surface vs Volume Distinction", "Curved Surface Scaling"],
        numerical: ["Cylinder/Cone Calculations", "Hemisphere Capacity"]
      }
    },
    {
      id: "statistics_9",
      chapterNumber: 11,
      title: "11. Statistics",
      chapterName: "Statistics",
      topics: ["Data Collection", "Graphical Representation", "Mean, Median, Mode"],
      subtopics: [
        "Collection and presentation of grouped/ungrouped data",
        "Bar graphs, histograms, frequency polygons",
        "Mean, median, and mode of ungrouped data"
      ],
      lessonModules: [
        { title: "Graphical Data Display", description: "Histograms and frequency polygons", duration: "25 mins", level: "Foundational" },
        { title: "Central Tendency Measures", description: "Calculating mean, median, and mode", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Frequency Distribution", "Averages Interpretation"],
        numerical: ["Mean/Median Computation", "Histogram Construction"]
      }
    },
    {
      id: "probability_9",
      chapterNumber: 12,
      title: "12. Probability",
      chapterName: "Probability",
      topics: ["Experimental Probability", "Theoretical Probability"],
      subtopics: [
        "Experimental probability based on empirical trials",
        "Theoretical probability of elementary and complementary events"
      ],
      lessonModules: [
        { title: "Empirical Probability", description: "Trial-based frequency probability", duration: "20 mins", level: "Foundational" },
        { title: "Theoretical Probability", description: "Favorable over total possible outcomes", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Sample Space Concept", "Complementary Events P(E)+P(not E)=1"],
        numerical: ["Coin/Dice Probabilities", "Card Deck Probabilities"]
      }
    }
  ]
};

export const INDIA_CBSE_PHYSICS_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Physics",
  chapters: [
    {
      id: "motion_9",
      chapterNumber: 1,
      title: "1. Motion",
      chapterName: "Motion",
      topics: ["Describing Motion", "Rate of Change of Velocity", "Graphical Representation", "Equations of Motion", "Uniform Circular Motion"],
      subtopics: [
        "Distance and displacement, uniform and non-uniform motion",
        "Speed and velocity, acceleration, rate of change of velocity",
        "Distance-time and velocity-time graphs for uniform and uniformly accelerated motion",
        "Derivation of equations of motion: v = u + at, s = ut + ½at², v² = u² + 2as",
        "Uniform circular motion, centripetal acceleration concept"
      ],
      lessonModules: [
        { title: "Distance & Displacement", description: "Scalar vs vector kinematics", duration: "25 mins", level: "Foundational" },
        { title: "Kinematic Equations", description: "Deriving and applying v = u + at, s = ut + ½at²", duration: "35 mins", level: "Core Formulation" },
        { title: "Graphical Analysis & Circular Motion", description: "v-t graphs and circular velocity", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Speed vs Velocity", "Uniform Acceleration Interpretation"],
        numerical: ["SUVAT Equation Problems", "Graphical Slope/Area Calculations"]
      }
    },
    {
      id: "force_laws_motion_9",
      chapterNumber: 2,
      title: "2. Force and Laws of Motion",
      chapterName: "Force and Laws of Motion",
      topics: ["Balanced and Unbalanced Forces", "Newton's First Law", "Inertia and Mass", "Newton's Second Law", "Newton's Third Law", "Conservation of Momentum"],
      subtopics: [
        "Balanced and unbalanced forces, frictional force introduction",
        "Newton's First Law of Motion, inertia and relation with mass",
        "Newton's Second Law of Motion, momentum (p = mv), force equation F = ma",
        "Newton's Third Law of Motion, action-reaction pairs",
        "Law of conservation of momentum, recoil of gun calculations"
      ],
      lessonModules: [
        { title: "Inertia & First Law", description: "Newton's first law and mass inertia", duration: "25 mins", level: "Foundational" },
        { title: "Second Law & Momentum", description: "F = ma and conservation of momentum", duration: "35 mins", level: "Core Formulation" },
        { title: "Third Law & Recoil Problems", description: "Action-reaction and collision calculations", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Inertia Examples", "Action-Reaction Pairs"],
        numerical: ["F = ma Calculations", "Momentum Conservation Collisions"]
      }
    },
    {
      id: "gravitation_9",
      chapterNumber: 3,
      title: "3. Gravitation",
      chapterName: "Gravitation",
      topics: ["Universal Law of Gravitation", "Free Fall & Acceleration due to Gravity (g)", "Mass vs Weight", "Thrust and Pressure", "Archimedes' Principle", "Buoyancy & Relative Density"],
      subtopics: [
        "Universal Law of Gravitation (F = G m₁ m₂ / r²), value of G",
        "Free fall, acceleration due to gravity g = 9.8 m/s², motion of objects under gravity",
        "Mass and weight distinction, weight of object on moon",
        "Thrust and pressure in fluids, pressure in solids and liquids",
        "Archimedes' Principle, buoyancy, flotation conditions",
        "Relative density and hydrometers"
      ],
      lessonModules: [
        { title: "Universal Gravitation Law", description: "Gravitational force and inverse square law", duration: "30 mins", level: "Foundational" },
        { title: "Free Fall & Weight on Moon", description: "Acceleration due to gravity and mass vs weight", duration: "30 mins", level: "Core Formulation" },
        { title: "Buoyancy & Archimedes' Principle", description: "Upthrust, flotation, and relative density", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Free Fall Mechanics", "Archimedes Principle Explanation"],
        numerical: ["Gravitational Force Formulae", "Buoyancy & Relative Density Calculations"]
      }
    },
    {
      id: "work_energy_9",
      chapterNumber: 4,
      title: "4. Work and Energy",
      chapterName: "Work and Energy",
      topics: ["Work Definition & Conditions", "Kinetic Energy", "Potential Energy", "Law of Conservation of Energy", "Power"],
      subtopics: [
        "Work done by a constant force: W = F s cos θ, positive, negative and zero work",
        "Kinetic energy formula Ek = ½mv² and derivation",
        "Potential energy Ep = mgh and gravitational potential energy",
        "Law of Conservation of Energy, mechanical energy transformation",
        "Power: rate of doing work, units (Watt, horsepower)"
      ],
      lessonModules: [
        { title: "Work & Energy Basics", description: "Conditions for work and kinetic energy", duration: "25 mins", level: "Foundational" },
        { title: "Potential Energy & Conservation", description: "Gravitational PE and energy transformations", duration: "30 mins", level: "Core Formulation" },
        { title: "Power & Commercial Units", description: "Calculating power and kilowatt-hours (kWh)", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Work Sign Conventions", "Energy Conservation Principle"],
        numerical: ["Kinetic/Potential Energy Calculations", "Power and kWh Billing Problems"]
      }
    },
    {
      id: "sound_9",
      chapterNumber: 5,
      title: "5. Sound",
      chapterName: "Sound",
      topics: ["Production & Propagation of Sound", "Longitudinal Waves", "Characteristics of Sound Wave", "Reflection of Sound & Echo", "Human Ear"],
      subtopics: [
        "Production of sound by vibration, propagation through medium (compressions and rarefactions)",
        "Longitudinal nature of sound waves, speed of sound in different media",
        "Characteristics of sound: pitch, loudness, quality (timbre), wavelength, frequency, amplitude",
        "Reflection of sound, echo, reverberation, applications in SONAR",
        "Audible range, infrasound and ultrasound, structure of human ear"
      ],
      lessonModules: [
        { title: "Wave Propagation & Speed", description: "Longitudinal waves and speed of sound", duration: "30 mins", level: "Foundational" },
        { title: "Wave Characteristics & Echoes", description: "Frequency, wavelength, echo, and SONAR", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Longitudinal vs Transverse Waves", "Ultrasound Applications"],
        numerical: ["Speed = Distance / Time (Echo calculations)", "Frequency-Wavelength (v = fλ)"]
      }
    }
  ]
};

export const INDIA_CBSE_CHEMISTRY_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Chemistry",
  chapters: [
    {
      id: "matter_surroundings_9",
      chapterNumber: 1,
      title: "1. Matter in Our Surroundings",
      chapterName: "Matter in Our Surroundings",
      topics: ["Physical Nature of Matter", "States of Matter", "Change of State", "Evaporation"],
      subtopics: [
        "Particle nature of matter, characteristics of particles of matter",
        "States of matter: solid, liquid, gas, plasma, Bose-Einstein condensate",
        "Interconversion of states of matter: melting, boiling, evaporation, sublimation, condensation",
        "Factors affecting evaporation and cooling effect caused by evaporation"
      ],
      lessonModules: [
        { title: "Particle Nature of Matter", description: "Diffusion and kinetic particle theory", duration: "25 mins", level: "Foundational" },
        { title: "States & Interconversion", description: "Latent heat of fusion and vaporization", duration: "30 mins", level: "Core Formulation" },
        { title: "Evaporation Cooling Mechanism", description: "Surface phenomenon and cooling effects", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Kinetic Theory of Matter", "Latent Heat Explanation"],
        numerical: ["Temperature Conversions (°C to Kelvin)", "Latent Heat Energy Calculations"]
      }
    },
    {
      id: "matter_around_us_pure_9",
      chapterNumber: 2,
      title: "2. Is Matter Around Us Pure",
      chapterName: "Is Matter Around Us Pure",
      topics: ["Pure Substances vs Mixtures", "Solutions, Colloids & Suspensions", "Separation of Components of Mixtures", "Physical vs Chemical Changes"],
      subtopics: [
        "Classification of matter: pure substances (elements, compounds) vs mixtures (homogeneous, heterogeneous)",
        "Solutions, concentration of solutions, solubility, suspensions, and colloidal solutions (Tyndall effect)",
        "Separation techniques: evaporation, centrifugation, sublimation, chromatography, distillation, fractional distillation",
        "Physical and chemical changes with examples"
      ],
      lessonModules: [
        { title: "Mixtures & Solutions", description: "True solutions, colloids, and Tyndall effect", duration: "30 mins", level: "Foundational" },
        { title: "Separation Methods", description: "Distillation, chromatography, and crystallization", duration: "35 mins", level: "Core Formulation" },
        { title: "Physical vs Chemical Changes", description: "Identifying transformation types", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Colloid vs Suspension vs Solution", "Physical Change Criteria"],
        numerical: ["Solution Concentration (Mass/Mass %)", "Solubility Curve Problems"]
      }
    },
    {
      id: "atoms_molecules_9",
      chapterNumber: 3,
      title: "3. Atoms and Molecules",
      chapterName: "Atoms and Molecules",
      topics: ["Laws of Chemical Combination", "Atoms and Symbols", "Molecules and Ions", "Chemical Formulae", "Mole Concept"],
      subtopics: [
        "Laws of Chemical Combination: Law of Conservation of Mass, Law of Constant Proportions",
        "Dalton's Atomic Theory, atomic mass, symbols of elements",
        "Molecules of elements and compounds, ions, writing chemical formulae",
        "Molecular mass, formula unit mass, Mole Concept, Avogadro constant (6.022 × 10²³)"
      ],
      lessonModules: [
        { title: "Chemical Combination Laws", description: "Conservation of mass and constant proportions", duration: "30 mins", level: "Foundational" },
        { title: "Chemical Formulae & Valency", description: "Writing ionic and molecular formulae", duration: "30 mins", level: "Core Formulation" },
        { title: "The Mole Concept", description: "Molar mass, Avogadro number, and gram-atoms", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Dalton's Postulates", "Valency & Radicals"],
        numerical: ["Formula Mass Calculations", "Mole-Mass-Number Interconversions"]
      }
    },
    {
      id: "structure_atom_9",
      chapterNumber: 4,
      title: "4. Structure of the Atom",
      chapterName: "Structure of the Atom",
      topics: ["Charged Particles in Matter", "Thomson's & Rutherford's Models", "Bohr's Model of Atom", "Distribution of Electrons", "Valency", "Atomic Number & Mass Number", "Isotopes & Isobars"],
      subtopics: [
        "Discovery of electron, proton, and neutron (cathode rays, anode rays)",
        "Thomson's model and Rutherford's alpha particle scattering experiment",
        "Bohr's model of atom, orbits, energy levels",
        "Distribution of electrons in shells (2n² rule), valence electrons, valency",
        "Atomic number (Z) and Mass number (A)",
        "Isotopes, applications of isotopes, and isobars"
      ],
      lessonModules: [
        { title: "Atomic Models", description: "Thomson, Rutherford, and Bohr models", duration: "30 mins", level: "Foundational" },
        { title: "Electronic Configuration & Valency", description: "Shell filling rules (2, 8, 18) and valency", duration: "30 mins", level: "Core Formulation" },
        { title: "Isotopes & Isobars", description: "Nuclear structure, isotopes, and medical uses", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Rutherford Scattering Alpha Particles", "Isotope Properties"],
        numerical: ["Subatomic Particle Counts (p, n, e)", "Average Atomic Mass Calculations"]
      }
    }
  ]
};

export const INDIA_CBSE_BIOLOGY_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Biology",
  chapters: [
    {
      id: "fundamental_unit_life_9",
      chapterNumber: 1,
      title: "1. The Fundamental Unit of Life",
      chapterName: "The Fundamental Unit of Life",
      topics: ["Cell Discovery & Theory", "Plasma Membrane & Cell Wall", "Cytoplasm & Cell Organelles", "Cell Division (Mitosis & Meiosis)"],
      subtopics: [
        "Discovery of cell (Robert Hooke), Cell Theory, unicellular and multicellular organisms",
        "Plasma membrane, osmosis, diffusion, cell wall structure and function",
        "Nucleus, cytoplasm, and cell organelles: Endoplasmic Reticulum, Golgi apparatus, Lysosomes, Mitochondria, Plastids, Vacuoles",
        "Cell division: Mitosis (growth and repair) and Meiosis (gamete formation)"
      ],
      lessonModules: [
        { title: "Cell Discovery & Structure", description: "Cell theory and plasma membrane transport", duration: "30 mins", level: "Foundational" },
        { title: "Cell Organelles", description: "Mitochondria, lysosomes, plastids, and ER", duration: "35 mins", level: "Core Formulation" },
        { title: "Cell Division", description: "Mitotic and meiotic division stages", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Osmosis in Plant/Animal Cells", "Organelle Functions"],
        numerical: ["Magnification Calculations", "Chromosome Count in Mitosis/Meiosis"]
      }
    },
    {
      id: "tissues_9",
      chapterNumber: 2,
      title: "2. Tissues",
      chapterName: "Tissues",
      topics: ["Plant Tissues (Meristematic & Permanent)", "Animal Tissues (Epithelial, Connective, Muscular, Nervous)"],
      subtopics: [
        "Definition of tissue, Plant tissues: Meristematic tissues (apical, intercalary, lateral) and Permanent tissues (simple: parenchyma, collenchyma, sclerenchyma; complex: xylem, phloem)",
        "Animal tissues: Epithelial tissue, Connective tissue (blood, bone, cartilage, ligament, tendon, adipose), Muscular tissue (striped, unstriped, cardiac), Nervous tissue (neuron structure)"
      ],
      lessonModules: [
        { title: "Plant Tissues", description: "Meristematic and permanent plant tissues", duration: "30 mins", level: "Foundational" },
        { title: "Animal Tissues", description: "Epithelial, connective, muscular, and nervous tissue", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Xylem vs Phloem Distinction", "Neuron Functional Anatomy"],
        numerical: ["Tissue Identification", "Stomatal Index Problems"]
      }
    },
    {
      id: "improvement_food_resources_9",
      chapterNumber: 3,
      title: "3. Improvement in Food Resources",
      chapterName: "Improvement in Food Resources",
      topics: ["Crop Variety Improvement", "Crop Production Management", "Crop Protection Management", "Animal Husbandry"],
      subtopics: [
        "Crop variety improvement (hybridization, genetic modification)",
        "Crop production management (nutrient management, manures, fertilizers, irrigation, cropping patterns)",
        "Crop protection management (weed control, insect pests, diseases)",
        "Animal husbandry: cattle farming, poultry, fish production (pisciculture), bee-keeping (apiculture)"
      ],
      lessonModules: [
        { title: "Crop Management & Nutrients", description: "Macro/micronutrients and irrigation", duration: "25 mins", level: "Foundational" },
        { title: "Animal Husbandry & Dairy", description: "Cattle breeding, poultry, and apiculture", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Macro vs Micronutrients", "Hybridization Objectives"],
        numerical: ["Yield Optimization", "Storage Loss Prevention"]
      }
    }
  ]
};

export const INDIA_CBSE_COMPUTER_SCIENCE_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Computer Science",
  chapters: [
    {
      id: "computer_system_basics_9",
      chapterNumber: 1,
      title: "1. Basics of Computer System",
      chapterName: "Basics of Computer System",
      topics: ["Hardware & Software", "CPU & Memory", "Input/Output Devices"],
      subtopics: [
        "Block diagram of computer, CPU, ALU, Control Unit, memory hierarchy",
        "Hardware components and peripheral devices",
        "Software types: System software (Operating Systems) and Application software"
      ],
      lessonModules: [
        { title: "Computer Architecture", description: "CPU, memory, and peripherals", duration: "25 mins", level: "Foundational" },
        { title: "Software Classification", description: "System vs application software", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Von Neumann Architecture", "RAM vs ROM"],
        numerical: ["Memory Unit Conversions (KB, MB, GB, TB)"]
      }
    },
    {
      id: "operating_system_9",
      chapterNumber: 2,
      title: "2. Operating System & File Management",
      chapterName: "Operating System & File Management",
      topics: ["OS Functions", "GUI Navigation", "File & Folder Management"],
      subtopics: [
        "Role of Operating System, user interface (GUI, CUI)",
        "Windows / Linux file system, creating folders, moving/copying files",
        "Utility software, disk defragmentation, virus and antivirus"
      ],
      lessonModules: [
        { title: "OS Roles & UI", description: "Operating system functions and GUI", duration: "25 mins", level: "Foundational" },
        { title: "File Organization", description: "Hierarchical file management", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["OS Resource Management", "File Extensions"],
        numerical: ["Path Navigation"]
      }
    },
    {
      id: "office_productivity_9",
      chapterNumber: 3,
      title: "3. Office Productivity Tools",
      chapterName: "Office Productivity Tools",
      topics: ["Word Processing", "Spreadsheet Basics", "Presentation Software"],
      subtopics: [
        "Word processor: formatting text, tables, mail merge in documents",
        "Spreadsheet: rows, columns, formulas, functions (SUM, AVERAGE, MAX, MIN)",
        "Presentation: creating slides, animations, transitions"
      ],
      lessonModules: [
        { title: "Word Processing & Mail Merge", description: "Advanced document formatting", duration: "30 mins", level: "Foundational" },
        { title: "Spreadsheet Formulas", description: "Using formulas and built-in functions", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Mail Merge Concepts", "Cell Addressing (Relative vs Absolute)"],
        numerical: ["Spreadsheet Formula Evaluation"]
      }
    },
    {
      id: "cyber_safety_9",
      chapterNumber: 4,
      title: "4. Cyber Safety & Digital Ethics",
      chapterName: "Cyber Safety & Digital Ethics",
      topics: ["Safe Web Browsing", "Cyberbullying", "Intellectual Property"],
      subtopics: [
        "Safe browsing habits, strong passwords, privacy settings",
        "Cyberbullying, cyberstalking, and reporting threats",
        "Copyright, plagiarism, and open-source software ethics"
      ],
      lessonModules: [
        { title: "Digital Citizenship", description: "Safe passwords and privacy", duration: "25 mins", level: "Foundational" },
        { title: "Cyber Ethics & Copyright", description: "Avoiding plagiarism and software piracy", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Password Security", "Copyright & Fair Use"],
        numerical: []
      }
    }
  ]
};

export const INDIA_CBSE_HISTORY_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "History",
  chapters: [
    {
      id: "french_revolution_9",
      chapterNumber: 1,
      title: "1. The French Revolution",
      chapterName: "The French Revolution",
      topics: ["French Society in 18th Century", "Outbreak of Revolution", "France Abolishes Monarchy", "Reign of Terror", "Women's Revolution & Slavery Abolition"],
      subtopics: [
        "Old Regime society, estates, subsistence crisis, rising middle class",
        "Outbreak of revolution, Fall of Bastille, Declaration of Rights of Man",
        "France becomes constitutional monarchy, abolition of monarchy, execution of Louis XVI",
        "The Reign of Terror (Robespierre), Directory rules France",
        "Role of women in revolution, abolition of slavery, legacy of French Revolution"
      ],
      lessonModules: [
        { title: "Old Regime & Crisis", description: "Three estates and economic crisis", duration: "30 mins", level: "Foundational" },
        { title: "Outbreak & Republic", description: "Storming of Bastille and Republic declaration", duration: "35 mins", level: "Core Formulation" },
        { title: "Terror & Legacy", description: "Robespierre and revolutionary ideals", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Liberty, Equality, Fraternity", "Causes of Revolution"],
        numerical: []
      }
    },
    {
      id: "socialism_europe_russian_rev_9",
      chapterNumber: 2,
      title: "2. Socialism in Europe and the Russian Revolution",
      chapterName: "Socialism in Europe and the Russian Revolution",
      topics: ["Age of Social Change", "Russian Empire in 1914", "1905 Revolution", "February & October Revolutions 1917", "Civil War & Stalin's Collectivization"],
      subtopics: [
        "Liberals, radicals, and conservatives, emergence of socialism",
        "Russian Empire, economy, society, and Tsar Nicholas II",
        "1905 Revolution, Bloody Sunday, creation of Dumas",
        "February Revolution in Petrograd, October Revolution (Bolshevik coup under Lenin)",
        "Civil war, making of Soviet socialist state, Stalin's collectivization and five-year plans"
      ],
      lessonModules: [
        { title: "Rise of Socialism", description: "Socialist ideas and Russian society", duration: "30 mins", level: "Foundational" },
        { title: "1917 Revolutions", description: "February and October Bolshevik revolutions", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Capitalism vs Socialism", "Bolshevik Policies"],
        numerical: []
      }
    },
    {
      id: "nazism_hitler_9",
      chapterNumber: 3,
      title: "3. Nazism and the Rise of Hitler",
      chapterName: "Nazism and the Rise of Hitler",
      topics: ["Birth of Weimar Republic", "Hitler's Rise to Power", "Nazi Worldview", "Youth & Women in Nazi Germany", "Holocaust & Crimes Against Humanity"],
      subtopics: [
        "Weimar Republic formation, Treaty of Versailles humiliation, economic crisis",
        "Hitler's background, Nazi party growth, destruction of democracy",
        "Nazi racial ideology, lebensraum, persecution of Jews and 'undesirables'",
        "Youth organizations, indoctrination, Nazi motherhood and women",
        "Holocaust documentation, concentration camps, and knowledge of the Holocaust"
      ],
      lessonModules: [
        { title: "Weimar Republic & Crisis", description: "Post-WWI Germany and economic depression", duration: "30 mins", level: "Foundational" },
        { title: "Nazi State & Holocaust", description: "Totalitarian control and genocide", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Totalitarianism", "Racial Hierarchy Theory"],
        numerical: []
      }
    },
    {
      id: "forest_society_colonialism_9",
      chapterNumber: 4,
      title: "4. Forest Society and Colonialism",
      chapterName: "Forest Society and Colonialism",
      topics: ["Why Deforestation?", "Commercial Forestry in India", "Rebellion in the Forest", "Forest Transformations in Java"],
      subtopics: [
        "Colonial rule and deforestation: railway expansion, shipbuilding, plantations",
        "Scientific forestry (Brandis), Forest Acts, livelihood impacts on villagers",
        "Rebellions in the forest: Bastar rebellion against colonial forest laws",
        "Forest transformations in Java: Dutch scientific forestry, Blandongdiensten system, Saminist movement"
      ],
      lessonModules: [
        { title: "Colonial Deforestation", description: "Commercial timber and railway expansion", duration: "30 mins", level: "Foundational" },
        { title: "Forest Acts & Rebellions", description: "Bastar and Java forest uprisings", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Scientific Forestry Critique", "Adivasi Rights"],
        numerical: []
      }
    },
    {
      id: "pastoralists_modern_world_9",
      chapterNumber: 5,
      title: "5. Pastoralists in the Modern World",
      chapterName: "Pastoralists in the Modern World",
      topics: ["Pastoral Nomads in India", "Colonial Rule & Pastoral Life", "Pastoralism in Africa"],
      subtopics: [
        "Nomadic pastoralists of India: Gujjars, Bakarwals, Raikas, Maasai",
        "Impact of colonial laws on pastoral grazing lands, taxes, criminal tribes act",
        "Pastoralism in Africa: Maasai pastoralists, loss of grazing lands and reserves"
      ],
      lessonModules: [
        { title: "Indian Pastoral Nomads", description: "Movement patterns across mountain and desert", duration: "25 mins", level: "Foundational" },
        { title: "Colonial Impact & African Maasai", description: "Grazing restrictions and reserve creation", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Nomadic Lifestyles", "Colonial Land Revenue Impact"],
        numerical: []
      }
    }
  ]
};

export const INDIA_CBSE_GEOGRAPHY_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Geography",
  chapters: [
    {
      id: "india_size_location_9",
      chapterNumber: 1,
      title: "1. India - Size and Location",
      chapterName: "India - Size and Location",
      topics: ["Latitudinal & Longitudinal Extent", "India and the World", "India's Neighbors"],
      subtopics: [
        "Location of India, latitudinal and longitudinal extent (8°4'N to 37°6'N and 68°7'E to 97°25'E)",
        "Standard Meridian (82°30'E) and time lag between Arunachal Pradesh and Gujarat",
        "India's land boundaries, neighboring countries, strategic position in Indian Ocean"
      ],
      lessonModules: [
        { title: "Latitudinal & Longitudinal Extent", description: "Coordinates and Standard Meridian time calculation", duration: "25 mins", level: "Foundational" },
        { title: "India's Geopolitical Neighbors", description: "Land frontiers and maritime boundaries", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Standard Time Zone Calculations", "Geographic Location Advantage"],
        numerical: ["Time Zone Difference Problem (2 hours across India)"]
      }
    },
    {
      id: "physical_features_india_9",
      chapterNumber: 2,
      title: "2. Physical Features of India",
      chapterName: "Physical Features of India",
      topics: ["Major Physiographic Divisions", "Himalayan Mountains", "Northern Plains", "Peninsular Plateau", "Indian Desert, Coastal Plains & Islands"],
      subtopics: [
        "Theory of Plate Tectonics (convergent, divergent, transform boundaries)",
        "Major physiographic divisions of India",
        "The Himalayan Mountains, Greater Himalayas, Lesser Himalayas, Shiwaliks",
        "The Northern Plains, doabs, bhangar, khadar",
        "The Peninsular Plateau, Central Highlands, Deccan Plateau, Western & Eastern Ghats",
        "The Indian Desert, Coastal Plains (Western & Eastern), Islands (Andaman & Nicobar, Lakshadweep)"
      ],
      lessonModules: [
        { title: "Plate Tectonics & Himalayas", description: "Formation of Himalayas and tectonic plates", duration: "30 mins", level: "Foundational" },
        { title: "Plains, Plateau & Coastal Regions", description: "Detailed study of northern plains and plateau blocks", duration: "35 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Plate Boundary Types", "Bhangar vs Khadar Soils"],
        numerical: []
      }
    },
    {
      id: "drainage_9",
      chapterNumber: 3,
      title: "3. Drainage",
      chapterName: "Drainage",
      topics: ["Drainage Systems in India", "Himalayan Rivers", "Peninsular Rivers", "Lakes & River Pollution"],
      subtopics: [
        "Drainage basin, water divide, drainage patterns (dendritic, trellis, rectangular, radial)",
        "Himalayan rivers: Indus, Ganga, Brahmaputra river systems",
        "Peninsular rivers: Narmada, Tapi, Godavari, Mahanadi, Krishna, Kaveri basins",
        "Lakes, role of rivers in economy, and National River Conservation Plan (NRCP)"
      ],
      lessonModules: [
        { title: "Himalayan vs Peninsular Rivers", description: "Perennial vs seasonal river basins", duration: "30 mins", level: "Foundational" },
        { title: "River Pollution & Conservation", description: "NRCP and water management", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Drainage Patterns", "Water Divide Concept"],
        numerical: []
      }
    },
    {
      id: "climate_9",
      chapterNumber: 4,
      title: "4. Climate",
      chapterName: "Climate",
      topics: ["Weather vs Climate", "Climatic Controls", "Indian Monsoon Mechanism", "Seasons in India", "Distribution of Rainfall"],
      subtopics: [
        "Climatic controls: latitude, altitude, pressure and wind system, distance from sea, ocean currents",
        "Factors affecting India's climate: Coriolis force, jet streams, western cyclonic disturbances",
        "The Indian Monsoon: onset and withdrawal, mechanism of monsoon",
        "Seasons: The cold weather season, hot weather season, advancing monsoon, retreating monsoon",
        "Distribution of rainfall and monsoon as unifier of India"
      ],
      lessonModules: [
        { title: "Monsoon Mechanism", description: "Pressure belts, ITCZ, and Jet streams", duration: "35 mins", level: "Foundational" },
        { title: "Four Seasons & Rainfall", description: "Monsoon onset, retreat, and regional variation", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Coriolis Force", "El Nino & Southern Oscillation"],
        numerical: []
      }
    },
    {
      id: "natural_vegetation_wildlife_9",
      chapterNumber: 5,
      title: "5. Natural Vegetation and Wildlife",
      chapterName: "Natural Vegetation and Wildlife",
      topics: ["Factors Affecting Vegetation", "Types of Vegetation in India", "Wildlife & Conservation"],
      subtopics: [
        "Factors affecting vegetation: relief (land, soil) and climate (temperature, photoperiod, precipitation)",
        "Types of vegetation: Tropical Evergreen, Tropical Deciduous, Thorn Forests, Montane Forests, Mangrove Forests",
        "Wildlife in India, conservation, biosphere reserves, national parks, wildlife sanctuaries, Project Tiger"
      ],
      lessonModules: [
        { title: "Forest Types of India", description: "Evergreen, deciduous, and thorn forests", duration: "30 mins", level: "Foundational" },
        { title: "Wildlife Conservation", description: "Biosphere reserves and Project Tiger", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Biodiversity Hotspots", "Flora-Fauna Adaptation"],
        numerical: []
      }
    },
    {
      id: "population_9",
      chapterNumber: 6,
      title: "6. Population",
      chapterName: "Population",
      topics: ["Population Size & Distribution", "Population Growth & Processes", "National Population Policy"],
      subtopics: [
        "Population size and distribution by numbers and density across India",
        "Population growth and processes of population change: birth rate, death rate, migration",
        "Age composition, sex ratio, literacy rates, occupational structure",
        "Adolescent population, National Population Policy"
      ],
      lessonModules: [
        { title: "Population Distribution & Density", description: "Census data and spatial spread", duration: "25 mins", level: "Foundational" },
        { title: "Growth & Demographics", description: "Birth rate, death rate, and migration", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Demographic Dividend", "Sex Ratio & Literacy"],
        numerical: ["Population Density Calculations"]
      }
    }
  ]
};

export const INDIA_CBSE_POLITICAL_SCIENCE_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Political Science",
  chapters: [
    {
      id: "what_is_democracy_9",
      chapterNumber: 1,
      title: "1. What is Democracy? Why Democracy?",
      chapterName: "What is Democracy? Why Democracy?",
      topics: ["Meaning of Democracy", "Features of Democracy", "Why Democracy? Broader Meanings"],
      subtopics: [
        "Definition of democracy, major decisions by elected leaders, rule of law and respect for rights",
        "Arguments against and for democracy, broader meaning of democracy in daily life"
      ],
      lessonModules: [
        { title: "Defining Democracy", description: "Core democratic features and case studies", duration: "25 mins", level: "Foundational" },
        { title: "Merits & Demerits", description: "Why democracy is preferred", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Democratic Principles", "Citizen Rights"],
        numerical: []
      }
    },
    {
      id: "constitutional_design_9",
      chapterNumber: 2,
      title: "2. Constitutional Design",
      chapterName: "Constitutional Design",
      topics: ["Democratic Constitution in South Africa", "Making of Indian Constitution", "Guiding Values of Constitution"],
      subtopics: [
        "Democratic transition in South Africa, struggle against apartheid, Nelson Mandela",
        "Making of the Indian Constitution, Constituent Assembly debates",
        "Guiding values of the Indian Constitution: Preamble and key philosophy"
      ],
      lessonModules: [
        { title: "South African Apartheid to Democracy", description: "Rainbow nation transition", duration: "25 mins", level: "Foundational" },
        { title: "Indian Constituent Assembly", description: "Framing the Constitution and Preamble", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Apartheid Struggle", "Constitutional Philosophy"],
        numerical: []
      }
    },
    {
      id: "electoral_politics_9",
      chapterNumber: 3,
      title: "3. Electoral Politics",
      chapterName: "Electoral Politics",
      topics: ["Why Elections?", "System of Elections in India", "What Makes Elections Democratic in India?"],
      subtopics: [
        "Need for elections in representative democracy, political competition",
        "Electoral constituencies, reserved constituencies, voter lists",
        "Nominations, election campaign, polling and counting of votes",
        "Independent Election Commission of India, challenges to free and fair elections"
      ],
      lessonModules: [
        { title: "Why Elections & Constituencies", description: "Democracy through ballot box", duration: "25 mins", level: "Foundational" },
        { title: "Election Commission & Fairness", description: "Code of conduct and fair elections", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Universal Adult Franchise", "Model Code of Conduct"],
        numerical: []
      }
    },
    {
      id: "working_institutions_9",
      chapterNumber: 4,
      title: "4. Working of Institutions",
      chapterName: "Working of Institutions",
      topics: ["How is Major Policy Decision Taken?", "Parliament", "Political Executive", "Judiciary"],
      subtopics: [
        "Government decision-making process: Parliament, Executive, and Judiciary interaction",
        "Parliament: Lok Sabha and Rajya Sabha, powers and necessity",
        "Political Executive: President, Prime Minister, Council of Ministers, civil services",
        "Judiciary: Supreme Court, High Courts, judicial review, independence of judiciary"
      ],
      lessonModules: [
        { title: "Parliament & Executive", description: "Legislature and executive powers", duration: "30 mins", level: "Foundational" },
        { title: "The Judiciary", description: "Supreme Court and judicial review", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Separation of Powers", "Cabinet Responsibility"],
        numerical: []
      }
    },
    {
      id: "democratic_rights_9",
      chapterNumber: 5,
      title: "5. Democratic Rights",
      chapterName: "Democratic Rights",
      topics: ["Life Without Rights", "Rights in Indian Constitution", "Expanding Scope of Rights"],
      subtopics: [
        "Need for rights in democracy, Guantanamo Bay case, rights in Saudi Arabia",
        "Fundamental Rights in Indian Constitution: Right to Equality, Freedom, Exploitation, Religion, Culture, Constitutional Remedies",
        "Expanding scope of rights: right to education, information, food"
      ],
      lessonModules: [
        { title: "Fundamental Rights Overview", description: "Six core fundamental rights", duration: "30 mins", level: "Foundational" },
        { title: "Constitutional Remedies & Expansion", description: "Writs and expanding human rights", duration: "25 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Writs & Enforcement", "Human Rights Significance"],
        numerical: []
      }
    }
  ]
};

export const INDIA_CBSE_ECONOMICS_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Economics",
  chapters: [
    {
      id: "story_village_palampur_9",
      chapterNumber: 1,
      title: "1. The Story of Village Palampur",
      chapterName: "The Story of Village Palampur",
      topics: ["Overview of Palampur", "Factors of Production", "Farming & Non-Farming Activities"],
      subtopics: [
        "Hypothetical village Palampur, organization of production factors: land, labor, physical capital, human capital",
        "Farming in Palampur: multiple cropping, modern farming methods, Green Revolution, land distribution, sustainability of land",
        "Non-farming activities in Palampur: dairy, small-scale manufacturing, transport, shopkeeping"
      ],
      lessonModules: [
        { title: "Factors of Production", description: "Land, labor, capital, and entrepreneurship", duration: "25 mins", level: "Foundational" },
        { title: "Farming vs Non-Farming", description: "Green Revolution and rural enterprise", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Physical vs Working Capital", "Green Revolution Impact"],
        numerical: []
      }
    },
    {
      id: "people_as_resource_9",
      chapterNumber: 2,
      title: "2. People as Resource",
      chapterName: "People as Resource",
      topics: ["Economic Activities by Men and Women", "Quality of Population", "Unemployment"],
      subtopics: [
        "People as resource, economic activities (primary, secondary, tertiary sectors)",
        "Quality of population: education, health, skill formation",
        "Unemployment: seasonal, disguised, and educated unemployment, economic impact"
      ],
      lessonModules: [
        { title: "Sectors of Economy", description: "Primary, secondary, and tertiary sectors", duration: "25 mins", level: "Foundational" },
        { title: "Quality & Unemployment", description: "Education, health, and jobless growth", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Human Capital Formation", "Disguised Unemployment"],
        numerical: []
      }
    },
    {
      id: "poverty_challenge_9",
      chapterNumber: 3,
      title: "3. Poverty as a Challenge",
      chapterName: "Poverty as a Challenge",
      topics: ["Two Typical Cases of Poverty", "Poverty Line & Estimates", "Causes of Poverty", "Poverty Alleviation Measures"],
      subtopics: [
        "Urban and rural poverty cases, vulnerable groups",
        "Poverty line concept, poverty estimates across India",
        "Causes of poverty: historical, unequal income distribution, population growth",
        "Poverty alleviation programs: MGNREGA, PMAY, PMGSY, challenges ahead"
      ],
      lessonModules: [
        { title: "Poverty Line & Causes", description: "Measuring poverty and root causes", duration: "25 mins", level: "Foundational" },
        { title: "Poverty Alleviation Programs", description: "MGNREGA and government welfare schemes", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Vulnerable Groups", "Poverty Line Metrics"],
        numerical: []
      }
    },
    {
      id: "food_security_india_9",
      chapterNumber: 4,
      title: "4. Food Security in India",
      chapterName: "Food Security in India",
      topics: ["What is Food Security?", "Why Food Security?", "Buffer Stock & Public Distribution System"],
      subtopics: [
        "Meaning of food security, availability, accessibility, affordability",
        "Why food security is needed, hunger, chronic and seasonal hunger",
        "Food security in India: Green Revolution, buffer stock, Public Distribution System (PDS), ration shops, MSP",
        "Role of cooperatives in food security: Amul, Mother Dairy"
      ],
      lessonModules: [
        { title: "Food Security Dimensions", description: "Availability, access, and absorption", duration: "25 mins", level: "Foundational" },
        { title: "Buffer Stock & PDS", description: "FCI, ration shops, and cooperatives", duration: "30 mins", level: "Exam Mastery" }
      ],
      practiceGoals: {
        conceptual: ["Buffer Stock Mechanism", "PDS System"],
        numerical: []
      }
    }
  ]
};

export const INDIA_CBSE_SST_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Social Science",
  chapters: [
    ...INDIA_CBSE_HISTORY_CLASS9_CURRICULUM.chapters,
    ...INDIA_CBSE_GEOGRAPHY_CLASS9_CURRICULUM.chapters,
    ...INDIA_CBSE_POLITICAL_SCIENCE_CLASS9_CURRICULUM.chapters,
    ...INDIA_CBSE_ECONOMICS_CLASS9_CURRICULUM.chapters
  ]
};

export const INDIA_CBSE_SCIENCE_CLASS9_CURRICULUM: DetailedBoardCurriculum = {
  boardAcronym: "CBSE",
  boardName: "Central Board of Secondary Education (CBSE)",
  nation: "India",
  classLevel: "Class 9",
  subject: "Science",
  chapters: [
    ...INDIA_CBSE_PHYSICS_CLASS9_CURRICULUM.chapters,
    ...INDIA_CBSE_CHEMISTRY_CLASS9_CURRICULUM.chapters,
    ...INDIA_CBSE_BIOLOGY_CLASS9_CURRICULUM.chapters
  ]
};


function getDetailedTopicsForChapters(chapters: ChapterCurriculum[]): string[] {
  if (!chapters || !Array.isArray(chapters)) return [];
  return chapters.map(ch => {
    const topicStr = ch.topics ? ch.topics.join(', ') : '';
    const subtopicStr = ch.subtopics && ch.subtopics.length > 0 ? ' — ' + ch.subtopics.join('; ') : '';
    return `${ch.title}${topicStr ? ' - ' + topicStr : ''}${subtopicStr}`;
  });
}

export function getDetailedBoardCurriculum(nation: string, acronym: string, level?: string, subject?: string): DetailedBoardCurriculum | null {
  const normNation = nation.toLowerCase();
  const normAcronym = acronym.toLowerCase();
  const isClass9 = level ? (level.includes('9') || level.includes('ix') || level.toLowerCase().includes('class 9')) : false;
  const isClass10 = level ? (level.includes('10') || level.toLowerCase().includes('class 10') || level.toLowerCase().includes('grade 10') || level.includes('x')) && !level.includes('11') && !level.includes('12') : false;
  const isClass11 = level ? (level.includes('11') || level.includes('xi') || level.toLowerCase().includes('class 11')) : false;
  const isClass12 = (!level || level.includes('12') || level.includes('xii') || level.toLowerCase().includes('class 12')) && !isClass9 && !isClass10 && !isClass11;
  const isMath = subject && (subject.toLowerCase().includes('math') || subject.toLowerCase().includes('mat'));
  const isPhysics = subject && (subject.toLowerCase().includes('physic') || subject.toLowerCase().includes('phy'));
  const isChem = subject && (subject.toLowerCase().includes('chem') || subject.toLowerCase().includes('che'));
  const isBio = subject && (subject.toLowerCase().includes('bio') || subject.toLowerCase().includes('biol'));
  const isCS = subject && (subject.toLowerCase().includes('computer') || subject.toLowerCase().includes('cs') || subject.toLowerCase().includes('it'));
  const isHistory = subject && (subject.toLowerCase().includes('history') || subject.toLowerCase().includes('hist'));
  const isGeog = subject && (subject.toLowerCase().includes('geography') || subject.toLowerCase().includes('geog'));
  const isPol = subject && (subject.toLowerCase().includes('political') || subject.toLowerCase().includes('pol'));
  const isSoc = subject && (subject.toLowerCase().includes('sociology') || subject.toLowerCase().includes('socio'));
  const isPsych = subject && (subject.toLowerCase().includes('psychology') || subject.toLowerCase().includes('psych'));
  const isEcon = subject && (subject.toLowerCase().includes('economy') || subject.toLowerCase().includes('economics') || subject.toLowerCase().includes('econ'));

  const isSupportedBoard = normNation.includes('india') || 
                           normAcronym.includes('cbse') || 
                           normAcronym.includes('icse') || 
                           normAcronym.includes('isc') || 
                           normAcronym.includes('cisce') || 
                           normAcronym.includes('cise');

  const isISC = normAcronym.includes('isc') || normAcronym.includes('cisce') || normAcronym.includes('icse');
  const isCBSE = normAcronym.includes('cbse');

  if (isSupportedBoard && isClass9 && isCBSE) {
    if (isMath) return INDIA_CBSE_MATH_CLASS9_CURRICULUM;
    if (isPhysics) return INDIA_CBSE_PHYSICS_CLASS9_CURRICULUM;
    if (isChem) return INDIA_CBSE_CHEMISTRY_CLASS9_CURRICULUM;
    if (isBio) return INDIA_CBSE_BIOLOGY_CLASS9_CURRICULUM;
    if (isHistory) return INDIA_CBSE_HISTORY_CLASS9_CURRICULUM;
    if (isGeog) return INDIA_CBSE_GEOGRAPHY_CLASS9_CURRICULUM;
    if (isPol) return INDIA_CBSE_POLITICAL_SCIENCE_CLASS9_CURRICULUM;
    if (isEcon) return INDIA_CBSE_ECONOMICS_CLASS9_CURRICULUM;
    if (subject && (subject.toLowerCase().includes('social') || subject.toLowerCase().includes('sst'))) return INDIA_CBSE_SST_CLASS9_CURRICULUM;
    if (subject && subject.toLowerCase().includes('science')) return INDIA_CBSE_SCIENCE_CLASS9_CURRICULUM;
  }

  if (isSupportedBoard && isClass9 && isMath) {
    return INDIA_ICSE_MATH_CLASS9_CURRICULUM;
  }

  if (isSupportedBoard && isClass10) {
    if (isMath) return INDIA_CBSE_MATH_CLASS10_CURRICULUM;
    if (isPhysics) return INDIA_CBSE_PHYSICS_CLASS10_CURRICULUM;
    if (isChem) return INDIA_CBSE_CHEMISTRY_CLASS10_CURRICULUM;
    if (isBio) return INDIA_CBSE_BIOLOGY_CLASS10_CURRICULUM;
    if (isCS) return INDIA_CBSE_IT_CLASS10_CURRICULUM;
    if (isHistory) return INDIA_CBSE_HISTORY_CLASS10_CURRICULUM;
    if (isGeog) return INDIA_CBSE_GEOGRAPHY_CLASS10_CURRICULUM;
    if (isPol) return INDIA_CBSE_POLITICAL_SCIENCE_CLASS10_CURRICULUM;
    if (isEcon) return INDIA_CBSE_ECONOMICS_CLASS10_CURRICULUM;
    if (subject && (subject.toLowerCase().includes('social') || subject.toLowerCase().includes('sst'))) return INDIA_CBSE_SST_CLASS10_CURRICULUM;
    if (subject && subject.toLowerCase().includes('science')) return INDIA_CBSE_SCIENCE_CLASS10_CURRICULUM;
  }

  if (isSupportedBoard && isClass11 && isChem) {
    return INDIA_ISC_CHEMISTRY_CLASS11_CURRICULUM;
  }

  if (isSupportedBoard && isClass11 && isSoc) {
    return INDIA_ISC_SOCIOLOGY_CLASS11_CURRICULUM;
  }

  if (isSupportedBoard && isClass11 && isPsych) {
    return INDIA_ISC_PSYCHOLOGY_CLASS11_CURRICULUM;
  }

  if (isSupportedBoard && isClass11 && isEcon) {
    return INDIA_ISC_ECONOMICS_CLASS11_CURRICULUM;
  }

  if (isSupportedBoard && isClass12 && isMath) {
    return INDIA_CBSE_MATH_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isPhysics) {
    return INDIA_CBSE_PHYSICS_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isChem) {
    return INDIA_CBSE_CHEMISTRY_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isBio) {
    return INDIA_CBSE_BIOLOGY_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isCS) {
    return INDIA_CBSE_COMPUTER_SCIENCE_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isHistory) {
    return INDIA_CBSE_HISTORY_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isGeog) {
    return INDIA_CBSE_GEOGRAPHY_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isPol) {
    return INDIA_CBSE_POLITICAL_SCIENCE_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isSoc) {
    return INDIA_CBSE_SOCIOLOGY_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isPsych) {
    if (isISC) {
      return INDIA_ISC_PSYCHOLOGY_CLASS12_CURRICULUM;
    }
    return INDIA_CBSE_PSYCHOLOGY_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && (subject?.toLowerCase().includes('biology') || false)) {
    if (isISC) {
      return INDIA_ISC_BIOLOGY_CLASS12_CURRICULUM;
    }
    return INDIA_CBSE_BIOLOGY_CLASS12_CURRICULUM;
  }
  if (isSupportedBoard && isClass12 && isEcon) {
    if (isISC) {
      return INDIA_ISC_ECONOMICS_CLASS12_CURRICULUM;
    }
    return INDIA_CBSE_ECONOMICS_CLASS12_CURRICULUM;
  }
  return null;
}

export function getBoardCurriculum(nation: string, acronym: string, level?: string): BoardCurriculum {
  const normNation = nation.toLowerCase();
  const normAcronym = acronym.toLowerCase();

  // --- GENERALIZED DETECTION FOR ALL UNIVERSITY CORES ---
  const activeBoard = EDUCATION_BOARDS.find(b => b.acronym.toLowerCase() === normAcronym);
  if (activeBoard) {
    if (activeBoard.type === 'technical-university') {
      return {
        levels: ['Year 1 Undergraduate', 'Year 2 Undergraduate', 'Year 3 Undergraduate', 'Year 4 Advanced', 'Post-Graduate Core', 'PhD Research'],
        subjects: ['mathematics', 'physics', 'chemistry', 'computer_science', 'electrical_engineering', 'mechanical_engineering', 'civil_engineering', 'chemical_engineering', 'aerospace_engineering', 'ai_research'],
        topics: {
          mathematics: [
            'Multivariable Calculus & Field Theory',
            'Linear Algebra & Vector Spaces',
            'Discrete Mathematics & Graph Theory',
            'Numerical Analysis & MATLAB Computing',
            'Differential Equations & Dynamical Systems',
            'Complex Analysis & Transforms',
            'Probability Theory & Stochastic Processes',
            'Optimization Methods & Linear Programming'
          ],
          physics: [
            'Electromagnetism & Maxwell Equations',
            'Quantum Mechanics & Semiconductor Physics',
            'Classical Mechanics & Hamiltonian Paths',
            'Thermodynamics & Statistical Mechanics',
            'Solid State Physics & Crystals',
            'Optics & Laser Technology',
            'Relativity & Astrophysics'
          ],
          chemistry: [
            'Organic Synthesis & Polymers',
            'Quantum Chemistry & Molecular Orbitals',
            'Spectroscopic Characterization of Materials',
            'Chemical Thermodynamics & Kinetics',
            'Electrochemistry & Solid State Materials',
            'Nanochemistry & Nanotechnology'
          ],
          computer_science: [
            'Design and Analysis of Algorithms',
            'Operating Systems & Concurrency',
            'Database Internals & Distributed Systems',
            'Compiler Design & Theory of Computation',
            'Computer Architecture & Assembly',
            'Computer Networks & Security Protocols',
            'Software Engineering & Design Patterns'
          ],
          electrical_engineering: [
            'Circuit Analysis & Network Theorems',
            'Signals and Systems Theory',
            'Digital Signal Processing (DSP)',
            'Microprocessors & Embedded Systems',
            'Control Systems & Feedback Loops',
            'Power Systems & Electromagnetic Fields'
          ],
          mechanical_engineering: [
            'Engineering Mechanics & Statics',
            'Strength of Materials & Solid Mechanics',
            'Fluid Mechanics & Hydraulics',
            'Thermodynamics & Heat Transfer',
            'Kinematics & Dynamics of Machinery',
            'Machine Design & Finite Element Method (FEM)'
          ],
          civil_engineering: [
            'Structural Analysis & Beams',
            'Geotechnical Engineering & Soils',
            'Fluid Mechanics & Hydraulics',
            'Surveying & GIS Mapping',
            'Concrete & Steel Structure Design',
            'Transportation & Highway Engineering'
          ],
          chemical_engineering: [
            'Transport Phenomena & Momentum',
            'Chemical Reaction Engineering',
            'Separation Processes & Distillation',
            'Chemical Process Control',
            'Plant Design & Economics'
          ],
          aerospace_engineering: [
            'Aerodynamics & Compressible Flow',
            'Flight Dynamics & Control',
            'Rocket Propulsion & Gas Turbines',
            'Orbital Mechanics & Astrodynamics',
            'Aerospace Structures & Materials'
          ],
          ai_research: [
            'Machine Learning Algorithms',
            'Neural Networks & Deep Learning',
            'Natural Language Processing (NLP)',
            'Computer Vision & Robotics',
            'Reinforcement Learning & Decision Making',
            'Large Language Models & Generative AI'
          ]
        }
      };
    } else if (activeBoard.type === 'university') {
      return {
        levels: ['Year 1 Undergraduate', 'Year 2 Undergraduate', 'Year 3 Undergraduate', 'Year 4 Advanced', 'Post-Graduate Core', 'PhD Research'],
        subjects: ['mathematics', 'physics', 'chemistry', 'biology', 'economics', 'literature', 'philosophy', 'history', 'political_science', 'sociology', 'psychology'],
        topics: {
          mathematics: [
            'Abstract Algebra & Ring Theory',
            'Real & Complex Analysis proofs',
            'Calculus & Functional Analysis',
            'Linear Algebra & Vector Spaces',
            'Probability Theory & Stochastic Processes',
            'Number Theory & Cryptography',
            'Set Theory & Mathematical Logic'
          ],
          physics: [
            'Thermodynamics & Statistical Physics',
            'Classical Mechanics & Lagrangian Systems',
            'Quantum Mechanics Foundations',
            'Electrodynamics & Special Relativity',
            'Cosmology & Particle Physics'
          ],
          chemistry: [
            'Organic Chemistry Structures',
            'Physical Chemistry & Kinetics',
            'Quantum Chemistry & Bonding',
            'Inorganic Complexes & Coordination',
            'Analytical Chemistry & Spectroscopy',
            'Biochemistry & Molecular Structure'
          ],
          biology: [
            'Cellular Biology & Genetics',
            'Biochemistry & Molecular Pathways',
            'Neurobiology & Human Physiology',
            'Evolution & Population Ecology',
            'Microbiology & Immunology',
            'Bioinformatics & Computational Genetics'
          ],
          economics: [
            'Advanced Microeconomics Concepts',
            'Macroeconomic Growth Theories',
            'Applied Econometrics & Regression',
            'Game Theory & Strategic Decisions',
            'Behavioral Economics & Policy',
            'Development Economics & Global Markets'
          ],
          literature: [
            'Academic Rhetoric & Essay Writing',
            'Comparative World Literature Novels',
            'Modern Literary Theory',
            'Historical Poetry & Prose',
            'Shakespearean Drama & Renaissance Studies',
            'Creative Writing & Narrative Techniques'
          ],
          philosophy: [
            'Introduction to Epistemology',
            'Classical & Symbolic Logic',
            'Ethics & Moral Philosophy',
            'Philosophy of Science & Mind',
            'Political Philosophy & Social Contract',
            'Eastern & Comparative Philosophy'
          ],
          history: [
            'Ancient Civilizations & Historiography',
            'Modern Global History & Geopolitics',
            'Social & Economic History of Nations',
            'Political Revolutions & Ideologies',
            'Colonialism & Post-Colonial Studies'
          ],
          political_science: [
            'Comparative Politics & Systems',
            'International Relations & Global Security',
            'Political Theory & Modern Thought',
            'Public Policy Analysis',
            'Human Rights & International Law'
          ],
          sociology: [
            'Sociological Theories & Pioneers',
            'Social Inequality, Class & Caste',
            'Gender, Family & Socialization',
            'Urban Sociology & Globalization',
            'Research Methods & Quantitative Analysis'
          ],
          psychology: [
            'Cognitive Psychology & Memory',
            'Developmental Psychology & Life Span',
            'Social Psychology & Group Behavior',
            'Clinical Psychology & Pathologies',
            'Neuropsychology & Brain Functions'
          ]
        }
      };
    }
  }

  // --- OVERRIDE FOR CBSE ---
  if (normNation.includes('india') && normAcronym.includes('cbse')) {
    const isClass12 = !level || level.includes('12');
    const isClass11 = level && level.includes('11');
    const isClass10 = level ? (level.includes('10') || level.toLowerCase().includes('class 10') || level.toLowerCase().includes('grade 10') || level.includes('x')) && !level.includes('11') && !level.includes('12') : false;
    const isClass9 = level ? (level.includes('9') || level.toLowerCase().includes('class 9') || level.toLowerCase().includes('grade 9') || level.includes('ix')) && !level.includes('10') && !level.includes('11') && !level.includes('12') : false;
    const isSenior = isClass12 || isClass11 || (level && (level.includes('11') || level.includes('12')));
    const subjects = isSenior 
      ? ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'english', 'history', 'geography', 'political_science', 'sociology', 'psychology', 'economics']
      : ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'english', 'social_science'];
    
    return {
      levels: [
        'Class 9 CBSE', 'Class 10 CBSE', 'Class 11 CBSE', 'Class 12 CBSE'
      ],
      subjects,
      topics: {
        mathematics: isClass12 ? MATHEMATICS_CBSE_LESSONS : isClass11 ? [
          'Sets, Relations & Functions',
          'Complex Numbers & Quadratic Equations',
          'Permutations & Combinations',
          'Binomial Theorem & Sequences',
          'Limits & Derivatives',
          'Statistics & Probability (Class 11)'
        ] : isClass10 ? getDetailedTopicsForChapters(INDIA_CBSE_MATH_CLASS10_CURRICULUM.chapters)
        : isClass9 ? getDetailedTopicsForChapters(INDIA_CBSE_MATH_CLASS9_CURRICULUM.chapters)
        : [
          'Real Numbers', 
          'Polynomials', 
          'Quadratic Equations', 
          'Arithmetic Progressions', 
          'Triangles & Coordinate Geometry', 
          'Trigonometry Introduction', 
          'Circles & Areas Related to Circles', 
          'Surface Areas & Volumes', 
          'Statistics & Probability'
        ],
        physics: isClass12 ? [
          'Chapter 1: Electric Charges and Fields - Coulomb\'s Law, continuous charge distribution, electric flux, Gauss\'s Theorem and its applications',
          'Chapter 2: Electrostatic Potential and Capacitance - Electric potential, equipotential surfaces, capacitance, parallel plate capacitors with and without dielectrics, energy stored in a capacitor',
          'Chapter 3: Current Electricity - Ohm\'s law, drift velocity, Kirchhoff\'s rules, Wheatstone bridge, EMF and internal resistance of a cell, potentiometer',
          'Chapter 4: Moving Charges and Magnetism - Biot-Savart law, Ampere\'s law, force on a moving charge, moving coil galvanometer and its conversion',
          'Chapter 5: Magnetism and Matter - Bar magnet, magnetic field lines, dia-, para-, and ferromagnetic substances',
          'Chapter 6: Electromagnetic Induction - Faraday\'s laws, Lenz\'s law, self and mutual induction',
          'Chapter 7: Alternating Current - Peak and RMS values, LCR series circuit, resonance, power, transformer and AC generator',
          'Chapter 8: Electromagnetic Waves - Displacement current, properties of EM waves, transverse nature, electromagnetic spectrum',
          'Chapter 9: Ray Optics and Optical Instruments - Reflection, refraction, lens maker\'s formula, optical instruments (microscopes and telescopes)',
          'Chapter 10: Wave Optics - Wavefront, Huygen\'s principle, interference (Young\'s double-slit experiment), diffraction',
          'Chapter 11: Dual Nature of Radiation and Matter - Photoelectric effect, Einstein\'s photoelectric equation, de Broglie relation',
          'Chapter 12: Atoms - Alpha particle scattering, Rutherford\'s model, Bohr\'s model of the hydrogen atom',
          'Chapter 13: Nuclei - Nuclear forces, mass defect, binding energy, nuclear fission and fusion',
          'Chapter 14: Semiconductor Electronics: Materials, Devices and Simple Circuits - Energy bands in conductors, semiconductors, and insulators; semiconductor diodes and their characteristics'
        ] : isClass11 ? [
          'Units & Measurements - Dimensions of physical quantities, dimensional analysis and its applications',
          'Kinematics & Motion - Frame of reference, Motion in a straight line, vectors, motion in a plane',
          'Laws of Motion & Friction - Intuitive concept of force, Newton\'s laws of motion, momentum, impulse, friction',
          'Work, Energy & Power - Kinetic energy, work-energy theorem, potential energy, conservative and non-conservative forces, collisions',
          'Rotational Motion & Gravitation - Center of mass, torque, angular momentum, Kepler\'s laws of planetary motion, acceleration due to gravity',
          'Thermodynamics & Kinetic Theory - Thermal equilibrium, zeroth law, first and second laws of thermodynamics, kinetic theory of gases',
          'Properties of Bulk Matter - Elastic behavior, stress-strain relationship, Hooke\'s law, pressure, viscosity, surface tension, heat, temperature',
          'Oscillations & Waves - Periodic motion, simple harmonic motion, wave motion, longitudinal and transverse waves, displacement relation for a progressive wave'
        ] : isClass10 ? getDetailedTopicsForChapters(INDIA_CBSE_PHYSICS_CLASS10_CURRICULUM.chapters)
        : isClass9 ? getDetailedTopicsForChapters(INDIA_CBSE_PHYSICS_CLASS9_CURRICULUM.chapters)
        : [
          'Light Reflection & Refraction', 
          'Human Eye & Colorful World', 
          'Electricity Physics', 
          'Magnetic Effects of Electric Current', 
          'Sources of Energy'
        ],
        chemistry: isClass12 ? CHEMISTRY_CBSE_LESSONS : isSenior ? [
          'Some Basic Concepts of Chemistry',
          'Structure of Atom',
          'Classification of Elements',
          'Chemical Bonding & Structure',
          'Chemical Thermodynamics',
          'Equilibrium & Redox Reactions',
          'Solutions & Electrochemistry',
          'Chemical Kinetics & d-Block',
          'Coordination Compounds',
          'Organic Chemistry: Hydrocarbons',
          'Alcohols, Phenols & Ethers',
          'Aldehydes, Ketones & Amines'
        ] : isClass10 ? getDetailedTopicsForChapters(INDIA_CBSE_CHEMISTRY_CLASS10_CURRICULUM.chapters)
        : isClass9 ? getDetailedTopicsForChapters(INDIA_CBSE_CHEMISTRY_CLASS9_CURRICULUM.chapters)
        : [
          'Chemical Reactions & Equations', 
          'Acids, Bases & Salts', 
          'Metals & Non-metals', 
          'Carbon & its Compounds', 
          'Periodic Classification of Elements'
        ],
        biology: isClass12 ? [
          'Chapter 1: Sexual Reproduction in Flowering Plants - Flower structure, gametogenesis, pollination, double fertilization, seed and fruit formation',
          'Chapter 2: Human Reproduction - Male and female reproductive systems, menstrual cycle, fertilization, embryonic development, parturition',
          'Chapter 3: Reproductive Health - Birth control, population explosion, STIs, infertility and assisted reproductive technologies (ART)',
          'Chapter 4: Principles of Inheritance and Variation - Mendelian inheritance, chromosomal theory, sex determination, mutation, genetic disorders',
          'Chapter 5: Molecular Basis of Inheritance - DNA structure, packaging, replication, transcription, translation, gene expression, HGP, DNA fingerprinting',
          'Chapter 6: Evolution - Origin of life, biological evolution, evidence, adaptive radiation, Hardy-Weinberg principle, human evolution',
          'Chapter 7: Human Health and Disease - Pathogens, immunity, vaccination, AIDS, cancer, drugs and alcohol abuse',
          'Chapter 8: Microbes in Human Welfare - Microbes in household, industry, sewage treatment, biogas, biocontrol, biofertilizers',
          'Chapter 9: Biotechnology: Principles and Processes - Recombinant DNA technology, restriction enzymes, vectors, transformation, processes',
          'Chapter 10: Biotechnology and its Applications - Bt cotton, gene therapy, molecular diagnosis, transgenic animals, ethical issues',
          'Chapter 11: Organisms and Populations - Adaptation, population attributes, growth models, population interactions',
          'Chapter 12: Ecosystem - Structure and function, energy flow, productivity, decomposition, pyramids, succession, nutrient cycling',
          'Chapter 13: Biodiversity and Conservation - Levels, patterns, importance, loss of biodiversity, in-situ and ex-situ conservation'
        ] : isSenior ? [
          'Diversity in Living Organisms',
          'Cell Structure & Cell Division',
          'Plant Physiology & Transport Systems',
          'Human Physiology & Systems'
        ] : isClass10 ? getDetailedTopicsForChapters(INDIA_CBSE_BIOLOGY_CLASS10_CURRICULUM.chapters)
        : isClass9 ? getDetailedTopicsForChapters(INDIA_CBSE_BIOLOGY_CLASS9_CURRICULUM.chapters)
        : [
          'Life Processes', 
          'Control & Coordination', 
          'How do Organisms Reproduce', 
          'Heredity & Evolution', 
          'Our Environment & Natural Resources'
        ],
        computer_science: isClass12 ? [
          'Chapter 1: Python Revision and Functions - Python basics review, functions, scoping rules, and recursion',
          'Chapter 2: File Handling in Python - Text files, binary files (pickle), CSV files, and exception handling',
          'Chapter 3: Data Structures - Stacks (Push/Pop operations) implementation using lists',
          'Chapter 4: Computer Networks - Networking evolution, types, topologies, devices, protocols, and security',
          'Chapter 5: Database Management - Relational concepts, SQL (DDL/DML), joins, and Python-SQL connectivity',
          'Chapter 6: Societal Impacts - Digital footprint, cyber crime, IT act, and e-waste management'
        ] : isSenior ? [
          'Computer Systems & Organisation',
          'Computational Thinking & Python',
          'Database Management & SQL Commands',
          'Cyber Ethics & Social AI Laws',
          'Computer Networks & Protocols'
        ] : isClass10 ? getDetailedTopicsForChapters(INDIA_CBSE_COMPUTER_SCIENCE_CLASS10_CURRICULUM.chapters)
        : isClass9 ? getDetailedTopicsForChapters(INDIA_CBSE_COMPUTER_SCIENCE_CLASS9_CURRICULUM.chapters)
        : [
          'Computational Thinking & Programming',
          'Python Programming Basics',
          'Computer Networks',
          'Database Management & SQL',
          'Society, Law & Ethics in AI'
        ],
        english: isSenior ? [
          'Advanced Reading Comprehension',
          'Creative Writing & Formal Reports',
          'Applied Grammar & Sentence Transformation',
          'Literature: Flamingo & Vistas Prose & Poetry'
        ] : [
          'Reading Comprehension passages',
          'Creative Writing Skills & formal letters',
          'Applied Grammar: Tenses, Modals, Voice',
          'Literature: Prose & Poetry First Flight / Footprints'
        ],
        social_science: isClass10 ? getDetailedTopicsForChapters(INDIA_CBSE_SST_CLASS10_CURRICULUM.chapters)
        : isClass9 ? getDetailedTopicsForChapters(INDIA_CBSE_SST_CLASS9_CURRICULUM.chapters)
        : [
          'Rise of Nationalism in Europe & India',
          'Resources and Development',
          'Water Resources & Agriculture',
          'Federalism & Gender, Religion, Caste',
          'Development & Sectors of Indian Economy'
        ],
        history: isClass12 ? [
          'Chapter 1: Bricks, Beads and Bones - The Harappan Civilisation',
          'Chapter 2: Kings, Farmers and Towns - Early States and Economies',
          'Chapter 3: Kinship, Caste and Class - Early Societies',
          'Chapter 4: Thinkers, Beliefs and Buildings - Cultural Developments',
          'Chapter 5: Through the Eyes of Travellers - Perceptions of Society',
          'Chapter 6: Bhakti-Sufi Traditions - Religious Beliefs and Devotional Texts',
          'Chapter 7: An Imperial Capital: Vijayanagara - Architecture and Power',
          'Chapter 8: Peasants, Zamindars and the State - Agrarian Society and Mughal Empire',
          'Chapter 9: Kings and Chronicles - The Mughal Courts',
          'Chapter 10: Colonialism and the Countryside - Official Archives',
          'Chapter 11: Rebels and the Raj - The Revolt of 1857',
          'Chapter 12: Mahatma Gandhi and the Nationalist Movement - Civil Disobedience and Beyond',
          'Chapter 13: Framing the Constitution - The Beginning of a New Era'
        ] : isSenior ? [
          'Harappan Civilisation',
          'Mauryan & Gupta Empires',
          'Medieval India: Travellers & Sufis',
          'Mughal Empire & Architecture',
          'Colonialism & Freedom Movement',
          'Framing of Indian Constitution'
        ] : [
          'Ancient Indian Civilizations & Harappan Culture',
          'Medieval Kings, Chronicles & Travellers',
          'Modern Colonialism, Mahatma Gandhi & Constitution',
          'Themes in World History: Industrial Revolution'
        ],
        geography: isClass12 ? [
          'Chapter 1: Human Geography: Nature and Scope - Concepts of human geography, nature, scope, determinism vs possibilism',
          'Chapter 2: The World Population: Distribution, Density and Growth - Population patterns, growth components, demographic transition',
          'Chapter 3: Human Development - HDI indicators, pillars of development, international comparisons',
          'Chapter 4: Primary Activities - Hunting, gathering, pastoralism, commercial and subsistence agriculture',
          'Chapter 5: Secondary Activities - Manufacturing, industries classification, modern industrial trends',
          'Chapter 6: Tertiary and Quaternary Activities - Services, trade, transport, BPO/KPO, digital divide',
          'Chapter 7: Transport and Communication - Land, water, air transport, satellite communication, pipelines',
          'Chapter 8: International Trade - Trade basis, WTO, regional blocs, gateways of trade',
          'Chapter 9: Human Settlements - Rural and urban settlements, functional classification of towns'
        ] : [
          'Fundamentals of Physical Geography',
          'India: Physical Environment & Landforms',
          'Fundamentals of Human Geography',
          'India: People & Economy, Resources'
        ],
        political_science: isClass12 ? [
          'Chapter 1: The End of Bipolarity - Disintegration of USSR and the Cold War era transition',
          'Chapter 2: Contemporary Centres of Power - Rise of EU, ASEAN, and China',
          'Chapter 3: Contemporary South Asia - Politics and democracy in South Asian nations',
          'Chapter 4: International Organizations - Role of UN and reforms in global governance',
          'Chapter 5: Security in the Contemporary World - Traditional and non-traditional threats',
          'Chapter 6: Environment and Natural Resources - Global environmental politics and resource sharing',
          'Chapter 7: Globalization - Causes, consequences, and India\'s role in global integration',
          'Chapter 8: Challenges of Nation-Building - Integration of princely states and reorganization',
          'Chapter 9: Recent Developments in Indian Politics - Era of coalitions and new political consensus'
        ] : [
          'Indian Constitution at Work',
          'Political Theory & Equality, Justice',
          'Contemporary World Politics & Cold War',
          'Politics in India since Independence'
        ],
        sociology: isClass12 ? [
          'Chapter 1: Demographic Structure of Indian Society - Malthusian theory, population trends, and age structure',
          'Chapter 2: Social Institutions: Continuity and Change - Caste system, tribal communities, and family patterns',
          'Chapter 3: Patterns of Social Inequality and Exclusion - Social stratification, dalit and adivasi struggles, and women\'s movements',
          'Chapter 4: The Challenges of Cultural Diversity - Regionalism, communalism, secularism, and nation-state',
          'Chapter 5: Structural Change - Colonialism, industrialization, and urbanization in India',
          'Chapter 6: Cultural Change - Sanskritization, westernization, modernization, and secularization',
          'Chapter 7: Change and Development in Rural Society - Agrarian structure, land reforms, and green revolution',
          'Chapter 8: Change and Development in Industrial Society - Industrialization organization and work patterns',
          'Chapter 9: Social Movements - Features, types, and various movements in India'
        ] : [
          'Introducing Sociology: Terms & Methods',
          'Understanding Society: Culture & Social Institutions',
          'Indian Society: Caste, Tribe & Demographics',
          'Social Change & Development in India'
        ],
        psychology: isClass12 ? [
          'Chapter 1: Variations in Psychological Attributes - Intelligence, aptitude, and assessment',
          'Chapter 2: Self and Personality - Self-concept, personality types and traits, and assessment',
          'Chapter 3: Meeting Life Challenges - Stress management and positive health',
          'Chapter 4: Psychological Disorders - Concepts of abnormality and clinical conditions',
          'Chapter 5: Therapeutic Approaches - CBT, humanistic, and other psychotherapies',
          'Chapter 6: Attitude and Social Cognition - Social behaviour and belief systems',
          'Chapter 7: Social Influence and Group Processes - Group dynamics and social influence'
        ] : [
          'Introduction to Psychology',
          'Methods of Enquiry in Psychology',
          'Bases of Human Behaviour',
          'Human Development & Learning',
          'Sensory, Attentional & Perceptual Processes'
        ],
        economics: [
          'Statistics for Economics & Data Collection',
          'Introductory Microeconomics: Consumer & Producer',
          'Introductory Macroeconomics: National Income',
          'Indian Economic Development & Reforms'
        ]
      }
    };
  }

  // --- OVERRIDE FOR CISCE / ICSE ---
  if (normNation.includes('india') && (normAcronym.includes('cisce') || normAcronym.includes('icse') || normAcronym.includes('isc'))) {
    const customTag = acronym.toUpperCase();
    const isClass9 = level ? (level.includes('9') || level.includes('ix') || level.toLowerCase().includes('class 9')) : false;
    const isClass10 = level ? (level.includes('10') || level.toLowerCase().includes('class 10') || (level.toLowerCase().includes('x') && !level.toLowerCase().includes('xi') && !level.toLowerCase().includes('ix'))) : false;
    const isClass12 = (!level || level.includes('12')) && !isClass9 && !isClass10;
    const isClass11 = level && level.includes('11');
    const isSenior = isClass12 || isClass11 || (level && (level.includes('11') || level.includes('12')));
    const subjects = isSenior 
      ? ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'english', 'history', 'geography', 'political_science', 'sociology', 'psychology', 'economics']
      : ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'english', 'social_science'];

    return {
      levels: [
        `Class 9 ${customTag}`, `Class 10 ${customTag}`,
        `Class 11 ${customTag}`, `Class 12 ${customTag}`
      ],
      subjects,
      topics: {
        mathematics: isClass12 ? MATHEMATICS_ICSE_LESSONS : isClass10 ? MATHEMATICS_ICSE_CLASS10_LESSONS : isClass11 ? MATHEMATICS_ICSE_CLASS11_LESSONS : isClass9 ? MATHEMATICS_ICSE_CLASS9_LESSONS : MATHEMATICS_ICSE_CLASS10_LESSONS,
        physics: isClass12 ? PHYSICS_ICSE_LESSONS : isClass11 ? PHYSICS_ICSE_CLASS11_LESSONS : isClass9 ? PHYSICS_ICSE_CLASS9_LESSONS : PHYSICS_ICSE_CLASS9_LESSONS,
        chemistry: isClass12 ? CHEMISTRY_ICSE_LESSONS : (isClass9 || !isSenior) ? CHEMISTRY_ICSE_CLASS9_LESSONS : isClass11 ? CHEMISTRY_ICSE_CLASS11_LESSONS : CHEMISTRY_ICSE_CLASS9_LESSONS,
        biology: isClass11 ? BIOLOGY_ICSE_CLASS11_LESSONS : isSenior ? [
          'Plant Physiology', 'Human Anatomy & Physiology', 'Health & Hygiene', 'Pollution & Ecosystems'
        ] : (isClass9 || !isSenior) ? BIOLOGY_ICSE_CLASS9_LESSONS : [
          'Basic Biology & Cells', 'Plant Physiology', 'Human Anatomy & Physiology', 'Health & Hygiene', 'Pollution & Ecosystems'
        ],
        computer_science: isClass11 ? COMPUTER_SCIENCE_ICSE_CLASS11_LESSONS : (isClass9 || !isSenior) ? COMPUTER_SCIENCE_ICSE_CLASS9_LESSONS : [
          'Object Oriented Programming in Java', 'Classes as Basis of All Computation', 'User-defined Methods', 'Arrays & Complex Structures'
        ],
        english: isSenior ? [
          'English Language: Essay & Report Writing', 'Literature: Shakespearean Drama & Modern Prose'
        ] : [
          'English Language: Essay, Letter, Comprehension', 'Literature in English: Shakespeare & Modern Poetry'
        ],
        social_science: (isClass9 || !isSenior) ? SOCIAL_SCIENCE_ICSE_CLASS9_LESSONS : [
          'Indian History & World Civics', 'Geography of India', 'Indian Democratic Principles & Institutions'
        ],
        history: isClass11 ? HISTORY_ICSE_CLASS11_LESSONS : (isClass9 || !isSenior) ? HISTORY_CIVICS_ICSE_CLASS9_LESSONS : [
          'Indian Freedom Movement & Nationalism', 'World War Eras & Colonialism', 'Civics & Organs of Indian Government'
        ],
        geography: isClass11 ? GEOGRAPHY_ICSE_CLASS11_LESSONS : (isClass9 || !isSenior) ? GEOGRAPHY_ICSE_CLASS9_LESSONS : [
          'Detailed Geography of India', 'Physical & Resource Geography', 'Climatic Zones & Soils of India'
        ],
        political_science: isClass11 ? POLITICAL_SCIENCE_ICSE_CLASS11_LESSONS : [
          'Contemporary Democratic Systems', 'International Relations & Diplomacy', 'Indian Constitution & Civil Rights'
        ],
        sociology: isClass11 ? SOCIOLOGY_ICSE_CLASS11_LESSONS : [
          'Foundations of Indian Sociology', 'Caste, Gender & Social Institutions', 'Social Structures and Urban Change'
        ],
        psychology: isClass11 ? PSYCHOLOGY_ICSE_CLASS11_LESSONS : [
          'Research Methods in Psychology', 'Intelligence, Aptitude & Personality Development', 'Therapeutic Processes & Mental Health'
        ],
        economics: isClass11 ? ECONOMICS_ICSE_CLASS11_LESSONS : [
          'Elementary Economic Theory', 'Commercial Banking & Indian Finance', 'Developmental Issues in India'
        ]
      }
    };
  }

  // --- OVERRIDE FOR OTHER INDIAN BOARDS (State Boards etc.) ---
  if (normNation.includes('india')) {
    const customTag = acronym.toUpperCase();
    const isSenior = level && (level.includes('11') || level.includes('12'));
    const subjects = isSenior 
      ? ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'english', 'history', 'geography', 'political_science', 'sociology', 'psychology', 'economics']
      : ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'english', 'social_science'];

    return {
      levels: [
        `Class 9 ${customTag}`, `Class 10 ${customTag}`,
        `Class 11 ${customTag}`, `Class 12 ${customTag}`
      ],
      subjects,
      topics: {
        mathematics: isSenior ? [
          'Calculus & Limits', 'Matrices & Determinants', 'Vectors & 3D Geometry', 'Complex Numbers', 'Probability', 'Algebraic Structures'
        ] : [
          'Number Systems', 'Commercial Mathematics', 'Algebra', 'Geometry', 'Trigonometry', 'Mensuration', 'Statistics', 'Probability'
        ],
        physics: isSenior ? [
          'Mechanics & Kinematics',
          'Thermal Physics & Thermodynamics',
          'Optics & Wave Motion',
          'Current Electricity & Electromagnetism',
          'Modern Physics & Electronics'
        ] : [
          'Force, Work, Power & Energy', 'Light & Lens Refraction', 'Sound Waves', 'Electricity & Magnetism'
        ],
        chemistry: isSenior ? [
          'Mole Concept & Stoichiometry', 'Organic Chemistry Compounds', 'Analytical Chemistry', 'Electrolysis & Metallurgy', 'Periodic Trends'
        ] : [
          'Periodic Table & Trends', 'Chemical Bonding', 'Acids, Bases & Salts', 'Analytical Chemistry', 'Mole Concept & Stoichiometry', 'Electrolysis', 'Metallurgy', 'Study of Compounds', 'Organic Chemistry Basics'
        ],
        biology: isSenior ? [
          'Plant Physiology', 'Human Anatomy & Physiology', 'Health & Hygiene', 'Pollution & Ecosystems'
        ] : [
          'Basic Biology & Cells', 'Plant Physiology', 'Human Anatomy & Physiology', 'Health & Hygiene', 'Pollution & Ecosystems'
        ],
        computer_science: [
          'Object Oriented Programming in Java', 'Classes as Basis of All Computation', 'User-defined Methods', 'Arrays & Complex Structures'
        ],
        english: isSenior ? [
          'English Language: Essay & Report Writing', 'Literature: Shakespearean Drama & Modern Prose'
        ] : [
          'English Language: Essay, Letter, Comprehension', 'Literature in English: Shakespeare & Modern Poetry'
        ],
        social_science: [
          'Indian History & World Civics', 'Geography of India', 'Indian Democratic Principles & Institutions'
        ],
        history: [
          'Indian Freedom Movement & Nationalism', 'World War Eras & Colonialism', 'Civics & Organs of Indian Government'
        ],
        geography: [
          'Detailed Geography of India', 'Physical & Resource Geography', 'Climatic Zones & Soils of India'
        ],
        political_science: [
          'Contemporary Democratic Systems', 'International Relations & Diplomacy', 'Indian Constitution & Civil Rights'
        ],
        sociology: [
          'Foundations of Indian Sociology', 'Caste, Gender & Social Institutions', 'Social Structures and Urban Change'
        ],
        psychology: [
          'Research Methods in Psychology', 'Intelligence, Aptitude & Personality Development', 'Therapeutic Processes & Mental Health'
        ],
        economics: [
          'Elementary Economic Theory', 'Commercial Banking & Indian Finance', 'Developmental Issues in India'
        ]
      }
    };
  }

  // --- OVERRIDE FOR UNITED STATES / AMERICA ---
  if (normNation.includes('united states') || normNation.includes('america') || normNation.includes('usa')) {
    const customTag = acronym.toUpperCase();
    const isSenior = level && (level.includes('11') || level.includes('12'));
    const subjects = isSenior
      ? ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'literature', 'history', 'economics', 'psychology', 'political_science']
      : ['mathematics', 'physics', 'chemistry', 'biology', 'literature', 'history'];

    return {
      levels: [
        `Grade 9 (${customTag})`, `Grade 10 (${customTag})`,
        `Grade 11 (${customTag})`, `Grade 12 (${customTag})`
      ],
      subjects,
      topics: {
        mathematics: isSenior ? ['AP Calculus AB/BC', 'AP Statistics', 'Pre-Calculus', 'Linear Algebra Basics'] : ['Algebra 1 & 2', 'Geometry', 'Integrated Math'],
        physics: isSenior ? ['AP Physics C: Mechanics', 'AP Physics: Electricity & Magnetism', 'Quantum/Nuclear Intro'] : ['Classical Mechanics', 'Waves & Optics', 'Thermodynamics'],
        chemistry: isSenior ? ['AP Chemistry: Forces & Solutions', 'Chemical Kinetics & Equilibrium', 'Thermodynamics'] : ['Atoms & Compounds', 'Chemical Bonding', 'Periodic Trends'],
        biology: isSenior ? ['AP Biology: Biochemistry & Genetics', 'Evolutionary Biology', 'Ecology'] : ['Cell Structure & Function', 'Basic Genetics', 'Biospheres'],
        computer_science: ['Programming in Java (AP CS A)', 'Computer Science Principles', 'Computational Thinking', 'Data Structures & OOP'],
        literature: isSenior ? ['AP English Literature & Rhetoric', 'American & British Literature', 'Rhetorical Analysis & Essays'] : ['Introduction to Literature', 'world_literature', 'Creative Writing'],
        history: isSenior ? ['AP US History', 'AP European History', 'AP World History', 'US Government & Politics'] : ['US History Basics', 'World History Overview'],
        economics: ['Microeconomics Concepts', 'Macroeconomics Indicators', 'Supply, Demand & Market Structure', 'Monetary & Fiscal Policy'],
        psychology: ['AP Psychology', 'Cognitive & Behavioral Science', 'Biological Bases of Behavior', 'Developmental Psychology'],
        political_science: ['AP US Government & Politics', 'Comparative Governments', 'Public Policy & Civil Rights']
      }
    };
  }

  // --- OVERRIDE FOR UNITED KINGDOM ---
  if (normNation.includes('united kingdom') || normNation.includes('uk')) {
    const customTag = acronym.toUpperCase();
    const isSenior = level && (level.includes('12') || level.includes('13'));
    const subjects = isSenior
      ? ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'literature', 'history_geography', 'economics', 'psychology']
      : ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'literature', 'history_geography'];

    return {
      levels: [
        `Year 9 (${customTag})`, `Year 10 (${customTag})`, `Year 11 (${customTag})`,
        `A-Level Year 12`, `A-Level Year 13`
      ],
      subjects,
      topics: {
        mathematics: isSenior ? ['Pure Mathematics', 'Force Mechanics', 'Applied Statistics'] : ['GCSE Foundation Algebra', 'GCSE Graphs & Geometry', 'GCSE Trigonometry'],
        physics: isSenior ? ['Particles & Radiation', 'Mechanics & Materials', 'Waves & Optics', 'Electricity & Fields', 'Astrophysics & Relativity'] : ['GCSE Particles & Forces', 'GCSE Waves & Light', 'GCSE Electricity'],
        chemistry: isSenior ? ['Physical Chemistry', 'Inorganic Chemistry', 'Organic Chemistry & Synthesis', 'Analytical chemistry methods'] : ['GCSE Periodic Table', 'GCSE Rates of Reaction', 'GCSE Organic Compounds'],
        biology: isSenior ? ['Biological Molecules', 'Cell Biology & Exchange', 'Genetic Information & Variation', 'Energy Transfers & Response', 'Genetics, Populations, Evolution'] : ['GCSE Biological Cells', 'GCSE Heredity', 'GCSE Ecology & Systems'],
        computer_science: isSenior ? ['A-Level Python & OOP', 'Algorithms & Data Representation', 'Cybersecurity & Computer Networks'] : ['GCSE Programming Basics', 'GCSE Computer Systems', 'GCSE Networks'],
        literature: isSenior ? ['Shakespearean Drama', 'Nineteenth-Century Novel', 'Modern Texts & Poetry', 'Rhetoric & Essay Structure'] : ['GCSE Shakespeare Play', 'GCSE Poetry Anthology', 'GCSE Creative Writing'],
        history_geography: isSenior ? ['British & World History', 'Physical geography Landscapes', 'Human geography Cities & Economy'] : ['GCSE British History', 'GCSE Landscapes & Climate'],
        economics: ['AS/A-Level Microeconomics', 'AS/A-Level Macroeconomics', 'Global Financial Markets & Policy'],
        psychology: ['AS/A-Level Cognitive Psychology', 'Social Influence & Memory', 'Attachment & Psychopathology']
      }
    };
  }

  // --- GENERAL FALLBACK FOR GERMANY, JAPAN, FRANCE, etc. ---
  const customTag = acronym.toUpperCase();
  return {
    levels: [
      `Junior Cycle (${customTag})`, `Secondary Cycle (${customTag})`, `Advanced Level (${customTag})`
    ],
    subjects: ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'history', 'economics'],
    topics: {
      mathematics: ['Foundational Algebra', 'Advanced Trigonometry', 'Coordinate Geometry', 'Probability & Statistics', 'Calculus Basics'],
      physics: ['Kinematics & Force', 'Waves & Sounds', 'Electricity Basics'],
      chemistry: ['Periodic Table Properties', 'Acids and Bases', 'Chemical Bonding'],
      biology: ['Cellular Biology', 'Ecology Basics', 'Genetics & Evolution Science'],
      computer_science: ['Algorithms Intro', 'Python Programming Basics', 'Networks & Security'],
      history: ['Modern National History', 'Industrialisation Age', 'World Wars Study'],
      economics: ['Microeconomics Basics', 'Supply and Demand Law', 'Global Economies Trade']
    }
  };
}

