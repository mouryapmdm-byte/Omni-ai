import React, { useState, useEffect } from 'react';
import { 
  GeneratedExample, 
  ExampleTrio, 
  INTEREST_CATEGORIES 
} from '../modules/personalization/types';
import { InterestProfileManager } from '../modules/personalization/interestProfile';
import { ExampleGenerator, ConceptSpec } from '../modules/personalization/exampleGenerator';
import { 
  Sparkles, 
  RefreshCw, 
  ThumbsUp, 
  Lightbulb, 
  Layers, 
  Check, 
  Zap, 
  SlidersHorizontal,
  Bookmark
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface ExampleCardProps {
  concept: ConceptSpec;
  studentId?: string;
  onOpenSettings?: () => void;
  className?: string;
}

export const ExampleCard: React.FC<ExampleCardProps> = ({
  concept,
  studentId = 'student_default',
  onOpenSettings,
  className
}) => {
  const [profile, setProfile] = useState(() => InterestProfileManager.getProfile(studentId));
  const [activeTab, setActiveTab] = useState<'primary' | 'secondary' | 'generic'>('primary');
  const [trio, setTrio] = useState<ExampleTrio | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [liked, setLiked] = useState<boolean>(false);
  const [variationCount, setVariationCount] = useState<number>(0);

  // Load / subscribe to profile
  useEffect(() => {
    setProfile(InterestProfileManager.getProfile(studentId));
    const unsub = InterestProfileManager.subscribe(p => {
      if (p.studentId === studentId) {
        setProfile(p);
      }
    });
    return unsub;
  }, [studentId]);

  // Load examples for concept
  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setLiked(false);
    
    ExampleGenerator.generateTrio(concept, profile)
      .then(res => {
        if (isMounted) {
          setTrio(res);
          setLoading(false);
        }
      })
      .catch(err => {
        console.error('Failed to load examples:', err);
        if (isMounted) setLoading(false);
      });

    return () => { isMounted = false; };
  }, [concept.conceptId, profile.interests]);

  const currentExample: GeneratedExample | null = trio ? trio[activeTab] : null;

  // Handle "Different Example" (Generate New Variant)
  const handleDifferentExample = async () => {
    if (!currentExample || refreshing) return;
    setRefreshing(true);
    const nextVarIndex = variationCount + 1;
    setVariationCount(nextVarIndex);

    try {
      const fresh = await ExampleGenerator.generateDifferentExample(
        concept,
        currentExample.interestCategory,
        currentExample.subInterest,
        nextVarIndex
      );

      setTrio(prev => {
        if (!prev) return null;
        return {
          ...prev,
          [activeTab]: fresh
        };
      });
      setLiked(false);
    } catch (e) {
      console.error('Failed to refresh example:', e);
    } finally {
      setRefreshing(false);
    }
  };

  // Handle student engagement (evolves interest weight)
  const handleEngagement = () => {
    if (!currentExample || liked) return;
    setLiked(true);
    InterestProfileManager.trackEngagement(studentId, currentExample.interestCategory, 0.20);
  };

  const getCategoryMeta = (catId: string) => {
    return INTEREST_CATEGORIES.find(c => c.id.toLowerCase() === catId.toLowerCase());
  };

  const primaryCat = profile.interests[0]?.category || 'space';
  const secondaryCat = profile.interests[1]?.category || 'gaming';
  const primaryMeta = getCategoryMeta(primaryCat);
  const secondaryMeta = getCategoryMeta(secondaryCat);

  return (
    <div className={cn(
      "rounded-3xl border p-5 sm:p-6 transition-all relative overflow-hidden shadow-lg",
      "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800",
      className
    )}>
      {/* Background ambient gradient glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20 shrink-0">
            <Sparkles size={20} className="animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm sm:text-base font-black text-slate-800 dark:text-slate-100">
                Personalized Real-World Scenario
              </h4>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 uppercase tracking-wider">
                Interest-Tuned
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Adapted to your passions for intuitive conceptual retention
            </p>
          </div>
        </div>

        {onOpenSettings && (
          <button
            onClick={onOpenSettings}
            className="text-xs font-bold text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400/50 transition cursor-pointer"
          >
            <SlidersHorizontal size={13} />
            <span>Customize Interests</span>
          </button>
        )}
      </div>

      {/* Interest Variant Selector Tabs */}
      <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800/80 w-fit mb-5">
        <button
          onClick={() => setActiveTab('primary')}
          className={cn(
            "px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
            activeTab === 'primary'
              ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-800"
          )}
        >
          <span>🎯 {primaryMeta?.name || 'Primary Interest'}</span>
        </button>

        <button
          onClick={() => setActiveTab('secondary')}
          className={cn(
            "px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
            activeTab === 'secondary'
              ? "bg-white dark:bg-slate-900 text-purple-600 dark:text-purple-400 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-800"
          )}
        >
          <span>⭐ {secondaryMeta?.name || 'Secondary Interest'}</span>
        </button>

        <button
          onClick={() => setActiveTab('generic')}
          className={cn(
            "px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
            activeTab === 'generic'
              ? "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-800"
          )}
        >
          <span>🌐 Classic Fallback</span>
        </button>
      </div>

      {/* Example Content Display */}
      {loading ? (
        <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800 flex flex-col items-center justify-center gap-3">
          <RefreshCw size={24} className="text-indigo-500 animate-spin" />
          <p className="text-xs font-medium text-slate-400">
            Crafting interest-tailored scenario with Professor Clarity...
          </p>
        </div>
      ) : currentExample ? (
        <div className="space-y-4">
          {/* Main Scenario Quote Card */}
          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 relative">
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-500 dark:text-indigo-400 flex items-center gap-1.5">
                <Lightbulb size={14} />
                Real-World Demonstration
              </span>
              {currentExample.subInterest && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                  Topic: {currentExample.subInterest}
                </span>
              )}
            </div>

            <p className="text-sm sm:text-base text-slate-800 dark:text-slate-200 leading-relaxed font-normal">
              "{currentExample.exampleText}"
            </p>

            {/* Formula / Calculation Box */}
            {currentExample.exampleFormula && (
              <div className="mt-3.5 pt-3 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between flex-wrap gap-2">
                <span className="text-[11px] font-mono font-bold text-slate-500">
                  Applied Formula:
                </span>
                <code className="px-3 py-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-mono font-bold text-indigo-600 dark:text-indigo-400 shadow-sm">
                  {currentExample.exampleFormula}
                </code>
              </div>
            )}
          </div>

          {/* Action Footer: Different Example Button & Engagement Upvote */}
          <div className="flex items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              {/* "Different Example" Button */}
              <button
                type="button"
                onClick={handleDifferentExample}
                disabled={refreshing}
                className="px-3.5 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center gap-2 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800/80 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw size={13} className={refreshing ? "animate-spin" : ""} />
                <span>{refreshing ? "Generating Variant..." : "Different Example"}</span>
              </button>
            </div>

            {/* Thumbs up engagement button */}
            <button
              type="button"
              onClick={handleEngagement}
              disabled={liked}
              className={cn(
                "px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border",
                liked
                  ? "bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400"
                  : "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100"
              )}
            >
              {liked ? <Check size={14} /> : <ThumbsUp size={14} />}
              <span>{liked ? "Helpful & Saved!" : "This Clicked for Me"}</span>
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
};
