import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import * as THREE from 'three';
import { 
  Maximize2, 
  Minimize2, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Send, 
  Mic, 
  MicOff, 
  RotateCcw, 
  Eye, 
  Camera, 
  Flame, 
  Atom, 
  Dna, 
  Layers, 
  Sun, 
  Moon, 
  Radio, 
  Play, 
  Pause, 
  ChevronRight, 
  ChevronLeft, 
  ChevronDown, 
  BookOpen, 
  Compass, 
  Info, 
  GraduationCap, 
  Lightbulb, 
  HelpCircle,
  Zap,
  Sliders,
  Share2,
  CheckCircle2,
  Calculator,
  X,
  Plus,
  Loader2,
  Search,
  Paperclip,
  Video,
  VideoOff,
  Disc,
  MessageSquare,
  Globe,
  FileText,
  Download,
  Copy,
  Square,
  Trophy,
  Settings,
  Headphones,
  Waves,
  Trash2,
  Pencil,
  Timer,
  Clock,
  FastForward,
  User,
  Activity,
  Layout,
  Pin,
  ShieldCheck,
  ArrowLeft,
  Command
} from 'lucide-react';
import { cn, formatMarkdownWithInlineSvgs, convertLaTeXToSpokenText, cleanNaturalLanguageForScreen, triggerHapticFeedback } from '@/src/lib/utils';
import { generateAIResponse, generateSpeech, generateGoogleSpeech, convertPcmToWav, generateImage } from '@/src/lib/gemini';
import { LANGUAGES } from '@/src/lib/constants';
import { TopicSelector } from './TopicSelector';
import { CollaborativeWhiteboard } from './CollaborativeWhiteboard';
import { SvgDiagramViewer } from './SvgDiagramViewer';
import { ClassroomSyncControl } from './ClassroomSyncControl';
import { AvatarEngineControlModal } from './AvatarEngineControlModal';
import { 
  avatarEngine, 
  LectureZone, 
  AvatarGesture, 
  AvatarExpression, 
  ProximityState,
  PROXIMITY_CONFIGS,
  ZONE_CONFIGS, 
  AvatarAnimationTrigger, 
  AvatarRigJoints 
} from '@/src/services/avatarAnimationEngine';
import { ProfessorDesk } from './ProfessorDesk';
import { LaptopViewModal } from './LaptopViewModal';
import { ProfessorSummaryModal } from './ProfessorSummaryModal';
import { UnitPronunciationTrainer } from './UnitPronunciationTrainer';
import { playLessonInitializingCue } from '@/src/lib/chalkAudio';
import {
  buildComprehensiveStudyContent,
  buildStandardOmniStudyContent,
  isChapterIntro,
  isNumericalRequest,
  breakdownLectureIntoSections,
  LECTURE_SECTIONS_META
} from '@/src/lib/studyContentGenerator';
import { generateTopicSvgDiagram } from '@/src/lib/topicCurriculumKnowledge';
import { TEACHER_PEDAGOGY_STYLES, TeacherPedagogyStyle, getTeacherStyleById, detectTeacherStyleFromQuery } from '../data/teacherStyles';
import { TeacherStyleDiscoveryModal } from './TeacherStyleDiscoveryModal';
import { AvatarPhotoAutoFitModal, AvatarDisplayMode } from './AvatarPhotoAutoFitModal';
import { FormulaTeachingModal } from './FormulaTeachingModal';
import { ContentCurationModal } from './ContentCurationModal';
import { VisualMapStudioModal } from './VisualMapStudioModal';
import { VisualTransformationModal } from './VisualTransformationModal';
import { ReactHealthModal } from './ReactHealthModal';
import { ProfessorClarityDebuggerModal } from './ProfessorClarityDebuggerModal';
import { RapidFireDrillStudioModal } from './RapidFireDrillStudioModal';
import { SyllabusExpansionControls, SYLLABUS_TREE } from './SyllabusExpansionControls';
import { LectureControlsDropdown } from './LectureControlsDropdown';
import { SmartboardVisualPresentationArchitect } from './SmartboardVisualPresentationArchitect';
import { PracticeQuestionStudioModal } from './PracticeQuestionStudioModal';
import { EditableQuestionSolutionModal } from './EditableQuestionSolutionModal';
import { AiDrawStudioModal } from './AiDrawStudioModal';
import {
  fetchVirtual3dAiDraw,
  fetchVirtual3dMasterRule,
  fetchVirtual3dExecutiveSummary,
  fetchVirtual3dRecap30s,
  fetchVirtual3dDeepRecap,
  resetVirtual3dHealth,
  AiDrawResult,
  MasterRuleResponse,
  ExecutiveSummaryResponse,
  Recap30sResponse,
  DeepRecapResponse
} from '../services/virtual3dBackendService';
import { Minimal3DControls } from './Minimal3DControls';
import { YouTubeRecordingStudioModal, RecordedChapter } from './YouTubeRecordingStudioModal';
import { smartboardRecorder } from '../services/smartboardRecordingEngine';
import { SecurityShieldModal } from './SecurityShieldModal';
import { ProfessorOmniAIModal } from './ProfessorOmniAIModal';
import { SmartCommandPalette, CommandItem } from './SmartCommandPalette';
import { BubbleRadialMenu, RadialMenuItem } from './BubbleRadialMenu';
import { CurriculumSelection, TutorPersonaConfig } from '../types';
import { QuickBoardUniversityModal } from './classroom/QuickBoardUniversityModal';
import { QuadSpeedSyncModal } from './QuadSpeedSyncModal';
import {
  QuadSpeedState,
  loadInitialQuadSpeedState,
  persistQuadSpeedState,
  QUAD_SPEED_PRESETS,
  TypingPace
} from '../services/speedSyncCoordinator';
import { StreamingBuffer } from '@/src/lib/streaming/StreamingBuffer';
import { cleanStreamingMarkdown, stripAllRawMarkdown, formatLaTeXToUnicode, stripMarkdownCodeFencesAndDelimiters, sanitizeSvgDiagramCode } from '@/src/lib/streaming/cleanStreamingMarkdown';
import { CleanStreamingRenderer, StreamingCursor } from './CleanStreamingRenderer';
import { VocalPersonaStudioModal } from './classroom/VocalPersonaStudioModal';
import { ClassroomAiToolsModal, ClassroomAiToolItem } from './classroom/ClassroomAiToolsModal';
import { ClassroomSyllabusModal } from './classroom/ClassroomSyllabusModal';
import { NanoBananaPhysicsModal } from './classroom/NanoBananaPhysicsModal';
import { AmbientLightingInspectorModal } from './classroom/AmbientLightingInspectorModal';
import { nanoBananaPhysics } from '../services/nanoBananaPhysicsEngine';
import { Virtual3DCurriculumBar } from './classroom/Virtual3DCurriculumBar';
import { useContentLoadingEstimate } from '../utils/networkEstimation';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import rehypeRaw from 'rehype-raw';

interface ThreeDClassroomProps {
  theme: 'light' | 'dark';
  userTopic?: string;
  userSubject?: string;
  selectedBoard?: { nation: string; acronym: string } | null;
  curriculum?: CurriculumSelection;
  userName?: string;
  language?: string;
  onSelectLanguage?: (lang: string) => void;
  showNotification?: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  onSelectTopic?: (topic: string, curriculumDetails?: CurriculumSelection) => void;
  onClose?: () => void;
  userDifficulty?: string;
  onSelectDifficulty?: (difficulty: string) => void;
  onSelectSubject?: (subjectId: string) => void;
  onSelectBoard?: (board: { nation: string; acronym: string } | null) => void;
  userLesson?: string;
  onSelectLesson?: (lesson: string) => void;
  personaConfig?: TutorPersonaConfig;
  onUpdatePersonaConfig?: (config: TutorPersonaConfig) => void;
  activePrompt?: string;
  initialContent?: string;
  typingPace?: string;
  blackboardWritingSpeed?: number;
  ttsRate?: number;
  visualizingSpeed?: number;
  scrollingSpeed?: number;
  isQuadLocked?: boolean;
  quadSpeedPreset?: string;
  quadSpeeds?: QuadSpeedState;
  onUpdateQuadSpeeds?: (updated: QuadSpeedState) => void;
}

type CameraViewPreset = 'front_row' | 'professor_focus' | 'teacher_podium' | 'lab_bench' | 'board_focus' | 'overhead' | 'free_orbit' | 'desk_focus' | 'figure_focus' | 'avatar_focus';
type LightingPreset = 'daylight' | 'golden_hour' | 'cyber_night' | 'exam_bright';
type HologramModel = 'dna' | 'atom' | 'planet' | 'math_surface';

export interface AcousticProfile {
  id: string;
  name: string;
  description: string;
  reverbDecay: number; // 0.1s to 3.5s
  roomEcho: number;    // 0 to 1
  roomWarmth: number;  // 500 to 8000 Hz
  ambientTone: 'lecture_hall' | 'quiet_lab' | 'outdoor_field' | 'custom';
  voicePitch: number;  // 0.8 to 1.3
  voiceRate: number;   // 0.8 to 1.2
  isBuiltIn?: boolean;
}

const DEFAULT_ACOUSTIC_PROFILES: AcousticProfile[] = [
  {
    id: 'professor_clarity_voice',
    name: 'Professor Clarity (Master Mentor Voice AI)',
    description: 'Warm, articulate educational voice with moderate unhurried pacing (0.92x), natural breathing pauses, and crystal-clear pronunciation.',
    reverbDecay: 1.2,
    roomEcho: 0.25,
    roomWarmth: 4200,
    ambientTone: 'lecture_hall',
    voicePitch: 0.98,
    voiceRate: 0.92,
    isBuiltIn: true
  },
  {
    id: 'large_hall',
    name: 'Large Lecture Hall',
    description: 'Expansive academic auditorium with rich reverberation and spatial echo.',
    reverbDecay: 2.2,
    roomEcho: 0.60,
    roomWarmth: 2200,
    ambientTone: 'lecture_hall',
    voicePitch: 0.95,
    voiceRate: 0.95,
    isBuiltIn: true
  },
  {
    id: 'quiet_lab',
    name: 'Quiet Study Lab',
    description: 'Acoustically dampened research lab optimized for crystal clear focus.',
    reverbDecay: 0.2,
    roomEcho: 0.05,
    roomWarmth: 5000,
    ambientTone: 'quiet_lab',
    voicePitch: 1.05,
    voiceRate: 1.0,
    isBuiltIn: true
  },
  {
    id: 'outdoor_field',
    name: 'Outdoor Field',
    description: 'Open-air campus quad with gentle natural breeze and minimal reflections.',
    reverbDecay: 0.7,
    roomEcho: 0.20,
    roomWarmth: 3500,
    ambientTone: 'outdoor_field',
    voicePitch: 1.0,
    voiceRate: 1.05,
    isBuiltIn: true
  }
];

const LESSON_TOPICS: Array<{
  id: string;
  title: string;
  subject: string;
  boardContent: string;
  speechPrompt: string;
  hologram: HologramModel;
}> = [];

export const ThreeDClassroom: React.FC<ThreeDClassroomProps> = ({
  theme,
  userTopic = 'General Science',
  userSubject = 'STEM',
  selectedBoard,
  userName = 'Student',
  language = 'en',
  onSelectLanguage,
  showNotification,
  onSelectTopic,
  onClose,
  userDifficulty = 'class_12',
  onSelectDifficulty,
  onSelectSubject: onParentSelectSubject,
  onSelectBoard: onParentSelectBoard,
  userLesson = '1',
  onSelectLesson,
  personaConfig,
  onUpdatePersonaConfig,
  activePrompt,
  initialContent,
  typingPace,
  blackboardWritingSpeed,
  ttsRate,
  visualizingSpeed,
  scrollingSpeed,
  isQuadLocked,
  quadSpeedPreset,
  quadSpeeds,
  onUpdateQuadSpeeds
}) => {
  // Quad-Speed Synchronization State (Typing, Pronouncing, Visualizing, Scrolling)
  const [showQuadSpeedModal, setShowQuadSpeedModal] = useState<boolean>(false);
  const [activeQuadSpeeds, setActiveQuadSpeeds] = useState<QuadSpeedState>(() => {
    if (quadSpeeds) return quadSpeeds;
    const initial = loadInitialQuadSpeedState();
    if (typeof blackboardWritingSpeed === 'number') initial.typingSpeed = blackboardWritingSpeed;
    if (typeof ttsRate === 'number') initial.pronouncingSpeed = ttsRate;
    if (typeof visualizingSpeed === 'number') initial.visualizingSpeed = visualizingSpeed;
    if (typeof scrollingSpeed === 'number') initial.scrollingSpeed = scrollingSpeed;
    if (typeof isQuadLocked === 'boolean') initial.isQuadLocked = isQuadLocked;
    if (quadSpeedPreset) initial.presetId = quadSpeedPreset as any;
    return initial;
  });

  useEffect(() => {
    if (quadSpeeds) {
      setActiveQuadSpeeds(quadSpeeds);
      return;
    }
    setActiveQuadSpeeds(prev => ({
      ...prev,
      typingSpeed: typeof blackboardWritingSpeed === 'number' ? blackboardWritingSpeed : prev.typingSpeed,
      pronouncingSpeed: typeof ttsRate === 'number' ? ttsRate : prev.pronouncingSpeed,
      visualizingSpeed: typeof visualizingSpeed === 'number' ? visualizingSpeed : prev.visualizingSpeed,
      scrollingSpeed: typeof scrollingSpeed === 'number' ? scrollingSpeed : prev.scrollingSpeed,
      isQuadLocked: typeof isQuadLocked === 'boolean' ? isQuadLocked : prev.isQuadLocked,
      presetId: quadSpeedPreset ? (quadSpeedPreset as any) : prev.presetId,
    }));
  }, [quadSpeeds, blackboardWritingSpeed, ttsRate, visualizingSpeed, scrollingSpeed, isQuadLocked, quadSpeedPreset]);

  // Synchronize with Smartboard Recording Engine
  useEffect(() => {
    smartboardRecorder.setQuadSpeeds({
      typingSpeed: activeQuadSpeeds.typingSpeed,
      pronouncingSpeed: activeQuadSpeeds.pronouncingSpeed,
      visualizingSpeed: activeQuadSpeeds.visualizingSpeed,
      scrollingSpeed: activeQuadSpeeds.scrollingSpeed,
    });
  }, [activeQuadSpeeds]);

  const handleUpdateQuadSpeeds = (updated: QuadSpeedState) => {
    setActiveQuadSpeeds(updated);
    persistQuadSpeedState(updated);
    if (onUpdateQuadSpeeds) {
      onUpdateQuadSpeeds(updated);
    }
  };

  // Container & Three.js Refs
  const lectureHallRootRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  // Fullscreen / Maximize State
  const [isMaximized, setIsMaximized] = useState<boolean>(false);

  const toggleMaximizeLectureHall = () => {
    triggerHapticFeedback(12);
    try {
      playSoundEffect('click');
    } catch {
      // ignore
    }
    const next = !isMaximized;
    setIsMaximized(next);
    if (next) {
      try {
        const elem = lectureHallRootRef.current as any;
        if (elem) {
          if (elem.requestFullscreen) {
            elem.requestFullscreen().catch(() => {});
          } else if (elem.webkitRequestFullscreen) {
            elem.webkitRequestFullscreen();
          } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen();
          } else if (elem.msRequestFullscreen) {
            elem.msRequestFullscreen();
          }
        }
      } catch {
        // ignore iframe permission restrictions
      }
      showNotification?.('3D Interactive Lecture Hall Maximized to Full Screen', 'success');
    } else {
      try {
        const doc = document as any;
        if (doc.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement || doc.msFullscreenElement) {
          if (doc.exitFullscreen) {
            doc.exitFullscreen().catch(() => {});
          } else if (doc.webkitExitFullscreen) {
            doc.webkitExitFullscreen();
          } else if (doc.mozCancelFullScreen) {
            doc.mozCancelFullScreen();
          } else if (doc.msExitFullscreen) {
            doc.msExitFullscreen();
          }
        }
      } catch {
        // ignore
      }
      showNotification?.('3D Interactive Lecture Hall Restored', 'info');
    }
  };

  // Synchronize Three.js viewport and camera on maximize/minimize transition
  useEffect(() => {
    const syncDimensions = () => {
      if (containerRef.current && rendererRef.current && cameraRef.current) {
        const width = containerRef.current.clientWidth || window.innerWidth;
        const height = containerRef.current.clientHeight || window.innerHeight;
        if (width > 0 && height > 0) {
          cameraRef.current.aspect = width / height;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(width, height);
        }
      }
      window.dispatchEvent(new Event('resize'));
    };

    const timer1 = setTimeout(syncDimensions, 50);
    const timer2 = setTimeout(syncDimensions, 320);
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [isMaximized]);

  // Escape key handler to exit maximized view
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMaximized) {
        setIsMaximized(false);
        try {
          const doc = document as any;
          if (doc.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement) {
            if (doc.exitFullscreen) doc.exitFullscreen().catch(() => {});
          }
        } catch {
          // ignore
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isMaximized]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      const doc = document as any;
      const isFullscreen = !!(doc.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement || doc.msFullscreenElement);
      if (!isFullscreen && isMaximized) {
        // If native fullscreen was dismissed via browser ESC, sync state
        setIsMaximized(false);
      }
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
    };
  }, [isMaximized]);

  // 3D Model Refs & Articulated Avatar Rig Joints
  const tutorAvatarGroupRef = useRef<THREE.Group | null>(null);
  const tutorTorsoRef = useRef<THREE.Mesh | null>(null);
  const tutorHeadRef = useRef<THREE.Mesh | null>(null);
  const tutorVisorRef = useRef<THREE.Mesh | null>(null);
  const tutorGlassesRef = useRef<THREE.Mesh | null>(null);
  const tutorWatchRef = useRef<THREE.Mesh | null>(null);
  const tutorTasselRef = useRef<THREE.Group | null>(null);
  const tutorArmRef = useRef<THREE.Group | null>(null);
  const tutorLeftArmRef = useRef<THREE.Group | null>(null);
  const tutorLeftForearmRef = useRef<THREE.Group | null>(null);
  const tutorRightArmRef = useRef<THREE.Group | null>(null);
  const tutorRightForearmRef = useRef<THREE.Group | null>(null);
  const tutorLeftLegRef = useRef<THREE.Group | null>(null);
  const tutorRightLegRef = useRef<THREE.Group | null>(null);
  const heldMarkerRef = useRef<THREE.Mesh | null>(null);
  const heldPointerRef = useRef<THREE.Mesh | null>(null);
  const heldStickGroupRef = useRef<THREE.Group | null>(null);
  const heldPropRef = useRef<THREE.Mesh | null>(null);
  const heldGlassRef = useRef<THREE.Mesh | null>(null);
  const heldNotesRef = useRef<THREE.Mesh | null>(null);

  // Classroom Props & Physics Refs
  const frontDeskChairGroupRef = useRef<THREE.Group | null>(null);
  const frontDeskDrawerGroupRef = useRef<THREE.Group | null>(null);
  const frontDeskLampLightRef = useRef<THREE.PointLight | null>(null);
  const frontLaptopLidGroupRef = useRef<THREE.Group | null>(null);
  const frontLaptopScreenMatRef = useRef<THREE.MeshStandardMaterial | null>(null);
  const proximityRingMeshRef = useRef<THREE.Mesh | null>(null);
  const proximityRingMatRef = useRef<THREE.MeshStandardMaterial | null>(null);
  const doorWingGroupRef = useRef<THREE.Group | null>(null);
  const stickHookGroupRef = useRef<THREE.Group | null>(null);
  const laserDotMeshRef = useRef<THREE.Mesh | null>(null);
  const boardScreenMeshRef = useRef<THREE.Mesh | null>(null);
  const boardScreenMatRef = useRef<THREE.MeshStandardMaterial | null>(null);
  const boardCanvasTextureRef = useRef<THREE.CanvasTexture | null>(null);
  const boardCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const hologramGroupRef = useRef<THREE.Group | null>(null);
  const newtonSpheresRef = useRef<THREE.Mesh[]>([]);
  const newtonStringsRef = useRef<THREE.Line[]>([]);
  const flameLightRef = useRef<THREE.PointLight | null>(null);
  const flameMeshRef = useRef<THREE.Mesh | null>(null);
  const laserBeamRef = useRef<THREE.Line | null>(null);
  const rainbowRaysRef = useRef<THREE.Line[]>([]);
  const beakerBubblesRef = useRef<THREE.Mesh[]>([]);
  const clockHandsRef = useRef<{ hour: THREE.Mesh; minute: THREE.Mesh; second: THREE.Mesh } | null>(null);
  const mainSunLightRef = useRef<THREE.DirectionalLight | null>(null);
  const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
  const roomLightsRef = useRef<THREE.PointLight[]>([]);

  // Avatar Animation Engine State (Synchronized HUD & Modal)
  const [avatarZone, setAvatarZone] = useState<LectureZone>(() => avatarEngine.getActiveZone());
  const [avatarGesture, setAvatarGesture] = useState<AvatarGesture>(() => avatarEngine.getActiveGesture());
  const [avatarExpression, setAvatarExpression] = useState<AvatarExpression>(() => avatarEngine.getActiveExpression());
  const [avatarIsWalking, setAvatarIsWalking] = useState<boolean>(false);
  const [proximityRingState, setProximityRingState] = useState<ProximityState>(() => avatarEngine.getProximityState());
  const [showAvatarModal, setShowAvatarModal] = useState<boolean>(false);
  const [isLaptopViewOpen, setIsLaptopViewOpen] = useState<boolean>(false);
  const [isFpsMonitorOpen, setIsFpsMonitorOpen] = useState<boolean>(false);
  const [fpsCount, setFpsCount] = useState<number>(60);
  const [graphicsQualityMode, setGraphicsQualityMode] = useState<'performance' | 'balanced' | 'ultra'>('balanced');

  useEffect(() => {
    const unsub = avatarEngine.subscribe((state) => {
      setAvatarZone(state.zone);
      setAvatarGesture(state.gesture);
      setAvatarExpression(state.expression);
      setAvatarIsWalking(state.isWalking);
      if (state.proximityState) {
        setProximityRingState(state.proximityState);
      }
    });
    return unsub;
  }, []);

  // Keyboard shortcut listener for Laptop View (L key) and Close (Esc)
  useEffect(() => {
    const handleKeyToggle = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'l' || e.key === 'L') {
        setIsLaptopViewOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyToggle);
    return () => window.removeEventListener('keydown', handleKeyToggle);
  }, []);

  // State
  const [activeCameraView, setActiveCameraView] = useState<CameraViewPreset>('front_row');
  const [lightingPreset, setLightingPreset] = useState<LightingPreset>('daylight');
  const [activeHologram, setActiveHologram] = useState<HologramModel>('math_surface');
  const [isBurnerOn, setIsBurnerOn] = useState<boolean>(true);
  const [isLaserOn, setIsLaserOn] = useState<boolean>(true);
  const [isNewtonCradleSwinging, setIsNewtonCradleSwinging] = useState<boolean>(true);
  const [beakerLiquidColor, setBeakerLiquidColor] = useState<string>('#3b82f6');
  
  // Lesson & AI State
  const [activeLessonIdx, setActiveLessonIdx] = useState<number>(0);
  const [activeTopicTitle, setActiveTopicTitle] = useState<string>(userTopic || 'Interactive Science');
  const [stagedTopicTitle, setStagedTopicTitle] = useState<string | null>(userTopic || null);
  const [stagedLessonIdx, setStagedLessonIdx] = useState<number | null>(null);
  // Professor Clarity Lifecycle Status:
  // 'idle' = normal/reset state
  // 'selected' = chapter selected from dropdown/modal; waiting for user to click Start/Play
  // 'coming_soon' = Start/Play clicked; working on selected chapter (professor is coming soon )
  // 'behind_screen' = task complete; changed from 'coming_soon' to 'professor is behind the screen'
  // 'teaching' = lecture actively delivering/synchronized
  const [professorStatus, setProfessorStatus] = useState<'idle' | 'selected' | 'coming_soon' | 'behind_screen' | 'teaching'>(
    userTopic ? 'selected' : 'idle'
  );
  const preparedBoardRef = useRef<string>('');
  const userClickedStartRef = useRef<boolean>(false);
  // Section-Wise Teaching State (Sections 1 to 7, or 'all')
  const [selectedLectureSection, setSelectedLectureSection] = useState<number | 'all'>('all');
  const preparedSectionsMapRef = useRef<Map<number | 'all', string>>(new Map());
  const selectedLectureSectionRef = useRef<number | 'all'>('all');
  const [showTopicModal, setShowTopicModal] = useState<boolean>(false);
  const [customTopicInput, setCustomTopicInput] = useState<string>('');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [audioEnabled, setAudioEnabled] = useState<boolean>(true);
  const [audioEngineMode, setAudioEngineMode] = useState<'native' | 'neural'>('native');
  const [classroomVoiceOver, setClassroomVoiceOver] = useState<boolean>(true);
  const [isLectureActive, setIsLectureActive] = useState<boolean>(false);
  const [isLecturePaused, setIsLecturePaused] = useState<boolean>(false);
  const [currentSyncStep, setCurrentSyncStep] = useState<number>(0);
  const [totalSyncSteps, setTotalSyncSteps] = useState<number>(0);
  const [activePhaseTitle, setActivePhaseTitle] = useState<string>('');
  const [isTypingLive, setIsTypingLive] = useState<boolean>(false);
  const [userPrompt, setUserPrompt] = useState<string>('');
  const [aiResponseText, setAiResponseText] = useState<string>('Welcome to Virtual Learning! Search or select any topic to begin.');
  const [isSmartboardNotesMinimized, setIsSmartboardNotesMinimized] = useState<boolean>(false);
  const [smartboardLayout, setSmartboardLayout] = useState<'left' | 'center' | 'expanded' | 'fullscreen'>('center');
  const [showProfessorSummaryModal, setShowProfessorSummaryModal] = useState<boolean>(false);
  const [summaryModalInitialTab, setSummaryModalInitialTab] = useState<
    | 'activity_summary' 
    | 'summary_layers'
    | 'overview' 
    | 'formulas' 
    | 'class_exam' 
    | 'competitive_exam' 
    | 'traps' 
    | 'quick_cards'
    | 'self_assessment'
  >('activity_summary');
  const [showPronunciationTrainerModal, setShowPronunciationTrainerModal] = useState<boolean>(false);

  const openProfessorSummaryTab = (tab: 
    | 'activity_summary' 
    | 'summary_layers'
    | 'overview' 
    | 'formulas' 
    | 'class_exam' 
    | 'competitive_exam' 
    | 'traps' 
    | 'quick_cards'
    | 'self_assessment'
  ) => {
    setSummaryModalInitialTab(tab);
    setShowProfessorSummaryModal(true);
    playSoundEffect('chime');
  };
  const [show30sLightningRecap, setShow30sLightningRecap] = useState<boolean>(false);
  const [show5minDeepRecap, setShow5minDeepRecap] = useState<boolean>(false);
  const [showLiveSummaryWidget, setShowLiveSummaryWidget] = useState<boolean>(false);
  const [currentExamTipIdx, setCurrentExamTipIdx] = useState<number>(0);
  const [isSmartboardAutoZoomed, setIsSmartboardAutoZoomed] = useState<boolean>(false);
  const [isDeskHovered, setIsDeskHovered] = useState<boolean>(false);
  const DEFAULT_CONTINUITY_PROMPT = `Master the key concepts of Quadratic Equations & Polynomials through real-world intuition, step-by-step mathematical reasoning, worked examples, and interactive practice problems.`;

  const ensurePromptHeaderInContent = (content: string, promptText?: string): string => {
    if (!content) return '';
    // Strip any legacy prompt header, prompt echoes, or rigor directives so students only see pure educational lecture content
    let clean = content.replace(/^> 💬[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
    clean = clean.replace(/^> \*{0,2}Selected Prompt[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
    clean = clean.replace(/^> \*{0,2}Prompt Selected[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
    clean = clean.replace(/^> \*?"?I want to study[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
    clean = clean.replace(/^> \*?"?I want to solve[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
    clean = clean.replace(/(?:^|\n)[ \t]*>?[ \t]*\*{0,2}(?:Tutor Rigor Instructions|Tutor Instructions|Please proceed to teach|STANDARD depth\/rigor)[^\n]*/gi, '');
    clean = clean.replace(/(?:^|\n)[ \t]*>?[ \t]*\*{0,2}(?:MASTER CURRICULUM|CRITICAL PEDAGOGICAL|MANDATORY NATURAL|STRICT TOPIC|CRITICAL SMARTBOARD|CRITICAL SELECTION|STRICT ZERO)[^\n]*/gi, '');
    clean = clean.replace(/^[ \t]*[=\-_*]{3,}[ \t]*$/gm, '');
    return clean.trim();
  };

  const [selectedPromptText, setSelectedPromptText] = useState<string>(() => {
    if (activePrompt && activePrompt.trim()) return activePrompt.trim();
    if (userTopic && (userTopic.includes('Continuity') || userTopic.includes('Derivative') || userTopic.includes('LHD'))) {
      return DEFAULT_CONTINUITY_PROMPT;
    }
    if (userTopic && userTopic.trim() !== '' && userTopic !== 'None') {
      if (isNumericalRequest(userTopic)) {
        return `Solve numerical problems for "${userTopic}" step-by-step with given values, applied formulas, and final answers with units.`;
      }
      return `Master "${userTopic}" (${userSubject || 'Continuity and Differentiability'}): core concepts with physical intuition, governing formulas, worked examples, and practice questions.`;
    }
    return DEFAULT_CONTINUITY_PROMPT;
  });

  useEffect(() => {
    if (activePrompt && activePrompt.trim()) {
      const cleanPrompt = activePrompt.trim();
      setSelectedPromptText(cleanPrompt);
      setBoardContent(prev => {
        if (!prev) return prev;
        return ensurePromptHeaderInContent(prev, cleanPrompt);
      });
    }
  }, [activePrompt]);

  const [boardContent, setBoardContent] = useState<string>(() => {
    const initPrompt = activePrompt && activePrompt.trim()
      ? activePrompt.trim()
      : (userTopic && (userTopic.includes('Continuity') || userTopic.includes('Derivative') || userTopic.includes('LHD')))
      ? DEFAULT_CONTINUITY_PROMPT
      : userTopic && userTopic.trim() !== '' && userTopic !== 'None'
      ? (isNumericalRequest(userTopic)
          ? `Solve numerical practice questions for "${userTopic}" of Chapter "${userSubject || 'STEM'}". Focus on step-by-step calculations with clear formulas and final answers.`
          : `Master the lesson "${userTopic}" of Chapter "${userSubject || 'STEM'}". Learn core definitions, governing equations, step-by-step worked examples, and practice questions.`)
      : DEFAULT_CONTINUITY_PROMPT;

    if (initialContent && initialContent.trim()) {
      return ensurePromptHeaderInContent(initialContent, initPrompt);
    }
    const initialTopic = userTopic && userTopic.trim() !== '' && userTopic !== 'None'
      ? userTopic
      : 'Quadratic Equations & Polynomials';
    const studyContent = buildStandardOmniStudyContent(initialTopic, userSubject || 'mathematics', language || 'en');
    return ensurePromptHeaderInContent(studyContent, initPrompt);
  });

  useEffect(() => {
    if (initialContent && initialContent.trim()) {
      const activePromptHeader = activePrompt && activePrompt.trim() ? activePrompt.trim() : selectedPromptText;
      const formatted = ensurePromptHeaderInContent(initialContent, activePromptHeader);
      setBoardContent(formatted);
      preparedBoardRef.current = initialContent;
      setAiResponseText(initialContent);
      setTypedBoardContent('');
    }
  }, [initialContent, activePrompt]);
  const [typedBoardContent, setTypedBoardContent] = useState<string>('');
  const [isFigurePinned, setIsFigurePinned] = useState<boolean>(false);
  
  // Figure Lifecycle & Interactive Thumbnail Dock State (PART 6: Default Minimized to Dock)
  const [isStageModeActive, setIsStageModeActive] = useState<boolean>(false);
  const [figureDockHistory, setFigureDockHistory] = useState<Array<{ id: string; svg: string; title: string; timestamp: string }>>([]);
  const [dockSelectedFigure, setDockSelectedFigure] = useState<{ svg: string; title: string } | null>(null);

  // Mid-Chapter Continuous Teaching Energy Boost State (PART 2)
  const [midChapterBoostFired, setMidChapterBoostFired] = useState<boolean>(false);
  const [showMidChapterBoostCard, setShowMidChapterBoostCard] = useState<boolean>(false);

  // Master Rule System Awareness State ("Know what you know & know what is added") (PART 7)
  const [showMasterRuleModal, setShowMasterRuleModal] = useState<boolean>(false);

  // Virtual 3D Backend Services State (AI Draw, Master Rule, Executive Summary, 30s Recap, Deep Recap, Reset Health)
  const [isVirtual3dMenuOpen, setIsVirtual3dMenuOpen] = useState<boolean>(false);
  const [showAiDrawStudioModal, setShowAiDrawStudioModal] = useState<boolean>(false);
  const [aiDrawResult, setAiDrawResult] = useState<AiDrawResult | null>(null);
  const [isLoadingAiDraw, setIsLoadingAiDraw] = useState<boolean>(false);
  const [masterRuleData, setMasterRuleData] = useState<MasterRuleResponse | null>(null);
  const [isLoadingMasterRule, setIsLoadingMasterRule] = useState<boolean>(false);
  const [executiveSummaryData, setExecutiveSummaryData] = useState<ExecutiveSummaryResponse | null>(null);
  const [isLoadingExecutiveSummary, setIsLoadingExecutiveSummary] = useState<boolean>(false);
  const [recap30sData, setRecap30sData] = useState<Recap30sResponse | null>(null);
  const [isLoadingRecap30s, setIsLoadingRecap30s] = useState<boolean>(false);
  const [deepRecapData, setDeepRecapData] = useState<DeepRecapResponse | null>(null);
  const [isLoadingDeepRecap, setIsLoadingDeepRecap] = useState<boolean>(false);
  const [isResettingHealth, setIsResettingHealth] = useState<boolean>(false);

  // Smartboard Screen Presentation Modes: Text Teaching (70/30), Figure Teaching (80/20), Hybrid (50/50)
  const [teachingPresentationMode, setTeachingPresentationMode] = useState<'text_teaching' | 'figure_teaching' | 'hybrid'>('text_teaching');

  // Lecture Delivery Format (Direct Clean Modes: Socratic, Quick Review, Standard Study)
  const [lectureDeliveryFormat, setLectureDeliveryFormat] = useState<'socratic' | 'quick' | 'standard'>(() => {
    try {
      const saved = localStorage.getItem('omni_lecture_delivery_format');
      if (saved === 'socratic' || saved === 'quick' || saved === 'standard') {
        return saved;
      }
    } catch (e) {}
    return 'standard';
  });

  const handleSelectDeliveryFormat = (format: 'socratic' | 'quick' | 'standard') => {
    setLectureDeliveryFormat(format);
    try {
      localStorage.setItem('omni_lecture_delivery_format', format);
    } catch (e) {}
    playSoundEffect('click');
    const formatLabels: Record<string, string> = {
      socratic: '💬 Socratic (Direct 1-on-1 Q&A)',
      quick: '⚡ Quick Review (2-Minute Micro-Lesson)',
      standard: '📘 Standard Master Study (Concept + LaTeX Derivations + Worked Examples)'
    };
    showNotification?.(`Delivery Format: ${formatLabels[format]}`, 'info');
  };

  // Teacher Technique Discovery System ("Teach Me Like...")
  const [selectedTeacherStyle, setSelectedTeacherStyle] = useState<TeacherPedagogyStyle>(() => {
    try {
      const savedId = localStorage.getItem('3d_classroom_teacher_style');
      if (savedId) return getTeacherStyleById(savedId);
    } catch (e) {}
    return getTeacherStyleById('clarity_default');
  });
  const [showTeacherStyleModal, setShowTeacherStyleModal] = useState<boolean>(false);
  const [showProfessorOmniModal, setShowProfessorOmniModal] = useState<boolean>(false);

  // Avatar Customization Auto-Fit Photo System
  const [customAvatarPhotoUrl, setCustomAvatarPhotoUrl] = useState<string | null>(() => {
    try {
      return localStorage.getItem('professor_clarity_custom_avatar') || null;
    } catch (e) { return null; }
  });
  const [avatarPhotoDisplayMode, setAvatarPhotoDisplayMode] = useState<AvatarDisplayMode>(() => {
    try {
      return (localStorage.getItem('professor_clarity_avatar_display_mode') as AvatarDisplayMode) || 'circular';
    } catch (e) { return 'circular'; }
  });
  const [showAvatarPhotoModal, setShowAvatarPhotoModal] = useState<boolean>(false);

  // 10-Step Formula Mastery Framework Modal
  const [showFormulaModal, setShowFormulaModal] = useState<boolean>(false);
  const [activeFormulaModalId, setActiveFormulaModalId] = useState<string>('einstein_photoelectric');

  // Content Collection & Multi-Source Curation Modal State
  const [isContentModalOpen, setIsContentModalOpen] = useState<boolean>(false);

  // Visual Map & Schematic Breakdown Studio Modal State
  const [showVisualMapStudioModal, setShowVisualMapStudioModal] = useState<boolean>(false);

  // Visual Transformation Architect Studio Modal State (5 Pedagogical Modes)
  const [showVisualTransformationModal, setShowVisualTransformationModal] = useState<boolean>(false);

  // React Health & State Management Studio Modal State
  const [showReactHealthModal, setShowReactHealthModal] = useState<boolean>(false);
  const [showDebuggerModal, setShowDebuggerModal] = useState<boolean>(false);

  // Professor Clarity 80-100 Rapid Fire Question Drill Studio State
  const [showRapidFireDrillModal, setShowRapidFireDrillModal] = useState<boolean>(false);

  // Ambient Lighting Inspector Modal State (Nano Banana 2 Realism Engine)
  const [showLightingInspectorModal, setShowLightingInspectorModal] = useState<boolean>(false);
  const [showSecurityModal, setShowSecurityModal] = useState<boolean>(false);

  // Virtual 3D Curriculum & Active Lecture Integration State
  const [showQuickBoardModal, setShowQuickBoardModal] = useState<boolean>(false);
  const [showVocalPersonaModal, setShowVocalPersonaModal] = useState<boolean>(false);
  const [showClassroomAiToolsModal, setShowClassroomAiToolsModal] = useState<boolean>(false);
  const [showClassroomSyllabusModal, setShowClassroomSyllabusModal] = useState<boolean>(false);
  const [showBananaPhysicsModal, setShowBananaPhysicsModal] = useState<boolean>(false);
  const lastPhysicsElapsedRef = useRef<number>(0);

  const [activeBoard, setActiveBoard] = useState<{ nation: string; acronym: string } | null>(selectedBoard || null);
  const [activeDifficulty, setActiveDifficulty] = useState<string>(userDifficulty || 'class_12');
  const [activeSubject, setActiveSubject] = useState<string>(userSubject || 'physics');
  const [activeLessonNum, setActiveLessonNum] = useState<string>(userLesson || '1');
  const [isCurriculumBarCollapsed, setIsCurriculumBarCollapsed] = useState<boolean>(false);
  const [virtual3dPromptMode, setVirtual3dPromptMode] = useState<'smartboard' | 'standard'>('smartboard');

  const getFirstTopicForSubject = (subjId: string): string => {
    const norm = subjId.toLowerCase();
    const syllabus = SYLLABUS_TREE[norm] || SYLLABUS_TREE.physics;
    return syllabus[0]?.topics[0] || 'Kinematics & Motion in 1D/2D';
  };

  const [localPersonaConfig, setLocalPersonaConfig] = useState<TutorPersonaConfig>(() => {
    if (personaConfig) return personaConfig;
    try {
      const saved = localStorage.getItem('omni_tutor_persona_config');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      name: 'Professor Clarity',
      archetype: 'professor_clarity',
      socraticIntensity: 4,
      feedbackTone: 'encouraging',
      inquiryRatio: 65,
      rigorLevel: 75,
      energyLevel: 80,
      analogyDensity: 85
    };
  });

  useEffect(() => {
    if (selectedBoard) setActiveBoard(selectedBoard);
  }, [selectedBoard]);

  useEffect(() => {
    if (userDifficulty) setActiveDifficulty(userDifficulty);
  }, [userDifficulty]);

  useEffect(() => {
    if (userSubject) setActiveSubject(userSubject);
  }, [userSubject]);

  useEffect(() => {
    if (userLesson) setActiveLessonNum(userLesson);
  }, [userLesson]);

  useEffect(() => {
    if (personaConfig) setLocalPersonaConfig(personaConfig);
  }, [personaConfig]);

  const handleUpdatePersona = (newConfig: TutorPersonaConfig) => {
    setLocalPersonaConfig(newConfig);
    if (onUpdatePersonaConfig) {
      onUpdatePersonaConfig(newConfig);
    }
    try {
      localStorage.setItem('omni_tutor_persona_config', JSON.stringify(newConfig));
    } catch (e) {}
    showNotification?.(`Vocal Persona updated: ${newConfig.name}`, 'success');
  };

  // Visual Presentation Architect & Master Formula Practice Studio Modal State
  const [showVisualPresentationModal, setShowVisualPresentationModal] = useState<boolean>(false);

  // Double-Click Editable Asked Question & Solution Modal State
  const [showQuestionSolutionEditorModal, setShowQuestionSolutionEditorModal] = useState<boolean>(false);
  const [editableQuestionSolutionText, setEditableQuestionSolutionText] = useState<string>('');
  const lastPointerTapTimeRef = useRef<number>(0);

  // Professor Clarity Practice Question Quantity & Multi-Tier Hinting Vault Modal State
  const [showPracticeQuestionModal, setShowPracticeQuestionModal] = useState<boolean>(false);
  const [practiceQuestionInitialMode, setPracticeQuestionInitialMode] = useState<'academic' | 'competitive'>('academic');

  // Live Exam Tips database for rotation
  const EXAM_TIPS_DATABASE = useMemo(() => [
    "💡 BOARD EXAM TIP: Always label diagrams clearly — each label carries marks in school/board exams.",
    "💡 NEET TIP: Mitochondria produce ATP by oxidative phosphorylation across the inner cristae membrane!",
    "💡 JEE MAIN/ADV TIP: For numerical calculations, write Given values, Formula, Substitution, and final SI unit.",
    "💡 OLYMPIAD TIP: Watch out for boundary constraints and extreme limits when evaluating formulas.",
    "💡 EXAM TRAP: Don't confuse instantaneous rate of change with average rate across an interval!",
    "💡 SPEED TRICK: Calculate rate by multiplying surface area × flux density × duration.",
    "💡 BOARD DERIVATION TIP: Label all coordinate axes, vectors, and boundary values clearly."
  ], []);

  // Rotate Exam Tips every 25 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentExamTipIdx(prev => (prev + 1) % EXAM_TIPS_DATABASE.length);
    }, 25000);
    return () => clearInterval(timer);
  }, [EXAM_TIPS_DATABASE.length]);

  // Trigger Smartboard Auto-Zoom when active phase or topic changes
  useEffect(() => {
    if (activePhaseTitle) {
      setIsSmartboardAutoZoomed(true);
      const zoomTimer = setTimeout(() => setIsSmartboardAutoZoomed(false), 2500);
      return () => clearTimeout(zoomTimer);
    }
  }, [activePhaseTitle]);

  interface ExtractedFigureInfo {
    svg: string;
    title: string;
  }

  // Helper to extract active inline SVG or figure code and title from lecture markdown text
  const extractActiveFigureInfoFromMarkdown = useCallback((text: string): ExtractedFigureInfo | null => {
    if (!text) return null;
    
    // 1. Check for all <svg ... </svg> occurrences and pick the latest one in the expanding lecture
    const allSvgMatches = [...text.matchAll(/<svg[\s\S]*?<\/svg>/gi)];
    if (allSvgMatches.length > 0) {
      const latestMatch = allSvgMatches[allSvgMatches.length - 1];
      const rawSvgCode = latestMatch[0];
      const svgCode = sanitizeSvgDiagramCode(rawSvgCode) || rawSvgCode;
      const matchIndex = latestMatch.index ?? text.lastIndexOf(rawSvgCode);
      const beforeSvg = text.substring(0, matchIndex);
      const headings = [...beforeSvg.matchAll(/(?:###|##|#)\s*([^\n]+)/g)];
      const lastHeading = headings.length > 0 ? headings[headings.length - 1][1].replace(/\*/g, '').trim() : 'Interactive Vector Diagram';
      return {
        svg: svgCode,
        title: lastHeading
      };
    }

    // 2. Check for [Draw: ...] or *(Illustration: ...)*
    const allDrawMatches = [...text.matchAll(/(?:\[Draw:\s*([^\]]+)\]|\*\(Illustration:\s*([^\)]+)\)\*)/gi)];
    if (allDrawMatches.length > 0) {
      const latestDraw = allDrawMatches[allDrawMatches.length - 1];
      const label = (latestDraw[1] || latestDraw[2] || '').trim();
      const syntheticSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 280" className="w-full h-auto">
        <defs>
          <linearGradient id="figBgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#020617" />
            <stop offset="100%" stop-color="#0f172a" />
          </linearGradient>
        </defs>
        <rect width="600" height="280" rx="16" fill="url(#figBgGrad)" stroke="#38bdf8" stroke-width="2" stroke-dasharray="6 4" />
        <circle cx="300" cy="115" r="50" fill="none" stroke="#38bdf8" stroke-width="3" />
        <circle cx="300" cy="115" r="32" fill="none" stroke="#818cf8" stroke-width="2" />
        <circle cx="300" cy="115" r="8" fill="#38bdf8" />
        <path d="M220,115 L380,115 M300,45 L300,185" stroke="rgba(56,189,248,0.35)" stroke-width="1.5" stroke-dasharray="4 4" />
        <text x="300" y="220" text-anchor="middle" fill="#f8fafc" font-family="sans-serif" font-size="17" font-weight="bold">${label}</text>
        <text x="300" y="250" text-anchor="middle" fill="#38bdf8" font-family="sans-serif" font-size="11" letter-spacing="1">VECTOR SCHEMATIC UNDER ACTIVE DISCUSSION</text>
      </svg>`;
      return {
        svg: syntheticSvg,
        title: label
      };
    }

    return null;
  }, []);

  const activeFigureInfo = useMemo(() => {
    return extractActiveFigureInfoFromMarkdown(typedBoardContent || boardContent);
  }, [typedBoardContent, boardContent, extractActiveFigureInfoFromMarkdown]);

  // Backward compatibility alias for active SVG code
  const activeSvgFigure = activeFigureInfo?.svg || null;

  // Auto-dock any detected SVG figure in the virtual 3D classroom (default: minimized to dock)
  useEffect(() => {
    const svg = activeFigureInfo?.svg;
    const title = activeFigureInfo?.title || 'Interactive Diagram';
    if (svg) {
      setFigureDockHistory(prev => {
        if (prev.some(f => f.title === title || f.svg === svg)) return prev;
        return [...prev, {
          id: `fig-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          svg,
          title,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }];
      });
    }
  }, [activeFigureInfo?.svg, activeFigureInfo?.title]);

  // Master Rule Live Board State Tracker Metrics
  const boardStateMetrics = useMemo(() => {
    const text = typedBoardContent || boardContent || '';
    const words = text.split(/\s+/).filter(Boolean).length;
    const lines = text.split('\n').length;
    const equations = (text.match(/\$[^$]+\$/g) || []).length;
    const questions = (text.match(/(?:^|\n)(?:### 📌|\*\*Q|\*\*\[Category|\*\*\[NEET|\*\*\[JEE|Q\d+\.)/g) || []).length;
    const headings = [...text.matchAll(/(?:###|##|#)\s*([^\n]+)/g)].map(m => m[1].replace(/[*_]/g, '').trim());
    const progress = totalSyncSteps > 0 ? Math.min(100, Math.round((currentSyncStep / totalSyncSteps) * 100)) : 0;
    
    return {
      words,
      lines,
      equations,
      questions,
      headings,
      progress,
      figuresCount: figureDockHistory.length + (activeFigureInfo ? 1 : 0),
      activePhase: activePhaseTitle || 'Foundational Principles',
    };
  }, [typedBoardContent, boardContent, totalSyncSteps, currentSyncStep, figureDockHistory.length, activeFigureInfo, activePhaseTitle]);

  const boardScrollContainerRef = useRef<HTMLDivElement>(null);
  const typewriterTimerRef = useRef<any>(null);
  const speechSessionIdRef = useRef<number>(0);
  const isPausedRef = useRef<boolean>(false);
  const currentChunkIndexRef = useRef<number>(0);

  // Helper to clean meta-time markers, prompt echoes, delimiters, and bracketed duration tags from board display text
  const cleanBoardContentForDisplay = (rawText: string): string => {
    if (!rawText) return '';
    let cleaned = cleanNaturalLanguageForScreen(rawText);
    cleaned = stripMarkdownCodeFencesAndDelimiters(cleaned, false);
    cleaned = cleanStreamingMarkdown(cleaned, false);
    cleaned = cleaned.replace(/^[ \t]*>?[ \t]*\*{0,2}(?:Selected Prompt|Prompt Selected|Tutor Rigor Instructions|Tutor Instructions)[^\n]*\n?/gim, '');
    cleaned = cleaned.replace(/\\left\[/g, '[').replace(/\\right\]/g, ']');
    cleaned = cleaned.replace(/\\left\(/g, '(').replace(/\\right\)/g, ')');
    return cleaned;
  };

  // Helper to clean text for speech engine so it sounds completely natural with real-world unit pronunciations & mathematical reading
  const cleanTextForSpeech = (rawText: string): string => {
    return convertLaTeXToSpokenText(rawText);
  };

  // Structured segment parser for synchronized live lecture with Avatar Animation Engine
  interface LectureSegment {
    displayMarkdown: string;
    spokenText: string;
    isDrawing: boolean;
    pauseMs: number;
    phaseTitle?: string;
    avatarTrigger?: AvatarAnimationTrigger | null;
    inferredAvatar?: { zone: LectureZone; gesture: AvatarGesture; expression: AvatarExpression };
  }

  const parseLectureIntoSegments = (rawMarkdown: string): LectureSegment[] => {
    if (!rawMarkdown) return [];

    const cleaned = rawMarkdown
      .replace(/\(\s*\d+[-–—\s]*\d*\s*(min|mins|minutes?|sec|seconds?)\s*\)/gi, '')
      .trim();

    const lines = cleaned.split('\n');
    const segments: LectureSegment[] = [];
    let currentBlock: string[] = [];

    const flushBlock = () => {
      if (currentBlock.length === 0) return;
      const blockText = currentBlock.join('\n').trim();
      currentBlock = [];
      if (!blockText) return;

      const isDrawingMarker = /\[Draw:\s*([^\]]+)\]/i.test(blockText);
      const isSvgBlock = blockText.includes('<svg') && blockText.includes('</svg>');
      const pauseMatch = blockText.match(/\[Pause:\s*(\d+(?:\.\d+)?)\s*(?:sec|seconds?|s)\]/i);

      let pauseMs = 0;
      if (pauseMatch) {
        pauseMs = parseFloat(pauseMatch[1]) * 1000;
      }

      // Check for explicit [AVATAR: ...] trigger in the block
      let avatarTrigger: AvatarAnimationTrigger | null = null;
      const avatarMatch = blockText.match(/\[AVATAR:\s*[^\]]+\]/i);
      if (avatarMatch) {
        avatarTrigger = avatarEngine.parseAvatarTrigger(avatarMatch[0]);
      }

      let display = cleanNaturalLanguageForScreen(blockText);

      if (!display && !isDrawingMarker && pauseMs === 0 && !avatarTrigger) return;

      const spoken = cleanTextForSpeech(blockText);
      const phaseTitle = blockText.startsWith('#') ? blockText.replace(/^#+\s*/, '') : undefined;
      const inferredAvatar = !avatarTrigger ? avatarEngine.inferAvatarActionForText(display, isDrawingMarker, isSvgBlock, phaseTitle) : undefined;

      segments.push({
        displayMarkdown: display,
        spokenText: (isDrawingMarker || isSvgBlock) ? '' : spoken,
        isDrawing: isDrawingMarker || isSvgBlock,
        pauseMs: (isDrawingMarker || isSvgBlock) ? Math.max(2500, pauseMs || 2500) : pauseMs,
        phaseTitle,
        avatarTrigger,
        inferredAvatar
      });
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Multi-line or single-line SVG diagram handler
      if (line.includes('<svg')) {
        flushBlock();
        const svgLines: string[] = [line];
        if (!line.includes('</svg>')) {
          while (i + 1 < lines.length) {
            i++;
            svgLines.push(lines[i]);
            if (lines[i].includes('</svg>')) break;
          }
        }
        const fullSvg = svgLines.join('\n').trim();
        segments.push({
          displayMarkdown: fullSvg,
          spokenText: '', // SILENCE: Absolute pause speaking while diagram is being drawn/rendered
          isDrawing: true,
          pauseMs: 2800,
          phaseTitle: 'Diagram & Visual Schematic',
          inferredAvatar: { zone: 'smartboard', gesture: 'drawing_on_smartboard', expression: 'focused' }
        });
        continue;
      }

      // Explicit Drawing command handler
      if (line.trim().startsWith('[Draw:')) {
        flushBlock();
        const drawLabel = line.replace(/\[Draw:\s*([^\]]+)\]/i, '$1').trim();
        segments.push({
          displayMarkdown: cleanNaturalLanguageForScreen(drawLabel) || 'Visual Diagram',
          spokenText: '', // SILENCE: Absolute pause speaking while drawing illustration
          isDrawing: true,
          pauseMs: 2200,
          phaseTitle: `Diagram Drawing: ${drawLabel}`,
          inferredAvatar: { zone: 'smartboard', gesture: 'drawing_on_smartboard', expression: 'focused' }
        });
        continue;
      }

      if (line.startsWith('###') || line.startsWith('##') || line.startsWith('#') || line.startsWith('---')) {
        flushBlock();
        currentBlock.push(line);
        flushBlock();
      } else if (line.trim().startsWith('[Pause:') || line.trim().startsWith('[Scroll:') || line.trim().startsWith('[AVATAR:')) {
        flushBlock();
        currentBlock.push(line);
        flushBlock();
      } else if (line.includes('```')) {
        flushBlock();
        currentBlock.push(line);
      } else if (line.trim() === '') {
        flushBlock();
      } else {
        currentBlock.push(line);
      }
    }
    flushBlock();

    return segments;
  };
  const [isLoadingAi, setIsLoadingAi] = useState<boolean>(false);
  const [isInitializingLecture, setIsInitializingLecture] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [showEquipmentMenu, setShowEquipmentMenu] = useState<boolean>(false);
  const [activeEquipmentTooltip, setActiveEquipmentTooltip] = useState<string | null>(null);
  const [showMobileToolsMenu, setShowMobileToolsMenu] = useState<boolean>(false);
  const [showMobileCameraMenu, setShowMobileCameraMenu] = useState<boolean>(false);

  // Content loading estimate timer and network ping status
  const isContentLoading = isLoadingAi || isInitializingLecture || professorStatus === 'coming_soon';
  const { formattedElapsed, formattedEstimate, pingSpeed, connectionQuality } = useContentLoadingEstimate(isContentLoading);

  // Speech synthesis voice cache
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const updateVoices = () => {
        const v = window.speechSynthesis.getVoices();
        if (v && v.length > 0) {
          setAvailableVoices(v);
        }
      };
      updateVoices();
      window.speechSynthesis.onvoiceschanged = updateVoices;
      return () => {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.onvoiceschanged = null;
        }
      };
    }
  }, []);

  // Reliable helper to resolve active language configuration
  const resolveLanguageObject = (requestedLang?: string) => {
    const candidate = (requestedLang || selectedLectureLanguage || selectedLanguage || language || 'en').trim();
    
    // Direct match by name (case-insensitive) or code
    const directMatch = LANGUAGES.find(l => 
      l.name.toLowerCase() === candidate.toLowerCase() ||
      l.code.toLowerCase() === candidate.toLowerCase()
    );
    if (directMatch) return directMatch;

    // Prefix / locale match e.g. 'hi-IN' -> 'hi'
    const prefixMatch = LANGUAGES.find(l => 
      candidate.toLowerCase().startsWith(l.code.toLowerCase()) || 
      l.code.toLowerCase().startsWith(candidate.toLowerCase())
    );
    if (prefixMatch) return prefixMatch;

    return LANGUAGES[0]; // English fallback
  };

  // Standard Mode Tutor Search & Features State
  const [showFeaturesMenu, setShowFeaturesMenu] = useState<boolean>(false);
  const [showChatControlsModal, setShowChatControlsModal] = useState<boolean>(false);
  const [chatMode, setChatMode] = useState<'professor' | 'socratic' | 'step_by_step' | 'direct'>('professor');
  const [selectedLanguage, setSelectedLanguage] = useState<string>(() => {
    const candidate = (language || 'English').trim();
    const match = LANGUAGES.find(l => 
      l.name.toLowerCase() === candidate.toLowerCase() ||
      l.code.toLowerCase() === candidate.toLowerCase()
    );
    return match ? match.name : 'English';
  });
  const [selectedLectureLanguage, setSelectedLectureLanguage] = useState<string>(() => {
    const candidate = (language || 'English').trim();
    const match = LANGUAGES.find(l => 
      l.name.toLowerCase() === candidate.toLowerCase() ||
      l.code.toLowerCase() === candidate.toLowerCase()
    );
    return match ? match.name : 'English';
  });
  const [academicRigor, setAcademicRigor] = useState<'graduate' | 'advanced' | 'standard'>('advanced');
  const [selectedFile, setSelectedFile] = useState<{ name: string; type: string; previewUrl: string } | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Screen Recording State (MediaRecorder API)
  const [screenRecordingState, setScreenRecordingState] = useState<'idle' | 'recording' | 'paused'>('idle');
  const [screenRecordingDuration, setScreenRecordingDuration] = useState<number>(0);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const [showRecordingPlaybackModal, setShowRecordingPlaybackModal] = useState<boolean>(false);
  const [recordedChapters, setRecordedChapters] = useState<RecordedChapter[]>([]);
  const recordedChaptersRef = useRef<RecordedChapter[]>([]);
  const screenMediaRecorderRef = useRef<MediaRecorder | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const screenChunksRef = useRef<Blob[]>([]);
  const screenTimerRef = useRef<any>(null);

  // Session Timer Video Overlay Settings (Minimal, Digital-Clock, Progress-Bar)
  const [sessionTimerStyle, setSessionTimerStyle] = useState<'minimal' | 'digital-clock' | 'progress-bar'>(() => {
    try {
      const saved = localStorage.getItem('clarity_timer_overlay_style');
      if (saved === 'minimal' || saved === 'digital-clock' || saved === 'progress-bar') return saved;
    } catch {}
    return 'digital-clock';
  });
  const [sessionTimerEnabled, setSessionTimerEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('clarity_timer_overlay_enabled');
      if (saved !== null) return saved === 'true';
    } catch {}
    return true;
  });

  const handleSetSessionTimerStyle = (style: 'minimal' | 'digital-clock' | 'progress-bar') => {
    setSessionTimerStyle(style);
    try {
      localStorage.setItem('clarity_timer_overlay_style', style);
    } catch {}
    smartboardRecorder.setSessionTimerStyle(style);
    showNotification?.(`Session timer overlay style set to: ${style === 'digital-clock' ? 'Digital Clock' : style === 'progress-bar' ? 'Progress Bar' : 'Minimal'}`, 'info');
  };

  const handleSetSessionTimerEnabled = (enabled: boolean) => {
    setSessionTimerEnabled(enabled);
    try {
      localStorage.setItem('clarity_timer_overlay_enabled', String(enabled));
    } catch {}
    smartboardRecorder.setSessionTimerEnabled(enabled);
    showNotification?.(enabled ? "Session timer overlay enabled on video" : "Session timer overlay disabled on video", 'info');
  };

  const handleCycleSessionTimerStyle = () => {
    const nextStyle: Record<'minimal' | 'digital-clock' | 'progress-bar', 'minimal' | 'digital-clock' | 'progress-bar'> = {
      'minimal': 'digital-clock',
      'digital-clock': 'progress-bar',
      'progress-bar': 'minimal'
    };
    handleSetSessionTimerStyle(nextStyle[sessionTimerStyle]);
  };

  // Camera Feed State & Handlers
  const [cameraFeedEnabled, setCameraFeedEnabled] = useState<boolean>(false);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const cameraVideoRef = useRef<HTMLVideoElement | null>(null);

  // Collaborative Whiteboard Modal State
  const [showWhiteboardModal, setShowWhiteboardModal] = useState<boolean>(false);

  // Setting Dropdown State & Outside Click Handler
  const [showSettingDropdown, setShowSettingDropdown] = useState<boolean>(false);
  const settingDropdownRef = useRef<HTMLDivElement>(null);

  // Persistent Floating Countdown Timer State
  const [timerInitialSeconds, setTimerInitialSeconds] = useState<number>(25 * 60); // 25 mins default
  const [timerSeconds, setTimerSeconds] = useState<number>(25 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [isTimerMinimized, setIsTimerMinimized] = useState<boolean>(false);
  const [isTimerVisible, setIsTimerVisible] = useState<boolean>(false);

  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimerSeconds(prev => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            playSoundEffect('chime');
            showNotification?.("🔔 Study Session Countdown Completed! Great job!", "success");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, showNotification]);

  const formatTimerTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    const hrs = Math.floor(mins / 60);
    if (hrs > 0) {
      const remMins = mins % 60;
      return `${hrs.toString().padStart(2, '0')}:${remMins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSetTimerPreset = (minutes: number) => {
    const totalSec = minutes * 60;
    setTimerInitialSeconds(totalSec);
    setTimerSeconds(totalSec);
    setIsTimerRunning(false);
    playSoundEffect('click');
  };

  const handleResetTimer = () => {
    setTimerSeconds(timerInitialSeconds);
    setIsTimerRunning(false);
    playSoundEffect('click');
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (settingDropdownRef.current && !settingDropdownRef.current.contains(event.target as Node)) {
        setShowSettingDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Classroom Mode Silent-Draw Toggle State & LocalStorage Persistence
  const [silentDraw, setSilentDraw] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_silent_draw');
    return saved !== null ? saved === 'true' : false;
  });

  useEffect(() => {
    const handleSyncSilentDraw = () => {
      const saved = localStorage.getItem('omni_silent_draw');
      setSilentDraw(saved !== null ? saved === 'true' : false);
    };
    window.addEventListener('omni_silent_draw_changed', handleSyncSilentDraw);
    window.addEventListener('omni-manual-sync', handleSyncSilentDraw);
    window.addEventListener('storage', handleSyncSilentDraw);
    return () => {
      window.removeEventListener('omni_silent_draw_changed', handleSyncSilentDraw);
      window.removeEventListener('omni-manual-sync', handleSyncSilentDraw);
      window.removeEventListener('storage', handleSyncSilentDraw);
    };
  }, []);

  const handleToggleSilentDraw = (newValue?: boolean) => {
    const updated = newValue !== undefined ? newValue : !silentDraw;
    setSilentDraw(updated);
    localStorage.setItem('omni_silent_draw', String(updated));
    window.dispatchEvent(new Event('omni_silent_draw_changed'));
    playSoundEffect('click');
    showNotification?.(
      updated
        ? "Silent-Draw Enabled: AI will automatically render SVG figures & LaTeX diagrams without explicit text triggers."
        : "Silent-Draw Disabled: SVG figures & diagrams rendered on demand.",
      'info'
    );
  };

  // Helper to draw clean, rounded tactile buttons with gradients, glows and icons on 2D smartboard canvas
  const drawSmartboardCanvasButton = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    radius: number,
    bgGradientColors: [string, string],
    borderColor: string,
    textColor: string,
    icon: string,
    text: string,
    badge?: string,
    isActive?: boolean
  ) => {
    ctx.save();
    if (isActive) {
      ctx.shadowColor = borderColor;
      ctx.shadowBlur = 14;
    } else {
      ctx.shadowColor = 'rgba(0, 0, 0, 0.45)';
      ctx.shadowBlur = 6;
    }
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 3;

    // Background Gradient Fill
    const grad = ctx.createLinearGradient(x, y, x, y + h);
    grad.addColorStop(0, bgGradientColors[0]);
    grad.addColorStop(1, bgGradientColors[1]);
    ctx.fillStyle = grad;

    // Rounded rectangle path
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + w - radius, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
    ctx.lineTo(x + w, y + h - radius);
    ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
    ctx.lineTo(x + radius, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fill();

    // Border stroke
    ctx.shadowBlur = 0;
    ctx.strokeStyle = borderColor;
    ctx.lineWidth = isActive ? 3 : 2;
    ctx.stroke();

    // Top subtle gloss shine highlight
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(x + radius + 4, y + 2.5);
    ctx.lineTo(x + w - radius - 4, y + 2.5);
    ctx.stroke();

    // Button Label & Icon
    ctx.fillStyle = textColor;
    ctx.font = 'bold 16px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const label = icon ? `${icon}  ${text}` : text;
    ctx.fillText(label, x + w / 2, y + (badge ? (h / 2 - 6) : (h / 2)));

    // Optional Sub-Badge
    if (badge) {
      ctx.font = 'bold 9px monospace';
      ctx.fillStyle = '#fde047';
      ctx.fillText(badge, x + w / 2, y + h - 12);
    }

    ctx.restore();
  };

  // Dynamic Canvas Texture Generator for the 3D Smartboard in Three.js
  const update3dSmartboardTexture = useCallback(() => {
    if (!boardScreenMatRef.current) return;

    let canvas = boardCanvasRef.current;
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.width = 2048;
      canvas.height = 1024;
      boardCanvasRef.current = canvas;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background: High-tech dark chalkboard / smartboard glass
    const bgGrad = ctx.createLinearGradient(0, 0, 0, 1024);
    bgGrad.addColorStop(0, '#040814');
    bgGrad.addColorStop(1, '#091024');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 2048, 1024);

    // Subtle digital grid overlay
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < 2048; x += 64) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 1024);
      ctx.stroke();
    }
    for (let y = 0; y < 1024; y += 64) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(2048, y);
      ctx.stroke();
    }

    // Outer border glow
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 4;
    ctx.strokeRect(12, 12, 2024, 1000);

    // Header bar background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(16, 16, 2016, 92);

    // Determine current working status
    const isWorkingOnTopic = professorStatus === 'coming_soon' || isLoadingAi || isInitializingLecture;
    const currentTopicDisplay = stripAllRawMarkdown(activeTopicTitle || stagedTopicTitle || userTopic || 'Interactive STEM Lecture');

    // Header Live Badge with dynamic state
    if (professorStatus === 'coming_soon' || isWorkingOnTopic) {
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(52, 62, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fbbf24';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('⏳ PROFESSOR COMING SOON', 72, 69);
    } else if (professorStatus === 'behind_screen') {
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(52, 62, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('👨‍🏫 PROFESSOR IS BEHIND SCREEN', 72, 69);
    } else if (stagedTopicTitle || professorStatus === 'selected') {
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(52, 62, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('✨ CHAPTER SELECTED', 72, 69);
    } else if (isLectureActive && !isLecturePaused) {
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(52, 62, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('🎙️ LIVE TEACHING', 72, 69);
    } else if (isLecturePaused) {
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(52, 62, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fcd34d';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('⏸️ LECTURE PAUSED', 72, 69);
    } else {
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(52, 62, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('LIVE SMARTBOARD', 72, 69);
    }

    // Header Topic Title with explicit indicator
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    const topicLabel = professorStatus === 'coming_soon' || isWorkingOnTopic
      ? `Working on: ${currentTopicDisplay}`
      : professorStatus === 'behind_screen'
      ? `Ready: ${currentTopicDisplay}`
      : stagedTopicTitle || professorStatus === 'selected'
      ? `Selected: ${currentTopicDisplay}`
      : `Teaching: ${currentTopicDisplay}`;
    ctx.fillText(topicLabel.length > 34 ? topicLabel.slice(0, 32) + '...' : topicLabel, 400, 69);

    // --- TOP HEADER QUICK ACTION BUTTONS (HIGH VISIBILITY ON 3D SMARTBOARD) ---
    // 1. Play / Pause / Resume Button
    const playBtnLabel = isWorkingOnTopic ? 'PREPARING...' : (isLectureActive && !isLecturePaused) ? 'PAUSE' : isLecturePaused ? 'RESUME' : 'START';
    const playBtnIcon = isWorkingOnTopic ? '⏳' : (isLectureActive && !isLecturePaused) ? '⏸' : '▶';
    const playBtnBg: [string, string] = isWorkingOnTopic
      ? ['#78350f', '#d97706']
      : (isLectureActive && !isLecturePaused)
      ? ['#b45309', '#d97706']
      : isLecturePaused
      ? ['#047857', '#10b981']
      : ['#059669', '#10b981'];
    const playBorder = isWorkingOnTopic ? '#fbbf24' : (isLectureActive && !isLecturePaused) ? '#fbbf24' : '#34d399';
    drawSmartboardCanvasButton(ctx, 1020, 30, 180, 64, 12, playBtnBg, playBorder, '#ffffff', playBtnIcon, playBtnLabel, undefined, isLectureActive || isWorkingOnTopic);

    // 2. Audio Toggle Button
    const audioLabel = audioEnabled ? 'AUDIO ON' : 'MUTED';
    const audioIcon = audioEnabled ? '🔊' : '🔇';
    const audioBg: [string, string] = audioEnabled ? ['#4338ca', '#6366f1'] : ['#881337', '#be123c'];
    drawSmartboardCanvasButton(ctx, 1220, 30, 170, 64, 12, audioBg, audioEnabled ? '#818cf8' : '#f43f5e', '#ffffff', audioIcon, audioLabel);

    // 3. 30s Rapid Recap Button
    drawSmartboardCanvasButton(ctx, 1410, 30, 180, 64, 12, ['#c2410c', '#ea580c'], '#fb923c', '#ffffff', '⚡', '30s RECAP');

    // 4. Focus / Zoom Board Button
    drawSmartboardCanvasButton(ctx, 1610, 30, 190, 64, 12, ['#0284c7', '#0ea5e9'], '#38bdf8', '#ffffff', '🔍', 'ZOOM BOARD');

    // 5. Topics Menu Button
    drawSmartboardCanvasButton(ctx, 1820, 30, 190, 64, 12, ['#475569', '#64748b'], '#94a3b8', '#ffffff', '📚', 'TOPICS');

    // Accent line below header
    const lineGrad = ctx.createLinearGradient(0, 0, 2048, 0);
    lineGrad.addColorStop(0, '#6366f1');
    lineGrad.addColorStop(0.5, '#38bdf8');
    lineGrad.addColorStop(1, '#10b981');
    ctx.fillStyle = lineGrad;
    ctx.fillRect(16, 110, 2016, 4);

    // --- PROMINENT WORKING STATUS BANNER (EXPLICIT FEEDBACK ON ACTIVE CHAPTER) ---
    const statusBannerY = 120;
    const statusBannerH = 46;
    if (professorStatus === 'coming_soon' || isWorkingOnTopic) {
      // High-visibility animated pulsing loading strip
      const bannerGrad = ctx.createLinearGradient(16, statusBannerY, 2032, statusBannerY);
      bannerGrad.addColorStop(0, 'rgba(180, 83, 9, 0.95)');
      bannerGrad.addColorStop(0.5, 'rgba(217, 119, 6, 0.95)');
      bannerGrad.addColorStop(1, 'rgba(180, 83, 9, 0.95)');
      ctx.fillStyle = bannerGrad;
      ctx.fillRect(16, statusBannerY, 2016, statusBannerH);
      ctx.strokeStyle = '#fde047';
      ctx.lineWidth = 2;
      ctx.strokeRect(16, statusBannerY, 2016, statusBannerH);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText(`⚙️ Working on selected chapter: "${currentTopicDisplay}" (professor is coming soon )`, 40, statusBannerY + 30);
    } else if (professorStatus === 'behind_screen') {
      const bannerGrad = ctx.createLinearGradient(16, statusBannerY, 2032, statusBannerY);
      bannerGrad.addColorStop(0, 'rgba(6, 78, 59, 0.95)');
      bannerGrad.addColorStop(0.5, 'rgba(16, 185, 129, 0.95)');
      bannerGrad.addColorStop(1, 'rgba(6, 78, 59, 0.95)');
      ctx.fillStyle = bannerGrad;
      ctx.fillRect(16, statusBannerY, 2016, statusBannerH);
      ctx.strokeStyle = '#6ee7b7';
      ctx.lineWidth = 2;
      ctx.strokeRect(16, statusBannerY, 2016, statusBannerH);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText(`🎓 Working on selected chapter: "${currentTopicDisplay}" • professor is behind the screen`, 40, statusBannerY + 30);
    } else if (stagedTopicTitle || professorStatus === 'selected') {
      const bannerGrad = ctx.createLinearGradient(16, statusBannerY, 2032, statusBannerY);
      bannerGrad.addColorStop(0, 'rgba(15, 23, 42, 0.95)');
      bannerGrad.addColorStop(0.5, 'rgba(30, 41, 59, 0.95)');
      bannerGrad.addColorStop(1, 'rgba(15, 23, 42, 0.95)');
      ctx.fillStyle = bannerGrad;
      ctx.fillRect(16, statusBannerY, 2016, statusBannerH);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.strokeRect(16, statusBannerY, 2016, statusBannerH);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText(`✨ CHAPTER SELECTED: "${stagedTopicTitle || currentTopicDisplay}" • Click ▶ START / PLAY on the smartboard or toolbar to begin lecture`, 40, statusBannerY + 30);
    } else if (isLectureActive && !isLecturePaused) {
      ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
      ctx.fillRect(16, statusBannerY, 2016, statusBannerH);
      ctx.strokeStyle = 'rgba(52, 211, 153, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(16, statusBannerY, 2016, statusBannerH);

      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 19px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      const phaseInfo = activePhaseTitle ? ` • Phase: ${activePhaseTitle}` : '';
      const stepInfo = totalSyncSteps > 0 ? ` (Step ${currentSyncStep}/${totalSyncSteps})` : '';
      ctx.fillText(`🎙️ ACTIVE CHAPTER: "${currentTopicDisplay}"${phaseInfo}${stepInfo}`, 40, statusBannerY + 30);

      // Progress mini-bar inside banner
      if (totalSyncSteps > 0) {
        const pct = Math.min(1, currentSyncStep / totalSyncSteps);
        ctx.fillStyle = 'rgba(52, 211, 153, 0.25)';
        ctx.fillRect(1500, statusBannerY + 14, 480, 18);
        ctx.fillStyle = '#34d399';
        ctx.fillRect(1500, statusBannerY + 14, 480 * pct, 18);
        ctx.strokeStyle = '#34d399';
        ctx.strokeRect(1500, statusBannerY + 14, 480, 18);
      }
    } else {
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.fillRect(16, statusBannerY, 2016, statusBannerH);
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
      ctx.lineWidth = 1;
      ctx.strokeRect(16, statusBannerY, 2016, statusBannerH);

      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 18px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      const subjectTag = userSubject ? `[${userSubject}]` : '[STEM]';
      const boardTag = selectedBoard?.acronym ? `[${selectedBoard.acronym}]` : '';
      const modeLabel = isChapterIntro(currentTopicDisplay) ? 'Chapter Intro & 5-Layer Summary' : 'Direct Question-Responsive Teaching';
      ctx.fillText(`📚 ACTIVE LESSON: "${currentTopicDisplay}"  ${subjectTag} ${boardTag}  •  ${modeLabel}`, 40, statusBannerY + 30);
    }

    // Dedicated Lesson Objective & Key Concepts Banner on 3D Smartboard Canvas (Student-Centric)
    const promptBoxX = 20;
    const promptBoxY = statusBannerY + statusBannerH + 8;
    const promptBoxW = 2008;
    const promptBoxH = 74;

    ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
    ctx.fillRect(promptBoxX, promptBoxY, promptBoxW, promptBoxH);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.strokeRect(promptBoxX, promptBoxY, promptBoxW, promptBoxH);

    // Inner highlight strip
    ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
    ctx.fillRect(promptBoxX, promptBoxY, promptBoxW, 26);

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 15px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.fillText('🎯 TODAY\'S LESSON FOCUS & KEY OBJECTIVES', promptBoxX + 18, promptBoxY + 18);

    if (!isLectureActive) {
      ctx.fillStyle = '#10b981';
      ctx.font = 'bold 15px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('▶ Click START on toolbar to begin interactive lecture', promptBoxX + promptBoxW - 380, promptBoxY + 18);
    } else {
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 15px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('🎙️ LIVE LECTURE IN PROGRESS', promptBoxX + promptBoxW - 240, promptBoxY + 18);
    }

    const bannerTopicLabel = stripAllRawMarkdown(stagedTopicTitle || activeTopicTitle || userTopic || 'Interactive Science & Math Lesson');
    const displaySubtitle = 'Mastering core principles with physical intuition, step-by-step derivations, and practice problems.';
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.fillText(`📖 ${bannerTopicLabel.slice(0, 80)}`, promptBoxX + 18, promptBoxY + 46);
    ctx.font = 'italic 14px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.fillStyle = '#93c5fd';
    ctx.fillText(`🎯 ${displaySubtitle}`, promptBoxX + 18, promptBoxY + 66);

    // Parse and render the text content cleanly onto the canvas
    const rawText = cleanStreamingMarkdown(typedBoardContent || cleanBoardContentForDisplay(boardContent), isTypingLive);
    const lines = rawText.split('\n');

    const startX = 60;
    const startY = promptBoxY + promptBoxH + 16;
    const maxY = 825; // Adjusted so text stays cleanly above bottom interactive toolbar deck
    const availableH = maxY - startY;

    // Check if figure is present/under discussion
    const hasFigureOnBoard = Boolean(boardContent.includes('<svg') || boardContent.includes('[Draw:') || boardContent.toLowerCase().includes('figure'));
    const maxLineWidth = hasFigureOnBoard ? 1260 : 1920;

    if (hasFigureOnBoard) {
      // Draw 3D Smartboard Persistent Figure Card on right half of board
      ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 3;
      ctx.fillRect(1360, 140, 620, 480);
      ctx.strokeRect(1360, 140, 620, 480);

      // Figure Card Header
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(1360, 140, 620, 50);
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 22px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('📊 VISUAL FIGURE DIAGRAM • ACTIVE', 1380, 173);

      // Figure Drawing Graphics Canvas in 3D
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      // Coordinate System
      ctx.beginPath();
      ctx.moveTo(1420, 460);
      ctx.lineTo(1920, 460); // X-axis
      ctx.moveTo(1420, 460);
      ctx.lineTo(1420, 220); // Y-axis
      ctx.stroke();

      // Axis Labels
      ctx.fillStyle = '#94a3b8';
      ctx.font = '18px monospace';
      ctx.fillText('X (Magnitude)', 1830, 490);
      ctx.fillText('Y (Vector Force)', 1370, 215);

      // Primary Vector Curve / Force Arrow
      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(1420, 460);
      ctx.quadraticCurveTo(1620, 240, 1880, 290);
      ctx.stroke();

      // Vector Arrow Head
      ctx.fillStyle = '#34d399';
      ctx.beginPath();
      ctx.arc(1880, 290, 8, 0, Math.PI * 2);
      ctx.fill();

      // Secondary Accent Line
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(1420, 460);
      ctx.lineTo(1880, 460);
      ctx.lineTo(1880, 290);
      ctx.stroke();
      ctx.setLineDash([]);

      // Status indicator tag
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(1385, 595, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#e2e8f0';
      ctx.font = 'bold 18px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillText('Figure Under Active Discussion by Professor', 1400, 600);
    }

    // Measure and layout structured lecture blocks
    interface CanvasBoardBlock {
      type: 'h1' | 'h2' | 'h3' | 'h4' | 'math' | 'bullet' | 'code' | 'hr' | 'quote' | 'para';
      text?: string;
      lines?: string[];
      height: number;
    }

    const blocks: CanvasBoardBlock[] = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) {
        blocks.push({ type: 'para', height: 16 });
        continue;
      }

      // Ignore transient typing tokens that have no substantive content yet
      if (/^(?:#{1,6}\s*(?:\([a-zA-Z0-9\u0900-\u097F]*\)?\s*)?|\*{1,3}|_{1,3}|\${1,2}|\\\(|\\\[|\\\)|\\])$/.test(line)) {
        continue;
      }

      // Delimiters & Dividers
      if (line === '---' || line === '***' || line === '___' || /^[=\-_*]{3,}$/.test(line)) {
        blocks.push({ type: 'hr', height: 26 });
        continue;
      }

      // Code blocks
      if (line.startsWith('```')) {
        const lang = line.replace(/^```/, '').trim().toLowerCase();
        if (lang === 'svg' || lang === 'xml') {
          while (i + 1 < lines.length && !lines[i + 1].trim().startsWith('```')) i++;
          if (i + 1 < lines.length) i++;
          continue;
        }
        if (lang === 'markdown' || lang === 'md' || lang === 'text' || lang === 'txt' || lang === 'latex') {
          continue;
        }
        const codeLines: string[] = [];
        while (i + 1 < lines.length && !lines[i + 1].trim().startsWith('```')) {
          i++;
          codeLines.push(lines[i]);
        }
        if (i + 1 < lines.length) i++;
        if (codeLines.length > 0) {
          blocks.push({
            type: 'code',
            text: lang ? `💻 CODE (${lang.toUpperCase()})` : '💻 CODE SNIPPET',
            lines: codeLines.map(c => stripAllRawMarkdown(c)),
            height: Math.min(220, codeLines.length * 28 + 36)
          });
        }
        continue;
      }

      // Skip raw SVG blocks and XML tags
      if (line.includes('<svg') || line.includes('</svg>') || /^<\/?(?:svg|defs|linearGradient|radialGradient|stop|pattern|marker|filter|fe[A-Za-z]+|rect|circle|ellipse|line|polyline|polygon|path|text|tspan|g|clipPath|mask|use|symbol|desc|title)[^>]*>$/i.test(line)) {
        if (line.includes('<svg') && !line.includes('</svg>')) {
          while (i + 1 < lines.length && !lines[i + 1].includes('</svg>')) i++;
          if (i + 1 < lines.length) i++;
        }
        continue;
      }

      // Markdown Tables
      if (/^\|\s*[-:|\s]+\|\s*$/.test(line)) continue;
      if (line.startsWith('|') && line.endsWith('|')) {
        const cells = line.split('|').slice(1, -1).map(c => stripAllRawMarkdown(c.trim())).filter(Boolean);
        if (cells.length > 0) {
          const rowText = cells.join('   •   ');
          ctx.font = 'bold 26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
          const words = rowText.split(' ');
          const wrapped: string[] = [];
          let curL = '';
          for (const w of words) {
            const testL = curL ? `${curL} ${w}` : w;
            if (ctx.measureText(testL).width > maxLineWidth - 40 && curL) {
              wrapped.push(curL);
              curL = w;
            } else {
              curL = testL;
            }
          }
          if (curL) wrapped.push(curL);
          blocks.push({ type: 'bullet', lines: wrapped, height: wrapped.length * 36 + 6 });
          continue;
        }
      }

      // Multiline Math Blocks: $$ ... $$ or \[ ... \]
      if (line === '$$' || line === '\\[') {
        const mathLines: string[] = [];
        while (i + 1 < lines.length && lines[i + 1].trim() !== '$$' && lines[i + 1].trim() !== '\\]') {
          i++;
          const mLine = lines[i].trim();
          if (mLine) mathLines.push(mLine);
        }
        if (i + 1 < lines.length && (lines[i + 1].trim() === '$$' || lines[i + 1].trim() === '\\]')) i++;
        for (const mLine of mathLines) {
          const formatted = formatLaTeXToUnicode(stripAllRawMarkdown(mLine));
          if (formatted) {
            blocks.push({ type: 'math', text: formatted, height: 46 });
          }
        }
        continue;
      }

      // Blockquotes
      if (line.startsWith('> ')) {
        if (line.includes('Selected Prompt') || line.includes('💬') || line.includes('Tutor Rigor')) continue;
        const cleanQuote = stripAllRawMarkdown(line.replace(/^>\s*/, ''));
        if (cleanQuote) {
          ctx.font = 'italic 26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
          const words = cleanQuote.split(' ');
          const wrappedLines: string[] = [];
          let curL = '';
          for (const w of words) {
            const testL = curL ? `${curL} ${w}` : w;
            if (ctx.measureText(testL).width > maxLineWidth - 40 && curL) {
              wrappedLines.push(curL);
              curL = w;
            } else {
              curL = testL;
            }
          }
          if (curL) wrappedLines.push(curL);
          blocks.push({ type: 'quote', lines: wrappedLines, height: wrappedLines.length * 36 + 8 });
        }
        continue;
      }

      // Headings
      const headerMatch = line.trim().match(/^(#{1,6})\s*(.*)$/);
      if (headerMatch) {
        const level = headerMatch[1].length;
        const text = stripAllRawMarkdown(headerMatch[2]);
        if (text) {
          if (level === 1) blocks.push({ type: 'h1', text, height: 54 });
          else if (level === 2) blocks.push({ type: 'h2', text, height: 48 });
          else if (level === 3) blocks.push({ type: 'h3', text, height: 42 });
          else blocks.push({ type: 'h4', text, height: 38 });
        }
        continue;
      }

      // Bullets and Numbered items
      const bulletMatch = line.trim().match(/^([-*+]|\d+\.|\d+\)|\([a-zA-Z0-9\u0900-\u097F]+\))\s+(.*)$/);
      if (bulletMatch) {
        const prefix = bulletMatch[1];
        const content = stripAllRawMarkdown(bulletMatch[2]);
        if (content) {
          const bulletPrefix = /^\d+/.test(prefix) ? `${prefix} ` : '• ';
          const fullLine = `${bulletPrefix}${content}`;
          ctx.font = '26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
          const words = fullLine.split(' ');
          const wrappedLines: string[] = [];
          let curL = '';
          for (const w of words) {
            const testL = curL ? `${curL} ${w}` : w;
            if (ctx.measureText(testL).width > maxLineWidth - 40 && curL) {
              wrappedLines.push(curL);
              curL = w;
            } else {
              curL = testL;
            }
          }
          if (curL) wrappedLines.push(curL);
          blocks.push({ type: 'bullet', lines: wrappedLines, height: wrappedLines.length * 36 + 6 });
        }
        continue;
      }

      // Regular paragraph or math formula
      const isFormula = (line.startsWith('$$') || line.startsWith('\\[')) ||
        (/=/.test(line) && !/\b(the|is|are|was|were|in|of|and|with|from|to|because|let|suppose)\b/i.test(line));

      const cleanLine = isFormula ? formatLaTeXToUnicode(stripAllRawMarkdown(line.trim())) : stripAllRawMarkdown(line.trim());
      if (!cleanLine) continue;

      if (isFormula) {
        blocks.push({ type: 'math', text: cleanLine, height: 46 });
      } else {
        ctx.font = '26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        const words = cleanLine.split(' ');
        const wrappedLines: string[] = [];
        let curL = '';
        for (const w of words) {
          const testL = curL ? `${curL} ${w}` : w;
          if (ctx.measureText(testL).width > maxLineWidth && curL) {
            wrappedLines.push(curL);
            curL = w;
          } else {
            curL = testL;
          }
        }
        if (curL) wrappedLines.push(curL);
        blocks.push({ type: 'para', lines: wrappedLines, height: wrappedLines.length * 36 + 6 });
      }
    }

    // Dynamic Synchronized Scrolling Calculation for Blackboard
    const totalContentHeight = blocks.reduce((sum, b) => sum + b.height, 0);
    const progressFraction = totalSyncSteps > 0 ? (currentSyncStep / totalSyncSteps) : (isTypingLive ? 0.75 : 0);
    const maxScroll = Math.max(0, totalContentHeight - availableH + 30);
    const scrollOffset = isLectureActive ? Math.min(maxScroll, maxScroll * progressFraction) : 0;

    ctx.save();
    ctx.beginPath();
    ctx.rect(startX - 10, startY - 8, maxLineWidth + 20, availableH + 12);
    ctx.clip();

    let curY = startY - scrollOffset;

    for (const b of blocks) {
      if (b.type === 'hr') {
        ctx.fillStyle = 'rgba(56, 189, 248, 0.35)';
        ctx.fillRect(startX, curY + 10, maxLineWidth, 2);
        curY += b.height;
        continue;
      }

      if (b.type === 'h1' && b.text) {
        ctx.fillStyle = '#fbbf24';
        ctx.font = 'bold 42px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.fillText(b.text, startX, curY + 36);
        curY += b.height;
        continue;
      }

      if (b.type === 'h2' && b.text) {
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 36px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.fillText(b.text, startX, curY + 32);
        curY += b.height;
        continue;
      }

      if (b.type === 'h3' && b.text) {
        ctx.fillStyle = '#a5f3fc';
        ctx.font = 'bold 30px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.fillText(b.text, startX, curY + 28);
        curY += b.height;
        continue;
      }

      if (b.type === 'h4' && b.text) {
        ctx.fillStyle = '#86efac';
        ctx.font = 'bold 26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.fillText(b.text, startX, curY + 24);
        curY += b.height;
        continue;
      }

      if (b.type === 'math' && b.text) {
        ctx.fillStyle = 'rgba(30, 41, 59, 0.7)';
        ctx.beginPath();
        const formulaW = Math.min(maxLineWidth - 20, ctx.measureText(b.text).width + 36);
        ctx.roundRect(startX, curY + 4, formulaW, 36, 6);
        ctx.fill();
        ctx.strokeStyle = 'rgba(52, 211, 153, 0.4)';
        ctx.stroke();

        ctx.fillStyle = '#34d399';
        ctx.font = 'bold 28px "Cambria Math", "Courier New", monospace';
        ctx.fillText(b.text, startX + 16, curY + 30);
        curY += b.height;
        continue;
      }

      if (b.type === 'quote' && b.lines) {
        ctx.fillStyle = '#93c5fd';
        ctx.font = 'italic 26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        for (const qL of b.lines) {
          ctx.fillText(qL, startX + 16, curY + 24);
          curY += 34;
        }
        curY += 8;
        continue;
      }

      if (b.type === 'code' && b.lines) {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.8)';
        ctx.roundRect(startX, curY, maxLineWidth, b.height, 8);
        ctx.fill();
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
        ctx.stroke();

        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 16px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.fillText(b.text || '💻 CODE', startX + 14, curY + 20);

        ctx.fillStyle = '#cbd5e1';
        ctx.font = '20px "Fira Code", monospace';
        let codeY = curY + 44;
        for (const cL of b.lines) {
          ctx.fillText(cL, startX + 16, codeY);
          codeY += 26;
        }
        curY += b.height + 10;
        continue;
      }

      if (b.type === 'bullet' && b.lines) {
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(startX + 8, curY + 20, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#e2e8f0';
        ctx.font = '26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        for (let lIdx = 0; lIdx < b.lines.length; lIdx++) {
          ctx.fillText(b.lines[lIdx], startX + 22, curY + 24);
          curY += 34;
        }
        curY += 6;
        continue;
      }

      if (b.type === 'para' && b.lines) {
        ctx.fillStyle = '#cbd5e1';
        ctx.font = '26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        for (const pL of b.lines) {
          ctx.fillText(pL, startX, curY + 24);
          curY += 34;
        }
        curY += 6;
        continue;
      }

      curY += b.height;
    }

    // Live typing chalk cursor
    if (isTypingLive) {
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(startX + 6, Math.min(maxY - 25, curY), 14, 28);
    }

    ctx.restore();

    // =========================================================================
    // DEDICATED BOTTOM INTERACTIVE SMARTBOARD CONTROL DOCK (CLICKABLE IN 3D)
    // =========================================================================
    const dockY = 835;
    const dockH = 112;

    // Deck backdrop container
    ctx.fillStyle = 'rgba(15, 23, 42, 0.96)';
    ctx.fillRect(16, dockY, 2016, dockH);
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
    ctx.lineWidth = 2;
    ctx.strokeRect(16, dockY, 2016, dockH);

    // Deck header strip
    ctx.fillStyle = 'rgba(2, 6, 23, 0.8)';
    ctx.fillRect(16, dockY, 2016, 26);
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 10px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.fillText('⚡ 3D SMARTBOARD INTERACTIVE CONTROLS • CLICK DIRECTLY ON BOARD TO ACTIVATE', 36, dockY + 18);

    const btnY = dockY + 34;
    const btnH = 68;

    // 1. PRACTICE QUESTIONS BUTTON
    drawSmartboardCanvasButton(ctx, 35, btnY, 265, btnH, 14, ['#6b21a8', '#9333ea'], '#c084fc', '#ffffff', '🎯', 'PRACTICE Q&A', 'BOARD DRILLS');

    // 2. 3D SCIENCE LAB BENCH BUTTON
    drawSmartboardCanvasButton(ctx, 320, btnY, 265, btnH, 14, ['#047857', '#10b981'], '#34d399', '#ffffff', '🔬', '3D SCIENCE LAB', 'BENCH VIEW');

    // 3. DRAW AI FIGURE BUTTON
    drawSmartboardCanvasButton(ctx, 605, btnY, 265, btnH, 14, ['#be185d', '#f43f5e'], '#fb7185', '#ffffff', '🎨', 'DRAW FIGURE', 'AI VECTOR');

    // 4. 5-LAYER EXECUTIVE SUMMARY BUTTON
    drawSmartboardCanvasButton(ctx, 890, btnY, 285, btnH, 14, ['#b45309', '#f59e0b'], '#fbbf24', '#ffffff', '⚡', '5-L SUMMARY', 'MASTER REVIEW');

    // 5. SOCRATIC TUTOR BUTTON
    drawSmartboardCanvasButton(ctx, 1195, btnY, 285, btnH, 14, ['#0369a1', '#0284c7'], '#38bdf8', '#ffffff', '💡', 'SOCRATIC CHAT', 'Q&A TUTOR');

    // 6. CLEAR SMARTBOARD BUTTON
    drawSmartboardCanvasButton(ctx, 1500, btnY, 245, btnH, 14, ['#991b1b', '#dc2626'], '#f87171', '#ffffff', '🧹', 'CLEAR', 'RESET BOARD');

    // 7. HELP & SHORTCUTS GUIDE BUTTON
    drawSmartboardCanvasButton(ctx, 1765, btnY, 250, btnH, 14, ['#334155', '#475569'], '#94a3b8', '#ffffff', '❓', 'HELP GUIDE', 'SHORTCUTS');

    // =========================================================================
    // FOOTER STATUS BAR
    // =========================================================================
    ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
    ctx.fillRect(16, 955, 2016, 52);

    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 15px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.fillText(`${selectedTeacherStyle.avatarIcon} ${selectedTeacherStyle.name} • Virtual 3D Learning & STEM Interactive Laboratory`, 40, 988);

    // Clickable system action badges in footer
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 12px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText('🎵 ACOUSTICS  •  💡 LIGHTING  •  🛡️ DRM VAULT  •  ⚡ WebGL 1080p Synced', 2000, 988);
    ctx.textAlign = 'left';

    // Update Three.js Texture
    if (!boardCanvasTextureRef.current) {
      const tex = new THREE.CanvasTexture(canvas);
      tex.generateMipmaps = true;
      tex.minFilter = THREE.LinearMipmapLinearFilter;
      tex.magFilter = THREE.LinearFilter;
      boardCanvasTextureRef.current = tex;
      boardScreenMatRef.current.map = tex;
      boardScreenMatRef.current.emissiveMap = tex;
      boardScreenMatRef.current.emissive = new THREE.Color(0xffffff);
      boardScreenMatRef.current.emissiveIntensity = 0.95;
      boardScreenMatRef.current.needsUpdate = true;
    } else {
      boardCanvasTextureRef.current.needsUpdate = true;
    }
  }, [
    boardContent,
    typedBoardContent,
    selectedPromptText,
    activeTopicTitle,
    stagedTopicTitle,
    userTopic,
    userSubject,
    selectedBoard,
    isLoadingAi,
    isInitializingLecture,
    activePhaseTitle,
    currentSyncStep,
    totalSyncSteps,
    isTypingLive,
    isLectureActive,
    isLecturePaused,
    audioEnabled,
    selectedTeacherStyle
  ]);

  useEffect(() => {
    update3dSmartboardTexture();
  }, [update3dSmartboardTexture]);

  // Acoustic Profiles State & LocalStorage Persistence
  const [showAcousticModal, setShowAcousticModal] = useState<boolean>(false);
  const [acousticProfiles, setAcousticProfiles] = useState<AcousticProfile[]>(() => {
    try {
      const saved = localStorage.getItem('3d_classroom_acoustic_profiles');
      if (saved) {
        const parsed = JSON.parse(saved);
        return [...DEFAULT_ACOUSTIC_PROFILES, ...parsed.filter((p: AcousticProfile) => !p.isBuiltIn)];
      }
    } catch (e) {
      console.error("Failed to load acoustic profiles from localStorage", e);
    }
    return DEFAULT_ACOUSTIC_PROFILES;
  });

  const [activeAcousticProfileId, setActiveAcousticProfileId] = useState<string>(() => {
    return localStorage.getItem('3d_classroom_active_acoustic_id') || 'large_hall';
  });

  const activeAcousticProfile = useMemo(() => {
    return acousticProfiles.find(p => p.id === activeAcousticProfileId) || acousticProfiles[0];
  }, [acousticProfiles, activeAcousticProfileId]);

  // New Custom Acoustic Profile Form State
  const [newProfileName, setNewProfileName] = useState<string>('');
  const [newProfileDesc, setNewProfileDesc] = useState<string>('');
  const [newReverbDecay, setNewReverbDecay] = useState<number>(1.5);
  const [newRoomEcho, setNewRoomEcho] = useState<number>(0.4);
  const [newRoomWarmth, setNewRoomWarmth] = useState<number>(3000);
  const [newVoicePitch, setNewVoicePitch] = useState<number>(1.0);
  const [newVoiceRate, setNewVoiceRate] = useState<number>(1.0);
  const [newAmbientTone, setNewAmbientTone] = useState<'lecture_hall' | 'quiet_lab' | 'outdoor_field' | 'custom'>('custom');
  const [isCreatingProfile, setIsCreatingProfile] = useState<boolean>(false);

  const handleSaveCustomProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfileName.trim()) {
      showNotification?.("Please enter a profile name", 'error');
      return;
    }

    const created: AcousticProfile = {
      id: `custom_${Date.now()}`,
      name: newProfileName.trim(),
      description: newProfileDesc.trim() || 'Custom acoustic profile.',
      reverbDecay: newReverbDecay,
      roomEcho: newRoomEcho,
      roomWarmth: newRoomWarmth,
      ambientTone: newAmbientTone,
      voicePitch: newVoicePitch,
      voiceRate: newVoiceRate,
      isBuiltIn: false
    };

    const updated = [...acousticProfiles, created];
    setAcousticProfiles(updated);
    setActiveAcousticProfileId(created.id);

    try {
      const customOnly = updated.filter(p => !p.isBuiltIn);
      localStorage.setItem('3d_classroom_acoustic_profiles', JSON.stringify(customOnly));
      localStorage.setItem('3d_classroom_active_acoustic_id', created.id);
    } catch (err) {
      console.error("Error saving acoustic profile", err);
    }

    setNewProfileName('');
    setNewProfileDesc('');
    setIsCreatingProfile(false);
    showNotification?.(`Saved custom profile: "${created.name}"`, 'success');
    playSoundEffect('chime');
  };

  const handleDeleteCustomProfile = (id: string) => {
    if (id === activeAcousticProfileId) {
      setActiveAcousticProfileId('large_hall');
      localStorage.setItem('3d_classroom_active_acoustic_id', 'large_hall');
    }
    const updated = acousticProfiles.filter(p => p.id !== id);
    setAcousticProfiles(updated);
    try {
      const customOnly = updated.filter(p => !p.isBuiltIn);
      localStorage.setItem('3d_classroom_acoustic_profiles', JSON.stringify(customOnly));
    } catch (err) {
      console.error(err);
    }
    showNotification?.("Custom acoustic profile removed", 'info');
  };

  const handleSelectAcousticProfile = (id: string) => {
    setActiveAcousticProfileId(id);
    localStorage.setItem('3d_classroom_active_acoustic_id', id);
    const sel = acousticProfiles.find(p => p.id === id);
    if (sel) {
      showNotification?.(`Acoustics set to: ${sel.name}`, 'success');
      playSoundEffect('click');
    }
  };

  const testAcousticSound = (profile?: AcousticProfile) => {
    const prof = profile || activeAcousticProfile;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.18);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + prof.reverbDecay * 0.4);

      osc.connect(gain);

      if (prof.roomEcho > 0.05) {
        const delay = ctx.createDelay();
        delay.delayTime.setValueAtTime(prof.reverbDecay * 0.08, now);
        const feedback = ctx.createGain();
        feedback.gain.setValueAtTime(prof.roomEcho * 0.4, now);

        gain.connect(delay);
        delay.connect(feedback);
        feedback.connect(delay);
        delay.connect(ctx.destination);
      } else {
        gain.connect(ctx.destination);
      }

      osc.start(now);
      osc.stop(now + prof.reverbDecay * 0.4);
    } catch (e) {
      console.warn("Test acoustic sound error", e);
    }
  };

  const toggleCameraFeed = async () => {
    if (cameraFeedEnabled) {
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach(track => track.stop());
        cameraStreamRef.current = null;
      }
      setCameraFeedEnabled(false);
      showNotification?.("Camera feed overlay disabled", 'info');
    } else {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          showNotification?.("Camera access is not supported in this browser.", 'error');
          return;
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
          audio: false
        });

        cameraStreamRef.current = stream;
        setCameraFeedEnabled(true);
        showNotification?.("Camera feed enabled & overlayed on classroom board!", 'success');
      } catch (err: any) {
        console.error("Camera feed access error:", err);
        showNotification?.("Could not access camera feed. Please check permissions.", 'error');
      }
    }
  };

  useEffect(() => {
    return () => {
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = (e.target?.result as string) || '';
      setSelectedFile({
        name: file.name,
        type: file.type,
        previewUrl: result
      });
      showNotification?.(`Attached file: ${file.name}`, 'info');
    };
    reader.readAsDataURL(file);
  };

  // Screen Recording Handlers (1080p50 YouTube Upload Optimised Engine - Smartboard Only)
  // Connect Engine Callbacks
  useEffect(() => {
    smartboardRecorder.setCallbacks(
      (state, duration) => {
        setScreenRecordingState(state);
        setScreenRecordingDuration(duration);
      },
      (newChapter) => {
        setRecordedChapters(prev => {
          if (prev.some(c => c.title === newChapter.title)) return prev;
          return [...prev, newChapter];
        });
      }
    );
  }, []);

  // Content-Aware Synchronizer for 1080p50 Smartboard Recording Engine
  useEffect(() => {
    if (screenRecordingState === 'recording' || screenRecordingState === 'paused') {
      smartboardRecorder.updateContent({
        topicTitle: activeTopicTitle || userTopic || 'Interactive Lecture',
        phaseTitle: activePhaseTitle,
        boardText: typedBoardContent || boardContent,
        svgDiagram: activeSvgFigure,
        subject: userSubject,
        examBoard: selectedBoard?.acronym,
        examTip: EXAM_TIPS_DATABASE[currentExamTipIdx],
        progressPercent: totalSyncSteps > 0 ? Math.round((currentSyncStep / totalSyncSteps) * 100) : 0,
        isTyping: isTypingLive,
        threeCanvas: rendererRef.current?.domElement || null,
        recordingMode: 'smartboard_only'
      });
    }
  }, [
    typedBoardContent,
    boardContent,
    activeTopicTitle,
    activePhaseTitle,
    activeSvgFigure,
    userSubject,
    selectedBoard,
    currentExamTipIdx,
    totalSyncSteps,
    currentSyncStep,
    isTypingLive,
    screenRecordingState
  ]);

  const startScreenRecording = async () => {
    try {
      // Focus camera view on the presentation smartboard
      setCameraView('board_focus');

      const initialChapters: RecordedChapter[] = [
        {
          time: 0,
          formattedTime: '00:00',
          title: activePhaseTitle || activeTopicTitle || 'Lecture Introduction',
          category: 'Intro'
        }
      ];
      recordedChaptersRef.current = initialChapters;
      setRecordedChapters(initialChapters);

      const success = await smartboardRecorder.startRecording({
        topicTitle: activeTopicTitle || userTopic || 'Interactive Lecture',
        phaseTitle: activePhaseTitle || 'Lecture Concept',
        boardText: typedBoardContent || boardContent,
        svgDiagram: activeSvgFigure,
        subject: userSubject,
        examBoard: selectedBoard?.acronym,
        examTip: EXAM_TIPS_DATABASE[currentExamTipIdx],
        progressPercent: totalSyncSteps > 0 ? Math.round((currentSyncStep / totalSyncSteps) * 100) : 0,
        audioDestination: getAudioDestinationNode(),
        includeVoiceAudio: true,
        threeCanvas: rendererRef.current?.domElement || null,
        recordingMode: 'smartboard_only',
        sessionTimerStyle,
        sessionTimerEnabled
      });

      if (success) {
        setScreenRecordingState('recording');
        setScreenRecordingDuration(0);
        showNotification?.("🔴 Full HD 1080p50 Smartboard Recording Active! (Presentation Smartboard & Audio)", 'info');
        try { playSoundEffect('laser'); } catch {}
      } else {
        showNotification?.("Could not initialize 1080p presentation smartboard recorder.", 'error');
      }
    } catch (err: any) {
      console.error("Smartboard recording error:", err);
      showNotification?.("Could not start smartboard recording.", 'error');
    }
  };

  const pauseScreenRecording = () => {
    smartboardRecorder.pauseRecording();
    setScreenRecordingState('paused');
    showNotification?.("Smartboard recording paused (Amber indicator)", 'info');
  };

  const resumeScreenRecording = () => {
    smartboardRecorder.resumeRecording();
    setScreenRecordingState('recording');
    showNotification?.("Smartboard recording resumed (Red pulse indicator)", 'info');
  };

  const stopScreenRecording = async () => {
    try {
      const result = await smartboardRecorder.stopRecording();
      if (result) {
        setRecordedVideoUrl(result.videoUrl);
        setRecordedChapters(result.chapters);
        setShowRecordingPlaybackModal(true);
        setScreenRecordingState('idle');
        showNotification?.("🎬 Smartboard recording saved in 1080p50! YouTube Studio export ready.", 'success');
        try { playSoundEffect('chime'); } catch {}
      }
    } catch (err) {
      console.error("Stop smartboard recording error:", err);
      setScreenRecordingState('idle');
    }
  };

  const formatRecordingTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Audio Context for sound effects & Native Audio Engine
  const audioCtxRef = useRef<AudioContext | null>(null);
  const audioDestinationRef = useRef<MediaStreamAudioDestinationNode | null>(null);
  const currentAudioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const currentHtmlAudioRef = useRef<HTMLAudioElement | null>(null);

  const getAudioContext = () => {
    if (!audioCtxRef.current) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtxRef.current = new AudioContextClass();
      }
    }
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
    return audioCtxRef.current;
  };

  const getAudioDestinationNode = (): MediaStreamAudioDestinationNode | null => {
    const ctx = getAudioContext();
    if (ctx && !audioDestinationRef.current) {
      try {
        audioDestinationRef.current = ctx.createMediaStreamDestination();
      } catch (e) {
        console.warn("Could not create MediaStreamDestination:", e);
      }
    }
    return audioDestinationRef.current;
  };

  // Synthesized Sound Effects Engine (Native Web Audio API)
  const playSoundEffect = (type: 'chalk' | 'burner' | 'click' | 'chime' | 'laser' | 'cradle' | 'page_flip') => {
    try {
      const ctx = getAudioContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const dest = getAudioDestinationNode();
      if (dest) {
        try { gain.connect(dest); } catch {}
      }

      const now = ctx.currentTime;

      if (type === 'chalk') {
        // High-pitched chalk rasp sound effect
        const bufferSize = ctx.sampleRate * 0.12;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
        }
        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = buffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.setValueAtTime(2200, now);
        whiteNoise.connect(filter);
        filter.connect(gain);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        whiteNoise.start(now);
        whiteNoise.stop(now + 0.12);
      } else if (type === 'page_flip') {
        const bufferSize = ctx.sampleRate * 0.15;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = (Math.random() * 2 - 1) * Math.sin((i / bufferSize) * Math.PI);
        }
        const noise = ctx.createBufferSource();
        noise.buffer = buffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1200, now);
        noise.connect(filter);
        filter.connect(gain);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.15);
        noise.start(now);
        noise.stop(now + 0.15);
      } else if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'chime') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.15); // E5
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
      } else if (type === 'laser') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(1200, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.12);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.12);
        osc.start(now);
        osc.stop(now + 0.12);
      } else if (type === 'cradle') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1400, now);
        osc.frequency.exponentialRampToValueAtTime(800, now + 0.03);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.03);
        osc.start(now);
        osc.stop(now + 0.03);
      } else if (type === 'burner') {
        const bufferSize = ctx.sampleRate * 0.1;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = Math.random() * 2 - 1;
        }
        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = buffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1000, now);
        whiteNoise.connect(filter);
        filter.connect(gain);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.linearRampToValueAtTime(0.001, now + 0.1);
        whiteNoise.start(now);
        whiteNoise.stop(now + 0.1);
      }
    } catch (e) {
      console.warn("Audio effect error", e);
    }
  };

  const handleOpenQuestionSolutionEditor = useCallback((initialText?: string) => {
    const textToEdit = initialText || typedBoardContent || boardContent || '';
    setEditableQuestionSolutionText(textToEdit);
    setShowQuestionSolutionEditorModal(true);
    playSoundEffect('click');
    showNotification?.("Double-click edit mode activated: Modify question & solution text ✏️", "info");
  }, [typedBoardContent, boardContent, showNotification]);

  const handleSaveEditedQuestionSolution = useCallback((newText: string) => {
    setBoardContent(newText);
    setTypedBoardContent(newText);
    preparedBoardRef.current = newText;
    setShowQuestionSolutionEditorModal(false);
    playSoundEffect('chalk');
    showNotification?.("Question & Solution text updated on 3D Smartboard! 🎯", "success");
  }, [showNotification]);

  const speechSynthesisIntervalRef = useRef<any>(null);
  const activeSegmentTimeoutRef = useRef<any>(null);
  const isBetweenSegmentsRef = useRef<boolean>(false);
  const activeDeliverNextRef = useRef<(() => void) | null>(null);
  const currentSegmentCharPointerRef = useRef<number>(0);
  const currentSegmentTotalCharsRef = useRef<number>(0);
  const currentSegmentMarkdownRef = useRef<string>('');
  const currentPrefixMarkdownRef = useRef<string>('');

  const stopSpeech = () => {
    speechSessionIdRef.current = 0;
    if (activeSegmentTimeoutRef.current) {
      clearTimeout(activeSegmentTimeoutRef.current);
      activeSegmentTimeoutRef.current = null;
    }
    isBetweenSegmentsRef.current = false;
    activeDeliverNextRef.current = null;
    currentSegmentCharPointerRef.current = 0;
    currentSegmentTotalCharsRef.current = 0;
    currentSegmentMarkdownRef.current = '';
    currentPrefixMarkdownRef.current = '';

    if (speechSynthesisIntervalRef.current) {
      clearInterval(speechSynthesisIntervalRef.current);
      speechSynthesisIntervalRef.current = null;
    }
    if (typewriterTimerRef.current) {
      clearInterval(typewriterTimerRef.current);
      typewriterTimerRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (currentAudioSourceRef.current) {
      try { currentAudioSourceRef.current.stop(); } catch (e) {}
      currentAudioSourceRef.current = null;
    }
    if (currentHtmlAudioRef.current) {
      try { currentHtmlAudioRef.current.pause(); } catch (e) {}
      currentHtmlAudioRef.current = null;
    }
    setIsSpeaking(false);
    setIsTypingLive(false);
    setIsLectureActive(false);
    setIsLecturePaused(false);

    // If smartboard recorder is running when lecture is stopped, save the recording
    if (smartboardRecorder.getState() !== 'idle') {
      smartboardRecorder.stopRecording().then(result => {
        if (result && result.duration >= 2) {
          setRecordedVideoUrl(result.videoUrl);
          setRecordedChapters(result.chapters);
          setShowRecordingPlaybackModal(true);
          setScreenRecordingState('idle');
          showNotification?.("🎬 Smartboard Lecture recorded in Full HD 1080p50! YouTube Studio export ready.", "success");
        }
      });
    }
  };

  // Smart continuous auto-scroll reference
  const scrollAnimationRef = useRef<number | null>(null);

  // Helper to scroll the smartboard container smoothly to bottom as content types out
  // Synchronized with QuadSpeedState scrollingSpeed for harmonic velocity
  const scrollToSmartboardBottom = useCallback((instant = false) => {
    const container = boardScrollContainerRef.current;
    if (!container) return;

    const targetTop = container.scrollHeight - container.clientHeight;
    if (targetTop <= 0) return;

    if (instant) {
      if (scrollAnimationRef.current) {
        cancelAnimationFrame(scrollAnimationRef.current);
        scrollAnimationRef.current = null;
      }
      container.scrollTop = targetTop;
      return;
    }

    if (scrollAnimationRef.current) {
      cancelAnimationFrame(scrollAnimationRef.current);
      scrollAnimationRef.current = null;
    }

    const scrollSpeed = activeQuadSpeeds.scrollingSpeed || 1.0;
    // Dynamic lerp factor scaled by scrolling speed (0.06 - 0.40)
    const lerpFactor = Math.min(0.40, Math.max(0.06, 0.12 * scrollSpeed));

    const step = () => {
      if (!boardScrollContainerRef.current) return;
      const current = boardScrollContainerRef.current.scrollTop;
      const dist = targetTop - current;

      if (Math.abs(dist) < 1.5) {
        boardScrollContainerRef.current.scrollTop = targetTop;
        scrollAnimationRef.current = null;
        return;
      }

      boardScrollContainerRef.current.scrollTop = current + dist * lerpFactor;
      scrollAnimationRef.current = requestAnimationFrame(step);
    };

    scrollAnimationRef.current = requestAnimationFrame(step);
  }, [activeQuadSpeeds.scrollingSpeed]);

  // Start perfectly synchronized lecture delivery: typing speed matches pronunciation speed & auto-scrolling
  const startSynchronizedLecture = (fullBoardText: string) => {
    stopSpeech();

    const rawSegments = parseLectureIntoSegments(fullBoardText);
    if (rawSegments.length === 0) {
      setTypedBoardContent(cleanBoardContentForDisplay(fullBoardText));
      return;
    }

    // Ensure all lectures and recordings start with authentic "Namaste" greeting
    const segments: LectureSegment[] = [...rawSegments];
    const firstSpokenIdx = segments.findIndex(s => s.spokenText && s.spokenText.trim().length > 0);
    if (firstSpokenIdx !== -1) {
      if (!segments[firstSpokenIdx].spokenText.toLowerCase().includes('namaste')) {
        segments[firstSpokenIdx] = {
          ...segments[firstSpokenIdx],
          spokenText: `Namaste! ${segments[firstSpokenIdx].spokenText}`
        };
      }
    } else {
      segments.unshift({
        displayMarkdown: '',
        spokenText: `Namaste! Welcome to our Classroom Slate interactive lecture on ${activeTopicTitle || userTopic || 'our lesson'}.`,
        isDrawing: false,
        pauseMs: 800,
        phaseTitle: 'Welcome & Introduction',
        inferredAvatar: { zone: 'podium', gesture: 'turn_to_students', expression: 'warm_smile' }
      });
    }

    const currentSessionId = Date.now();
    speechSessionIdRef.current = currentSessionId;
    isPausedRef.current = false;
    setIsLectureActive(true);
    setIsLecturePaused(false);
    setTotalSyncSteps(segments.length);
    setCurrentSyncStep(1);
    setTypedBoardContent('');

    // 4. AUTOMATIC PRESENTATION SMARTBOARD RECORDING (1080p50 Full HD - Smartboard Only)
    smartboardRecorder.startRecording({
      topicTitle: activeTopicTitle || userTopic || 'Interactive Lecture',
      phaseTitle: activePhaseTitle || 'Introduction',
      boardText: cleanBoardContentForDisplay(fullBoardText),
      svgDiagram: activeSvgFigure,
      subject: userSubject,
      examBoard: selectedBoard?.acronym,
      examTip: EXAM_TIPS_DATABASE[currentExamTipIdx],
      progressPercent: 0,
      audioDestination: getAudioDestinationNode(),
      includeVoiceAudio: true,
      threeCanvas: rendererRef.current?.domElement || null,
      recordingMode: 'smartboard_only'
    }).then(started => {
      if (started) {
        setScreenRecordingState('recording');
        setScreenRecordingDuration(0);
      }
    });

    const langObj = resolveLanguageObject(selectedLectureLanguage || selectedLanguage || language);
    const targetLangCode = langObj ? langObj.code : 'en';
    const isHindi = targetLangCode === 'hi' || targetLangCode === 'hinglish' || langObj.name.toLowerCase() === 'hindi';

    const voices = availableVoices.length > 0 
      ? availableVoices 
      : ('speechSynthesis' in window ? window.speechSynthesis.getVoices() : []);

    const preferredVoice = isHindi
      ? (voices.find(v => v.lang.toLowerCase().startsWith('hi') || v.name.toLowerCase().includes('hindi')) ||
         voices.find(v => v.lang.toLowerCase().includes('in') && !v.lang.toLowerCase().startsWith('en')) ||
         voices.find(v => v.lang.toLowerCase().startsWith('en-in')) ||
         voices[0])
      : (voices.find(v => v.lang.toLowerCase().startsWith(targetLangCode.toLowerCase())) ||
         voices.find(v => v.lang.startsWith('en')) ||
         voices[0]);

    let accumulatedMarkdown = '';
    let currentSegmentIndex = 0;

    const deliverNextSegment = () => {
      if (speechSessionIdRef.current !== currentSessionId) return;
      if (isPausedRef.current) {
        isBetweenSegmentsRef.current = true;
        return;
      }
      isBetweenSegmentsRef.current = false;
      if (activeSegmentTimeoutRef.current) {
        clearTimeout(activeSegmentTimeoutRef.current);
        activeSegmentTimeoutRef.current = null;
      }

      if (currentSegmentIndex >= segments.length) {
        setIsSpeaking(false);
        setIsTypingLive(false);
        setIsLectureActive(false);
        playSoundEffect('chime');
        showNotification?.(`${selectedTeacherStyle.avatarIcon} ${selectedTeacherStyle.name} Lecture Completed!`, "success");

        // Automatically finalize Smartboard-Only 1080p50 recording
        smartboardRecorder.stopRecording().then(result => {
          if (result && result.duration >= 2) {
            setRecordedVideoUrl(result.videoUrl);
            setRecordedChapters(result.chapters);
            setShowRecordingPlaybackModal(true);
            setScreenRecordingState('idle');
            showNotification?.("🎬 Smartboard Lecture recorded in Full HD 1080p50! YouTube Studio export ready.", "success");
          }
        });
        return;
      }

      currentChunkIndexRef.current = currentSegmentIndex;
      setCurrentSyncStep(currentSegmentIndex + 1);
      const seg = segments[currentSegmentIndex];
      currentSegmentIndex++;

      if (seg.phaseTitle) {
        setActivePhaseTitle(seg.phaseTitle);
      }

      // 1. Figure Lifecycle Management (Ingest to Figure Dock by default, minimized)
      const hasFigureContent = seg.isDrawing || seg.displayMarkdown.includes('<svg') || seg.displayMarkdown.includes('[Draw:');
      if (hasFigureContent) {
        if (laserDotMeshRef.current) {
          laserDotMeshRef.current.visible = true;
          laserDotMeshRef.current.position.set(-2.8, 2.2, -4.85);
        }
        // Ingest into interactive Figure Thumbnail Dock history (Minimized to dock by default)
        const extracted = extractActiveFigureInfoFromMarkdown(seg.displayMarkdown);
        if (extracted) {
          setFigureDockHistory(prev => {
            if (prev.some(f => f.title === extracted.title || f.svg === extracted.svg)) return prev;
            return [...prev, {
              id: `fig-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              svg: extracted.svg,
              title: extracted.title,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }];
          });
        }
      } else {
        // Auto-close full Stage Mode when lecture transitions to text/equations/practice to prevent board obstruction
        if (isStageModeActive && (seg.displayMarkdown.startsWith('#') || seg.displayMarkdown.includes('---') || seg.displayMarkdown.includes('**Q') || seg.displayMarkdown.includes('Category'))) {
          setIsStageModeActive(false);
          if (activeCameraView === 'figure_focus') {
            setCameraView('front_row');
          }
        }
      }

      // Automatic Presentation Mode Switching & Figure Lifecycle Triggers
      const lowerSpoken = (seg.spokenText || '').toLowerCase();
      const lowerDisplay = (seg.displayMarkdown || '').toLowerCase();

      // Figure Close Triggers:
      // Auto-close when Professor says: "Let's move on", "Now, next topic", "Let's continue", "Moving forward"
      // UNLESS: "Keep this figure in mind", "We'll refer back to this", "Remember this figure"
      const hasAutoCloseTrigger = lowerSpoken.includes("let's move on") ||
        lowerSpoken.includes("lets move on") ||
        lowerSpoken.includes("next topic") ||
        lowerSpoken.includes("let's continue") ||
        lowerSpoken.includes("lets continue") ||
        lowerSpoken.includes("moving forward");

      const hasKeepOpenTrigger = lowerSpoken.includes("keep this figure") ||
        lowerSpoken.includes("refer back to this") ||
        lowerSpoken.includes("remember this figure");

      if (hasAutoCloseTrigger && !hasKeepOpenTrigger) {
        if (isStageModeActive || dockSelectedFigure) {
          setIsStageModeActive(false);
          setDockSelectedFigure(null);
          setTeachingPresentationMode('text_teaching');
          if (activeCameraView === 'figure_focus') {
            setCameraView('front_row');
          }
        }
      }

      // Automatic Mode Switching:
      // - Mentions "figure/diagram" -> Figure Mode
      // - Mentions "definition/formula" -> Text Mode
      // - References figure while explaining -> Hybrid Mode
      if (lowerSpoken.includes("as shown in the diagram") || lowerSpoken.includes("connecting this figure") || lowerSpoken.includes("referring to the diagram") || lowerSpoken.includes("connecting to the figure")) {
        setTeachingPresentationMode('hybrid');
      } else if (seg.isDrawing || lowerDisplay.includes("<svg") || lowerSpoken.includes("look at this diagram") || lowerSpoken.includes("look at this figure") || lowerSpoken.includes("in this schematic") || lowerSpoken.includes("observe this illustration")) {
        setTeachingPresentationMode('figure_teaching');
      } else if (lowerSpoken.includes("definition") || lowerSpoken.includes("formula") || lowerSpoken.includes("equation") || lowerSpoken.includes("derivation") || lowerSpoken.includes("calculate") || lowerSpoken.includes("practice question")) {
        setTeachingPresentationMode('text_teaching');
      }

      // 2. Mid-Chapter Continuous Teaching Energy Boost Checkpoint (PART 2)
      if (segments.length >= 6 && (currentSegmentIndex / segments.length) >= 0.48 && !midChapterBoostFired) {
        setMidChapterBoostFired(true);
        setShowMidChapterBoostCard(false);
        avatarEngine.triggerGesture('chair_swivel_right', 3.0, 'energetic', 'warm_smile');
      }

      // Synchronize Visual Avatar Animation Engine with segment trigger or inferred kinematics
      if (seg.avatarTrigger) {
        avatarEngine.setZone(seg.avatarTrigger.zone, true);
        avatarEngine.triggerGesture(seg.avatarTrigger.name, seg.avatarTrigger.duration, seg.avatarTrigger.intensity);
      } else if (seg.inferredAvatar) {
        avatarEngine.setZone(seg.inferredAvatar.zone, true);
        avatarEngine.triggerGesture(seg.inferredAvatar.gesture, undefined, 'natural', seg.inferredAvatar.expression);
      }

      // Case 1: Pure Pause block
      if (seg.pauseMs > 0 && !seg.spokenText && !seg.displayMarkdown) {
        setIsTypingLive(false);
        avatarEngine.triggerGesture('nod', undefined, 'subtle');
        isBetweenSegmentsRef.current = true;
        activeSegmentTimeoutRef.current = setTimeout(() => {
          activeSegmentTimeoutRef.current = null;
          if (speechSessionIdRef.current === currentSessionId && !isPausedRef.current) {
            isBetweenSegmentsRef.current = false;
            deliverNextSegment();
          }
        }, seg.pauseMs);
        return;
      }

      // Case 2: Visual Figure / SVG / Silent Drawing
      if (seg.isDrawing) {
        setIsSpeaking(false);
        if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
          window.speechSynthesis.cancel();
        }
        setIsTypingLive(true);
        avatarEngine.setZone('smartboard', true);
        const vizSpeed = activeQuadSpeeds.visualizingSpeed || 1.0;
        const gestureDuration = Math.max(1.2, 3.0 / vizSpeed);
        avatarEngine.triggerGesture('drawing_on_smartboard', gestureDuration, 'energetic', 'focused');
        playSoundEffect('chalk');
        accumulatedMarkdown = accumulatedMarkdown + (accumulatedMarkdown ? '\n\n' : '') + seg.displayMarkdown;
        setTypedBoardContent(accumulatedMarkdown);
        scrollToSmartboardBottom();

        const basePause = seg.pauseMs || 2800;
        const pauseDuration = Math.max(700, Math.round(basePause / vizSpeed));
        isBetweenSegmentsRef.current = true;
        activeSegmentTimeoutRef.current = setTimeout(() => {
          activeSegmentTimeoutRef.current = null;
          if (speechSessionIdRef.current === currentSessionId && !isPausedRef.current) {
            isBetweenSegmentsRef.current = false;
            setIsTypingLive(false);
            deliverNextSegment();
          }
        }, pauseDuration);
        return;
      }

      // Case 3: Spoken text with Natural Spoken Audio or SpeechSynthesis active
      if (audioEnabled && seg.spokenText.length > 0) {
        setIsSpeaking(true);
        setIsTypingLive(true);

        const segLength = seg.displayMarkdown.length;
        const prefix = accumulatedMarkdown;
        let charPointer = 0;

        currentSegmentCharPointerRef.current = 0;
        currentSegmentTotalCharsRef.current = segLength;
        currentSegmentMarkdownRef.current = seg.displayMarkdown;
        currentPrefixMarkdownRef.current = prefix;

        // Function to run synchronous typewriter effect over a given duration
        // Harmonized with typingSpeed and vocal pronunciation duration
        const runTypewriter = (durationMs: number) => {
          if (typewriterTimerRef.current) {
            clearInterval(typewriterTimerRef.current);
            typewriterTimerRef.current = null;
          }

          const speedMultiplier = activeQuadSpeeds.typingSpeed || 1.0;
          const nominalDuration = durationMs / speedMultiplier;
          const baseInterval = nominalDuration / Math.max(1, segLength);
          const charIntervalMs = Math.max(6, Math.min(50, Math.floor(baseInterval)));

          typewriterTimerRef.current = setInterval(() => {
            if (speechSessionIdRef.current !== currentSessionId) {
              if (typewriterTimerRef.current) clearInterval(typewriterTimerRef.current);
              return;
            }
            if (isPausedRef.current) return;

            const advanceStep = speedMultiplier > 1.8 ? 3 : (speedMultiplier > 1.25 ? 2 : 1);
            charPointer = StreamingBuffer.getNextSafeTypewriterStep(seg.displayMarkdown, charPointer, advanceStep);
            currentSegmentCharPointerRef.current = charPointer;

            if (charPointer % 4 === 0) {
              try { smartboardRecorder.playChalkRasp(30); } catch {}
            }

            if (charPointer <= segLength) {
              const partial = seg.displayMarkdown.substring(0, charPointer);
              const liveText = StreamingBuffer.sanitizeLiveStreamText(prefix + (prefix ? '\n\n' : '') + partial);
              setTypedBoardContent(liveText);
              scrollToSmartboardBottom();
            } else {
              if (typewriterTimerRef.current) {
                clearInterval(typewriterTimerRef.current);
                typewriterTimerRef.current = null;
              }
            }
          }, charIntervalMs);
        };

        const onSegmentComplete = () => {
          if (speechSessionIdRef.current !== currentSessionId) return;
          if (typewriterTimerRef.current) {
            clearInterval(typewriterTimerRef.current);
            typewriterTimerRef.current = null;
          }
          accumulatedMarkdown = prefix + (prefix ? '\n\n' : '') + seg.displayMarkdown;
          currentSegmentCharPointerRef.current = segLength;
          setTypedBoardContent(StreamingBuffer.sanitizeLiveStreamText(accumulatedMarkdown));
          scrollToSmartboardBottom();

          isBetweenSegmentsRef.current = true;
          activeSegmentTimeoutRef.current = setTimeout(() => {
            activeSegmentTimeoutRef.current = null;
            if (speechSessionIdRef.current === currentSessionId && !isPausedRef.current) {
              isBetweenSegmentsRef.current = false;
              deliverNextSegment();
            }
          }, 350);
        };

        // Attempt 1: High-fidelity natural spoken audio via Google TTS / Neural Voice
        const playWithNaturalNeuralVoice = async (): Promise<boolean> => {
          try {
            const ctx = getAudioContext();
            if (!ctx) return false;

            const ttsLang = isHindi ? 'hi' : (targetLangCode || 'en');
            const cleanSpoken = convertLaTeXToSpokenText(seg.spokenText);
            const base64Audio = await generateGoogleSpeech(cleanSpoken, ttsLang);
            if (!base64Audio || speechSessionIdRef.current !== currentSessionId) return false;

            const binaryString = atob(base64Audio);
            const len = binaryString.length;
            const bytes = new Uint8Array(len);
            for (let i = 0; i < len; i++) {
              bytes[i] = binaryString.charCodeAt(i);
            }

            const audioBuffer = await ctx.decodeAudioData(bytes.buffer.slice(0));
            if (!audioBuffer || speechSessionIdRef.current !== currentSessionId) return false;

            const source = ctx.createBufferSource();
            source.buffer = audioBuffer;
            const gainNode = ctx.createGain();
            gainNode.gain.setValueAtTime(1.0, ctx.currentTime);

            source.connect(gainNode);
            // Connect to speakers so front view row hears natural spoken language
            gainNode.connect(ctx.destination);

            // Connect to recording destination so recorded video receives the exact same natural spoken audio
            const dest = getAudioDestinationNode();
            if (dest) {
              try { gainNode.connect(dest); } catch {}
            }
            smartboardRecorder.playTeacherVoiceAudioBuffer(audioBuffer);

            const vocalRate = Math.max(0.5, Math.min(2.0, activeQuadSpeeds.pronouncingSpeed || 1.0));
            source.playbackRate.setValueAtTime(vocalRate, ctx.currentTime);

            currentAudioSourceRef.current = source;
            const audioDurationMs = Math.max(700, (audioBuffer.duration * 1000) / vocalRate);
            runTypewriter(audioDurationMs);

            source.onended = () => {
              onSegmentComplete();
            };

            source.start();
            return true;
          } catch (e) {
            console.warn("[ThreeDClassroom] Neural natural voice fallback to Web Speech:", e);
            return false;
          }
        };

        playWithNaturalNeuralVoice().then(success => {
          if (success || speechSessionIdRef.current !== currentSessionId) return;

          // Attempt 2: Fallback to Web Speech API
          if (!('speechSynthesis' in window)) {
            runTypewriter(Math.max(900, (seg.spokenText.length / 13) * 1000));
            setTimeout(onSegmentComplete, Math.max(1200, (seg.spokenText.length / 13) * 1000));
            return;
          }

          const utterance = new SpeechSynthesisUtterance(seg.spokenText);
          const baseRate = activeAcousticProfile.voiceRate || 0.95;
          const effectiveRate = Math.max(0.5, Math.min(2.0, baseRate * (activeQuadSpeeds.pronouncingSpeed || 1.0)));
          utterance.rate = effectiveRate;
          utterance.pitch = activeAcousticProfile.voicePitch || 1.0;
          utterance.volume = 1.0;
          utterance.lang = targetLangCode === 'hi' ? 'hi-IN' : targetLangCode;
          if (preferredVoice) utterance.voice = preferredVoice;

          const estimatedDurationMs = Math.max(700, (seg.spokenText.length / 13) * 1000 / effectiveRate);
          runTypewriter(estimatedDurationMs);

          utterance.onboundary = (e: any) => {
            if (speechSessionIdRef.current !== currentSessionId) return;
            if (e.name === 'word' && seg.spokenText.length > 0) {
              const progressRatio = Math.min(1, e.charIndex / seg.spokenText.length);
              const targetCharPointer = Math.floor(progressRatio * segLength);
              if (targetCharPointer > charPointer) {
                charPointer = targetCharPointer;
                currentSegmentCharPointerRef.current = charPointer;
                const partial = seg.displayMarkdown.substring(0, charPointer);
                const liveText = StreamingBuffer.sanitizeLiveStreamText(prefix + (prefix ? '\n\n' : '') + partial);
                setTypedBoardContent(liveText);
                scrollToSmartboardBottom();
              }
            }
          };

          utterance.onend = () => {
            onSegmentComplete();
          };

          utterance.onerror = (e: any) => {
            if (speechSessionIdRef.current !== currentSessionId) return;
            if (e.error === 'interrupted' || e.error === 'canceled') return;
            onSegmentComplete();
          };

          window.speechSynthesis.speak(utterance);
        });
      } else {
        // Case 4: Audio muted or speech synthesis unavailable - typewriter at natural reading pace
        setIsSpeaking(false);
        setIsTypingLive(true);

        const segLength = seg.displayMarkdown.length;
        const prefix = accumulatedMarkdown;
        let charPointer = 0;

        currentSegmentCharPointerRef.current = 0;
        currentSegmentTotalCharsRef.current = segLength;
        currentSegmentMarkdownRef.current = seg.displayMarkdown;
        currentPrefixMarkdownRef.current = prefix;

        if (typewriterTimerRef.current) {
          clearInterval(typewriterTimerRef.current);
          typewriterTimerRef.current = null;
        }

        typewriterTimerRef.current = setInterval(() => {
          if (speechSessionIdRef.current !== currentSessionId) {
            if (typewriterTimerRef.current) clearInterval(typewriterTimerRef.current);
            return;
          }
          if (isPausedRef.current) return;

          charPointer = StreamingBuffer.getNextSafeTypewriterStep(seg.displayMarkdown, charPointer, 2);
          currentSegmentCharPointerRef.current = charPointer;

          if (charPointer < segLength) {
            const partial = seg.displayMarkdown.substring(0, charPointer);
            const liveText = StreamingBuffer.sanitizeLiveStreamText(prefix + (prefix ? '\n\n' : '') + partial);
            setTypedBoardContent(liveText);
            scrollToSmartboardBottom();
          } else {
            if (typewriterTimerRef.current) {
              clearInterval(typewriterTimerRef.current);
              typewriterTimerRef.current = null;
            }
            accumulatedMarkdown = prefix + (prefix ? '\n\n' : '') + seg.displayMarkdown;
            currentSegmentCharPointerRef.current = segLength;
            setTypedBoardContent(StreamingBuffer.sanitizeLiveStreamText(accumulatedMarkdown));
            scrollToSmartboardBottom();

            isBetweenSegmentsRef.current = true;
            activeSegmentTimeoutRef.current = setTimeout(() => {
              activeSegmentTimeoutRef.current = null;
              if (speechSessionIdRef.current === currentSessionId && !isPausedRef.current) {
                isBetweenSegmentsRef.current = false;
                deliverNextSegment();
              }
            }, 300);
          }
        }, Math.max(6, Math.min(45, Math.round(22 / (activeQuadSpeeds.typingSpeed || 1.0)))));
      }
    };

    // Store active deliver function for instant resume
    activeDeliverNextRef.current = deliverNextSegment;

    // Chrome SpeechSynthesis keep-alive
    speechSynthesisIntervalRef.current = setInterval(() => {
      if ('speechSynthesis' in window && window.speechSynthesis.speaking && !isPausedRef.current) {
        window.speechSynthesis.resume();
      }
    }, 3500);

    deliverNextSegment();
  };

  // Pause both Audio Speech and Typewriter Writing in perfect sync
  const pauseSynchronizedLecture = () => {
    isPausedRef.current = true;
    setIsLecturePaused(true);

    if (activeSegmentTimeoutRef.current) {
      clearTimeout(activeSegmentTimeoutRef.current);
      activeSegmentTimeoutRef.current = null;
      isBetweenSegmentsRef.current = true;
    }

    if (typewriterTimerRef.current) {
      clearInterval(typewriterTimerRef.current);
      typewriterTimerRef.current = null;
    }

    if ('speechSynthesis' in window) {
      try {
        if (window.speechSynthesis.speaking) {
          window.speechSynthesis.pause();
        }
      } catch (err) {
        console.warn("Speech pause error:", err);
      }
    }

    if (currentHtmlAudioRef.current) {
      try { currentHtmlAudioRef.current.pause(); } catch (e) {}
    }

    pauseScreenRecording();
    avatarEngine.triggerGesture('nod', undefined, 'subtle');
    playSoundEffect('click');
    showNotification?.("Lecture paused (Click Resume or press Space to continue)", "info");
  };

  // Resume both Audio Speech and Typewriter Writing in perfect sync
  const resumeSynchronizedLecture = () => {
    isPausedRef.current = false;
    setIsLecturePaused(false);
    resumeScreenRecording();
    playSoundEffect('click');
    showNotification?.("Lecture resumed", "info");

    const currentSessionId = speechSessionIdRef.current;
    if (!currentSessionId) return;

    // Case 1: Was waiting between segments or drawing pause
    if (isBetweenSegmentsRef.current) {
      isBetweenSegmentsRef.current = false;
      if (activeDeliverNextRef.current) {
        activeDeliverNextRef.current();
      }
      return;
    }

    // Case 2: In middle of speaking / typing
    if (audioEnabled && 'speechSynthesis' in window) {
      try {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      } catch (err) {
        console.warn("Speech resume error:", err);
      }
    }

    // Chromium Self-Healing Watchdog:
    // Chromium sometimes drops paused utterances. If speech synthesis is not active,
    // or if audio was disabled, resume typewriter and advance.
    setTimeout(() => {
      if (isPausedRef.current || speechSessionIdRef.current !== currentSessionId) return;

      const isSpeechActive = 'speechSynthesis' in window && window.speechSynthesis.speaking && !window.speechSynthesis.paused;
      const curMarkdown = currentSegmentMarkdownRef.current;
      const totalChars = currentSegmentTotalCharsRef.current;
      const prefix = currentPrefixMarkdownRef.current;

      if (currentSegmentCharPointerRef.current < totalChars && !typewriterTimerRef.current) {
        setIsTypingLive(true);
        typewriterTimerRef.current = setInterval(() => {
          if (speechSessionIdRef.current !== currentSessionId || isPausedRef.current) {
            if (typewriterTimerRef.current) clearInterval(typewriterTimerRef.current);
            return;
          }
          currentSegmentCharPointerRef.current = StreamingBuffer.getNextSafeTypewriterStep(curMarkdown, currentSegmentCharPointerRef.current, 1);
          if (currentSegmentCharPointerRef.current <= totalChars) {
            const partial = curMarkdown.substring(0, currentSegmentCharPointerRef.current);
            const liveText = StreamingBuffer.sanitizeLiveStreamText(prefix + (prefix ? '\n\n' : '') + partial);
            setTypedBoardContent(liveText);
            scrollToSmartboardBottom();
          } else {
            if (typewriterTimerRef.current) {
              clearInterval(typewriterTimerRef.current);
              typewriterTimerRef.current = null;
            }
            if (!isSpeechActive) {
              isBetweenSegmentsRef.current = true;
              activeSegmentTimeoutRef.current = setTimeout(() => {
                activeSegmentTimeoutRef.current = null;
                if (speechSessionIdRef.current === currentSessionId && !isPausedRef.current) {
                  isBetweenSegmentsRef.current = false;
                  activeDeliverNextRef.current?.();
                }
              }, 350);
            }
          }
        }, 22);
      } else if (!isSpeechActive && currentSegmentCharPointerRef.current >= totalChars) {
        activeDeliverNextRef.current?.();
      }
    }, 260);
  };

  // Skip and instantly reveal full board content
  const skipSynchronizedLectureToFull = () => {
    stopSpeech();
    const fullClean = cleanBoardContentForDisplay(boardContent);
    setTypedBoardContent(fullClean);
    if (boardScrollContainerRef.current) {
      boardScrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
    playSoundEffect('chime');
    showNotification?.("Revealed complete lecture content on board", "info");
  };

  // Replay lecture from start with full synchronization
  const replaySynchronizedLecture = () => {
    startSynchronizedLecture(boardContent);
    playSoundEffect('chime');
    showNotification?.("Replaying lecture with synchronized typing & audio", "info");
  };

  // Narrate Current Board Content (Full Lecture Synchronized Engine)
  const narrateCurrentBoardContent = (customText?: string) => {
    const raw = customText || boardContent;
    if (!raw) return;
    startSynchronizedLecture(raw);
  };

  // Handle user selecting a specific section or all sections to teach
  const handleSelectLectureSection = (sectionId: number | 'all') => {
    setSelectedLectureSection(sectionId);
    selectedLectureSectionRef.current = sectionId;

    const topicTitle = activeTopicTitle || stagedTopicTitle || userTopic || 'Universal Scientific Foundations';
    const langObj = resolveLanguageObject(selectedLectureLanguage || selectedLanguage || language);
    const targetLangCode = langObj ? langObj.code : 'en';

    // Ensure we have broken down sections for this topic
    if (!preparedSectionsMapRef.current || preparedSectionsMapRef.current.size === 0) {
      preparedSectionsMapRef.current = breakdownLectureIntoSections(topicTitle, preparedBoardRef.current || boardContent, targetLangCode);
    }

    const sectionContent = preparedSectionsMapRef.current.get(sectionId) || preparedSectionsMapRef.current.get('all') || preparedBoardRef.current || boardContent;
    preparedBoardRef.current = sectionContent;

    const meta = typeof sectionId === 'number' ? LECTURE_SECTIONS_META.find(s => s.id === sectionId) : null;
    const sectionName = meta ? meta.fullName : 'All 7 Sections (Full Comprehensive Lecture)';

    if (isLectureActive || professorStatus === 'teaching') {
      showNotification?.(`${selectedTeacherStyle.name} is now teaching ${sectionName}! ${selectedTeacherStyle.avatarIcon}`, 'info');
      setBoardContent(sectionContent);
      setAiResponseText(sectionContent);
      startSynchronizedLecture(sectionContent);
    } else {
      setBoardContent(sectionContent);
      setAiResponseText(sectionContent);
      showNotification?.(`Section selected: ${sectionName}. Click ▶ START / PLAY for ${selectedTeacherStyle.name} to teach this section!`, 'success');
    }
  };

  // Play Tutor Speech via Native Engine or Neural Gemini TTS
  const speakTutorMessage = async (text: string) => {
    if (!audioEnabled) return;

    try {
      stopSpeech();
      setIsSpeaking(true);
      const cleanText = cleanTextForSpeech(text);
      startSynchronizedLecture(cleanText);
    } catch (err) {
      console.warn("TTS playback error, falling back to Native Engine:", err);
      const cleanText = cleanTextForSpeech(text);
      startSynchronizedLecture(cleanText);
    }
  };

  // Camera views preset definitions
  const CAMERA_POSITIONS: Record<CameraViewPreset, { pos: THREE.Vector3; lookAt: THREE.Vector3; fov: number }> = {
    front_row: {
      pos: new THREE.Vector3(0, 2.15, 3.8),
      lookAt: new THREE.Vector3(-0.8, 2.3, -4.8),
      fov: 48
    },
    professor_focus: {
      pos: new THREE.Vector3(1.0, 1.95, 0.4),
      lookAt: new THREE.Vector3(0.5, 1.8, -4.1),
      fov: 38
    },
    teacher_podium: {
      pos: new THREE.Vector3(3.2, 2.4, -1.8),
      lookAt: new THREE.Vector3(-0.5, 1.8, 3.5),
      fov: 55
    },
    lab_bench: {
      pos: new THREE.Vector3(3.6, 2.4, -0.5),
      lookAt: new THREE.Vector3(4.8, 1.8, -1.0),
      fov: 48
    },
    board_focus: {
      pos: new THREE.Vector3(-2.2, 2.65, 1.8),
      lookAt: new THREE.Vector3(-2.5, 2.7, -5.28),
      fov: 44
    },
    overhead: {
      pos: new THREE.Vector3(0, 10.5, 2.0),
      lookAt: new THREE.Vector3(0, 0, -0.5),
      fov: 60
    },
    free_orbit: {
      pos: new THREE.Vector3(4.5, 5.0, 7.5),
      lookAt: new THREE.Vector3(-0.5, 2.0, 0),
      fov: 52
    },
    desk_focus: {
      pos: new THREE.Vector3(2.8, 1.85, -2.4),
      lookAt: new THREE.Vector3(4.2, 1.15, -3.85),
      fov: 44
    },
    figure_focus: {
      pos: new THREE.Vector3(-0.8, 2.3, 1.5),
      lookAt: new THREE.Vector3(-1.4, 2.2, -4.5),
      fov: 45
    },
    avatar_focus: {
      pos: new THREE.Vector3(1.2, 2.0, -2.5),
      lookAt: new THREE.Vector3(0.5, 1.8, -4.1),
      fov: 32
    }
  };

  // Handle camera view transitions
  const setCameraView = (preset: CameraViewPreset) => {
    setActiveCameraView(preset);
    playSoundEffect('click');
    showNotification?.(`Camera switched to ${preset.replace('_', ' ').toUpperCase()}`, 'info');

    if (!cameraRef.current) return;
    const target = CAMERA_POSITIONS[preset];
    
    // Smooth animated transition
    const startPos = cameraRef.current.position.clone();
    const startTime = performance.now();
    const duration = 800; // ms

    const animateCamera = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Smooth easeInOutCubic
      const ease = progress < 0.5 
        ? 4 * progress * progress * progress 
        : 1 - Math.pow(-2 * progress + 2, 3) / 2;

      if (cameraRef.current) {
        cameraRef.current.position.lerpVectors(startPos, target.pos, ease);
        cameraRef.current.lookAt(target.lookAt);
        cameraRef.current.fov = THREE.MathUtils.lerp(cameraRef.current.fov, target.fov, ease);
        cameraRef.current.updateProjectionMatrix();
      }

      if (progress < 1) {
        requestAnimationFrame(animateCamera);
      }
    };

    requestAnimationFrame(animateCamera);
  };

  // Update Lighting Preset & Automated Nano Banana 2 Lighting Calibration
  const applyLightingPreset = (preset: LightingPreset) => {
    setLightingPreset(preset);
    playSoundEffect('click');

    const lightingCalibrations: Record<LightingPreset, string> = {
      daylight: "💡 Nano Banana 2 Calibrated: 5200K Studio Neutral Daylight • Diffuse Satin Shading & Glass Refraction",
      golden_hour: "💡 Nano Banana 2 Calibrated: 3200K Warm Golden Key Light • Metallic Specular Highlights & Rim Shadows",
      cyber_night: "💡 Nano Banana 2 Calibrated: 10000K Cyber Indigo Key • Emissive Cyan Gloss (#00f5ff) & Subsurface Glow",
      exam_bright: "💡 Nano Banana 2 Calibrated: 6500K Pure White Exam Focus • Crisp High-Definition Non-Glare Finish"
    };
    showNotification?.(lightingCalibrations[preset], 'info');

    if (!mainSunLightRef.current || !ambientLightRef.current || !sceneRef.current) return;

    if (preset === 'daylight') {
      sceneRef.current.background = new THREE.Color(0xdbeafe);
      sceneRef.current.fog = new THREE.FogExp2(0xdbeafe, 0.02);
      mainSunLightRef.current.color.setHex(0xfffaed);
      mainSunLightRef.current.intensity = 1.8;
      ambientLightRef.current.color.setHex(0xe2e8f0);
      ambientLightRef.current.intensity = 0.8;
      roomLightsRef.current.forEach(l => { l.color.setHex(0xffffff); l.intensity = 0.6; });
    } else if (preset === 'golden_hour') {
      sceneRef.current.background = new THREE.Color(0xfef3c7);
      sceneRef.current.fog = new THREE.FogExp2(0xfef3c7, 0.025);
      mainSunLightRef.current.color.setHex(0xf59e0b);
      mainSunLightRef.current.intensity = 2.2;
      ambientLightRef.current.color.setHex(0xfde68a);
      ambientLightRef.current.intensity = 0.6;
      roomLightsRef.current.forEach(l => { l.color.setHex(0xfef08a); l.intensity = 0.5; });
    } else if (preset === 'cyber_night') {
      sceneRef.current.background = new THREE.Color(0x090d16);
      sceneRef.current.fog = new THREE.FogExp2(0x090d16, 0.035);
      mainSunLightRef.current.color.setHex(0x6366f1);
      mainSunLightRef.current.intensity = 0.8;
      ambientLightRef.current.color.setHex(0x1e1b4b);
      ambientLightRef.current.intensity = 0.4;
      roomLightsRef.current.forEach(l => { l.color.setHex(0x38bdf8); l.intensity = 1.2; });
    } else if (preset === 'exam_bright') {
      sceneRef.current.background = new THREE.Color(0xf8fafc);
      sceneRef.current.fog = new THREE.FogExp2(0xf8fafc, 0.015);
      mainSunLightRef.current.color.setHex(0xffffff);
      mainSunLightRef.current.intensity = 2.0;
      ambientLightRef.current.color.setHex(0xffffff);
      ambientLightRef.current.intensity = 1.0;
      roomLightsRef.current.forEach(l => { l.color.setHex(0xffffff); l.intensity = 0.9; });
    }
  };

  // Reset Smartboard to its Default Reset Position (Docked Left, Front Row Camera, Scroll Top)
  const resetSmartboardPosition = () => {
    setSmartboardLayout('left');
    setCameraView('front_row');
    setIsSmartboardAutoZoomed(false);
    setIsSmartboardNotesMinimized(false);
    if (boardScrollContainerRef.current) {
      boardScrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Stage Selected Chapter: shows that chapter is being prepared and waits for user to click START/PLAY
  const handleStageSelectedChapter = (chapterTitle: string, notifyParent: boolean = false) => {
    if (!chapterTitle || !chapterTitle.trim()) return;
    const cleanTitle = chapterTitle.trim();

    // 1. Immediately cancel/stop any active lecture, speech synthesis, typewriter timers, or audio narration
    stopSpeech();
    setIsLectureActive(false);
    setIsLecturePaused(false);
    setIsLoadingAi(false);
    userClickedStartRef.current = false; // Lecture must start ONLY after clicking play/start button!

    // 2. Set staged & lifecycle state
    setStagedTopicTitle(cleanTitle);
    setActiveTopicTitle(cleanTitle);
    prevUserTopicRef.current = cleanTitle;
    setProfessorStatus('coming_soon');
    setTypedBoardContent('');

    const newPrompt = `I want to study the lesson "${cleanTitle}" of Chapter "${userSubject || '5. Continuity and Differentiability'}" to a degree of ${userDifficulty ? userDifficulty.toUpperCase() : 'STANDARD'} depth/rigor. Tutor Rigor Instructions: Provide a standard, granular, step-by-step academic explanation. Explain definitions, list equations, detail a complete concrete worked-out example with intermediate steps, and test me on the content with 2 standard practice questions. Please proceed to teach the lesson now with high quality and formatting.`;
    setSelectedPromptText(newPrompt);

    // 3. Reset smartboard position to front row view so it's fully visible and unminimized
    resetSmartboardPosition();
    setIsSmartboardNotesMinimized(false);
    setShowTopicModal(false);

    // 4. Update Smartboard Content to show working on selected chapter (professor is coming soon )
    const isOmni = selectedTeacherStyle.id === 'omni_ai';
    const workingMarkdown = isOmni
      ? `# ⚡ Working on selected chapter: ${cleanTitle}\n\n### (professor is coming soon )\n\n${selectedTeacherStyle.name} is preparing the complete standard curriculum master lecture exclusively for **${cleanTitle}**:\n- Comprehensive conceptual foundation & core laws\n- Rigorous LaTeX formulas & step-by-step derivations\n- Concrete worked-out numerical & analytical examples\n- Standard practice questions with complete solutions\n- Core formula summary sheet\n\n*(professor is coming soon — click ▶ START / PLAY when ready)*`
      : `# ⚙️ Working on selected chapter: ${cleanTitle}\n\n### (professor is coming soon )\n\n${selectedTeacherStyle.name} is preparing the complete master lecture exclusively for **${cleanTitle}**:\n- Everyday physical analogies & zero-level concept building\n- Dynamic vector diagrams & core scientific equations\n- 5-layer progressive review breakdown\n- Academic & competitive entrance exam practice drills\n\n*(professor is coming soon — click ▶ START / PLAY when ready)*`;
    setBoardContent(workingMarkdown);

    // 5. Hologram inference for selected chapter
    const lower = cleanTitle.toLowerCase();
    if (lower.includes('dna') || lower.includes('bio') || lower.includes('gene') || lower.includes('cell')) {
      setActiveHologram('dna');
    } else if (lower.includes('planet') || lower.includes('astro') || lower.includes('space') || lower.includes('orbit')) {
      setActiveHologram('planet');
    } else if (lower.includes('math') || lower.includes('calc') || lower.includes('matrix') || lower.includes('algebra') || lower.includes('geometry')) {
      setActiveHologram('math_surface');
    } else {
      setActiveHologram('atom');
    }

    if (notifyParent) {
      onSelectTopic?.(cleanTitle);
    }

    playSoundEffect('chalk');
    showNotification?.(`Working on selected chapter: "${cleanTitle}" (professor is coming soon )`, 'info');

    // Trigger preparation in background; autoStart = false ensures lecture won't start until user clicks Start/Play
    handleSelectCustomTopic(cleanTitle, false, false);
  };

  // Switch Lesson Topic (Stages by default; never starts automatically)
  const handleSelectLesson = (idx: number, autoStart: boolean = false) => {
    const lesson = LESSON_TOPICS[idx];
    if (!lesson) return;
    
    if (!autoStart) {
      handleStageSelectedChapter(lesson.title, true);
      return;
    }

    // When autoStart is explicitly true (user clicked Start/Play)
    handleSelectCustomTopic(lesson.title, true, true);
  };

  // Select or Generate Custom Topic for 3D Classroom
  const handleSelectCustomTopic = async (
    topicName: string, 
    notifyParent: boolean = true, 
    autoStart: boolean = true,
    overrideLangName?: string
  ) => {
    if (!topicName.trim()) return;

    if (autoStart) {
      userClickedStartRef.current = true;
    }

    resetSmartboardPosition();
    setStagedTopicTitle(null);
    prevUserTopicRef.current = topicName;
    setActiveTopicTitle(topicName);
    if (notifyParent) {
      onSelectTopic?.(topicName);
    }
    setShowTopicModal(false);

    // Show on smartboard that you are working on the selected chapter (professor is coming soon )
    setProfessorStatus('coming_soon');
    setIsLoadingAi(true);
    setIsLectureActive(false);
    setIsLecturePaused(false);
    setTypedBoardContent('');

    const isOmni = selectedTeacherStyle.id === 'omni_ai';
    const isNumReq = isNumericalRequest(topicName);
    const isIntro = isNumReq ? false : isChapterIntro(topicName);
    const workingMarkdown = isNumReq
      ? `# 🔢 Preparing Numerical Questions & Solved Problems: ${topicName}\n\n### (professor is coming soon )\n\n${selectedTeacherStyle.name} is preparing numerical questions and step-by-step problem solving for **${topicName}**:\n- 🔢 Numerical Problem 1 with Given Data & Applied Formula\n- ✍️ Step-by-step arithmetic & algebraic calculations\n- 🎯 Final calculated results with standard SI units\n- 📝 Follow-up practice numericals\n\n*(professor is coming soon — click ▶ START / PLAY when ready)*`
      : (isIntro
          ? (isOmni
              ? `# ⚡ Working on chapter introduction: ${topicName}\n\n### (professor is coming soon )\n\n${selectedTeacherStyle.name} is preparing the comprehensive chapter introductory overview for **${topicName}**:\n- 💡 Conceptual foundation & core principles\n- 📐 Governing laws, formulations & LaTeX derivations\n- 🔬 Concrete worked-out numerical & analytical examples\n- 📝 Standard practice questions with complete solutions\n- ⚡ Key formula sheet & essential takeaways\n\n*(professor is coming soon — click ▶ START / PLAY when ready)*`
              : `# ⚙️ Working on chapter introduction: ${topicName}\n\n### (professor is coming soon )\n\n${selectedTeacherStyle.name} is preparing the introductory master overview for **${topicName}**:\n- Everyday physical analogies & zero-level concept building\n- Dynamic vector diagrams & core scientific equations\n- 5-layer progressive review breakdown\n- Academic & competitive entrance exam practice drills\n\n*(professor is coming soon — click ▶ START / PLAY when ready)*`)
          : `# ⚡ Preparing explanation: ${topicName}\n\n### (professor is coming soon )\n\n${selectedTeacherStyle.name} is preparing a focused lesson teaching directly according to what is asked in **${topicName}**:\n- 🎯 Direct conceptual answer & physical intuition\n- 🔍 Step-by-step explanation addressing the question\n- 📐 Key mathematical equations & scientific reasoning\n- 📌 Clear conclusion and takeaways\n\n*(professor is coming soon — click ▶ START / PLAY when ready)*`);
    setBoardContent(workingMarkdown);
    playSoundEffect('chalk');
    showNotification?.(`Working on selected chapter: "${topicName}" (professor is coming soon )`, 'info');

    // Infer hologram
    const lower = topicName.toLowerCase();
    if (lower.includes('dna') || lower.includes('bio') || lower.includes('gene') || lower.includes('cell')) {
      setActiveHologram('dna');
    } else if (lower.includes('planet') || lower.includes('astro') || lower.includes('space') || lower.includes('orbit')) {
      setActiveHologram('planet');
    } else if (lower.includes('math') || lower.includes('calc') || lower.includes('matrix') || lower.includes('algebra') || lower.includes('geometry')) {
      setActiveHologram('math_surface');
    } else {
      setActiveHologram('atom');
    }

    const langObj = resolveLanguageObject(overrideLangName || selectedLectureLanguage || selectedLanguage || language);
    const currentLangName = langObj ? langObj.name : 'English';
    const currentLangNative = langObj?.native || currentLangName;
    const isHindi = currentLangName.toLowerCase() === 'hindi' || langObj?.code === 'hi' || langObj?.code === 'hinglish';

    try {
      const isSilentDraw = silentDraw || localStorage.getItem('omni_silent_draw') === 'true';
      const silentDrawRule = isSilentDraw
        ? "SILENT-DRAW MODE ACTIVE: You MUST automatically generate and embed a clean inline SVG figure (<svg viewBox=\"0 0 1000 500\" width=\"100%\" height=\"100%\" xmlns=\"http://www.w3.org/2000/svg\">...</svg>) and rendered LaTeX block diagrams ($$...$$) for all visual concepts, taxonomy charts, or mathematical topics without requiring explicit text triggers."
        : "SILENT-DRAW MODE INACTIVE: Do not automatically generate SVG figures unless requested or describing visual concepts.";

      const svgPlacementRule = "VECTOR SVG PLACEMENT RULE: When generating vector figures or taxonomy charts (matrices, physics vectors, chemical structures, geometry), embed the complete <svg ...>...</svg> element directly at the exact position in your text where it belongs conceptually (between paragraphs or under sub-headings). Include full defs, patterns, hatching, gradients, filters, markers, and interactive click overlays where applicable. The classroom smartboard renders all inline SVGs with full interactive fidelity right where they appear in the text.";

      const professorClarityRule = `
      You are Professor Clarity, a world-class AI educator who delivers chapters in the Classroom Slate 3D environment. Your job is NOT just to "cover" a chapter — it is to transform a student from confusion to mastery through a carefully orchestrated series of separate, focused lectures — one for each subtopic of whatever chapter the student selects.

      Every lecture must be a complete, self-contained learning experience — with its own beginning (curiosity), middle (discovery), and end (mastery).
      All teaching operates automatically from the backend without extra buttons or manual controls.

      ======================================================================
      PART 1: DYNAMIC CHAPTER-TO-LECTURE SYSTEM
      ======================================================================
      Core Principle: Every Chapter Is Different.
      The system does NOT follow a fixed structure for all chapters.
      Each chapter has its own:
      - Number of subtopics
      - Names of subtopics
      - Difficulty progression
      - Formula density
      - Diagram requirements
      - Exam weightage
      - Prerequisites
      - Teaching approach

      The system AUTOMATICALLY:
      1. Reads the selected chapter's syllabus/metadata
      2. Identifies all subtopics (from syllabus/chapter data)
      3. Creates a separate lecture for each subtopic
      4. Creates 1–2 lectures for Board Exam questions
      5. Creates 1–2 lectures for Competitive Exam questions
      6. Adjusts teaching style based on subtopic type
      7. Adapts duration based on subtopic complexity
      8. Modifies examples based on subject context

      ======================================================================
      PART 2: HOW THE SYSTEM ADAPTS TO ANY CHAPTER
      ======================================================================
      Automatic Chapter Analysis:
      When a student selects a chapter:
      Step 1: READ CHAPTER METADATA (name, subject, grade, exam relevance, prerequisites)
      Step 2: IDENTIFY SUBTOPICS (extract subtopics, order them logically, determine prerequisites)
      Step 3: ASSIGN LECTURE STRUCTURE
        - 1 subtopic = 1 lecture (minimum)
        - Complex subtopics = 2–3 lectures
        - Simple subtopics = combined lecture
        - Always: 1 lecture for Board Exam questions
        - Always: 1 lecture for Competitive Exam questions
      Step 4: ADAPT TEACHING APPROACH
        - Conceptual subtopic → Analogies, stories, real-world, less formulas
        - Formula-based subtopic → Step-by-step derivations, worked examples, practice
        - Diagram-based subtopic → Visual-first, progressive drawing, label synchronization
        - Process-based subtopic → Storytelling, step-by-step flow, cause-and-effect
        - Comparison-based subtopic → Side-by-side, tables, differences/similarities
        - Numerical subtopic → Worked examples, problem-solving strategies, exam technique
      Step 5: GENERATE LECTURE SERIES (titles, durations, objectives, transitions, progress tracking)

      ======================================================================
      PART 3: EXAMPLE CHAPTER STRUCTURE — VECTOR (REFERENCE ONLY)
      ======================================================================
      Chapter: Vector (Mathematics — Class 11/12) [Used for illustration only]
      Subtopics Detected:
      1. Introduction to Vectors
      2. Vectors and Scalars (magnitude, direction, position vector, direction cosines/ratios)
      3. Types of Vectors (null, unit, co-initial, collinear, equal)
      4. Vector Operations (addition, scalar multiplication, section formulas)
      5. Vector Products (dot product, projection, cross product, area)
      6. Scalar Triple Product ([a,b,c], volume, coplanarity)
      7. Solved Numerical Problems
      Generated Lecture Series:
      ├── Lecture 1: Introduction to Vectors
      ├── Lecture 2: Vectors and Scalars
      ├── Lecture 3: Types of Vectors
      ├── Lecture 4: Vector Operations
      ├── Lecture 5: Vector Products
      ├── Lecture 6: Scalar Triple Product
      ├── Lecture 7: Solved Numerical Problems
      ├── Lecture 8: Board Exam Questions (All Types)
      └── Lecture 9: Competitive Exam Questions (All Types)

      Note: Vector is an example. The system automatically reads and generates a custom lecture series for ANY chapter the student selects.

      ======================================================================
      PART 4: UNIVERSAL LECTURE ARCHITECTURE (7 PHASES)
      ======================================================================
      Regardless of chapter or subtopic, every lecture follows:
      Phase 1: LECTURE ORIENTATION (2–3 min) — Welcome, context, objectives, preview, connection to previous lecture.
      Phase 2: CURIOSITY HOOK (1–2 min) — Question or observation sparking interest, real-world connection.
      Phase 3: CONCEPT FOUNDATION (8–15 min) — Clear definition, why it matters, multiple representations, progressive diagram building, formula derivation.
      Phase 4: GUIDED EXPLORATION (5–10 min) — Worked examples (2–3), common misconceptions, multiple approaches.
      Phase 5: CHECKPOINT & PRACTICE (5–10 min) — Quick understanding check, 3–5 practice questions at progressive difficulty.
      Phase 6: LECTURE SUMMARY (2–3 min) — Key takeaways, formula recap, bridge to next lecture.
      Phase 7: REFLECTION & NEXT STEPS (1–2 min) — 30 seconds silence, preview of next lecture, encouraging closure.

      ======================================================================
      PART 5: AUTO-ADAPTIVE TEACHING BASED ON SUBTOPIC TYPE
      ======================================================================
      TYPE 1: CONCEPTUAL SUBTOPIC (Keywords: "Introduction", "Definition", "Meaning", "Concept")
        → More analogies, stories, real-world examples, less formulas.
      TYPE 2: FORMULA-BASED SUBTOPIC (Keywords: "Formula", "Equation", "Calculation")
        → Step-by-step derivations, worked examples, numerical practice.
      TYPE 3: DIAGRAM-BASED SUBTOPIC (Keywords: "Diagram", "Structure", "Label", "Draw")
        → Visual-first teaching, progressive drawing, label synchronization, 3D visualization.
      TYPE 4: PROCESS-BASED SUBTOPIC (Keywords: "Process", "Cycle", "Reaction", "Mechanism")
        → Storytelling, step-by-step flow, cause-and-effect, sequence emphasis.
      TYPE 5: COMPARISON-BASED SUBTOPIC (Keywords: "vs", "Compare", "Difference", "Similarities")
        → Side-by-side comparison tables, memory aids, key differences.
      TYPE 6: NUMERICAL SUBTOPIC (Keywords: "Numerical", "Problems", "Calculation")
        → Many worked examples, problem-solving strategies, exam technique, common mistakes.

      ======================================================================
      PART 6: EXAM QUESTION QUANTITIES & COMPREHENSIVE MODULES
      ======================================================================
      Board Exam Question Lecture:
      - Taught: 5–10 questions per type across all 8 board categories (Very Short, Short, Long, Diagram-Based, Fill Blanks, True/False, Match, Assertion-Reason).
      - Suggested: 5–10 questions per type (with step hints).

      Competitive Entrance Exam Question Lecture (NEET / JEE / AIIMS):
      - Taught: 20–30 questions per type across all 8 entrance categories + 50 high-yield MCQs.
      - Suggested: 20–30 questions per type (with step hints) + 50 practice MCQs.

      --- CORE CONCEPT TO STUDENT LEVEL PEDAGOGICAL MANDATE ---
      Mind that the student knows nothing about the topic at the start. Teach from absolute zero level up to their grade/target level (Class 9, 10, 11, 12, or Entrance Exams like NEET/JEE/AIIMS):
      - Start with zero-jargon everyday intuition, physical analogies, and a curiosity question.
      - Step up to core foundations and equations.
      - Elevate to advanced physical/chemical mechanisms and derivations.
      - Conclude with competitive entrance high-yield shortcuts, experimental reasoning, and negative-marking traps.

      --- PRONUNCIATION & SCIENTIFIC SYMBOL RULES ---
      - Never pronounce raw formatting marks (asterisks, hyphens, bullets, LaTeX backslashes, hash signs) — keep them silent to create natural pauses.
      - Pronounce chemical formulas and scientific quantities naturally: "CO₂" as "carbon dioxide", "H₂O" as "water", "ΔG°" as "delta G standard", "kJ/mol" as "kilojoules per mole", "→" as "yields" or "gives".
      - Distinguish algebraic variables like "2a" from physical units like "2 A" (two Amperes).

      --- DYNAMIC FIGURE PROGRESSION ---
      - Provide distinct <svg> diagrams for each stage so the smartboard switches figures dynamically in real time.

      --- CORE TEACHING PHILOSOPHY & THE GOLDEN RULE ---
      Never read content word-for-word. Always explain it in your own words, with your own examples, in your own style.
      - Reading style (AVOID): "The derivative is the limit of the difference quotient as h approaches zero..."
      - Teaching style (USE): "Imagine glancing at your car's speedometer. You're not asking how far you went in an hour — you want your exact rate right this instant. That's a derivative!..."

      --- 10 CORE TEACHING TECHNIQUES ---
      1. Analogy Method  2. Question-First Method  3. Story Method  4. Breakdown Method  5. Connection Method
      6. Simplification Method  7. Demonstration Method  8. Misconception-First Method  9. Relevance Method  10. Mnemonic Method

      --- 10 TEACHING BEHAVIOUR RULES ---
      1. Never Read Verbatim  2. Always Add Explanation  3. Use Your Own Words  4. Check for Understanding
      5. Use Voice Naturally  6. Connect Everything  7. Use Visuals Actively  8. Tell Stories  9. Create Mnemonics  10. Show Enthusiasm

      --- DYNAMIC FIGURE TEACHING: CORE PRINCIPLES ---
      1. Progressive Revelation  2. Speech-Synchronised Highlighting  3. Auto-Zoom on Focus  4. Visual Connections
      5. Colour Coding  6. Layered Labels  7. Contextual Animations  8. Interactive Prompts  9. Memory Anchors  10. Exam-Focused Annotations

      --- 🚫 STRICT ZERO MACHINE LANGUAGE MANDATE (CRITICAL) ---
      - ABSOLUTELY FORBIDDEN: You MUST NEVER output machine language, bracketed commands, stage directions, pseudo-code, timing parameters, or syntax tags like [AVATAR:...], [SMARTBOARD:...], [Type:...], [Draw:...], [Scroll:...], [Pause:...], [Animation:...], [Phase:...], [Step:...], or pipe-separated directives (| 1s | sync_with:...).
      - SHOW WORDS IN PURE NATURAL LANGUAGE ONLY: Every word displayed on the smartboard and spoken aloud must be in human, natural, conversational educational language.
      - Mathematical and chemical equations are written in standard LaTeX ($...$ and $$...$$). Diagrams are rendered in standard SVG (<svg viewBox="0 0 650 260">...</svg>).`;

      const deliveryFormatGuidance = 
        lectureDeliveryFormat === 'socratic'
          ? `DELIVERY FORMAT: SOCRATIC DIALOGUE & GUIDED INQUIRY
             - Lead with curiosity-sparking questions and relatable physical intuition before presenting any equations.
             - Engage the student in guided discovery with gentle checks for understanding ("Notice what happens when...", "Why do you think this occurs?").
             - Break down intermediate derivations step by step with conversational transitions.`
          : lectureDeliveryFormat === 'quick'
          ? `DELIVERY FORMAT: HIGH-YIELD RAPID REVIEW
             - Fast-paced, crystal-clear conceptual summary.
             - Highlight primary governing equations in LaTeX, key SI units, and common examiner traps.
             - Provide 1 high-yield numerical problem and 1 quick exam check.`
          : `DELIVERY FORMAT: MASTER ACADEMIC CURRICULUM LECTURE
             - Comprehensive, high-clarity lesson with deep physical intuition, complete step-by-step mathematical derivations in LaTeX, multi-level worked examples (Levels 1-5), and exam practice problems.`;

      const chapterIntroTeachingPrompt = `
      ======================================================================
      MASTER CURRICULUM CHAPTER INTRODUCTION LECTURE STRUCTURE:
      Deliver a comprehensive introductory overview for the chapter "${topicName}" in natural ${currentLangName} (${currentLangNative}):
      ${deliveryFormatGuidance}

      REQUIRED PROGRESSIVE CHAPTER INTRODUCTION SECTIONS (VALID ONLY FOR CHAPTER INTRODUCTIONS):
      1. 💡 Conceptual Foundation & Core Principles — Relatable physical analogies, curiosity-sparking hook, and core scientific laws in natural language.
      2. 📐 Governing Laws, Formulations & LaTeX Derivations — Full mathematical formulations in standard LaTeX ($...$ inline, $$...$$ blocks), parameter definitions, SI units, and rigorous step-by-step derivations.
      3. 🔬 Concrete Worked-Out Numerical & Analytical Examples — Complete step-by-step solved examples with intermediate steps, formulas applied, and final units highlighted.
      4. 📝 Standard Practice Questions & Solutions — High-yield practice questions with comprehensive step-by-step solutions and marking rubrics.
      5. ⚡ Key Formula Sheet & Essential Takeaways — Quick-reference formula summary and common pitfalls/traps to avoid.

      SMOOTH TRANSITIONS & NATURAL HUMAN EDUCATIONAL EXPLANATIONS:
      - Use smooth conversational transition bridges between sections.
      - Explain the physical meaning of every variable before substituting numbers.
      ======================================================================`;

      const questionResponsiveTeachingPrompt = `
      ======================================================================
      TEACH ACCORDING TO WHAT IS ASKED IN THE QUESTION (CRITICAL PEDAGOGICAL DIRECTIVE):
      The student has asked or selected: "${topicName}".
      You MUST teach STRICTLY ACCORDING TO WHAT IS ASKED IN THIS QUESTION, NOT according to the rigid 5-part rule-based template.
      (The 5-part rule-based template — 1. Conceptual Foundation, 2. Governing Laws & Derivations, 3. Worked Examples, 4. Practice Questions, 5. Formula Sheet — is valid ONLY for the introduction of a chapter).

      HOW TO TEACH ACCORDING TO WHAT IS ASKED:
      1. DIRECT & LASER-FOCUSED ANSWER:
         - Address exactly what is asked in "${topicName}" immediately and directly.
         - Do NOT force unrequested sections, unrequested practice question banks, or unrequested formula sheets.
      2. QUESTION-TAILORED PEDAGOGY:
         - If the question asks for a definition or concept: Provide intuitive physical analogies, real-world relevance, and clear explanation of the concept.
         - If the question asks to solve or calculate: State the given information, identify the specific governing formula, work out the solution step-by-step with clear arithmetic and algebraic logic, and highlight the final answer with correct physical units.
         - If the question asks for a derivation or proof: Set up the physical diagram/system, declare assumptions, and walk through the mathematical derivation line by line with clear LaTeX ($...$ and $$...$$), explaining the physical intuition of each transition.
         - If the question asks "why" or "how": Explain the scientific mechanism, cause-and-effect chain, and practical implications.
         - If the question asks to compare or differentiate: Provide a clear, sharp comparison table or side-by-side contrast of key attributes.
      3. PEDAGOGICAL CLARITY & WARMTH:
         - Explain in warm, clear, natural human language for a student.
         - Use inline SVG diagrams or clear LaTeX formulas if directly relevant to answering the question.
         - End with a concise summary takeaway that directly solidifies the answer to what was asked.
      ======================================================================`;

      const activeTeachingPrompt = isIntro ? chapterIntroTeachingPrompt : questionResponsiveTeachingPrompt;

      const languageInstruction = isHindi
        ? `CRITICAL HINDI (हिन्दी) LANGUAGE MANDATE:
        - You MUST deliver the ENTIRE lecture, smartboard text, explanations, formulas, analogies, exam questions, bullet points, and speech explanation in fluent, authentic HINDI (हिन्दी) using Devanagari script.
        - Every single heading, sentence, definition, and concept explanation MUST be written in Hindi (e.g. 'मुख्य अवधारणा', 'ऊष्मागतिकी के नियम', 'ऊर्जा संरक्षण का सिद्धांत', 'दक्षता एवं कार्नो इंजन', 'प्रमुख सूत्र सारांश').
        - Do NOT write in English. Do NOT switch back to English.
        - You may include standard English terms in parentheses alongside Hindi terms if helpful for students (e.g., 'ऊष्मागतिकी (Thermodynamics)', 'आंतरिक ऊर्जा (Internal Energy)').
        - All mathematical and chemical equations must use standard LaTeX notation ($...$ or $$...$$).`
        : `CRITICAL LANGUAGE DIRECTIVE: Deliver the entire lecture, smartboard text, formulas, bullet points, and speech explanation in "${currentLangName}" (${currentLangNative}). Do not write in English unless scientific notation or standard mathematical symbols require standard notation.`;

      const strictChapterExclusivityRule = `
      ======================================================================
      STRICT TOPIC EXCLUSIVITY MANDATE:
      You are ${selectedTeacherStyle.name}. You MUST teach EXCLUSIVELY and ONLY what is asked in: "${topicName}".
      Under NO circumstances should you introduce, teach, or mention unrelated chapters or topics.
      Every single concept, intuition, analogy, chemical formula, mathematical equation, vector SVG diagram, and step MUST be 100% strictly and specifically focused on answering "${topicName}".
      ======================================================================`;

      const humanNaturalLanguageTeachingMandate = `
      ======================================================================
      MANDATORY NATURAL HUMAN LANGUAGE TEACHING DIRECTIVE (FOR A STUDENT):
      Reading is robotic. Teaching is human. You are a real, articulate human educator teaching a human student.
      1. NATURAL, ENGAGING STUDENT DIALOGUE & SMOOTH TRANSITIONS:
         - Speak and teach in pure natural human languages (for a student). Address the student directly and warmly ("you", "we", "let us explore this together", "think of it this way").
         - Explain the physical intuition, real-world relevance, and meaning behind every concept before giving mathematical formulas.
         - Connect each topic smoothly to the next with natural bridge phrases.
         - Use natural human numbers and natural step sequences (Step 1, Step 2, Step 3... never 0-indexed or robotic machine indices).
      2. STRICT ZERO MACHINE SYNTAX:
         - NEVER output machine commands, bracketed tags, avatar directives, timing parameters, or pseudo-code (such as [AVATAR:...], [SMARTBOARD:...], [Type:...], [Draw:...], [Scroll:...], [Pause:...], [Animation:...], [Phase:...], [sync_with:...], [TEACHING_GOLDEN_RULE], [ANALOGY_METHOD], etc.).
         - All written smartboard content must be pure, clean human-readable GFM Markdown with standard LaTeX ($...$ inline, $$...$$ block) and standard scientific graphics.
      3. NATURAL HUMAN SPEECH FOR STUDENT EARS:
         - Every word spoken aloud must sound like a warm, supportive teacher.
         - Never say formatting symbol names (NEVER say "asterisk", "star star", "hash", "bullet point", "dot dot dot", "hyphen", "dash", "underscore", "backslash", "slash", "equals sign", "bracket").
         - Pronounce formulas and equations naturally for a student's ear.
      4. REAL-WORLD STUDENT-CENTRIC EXPLANATION (MAKING CONTENT 100% UNDERSTANDABLE FOR A REAL STUDENT):
         - Ground every abstract concept in tangible real-world physical intuition (everyday objects, physical movements, relatable scenarios) BEFORE introducing equations.
         - When presenting formulas, explain what EVERY variable physically means in plain conversational terms (e.g. "here, 'v' is how fast the object moves in m/s, while 't' tracks elapsed time in seconds").
         - NEVER echo, quote, or display prompt instructions, engineering parameters, or "Tutor Rigor Instructions" on the smartboard or in speech.
         - Address common student confusions and misconceptions proactively ("Students often trip up here because...", "Here is a simple trick to remember...").
         - Check for understanding with gentle conversational cues ("Does this picture make sense to you?", "Notice how everything clicks together here").
      ======================================================================`;

      const isNumReq = isNumericalRequest(topicName);
      const effectiveIsIntro = isNumReq ? false : isIntro;

      let systemInstruction = '';
      let promptQuery = '';

      if (virtual3dPromptMode === 'smartboard') {
        const cleanPromptText = selectedPromptText || DEFAULT_CONTINUITY_PROMPT;
        systemInstruction = `You are ${selectedTeacherStyle.name}, the Master AI Educator in an interactive lecture hall.
The student has selected a custom prompt on the smartboard.
CRITICAL SMARTBOARD PROMPT MODE DIRECTIVE:
You MUST teach and answer strictly according to the custom question/prompt selected on the smartboard: "${cleanPromptText}".
Do NOT mix this with standard syllabus play mode templates. Address exactly what is requested, answer the specific questions asked, solve any calculations step-by-step, and explain the key scientific/mathematical mechanisms.
Format mathematical equations in clear LaTeX ($...$ for inline, $$...$$ for blocks).
Always include an illustrative, high-clarity inline SVG scientific/mathematical diagram (<svg viewBox="0 0 800 400" ...>...</svg>) on the smartboard that directly illustrates this custom smartboard question and concept with clear labeled parts and color-coding.
${strictChapterExclusivityRule}
${humanNaturalLanguageTeachingMandate}
${languageInstruction}
${svgPlacementRule}
${silentDrawRule}

🚫 STRICT ZERO 3D VIRTUAL DIRECTIVES: Output pure, standard educational markdown in natural human language.`;

        promptQuery = `Deliver a complete, high-clarity teaching session explaining and answering the smartboard prompt question: "${cleanPromptText}". Focus 100% on addressing and answering exactly what is asked in this question with deep pedagogical clarity in natural ${currentLangName} for a student. Always include a custom-designed, color-coded inline SVG diagram (<svg viewBox="0 0 800 400">...</svg>) illustrating the concepts or solutions asked in the smartboard prompt.`;
      } else {
        if (isOmni) {
          systemInstruction = `You are Professor Omni AI, the premier master educator from Omni AI.
CRITICAL SELECTION & DEMAND TEACHING MANDATE:
Professors MUST teach strictly according to the standard syllabus lesson selected by the user ("${topicName}"). You MUST NOT rearrange study content or insert any unrequested custom smartboard prompts.
${isNumReq 
  ? `THE STUDENT EXPLICITLY REQUESTED NUMERICAL QUESTIONS / PRACTICE PROBLEMS FOR "${topicName}". YOU MUST START IMMEDIATELY FROM NUMERICAL PROBLEM 1 (Problem Statement, Given Data, Applied Formula, Step-by-Step Solution, Final Result) FOLLOWED BY NUMERICAL PROBLEM 2 AND 3. DO NOT INCLUDE AN INTRODUCTORY LECTURE, PREAMBLE, OR HISTORICAL OVERVIEW.` 
  : (effectiveIsIntro 
      ? `You MUST teach the complete introductory academic curriculum content for the chapter: "${topicName}" in pure natural human language for a student.`
      : `You MUST teach strictly according to what is asked in the standard syllabus question/topic: "${topicName}" in pure natural human language for a student. Do not use the rigid 5-part rule-based template; that template is valid ONLY for chapter introductions.`)}
You do NOT teach according to 3D virtual scripts, 3D room constraints, or virtual stage directives.

${activeTeachingPrompt}
${strictChapterExclusivityRule}
${humanNaturalLanguageTeachingMandate}
${languageInstruction}
${svgPlacementRule}
${silentDrawRule}

🚫 STRICT ZERO 3D VIRTUAL DIRECTIVES: Output pure, standard educational markdown in natural human language. Do NOT use 3D avatar commands, virtual room tags, or virtual phase scripts. Deliver clean academic content directly.`;
        } else {
          systemInstruction = `You are ${selectedTeacherStyle.name}, the Master AI Educator in an interactive lecture hall.
The student has selected standard syllabus topic: "${topicName}".
CRITICAL SELECTION & DEMAND TEACHING MANDATE:
Professors MUST teach strictly according to what the student selected or requested ("${topicName}"). You MUST NOT rearrange study content or insert any unrequested custom smartboard prompts.
${isNumReq ? `THE STUDENT EXPLICITLY REQUESTED NUMERICAL QUESTIONS / PRACTICE PROBLEMS FOR "${topicName}". START IMMEDIATELY FROM NUMERICAL PROBLEM 1 WITHOUT AN INTRODUCTION.` : ''}
${strictChapterExclusivityRule}
${humanNaturalLanguageTeachingMandate}
${languageInstruction}
${activeTeachingPrompt}

Provide a complete, high-clarity smartboard lesson EXCLUSIVELY for standard syllabus topic: "${topicName}" in natural ${currentLangName} for a student, teaching directly according to what is asked.
Format mathematical equations in clear LaTeX ($...$ for inline, $$...$$ for blocks).
${selectedTeacherStyle.promptDirective || ''}
${svgPlacementRule}
${silentDrawRule}`;
        }

        promptQuery = isNumReq
          ? `Deliver numerical questions and step-by-step problem solving for standard syllabus topic: "${topicName}" in natural ${currentLangName} for a student. Start IMMEDIATELY with Numerical Problem 1 (problem statement, given data, applied formula, step-by-step solution, final result) followed by Numerical Problem 2 and 3. Do NOT include an introduction or preamble. Include a clean inline SVG scientific diagram (<svg viewBox="0 0 800 400" ...>...</svg>) illustrating the problem setup.`
          : (effectiveIsIntro
              ? `Deliver the complete introductory lesson for standard syllabus chapter: "${topicName}" in natural ${currentLangName} for a student (human being). Teach all concepts, formulas, worked examples, and practice questions in warm, clear, natural human language with smooth transitions, including an illustrative inline SVG scientific diagram (<svg viewBox="0 0 800 400" ...>...</svg>).`
              : `Teach directly according to what is asked in standard syllabus topic: "${topicName}". Focus 100% on explaining and answering what is asked in this syllabus question/topic with deep pedagogical clarity in natural ${currentLangName} for a student (human being). Always include an illustrative, high-clarity inline SVG scientific/mathematical diagram (<svg viewBox="0 0 800 400" ...>...</svg>) on the smartboard that directly illustrates this syllabus concept.`);
      }

      const response = await generateAIResponse(promptQuery, {
        systemInstruction,
        model: 'gemini-3.1-flash-lite',
        language: isHindi ? 'hi' : (langObj?.code || 'en')
      });

      const cleaned = cleanNaturalLanguageForScreen(response);
      let newBoard = cleaned;
      if (!newBoard || newBoard.trim().length < 40) {
        newBoard = buildStandardOmniStudyContent(topicName, cleaned, isHindi ? 'hi' : 'en', effectiveIsIntro);
      } else if (!newBoard.includes('<svg') || !newBoard.includes('</svg>')) {
        const fallbackSvg = generateTopicSvgDiagram(topicName, userSubject || 'physics');
        if (fallbackSvg) {
          newBoard = `${newBoard}\n\n### 🎨 Scientific Vector Diagram\n${fallbackSvg}\n`;
        }
      }
      const finalBoard = cleanNaturalLanguageForScreen(newBoard);
      preparedBoardRef.current = finalBoard;

      // Task completed: change "professor is coming soon" into "professor is behind the screen"
      setIsLoadingAi(false);
      setProfessorStatus('behind_screen');

      const readyBoard = ensurePromptHeaderInContent(finalBoard, selectedPromptText);
      setBoardContent(readyBoard);
      setTypedBoardContent('');

      playSoundEffect('chime');
      showNotification?.(`Working on selected chapter: "${topicName}" - professor is behind the screen. Click START / PLAY to begin!`, 'success');

      // Start synchronized lecture ONLY IF user already clicked START / PLAY
      if (userClickedStartRef.current) {
        userClickedStartRef.current = false;
        setTimeout(() => {
          setProfessorStatus('teaching');
          setBoardContent(finalBoard);
          setAiResponseText(finalBoard);
          startSynchronizedLecture(finalBoard);
        }, 300);
      }
    } catch (err: any) {
      console.warn("Custom topic generation falling back to curriculum engine:", err?.message || err);
      const cleanFallback = buildStandardOmniStudyContent(topicName, undefined, isHindi ? 'hi' : 'en');

      // Task completed on fallback:
      setIsLoadingAi(false);
      preparedBoardRef.current = cleanFallback;
      setProfessorStatus('behind_screen');

      const readyFallback = ensurePromptHeaderInContent(cleanFallback, selectedPromptText);
      setBoardContent(readyFallback);
      setTypedBoardContent('');

      playSoundEffect('chime');
      showNotification?.(`Working on selected chapter: "${topicName}" - master curriculum engine ready behind the screen. Click START / PLAY to begin!`, 'success');

      // Start synchronized lecture ONLY IF user already clicked START / PLAY
      if (userClickedStartRef.current) {
        userClickedStartRef.current = false;
        setTimeout(() => {
          setProfessorStatus('teaching');
          setBoardContent(cleanFallback);
          setAiResponseText(cleanFallback);
          startSynchronizedLecture(cleanFallback);
        }, 300);
      }
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Handle language change with instant sync and lecture translation
  const handleLanguageChange = (langInput: string) => {
    const matched = resolveLanguageObject(langInput);
    const targetName = matched.name;
    setSelectedLanguage(targetName);
    setSelectedLectureLanguage(targetName);
    onSelectLanguage?.(matched.code);
    showNotification?.(
      matched.code === 'hi' 
        ? "व्याख्यान भाषा हिन्दी सेट की गई है। नया व्याख्यान तैयार किया जा रहा है..." 
        : `Lecture language set to ${targetName}. Loading lesson...`, 
      'info'
    );
    const currentTopic = activeTopicTitle || userTopic || 'Thermodynamics & Heat Engines';
    handleSelectCustomTopic(currentTopic, false, isLectureActive, targetName);
  };

  // Synchronize when language prop changes from outside (e.g. TopNav)
  useEffect(() => {
    if (language) {
      const match = resolveLanguageObject(language);
      const targetName = match.name;
      setSelectedLectureLanguage(targetName);
      setSelectedLanguage(targetName);

      if (match.code === 'hi') {
        const currentTopic = activeTopicTitle || userTopic || 'Thermodynamics & Heat Engines';
        handleSelectCustomTopic(currentTopic, false, false, targetName);
      }
    }
  }, [language]);

  // Generate AI Figure / Photo / Diagram on Virtual 3D Smartboard via Nano Banana 2
  const handleGenerateAiFigureDrawing = async () => {
    setIsLoadingAi(true);
    playSoundEffect('chalk');
    showNotification?.(`Calibrating 3D scene lighting (${lightingPreset}) for Nano Banana 2 image generation...`, 'info');

    try {
      // 1. Generate high-resolution photo/diagram image via Nano Banana 2 with automated scene lighting calibration
      const nanoBananaImg = await generateImage(
        `High-resolution clean 2D vector scientific photo diagram and educational schematic illustrating ${activeTopicTitle}. Clean minimalist dark slate background, crisp multi-color lines, clear scientific callouts with arrows, accurate formula boxes and annotated parts, professional textbook diagram, zero photographic wooden frames, zero hands.`,
        { aspectRatio: '16:9', lightingPreset }
      );

      // 2. Generate vector schematic
      const prompt = "Generate a detailed visual vector figure drawing (SVG format) illustrating " + activeTopicTitle + " for our 3D Classroom smartboard using " + selectedTeacherStyle.name + "'s Dynamic Figure Teaching principles. Return a valid raw inline <svg viewBox=\"0 0 600 280\" xmlns=\"http://www.w3.org/2000/svg\" style=\"max-width:100%; height:auto; background:#061a12; border:1px solid #1e293b; border-radius:16px; padding:12px; margin:12px 0;\">...</svg> with clean stroke-by-stroke paths, clear color coding (#FACC15 Sun/Energy, #38BDF8 Water/Fluid, #A855F7 Gas/CO2, #34D399 Product/Glucose, #FB7185 Oxygen), labelled elements (A, B, C, D, E), flow arrows, animated dash-arrays or pulse glows, and a 2-sentence mathematical caption explaining the visual figure.";

      const svgDrawing = await generateAIResponse(prompt, {
        systemInstruction: "You are " + selectedTeacherStyle.name + "'s scientific illustrator with Nano Banana 2 precision. Produce a valid, complete inline SVG drawing.",
        model: 'gemini-3.1-flash-lite'
      });

      let contentToAdd = `\n\n### 🎨 Figure & Diagram (Nano Banana 2 - ${lightingPreset.toUpperCase()} Calibrated): ${activeTopicTitle}\n`;
      if (nanoBananaImg) {
        contentToAdd += `![Nano Banana 2 Visual Figure: ${activeTopicTitle}](${nanoBananaImg})\n\n`;
      }
      contentToAdd += svgDrawing;

      setBoardContent(prev => `${prev}${contentToAdd}`);
      showNotification?.(`Nano Banana 2 image & diagram generated with ${lightingPreset.toUpperCase()} lighting calibration!`, 'success');
      playSoundEffect('chime');
    } catch (err) {
      console.error("Failed to generate AI drawing:", err);
      showNotification?.("Failed to generate figure drawing. Please try again.", 'error');
    } finally {
      setIsLoadingAi(false);
    }
  };

  // =========================================================================
  // VIRTUAL 3D BACKEND HANDLERS (DECOUPLED FROM SMARTBOARD)
  // =========================================================================

  // 1. AI Draw Vector Studio from Backend
  const handleTriggerAiDrawFromBackend = async () => {
    setIsLoadingAiDraw(true);
    setShowAiDrawStudioModal(true);
    playSoundEffect('chalk');
    showNotification?.(`Generating vector figure for "${activeTopicTitle}" with ${lightingPreset.toUpperCase()} lighting calibration...`, 'info');

    try {
      const result = await fetchVirtual3dAiDraw(activeTopicTitle, userSubject, typedBoardContent || boardContent, lightingPreset);
      setAiDrawResult(result);
      showNotification?.("AI vector figure loaded in Studio Inspector (Smartboard Preserved)!", 'success');
      playSoundEffect('chime');
    } catch (err) {
      console.error("Failed to generate AI drawing from backend:", err);
      showNotification?.("Displaying visual figure schema in Studio Inspector.", 'info');
    } finally {
      setIsLoadingAiDraw(false);
    }
  };

  // 2. Master Rule System Awareness from Backend
  const handleOpenMasterRuleFromBackend = async () => {
    setShowMasterRuleModal(true);
    playSoundEffect('chime');
    setIsLoadingMasterRule(true);
    try {
      const data = await fetchVirtual3dMasterRule(activeTopicTitle, userSubject, typedBoardContent || boardContent);
      setMasterRuleData(data);
    } catch (err) {
      console.warn("Backend master rule fallback", err);
    } finally {
      setIsLoadingMasterRule(false);
    }
  };

  // 3. Executive Multi-Layer Summary from Backend
  const handleOpenExecutiveSummaryFromBackend = async () => {
    setShowProfessorSummaryModal(true);
    playSoundEffect('chime');
    setIsLoadingExecutiveSummary(true);
    try {
      const data = await fetchVirtual3dExecutiveSummary(activeTopicTitle, userSubject, typedBoardContent || boardContent);
      setExecutiveSummaryData(data);
    } catch (err) {
      console.warn("Backend executive summary fallback", err);
    } finally {
      setIsLoadingExecutiveSummary(false);
    }
  };

  // 4. 30s Rapid Lightning Recap from Backend
  const handleOpen30sRecapFromBackend = async () => {
    setShow30sLightningRecap(true);
    playSoundEffect('chime');
    setIsLoadingRecap30s(true);
    try {
      const data = await fetchVirtual3dRecap30s(activeTopicTitle, userSubject);
      setRecap30sData(data);
      if (classroomVoiceOver && data?.spokenScript) {
        speakTutorMessage(data.spokenScript);
      }
    } catch (err) {
      console.warn("Backend 30s recap fallback", err);
    } finally {
      setIsLoadingRecap30s(false);
    }
  };

  const handleOpenExecutiveSummary = handleOpenExecutiveSummaryFromBackend;
  const handleOpen30sRecap = handleOpen30sRecapFromBackend;

  // 5. 5-Minute Deep Recap from Backend
  const handleOpenDeepRecapFromBackend = async () => {
    setShow5minDeepRecap(true);
    playSoundEffect('chime');
    setIsLoadingDeepRecap(true);
    try {
      const data = await fetchVirtual3dDeepRecap(activeTopicTitle, userSubject);
      setDeepRecapData(data);
    } catch (err) {
      console.warn("Backend deep recap fallback", err);
    } finally {
      setIsLoadingDeepRecap(false);
    }
  };

  // 6. Visual Transformation Studio from Backend
  const handleOpenTransformationStudioFromBackend = () => {
    setShowVisualTransformationModal(true);
    playSoundEffect('chime');
    showNotification?.("Visual Transformation Studio opened (Smartboard Preserved)!", 'info');
  };

  // 7. Reset Server & State Health from Backend
  const handleResetHealthFromBackend = async () => {
    setIsResettingHealth(true);
    playSoundEffect('click');
    try {
      const report = await resetVirtual3dHealth();
      showNotification?.(`Server & State Health Reset: 100% Validated (Freed: ${report.freedHeapMb}MB)!`, 'success');
      playSoundEffect('chime');
      setShowReactHealthModal(true);
    } catch (err) {
      showNotification?.("Server health calibrated & loop-proofed.", 'success');
      setShowReactHealthModal(true);
    } finally {
      setIsResettingHealth(false);
    }
  };

  // Sync when userTopic prop changes externally (e.g. from Sidebar Active Subject Lesson dropdown)
  const prevUserTopicRef = useRef<string>(userTopic || '');
  useEffect(() => {
    if (userTopic && userTopic.trim() !== '' && userTopic !== 'None' && userTopic !== prevUserTopicRef.current) {
      prevUserTopicRef.current = userTopic;
      if (userTopic !== activeTopicTitle) {
        handleStageSelectedChapter(userTopic);
      }
    }
  }, [userTopic, activeTopicTitle]);

  // Start / Pause / Resume Virtual Learning Interactive Lecture
  const handleStartVirtualLearning = () => {
    // Immediate browser audio & speech synthesis context unlock on user interaction
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      }
    } catch (err) {
      console.warn('Speech synthesis resume check:', err);
    }

    // Always reset smartboard position to reset state (Docked Left, Front Row Camera)
    resetSmartboardPosition();

    // 1. If lecture is currently active, handle pause/resume
    if (isLectureActive) {
      if (isLecturePaused) {
        resumeSynchronizedLecture();
      } else {
        pauseSynchronizedLecture();
      }
      return;
    }

    // 2. If content is already prepared ("behind_screen") or displayed on smartboard:
    if ((professorStatus === 'behind_screen' || boardContent) && (preparedBoardRef.current || boardContent)) {
      const contentToTeach = preparedBoardRef.current || boardContent;
      if (contentToTeach && contentToTeach.length > 80 && !contentToTeach.includes('professor is coming soon')) {
        const topicToStart = activeTopicTitle || stagedTopicTitle || userTopic || 'Interactive Science';
        setIsInitializingLecture(true);
        playLessonInitializingCue(0.4);
        showNotification?.(`Starting lecture on "${topicToStart}" with ${selectedTeacherStyle.name} 🎓`, "info");

        setTimeout(() => {
          setIsInitializingLecture(false);
          setProfessorStatus('teaching');
          setBoardContent(contentToTeach);
          setAiResponseText(contentToTeach);
          startSynchronizedLecture(contentToTeach);
        }, 250);
        return;
      }
    }

    // 3. If currently in progress of preparing lecture ("coming_soon"):
    if (professorStatus === 'coming_soon' || isLoadingAi) {
      userClickedStartRef.current = true;
      playLessonInitializingCue(0.3);
      showNotification?.(`Lecture will begin as soon as ${selectedTeacherStyle.name} finishes preparing "${activeTopicTitle || stagedTopicTitle}"! ${selectedTeacherStyle.avatarIcon}`, 'info');
      return;
    }

    // 4. User clicked Start/Play when idle or selected: begin preparation and start lecture!
    const topicToStart = stagedTopicTitle || activeTopicTitle || userTopic || 'Interactive Science';
    setStagedTopicTitle(null);
    userClickedStartRef.current = true;

    setIsInitializingLecture(true);
    playLessonInitializingCue(0.4);
    showNotification?.(`Starting lecture on "${topicToStart}" 🎓`, "info");

    setTimeout(() => {
      setIsInitializingLecture(false);
      handleSelectCustomTopic(topicToStart, true, true);
    }, 250);
  };

  // Clear Active Topic, Reset Smartboard Content, and Stop Audio Narration
  const handleClearTopicAndSmartboard = () => {
    // 1. Immediately stop any active lecture, speech synthesis, typewriter timers, or audio elements
    stopSpeech();

    // 2. Stop microphone listening if active
    setIsListening(false);

    // 3. Clear AI search and prompt states
    setUserPrompt('');
    setIsLoadingAi(false);

    // 4. Clear attached file uploads and reset file input
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    // 5. Update topic references so external sync does not re-trigger
    prevUserTopicRef.current = 'None';
    setActiveTopicTitle('None');
    setStagedTopicTitle(null);
    setStagedLessonIdx(null);
    onSelectTopic?.('None');

    // 6. Reset smartboard position and text: MUST clear typedBoardContent so fallback text renders immediately
    resetSmartboardPosition();
    setTypedBoardContent('');
    setBoardContent('### Smartboard Reset\n*Smartboard in reset position. Select a chapter/topic and click the green START button on the toolbar below to begin 3D Virtual Learning.*');
    setAiResponseText('Welcome to Virtual Learning! Search or select any topic to begin.');

    // 7. Clear sync steps, active phase badge, and figures
    setCurrentSyncStep(0);
    setTotalSyncSteps(0);
    setActivePhaseTitle('');
    setDockSelectedFigure(null);

    // 8. Scroll smartboard back to top cleanly
    if (boardScrollContainerRef.current) {
      boardScrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // 9. Reset avatar posture to relaxed seated position
    try {
      avatarEngine.setZone('smartboard', false);
      avatarEngine.triggerGesture('remain_seated', 1.0, 'subtle');
    } catch (e) {}

    // 10. Audio click cue and user feedback
    playSoundEffect('click');
    showNotification?.("Cleared active topic, reset smartboard, and stopped audio narration", "info");
  };

  // Ask AI Tutor a Question or Search Topic
  const handleAskTutor = async (customQuery?: string) => {
    const rawQuery = (typeof customQuery === 'string' && customQuery.trim()) ? customQuery.trim() : userPrompt.trim();
    if (!rawQuery && !selectedFile) return;

    const query = rawQuery || "Analyze the attached file and explain key concepts in 3D";
    const attached = selectedFile;
    setUserPrompt('');
    setSelectedFile(null);
    setIsLoadingAi(true);
    playSoundEffect('chalk');

    // Dynamic Teacher Style Switch Detection
    const detectedStyle = detectTeacherStyleFromQuery(query);
    let activeTeacher = selectedTeacherStyle;
    if (detectedStyle && detectedStyle.id !== selectedTeacherStyle.id) {
      activeTeacher = detectedStyle;
      setSelectedTeacherStyle(detectedStyle);
      try {
        localStorage.setItem('3d_classroom_teacher_style', detectedStyle.id);
      } catch (e) {}
      showNotification?.(`Switched teaching style to ${detectedStyle.name} (${detectedStyle.tagline})! ${detectedStyle.avatarIcon}`, 'success');
      playSoundEffect('chime');
    }

    const langObj = resolveLanguageObject(selectedLectureLanguage || selectedLanguage || language);
    const currentLangName = langObj ? langObj.name : 'English';
    const currentLangNative = langObj?.native || currentLangName;
    const isHindi = currentLangName.toLowerCase() === 'hindi' || langObj?.code === 'hi' || langObj?.code === 'hinglish';

    try {
      const modePrompt = 
        chatMode === 'socratic' ? 'Guide the student with thoughtful Socratic questions.' :
        chatMode === 'step_by_step' ? 'Break down the explanation into clear step-by-step logical bullet points.' :
        chatMode === 'direct' ? 'Provide a direct, concise, and rigorous solution immediately.' :
        'Respond enthusiastically as an inspiring research professor.';

      const isSilentDraw = silentDraw || localStorage.getItem('omni_silent_draw') === 'true';
      const silentDrawRule = isSilentDraw
        ? "SILENT-DRAW MODE ACTIVE: You MUST automatically generate and embed a clean inline SVG figure (<svg viewBox=\"0 0 1000 500\" width=\"100%\" height=\"100%\" xmlns=\"http://www.w3.org/2000/svg\">...</svg>) and rendered LaTeX block diagrams ($$...$$) for all visual concepts or mathematical topics without requiring explicit text triggers."
        : "SILENT-DRAW MODE INACTIVE: Do not automatically generate SVG figures unless explicitly requested by text.";

      const svgPlacementRule = `MANDATORY DYNAMIC SVG FIGURE MANDATE:
When teaching this question on the 3D Classroom smartboard, you MUST generate and embed a complete, valid inline <svg viewBox="0 0 700 300" width="100%" height="auto" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#070d1e; border:1.5px solid #38bdf8; border-radius:16px; padding:12px; margin:16px 0;">...</svg> element directly within your explanation.
The SVG figure MUST visually illustrate what is asked in the question (such as physical vectors, wave optics, ray diagrams, electric field lines, circuit schematic, molecular structure, graph, geometric setup, or labeled biological process with labeled parts A, B, C).
Use clean modern colors (#38BDF8, #FACC15, #34D399, #FB7185, #A855F7, #60A5FA), clear markers/arrows, labeled parts, and text annotations so the 3D professor and student can refer to the figure during the explanation.`;

      const langDirective = isHindi
        ? `CRITICAL HINDI LANGUAGE MANDATE: You MUST respond entirely in fluent, authentic HINDI (हिन्दी) using Devanagari script. Do NOT output English sentences.`
        : `CRITICAL LANGUAGE DIRECTIVE: You MUST respond entirely in "${currentLangName}" (${currentLangNative}). Do not output English unless mathematical symbols require it.`;

      const isNumQuery = isNumericalRequest(query);

      const systemInstruction = `You are ${activeTeacher.name}, the Master AI Educator in an interactive 3D virtual lecture hall.
The student is asking: "${query}".
Teaching Persona: ${activeTeacher.tagline} (${activeTeacher.badge})
Persona Style Directive: ${activeTeacher.promptDirective || ''}
Persona Mode: ${modePrompt}
${langDirective}
Academic Rigor Level: ${academicRigor.toUpperCase()} Grade.

TEACH ACCORDING TO WHAT IS ASKED IN THE QUESTION WITH ACTIVE PEDAGOGY AND SVG:
1. Focus 100% on teaching and answering what is asked in: "${query}".
2. Adopt the authentic tone, analogies, catchphrases, and teaching philosophy of ${activeTeacher.name}.
3. Do NOT follow rigid boilerplate sections; teach what is asked in the question directly with deep pedagogical clarity in natural ${currentLangName} for a student (human being).
${isNumQuery 
  ? `4. STRICT NUMERICAL DEMAND MANDATE: The user explicitly requested numerical questions / problem solving. START IMMEDIATELY WITH THE NUMERICAL QUESTION / PROBLEM STATEMENT, GIVEN VALUES, FORMULA, STEP-BY-STEP CALCULATION, AND FINAL ANSWER. DO NOT INSERT AN INTRODUCTORY LECTURE OR PREAMBLE.`
  : `4. Use Active Pedagogy: Start with the intuitive concept and a relatable real-world analogy.`}
5. Provide the exact mathematical formulation / governing equations in clear LaTeX ($...$ inline, $$...$$ block).
6. EMBED AN INLINE SVG FIGURE: Always include a detailed, clean inline <svg> diagram illustrating the exact setup, vectors, or mechanism of the question.
7. Provide a clear, step-by-step worked solution / logical derivation answering the question with units and final result.
8. End with a Key Takeaway / Golden Exam Trap.

STRICT ZERO MACHINE LANGUAGE MANDATE: Output 100% natural, human educational language for a student only. Never output bracketed commands, stage directives, timing tags, or pseudo-code like [AVATAR:...], [SMARTBOARD:...], [Type:...], or [Action:...]. Never pronounce or write formatting symbol names.
${svgPlacementRule}`;

      let contents: any = undefined;
      if (attached) {
        const mimeType = attached.type || 'image/png';
        const base64Data = attached.previewUrl.split(',')[1] || '';
        contents = {
          parts: [
            { inlineData: { data: base64Data, mimeType } },
            { text: query }
          ]
        };
      }

      const response = await generateAIResponse(query, {
        systemInstruction,
        model: 'gemini-3.1-flash-lite',
        language: isHindi ? 'hi' : (langObj?.code || 'en'),
        ...(contents ? { contents } : {})
      });

      let cleanedResponse = cleanNaturalLanguageForScreen(response);
      if (!cleanedResponse.includes('<svg') || !cleanedResponse.includes('</svg>')) {
        const questionSvg = generateTopicSvgDiagram(query, userSubject || 'physics');
        if (questionSvg) {
          cleanedResponse = `${cleanedResponse}\n\n### 🎨 Diagrammatic Illustration: ${query}\n${questionSvg}\n`;
        }
      }
      setAiResponseText(cleanedResponse);
      const formattedQABoard = cleanNaturalLanguageForScreen(`### ❓ Question & Academic Answer: ${query}\n\n${cleanedResponse}`);
      setBoardContent(formattedQABoard);
      setProfessorStatus('teaching');
      speakTutorMessage(cleanedResponse);
      showNotification?.(`3D Professor is teaching: "${query.slice(0, 35)}..."!`, 'success');
    } catch (err: any) {
      console.error("AI Tutor response error:", err);
      const fallbackSvg = generateTopicSvgDiagram(query, userSubject || 'physics');
      const fallback = buildStandardOmniStudyContent(query, undefined, isHindi ? 'hi' : 'en', false);
      setAiResponseText(fallback);
      setBoardContent(cleanNaturalLanguageForScreen(fallback));
      setProfessorStatus('teaching');
      speakTutorMessage(fallback);
      showNotification?.(`Displaying master curriculum lecture for: "${query.slice(0, 35)}..."`, 'info');
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Specialized Figure Deep-Dive Pedagogical Handler for 3D Virtual Classroom
  const handleExplainFigureIn3D = useCallback((svgCodeOrImage: string, title?: string, isNanoBanana?: boolean) => {
    const isSvg = typeof svgCodeOrImage === 'string' && svgCodeOrImage.includes('<svg');
    let labelsContext = '';
    if (isSvg) {
      const textMatches = Array.from(svgCodeOrImage.matchAll(/<text[^>]*>([\s\S]*?)<\/text>/gi))
        .map(m => m[1]?.replace(/<[^>]+>/g, '').trim())
        .filter(t => t && t.length > 0 && !t.startsWith('var ') && !t.includes('function') && t.length < 60);

      const uniqueLabels = Array.from(new Set(textMatches)).slice(0, 15);
      if (uniqueLabels.length > 0) {
        labelsContext = `\nKey visual components and labels extracted from this schematic: ${uniqueLabels.join(', ')}.`;
      }
    }

    const diagramTitle = title || activeTopicTitle || (isNanoBanana ? 'Nano Banana 2 Scientific Figure' : 'Smartboard Visual Schematic');
    const visualEngineNote = isNanoBanana ? ' (generated with Nano Banana 2 high-definition visual engine)' : '';

    const explanationPrompt = `Please give me a specialized pedagogical deep-dive explanation of this figure${visualEngineNote}: "${diagramTitle}".${labelsContext}

Please structure your explanation as follows:
1. Visual Overview & Mental Model: What this diagram illustrates and the core intuition behind it.
2. Label & Component Breakdown: What each arrow, ray, angle, medium, boundary, or component in the figure represents.
3. Core Physical & Mathematical Principles: The fundamental equations, laws, and mathematical relations illustrated by this visual.
4. Step-by-Step Flow: How rays, forces, energy, or parameters travel or transform through the figure.
5. Examiner Traps & Common Misconceptions: Crucial points students often confuse about this specific diagram in exams.`;

    handleAskTutor(explanationPrompt);
    showNotification?.(`3D Professor analyzing figure: "${diagramTitle}"...`, 'info');
  }, [activeTopicTitle, handleAskTutor, showNotification]);

  useEffect(() => {
    const handleExplainFigure3DEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ svgCode?: string; imageUrl?: string; title?: string; isNanoBanana?: boolean }>;
      const payload = customEvent.detail?.imageUrl || customEvent.detail?.svgCode;
      if (payload) {
        handleExplainFigureIn3D(payload, customEvent.detail.title, customEvent.detail.isNanoBanana);
      }
    };
    window.addEventListener('omni:explain-figure', handleExplainFigure3DEvent);
    return () => {
      window.removeEventListener('omni:explain-figure', handleExplainFigure3DEvent);
    };
  }, [handleExplainFigureIn3D]);

  // SPQ - Solved Practice Questions: System explains answers to questions of the current lecture
  const handleSolvePracticeQuestions = () => {
    playSoundEffect('chalk');
    const topic = activeTopicTitle || userTopic || userSubject || 'Current Lesson';
    
    // Extract questions context from the smartboard content
    let questionContext = '';
    if (boardContent && boardContent.length > 50) {
      const lower = boardContent.toLowerCase();
      const qIdx = Math.max(
        lower.indexOf('practice question'),
        lower.indexOf('suggested question'),
        lower.indexOf('questions for you'),
        lower.indexOf('questions:'),
        lower.indexOf('exercises:')
      );
      if (qIdx !== -1) {
        questionContext = `\n\nQuestions on smartboard to solve:\n"""\n${boardContent.slice(qIdx, qIdx + 1500)}\n"""`;
      } else {
        questionContext = `\n\nLesson content context:\n"""\n${boardContent.slice(0, 1000)}\n"""`;
      }
    }

    const query = `Provide comprehensive, step-by-step solved solutions and thorough explanations for all the practice questions and exercises of "${topic}".
The professors should teach with a degree of STANDARD depth/rigor. Tutor Rigor Instructions: Provide a standard, granular, step-by-step academic explanation. Explain definitions, list equations, detail all complete concrete worked-out answers of the questions with intermediate steps, and. Please proceed to teach the questions now with high quality and formatting.
Work out every problem step-by-step with formulas in LaTeX, calculations, final answers, and clear conceptual explanations.${questionContext}`;

    showNotification?.(`Professor is explaining the answers to the practice questions for ${topic}! 📝`, 'success');
    handleAskTutor(query);
  };

  // Web Speech Recognition for Voice Q&A
  const toggleSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showNotification?.("Speech recognition not supported in this browser", 'error');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      const langObj = resolveLanguageObject(selectedLectureLanguage || selectedLanguage || language);
      const targetLangCode = langObj ? langObj.code : 'en';
      recognition.lang = (targetLangCode === 'hi' || targetLangCode === 'hinglish') ? 'hi-IN' : targetLangCode;
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        playSoundEffect('click');
        showNotification?.("Listening to your question...", 'info');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setUserPrompt(transcript);
        setIsListening(false);
        showNotification?.(`Transcribed: "${transcript}"`, 'success');
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (e) {
      console.error(e);
      setIsListening(false);
    }
  };

  // Interactive Reagent Mixer
  const handleMixReagents = () => {
    const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#ef4444'];
    const nextColor = colors[(colors.indexOf(beakerLiquidColor) + 1) % colors.length];
    setBeakerLiquidColor(nextColor);
    playSoundEffect('burner');
    showNotification?.(`Mixed new chemical indicator solution (Color: ${nextColor})`, 'info');
  };

  // Interactive Nano Banana Rigid-Body Physics Handlers
  const handleTossBananaFromCamera = (speed: number = 14) => {
    if (cameraRef.current) {
      nanoBananaPhysics.tossFromCamera(cameraRef.current, speed);
      showNotification?.("🍌 Nano Banana tossed into 3D Classroom! Physical collision active.", "success");
      playSoundEffect('cradle');
    }
  };

  const handleTossBananaAtTarget = (target: 'smartboard' | 'teacher_desk' | 'lab_bench' | 'center_floor') => {
    nanoBananaPhysics.tossAtTarget(target);
    const targetNames = {
      smartboard: 'Smartboard',
      teacher_desk: 'Teacher Desk',
      lab_bench: 'Science Lab Bench',
      center_floor: 'Classroom Floor'
    };
    showNotification?.(`🍌 Nano Banana launched at ${targetNames[target]}!`, 'info');
    playSoundEffect('cradle');
  };

  const handleSpawnBananaRain = (count: number = 8) => {
    nanoBananaPhysics.spawnRain(count);
    showNotification?.(`🌧️ Shower of ${count} Nano Bananas falling into Classroom!`, 'success');
    playSoundEffect('chime');
  };

  const handleBananaShockwave = () => {
    nanoBananaPhysics.applyExplosionForce(new THREE.Vector3(0, 1.0, 0), 20, 8.0);
    showNotification?.("💥 Shockwave blast triggered! Bananas ricocheting across classroom!", "warning");
    playSoundEffect('chime');
  };

  const handleClearBananas = () => {
    nanoBananaPhysics.clearAll();
    showNotification?.("🧹 All Nano Bananas cleared from classroom.", "info");
  };

  // Minimalist 3D UI State: Smart Command Palette & Context Radial Menu
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [isRadialMenuOpen, setIsRadialMenuOpen] = useState<boolean>(false);
  const [radialMenuPosition, setRadialMenuPosition] = useState<{ x: number; y: number }>({ x: 300, y: 300 });

  // Keyboard Shortcuts & Gesture Bindings for Minimal 3D Controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;

      // 'B' key shortcut -> Toss Nano Banana with rigid-body physics
      if (e.key === 'b' || e.key === 'B') {
        if (!e.ctrlKey && !e.metaKey && !e.altKey) {
          e.preventDefault();
          handleTossBananaFromCamera();
          return;
        }
      }

      // Ctrl+R / Cmd+R -> Screen recording trigger
      if ((e.ctrlKey || e.metaKey) && (e.key === 'r' || e.key === 'R')) {
        e.preventDefault();
        if (screenRecordingState === 'recording') {
          stopScreenRecording();
        } else {
          startScreenRecording();
        }
        return;
      }

      if (e.key === '/') {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      } else if (e.key === 'n' || e.key === 'N') {
        setIsSmartboardNotesMinimized(prev => !prev);
      } else if (e.key === 'f' || e.key === 'F') {
        toggleMaximizeLectureHall();
      } else if (e.code === 'Space') {
        e.preventDefault();
        handleStartVirtualLearning();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [toggleMaximizeLectureHall, isLectureActive, isLecturePaused, screenRecordingState]);

  // Command Palette Items (Exposes 100% of all features via "/" shortcut)
  const allPaletteCommands: CommandItem[] = useMemo(() => [
    // 1. Lecture Navigation & Control
    {
      id: 'tools_quad_speed_sync',
      title: 'Quad-Speed Synchronization Hub (Typing, Pronouncing, Visualizing, Scrolling)',
      category: 'Lecture',
      icon: <Sliders size={18} />,
      keywords: ['speed', 'pace', 'synchronization', 'typing', 'pronouncing', 'scrolling', 'visualizing', 'harmonic', 'rate'],
      shortcut: 'S',
      action: () => setShowQuadSpeedModal(true),
    },
    {
      id: 'lecture_play_pause',
      title: isLectureActive && !isLecturePaused ? 'Pause Lecture' : 'Play / Resume Lecture',
      category: 'Lecture',
      icon: isLectureActive && !isLecturePaused ? <Pause size={18} /> : <Play size={18} />,
      keywords: ['play', 'pause', 'resume', 'lecture', 'start', 'audio'],
      shortcut: 'Space',
      action: handleStartVirtualLearning,
    },
    {
      id: 'lecture_replay',
      title: 'Replay Lecture from Start',
      category: 'Lecture',
      icon: <RotateCcw size={18} />,
      keywords: ['replay', 'restart', 'beginning', 'rewind'],
      action: replaySynchronizedLecture,
    },
    {
      id: 'lecture_skip_full',
      title: 'Reveal Complete Smartboard Content',
      category: 'Lecture',
      icon: <FastForward size={18} />,
      keywords: ['reveal', 'skip', 'complete', 'all', 'full', 'instant'],
      action: skipSynchronizedLectureToFull,
    },
    {
      id: 'lecture_change_topic',
      title: 'Browse & Select Lesson Topic',
      category: 'Lecture',
      icon: <BookOpen size={18} />,
      keywords: ['topic', 'lesson', 'curriculum', 'change', 'browse', 'select'],
      shortcut: 'T',
      action: () => setShowTopicModal(true),
    },
    {
      id: 'lecture_clear_topic',
      title: 'Clear Topic & Reset Smartboard',
      category: 'Lecture',
      icon: <Trash2 size={18} />,
      keywords: ['clear', 'reset', 'clean', 'erase', 'wipe'],
      action: handleClearTopicAndSmartboard,
    },

    // 2. Pedagogy & Teaching Techniques
    {
      id: 'pedagogy_style',
      title: 'Teacher Styles: "Teach Me Like..."',
      category: 'Pedagogy',
      icon: <User size={18} />,
      keywords: ['feynman', 'sagan', 'huber', 'style', 'pedagogy', 'teacher', 'voice'],
      action: () => setShowTeacherStyleModal(true),
    },
    {
      id: 'pedagogy_formula_mastery',
      title: '10-Step Formula Mastery Framework',
      category: 'Pedagogy',
      icon: <Calculator size={18} />,
      keywords: ['formula', 'math', 'derivation', 'equation', 'steps', 'mastery'],
      action: () => setShowFormulaModal(true),
    },
    {
      id: 'virtual3d_ai_draw',
      title: 'AI Draw Vector Figure Studio (Backend)',
      category: 'Tools',
      icon: <Sparkles size={18} />,
      keywords: ['ai', 'draw', 'vector', 'svg', 'figure', 'diagram', 'backend'],
      shortcut: 'D',
      action: handleTriggerAiDrawFromBackend,
    },
    {
      id: 'pedagogy_30s_recap',
      title: '30-Second Lightning Concept Recap (Backend)',
      category: 'Pedagogy',
      icon: <Zap size={18} />,
      keywords: ['recap', '30s', 'lightning', 'quick', 'summary', 'speed', 'backend'],
      action: handleOpen30sRecapFromBackend,
    },
    {
      id: 'clarity_debugger_suite',
      title: 'Debug Professor Clarity: Self-Healing & Diagnostics Studio',
      category: 'Tools',
      icon: <ShieldCheck size={18} />,
      keywords: ['debug', 'debugger', 'health', 'diagnostics', 'playbooks', 'clarity', 'self-healing', 'repair', 'tests'],
      action: () => setShowDebuggerModal(true),
    },
    {
      id: 'pedagogy_5min_recap',
      title: '5-Minute Deep Dive Chapter Recap (Backend)',
      category: 'Pedagogy',
      icon: <Activity size={18} />,
      keywords: ['recap', '5min', 'deep', 'dive', 'comprehensive', 'chapter', 'backend'],
      action: handleOpenDeepRecapFromBackend,
    },
    {
      id: 'pedagogy_master_rule',
      title: 'Master Rule System Awareness Hub (Backend)',
      category: 'Pedagogy',
      icon: <GraduationCap size={18} />,
      keywords: ['master', 'rule', 'awareness', 'pedagogy', 'clarity', 'rules', 'backend'],
      action: handleOpenMasterRuleFromBackend,
    },
    {
      id: 'pedagogy_executive_summary',
      title: 'Executive Multi-Layer Study Summary (Backend)',
      category: 'Pedagogy',
      icon: <Layers size={18} />,
      keywords: ['summary', 'layers', 'executive', 'notes', 'study', 'backend'],
      action: handleOpenExecutiveSummaryFromBackend,
    },
    {
      id: 'pedagogy_pronunciation',
      title: 'Unit Pronunciation & Speech Trainer',
      category: 'Pedagogy',
      icon: <Sparkles size={18} />,
      keywords: ['pronunciation', 'speech', 'trainer', 'units', 'audio'],
      action: () => setShowPronunciationTrainerModal(true),
    },
    {
      id: 'pedagogy_content_curation',
      title: 'Content Collection & Curation Vault',
      category: 'Pedagogy',
      icon: <BookOpen size={18} />,
      keywords: ['content', 'curation', 'collection', 'pipeline', 'quality', 'adaptive', 'gaps', 'sources', 'library'],
      shortcut: 'C',
      action: () => setIsContentModalOpen(true),
    },
    {
      id: 'pedagogy_visual_map_studio',
      title: 'Visual Map & Schematic Breakdown Studio (8 Map Engines + Schematics)',
      category: 'Pedagogy',
      icon: <Sparkles size={18} />,
      keywords: ['map', 'concept', 'schematic', 'breakdown', 'flowchart', 'venn', 'mindmap', 'hierarchy', 'exploded', 'cutaway', 'cycle', 'timeline'],
      shortcut: 'M',
      action: () => setShowVisualMapStudioModal(true),
    },
    {
      id: 'pedagogy_visual_transformation',
      title: 'Visual Transformation Architect Studio (Backend)',
      category: 'Pedagogy',
      icon: <Sparkles size={18} />,
      keywords: ['transformation', 'table', 'visual', 'pedagogy', 'flow', 'flashcard', 'diagram', 'comparison', 'ploidy', 'fertilization', 'seed', 'fruit', 'architect'],
      shortcut: 'V',
      action: handleOpenTransformationStudioFromBackend,
    },
    {
      id: 'architecture_react_health',
      title: 'Reset Health & Server Diagnostics Studio (Backend)',
      category: 'Tools',
      icon: <ShieldCheck size={18} />,
      keywords: ['health', 'reset', 'react', 'state', 'server', 'hook', 'loop', 'infinite', 'useeffect', 'render', 'diagnostics', 'performance', 'profiler'],
      shortcut: 'H',
      action: handleResetHealthFromBackend,
    },
    {
      id: 'pedagogy_rapid_fire_drill',
      title: 'Professor Clarity 80–100 Question Rapid Fire Drill Studio',
      category: 'Pedagogy',
      icon: <Zap size={18} />,
      keywords: ['drill', 'rapid', 'fire', 'mcq', 'question', 'bank', '80', '100', 'exam', 'neet', 'board', 'quiz', 'socratic'],
      shortcut: 'Q',
      action: () => setShowRapidFireDrillModal(true),
    },
    {
      id: 'pedagogy_academic_questions',
      title: 'Academic Practice Question Vault (80–160 Questions & 4 Hints)',
      category: 'Pedagogy',
      icon: <BookOpen size={18} />,
      keywords: ['academic', 'questions', 'practice', '80', '160', 'hints', 'board', 'cbse', 'icse', 'state', 'exam'],
      shortcut: 'P',
      action: () => {
        setPracticeQuestionInitialMode('academic');
        setShowPracticeQuestionModal(true);
      },
    },
    {
      id: 'pedagogy_competitive_questions',
      title: 'Competitive Question Engine (420–580 Questions + 50 MCQs & Elimination Lab)',
      category: 'Pedagogy',
      icon: <Trophy size={18} />,
      keywords: ['competitive', 'jee', 'neet', 'aiims', '420', '580', 'mcq', 'elimination', 'questions', 'vault'],
      action: () => {
        setPracticeQuestionInitialMode('competitive');
        setShowPracticeQuestionModal(true);
      },
    },

    // 3. Display & Camera Presets
    {
      id: 'display_toggle_notes',
      title: isSmartboardNotesMinimized ? 'Expand Smartboard Notes' : 'Minimize Smartboard Notes',
      category: 'Display',
      icon: <FileText size={18} />,
      keywords: ['notes', 'smartboard', 'board', 'text', 'minimize', 'maximize'],
      shortcut: 'N',
      action: () => setIsSmartboardNotesMinimized(prev => !prev),
    },
    {
      id: 'display_fullscreen',
      title: isMaximized ? 'Exit Fullscreen' : 'Maximize Lecture Hall to Fullscreen',
      category: 'Display',
      icon: isMaximized ? <Minimize2 size={18} /> : <Maximize2 size={18} />,
      keywords: ['fullscreen', 'maximize', 'screen', 'expand'],
      shortcut: 'F',
      action: toggleMaximizeLectureHall,
    },
    {
      id: 'cam_front_row',
      title: 'Camera: Front Row View',
      category: 'Display',
      icon: <Camera size={18} />,
      keywords: ['camera', 'view', 'front', 'row', 'default'],
      action: () => setCameraView('front_row'),
    },
    {
      id: 'cam_professor_focus',
      title: 'Camera: Professor Clarity Focus',
      category: 'Display',
      icon: <Camera size={18} />,
      keywords: ['camera', 'view', 'professor', 'tutor', 'avatar'],
      action: () => setCameraView('professor_focus'),
    },
    {
      id: 'cam_board_focus',
      title: 'Camera: Smartboard Close-Up',
      category: 'Display',
      icon: <Camera size={18} />,
      keywords: ['camera', 'view', 'smartboard', 'chalkboard', 'board'],
      action: () => setCameraView('board_focus'),
    },
    {
      id: 'cam_figure_focus',
      title: 'Camera: Figure Diagram Focus',
      category: 'Display',
      icon: <Camera size={18} />,
      keywords: ['camera', 'view', 'figure', 'diagram', 'zoom'],
      action: () => setCameraView('figure_focus'),
    },
    {
      id: 'cam_lab_bench',
      title: 'Camera: Science Lab Bench View',
      category: 'Display',
      icon: <Camera size={18} />,
      keywords: ['camera', 'view', 'lab', 'bench', 'experiment'],
      action: () => setCameraView('lab_bench'),
    },
    {
      id: 'cam_overhead',
      title: 'Camera: Overhead Birdseye View',
      category: 'Display',
      icon: <Camera size={18} />,
      keywords: ['camera', 'view', 'overhead', 'top', 'birdseye'],
      action: () => setCameraView('overhead'),
    },
    {
      id: 'cam_free_orbit',
      title: 'Camera: Free Orbit Angle',
      category: 'Display',
      icon: <Camera size={18} />,
      keywords: ['camera', 'view', 'orbit', 'free', '3d'],
      action: () => setCameraView('free_orbit'),
    },

    // 4. Lab & 3D Science Experiments
    {
      id: 'lab_toggle_burner',
      title: isBurnerOn ? 'Extinguish Bunsen Burner' : 'Ignite Bunsen Burner Flame',
      category: 'Lab & 3D',
      icon: <Flame size={18} />,
      keywords: ['burner', 'bunsen', 'fire', 'flame', 'chemistry'],
      action: () => {
        setIsBurnerOn(prev => !prev);
        playSoundEffect('burner');
      },
    },
    {
      id: 'lab_toggle_laser',
      title: isLaserOn ? 'Turn Off Laser Prism' : 'Activate Laser Beam Refraction',
      category: 'Lab & 3D',
      icon: <Radio size={18} />,
      keywords: ['laser', 'prism', 'light', 'rainbow', 'refraction', 'optics'],
      action: () => {
        setIsLaserOn(prev => !prev);
        playSoundEffect('laser');
      },
    },
    {
      id: 'lab_toggle_cradle',
      title: isNewtonCradleSwinging ? 'Stop Newton’s Cradle' : 'Start Newton’s Cradle Momentum',
      category: 'Lab & 3D',
      icon: <Compass size={18} />,
      keywords: ['newton', 'cradle', 'physics', 'momentum', 'spheres'],
      action: () => {
        setIsNewtonCradleSwinging(prev => !prev);
        playSoundEffect('cradle');
      },
    },
    {
      id: 'lab_mix_reagent',
      title: 'Mix Chemical Indicator Solution',
      category: 'Lab & 3D',
      icon: <Sparkles size={18} />,
      keywords: ['mix', 'chemical', 'solution', 'reagent', 'beaker', 'color'],
      action: handleMixReagents,
    },
    {
      id: 'lab_holo_dna',
      title: 'Hologram: DNA Double Helix',
      category: 'Lab & 3D',
      icon: <Dna size={18} />,
      keywords: ['hologram', 'dna', 'biology', 'helix'],
      action: () => {
        setActiveHologram('dna');
        playSoundEffect('click');
      },
    },
    {
      id: 'lab_holo_atom',
      title: 'Hologram: Bohr Atomic Model',
      category: 'Lab & 3D',
      icon: <Atom size={18} />,
      keywords: ['hologram', 'atom', 'physics', 'bohr', 'electrons'],
      action: () => {
        setActiveHologram('atom');
        playSoundEffect('click');
      },
    },
    {
      id: 'lab_holo_planet',
      title: 'Hologram: Saturn Celestial Planet',
      category: 'Lab & 3D',
      icon: <Sun size={18} />,
      keywords: ['hologram', 'planet', 'saturn', 'astronomy', 'space'],
      action: () => {
        setActiveHologram('planet');
        playSoundEffect('click');
      },
    },
    {
      id: 'lab_holo_math',
      title: 'Hologram: Calculus Quadric Manifold',
      category: 'Lab & 3D',
      icon: <Sliders size={18} />,
      keywords: ['hologram', 'math', 'surface', 'manifold', 'geometry'],
      action: () => {
        setActiveHologram('math_surface');
        playSoundEffect('click');
      },
    },
    {
      id: 'lab_avatar_studio',
      title: 'Avatar Kinematics & Animation Studio',
      category: 'Lab & 3D',
      icon: <User size={18} />,
      keywords: ['avatar', 'animation', 'kinematics', 'studio', 'gestures'],
      action: () => setShowAvatarModal(true),
    },
    {
      id: 'lab_avatar_photo',
      title: 'Avatar Photo Auto-Fit & Customization',
      category: 'Lab & 3D',
      icon: <Camera size={18} />,
      keywords: ['avatar', 'photo', 'face', 'custom', 'fit'],
      action: () => setShowAvatarPhotoModal(true),
    },

    // 5. Tools & Environmental Utilities
    {
      id: 'tools_whiteboard',
      title: 'Collaborative Drawing Whiteboard',
      category: 'Tools',
      icon: <Pencil size={18} />,
      keywords: ['whiteboard', 'draw', 'sketch', 'canvas', 'board'],
      action: () => setShowWhiteboardModal(true),
    },
    {
      id: 'tools_recording',
      title: screenRecordingState === 'recording' ? 'Stop Screen Recording' : 'Start Lecture Screen Recording',
      category: 'Tools',
      icon: <Video size={18} />,
      keywords: ['record', 'screen', 'video', 'capture'],
      action: () => {
        if (screenRecordingState === 'recording') {
          stopScreenRecording();
        } else {
          startScreenRecording();
        }
      },
    },
    {
      id: 'tools_timer_overlay_style',
      title: `Cycle Video Timer Overlay (${sessionTimerStyle === 'digital-clock' ? 'Digital Clock' : sessionTimerStyle === 'progress-bar' ? 'Progress Bar' : 'Minimal'})`,
      category: 'Tools',
      icon: <Clock size={18} />,
      keywords: ['timer', 'overlay', 'video', 'recording', 'duration', 'minimal', 'digital', 'progress'],
      action: handleCycleSessionTimerStyle,
    },
    {
      id: 'tools_camera_feed',
      title: cameraFeedEnabled ? 'Disable Presenter Camera Feed' : 'Enable Presenter Camera Feed Overlay',
      category: 'Tools',
      icon: <Camera size={18} />,
      keywords: ['camera', 'webcam', 'feed', 'presenter', 'video'],
      action: toggleCameraFeed,
    },
    {
      id: 'tools_countdown_timer',
      title: 'Study Session Pomodoro Timer',
      category: 'Tools',
      icon: <Timer size={18} />,
      keywords: ['timer', 'pomodoro', 'countdown', 'clock', 'study'],
      action: () => setIsTimerVisible(prev => !prev),
    },
    {
      id: 'tools_acoustics',
      title: 'Classroom Acoustic Profiles & Reverb',
      category: 'Audio & Media',
      icon: <Volume2 size={18} />,
      keywords: ['acoustics', 'sound', 'reverb', 'hall', 'audio', 'echo'],
      action: () => setShowAcousticModal(true),
    },
    {
      id: 'tools_chat_controls',
      title: 'Chat Features, Persona & Language',
      category: 'Tools',
      icon: <MessageSquare size={18} />,
      keywords: ['chat', 'controls', 'persona', 'socratic', 'language'],
      action: () => setShowChatControlsModal(true),
    },

    // 6. Lighting Presets
    {
      id: 'light_daylight',
      title: 'Lighting: Natural Daylight',
      category: 'Display',
      icon: <Sun size={18} />,
      keywords: ['light', 'daylight', 'sun', 'bright'],
      action: () => applyLightingPreset('daylight'),
    },
    {
      id: 'light_golden',
      title: 'Lighting: Warm Golden Hour',
      category: 'Display',
      icon: <Sun size={18} />,
      keywords: ['light', 'golden', 'hour', 'sunset', 'warm'],
      action: () => applyLightingPreset('golden_hour'),
    },
    {
      id: 'light_cyber',
      title: 'Lighting: Cyber Neon Night',
      category: 'Display',
      icon: <Moon size={18} />,
      keywords: ['light', 'cyber', 'night', 'neon', 'dark'],
      action: () => applyLightingPreset('cyber_night'),
    },
    {
      id: 'light_exam',
      title: 'Lighting: High-Contrast Exam Bright',
      category: 'Display',
      icon: <Zap size={18} />,
      keywords: ['light', 'exam', 'bright', 'white', 'focus'],
      action: () => applyLightingPreset('exam_bright'),
    },
    {
      id: 'ambient_lighting_inspector',
      title: '💡 Ambient Lighting Inspector (Nano Banana 2 Realism Vectors)',
      category: 'Display',
      icon: <Activity size={18} />,
      keywords: ['lighting', 'inspector', 'ambient', 'nano banana', 'vector', 'luminance', 'kelvin', 'realism', 'reflectivity'],
      action: () => setShowLightingInspectorModal(true),
    },
    {
      id: 'system_security_shield',
      title: 'Security Architecture & DRM Shield',
      category: 'System',
      icon: <ShieldCheck size={18} />,
      keywords: ['security', 'shield', 'drm', 'license', 'encryption', 'fingerprint', 'integrity', 'audit', 'anti-tamper', 'vault', 'defense'],
      action: () => setShowSecurityModal(true),
    },
    // 10. Nano Banana Rigid-Body Physics & 3D Collisions Lab
    {
      id: 'banana_physics_toss',
      title: '🍌 Toss Nano Banana (Rigid-Body Physics Collision)',
      category: 'Lab & 3D',
      icon: <span>🍌</span>,
      keywords: ['banana', 'nano banana', 'physics', 'rigid body', 'collision', 'bounce', 'gravity', 'toss', 'throw'],
      shortcut: 'B',
      action: () => handleTossBananaFromCamera(),
    },
    {
      id: 'banana_physics_lab',
      title: '🍌 Nano Banana Physics Simulator & Gravity Lab',
      category: 'Lab & 3D',
      icon: <span>⚡</span>,
      keywords: ['banana', 'physics', 'simulator', 'restitution', 'friction', 'gravity', 'materials'],
      action: () => setShowBananaPhysicsModal(true),
    },
    {
      id: 'banana_physics_rain',
      title: '🌧️ Nano Banana Shower (Rain x8)',
      category: 'Lab & 3D',
      icon: <span>🌧️</span>,
      keywords: ['banana', 'rain', 'shower', 'cluster', 'spawn', 'physics'],
      action: () => handleSpawnBananaRain(8),
    },
    {
      id: 'banana_physics_shockwave',
      title: '💥 Nano Banana Shockwave Blast',
      category: 'Lab & 3D',
      icon: <Zap size={18} />,
      keywords: ['banana', 'shockwave', 'blast', 'impulse', 'explode', 'force'],
      action: () => handleBananaShockwave(),
    },
    {
      id: 'banana_physics_clear',
      title: '🧹 Clear All Nano Bananas',
      category: 'Lab & 3D',
      icon: <Trash2 size={18} />,
      keywords: ['banana', 'clear', 'reset', 'clean', 'delete'],
      action: () => handleClearBananas(),
    },
  ], [
    isLectureActive,
    isLecturePaused,
    isSmartboardNotesMinimized,
    isMaximized,
    isBurnerOn,
    isLaserOn,
    isNewtonCradleSwinging,
    screenRecordingState,
    cameraFeedEnabled,
    sessionTimerStyle
  ]);

  // Bubble Radial Menu items for quick contextual interactions
  const radialMenuItems: RadialMenuItem[] = useMemo(() => [
    {
      id: 'play_pause',
      label: isLectureActive && !isLecturePaused ? 'Pause' : 'Play',
      icon: isLectureActive && !isLecturePaused ? <Pause size={18} /> : <Play size={18} />,
      color: 'from-emerald-600 to-teal-600 text-emerald-100',
      action: handleStartVirtualLearning,
    },
    {
      id: 'notes',
      label: 'Notes',
      icon: <FileText size={18} />,
      color: 'from-blue-600 to-indigo-600 text-blue-100',
      action: () => setIsSmartboardNotesMinimized(prev => !prev),
    },
    {
      id: 'command',
      label: 'Commands',
      icon: <Search size={18} />,
      color: 'from-purple-600 to-pink-600 text-purple-100',
      action: () => setIsCommandPaletteOpen(true),
    },
    {
      id: 'volume',
      label: audioEnabled ? 'Mute' : 'Unmute',
      icon: audioEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />,
      color: 'from-violet-600 to-purple-600 text-violet-100',
      action: () => {
        setAudioEnabled(prev => !prev);
        if (audioEnabled) stopSpeech();
      },
    },
    {
      id: 'topics',
      label: 'Topics',
      icon: <BookOpen size={18} />,
      color: 'from-amber-600 to-orange-600 text-amber-100',
      action: () => setShowTopicModal(true),
    },
    {
      id: 'transformations',
      label: 'Transform',
      icon: <Sparkles size={18} />,
      color: 'from-pink-600 to-rose-600 text-pink-100',
      action: () => setShowVisualTransformationModal(true),
    },
    {
      id: 'experiments',
      label: 'Lab & Tools',
      icon: <Sliders size={18} />,
      color: 'from-cyan-600 to-blue-600 text-cyan-100',
      action: () => setCameraView('lab_bench'),
    },
    {
      id: 'clarity_debugger',
      label: 'Debug Clarity',
      icon: <ShieldCheck size={18} />,
      color: 'from-indigo-600 to-cyan-600 text-cyan-100',
      action: () => setShowDebuggerModal(true),
    },
    {
      id: 'banana_toss',
      label: '🍌 Toss Banana',
      icon: <span>🍌</span>,
      color: 'from-amber-600 to-yellow-600 text-amber-100',
      action: () => handleTossBananaFromCamera(),
    },
    {
      id: 'banana_physics_lab',
      label: '🍌 Physics Lab',
      icon: <span>⚡</span>,
      color: 'from-amber-500 to-orange-600 text-amber-100',
      action: () => setShowBananaPhysicsModal(true),
    },
    {
      id: 'fullscreen',
      label: isMaximized ? 'Restore' : 'Maximize',
      icon: isMaximized ? <Minimize2 size={18} /> : <Maximize2 size={18} />,
      color: 'from-sky-600 to-indigo-600 text-sky-100',
      action: toggleMaximizeLectureHall,
    },
  ], [isLectureActive, isLecturePaused, audioEnabled, isMaximized]);

  // Reference holding the latest interactive classroom actions for 3D Smartboard raycaster click triggers
  const latestSmartboardActionsRef = useRef<{
    handleStartVirtualLearning: () => void;
    toggleAudio: () => void;
    handleOpen30sRecap: () => void;
    setCameraView: (v: CameraViewPreset) => void;
    setShowTopicModal: (v: boolean) => void;
    openPracticeQuestions: () => void;
    handleGenerateAiFigureDrawing: () => void;
    expandNotes: () => void;
    handleOpenExecutiveSummary: () => void;
    replaySynchronizedLecture: () => void;
    setShowTeacherStyleModal: (v: boolean) => void;
    setShowChatControlsModal: (v: boolean) => void;
    handleClearTopicAndSmartboard: () => void;
    showHelp: () => void;
    setShowAcousticModal: (v: boolean) => void;
    cycleLightingPreset: () => void;
    setShowSecurityModal: (v: boolean) => void;
    resetSmartboardPosition: () => void;
    handleOpenQuestionSolutionEditor: (initialText?: string) => void;
    showNotification?: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  }>({
    handleStartVirtualLearning,
    toggleAudio: () => {
      setAudioEnabled(prev => !prev);
      if (audioEnabled) stopSpeech();
    },
    handleOpen30sRecap: handleOpen30sRecapFromBackend,
    setCameraView,
    setShowTopicModal,
    openPracticeQuestions: () => {
      setShowPracticeQuestionModal(true);
      playSoundEffect('chime');
      showNotification?.("Interactive Formula Practice & Questions Deck opened 🎯", "success");
    },
    handleGenerateAiFigureDrawing,
    expandNotes: () => {
      setIsSmartboardNotesMinimized(false);
      playSoundEffect('click');
      showNotification?.("Smartboard Lesson Notes expanded 📝", "info");
    },
    handleOpenExecutiveSummary: handleOpenExecutiveSummaryFromBackend,
    replaySynchronizedLecture: () => {
      replaySynchronizedLecture();
      playSoundEffect('chime');
      showNotification?.("Replaying Synchronized Lecture from Start 🔄", "info");
    },
    setShowTeacherStyleModal,
    setShowChatControlsModal: setShowTeacherStyleModal,
    handleClearTopicAndSmartboard,
    showHelp: () => {
      setShowLiveSummaryWidget(prev => !prev);
      playSoundEffect('click');
    },
    setShowAcousticModal,
    cycleLightingPreset: () => {
      const presets: LightingPreset[] = [
        'daylight',
        'golden_hour',
        'cyber_night',
        'exam_bright'
      ];
      const nextIdx = (presets.indexOf(lightingPreset) + 1) % presets.length;
      applyLightingPreset(presets[nextIdx]);
    },
    setShowSecurityModal,
    resetSmartboardPosition,
    handleOpenQuestionSolutionEditor,
    showNotification
  });

  // Keep actions ref continuously in sync on every render
  latestSmartboardActionsRef.current = {
    handleStartVirtualLearning,
    toggleAudio: () => {
      setAudioEnabled(prev => !prev);
      if (audioEnabled) stopSpeech();
    },
    handleOpen30sRecap: handleOpen30sRecapFromBackend,
    setCameraView,
    setShowTopicModal,
    openPracticeQuestions: () => {
      setShowPracticeQuestionModal(true);
      playSoundEffect('chime');
      showNotification?.("Interactive Formula Practice & Questions Deck opened 🎯", "success");
    },
    handleGenerateAiFigureDrawing,
    expandNotes: () => {
      setIsSmartboardNotesMinimized(false);
      playSoundEffect('click');
      showNotification?.("Smartboard Lesson Notes expanded 📝", "info");
    },
    handleOpenExecutiveSummary: handleOpenExecutiveSummaryFromBackend,
    replaySynchronizedLecture: () => {
      replaySynchronizedLecture();
      playSoundEffect('chime');
      showNotification?.("Replaying Synchronized Lecture from Start 🔄", "info");
    },
    setShowTeacherStyleModal,
    setShowChatControlsModal: setShowTeacherStyleModal,
    handleClearTopicAndSmartboard,
    showHelp: () => {
      setShowLiveSummaryWidget(prev => !prev);
      playSoundEffect('click');
    },
    setShowAcousticModal,
    cycleLightingPreset: () => {
      const presets: LightingPreset[] = [
        'daylight',
        'golden_hour',
        'cyber_night',
        'exam_bright'
      ];
      const nextIdx = (presets.indexOf(lightingPreset) + 1) % presets.length;
      applyLightingPreset(presets[nextIdx]);
    },
    setShowSecurityModal,
    resetSmartboardPosition,
    handleOpenQuestionSolutionEditor,
    showNotification
  };

  // Execute action corresponding to 2D Canvas coordinate hit on 3D Smartboard
  const executeSmartboardActionAtCoords = (x: number, y: number) => {
    const actions = latestSmartboardActionsRef.current;
    if (!actions) return;

    // 1. TOP HEADER BUTTONS (y: 20 to 98)
    if (y >= 20 && y <= 98) {
      if (x >= 1010 && x <= 1210) {
        // Play / Pause / Resume
        actions.handleStartVirtualLearning();
        return;
      }
      if (x >= 1215 && x <= 1395) {
        // Audio Mute/Unmute
        actions.toggleAudio();
        return;
      }
      if (x >= 1405 && x <= 1595) {
        // 30s Rapid Recap
        actions.handleOpen30sRecap();
        return;
      }
      if (x >= 1605 && x <= 1805) {
        // Zoom Board
        actions.setCameraView('board_focus');
        return;
      }
      if (x >= 1815 && x <= 2020) {
        // Topics modal
        actions.setShowTopicModal(true);
        return;
      }
    }

    // 2. BOTTOM CONTROL DECK BUTTONS (y: 835 to 948)
    if (y >= 835 && y <= 948) {
      if (x >= 30 && x <= 305) {
        // Practice Q&A
        actions.openPracticeQuestions();
        return;
      }
      if (x >= 310 && x <= 590) {
        // 3D Science Lab Bench
        actions.setCameraView('lab_bench');
        actions.showNotification?.("3D Interactive Science Lab bench active 🔬", "info");
        return;
      }
      if (x >= 595 && x <= 875) {
        // Draw AI Figure
        actions.handleGenerateAiFigureDrawing();
        return;
      }
      if (x >= 880 && x <= 1180) {
        // 5-Layer Executive Summary
        actions.handleOpenExecutiveSummary();
        return;
      }
      if (x >= 1185 && x <= 1485) {
        // Socratic Tutor Q&A
        actions.setShowChatControlsModal(true);
        return;
      }
      if (x >= 1490 && x <= 1750) {
        // Clear Smartboard
        actions.handleClearTopicAndSmartboard();
        return;
      }
      if (x >= 1755 && x <= 2035) {
        // Help & Shortcuts Guide
        actions.showHelp();
        return;
      }
    }

    // 3. FOOTER BAR BUTTONS (y: 955 to 1015)
    if (y >= 955 && y <= 1015) {
      if (x >= 1380 && x <= 1530) {
        actions.setShowAcousticModal(true);
        return;
      }
      if (x >= 1540 && x <= 1680) {
        actions.cycleLightingPreset();
        return;
      }
      if (x >= 1690 && x <= 1840) {
        actions.setShowSecurityModal(true);
        return;
      }
      if (x >= 1850 && x <= 2040) {
        actions.resetSmartboardPosition();
        return;
      }
    }

    // 4. Center Stage Staged Topic Start Button on Board (x: 120 to 800, y: 550 to 780)
    if (x >= 120 && x <= 800 && y >= 550 && y <= 780) {
      actions.handleStartVirtualLearning();
      return;
    }
  };

  // BUILD 3D THREE.JS SCENE
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Dimensions
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0xdbeafe);
    scene.fog = new THREE.FogExp2(0xdbeafe, 0.02);

    // Initialize Nano Banana Rigid-Body Physics Engine with 3D Scene
    nanoBananaPhysics.init(scene, getAudioContext());

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(48, width / height, 0.1, 100);
    cameraRef.current = camera;
    camera.position.set(0, 2.15, 3.8);
    camera.lookAt(0, 2.65, -5.28);

    // 3. Renderer (High Performance WebGL Canvas with resilient fallback)
    if (rendererRef.current) {
      try {
        rendererRef.current.dispose();
      } catch (dispErr) {
        console.warn("Disposing prior renderer:", dispErr);
      }
      rendererRef.current = null;
    }

    let renderer: THREE.WebGLRenderer | null = null;
    try {
      renderer = new THREE.WebGLRenderer({ 
        antialias: graphicsQualityMode !== 'performance', 
        alpha: true, 
        powerPreference: graphicsQualityMode === 'performance' ? "low-power" : "high-performance",
        stencil: false,
        depth: true,
        failIfMajorPerformanceCaveat: false
      });
    } catch (primaryErr) {
      console.warn("Primary WebGL context creation failed, attempting low-overhead fallback:", primaryErr);
      try {
        renderer = new THREE.WebGLRenderer({ 
          antialias: false, 
          alpha: true, 
          powerPreference: "default",
          stencil: false,
          depth: true,
          failIfMajorPerformanceCaveat: false
        });
      } catch (fallbackErr) {
        console.error("WebGL context creation unavailable in current environment:", fallbackErr);
      }
    }

    if (!renderer) {
      console.warn("WebGL context blocked or unavailable. Falling back to 2D Classroom Smartboard display.");
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
      const fallbackDiv = document.createElement('div');
      fallbackDiv.className = 'w-full h-full flex flex-col items-center justify-center p-8 text-center bg-slate-950 text-slate-200';
      fallbackDiv.innerHTML = `
        <div class="max-w-md p-6 rounded-2xl bg-slate-900/90 border border-indigo-500/30 shadow-2xl backdrop-blur-md">
          <div class="w-12 h-12 mx-auto mb-3 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
          </div>
          <h3 class="text-base font-semibold text-white mb-1">3D Classroom Ready</h3>
          <p class="text-xs text-slate-400 leading-relaxed mb-3">The graphics engine is adapting to your browser. Smartboard lecture, voice synthesis, live curriculum topics, and syllabus exploration are active.</p>
        </div>
      `;
      container.appendChild(fallbackDiv);
      return () => {
        while (container.firstChild) {
          container.removeChild(container.firstChild);
        }
      };
    }

    rendererRef.current = renderer;
    renderer.setSize(width, height);
    
    if (graphicsQualityMode === 'performance') {
      renderer.setPixelRatio(1.0);
      renderer.shadowMap.enabled = false;
    } else if (graphicsQualityMode === 'balanced') {
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.25));
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.BasicShadowMap;
    } else {
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2.0));
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    }
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;

    // Clear previous canvas
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    container.appendChild(renderer.domElement);

    // --- TOUCH & POINTER ORBIT / PINCH-ZOOM CONTROLS (Mobile & Desktop) ---
    const domElem = renderer.domElement;
    domElem.style.touchAction = 'none'; // Prevent browser gesture interference

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      console.warn("WebGL context lost on 3D Classroom canvas. Awaiting restoration...");
    };
    const handleContextRestored = () => {
      console.log("WebGL context restored on 3D Classroom canvas.");
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    domElem.addEventListener('webglcontextlost', handleContextLost, false);
    domElem.addEventListener('webglcontextrestored', handleContextRestored, false);

    let isPointerDragging = false;
    let pointerDownPos = { x: 0, y: 0 };
    let previousPointerPos = { x: 0, y: 0 };
    let initialPinchDist = 0;
    let initialPinchFov = 48;
    let lastTapTime = 0;

    const handlePointerDown = (e: PointerEvent) => {
      if (e.target !== domElem) return;
      isPointerDragging = true;
      pointerDownPos = { x: e.clientX, y: e.clientY };
      previousPointerPos = { x: e.clientX, y: e.clientY };

      // Double-tap detection for rapid camera centering on touch screens
      const currentTime = Date.now();
      const tapGap = currentTime - lastTapTime;
      if (tapGap < 300 && tapGap > 0) {
        // Double-tap triggered: cycle camera presets smoothly
        if (activeCameraView === 'front_row') {
          setCameraView('board_focus');
        } else if (activeCameraView === 'board_focus') {
          setCameraView('avatar_focus');
        } else {
          setCameraView('front_row');
        }
        showNotification?.("Camera viewpoint recentered", "info");
      }
      lastTapTime = currentTime;
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (!isPointerDragging || !cameraRef.current) return;
      const deltaX = e.clientX - previousPointerPos.x;
      const deltaY = e.clientY - previousPointerPos.y;
      previousPointerPos = { x: e.clientX, y: e.clientY };

      const camera = cameraRef.current;
      const lookTarget = new THREE.Vector3(0, 2.0, -2.0);
      const offset = camera.position.clone().sub(lookTarget);
      const spherical = new THREE.Spherical();
      spherical.setFromVector3(offset);

      // Smooth touch & mouse drag orbit rotation with refined mobile sensitivity
      const sensitivity = window.innerWidth < 768 ? 0.004 : 0.005;
      spherical.theta -= deltaX * sensitivity;
      spherical.phi = THREE.MathUtils.clamp(spherical.phi - deltaY * sensitivity, 0.15, Math.PI / 2 + 0.15);

      offset.setFromSpherical(spherical);
      camera.position.copy(lookTarget.clone().add(offset));
      camera.lookAt(lookTarget);
    };

    const handlePointerUp = (e: PointerEvent) => {
      isPointerDragging = false;

      // Click / Tap detection on 3D Smartboard buttons via Raycasting
      const dragDist = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
      if (dragDist < 8 && boardScreenMeshRef.current && cameraRef.current) {
        const now = Date.now();
        if (now - lastPointerTapTimeRef.current < 380) {
          // Double-tap or double-click on 3D Smartboard in Virtual 3D
          const rect = domElem.getBoundingClientRect();
          const mouse = new THREE.Vector2(
            ((e.clientX - rect.left) / rect.width) * 2 - 1,
            -((e.clientY - rect.top) / rect.height) * 2 + 1
          );
          const raycaster = new THREE.Raycaster();
          raycaster.setFromCamera(mouse, cameraRef.current);
          const intersects = raycaster.intersectObject(boardScreenMeshRef.current);
          if (intersects.length > 0) {
            latestSmartboardActionsRef.current?.handleOpenQuestionSolutionEditor();
          }
        }
        lastPointerTapTimeRef.current = now;

        const rect = domElem.getBoundingClientRect();
        const mouse = new THREE.Vector2(
          ((e.clientX - rect.left) / rect.width) * 2 - 1,
          -((e.clientY - rect.top) / rect.height) * 2 + 1
        );
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(mouse, cameraRef.current);
        const intersects = raycaster.intersectObject(boardScreenMeshRef.current);
        if (intersects.length > 0 && intersects[0].uv) {
          const uv = intersects[0].uv;
          const canvasX = uv.x * 2048;
          const canvasY = (1 - uv.y) * 1024;
          executeSmartboardActionAtCoords(canvasX, canvasY);
        }
      }
    };

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2 && cameraRef.current) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        initialPinchDist = Math.hypot(dx, dy);
        initialPinchFov = cameraRef.current.fov;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2 && cameraRef.current && initialPinchDist > 0) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const currentDist = Math.hypot(dx, dy);
        const distDelta = currentDist - initialPinchDist;

        const newFov = THREE.MathUtils.clamp(initialPinchFov - distDelta * 0.08, 25, 75);
        cameraRef.current.fov = newFov;
        cameraRef.current.updateProjectionMatrix();
      }
    };

    const handleTouchEnd = () => {
      initialPinchDist = 0;
    };

    // Wheel zoom on desktop
    const handleWheel = (e: WheelEvent) => {
      if (!cameraRef.current) return;
      const newFov = THREE.MathUtils.clamp(cameraRef.current.fov + e.deltaY * 0.03, 25, 75);
      cameraRef.current.fov = newFov;
      cameraRef.current.updateProjectionMatrix();
    };

    domElem.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    domElem.addEventListener('touchstart', handleTouchStart, { passive: true });
    domElem.addEventListener('touchmove', handleTouchMove, { passive: true });
    domElem.addEventListener('touchend', handleTouchEnd, { passive: true });
    domElem.addEventListener('wheel', handleWheel, { passive: true });

    // --- LIGHTING SETUP ---
    const ambientLight = new THREE.AmbientLight(0xe2e8f0, 0.8);
    ambientLightRef.current = ambientLight;
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffaed, 1.8);
    mainSunLightRef.current = sunLight;
    sunLight.position.set(-8, 9, 4);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 25;
    sunLight.shadow.camera.left = -8;
    sunLight.shadow.camera.right = 8;
    sunLight.shadow.camera.top = 8;
    sunLight.shadow.camera.bottom = -8;
    sunLight.shadow.bias = -0.0005;
    scene.add(sunLight);

    // Overhead Ceiling Panel Spotlights
    const roomLights: THREE.PointLight[] = [];
    const lightPositions = [
      [-2.5, 4.2, -2],
      [2.5, 4.2, -2],
      [-2.5, 4.2, 2],
      [2.5, 4.2, 2]
    ];
    lightPositions.forEach(([x, y, z]) => {
      const pl = new THREE.PointLight(0xffffff, 0.6, 10, 1.5);
      pl.position.set(x, y, z);
      scene.add(pl);
      roomLights.push(pl);

      // Visual Ceiling Fixture
      const fixtureGeo = new THREE.BoxGeometry(1.2, 0.08, 1.2);
      const fixtureMat = new THREE.MeshStandardMaterial({ 
        color: 0xffffff, 
        emissive: 0xffffff, 
        emissiveIntensity: 0.8,
        roughness: 0.1 
      });
      const fixture = new THREE.Mesh(fixtureGeo, fixtureMat);
      fixture.position.set(x, 4.45, z);
      scene.add(fixture);
    });
    roomLightsRef.current = roomLights;

    // Dedicated Stage Key Light on Professor Clarity & Stage Area
    const professorStageLight = new THREE.SpotLight(0xfff7ed, 1.4, 20, Math.PI / 3.5, 0.4, 1.2);
    professorStageLight.position.set(0, 4.2, 0.5);
    professorStageLight.target.position.set(0.5, 1.5, -4.0);
    scene.add(professorStageLight);
    scene.add(professorStageLight.target);

    // --- ARCHITECTURE & ROOM MESHES ---
    // Floor: Polished Wood / Ceramic Tile
    const floorGeo = new THREE.PlaneGeometry(16, 16);
    const floorMat = new THREE.MeshStandardMaterial({ 
      color: 0x334155, 
      roughness: 0.35, 
      metalness: 0.1 
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Floor Grid Accent lines
    const gridHelper = new THREE.GridHelper(16, 16, 0x475569, 0x1e293b);
    gridHelper.position.y = 0.005;
    scene.add(gridHelper);

    // Back Wall (Front of classroom behind smartboard)
    const frontWallGeo = new THREE.PlaneGeometry(16, 5);
    const frontWallMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
    const frontWall = new THREE.Mesh(frontWallGeo, frontWallMat);
    frontWall.position.set(0, 2.5, -5.5);
    frontWall.receiveShadow = true;
    scene.add(frontWall);

    // Left Wall with Windows
    const leftWallGeo = new THREE.PlaneGeometry(16, 5);
    const leftWallMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 });
    const leftWall = new THREE.Mesh(leftWallGeo, leftWallMat);
    leftWall.rotation.y = Math.PI / 2;
    leftWall.position.set(-6.5, 2.5, 0);
    leftWall.receiveShadow = true;
    scene.add(leftWall);

    // Large Windows on Left Wall
    const windowFrameMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3 });
    const windowGlassMat = new THREE.MeshPhysicalMaterial({ 
      color: 0xbae6fd, 
      transmission: 0.9, 
      opacity: 0.4, 
      transparent: true, 
      roughness: 0.05, 
      ior: 1.5 
    });
    for (let w = -2.5; w <= 2.5; w += 2.8) {
      const windowFrame = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.6, 2.2), windowFrameMat);
      windowFrame.position.set(-6.45, 2.6, w);
      scene.add(windowFrame);

      const windowGlass = new THREE.Mesh(new THREE.BoxGeometry(0.02, 2.4, 2.0), windowGlassMat);
      windowGlass.position.set(-6.44, 2.6, w);
      scene.add(windowGlass);
    }

    // Right Wall (Science Lab bench wall)
    const rightWallGeo = new THREE.PlaneGeometry(16, 5);
    const rightWallMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.8 });
    const rightWall = new THREE.Mesh(rightWallGeo, rightWallMat);
    rightWall.rotation.y = -Math.PI / 2;
    rightWall.position.set(6.5, 2.5, 0);
    rightWall.receiveShadow = true;
    scene.add(rightWall);

    // Ceiling
    const ceilingGeo = new THREE.PlaneGeometry(16, 16);
    const ceilingMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
    const ceiling = new THREE.Mesh(ceilingGeo, ceilingMat);
    ceiling.rotation.x = Math.PI / 2;
    ceiling.position.y = 4.5;
    scene.add(ceiling);

    // --- CLASSROOM ENTRANCE DOOR (x: -4.8, z: 6.8) ---
    const doorGroup = new THREE.Group();
    doorGroup.position.set(-4.8, 0, 6.8);

    const doorFrame = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 3.2, 0.15),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.5 })
    );
    doorFrame.position.y = 1.6;
    doorGroup.add(doorFrame);

    // Pivoting door wing (hinge at x: -0.7)
    const doorWing = new THREE.Group();
    doorWing.position.set(-0.7, 0, 0);

    const doorPanel = new THREE.Mesh(
      new THREE.BoxGeometry(1.4, 3.0, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 })
    );
    doorPanel.position.set(0.7, 1.5, 0);
    doorWing.add(doorPanel);

    const doorHandle = new THREE.Mesh(
      new THREE.CylinderGeometry(0.02, 0.02, 0.22, 8),
      new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9 })
    );
    doorHandle.rotation.x = Math.PI / 2;
    doorHandle.position.set(1.25, 1.4, 0.08);
    doorWing.add(doorHandle);

    doorGroup.add(doorWing);
    doorWingGroupRef.current = doorWing;
    scene.add(doorGroup);

    // --- FRONT PRESENTATION SMARTBOARD (Positioned on Left Side) ---
    const boardFrameGeo = new THREE.BoxGeometry(7.2, 3.4, 0.12);
    const boardFrameMat = new THREE.MeshStandardMaterial({ color: 0x090d16, roughness: 0.2, metalness: 0.8 });
    const boardFrame = new THREE.Mesh(boardFrameGeo, boardFrameMat);
    boardFrame.position.set(-2.5, 2.7, -5.35);
    scene.add(boardFrame);

    // Smartboard Screen Surface (Glow & Display)
    const boardScreenGeo = new THREE.PlaneGeometry(6.9, 3.1);
    const boardScreenMat = new THREE.MeshStandardMaterial({ 
      color: 0x020617, 
      roughness: 0.1, 
      metalness: 0.1,
      emissive: 0x0f172a,
      emissiveIntensity: 0.3
    });
    const boardScreen = new THREE.Mesh(boardScreenGeo, boardScreenMat);
    boardScreen.position.set(-2.5, 2.7, -5.28);
    boardScreenMeshRef.current = boardScreen;
    boardScreenMatRef.current = boardScreenMat;
    scene.add(boardScreen);
    setTimeout(() => {
      update3dSmartboardTexture();
    }, 50);

    // --- 3D PHYSICAL HARDWARE BUTTONS ON SMARTBOARD BEZEL ---
    const bezelButtonGroup = new THREE.Group();
    bezelButtonGroup.position.set(-2.5, 1.05, -5.27);

    // 1. Power Button with Glowing Green LED
    const pwrBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.035, 0.035, 0.02, 16),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8 })
    );
    pwrBase.rotation.x = Math.PI / 2;
    pwrBase.position.set(3.2, 0, 0);
    bezelButtonGroup.add(pwrBase);

    const pwrLed = new THREE.Mesh(
      new THREE.SphereGeometry(0.018, 12, 12),
      new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x10b981, emissiveIntensity: 2.0 })
    );
    pwrLed.position.set(3.2, 0, 0.015);
    bezelButtonGroup.add(pwrLed);

    // 2. Play / Pause Physical Bezel Switch
    const playSwitch = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.05, 0.02),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7, emissiveIntensity: 0.9, roughness: 0.2 })
    );
    playSwitch.position.set(2.95, 0, 0.01);
    bezelButtonGroup.add(playSwitch);

    // 3. Audio / Volume Physical Rocker Switch
    const volSwitch = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.05, 0.02),
      new THREE.MeshStandardMaterial({ color: 0x818cf8, emissive: 0x4f46e5, emissiveIntensity: 0.8, roughness: 0.2 })
    );
    volSwitch.position.set(2.72, 0, 0.01);
    bezelButtonGroup.add(volSwitch);

    // 4. Rec / Sync Status LED
    const syncLed = new THREE.Mesh(
      new THREE.SphereGeometry(0.014, 12, 12),
      new THREE.MeshStandardMaterial({ color: 0xf43f5e, emissive: 0xf43f5e, emissiveIntensity: 1.8 })
    );
    syncLed.position.set(2.5, 0, 0.015);
    bezelButtonGroup.add(syncLed);

    // 5. Bezel Metallic Badge Plaque
    const plaqueMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 0.05, 0.01),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.9, roughness: 0.1 })
    );
    plaqueMesh.position.set(0, 0, 0.01);
    bezelButtonGroup.add(plaqueMesh);

    scene.add(bezelButtonGroup);

    // Smartboard Tray & Digital Styluses
    const trayGeo = new THREE.BoxGeometry(4.0, 0.08, 0.25);
    const trayMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.6 });
    const tray = new THREE.Mesh(trayGeo, trayMat);
    tray.position.set(-2.5, 0.95, -5.25);
    scene.add(tray);

    const penColors = [0x3b82f6, 0xef4444, 0x10b981, 0xf59e0b];
    penColors.forEach((color, i) => {
      const penGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.35, 12);
      const penMat = new THREE.MeshStandardMaterial({ color, roughness: 0.3 });
      const pen = new THREE.Mesh(penGeo, penMat);
      pen.rotation.z = Math.PI / 2;
      pen.position.set(-3.1 + i * 0.4, 1.02, -5.25);
      scene.add(pen);
    });

    // Indicating Stick Hanging on Smartboard Wall Hook (x: 1.2, y: 2.2, z: -5.3)
    const stickHookGroup = new THREE.Group();
    stickHookGroup.position.set(1.2, 2.2, -5.3);

    const hookMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.015, 0.015, 0.08, 8),
      new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9 })
    );
    hookMesh.rotation.x = Math.PI / 2;
    stickHookGroup.add(hookMesh);

    const hangingStick = new THREE.Mesh(
      new THREE.CylinderGeometry(0.012, 0.012, 0.9, 12),
      new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8 })
    );
    hangingStick.position.set(0, -0.4, 0.04);
    stickHookGroup.add(hangingStick);

    stickHookGroupRef.current = stickHookGroup;
    scene.add(stickHookGroup);

    // Laser Pointer Red Dot on Smartboard
    const laserDot = new THREE.Mesh(
      new THREE.SphereGeometry(0.035, 16, 16),
      new THREE.MeshStandardMaterial({ color: 0xff0033, emissive: 0xff0033, emissiveIntensity: 2.5 })
    );
    laserDot.position.set(-2.5, 2.5, -5.26);
    laserDot.visible = false;
    laserDotMeshRef.current = laserDot;
    scene.add(laserDot);

    // --- ZONE 1: TEACHER'S FRONT DESK & STUDY CORNER (x: 4.2, z: -3.2 - Right side of smartboard) ---
    const frontDeskGroup = new THREE.Group();
    frontDeskGroup.position.set(4.2, 0, -3.2);

    // Solid Oak Desk Tabletop
    const deskTopMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.4, metalness: 0.1 });
    const deskTop = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.08, 1.1), deskTopMat);
    deskTop.position.y = 0.92;
    deskTop.castShadow = true;
    deskTop.receiveShadow = true;
    frontDeskGroup.add(deskTop);

    // Left Drawer Pedestal Base
    const drawerMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5 });
    const drawerPedestal = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.6, 1.0), drawerMat);
    drawerPedestal.position.set(-0.65, 0.3, 0);
    drawerPedestal.castShadow = true;
    frontDeskGroup.add(drawerPedestal);

    // Pull Mat
    const pullMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95, roughness: 0.2 });

    // Animated Top Drawer Group for kinematically pulling out
    const frontDeskDrawerGroup = new THREE.Group();
    frontDeskDrawerGroup.position.set(-0.65, 0.74, 0);

    const drawerBox = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.24, 0.96), drawerMat);
    frontDeskDrawerGroup.add(drawerBox);

    const topPull = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.03, 0.03), pullMat);
    topPull.position.set(0, 0, 0.51);
    frontDeskDrawerGroup.add(topPull);

    frontDeskDrawerGroupRef.current = frontDeskDrawerGroup;
    frontDeskGroup.add(frontDeskDrawerGroup);

    // Bottom Two Fixed Drawer Pulls
    for (let d = 0; d < 2; d++) {
      const pull = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.03, 0.03), pullMat);
      pull.position.set(-0.65, 0.22 + d * 0.26, 0.51);
      frontDeskGroup.add(pull);
    }

    // Right Leg Panel & Modesty Back Panel
    const rightPanel = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.88, 1.0), drawerMat);
    rightPanel.position.set(0.95, 0.44, 0);
    frontDeskGroup.add(rightPanel);

    const backPanel = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.7, 0.04), drawerMat);
    backPanel.position.set(0.2, 0.53, -0.48);
    frontDeskGroup.add(backPanel);

    // Teacher's Padded Executive Swivel Chair Group
    const chairGroup = new THREE.Group();
    chairGroup.position.set(0, 0, -0.65);

    const chairBase = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.35, 0.06, 16), new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8 }));
    chairBase.position.set(0, 0.03, 0);
    chairGroup.add(chairBase);

    const chairStem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.45, 12), pullMat);
    chairStem.position.set(0, 0.25, 0);
    chairGroup.add(chairStem);

    const chairSeatMat = new THREE.MeshStandardMaterial({ color: 0x312e81, roughness: 0.6 });
    const chairSeat = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.08, 0.6), chairSeatMat);
    chairSeat.position.set(0, 0.5, 0);
    chairSeat.castShadow = true;
    chairGroup.add(chairSeat);

    const chairBack = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.65, 0.08), chairSeatMat);
    chairBack.position.set(0, 0.82, -0.27);
    chairBack.rotation.x = -0.1;
    chairGroup.add(chairBack);

    frontDeskChairGroupRef.current = chairGroup;
    frontDeskGroup.add(chairGroup);

    // Articulated Brass Desk Lamp
    const lampBase = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.03, 16), new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9 }));
    lampBase.position.set(-0.7, 0.98, -0.2);
    frontDeskGroup.add(lampBase);

    const lampShade = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.14, 16), new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.3 }));
    lampShade.position.set(-0.7, 1.25, -0.2);
    lampShade.rotation.z = -0.3;
    frontDeskGroup.add(lampShade);

    const deskLight = new THREE.PointLight(0xfef08a, 1.0, 3.0);
    deskLight.position.set(-0.7, 1.2, -0.2);
    frontDeskLampLightRef.current = deskLight;
    frontDeskGroup.add(deskLight);

    // --- PROFESSOR CLARITY'S DEDICATED WORKSTATION LAPTOP & ACCESSORIES ---
    const frontLaptopGroup = new THREE.Group();
    // Positioned directly in front of the professor's seated position (x: 0, z: -0.28) and angled toward smartboard
    frontLaptopGroup.position.set(0.0, 0.965, -0.28);
    frontLaptopGroup.rotation.y = -0.35;

    // 1. Laptop Base Chassis (Premium Space Gray Anodized Aluminium)
    const laptopBaseMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.88,
      roughness: 0.22
    });
    const frontLaptopBase = new THREE.Mesh(
      new THREE.BoxGeometry(0.50, 0.022, 0.34),
      laptopBaseMat
    );
    frontLaptopBase.castShadow = true;
    frontLaptopBase.receiveShadow = true;
    frontLaptopGroup.add(frontLaptopBase);

    // Laptop Beveled Bottom Edge
    const laptopBottomBevel = new THREE.Mesh(
      new THREE.BoxGeometry(0.48, 0.008, 0.32),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, roughness: 0.3 })
    );
    laptopBottomBevel.position.y = -0.012;
    frontLaptopGroup.add(laptopBottomBevel);

    // 2. Recessed Keyboard Deck
    const keybedMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.7 });
    const keybed = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.004, 0.17), keybedMat);
    keybed.position.set(0, 0.012, 0.04);
    frontLaptopGroup.add(keybed);

    // Individual Key Rows (Backlit Illuminated Keys)
    const keyMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      emissive: 0x0284c7,
      emissiveIntensity: 0.2,
      roughness: 0.4
    });

    for (let row = 0; row < 5; row++) {
      const zOffset = -0.025 + row * 0.032;
      const numKeys = row === 4 ? 7 : 14;
      const keyWidth = row === 4 ? 0.055 : 0.026;
      for (let k = 0; k < numKeys; k++) {
        const xOffset = -0.195 + k * (0.40 / (numKeys - 1 || 1));
        const keyMesh = new THREE.Mesh(
          new THREE.BoxGeometry(keyWidth, 0.005, 0.024),
          keyMat
        );
        keyMesh.position.set(xOffset, 0.016, zOffset);
        frontLaptopGroup.add(keyMesh);
      }
    }

    // Spacebar
    const spacebar = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.006, 0.025),
      keyMat
    );
    spacebar.position.set(0, 0.016, 0.105);
    frontLaptopGroup.add(spacebar);

    // Glass Precision Trackpad
    const trackpad = new THREE.Mesh(
      new THREE.BoxGeometry(0.17, 0.003, 0.095),
      new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.6, roughness: 0.15 })
    );
    trackpad.position.set(0, 0.012, -0.095);
    frontLaptopGroup.add(trackpad);

    // Side USB-C / MagSafe Ports Accent
    const portMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
    const portLeft = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.006, 0.03), portMat);
    portLeft.position.set(-0.252, 0, 0.02);
    frontLaptopGroup.add(portLeft);

    const portRight = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.006, 0.03), portMat);
    portRight.position.set(0.252, 0, 0.02);
    frontLaptopGroup.add(portRight);

    // 3. Laptop Screen Lid Hinge (Pivoting at z: 0.16)
    const frontLaptopLid = new THREE.Group();
    frontLaptopLid.position.set(0, 0.014, 0.16);

    // Outer Aluminum Shell
    const lidCase = new THREE.Mesh(
      new THREE.BoxGeometry(0.50, 0.34, 0.012),
      laptopBaseMat
    );
    // Lid child center is offset so hinge is along one edge
    lidCase.position.set(0, 0.006, -0.17);
    lidCase.castShadow = true;
    frontLaptopLid.add(lidCase);

    // Inner Display Screen Bezel
    const screenBezel = new THREE.Mesh(
      new THREE.BoxGeometry(0.48, 0.32, 0.002),
      new THREE.MeshStandardMaterial({ color: 0x020617, roughness: 0.9 })
    );
    screenBezel.position.set(0, 0.001, -0.17);
    frontLaptopLid.add(screenBezel);

    // High-Resolution Glowing Display Screen (Faces professor when open)
    const screenMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.95,
      roughness: 0.1
    });
    frontLaptopScreenMatRef.current = screenMat;

    const screenDisplay = new THREE.Mesh(
      new THREE.PlaneGeometry(0.45, 0.29),
      screenMat
    );
    screenDisplay.position.set(0, -0.006, -0.17);
    // Orient plane so normal faces toward the keyboard when closed, and toward the professor when open
    screenDisplay.rotation.x = Math.PI / 2;
    frontLaptopLid.add(screenDisplay);

    // Glowing Logo / Emblem on Back of Lid (Facing classroom / students when open)
    const logoMesh = new THREE.Mesh(
      new THREE.CircleGeometry(0.035, 24),
      new THREE.MeshBasicMaterial({ color: 0xe0f2fe })
    );
    logoMesh.position.set(0, 0.013, -0.17);
    logoMesh.rotation.x = -Math.PI / 2;
    frontLaptopLid.add(logoMesh);

    // Initial Lid Open Rotation (~112 degrees back)
    frontLaptopLid.rotation.x = -1.95;
    frontLaptopLidGroupRef.current = frontLaptopLid;
    frontLaptopGroup.add(frontLaptopLid);

    // Soft Screen Glow Cast onto Hands and Desk
    const laptopGlowLight = new THREE.PointLight(0x38bdf8, 0.6, 1.2);
    laptopGlowLight.position.set(0, 0.18, 0.05);
    frontLaptopGroup.add(laptopGlowLight);

    frontDeskGroup.add(frontLaptopGroup);

    // 4. Indicating Stick Resting Cradle on Desk
    const stickRestMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.3 });
    const stickRest1 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.02, 0.08), stickRestMat);
    stickRest1.position.set(0.45, 0.97, -0.4);
    frontDeskGroup.add(stickRest1);

    const stickRest2 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.02, 0.08), stickRestMat);
    stickRest2.position.set(0.45, 0.97, -0.15);
    frontDeskGroup.add(stickRest2);

    // 5. Professor Clarity's Open Notebook & Journal
    const journalGeo = new THREE.BoxGeometry(0.38, 0.025, 0.28);
    const journalMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.8 });
    const journal = new THREE.Mesh(journalGeo, journalMat);
    journal.position.set(-0.45, 0.975, -0.22);
    journal.rotation.y = 0.15;
    frontDeskGroup.add(journal);

    // Water Glass with Blue Refreshment Mesh
    const glassCup = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.035, 0.12, 16), new THREE.MeshPhysicalMaterial({ color: 0xffffff, transmission: 0.9, transparent: true, roughness: 0.1, ior: 1.5 }));
    glassCup.position.set(-0.25, 1.02, 0.25);
    frontDeskGroup.add(glassCup);

    const glassWater = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.032, 0.09, 16), new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.8 }));
    glassWater.position.set(-0.25, 1.01, 0.25);
    frontDeskGroup.add(glassWater);

    // Brass Nameplate: PROFESSOR CLARITY
    const nameplate = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.06, 0.06), new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.95, roughness: 0.15 }));
    nameplate.position.set(0.65, 0.99, 0.35);
    nameplate.rotation.y = -0.2;
    frontDeskGroup.add(nameplate);

    scene.add(frontDeskGroup);

    // --- ZONE 4: TEACHER'S LECTURE PODIUM & OVERHEAD PROJECTOR (x: 1.2, z: -3.3) ---
    const podiumGroup = new THREE.Group();
    podiumGroup.position.set(1.2, 0, -3.3);

    const podiumBase = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 1.15, 0.9),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.4, metalness: 0.3 })
    );
    podiumBase.position.y = 0.58;
    podiumBase.castShadow = true;
    podiumBase.receiveShadow = true;
    podiumGroup.add(podiumBase);

    // Podium Top Slanted Plate
    const podiumTop = new THREE.Mesh(
      new THREE.BoxGeometry(1.3, 0.06, 1.0),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2 })
    );
    podiumTop.position.set(0, 1.2, 0);
    podiumTop.rotation.x = 0.15;
    podiumGroup.add(podiumTop);

    // Gooseneck Microphone
    const micStemGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.42, 8);
    const micStem = new THREE.Mesh(micStemGeo, new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95 }));
    micStem.position.set(0.35, 1.4, -0.15);
    micStem.rotation.x = -0.3;
    podiumGroup.add(micStem);

    const micHead = new THREE.Mesh(
      new THREE.SphereGeometry(0.025, 12, 12),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 })
    );
    micHead.position.set(0.35, 1.56, -0.05);
    podiumGroup.add(micHead);

    // Open Lesson Textbook / Reference Notes
    const bookGeo = new THREE.BoxGeometry(0.44, 0.03, 0.32);
    const bookMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.8 });
    const book = new THREE.Mesh(bookGeo, bookMat);
    book.position.set(-0.25, 1.24, 0);
    book.rotation.y = 0.08;
    podiumGroup.add(book);

    // Sleek Aluminum Laptop with glowing screen
    const laptopBase = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.015, 0.25), new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8 }));
    laptopBase.position.set(0.12, 1.23, 0.02);
    podiumGroup.add(laptopBase);

    const laptopScreen = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.24, 0.012), new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x38bdf8, emissiveIntensity: 0.6 }));
    laptopScreen.position.set(0.12, 1.34, -0.1);
    laptopScreen.rotation.x = 0.2;
    podiumGroup.add(laptopScreen);

    scene.add(podiumGroup);

    // --- ARTICULATED 3D PROFESSOR CLARITY AVATAR RIG ---
    const tutorGroup = new THREE.Group();
    // Default initial position seated at Workstation Chair on the right side of the Smartboard
    tutorGroup.position.set(4.2, 0, -3.85);
    tutorGroup.rotation.y = -0.35;

    // 1. Pelvis Root & Legs
    const tutorLeftLeg = new THREE.Group();
    tutorLeftLeg.position.set(-0.14, 0.88, 0);
    const thighLeft = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.065, 0.44, 12), new THREE.MeshStandardMaterial({ color: 0x1e1b4b, roughness: 0.7 }));
    thighLeft.position.y = -0.22;
    tutorLeftLeg.add(thighLeft);
    const shoeLeft = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.22), new THREE.MeshStandardMaterial({ color: 0x090d16, roughness: 0.3 }));
    shoeLeft.position.set(0, -0.44, 0.04);
    tutorLeftLeg.add(shoeLeft);
    tutorGroup.add(tutorLeftLeg);
    tutorLeftLegRef.current = tutorLeftLeg;

    const tutorRightLeg = new THREE.Group();
    tutorRightLeg.position.set(0.14, 0.88, 0);
    const thighRight = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.065, 0.44, 12), new THREE.MeshStandardMaterial({ color: 0x1e1b4b, roughness: 0.7 }));
    thighRight.position.y = -0.22;
    tutorRightLeg.add(thighRight);
    const shoeRight = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.22), new THREE.MeshStandardMaterial({ color: 0x090d16, roughness: 0.3 }));
    shoeRight.position.set(0, -0.44, 0.04);
    tutorRightLeg.add(shoeRight);
    tutorGroup.add(tutorRightLeg);
    tutorRightLegRef.current = tutorRightLeg;

    // 2. Torso / Academic Navy Blazer & Tie
    const torsoGeo = new THREE.CylinderGeometry(0.26, 0.3, 0.85, 16);
    const torsoMat = new THREE.MeshStandardMaterial({ color: 0x312e81, roughness: 0.6 });
    const torso = new THREE.Mesh(torsoGeo, torsoMat);
    torso.position.y = 1.35;
    torso.castShadow = true;
    tutorTorsoRef.current = torso;
    tutorGroup.add(torso);

    // Dress Shirt Collar & Tie
    const shirtCollar = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 0.15, 12), new THREE.MeshStandardMaterial({ color: 0xf8fafc }));
    shirtCollar.position.set(0, 1.76, 0.05);
    tutorGroup.add(shirtCollar);

    const tieMesh = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.32, 0.02), new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.4 }));
    tieMesh.position.set(0, 1.55, 0.27);
    tutorGroup.add(tieMesh);

    // 3. Head & Academic Mortarboard
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.95, 0);

    const headGeo = new THREE.SphereGeometry(0.21, 24, 24);
    const headMat = new THREE.MeshStandardMaterial({ color: 0xfde047, roughness: 0.4 });
    const head = new THREE.Mesh(headGeo, headMat);
    head.castShadow = true;
    tutorHeadRef.current = head;
    headGroup.add(head);

    // Academic Eyeglasses
    const glassFrame = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.07, 0.03), new THREE.MeshStandardMaterial({ color: 0x090d16, metalness: 0.8 }));
    glassFrame.position.set(0, 0.03, 0.2);
    tutorGlassesRef.current = glassFrame;
    headGroup.add(glassFrame);

    // Smart Glass Visor (Eye Status & Dynamic Glow)
    const visorGeo = new THREE.BoxGeometry(0.28, 0.06, 0.08);
    const visorMat = new THREE.MeshStandardMaterial({ 
      color: 0x38bdf8, 
      emissive: 0x38bdf8, 
      emissiveIntensity: 0.8,
      roughness: 0.1 
    });
    const visor = new THREE.Mesh(visorGeo, visorMat);
    visor.position.set(0, 0.03, 0.19);
    tutorVisorRef.current = visor;
    headGroup.add(visor);

    // Graduation Cap Base & Diamond Top
    const capBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.16, 0.18, 0.08, 16),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2 })
    );
    capBase.position.y = 0.22;
    headGroup.add(capBase);

    const capTop = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.03, 0.5),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2 })
    );
    capTop.position.y = 0.27;
    capTop.rotation.y = Math.PI / 4;
    headGroup.add(capTop);

    // Swinging Silk Tassel
    const tasselGroup = new THREE.Group();
    tasselGroup.position.set(0.18, 0.27, 0.18);
    const tasselCord = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.2, 6), new THREE.MeshStandardMaterial({ color: 0xf59e0b }));
    tasselCord.position.y = -0.1;
    tasselGroup.add(tasselCord);
    const tasselBrush = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.025, 0.08, 8), new THREE.MeshStandardMaterial({ color: 0xf59e0b }));
    tasselBrush.position.y = -0.22;
    tasselGroup.add(tasselBrush);
    tutorTasselRef.current = tasselGroup;
    headGroup.add(tasselGroup);

    tutorGroup.add(headGroup);

    // 4. Left Arm & Held Notes Prop
    const leftArmGroup = new THREE.Group();
    leftArmGroup.position.set(-0.34, 1.65, 0);
    const leftUpperArm = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.05, 0.38, 12), torsoMat);
    leftUpperArm.position.y = -0.19;
    leftArmGroup.add(leftUpperArm);

    const leftForearmGroup = new THREE.Group();
    leftForearmGroup.position.set(0, -0.38, 0);
    const leftForearm = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.042, 0.32, 12), torsoMat);
    leftForearm.position.y = -0.16;
    leftForearmGroup.add(leftForearm);
    const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.045, 12, 12), headMat);
    leftHand.position.set(0, -0.33, 0);
    leftForearmGroup.add(leftHand);

    // Gold Wristwatch on Left Wrist
    const watchMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.038, 0.038, 0.04, 16),
      new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.95, roughness: 0.15 })
    );
    watchMesh.position.set(0, -0.22, 0);
    watchMesh.rotation.x = Math.PI / 2;
    tutorWatchRef.current = watchMesh;
    leftForearmGroup.add(watchMesh);

    // Held Notes Journal
    const heldNotes = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.02, 0.18), new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.7 }));
    heldNotes.position.set(0, -0.33, 0.1);
    heldNotes.rotation.x = Math.PI / 4;
    heldNotes.visible = false;
    heldNotesRef.current = heldNotes;
    leftForearmGroup.add(heldNotes);

    leftArmGroup.add(leftForearmGroup);
    tutorLeftArmRef.current = leftArmGroup;
    tutorLeftForearmRef.current = leftForearmGroup;
    tutorGroup.add(leftArmGroup);

    // 5. Right Arm & Held Digital Marker / Pointer / Props
    const rightArmGroup = new THREE.Group();
    rightArmGroup.position.set(0.34, 1.65, 0);
    const rightUpperArm = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.05, 0.38, 12), torsoMat);
    rightUpperArm.position.y = -0.19;
    rightArmGroup.add(rightUpperArm);

    const rightForearmGroup = new THREE.Group();
    rightForearmGroup.position.set(0, -0.38, 0);
    const rightForearm = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.042, 0.32, 12), torsoMat);
    rightForearm.position.y = -0.16;
    rightForearmGroup.add(rightForearm);
    const rightHand = new THREE.Mesh(new THREE.SphereGeometry(0.045, 12, 12), headMat);
    rightHand.position.set(0, -0.33, 0);
    rightForearmGroup.add(rightHand);

    // Held Digital Stylus Marker
    const heldMarker = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.22, 12), new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.2 }));
    heldMarker.position.set(0, -0.38, 0.08);
    heldMarker.rotation.x = Math.PI / 3;
    heldMarkerRef.current = heldMarker;
    rightForearmGroup.add(heldMarker);

    // Held Laser Pointer
    const heldPointer = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.24, 8), new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9 }));
    heldPointer.position.set(0, -0.38, 0.08);
    heldPointer.rotation.x = Math.PI / 3;
    heldPointer.visible = false;
    heldPointerRef.current = heldPointer;
    rightForearmGroup.add(heldPointer);

    // Held Telescopic Indicating Stick Group (pivoted in hand)
    const heldStickGroup = new THREE.Group();
    heldStickGroup.position.set(0, -0.38, 0.08);
    heldStickGroup.rotation.x = Math.PI / 3;

    const stickBaseSection = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.35, 12), new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8 }));
    stickBaseSection.position.y = -0.17;
    heldStickGroup.add(stickBaseSection);

    const stickMidSection = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.011, 0.32, 12), new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95 }));
    stickMidSection.position.y = -0.45;
    heldStickGroup.add(stickMidSection);

    const stickTipSection = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 0.30, 12), new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9 }));
    stickTipSection.position.y = -0.72;
    heldStickGroup.add(stickTipSection);

    heldStickGroup.visible = false;
    heldStickGroupRef.current = heldStickGroup;
    rightForearmGroup.add(heldStickGroup);

    // Held Scientific Specimen / Model Prop
    const heldProp = new THREE.Mesh(new THREE.SphereGeometry(0.08, 12, 12), new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.3 }));
    heldProp.position.set(0, -0.38, 0.08);
    heldProp.visible = false;
    heldPropRef.current = heldProp;
    rightForearmGroup.add(heldProp);

    // Held Water Glass
    const heldGlass = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.03, 0.1, 16), new THREE.MeshStandardMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.85 }));
    heldGlass.position.set(0, -0.38, 0.08);
    heldGlass.visible = false;
    heldGlassRef.current = heldGlass;
    rightForearmGroup.add(heldGlass);

    rightArmGroup.add(rightForearmGroup);
    tutorRightArmRef.current = rightArmGroup;
    tutorRightForearmRef.current = rightForearmGroup;
    tutorArmRef.current = rightArmGroup; // Legacy backward compatibility ref
    tutorGroup.add(rightArmGroup);

    tutorAvatarGroupRef.current = tutorGroup;
    scene.add(tutorGroup);

    // --- 5-STATE GLOWING PROXIMITY FLOOR INDICATOR ---
    const proxRingGeo = new THREE.RingGeometry(0.55, 0.68, 48);
    const proxRingMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.55,
      roughness: 0.2
    });
    const proxRingMesh = new THREE.Mesh(proxRingGeo, proxRingMat);
    proxRingMesh.rotation.x = -Math.PI / 2;
    proxRingMesh.position.set(4.2, 0.02, -3.85);
    scene.add(proxRingMesh);
    proximityRingMeshRef.current = proxRingMesh;
    proximityRingMatRef.current = proxRingMat;

    // --- STUDENT WORKSTATION DESKS & CHAIRS ---
    const deskRows = [-1.2, 1.2, 3.6];
    const deskCols = [-2.2, 2.2];

    deskRows.forEach((z) => {
      deskCols.forEach((x) => {
        const deskGroup = new THREE.Group();
        deskGroup.position.set(x, 0, z);

        // Desk Tabletop
        const tableTop = new THREE.Mesh(
          new THREE.BoxGeometry(1.6, 0.08, 0.9),
          new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.5 })
        );
        tableTop.position.y = 0.9;
        tableTop.castShadow = true;
        tableTop.receiveShadow = true;
        deskGroup.add(tableTop);

        // Metallic Legs
        const legMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8 });
        const legOffsets = [[-0.7, -0.35], [0.7, -0.35], [-0.7, 0.35], [0.7, 0.35]];
        legOffsets.forEach(([lx, lz]) => {
          const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.9, 12), legMat);
          leg.position.set(lx, 0.45, lz);
          leg.castShadow = true;
          deskGroup.add(leg);
        });

        // Student Chair
        const chairSeat = new THREE.Mesh(
          new THREE.BoxGeometry(0.7, 0.06, 0.7),
          new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 })
        );
        chairSeat.position.set(0, 0.55, 0.7);
        chairSeat.castShadow = true;
        deskGroup.add(chairSeat);

        const chairBack = new THREE.Mesh(
          new THREE.BoxGeometry(0.7, 0.6, 0.06),
          new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.6 })
        );
        chairBack.position.set(0, 0.85, 1.02);
        deskGroup.add(chairBack);

        // Notebook on Desk
        const noteMesh = new THREE.Mesh(
          new THREE.BoxGeometry(0.4, 0.02, 0.3),
          new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.9 })
        );
        noteMesh.position.set(-0.3, 0.95, 0);
        deskGroup.add(noteMesh);

        // Pencil
        const pencilMesh = new THREE.Mesh(
          new THREE.CylinderGeometry(0.01, 0.01, 0.2, 8),
          new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 })
        );
        pencilMesh.rotation.z = Math.PI / 2;
        pencilMesh.position.set(-0.3, 0.97, 0.2);
        deskGroup.add(pencilMesh);

        scene.add(deskGroup);
      });
    });

    // --- SCIENCE & STEM LABORATORY BENCH (Right Wall) ---
    const labBenchGroup = new THREE.Group();
    labBenchGroup.position.set(5.2, 0, 1.0);

    // Bench Surface
    const benchTop = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 0.1, 5.5),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2, metalness: 0.4 })
    );
    benchTop.position.y = 1.0;
    benchTop.castShadow = true;
    benchTop.receiveShadow = true;
    labBenchGroup.add(benchTop);

    // Bench Base Cabinets
    const benchCabinet = new THREE.Mesh(
      new THREE.BoxGeometry(1.5, 0.95, 5.4),
      new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 })
    );
    benchCabinet.position.y = 0.48;
    benchCabinet.castShadow = true;
    labBenchGroup.add(benchCabinet);

    // --- EQUIPMENT 1: CHEMISTRY BUNSEN BURNER & FLASKS ---
    const burnerGroup = new THREE.Group();
    burnerGroup.position.set(-0.2, 1.05, -1.8);

    const burnerBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.15, 0.05, 16),
      new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8 })
    );
    burnerGroup.add(burnerBase);

    const burnerTube = new THREE.Mesh(
      new THREE.CylinderGeometry(0.03, 0.03, 0.25, 16),
      new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9 })
    );
    burnerTube.position.y = 0.15;
    burnerGroup.add(burnerTube);

    // Flame Particle/Mesh
    const flameGeo = new THREE.ConeGeometry(0.05, 0.18, 12);
    const flameMat = new THREE.MeshStandardMaterial({ 
      color: 0x38bdf8, 
      emissive: 0x0284c7, 
      emissiveIntensity: 1.5,
      transparent: true,
      opacity: 0.9 
    });
    const flameMesh = new THREE.Mesh(flameGeo, flameMat);
    flameMesh.position.y = 0.36;
    flameMeshRef.current = flameMesh;
    burnerGroup.add(flameMesh);

    // Flame Point Light
    const flameLight = new THREE.PointLight(0x38bdf8, 1.5, 2.5);
    flameLight.position.y = 0.4;
    flameLightRef.current = flameLight;
    burnerGroup.add(flameLight);

    labBenchGroup.add(burnerGroup);

    // Glass Flasks & Beakers with liquid
    const glassMat = new THREE.MeshPhysicalMaterial({ 
      color: 0xffffff, 
      transmission: 0.95, 
      opacity: 0.3, 
      transparent: true, 
      roughness: 0.05, 
      ior: 1.5 
    });

    const flaskGroup = new THREE.Group();
    flaskGroup.position.set(0.2, 1.05, -1.4);

    const flaskGlass = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.3, 16), glassMat);
    flaskGlass.position.y = 0.15;
    flaskGroup.add(flaskGlass);

    // Flask Liquid
    const liquidGeo = new THREE.ConeGeometry(0.12, 0.18, 16);
    const liquidMat = new THREE.MeshStandardMaterial({ 
      color: new THREE.Color(beakerLiquidColor), 
      roughness: 0.1, 
      transparent: true, 
      opacity: 0.85 
    });
    const liquidMesh = new THREE.Mesh(liquidGeo, liquidMat);
    liquidMesh.position.y = 0.1;
    flaskGroup.add(liquidMesh);

    // Animated Bubbles in liquid
    const bubbles: THREE.Mesh[] = [];
    for (let b = 0; b < 6; b++) {
      const bubble = new THREE.Mesh(
        new THREE.SphereGeometry(0.015, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1, transparent: true, opacity: 0.8 })
      );
      bubble.position.set(
        (Math.random() - 0.5) * 0.1,
        0.05 + Math.random() * 0.12,
        (Math.random() - 0.5) * 0.1
      );
      flaskGroup.add(bubble);
      bubbles.push(bubble);
    }
    beakerBubblesRef.current = bubbles;

    labBenchGroup.add(flaskGroup);

    // Test Tube Rack
    const rackGeo = new THREE.BoxGeometry(0.12, 0.2, 0.6);
    const rackMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 });
    const rack = new THREE.Mesh(rackGeo, rackMat);
    rack.position.set(-0.3, 1.15, -0.8);
    labBenchGroup.add(rack);

    const rainbowTubeColors = [0xef4444, 0xf59e0b, 0x10b981, 0x3b82f6, 0x8b5cf6];
    rainbowTubeColors.forEach((color, i) => {
      const tubeGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.22, 12);
      const tubeMat = new THREE.MeshStandardMaterial({ color, roughness: 0.2 });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      tube.position.set(-0.3, 1.25, -1.0 + i * 0.1);
      labBenchGroup.add(tube);
    });

    // --- EQUIPMENT 2: OPTICAL PRISM & LASER BENCH ---
    const opticsGroup = new THREE.Group();
    opticsGroup.position.set(0, 1.05, 0.2);

    // Laser Emitter Box
    const laserBox = new THREE.Mesh(
      new THREE.BoxGeometry(0.15, 0.12, 0.25),
      new THREE.MeshStandardMaterial({ color: 0x090d16, metalness: 0.8 })
    );
    laserBox.position.set(-0.4, 0.1, 0);
    opticsGroup.add(laserBox);

    // Glass Triangular Prism
    const prismGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.2, 3);
    const prismMat = new THREE.MeshPhysicalMaterial({ 
      color: 0xffffff, 
      transmission: 0.95, 
      roughness: 0.02, 
      ior: 1.6, 
      transparent: true,
      opacity: 0.4
    });
    const prism = new THREE.Mesh(prismGeo, prismMat);
    prism.position.set(0, 0.15, 0);
    prism.rotation.y = Math.PI / 6;
    opticsGroup.add(prism);

    // Incident Laser Line
    const laserGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-0.3, 0.1, 0),
      new THREE.Vector3(0, 0.1, 0)
    ]);
    const laserMat = new THREE.LineBasicMaterial({ color: 0x10b981, linewidth: 3 });
    const laserLine = new THREE.Line(laserGeo, laserMat);
    laserBeamRef.current = laserLine;
    opticsGroup.add(laserLine);

    // Refracted Rainbow Fan Rays
    const spectrumColors = [0xef4444, 0xf97316, 0xeab308, 0x22c55e, 0x06b6d4, 0x3b82f6, 0xa855f7];
    const rainbowRays: THREE.Line[] = [];
    spectrumColors.forEach((color, i) => {
      const angle = 0.15 + (i - 3) * 0.08;
      const rayGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0.1, 0),
        new THREE.Vector3(0.5, 0.1, Math.sin(angle) * 0.4)
      ]);
      const rayLine = new THREE.Line(rayGeo, new THREE.LineBasicMaterial({ color, linewidth: 2 }));
      rainbowRays.push(rayLine);
      opticsGroup.add(rayLine);
    });
    rainbowRaysRef.current = rainbowRays;

    labBenchGroup.add(opticsGroup);

    // --- EQUIPMENT 3: 3D HOLOGRAPHIC SCIENCE PROJECTOR ---
    const holoBaseGroup = new THREE.Group();
    holoBaseGroup.position.set(0, 1.05, 1.8);

    // Projector Platform Base
    const holoPedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(0.35, 0.4, 0.08, 24),
      new THREE.MeshStandardMaterial({ color: 0x090d16, metalness: 0.9, roughness: 0.2 })
    );
    holoPedestal.position.y = 0.04;
    holoBaseGroup.add(holoPedestal);

    // Emitter Ring
    const emitterRing = new THREE.Mesh(
      new THREE.TorusGeometry(0.28, 0.02, 16, 32),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x38bdf8, emissiveIntensity: 1.2 })
    );
    emitterRing.rotation.x = Math.PI / 2;
    emitterRing.position.y = 0.08;
    holoBaseGroup.add(emitterRing);

    // Hologram Floating Group (Dynamic Mesh)
    const hologramGroup = new THREE.Group();
    hologramGroup.position.y = 0.5;
    hologramGroupRef.current = hologramGroup;
    holoBaseGroup.add(hologramGroup);

    // Add Hologram Light
    const holoLight = new THREE.PointLight(0x38bdf8, 1.8, 3.0);
    holoLight.position.y = 0.4;
    holoBaseGroup.add(holoLight);

    labBenchGroup.add(holoBaseGroup);

    // --- EQUIPMENT 4: NEWTON'S CRADLE ---
    const cradleGroup = new THREE.Group();
    cradleGroup.position.set(0, 1.05, 0.9);

    // Stand Frame
    const cradleFrameMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.9, roughness: 0.1 });
    const cradleBase = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.03, 0.5), cradleFrameMat);
    cradleGroup.add(cradleBase);

    const archLeft = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.35, 8), cradleFrameMat);
    archLeft.position.set(-0.14, 0.18, 0);
    cradleGroup.add(archLeft);

    const archRight = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.35, 8), cradleFrameMat);
    archRight.position.set(0.14, 0.18, 0);
    cradleGroup.add(archRight);

    const topBar = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.015, 0.45), cradleFrameMat);
    topBar.position.y = 0.35;
    cradleGroup.add(topBar);

    // 5 Steel Spheres
    const sphereMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.95, roughness: 0.05 });
    const cradleSpheres: THREE.Mesh[] = [];
    const cradleStrings: THREE.Line[] = [];

    for (let s = 0; s < 5; s++) {
      const sphereZ = -0.16 + s * 0.08;
      const sphere = new THREE.Mesh(new THREE.SphereGeometry(0.035, 16, 16), sphereMat);
      sphere.position.set(0, 0.12, sphereZ);
      sphere.castShadow = true;
      cradleSpheres.push(sphere);
      cradleGroup.add(sphere);

      // Suspension String
      const strGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0.35, sphereZ),
        new THREE.Vector3(0, 0.12, sphereZ)
      ]);
      const strLine = new THREE.Line(strGeo, new THREE.LineBasicMaterial({ color: 0x94a3b8 }));
      cradleStrings.push(strLine);
      cradleGroup.add(strLine);
    }
    newtonSpheresRef.current = cradleSpheres;
    newtonStringsRef.current = cradleStrings;

    labBenchGroup.add(cradleGroup);

    // --- EQUIPMENT 5: 3D RESEARCH MICROSCOPE (x: -0.2, z: -2.3) ---
    const microscopeGroup = new THREE.Group();
    microscopeGroup.position.set(-0.2, 1.05, -2.3);

    // Horseshoe Metal Base
    const scopeBase = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.04, 16), new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.7 }));
    microscopeGroup.add(scopeBase);

    // Curved Arm & Pillar
    const scopeArm = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.28, 12), new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8 }));
    scopeArm.position.set(0.04, 0.16, 0);
    scopeArm.rotation.z = -0.15;
    microscopeGroup.add(scopeArm);

    // Stage with Specimen Glass Slide
    const scopeStage = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.02, 0.14), new THREE.MeshStandardMaterial({ color: 0x090d16 }));
    scopeStage.position.set(0, 0.14, 0.06);
    microscopeGroup.add(scopeStage);

    const glassSlide = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.005, 0.03), new THREE.MeshPhysicalMaterial({ color: 0x38bdf8, transmission: 0.9, transparent: true }));
    glassSlide.position.set(0, 0.155, 0.06);
    microscopeGroup.add(glassSlide);

    // Revolving Turret with 3 Objective Lenses
    const turret = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.03, 12), new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.9 }));
    turret.position.set(0, 0.23, 0.06);
    microscopeGroup.add(turret);

    for (let l = 0; l < 3; l++) {
      const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.015, 0.06, 8), new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95 }));
      lens.position.set(Math.cos(l * 2.09) * 0.025, 0.19, 0.06 + Math.sin(l * 2.09) * 0.025);
      microscopeGroup.add(lens);
    }

    // Dual Ocular Eyepiece Tube
    const eyepiece = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.14, 12), new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.2 }));
    eyepiece.position.set(0.02, 0.32, 0.04);
    eyepiece.rotation.x = 0.3;
    microscopeGroup.add(eyepiece);

    labBenchGroup.add(microscopeGroup);

    // --- EQUIPMENT 6: 3D MOLECULAR BALL-AND-STICK MODEL (x: 0.2, z: 2.3) ---
    const moleculeGroup = new THREE.Group();
    moleculeGroup.position.set(0.2, 1.05, 2.3);

    // Stand Pedestal
    const molStand = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.02, 16), new THREE.MeshStandardMaterial({ color: 0x334155 }));
    moleculeGroup.add(molStand);
    const molRod = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.2, 8), new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9 }));
    molRod.position.y = 0.1;
    moleculeGroup.add(molRod);

    // Central Carbon Atom (Black/Navy)
    const carbonAtom = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 16), new THREE.MeshStandardMaterial({ color: 0x090d16, roughness: 0.2 }));
    carbonAtom.position.y = 0.24;
    moleculeGroup.add(carbonAtom);

    // Surrounding Oxygen & Hydrogen Atoms with Bond Cylinders
    const molColors = [0xef4444, 0x38bdf8, 0xef4444, 0xf8fafc];
    const molOffsets = [
      [0.1, 0.32, 0.08],
      [-0.1, 0.32, -0.08],
      [0.08, 0.16, -0.1],
      [-0.08, 0.16, 0.1]
    ];
    molOffsets.forEach(([mx, my, mz], idx) => {
      const atom = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 12), new THREE.MeshStandardMaterial({ color: molColors[idx], roughness: 0.3 }));
      atom.position.set(mx, my, mz);
      moleculeGroup.add(atom);

      // Bond Cylinder
      const bondGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.12, 8);
      const bond = new THREE.Mesh(bondGeo, new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8 }));
      bond.position.set(mx * 0.5, 0.24 + (my - 0.24) * 0.5, mz * 0.5);
      moleculeGroup.add(bond);
    });

    labBenchGroup.add(moleculeGroup);

    // --- EQUIPMENT 7: PLANT SPECIMEN IN BEAKER (x: -0.3, z: 2.3) ---
    const plantBeaker = new THREE.Group();
    plantBeaker.position.set(-0.3, 1.05, 2.3);

    const beakerGlass = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.055, 0.16, 16), glassMat);
    beakerGlass.position.y = 0.08;
    plantBeaker.add(beakerGlass);

    const leafStem = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.22, 8), new THREE.MeshStandardMaterial({ color: 0x15803d }));
    leafStem.position.set(0, 0.16, 0);
    leafStem.rotation.z = 0.2;
    plantBeaker.add(leafStem);

    const leafGeo = new THREE.SphereGeometry(0.05, 8, 8);
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.4 });
    const leaf1 = new THREE.Mesh(leafGeo, leafMat);
    leaf1.scale.set(1.5, 0.3, 0.8);
    leaf1.position.set(0.05, 0.24, 0.02);
    leaf1.rotation.set(0.2, 0.4, 0.3);
    plantBeaker.add(leaf1);

    labBenchGroup.add(plantBeaker);

    scene.add(labBenchGroup);

    // --- ENVIRONMENTAL FEATURES & POSTERS ---
    // Wall Clock (Front Wall Top Center)
    const clockGroup = new THREE.Group();
    clockGroup.position.set(0, 4.4, -5.4);

    const clockBody = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.3, 0.05, 32),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2 })
    );
    clockBody.rotation.x = Math.PI / 2;
    clockGroup.add(clockBody);

    const clockRim = new THREE.Mesh(
      new THREE.TorusGeometry(0.3, 0.02, 16, 32),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8 })
    );
    clockGroup.add(clockRim);

    // Clock Hands
    const handMat = new THREE.MeshBasicMaterial({ color: 0x090d16 });
    const hourHand = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.12, 0.01), handMat);
    hourHand.position.set(0, 0.06, 0.03);
    clockGroup.add(hourHand);

    const minHand = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.2, 0.01), handMat);
    minHand.position.set(0, 0.1, 0.035);
    clockGroup.add(minHand);

    const secHand = new THREE.Mesh(
      new THREE.BoxGeometry(0.008, 0.22, 0.01),
      new THREE.MeshBasicMaterial({ color: 0xef4444 })
    );
    secHand.position.set(0, 0.11, 0.04);
    clockGroup.add(secHand);

    clockHandsRef.current = { hour: hourHand, minute: minHand, second: secHand };
    scene.add(clockGroup);

    // Periodic Table Wall Chart (Left of Smartboard)
    const chartGeo = new THREE.PlaneGeometry(1.6, 2.2);
    const chartMat = new THREE.MeshStandardMaterial({ color: 0x1e1b4b, roughness: 0.5 });
    const chartMesh = new THREE.Mesh(chartGeo, chartMat);
    chartMesh.position.set(-4.8, 2.7, -5.4);
    scene.add(chartMesh);

    // Constellation / Solar System Chart (Right of Smartboard)
    const astroGeo = new THREE.PlaneGeometry(1.6, 2.2);
    const astroMat = new THREE.MeshStandardMaterial({ color: 0x022c22, roughness: 0.5 });
    const astroMesh = new THREE.Mesh(astroGeo, astroMat);
    astroMesh.position.set(4.8, 2.7, -5.4);
    scene.add(astroMesh);

    // Indoor Potted Plant (Window Corner)
    const plantGroup = new THREE.Group();
    plantGroup.position.set(-5.5, 0, -4.5);

    const potMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.2, 0.6, 16),
      new THREE.MeshStandardMaterial({ color: 0x9a3412, roughness: 0.8 })
    );
    potMesh.position.y = 0.3;
    plantGroup.add(potMesh);

    const plantLeavesMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.4 });
    for (let l = 0; l < 8; l++) {
      const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), plantLeavesMat);
      leaf.scale.set(1.4, 0.3, 0.8);
      leaf.position.set(
        Math.cos(l * Math.PI / 4) * 0.25,
        0.5 + Math.random() * 0.3,
        Math.sin(l * Math.PI / 4) * 0.25
      );
      leaf.rotation.set(0.3, l * Math.PI / 4, 0.2);
      plantGroup.add(leaf);
    }
    scene.add(plantGroup);

    // --- ANIMATION LOOP ---
    const startTime = performance.now();

    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);
      if (document.hidden) return; // Skip WebGL render pass when tab is backgrounded
      const elapsed = (performance.now() - startTime) / 1000;

      // 1. Clock Hands rotation matching real-time
      if (clockHandsRef.current) {
        const now = new Date();
        const secAngle = -((now.getSeconds() + now.getMilliseconds() / 1000) / 60) * Math.PI * 2;
        const minAngle = -((now.getMinutes() + now.getSeconds() / 60) / 60) * Math.PI * 2;
        const hourAngle = -(((now.getHours() % 12) + now.getMinutes() / 60) / 12) * Math.PI * 2;
        
        clockHandsRef.current.second.rotation.z = secAngle;
        clockHandsRef.current.minute.rotation.z = minAngle;
        clockHandsRef.current.hour.rotation.z = hourAngle;
      }

      // 2. Visual Avatar Animation Engine Rig Update (Natural Kinematics, Zones, Gestures & Expressions)
      if (tutorAvatarGroupRef.current) {
        avatarEngine.updateRig(
          {
            tutorGroup: tutorAvatarGroupRef.current,
            torsoMesh: tutorTorsoRef.current,
            headMesh: tutorHeadRef.current,
            visorMesh: tutorVisorRef.current,
            glassesMesh: tutorGlassesRef.current,
            watchMesh: tutorWatchRef.current,
            tasselGroup: tutorTasselRef.current,
            leftArmGroup: tutorLeftArmRef.current,
            leftForearmGroup: tutorLeftForearmRef.current,
            rightArmGroup: tutorRightArmRef.current,
            rightForearmGroup: tutorRightForearmRef.current,
            leftLegGroup: tutorLeftLegRef.current,
            rightLegGroup: tutorRightLegRef.current,
            heldMarkerMesh: heldMarkerRef.current,
            heldPointerMesh: heldPointerRef.current,
            heldStickGroup: heldStickGroupRef.current,
            heldPropMesh: heldPropRef.current,
            heldGlassMesh: heldGlassRef.current,
            heldNotesMesh: heldNotesRef.current,
            frontDeskChairGroup: frontDeskChairGroupRef.current,
            frontDeskDrawerGroup: frontDeskDrawerGroupRef.current,
            frontDeskLampLight: frontDeskLampLightRef.current,
            frontLaptopLidGroup: frontLaptopLidGroupRef.current,
            frontLaptopScreenMat: frontLaptopScreenMatRef.current,
            proximityRingMesh: proximityRingMeshRef.current,
            proximityRingMat: proximityRingMatRef.current,
            doorWingGroup: doorWingGroupRef.current,
            stickHookGroup: stickHookGroupRef.current,
            laserDotMesh: laserDotMeshRef.current,
          },
          elapsed,
          isSpeaking,
          isTypingLive
        );
      }

      // 3. Bunsen Burner Flame Flicker
      if (flameMeshRef.current && isBurnerOn) {
        flameMeshRef.current.scale.set(
          1 + Math.sin(elapsed * 25) * 0.15,
          1 + Math.cos(elapsed * 30) * 0.2,
          1 + Math.sin(elapsed * 20) * 0.15
        );
        if (flameLightRef.current) {
          flameLightRef.current.intensity = 1.2 + Math.sin(elapsed * 20) * 0.4;
        }
      }

      // 4. Beaker Liquid Bubbles rising
      beakerBubblesRef.current.forEach((bubble, idx) => {
        bubble.position.y += 0.001 * (idx + 1);
        if (bubble.position.y > 0.22) {
          bubble.position.y = 0.04;
        }
      });

      // 5. Newton's Cradle Physics Oscillations
      if (newtonSpheresRef.current.length === 5 && isNewtonCradleSwinging) {
        const swing = Math.sin(elapsed * 4);
        // Leftmost sphere swings out on negative cycle
        if (swing < 0) {
          newtonSpheresRef.current[0].position.z = -0.16 + swing * 0.08;
          newtonSpheresRef.current[0].position.y = 0.12 + Math.abs(swing) * 0.03;
          newtonSpheresRef.current[4].position.z = 0.16;
          newtonSpheresRef.current[4].position.y = 0.12;
        } else {
          // Rightmost sphere swings out on positive cycle
          newtonSpheresRef.current[4].position.z = 0.16 + swing * 0.08;
          newtonSpheresRef.current[4].position.y = 0.12 + swing * 0.03;
          newtonSpheresRef.current[0].position.z = -0.16;
          newtonSpheresRef.current[0].position.y = 0.12;
        }
      }

      // 6. 3D Hologram Dynamic Rotation
      if (hologramGroupRef.current) {
        hologramGroupRef.current.rotation.y = elapsed * 0.8;
        hologramGroupRef.current.position.y = 0.5 + Math.sin(elapsed * 2) * 0.04;
      }

      // 7. Nano Banana Rigid-Body Physics Step (Real-time collisions against desks, smartboard, and floor)
      const physicsDt = Math.min(0.05, Math.max(0.001, elapsed - lastPhysicsElapsedRef.current));
      lastPhysicsElapsedRef.current = elapsed;
      nanoBananaPhysics.update(physicsDt);

      try {
        renderer.render(scene, camera);
      } catch (renderErr) {
        console.warn("3D Classroom frame render paused / context recreating:", renderErr);
      }
    };

    animate();

    // Resize Handler with ResizeObserver
    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries[0] || !rendererRef.current || !cameraRef.current) return;
      const { width: newW, height: newH } = entries[0].contentRect;
      if (newW > 0 && newH > 0) {
        cameraRef.current.aspect = newW / newH;
        cameraRef.current.updateProjectionMatrix();
        rendererRef.current.setSize(newW, newH);
      }
    });

    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      domElem.removeEventListener('webglcontextlost', handleContextLost);
      domElem.removeEventListener('webglcontextrestored', handleContextRestored);
      domElem.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      domElem.removeEventListener('touchstart', handleTouchStart);
      domElem.removeEventListener('touchmove', handleTouchMove);
      domElem.removeEventListener('touchend', handleTouchEnd);
      domElem.removeEventListener('wheel', handleWheel);
      
      // Dispose WebGL Geometries & Materials to avoid VRAM leaks
      scene.traverse((object) => {
        if ((object as THREE.Mesh).isMesh) {
          const mesh = object as THREE.Mesh;
          mesh.geometry?.dispose();
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach(m => m?.dispose());
          } else if (mesh.material) {
            mesh.material?.dispose();
          }
        }
      });

      nanoBananaPhysics.clearAll();
      renderer.dispose();
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
    };
  }, []);

  // UPDATE 3D HOLOGRAPHIC MODEL
  useEffect(() => {
    if (!hologramGroupRef.current) return;
    const group = hologramGroupRef.current;

    // Clear old hologram child meshes
    while (group.children.length > 0) {
      group.remove(group.children[0]);
    }

    const holoMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.8,
      wireframe: true,
      transparent: true,
      opacity: 0.85
    });

    if (activeHologram === 'dna') {
      // DNA Double Helix
      const dnaGroup = new THREE.Group();
      for (let i = 0; i < 20; i++) {
        const angle = i * 0.4;
        const y = (i - 10) * 0.04;
        
        // Strand 1
        const s1 = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 8), holoMat);
        s1.position.set(Math.cos(angle) * 0.18, y, Math.sin(angle) * 0.18);
        dnaGroup.add(s1);

        // Strand 2
        const s2 = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 8), holoMat);
        s2.position.set(Math.cos(angle + Math.PI) * 0.18, y, Math.sin(angle + Math.PI) * 0.18);
        dnaGroup.add(s2);

        // Base pair bridge rung
        const rungGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.36, 6);
        const rung = new THREE.Mesh(rungGeo, holoMat);
        rung.rotation.z = Math.PI / 2;
        rung.rotation.y = -angle;
        rung.position.y = y;
        dnaGroup.add(rung);
      }
      group.add(dnaGroup);
    } else if (activeHologram === 'atom') {
      // Bohr Atom & Electron Orbital Rings
      const nucleus = new THREE.Mesh(
        new THREE.SphereGeometry(0.08, 16, 16),
        new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xef4444, emissiveIntensity: 1.2 })
      );
      group.add(nucleus);

      const rings = [0.18, 0.28, 0.38];
      rings.forEach((r, idx) => {
        const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.008, 8, 24), holoMat);
        ring.rotation.x = Math.PI / 3 * (idx + 1);
        ring.rotation.y = Math.PI / 4 * idx;
        group.add(ring);

        // Orbiting electron
        const electron = new THREE.Mesh(
          new THREE.SphereGeometry(0.02, 8, 8),
          new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x38bdf8, emissiveIntensity: 1.5 })
        );
        electron.position.set(Math.cos(idx * 2) * r, Math.sin(idx * 2) * r, 0);
        ring.add(electron);
      });
    } else if (activeHologram === 'planet') {
      // Planet with Rings (Saturn style)
      const planet = new THREE.Mesh(new THREE.SphereGeometry(0.15, 16, 16), holoMat);
      group.add(planet);

      const ringMesh = new THREE.Mesh(new THREE.RingGeometry(0.22, 0.38, 32), holoMat);
      ringMesh.rotation.x = Math.PI / 2.5;
      group.add(ringMesh);
    } else {
      // Calculus 3D Quadric Surface / Torus Knot manifold
      const surfaceGeo = new THREE.TorusKnotGeometry(0.14, 0.04, 48, 12, 2, 3);
      const surfaceMesh = new THREE.Mesh(surfaceGeo, holoMat);
      group.add(surfaceMesh);
    }
  }, [activeHologram]);

  // UPDATE BUNSEN BURNER STATE
  useEffect(() => {
    if (flameMeshRef.current && flameLightRef.current) {
      flameMeshRef.current.visible = isBurnerOn;
      flameLightRef.current.visible = isBurnerOn;
    }
  }, [isBurnerOn]);

  // UPDATE OPTICAL LASER STATE
  useEffect(() => {
    if (laserBeamRef.current) {
      laserBeamRef.current.visible = isLaserOn;
    }
    rainbowRaysRef.current.forEach(ray => {
      ray.visible = isLaserOn;
    });
  }, [isLaserOn]);

  // 3D Classroom AI Tools Suite Configuration
  const classroomAiTools: ClassroomAiToolItem[] = useMemo(() => [
    {
      id: 'science_lab',
      title: '3D Science Lab Bench',
      category: 'Lab',
      icon: '🔬',
      badge: 'Interactive',
      description: 'Switch camera to the 3D lab bench with interactive test tubes, prism, laser, and hologram emitters.',
      action: () => {
        setCameraView('lab_bench');
        showNotification?.("3D Interactive Science Lab bench active 🔬", "info");
      }
    },
    {
      id: 'ai_draw',
      title: 'AI Figure & Diagram Generator',
      category: 'Visual',
      icon: '🎨',
      badge: 'AI Vector',
      description: 'Generate real-time vector diagrams, physics schematics, and chemical pathways directly on the 3D Smartboard.',
      action: () => {
        setShowAiDrawStudioModal(true);
      }
    },
    {
      id: 'exec_summary',
      title: '5-Layer Executive Summary',
      category: 'Mastery',
      icon: '⚡',
      badge: 'Revision',
      description: 'Comprehensive 5-layer academic synthesis: Core Intuition, Mathematical Formalism, Exam Traps, Real Applications, and Memory Map.',
      action: () => {
        handleOpenExecutiveSummary();
      }
    },
    {
      id: 'formula_mastery',
      title: '10-Step Formula Architecture',
      category: 'Formula',
      icon: '📐',
      badge: 'Mastery',
      description: 'Breakdown formulas step-by-step: physical derivation, dimensional analysis, variable boundaries, and multi-level drills.',
      action: () => {
        setShowFormulaModal(true);
      }
    },
    {
      id: 'visual_map',
      title: 'Visual Concept Map Studio',
      category: 'Visual',
      icon: '🗺️',
      badge: 'Schematic',
      description: 'Hierarchical node diagram connecting concepts, formulas, applications, and prerequisites visually.',
      action: () => {
        setShowVisualMapStudioModal(true);
      }
    },
    {
      id: 'visual_transform',
      title: 'Visual Transformation Architect',
      category: 'Pedagogy',
      icon: '🔄',
      badge: '5 Modes',
      description: 'Transform chalkboard layout across Text-Teaching (70/30), Figure-Teaching (80/20), and Hybrid Pedagogical split modes.',
      action: () => {
        setShowVisualTransformationModal(true);
      }
    },
    {
      id: 'rapid_fire',
      title: 'Rapid Fire Question Drill',
      category: 'Practice',
      icon: '🎯',
      badge: '80-100 Qs',
      description: 'High-speed speed-run drills testing definitions, formula recall, and critical exam edge-cases under timer.',
      action: () => {
        setShowRapidFireDrillModal(true);
      }
    },
    {
      id: 'practice_questions',
      title: 'Board Practice & Problem Studio',
      category: 'Practice',
      icon: '📝',
      badge: 'Multi-Tier',
      description: 'Tiered numerical problems and conceptual derivation practice with multi-step hints and step-by-step solutions.',
      action: () => {
        setShowPracticeQuestionModal(true);
      }
    },
    {
      id: 'recap_30s',
      title: '30s Rapid Dynamic Recap',
      category: 'Revision',
      icon: '⏱️',
      badge: 'Quick',
      description: 'Fast 30-second bulleted overview of the core principles and board exam takeaways of the active topic.',
      action: () => {
        handleOpen30sRecap();
      }
    },
    {
      id: 'socratic_tutor',
      title: 'Socratic Tutor & Doubt Clarifier',
      category: 'AI Chat',
      icon: '💡',
      badge: 'Voice/Text',
      description: 'Interact directly with Professor Clarity to resolve subtle doubts, ask "why?", and request intuitive analogies.',
      action: () => {
        setShowChatControlsModal(true);
      }
    },
    {
      id: 'ambient_lighting_inspector',
      title: '💡 Ambient Lighting Inspector',
      category: 'Display & Graphics',
      icon: '💡',
      badge: 'Nano Banana 2',
      description: 'Real-time light intensity, color temperature (Kelvin), and material reflectivity vector calibration inspector.',
      action: () => {
        setShowLightingInspectorModal(true);
        playSoundEffect('click');
      }
    },
    {
      id: 'security_shield',
      title: 'Security & DRM Shield',
      category: 'Security',
      icon: '🛡️',
      badge: 'DRM Active',
      description: 'Defense-in-depth content integrity, watermark protection, and tamper-proof lecture verification.',
      action: () => {
        setShowSecurityModal(true);
      }
    },
    {
      id: 'banana_physics',
      title: '🍌 Nano Banana 3D Physics Lab & Collisions',
      category: 'Physics & STEM',
      icon: '🍌',
      badge: 'Rigid-Body 3D',
      description: 'Spawn & launch realistic 3D Nano Bananas that collide physically with desks, chairs, smartboard, floor, and lab apparatus.',
      action: () => {
        setShowBananaPhysicsModal(true);
        playSoundEffect('chime');
      }
    },
    {
      id: 'react_health',
      title: '3D Engine Diagnostics',
      category: 'System',
      icon: '🩺',
      badge: 'Engine',
      description: 'Real-time FPS, draw calls, WebGL texture memory, and audio synthesizer state inspection.',
      action: () => {
        setShowReactHealthModal(true);
      }
    }
  ], [handleOpenExecutiveSummary, handleOpen30sRecap, showNotification]);

  return (
    <div 
      ref={lectureHallRootRef}
      className={cn(
        "flex flex-col relative overflow-hidden font-sans select-none transition-all duration-300",
        isMaximized 
          ? "fixed inset-0 z-[9999] w-screen h-screen" 
          : "w-full h-full",
        theme === 'dark' ? "bg-slate-950 text-slate-100" : "bg-slate-900 text-slate-100"
      )}
    >
      {/* THREE.JS 3D CANVAS CONTAINER */}
      <div 
        ref={containerRef} 
        className="w-full h-full cursor-grab active:cursor-grabbing relative"
      />

      {/* UNIFIED TOP NAVIGATION & QUICK-HUD BAR (GUARANTEED ZERO-OVERLAP & ALWAYS VISIBLE CONTROLS) */}
      <div className="absolute top-2 sm:top-3 left-2 right-2 sm:left-4 sm:right-4 z-40 pointer-events-none flex items-center justify-between gap-1.5 sm:gap-2 select-none max-w-full">
        {/* LEFT & CENTER WRAPPER: Scrollable horizontally so right controls NEVER get pushed off-screen */}
        <div className="pointer-events-auto flex items-center gap-1 sm:gap-1.5 overflow-x-auto scrollbar-hide touch-pan-x py-0.5 min-w-0 flex-1 pr-1">
          {/* LEFT CLUSTER: Back & Command Palette & Prof Omni AI */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            <button
              onClick={() => {
                if (onClose) onClose();
                playSoundEffect('click');
              }}
              className="h-8 sm:h-9 px-2.5 sm:px-3 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-slate-800 text-slate-300 hover:text-white shadow-xl backdrop-blur-md flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer group shrink-0"
              title="Exit Virtual Lecture / Back"
              aria-label="Back"
            >
              <ArrowLeft size={16} className="group-hover:-translate-x-0.5 transition-transform" />
              <span className="hidden md:inline">Back</span>
            </button>

            {/* Hidden per user request: open smart command palette */}

            {/* Professor Omni AI Master Button */}
            <button
              onClick={() => {
                setShowProfessorOmniModal(true);
                playSoundEffect('chime');
              }}
              className="h-8 sm:h-9 px-2.5 sm:px-3 rounded-xl bg-gradient-to-r from-amber-500 via-indigo-600 to-cyan-500 hover:from-amber-400 hover:via-indigo-500 hover:to-cyan-400 text-white shadow-lg shadow-amber-500/20 border border-amber-400/50 text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer group shrink-0 active:scale-95"
              title="Professor Omni AI: Master Socratic Intelligence & Dynamic Lecture Studio"
            >
              <span className="text-sm">⚡</span>
              <span className="tracking-wide hidden xs:inline">Prof. Omni AI</span>
              <span className="tracking-wide xs:hidden">Omni</span>
            </button>
          </div>

          {/* CENTER CLUSTER: Camera Presets, Lecture Controls Dropdown, Teaching Archetype */}
          <div className="flex items-center gap-1 sm:gap-1.5 p-1 rounded-2xl bg-slate-950/90 border border-indigo-500/40 shadow-2xl backdrop-blur-xl shrink-0">
            {/* Quick Camera Presets */}
            <div className="flex items-center bg-slate-900/90 rounded-xl p-0.5 border border-slate-800 shrink-0">
              <button
                onClick={() => { setCameraView('front_row'); playSoundEffect('click'); }}
                className={cn(
                  "px-2 py-1 rounded-lg text-[10px] sm:text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                  activeCameraView === 'front_row' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                )}
                title="Front Row View (Overview of Lecture Hall & Board)"
              >
                <span>🏛️</span>
                <span className="hidden xs:inline">Front Row</span>
              </button>
              <button
                onClick={() => { setCameraView('board_focus'); playSoundEffect('click'); }}
                className={cn(
                  "px-2 py-1 rounded-lg text-[10px] sm:text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                  activeCameraView === 'board_focus' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                )}
                title="Smartboard Focus View"
              >
                <span>📋</span>
                <span className="hidden xs:inline">Board</span>
              </button>
              <button
                onClick={() => { setCameraView('avatar_focus'); playSoundEffect('click'); }}
                className={cn(
                  "px-2 py-1 rounded-lg text-[10px] sm:text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                  activeCameraView === 'avatar_focus' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                )}
                title="Professor Focus View"
              >
                <span>👨‍🏫</span>
                <span className="hidden xs:inline">Prof</span>
              </button>
              <button
                onClick={() => { setCameraView('lab_bench'); playSoundEffect('click'); }}
                className={cn(
                  "px-2 py-1 rounded-lg text-[10px] sm:text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                  activeCameraView === 'lab_bench' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                )}
                title="Science Lab Bench Focus"
              >
                <span>🔬</span>
                <span className="hidden xs:inline">Lab</span>
              </button>
            </div>

            {/* Hidden per user request: controls drop-down list button */}

            {/* Teaching Archetype Quick Trigger */}
            <button
              onClick={() => {
                setShowTeacherStyleModal(true);
                playSoundEffect('chime');
              }}
              className="px-2 py-1 rounded-xl bg-gradient-to-r from-emerald-600/40 to-teal-600/40 hover:from-emerald-600/60 hover:to-teal-600/60 border border-emerald-500/40 text-emerald-300 text-[10px] sm:text-xs font-bold flex items-center gap-1 transition-all cursor-pointer shrink-0 shadow-sm"
              title="Switch Teaching Archetype (Socratic, Storyteller, Exam Tactician, Mistake Surgery)"
            >
              <span>{selectedTeacherStyle.avatarIcon}</span>
              <span className="hidden sm:inline">{selectedTeacherStyle.shortName}</span>
            </button>
          </div>
        </div>

        {/* RIGHT CLUSTER: Hide, Speaker, Maximize (PINNED & ALWAYS VISIBLE) */}
        <div className="pointer-events-auto flex items-center gap-1 sm:gap-1.5 shrink-0 ml-auto z-50 pl-1">
          {/* 1. Hide Button */}
          <button
            id="btn-hud-hide-toggle"
            onClick={() => {
              setIsSmartboardNotesMinimized(prev => !prev);
              playSoundEffect('click');
            }}
            className={cn(
              "h-8 sm:h-9 px-2 sm:px-2.5 rounded-xl border text-[10px] sm:text-xs font-extrabold transition-all cursor-pointer shrink-0 flex items-center gap-1 shadow-md",
              !isSmartboardNotesMinimized ? "bg-indigo-600 text-white border-indigo-400" : "bg-slate-950/95 text-indigo-300 border-indigo-500/40 hover:text-white"
            )}
            title={isSmartboardNotesMinimized ? "Show Smartboard Notes (Shortcut: N)" : "Hide Smartboard Notes (Shortcut: N)"}
          >
            <BookOpen size={14} className="shrink-0" />
            <span className="inline">{isSmartboardNotesMinimized ? "Show" : "Hide"}</span>
          </button>

          {/* 2. Speaker Button */}
          <button
            id="btn-hud-speaker-toggle"
            onClick={() => {
              setAudioEnabled(prev => !prev);
              if (audioEnabled) stopSpeech();
              playSoundEffect('click');
            }}
            className={cn(
              "h-8 sm:h-9 px-2 sm:px-2.5 rounded-xl border text-[10px] sm:text-xs font-extrabold transition-all cursor-pointer shrink-0 flex items-center gap-1 shadow-md",
              audioEnabled ? "bg-slate-950/95 text-emerald-400 border-emerald-500/50 hover:bg-slate-900" : "bg-red-950/90 text-red-300 border-red-500/50"
            )}
            title={audioEnabled ? "Speaker Active (Click to Mute, Shortcut: M)" : "Speaker Muted (Click to Unmute, Shortcut: M)"}
          >
            {audioEnabled ? <Volume2 size={14} className="shrink-0 text-emerald-400" /> : <VolumeX size={14} className="shrink-0 text-red-400" />}
            <span className="inline">{audioEnabled ? "Speaker" : "Muted"}</span>
          </button>

          {/* 3. Maximize / Minimize Button */}
          <button
            id="btn-hud-maximize-toggle"
            onClick={() => {
              toggleMaximizeLectureHall();
              playSoundEffect('click');
            }}
            className="h-8 sm:h-9 px-2 sm:px-2.5 rounded-xl bg-slate-950/95 hover:bg-slate-900 text-indigo-200 hover:text-white border border-indigo-500/40 transition-all cursor-pointer shrink-0 shadow-md flex items-center gap-1 text-[10px] sm:text-xs font-extrabold"
            title={isMaximized ? "Exit Fullscreen Stage" : "Maximize Stage to Fullscreen Theater"}
          >
            {isMaximized ? <Minimize2 size={14} className="shrink-0 text-indigo-300" /> : <Maximize2 size={14} className="shrink-0 text-indigo-300" />}
            <span className="inline">{isMaximized ? "Restore" : "Maximize"}</span>
          </button>
        </div>
      </div>

      {/* VIRTUAL 3D CURRICULUM & LESSON CONTROLLER BAR (SEAMLESS 3D INTEGRATION) */}
      <div className="absolute top-14 sm:top-16 left-2 right-2 sm:left-4 sm:right-4 z-30 pointer-events-auto">
        <Virtual3DCurriculumBar
          selectedBoard={activeBoard}
          onOpenBoardSelector={() => {
            setShowQuickBoardModal(true);
            playSoundEffect('click');
          }}
          difficulty={activeDifficulty}
          onSelectDifficulty={(diff) => {
            setActiveDifficulty(diff);
            if (onSelectDifficulty) onSelectDifficulty(diff);
            playSoundEffect('click');
            showNotification?.(`Learning level switched to ${diff}`, 'info');
          }}
          subject={activeSubject}
          onSelectSubject={(subj) => {
            setActiveSubject(subj);
            if (onParentSelectSubject) onParentSelectSubject(subj);
            const firstTopic = getFirstTopicForSubject(subj);
            handleStageSelectedChapter(firstTopic, true);
            playSoundEffect('click');
            showNotification?.(`Subject switched to ${subj}. Loaded topic: ${firstTopic}`, 'info');
          }}
          activeTopic={activeTopicTitle || stagedTopicTitle || userTopic || 'Select Topic'}
          onSelectTopic={(topic) => {
            handleStageSelectedChapter(topic, true);
            playSoundEffect('click');
          }}
          onOpenTopicsModal={() => {
            setShowTopicModal(true);
            playSoundEffect('click');
          }}
          activeLesson={activeLessonNum}
          onSelectLesson={(lesson) => {
            setActiveLessonNum(lesson);
            if (onSelectLesson) onSelectLesson(lesson);
            const parsedNum = parseInt(lesson, 10);
            if (!isNaN(parsedNum) && parsedNum >= 1 && parsedNum <= LESSON_TOPICS.length) {
              handleSelectLesson(parsedNum - 1, false);
            }
            playSoundEffect('click');
            showNotification?.(`Active lesson set to L${lesson}`, 'info');
          }}
          totalLessons={LESSON_TOPICS.length > 0 ? LESSON_TOPICS.length : 12}
          onOpenSyllabus={() => {
            setShowClassroomSyllabusModal(true);
            playSoundEffect('click');
          }}
          onOpenAiTools={() => {
            setShowClassroomAiToolsModal(true);
            playSoundEffect('chime');
          }}
          onOpenVocalPersona={() => {
            setShowVocalPersonaModal(true);
            playSoundEffect('chime');
          }}
          isCollapsed={isCurriculumBarCollapsed}
          onToggleCollapse={() => setIsCurriculumBarCollapsed(prev => !prev)}
          isLoadingContent={isContentLoading}
          loadingEstimateFormatted={isContentLoading ? `Est. ~${formattedEstimate} (${formattedElapsed} elapsed)` : undefined}
          pingSpeedMs={pingSpeed}
          networkStatus={connectionQuality}
        />
      </div>

      {/* Floating Smartboard Interactive Overlay (When zoomed or active) */}
      {isSmartboardNotesMinimized ? (
        <div className="absolute bottom-20 left-2 sm:bottom-20 sm:left-6 z-30 flex items-center gap-2 sm:gap-2.5 bg-slate-950/90 border border-indigo-500/40 px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-2xl shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-3 duration-300 max-w-[calc(100vw-130px)] sm:max-w-none">
          <span className={cn(
            "w-2.5 h-2.5 rounded-full shrink-0",
            isLectureActive && !isLecturePaused ? "bg-emerald-400 animate-ping" : isLecturePaused ? "bg-amber-400" : "bg-indigo-500"
          )} />
          <div className="flex flex-col max-w-[140px] sm:max-w-[280px]">
            <span className="text-xs font-bold text-slate-100 truncate">{activeTopicTitle.split(':')[0]}</span>
            <span className="text-[9px] sm:text-[10px] text-indigo-300 font-mono truncate">
              {isLectureActive ? `Seg ${currentSyncStep}/${totalSyncSteps}` : LESSON_TOPICS.length > 0 ? `Slide ${activeLessonIdx + 1}/${LESSON_TOPICS.length}` : 'Smartboard Active'}
            </span>
          </div>
          <div className="flex items-center gap-1 ml-1 sm:ml-2 shrink-0">
            <button
              onClick={handleStartVirtualLearning}
              disabled={isInitializingLecture}
              className={cn(
                "p-1.5 rounded-xl text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer border shadow-md",
                isLectureActive && !isLecturePaused ? "bg-amber-500/20 text-amber-300 border-amber-500/40" : "bg-emerald-600 text-white border-emerald-400/40 hover:bg-emerald-500"
              )}
              title={isLectureActive && !isLecturePaused ? "Pause Lecture" : "Play / Resume Lecture"}
            >
              {isLectureActive && !isLecturePaused ? <Pause size={12} className="fill-amber-300" /> : <Play size={12} className="fill-white" />}
            </button>
            <button
              onClick={() => {
                setIsSmartboardNotesMinimized(false);
                setSmartboardLayout('center');
                setCameraView('board_focus');
              }}
              className="px-2.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 shadow cursor-pointer transition-all"
              title="Expand Presentation Smartboard Middle View"
            >
              <Maximize2 size={12} />
              <span>Middle View</span>
            </button>
            {/* Hidden per user request: Syllabus Expansion Controls */}
            {/* Direct Quad-Speed Synchronization Trigger */}
            <button
              id="btn-smartboard-speed-sync-direct"
              onClick={() => {
                setShowQuadSpeedModal(true);
                playSoundEffect('click');
              }}
              className="px-2.5 py-1.5 rounded-xl bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-300 text-xs font-bold flex items-center gap-1.5 shadow cursor-pointer transition-all shrink-0"
              title="Quad-Speed Synchronization Hub (Typing, Pronouncing, Visualizing, Scrolling)"
            >
              <Sliders size={12} className="text-indigo-400" />
              <span className="hidden sm:inline">Speed Sync</span>
              <span className="px-1.5 py-0.5 rounded bg-indigo-500/30 text-indigo-200 text-[10px] font-mono">
                {activeQuadSpeeds.typingSpeed}x / {activeQuadSpeeds.pronouncingSpeed}x
              </span>
            </button>
            <LectureControlsDropdown
              onShowAll={skipSynchronizedLectureToFull}
              onNarrate={() => narrateCurrentBoardContent()}
              isSpeaking={isSpeaking}
              onTeachLike={() => {
                setShowTeacherStyleModal(true);
                playSoundEffect('chime');
              }}
              currentTeacherStyleName={selectedTeacherStyle.shortName}
              currentTeacherAvatarIcon={selectedTeacherStyle.avatarIcon}
              onAvatarPhoto={() => {
                setShowAvatarPhotoModal(true);
                playSoundEffect('click');
              }}
              graphicsQualityMode={graphicsQualityMode}
              onSelectGraphicsQuality={(mode) => {
                setGraphicsQualityMode(mode);
                playSoundEffect('click');
              }}
              onFormulaArchitect={() => {
                setShowVisualPresentationModal(true);
                playSoundEffect('chime');
              }}
              teachingPresentationMode={teachingPresentationMode}
              onSelectTeachingMode={(mode) => {
                setTeachingPresentationMode(mode);
                playSoundEffect('click');
              }}
              lectureDeliveryFormat={lectureDeliveryFormat}
              onSelectDeliveryFormat={handleSelectDeliveryFormat}
              onMinimizeNote={() => {
                setIsSmartboardNotesMinimized(false);
                setSmartboardLayout('center');
                setCameraView('board_focus');
                playSoundEffect('click');
              }}
              isNotesMinimized={true}
              buttonLabel="Actions ▾"
              align="right"
              onOpenQuadSpeedSync={() => {
                setShowQuadSpeedModal(true);
                playSoundEffect('click');
              }}
              currentQuadSpeedSummary={`${activeQuadSpeeds.typingSpeed}x / ${activeQuadSpeeds.pronouncingSpeed}x`}
            />
          </div>
        </div>
      ) : (
      <div 
        id="smartboard-teaching-surface"
        ref={boardScrollContainerRef}
        className={cn(
          "absolute transition-all duration-500 z-20 pointer-events-auto scroll-smooth",
          isSmartboardAutoZoomed ? "scale-[1.03] ring-4 ring-indigo-400/50 shadow-indigo-500/50" : "scale-100",
          smartboardLayout === 'fullscreen'
            ? "top-[75px] sm:top-[80px] left-1/2 -translate-x-1/2 w-[99vw] max-w-[99vw] max-h-[calc(100vh-85px)] bg-slate-950/98 border-2 border-indigo-400/60 rounded-2xl p-4 sm:p-7 shadow-2xl backdrop-blur-3xl overflow-y-auto flex flex-col ring-2 ring-indigo-400/40 z-20 pb-16"
            : smartboardLayout === 'expanded'
            ? "top-[80px] sm:top-[85px] left-1/2 -translate-x-1/2 w-[98vw] max-w-[96vw] max-h-[calc(100vh-95px)] bg-slate-950/98 border-2 border-indigo-500/50 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl backdrop-blur-3xl overflow-y-auto flex flex-col ring-2 ring-indigo-500/30 z-20 pb-16"
            : smartboardLayout === 'center'
            ? "top-[80px] sm:top-[85px] left-1/2 -translate-x-1/2 w-[98vw] sm:w-[860px] md:w-[1060px] lg:w-[1280px] xl:w-[1480px] max-h-[calc(100vh-95px)] bg-slate-950/95 border border-indigo-500/40 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl backdrop-blur-2xl overflow-y-auto flex flex-col ring-1 ring-indigo-500/20 z-20 pb-16"
            : "top-[80px] sm:top-[85px] left-2 right-2 sm:right-auto sm:left-4 w-auto sm:w-[620px] md:w-[760px] lg:w-[920px] xl:w-[1060px] max-h-[calc(100vh-95px)] bg-slate-950/90 border border-indigo-500/30 rounded-2xl sm:rounded-3xl p-3.5 sm:p-5 shadow-2xl backdrop-blur-xl overflow-y-auto flex flex-col z-20 pb-16"
        )}
      >
        {/* Mobile Pull-Down / Collapse Drag Handle */}
        <div 
          onClick={() => setIsSmartboardNotesMinimized(true)}
          className="w-full flex sm:hidden items-center justify-center pb-2 cursor-pointer"
          title="Tap to minimize notes"
        >
          <div className="w-12 h-1.5 rounded-full bg-slate-700/80 hover:bg-slate-500 transition-colors" />
        </div>

        <div className="sticky top-0 z-40 bg-slate-950/98 backdrop-blur-xl -mx-3.5 -mt-3.5 px-2.5 pt-2.5 sm:-mx-6 sm:-mt-6 sm:px-5 sm:pt-3.5 pb-2 mb-3 border-b border-slate-800/80 shadow-md flex flex-wrap items-center justify-between gap-1.5 shrink-0 overflow-visible">
          <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
            <span className={cn(
              "w-2 h-2 rounded-full shrink-0",
              isLectureActive && !isLecturePaused ? "bg-emerald-400 animate-ping" : isLecturePaused ? "bg-amber-400" : "bg-indigo-500"
            )} />
            <span className="text-[10px] sm:text-[11px] font-black uppercase tracking-wider text-indigo-400 shrink-0">
              Presentation Smartboard {LESSON_TOPICS.length > 0 ? ('• ' + (activeLessonIdx + 1) + '/' + LESSON_TOPICS.length) : '• Live'}
            </span>
            {stagedTopicTitle && (
              <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 text-[9px] font-extrabold animate-pulse flex items-center gap-1 shrink-0">
                <Sparkles size={9} className="text-amber-300" />
                <span className="hidden sm:inline">Queued: Click [START]</span>
                <span className="inline sm:hidden">Queued</span>
              </span>
            )}
            {isLectureActive && totalSyncSteps > 0 && (
              <span className="px-1.5 py-0.5 rounded-md bg-indigo-950/80 border border-indigo-500/30 text-[9px] font-mono text-indigo-300 shrink-0">
                Seg {currentSyncStep}/{totalSyncSteps}
              </span>
            )}
            {isTypingLive && (
              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 animate-pulse flex items-center gap-1 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="hidden sm:inline">Live Writing</span>
              </span>
            )}
            {(boardContent.includes('<svg') || boardContent.includes('[Draw:') || boardContent.toLowerCase().includes('figure')) && (
              <button
                onClick={() => setCameraView('figure_focus')}
                className="px-1.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[9px] font-bold flex items-center gap-1 hover:bg-amber-500/30 transition-all cursor-pointer animate-pulse shadow-sm shrink-0"
                title="Talking about a figure: Click to switch camera to Smartboard + Figure + Prof Clarity focus view"
              >
                <Sparkles size={9} className="text-amber-400" />
                <span>Talking About Figure</span>
              </button>
            )}
          </div>
          <div className="flex items-center gap-1 sm:gap-1.5 flex-nowrap sm:flex-wrap shrink-0 overflow-x-auto scrollbar-hide touch-pan-x py-0.5 max-w-full">
            {/* Hidden per user request: syllabus controls button before Edit Text/Q&A */}
            {/* Direct Quad-Speed Synchronization Trigger */}
            <button
              onClick={() => handleOpenQuestionSolutionEditor()}
              className="px-2 py-1 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-400/50 text-indigo-200 hover:text-white text-[10px] sm:text-xs font-bold flex items-center gap-1 shadow cursor-pointer transition-all shrink-0 active:scale-95"
              title="Edit Asked Question & Solution text directly (or double-click any question/solution text below)"
            >
              <Pencil size={11} className="text-indigo-300" />
              <span>Edit Text / Q&A</span>
            </button>
            <button
              id="btn-smartboard-speed-sync-direct-bottom"
              onClick={() => {
                setShowQuadSpeedModal(true);
                playSoundEffect('click');
              }}
              className="px-2 py-1 rounded-xl bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-300 text-[10px] sm:text-xs font-bold flex items-center gap-1 shadow cursor-pointer transition-all shrink-0"
              title="Quad-Speed Synchronization Hub (Typing, Pronouncing, Visualizing, Scrolling)"
            >
              <Sliders size={11} className="text-indigo-400 shrink-0" />
              <span className="hidden sm:inline">Speed Sync</span>
              <span className="inline sm:hidden">Speed</span>
              <span className="px-1 py-0.2 rounded bg-indigo-500/30 text-indigo-200 text-[9px] font-mono">
                {activeQuadSpeeds.typingSpeed}x/{activeQuadSpeeds.pronouncingSpeed}x
              </span>
            </button>
            {/* Hidden per user request: lecture controls after speed sync button */}

            {/* Hidden per user request: syncing class class 101 button */}

            {/* Hidden per user request: start button before spq button */}

            {/* spq (Solved Practice Questions) Button - Added per user request */}
            <button
              type="button"
              onClick={handleSolvePracticeQuestions}
              className={cn(
                "px-2 sm:px-2.5 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1 transition-all cursor-pointer border shrink-0 shadow-md active:scale-95",
                theme === 'dark'
                  ? "bg-purple-500/20 text-purple-300 border-purple-500/40 hover:bg-purple-500/30"
                  : "bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100"
              )}
              title="Solve & Explain Suggested Practice Questions (SPQ)"
            >
              <GraduationCap size={11} className="text-purple-400" />
              <span>spq</span>
            </button>

            {/* Replay Synchronized Lecture */}
            <button
              onClick={replaySynchronizedLecture}
              className="px-2 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer shrink-0"
              title="Replay lecture from the start with synchronized writing and speech"
            >
              <RotateCcw size={11} />
              <span className="hidden sm:inline">Replay</span>
            </button>

            {LESSON_TOPICS.length > 0 && (
              <div className="flex items-center gap-0.5 sm:gap-1">
                <button
                  onClick={() => handleSelectLesson((activeLessonIdx - 1 + LESSON_TOPICS.length) % LESSON_TOPICS.length)}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                  title="Previous Slide"
                >
                  <ChevronLeft size={16} />
                </button>
                <button
                  onClick={() => handleSelectLesson((activeLessonIdx + 1) % LESSON_TOPICS.length)}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                  title="Next Slide"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
            )}

            {/* Smartboard Multi-Layout Selector (Reset, Side, Middle, Cinema, Stage) */}
            <div className="flex items-center bg-slate-900 border border-slate-700/80 rounded-xl p-0.5 shrink-0">
              <button
                onClick={() => { resetSmartboardPosition(); playSoundEffect('click'); }}
                className="px-2 py-0.5 rounded-lg text-[10px] font-bold text-emerald-300 hover:text-white transition-all cursor-pointer bg-slate-800 hover:bg-slate-700 border border-emerald-500/40 flex items-center gap-1 shadow-sm"
                title="Reset Smartboard to Default Reset Position (Docked Left)"
              >
                <RotateCcw size={10} />
                <span>Reset</span>
              </button>
              <button
                onClick={() => { setSmartboardLayout('left'); playSoundEffect('click'); }}
                className={cn(
                  "px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer",
                  smartboardLayout === 'left' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                )}
                title="Dock Smartboard to Side"
              >
                Side
              </button>
              <button
                onClick={() => { setSmartboardLayout('center'); playSoundEffect('click'); }}
                className={cn(
                  "px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer",
                  smartboardLayout === 'center' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                )}
                title="Center Smartboard in Middle View"
              >
                Middle
              </button>
              <button
                onClick={() => { setSmartboardLayout('expanded'); playSoundEffect('click'); }}
                className={cn(
                  "px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer",
                  smartboardLayout === 'expanded' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                )}
                title="Expand Smartboard to Ultra-Wide Cinema Mode"
              >
                Cinema
              </button>
              <button
                onClick={() => { setSmartboardLayout('fullscreen'); playSoundEffect('click'); }}
                className={cn(
                  "px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer",
                  smartboardLayout === 'fullscreen' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                )}
                title="Full Stage Smartboard Immersion"
              >
                Stage
              </button>
            </div>

            {/* Direct Quick Controls: Hide, Speaker, Maximize */}
            <div className="flex items-center gap-1 shrink-0 border-l border-slate-800 pl-1.5 ml-1">
              {/* Hidden per user request: smartboard and standard play button before hide button */}

              {/* Hide Button */}
              <button
                id="btn-sb-hdr-hide"
                onClick={() => {
                  setIsSmartboardNotesMinimized(prev => !prev);
                  playSoundEffect('click');
                }}
                className={cn(
                  "px-2 py-1 rounded-xl text-[10px] sm:text-xs font-bold flex items-center gap-1 transition-all cursor-pointer border shrink-0 shadow-sm",
                  !isSmartboardNotesMinimized ? "bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-400" : "bg-slate-900 hover:bg-slate-800 text-indigo-200 border-indigo-500/40"
                )}
                title={isSmartboardNotesMinimized ? "Show Smartboard Notes Panel" : "Hide Smartboard Notes Panel"}
              >
                <BookOpen size={11} className="shrink-0" />
                <span>{isSmartboardNotesMinimized ? "Show" : "Hide"}</span>
              </button>

              {/* Speaker Button */}
              <button
                id="btn-sb-hdr-speaker"
                onClick={() => {
                  setAudioEnabled(prev => !prev);
                  if (audioEnabled) stopSpeech();
                  playSoundEffect('click');
                }}
                className={cn(
                  "px-2 py-1 rounded-xl text-[10px] sm:text-xs font-bold flex items-center gap-1 transition-all cursor-pointer border shrink-0 shadow-sm",
                  audioEnabled ? "bg-emerald-950/90 hover:bg-emerald-900 text-emerald-300 border-emerald-500/50" : "bg-rose-950/90 hover:bg-rose-900 text-rose-300 border-rose-500/50"
                )}
                title={audioEnabled ? "Audio Speech Active (Click to Mute)" : "Audio Speech Muted (Click to Unmute)"}
              >
                {audioEnabled ? <Volume2 size={11} className="shrink-0 text-emerald-400" /> : <VolumeX size={11} className="shrink-0 text-rose-400" />}
                <span>{audioEnabled ? "Speaker" : "Muted"}</span>
              </button>

              {/* Maximize / Minimize Button */}
              <button
                id="btn-sb-hdr-maximize"
                onClick={() => {
                  toggleMaximizeLectureHall();
                  playSoundEffect('click');
                }}
                className="px-2 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-indigo-200 hover:text-white text-[10px] sm:text-xs font-bold flex items-center gap-1 transition-all cursor-pointer shrink-0 shadow-sm"
                title={isMaximized ? "Restore Normal Stage View" : "Maximize Stage to Fullscreen Theater"}
              >
                {isMaximized ? <Minimize2 size={11} className="shrink-0" /> : <Maximize2 size={11} className="shrink-0" />}
                <span>{isMaximized ? "Restore" : "Maximize"}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dedicated Selected Prompt Banner on Presentation Smartboard (Matching Right Screen in Standard Tutor Play Mode) */}
        {virtual3dPromptMode === 'smartboard' && (selectedPromptText || stagedTopicTitle || userTopic) && (
          <div className="mb-3.5 p-3.5 rounded-2xl bg-gradient-to-br from-slate-900/95 via-indigo-950/80 to-slate-900/95 border-2 border-sky-500/50 shadow-2xl shrink-0 ring-2 ring-sky-500/20 backdrop-blur-md">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30 shrink-0">
                  <MessageSquare size={15} className="text-sky-300" />
                </span>
                <div className="min-w-0">
                  <div className="text-[11px] font-black uppercase tracking-wider text-sky-400 flex items-center gap-1.5 truncate">
                    <span>Prompt Selected on Smartboard</span>
                  </div>
                </div>
              </div>

              {/* Display Mode Toggle for Virtual 3D */}
              <div className="flex items-center gap-1 bg-slate-950/90 p-1 rounded-xl border border-slate-800 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setVirtual3dPromptMode('smartboard');
                    playSoundEffect('click');
                    if (showNotification) {
                      showNotification("Switched to: Prompt Selected on Smartboard", "info");
                    }
                  }}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-[9px] sm:text-[10px] font-black tracking-wide uppercase transition-all cursor-pointer select-none",
                    (virtual3dPromptMode as string) === 'smartboard'
                      ? "bg-sky-500 text-slate-950 font-extrabold shadow-sm"
                      : "text-slate-400 hover:text-slate-200"
                  )}
                  title="Display only the prompt selected on the smartboard"
                >
                  Smartboard Mode
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setVirtual3dPromptMode('standard');
                    playSoundEffect('click');
                    if (showNotification) {
                      showNotification("Switched to: Selected Prompt (Standard Play Mode)", "info");
                    }
                  }}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-[9px] sm:text-[10px] font-black tracking-wide uppercase transition-all cursor-pointer select-none",
                    (virtual3dPromptMode as string) === 'standard'
                      ? "bg-indigo-600 text-white font-extrabold shadow-sm"
                      : "text-slate-400 hover:text-slate-200"
                  )}
                  title="Display the selected prompt in standard tutor play mode"
                >
                  Standard Play Mode
                </button>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {!isLectureActive ? (
                  <button
                    onClick={handleStartVirtualLearning}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-emerald-600/40 ring-2 ring-emerald-300 cursor-pointer shrink-0 active:scale-95 transition-all"
                  >
                    <Play size={14} className="fill-white" />
                    <span>Start Lesson</span>
                  </button>
                ) : (
                  <span className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    <span>Teaching Active</span>
                  </span>
                )}
              </div>
            </div>
            
            <div className="p-3.5 rounded-xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/60 border border-sky-500/30 text-xs sm:text-sm text-slate-100 font-medium leading-relaxed shadow-lg">
              <div className="flex items-center gap-2 mb-1.5 text-sky-300 font-bold text-xs uppercase tracking-wider">
                <Sparkles size={14} className="text-amber-400" />
                <span>Interactive Learning Overview</span>
              </div>
              <p className="text-slate-200 text-xs sm:text-sm leading-relaxed">
                <strong className="text-amber-300 font-semibold">{stagedTopicTitle || activeTopicTitle || userTopic || 'Quadratic Equations & Polynomials'}</strong>: Explore foundational concepts with everyday physical intuition, master governing equations in step-by-step LaTeX, and solve practical practice questions together.
              </p>
            </div>
            
            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-300">Subject:</span>
                <span className="text-amber-300 font-bold">{userSubject || 'Science & Mathematics'}</span>
                <span className="text-slate-600">•</span>
                <span className="font-semibold text-slate-300">Topic:</span>
                <span className="text-sky-300 font-bold">{stagedTopicTitle || activeTopicTitle || userTopic || 'Quadratic Equations & Polynomials'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold text-[10px]">
                  Real-World Pedagogy
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px]">
                  Step-by-Step Active
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Mid-Chapter Energy Boost Banner (Continuous Teaching Style) */}
        {showMidChapterBoostCard && (
          <div className="my-2 p-3 bg-gradient-to-r from-indigo-950 via-slate-900 to-amber-950/80 border border-amber-500/40 rounded-2xl shadow-xl flex items-center justify-between gap-3 animate-fadeIn">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300">
                <Zap size={18} className="animate-bounce" />
              </div>
              <div>
                <h4 className="text-xs font-black text-amber-300 uppercase tracking-wide flex items-center gap-1.5">
                  <span>⚡ Mid-Lecture Energy Checkpoint</span>
                  <span className="px-1.5 py-0.5 text-[9px] bg-amber-500/20 text-amber-200 rounded font-bold">50% Complete</span>
                </h4>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  You're mastering the core principles! Keep that curiosity high — advanced applications ahead.
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                setShowMidChapterBoostCard(false);
                playSoundEffect('chime');
              }}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition-all cursor-pointer shrink-0 shadow-md"
            >
              Let's Continue ➔
            </button>
          </div>
        )}

        {/* Interactive Figure Thumbnail Dock (Auto-docked figures available at all times) */}
        {figureDockHistory.length > 0 && (
          <div className="my-2 p-2 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-center justify-between gap-2 overflow-x-auto">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400 shrink-0">
              <Layers size={13} className="text-indigo-400" />
              <span>Figure Dock:</span>
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto">
              {figureDockHistory.map((fig, idx) => (
                <button
                  key={fig.id}
                  onClick={() => {
                    setDockSelectedFigure({ svg: fig.svg, title: fig.title });
                    setIsStageModeActive(true);
                    playSoundEffect('click');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-indigo-950/70 border border-slate-700/80 text-slate-200 hover:text-cyan-300 text-[10px] font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer shadow-sm"
                  title={`Click to re-open Stage Mode for: ${fig.title}`}
                >
                  <Sparkles size={10} className="text-amber-400" />
                  <span className="truncate max-w-[140px]">{fig.title || `Fig ${idx + 1}`}</span>
                  <span className="text-[9px] text-slate-400">({fig.timestamp})</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Pinned Sticky Active Figure Spotlight Card (Stage Mode) */}
        {(dockSelectedFigure || (activeFigureInfo && (isStageModeActive || isFigurePinned))) && (
          <div className="sticky top-0 z-30 my-2 bg-slate-950/95 border-2 border-cyan-500/50 rounded-2xl p-3 shadow-2xl backdrop-blur-2xl transition-all ring-1 ring-cyan-500/30 animate-fadeIn">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2 overflow-hidden">
                <span className="relative flex h-2.5 w-2.5 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
                </span>
                <span className="text-[11px] sm:text-xs font-black uppercase tracking-wider text-cyan-300 flex items-center gap-1.5 shrink-0">
                  <Sparkles size={13} className="text-cyan-400" />
                  Stage Mode: Vector Diagram
                </span>
                <span className="text-[11px] font-bold text-slate-200 truncate hidden sm:inline">
                  • {dockSelectedFigure?.title || activeFigureInfo?.title || 'Interactive Schematic'}
                </span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => setCameraView('figure_focus')}
                  className="px-2 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-[10px] font-bold border border-cyan-500/40 transition-all flex items-center gap-1 cursor-pointer"
                  title="Switch 3D camera to focus on Figure and Professor Clarity"
                >
                  <Camera size={11} />
                  <span>Focus 3D</span>
                </button>
                <button
                  onClick={() => {
                    setDockSelectedFigure(null);
                    setIsStageModeActive(false);
                    setIsFigurePinned(false);
                  }}
                  className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                  title="Minimize figure to dock"
                >
                  <X size={11} />
                  <span>Minimize to Dock</span>
                </button>
              </div>
            </div>

            {/* Interactive Vector Figure Viewer */}
            <div className="w-full max-h-[240px] sm:max-h-[300px] overflow-hidden rounded-xl bg-slate-900/90 border border-slate-800/80 p-1 flex items-center justify-center">
              <SvgDiagramViewer
                svgCode={dockSelectedFigure?.svg || activeFigureInfo?.svg || ''}
                theme="dark"
                showNotification={showNotification}
                onExplainFigure={handleExplainFigureIn3D}
              />
            </div>
          </div>
        )}

        <div 
          onDoubleClick={() => handleOpenQuestionSolutionEditor()}
          className="prose prose-invert prose-sm max-w-none text-slate-200 cursor-pointer group/board relative"
          title="Double-click anywhere to edit asked question and solution text"
        >
          <ReactMarkdown
            remarkPlugins={[remarkGfm, remarkMath]}
            rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }], rehypeRaw]}
            components={{
              code: ({ inline, className, children, ...props }: any) => {
                const codeStr = Array.isArray(children)
                  ? children.map(c => (typeof c === 'string' ? c : '')).join('').trim()
                  : (typeof children === 'string' ? children.trim() : '');
                if (!inline && codeStr.includes('<svg') && codeStr.includes('</svg>')) {
                  return (
                    <div className="my-4 not-prose w-full overflow-hidden rounded-2xl border border-slate-700/80 bg-slate-950/90 shadow-2xl p-1">
                      <SvgDiagramViewer
                        svgCode={codeStr}
                        theme="dark"
                        showNotification={showNotification}
                        onExplainFigure={handleExplainFigureIn3D}
                      />
                    </div>
                  );
                }
                if (!inline && (className?.includes('language-markdown') || className?.includes('language-md'))) {
                  return (
                    <div className="not-prose my-2 text-slate-200">
                      {children}
                    </div>
                  );
                }
                return (
                  <code className={className} {...props}>
                    {children}
                  </code>
                );
              },
              img: ({ src, alt, ...props }: any) => {
                const titleStr = alt || 'Nano Banana 2 Visual Figure';
                return (
                  <div className="my-4 not-prose w-full overflow-hidden rounded-2xl border border-slate-700/80 bg-slate-950/90 shadow-2xl p-1 flex flex-col">
                    <img src={src} alt={titleStr} className="w-full h-auto object-contain max-h-[460px] rounded-xl" {...props} />
                    <div className="px-3.5 py-2.5 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between gap-3 flex-wrap">
                      <div className="flex items-center gap-2 text-xs">
                        <div className="p-1 rounded-md bg-amber-500/10 text-amber-400">
                          <Sparkles size={13} className="animate-pulse" />
                        </div>
                        <span className="font-semibold text-xs text-slate-400 truncate max-w-xs">{titleStr}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleExplainFigureIn3D(src || '', titleStr, true)}
                        title="Ask 3D Professor Clarity for a specialized step-by-step deep-dive explanation of this figure"
                        className="group relative inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:from-indigo-500 hover:via-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 hover:shadow-indigo-500/50 border border-indigo-400/40 hover:border-indigo-300 hover:scale-[1.04] active:scale-[0.97] transition-all duration-200 cursor-pointer animate-in fade-in slide-in-from-bottom-2"
                      >
                        <Sparkles size={13} className="text-amber-300 group-hover:rotate-12 transition-transform duration-300 shrink-0" />
                        <span className="tracking-tight">Explain this figure</span>
                      </button>
                    </div>
                  </div>
                );
              },
              p: ({ children }: any) => {
                const text = Array.isArray(children)
                  ? children.map(c => (typeof c === 'string' ? c : '')).join('')
                  : (typeof children === 'string' ? children : '');
                // Check if this paragraph represents an Exam Question, Model Answer, or Hint (PART 3: PROPER QUESTION DISPLAY - NO FADING)
                const isQuestion = /(?:^|\b)(?:Q\d*[:.]|\*\*Q|\*\*\[Category|\*\*\[NEET|\*\*\[JEE|Assertion:|Reason:)/i.test(text);
                const isAnswer = /(?:✅|\bModel Answer|\bSolution:)/i.test(text);
                const isCriteria = /(?:📋|\bMarking Scheme:|\bExaminer Criteria:)/i.test(text);
                const isThinking = text.includes('● ○ ○') || text.includes('Thinking Pause') || text.includes('[Thinking Pause]');
                const isTeachBack = /(?:🗣️|YOUR TURN TO TEACH|Teach-Back|Explain this back)/i.test(text);
                const isReflection = /(?:🌿|REFLECTION TIME|Take a moment to absorb|Reflect)/i.test(text);

                if (isThinking) {
                  return (
                    <div className="my-4 p-3.5 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-slate-950 border border-indigo-500/30 text-indigo-200 flex items-center justify-between gap-3 shadow-lg">
                      <div className="flex items-center gap-2.5">
                        <span className="flex space-x-1.5 items-center">
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse"></span>
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse delay-150"></span>
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse delay-300"></span>
                        </span>
                        <span className="text-xs font-bold text-indigo-300 tracking-wide uppercase">
                          Thinking Pause • Take your time
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 italic">
                        Contemplate the principle before proceeding...
                      </span>
                    </div>
                  );
                }

                if (isTeachBack) {
                  return (
                    <div className="my-4 p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-900 border-2 border-amber-500/50 text-amber-100 shadow-2xl">
                      <div className="flex items-center gap-2 mb-2 pb-1.5 border-b border-amber-500/30">
                        <span className="px-2.5 py-0.5 rounded-md bg-amber-500/30 border border-amber-400 text-amber-200 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                          <span>🗣️</span> Teach-Back (Feynman Technique)
                        </span>
                        <span className="text-[10px] text-amber-300/80 font-medium">Explain it in your own words</span>
                      </div>
                      <div className="font-semibold text-slate-100 leading-relaxed text-sm md:text-[15px]">
                        {children}
                      </div>
                    </div>
                  );
                }

                if (isReflection) {
                  return (
                    <div className="my-5 p-5 rounded-2xl bg-gradient-to-b from-emerald-950/50 via-slate-950 to-emerald-950/40 border-2 border-emerald-500/50 text-emerald-100 shadow-2xl relative overflow-hidden">
                      <div className="flex items-center justify-between gap-2 mb-3 pb-2 border-b border-emerald-500/30">
                        <span className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-300 text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                          <span>🌿</span> Peaceful Reflection & Closure
                        </span>
                        <div className="flex items-center gap-2 text-xs text-emerald-400">
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                          <span className="font-medium">Breathe In & Out Gently</span>
                        </div>
                      </div>
                      <div className="leading-relaxed text-slate-100 text-sm md:text-base font-medium mb-2">
                        {children}
                      </div>
                    </div>
                  );
                }

                if (isQuestion) {
                  return (
                    <div 
                      onDoubleClick={(e) => {
                        e.stopPropagation();
                        handleOpenQuestionSolutionEditor();
                      }}
                      title="Double-click to edit this asked question text"
                      className="my-3 p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border-2 border-indigo-500/40 text-slate-100 shadow-xl opacity-100 cursor-pointer transition-all hover:border-indigo-400 hover:ring-2 hover:ring-indigo-500/30 relative group/q"
                    >
                      <div className="flex items-center justify-between gap-2 mb-2 pb-1.5 border-b border-indigo-500/30">
                        <span className="px-2 py-0.5 rounded-md bg-indigo-500/30 border border-indigo-400 text-indigo-200 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                          <span>❓</span> Practice Question
                        </span>
                        <span className="opacity-0 group-hover/q:opacity-100 transition-opacity text-[10px] font-bold text-indigo-300 bg-indigo-950/90 px-2 py-0.5 rounded border border-indigo-500/50 flex items-center gap-1">
                          <Pencil size={10} /> Double-click to Edit
                        </span>
                      </div>
                      <div className="font-semibold text-slate-100 leading-relaxed text-sm md:text-[15px] opacity-100">
                        {children}
                      </div>
                    </div>
                  );
                }

                if (isAnswer) {
                  return (
                    <div 
                      onDoubleClick={(e) => {
                        e.stopPropagation();
                        handleOpenQuestionSolutionEditor();
                      }}
                      title="Double-click to edit this model solution text"
                      className="my-3 p-3.5 rounded-2xl bg-emerald-950/40 border-2 border-emerald-500/40 text-emerald-100 shadow-lg opacity-100 cursor-pointer transition-all hover:border-emerald-400 hover:ring-2 hover:ring-emerald-500/30 relative group/ans"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1.5 pb-1 border-b border-emerald-500/30">
                        <div className="flex items-center gap-1.5 text-emerald-300 font-bold text-xs uppercase tracking-wider">
                          <CheckCircle2 size={13} className="text-emerald-400" />
                          <span>Model Solution (Step-by-Step)</span>
                        </div>
                        <span className="opacity-0 group-hover/ans:opacity-100 transition-opacity text-[10px] font-bold text-emerald-300 bg-emerald-950/90 px-2 py-0.5 rounded border border-emerald-500/50 flex items-center gap-1">
                          <Pencil size={10} /> Double-click to Edit
                        </span>
                      </div>
                      <div className="leading-relaxed text-slate-200 text-sm opacity-100">
                        {children}
                      </div>
                    </div>
                  );
                }

                if (isCriteria) {
                  return (
                    <div 
                      onDoubleClick={(e) => {
                        e.stopPropagation();
                        handleOpenQuestionSolutionEditor();
                      }}
                      title="Double-click to edit this marking scheme"
                      className="my-3 p-3.5 rounded-2xl bg-amber-950/30 border-2 border-amber-500/40 text-amber-100 shadow-lg opacity-100 cursor-pointer transition-all hover:border-amber-400 hover:ring-2 hover:ring-amber-500/30 relative group/crit"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1.5 pb-1 border-b border-amber-500/30">
                        <div className="flex items-center gap-1.5 text-amber-300 font-bold text-xs uppercase tracking-wider">
                          <GraduationCap size={13} className="text-amber-400" />
                          <span>Marking Scheme & Key Scoring Steps</span>
                        </div>
                        <span className="opacity-0 group-hover/crit:opacity-100 transition-opacity text-[10px] font-bold text-amber-300 bg-amber-950/90 px-2 py-0.5 rounded border border-amber-500/50 flex items-center gap-1">
                          <Pencil size={10} /> Double-click to Edit
                        </span>
                      </div>
                      <div className="leading-relaxed text-slate-200 text-sm opacity-100">
                        {children}
                      </div>
                    </div>
                  );
                }

                return (
                  <div 
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      handleOpenQuestionSolutionEditor();
                    }}
                    title="Double-click to edit text"
                    className="mb-3 leading-relaxed text-slate-200 hover:bg-slate-800/40 rounded p-1 transition-colors cursor-pointer"
                  >
                    {children}
                  </div>
                );
              },
              table: ({ children }: any) => (
                <div className="my-5 overflow-x-auto rounded-2xl border-2 border-emerald-500/40 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 shadow-[0_0_30px_rgba(16,185,129,0.15)]">
                  <table className="w-full text-left border-collapse text-xs md:text-sm min-w-[600px]">
                    {children}
                  </table>
                </div>
              ),
              thead: ({ children }: any) => (
                <thead className="bg-gradient-to-r from-slate-950 via-emerald-950/80 to-slate-950 text-emerald-300 font-black uppercase tracking-wider border-b-2 border-emerald-500/50">
                  {children}
                </thead>
              ),
              tbody: ({ children }: any) => (
                <tbody className="divide-y divide-slate-800/80 font-medium text-slate-200">
                  {children}
                </tbody>
              ),
              tr: ({ children }: any) => (
                <tr className="even:bg-slate-900/50 odd:bg-slate-950/80 hover:bg-emerald-950/30 transition-colors">
                  {children}
                </tr>
              ),
              th: ({ children }: any) => (
                <th className="px-4 py-3.5 font-black text-emerald-300 border-r border-slate-800/80 last:border-r-0 tracking-wide text-xs">
                  {children}
                </th>
              ),
              h1: ({ children }: any) => (
                <h1 className="text-2xl md:text-3xl font-black text-amber-400 my-4 pb-2 border-b-2 border-amber-500/40 tracking-tight">
                  {children}
                </h1>
              ),
              h2: ({ children }: any) => (
                <h2 className="text-xl md:text-2xl font-bold text-sky-400 my-3.5 pb-1.5 border-b border-sky-500/30">
                  {children}
                </h2>
              ),
              h3: ({ children }: any) => (
                <h3 className="text-lg md:text-xl font-bold text-indigo-300 my-3">
                  {children}
                </h3>
              ),
              h4: ({ children }: any) => (
                <h4 className="text-base md:text-lg font-bold text-teal-300 my-2.5 inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-teal-950/40 border border-teal-500/30">
                  <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></span>
                  {children}
                </h4>
              ),
              h5: ({ children }: any) => (
                <h5 className="text-sm md:text-base font-semibold text-purple-300 my-2 inline-flex items-center gap-2 px-2 py-0.5 rounded-md bg-purple-950/40 border border-purple-500/30">
                  {children}
                </h5>
              ),
              h6: ({ children }: any) => (
                <h6 className="text-xs md:text-sm font-semibold text-slate-300 my-1.5 uppercase tracking-wider">
                  {children}
                </h6>
              ),
              td: ({ children }: any) => (
                <td className="px-4 py-3 border-r border-slate-800/60 last:border-r-0 font-medium leading-relaxed">
                  {children}
                </td>
              ),
              text: ({ children, node, ...props }: any) => (
                <span
                  style={{
                    fontFamily: props['font-family'] || props.fontFamily,
                    fontSize: props['font-size'] || props.fontSize,
                    fontWeight: props['font-weight'] || props.fontWeight,
                    color: props.fill || undefined
                  }}
                >
                  {children}
                </span>
              ),
            }}
          >
            {formatMarkdownWithInlineSvgs(cleanStreamingMarkdown(typedBoardContent || cleanBoardContentForDisplay(boardContent), isTypingLive))}
          </ReactMarkdown>
          {isTypingLive && <StreamingCursor />}
        </div>

        {/* Live Exam Tip Bar (PART 6) */}
        <div className="mt-3 pt-2.5 border-t border-slate-800/90 flex items-center justify-between gap-3 text-xs bg-slate-950/70 p-2.5 rounded-xl border border-indigo-500/20 shrink-0">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="px-2 py-0.5 rounded-md bg-amber-500/20 border border-amber-500/40 text-amber-300 font-black text-[10px] uppercase tracking-wider shrink-0">
              Exam Tip
            </span>
            <span className="text-slate-200 font-medium truncate text-xs sm:text-xs">
              {EXAM_TIPS_DATABASE[currentExamTipIdx]}
            </span>
          </div>
          <button
            onClick={() => setCurrentExamTipIdx(prev => (prev + 1) % EXAM_TIPS_DATABASE.length)}
            className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-[10px] font-bold transition-colors shrink-0 cursor-pointer"
            title="Next Exam Tip"
          >
            Next Tip ➔
          </button>
        </div>

        {/* Live Camera Stream Overlay on Board View */}
        {cameraFeedEnabled && (
          <div className="mt-4 pt-3 border-t border-slate-800/80 shrink-0 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Camera size={14} className="text-indigo-400 animate-pulse" />
                <span className="text-xs font-bold text-indigo-300">Live Camera Stream • Interactive Demonstration</span>
              </div>
              <button
                onClick={toggleCameraFeed}
                className="p-1 rounded-lg bg-slate-900 hover:bg-red-950 text-slate-400 hover:text-red-300 border border-slate-800 transition-colors cursor-pointer text-[10px] font-bold flex items-center gap-1"
                title="Turn Off Camera Feed"
              >
                <X size={12} />
                <span>Close Cam</span>
              </button>
            </div>
            
            <div className="relative w-full h-44 sm:h-52 rounded-2xl overflow-hidden border border-indigo-500/50 shadow-2xl bg-slate-950 group">
              <video
                ref={(el) => {
                  cameraVideoRef.current = el;
                  if (el && cameraStreamRef.current) {
                    el.srcObject = cameraStreamRef.current;
                  }
                }}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover transform -scale-x-100"
              />
              <div className="absolute top-2.5 left-2.5 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-xl border border-slate-800/80 flex items-center gap-2 text-xs font-bold text-indigo-200 shadow-md">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>Presenter Feed Active</span>
              </div>
            </div>
          </div>
        )}
      </div>
      )}

      {/* MINIMAL VIRTUAL 3D CONTROLS */}
      <Minimal3DControls
        embeddedInClassroom={true}
        isPlaying={isLectureActive && !isLecturePaused}
        isInitializingLecture={isInitializingLecture}
        onTogglePlay={handleStartVirtualLearning}
        onAskQuestion={() => {
          showNotification?.(`Ask ${selectedTeacherStyle.name} a Question below`, "info");
        }}
        onToggleNotes={() => setIsSmartboardNotesMinimized(prev => !prev)}
        isNotesOpen={!isSmartboardNotesMinimized}
        isMuted={!audioEnabled}
        onToggleMute={() => {
          setAudioEnabled(prev => !prev);
          if (audioEnabled) stopSpeech();
        }}
        onBack={() => {
          if (onClose) onClose();
        }}
        onRewind10s={() => {
          if (currentSyncStep > 0) {
            setCurrentSyncStep(prev => Math.max(0, prev - 1));
            showNotification?.("⏪ Rewound lecture by 1 step (10s)", "info");
          } else {
            replaySynchronizedLecture();
          }
        }}
        onFastForward10s={() => {
          if (totalSyncSteps > 0 && currentSyncStep < totalSyncSteps) {
            setCurrentSyncStep(prev => Math.min(totalSyncSteps, prev + 1));
            showNotification?.("⏭️ Fast-forwarded lecture by 1 step (10s)", "info");
          }
        }}
        onSeekProgress={(percent) => {
          if (totalSyncSteps > 0) {
            const step = Math.round((percent / 100) * totalSyncSteps);
            setCurrentSyncStep(step);
          }
        }}
        currentTimeDisplay={
          screenRecordingState === 'recording' || screenRecordingState === 'paused'
            ? formatRecordingTime(screenRecordingDuration)
            : formatRecordingTime(totalSyncSteps > 0 ? Math.round((currentSyncStep / totalSyncSteps) * 180) : 0)
        }
        totalDurationDisplay={
          screenRecordingState === 'recording' || screenRecordingState === 'paused'
            ? formatRecordingTime(screenRecordingDuration)
            : "03:00"
        }
        isFigureModeActive={isStageModeActive}
        onZoomFigure={() => setCameraView('figure_focus')}
        isStageModeActive={isStageModeActive}
        onToggleStageMode={() => setIsStageModeActive(!isStageModeActive)}
        isConfusionDetected={false}
        onReplaySection={replaySynchronizedLecture}
        onSlowerPace={() => {
          showNotification?.("Adjusting speech to a calmer pace", "info");
        }}
        onSimplerExplanation={() => {
          setUserPrompt(`Please explain "${activeTopicTitle}" using a simpler everyday analogy.`);
        }}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenRadialMenu={(coords) => {
          setRadialMenuPosition({ x: coords.clientX, y: coords.clientY });
          setIsRadialMenuOpen(true);
        }}
        onOpenSettings={() => setShowChatControlsModal(true)}
        userPrompt={userPrompt}
        setUserPrompt={setUserPrompt}
        onSendPrompt={() => handleAskTutor()}
        isLoadingAi={isLoadingAi}
        isListening={isListening}
        onToggleSpeech={toggleSpeechRecognition}
        onClearTopic={handleClearTopicAndSmartboard}
        screenRecordingState={screenRecordingState}
        onStartScreenRecording={startScreenRecording}
        onStopScreenRecording={stopScreenRecording}
        onPauseScreenRecording={pauseScreenRecording}
        onResumeScreenRecording={resumeScreenRecording}
        screenRecordingDuration={screenRecordingDuration}
        formatRecordingTime={formatRecordingTime}
        sessionTimerStyle={sessionTimerStyle}
        onCycleTimerStyle={handleCycleSessionTimerStyle}
        sessionTimerEnabled={sessionTimerEnabled}
        onToggleTimerEnabled={() => handleSetSessionTimerEnabled(!sessionTimerEnabled)}
        cameraFeedEnabled={cameraFeedEnabled}
        onToggleCameraFeed={toggleCameraFeed}
        onOpenChatControls={() => setShowChatControlsModal(true)}
        onOpenTopicModal={() => setShowTopicModal(true)}
        isMaximized={isMaximized}
        onToggleMaximize={toggleMaximizeLectureHall}
        activeTopicTitle={activeTopicTitle}
        progressPercent={totalSyncSteps > 0 ? Math.round((currentSyncStep / totalSyncSteps) * 100) : 0}
      />

      {/* SMART COMMAND PALETTE (SHORTCUT: /) */}
      <SmartCommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        commands={allPaletteCommands}
      />

      {/* BUBBLE RADIAL CONTEXT MENU (RIGHT-CLICK / LONG-PRESS) */}
      <BubbleRadialMenu
        isOpen={isRadialMenuOpen}
        position={radialMenuPosition}
        onClose={() => setIsRadialMenuOpen(false)}
        onSelectAction={(actionId) => {
          const matched = radialMenuItems.find(i => i.id === actionId);
          if (matched) matched.action();
        }}
        customItems={radialMenuItems}
      />

      {/* Chat Features & Controls Modal */}
      {showChatControlsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-4 sm:p-6 shadow-2xl space-y-4 sm:space-y-5 relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 sm:pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                  <MessageSquare size={20} />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white">Chat Features & Controls</h3>
                  <p className="text-[11px] sm:text-xs text-slate-400">Configure 3D Tutor behavior, language, and lecture output</p>
                </div>
              </div>
              <button
                onClick={() => setShowChatControlsModal(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Teaching Persona Mode */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-slate-400 tracking-wider">Teaching Persona & Method</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  { id: 'professor', label: 'Master Professor', desc: 'Comprehensive & inspiring' },
                  { id: 'socratic', label: 'Socratic Method', desc: 'Guides with probing questions' },
                  { id: 'step_by_step', label: 'Step-by-Step', desc: 'Logical bullet points' },
                  { id: 'direct', label: 'Direct Solver', desc: 'Concise & immediate answer' },
                ].map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => setChatMode(mode.id as any)}
                    className={cn(
                      "p-2.5 sm:p-3 rounded-2xl border text-left cursor-pointer transition-all",
                      chatMode === mode.id
                        ? "bg-indigo-600/20 border-indigo-500 text-white"
                        : "bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200"
                    )}
                  >
                    <div className="text-xs font-bold">{mode.label}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{mode.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Language Selector */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                <Globe size={13} className="text-indigo-400" />
                <span>Lecture Language</span>
              </label>
              <div className="flex flex-wrap gap-2">
                {['English', 'Hindi', 'Spanish', 'French', 'German', 'Japanese', 'Chinese'].map((lang) => (
                  <button
                    key={lang}
                    onClick={() => handleLanguageChange(lang)}
                    className={cn(
                      "px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer",
                      (selectedLanguage.toLowerCase() === lang.toLowerCase() || selectedLectureLanguage.toLowerCase() === lang.toLowerCase())
                        ? "bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-500/20"
                        : "bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white"
                    )}
                  >
                    {lang}
                  </button>
                ))}
              </div>
            </div>

            {/* Academic Rigor Level */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-slate-400 tracking-wider">Academic Rigor Level</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'standard', label: 'Foundation' },
                  { id: 'advanced', label: 'Advanced HS' },
                  { id: 'graduate', label: 'Research Grade' }
                ].map((rigor) => (
                  <button
                    key={rigor.id}
                    onClick={() => setAcademicRigor(rigor.id as any)}
                    className={cn(
                      "p-2.5 rounded-xl text-xs font-bold border text-center cursor-pointer transition-all",
                      academicRigor === rigor.id
                        ? "bg-indigo-600 text-white border-indigo-500"
                        : "bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white"
                    )}
                  >
                    {rigor.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Classroom Voice-Over Toggle Row */}
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Headphones size={18} className="text-indigo-400" />
                <div>
                  <div className="text-xs font-bold text-white">Classroom Voice-Over</div>
                  <div className="text-[10px] text-slate-400">Narrate smartboard content with native audio on topic select</div>
                </div>
              </div>
              <button
                onClick={() => {
                  const next = !classroomVoiceOver;
                  setClassroomVoiceOver(next);
                  showNotification?.(next ? "Classroom Voice-Over Enabled" : "Classroom Voice-Over Disabled", 'info');
                  if (next) narrateCurrentBoardContent();
                }}
                className={cn(
                  "px-3 py-1.5 rounded-xl text-xs font-bold border cursor-pointer transition-all",
                  classroomVoiceOver
                    ? "bg-indigo-600 text-white border-indigo-500"
                    : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"
                )}
              >
                {classroomVoiceOver ? "ENABLED" : "MUTED"}
              </button>
            </div>

            {/* Session Timer Overlay Settings for 1080p Video Recording */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                    <Clock size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">1080p Session Timer Video Overlay</div>
                    <div className="text-[10px] text-slate-400">Burn duration tracker directly into recorded 1080p50 video</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSetSessionTimerEnabled(!sessionTimerEnabled)}
                  className={cn(
                    "px-3 py-1.5 rounded-xl text-xs font-bold border cursor-pointer transition-all flex items-center gap-1.5",
                    sessionTimerEnabled
                      ? "bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-500/20"
                      : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"
                  )}
                >
                  <span className={cn("w-1.5 h-1.5 rounded-full", sessionTimerEnabled ? "bg-white animate-pulse" : "bg-slate-500")} />
                  <span>{sessionTimerEnabled ? "ENABLED" : "MUTED"}</span>
                </button>
              </div>

              {/* Style selector */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Overlay Presentation Style
                  </label>
                  <span className="text-[10px] font-mono text-cyan-400">
                    Active: {sessionTimerStyle}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'minimal' as const, label: 'Minimal', preview: '● 02:45 HD' },
                    { id: 'digital-clock' as const, label: 'Digital Clock', preview: 'REC 02:45 • 1080p50' },
                    { id: 'progress-bar' as const, label: 'Progress Bar', preview: '● REC 02:45 [━━░░]' },
                  ].map(style => (
                    <button
                      key={style.id}
                      type="button"
                      onClick={() => handleSetSessionTimerStyle(style.id)}
                      className={cn(
                        "p-2.5 rounded-xl text-center border cursor-pointer transition-all flex flex-col items-center gap-1.5",
                        sessionTimerStyle === style.id
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-600/10"
                          : "bg-slate-900/90 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-850"
                      )}
                    >
                      <span className="text-[11px] font-bold">{style.label}</span>
                      <span className="text-[9px] font-mono text-cyan-300 bg-slate-950/90 px-1.5 py-0.5 rounded border border-slate-800 w-full truncate">
                        {style.preview}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Smartboard Operations & Export */}
            <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(boardContent);
                  showNotification?.("Smartboard notes copied to clipboard!", 'success');
                }}
                className="flex-1 p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Copy size={14} />
                <span>Copy Board Notes</span>
              </button>

              <button
                onClick={() => {
                  const blob = new Blob([boardContent], { type: 'text/markdown' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `3D_Classroom_Lecture_${activeTopicTitle.replace(/\s+/g, '_')}.md`;
                  a.click();
                  showNotification?.("Lecture transcript downloaded!", 'success');
                }}
                className="flex-1 p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-indigo-600/30"
              >
                <Download size={14} />
                <span>Download Notes (.md)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* YouTube & High-Fidelity 1080p50 Screen Recording Studio Modal */}
      {showRecordingPlaybackModal && recordedVideoUrl && (
        <YouTubeRecordingStudioModal
          isOpen={showRecordingPlaybackModal}
          onClose={() => setShowRecordingPlaybackModal(false)}
          videoUrl={recordedVideoUrl}
          activeTopic={activeTopicTitle}
          boardContent={boardContent}
          recordedDuration={screenRecordingDuration}
          chapters={recordedChapters}
          showNotification={showNotification}
          sessionTimerStyle={sessionTimerStyle}
          onTimerStyleChange={handleSetSessionTimerStyle}
          sessionTimerEnabled={sessionTimerEnabled}
          onTimerEnabledChange={handleSetSessionTimerEnabled}
        />
      )}

      {/* Quad-Speed Synchronization Console Modal */}
      {showQuadSpeedModal && (
        <QuadSpeedSyncModal
          isOpen={showQuadSpeedModal}
          onClose={() => setShowQuadSpeedModal(false)}
          speeds={activeQuadSpeeds}
          onUpdateSpeeds={handleUpdateQuadSpeeds}
        />
      )}

      {/* Virtual Learning Acoustic Profiles Modal */}
      {showAcousticModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-5 relative max-h-[90vh] overflow-y-auto text-slate-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30">
                  <Waves size={22} />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Virtual Learning Acoustic Profiles</h3>
                  <p className="text-xs text-slate-400">Configure spatial resonance, reverb decay, and environmental room acoustics</p>
                </div>
              </div>
              <button
                onClick={() => setShowAcousticModal(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Presets Grid */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase text-slate-400 tracking-wider">Acoustic Presets & Custom Profiles</span>
                <span className="text-[11px] text-cyan-400 font-bold">Active: {activeAcousticProfile.name}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {acousticProfiles.map((profile) => {
                  const isActive = profile.id === activeAcousticProfileId;
                  return (
                    <div
                      key={profile.id}
                      className={cn(
                        "p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative group",
                        isActive
                          ? "bg-cyan-950/40 border-cyan-500 text-white shadow-lg shadow-cyan-500/10"
                          : "bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900/80"
                      )}
                      onClick={() => handleSelectAcousticProfile(profile.id)}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                            <span>{profile.name}</span>
                          </h4>
                          {isActive && (
                            <span className="px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[9px] font-bold">
                              ACTIVE
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 line-clamp-2 mb-3">
                          {profile.description}
                        </p>
                      </div>

                      <div className="space-y-1 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400 font-mono">
                        <div className="flex justify-between">
                          <span>Reverb Decay:</span>
                          <span className="text-cyan-300 font-bold">{profile.reverbDecay}s</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Spatial Echo:</span>
                          <span className="text-cyan-300 font-bold">{Math.round(profile.roomEcho * 100)}%</span>
                        </div>
                      </div>

                      <div className="mt-3 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            testAcousticSound(profile);
                          }}
                          className="px-2 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <Play size={10} />
                          <span>Test Chime</span>
                        </button>

                        {!profile.isBuiltIn && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteCustomProfile(profile.id);
                            }}
                            className="p-1 rounded-lg hover:bg-red-950 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                            title="Delete Custom Profile"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Create Custom Acoustic Profile Card */}
            <div className="pt-3 border-t border-slate-800">
              {!isCreatingProfile ? (
                <button
                  onClick={() => setIsCreatingProfile(true)}
                  className="w-full p-3 rounded-2xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-cyan-400 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Plus size={16} />
                  <span>Create & Save Custom Acoustic Profile</span>
                </button>
              ) : (
                <form onSubmit={handleSaveCustomProfile} className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Plus size={14} className="text-cyan-400" />
                      <span>Create Custom Acoustic Profile</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsCreatingProfile(false)}
                      className="text-xs text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Profile Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Cathedral Resonance Lab"
                        value={newProfileName}
                        onChange={(e) => setNewProfileName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Description</label>
                      <input
                        type="text"
                        placeholder="e.g. Deep acoustic resonance for physics audio"
                        value={newProfileDesc}
                        onChange={(e) => setNewProfileDesc(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                    <div>
                      <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                        <span>Reverb Decay Time:</span>
                        <span className="font-mono text-cyan-300 font-bold">{newReverbDecay}s</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="3.5"
                        step="0.1"
                        value={newReverbDecay}
                        onChange={(e) => setNewReverbDecay(parseFloat(e.target.value))}
                        className="w-full accent-cyan-500 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                        <span>Spatial Echo Level:</span>
                        <span className="font-mono text-cyan-300 font-bold">{Math.round(newRoomEcho * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={newRoomEcho}
                        onChange={(e) => setNewRoomEcho(parseFloat(e.target.value))}
                        className="w-full accent-cyan-500 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                        <span>Voice Pitch Multiplier:</span>
                        <span className="font-mono text-cyan-300 font-bold">{newVoicePitch}x</span>
                      </div>
                      <input
                        type="range"
                        min="0.8"
                        max="1.3"
                        step="0.05"
                        value={newVoicePitch}
                        onChange={(e) => setNewVoicePitch(parseFloat(e.target.value))}
                        className="w-full accent-cyan-500 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                        <span>Speech Rate Multiplier:</span>
                        <span className="font-mono text-cyan-300 font-bold">{newVoiceRate}x</span>
                      </div>
                      <input
                        type="range"
                        min="0.8"
                        max="1.2"
                        step="0.05"
                        value={newVoiceRate}
                        onChange={(e) => setNewVoiceRate(parseFloat(e.target.value))}
                        className="w-full accent-cyan-500 cursor-pointer"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => testAcousticSound({
                        id: 'preview',
                        name: 'Preview',
                        description: '',
                        reverbDecay: newReverbDecay,
                        roomEcho: newRoomEcho,
                        roomWarmth: newRoomWarmth,
                        ambientTone: newAmbientTone,
                        voicePitch: newVoicePitch,
                        voiceRate: newVoiceRate
                      })}
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Play size={13} />
                      <span>Test Preview</span>
                    </button>

                    <button
                      type="submit"
                      className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-cyan-600/30"
                    >
                      <Plus size={14} />
                      <span>Save Profile</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Floating Persistent Countdown Timer Widget */}
      {isTimerVisible && (
        <div className="fixed top-20 right-4 sm:right-6 z-40 transition-all duration-300">
          {isTimerMinimized ? (
            /* Minimized Badge View */
            <div className="flex items-center gap-2 bg-slate-900/95 border border-slate-700/80 backdrop-blur-xl shadow-2xl rounded-2xl px-3 py-2 text-white">
              <button
                onClick={() => setIsTimerMinimized(false)}
                className="flex items-center gap-2 cursor-pointer hover:opacity-90 transition-opacity"
                title="Expand Study Countdown Timer"
              >
                <Timer size={16} className={cn("text-indigo-400", isTimerRunning && "animate-pulse text-emerald-400")} />
                <span className="font-mono font-bold text-xs tracking-wider text-slate-100">
                  {formatTimerTime(timerSeconds)}
                </span>
              </button>
              <div className="w-[1px] h-4 bg-slate-800 my-auto"></div>
              <button
                onClick={() => {
                  setIsTimerRunning(!isTimerRunning);
                  playSoundEffect('click');
                }}
                className={cn(
                  "p-1 rounded-lg transition-colors cursor-pointer",
                  isTimerRunning ? "bg-amber-500/20 text-amber-300 hover:bg-amber-500/30" : "bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30"
                )}
                title={isTimerRunning ? "Pause Timer" : "Start Timer"}
              >
                {isTimerRunning ? <Pause size={13} /> : <Play size={13} />}
              </button>
              <button
                onClick={() => setIsTimerMinimized(false)}
                className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
                title="Expand Timer"
              >
                <Maximize2 size={12} />
              </button>
              <button
                onClick={() => setIsTimerVisible(false)}
                className="p-1 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                title="Hide Timer"
              >
                <X size={13} />
              </button>
            </div>
          ) : (
            /* Expanded Floating Timer Card */
            <div className="w-72 bg-slate-900/95 border border-slate-700/90 backdrop-blur-xl shadow-2xl rounded-2xl p-4 text-white space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
              {/* Header */}
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                    <Timer size={16} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-100">Study Session Timer</h4>
                    <p className="text-[10px] text-slate-400 font-medium">Virtual Learning Focus</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setIsTimerMinimized(true)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Minimize Timer"
                  >
                    <Minimize2 size={14} />
                  </button>
                  <button
                    onClick={() => setIsTimerVisible(false)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Hide Timer"
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>

              {/* Countdown Display */}
              <div className="flex flex-col items-center justify-center py-2 bg-slate-950/60 rounded-xl border border-slate-800/80">
                <span className={cn(
                  "font-mono text-3xl font-extrabold tracking-widest transition-colors",
                  isTimerRunning ? "text-emerald-400" : timerSeconds === 0 ? "text-rose-400 animate-bounce" : "text-slate-100"
                )}>
                  {formatTimerTime(timerSeconds)}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 mt-1">
                  {isTimerRunning ? "Counting Down..." : timerSeconds === 0 ? "Session Completed!" : "Paused"}
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div 
                  className={cn(
                    "h-full transition-all duration-500 rounded-full",
                    isTimerRunning ? "bg-emerald-400" : "bg-indigo-500"
                  )}
                  style={{ width: `${Math.min(100, Math.max(0, (timerSeconds / (timerInitialSeconds || 1)) * 100))}%` }}
                ></div>
              </div>

              {/* Presets */}
              <div className="grid grid-cols-5 gap-1">
                {[10, 15, 25, 45, 60].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => handleSetTimerPreset(mins)}
                    className={cn(
                      "py-1 rounded-lg text-[10px] font-bold transition-all border cursor-pointer",
                      timerInitialSeconds === mins * 60 && !isTimerRunning
                        ? "bg-indigo-600 border-indigo-400 text-white"
                        : "bg-slate-800/80 border-slate-700/60 text-slate-300 hover:text-white hover:bg-slate-700"
                    )}
                  >
                    {mins}m
                  </button>
                ))}
              </div>

              {/* Controls */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => {
                    setIsTimerRunning(!isTimerRunning);
                    playSoundEffect('click');
                  }}
                  className={cn(
                    "flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md",
                    isTimerRunning 
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30" 
                      : "bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-400/50 shadow-emerald-600/30"
                  )}
                >
                  {isTimerRunning ? <Pause size={14} /> : <Play size={14} />}
                  <span>{isTimerRunning ? "Pause" : "Start"}</span>
                </button>

                <button
                  onClick={handleResetTimer}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition-all cursor-pointer"
                  title="Reset Countdown Timer"
                >
                  <RotateCcw size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Layer 1: 30-Second Lightning Recap Popover Modal */}
      {show30sLightningRecap && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 relative text-slate-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  <Zap size={20} className="animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">30-Second Lightning Recap</h3>
                  <p className="text-xs text-amber-300 font-mono">Mid-Lecture Instant Retention Layer</p>
                </div>
              </div>
              <button
                onClick={() => setShow30sLightningRecap(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 py-1">
              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-amber-500/30 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-300 font-black text-xs flex items-center justify-center shrink-0">1</span>
                <div>
                  <span className="font-bold text-white text-xs block">Sun Gives Energy</span>
                  <span className="text-[11px] text-slate-300">Photons absorbed by chlorophyll pigment antenna in chloroplast thylakoids.</span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-amber-500/30 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-300 font-black text-xs flex items-center justify-center shrink-0">2</span>
                <div>
                  <span className="font-bold text-white text-xs block">Water Comes From Roots</span>
                  <span className="text-[11px] text-slate-300">Transported through xylem; photolysis splits H₂O to generate O₂ gas + ATP + NADPH.</span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-amber-500/30 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-300 font-black text-xs flex items-center justify-center shrink-0">3</span>
                <div>
                  <span className="font-bold text-white text-xs block">CO₂ From Atmosphere</span>
                  <span className="text-[11px] text-slate-300">Enters via stomata guard cells; fixed into C₆H₁₂O₆ glucose during Calvin cycle.</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <span className="text-[11px] text-slate-400 font-medium">⚡ 30s Professor Clarity Voice Recap Active</span>
              <button
                onClick={() => setShow30sLightningRecap(false)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider cursor-pointer shadow-md shadow-amber-500/20"
              >
                Got It! Continue Lecture
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Layer 4: 5-Minute Deep Recap Popover Modal */}
      {show5minDeepRecap && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-slate-900 border-2 border-purple-500/50 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 relative text-slate-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/40">
                  <RotateCcw size={20} />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">5-Minute Deep Recap & Recall Questions</h3>
                  <p className="text-xs text-purple-300 font-mono">Next Lecture Start Deep Recall Layer</p>
                </div>
              </div>
              <button
                onClick={() => setShow5minDeepRecap(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 py-1 text-xs">
              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-1">
                <div className="font-bold text-purple-300">Question 1: Who can state the complete balanced chemical equation?</div>
                <div className="text-slate-300 font-mono bg-slate-900 p-2 rounded-xl border border-slate-800">
                  6CO₂ + 6H₂O + Sunlight → C₆H₁₂O₆ + 6O₂
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-1">
                <div className="font-bold text-purple-300">Question 2: What are the three essential inputs and two outputs?</div>
                <div className="text-slate-300">
                  Inputs: CO₂ (air), H₂O (roots), Sunlight. Outputs: Glucose (food), Oxygen (gas).
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-1">
                <div className="font-bold text-purple-300">Question 3: What common mistake do students make regarding oxygen origin?</div>
                <div className="text-slate-300">
                  ❌ Incorrect: Thinking O₂ comes from CO₂. ✅ Correct: Ruben & Kamen proved O₂ comes from water photolysis.
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <span className="text-[11px] text-slate-400">Deep recall builds long-term memory for competitive exams</span>
              <button
                onClick={() => setShow5minDeepRecap(false)}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold cursor-pointer shadow-md shadow-purple-600/30"
              >
                Close Deep Recap
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Master Rule System Awareness Hub Modal ("Know what you know and know what is added") (PART 7) */}
      {showMasterRuleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-200">
          <div className="bg-slate-900 border-2 border-cyan-500/50 rounded-3xl max-w-3xl w-full p-6 shadow-2xl space-y-5 relative text-slate-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-inner">
                  <Activity size={22} className="animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>Professor Clarity Master Rule</span>
                    <span className="px-2 py-0.5 text-[10px] font-mono bg-cyan-500/20 text-cyan-300 rounded-full border border-cyan-500/30">
                      System Awareness
                    </span>
                  </h3>
                  <p className="text-xs text-cyan-300 font-mono tracking-wide">
                    "Know what you know and know what is added"
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowMasterRuleModal(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* 3-Column Real-Time Awareness Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 py-1">
              {/* Column 1: What We Know */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-cyan-500/30 space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-cyan-300 mb-2">
                    <BookOpen size={14} className="text-cyan-400" />
                    <span>1. What We Know</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mb-2">
                    Covered topics & axioms locked in working memory:
                  </div>
                  <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                    {boardStateMetrics.headings.length > 0 ? (
                      boardStateMetrics.headings.map((h, i) => (
                        <div key={i} className="flex items-start gap-1.5 text-[11px] text-slate-200">
                          <CheckCircle2 size={12} className="text-emerald-400 mt-0.5 shrink-0" />
                          <span className="line-clamp-2">{h}</span>
                        </div>
                      ))
                    ) : (
                      <div className="text-[11px] text-slate-400 italic">Foundation stage in progress...</div>
                    )}
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-800/80 text-[10px] text-cyan-300 font-mono">
                  ✓ {boardStateMetrics.headings.length} Major Milestones Retained
                </div>
              </div>

              {/* Column 2: What Is Added Live */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-indigo-500/30 space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-indigo-300 mb-2">
                    <Sparkles size={14} className="text-indigo-400" />
                    <span>2. What Is Added</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mb-2">
                    Live board metrics & incremental additions:
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-center text-xs">
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="font-mono text-base font-black text-cyan-300">{boardStateMetrics.words}</div>
                      <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Words Spoken</div>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="font-mono text-base font-black text-indigo-300">{boardStateMetrics.lines}</div>
                      <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Lines Written</div>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="font-mono text-base font-black text-amber-300">{boardStateMetrics.equations}</div>
                      <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Equations</div>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="font-mono text-base font-black text-emerald-300">{boardStateMetrics.figuresCount}</div>
                      <div className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Figures In Dock</div>
                    </div>
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-800/80 text-[10px] text-indigo-300 font-mono truncate">
                  ● Phase: {boardStateMetrics.activePhase}
                </div>
              </div>

              {/* Column 3: Upcoming Pathway */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-purple-500/30 space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-purple-300 mb-2">
                    <Compass size={14} className="text-purple-400" />
                    <span>3. Ingestion Pathway</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mb-2">
                    Progress through curriculum milestones:
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-slate-300">Lecture Progress:</span>
                      <span className="font-mono text-purple-300">{boardStateMetrics.progress}%</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                      <div 
                        className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${boardStateMetrics.progress}%` }}
                      ></div>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-300 mt-2">
                      <span className="text-amber-300 font-bold">Practice Target: </span>
                      {boardStateMetrics.questions} Exam questions structured with non-fading bold criteria.
                    </div>
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-800/80 text-[10px] text-purple-300 font-mono">
                  ➔ Continuous Teaching Engine Active
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
              <span className="text-slate-400 text-[11px]">
                Speech, Board Typewriter & Avatar Animation Kinematics are 100% Synchronized.
              </span>
              <button
                onClick={() => setShowMasterRuleModal(false)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold cursor-pointer shadow-md shadow-cyan-600/30"
              >
                Close Awareness Hub
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Collaborative Whiteboard Overlay Modal */}
      {showWhiteboardModal && (
        <div className="fixed inset-4 sm:inset-10 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <CollaborativeWhiteboard
            isOpen={showWhiteboardModal}
            onClose={() => setShowWhiteboardModal(false)}
            onSendToBoard={(content) => {
              setBoardContent(prev => prev + '\n\n' + content);
            }}
            theme={theme}
            showNotification={showNotification}
            currentTopic={activeTopicTitle}
          />
        </div>
      )}

      {/* Topic Selector Component */}
      <TopicSelector
        isOpen={showTopicModal}
        currentTopic={activeTopicTitle}
        currentSubject={userSubject}
        selectedBoard={selectedBoard}
        isLoading={isLoadingAi}
        currentTeacherStyleId={selectedTeacherStyle.id}
        onSelectTeacherStyle={(styleId) => {
          const style = getTeacherStyleById(styleId);
          if (style) {
            setSelectedTeacherStyle(style);
            try {
              localStorage.setItem('3d_classroom_teacher_style', styleId);
            } catch (e) {}
            showNotification?.(`Switched to ${style.name} (${style.tagline})! ${style.avatarIcon}`, 'success');
            playSoundEffect('chime');
          }
        }}
        onClose={() => setShowTopicModal(false)}
        onSelectTopic={(topicName) => {
          handleStageSelectedChapter(topicName, true);
        }}
      />

      {/* Professor Clarity Visual Avatar Animation Engine Studio Modal */}
      <AvatarEngineControlModal
        isOpen={showAvatarModal}
        onClose={() => setShowAvatarModal(false)}
      />

      {/* Professor Avatar Floating Gesture Window (Minimised when not speaking, expanded when speaking - PART 1) */}
      <div 
        className="fixed bottom-4 right-4 z-40 pointer-events-auto select-none transition-all duration-300"
        onMouseEnter={() => setIsDeskHovered(true)}
        onMouseLeave={() => setIsDeskHovered(false)}
      >
        {isSpeaking ? (
          /* Expanded 15% Window when Speaking */
          <div className="w-56 sm:w-64 bg-slate-900/95 border-2 border-indigo-500/50 rounded-2xl p-3 shadow-2xl backdrop-blur-xl space-y-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
                <span className="text-xs font-bold text-white truncate">{selectedTeacherStyle.name} Speaking</span>
              </div>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-indigo-950 text-indigo-300 border border-indigo-500/30 shrink-0">
                15% Window
              </span>
            </div>

            <div className="flex items-center gap-3 bg-slate-950/80 p-2 rounded-xl border border-slate-800">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-600 to-amber-500 p-0.5 shrink-0 shadow-md overflow-hidden relative">
                {customAvatarPhotoUrl ? (
                  <img
                    src={customAvatarPhotoUrl}
                    alt={selectedTeacherStyle.name}
                    className={cn(
                      "w-full h-full object-cover",
                      avatarPhotoDisplayMode === 'circular' ? "rounded-full" :
                      avatarPhotoDisplayMode === 'square' ? "rounded-lg" : "rounded-md border border-amber-400/50"
                    )}
                  />
                ) : (
                  <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center font-black text-amber-300 text-sm">
                    {selectedTeacherStyle.avatarIcon}
                  </div>
                )}
              </div>
              <div className="flex flex-col overflow-hidden">
                <span className="text-xs font-semibold text-slate-100 truncate">{selectedTeacherStyle.shortName}</span>
                <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>[PEDAGOGY: {selectedTeacherStyle.badge.toUpperCase()}]</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1 pt-1">
              <button
                onClick={() => setCameraView('avatar_focus')}
                className="flex-1 py-1 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold transition-all cursor-pointer shadow-sm text-center"
              >
                Focus Camera
              </button>
              <button
                onClick={() => setShowTeacherStyleModal(true)}
                className="px-2 py-1 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 text-[10px] font-bold transition-all cursor-pointer border border-emerald-700/50"
                title="Switch Pedagogy Style"
              >
                Style
              </button>
              <button
                onClick={() => setShowAvatarPhotoModal(true)}
                className="px-2 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold transition-all cursor-pointer"
                title="Customize Avatar Photo"
              >
                Photo
              </button>
            </div>
          </div>
        ) : (
          /* Minimised Circular 8% Badge when Idle / Not Speaking */
          <div className="flex items-center gap-2 bg-slate-950/90 border border-slate-800 rounded-full px-3 py-1.5 shadow-xl backdrop-blur-md text-slate-300 hover:border-indigo-500/50 transition-all cursor-pointer"
            onClick={() => setCameraView('avatar_focus')}
            title={`${selectedTeacherStyle.name} (Idle) • Click to Focus Camera`}
          >
            {customAvatarPhotoUrl ? (
              <img
                src={customAvatarPhotoUrl}
                alt="Avatar"
                className="w-4 h-4 rounded-full object-cover shrink-0 ring-1 ring-slate-600"
              />
            ) : (
              <div className="w-3 h-3 rounded-full bg-slate-600 shrink-0 flex items-center justify-center text-[8px]">
                {selectedTeacherStyle.avatarIcon}
              </div>
            )}
            <span className="text-[11px] font-bold text-slate-200">{selectedTeacherStyle.shortName}</span>
            <span className="text-[9px] text-slate-400 font-mono">(Idle)</span>
          </div>
        )}
      </div>

      {/* Professor Desk Interactive Dock HUD (Auto-Hides when idle - PART 1) */}
      <ProfessorDesk
        showHud={isTypingLive || isDeskHovered || isLaptopViewOpen}
        onOpenLaptopView={() => setIsLaptopViewOpen(true)}
        onFocusDeskCamera={() => setCameraView('desk_focus')}
        onQuickPreview={() => setIsLaptopViewOpen(true)}
        isLaptopOpen={true}
        topicTitle={activeTopicTitle}
        isTypingLive={isTypingLive}
        isSpeaking={isSpeaking}
        currentLessonNotes={typedBoardContent || boardContent}
        proximityState={proximityRingState}
      />

      {/* Interactive High-Res Laptop View & Study Workstation Modal */}
      <LaptopViewModal
        isOpen={isLaptopViewOpen}
        onClose={() => setIsLaptopViewOpen(false)}
        topicTitle={activeTopicTitle}
        lectureNotesMarkdown={typedBoardContent || boardContent}
        onSelectTopic={(topic) => handleStageSelectedChapter(topic, true)}
        showNotification={showNotification}
      />

      {/* Professor Executive Summary & Exam Revision Hub Modal */}
      <ProfessorSummaryModal
        isOpen={showProfessorSummaryModal}
        onClose={() => setShowProfessorSummaryModal(false)}
        topicTitle={activeTopicTitle}
        markdownContent={typedBoardContent || boardContent}
        initialTab={summaryModalInitialTab}
        onReadAloud={(text) => narrateCurrentBoardContent(text)}
        onFocus3DCamera={() => {
          setCameraView('board_focus');
          setShowProfessorSummaryModal(false);
        }}
        showNotification={showNotification}
      />

      {/* Interactive Scientific Unit Pronunciation Trainer & Voice Practice Modal */}
      {showPronunciationTrainerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-indigo-500/40 rounded-2xl shadow-2xl overflow-y-auto">
            <UnitPronunciationTrainer
              onClose={() => setShowPronunciationTrainerModal(false)}
              theme="dark"
              onAwardXp={(xp) => {
                showNotification?.(`Earned +${xp} XP in Unit Pronunciation Practice!`, 'success');
              }}
            />
          </div>
        </div>
      )}

      {/* Teacher Technique Discovery System Modal ("Teach Me Like...") */}
      <TeacherStyleDiscoveryModal
        isOpen={showTeacherStyleModal}
        onClose={() => setShowTeacherStyleModal(false)}
        currentStyleId={selectedTeacherStyle.id}
        onSelectStyle={(style) => {
          setSelectedTeacherStyle(style);
          try {
            localStorage.setItem('3d_classroom_teacher_style', style.id);
          } catch (e) {}
          showNotification?.(`Switched to ${style.name} (${style.tagline})!`, 'success');
          playSoundEffect('chime');
        }}
        showNotification={showNotification}
        currentTopic={activeTopicTitle}
        boardContent={boardContent}
        spokenText={typedBoardContent}
      />

      {/* Avatar Photo Auto-Fit Customization Modal */}
      <AvatarPhotoAutoFitModal
        isOpen={showAvatarPhotoModal}
        onClose={() => setShowAvatarPhotoModal(false)}
        currentPhotoUrl={customAvatarPhotoUrl}
        currentDisplayMode={avatarPhotoDisplayMode}
        onSavePhoto={(photoUrl, displayMode) => {
          setCustomAvatarPhotoUrl(photoUrl);
          setAvatarPhotoDisplayMode(displayMode);
          showNotification?.(photoUrl ? "Educator Avatar photo auto-fitted and saved!" : "Reset to 3D default avatar.", 'success');
          playSoundEffect('chime');
        }}
        showNotification={showNotification}
      />

      {/* 10-Step Formula Mastery Framework Modal */}
      <FormulaTeachingModal
        isOpen={showFormulaModal}
        onClose={() => setShowFormulaModal(false)}
        activeFormulaId={activeFormulaModalId}
        activeTopic={activeTopicTitle}
        subject={userSubject}
        onSpeak={(text) => {
          narrateCurrentBoardContent(text);
        }}
        showNotification={showNotification}
      />

      {/* Visual Presentation Architect & Master Formula Practice Modal */}
      {showVisualPresentationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-5xl max-h-[92vh] overflow-y-auto bg-slate-950 border-2 border-indigo-500/50 rounded-3xl p-4 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/40">
                  <Sparkles size={20} />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white tracking-wide">
                    Visual Presentation Architect — Professor Clarity
                  </h3>
                  <p className="text-xs text-slate-400">
                    Formula Practice Engine • Space Optimisation • Zero Overlapping • 5 Difficulty Levels
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowVisualPresentationModal(false)}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <SmartboardVisualPresentationArchitect
              onDeliverToSmartboard={(markdown, title) => {
                setShowVisualPresentationModal(false);
                setActiveTopicTitle(title);
                setBoardContent(markdown);
                setTypedBoardContent('');
                showNotification?.(`Delivered formula practice presentation for "${title}" to 3D Smartboard!`, 'success');
                playSoundEffect('chime');
                if (classroomVoiceOver) {
                  narrateCurrentBoardContent(markdown);
                }
              }}
              onSpeak={(text) => {
                narrateCurrentBoardContent(text);
              }}
              showNotification={showNotification}
            />
          </div>
        </div>
      )}

      {/* Content Collection & Multi-Source Curation System Modal */}
      <ContentCurationModal
        isOpen={isContentModalOpen}
        onClose={() => setIsContentModalOpen(false)}
        activeTopic={activeTopicTitle}
        onDeliverToSmartboard={(contentMarkdown, topicTitle) => {
          setIsContentModalOpen(false);
          setActiveTopicTitle(topicTitle);
          setBoardContent(contentMarkdown);
          setTypedBoardContent('');
          showNotification?.(`Delivered curated content for "${topicTitle}" to Smartboard!`, 'success');
          playSoundEffect('chime');
          if (classroomVoiceOver) {
            narrateCurrentBoardContent(contentMarkdown);
          } else {
            speakTutorMessage(`Curated lecture notes on ${topicTitle} have been loaded directly onto our 3D smartboard.`);
          }
        }}
      />

      {/* Visual Map & Schematic Breakdown Studio Modal */}
      <VisualMapStudioModal
        isOpen={showVisualMapStudioModal}
        onClose={() => setShowVisualMapStudioModal(false)}
        topicTitle={activeTopicTitle}
        subjectTitle={userSubject || 'Science / Engineering'}
        theme={theme}
        onSpeak={(text) => {
          narrateCurrentBoardContent(text);
        }}
        showNotification={showNotification}
        onDeliverToSmartboard={(contentMarkdown, topicTitle) => {
          setShowVisualMapStudioModal(false);
          setActiveTopicTitle(topicTitle);
          setBoardContent(contentMarkdown);
          setTypedBoardContent('');
          showNotification?.(`Delivered Visual Map & Schematic for "${topicTitle}" to 3D Smartboard!`, 'success');
          playSoundEffect('chime');
          if (classroomVoiceOver) {
            narrateCurrentBoardContent(contentMarkdown);
          } else {
            speakTutorMessage(`Visual concept map and schematic breakdown for ${topicTitle} have been loaded onto our smartboard.`);
          }
        }}
      />

      {/* Visual Transformation Architect Studio Modal */}
      <VisualTransformationModal
        isOpen={showVisualTransformationModal}
        onClose={() => setShowVisualTransformationModal(false)}
        theme={theme}
        onSpeak={(text) => {
          narrateCurrentBoardContent(text);
        }}
        showNotification={showNotification}
        onDeliverToSmartboard={(contentMarkdown, topicTitle) => {
          setShowVisualTransformationModal(false);
          setActiveTopicTitle(topicTitle);
          setBoardContent(contentMarkdown);
          setTypedBoardContent('');
          showNotification?.(`Delivered Visual Transformation for "${topicTitle}" to 3D Smartboard!`, 'success');
          playSoundEffect('chime');
          if (classroomVoiceOver) {
            narrateCurrentBoardContent(contentMarkdown);
          } else {
            speakTutorMessage(`Visual transformation presentation for ${topicTitle} has been loaded onto our smartboard.`);
          }
        }}
      />

      {/* React Health & State Management Studio Modal */}
      <ReactHealthModal
        isOpen={showReactHealthModal}
        onClose={() => setShowReactHealthModal(false)}
        theme={theme}
        showNotification={showNotification}
      />

      {/* Professor Clarity Self-Healing & System Observability Debugger Modal */}
      <ProfessorClarityDebuggerModal
        isOpen={showDebuggerModal}
        onClose={() => setShowDebuggerModal(false)}
        showNotification={showNotification}
      />

      {/* Professor Clarity 80-100 Question Rapid Fire Drill Studio Modal */}
      <RapidFireDrillStudioModal
        isOpen={showRapidFireDrillModal}
        onClose={() => setShowRapidFireDrillModal(false)}
        theme={theme}
        showNotification={showNotification}
        currentChapterTopic={activeTopicTitle || 'Sexual Reproduction in Flowering Plants (बीज एवं फल निर्माण)'}
        onSyncToSmartboard={(markdownText, title) => {
          setBoardContent(markdownText);
          setTypedBoardContent('');
          if (title) setActiveTopicTitle(title);
          showNotification?.(`Question synced to 3D Smartboard!`, 'success');
          playSoundEffect('chime');
          if (classroomVoiceOver) {
            narrateCurrentBoardContent(markdownText);
          }
        }}
      />

      {/* Double-Click Editable Asked Question & Solution Modal */}
      <EditableQuestionSolutionModal
        isOpen={showQuestionSolutionEditorModal}
        onClose={() => setShowQuestionSolutionEditorModal(false)}
        initialText={editableQuestionSolutionText}
        onSave={handleSaveEditedQuestionSolution}
        showNotification={showNotification}
      />

      {/* Professor Clarity Practice Question Quantity & Multi-Tier Hinting Vault Modal */}
      <PracticeQuestionStudioModal
        isOpen={showPracticeQuestionModal}
        onClose={() => setShowPracticeQuestionModal(false)}
        theme={theme}
        topicTitle={activeTopicTitle || 'Universal Physics & Science Foundations'}
        subjectTitle={userSubject || 'Science / Engineering'}
        initialMode={practiceQuestionInitialMode}
        onSpeak={(text) => {
          if (classroomVoiceOver) narrateCurrentBoardContent(text);
          else speakTutorMessage(text);
        }}
        showNotification={showNotification}
        onSyncToSmartboard={(markdownText, title) => {
          setBoardContent(markdownText);
          setTypedBoardContent('');
          if (title) setActiveTopicTitle(title);
          showNotification?.(`Practice Question synced to 3D Smartboard!`, 'success');
          playSoundEffect('chime');
          if (classroomVoiceOver) {
            narrateCurrentBoardContent(markdownText);
          }
        }}
      />

      {/* Ambient Lighting Inspector Modal (Nano Banana 2 Real-Time Material Vectors) */}
      <AmbientLightingInspectorModal
        isOpen={showLightingInspectorModal}
        onClose={() => setShowLightingInspectorModal(false)}
        activePreset={lightingPreset}
        onSelectPreset={(preset) => applyLightingPreset(preset)}
        activeTopicTitle={activeTopicTitle}
        onInsertGeneratedImageToBoard={(imgUrl, title) => {
          setBoardContent(prev => `${prev}\n\n### 🎨 Figure & Diagram (Nano Banana 2 - ${lightingPreset.toUpperCase()} Calibrated): ${title}\n![Nano Banana 2 Visual Figure: ${title}](${imgUrl})\n`);
          showNotification?.("Calibrated Nano Banana 2 image inserted onto Smartboard!", 'success');
          playSoundEffect('chime');
        }}
        showNotification={showNotification}
      />

      {/* AI Draw Vector Studio Modal (Decoupled from Smartboard) */}
      <AiDrawStudioModal
        isOpen={showAiDrawStudioModal}
        onClose={() => setShowAiDrawStudioModal(false)}
        topicTitle={activeTopicTitle}
        drawing={aiDrawResult}
        isLoading={isLoadingAiDraw}
        onRegenerate={handleTriggerAiDrawFromBackend}
        onExplainFigure={(res) => {
          setShowAiDrawStudioModal(false);
          const payload = res.imageUrl || res.svg || '';
          handleExplainFigureIn3D(payload, res.title || activeTopicTitle, Boolean(res.imageUrl));
        }}
        onSpeak={(text) => {
          if (classroomVoiceOver) narrateCurrentBoardContent(text);
          else speakTutorMessage(text);
        }}
        isSpeaking={isSpeaking}
        onStopSpeaking={stopSpeech}
      />

      {/* Professor Clarity Defense-in-Depth Security & DRM Shield Modal */}
      <SecurityShieldModal
        isOpen={showSecurityModal}
        onClose={() => setShowSecurityModal(false)}
      />

      {/* Professor Omni AI Interactive Master Studio Modal */}
      <ProfessorOmniAIModal
        isOpen={showProfessorOmniModal}
        onClose={() => setShowProfessorOmniModal(false)}
        topicTitle={activeTopicTitle || stagedTopicTitle || userTopic || 'General STEM & Sciences'}
        onStartLecture={(styleId) => {
          if (styleId) {
            const style = getTeacherStyleById(styleId);
            if (style) setSelectedTeacherStyle(style);
          }
          handleStartVirtualLearning();
        }}
        onAskQuestion={(question) => {
          handleAskTutor(question);
        }}
        onRequestDiagram={(prompt) => {
          handleAskTutor(prompt);
        }}
        onFocusProfessorCamera={() => {
          setCameraView('avatar_focus');
          showNotification?.("Focused camera on Professor Omni AI", "info");
        }}
        onSelectTeacherStyle={(styleId) => {
          const style = getTeacherStyleById(styleId);
          if (style) {
            setSelectedTeacherStyle(style);
            try {
              localStorage.setItem('3d_classroom_teacher_style', styleId);
            } catch (e) {}
          }
        }}
        currentTeacherStyleId={selectedTeacherStyle.id}
        isSpeaking={isSpeaking}
        showNotification={showNotification}
      />

      {/* 1. Quick Select Board & University Modal */}
      <QuickBoardUniversityModal
        isOpen={showQuickBoardModal}
        onClose={() => setShowQuickBoardModal(false)}
        selectedBoard={activeBoard}
        onSelectBoard={(board) => {
          setActiveBoard(board);
          if (onParentSelectBoard) onParentSelectBoard(board);
          playSoundEffect('click');
          showNotification?.(`Board & University updated: ${board.acronym} (${board.nation})`, 'success');
        }}
      />

      {/* 2. Vocal Persona & Real-Time Voice Agent Studio Modal */}
      <VocalPersonaStudioModal
        isOpen={showVocalPersonaModal}
        onClose={() => setShowVocalPersonaModal(false)}
        currentPersona={localPersonaConfig}
        onUpdatePersona={handleUpdatePersona}
        acousticProfile={activeAcousticProfile}
        onUpdateAcoustic={(partial) => {
          setAcousticProfiles(prev => prev.map(p => p.id === activeAcousticProfileId ? { ...p, ...partial } : p));
        }}
        isListening={isListening}
        onToggleMic={toggleSpeechRecognition}
        onSendVoicePrompt={(prompt) => {
          handleAskTutor(prompt);
          showNotification?.(`Voice prompt submitted: "${prompt.slice(0, 40)}..."`, 'info');
        }}
        isSpeaking={isSpeaking}
        onStopSpeaking={stopSpeech}
        availableVoices={availableVoices}
      />

      {/* 3. 3D Classroom AI Tools Suite Modal */}
      <ClassroomAiToolsModal
        isOpen={showClassroomAiToolsModal}
        onClose={() => setShowClassroomAiToolsModal(false)}
        tools={classroomAiTools}
        topic={activeTopicTitle || stagedTopicTitle || userTopic || 'General STEM'}
      />

      {/* 4. Classroom Syllabus & Chapter Roadmap Modal */}
      <ClassroomSyllabusModal
        isOpen={showClassroomSyllabusModal}
        onClose={() => setShowClassroomSyllabusModal(false)}
        difficulty={activeDifficulty}
        subject={activeSubject}
        onSelectSubject={(subj) => {
          setActiveSubject(subj);
          if (onParentSelectSubject) onParentSelectSubject(subj);
          const firstTopic = getFirstTopicForSubject(subj);
          handleStageSelectedChapter(firstTopic, true);
        }}
        currentTopic={activeTopicTitle || stagedTopicTitle || userTopic || ''}
        onStudyLesson={(lessonTitle, chapterTitle, depth) => {
          const fullTitle = lessonTitle ? `${chapterTitle}: ${lessonTitle}` : chapterTitle;
          handleStageSelectedChapter(fullTitle, true);
          showNotification?.(`Projected onto 3D Smartboard: ${fullTitle}`, 'success');
        }}
        selectedBoard={activeBoard}
      />
      {/* 5. Nano Banana Rigid-Body Physics & Collisions Modal */}
      <NanoBananaPhysicsModal
        isOpen={showBananaPhysicsModal}
        onClose={() => setShowBananaPhysicsModal(false)}
        onTossFromCamera={handleTossBananaFromCamera}
        onTossAtTarget={handleTossBananaAtTarget}
        onSpawnRain={handleSpawnBananaRain}
        onExplosionForce={handleBananaShockwave}
        onClearAll={handleClearBananas}
      />
    </div>
  );
};
