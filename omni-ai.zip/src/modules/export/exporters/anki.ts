import { saveAs } from 'file-saver';
import JSZip from 'jszip';

export async function exportToAnki(cards: { front: string; back: string }[]) {
  const zip = new JSZip();
  const text = cards.map(c => `${c.front}\t${c.back}`).join('\n');
  zip.file('cards.txt', text);
  const blob = await zip.generateAsync({ type: 'blob' });
  saveAs(blob, 'flashcards.apkg');
}
