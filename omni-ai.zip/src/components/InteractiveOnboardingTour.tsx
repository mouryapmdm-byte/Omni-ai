import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Check, 
  Box, 
  Search, 
  GraduationCap, 
  Wand2, 
  BookOpen, 
  WifiOff, 
  HelpCircle,
  Menu,
  Brain
} from 'lucide-react';
import { cn, triggerHapticFeedback } from '@/src/lib/utils';

export interface TourStep {
  targetId?: string;
  title: string;
  description: string;
  badge: string;
  icon: React.ReactNode;
  position?: 'bottom' | 'top' | 'center';
}

interface InteractiveOnboardingTourProps {
  isOpen: boolean;
  onClose: () => void;
  theme?: 'light' | 'dark';
}

const TOUR_STEPS: TourStep[] = [
  {
    title: "Welcome to Omni AI Platform",
    badge: "1/6 - Getting Started",
    description: "Experience next-gen AI education powered by Professor Clarity in 2D and immersive 3D virtual classrooms.",
    icon: <Brain size={24} className="text-indigo-400" />,
    position: "center"
  },
  {
    targetId: "topnav-search-bar",
    title: "Instant Global Search Bar",
    badge: "2/6 - Search & Discovery",
    description: "Quickly find any lesson, chapter, numerical practice, 3D STEM lab, or study tool. Try pressing Ctrl+K anywhere!",
    icon: <Search size={24} className="text-indigo-400" />,
    position: "bottom"
  },
  {
    targetId: "topnav-mode-3d",
    title: "Virtual 3D Classroom",
    badge: "3/6 - Immersive Learning",
    description: "Switch seamlessly into the 3D Virtual Lecture Hall with animated smartboard, lab apparatus, and double-click editable solutions.",
    icon: <Box size={24} className="text-indigo-400" />,
    position: "bottom"
  },
  {
    targetId: "topnav-sidebar-toggle",
    title: "Curriculum Navigation Sidebar",
    badge: "4/6 - Curriculum & Topics",
    description: "Access structured chapters, topic trees, saved chat sessions, and custom pedagogical options.",
    icon: <Menu size={24} className="text-indigo-400" />,
    position: "bottom"
  },
  {
    targetId: "topnav-tutor-wizard",
    title: "AI Socratic Tutor Wizard",
    badge: "5/6 - Direct Demand Teaching",
    description: "Configure tutor styles, voice narration, or request specific content like numerical questions or formula derivations.",
    icon: <Wand2 size={24} className="text-emerald-400" />,
    position: "bottom"
  },
  {
    title: "Offline Material Caching Ready",
    badge: "6/6 - Service Worker Powered",
    description: "All opened study materials, lessons, and diagrams are automatically cached for seamless offline access whenever you are disconnected.",
    icon: <WifiOff size={24} className="text-cyan-400" />,
    position: "center"
  }
];

export const InteractiveOnboardingTour: React.FC<InteractiveOnboardingTourProps> = ({
  isOpen,
  onClose,
  theme = 'dark'
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (isOpen) {
      setCurrentStep(0);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const step = TOUR_STEPS[currentStep];
  const isFirst = currentStep === 0;
  const isLast = currentStep === TOUR_STEPS.length - 1;

  const handleNext = () => {
    triggerHapticFeedback(10);
    if (isLast) {
      localStorage.setItem('omni_onboarding_completed', 'true');
      onClose();
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    triggerHapticFeedback(10);
    if (!isFirst) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSkip = () => {
    triggerHapticFeedback(10);
    localStorage.setItem('omni_onboarding_completed', 'true');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      {/* Backdrop click to dismiss */}
      <div className="absolute inset-0" onClick={handleSkip} />

      {/* Modal Card */}
      <div className={cn(
        "relative w-full max-w-lg rounded-3xl border-2 p-6 shadow-2xl z-10 transition-all duration-300 animate-in zoom-in-95",
        theme === 'dark' 
          ? "bg-slate-900 border-indigo-500/50 text-white shadow-indigo-950/60 ring-1 ring-indigo-500/30" 
          : "bg-white border-indigo-200 text-slate-900 shadow-xl"
      )}>
        {/* Top bar */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/40 mb-4">
          <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            {step.badge}
          </span>
          <button 
            onClick={handleSkip}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close / Skip Tour"
          >
            <X size={18} />
          </button>
        </div>

        {/* Step Content */}
        <div className="flex items-start gap-4 mb-6">
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-violet-500/20 border border-indigo-500/30 shrink-0">
            {step.icon}
          </div>
          <div>
            <h3 className="text-lg font-black tracking-tight mb-1.5 flex items-center gap-2">
              {step.title}
            </h3>
            <p className={cn("text-xs leading-relaxed font-medium", theme === 'dark' ? "text-slate-300" : "text-slate-600")}>
              {step.description}
            </p>
          </div>
        </div>

        {/* Step Progress Dots */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800/40">
          <div className="flex items-center gap-1.5">
            {TOUR_STEPS.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  triggerHapticFeedback(5);
                  setCurrentStep(idx);
                }}
                className={cn(
                  "h-2 rounded-full transition-all cursor-pointer",
                  idx === currentStep 
                    ? "w-6 bg-indigo-500" 
                    : "w-2 bg-slate-700 hover:bg-slate-500"
                )}
                title={`Go to step ${idx + 1}`}
              />
            ))}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            {!isFirst && (
              <button
                onClick={handlePrev}
                className={cn(
                  "px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer border",
                  theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700" : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                )}
              >
                <ChevronLeft size={14} /> Back
              </button>
            )}

            <button
              onClick={handleNext}
              className="px-4 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
            >
              {isLast ? (
                <>Complete Tour <Check size={14} /></>
              ) : (
                <>Next Step <ChevronRight size={14} /></>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
