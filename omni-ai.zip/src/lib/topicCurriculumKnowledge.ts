/**
 * Topic Curriculum Knowledge Engine
 * Provides authoritative, deep pedagogical profiles for all STEM chapters/topics.
 * Ensures Professor Clarity teaches ONLY the selected chapter/topic across all 7 sections.
 */

export interface TenStepItem {
  step: number;
  phase: string;
  explanation: string;
  formulaOrValue: string;
  trapAndTip: string;
}

export interface Technique11Question {
  level: number;
  levelName: string;
  difficulty: string;
  question: string;
  formulaApplication: string;
  stepByStepSolution: string[];
  answer: string;
}

export interface ComparativeMatrix {
  title: string;
  headers: string[];
  rows: string[][];
}

export interface AcademicQuestionItem {
  id: string;
  category: string;
  question: string;
  answer: string;
  marks: number;
  markingScheme: string[];
}

export interface CompetitiveQuestionItem {
  category: string;
  question: string;
  options?: string[];
  correctOption?: string;
  solution: string;
  speedTrick: string;
  negativeMarkingTrap: string;
}

export interface RapidFireItem {
  qNumber: number;
  question: string;
  answer: string;
  shortExplanation: string;
}

export interface VocabularyItem {
  term: string;
  etymology: string;
  definition: string;
  memoryHook: string;
}

export interface SpokenUnitItem {
  symbol: string;
  unitName: string;
  spokenForm: string;
  physicalMeaning: string;
}

export interface FiveLayerSummaryItem {
  layer1UltraRapid: string;
  layer2FirstPrinciples: string[];
  layer3GoldenEquations: string[];
  layer4ExaminerTraps: string[];
  layer5VisualMentalSchema: string;
}

export interface TopicCurriculumProfile {
  title: string;
  domain: 'physics' | 'chemistry' | 'biology' | 'math' | 'general';
  
  // Section 1: Core Conceptual Foundation & Active Pedagogy
  introConcept: string;
  analogy: string;
  questionFirst: string;
  svgDiagram: string;
  
  // Section 2: Master 10-Step Formula & Algorithmic Framework
  governingEquationName: string;
  governingEquationLatex: string;
  tenStepProtocol: TenStepItem[];
  technique11Questions: Technique11Question[];
  
  // Section 3: Master Tabular Summaries & Comparative Matrix Suite
  comparativeMatrices: ComparativeMatrix[];
  diagnosticDecisionMatrix: ComparativeMatrix;
  
  // Section 4: Academic & Board Exam Preparation Suite (8 Structured Categories)
  academicQuestions: AcademicQuestionItem[];
  
  // Section 5: Competitive Entrance Exam Vault (NEET / JEE / AIIMS - 10 Categories)
  competitiveQuestions: CompetitiveQuestionItem[];
  
  // Section 6: High-Yield Question Bank, Vocabulary & Spoken Units
  rapidFireQuestions: RapidFireItem[];
  vocabularyMasterclass: VocabularyItem[];
  spokenUnits: SpokenUnitItem[];
  
  // Section 7: The 5-Layer Progressive High Voltage Summary
  fiveLayerSummary: FiveLayerSummaryItem;
}

// Helper to determine subject domain
export function detectSubjectDomain(topicTitle: string): 'physics' | 'chemistry' | 'biology' | 'math' | 'general' {
  const text = (topicTitle || '').toLowerCase();
  
  if (text.includes('photo') || text.includes('cell') || text.includes('bio') || text.includes('plant') || 
      text.includes('dna') || text.includes('organ') || text.includes('genet') || text.includes('ecolog') || 
      text.includes('botan') || text.includes('zoolog') || text.includes('reproduct') || text.includes('respirat') ||
      text.includes('evolution') || text.includes('tissue') || text.includes('microb')) {
    return 'biology';
  }
  
  if (text.includes('chem') || text.includes('reaction') || text.includes('bond') || text.includes('acid') || 
      text.includes('base') || text.includes('mole') || text.includes('atom') || text.includes('equilibrium') || 
      text.includes('redox') || text.includes('organic') || text.includes('solution') || text.includes('periodic') ||
      text.includes('electrochem') || text.includes('kinetic') || text.includes('haloalkan') || text.includes('alcohol') ||
      text.includes('aldehyde') || text.includes('amine') || text.includes('element')) {
    return 'chemistry';
  }
  
  if (text.includes('force') || text.includes('thermo') || text.includes('optic') || text.includes('wave') || 
      text.includes('physic') || text.includes('electric') || text.includes('current') || text.includes('magnet') || 
      text.includes('gravity') || text.includes('gravitat') || text.includes('motion') || text.includes('kinematic') ||
      text.includes('charge') || text.includes('field') || text.includes('potential') || text.includes('capacit') ||
      text.includes('induct') || text.includes('radiation') || text.includes('nuclei') || text.includes('semiconductor') ||
      text.includes('light') || text.includes('refraction') || text.includes('reflection')) {
    return 'physics';
  }
  
  if (text.includes('math') || text.includes('calculus') || text.includes('derivative') || text.includes('integral') || 
      text.includes('matrix') || text.includes('matrices') || text.includes('determinant') || text.includes('vector') || 
      text.includes('algebra') || text.includes('geometry') || text.includes('trig') || text.includes('equation') || 
      text.includes('relation') || text.includes('function') || text.includes('probability') || text.includes('differential')) {
    return 'math';
  }
  
  return 'general';
}

// Build SVG dynamic illustration customized to topic domain & title
export function generateTopicSvgDiagram(topicTitle: string, domain: string): string {
  const clean = topicTitle.replace(/^(###\s*|Topic:\s*|\d+\.\s*)/i, '').trim();
  const lower = clean.toLowerCase();

  if (lower.includes('photoelectric') || lower.includes('dual nature') || lower.includes('radiation')) {
    return `<svg viewBox="0 0 650 260" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#0a0f1d; border:1.5px solid #38bdf8; border-radius:16px; padding:12px; margin:16px 0;">
  <defs>
    <linearGradient id="peLight" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#fde047"/><stop offset="100%" stop-color="#ea580c"/></linearGradient>
    <linearGradient id="peMetal" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stop-color="#475569"/><stop offset="100%" stop-color="#1e293b"/></linearGradient>
    <marker id="peArr" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 1 L 10 5 L 0 9 z" fill="#38bdf8"/></marker>
  </defs>
  <rect x="50" y="160" width="340" height="40" rx="8" fill="url(#peMetal)" stroke="#64748b" stroke-width="2"/>
  <text x="220" y="185" font-family="sans-serif" font-size="12" font-weight="bold" fill="#f8fafc" text-anchor="middle">Photosensitive Metal Plate (Work Function Φ₀)</text>
  <!-- Incident Photons -->
  <path d="M 60 30 Q 80 50 100 70 T 140 110 T 180 155" fill="none" stroke="url(#peLight)" stroke-width="3"/>
  <circle cx="60" cy="30" r="5" fill="#fde047"/>
  <text x="70" y="25" font-family="sans-serif" font-size="11" font-weight="bold" fill="#fde047">Incident Photon: E = hν</text>
  <!-- Emitted Photoelectron -->
  <path d="M 220 155 L 300 75" stroke="#38bdf8" stroke-width="3" marker-end="url(#peArr)" stroke-dasharray="4,2"/>
  <circle cx="220" cy="155" r="5" fill="#38bdf8"/>
  <text x="310" y="70" font-family="sans-serif" font-size="11" font-weight="bold" fill="#38bdf8">Ejected Electron (K_max = hν - Φ₀)</text>
  <!-- Energy Conservation Box -->
  <rect x="420" y="40" width="200" height="160" rx="12" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5"/>
  <text x="520" y="70" font-family="sans-serif" font-size="12" font-weight="black" fill="#38bdf8" text-anchor="middle">Einstein's Equation</text>
  <text x="520" y="100" font-family="sans-serif" font-size="14" font-weight="bold" fill="#fde047" text-anchor="middle">hν = Φ₀ + K_max</text>
  <text x="520" y="130" font-family="sans-serif" font-size="11" fill="#94a3b8" text-anchor="middle">Φ₀ = hν₀ (Threshold)</text>
  <text x="520" y="155" font-family="sans-serif" font-size="11" fill="#34d399" text-anchor="middle">K_max = e V₀ (Stopping)</text>
  <text x="520" y="180" font-family="sans-serif" font-size="10" fill="#cbd5e1" text-anchor="middle">Instantaneous (t &lt; 10⁻⁹ s)</text>
</svg>`;
  }

  if (lower.includes('photo') || lower.includes('plant') || lower.includes('leaf') || lower.includes('chlorophyll')) {
    return `<svg viewBox="0 0 650 260" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#06140e; border:1.5px solid #22c55e; border-radius:16px; padding:12px; margin:16px 0;">
  <defs>
    <linearGradient id="leafGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#15803d"/><stop offset="100%" stop-color="#14532d"/></linearGradient>
    <linearGradient id="sunGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#fef08a"/><stop offset="100%" stop-color="#eab308"/></linearGradient>
  </defs>
  <!-- Sun Element (A) -->
  <circle cx="80" cy="60" r="32" fill="url(#sunGrad)" stroke="#facc15" stroke-width="2"/>
  <text x="80" y="65" font-family="sans-serif" font-size="11" font-weight="bold" fill="#713f12" text-anchor="middle">SUN (Light)</text>
  <!-- Leaf Central Laboratory -->
  <path d="M 220 50 C 340 20 420 80 400 180 C 320 220 200 200 220 50 Z" fill="url(#leafGrad)" stroke="#4ade80" stroke-width="2.5"/>
  <text x="310" y="125" font-family="sans-serif" font-size="13" font-weight="black" fill="#ffffff" text-anchor="middle">CHLOROPLAST</text>
  <text x="310" y="145" font-family="sans-serif" font-size="11" fill="#bbf7d0" text-anchor="middle">6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂</text>
  <!-- Inputs: Water & CO2 -->
  <rect x="60" y="160" width="110" height="40" rx="8" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5"/>
  <text x="115" y="185" font-family="sans-serif" font-size="11" font-weight="bold" fill="#ffffff" text-anchor="middle">H₂O from Roots</text>
  <path d="M 170 180 L 230 160" stroke="#38bdf8" stroke-width="3" stroke-dasharray="4,2"/>
  <!-- Outputs: Glucose & Oxygen -->
  <rect x="460" y="60" width="140" height="42" rx="8" fill="#d97706" stroke="#f59e0b" stroke-width="1.5"/>
  <text x="530" y="85" font-family="sans-serif" font-size="11" font-weight="bold" fill="#ffffff" text-anchor="middle">C₆H₁₂O₆ (Glucose)</text>
  <rect x="460" y="130" width="140" height="42" rx="8" fill="#059669" stroke="#34d399" stroke-width="1.5"/>
  <text x="530" y="155" font-family="sans-serif" font-size="11" font-weight="bold" fill="#ffffff" text-anchor="middle">6O₂ Released (Life)</text>
</svg>`;
  }

  if (lower.includes('electric') || lower.includes('charge') || lower.includes('coulomb') || lower.includes('field') || lower.includes('current')) {
    return `<svg viewBox="0 0 650 260" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#0b1329; border:1.5px solid #38bdf8; border-radius:16px; padding:12px; margin:16px 0;">
  <circle cx="160" cy="120" r="36" fill="#dc2626" stroke="#f87171" stroke-width="3"/>
  <text x="160" y="126" font-family="sans-serif" font-size="20" font-weight="bold" fill="#ffffff" text-anchor="middle">+q₁</text>
  <circle cx="420" cy="120" r="36" fill="#2563eb" stroke="#60a5fa" stroke-width="3"/>
  <text x="420" y="126" font-family="sans-serif" font-size="20" font-weight="bold" fill="#ffffff" text-anchor="middle">-q₂</text>
  <!-- Field Lines -->
  <path d="M 196 120 L 384 120" stroke="#fde047" stroke-width="3"/>
  <path d="M 180 90 Q 290 40 400 90" fill="none" stroke="#38bdf8" stroke-width="2.5"/>
  <path d="M 180 150 Q 290 200 400 150" fill="none" stroke="#38bdf8" stroke-width="2.5"/>
  <text x="290" y="110" font-family="sans-serif" font-size="11" font-weight="bold" fill="#fde047" text-anchor="middle">Electrostatic Attraction</text>
  <rect x="180" y="215" width="220" height="30" rx="6" fill="#1e293b" stroke="#475569" stroke-width="1"/>
  <text x="290" y="235" font-family="monospace" font-size="11" font-weight="bold" fill="#38bdf8" text-anchor="middle">F = (1/4πε₀) · |q₁q₂| / r²</text>
</svg>`;
  }

  if (lower.includes('optic') || lower.includes('light') || lower.includes('reflection') || lower.includes('refraction') || lower.includes('lens') || lower.includes('mirror')) {
    return `<svg viewBox="0 0 650 260" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#0b1329; border:1.5px solid #a855f7; border-radius:16px; padding:12px; margin:16px 0;">
  <!-- Optical Axis -->
  <line x1="30" y1="130" x2="620" y2="130" stroke="#64748b" stroke-width="1.5" stroke-dasharray="6,4"/>
  <!-- Convex Lens -->
  <path d="M 325 30 Q 350 130 325 230 Q 300 130 325 30 Z" fill="#38bdf8" fill-opacity="0.3" stroke="#38bdf8" stroke-width="2.5"/>
  <text x="325" y="248" font-family="sans-serif" font-size="11" font-weight="bold" fill="#38bdf8" text-anchor="middle">Optical Center (O)</text>
  <!-- Object -->
  <line x1="140" y1="130" x2="140" y2="70" stroke="#facc15" stroke-width="3"/>
  <polygon points="135,70 145,70 140,60" fill="#facc15"/>
  <text x="140" y="52" font-family="sans-serif" font-size="11" font-weight="bold" fill="#facc15" text-anchor="middle">Object (h_o)</text>
  <!-- Parallel Ray to Focus -->
  <line x1="140" y1="70" x2="325" y2="70" stroke="#ef4444" stroke-width="2"/>
  <line x1="325" y1="70" x2="520" y2="190" stroke="#ef4444" stroke-width="2"/>
  <!-- Central Ray -->
  <line x1="140" y1="70" x2="520" y2="190" stroke="#22c55e" stroke-width="2"/>
  <!-- Image -->
  <line x1="520" y1="130" x2="520" y2="190" stroke="#a855f7" stroke-width="3"/>
  <polygon points="515,190 525,190 520,200" fill="#a855f7"/>
  <text x="520" y="215" font-family="sans-serif" font-size="11" font-weight="bold" fill="#a855f7" text-anchor="middle">Real Inverted Image (h_i)</text>
  <!-- Formula -->
  <rect x="440" y="30" width="180" height="35" rx="8" fill="#1e1b4b" stroke="#a855f7" stroke-width="1.5"/>
  <text x="530" y="52" font-family="monospace" font-size="11" font-weight="bold" fill="#e9d5ff" text-anchor="middle">1/f = 1/v - 1/u</text>
</svg>`;
  }

  // Matrices & Determinants / Linear Transformations & Scalar Multiplications
  if (lower.includes('matrix') || lower.includes('matrices') || lower.includes('determinant') || lower.includes('linear transform') || lower.includes('eigen')) {
    return `<svg viewBox="0 0 650 260" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#070d1e; border:1.5px solid #38bdf8; border-radius:16px; padding:12px; margin:16px 0;">
  <defs>
    <linearGradient id="transGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#38bdf8"/><stop offset="100%" stop-color="#818cf8"/></linearGradient>
    <linearGradient id="sqGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#22c55e" stop-opacity="0.3"/><stop offset="100%" stop-color="#15803d" stop-opacity="0.5"/></linearGradient>
    <linearGradient id="paraGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#f59e0b" stop-opacity="0.4"/><stop offset="100%" stop-color="#ea580c" stop-opacity="0.6"/></linearGradient>
    <marker id="matArr1" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 1 L 10 5 L 0 9 z" fill="#38bdf8"/></marker>
    <marker id="matArr2" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 1 L 10 5 L 0 9 z" fill="#facc15"/></marker>
  </defs>
  <!-- Grid 1: Original Unit Square Domain -->
  <line x1="30" y1="200" x2="210" y2="200" stroke="#475569" stroke-width="1.5"/>
  <line x1="60" y1="230" x2="60" y2="60" stroke="#475569" stroke-width="1.5"/>
  <polygon points="60,200 130,200 130,130 60,130" fill="url(#sqGrad)" stroke="#22c55e" stroke-width="2"/>
  <text x="95" y="170" font-family="sans-serif" font-size="11" font-weight="bold" fill="#86efac" text-anchor="middle">Area = 1</text>
  <text x="95" y="218" font-family="sans-serif" font-size="10" font-weight="bold" fill="#38bdf8" text-anchor="middle">i_hat (1,0)</text>
  <text x="40" y="165" font-family="sans-serif" font-size="10" font-weight="bold" fill="#facc15" text-anchor="middle">j_hat (0,1)</text>

  <!-- Transformation Arrow: Matrix A -->
  <path d="M 230 145 L 290 145" stroke="#38bdf8" stroke-width="3" marker-end="url(#matArr1)"/>
  <rect x="225" y="105" width="70" height="28" rx="6" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5"/>
  <text x="260" y="124" font-family="sans-serif" font-size="12" font-weight="black" fill="#38bdf8" text-anchor="middle">A [T]</text>

  <!-- Grid 2: Transformed Parallelogram Domain -->
  <line x1="320" y1="200" x2="520" y2="200" stroke="#475569" stroke-width="1.5"/>
  <line x1="340" y1="230" x2="340" y2="60" stroke="#475569" stroke-width="1.5"/>
  <!-- Transformed basis: (1,0)->(80,-30), (0,1)->(30,-80) -> (340,200) -> (420,170), (370,120), (450,90) -->
  <polygon points="340,200 440,185 490,105 390,120" fill="url(#paraGrad)" stroke="#f59e0b" stroke-width="2.5"/>
  <line x1="340" y1="200" x2="440" y2="185" stroke="#38bdf8" stroke-width="2.5" marker-end="url(#matArr1)"/>
  <line x1="340" y1="200" x2="390" y2="120" stroke="#facc15" stroke-width="2.5" marker-end="url(#matArr2)"/>
  <text x="430" y="150" font-family="sans-serif" font-size="11" font-weight="bold" fill="#fde047" text-anchor="middle">Area = |det(A)|</text>

  <!-- Formula Panel: Invariant Scaling Metric -->
  <rect x="525" y="35" width="115" height="195" rx="10" fill="#0f172a" stroke="#818cf8" stroke-width="1.5"/>
  <text x="582" y="60" font-family="sans-serif" font-size="11" font-weight="black" fill="#818cf8" text-anchor="middle">GOLDEN LAW</text>
  <text x="582" y="90" font-family="monospace" font-size="12" font-weight="bold" fill="#facc15" text-anchor="middle">det(kA)</text>
  <text x="582" y="112" font-family="monospace" font-size="13" font-weight="bold" fill="#38bdf8" text-anchor="middle">= kⁿ det(A)</text>
  <text x="582" y="145" font-family="sans-serif" font-size="10" fill="#94a3b8" text-anchor="middle">n = Matrix Order</text>
  <text x="582" y="170" font-family="sans-serif" font-size="10" fill="#a5f3fc" text-anchor="middle">2D Area ∝ k²</text>
  <text x="582" y="195" font-family="sans-serif" font-size="10" fill="#cbd5e1" text-anchor="middle">3D Vol ∝ k³</text>

  <!-- Banner Header -->
  <rect x="150" y="10" width="350" height="26" rx="8" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5"/>
  <text x="325" y="27" font-family="sans-serif" font-size="11" font-weight="black" fill="#38bdf8" text-anchor="middle">LINEAR TRANSFORMATIONS &amp; DETERMINANT AREA SCALING</text>
</svg>`;
  }

  // Vectors & Vector Algebra
  if (lower.includes('vector') || lower.includes('cross product') || lower.includes('dot product') || lower.includes('scalar product')) {
    return `<svg viewBox="0 0 650 260" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#070d1e; border:1.5px solid #818cf8; border-radius:16px; padding:12px; margin:16px 0;">
  <defs>
    <marker id="vArr1" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 1 L 10 5 L 0 9 z" fill="#38bdf8"/></marker>
    <marker id="vArr2" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 1 L 10 5 L 0 9 z" fill="#facc15"/></marker>
    <marker id="vArrR" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 1 L 10 5 L 0 9 z" fill="#ef4444"/></marker>
  </defs>
  <!-- Vector Addition Parallelogram -->
  <polygon points="60,200 240,200 320,100 140,100" fill="rgba(99,102,241,0.2)" stroke="#475569" stroke-width="1.5" stroke-dasharray="4,2"/>
  <line x1="60" y1="200" x2="240" y2="200" stroke="#38bdf8" stroke-width="3.5" marker-end="url(#vArr1)"/>
  <text x="150" y="222" font-family="sans-serif" font-size="12" font-weight="bold" fill="#38bdf8" text-anchor="middle">Vector A</text>
  <line x1="60" y1="200" x2="140" y2="100" stroke="#facc15" stroke-width="3.5" marker-end="url(#vArr2)"/>
  <text x="80" y="145" font-family="sans-serif" font-size="12" font-weight="bold" fill="#facc15" text-anchor="middle">Vector B</text>
  <!-- Resultant Vector R = A + B -->
  <line x1="60" y1="200" x2="320" y2="100" stroke="#ef4444" stroke-width="3.5" marker-end="url(#vArrR)"/>
  <text x="210" y="135" font-family="sans-serif" font-size="12" font-weight="black" fill="#f87171" text-anchor="middle">R = A + B</text>

  <!-- Right Panel: Operations & Formulas -->
  <rect x="360" y="35" width="270" height="200" rx="12" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5"/>
  <text x="495" y="65" font-family="sans-serif" font-size="13" font-weight="black" fill="#38bdf8" text-anchor="middle">VECTOR OPERATIONS</text>
  <text x="495" y="95" font-family="monospace" font-size="11" font-weight="bold" fill="#fde047" text-anchor="middle">A · B = |A||B| cos θ (Dot)</text>
  <text x="495" y="125" font-family="monospace" font-size="11" font-weight="bold" fill="#a5f3fc" text-anchor="middle">|A × B| = |A||B| sin θ (Cross)</text>
  <text x="495" y="155" font-family="sans-serif" font-size="11" fill="#cbd5e1" text-anchor="middle">Resultant Magnitude:</text>
  <text x="495" y="180" font-family="monospace" font-size="11" font-weight="bold" fill="#86efac" text-anchor="middle">R = √(A² + B² + 2AB cos θ)</text>
  <text x="495" y="210" font-family="sans-serif" font-size="10" fill="#94a3b8" text-anchor="middle">Direction: tan α = (B sin θ)/(A + B cos θ)</text>
</svg>`;
  }

  // Continuity & Differentiability / LHD & RHD Vector Diagram
  if (lower.includes('continuity') || lower.includes('differentiab') || lower.includes('lhd') || lower.includes('rhd') || (lower.includes('derivative') && (lower.includes('left') || lower.includes('right') || lower.includes('limit') || lower.includes('calculus')))) {
    return `<svg viewBox="0 0 650 260" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#070d1e; border:1.5px solid #38bdf8; border-radius:16px; padding:12px; margin:16px 0;">
  <defs>
    <linearGradient id="diffGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#38bdf8"/><stop offset="100%" stop-color="#818cf8"/></linearGradient>
    <marker id="mathArr" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 1 L 10 5 L 0 9 z" fill="#38bdf8"/></marker>
  </defs>
  <!-- Axis Left: Smooth Differentiable Curve -->
  <line x1="30" y1="180" x2="290" y2="180" stroke="#475569" stroke-width="1.5"/>
  <line x1="160" y1="30" x2="160" y2="200" stroke="#475569" stroke-width="1.5"/>
  <path d="M 60 170 Q 160 140 260 40" fill="none" stroke="#22c55e" stroke-width="3"/>
  <!-- Tangent Line at x=a -->
  <line x1="90" y1="180" x2="230" y2="80" stroke="#facc15" stroke-width="2" stroke-dasharray="4,2"/>
  <circle cx="160" cy="130" r="5" fill="#facc15"/>
  <text x="160" y="115" font-family="sans-serif" font-size="11" font-weight="bold" fill="#facc15" text-anchor="middle">Point (a, f(a))</text>
  <text x="160" y="215" font-family="sans-serif" font-size="11" font-weight="bold" fill="#86efac" text-anchor="middle">Smooth: LHD = RHD = f'(a)</text>
  <text x="160" y="235" font-family="sans-serif" font-size="10" fill="#94a3b8" text-anchor="middle">Unique Tangent Exists (Differentiable)</text>

  <!-- Divider -->
  <line x1="320" y1="20" x2="320" y2="240" stroke="#334155" stroke-width="2" stroke-dasharray="6,4"/>

  <!-- Axis Right: Sharp Corner (e.g. f(x) = |x| at x=0) -->
  <line x1="350" y1="180" x2="610" y2="180" stroke="#475569" stroke-width="1.5"/>
  <line x1="480" y1="30" x2="480" y2="200" stroke="#475569" stroke-width="1.5"/>
  <!-- Left Ray: Slope = -1 -->
  <line x1="390" y1="90" x2="480" y2="180" stroke="#ef4444" stroke-width="3"/>
  <!-- Right Ray: Slope = +1 -->
  <line x1="480" y1="180" x2="570" y2="90" stroke="#38bdf8" stroke-width="3"/>
  <circle cx="480" cy="180" r="5" fill="#f87171"/>
  <!-- Labels for LHD & RHD -->
  <text x="415" y="125" font-family="sans-serif" font-size="10" font-weight="bold" fill="#f87171">LHD = -1</text>
  <text x="535" y="125" font-family="sans-serif" font-size="10" font-weight="bold" fill="#38bdf8">RHD = +1</text>
  <text x="480" y="215" font-family="sans-serif" font-size="11" font-weight="bold" fill="#f87171" text-anchor="middle">Sharp Corner: LHD ≠ RHD</text>
  <text x="480" y="235" font-family="sans-serif" font-size="10" fill="#fca5a5" text-anchor="middle">Continuous but NOT Differentiable</text>

  <!-- Header Banner -->
  <rect x="180" y="10" width="290" height="28" rx="8" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5"/>
  <text x="325" y="28" font-family="sans-serif" font-size="11" font-weight="black" fill="#38bdf8" text-anchor="middle">LHD &amp; RHD CORRELATIONS &amp; DIFFERENTIABILITY</text>
</svg>`;
  }

  // Default Scientific Vector Schematic for Topic
  return `<svg viewBox="0 0 650 260" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#0b1329; border:1.5px solid #38bdf8; border-radius:16px; padding:12px; margin:16px 0;">
  <defs>
    <linearGradient id="defGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#38bdf8"/><stop offset="100%" stop-color="#2563eb"/></linearGradient>
    <marker id="defArr" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 1 L 10 5 L 0 9 z" fill="#38bdf8"/></marker>
  </defs>
  <rect x="40" y="30" width="220" height="70" rx="12" fill="#1e293b" stroke="#38bdf8" stroke-width="2"/>
  <text x="150" y="60" font-family="sans-serif" font-size="12" font-weight="black" fill="#38bdf8" text-anchor="middle">FUNDAMENTAL STATE</text>
  <text x="150" y="80" font-family="sans-serif" font-size="11" fill="#94a3b8" text-anchor="middle">${clean.slice(0, 24)}</text>
  <path d="M 260 65 L 370 65" stroke="#38bdf8" stroke-width="3" marker-end="url(#defArr)"/>
  <text x="315" y="55" font-family="sans-serif" font-size="10" font-weight="bold" fill="#fde047" text-anchor="middle">Dynamic Flow</text>
  <rect x="380" y="30" width="230" height="70" rx="12" fill="#0f172a" stroke="#22c55e" stroke-width="2"/>
  <text x="495" y="60" font-family="sans-serif" font-size="12" font-weight="black" fill="#22c55e" text-anchor="middle">GOVERNING EQUILIBRIUM</text>
  <text x="495" y="80" font-family="sans-serif" font-size="11" fill="#86efac" text-anchor="middle">Conserved Invariants</text>
  <rect x="40" y="140" width="570" height="90" rx="12" fill="#0f172a" stroke="#475569" stroke-width="1.5"/>
  <text x="325" y="170" font-family="sans-serif" font-size="13" font-weight="bold" fill="#f8fafc" text-anchor="middle">Topic Core: ${clean}</text>
  <text x="325" y="195" font-family="monospace" font-size="12" fill="#fde047" text-anchor="middle">Governing First-Principles Axiom &amp; Conservation Metric</text>
  <text x="325" y="215" font-family="sans-serif" font-size="11" fill="#94a3b8" text-anchor="middle">Active Pedagogy • 10-Step Algorithm • 8-Category Board Prep • NEET/JEE Vault</text>
</svg>`;
}

// Full Authoritative Topic Profile Builder
export function getCurriculumProfile(topicTitle: string): TopicCurriculumProfile {
  const clean = (topicTitle || 'Universal Scientific Foundations').replace(/^(###\s*|Topic:\s*|\d+\.\s*)/i, '').trim();
  const domain = detectSubjectDomain(clean);
  const lower = clean.toLowerCase();

  // CONTINUITY & DIFFERENTIABILITY: LHD AND RHD CORRELATIONS
  if (lower.includes('continuity') || lower.includes('differentiab') || lower.includes('lhd') || lower.includes('rhd') || (lower.includes('derivative') && (lower.includes('left') || lower.includes('right') || lower.includes('limit') || lower.includes('calculus')))) {
    return {
      title: clean || '2. Left-hand derivative (LHD) and right-hand derivative (RHD) correlations - 5. Continuity and Differentiability',
      domain: 'math',
      introConcept: `In differential calculus, **differentiability** measures the existence of a unique, non-vertical tangent line to a curve at a given point $x = a$. For a real-valued function $f(x)$ defined on an open interval around $x = a$, the derivative $f'(a)$ exists if and only if both the **Left-Hand Derivative (LHD)** and the **Right-Hand Derivative (RHD)** exist finitely and are strictly equal:
$$\\text{LHD} = f'(a^-) = \\lim_{h \\to 0^+} \\frac{f(a-h) - f(a)}{-h} = \\lim_{h \\to 0^+} \\frac{f(a+h) - f(a)}{h} = f'(a^+) = \\text{RHD}$$

A fundamental cornerstone theorem states: **Every differentiable function is necessarily continuous, but every continuous function is NOT necessarily differentiable.** At sharp corners, cusps, or vertical tangents (such as $f(x) = |x|$ at $x = 0$), the curve is continuous because the limit equals the function value, yet non-differentiable because the tangent slope from the left ($-1$) disagrees with the tangent slope from the right ($+1$).`,
      analogy: `Imagine driving a high-speed car on a highway. **Continuity** simply means there are no physical gaps, potholes, or cliffs in the asphalt—you can drive from left to right without falling off. **Differentiability**, however, requires that the road curves *smoothly*. If the road has a sudden sharp V-bend (a corner), your steering wheel would have to instantaneously snap from $-45^\\circ$ to $+45^\\circ$ in zero seconds (infinite rotational acceleration). Because steering wheels cannot snap instantaneously, a sharp corner is continuous (the road exists) but non-differentiable (no smooth directional tangent)!`,
      questionFirst: `If a function is continuous at a point $x = a$, why can't we immediately conclude that its derivative $f'(a)$ exists? What exact geometric feature causes $f(x) = |x|$ to fail differentiability at the origin?`,
      svgDiagram: generateTopicSvgDiagram(clean, 'math'),
      governingEquationName: `Axiom of Differentiability & LHD/RHD Equivalence Criterion`,
      governingEquationLatex: `f'(a) = \\lim_{x \\to a} \\frac{f(x) - f(a)}{x - a} \\iff \\text{LHD} = \\lim_{h \\to 0^+} \\frac{f(a - h) - f(a)}{-h} = \\lim_{h \\to 0^+} \\frac{f(a + h) - f(a)}{h} = \\text{RHD} = L \\in \\mathbb{R}`,
      tenStepProtocol: [
        { 
          step: 1, 
          phase: 'Definition of First-Principles Derivative', 
          explanation: 'The instantaneous rate of change of f(x) at x = a is defined as the limit of the difference quotient secant slope as x approaches a.', 
          formulaOrValue: `f'(a) = \\lim_{x \\to a} \\frac{f(x) - f(a)}{x - a}`, 
          trapAndTip: 'Always check if the point x = a lies in the interior domain of the function!' 
        },
        { 
          step: 2, 
          phase: 'Right-Hand Derivative (RHD) Formula', 
          explanation: 'Let x = a + h where h > 0 approaches 0. RHD evaluates the limiting slope of secants connecting (a, f(a)) to points immediately to the right.', 
          formulaOrValue: `\\text{RHD} = f'(a^+) = \\lim_{h \\to 0^+} \\frac{f(a+h) - f(a)}{h}`, 
          trapAndTip: 'In the denominator, h is strictly positive (+h).' 
        },
        { 
          step: 3, 
          phase: 'Left-Hand Derivative (LHD) Formula', 
          explanation: 'Let x = a - h where h > 0 approaches 0. LHD evaluates the limiting slope of secants connecting (a, f(a)) to points immediately to the left.', 
          formulaOrValue: `\\text{LHD} = f'(a^-) = \\lim_{h \\to 0^+} \\frac{f(a-h) - f(a)}{-h} = \\lim_{t \\to 0^-} \\frac{f(a+t) - f(a)}{t}`, 
          trapAndTip: 'TRAP: Forgetting the negative sign in the denominator (-h) when substituting x = a - h!' 
        },
        { 
          step: 4, 
          phase: 'Differentiability Existence Condition', 
          explanation: 'For f(x) to be differentiable at x = a, three conditions must hold: (1) LHD exists finitely, (2) RHD exists finitely, and (3) LHD = RHD.', 
          formulaOrValue: `\\text{LHD} = \\text{RHD} = L \\in (-\\infty, \\infty)`, 
          trapAndTip: 'If LHD or RHD equals +∞ or -∞, the function has a vertical tangent and is NOT differentiable.' 
        },
        { 
          step: 5, 
          phase: 'Theorem: Differentiability Implies Continuity', 
          explanation: 'Proof: f(x) - f(a) = [ (f(x) - f(a))/(x - a) ] · (x - a). Taking lim as x→a gives lim [f(x) - f(a)] = f\'(a) · 0 = 0, so lim f(x) = f(a).', 
          formulaOrValue: `\\lim_{x \\to a} [f(x) - f(a)] = \\lim_{x \\to a} \\left( \\frac{f(x)-f(a)}{x-a} \\right) \\cdot \\lim_{x \\to a} (x-a) = f'(a) \\cdot 0 = 0`, 
          trapAndTip: 'Crucial: Converse is FALSE! Continuity does NOT guarantee differentiability.' 
        },
        { 
          step: 6, 
          phase: 'The Canonical Counterexample: Absolute Value f(x) = |x| at x = 0', 
          explanation: 'f(0) = 0. LHD = lim_{h→0+} (|0-h|-0)/(-h) = h/(-h) = -1. RHD = lim_{h→0+} (|0+h|-0)/h = h/h = +1. Since -1 ≠ +1, f(x) is not differentiable at x = 0.', 
          formulaOrValue: `\\text{LHD} = -1 \\neq +1 = \\text{RHD} \\implies f'(0) \\text{ does not exist}`, 
          trapAndTip: 'Graphically, any "corner" (sharp change in slope) or "cusp" lacks differentiability.' 
        },
        { 
          step: 7, 
          phase: 'Smooth Stitching for Piecewise Functions', 
          explanation: 'For piecewise functions with split at x = c, ensure both (1) continuity: f(c^-) = f(c^+) = f(c) AND (2) smooth transition: LHD(c) = RHD(c).', 
          formulaOrValue: `f_1(c) = f_2(c) \\quad \\text{AND} \\quad f_1'(c) = f_2'(c)`, 
          trapAndTip: 'TRAP: Do not differentiate the branches first before verifying continuity! Discontinuous branches can produce equal formula derivatives but remain non-differentiable.' 
        },
        { 
          step: 8, 
          phase: 'Worked Numerical Verification', 
          explanation: 'Test differentiability of f(x) = x · |x| at x = 0: LHD = lim_{h→0+} (-h · |-h| - 0)/(-h) = |-h| = 0. RHD = lim_{h→0+} (h · |h| - 0)/h = |h| = 0. LHD = RHD = 0!', 
          formulaOrValue: `f(x) = x|x| \\implies \\text{LHD} = 0 = \\text{RHD} \\implies f'(0) = 0`, 
          trapAndTip: 'Multiplying |x| by x smooths out the corner at the origin into a quadratic tangent!' 
        },
        { 
          step: 9, 
          phase: 'Examiner Traps & Common Misconceptions', 
          explanation: 'Never assume that if a function has a formula derivative f\'(x), that f\'(a) equals lim_{x→a} f\'(x) without checking continuity of the derivative.', 
          formulaOrValue: `f'(a) = \\text{First-Principles Definition, NOT just } \\lim_{x \\to a} f'(x)`, 
          trapAndTip: 'For oscillating functions like x² sin(1/x) at x=0, always revert to the first-principles limit!' 
        },
        { 
          step: 10, 
          phase: '10-Second Recall Mnemonic & Golden Rule', 
          explanation: '"Smooth road means unique tangent; Left slope matches Right slope; No gaps, no corners, no cliffs!"', 
          formulaOrValue: `\\text{Diff} \\implies \\text{Cont} \\quad [\\text{D} \\subset \\text{C}], \\quad \\text{LHD} = \\text{RHD} = f'(a)`, 
          trapAndTip: 'Remember: Differentiability is a strictly stronger condition than Continuity.' 
        }
      ],
      technique11Questions: [
        {
          level: 1, levelName: 'Direct Substitution & Formula Familiarity', difficulty: 'Easy',
          question: 'Using the first-principles definition of Left-Hand Derivative (LHD) and Right-Hand Derivative (RHD), show that f(x) = x² is differentiable at x = 2 and find f\'(2).',
          formulaApplication: 'LHD = lim_{h→0+} [f(2-h)-f(2)] / (-h), RHD = lim_{h→0+} [f(2+h)-f(2)] / h',
          stepByStepSolution: [
            'Evaluate f(2): f(2) = 2² = 4.',
            'Calculate LHD at x = 2: LHD = lim_{h→0+} [ (2-h)² - 4 ] / (-h) = lim_{h→0+} [ 4 - 4h + h² - 4 ] / (-h) = lim_{h→0+} [ -4h + h² ] / (-h) = lim_{h→0+} [ 4 - h ] = 4.',
            'Calculate RHD at x = 2: RHD = lim_{h→0+} [ (2+h)² - 4 ] / h = lim_{h→0+} [ 4 + 4h + h² - 4 ] / h = lim_{h→0+} [ 4h + h² ] / h = lim_{h→0+} [ 4 + h ] = 4.',
            'Since LHD = 4 = RHD, both limits exist, are finite and equal.',
            'Therefore, f(x) = x² is differentiable at x = 2 and f\'(2) = 4.'
          ],
          answer: 'f\'(2) = 4 (LHD = RHD = 4)'
        },
        {
          level: 2, levelName: 'Variable Rearrangement & Unknown Parameter Isolation', difficulty: 'Medium',
          question: 'Find the values of constants a and b such that the function f(x) is differentiable at x = 1, where f(x) = x² + 3x + a for x ≤ 1, and f(x) = bx + 2 for x > 1.',
          formulaApplication: 'Step 1: Continuity at x = 1 (LHL = RHL = f(1)). Step 2: Differentiability at x = 1 (LHD = RHD).',
          stepByStepSolution: [
            'Condition 1 (Continuity at x = 1): LHL = f(1) = 1² + 3(1) + a = 4 + a. RHL = lim_{x→1+} (bx + 2) = b + 2. For continuity: 4 + a = b + 2 ⟹ b - a = 2 (Equation 1).',
            'Condition 2 (Differentiability at x = 1): LHD = d/dx(x² + 3x + a)|_{x=1} = (2x + 3)|_{x=1} = 2(1) + 3 = 5.',
            'RHD = d/dx(bx + 2)|_{x=1} = b.',
            'For differentiability, LHD = RHD ⟹ b = 5.',
            'Substitute b = 5 into Equation 1: 5 - a = 2 ⟹ a = 3.',
            'Verification: Continuity gives 4 + 3 = 7, 5(1) + 2 = 7. Differentiability gives LHD = 5 = RHD = 5.'
          ],
          answer: 'a = 3, b = 5'
        },
        {
          level: 3, levelName: 'Multi-Step Rigor & Oscillating Metric Traps', difficulty: 'Hard',
          question: 'Examine the continuity and differentiability of f(x) = x · sin(1/x) for x ≠ 0 and f(0) = 0 at x = 0.',
          formulaApplication: 'Continuity: Squeeze Theorem on |x sin(1/x)| ≤ |x|. Differentiability: First-principles difference quotient.',
          stepByStepSolution: [
            'Part A: Testing Continuity at x = 0: lim_{x→0} f(x) = lim_{x→0} [x · sin(1/x)]. Since -1 ≤ sin(1/x) ≤ 1 for all x ≠ 0, we have -|x| ≤ x · sin(1/x) ≤ |x|.',
            'As x → 0, -|x| → 0 and |x| → 0. By the Squeeze (Sandwich) Theorem, lim_{x→0} f(x) = 0 = f(0). Hence, f(x) is CONTINUOUS at x = 0.',
            'Part B: Testing Differentiability at x = 0: RHD = lim_{h→0+} [f(0+h) - f(0)] / h = lim_{h→0+} [h · sin(1/h) - 0] / h = lim_{h→0+} sin(1/h).',
            'As h → 0+, 1/h → ∞, so sin(1/h) oscillates infinitely between -1 and +1 without settling on any single finite limit value.',
            'Therefore, the limit does not exist, meaning RHD does not exist (and similarly LHD does not exist).',
            'Conclusion: f(x) is continuous at x = 0, but NOT differentiable at x = 0.'
          ],
          answer: 'Continuous at x = 0, but NOT Differentiable at x = 0'
        },
        {
          level: 4, levelName: 'Piecewise Modulus & Multi-Corner Differentiation', difficulty: 'Advanced',
          question: 'Determine all points of non-differentiability for the function f(x) = |x - 1| + |x - 2| on the real line ℝ, and write the piecewise formula.',
          formulaApplication: 'Deconstruct absolute values at critical partition points x = 1 and x = 2; evaluate LHD and RHD at partition points.',
          stepByStepSolution: [
            'Split ℝ into three intervals: (i) x < 1: f(x) = -(x - 1) - (x - 2) = -2x + 3.',
            '(ii) 1 ≤ x < 2: f(x) = (x - 1) - (x - 2) = 1.',
            '(iii) x ≥ 2: f(x) = (x - 1) + (x - 2) = 2x - 3.',
            'Check x = 1: LHD = d/dx(-2x + 3) = -2. RHD = d/dx(1) = 0. Since LHD = -2 ≠ 0 = RHD, f is NOT differentiable at x = 1.',
            'Check x = 2: LHD = d/dx(1) = 0. RHD = d/dx(2x - 3) = 2. Since LHD = 0 ≠ 2 = RHD, f is NOT differentiable at x = 2.',
            'Everywhere else (x ∈ ℝ \\ {1, 2}), f(x) is a linear polynomial with continuous derivatives.'
          ],
          answer: 'Non-differentiable at x = 1 and x = 2 (Continuous everywhere on ℝ)'
        },
        {
          level: 5, levelName: 'Competitive Entrance & Greatest Integer Product', difficulty: 'Mastery',
          question: '(JEE Advanced / Board Mastery) Discuss the differentiability of f(x) = [x] · sin(πx) at integer points x = n ∈ ℤ, where [x] denotes the greatest integer function.',
          formulaApplication: 'Evaluate LHD and RHD at x = n using left/right behavior of [x] near n.',
          stepByStepSolution: [
            'Let n be any integer. At x = n, f(n) = [n] · sin(nπ) = n · 0 = 0.',
            'Left-Hand Derivative at x = n: For x ∈ (n - 1, n), [x] = n - 1. LHD = lim_{h→0+} [f(n - h) - f(n)] / (-h) = lim_{h→0+} [ (n - 1) · sin(π(n - h)) - 0 ] / (-h).',
            'sin(nπ - πh) = sin(nπ)cos(πh) - cos(nπ)sin(πh) = 0 - (-1)ⁿ sin(πh) = (-1)ⁿ⁺¹ sin(πh).',
            'LHD = lim_{h→0+} [ (n - 1) · (-1)ⁿ⁺¹ sin(πh) ] / (-h) = (n - 1) · (-1)ⁿ · lim_{h→0+} [sin(πh) / h] = (n - 1) · (-1)ⁿ · π.',
            'Right-Hand Derivative at x = n: For x ∈ [n, n + 1), [x] = n. RHD = lim_{h→0+} [f(n + h) - f(n)] / h = lim_{h→0+} [ n · sin(π(n + h)) ] / h = lim_{h→0+} [ n · (-1)ⁿ sin(πh) ] / h = n · (-1)ⁿ · π.',
            'Equating LHD and RHD: (n - 1) · (-1)ⁿ · π = n · (-1)ⁿ · π ⟹ n - 1 = n ⟹ -1 = 0, which is impossible for any integer!',
            'Conclusion: f(x) is NOT differentiable at ANY integer point x = n ∈ ℤ.'
          ],
          answer: 'f(x) is non-differentiable at all integer points x ∈ ℤ'
        }
      ],
      comparativeMatrices: [
        {
          title: 'Comprehensive Comparison: Continuity vs. Differentiability',
          headers: ['Criterion / Attribute', 'Continuity at x = a', 'Differentiability at x = a', 'Relationship & Interdependence'],
          rows: [
            ['Mathematical Definition', 'lim_{x→a} f(x) = f(a) [LHL = RHL = f(a)]', 'lim_{x→a} [f(x)-f(a)]/(x-a) exists [LHD = RHD]', 'Differentiability implies Continuity'],
            ['Geometric Meaning', 'No breaks, jumps, holes, or gaps in curve', 'Smooth curve with a unique, non-vertical tangent', 'Smoothness is strictly stronger than connectivity'],
            ['Behavior at Sharp Corners', 'Preserved (Graph is continuous at sharp vertex)', 'Destroyed (LHD ≠ RHD at sharp corner/cusp)', 'Continuity does NOT imply Differentiability'],
            ['Rate of Change', 'Function value can be evaluated without rate', 'Instantaneous rate of change is well-defined', 'Differentiability gives velocity/gradient'],
            ['Canonical Counterexample', 'f(x) = |x| is continuous at x = 0', 'f(x) = |x| has LHD = -1, RHD = +1 (Not differentiable)', 'Proves the non-reversibility of the implication']
          ]
        }
      ],
      diagnosticDecisionMatrix: {
        title: 'Diagnostic Decision Matrix for Differentiability Testing',
        headers: ['Function Type / Feature', 'Primary Step to Execute', 'Verification Criterion', 'Common Student Pitfall'],
        rows: [
          ['Modulus Functions |g(x)|', 'Find roots g(x) = 0; split into piecewise branches', 'Evaluate LHD = lim (g(a-h))/(-h) and RHD', 'Assuming |x-c| is never differentiable (it is except at x=c)'],
          ['Piecewise Branch Splitting', 'Step 1: Check f(c^-) = f(c^+); Step 2: LHD = RHD', 'Both continuity AND matching slopes required', 'Differentiating branches without checking continuity first'],
          ['Oscillating xⁿ sin(1/x)', 'Use difference quotient limit hⁿ⁻¹ sin(1/h)', 'Differentiable if n > 1; non-differentiable if n ≤ 1', 'Trying to differentiate sin(1/x) directly at x = 0'],
          ['Greatest Integer [x]', 'Evaluate left integer limit (n-1) vs right (n)', 'Usually discontinuous, hence non-differentiable', 'Forgetting that multiplying by root (x-n) can restore continuity']
        ]
      },
      academicQuestions: [
        {
          id: 'diff_acad_1',
          category: 'Very Short Answer (VSA - 1 Mark)',
          question: 'State the necessary and sufficient condition for a real function f(x) to be differentiable at x = c.',
          answer: 'The necessary and sufficient condition is that both the Left-Hand Derivative LHD = lim_{h→0+} [f(c-h)-f(c)]/(-h) and the Right-Hand Derivative RHD = lim_{h→0+} [f(c+h)-f(c)]/h must exist as finite real numbers and be equal: LHD = RHD = f\'(c).',
          marks: 1,
          markingScheme: ['1 Mark: Existence of finite LHD and RHD and strict equality LHD = RHD.']
        },
        {
          id: 'diff_acad_2',
          category: 'Short Answer I (SA-I - 2 Marks)',
          question: 'Show that the function f(x) = |x - 3|, x ∈ ℝ is not differentiable at x = 3.',
          answer: 'f(3) = |3 - 3| = 0. LHD at x=3: lim_{h→0+} [|3-h-3| - 0]/(-h) = lim_{h→0+} |-h|/(-h) = lim_{h→0+} h/(-h) = -1. RHD at x=3: lim_{h→0+} [|3+h-3| - 0]/h = lim_{h→0+} |h|/h = 1. Since LHD = -1 ≠ 1 = RHD, f(x) is not differentiable at x = 3.',
          marks: 2,
          markingScheme: ['1 Mark: Calculation of LHD = -1.', '1 Mark: Calculation of RHD = +1 and conclusion that LHD ≠ RHD.']
        },
        {
          id: 'diff_acad_3',
          category: 'Short Answer II (SA-II - 3 Marks)',
          question: 'Prove that every differentiable function is continuous. Is the converse true? Justify with a counterexample.',
          answer: 'Proof: Let f be differentiable at x = c. Then f\'(c) = lim_{x→c} [f(x)-f(c)]/(x-c) exists finitely. We write f(x) - f(c) = [(f(x)-f(c))/(x-c)] · (x-c) for x ≠ c. Taking limits as x→c: lim_{x→c} [f(x)-f(c)] = lim_{x→c} [(f(x)-f(c))/(x-c)] · lim_{x→c} (x-c) = f\'(c) · 0 = 0. Thus lim_{x→c} f(x) = f(c), proving f is continuous at x = c. The converse is false: f(x) = |x| is continuous at x = 0 since lim_{x→0} |x| = 0 = f(0), but non-differentiable at x = 0 because LHD = -1 ≠ 1 = RHD.',
          marks: 3,
          markingScheme: ['1.5 Marks: Algebraic step lim [f(x)-f(c)] = f\'(c) · 0 = 0.', '1.5 Marks: Counterexample f(x) = |x| at origin showing continuity but non-differentiability.']
        }
      ],
      competitiveQuestions: [
        {
          category: 'Multiple Correct Choice (JEE Advanced)',
          question: 'Let f(x) = { x² sin(1/x) for x ≠ 0; 0 for x = 0 }. Which of the following statements is/are correct?',
          options: ['A) f(x) is continuous at x = 0', 'B) f(x) is differentiable at x = 0 with f\'(0) = 0', 'C) f\'(x) is continuous at x = 0', 'D) f\'(x) is discontinuous at x = 0'],
          correctOption: 'A, B, D',
          solution: '1. Continuity: |x² sin(1/x)| ≤ x² → 0 as x → 0 (Continuous). 2. Differentiability: f\'(0) = lim_{h→0} [h² sin(1/h) - 0]/h = lim_{h→0} h sin(1/h) = 0 (Differentiable, f\'(0)=0). 3. For x ≠ 0, f\'(x) = 2x sin(1/x) - cos(1/x). As x → 0, 2x sin(1/x) → 0 but cos(1/x) oscillates between -1 and +1 without limit. Hence f\'(x) is discontinuous at x = 0!',
          speedTrick: 'xⁿ sin(1/x) at x=0 is: Continuous if n > 0; Differentiable if n > 1; Derivative is continuous if n > 2.',
          negativeMarkingTrap: 'Assuming that because f\'(0) exists, f\'(x) must be continuous at x = 0!'
        }
      ],
      rapidFireQuestions: [
        { qNumber: 1, question: 'What is the LHD of f(x) = |x| at x = 0?', answer: '-1', shortExplanation: 'As h → 0+, (|0-h|-0)/(-h) = h/(-h) = -1.' },
        { qNumber: 2, question: 'What is the RHD of f(x) = |x| at x = 0?', answer: '+1', shortExplanation: 'As h → 0+, (|0+h|-0)/h = h/h = +1.' },
        { qNumber: 3, question: 'Does continuity guarantee differentiability?', answer: 'No', shortExplanation: 'Sharp corners like |x| at x=0 are continuous but non-differentiable.' },
        { qNumber: 4, question: 'Does differentiability guarantee continuity?', answer: 'Yes', shortExplanation: 'Every differentiable function is unconditionally continuous.' },
        { qNumber: 5, question: 'What geometric feature represents non-differentiability on a continuous curve?', answer: 'A sharp corner, cusp, or vertical tangent', shortExplanation: 'A unique tangent line cannot exist at vertices where left and right secants disagree.' }
      ],
      vocabularyMasterclass: [
        { term: 'Left-Hand Derivative (LHD)', etymology: 'Latin derivare (to draw off) from the left limit', definition: 'The limiting slope of secants approaching a point x = a from strictly values x < a.', memoryHook: 'LHD = Slope from the left side.' },
        { term: 'Right-Hand Derivative (RHD)', etymology: 'Limiting slope from the right limit', definition: 'The limiting slope of secants approaching a point x = a from strictly values x > a.', memoryHook: 'RHD = Slope from the right side.' },
        { term: 'Differentiability', etymology: 'Latin differentia (difference)', definition: 'The property of a function having a unique, finite, non-vertical tangent line at a point.', memoryHook: 'Differentiable = Smooth and seamless curve.' }
      ],
      spokenUnits: [
        { symbol: "f'(a)", unitName: 'First derivative of f at a', spokenForm: 'f prime of a', physicalMeaning: 'Instantaneous rate of change or gradient of the tangent line at x = a' },
        { symbol: "f'(a⁻)", unitName: 'Left-hand derivative at a', spokenForm: 'f prime of a minus', physicalMeaning: 'Limiting slope from the left' },
        { symbol: "f'(a⁺)", unitName: 'Right-hand derivative at a', spokenForm: 'f prime of a plus', physicalMeaning: 'Limiting slope from the right' }
      ],
      fiveLayerSummary: {
        layer1UltraRapid: `A function f(x) is differentiable at x = a if and only if LHD = f'(a⁻) = RHD = f'(a⁺) = L ∈ ℝ. Differentiability implies continuity, but continuity does not imply differentiability.`,
        layer2FirstPrinciples: [
          `First-principles definition: f'(a) = lim_{x→a} [f(x)-f(a)]/(x-a).`,
          `LHD = lim_{h→0+} [f(a-h)-f(a)]/(-h) evaluates slope from the left.`,
          `RHD = lim_{h→0+} [f(a+h)-f(a)]/h evaluates slope from the right.`,
          `Theorem: Differentiable ⟹ Continuous (lim_{x→a} f(x) = f(a)).`,
          `Counterexample: f(x) = |x| is continuous at 0 but non-differentiable (LHD = -1 ≠ +1 = RHD).`
        ],
        layer3GoldenEquations: [
          `f'(a) = \\lim_{h \\to 0} \\frac{f(a+h) - f(a)}{h}`,
          `\\text{LHD} = \\lim_{h \\to 0^+} \\frac{f(a-h) - f(a)}{-h}`,
          `\\text{RHD} = \\lim_{h \\to 0^+} \\frac{f(a+h) - f(a)}{h}`,
          `\\text{Differentiability} \\implies \\text{Continuity} \\quad [\\text{Converse is False}]`
        ],
        layer4ExaminerTraps: [
          `Trap 1: Differentiating piecewise branches without verifying continuity at the boundary first.`,
          `Trap 2: Forgetting the -h denominator when computing LHD from first principles.`,
          `Trap 3: Assuming continuity guarantees differentiability (e.g. |x| at x = 0 is continuous but NOT differentiable).`,
          `Trap 4: Confounding vertical tangents (slope = ±∞) with differentiability (infinite derivative means non-differentiable).`
        ],
        layer5VisualMentalSchema: `"Differentiable is Smooth and Connected; Continuous is just Connected without gaps; LHD equals RHD means Tangent is Perfect!"`
      }
    };
  }

  // 1. MATRICES & DETERMINANTS / LINEAR TRANSFORMATIONS & SCALAR MULTIPLICATION
  if (lower.includes('matrix') || lower.includes('matrices') || lower.includes('determinant') || lower.includes('linear transform') || lower.includes('eigen')) {
    return {
      title: clean || 'Matrices and Determinants — Properties, Multiplicative Scaling & Linear Transformations',
      domain: 'math',
      introConcept: `In linear algebra, an $n \\times n$ square **matrix** $A$ represents a linear transformation mapping vectors across coordinate space, and its **determinant** $\\det(A)$ (or $|A|$) measures the signed oriented volume/area expansion factor induced by that transformation. Because the determinant is a multilinear alternating form operating independently on all $n$ rows, multiplying the entire matrix $A$ by a scalar $k$ (which multiplies every individual row by $k$) causes the determinant to scale by $k^n$:
$$\\det(kA) = k^n \\det(A)$$

For a single $1 \\times 1$ scalar matrix $A = [a]$, the determinant is simply $\\det([a]) = a$. For a $2 \\times 2$ matrix, $\\det(kA) = k^2 \\det(A)$ (area scaling); for a $3 \\times 3$ matrix, $\\det(kA) = k^3 \\det(A)$ (volume scaling). Furthermore, the determinant satisfies five fundamental invariant laws:
1. Multiplicative Product Law: $\\det(AB) = \\det(A)\\det(B)$
2. Transpose Invariance: $\\det(A^T) = \\det(A)$
3. Invertibility & Reciprocal Law: $\\det(A^{-1}) = \\frac{1}{\\det(A)} \\iff \\det(A) \\neq 0$
4. Adjoint Invariant Law: $\\det(\\text{adj}(A)) = (\\det(A))^{n-1}$
5. Orthogonal / Unitary Invariant: If $A^T A = I$, then $\\det(A) = \\pm 1$`,
      analogy: `Imagine stretching an elastic rubber sheet marked with a unit square of area $1$. A $2 \\times 2$ matrix transformation distorts this unit square into a parallelogram whose area is exactly $|\\det(A)|$. If you double the scale of every coordinate ($k = 2$ in 2D), both width and height double, so the transformed area quadruples ($2^2 = 4$ times, $\\det(2A) = 2^2 \\det(A)$). If you are in 3D space with a unit cube of volume $1$, scaling all three dimensions by $k = 2$ expands the volume by $2^3 = 8$ times (length $\\times 2$, width $\\times 2$, height $\\times 2$). In general $n$-dimensional space, scaling all $n$ basis vectors by $k$ scales the hypervolume by exactly $k^n$!`,
      questionFirst: `If $A$ is a square matrix of order $3 \\times 3$ with $\\det(A) = 5$, why is $\\det(2A)$ equal to $40$ rather than $10$? How does the row-wise multilinearity of determinants geometrically explain the exponent $n$ in $k^n$?`,
      svgDiagram: generateTopicSvgDiagram(clean, 'math'),
      governingEquationName: `Scalar Multiplicative Law of Determinants & Dimension Scaling Criterion`,
      governingEquationLatex: `\\det(k A) = k^n \\det(A), \\quad \\text{where } A \\in M_{n \\times n}(\\mathbb{R}), \\; k \\in \\mathbb{R}, \\; n \\in \\mathbb{N}`,
      tenStepProtocol: [
        { 
          step: 1, 
          phase: 'Definition of Matrix Determinant', 
          explanation: 'The determinant is a scalar-valued function assigning to each square matrix A the signed hypervolume of the parallelotope spanned by its column vectors.', 
          formulaOrValue: `\\det: M_{n \\times n}(\\mathbb{R}) \\to \\mathbb{R}`, 
          trapAndTip: 'Determinants are strictly defined ONLY for square matrices (n × n).' 
        },
        { 
          step: 2, 
          phase: 'Row-Wise Multilinearity Property', 
          explanation: 'If any single row of matrix A is multiplied by scalar k, the determinant of the resulting matrix is multiplied by k: det(R₁, ..., k·Rᵢ, ..., Rₙ) = k · det(A).', 
          formulaOrValue: `\\det(R_1, \\dots, k R_i, \\dots, R_n) = k \\cdot \\det(R_1, \\dots, R_i, \\dots, R_n)`, 
          trapAndTip: 'Matrix multiplication kA multiplies ALL n rows by k simultaneously!' 
        },
        { 
          step: 3, 
          phase: 'Derivation of Scalar Scaling Law det(kA) = kⁿ det(A)', 
          explanation: 'Factor out scalar k from each of the n rows consecutively: det(kA) = det(k·R₁, k·R₂, ..., k·Rₙ) = k · k · ... · k · det(R₁, ..., Rₙ) = kⁿ det(A).', 
          formulaOrValue: `\\det(k A) = k^n \\det(A)`, 
          trapAndTip: 'TRAP: Writing det(kA) = k·det(A). The exponent n is the matrix ORDER!' 
        },
        { 
          step: 4, 
          phase: 'Order 1, Order 2, and Order 3 Specific Cases', 
          explanation: 'For n=1: det(kA) = k·det(A). For n=2: det(kA) = k²·det(A). For n=3: det(kA) = k³·det(A).', 
          formulaOrValue: `n=1: \\det(kA)=k|A|, \\quad n=2: \\det(kA)=k^2|A|, \\quad n=3: \\det(kA)=k^3|A|`, 
          trapAndTip: 'In board exams, double check the matrix dimension before applying the exponent.' 
        },
        { 
          step: 5, 
          phase: 'Product Theorem for Determinants', 
          explanation: 'The determinant of a matrix product AB equals the product of their individual determinants: det(AB) = det(A) · det(B).', 
          formulaOrValue: `\\det(AB) = \\det(A) \\cdot \\det(B)`, 
          trapAndTip: 'Matrix multiplication is non-commutative (AB ≠ BA), but det(AB) = det(BA) always!' 
        },
        { 
          step: 6, 
          phase: 'Transpose Invariance Law', 
          explanation: 'Interchanging all rows and columns leaves the determinant value unchanged: det(Aᵀ) = det(A).', 
          formulaOrValue: `\\det(A^T) = \\det(A)`, 
          trapAndTip: 'Any operation valid for rows of a determinant is equally valid for columns.' 
        },
        { 
          step: 7, 
          phase: 'Inverse Matrix Determinant Law', 
          explanation: 'Since A · A⁻¹ = I and det(I) = 1, det(A · A⁻¹) = det(A)·det(A⁻¹) = 1 ⟹ det(A⁻¹) = 1 / det(A).', 
          formulaOrValue: `\\det(A^{-1}) = \\frac{1}{\\det(A)} = (\\det(A))^{-1} \\quad [\\det(A) \\neq 0]`, 
          trapAndTip: 'A matrix is invertible (non-singular) if and only if det(A) ≠ 0.' 
        },
        { 
          step: 8, 
          phase: 'Adjoint Matrix Determinant Law', 
          explanation: 'Since A · adj(A) = det(A) · I, taking determinants: det(A · adj(A)) = det(det(A) · I) ⟹ det(A) · det(adj(A)) = (det(A))ⁿ ⟹ det(adj(A)) = (det(A))ⁿ⁻¹.', 
          formulaOrValue: `\\det(\\text{adj}(A)) = (\\det(A))^{n-1}`, 
          trapAndTip: 'For order n=3: det(adj(A)) = (det(A))².' 
        },
        { 
          step: 9, 
          phase: 'Skew-Symmetric Matrix Determinant Theorem', 
          explanation: 'If A is skew-symmetric (Aᵀ = -A) of odd order n: det(A) = det(Aᵀ) = det(-A) = (-1)ⁿ det(A) = -det(A) ⟹ 2 det(A) = 0 ⟹ det(A) = 0.', 
          formulaOrValue: `A^T = -A, \\; n \\text{ is odd} \\implies \\det(A) = 0`, 
          trapAndTip: 'Determinant of every odd-order skew-symmetric matrix is identically ZERO!' 
        },
        { 
          step: 10, 
          phase: 'Triangular & Diagonal Matrix Determinant Rule', 
          explanation: 'The determinant of an upper triangular, lower triangular, or diagonal matrix equals the simple product of its main diagonal entries.', 
          formulaOrValue: `\\det(A) = a_{11} \\cdot a_{22} \\cdot \\dots \\cdot a_{nn} = \\prod_{i=1}^n a_{ii}`, 
          trapAndTip: 'Use row operations (Gaussian elimination) to reduce matrices to triangular form for ultra-fast calculation.' 
        }
      ],
      technique11Questions: [
        {
          level: 1, levelName: 'Direct Substitution & Formula Familiarity', difficulty: 'Easy',
          question: 'If A is a square matrix of order 3 × 3 and det(A) = 5, evaluate the determinant of 2A, i.e., det(2A).',
          formulaApplication: '\\det(kA) = k^n \\det(A) \\text{ with } k = 2, n = 3, \\det(A) = 5',
          stepByStepSolution: [
            'Identify the parameters: Matrix order n = 3, scalar k = 2, determinant det(A) = 5.',
            'Apply the scaling theorem: det(kA) = kⁿ · det(A).',
            'Substitute values: det(2A) = 2³ · det(A) = 8 · 5 = 40.'
          ],
          answer: 'det(2A) = 40'
        },
        {
          level: 2, levelName: 'Variable Rearrangement & Unknown Isolation', difficulty: 'Medium',
          question: 'For a square matrix A of order n × n, it is given that det(3A) = 81 · det(A). Determine the order n of matrix A.',
          formulaApplication: '\\det(3A) = 3^n \\det(A) = 81 \\det(A) \\implies 3^n = 81',
          stepByStepSolution: [
            'Using the scalar scaling formula: det(3A) = 3ⁿ · det(A).',
            'Equate to the given relation: 3ⁿ · det(A) = 81 · det(A).',
            'Since det(A) ≠ 0, divide both sides: 3ⁿ = 81.',
            'Express 81 as a power of 3: 81 = 3⁴ ⟹ n = 4.'
          ],
          answer: 'n = 4 (Order is 4 × 4)'
        },
        {
          level: 3, levelName: 'Multi-Step Metric Traps & Composite Invariants', difficulty: 'Hard',
          question: 'Let A and B be two square matrices of order 3 × 3 such that det(A) = 4 and det(B) = -2. Evaluate the exact value of det(3 A⁻¹ Bᵀ).',
          formulaApplication: '\\det(k M) = k^n \\det(M), \\; \\det(MN) = \\det(M)\\det(N), \\; \\det(A^{-1}) = \\frac{1}{\\det(A)}, \\; \\det(B^T) = \\det(B)',
          stepByStepSolution: [
            'Extract the scalar constant 3 from the 3 × 3 matrix: det(3 A⁻¹ Bᵀ) = 3³ · det(A⁻¹ Bᵀ) = 27 · det(A⁻¹ Bᵀ).',
            'Apply the product rule: det(A⁻¹ Bᵀ) = det(A⁻¹) · det(Bᵀ).',
            'Substitute inverse and transpose laws: det(A⁻¹) = 1 / det(A) = 1/4, and det(Bᵀ) = det(B) = -2.',
            'Compute the combined determinant: det(A⁻¹ Bᵀ) = (1/4) · (-2) = -1/2.',
            'Multiply by the scalar factor: 27 · (-1/2) = -27/2 = -13.5.'
          ],
          answer: 'det(3 A⁻¹ Bᵀ) = -27/2 = -13.5'
        },
        {
          level: 4, levelName: 'Geometric Transformation & Area Distortion', difficulty: 'Advanced',
          question: 'A linear transformation T: ℝ² → ℝ² represented by matrix A = [[3, 1], [2, 4]] maps the unit disk x² + y² ≤ 1 (area = π) onto an ellipse. Find the exact area of the resulting ellipse.',
          formulaApplication: '\\text{Area}_{\\text{image}} = |\\det(A)| \\cdot \\text{Area}_{\\text{original}}',
          stepByStepSolution: [
            'Calculate the determinant of matrix A: det(A) = (3)(4) - (1)(2) = 12 - 2 = 10.',
            'Since det(A) = 10 > 0, the transformation expands 2D areas by an exact factor of 10.',
            'Area of the original unit disk is A_orig = π · (1)² = π.',
            'Area of the transformed ellipse = |det(A)| · A_orig = 10 · π = 10π.'
          ],
          answer: 'Area = 10π square units'
        },
        {
          level: 5, levelName: 'Competitive Entrance & Adjoint-Scalar Power Challenge', difficulty: 'Mastery',
          question: '(JEE Advanced / CBSE Board Mastery) If A is a non-singular square matrix of order 3 such that det(adj(2A)) = 2ᵃ · (det(A))ᵇ, determine the exact integer values of a and b.',
          formulaApplication: '\\text{For order } n, \\; \\det(\\text{adj}(M)) = (\\det(M))^{n-1} \\text{ and } \\det(kM) = k^n \\det(M)',
          stepByStepSolution: [
            'Let M = 2A. The matrix M has order n = 3.',
            'Using the adjoint determinant theorem: det(adj(M)) = (det(M))ⁿ⁻¹ = (det(2A))³⁻¹ = (det(2A))².',
            'Now compute det(2A): Since A is order 3, det(2A) = 2³ · det(A) = 8 · det(A).',
            'Substitute into the squared expression: det(adj(2A)) = (8 · det(A))² = 8² · (det(A))² = 64 · (det(A))².',
            'Express 64 as a power of 2: 64 = 2⁶.',
            'Therefore, det(adj(2A)) = 2⁶ · (det(A))².',
            'Comparing with 2ᵃ · (det(A))ᵇ gives: a = 6, b = 2.'
          ],
          answer: 'a = 6, b = 2  [det(adj(2A)) = 2⁶ · (det(A))² = 64 (det(A))²]'
        }
      ],
      comparativeMatrices: [
        {
          title: 'Matrix Properties vs. Determinant Properties',
          headers: ['Operation / Property', 'Matrix Behavior (A)', 'Determinant Behavior (det(A))', 'Key Distinguishing Feature'],
          rows: [
            ['Scalar Multiplication (k)', 'Multiplies EVERY element: [k aᵢⱼ]', 'Multiplies value by kⁿ: det(kA) = kⁿ det(A)', 'Matrix is an array; Determinant is a scalar'],
            ['Matrix Addition (A + B)', 'Element-wise: [aᵢⱼ + bᵢⱼ]', 'det(A + B) ≠ det(A) + det(B) in general', 'Determinant is NOT linear over addition'],
            ['Matrix Product (AB)', 'Row-by-column product AB', 'det(AB) = det(A) · det(B) strictly', 'Multiplicative property always holds'],
            ['Matrix Inverse (A⁻¹)', 'A⁻¹ = (1/det(A)) · adj(A)', 'det(A⁻¹) = 1 / det(A)', 'Exists if and only if det(A) ≠ 0']
          ]
        }
      ],
      diagnosticDecisionMatrix: {
        title: 'Diagnostic Decision Matrix: Scaling & Operations across Dimensions',
        headers: ['Target Quantity', 'Order n = 1', 'Order n = 2', 'Order n = 3', 'General Order n'],
        rows: [
          ['det(k A)', 'k · det(A)', 'k² · det(A)', 'k³ · det(A)', 'kⁿ · det(A)'],
          ['det(adj(A))', '1', 'det(A)', '(det(A))²', '(det(A))ⁿ⁻¹'],
          ['det(A⁻¹)', '1 / det(A)', '1 / det(A)', '1 / det(A)', '1 / det(A)'],
          ['det(adj(adj(A)))', '1', 'det(A)', '(det(A))⁴', '(det(A))^{(n-1)²}']
        ]
      },
      academicQuestions: [
        {
          id: 'vsa_1',
          category: 'Very Short Answer (VSA)',
          question: 'If A is a 3 × 3 matrix and |A| = -3, find the value of |-2A|.',
          answer: 'Using |kA| = kⁿ |A| where n = 3, k = -2:\n|-2A| = (-2)³ · |A| = (-8) · (-3) = 24.',
          marks: 1,
          markingScheme: ['Formula identification |kA| = kⁿ|A| (0.5 mark)', 'Correct substitution & final answer 24 (0.5 mark)']
        },
        {
          id: 'sa_1',
          category: 'Short Answer Type I (SA-I)',
          question: 'Prove that for any square matrix A of order n, det(adj(A)) = (det(A))ⁿ⁻¹.',
          answer: 'We know that A · adj(A) = |A| · Iₙ.\nTaking determinants on both sides:\n|A · adj(A)| = ||A| · Iₙ|\nUsing the product property |AB| = |A||B| on LHS:\n|A| · |adj(A)| = |A|ⁿ · |Iₙ| = |A|ⁿ · 1 = |A|ⁿ.\nDividing both sides by |A| (assuming |A| ≠ 0):\n|adj(A)| = |A|ⁿ⁻¹.\nBy continuity, this holds for all square matrices.',
          marks: 2,
          markingScheme: ['Stating A · adj(A) = |A|Iₙ and taking determinants (1 mark)', 'Applying scaling to identity and dividing by |A| (1 mark)']
        },
        {
          id: 'sa_2',
          category: 'Short Answer Type II (SA-II)',
          question: 'If A is a 3 × 3 non-singular matrix such that A · Aᵀ = I and det(A) > 0, find the value of det(adj(3A)).',
          answer: 'Given A · Aᵀ = I ⟹ det(A · Aᵀ) = det(I) ⟹ det(A) · det(Aᵀ) = 1 ⟹ (det(A))² = 1.\nSince det(A) > 0, det(A) = 1.\nNow, let M = 3A. Then det(M) = det(3A) = 3³ · det(A) = 27 · 1 = 27.\nFor order n = 3, det(adj(M)) = (det(M))³⁻¹ = (det(M))² = 27² = 729.',
          marks: 3,
          markingScheme: ['Finding det(A) = 1 from orthogonality (1 mark)', 'Evaluating det(3A) = 27 (1 mark)', 'Computing det(adj(3A)) = 27² = 729 (1 mark)']
        }
      ],
      competitiveQuestions: [
        {
          category: 'Single Correct (JEE Advanced / NEET)',
          question: 'Let A be an n × n matrix with det(A) = 4. If det(2 adj(3A)) = 2⁸ · 3¹² for n = 3, what is the value of det(A⁻¹)?',
          options: ['A) 1/4', 'B) 1/2', 'C) 4', 'D) 1/16'],
          correctOption: 'A) 1/4',
          solution: 'Since det(A) = 4, det(A⁻¹) = 1 / det(A) = 1/4 directly.',
          speedTrick: 'det(A⁻¹) only depends on det(A); ignore the distractor expression!',
          negativeMarkingTrap: 'Do not spend 5 minutes calculating adj(3A) when asked for det(A⁻¹).'
        }
      ],
      rapidFireQuestions: [
        { qNumber: 1, question: 'What is det(Iₙ)?', answer: '1', shortExplanation: 'Identity matrix determinant is always 1.' },
        { qNumber: 2, question: 'If two rows of a determinant are identical, what is its value?', answer: '0', shortExplanation: 'Alternating multilinear form vanishes on linearly dependent rows.' },
        { qNumber: 3, question: 'What is det(kA) for a 4 × 4 matrix?', answer: 'k⁴ det(A)', shortExplanation: 'Power equals dimension n = 4.' }
      ],
      vocabularyMasterclass: [
        { term: 'Determinant', etymology: 'Latin determinare ("to enclose, bound, determine")', definition: 'A scalar value that determines whether a system of linear equations has a unique solution.', memoryHook: 'Determinant DETERMINES invertibility!' },
        { term: 'Adjoint', etymology: 'Latin adjungere ("to join to")', definition: 'The transpose of the cofactor matrix.', memoryHook: 'Adjoint is the Transposed Cofactor matrix.' }
      ],
      spokenUnits: [
        { symbol: 'det(A)', unitName: 'Determinant', spokenForm: 'determinant of A', physicalMeaning: 'Hypervolume scaling factor' },
        { symbol: 'kⁿ', unitName: 'Dimension Power', spokenForm: 'k to the power n', physicalMeaning: 'Scaling exponent across n axes' }
      ],
      fiveLayerSummary: {
        layer1UltraRapid: 'For an n × n matrix, scaling all elements by k scales the determinant by kⁿ: det(kA) = kⁿ det(A).',
        layer2FirstPrinciples: [
          'The determinant is linear in each row individually (multilinear).',
          'Multiplying matrix by k multiplies all n rows by k simultaneously.',
          'Factoring k from each of the n rows yields k · k · ... · k = kⁿ.'
        ],
        layer3GoldenEquations: [
          '\\det(kA) = k^n \\det(A)',
          '\\det(AB) = \\det(A) \\cdot \\det(B)',
          '\\det(A^{-1}) = \\frac{1}{\\det(A)}',
          '\\det(\\text{adj}(A)) = (\\det(A))^{n-1}'
        ],
        layer4ExaminerTraps: [
          'Trap 1: Writing det(kA) = k det(A) without raising k to matrix order n.',
          'Trap 2: Assuming det(A + B) = det(A) + det(B) (False!).',
          'Trap 3: Forgetting that det(adj(A)) has exponent (n - 1), so for n=3 it is squared.'
        ],
        layer5VisualMentalSchema: '"Determinant is Area or Volume: scaling every axis by k scales n-dimensional space by kⁿ!"'
      }
    };
  }

  // 2. PHOTOELECTRIC EFFECT & DUAL NATURE
  if (lower.includes('photoelectric') || lower.includes('dual nature') || lower.includes('einstein') && lower.includes('photo')) {
    return {
      title: clean,
      domain: 'physics',
      introConcept: `The Photoelectric Effect proves that light behaves as discrete quantized packets of energy called **photons**, rather than continuous waves. When light of sufficient frequency strikes a metal surface, electrons are ejected instantaneously ($t < 10^{-9}\\text{ s}$). Classical wave theory completely failed because it predicted a time lag for energy accumulation and thought electron kinetic energy depended on intensity. In reality, **intensity controls current (number of electrons)**, while **frequency controls electron kinetic energy**!`,
      analogy: `Imagine a vending machine with a strict rule: it costs at least $2.00 to release a soda. If you insert pennies, no matter how many millions of pennies you dump at once (high intensity, low frequency), the machine will not trigger. But the instant you drop in a two-dollar token (high frequency photon), a soda pops out immediately! The coin value is photon energy $h\\nu$, the required cost is the work function $\\Phi_0$, and any change left over is the kinetic energy of the ejected electron!`,
      questionFirst: `Why does even intense red laser light fail to release a single electron from zinc, while a faint flicker of ultraviolet light knocks them out immediately?`,
      svgDiagram: generateTopicSvgDiagram(clean, 'physics'),
      governingEquationName: `Einstein's Photoelectric Equation`,
      governingEquationLatex: `h\\nu = \\Phi_0 + K_{\\max} = h\\nu_0 + \\frac{1}{2}m v_{\\max}^2 = e V_0`,
      tenStepProtocol: [
        { step: 1, phase: 'Core Law Statement', explanation: 'One photon of energy hν transfers its entire energy to one electron in a metal. Part overcomes binding (work function Φ₀), the remainder is maximum kinetic energy.', formulaOrValue: 'h\\nu = \\Phi_0 + K_{\\max}', trapAndTip: 'One-to-one interaction! Higher intensity only means MORE photons, not more energetic photons.' },
        { step: 2, phase: 'SI Units & Constants', explanation: 'Planck constant h = 6.626 × 10⁻³⁴ J·s (or 4.136 × 10⁻¹⁵ eV·s). Frequency in Hertz (Hz). 1 eV = 1.6 × 10⁻¹⁹ J.', formulaOrValue: 'h = 6.626 \\times 10^{-34}\\text{ J}\\cdot\\text{s}', trapAndTip: 'TRAP: Forgetting to convert eV to Joules when computing electron velocity in m/s!' },
        { step: 3, phase: 'Threshold Frequency', explanation: 'The minimum frequency required to liberate an electron with zero kinetic energy is threshold frequency ν₀ = Φ₀/h.', formulaOrValue: '\\nu_0 = \\frac{\\Phi_0}{h} \\iff \\lambda_0 = \\frac{hc}{\\Phi_0}', trapAndTip: 'If incident frequency ν < ν₀, photoelectric emission is IMPOSSIBLE regardless of intensity.' },
        { step: 4, phase: 'Stopping Potential Form', explanation: 'The negative potential applied to the anode that reduces photoelectric current to exactly zero.', formulaOrValue: 'e V_0 = K_{\\max} = h\\nu - \\Phi_0 \\implies V_0 = \\left(\\frac{h}{e}\\right)\\nu - \\frac{\\Phi_0}{e}', trapAndTip: 'Graph of V₀ vs ν is a straight line! Slope = h/e (universal constant), y-intercept = -Φ₀/e.' },
        { step: 5, phase: 'de Broglie Wavelength', explanation: 'Matter particles with momentum p have an associated wave character λ = h/p = h/√(2mE).', formulaOrValue: '\\lambda = \\frac{h}{\\sqrt{2m e V}} = \\frac{1.227}{\\sqrt{V}}\\text{ nm}', trapAndTip: 'For electrons accelerated through potential V, use the quick shortcut λ = 1.227 / √V nm.' },
        { step: 6, phase: 'Dimensional Analysis', explanation: 'Planck constant has dimensions of action or angular momentum: [M¹ L² T⁻¹].', formulaOrValue: '[h] = [M^1 L^2 T^{-1}]', trapAndTip: 'Check dimensions of hν: [M¹ L² T⁻¹] × [T⁻¹] = [M¹ L² T⁻²] (Energy/Joules).' },
        { step: 7, phase: 'Intensity vs Frequency', explanation: 'Doubling intensity doubles photoelectric current; stopping potential and K_max remain completely unchanged!', formulaOrValue: 'I \\propto \\text{Current}, \\quad \\nu \\propto V_0', trapAndTip: 'Board favorite: "What happens to stopping potential if intensity is tripled?" Answer: Absolutely nothing!' },
        { step: 8, phase: 'Worked Numerical', explanation: 'A metal has work function Φ₀ = 2.0 eV. Light of wavelength λ = 400 nm falls on it. Find stopping potential V₀.', formulaOrValue: 'E = 1240 / 400 = 3.1\\text{ eV} \\implies V_0 = 3.1 - 2.0 = 1.1\\text{ V}', trapAndTip: 'Numerical shortcut: E(eV) ≈ 1240 / λ(nm) for rapid competitive calculations!' },
        { step: 9, phase: 'Examiner Traps & Pitfalls', explanation: 'Confounding photoelectron maximum speed with average speed. Electrons undergo collisions, so speeds range from 0 to v_max.', formulaOrValue: '0 \\le v \\le v_{\\max}', trapAndTip: 'Only electrons on the outermost surface emerge with K_max!' },
        { step: 10, phase: '10-Second Recall Mnemonic', explanation: '"Photon pays the work fee first, keeps the change for kinetic burst!"', formulaOrValue: 'h\\nu = \\Phi_0 + K_{\\max}', trapAndTip: 'Immediate mental anchor for exam problem solving.' }
      ],
      technique11Questions: [
        {
          level: 1, levelName: 'Direct Substitution & Formula Familiarity', difficulty: 'Easy',
          question: 'The work function of cesium is 2.14 eV. Find the threshold frequency (ν₀) for cesium. (Take h = 6.63 × 10⁻³⁴ J·s, 1 eV = 1.6 × 10⁻¹⁹ J).',
          formulaApplication: 'Φ₀ = h ν₀ ⟹ ν₀ = Φ₀ / h',
          stepByStepSolution: [
            'Convert Φ₀ to Joules: Φ₀ = 2.14 × 1.6 × 10⁻¹⁹ J = 3.424 × 10⁻¹⁹ J.',
            'Calculate ν₀ = (3.424 × 10⁻¹⁹ J) / (6.63 × 10⁻³⁴ J·s).',
            'ν₀ ≈ 5.16 × 10¹⁴ Hz.'
          ],
          answer: 'ν₀ = 5.16 × 10¹⁴ Hz'
        },
        {
          level: 2, levelName: 'Variable Rearrangement & Unknown Isolation', difficulty: 'Medium',
          question: 'When radiation of wavelength 300 nm falls on a metal, the stopping potential is 1.85 V. What is the work function of the metal in eV?',
          formulaApplication: 'hν = Φ₀ + e V₀ ⟹ Φ₀ = (hc/λ) - e V₀',
          stepByStepSolution: [
            'Energy of incident photon: E = 1240 / 300 nm = 4.133 eV.',
            'Maximum kinetic energy: K_max = e V₀ = 1.85 eV.',
            'Work function: Φ₀ = E - K_max = 4.133 eV - 1.85 eV = 2.28 eV.'
          ],
          answer: 'Φ₀ = 2.28 eV'
        },
        {
          level: 3, levelName: 'Multi-Step Unit Conversions & Metric Traps', difficulty: 'Hard',
          question: 'Light of frequency 1.5 × 10¹⁵ Hz is incident on a metal with work function 2.5 eV. Calculate the maximum velocity of emitted photoelectrons. (m_e = 9.1 × 10⁻³¹ kg).',
          formulaApplication: 'K_max = hν - Φ₀ = (1/2) m v_max² ⟹ v_max = √(2 K_max / m)',
          stepByStepSolution: [
            'Photon energy hν = (6.63 × 10⁻³⁴) × (1.5 × 10¹⁵) = 9.945 × 10⁻¹⁹ J.',
            'Convert Φ₀ to Joules: 2.5 × 1.6 × 10⁻¹⁹ = 4.0 × 10⁻¹⁹ J.',
            'K_max = 9.945 × 10⁻¹⁹ - 4.0 × 10⁻¹⁹ = 5.945 × 10⁻¹⁹ J.',
            'v_max = √[2 × (5.945 × 10⁻¹⁹) / (9.1 × 10⁻³¹)] = √[1.3066 × 10¹²] ≈ 1.14 × 10⁶ m/s.'
          ],
          answer: 'v_max = 1.14 × 10⁶ m/s'
        },
        {
          level: 4, levelName: 'Physical Constraints & Ratio Shifts', difficulty: 'Advanced',
          question: 'When a photosensitive surface is illuminated with frequency ν, stopping potential is V₁. When illuminated with frequency 2ν, stopping potential is V₂. Prove that V₂ > 2V₁.',
          formulaApplication: 'e V₁ = hν - Φ₀ and e V₂ = 2hν - Φ₀',
          stepByStepSolution: [
            'Express e V₂: e V₂ = 2(hν - Φ₀) + Φ₀ = 2(e V₁) + Φ₀.',
            'Divide by e: V₂ = 2V₁ + (Φ₀ / e).',
            'Since work function Φ₀ > 0, the additive term (Φ₀/e) is strictly positive.',
            'Therefore, V₂ > 2V₁ (stopping potential more than doubles when frequency doubles!).'
          ],
          answer: 'Proven: V₂ = 2V₁ + (Φ₀/e) > 2V₁'
        },
        {
          level: 5, levelName: 'Competitive Entrance & de Broglie Coupling', difficulty: 'Mastery',
          question: '(JEE Advanced) A monochromatic light source illuminates a metallic sphere of radius r placed on an insulating stand. If the work function is Φ₀ and incident frequency is ν > ν₀, find the maximum charge Q acquired by the sphere before photoelectric emission stops.',
          formulaApplication: 'As electrons leave, sphere charges positively until surface potential V_s = Stopping potential V₀',
          stepByStepSolution: [
            'Stopping potential needed to halt emission: V₀ = (hν - Φ₀) / e.',
            'Electric potential on sphere of radius r with charge Q: V_s = Q / (4πε₀ r).',
            'Equating potentials: Q / (4πε₀ r) = (hν - Φ₀) / e.',
            'Solving for maximum charge: Q_max = 4πε₀ r (hν - Φ₀) / e.'
          ],
          answer: 'Q_max = 4πε₀ r (hν - Φ₀) / e'
        }
      ],
      comparativeMatrices: [
        {
          title: 'Classical Wave Theory vs. Einstein\'s Quantum Photon Theory',
          headers: ['Parameter / Observation', 'Classical Wave Prediction', 'Einstein\'s Photon Explanation', 'Experimental Truth'],
          rows: [
            ['Kinetic Energy of Electrons', 'Proportional to Light Intensity', 'Independent of Intensity; depends on Frequency', 'Photon Theory Confirmed'],
            ['Threshold Frequency (ν₀)', 'No threshold exists; any light will work given time', 'Strict threshold ν₀ = Φ₀/h required', 'No emission below ν₀'],
            ['Time Lag for Emission', 'Noticeable delay (hours) to gather wave energy', 'Instantaneous (< 10⁻⁹ seconds)', 'Instantaneous ejection observed'],
            ['Light Intensity Effect', 'Increases electron kinetic energy', 'Increases number of emitted electrons (current)', 'Current ∝ Intensity']
          ]
        }
      ],
      diagnosticDecisionMatrix: {
        title: 'Diagnostic Decision Matrix for Photoelectric Problem Solving',
        headers: ['Given Input Data', 'Unknown to Find', 'Direct Formula Path', 'Critical Units / Trap'],
        rows: [
          ['λ (nm), Φ₀ (eV)', 'Stopping Potential V₀ (V)', 'V₀ = (1240/λ) - Φ₀', 'Ensure λ in nm and Φ₀ in eV'],
          ['ν (Hz), V₀ (V)', 'Work function Φ₀ (J or eV)', 'Φ₀ = hν - e V₀', 'Convert e V₀ to Joules (×1.6×10⁻¹⁹)'],
          ['Accelerating Potential V', 'de Broglie Wavelength λ', 'λ = 1.227 / √V nm', 'Applies strictly for non-relativistic electron']
        ]
      },
      academicQuestions: [
        { id: 'pe_acad_1', category: 'Very Short Answer (1–2 Marks)', question: 'Define work function of a metal.', answer: 'Work function (Φ₀) is the minimum energy required to eject an electron from the surface of a metal with zero kinetic energy.', marks: 1, markingScheme: ['1 Mark: Accurate definition highlighting minimum energy and metal surface.'] },
        { id: 'pe_acad_2', category: 'Very Short Answer (1–2 Marks)', question: 'State the effect of increasing incident light frequency on stopping potential.', answer: 'Stopping potential increases linearly with the frequency of incident radiation (V₀ = (h/e)ν - Φ₀/e).', marks: 1, markingScheme: ['1 Mark: Stating linear increase.'] },
        { id: 'pe_acad_3', category: 'Short Answer (3–4 Marks)', question: 'Explain three experimental features of photoelectric effect that classical wave theory could not explain.', answer: '1. Existence of threshold frequency below which no emission occurs. 2. Independence of maximum kinetic energy from light intensity. 3. Instantaneous emission with no time lag.', marks: 3, markingScheme: ['1 Mark each for correctly stating and explaining the 3 failures.'] }
      ],
      competitiveQuestions: [
        { category: 'Multiple Correct Choice (JEE Adv)', question: 'In a photoelectric experiment, if the intensity of incident monochromatic radiation is doubled, which of the following is/are correct?', options: ['A) Saturation current is doubled', 'B) Stopping potential is doubled', 'C) Maximum kinetic energy remains unchanged', 'D) Work function is doubled'], correctOption: 'A, C', solution: 'Intensity is proportional to photon count per second, hence saturation current doubles. Kinetic energy and stopping potential depend solely on frequency, and work function is a material constant.', speedTrick: 'Remember: Intensity = Quantity, Frequency = Quality (Energy).', negativeMarkingTrap: 'Students often incorrectly think stopping potential doubles with intensity.' }
      ],
      rapidFireQuestions: [
        { qNumber: 1, question: 'What is the rest mass of a photon?', answer: 'Zero.', shortExplanation: 'Photons travel at speed of light c and have zero rest mass.' },
        { qNumber: 2, question: 'What is the slope of the graph between stopping potential and frequency?', answer: 'h/e.', shortExplanation: 'From V₀ = (h/e)ν - Φ₀/e, the slope is Planck constant divided by electron charge.' },
        { qNumber: 3, question: 'Does photoelectric current depend on frequency above threshold?', answer: 'No, it depends on intensity.', shortExplanation: 'Frequency determines energy per photon, not number of photons.' }
      ],
      vocabularyMasterclass: [
        { term: 'Photon', etymology: 'Greek "phos" (light) + suffix "-on" (elementary particle).', definition: 'The quantum of electromagnetic radiation carrying energy E = hν.', memoryHook: 'Light bullet carrying an exact energy packet.' },
        { term: 'Work Function', etymology: 'German "Austrittsarbeit" (escape work) coined by Einstein.', definition: 'Minimum energy barrier an electron must overcome to escape metallic lattice.', memoryHook: 'Toll fee to exit the metal highway.' }
      ],
      spokenUnits: [
        { symbol: 'h', unitName: 'Joule-second (J·s)', spokenForm: 'Joules times seconds', physicalMeaning: 'Quantum of action' },
        { symbol: 'V₀', unitName: 'Volt (V)', spokenForm: 'Volts stopping potential', physicalMeaning: 'Potential that halts fastest photoelectrons' }
      ],
      fiveLayerSummary: {
        layer1UltraRapid: 'Photoelectric effect proves light consists of photons (E = hν). Electrons eject instantly if ν ≥ ν₀. Intensity increases current; frequency increases kinetic energy.',
        layer2FirstPrinciples: [
          'Photons carry discrete energy packets: E = hν.',
          'One-to-one photon-electron interaction on metal surface.',
          'Energy split: Photon energy = Work function barrier + Kinetic energy.',
          'Stopping potential halts fastest photoelectrons: e V₀ = K_max.',
          'Wave nature of matter: λ = h/p = 1.227 / √V nm for electrons.'
        ],
        layer3GoldenEquations: [
          'hν = Φ₀ + K_max',
          'K_max = e V₀ = (1/2) m v_max²',
          'ν₀ = Φ₀ / h ⟺ λ₀ = hc / Φ₀',
          'V₀ = (h/e)ν - Φ₀/e',
          'λ_deBroglie = h / p = 1.227 / √V nm'
        ],
        layer4ExaminerTraps: [
          'Mixing eV and Joules: Always multiply eV by 1.6 × 10⁻¹⁹ when finding velocity!',
          'Confusing intensity and frequency: Intensity changes current, NOT stopping potential!',
          'Assuming all electrons have K_max: Speeds range from 0 to v_max due to lattice collisions.'
        ],
        layer5VisualMentalSchema: 'Photon (hν) ──► Strikes Metal Plate ──► Pays Φ₀ Fee ──► Ejected Electron (K_max = e V₀)'
      }
    };
  }

  // 2. PHOTOSYNTHESIS & ENERGETICS
  if (lower.includes('photo') && (lower.includes('synthesis') || lower.includes('bio') || lower.includes('plant') || lower.includes('chlorophyll'))) {
    return {
      title: clean,
      domain: 'biology',
      introConcept: `Photosynthesis is the fundamental biochemical process on Earth that converts electromagnetic radiation into stable chemical energy stored in glucose ($C_6H_{12}O_6$), while releasing oxygen ($O_2$) as a vital byproduct. It occurs in two coupled stages within the chloroplast: the **Light-Dependent Reactions** (photolysis of water and ATP/NADPH synthesis on thylakoid membranes) and the **Light-Independent Calvin Cycle** (carbon fixation via RuBisCO in the stroma).`,
      analogy: `Think of a green leaf as a high-tech solar bakery. The solar panels on the roof are chlorophyll molecules in the thylakoids. They capture sunlight to charge portable batteries (ATP and NADPH) and split tap water, releasing oxygen exhaust. Then in the kitchen workspace (stroma), chef RuBisCO uses carbon dioxide from the air and the charged batteries to bake loaves of sugar (glucose)!`,
      questionFirst: `Where does the oxygen we breathe actually come from during photosynthesis — does it come from carbon dioxide ($CO_2$) or from water ($H_2O$)?`,
      svgDiagram: generateTopicSvgDiagram(clean, 'biology'),
      governingEquationName: `Overall Balanced Photosynthetic Stoichiometry`,
      governingEquationLatex: `6\\text{CO}_2 + 6\\text{H}_2\\text{O} + h\\nu \\xrightarrow{\\text{chlorophyll}} \\text{C}_6\\text{H}_{12}\\text{O}_6 + 6\\text{O}_2 \\qquad (\\Delta G^\\circ = +2870\\text{ kJ/mol})`,
      tenStepProtocol: [
        { step: 1, phase: 'Core Stoichiometric Equation', explanation: 'Six molecules of carbon dioxide react with six molecules of water in the presence of sunlight and chlorophyll to produce one molecule of glucose and six molecules of oxygen.', formulaOrValue: '6\\text{CO}_2 + 6\\text{H}_2\\text{O} \\to \\text{C}_6\\text{H}_{12}\\text{O}_6 + 6\\text{O}_2', trapAndTip: 'Oxygen comes exclusively from WATER (photolysis in PS II), NOT from CO₂!' },
        { step: 2, phase: 'Photolysis of Water', explanation: 'Light energy splits water at the Oxygen-Evolving Complex of PS II, releasing protons, electrons, and molecular oxygen.', formulaOrValue: '2\\text{H}_2\\text{O} \\to 4\\text{H}^+ + 4e^- + \\text{O}_2', trapAndTip: 'Manganese (Mn²⁺) and Chloride (Cl⁻) ions are essential cofactors for photolysis.' },
        { step: 3, phase: 'Z-Scheme Electron Transport', explanation: 'Electrons flow from PS II (P680) through plastoquinone, cytochrome b6f, and plastocyanin to PS I (P700), generating a proton gradient.', formulaOrValue: '\\text{PS II (680 nm)} \\to \\text{Cyt } b_6f \\to \\text{PS I (700 nm)}', trapAndTip: 'Non-cyclic photophosphorylation produces BOTH ATP and NADPH; cyclic produces ONLY ATP.' },
        { step: 4, phase: 'Chemiosmotic ATP Synthesis', explanation: 'Protons accumulate in the thylakoid lumen; their flow back to stroma through ATP synthase powers ADP phosphorylation.', formulaOrValue: '\\text{ADP} + \\text{P}_i + \\text{H}^+_{\\text{lumen}} \\to \\text{ATP} + \\text{H}^+_{\\text{stroma}}', trapAndTip: 'Lumen has acidic pH (~4-5), stroma is alkaline (~8).' },
        { step: 5, phase: 'Calvin Cycle Carbon Fixation', explanation: 'Enzyme RuBisCO catalyzes carboxylation of Ribulose-1,5-bisphosphate (RuBP) to produce 3-PGA.', formulaOrValue: '\\text{RuBP (5C)} + \\text{CO}_2 \\xrightarrow{\\text{RuBisCO}} 2 \\times \\text{3-PGA (3C)}', trapAndTip: 'RuBisCO is the most abundant enzyme on Earth, but has oxygenase affinity leading to photorespiration in C3 plants.' },
        { step: 6, phase: 'ATP & NADPH Energy Cost', explanation: 'Fixing one single molecule of CO₂ requires 3 ATP and 2 NADPH. To make one full glucose (6 carbons), exactly 18 ATP and 12 NADPH are consumed.', formulaOrValue: '1\\text{ Glucose} = 18\\text{ ATP} + 12\\text{ NADPH}', trapAndTip: 'Golden competitive exam number: 18 ATP and 12 NADPH per glucose!' },
        { step: 7, phase: 'C4 & CAM Plant Adaptations', explanation: 'C4 plants spatial separation (mesophyll and bundle sheath) prevents photorespiration; CAM plants temporal separation (stomata open at night).', formulaOrValue: '\\text{PEP Carboxylase fixes CO}_2 \\to \\text{Oxaloacetate (4C)}', trapAndTip: 'Kranz anatomy is characteristic of C4 plants (e.g., maize, sugarcane).' },
        { step: 8, phase: 'Blackman\'s Law of Limiting Factors', explanation: 'When a chemical process is conditioned by several factors, its rate is limited by the pace of the slowest factor.', formulaOrValue: '\\text{Rate} = f(\\text{Light}, \\text{CO}_2, \\text{Temperature}, \\text{Water})', trapAndTip: 'At low light, light is limiting; at saturated light, CO₂ concentration is usually limiting.' },
        { step: 9, phase: 'Examiner Traps & Pitfalls', explanation: 'Dark reactions do NOT require darkness — they are simply light-independent and occur during the day using daytime ATP/NADPH!', formulaOrValue: '\\text{Light-independent} \\neq \\text{Night only}', trapAndTip: 'Calling Calvin cycle "dark reactions" fools many students into thinking it occurs at night.' },
        { step: 10, phase: '10-Second Recall Mnemonic', explanation: '"SWC in, GO out; Water splits and oxygen shouts!"', formulaOrValue: '6\\text{CO}_2 + 6\\text{H}_2\\text{O} \\to \\text{C}_6\\text{H}_{12}\\text{O}_6 + 6\\text{O}_2', trapAndTip: 'Fast anchor for inputs (Sun, Water, CO₂) and outputs (Glucose, Oxygen).' }
      ],
      technique11Questions: [
        {
          level: 1, levelName: 'Direct Substitution & Formula Familiarity', difficulty: 'Easy',
          question: 'How many molecules of ATP and NADPH are required to synthesize two molecules of glucose in the Calvin cycle?',
          formulaApplication: '1 Glucose = 18 ATP + 12 NADPH ⟹ 2 Glucose = 2 × (18 ATP + 12 NADPH)',
          stepByStepSolution: [
            'For 1 glucose molecule (6 CO₂ fixed): 18 ATP and 12 NADPH are required.',
            'For 2 glucose molecules: 2 × 18 = 36 ATP.',
            'For 2 glucose molecules: 2 × 12 = 24 NADPH.'
          ],
          answer: '36 ATP and 24 NADPH'
        },
        {
          level: 2, levelName: 'Substrate & Product Stoichiometry', difficulty: 'Medium',
          question: 'In photosynthesis, how many turns of the Calvin cycle and how many molecules of water must undergo photolysis to produce one mole of sucrose (C₁₂H₂₂O₁₁)?',
          formulaApplication: 'Sucrose = 12 Carbons (equivalent to 2 hexose units). Each O₂ requires 2 H₂O photolysis.',
          stepByStepSolution: [
            'Each turn of Calvin cycle fixes 1 CO₂. A 12-carbon sucrose requires 12 turns of Calvin cycle.',
            'Formation of 2 hexoses yields 12 O₂ molecules.',
            'Since 2 H₂O produce 1 O₂, 12 O₂ requires photolysis of 24 H₂O molecules.'
          ],
          answer: '12 turns of Calvin cycle and photolysis of 24 H₂O molecules'
        },
        {
          level: 3, levelName: 'Energetics & Quantum Requirement', difficulty: 'Hard',
          question: 'If the quantum requirement of photosynthesis is 8 photons per molecule of O₂ evolved, how many photons are required to synthesize one molecule of glucose?',
          formulaApplication: '1 Glucose synthesis evolves 6 O₂ molecules. Total photons = 6 × Quantum Requirement.',
          stepByStepSolution: [
            '1 molecule of glucose evolution yields 6 O₂ molecules.',
            'Quantum requirement = 8 photons per O₂ evolved.',
            'Total photons needed = 6 × 8 = 48 photons.'
          ],
          answer: '48 photons (Quantum yield = 1/8 = 12.5%)'
        },
        {
          level: 4, levelName: 'Comparative Pathway Efficiency', difficulty: 'Advanced',
          question: 'Calculate the net ATP cost per glucose molecule in a C4 plant compared to a C3 plant, and explain the biological reason for the difference.',
          formulaApplication: 'C3 cost = 18 ATP; C4 cost = 30 ATP (extra 2 ATP per CO₂ for PEP regeneration).',
          stepByStepSolution: [
            'In C3 plants: 3 ATP per CO₂ × 6 CO₂ = 18 ATP.',
            'In C4 plants: 2 additional ATP per CO₂ are consumed to regenerate phosphoenolpyruvate (PEP) from pyruvate.',
            'Total ATP in C4 = (3 + 2) × 6 = 30 ATP.',
            'Difference = 30 - 18 = 12 extra ATP consumed to suppress photorespiration.'
          ],
          answer: 'C4 consumes 30 ATP vs 18 ATP in C3 (12 additional ATP)'
        },
        {
          level: 5, levelName: 'Limiting Factor Integration & Kinetics', difficulty: 'Mastery',
          question: '(NEET / AIIMS Challenge) Explain why the light saturation point of C3 plants is ~10% of full sunlight, whereas C4 plants rarely saturate under natural light intensities.',
          formulaApplication: 'RuBisCO CO₂ limitation in C3 vs PEP Carboxylase high CO₂ affinity and concentration mechanism in C4.',
          stepByStepSolution: [
            'In C3 plants, at ~10% full sunlight, light is no longer limiting; atmospheric CO₂ (0.04%) becomes the strictly limiting substrate for RuBisCO.',
            'In C4 plants, PEP carboxylase has exceptionally high affinity for bicarbonate and concentrates CO₂ around RuBisCO in bundle sheath cells.',
            'Therefore, C4 plants avoid RuBisCO substrate saturation and can utilize much higher light intensities.'
          ],
          answer: 'CO₂ concentration mechanism via Kranz anatomy eliminates RuBisCO saturation'
        }
      ],
      comparativeMatrices: [
        {
          title: 'Light-Dependent Reactions vs. Calvin Cycle (Light-Independent)',
          headers: ['Feature', 'Light-Dependent Reactions', 'Calvin Cycle (Light-Independent)'],
          rows: [
            ['Location', 'Thylakoid membranes (Grana)', 'Stroma of Chloroplast'],
            ['Inputs', 'Light energy, H₂O, NADP⁺, ADP + P_i', 'CO₂, ATP, NADPH'],
            ['Outputs', 'ATP, NADPH, O₂ (gas)', 'Glucose (G3P), ADP, NADP⁺'],
            ['Key Enzymes', 'Oxygen-Evolving Complex, ATP Synthase', 'RuBisCO, Triose Phosphate Isomerase'],
            ['Dependence on Light', 'Directly dependent on photons', 'Indirectly dependent (requires ATP/NADPH)']
          ]
        },
        {
          title: 'Photosystem I (PS I) vs. Photosystem II (PS II)',
          headers: ['Characteristic', 'Photosystem I (PS I)', 'Photosystem II (PS II)'],
          rows: [
            ['Reaction Center', 'P700 (absorbs 700 nm)', 'P680 (absorbs 680 nm)'],
            ['Location', 'Outer surface of non-appressed thylakoids', 'Appressed thylakoid membranes (grana)'],
            ['Photolysis of Water', 'Absent', 'Present (Water-splitting complex)'],
            ['Primary Function', 'NADPH synthesis & cyclic ATP', 'ATP synthesis & water splitting'],
            ['Electron Source', 'Plastocyanin from PS II', 'Water (H₂O)']
          ]
        }
      ],
      diagnosticDecisionMatrix: {
        title: 'Diagnostic Decision Matrix for Photosynthetic Pathway Identification',
        headers: ['Observed Anatomical / Biochemical Feature', 'Pathway Type', 'Key Diagnostic Marker'],
        rows: [
          ['Kranz Anatomy, Dimorphic Chloroplasts', 'C4 Pathway (Hatch-Slack)', 'Bundle sheath cells with thick walls, no intercellular spaces'],
          ['Stomata open at night, Malic acid stored in vacuole', 'CAM Pathway', 'Temporal separation of CO₂ fixation in desert succulents'],
          ['Single cell type, photorespiration at high temp', 'C3 Pathway (Calvin Cycle)', 'High RuBisCO oxygenase activity at 30°C+']
        ]
      },
      academicQuestions: [
        { id: 'ps_acad_1', category: 'Very Short Answer (1–2 Marks)', question: 'Name the reaction center chlorophyll in Photosystem II.', answer: 'P680 (chlorophyll a with maximum absorption at 680 nm).', marks: 1, markingScheme: ['1 Mark: P680.'] },
        { id: 'ps_acad_2', category: 'Very Short Answer (1–2 Marks)', question: 'Where does the oxygen released during photosynthesis originate?', answer: 'From water (H₂O) via photolysis at the Oxygen-Evolving Complex of Photosystem II.', marks: 1, markingScheme: ['1 Mark: Explicitly mentioning water.'] },
        { id: 'ps_acad_3', category: 'Short Answer (3–4 Marks)', question: 'Differentiate between cyclic and non-cyclic photophosphorylation.', answer: '1. Cyclic involves only PS I; non-cyclic involves both PS I and PS II. 2. Cyclic produces only ATP; non-cyclic produces both ATP and NADPH. 3. Cyclic has no photolysis of water or oxygen evolution; non-cyclic splits water and releases O₂.', marks: 3, markingScheme: ['1 Mark each for the 3 distinct points of difference.'] }
      ],
      competitiveQuestions: [
        { category: 'Assertion-Reason (NEET/AIIMS)', question: 'Assertion (A): C4 plants are more efficient photosynthesizers at elevated temperatures than C3 plants.\nReason (R): In C4 plants, RuBisCO operates under elevated CO₂ concentration in bundle sheath cells, preventing photorespiration.', options: ['A) Both A and R are true, and R is the correct explanation of A', 'B) Both A and R are true, but R is NOT the correct explanation of A', 'C) A is true, R is false', 'D) A is false, R is true'], correctOption: 'A', solution: 'The high local CO₂ generated in bundle sheath cells saturates RuBisCO active sites with CO₂, preventing its binding to O₂ and completely suppressing wasteful photorespiration.', speedTrick: 'Whenever C4 efficiency is compared at high temperature, photorespiration suppression is the root cause.', negativeMarkingTrap: 'Students sometimes confuse PEP carboxylase location with RuBisCO location.' }
      ],
      rapidFireQuestions: [
        { qNumber: 1, question: 'What metal ion is present at the center of the chlorophyll porphyrin ring?', answer: 'Magnesium (Mg²⁺).', shortExplanation: 'Coordinates four pyrrole nitrogens.' },
        { qNumber: 2, question: 'What is the first stable product of CO₂ fixation in C3 plants?', answer: '3-Phosphoglyceric acid (3-PGA).', shortExplanation: 'A 3-carbon organic acid.' },
        { qNumber: 3, question: 'What is the primary acceptor of CO₂ in C4 plants?', answer: 'Phosphoenolpyruvate (PEP).', shortExplanation: 'A 3-carbon compound in mesophyll cells.' }
      ],
      vocabularyMasterclass: [
        { term: 'Chlorophyll', etymology: 'Greek "chloros" (green) + "phyllon" (leaf).', definition: 'The primary photosynthetic pigment absorbing blue and red light.', memoryHook: 'Green pigment that captures light energy in leaves.' },
        { term: 'Photolysis', etymology: 'Greek "photo" (light) + "lysis" (splitting).', definition: 'Light-dependent breakdown of water into protons, electrons, and oxygen.', memoryHook: 'Light splitting water.' }
      ],
      spokenUnits: [
        { symbol: 'nm', unitName: 'Nanometer (10⁻⁹ m)', spokenForm: 'nanometers', physicalMeaning: 'Wavelength of light' },
        { symbol: 'ATP', unitName: 'Adenosine Triphosphate', spokenForm: 'A T P', physicalMeaning: 'Cellular energy currency' }
      ],
      fiveLayerSummary: {
        layer1UltraRapid: 'Photosynthesis converts sunlight, water, and CO₂ into glucose and oxygen. Light reactions in thylakoids make ATP/NADPH via water splitting; Calvin cycle in stroma fixes CO₂ into sugar.',
        layer2FirstPrinciples: [
          'Photons excite electrons in PS II (P680) and PS I (P700).',
          'Photolysis of water ($2H_2O \\to 4H^+ + 4e^- + O_2$) provides electrons and releases breathable oxygen.',
          'Proton gradient across thylakoid membrane drives ATP synthesis.',
          'RuBisCO fixes CO₂ into 3-PGA in the stroma using 3 ATP and 2 NADPH per CO₂.',
          'C4 plants bypass photorespiration via Kranz anatomy and spatial separation.'
        ],
        layer3GoldenEquations: [
          '6CO₂ + 6H₂O + hν → C₆H₁₂O₆ + 6O₂',
          '2H₂O → 4H⁺ + 4e⁻ + O₂ (PS II)',
          '1 Glucose = 18 ATP + 12 NADPH (C3)',
          '1 Glucose = 30 ATP + 12 NADPH (C4)'
        ],
        layer4ExaminerTraps: [
          'Oxygen comes from H₂O, NEVER from CO₂!',
          'Calvin cycle does NOT need darkness; it runs during the daytime using light-reaction products.',
          'RuBisCO fixes both CO₂ (photosynthesis) and O₂ (photorespiration).'
        ],
        layer5VisualMentalSchema: 'Light + H₂O ──► Thylakoid Grana ──► [ATP + NADPH] + O₂ ──► Stroma Calvin Cycle + CO₂ ──► Glucose'
      }
    };
  }

  // 3. ELECTRIC CHARGES AND FIELDS / CURRENT ELECTRICITY
  if (lower.includes('electric') || lower.includes('coulomb') || lower.includes('charge') || lower.includes('ohm') || lower.includes('current')) {
    const isCurrent = lower.includes('current') || lower.includes('ohm') || lower.includes('resistance');
    return {
      title: clean,
      domain: 'physics',
      introConcept: isCurrent
        ? `Electric Current is the organized net rate of flow of electric charge through a cross-sectional area ($I = dq/dt$). Inside conductors, free electrons drift with a slow average drift velocity ($v_d \\sim 10^{-4}\\text{ m/s}$) under an applied electric field, colliding with lattice ions. Ohm's Law states that current is directly proportional to potential difference across a conductor at constant temperature ($V = IR$).`
        : `Electrostatics deals with stationary electric charges and their interactions. Fundamental charges are quantized in integer multiples of elementary charge ($q = \\pm ne$, where $e = 1.6 \\times 10^{-19}\\text{ C}$). Coulomb's Law governs the electrostatic force between two point charges, operating along the line connecting them via an inverse-square relationship. Gauss's Law links total electric flux through a closed Gaussian surface to the enclosed net charge.`,
      analogy: isCurrent
        ? `Think of an electric circuit as a closed water pipe system. The battery is a water pump creating water pressure (Voltage $V$). The rate of water flowing past a point is current ($I$). Narrow pipes or rough obstacles represent resistance ($R$). Ohm's Law simply says: more pump pressure pushes more water flow, while narrower pipes restrict flow!`
        : `Imagine charges as gravitational masses with a superpower: while masses only attract, charges can both attract (opposites) and violently repel (likes)! Two 1-Coulomb charges separated by 1 meter would push each other with 9 billion Newtons of force — equivalent to the weight of nearly one million cars!`,
      questionFirst: isCurrent
        ? `If drift velocity of electrons is only a fraction of a millimeter per second, why does a light bulb turn on the instant you flip a switch 10 meters away?`
        : `Why do two parallel charged plates produce a completely uniform, constant electric field everywhere between them, regardless of distance?`,
      svgDiagram: generateTopicSvgDiagram(clean, 'physics'),
      governingEquationName: isCurrent ? `Ohm's Law & Microscopic Current Relation` : `Coulomb's Law & Electric Field Formulation`,
      governingEquationLatex: isCurrent
        ? `V = IR \\qquad \\iff \\qquad I = n e A v_d \\qquad \\iff \\qquad \\vec{J} = \\sigma \\vec{E}`
        : `F = \\frac{1}{4\\pi\\varepsilon_0}\\frac{|q_1 q_2|}{r^2} \\qquad \\iff \\qquad \\vec{E} = \\frac{\\vec{F}}{q_0} = \\frac{1}{4\\pi\\varepsilon_0}\\frac{q}{r^2}\\hat{r}`,
      tenStepProtocol: isCurrent
        ? [
            { step: 1, phase: 'Macroscopic Ohm\'s Law', explanation: 'At constant temperature, current through a conductor is directly proportional to the applied potential difference.', formulaOrValue: 'V = IR', trapAndTip: 'Ohm\'s law is NOT a fundamental law of nature — it only applies to ohmic conductors!' },
            { step: 2, phase: 'Microscopic Drift Relation', explanation: 'Current equals electron density times charge times cross-sectional area times drift velocity.', formulaOrValue: 'I = n e A v_d', trapAndTip: 'Drift velocity is very slow (mm/s), but electric signal travels near the speed of light c!' },
            { step: 3, phase: 'Resistance and Resistivity', explanation: 'Resistance is proportional to length and inversely proportional to area: R = ρ l / A.', formulaOrValue: 'R = \\rho \\frac{l}{A} = \\frac{m}{n e^2 \\tau}\\frac{l}{A}', trapAndTip: 'Resistivity ρ depends only on material and temperature, NOT on length or area!' },
            { step: 4, phase: 'Temperature Coefficient', explanation: 'Metals increase resistance with temperature: R_T = R_0(1 + αΔT). Semiconductors have negative α!', formulaOrValue: 'R_T = R_0(1 + \\alpha \\Delta T)', trapAndTip: 'For metals, α > 0; for semiconductors and electrolytes, α < 0.' },
            { step: 5, phase: 'Kirchhoff\'s Rules', explanation: 'Junction Rule (conservation of charge: ΣI = 0) and Loop Rule (conservation of energy: ΣΔV = 0).', formulaOrValue: '\\sum I = 0, \\quad \\sum \\Delta V = 0', trapAndTip: 'Always track signs carefully when traversing EMF sources and resistors.' },
            { step: 6, phase: 'Electrical Power & Heating', explanation: 'Joule heating rate: P = VI = I²R = V²/R.', formulaOrValue: 'P = V I = I^2 R = \\frac{V^2}{R}', trapAndTip: 'Use I²R for series (constant I), and V²/R for parallel (constant V).' },
            { step: 7, phase: 'Stretching a Wire Trap', explanation: 'If a wire is stretched to double its length (l\' = 2l), its volume remains constant, so area halves and resistance quadruples!', formulaOrValue: 'R\' = n^2 R', trapAndTip: 'Classic exam trap: "Length doubled by stretching" gives R\' = 4R, not 2R!' },
            { step: 8, phase: 'Wheatstone Bridge', explanation: 'Bridge is balanced when no current flows through galvanometer: R₁/R₂ = R₃/R₄.', formulaOrValue: '\\frac{R_1}{R_2} = \\frac{R_3}{R_4}', trapAndTip: 'Galvanometer and cell positions can be interchanged without affecting balance.' },
            { step: 9, phase: 'Internal Resistance & EMF', explanation: 'Terminal voltage V = E - Ir during discharge; V = E + Ir during charging.', formulaOrValue: 'V = \\mathcal{E} - I r', trapAndTip: 'Terminal voltage equals EMF only when open circuit (I = 0).' },
            { step: 10, phase: 'Recall Mnemonic', explanation: '"Volts push Current past Resistance"', formulaOrValue: 'V = I R', trapAndTip: 'Foundation of all circuit analysis.' }
          ]
        : [
            { step: 1, phase: 'Coulomb\'s Law Statement', explanation: 'Electrostatic force between two point charges is proportional to product of charges and inversely proportional to square of distance.', formulaOrValue: 'F = \\frac{1}{4\\pi\\varepsilon_0}\\frac{|q_1 q_2|}{r^2}', trapAndTip: 'Applies strictly to POINT charges at rest!' },
            { step: 2, phase: 'Electrostatic Constant', explanation: 'In vacuum, 1/(4πε₀) = 8.98755 × 10⁹ N·m²/C² ≈ 9 × 10⁹ N·m²/C².', formulaOrValue: '\\frac{1}{4\\pi\\varepsilon_0} = 9 \\times 10^9\\text{ N}\\cdot\\text{m}^2/\\text{C}^2', trapAndTip: 'In a dielectric medium of constant K, force reduces by factor K: F_med = F_vac / K.' },
            { step: 3, phase: 'Electric Field Definition', explanation: 'Electric field is force per unit test charge: E = F / q₀.', formulaOrValue: '\\vec{E} = \\frac{\\vec{F}}{q_0} = \\frac{1}{4\\pi\\varepsilon_0}\\frac{q}{r^2}\\hat{r}', trapAndTip: 'Test charge q₀ must be infinitesimal so it does not perturb source charge field.' },
            { step: 4, phase: 'Electric Dipole Moment', explanation: 'Pair of equal and opposite charges ±q separated by distance 2a: p = q(2a) directed from -q to +q.', formulaOrValue: '\\vec{p} = q(2\\vec{a})', trapAndTip: 'Dipole moment points from NEGATIVE to POSITIVE charge!' },
            { step: 5, phase: 'Electric Flux & Gauss\'s Law', explanation: 'Total electric flux through closed surface equals enclosed charge divided by ε₀.', formulaOrValue: '\\Phi_E = \\oint \\vec{E} \\cdot d\\vec{A} = \\frac{q_{\\text{enclosed}}}{\\varepsilon_0}', trapAndTip: 'Gauss\'s law holds for any surface, but is useful for calculation only when symmetry exists.' },
            { step: 6, phase: 'Field Due to Infinite Wire', explanation: 'Radial electric field due to infinitely long line charge with linear charge density λ.', formulaOrValue: 'E = \\frac{\\lambda}{2\\pi\\varepsilon_0 r}', trapAndTip: 'Notice E ∝ 1/r, NOT 1/r²!' },
            { step: 7, phase: 'Field Due to Infinite Sheet', explanation: 'Uniform field on either side of non-conducting sheet with surface density σ: E = σ / (2ε₀).', formulaOrValue: 'E = \\frac{\\sigma}{2\\varepsilon_0}', trapAndTip: 'Field is INDEPENDENT of distance r from the sheet!' },
            { step: 8, phase: 'Conductor in Electrostatic Field', explanation: 'Inside a conductor in electrostatic equilibrium, electric field is identically ZERO: E_inside = 0.', formulaOrValue: '\\vec{E}_{\\text{inside}} = 0', trapAndTip: 'All excess charge resides exclusively on the outer surface.' },
            { step: 9, phase: 'Electric Field Lines Rules', explanation: 'Start at positive charges, end at negative charges, never intersect, never form closed loops.', formulaOrValue: '\\text{No closed loops for static } \\vec{E}', trapAndTip: 'Magnetic field lines form closed loops; electrostatic field lines NEVER form closed loops!' },
            { step: 10, phase: 'Recall Mnemonic', explanation: '"Like charges repel, opposites attract; Coulomb counts the inverse distance pact!"', formulaOrValue: 'F \\propto \\frac{q_1 q_2}{r^2}', trapAndTip: 'Fast mental anchor.' }
          ],
      technique11Questions: [
        {
          level: 1, levelName: 'Direct Substitution & Formula Familiarity', difficulty: 'Easy',
          question: isCurrent
            ? 'A copper wire carries a current of 3.2 A. How many electrons pass through any cross-section of the wire per minute? (e = 1.6 × 10⁻¹⁹ C).'
            : 'Two point charges of +2 μC and +6 μC are placed 30 cm apart in air. Calculate the electrostatic repulsive force between them.',
          formulaApplication: isCurrent ? 'I = q / t = n e / t ⟹ n = I t / e' : 'F = (1/4πε₀) · (q₁ q₂ / r²)',
          stepByStepSolution: isCurrent
            ? [
                'Time t = 1 minute = 60 seconds.',
                'Total charge Q = I × t = 3.2 A × 60 s = 192 C.',
                'Number of electrons n = Q / e = 192 / (1.6 × 10⁻¹⁹) = 1.2 × 10²¹ electrons.'
              ]
            : [
                'q₁ = 2 × 10⁻⁶ C, q₂ = 6 × 10⁻⁶ C, r = 0.30 m.',
                'F = (9 × 10⁹) × [(2 × 10⁻⁶) × (6 × 10⁻⁶)] / (0.30)²',
                'F = (9 × 10⁹) × (12 × 10⁻¹²) / 0.09 = 108 × 10⁻³ / 0.09 = 1.2 N.'
              ],
          answer: isCurrent ? 'n = 1.2 × 10²¹ electrons' : 'F = 1.2 N (repulsive)'
        },
        {
          level: 2, levelName: 'Geometric & Parameter Rearrangement', difficulty: 'Medium',
          question: isCurrent
            ? 'A wire of resistance R is stretched uniformly such that its length increases by 10%. Find the percentage increase in its resistance.'
            : 'At what point on the line joining two charges +q and +4q separated by distance d is the net electric field zero?',
          formulaApplication: isCurrent ? 'Volume V = A l = const ⟹ R ∝ l² ⟹ R\' = R (1 + 0.1)²' : 'E₁ = E₂ ⟹ kq / x² = k(4q) / (d - x)²',
          stepByStepSolution: isCurrent
            ? [
                'Since mass and density are constant, volume A · l = constant.',
                'New length l\' = 1.10 l ⟹ new area A\' = A / 1.10.',
                'New resistance R\' = ρ l\' / A\' = ρ (1.10 l) / (A / 1.10) = (1.10)² R = 1.21 R.',
                'Percentage increase = (1.21 - 1.0) × 100% = 21%.'
              ]
            : [
                'Let neutral point be at distance x from +q. Distance from +4q is (d - x).',
                'kq / x² = k(4q) / (d - x)² ⟹ 1 / x² = 4 / (d - x)²',
                'Take square root: 1 / x = 2 / (d - x) ⟹ d - x = 2x ⟹ 3x = d ⟹ x = d/3.'
              ],
          answer: isCurrent ? 'Resistance increases by 21%' : 'x = d/3 from the smaller charge +q'
        },
        {
          level: 3, levelName: 'Circuit Network / Dielectric Multi-Step', difficulty: 'Hard',
          question: isCurrent
            ? 'Three identical resistors of 6 Ω each are connected in delta (triangle). What is the equivalent resistance between any two vertices?'
            : 'Two small identical conducting spheres carrying charges +10 μC and -2 μC attract with force F. They are touched together and returned to their initial distance. What is the new force in terms of F?',
          formulaApplication: isCurrent ? 'One resistor in parallel with series combination of other two: R_eq = 6 || (6 + 6)' : 'Conservation of charge: each sphere gets (q₁ + q₂)/2',
          stepByStepSolution: isCurrent
            ? [
                'Two sides are in series: 6 Ω + 6 Ω = 12 Ω.',
                'This 12 Ω combination is in parallel with the third side (6 Ω).',
                'R_eq = (6 × 12) / (6 + 12) = 72 / 18 = 4 Ω.'
              ]
            : [
                'Initial force magnitude: F ∝ |(+10) × (-2)| = 20.',
                'When touched, charges equalize: q_new = (10 - 2) / 2 = +4 μC on each sphere.',
                'New force: F\' ∝ (+4) × (+4) = 16.',
                'Ratio F\' / F = 16 / 20 = 4/5 ⟹ F\' = 0.8 F (now repulsive).'
              ],
          answer: isCurrent ? 'R_eq = 4 Ω' : 'F\' = 0.8 F (repulsive)'
        },
        {
          level: 4, levelName: 'Physical Constraints & Symmetry Traps', difficulty: 'Advanced',
          question: isCurrent
            ? 'A battery of EMF E and internal resistance r is connected to an external load resistor R. Prove that maximum power is delivered to the load when R = r (Maximum Power Transfer Theorem).'
            : 'A point charge q is placed at one corner of a cube of side a. Calculate the electric flux through one of the three faces opposite to the corner.',
          formulaApplication: isCurrent ? 'P = I² R = [E / (R + r)]² R. Differentiate dP/dR = 0.' : 'Gauss\'s law with 8 symmetric cubes sharing the corner: Φ_total = q / (8ε₀)',
          stepByStepSolution: isCurrent
            ? [
                'P(R) = E² R (R + r)⁻².',
                'dP/dR = E² [(R + r)² - 2R(R + r)] / (R + r)⁴ = E² (r - R) / (R + r)³.',
                'Set dP/dR = 0 ⟹ r - R = 0 ⟹ R = r.',
                'At R = r, maximum power P_max = E² / (4r).'
              ]
            : [
                'Construct 8 identical cubes around the corner charge. Enclosed charge is q, so total flux through all 8 cubes = q / ε₀.',
                'Flux through one full cube = q / (8 ε₀).',
                'The 3 faces meeting at the corner have E parallel to surface (zero flux).',
                'The remaining 3 faces share the flux equally: Φ_face = [q / (8 ε₀)] / 3 = q / (24 ε₀).'
              ],
          answer: isCurrent ? 'Proven: Maximum power occurs when R = r, and P_max = E²/(4r)' : 'Flux through one opposite face = q / (24 ε₀)'
        },
        {
          level: 5, levelName: 'Competitive Entrance Challenge', difficulty: 'Mastery',
          question: isCurrent
            ? '(JEE Advanced) In a potentiometer wire of length 100 cm and resistance 10 Ω connected in series with a 40 Ω resistor and a 2 V accumulator, find the balancing length for a cell of EMF 1.08 V.'
            : '(JEE Advanced) A thin spherical conducting shell of radius R has charge Q. A point charge q is brought from infinity to the center of the shell through a tiny hole. What is the external work required?',
          formulaApplication: isCurrent ? 'Potential gradient k = V_wire / L. Balancing length l = E_cell / k.' : 'Potential inside conducting shell is constant and equals surface potential: V = Q / (4πε₀ R)',
          stepByStepSolution: isCurrent
            ? [
                'Total resistance of circuit = R_wire + R_series = 10 Ω + 40 Ω = 50 Ω.',
                'Current in potentiometer wire = 2 V / 50 Ω = 0.04 A.',
                'Potential drop across wire V_wire = 0.04 A × 10 Ω = 0.40 V.',
                'Potential gradient k = 0.40 V / 100 cm = 0.004 V/cm.',
                'Wait: A cell of 1.08 V exceeds total wire voltage 0.4 V, so no balance point is obtained on the wire!'
              ]
            : [
                'Work required W = q [V_center - V_infinity].',
                'V_infinity = 0.',
                'Inside a conducting shell, potential everywhere inside is constant and equals potential on the surface: V_center = Q / (4πε₀ R).',
                'Therefore, work required W = q Q / (4πε₀ R).'
              ],
          answer: isCurrent ? 'No balance point obtained (cell EMF 1.08 V > wire voltage 0.4 V)' : 'W = q Q / (4πε₀ R)'
        }
      ],
      comparativeMatrices: [
        {
          title: isCurrent ? 'Series vs. Parallel Resistor Combinations' : 'Electrostatic Field vs. Gravitational Field',
          headers: isCurrent
            ? ['Property', 'Series Circuit', 'Parallel Circuit']
            : ['Property', 'Electrostatic Field', 'Gravitational Field'],
          rows: isCurrent
            ? [
                ['Current', 'Same through all components', 'Splits across branches (I = I₁ + I₂)'],
                ['Voltage', 'Splits across resistors (V = V₁ + V₂)', 'Same across all branches'],
                ['Equivalent Resistance', 'R_eq = R₁ + R₂ + ... (Larger than largest)', '1/R_eq = 1/R₁ + 1/R₂ (Smaller than smallest)'],
                ['Failure Consequence', 'One open circuit breaks entire loop', 'Other branches continue functioning independently']
              ]
            : [
                ['Source', 'Electric charges (q)', 'Masses (m)'],
                ['Nature of Force', 'Attractive or Repulsive', 'Always Attractive only'],
                ['Medium Dependence', 'Strongly dependent on medium (dielectric K)', 'Completely independent of medium'],
                ['Governing Law', 'Coulomb\'s Law: F = kq₁q₂/r²', 'Newton\'s Law: F = Gm₁m₂/r²']
              ]
        }
      ],
      diagnosticDecisionMatrix: {
        title: isCurrent ? 'Circuit Analysis Heuristics' : 'Electrostatic Field Determination Heuristics',
        headers: ['Circuit / Charge Configuration', 'Preferred Principle / Law', 'Calculation Shortcut'],
        rows: isCurrent
          ? [
              ['Single loop with multiple batteries', 'Kirchhoff\'s Loop Rule (KVL)', 'Net EMF / Net Resistance'],
              ['Multi-junction symmetric bridge', 'Wheatstone Bridge Balance', 'Remove central galvanometer arm'],
              ['Complex multi-node circuit', 'Nodal Voltage Analysis', 'Assign 0V reference to bottom rail']
            ]
          : [
              ['Point charges at fixed coordinates', 'Superposition Principle with Coulomb\'s Law', 'Sum vector components along x and y'],
              ['High symmetry (cylindrical, spherical, planar)', 'Gauss\'s Law with Gaussian Surface', 'E · A_gaussian = q_in / ε₀'],
              ['Continuous irregular charge distribution', 'Direct Integration of dE = k dq / r²', 'Exploit coordinate symmetries to cancel components']
            ]
      },
      academicQuestions: [
        { id: 'el_acad_1', category: 'Very Short Answer (1–2 Marks)', question: isCurrent ? 'State Ohm\'s Law and write its mathematical formula.' : 'State Coulomb\'s Law in electrostatics.', answer: isCurrent ? 'Ohm\'s Law states that the current through a conductor is directly proportional to the potential difference across it, provided temperature and other physical conditions remain constant: V = IR.' : 'Coulomb\'s Law states that the electrostatic force between two stationary point charges is directly proportional to the product of charges and inversely proportional to the square of the distance between them: F = (1/4πε₀)(q₁q₂/r²).', marks: 1, markingScheme: ['1 Mark: Complete statement with formula.'] },
        { id: 'el_acad_2', category: 'Short Answer (3–4 Marks)', question: isCurrent ? 'Derive the relation between electric current and drift velocity of electrons in a conductor.' : 'State Gauss\'s theorem and use it to find the electric field due to an infinitely long straight charged wire.', answer: isCurrent ? 'In time Δt, charge passing through cross-section A is ΔQ = n · e · (A · v_d · Δt). Current I = ΔQ / Δt = n e A v_d.' : 'Gauss\'s theorem: Total flux through closed surface Φ = ∮E·dA = q/ε₀. For cylinder of length l and radius r around line charge λ: E(2πrl) = (λl)/ε₀ ⟹ E = λ / (2πε₀r).', marks: 3, markingScheme: ['1 Mark: Statement. 2 Marks: Complete step-by-step derivation.'] }
      ],
      competitiveQuestions: [
        { category: 'Assertion-Reason (NEET/JEE)', question: isCurrent ? 'Assertion (A): Electric field inside a current-carrying metallic conductor is non-zero.\nReason (R): Charges inside a current-carrying conductor are in motion, not in electrostatic equilibrium.' : 'Assertion (A): Electrostatic field lines never intersect each other.\nReason (R): If they intersect, at the point of intersection there would be two tangents and two directions of electric field, which is physically impossible.', options: ['A) Both A and R are true, and R is the correct explanation of A', 'B) Both A and R are true, but R is NOT the correct explanation of A', 'C) A is true, R is false', 'D) A is false, R is true'], correctOption: 'A', solution: 'Both assertion and reason are true and correctly linked.', speedTrick: 'Remember electrostatic equilibrium (E=0) vs steady current dynamics (E=J/σ ≠ 0).', negativeMarkingTrap: 'Students often confuse static conductors (E=0) with current-carrying wires (E=V/l).' }
      ],
      rapidFireQuestions: [
        { qNumber: 1, question: isCurrent ? 'What is the SI unit of electrical conductivity?' : 'What is the SI unit of electric permittivity ε₀?', answer: isCurrent ? 'Siemens per meter (S/m) or (Ω·m)⁻¹.' : 'Farads per meter (F/m) or C²/(N·m²).', shortExplanation: 'Conductivity is reciprocal of resistivity.' },
        { qNumber: 2, question: isCurrent ? 'How does resistance of semiconductors change with increasing temperature?' : 'What is the angle between electric field lines and equipotential surfaces?', answer: isCurrent ? 'It decreases (negative temperature coefficient).' : '90 degrees (perpendicular).', shortExplanation: isCurrent ? 'Thermal energy frees more charge carriers.' : 'No work is done moving charge along equipotential surface.' }
      ],
      vocabularyMasterclass: [
        { term: isCurrent ? 'Resistivity' : 'Permittivity', etymology: isCurrent ? 'Latin "resistere" (to hold back).' : 'Latin "permittere" (to let through).', definition: isCurrent ? 'Intrinsic material property quantifying opposition to current flow.' : 'Measure of a medium\'s resistance to forming an electric field.', memoryHook: isCurrent ? 'The intrinsic friction of the material.' : 'How easily a medium permits electric flux.' }
      ],
      spokenUnits: [
        { symbol: isCurrent ? 'Ω' : 'C', unitName: isCurrent ? 'Ohm' : 'Coulomb', spokenForm: isCurrent ? 'Ohms resistance' : 'Coulombs charge', physicalMeaning: isCurrent ? 'Opposition to current' : 'Electric charge' },
        { symbol: isCurrent ? 'A' : 'N/C', unitName: isCurrent ? 'Ampere' : 'Newton per Coulomb', spokenForm: isCurrent ? 'Amperes current' : 'Newtons per Coulomb', physicalMeaning: isCurrent ? 'Rate of charge flow' : 'Electric field strength' }
      ],
      fiveLayerSummary: {
        layer1UltraRapid: isCurrent
          ? 'Electric current is the flow of charge (I = n e A v_d). Ohm\'s law V = IR governs ohmic conductors. Kirchhoff\'s laws enforce charge and energy conservation.'
          : 'Coulomb\'s Law governs inverse-square electrostatic force between point charges. Gauss\'s Law equates closed surface flux to enclosed charge over ε₀.',
        layer2FirstPrinciples: isCurrent
          ? [
              'Charge carriers drift slowly under electric field: v_d = eEτ/m.',
              'Resistance depends on geometry: R = ρ l / A.',
              'Energy conservation in loops: ΣΔV = 0.',
              'Charge conservation at junctions: ΣI = 0.',
              'Electric power dissipation: P = VI = I²R.'
            ]
          : [
              'Electric charge is quantized (q = ne) and conserved.',
              'Coulomb force operates along line connecting charges.',
              'Electric field is force per unit test charge: E = F/q₀.',
              'Conductors in equilibrium have zero internal electric field.',
              'Gauss\'s law relates flux to enclosed charge: ∮E·dA = q_enclosed/ε₀.'
            ],
        layer3GoldenEquations: isCurrent
          ? ['V = IR', 'I = n e A v_d', 'R = ρ l / A', 'P = VI = I²R', 'R_T = R_0(1 + αΔT)']
          : ['F = (1/4πε₀) · |q₁q₂| / r²', 'E = F / q₀', 'Φ_E = ∮E·dA = q/ε₀', 'p = q(2a)', 'E_sheet = σ / (2ε₀)'],
        layer4ExaminerTraps: isCurrent
          ? [
              'Stretching wire doubles length but quadruples resistance (R ∝ l²)!',
              'Ohm\'s law fails for semiconductors, diodes, and electrolytes.',
              'Current flows in direction of positive charge, opposite to electron drift.'
            ]
          : [
              'Electrostatic field lines NEVER form closed loops (unlike magnetic field lines)!',
              'Internal field of conductor is ZERO only in static equilibrium, not when current flows!',
              'Dipole moment direction is from NEGATIVE to POSITIVE.'
            ],
        layer5VisualMentalSchema: isCurrent
          ? 'EMF Source (V) ──► Voltage Pressure ──► Drift of Electrons (I = neAv_d) ──► Resistance Friction (R = ρl/A)'
          : 'Point Charge q ──► Radial Electric Field E = kq/r² ──► Flux through Gaussian Surface Φ = q/ε₀'
      }
    };
  }

  // 4. GENERALIZED TOPIC CURRICULUM SYNTHESIZER (Handles Any Custom / Other STEM Topic)
  const isBio = domain === 'biology';
  const isChem = domain === 'chemistry';
  const isMath = domain === 'math';

  const defaultFormulaLatex = isMath
    ? `f'(x) = \\lim_{h \\to 0} \\frac{f(x+h) - f(x)}{h} \\qquad \\iff \\qquad \\int f(x) dx = F(x) + C`
    : isChem
    ? `k = A e^{-\\frac{E_a}{RT}} \\qquad \\iff \\qquad \\ln k = \\ln A - \\frac{E_a}{RT}`
    : isBio
    ? `\\frac{dN}{dt} = r N \\left(1 - \\frac{N}{K}\\right) \\qquad (\\text{Logistic Growth & Energy Balance})`
    : `\\vec{F}_{\\text{net}} = \\frac{d\\vec{p}}{dt} = m\\vec{a} \\qquad (\\text{Fundamental Conservation Dynamic})`;

  const defaultEqName = isMath
    ? `Fundamental Calculus & Invariant Formulation of ${clean}`
    : isChem
    ? `Chemical Kinetics & Governing Rate Equation for ${clean}`
    : isBio
    ? `Biological Energy Transfer & Regulatory Mechanism of ${clean}`
    : `First-Principles Governing Law of ${clean}`;

  return {
    title: clean,
    domain,
    introConcept: `Welcome to the master exploration of **${clean}**! Let us build your understanding from absolute first principles without any confusing jargon. At its core, ${clean} governs how fundamental entities (matter, energy, numbers, or biological structures) interact, transform, and conserve invariant quantities. By understanding the underlying mechanisms and boundary constraints, every complex exam problem collapses into a predictable, logical progression!`,
    analogy: `Imagine ${clean} like a balanced financial ledger. On one side, you have inputs and incoming driving forces; on the other, you have outputs, conserved balances, and inevitable conversion costs. Nothing vanishes without accounting: every change in one variable precisely dictates the response in connected parameters!`,
    questionFirst: `What is the single governing constraint that prevents ${clean} from behaving arbitrarily in real-world systems?`,
    svgDiagram: generateTopicSvgDiagram(clean, domain),
    governingEquationName: defaultEqName,
    governingEquationLatex: defaultFormulaLatex,
    tenStepProtocol: [
      { step: 1, phase: 'Fundamental Law Statement', explanation: `Define the primary governing relationship of ${clean} in precise scientific terms.`, formulaOrValue: defaultFormulaLatex, trapAndTip: `Ensure you clearly identify independent vs dependent parameters.` },
      { step: 2, phase: 'SI Units & Physical Dimensions', explanation: `Map all active variables and constants into coherent metric/SI units to prevent magnitude errors.`, formulaOrValue: `[\\text{Dimensions derived from first principles}]`, trapAndTip: `Metric prefix conversions (milli, micro, kilo) are prime areas where examiners set traps!` },
      { step: 3, phase: 'First-Principles Derivation', explanation: `Trace how the governing equation emerges from conservation of mass, energy, or foundational mathematical axioms.`, formulaOrValue: `\\Delta(\\text{System}) = 0`, trapAndTip: `Never memorize just the end formula; know the 2-step assumption framework.` },
      { step: 4, phase: 'Limiting & Boundary Conditions', explanation: `Evaluate system behavior as key parameters approach extreme bounds (zero or infinity).`, formulaOrValue: `\\lim_{x \\to 0} f(x) \\quad \\text{and} \\quad \\lim_{x \\to \\infty} f(x)`, trapAndTip: `Singularities and asymptotic thresholds define where equations break down.` },
      { step: 5, phase: 'Graphical & Geometric Representation', explanation: `Translate the analytical equation into its visual curve (linear, exponential, parabolic, or sigmoidal).`, formulaOrValue: `y = f(x)`, trapAndTip: `The slope (derivative) and area under the curve (integral) always represent physical quantities!` },
      { step: 6, phase: 'Dimensional Consistency Check', explanation: `Verify that left-hand side dimensions exactly equal right-hand side dimensions.`, formulaOrValue: `[\\text{LHS}] = [\\text{RHS}]`, trapAndTip: `Quick elimination technique for competitive MCQs: eliminate options with wrong dimensions!` },
      { step: 7, phase: 'Parameter Scaling Laws', explanation: `Determine how doubling or halving an input parameter scales the ultimate output response.`, formulaOrValue: `y \\propto x^n`, trapAndTip: `Quadratic (square) relationships double the output by a factor of 4!` },
      { step: 8, phase: 'Worked Numerical Application', explanation: `Step-by-step resolution of a canonical exam-style problem for ${clean}.`, formulaOrValue: `\\text{Substitute knowns } \\to \\text{ Solve unknown}`, trapAndTip: `Keep track of signs and standard units throughout the calculation.` },
      { step: 9, phase: 'High-Frequency Pitfalls & Traps', explanation: `Common misconceptions that cause over 60% of students to lose marks on exams.`, formulaOrValue: `\\text{Watch out for hidden boundary assumptions}`, trapAndTip: `Read the question twice to check if specific conditions (constant temperature, vacuum, ideal state) are specified!` },
      { step: 10, phase: '10-Second Recall Mnemonic', explanation: `A sharp mental anchor to permanently lock in the formula for ${clean}.`, formulaOrValue: `\\text{Anchor: "${clean} balances inputs and outputs"}`, trapAndTip: `Use this mnemonic right before walking into the examination hall.` }
    ],
    technique11Questions: [
      {
        level: 1, levelName: 'Direct Substitution & Formula Familiarity', difficulty: 'Easy',
        question: `State the fundamental governing equation of ${clean} and solve for the primary dependent variable given standard baseline parameters.`,
        formulaApplication: `Direct application of ${defaultFormulaLatex}`,
        stepByStepSolution: [
          `Identify the given baseline inputs for ${clean}.`,
          `Substitute into the governing formulation.`,
          `Compute final numerical value and append correct SI units.`
        ],
        answer: `Directly verified using baseline parameters.`
      },
      {
        level: 2, levelName: 'Variable Rearrangement & Unknown Isolation', difficulty: 'Medium',
        question: `Rearrange the core formulation of ${clean} to isolate the primary intermediate constant when the output is doubled.`,
        formulaApplication: `Algebraic isolation and inverse mapping.`,
        stepByStepSolution: [
          `Set up the equation for state 1 and state 2.`,
          `Divide the two expressions to eliminate unneeded constants.`,
          `Solve for the isolated target variable.`
        ],
        answer: `Target variable isolated with proper scaling factor.`
      },
      {
        level: 3, levelName: 'Multi-Step Unit Conversions & Metric Traps', difficulty: 'Hard',
        question: `Calculate the net systemic response of ${clean} when input parameters are provided in non-standard metric units requiring dimensional scaling.`,
        formulaApplication: `Multi-step conversion and dimensional checking.`,
        stepByStepSolution: [
          `Convert all inputs to standard SI base units.`,
          `Apply intermediate equation and track powers of 10.`,
          `Verify final answer format matches examination specification.`
        ],
        answer: `Correctly calculated with zero metric prefix errors.`
      },
      {
        level: 4, levelName: 'Physical Constraints & Real-World Application', difficulty: 'Advanced',
        question: `Analyze a constrained boundary condition in ${clean} where one parameter reaches its practical physical saturation limit.`,
        formulaApplication: `Constraint optimization and asymptotic analysis.`,
        stepByStepSolution: [
          `Express boundary constraint mathematically.`,
          `Evaluate rate of change at the saturation boundary.`,
          `Draw physical conclusions regarding efficiency or stability.`
        ],
        answer: `System operates at maximum constrained threshold.`
      },
      {
        level: 5, levelName: 'Competitive Entrance Challenge', difficulty: 'Mastery',
        question: `(JEE / NEET / Olympiad Challenge) Derive the combined governing relationship for ${clean} under non-ideal, perturbed multi-variable conditions.`,
        formulaApplication: `Coupled differential equations or multi-factor balance.`,
        stepByStepSolution: [
          `Write full differential rate or balance equation.`,
          `Integrate across the specified boundary limits.`,
          `Apply competitive elimination heuristics to confirm the single valid option.`
        ],
        answer: `Rigorous analytical solution confirmed.`
      }
    ],
    comparativeMatrices: [
      {
        title: `Comprehensive Comparative Analysis of Key Regimes in ${clean}`,
        headers: ['Evaluation Parameter', 'Regime A / Standard Condition', 'Regime B / Extreme Condition'],
        rows: [
          ['Primary Mechanism', `Baseline behavior of ${clean}`, `High-intensity / Limiting response`],
          ['Mathematical Relationship', 'Linear / First-order approximation', 'Non-linear / Saturated behavior'],
          ['Dominant Governing Variable', 'Internal state variables', 'External boundary forcing'],
          ['Exam Application', 'Standard board exam numericals', 'Competitive entrance tricky edge-cases']
        ]
      }
    ],
    diagnosticDecisionMatrix: {
      title: `Diagnostic Decision Matrix for ${clean} Problem Solving`,
      headers: ['Given Problem Description', 'Immediate Formula Choice', 'Key Elimination Clue'],
      rows: [
        [`Standard direct calculation for ${clean}`, defaultEqName, 'Check that units are in SI before plugging in'],
        [`Ratio comparison between two states of ${clean}`, 'Scaling proportion (State 2 / State 1)', 'Cancel all common constants immediately'],
        [`Boundary or threshold problem in ${clean}`, 'Set limiting derivative or condition = 0', 'Check for physical non-negativity constraints']
      ]
    },
    academicQuestions: [
      { id: 'gen_acad_1', category: 'Very Short Answer (1–2 Marks)', question: `Define the primary scientific concept of ${clean}.`, answer: `${clean} is defined as the foundational process and framework governing the systematic transformation and conservation of core system properties.`, marks: 1, markingScheme: ['1 Mark: Precise scientific definition with governing term.'] },
      { id: 'gen_acad_2', category: 'Very Short Answer (1–2 Marks)', question: `State the primary SI unit associated with the key parameter of ${clean}.`, answer: `The standard SI unit is derived directly from the first-principles dimensions of ${clean}.`, marks: 1, markingScheme: ['1 Mark: Correct SI unit.'] },
      { id: 'gen_acad_3', category: 'Short Answer (3–4 Marks)', question: `Explain the fundamental principle of ${clean} with a neat diagram and state two key applications.`, answer: `1. Principle: Systems operating under ${clean} maintain rigorous conservation of fundamental invariants. 2. Applications: Practical design, diagnostic analysis, and predictive modeling in natural and physical sciences.`, marks: 3, markingScheme: ['1 Mark: Statement. 1 Mark: Diagram description. 1 Mark: Two valid applications.'] }
    ],
    competitiveQuestions: [
      { category: 'Multiple Choice (Single Option Correct)', question: `In the study of ${clean}, which of the following statements is strictly correct under all standard conditions?`, options: [`A) It adheres to fundamental conservation laws at all times`, `B) It is completely independent of environmental temperature and pressure`, `C) It violates second-order thermodynamic principles`, `D) Its output scales inversely with the cube of all inputs`], correctOption: 'A', solution: `Conservation laws represent unbreakable physical and mathematical invariants governing ${clean}.`, speedTrick: `Options with extreme absolutes like "completely independent" or "violates laws" are almost always incorrect distractors!`, negativeMarkingTrap: `Do not jump to conclusions without checking whether the question specifies ideal or non-ideal regimes.` }
    ],
    rapidFireQuestions: [
      { qNumber: 1, question: `What is the primary governing factor in ${clean}?`, answer: `The fundamental balance of input energy, matter, or mathematical domain constraints.`, shortExplanation: `Dictates the direction and magnitude of all changes.` },
      { qNumber: 2, question: `Can the fundamental invariant of ${clean} be destroyed in an isolated system?`, answer: `No, it is strictly conserved.`, shortExplanation: `First law of conservation holds universally.` }
    ],
    vocabularyMasterclass: [
      { term: clean, etymology: `Derived from classical roots representing systematic observation and analytical law.`, definition: `The scientific study, formulation, and application of ${clean}.`, memoryHook: `Key cornerstone of the academic syllabus.` }
    ],
    spokenUnits: [
      { symbol: 'Units', unitName: 'Standard SI Base Units', spokenForm: 'Standard units', physicalMeaning: `Metric dimension of ${clean}` }
    ],
    fiveLayerSummary: {
      layer1UltraRapid: `${clean} establishes the fundamental laws and conservation metrics governing the topic. Master the core equation, know the SI units, and avoid common boundary traps.`,
      layer2FirstPrinciples: [
        `First-principles foundation of ${clean}.`,
        `Direct mathematical formulation and variable mappings.`,
        `Conservation of invariants across transformations.`,
        `Boundary constraints and physical limits.`,
        `Exam problem-solving protocol and elimination tricks.`
      ],
      layer3GoldenEquations: [
        defaultFormulaLatex,
        `\\text{Conservation: } \\Sigma(\\text{Inputs}) = \\Sigma(\\text{Outputs})`
      ],
      layer4ExaminerTraps: [
        `Always convert non-standard units to SI base units before starting calculations!`,
        `Watch out for signs (+ vs -) and directionality in vector or energy balances!`,
        `Verify whether ideal or realistic conditions are specified in the question.`
      ],
      layer5VisualMentalSchema: `Inputs ──► Core Dynamic of ${clean} ──► Conserved Transformation ──► Outputs & Practice Mastery`
    }
  };
}
