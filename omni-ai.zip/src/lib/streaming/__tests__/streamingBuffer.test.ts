import { StreamingBuffer } from '../StreamingBuffer';
import { TokenClassifier } from '../TokenClassifier';
import { StreamingEdgeCaseHandler } from '../StreamingEdgeCaseHandler';
import { cleanStreamingMarkdown, stripMarkdownCodeFencesAndDelimiters } from '../cleanStreamingMarkdown';

/**
 * Streaming Buffer Verification Test Suite
 */
export function runStreamingTests(): { passed: number; failed: number; results: { name: string; success: boolean; error?: string }[] } {
  const tests: { name: string; fn: () => void }[] = [];
  const results: { name: string; success: boolean; error?: string }[] = [];
  let passed = 0;
  let failed = 0;

  const test = (name: string, fn: () => void) => {
    tests.push({ name, fn });
  };

  const expect = (actual: any) => ({
    toBe: (expected: any) => {
      if (actual !== expected) {
        throw new Error(`Expected "${expected}" but got "${actual}"`);
      }
    },
    toEqual: (expected: any) => {
      if (JSON.stringify(actual) !== JSON.stringify(expected)) {
        throw new Error(`Expected ${JSON.stringify(expected)} but got ${JSON.stringify(actual)}`);
      }
    },
    toBeTruthy: () => {
      if (!actual) {
        throw new Error(`Expected truthy but got ${actual}`);
      }
    },
  });

  // Test 1: Incomplete header token suppression
  test('hides incomplete #### and (क) tokens during streaming', () => {
    const buffer = new StreamingBuffer();
    buffer.append('####');
    expect(buffer.getSafeContent()).toBe('');

    buffer.append(' (क)');
    expect(buffer.getSafeContent()).toBe('');

    buffer.append(' Einstein Equation\n');
    expect(buffer.getSafeContent().trim()).toBe('#### (क) Einstein Equation');
  });

  // Test 2: Incomplete inline math suppression
  test('hides incomplete $ math delimiters until closing $ arrives', () => {
    const buffer = new StreamingBuffer();
    buffer.append('Energy is $h\\nu');
    expect(buffer.getSafeContent()).toBe('Energy is ');

    buffer.append(' = \\Phi_0 + K$');
    expect(buffer.getSafeContent()).toBe('Energy is $h\\nu = \\Phi_0 + K$');
  });

  // Test 3: Incomplete display math suppression
  test('hides incomplete $$ display math blocks until closed', () => {
    const buffer = new StreamingBuffer();
    buffer.append('Formula:\n$$E = mc^2');
    expect(buffer.getSafeContent()).toBe('Formula:\n');

    buffer.append('$$\nNext line');
    expect(buffer.getSafeContent()).toBe('Formula:\n$$E = mc^2$$\nNext line');
  });

  // Test 4: Live sanitizer strips incomplete syntax
  test('StreamingBuffer.sanitizeLiveStreamText cleans trailing raw markers instantly', () => {
    const sanitizedHeader = StreamingBuffer.sanitizeLiveStreamText('#### (क) ');
    expect(sanitizedHeader).toBe('');

    const sanitizedMath = StreamingBuffer.sanitizeLiveStreamText('Energy $h\\nu = ');
    expect(sanitizedMath).toBe('Energy h\\nu = ');

    const sanitizedBold = StreamingBuffer.sanitizeLiveStreamText('Important **Concept');
    expect(sanitizedBold).toBe('Important Concept');
  });

  // Test 5: cleanStreamingMarkdown transforms LaTeX commands for clear reading
  test('cleanStreamingMarkdown formats vectors, text and arrows', () => {
    const out = cleanStreamingMarkdown('Vector $\\vec{F} = m\\vec{a}$ and $\\text{Mass} \\times \\text{Acc}$');
    expect(out.includes('F⃗')).toBeTruthy();
    expect(out.includes('a⃗')).toBeTruthy();
  });

  // Test 6: Devanagari Unicode split preservation
  test('StreamingEdgeCaseHandler protects Devanagari combined glyphs', () => {
    const text = 'प्रकाश-संश्लेषण (Photosynthesis)';
    const split = StreamingEdgeCaseHandler.safeUnicodeSplit(text, 5);
    expect(split <= 5).toBeTruthy();
  });

  // Test 7: stripMarkdownCodeFencesAndDelimiters unwraps ```markdown and ```md wrappers
  test('stripMarkdownCodeFencesAndDelimiters unwraps ```markdown and ```md wrappers', () => {
    const raw = '```markdown\n# Photosynthesis Lecture\n- Concept 1\n```';
    const out = stripMarkdownCodeFencesAndDelimiters(raw);
    expect(out.trim()).toBe('# Photosynthesis Lecture\n- Concept 1');
  });

  // Test 8: stripMarkdownCodeFencesAndDelimiters unwraps ```svg code fences into inline SVG
  test('stripMarkdownCodeFencesAndDelimiters unwraps ```svg code fences into clean SVG', () => {
    const raw = 'Before\n```svg\n<svg width="200" height="100"><circle cx="50" cy="50" r="40"/></svg>\n```\nAfter';
    const out = stripMarkdownCodeFencesAndDelimiters(raw);
    expect(out.includes('```svg')).toBe(false);
    expect(out.includes('<svg width="200"')).toBe(true);
  });

  // Test 9: cleanStreamingMarkdown strips trailing code fence characters during live streaming
  test('cleanStreamingMarkdown strips trailing code fence characters during live streaming', () => {
    const liveStreamingText = 'Heading content\n```markdown';
    const out = cleanStreamingMarkdown(liveStreamingText, true);
    expect(out.includes('```markdown')).toBe(false);
    expect(out.trim()).toBe('Heading content');
  });

  // Run all tests
  for (const t of tests) {
    try {
      t.fn();
      passed++;
      results.push({ name: t.name, success: true });
    } catch (err: any) {
      failed++;
      results.push({ name: t.name, success: false, error: err.message || String(err) });
    }
  }

  return { passed, failed, results };
}
