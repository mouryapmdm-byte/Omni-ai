import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, Eye, TrendingUp, Heart, Clock, Sparkles, Smile, 
  Volume2, ShieldAlert, Zap, Award, AlertTriangle, RefreshCw, 
  Play, Pause, MessageSquare, Compass, Terminal, CheckCircle2,
  Users, HelpCircle, FileText, ChevronRight, Sliders
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, 
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  ScatterChart, Scatter, ZAxis
} from 'recharts';

interface TimelineEvent {
  time: string;
  timestampSec: number;
  title: string;
  category: 'System' | 'Visual' | 'Acoustic' | 'Input' | 'Social' | 'Mastery';
  description: string;
  sentimentScore: number; // -1.0 to 1.0
  sentimentLabel: 'Frustrated' | 'Confused' | 'Enthusiastic' | 'Skeptical' | 'Satisfied' | 'Neutral';
  gazeX: number; // 0-100 target coordinate
  gazeY: number; // 0-100 target coordinate
  gazeTarget: 'Equation Canvas' | 'Peer Chat panel' | 'Off-Screen' | 'Instructions';
  keystrokeWpm: number;
  keystrokeErrorRate: number; // % of backspaces
  vocalPitchHz: number;
  vocalAmplitudeDb: number;
  vocalStressIndex: number; // 0-100%
  synergyOverlap: number; // 0-100% cursor alignment
  masteryIndex: number; // 0-100%
  pedagogicalTip: string;
}

const TIMELINE_DATA: TimelineEvent[] = [
  {
    time: "09:00 AM",
    timestampSec: 0,
    title: "Session Initiation & Calibration",
    category: "System",
    description: "Multimodal sensor streams synchronized. Gaze calibration offset verified at ±0.4 degrees. Mic voiceprint identified as student Alex Thorne.",
    sentimentScore: 0.2,
    sentimentLabel: "Neutral",
    gazeX: 50,
    gazeY: 50,
    gazeTarget: "Instructions",
    keystrokeWpm: 12,
    keystrokeErrorRate: 2,
    vocalPitchHz: 135,
    vocalAmplitudeDb: 42,
    vocalStressIndex: 12,
    synergyOverlap: 35,
    masteryIndex: 10,
    pedagogicalTip: "Optimal calibration achieved. Alex is starting the lesson with relaxed vocal indicators."
  },
  {
    time: "09:03 AM",
    timestampSec: 180,
    title: "Encountered Euler's Identity - Step 1",
    category: "Visual",
    description: "Visual focus locked on the Taylor series expansion. High pupillary dilation detected, indicating strong immediate cognitive enrollment.",
    sentimentScore: 0.6,
    sentimentLabel: "Enthusiastic",
    gazeX: 45,
    gazeY: 35,
    gazeTarget: "Equation Canvas",
    keystrokeWpm: 48,
    keystrokeErrorRate: 4,
    vocalPitchHz: 148,
    vocalAmplitudeDb: 55,
    vocalStressIndex: 22,
    synergyOverlap: 40,
    masteryIndex: 25,
    pedagogicalTip: "Excellent initial attention. Alex's gaze focus coordinates remain on the core equation blocks."
  },
  {
    time: "09:08 AM",
    timestampSec: 480,
    title: "Stalled on Complex Substitution",
    category: "Input",
    description: "Severe drop in typing cadence combined with multiple consecutive backspaces. Gaze coordinates drift frequently off-canvas, indicating a cognitive roadblock.",
    sentimentScore: -0.5,
    sentimentLabel: "Confused",
    gazeX: 12,
    gazeY: 82,
    gazeTarget: "Off-Screen",
    keystrokeWpm: 8,
    keystrokeErrorRate: 45,
    vocalPitchHz: 124,
    vocalAmplitudeDb: 38,
    vocalStressIndex: 68,
    synergyOverlap: 18,
    masteryIndex: 28,
    pedagogicalTip: "Roadblock detected. Keystroke error spikes suggest frustration. Prompting with peer hints would relieve cognitive overload."
  },
  {
    time: "09:11 AM",
    timestampSec: 660,
    title: "Collaborative Synergy Triggered",
    category: "Social",
    description: "Alex aligned whiteboard pointers with Rohan Sharma. Teammates exchanged 3 chat responses within a 45-second window. Synergy multiplier active.",
    sentimentScore: 0.4,
    sentimentLabel: "Skeptical",
    gazeX: 78,
    gazeY: 48,
    gazeTarget: "Peer Chat panel",
    keystrokeWpm: 55,
    keystrokeErrorRate: 8,
    vocalPitchHz: 141,
    vocalAmplitudeDb: 58,
    vocalStressIndex: 35,
    synergyOverlap: 92,
    masteryIndex: 45,
    pedagogicalTip: "Social coupling is successfully lowering stress indicators. Collaborative peer dialogue is scaffolded effectively."
  },
  {
    time: "09:16 AM",
    timestampSec: 960,
    title: "Vocal Reasoning Sparked - Step 2",
    category: "Acoustic",
    description: "Voice amplitude spike of +12dB. Rapid self-correction vocal utterance recorded. High pitch variability matches cognitive breakthroughs.",
    sentimentScore: 0.8,
    sentimentLabel: "Satisfied",
    gazeX: 52,
    gazeY: 33,
    gazeTarget: "Equation Canvas",
    keystrokeWpm: 68,
    keystrokeErrorRate: 5,
    vocalPitchHz: 156,
    vocalAmplitudeDb: 64,
    vocalStressIndex: 15,
    synergyOverlap: 85,
    masteryIndex: 72,
    pedagogicalTip: "Active Socratic self-explanation detected in vocal logs. This is highly correlated with schema integration."
  },
  {
    time: "09:22 AM",
    timestampSec: 1320,
    title: "Pythagorean Geometric Synthesis",
    category: "Mastery",
    description: "Successful transposition of algebraic structures into 2D geometric blocks. Inter-disciplinary conceptual links established inside semantic graph.",
    sentimentScore: 0.9,
    sentimentLabel: "Satisfied",
    gazeX: 48,
    gazeY: 40,
    gazeTarget: "Equation Canvas",
    keystrokeWpm: 74,
    keystrokeErrorRate: 3,
    vocalPitchHz: 144,
    vocalAmplitudeDb: 48,
    vocalStressIndex: 10,
    synergyOverlap: 60,
    masteryIndex: 95,
    pedagogicalTip: "Cross-domain mastery unlocked! Student successfully mapped algebraic values to visual coordinates."
  }
];

const TRANSCRIBED_CHAT_SAMPLES = [
  { id: 'u1', sender: "Alex Thorne", text: "Wait, I don't see why the exponents simplify when we introduce the complex unit i.", timestamp: "09:08 AM", sentiment: "Confused", confidence: 0.84, valence: -0.42, arousal: 0.65 },
  { id: 'u2', sender: "Rohan Sharma", text: "Look at the powers of i: i^2 is -1, so the even terms flip sign, and the odd terms keep an i!", timestamp: "09:09 AM", sentiment: "Neutral", confidence: 0.92, valence: 0.15, arousal: 0.38 },
  { id: 'u3', sender: "Alex Thorne", text: "Ah! Of course! So that's how we split it into the real cos(x) and imaginary sin(x) Taylor parts! That is so clean.", timestamp: "09:10 AM", sentiment: "Enthusiastic", confidence: 0.97, valence: 0.88, arousal: 0.82 },
  { id: 'u4', sender: "Alex Thorne", text: "But wait, for Pythagoras, are we subtracting the common cross-term from both sides of the large boundary?", timestamp: "09:18 AM", sentiment: "Skeptical", confidence: 0.78, valence: -0.10, arousal: 0.52 },
  { id: 'u5', sender: "Sneha Kapoor", text: "Exactly, subtract 2ab from both sides and you get left with just a^2 + b^2 = c^2!", timestamp: "09:19 AM", sentiment: "Enthusiastic", confidence: 0.95, valence: 0.85, arousal: 0.70 }
];

export const MultiModelEngagementAnalytics: React.FC<{
  theme: 'light' | 'dark';
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}> = ({ theme, showNotification }) => {
  const [selectedIdx, setSelectedIdx] = useState<number>(2); // Default to roadblock
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [customInputText, setCustomInputText] = useState<string>("");
  const [isParsingInput, setIsParsingInput] = useState<boolean>(false);
  const [customParsedResult, setCustomParsedResult] = useState<any | null>(null);
  
  const currentEvent = TIMELINE_DATA[selectedIdx];
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Auto playback of the study timeline
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        setSelectedIdx(prev => {
          if (prev >= TIMELINE_DATA.length - 1) {
            setIsPlaying(false);
            if (showNotification) {
              showNotification("Timeline simulation completed.", "success");
            }
            return 0;
          }
          return prev + 1;
        });
      }, 3500);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isPlaying]);

  // Generate interactive charts data based on timeline
  const chartData = TIMELINE_DATA.map((ev, idx) => ({
    timeLabel: ev.time.split(' ')[0],
    cognitiveLoad: ev.vocalStressIndex,
    errorRate: ev.keystrokeErrorRate,
    attention: ev.gazeTarget === 'Off-Screen' ? 38 : ev.gazeTarget === 'Peer Chat panel' ? 78 : 95,
    synergy: ev.synergyOverlap,
    mastery: ev.masteryIndex,
    wpm: ev.keystrokeWpm
  }));

  // Radar chart data for the 5 multi-model dimensions
  const radarData = [
    { name: 'Gaze Focus', value: currentEvent.gazeTarget === 'Off-Screen' ? 25 : currentEvent.gazeTarget === 'Peer Chat panel' ? 75 : 95 },
    { name: 'Input Cadence', value: currentEvent.keystrokeWpm > 60 ? 90 : currentEvent.keystrokeWpm > 40 ? 70 : 30 },
    { name: 'Vocal Presence', value: currentEvent.vocalAmplitudeDb > 60 ? 95 : currentEvent.vocalAmplitudeDb > 40 ? 75 : 40 },
    { name: 'Peer Synergy', value: currentEvent.synergyOverlap },
    { name: 'Mastery Speed', value: currentEvent.masteryIndex }
  ];

  // Custom AI analyzer simulator
  const handleParseCustomText = () => {
    if (!customInputText.trim()) return;
    setIsParsingInput(true);

    setTimeout(() => {
      const text = customInputText.toLowerCase();
      let primarySentiment = "Curious / Exploratory";
      let cognitiveLoadScore = 32;
      let sentimentValue = 0.45;
      let keywords: string[] = [];
      let recommendation = "";

      if (text.includes("stuck") || text.includes("error") || text.includes("fail") || text.includes("hard")) {
        primarySentiment = "Frustrated / Confused";
        cognitiveLoadScore = 84;
        sentimentValue = -0.68;
        keywords = ["block", "syntax error", "limits"];
        recommendation = "High cognitive stress with low input cadence. Provide an interactive diagrammatic breakdown and a socratic hint prompt.";
      } else if (text.includes("amazing") || text.includes("cool") || text.includes("solved") || text.includes("got it")) {
        primarySentiment = "Enthusiastic / Satisfied";
        cognitiveLoadScore = 15;
        sentimentValue = 0.92;
        keywords = ["euler", "geometry", "accomplishment"];
        recommendation = "Optimal flow state. Recommend advanced challenge assignments or invite student to assist peer Rohan Sharma in active chat.";
      } else {
        primarySentiment = "Skeptical / Questioning";
        cognitiveLoadScore = 55;
        sentimentValue = -0.12;
        keywords = ["how", "proof", "derivation"];
        recommendation = "Engaged Socratic processing. Highlight foundational axioms and support the student with guided deduction checkpoints.";
      }

      setCustomParsedResult({
        sentiment: primarySentiment,
        load: cognitiveLoadScore,
        score: sentimentValue,
        keywords,
        rec: recommendation
      });
      setIsParsingInput(false);
      
      if (showNotification) {
        showNotification("Linguistic analysis computed successfully.", "success");
      }
    }, 1500);
  };

  return (
    <div className="flex flex-col gap-6 w-full text-left">
      
      {/* Tab Title Banner */}
      <div className="p-4 bg-indigo-50 dark:bg-indigo-950/20 rounded-2xl border border-indigo-100 dark:border-indigo-900/30 flex flex-col gap-1.5 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-sm font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
            <Sliders size={16} /> Educator Multi-Model Engagement Suite
          </h2>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal">
            Synthesize student ocular focus, cognitive typing rhythm, audio prosody, peer whiteboard synergy, and mastery timelines.
          </p>
        </div>
        
        {/* Playback Simulation Controller */}
        <button
          onClick={() => {
            setIsPlaying(!isPlaying);
            if (showNotification) {
              showNotification(isPlaying ? "Timeline playback paused." : "Starting live session telemetry simulation.", "info");
            }
          }}
          className={`px-3.5 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider cursor-pointer flex items-center gap-1.5 transition-all self-start md:self-auto ${
            isPlaying 
              ? 'bg-red-500 text-white animate-pulse' 
              : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm'
          }`}
        >
          {isPlaying ? (
            <>
              <Pause size={11} className="fill-white" /> Pause Telemetry
            </>
          ) : (
            <>
              <Play size={11} className="fill-white" /> Play Session Run
            </>
          )}
        </button>
      </div>

      {/* Grid: Timeline and Dials */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Horizontal Timeline Block (Col 8) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          
          {/* Interactive Timeline Stream */}
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col justify-between">
            <div className="flex justify-between items-center mb-3">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">
                Session Interactive Timeline (Scrubbing Axis)
              </span>
              <span className="text-[8px] font-bold text-indigo-500 dark:text-indigo-400 font-mono">
                Click nodes or press Play to scrub time
              </span>
            </div>

            {/* Timeline track */}
            <div className="relative my-6 px-4">
              <div className="absolute top-1/2 left-0 right-0 h-1 bg-slate-100 dark:bg-slate-800 transform -translate-y-1/2 rounded-full" />
              <div 
                className="absolute top-1/2 left-0 h-1 bg-indigo-500 transform -translate-y-1/2 rounded-full transition-all duration-300"
                style={{ width: `${(selectedIdx / (TIMELINE_DATA.length - 1)) * 100}%` }}
              />

              <div className="flex justify-between relative z-10">
                {TIMELINE_DATA.map((ev, idx) => {
                  const isActive = idx === selectedIdx;
                  const isPast = idx < selectedIdx;
                  
                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        setSelectedIdx(idx);
                        setIsPlaying(false);
                      }}
                      className="flex flex-col items-center gap-1.5 focus:outline-none cursor-pointer group"
                    >
                      <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                        isActive
                          ? 'bg-indigo-600 border-indigo-600 text-white scale-110 shadow-lg shadow-indigo-500/20'
                          : isPast
                            ? 'bg-indigo-50 border-indigo-400 text-indigo-500 dark:bg-slate-800'
                            : 'bg-white border-slate-200 text-slate-400 dark:bg-slate-900 dark:border-slate-800 hover:border-slate-400'
                      }`}>
                        <span className="text-xs font-black font-mono">{idx + 1}</span>
                      </div>
                      
                      <div className="text-center">
                        <span className={`text-[8px] font-black block leading-none ${
                          isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'
                        }`}>
                          {ev.time.split(' ')[0]}
                        </span>
                        <span className="text-[7px] font-mono text-slate-400 group-hover:text-slate-600 block max-w-[64px] truncate">
                          {ev.title.split(' ')[0]}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Dynamic event description card */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-850/60 rounded-xl border border-slate-150 dark:border-slate-800/80 mt-2">
              <div className="flex justify-between items-start gap-2 mb-1.5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-[8px] font-black uppercase tracking-wider">
                      {currentEvent.category} event
                    </span>
                    <h3 className="text-xs font-black text-slate-850 dark:text-white">
                      {currentEvent.title}
                    </h3>
                  </div>
                  <span className="text-[8px] font-mono text-slate-400 mt-0.5 block">Session time offset: {currentEvent.timestampSec} seconds</span>
                </div>
                
                {/* Sentiment Stamp */}
                <div className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                  currentEvent.sentimentScore > 0.4 ? 'bg-emerald-500/10 text-emerald-500' :
                  currentEvent.sentimentScore < 0 ? 'bg-rose-500/10 text-rose-500' :
                  'bg-amber-500/10 text-amber-500'
                }`}>
                  Linguistic Tone: {currentEvent.sentimentLabel}
                </div>
              </div>

              <p className="text-[10px] text-slate-650 dark:text-slate-300 leading-normal mb-3">
                {currentEvent.description}
              </p>

              {/* Actionable Pedagogical Advice */}
              <div className="p-2.5 bg-indigo-500/5 dark:bg-indigo-500/10 border border-indigo-500/20 rounded-lg flex items-start gap-2">
                <Sparkles size={13} className="text-indigo-500 shrink-0 mt-0.5" />
                <div className="text-[9px] text-slate-600 dark:text-slate-350 leading-relaxed">
                  <strong className="text-indigo-600 dark:text-indigo-400 font-extrabold uppercase tracking-wide">AI Recommendation: </strong> 
                  {currentEvent.pedagogicalTip}
                </div>
              </div>
            </div>

          </div>

          {/* Area charts overlaying key values */}
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-3">
              Session Analytics Area Streams (Trend Charts)
            </span>
            
            <div className="h-[140px] w-full">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <AreaChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorCognitive" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#818cf8" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#818cf8" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorErrors" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="timeLabel" style={{ fontSize: '8px', fontFamily: 'monospace' }} />
                  <YAxis style={{ fontSize: '8px', fontFamily: 'monospace' }} />
                  <Tooltip contentStyle={{ fontSize: '10px', borderRadius: '8px', backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff' }} />
                  <Area type="monotone" name="Cognitive Load" dataKey="cognitiveLoad" stroke="#818cf8" fillOpacity={1} fill="url(#colorCognitive)" strokeWidth={2} />
                  <Area type="monotone" name="Input Roadblock %" dataKey="errorRate" stroke="#f43f5e" fillOpacity={1} fill="url(#colorErrors)" strokeWidth={1.5} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            
            <div className="flex gap-4 items-center justify-center text-[8px] font-black text-slate-400 font-mono mt-2">
              <span className="flex items-center gap-1"><span className="w-2.5 h-1 bg-indigo-400 rounded" /> COGNITIVE LOAD INDEX (PUPIL DILATION & VOCAL PITCH)</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-1 bg-rose-400 rounded" /> KEYBOARD ERROR RATE (BACKSPACE DYNAMICS)</span>
            </div>
          </div>

        </div>

        {/* 5 Multi-Model Analytics Sensors Dials (Col 4) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          
          {/* Radar Mastery mapping */}
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col justify-between">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">
              5-Core Multi-Model Telemetry
            </span>
            
            <div className="h-[180px] w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                  <PolarGrid stroke={theme === 'dark' ? '#1e293b' : '#e2e8f0'} />
                  <PolarAngleAxis dataKey="name" style={{ fontSize: '8px', fontWeight: 'bold' }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} style={{ fontSize: '6px' }} />
                  <Radar 
                    name="Student Profile" 
                    dataKey="value" 
                    stroke="#4f46e5" 
                    fill="#818cf8" 
                    fillOpacity={0.35} 
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>

            <div className="border-t border-slate-100 dark:border-slate-800 pt-2 text-[8px] font-mono text-slate-500 leading-normal">
              <strong>Sensor Fusion Algorithm:</strong> Combines micro-movements, acoustic frequencies, verbal semantics, and cursor synergy calculations into 5 real-time streams.
            </div>
          </div>

          {/* Real-time Dials Inspector */}
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col gap-3">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">
              Sensor Diagnostics Inspector
            </span>

            {/* Sensor 1: Gaze Focus Target */}
            <div className="flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800/80">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                  <Eye size={14} />
                </div>
                <div>
                  <span className="text-[9px] font-black text-slate-400 block uppercase leading-none mb-0.5">1. Eye Gaze Target</span>
                  <span className="text-[10px] font-bold text-slate-750 dark:text-slate-200">{currentEvent.gazeTarget}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[11px] font-mono font-bold text-indigo-500">
                  [{currentEvent.gazeX}, {currentEvent.gazeY}]
                </span>
                <span className="text-[7px] text-slate-400 block">Coordinates</span>
              </div>
            </div>

            {/* Sensor 2: Keystroke Speed */}
            <div className="flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800/80">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                  <Activity size={14} />
                </div>
                <div>
                  <span className="text-[9px] font-black text-slate-400 block uppercase leading-none mb-0.5">2. Keystroke Dynamics</span>
                  <span className="text-[10px] font-bold text-slate-750 dark:text-slate-200">{currentEvent.keystrokeWpm} Words/Min</span>
                </div>
              </div>
              <div className="text-right">
                <span className={`text-[11px] font-mono font-bold ${
                  currentEvent.keystrokeErrorRate > 30 ? 'text-red-500' : 'text-emerald-500'
                }`}>
                  {currentEvent.keystrokeErrorRate}%
                </span>
                <span className="text-[7px] text-slate-400 block">Backspace error</span>
              </div>
            </div>

            {/* Sensor 3: Vocal Acoustics */}
            <div className="flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800/80">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center">
                  <Volume2 size={14} />
                </div>
                <div>
                  <span className="text-[9px] font-black text-slate-400 block uppercase leading-none mb-0.5">3. Vocal Prosody (Audio)</span>
                  <span className="text-[10px] font-bold text-slate-750 dark:text-slate-200">{currentEvent.vocalPitchHz} Hz Frequency</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[11px] font-mono font-bold text-slate-700 dark:text-slate-200">
                  {currentEvent.vocalAmplitudeDb} dB
                </span>
                <span className="text-[7px] text-slate-400 block">Amplitude</span>
              </div>
            </div>

            {/* Sensor 4: Workspace Synchronicity */}
            <div className="flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800/80">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-pink-500/10 text-pink-500 flex items-center justify-center">
                  <Users size={14} />
                </div>
                <div>
                  <span className="text-[9px] font-black text-slate-400 block uppercase leading-none mb-0.5">4. Peer Whiteboard Synergy</span>
                  <span className="text-[10px] font-bold text-slate-750 dark:text-slate-200">Cursor Proximity Sync</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[11px] font-mono font-bold text-pink-500">
                  {currentEvent.synergyOverlap}%
                </span>
                <span className="text-[7px] text-slate-400 block">Co-presence overlap</span>
              </div>
            </div>

            {/* Sensor 5: Mastery Linkage Speed */}
            <div className="flex items-center justify-between p-2 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800/80">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
                  <Award size={14} />
                </div>
                <div>
                  <span className="text-[9px] font-black text-slate-400 block uppercase leading-none mb-0.5">5. Inter-domain Linkage</span>
                  <span className="text-[10px] font-bold text-slate-750 dark:text-slate-200">Conceptual Overlap Speed</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[11px] font-mono font-bold text-indigo-500">
                  {currentEvent.masteryIndex}%
                </span>
                <span className="text-[7px] text-slate-400 block">Schema convergence</span>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Section 2: Semantic Sentiment Report & Realtime Text Analyzer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 border-t border-slate-200 dark:border-slate-850 pt-6">
        
        {/* Semantic Sentiment Report (Col 7) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex-1 flex flex-col">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-1">
              <MessageSquare size={14} className="text-indigo-500" /> Semantic Sentiment Report (Linguistic Parsing)
            </h3>
            <p className="text-[10px] text-slate-500 mb-4 leading-normal">
              Continuous natural language processing on collaborative chat rooms, identifying emotional valence and conceptual stalling indicators.
            </p>

            {/* Valence & Arousal Quadrant mapping */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              
              <div className="p-3.5 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800/80">
                <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-2">
                  Linguistic Transcript Analysis
                </span>
                
                <div className="flex flex-col gap-2 max-h-[220px] overflow-y-auto pr-1">
                  {TRANSCRIBED_CHAT_SAMPLES.map((transcript) => (
                    <div key={transcript.id} className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-150 dark:border-slate-800 flex flex-col gap-1">
                      <div className="flex justify-between items-center text-[8px] font-bold">
                        <span className="text-indigo-500">{transcript.sender}</span>
                        <span className={`px-1.5 py-0.5 rounded ${
                          transcript.sentiment === 'Enthusiastic' ? 'bg-emerald-500/10 text-emerald-500' :
                          transcript.sentiment === 'Confused' ? 'bg-rose-500/10 text-rose-500' :
                          'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                        }`}>
                          {transcript.sentiment} ({Math.round(transcript.confidence * 100)}%)
                        </span>
                      </div>
                      <p className="text-[10px] italic text-slate-650 dark:text-slate-300">
                        "{transcript.text}"
                      </p>
                      <div className="flex gap-2 text-[7px] font-mono text-slate-400">
                        <span>Valence: <strong>{transcript.valence}</strong></span>
                        <span>•</span>
                        <span>Arousal: <strong>{transcript.arousal}</strong></span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Affective mapping dial/quadrant */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800/80 flex flex-col justify-between">
                <div>
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1">
                    Affective State Quadrant Map
                  </span>
                  <p className="text-[8px] text-slate-500 leading-tight">
                    Maps verbal sentiment on a psychological dimensional grid (Positive/Negative Valence vs. High/Low Arousal).
                  </p>
                </div>

                <div className="relative w-full h-[120px] border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 my-2 overflow-hidden flex items-center justify-center">
                  {/* Quadrant lines */}
                  <div className="absolute inset-x-0 h-px bg-slate-200 dark:bg-slate-700" style={{ top: '50%' }} />
                  <div className="absolute inset-y-0 w-px bg-slate-200 dark:bg-slate-700" style={{ left: '50%' }} />
                  
                  {/* Axis labels */}
                  <span className="absolute top-1 text-[7px] font-black text-slate-400 uppercase">High Arousal (Excited)</span>
                  <span className="absolute bottom-1 text-[7px] font-black text-slate-400 uppercase">Low Arousal (Calm)</span>
                  <span className="absolute right-1 text-[7px] font-black text-slate-400 uppercase rotate-90 origin-right translate-y-3">Positive Valence</span>
                  <span className="absolute left-1 text-[7px] font-black text-slate-400 uppercase -rotate-90 origin-left -translate-y-3">Negative Valence</span>

                  {/* Points mapping */}
                  {TRANSCRIBED_CHAT_SAMPLES.map((tr, tIdx) => {
                    // map -1 to 1 valence to percentage (0% to 100%)
                    const posX = ((tr.valence + 1) / 2) * 80 + 10; // offset inside boundaries
                    const posY = (1 - (tr.arousal)) * 80 + 10; // invert Y for arousal (high is top)
                    
                    return (
                      <div 
                        key={tr.id}
                        className="absolute w-3 h-3 rounded-full border-2 border-white shadow-md flex items-center justify-center cursor-help group/dot"
                        style={{ left: `${posX}%`, top: `${posY}%`, backgroundColor: tr.sentiment === 'Enthusiastic' ? '#10b981' : tr.sentiment === 'Confused' ? '#f43f5e' : '#6b7280' }}
                      >
                        <div className="hidden group-hover/dot:block absolute z-50 p-2 bg-slate-950 text-white rounded text-[8px] font-bold bottom-4 w-28 text-left border border-slate-800">
                          <strong>{tr.sender}</strong>: {tr.sentiment}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <span className="text-[7px] font-mono text-slate-400 text-center block">
                  🟢 Green = Enthusiastic | 🔴 Red = Confused | ⚫ Grey = Socratic
                </span>
              </div>

            </div>

          </div>
        </div>

        {/* Real-time Text Analyzer / NLP engine simulator (Col 5) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex-1 flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-1">
                <Terminal size={14} className="text-indigo-500" /> Interactive Linguistic Analyzer
              </h3>
              <p className="text-[10px] text-slate-500 mb-3.5 leading-normal">
                Paste student essay responses, study journal notes, or peer discussion logs to test the linguistic sentiment engine immediately.
              </p>

              <textarea
                value={customInputText}
                onChange={(e) => setCustomInputText(e.target.value)}
                placeholder="Paste student notes, e.g. 'I am completely stuck on Taylor series, the division steps make absolutely no sense and I keep deleting my attempts...' or 'I finally solved the visual pythagorean puzzle! Connecting geometry to equations makes it incredibly easy.'"
                className="w-full p-3 h-[90px] bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl text-[11px] outline-none font-sans dark:text-white focus:border-indigo-500 leading-normal resize-none"
              />

              <button
                onClick={handleParseCustomText}
                disabled={isParsingInput || !customInputText.trim()}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-black uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-sm mt-3.5"
              >
                {isParsingInput ? (
                  <RefreshCw size={12} className="animate-spin" />
                ) : (
                  <Sparkles size={12} className="animate-pulse" />
                )}
                {isParsingInput ? "Running AI Semantic Analysis..." : "Run Linguistic Semantic Scan"}
              </button>
            </div>

            {/* Analysis results */}
            <AnimatePresence mode="wait">
              {customParsedResult ? (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="p-3 bg-indigo-500/5 border border-indigo-500/15 rounded-xl text-[10px] flex flex-col gap-2 mt-4"
                >
                  <div className="flex justify-between items-center pb-1.5 border-b border-indigo-500/10">
                    <span className="font-black text-indigo-400 uppercase tracking-widest block">AI Diagnostic Scan Output</span>
                    <span className="text-[8px] bg-indigo-500/25 text-indigo-500 dark:text-indigo-300 px-1.5 py-0.5 rounded font-black font-mono">NLP ONLINE</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div>
                      <span className="text-slate-400 block text-[8px] uppercase font-black">Affective Sentiment</span>
                      <strong className="text-slate-700 dark:text-slate-200">{customParsedResult.sentiment}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[8px] uppercase font-black">Linguistic Valence</span>
                      <strong className={customParsedResult.score < 0 ? 'text-rose-500' : 'text-emerald-500'}>
                        {customParsedResult.score > 0 ? '+' : ''}{customParsedResult.score}
                      </strong>
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[8px] uppercase font-black">Extracted Semantic Vectors</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {customParsedResult.keywords.map((kw: string, kIdx: number) => (
                        <span key={kIdx} className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[8px] font-mono text-slate-600 dark:text-slate-400">
                          #{kw}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="p-2 bg-indigo-500/10 rounded border border-indigo-500/10 text-[9px] text-slate-600 dark:text-slate-350 leading-relaxed">
                    <strong>Suggested Action: </strong> {customParsedResult.rec}
                  </div>
                </motion.div>
              ) : (
                <div className="p-4 bg-slate-50 dark:bg-slate-850/40 border border-slate-150 dark:border-slate-800/60 rounded-xl text-center text-[10px] text-slate-400 mt-4">
                  No scan compiled. Paste sample utterances in the field above to run continuous diagnostic evaluations.
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>

      </div>

    </div>
  );
};
