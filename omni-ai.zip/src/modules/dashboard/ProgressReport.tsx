import React from 'react';

export const ProgressReport: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-bold text-white">Progress Report</h2>
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
        <h3 className="text-lg font-semibold text-white">Monthly Summary</h3>
        <p className="text-slate-400">Consistent growth in physics performance.</p>
      </div>
    </div>
  );
};
