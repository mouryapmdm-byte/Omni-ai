import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  GraduationCap, 
  HeartHandshake, 
  Zap, 
  Brain, 
  Sparkles, 
  Sliders, 
  Check, 
  MessageSquare, 
  Wand2, 
  RotateCcw, 
  Volume2, 
  Info, 
  ShieldAlert, 
  Flame, 
  HelpCircle, 
  BookOpen, 
  Target, 
  Compass, 
  CheckCircle2,
  ChevronRight,
  Play
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { TutorPersonaConfig, PersonaArchetype, FeedbackTone } from '@/src/types';

export const DEFAULT_PERSONA_PRESETS: Record<PersonaArchetype, TutorPersonaConfig> = {
  professor_clarity: {
    archetype: 'professor_clarity',
    name: 'Professor Clarity (6-Feature Master Educator)',
    avatarIcon: 'GraduationCap',
    socraticIntensity: 4,
    feedbackTone: 'balanced_encouragement',
    inquiryRatio: 50,
    rigorLevel: 90,
    energyLevel: 85,
    analogyDensity: 95,
    customInstructions: 'Structure every single lesson using all 6 Core Features: Hook & Big Picture, Foundational Concept Build, Labelled Diagram with [→ Animation] markers, 4-Pillar Deep Dive, 4 Utilities (Clarity, Academic, Competitive, General), and the Mastery Toolkit.'
  },
  strict_academic: {
    archetype: 'strict_academic',
    name: 'Professor Clarity (Strict Academic)',
    avatarIcon: 'GraduationCap',
    socraticIntensity: 3,
    feedbackTone: 'constructive_critique',
    inquiryRatio: 35,
    rigorLevel: 95,
    energyLevel: 30,
    analogyDensity: 25,
    customInstructions: 'Focus on rigorous derivations, formal LaTeX notation, precise academic vocabulary, and scholarly boardwork.'
  },
  gentle_mentor: {
    archetype: 'gentle_mentor',
    name: 'Dr. Omni (Gentle Mentor)',
    avatarIcon: 'HeartHandshake',
    socraticIntensity: 3,
    feedbackTone: 'balanced_encouragement',
    inquiryRatio: 60,
    rigorLevel: 65,
    energyLevel: 55,
    analogyDensity: 75,
    customInstructions: 'Provide empathetic step-by-step guidance, warm encouragement, patience, and gentle low-stakes checkpoints.'
  },
  high_energy: {
    archetype: 'high_energy',
    name: 'Coach Omni (High-Energy)',
    avatarIcon: 'Zap',
    socraticIntensity: 2,
    feedbackTone: 'high_energy_praise',
    inquiryRatio: 50,
    rigorLevel: 70,
    energyLevel: 95,
    analogyDensity: 65,
    customInstructions: 'Maintain high momentum, dynamic motivational tone, enthusiastic feedback, quick quizzes, and action-oriented energy!'
  },
  socratic_specialist: {
    archetype: 'socratic_specialist',
    name: 'Socrates Omni (Inquiry Specialist)',
    avatarIcon: 'Brain',
    socraticIntensity: 5,
    feedbackTone: 'challenging_probe',
    inquiryRatio: 95,
    rigorLevel: 85,
    energyLevel: 65,
    analogyDensity: 50,
    customInstructions: 'Never reveal answers directly. Ask targeted probing questions to guide the learner to self-discovery and deep inquiry.'
  },
  conceptual_storyteller: {
    archetype: 'conceptual_storyteller',
    name: 'Omni Storyteller (Visual Analogies)',
    avatarIcon: 'Sparkles',
    socraticIntensity: 3,
    feedbackTone: 'balanced_encouragement',
    inquiryRatio: 45,
    rigorLevel: 50,
    energyLevel: 80,
    analogyDensity: 95,
    customInstructions: 'Use vivid real-world analogies, historical contexts, intuitive visual metaphors, and narrative hooks before formulas.'
  },
  custom: {
    archetype: 'custom',
    name: 'Custom Tailored Persona',
    avatarIcon: 'Sliders',
    socraticIntensity: 3,
    feedbackTone: 'balanced_encouragement',
    inquiryRatio: 50,
    rigorLevel: 50,
    energyLevel: 50,
    analogyDensity: 50,
    customInstructions: ''
  }
};

const SOCRATIC_LEVEL_DESCRIPTIONS: Record<number, { title: string; desc: string; badge: string; color: string }> = {
  1: {
    title: 'Direct & Explicit',
    desc: 'Provides direct explanations and full solutions immediately, followed by brief summary checks.',
    badge: 'Level 1 • Direct',
    color: 'from-blue-500 to-cyan-500'
  },
  2: {
    title: 'Guided Overview',
    desc: 'Explains core concepts first, then poses 1 verification question to test immediate retention.',
    badge: 'Level 2 • Overview + Check',
    color: 'from-teal-500 to-emerald-500'
  },
  3: {
    title: 'Balanced Scaffolding',
    desc: 'Provides key hints and step-by-step guidance, encouraging the learner to solve each step.',
    badge: 'Level 3 • Balanced',
    color: 'from-amber-500 to-emerald-500'
  },
  4: {
    title: 'Probing Inquirer',
    desc: 'Asks targeted leading questions before revealing formulas or mathematical procedures.',
    badge: 'Level 4 • Probing',
    color: 'from-orange-500 to-amber-500'
  },
  5: {
    title: 'Deep Socratic Inquiry',
    desc: 'Never gives direct answers. Uses pure guided inquiry to lead student to complete self-discovery.',
    badge: 'Level 5 • Pure Socratic',
    color: 'from-indigo-500 to-purple-500'
  }
};

const FEEDBACK_TONE_OPTIONS: { id: FeedbackTone; title: string; desc: string; icon: React.ReactNode; badgeColor: string }[] = [
  {
    id: 'constructive_critique',
    title: 'Scholarly Critique',
    desc: 'Rigorous analysis focusing on technical accuracy, formal notation, and correcting edge cases.',
    icon: <GraduationCap className="w-4 h-4 text-blue-400" />,
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/30'
  },
  {
    id: 'balanced_encouragement',
    title: 'Balanced & Empathetic',
    desc: 'Validates correct intuition first, then provides gentle hints to fix misconceptions.',
    icon: <HeartHandshake className="w-4 h-4 text-emerald-400" />,
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30'
  },
  {
    id: 'high_energy_praise',
    title: 'High-Energy Coach',
    desc: 'Enthusiastic, celebratory praise when correct, highly motivating and action-focused when stuck.',
    icon: <Flame className="w-4 h-4 text-amber-400" />,
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-400/30'
  },
  {
    id: 'challenging_probe',
    title: 'Challenging Counter-Probe',
    desc: 'Pushes boundaries by posing "What if?" counter-examples and deeper conceptual paradoxes.',
    icon: <Target className="w-4 h-4 text-purple-400" />,
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-400/30'
  }
];

export interface TutorPersonaWizardModalProps {
  currentPersona?: TutorPersonaConfig;
  initialConfig?: TutorPersonaConfig;
  initialPersona?: TutorPersonaConfig;
  onSavePersona: (persona: TutorPersonaConfig) => void;
  onClose?: () => void;
  theme?: 'light' | 'dark' | 'blackboard';
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
}

export const TutorPersonaWizardModal: React.FC<TutorPersonaWizardModalProps> = ({
  currentPersona,
  initialConfig,
  initialPersona,
  onSavePersona,
  onClose,
  theme = 'blackboard',
  showNotification
}) => {
  const activeInitial = currentPersona || initialConfig || initialPersona;
  const [config, setConfig] = useState<TutorPersonaConfig>(() => {
    return activeInitial || DEFAULT_PERSONA_PRESETS.strict_academic;
  });

  const [activeStep, setActiveStep] = useState<'archetype' | 'scaffolding' | 'playground'>('archetype');
  const [sampleQuestion, setSampleQuestion] = useState('Why does light bend when entering a glass block?');
  const [simulatedResponse, setSimulatedResponse] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const handleSelectArchetype = (archetype: PersonaArchetype) => {
    const preset = DEFAULT_PERSONA_PRESETS[archetype];
    setConfig(preset);
  };

  const handleReset = () => {
    setConfig(DEFAULT_PERSONA_PRESETS.strict_academic);
    showNotification?.('Reset tutor persona to Strict Academic default', 'info');
  };

  const handleSave = () => {
    onSavePersona(config);
    try {
      localStorage.setItem('omni_tutor_persona_config', JSON.stringify(config));
    } catch {
      // ignore localstorage errors
    }
    showNotification?.(`Applied Tutor Persona: ${config.name}!`, 'success');
    if (onClose) onClose();
  };

  // Generate a live simulated tutor response based on configured persona & sample question
  const generateSimulatedPreview = () => {
    setIsSimulating(true);
    setSimulatedResponse(null);

    setTimeout(() => {
      let previewText = '';

      if (config.archetype === 'strict_academic') {
        previewText = `### 🎓 Professor Clarity's Boardwork Analysis\n\nTo analyze why light refracts upon entering a dielectric glass medium of refractive index $n > 1$, we begin with **Fermat's Principle of Least Time** and the phase velocity of electromagnetic waves:\n\n$$v = \\frac{c}{n} \\implies v < c$$\n\nAs the wave front encounters the optical boundary at an angle of incidence $\\theta_i$, the reduction in wave propagation speed causes a spatial tilt in the phase fronts, yielding **Snell's Law of Refraction**:\n\n$$n_1 \\sin\\theta_1 = n_2 \\sin\\theta_2$$\n\n**Blackboard Verification Check:** What happens to the wavelength $\\lambda$ inside the glass while the frequency $f$ remains strictly constant?`;
      } else if (config.archetype === 'gentle_mentor') {
        previewText = `### 🤝 Warm Welcome! Let's explore this together...\n\nGreat question! Think of a rolling toy car moving from a smooth hardwood floor onto a thick plush rug at an angle.\n\nWhen the front-right wheel hits the rug first, it slows down before the left wheel does. What do you think happens to the direction of the car as a result?\n\nThat's exactly what happens to light waves entering glass! Light travels slightly slower in denser glass ($v = c/n$), causing the wave to bend toward the normal. \n\nHow does this mental picture feel to you? Would you like to try predicting what happens when it exits back into air?`;
      } else if (config.archetype === 'high_energy') {
        previewText = `### ⚡ High-Energy Physics Challenge! 🔥\n\nBoom! You've hit one of the most exciting phenomena in wave optics! 🚀\n\nHere's the core speed breakdown: Light is a cosmic speed demon at $3 \\times 10^8\\text{ m/s}$ in vacuum, but glass acts like an optical obstacle course! It slows down light to roughly $2 \\times 10^8\\text{ m/s}$!\n\nBecause the light enters at an angle, one edge hits the glass first and brakes earlier than the rest of the beam — causing the entire beam to pivot!\n\n⚡ **Quick Fire Quiz:** If light hits the glass straight on at $90^\\circ$ (along the normal), does it still bend? What's your call? Let's go!`;
      } else if (config.archetype === 'socratic_specialist') {
        previewText = `### 🧠 Socratic Inquiry Probe\n\nLet's discover the answer together! Before we look at light itself, consider this scenario:\n\n1. Imagine two runners holding a long rigid pole side-by-side, running at full speed on dry pavement.\n2. Suddenly, Runner A steps into deep mud while Runner B is still on dry pavement.\n\n*What will happen to the direction of the pole they are holding?*\n\nTake a moment to describe what happens to the pole's trajectory, and how that might relate to a beam of light crossing from air into glass.`;
      } else if (config.archetype === 'conceptual_storyteller') {
        previewText = `### 🎨 The Story of Light's March\n\nPicture a vast marching band marching in flawless parallel rows across a smooth paved parade ground.\n\nSuddenly, the band marches diagonally into a muddy field. The musicians on the right flank step into the mud first and their marching pace instantly slows down, while the musicians on the left flank are still striding quickly on dry pavement.\n\nThe entire marching line pivots at the boundary!\n\nIn our universe, light is the ultimate marching band of electromagnetic ripples. Glass is the optical "mud" that reduces light's phase speed, bending the beam.`;
      } else {
        previewText = `### ⚙️ Tailored Persona Response\n\n**Custom Settings:** Socratic Level ${config.socraticIntensity} / Rigor ${config.rigorLevel}% / Energy ${config.energyLevel}%\n\nLight bends when entering glass due to the change in propagation speed between air ($n_1 \\approx 1.0$) and glass ($n_2 \\approx 1.5$). By Snell's Law ($n_1 \\sin\\theta_1 = n_2 \\sin\\theta_2$), the light ray bends toward the normal line.\n\n**Checkpoint:** How would you derive the critical angle $\\theta_c$ for total internal reflection?`;
      }

      setSimulatedResponse(previewText);
      setIsSimulating(false);
    }, 600);
  };

  const getArchetypeIcon = (archetype: PersonaArchetype) => {
    switch (archetype) {
      case 'strict_academic': return <GraduationCap className="w-5 h-5 text-blue-400" />;
      case 'gentle_mentor': return <HeartHandshake className="w-5 h-5 text-emerald-400" />;
      case 'high_energy': return <Zap className="w-5 h-5 text-amber-400" />;
      case 'socratic_specialist': return <Brain className="w-5 h-5 text-purple-400" />;
      case 'conceptual_storyteller': return <Sparkles className="w-5 h-5 text-rose-400" />;
      case 'custom': return <Sliders className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <div className="flex flex-col h-full max-w-5xl mx-auto text-slate-100">
      {/* Header Banner */}
      <div className="p-4 sm:p-6 bg-slate-900/90 border-b border-emerald-500/30 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-emerald-500/30 via-indigo-500/20 to-amber-500/20 border border-emerald-400/40 shadow-inner">
            <Wand2 className="w-6 h-6 text-emerald-300 animate-pulse" />
          </div>
          <div>
            <div className="text-[10px] font-mono font-extrabold uppercase tracking-widest text-emerald-400 flex items-center gap-1.5">
              <span>🎓 PEDAGOGY ENGINE</span>
              <span>•</span>
              <span>PERSONA & SOCRATIC WIZARD</span>
            </div>
            <h2 className="text-xl font-black text-white tracking-wide flex items-center gap-2">
              <span>Interactive AI Tutor Persona Customization</span>
            </h2>
          </div>
        </div>

        {/* Step Navigation Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveStep('archetype')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              activeStep === 'archetype' 
                ? "bg-emerald-500 text-slate-950 shadow-md font-extrabold" 
                : "text-slate-400 hover:text-slate-200"
            )}
          >
            <span>1. Teaching Archetypes</span>
          </button>
          <button
            onClick={() => setActiveStep('scaffolding')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              activeStep === 'scaffolding' 
                ? "bg-emerald-500 text-slate-950 shadow-md font-extrabold" 
                : "text-slate-400 hover:text-slate-200"
            )}
          >
            <span>2. Scaffolding & Sliders</span>
          </button>
          <button
            onClick={() => {
              setActiveStep('playground');
              if (!simulatedResponse) generateSimulatedPreview();
            }}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              activeStep === 'playground' 
                ? "bg-emerald-500 text-slate-950 shadow-md font-extrabold" 
                : "text-slate-400 hover:text-slate-200"
            )}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>3. Live Simulator</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 bg-slate-950/80">
        <AnimatePresence mode="wait">
          {/* STEP 1: ARCHETYPE SELECTION */}
          {activeStep === 'archetype' && (
            <motion.div
              key="step-archetype"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
              className="space-y-6"
            >
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <Compass className="w-5 h-5 text-emerald-400" />
                  <span>Choose Your AI Tutor's Teaching Archetype</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Select a pre-configured teaching style below. Each archetype automatically adjusts Socratic scaffolding depth, feedback tone, and explanation style.
                </p>
              </div>

              {/* Grid of Archetype Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(Object.keys(DEFAULT_PERSONA_PRESETS) as PersonaArchetype[]).map((archetype) => {
                  const preset = DEFAULT_PERSONA_PRESETS[archetype];
                  const isSelected = config.archetype === archetype;

                  return (
                    <motion.div
                      key={archetype}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleSelectArchetype(archetype)}
                      className={cn(
                        "p-5 rounded-2xl border-2 transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between space-y-4",
                        isSelected 
                          ? "bg-slate-900 border-emerald-400 shadow-[0_0_25px_rgba(16,185,129,0.25)]" 
                          : "bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80"
                      )}
                    >
                      {/* Top Selection Ribbon */}
                      {isSelected && (
                        <div className="absolute top-3 right-3 p-1 rounded-full bg-emerald-500 text-slate-950 shadow-md">
                          <Check className="w-4 h-4 stroke-[3]" />
                        </div>
                      )}

                      <div className="space-y-2.5">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 shadow-inner">
                            {getArchetypeIcon(archetype)}
                          </div>
                          <div>
                            <h4 className="text-sm font-bold text-white">{preset.name}</h4>
                            <span className="text-[10px] font-mono text-emerald-400/90 font-semibold uppercase tracking-wider">
                              Socratic Level {preset.socraticIntensity}/5
                            </span>
                          </div>
                        </div>

                        <p className="text-xs text-slate-300 leading-relaxed">
                          {preset.customInstructions || "Tailored pedagogy parameters with custom slider configuration."}
                        </p>
                      </div>

                      {/* Stat Metrics Pills */}
                      <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-800/80 text-[11px] font-mono">
                        <div className="bg-slate-950/80 p-2 rounded-lg border border-slate-800 flex justify-between items-center">
                          <span className="text-slate-400">Inquiry:</span>
                          <span className="text-amber-300 font-bold">{preset.inquiryRatio}%</span>
                        </div>
                        <div className="bg-slate-950/80 p-2 rounded-lg border border-slate-800 flex justify-between items-center">
                          <span className="text-slate-400">Rigor:</span>
                          <span className="text-cyan-300 font-bold">{preset.rigorLevel}%</span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {/* Next Step CTA */}
              <div className="flex justify-end pt-4">
                <button
                  onClick={() => setActiveStep('scaffolding')}
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-all shadow-lg flex items-center gap-2 cursor-pointer"
                >
                  <span>Continue to Scaffolding Sliders</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 2: SCAFFOLDING & SLIDERS */}
          {activeStep === 'scaffolding' && (
            <motion.div
              key="step-scaffolding"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
              className="space-y-6"
            >
              {/* Socratic Scaffolding Intensity Slider */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-emerald-500/30 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-indigo-400" />
                    <h3 className="text-sm font-bold text-white">Socratic Scaffolding Intensity</h3>
                  </div>
                  <span className={cn(
                    "px-3 py-1 rounded-full text-xs font-mono font-extrabold border bg-gradient-to-r text-white shadow-md",
                    SOCRATIC_LEVEL_DESCRIPTIONS[config.socraticIntensity].color
                  )}>
                    {SOCRATIC_LEVEL_DESCRIPTIONS[config.socraticIntensity].badge}
                  </span>
                </div>

                <div className="space-y-2">
                  <input
                    type="range"
                    min="1"
                    max="5"
                    step="1"
                    value={config.socraticIntensity}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      setConfig(prev => ({
                        ...prev,
                        archetype: 'custom',
                        socraticIntensity: val
                      }));
                    }}
                    className="w-full accent-emerald-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] font-mono text-slate-400 px-1">
                    <span>1 (Direct Answers)</span>
                    <span>2 (Guided Check)</span>
                    <span>3 (Balanced)</span>
                    <span>4 (Probing)</span>
                    <span>5 (Pure Socratic)</span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 bg-slate-950/80 p-3 rounded-xl border border-slate-800 leading-relaxed">
                  <strong className="text-amber-300 font-mono">{SOCRATIC_LEVEL_DESCRIPTIONS[config.socraticIntensity].title}:</strong> {' '}
                  {SOCRATIC_LEVEL_DESCRIPTIONS[config.socraticIntensity].desc}
                </p>
              </div>

              {/* Feedback Tone Selection */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-emerald-400" />
                  <span>Feedback Tone & Critique Style</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {FEEDBACK_TONE_OPTIONS.map((tone) => {
                    const isSelected = config.feedbackTone === tone.id;
                    return (
                      <div
                        key={tone.id}
                        onClick={() => setConfig(prev => ({ ...prev, archetype: 'custom', feedbackTone: tone.id }))}
                        className={cn(
                          "p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3",
                          isSelected 
                            ? "bg-slate-900 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.15)]" 
                            : "bg-slate-900/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900"
                        )}
                      >
                        <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 mt-0.5">
                          {tone.icon}
                        </div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-white">{tone.title}</h4>
                            {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />}
                          </div>
                          <p className="text-[11px] text-slate-300 leading-relaxed">{tone.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Fine-Tuning Sliders */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-5">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-amber-400" />
                  <span>Fine-Tuning Pedagogy Parameters</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Inquiry Ratio */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-300">Inquiry Ratio (Socratic Questions):</span>
                      <span className="text-amber-300 font-bold">{config.inquiryRatio}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={config.inquiryRatio}
                      onChange={(e) => setConfig(prev => ({ ...prev, archetype: 'custom', inquiryRatio: parseInt(e.target.value) }))}
                      className="w-full accent-amber-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>0% Direct Explanation</span>
                      <span>100% Pure Questions</span>
                    </div>
                  </div>

                  {/* Academic Rigor */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-300">Academic Rigor & Derivations:</span>
                      <span className="text-cyan-300 font-bold">{config.rigorLevel}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={config.rigorLevel}
                      onChange={(e) => setConfig(prev => ({ ...prev, archetype: 'custom', rigorLevel: parseInt(e.target.value) }))}
                      className="w-full accent-cyan-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>0% Intuitive Conceptual</span>
                      <span>100% Formal Proofs</span>
                    </div>
                  </div>

                  {/* Energy Level */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-300">Energy & Enthusiasm:</span>
                      <span className="text-emerald-300 font-bold">{config.energyLevel}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={config.energyLevel}
                      onChange={(e) => setConfig(prev => ({ ...prev, archetype: 'custom', energyLevel: parseInt(e.target.value) }))}
                      className="w-full accent-emerald-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>0% Calm Podium</span>
                      <span>100% High-Energy Coach</span>
                    </div>
                  </div>

                  {/* Analogy Density */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-300">Analogy Density (Visual Metaphors):</span>
                      <span className="text-purple-300 font-bold">{config.analogyDensity}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={config.analogyDensity}
                      onChange={(e) => setConfig(prev => ({ ...prev, archetype: 'custom', analogyDensity: parseInt(e.target.value) }))}
                      className="w-full accent-purple-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>0% Pure Equations</span>
                      <span>100% Rich Storytelling</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Navigation CTAs */}
              <div className="flex justify-between pt-4">
                <button
                  onClick={() => setActiveStep('archetype')}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-all cursor-pointer"
                >
                  Back to Archetypes
                </button>

                <button
                  onClick={() => {
                    setActiveStep('playground');
                    generateSimulatedPreview();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-all shadow-lg flex items-center gap-2 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Test in Live Simulator</span>
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 3: LIVE SIMULATOR */}
          {activeStep === 'playground' && (
            <motion.div
              key="step-playground"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.2 }}
              className="space-y-6"
            >
              <div className="p-5 rounded-2xl bg-slate-900 border border-emerald-500/30 space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-400 animate-pulse" />
                    <h3 className="text-sm font-bold text-white">Live Persona Simulator</h3>
                  </div>
                  <span className="text-xs font-mono text-emerald-400 font-semibold bg-emerald-950 px-2.5 py-1 rounded-lg border border-emerald-500/30">
                    Config: {config.name}
                  </span>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-mono text-slate-400">Sample Student Question / Concept Prompt:</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={sampleQuestion}
                      onChange={(e) => setSampleQuestion(e.target.value)}
                      className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                      placeholder="Type a sample question..."
                    />
                    <button
                      onClick={generateSimulatedPreview}
                      disabled={isSimulating}
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <Wand2 className="w-3.5 h-3.5" />
                      <span>{isSimulating ? "Simulating..." : "Simulate"}</span>
                    </button>
                  </div>

                  {/* Quick Preset Prompts */}
                  <div className="flex flex-wrap gap-2 pt-1">
                    {[
                      "Why does light bend when entering glass?",
                      "How do vectors add together graphically?",
                      "Can you explain Newton's laws of motion simply?",
                      "What is Euler's Formula $e^{i\\pi} + 1 = 0$?"
                    ].map((q, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setSampleQuestion(q);
                          setTimeout(generateSimulatedPreview, 50);
                        }}
                        className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-slate-950 text-slate-400 hover:text-emerald-300 border border-slate-800 hover:border-emerald-500/40 transition-all cursor-pointer"
                      >
                        "{q}"
                      </button>
                    ))}
                  </div>
                </div>

                {/* Simulated Tutor Response Box */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 min-h-[160px] text-xs font-mono leading-relaxed relative">
                  {isSimulating ? (
                    <div className="flex items-center justify-center h-32 text-amber-400 gap-2">
                      <Wand2 className="w-5 h-5 animate-spin" />
                      <span>Simulating {config.name}'s response tone...</span>
                    </div>
                  ) : simulatedResponse ? (
                    <div className="text-slate-200 whitespace-pre-wrap">
                      {simulatedResponse}
                    </div>
                  ) : (
                    <div className="text-slate-500 text-center py-10">
                      Click "Simulate" to see how {config.name} responds to this prompt!
                    </div>
                  )}
                </div>
              </div>

              {/* Navigation CTAs */}
              <div className="flex justify-between pt-2">
                <button
                  onClick={() => setActiveStep('scaffolding')}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-all cursor-pointer"
                >
                  Back to Sliders
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleReset}
                    className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-bold text-xs transition-all cursor-pointer"
                  >
                    Reset Defaults
                  </button>
                  <button
                    onClick={handleSave}
                    className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm transition-all shadow-lg flex items-center gap-2 cursor-pointer"
                  >
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>Save & Apply Persona</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
