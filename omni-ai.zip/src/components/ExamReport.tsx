import React, { useState } from 'react';
import { 
  Award, CheckCircle2, XCircle, Clock, BarChart3, 
  TrendingUp, Zap, HelpCircle, ChevronRight, BookOpen, 
  RefreshCw, ArrowRight, Printer, Sparkles, AlertTriangle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { FullExamEvaluationReport, ExamQuestionItem } from '../modules/exam-simulator/types';

interface ExamReportProps {
  report: FullExamEvaluationReport;
  questions: ExamQuestionItem[];
  onRetakeExam?: () => void;
  onClose?: () => void;
  isDark?: boolean;
}

export const ExamReport: React.FC<ExamReportProps> = ({
  report,
  questions,
  onRetakeExam,
  onClose,
  isDark = true,
}) => {
  const [selectedTopicFilter, setSelectedTopicFilter] = useState<string>('all');
  const [expandedSolutionId, setExpandedSolutionId] = useState<string | null>(null);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className={cn(
      "w-full rounded-2xl border shadow-2xl p-5 sm:p-8 flex flex-col space-y-6 animate-in fade-in zoom-in-95",
      isDark ? "bg-slate-950 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Top Banner & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 font-bold uppercase tracking-wider">
              {report.examType.toUpperCase()} Official Blueprint
            </span>
            <span className="text-xs text-slate-400">
              Completed {new Date(report.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">{report.examTitle}</h2>
          <p className="text-xs text-slate-400 mt-0.5">Comprehensive Performance Evaluation & Rank Projection</p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition cursor-pointer"
          >
            <Printer size={14} /> Print Scorecard
          </button>
          {onRetakeExam && (
            <button
              onClick={onRetakeExam}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/20 flex items-center gap-1.5 transition cursor-pointer"
            >
              <RefreshCw size={14} /> Re-Simulate Exam
            </button>
          )}
        </div>
      </div>

      {/* Hero Score Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Total Score */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/50 to-slate-900 border border-indigo-500/30">
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400 block mb-1">
            Total Score
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-black text-indigo-200">{report.totalScore}</span>
            <span className="text-xs text-slate-400 font-semibold">/ {report.maxScore}</span>
          </div>
          <span className="text-xs font-bold text-indigo-400 mt-1 inline-block">
            {report.percentage}% Marks
          </span>
        </div>

        {/* Percentile Rank */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/50 to-slate-900 border border-purple-500/30">
          <span className="text-[11px] font-bold uppercase tracking-wider text-purple-400 block mb-1">
            National Percentile
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-black text-purple-200">{report.percentile}</span>
            <span className="text-xs text-purple-400 font-bold">%ile</span>
          </div>
          <span className="text-[11px] font-semibold text-purple-300 mt-1 truncate block">
            {report.rankEstimate}
          </span>
        </div>

        {/* Accuracy */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/50 to-slate-900 border border-emerald-500/30">
          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 block mb-1">
            Accuracy Rate
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl sm:text-3xl font-black text-emerald-200">{report.accuracyPercentage}</span>
            <span className="text-xs text-slate-400 font-semibold">%</span>
          </div>
          <span className="text-xs text-slate-400 mt-1 inline-block">
            {report.questionResults.filter(q => q.isCorrect).length} Correct of {report.questionResults.filter(q => q.isAttempted).length} Attempted
          </span>
        </div>

        {/* Speed & Time */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-teal-950/50 to-slate-900 border border-teal-500/30">
          <span className="text-[11px] font-bold uppercase tracking-wider text-teal-400 block mb-1">
            Time & Pace
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-black text-teal-200">{formatTime(report.totalTimeSpentSeconds)}</span>
          </div>
          <span className="text-xs text-teal-400 font-semibold mt-1 inline-block">
            Pacing: {report.speedIndex}
          </span>
        </div>
      </div>

      {/* Section-Wise Breakdown Table */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <BarChart3 size={16} className="text-indigo-400" /> Section-Wise Performance Breakdown
        </h3>
        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-400 uppercase font-bold border-b border-slate-800">
              <tr>
                <th className="p-3">Section</th>
                <th className="p-3">Attempted</th>
                <th className="p-3">Correct</th>
                <th className="p-3">Incorrect</th>
                <th className="p-3">Time Spent</th>
                <th className="p-3">Accuracy</th>
                <th className="p-3">Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {report.sections.map((sec) => (
                <tr key={sec.sectionId} className="hover:bg-slate-900/40 transition">
                  <td className="p-3 font-semibold text-slate-200">{sec.sectionName}</td>
                  <td className="p-3 text-slate-300">{sec.attempted} / {sec.attempted + sec.unattempted}</td>
                  <td className="p-3 text-emerald-400 font-bold">{sec.correct}</td>
                  <td className="p-3 text-rose-400 font-bold">{sec.incorrect}</td>
                  <td className="p-3 text-slate-400">{formatTime(sec.timeSpentSeconds)}</td>
                  <td className="p-3">
                    <span className={cn(
                      "px-2 py-0.5 rounded font-bold",
                      sec.accuracy >= 80 ? "bg-emerald-500/20 text-emerald-300" : sec.accuracy >= 50 ? "bg-amber-500/20 text-amber-300" : "bg-rose-500/20 text-rose-300"
                    )}>
                      {sec.accuracy}%
                    </span>
                  </td>
                  <td className="p-3 font-black text-indigo-300">{sec.score} / {sec.maxScore}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Topic Mastery & Insights Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Topic Mastery */}
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <BookOpen size={14} className="text-purple-400" /> Topic-Wise Mastery
          </h4>
          <div className="space-y-2.5">
            {report.topics.map((t) => (
              <div key={t.topic} className="space-y-1">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-300">{t.topic}</span>
                  <span className="text-slate-400">{t.correct}/{t.totalQuestions} ({t.masteryPercentage}%)</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-500",
                      t.masteryPercentage >= 75 ? "bg-emerald-500" : t.masteryPercentage >= 50 ? "bg-amber-500" : "bg-rose-500"
                    )}
                    style={{ width: `${t.masteryPercentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recommendations & Time Management */}
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2 mb-2">
              <Clock size={14} className="text-teal-400" /> Time Management Diagnostics
            </h4>
            <div className="space-y-1.5">
              {report.timeManagementInsights.map((insight, idx) => (
                <p key={idx} className="text-xs text-slate-300 bg-slate-800/40 p-2.5 rounded-xl border border-slate-700/50">
                  {insight}
                </p>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2 mb-2">
              <Sparkles size={14} className="text-amber-400" /> Professor Clarity's Action Plan
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {report.recommendations.map((rec, idx) => (
                <li key={idx} className="flex items-start gap-2 bg-indigo-950/20 p-2.5 rounded-xl border border-indigo-500/20">
                  <ChevronRight size={14} className="text-indigo-400 shrink-0 mt-0.5" />
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Question-by-Question Solutions Review */}
      <div className="space-y-4 pt-2">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <Award size={16} className="text-indigo-400" /> Detailed Question Solutions & Step-Wise Rubric
        </h3>

        <div className="space-y-3">
          {report.questionResults.map((qr) => {
            const originalQ = questions.find(q => q.id === qr.questionId);
            if (!originalQ) return null;
            const isExpanded = expandedSolutionId === qr.questionId;

            return (
              <div
                key={qr.questionId}
                className={cn(
                  "p-4 rounded-xl border transition-all",
                  qr.isCorrect
                    ? "bg-emerald-950/10 border-emerald-500/20"
                    : qr.isAttempted
                    ? "bg-rose-950/10 border-rose-500/20"
                    : "bg-slate-900/40 border-slate-800"
                )}
              >
                <div className="flex items-start justify-between gap-3 cursor-pointer" onClick={() => setExpandedSolutionId(isExpanded ? null : qr.questionId)}>
                  <div className="flex items-start gap-3">
                    <div className={cn(
                      "w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 mt-0.5",
                      qr.isCorrect ? "bg-emerald-500/20 text-emerald-400" : qr.isAttempted ? "bg-rose-500/20 text-rose-400" : "bg-slate-800 text-slate-400"
                    )}>
                      Q{originalQ.questionNumber}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-slate-200">Topic: {originalQ.topic}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-semibold">
                          {originalQ.marks} Marks
                        </span>
                        <span className="text-[10px] text-slate-400">
                          Time: {formatTime(qr.timeSpent)}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 line-clamp-2">{originalQ.questionText}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "text-xs font-black px-2 py-1 rounded-lg",
                      qr.awardedMarks > 0 ? "text-emerald-400 bg-emerald-500/10" : "text-rose-400 bg-rose-500/10"
                    )}>
                      {qr.awardedMarks > 0 ? `+${qr.awardedMarks}` : qr.awardedMarks} / {qr.maxMarks} M
                    </span>
                    <ChevronRight size={16} className={cn("text-slate-400 transition-transform", isExpanded && "rotate-90")} />
                  </div>
                </div>

                {/* Expanded Detailed Solution */}
                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-3 text-xs animate-in fade-in">
                    <div>
                      <span className="font-bold text-slate-400 uppercase text-[10px] block mb-1">Question Statement:</span>
                      <p className="text-slate-200 bg-slate-900 p-3 rounded-lg border border-slate-800">{originalQ.questionText}</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="font-bold text-slate-400 uppercase text-[10px] block mb-1">Your Response:</span>
                        <p className={qr.isCorrect ? "text-emerald-300 font-medium" : "text-rose-300 font-medium"}>
                          {qr.userAnswer || 'Unanswered'}
                        </p>
                      </div>
                      <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                        <span className="font-bold text-slate-400 uppercase text-[10px] block mb-1">Ideal / Correct Answer:</span>
                        <p className="text-emerald-300 font-medium">{qr.correctAnswer}</p>
                      </div>
                    </div>

                    {/* Step-wise breakdown if available */}
                    {qr.stepWiseBreakdown && qr.stepWiseBreakdown.length > 0 && (
                      <div className="p-3 rounded-lg bg-indigo-950/20 border border-indigo-500/20 space-y-1.5">
                        <span className="font-bold text-indigo-300 uppercase text-[10px] block">Step-Wise Marking Breakdown:</span>
                        {qr.stepWiseBreakdown.map((st, sidx) => (
                          <div key={sidx} className="flex justify-between items-center text-[11px] border-b border-indigo-500/10 pb-1">
                            <span className="text-slate-300">{st.step}</span>
                            <span className="text-indigo-400 font-bold">{st.awarded} / {st.maxMarks} M</span>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
                      <span className="font-bold text-amber-400 uppercase text-[10px] block mb-1">Official Solution & Concept:</span>
                      <p className="text-slate-300 leading-relaxed">{originalQ.detailedSolution}</p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
