import React from 'react';
import { CONFIG, DIFFICULTY_NAMES, TOPIC_ICONS, SUBJECT_ICONS, PERSONAS, getLessonsForSubject } from '@/src/lib/constants';
import { cn, triggerHapticFeedback } from '@/src/lib/utils';
import { X, GraduationCap, BookOpen, Target, User, Brain, Lightbulb, Calculator, FileText, Zap, Globe, Award, Timer, Layers, TrendingUp, Coins, Wrench, ChevronDown, Edit3, Radio, FlaskConical, Gamepad2, ShieldCheck, Users, Volume2, Flame, Atom, Bookmark, Table, Film, LayoutDashboard, Wand2, Box, Orbit, Sparkles, Search, Mic, MessageSquare, HelpCircle, Database } from 'lucide-react';
import { getBoardCurriculum, EDUCATION_BOARDS, EducationBoard } from '../data/boards';
import { getSkillsForNation, DEFAULT_SKILLS, Skill } from '../data/skills';
import { PWAInstallButton } from './PWAInstallButton';
import { isMakerDevice } from '../lib/makerDevice';

interface SidebarProps {
  expanded: boolean;
  setExpanded: (expanded: boolean) => void;
  difficulty: string;
  setDifficulty: (level: string) => void;
  subject: string;
  setSubject: (subject: string) => void;
  topic: string;
  setTopic: (topic: string) => void;
  lesson: string;
  setLesson: (lesson: string) => void;
  tutor: string;
  setTutor: (tutor: string) => void;
  xp: number;
  level: number;
  streak: number;
  theme: 'light' | 'dark';
  onOpenTool: (toolId: string) => void;
  selectedBoard?: {
    nation: string;
    acronym: string;
  } | null;
  onSelectBoard: (board: EducationBoard) => void;
  selectedPersonaId: string;
  onSelectPersonaId: (id: string) => void;
  mode?: string;
  selectedSkillId?: string;
  onSelectSkillId?: (skillId: string) => void;
  selectedEntranceExam: string;
  setSelectedEntranceExam: (exam: string) => void;
  isLectureMode: boolean;
  setIsLectureMode: (val: boolean) => void;
  lectureSubMode: 'classroom' | 'quiz' | 'lecture' | 'video_classroom';
  setLectureSubMode: (val: 'classroom' | 'quiz' | 'lecture' | 'video_classroom') => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  bookmarkedLessons?: { title: string; subject: string; lessonNumber: number; addedAt: string }[] | null;
  onToggleBookmark?: (lessonTitle: string, lessonSubject: string, lessonNumber: number) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  expanded,
  setExpanded,
  difficulty,
  setDifficulty,
  subject,
  setSubject,
  topic,
  setTopic,
  lesson,
  setLesson,
  tutor,
  setTutor,
  xp,
  level,
  streak,
  theme,
  onOpenTool,
  selectedBoard,
  onSelectBoard,
  selectedPersonaId,
  onSelectPersonaId,
  mode,
  selectedSkillId,
  onSelectSkillId,
  selectedEntranceExam,
  setSelectedEntranceExam,
  isLectureMode,
  setIsLectureMode,
  lectureSubMode,
  setLectureSubMode,
  showNotification,
  bookmarkedLessons,
  onToggleBookmark
}) => {
  const [localNation, setLocalNation] = React.useState<string>(selectedBoard?.nation || 'India');
  const [isAIToolsOpen, setIsAIToolsOpen] = React.useState(false);
  const [topicFilter, setTopicFilter] = React.useState<string>('');

  const playModeTransitionSound = (mode: 'standard' | 'classroom' | 'quiz' | 'lecture' | 'video_classroom') => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const now = ctx.currentTime;
      
      if (mode === 'standard') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (mode === 'classroom') {
        const playClick = () => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(120 + Math.random() * 40, now);
          gain.gain.setValueAtTime(0.02, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.05);
        };
        playClick();
        setTimeout(playClick, 120);
      } else if (mode === 'quiz') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.18);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.22);
      } else if (mode === 'lecture') {
        [130.81, 196.00].forEach(freq => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now);
          gain.gain.setValueAtTime(0.03, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.45);
        });
      } else if (mode === 'video_classroom') {
        // High-tech warm synth chime for movie mode start
        [261.63, 329.63, 392.00, 523.25].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + idx * 0.08);
          gain.gain.setValueAtTime(0.025, now + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.4);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.08);
          osc.stop(now + idx * 0.08 + 0.4);
        });
      }
    } catch (e) {}
  };

  React.useEffect(() => {
    if (selectedBoard?.nation) {
      setLocalNation(selectedBoard.nation);
    }
  }, [selectedBoard]);

  const nations = React.useMemo(() => {
    const list = new Set<string>();
    EDUCATION_BOARDS.forEach(b => list.add(b.nation));
    return Array.from(list);
  }, []);

  const availableBoards = React.useMemo(() => {
    return EDUCATION_BOARDS.filter(b => b.nation === localNation);
  }, [localNation]);

  const curriculum = selectedBoard ? getBoardCurriculum(selectedBoard.nation, selectedBoard.acronym, difficulty) : null;
  const levels = curriculum ? curriculum.levels : CONFIG.DIFFICULTY_LEVELS;
  
  const subjects = React.useMemo(() => {
    if (!curriculum) return CONFIG.SUBJECTS;
    return curriculum.subjects;
  }, [curriculum]);

  const topics = React.useMemo(() => {
    let list: string[] = [];
    if (curriculum && curriculum.topics[subject] && curriculum.topics[subject].length > 0) {
      list = [...curriculum.topics[subject]];
    } else {
      list = [...(CONFIG.TOPICS[subject] || [])];
    }
    if (topic && !list.includes(topic)) {
      list.unshift(topic);
    }
    return list;
  }, [curriculum, subject, topic]);

  const skillsForActiveNation = React.useMemo(() => {
    return getSkillsForNation(localNation);
  }, [localNation]);

  const subjectLessons = React.useMemo(() => {
    if (curriculum && curriculum.topics[subject] && curriculum.topics[subject].length > 0) {
      return curriculum.topics[subject];
    }
    return getLessonsForSubject(subject, selectedBoard?.acronym, difficulty);
  }, [subject, curriculum, selectedBoard, difficulty]);

  // Sync active subject topic when lesson changes
  React.useEffect(() => {
    const lessonIdx = (parseInt(lesson, 10) || 1) - 1;
    const lessonTitle = subjectLessons[lessonIdx] || subjectLessons[0];
    if (lessonTitle && lessonTitle !== topic) {
      setTopic(lessonTitle);
    }
  }, [lesson, subjectLessons, topic, setTopic]);

  const activeSkill = React.useMemo(() => {
    return skillsForActiveNation.find(s => s.id === selectedSkillId) || skillsForActiveNation[0] || DEFAULT_SKILLS[0];
  }, [skillsForActiveNation, selectedSkillId]);

  const [touchStartX, setTouchStartX] = React.useState<number | null>(null);
  const [touchEndX, setTouchEndX] = React.useState<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEndX(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (touchStartX === null || touchEndX === null) return;
    const distance = touchStartX - touchEndX;
    const isLeftSwipe = distance > 50;

    if (expanded && isLeftSwipe) {
      setExpanded(false);
    }
    setTouchStartX(null);
    setTouchEndX(null);
  };

  React.useEffect(() => {
    let startX = 0;
    let endX = 0;

    const handleGlobalTouchStart = (e: TouchEvent) => {
      if (!expanded && e.touches[0].clientX < 35) {
        startX = e.touches[0].clientX;
      } else {
        startX = 0;
      }
    };

    const handleGlobalTouchMove = (e: TouchEvent) => {
      if (!expanded && startX > 0) {
        endX = e.touches[0].clientX;
      }
    };

    const handleGlobalTouchEnd = () => {
      if (!expanded && startX > 0 && endX > 0) {
        const distance = endX - startX;
        if (distance > 50) {
          setExpanded(true);
        }
      }
      startX = 0;
      endX = 0;
    };

    window.addEventListener('touchstart', handleGlobalTouchStart);
    window.addEventListener('touchmove', handleGlobalTouchMove);
    window.addEventListener('touchend', handleGlobalTouchEnd);

    return () => {
      window.removeEventListener('touchstart', handleGlobalTouchStart);
      window.removeEventListener('touchmove', handleGlobalTouchMove);
      window.removeEventListener('touchend', handleGlobalTouchEnd);
    };
  }, [expanded, setExpanded]);

  return (
    <div 
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className={cn(
      "fixed left-0 top-0 h-screen w-[280px] border-r z-[1000] transition-all duration-300 flex flex-col shadow-xl",
      !expanded && "-left-[280px]",
      theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
    )}>
      <div className={cn(
        "p-6 border-b flex items-center justify-between",
        theme === 'dark' ? "border-slate-800/50 bg-slate-900/50" : "border-slate-100 bg-slate-50/50"
      )}>
        <div className="flex items-center gap-3 group cursor-default">
          <div className="w-10 h-10 rounded-2xl overflow-hidden shadow-lg shadow-indigo-500/20 group-hover:rotate-12 transition-transform duration-500 border border-white/20 bg-slate-950 flex items-center justify-center">
            <img 
              src="/app-icon.jpg" 
              alt="Omni AI Icon" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex flex-col">
            <h1 className={cn(
              "font-black text-lg tracking-tight leading-none",
              theme === 'dark' ? "text-white" : "text-slate-900"
            )}>
              Omni AI
            </h1>
          </div>
        </div>
        <button 
          className={cn(
            "p-3 rounded-xl transition-all duration-300 hover:bg-red-50 hover:text-red-500 active:scale-95 cursor-pointer min-w-[42px] min-h-[42px] flex items-center justify-center",
            theme === 'dark' ? "text-slate-500 hover:bg-red-900/20" : "text-slate-400"
          )}
          onClick={() => setExpanded(false)}
        >
          <X size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {mode === 'earn' ? (
          <section className="space-y-2">
            <div 
              className={cn(
                "w-full p-3 rounded-xl border flex items-center justify-between transition-all group",
                theme === 'dark' 
                  ? "bg-slate-800/40 border-slate-700/80 text-slate-300" 
                  : "bg-white border-slate-200 text-slate-700",
                "border-amber-500/80 ring-2 ring-amber-500/10"
              )}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-amber-100/15 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Coins size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">
                    Nation-Skill
                  </div>
                  <div className="text-[10px] opacity-60">Earning & skill metrics</div>
                </div>
              </div>
              <span className={cn(
                "text-[10px] font-bold px-2 py-0.5 rounded-full border bg-amber-50 dark:bg-amber-950/40 border-amber-250 dark:border-amber-800/60 text-amber-600 dark:text-amber-400"
              )}>
                Earning Active
              </span>
            </div>

            {/* Quick Dropdown Selectors for Nation & Skill inside Sidebar */}
            <div className={cn(
              "p-2.5 rounded-xl border space-y-2.5",
              theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50/70 border-slate-200/80"
            )}>
              <div className="flex items-center justify-between text-[11px] font-bold opacity-75 uppercase tracking-wider">
                <span>Select Nation & Skill</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[10px] font-semibold opacity-60">Nation</label>
                  <select
                    value={localNation}
                    onChange={(e) => {
                      const nat = e.target.value;
                      setLocalNation(nat);
                      const skills = getSkillsForNation(nat);
                      if (skills.length > 0) {
                        onSelectSkillId?.(skills[0].id);
                      }
                    }}
                    className={cn(
                      "w-full p-1.5 border rounded-lg text-xs cursor-pointer outline-none transition-colors",
                      theme === 'dark' ? "bg-slate-850 border-slate-700 text-white" : "bg-white border-slate-250 text-slate-800"
                    )}
                  >
                    {nations.map(nat => (
                      <option key={nat} value={nat}>
                        {nat.replace(/\s*\(.*\)/g, '').trim()}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-semibold opacity-60">Skill</label>
                  <select
                    value={selectedSkillId || ''}
                    onChange={(e) => {
                      onSelectSkillId?.(e.target.value);
                    }}
                    className={cn(
                      "w-full p-1.5 border rounded-lg text-xs cursor-pointer outline-none transition-colors",
                      theme === 'dark' ? "bg-slate-850 border-slate-700 text-white" : "bg-white border-slate-250 text-slate-800"
                    )}
                  >
                    <option value="" disabled>Select Skill</option>
                    {skillsForActiveNation.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </section>
        ) : (
          <section className="space-y-2">
            <button 
              onClick={() => mode !== 'entrance' && onOpenTool('boards')}
              className={cn(
                "w-full p-3 rounded-xl border flex items-center justify-between transition-all group",
                mode !== 'entrance' && "cursor-pointer",
                theme === 'dark' 
                  ? "bg-slate-800/40 border-slate-700/80 hover:border-indigo-500 text-slate-300 hover:bg-slate-800" 
                  : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700 hover:bg-slate-50",
                (selectedBoard || mode === 'entrance') && "border-indigo-500/80 ring-2 ring-indigo-500/10"
              )}
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-150/15 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Award size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">
                    {mode === 'entrance' 
                      ? ((CONFIG.ENTRANCE_EXAMS_DATA as any)[selectedEntranceExam]?.name || selectedEntranceExam)
                      : (selectedBoard 
                          ? ` ${selectedBoard.nation.toUpperCase().replace(/\s*\(.*\)/g, '').trim()}-${selectedBoard.acronym.toUpperCase()}`
                          : "Board / University")}
                  </div>
                  <div className="text-[10px] opacity-60">
                    {mode === 'entrance' ? 'Entrance Exam' : 'Syllabus & curriculum'}
                  </div>
                </div>
              </div>
            </button>

            {mode !== 'entrance' && (
              /* Quick Dropdown Selectors for Nation & Board inside Sidebar */
              <div className={cn(
                "p-2.5 rounded-xl border space-y-2.5",
                theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50/70 border-slate-200/80"
              )}>
                <div className="flex items-center justify-between text-[11px] font-bold opacity-75 uppercase tracking-wider">
                  <span>Quick Select Board & Uni</span>
                  <button 
                    onClick={() => onOpenTool('boards')}
                    className="text-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer"
                  >
                    Browse All
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] font-semibold opacity-60">Nation</label>
                    <select
                      value={localNation}
                      onChange={(e) => {
                        const nat = e.target.value;
                        setLocalNation(nat);
                        // Automatically activate the first board of that nation
                        const interactiveBoard = EDUCATION_BOARDS.find(b => b.nation === nat);
                        if (interactiveBoard) {
                          onSelectBoard(interactiveBoard);
                        }
                      }}
                      className={cn(
                        "w-full p-1.5 border rounded-lg text-xs cursor-pointer outline-none transition-colors",
                        theme === 'dark' ? "bg-slate-850 border-slate-700 text-white" : "bg-white border-slate-250 text-slate-800"
                      )}
                    >
                      {nations.map(nat => (
                        <option key={nat} value={nat}>
                          {nat.replace(/\s*\(.*\)/g, '').trim()}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-semibold opacity-60">Board</label>
                    <select
                      value={selectedBoard?.acronym || ''}
                      onChange={(e) => {
                        const activeB = availableBoards.find(b => b.acronym === e.target.value);
                        if (activeB) {
                          onSelectBoard(activeB);
                        }
                      }}
                      className={cn(
                        "w-full p-1.5 border rounded-lg text-xs cursor-pointer outline-none transition-colors",
                        theme === 'dark' ? "bg-slate-850 border-slate-700 text-white" : "bg-white border-slate-250 text-slate-800"
                      )}
                    >
                      <option value="" disabled>Select Board</option>
                      {availableBoards.map(b => (
                        <option key={b.acronym} value={b.acronym}>
                          {b.acronym}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}
            
            {mode === 'entrance' && (
              <div className={cn(
                "p-2.5 rounded-xl border space-y-2.5",
                theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50/70 border-slate-200/80"
              )}>
                 <div className="flex items-center justify-between text-[11px] font-bold opacity-75 uppercase tracking-wider">
                  <span>Select Entrance Exam</span>
                </div>
                <select
                  value={selectedEntranceExam}
                  onChange={(e) => {
                    setSelectedEntranceExam(e.target.value);
                    const subjs = ((CONFIG.ENTRANCE_EXAMS_DATA as any)[e.target.value]?.subjects);
                    if (subjs && subjs.length > 0) setSubject(subjs[0]);
                  }}
                  className={cn(
                    "w-full p-1.5 border rounded-lg text-xs cursor-pointer outline-none transition-colors",
                    theme === 'dark' ? "bg-slate-850 border-slate-700 text-white" : "bg-white border-slate-250 text-slate-800"
                  )}
                >
                  {Object.entries(CONFIG.ENTRANCE_EXAMS_DATA).map(([id, exam]) => (
                    <option key={id} value={id}>{exam.name}</option>
                  ))}
                </select>
              </div>
            )}
          </section>
        )}

        {mode === 'earn' ? (
          <section>
            <div className="text-xs uppercase tracking-wider text-amber-500 mb-4 font-semibold flex items-center gap-2">
              <TrendingUp size={14} /> Earning Level
            </div>
            <select 
              className={cn(
                "w-full p-2.5 border rounded-lg text-sm cursor-pointer outline-none transition-colors border-amber-500/30 focus:border-amber-500",
                theme === 'dark' ? "bg-slate-800 border-slate-700 text-white hover:border-amber-500" : "bg-white border-slate-200 text-slate-900 hover:border-amber-300 focus:border-amber-500"
              )}
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value)}
            >
              {activeSkill.earningLevels.map(lvl => (
                <option key={lvl} value={lvl}>
                  {lvl} ({activeSkill.earningRates[lvl] || '$25/hr'})
                </option>
              ))}
            </select>
          </section>
        ) : (
          <section>
            <div className="text-xs uppercase tracking-wider text-slate-500 mb-4 font-semibold flex items-center gap-2">
              <GraduationCap size={14} /> {mode === 'entrance' ? 'Eligibility' : 'Learning Level'}
            </div>
            {mode === 'entrance' ? (
              <div className={cn(
                "p-3 rounded-lg text-xs leading-relaxed",
                theme === 'dark' ? "bg-indigo-950/30 text-indigo-300 border border-indigo-900/50" : "bg-indigo-50 text-indigo-700 border border-indigo-100"
              )}>
                {((CONFIG.ENTRANCE_EXAMS_DATA as any)[selectedEntranceExam]?.eligibility || '')}
              </div>
            ) : (
              <select 
                className={cn(
                  "w-full p-2.5 border rounded-lg text-sm cursor-pointer outline-none transition-colors",
                  theme === 'dark' ? "bg-slate-800 border-slate-700 text-white hover:border-indigo-500" : "bg-white border-slate-200 text-slate-900 hover:border-indigo-300 focus:border-indigo-500"
                )}
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value)}
              >
                {levels.map(level => (
                  <option key={level} value={level}>
                    {DIFFICULTY_NAMES[level] || level}
                  </option>
                ))}
              </select>
            )}
          </section>
        )}



        {mode === 'earn' && (
          <section className="space-y-3">
            <div className="text-xs uppercase tracking-wider text-slate-500 font-semibold flex items-center gap-2">
              <Wrench size={14} className="text-amber-500" /> Skill Directory
            </div>
            
            <div className="space-y-4 max-h-[320px] overflow-y-auto pr-1">
              {/* Hard Skills */}
              <div className="space-y-2">
                <div className="text-[10px] font-black text-amber-500 uppercase tracking-wider flex items-center gap-1">
                  🔧 Hard Skills (Industries Skill)
                </div>
                <div className="space-y-1.5">
                  {skillsForActiveNation.filter(s => s.type === 'hard').map(s => {
                    const isSelected = selectedSkillId === s.id;
                    return (
                      <button
                        key={s.id}
                        onClick={() => onSelectSkillId?.(s.id)}
                        className={cn(
                          "w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden",
                          isSelected 
                            ? "bg-amber-500/10 border-amber-500 shadow-md shadow-amber-500/5 ring-1 ring-amber-500" 
                            : theme === 'dark' 
                              ? "bg-slate-800/40 border-slate-700/80 hover:bg-slate-850 hover:border-slate-650 text-slate-300" 
                              : "bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300 text-slate-700"
                        )}
                      >
                        <div className="font-bold text-xs flex justify-between items-center">
                          <span className={cn(isSelected && "text-amber-500")}>{s.name}</span>
                          {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />}
                        </div>
                        <p className="text-[10px] opacity-75 mt-0.5 leading-tight">{s.description}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Soft Skills */}
              <div className="space-y-2">
                <div className="text-[10px] font-black text-violet-500 uppercase tracking-wider flex items-center gap-1">
                  🎨 Soft Skills (Software Designing)
                </div>
                <div className="space-y-1.5">
                  {skillsForActiveNation.filter(s => s.type === 'soft').map(s => {
                    const isSelected = selectedSkillId === s.id;
                    return (
                      <button
                        key={s.id}
                        onClick={() => onSelectSkillId?.(s.id)}
                        className={cn(
                          "w-full p-2.5 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden",
                          isSelected 
                            ? "bg-violet-500/10 border-violet-500 shadow-md shadow-violet-500/5 ring-1 ring-violet-500" 
                            : theme === 'dark' 
                              ? "bg-slate-800/40 border-slate-700/80 hover:bg-slate-850 hover:border-slate-650 text-slate-300" 
                              : "bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300 text-slate-700"
                        )}
                      >
                        <div className="font-bold text-xs flex justify-between items-center">
                          <span className={cn(isSelected && "text-violet-500")}>{s.name}</span>
                          {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-violet-500" />}
                        </div>
                        <p className="text-[10px] opacity-75 mt-0.5 leading-tight">{s.description}</p>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>
        )}

        <section>
          <div className="text-xs uppercase tracking-wider text-slate-500 mb-4 font-semibold flex items-center gap-2">
            <BookOpen size={14} /> {mode === 'entrance' ? ' Subjects' : 'Subjects'}
          </div>
          <select 
            className={cn(
              "w-full p-2.5 border rounded-lg text-sm cursor-pointer outline-none transition-colors",
              theme === 'dark' ? "bg-slate-800 border-slate-700 text-white hover:border-indigo-500" : "bg-white border-slate-200 text-slate-900 hover:border-indigo-300 focus:border-indigo-500"
            )}
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          >
            {mode === 'entrance' 
              ? (((CONFIG.ENTRANCE_EXAMS_DATA as any)[selectedEntranceExam]?.subjects || []) as string[]).map((s: string) => (
                  <option key={s} value={s}>
                    {SUBJECT_ICONS[s] || '📚'} {s.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                  </option>
                ))
              : (curriculum ? (
                  curriculum.subjects.map((s: string) => (
                    <option key={s} value={s}>
                      {SUBJECT_ICONS[s] || '📚'} {s.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                    </option>
                  ))
                ) : (
                  CONFIG.SUBJECTS.map((s: string) => (
                    <option key={s} value={s}>
                      {SUBJECT_ICONS[s] || '📚'} {s.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                    </option>
                  ))
                ))
            }
          </select>
        </section>

        <section className="mt-4">
          <div className="text-xs uppercase tracking-wider text-slate-500 mb-2 font-semibold flex items-center justify-between">
            <span className="flex items-center gap-2">
              <FileText size={14} className="text-indigo-500" /> Topics & Chapters
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              {topics.length} Available
            </span>
          </div>

          {/* Quick Search Filter */}
          <div className="relative mb-2">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search chapters or topics..."
              value={topicFilter}
              onChange={(e) => setTopicFilter(e.target.value)}
              className={cn(
                "w-full pl-8 pr-3 py-1.5 rounded-lg text-xs outline-none transition-all border",
                theme === 'dark'
                  ? "bg-slate-800/80 border-slate-700 text-white placeholder-slate-500 focus:border-indigo-500"
                  : "bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500"
              )}
            />
            {/* Clear/Delete button - Hidden per user request */}
            {false && topicFilter && (
              <button
                onClick={() => setTopicFilter('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X size={12} />
              </button>
            )}
          </div>

          <select 
            className={cn(
              "w-full p-2.5 border rounded-lg text-sm cursor-pointer outline-none transition-colors",
              theme === 'dark' ? "bg-slate-800 border-slate-700 text-white hover:border-indigo-500" : "bg-white border-slate-200 text-slate-900 hover:border-indigo-300 focus:border-indigo-500"
            )}
            value={topic}
            onChange={(e) => {
              triggerHapticFeedback(8);
              setTopic(e.target.value);
            }}
          >
            {topics
              .filter(t => !topicFilter || t.toLowerCase().includes(topicFilter.toLowerCase()))
              .map(t => (
                <option key={t} value={t}>
                  {TOPIC_ICONS[t] || '📚'} {t.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </option>
              ))}
          </select>
          <p className="text-[10px] text-slate-500 mt-2 px-1 leading-tight">
            Selecting a topic here automatically updates your <span className="font-bold text-indigo-500">syllabus expansion controls</span> and lesson plan.
          </p>
        </section>

        <section className="mt-4">
          <div className="text-xs uppercase tracking-wider text-slate-500 mb-3 font-semibold flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Target size={14} className="text-indigo-500" /> Active Subject Lesson
            </span>
          </div>
          <div className="flex items-stretch gap-1.5">
            <select
              className={cn(
                "flex-1 w-full p-2.5 border rounded-lg text-sm cursor-pointer outline-none transition-colors",
                theme === 'dark' ? "bg-slate-800 border-slate-700 text-white hover:border-indigo-500" : "bg-white border-slate-200 text-slate-900 hover:border-indigo-300 focus:border-indigo-500"
              )}
              value={lesson}
              onChange={(e) => {
                const newLessonVal = e.target.value;
                setLesson(newLessonVal);
                const lessonIdx = (parseInt(newLessonVal, 10) || 1) - 1;
                const chapterTitle = subjectLessons[lessonIdx] || subjectLessons[0];
                if (chapterTitle) {
                  setTopic(chapterTitle);
                }
              }}
            >
              {subjectLessons.map((title, i) => {
                const lessonNum = i + 1;
                return (
                  <option key={lessonNum} value={String(lessonNum)}>
                    {lessonNum}. {title}
                  </option>
                );
              })}
            </select>
            <button
              onClick={() => {
                const currentLessonNum = parseInt(lesson) || 1;
                const title = subjectLessons[currentLessonNum - 1] || subjectLessons[0];
                onToggleBookmark?.(title, subject, currentLessonNum);
              }}
              className={cn(
                "px-2.5 rounded-xl border transition-all cursor-pointer active:scale-95 flex items-center justify-center min-w-[38px] min-h-[38px] flex-shrink-0",
                (bookmarkedLessons || []).some(b => b.title === (subjectLessons[(parseInt(lesson) || 1) - 1] || subjectLessons[0]) && b.subject === subject)
                  ? "bg-amber-500/10 border-amber-500/40 text-amber-500"
                  : theme === 'dark'
                    ? "border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700 hover:bg-slate-800/30"
                    : "border-slate-200 text-slate-400 hover:text-slate-600 hover:border-slate-300 hover:bg-slate-50"
              )}
              title="Toggle Bookmark"
            >
              <Bookmark size={13} className={(bookmarkedLessons || []).some(b => b.title === (subjectLessons[(parseInt(lesson) || 1) - 1] || subjectLessons[0]) && b.subject === subject) ? "fill-current" : ""} />
            </button>
          </div>

          {/* Visual Summary Button for Active Lesson */}
        </section>

        <section>
          <div className="text-xs uppercase tracking-wider text-slate-500 mb-2 font-semibold flex items-center gap-2">
            <BookOpen size={14} className="text-indigo-500" /> Syllabus & Chapters
          </div>
          <button
            onClick={() => onOpenTool('chapters')}
            className={cn(
              "w-full p-2.5 rounded-xl border flex items-center justify-between text-sm font-bold transition-all group cursor-pointer",
              theme === 'dark' 
                ? "bg-slate-800/40 border-slate-700/80 hover:border-indigo-500 text-slate-300 hover:bg-slate-800"
                : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700 hover:bg-slate-50"
            )}
          >
            <div className="flex items-center gap-2.5">
              <GraduationCap size={16} className="text-indigo-500 group-hover:scale-110 transition-transform" />
              <span>Expansion Controls</span>
            </div>
            <span className="text-[10px] bg-indigo-50 dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 text-indigo-600 dark:text-indigo-400 px-1.5 py-0.5 rounded-md font-bold">
              Explore
            </span>
          </button>
        </section>



        <section>
          <button
            onClick={() => setIsAIToolsOpen(!isAIToolsOpen)}
            className="w-full flex items-center justify-between text-xs uppercase tracking-wider text-slate-500 mb-4 font-semibold hover:text-indigo-500 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Zap size={14} className="text-amber-500" /> AI Tools
            </div>
            <ChevronDown size={14} className={cn("transition-transform", isAIToolsOpen ? "rotate-180" : "")} />
          </button>
          
          {isAIToolsOpen && (
            <div className="grid grid-cols-1 gap-2 animate-in fade-in slide-in-from-top-2 duration-300">
              <button 
                onClick={() => onOpenTool('dashboard')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-indigo-900/40 border-indigo-500/50 hover:border-indigo-400 text-indigo-200" : "bg-indigo-50 border-indigo-200 hover:border-indigo-400 text-indigo-900"
                )}
              >
                <div className="w-8 h-8 bg-indigo-500 text-white rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
                  <LayoutDashboard size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Learning Dashboard</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-indigo-500 text-white">SUMMARY</span>
                  </div>
                  <div className="text-[10px] opacity-60">XP, recent study sessions & quests</div>
                </div>
              </button>

              {/* 16-Feature Master Pedagogical Suite Banner */}
              <button 
                onClick={() => onOpenTool('master_feature_suite')}
                className={cn(
                  "w-full p-3.5 rounded-2xl border flex items-center gap-3 transition-all group relative overflow-hidden shadow-lg cursor-pointer",
                  theme === 'dark' 
                    ? "bg-gradient-to-r from-indigo-950/80 via-purple-950/60 to-slate-900 border-indigo-500/70 hover:border-indigo-400 text-white shadow-indigo-500/10" 
                    : "bg-gradient-to-r from-indigo-50 via-purple-50 to-pink-50 border-indigo-300 hover:border-indigo-500 text-slate-900 shadow-indigo-500/10"
                )}
              >
                <div className="w-9 h-9 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 text-white rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-md shadow-indigo-500/30">
                  <Sparkles size={20} className="animate-spin" style={{ animationDuration: '9s' }} />
                </div>
                <div className="text-left flex-1 min-w-0">
                  <div className="text-xs font-black flex items-center gap-1.5 tracking-tight">
                    <span className="truncate">Master Feature Suite</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-sm">
                      16 / 16
                    </span>
                  </div>
                  <div className="text-[10px] opacity-75 truncate">All 16 AI features &amp; curriculum tools</div>
                </div>
              </button>

              {/* Professor Clarity Self-Healing & Debugger Launcher */}
              <button 
                onClick={() => onOpenTool('clarity_debugger')}
                className={cn(
                  "w-full p-2.5 rounded-2xl border flex items-center gap-2.5 transition-all group relative overflow-hidden shadow-sm cursor-pointer",
                  theme === 'dark' 
                    ? "bg-slate-900/90 border-slate-800 hover:border-indigo-500/60 text-white" 
                    : "bg-white border-slate-200 hover:border-indigo-400 text-slate-900"
                )}
              >
                <div className="w-7 h-7 bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform shrink-0">
                  <ShieldCheck size={16} />
                </div>
                <div className="text-left flex-1 min-w-0">
                  <div className="text-[11px] font-bold flex items-center gap-1.5">
                    <span className="truncate">Clarity Health &amp; Debugger</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  </div>
                  <div className="text-[9px] text-emerald-400 font-mono font-bold">Auto-Healing &bull; 98% Health</div>
                </div>
              </button>

              {/* Quick Feature Launchers Grid */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => onOpenTool('adaptive_learning_path')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-indigo-500 text-slate-200" : "bg-white border-slate-200 hover:border-indigo-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-indigo-400 font-bold text-xs">
                    <Brain size={14} /> Adaptive Path
                  </div>
                  <span className="text-[9px] text-slate-400">Curriculum Builder</span>
                </button>

                <button
                  onClick={() => onOpenTool('two_way_voice_dialogue')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-emerald-500 text-slate-200" : "bg-white border-slate-200 hover:border-emerald-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
                    <Mic size={14} /> Voice Dialogue
                  </div>
                  <span className="text-[9px] text-slate-400">Two-Way Voice</span>
                </button>

                <button
                  onClick={() => onOpenTool('multilingual_translation')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-cyan-500 text-slate-200" : "bg-white border-slate-200 hover:border-cyan-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-xs">
                    <Globe size={14} /> Translation
                  </div>
                  <span className="text-[9px] text-slate-400">20+ Languages</span>
                </button>

                <button
                  onClick={() => onOpenTool('exam_simulator_hub')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-rose-500 text-slate-200" : "bg-white border-slate-200 hover:border-rose-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-rose-400 font-bold text-xs">
                    <GraduationCap size={14} /> Exam Simulator
                  </div>
                  <span className="text-[9px] text-slate-400">CBSE / JEE / NEET</span>
                </button>

                <button
                  onClick={() => onOpenTool('time_coach')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-amber-500 text-slate-200" : "bg-white border-slate-200 hover:border-amber-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                    <Timer size={14} /> Time Coach
                  </div>
                  <span className="text-[9px] text-slate-400">Speed & Skip Drills</span>
                </button>

                <button
                  onClick={() => onOpenTool('pyq_intelligence')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-emerald-500 text-slate-200" : "bg-white border-slate-200 hover:border-emerald-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
                    <Database size={14} /> PYQ Intelligence
                  </div>
                  <span className="text-[9px] text-slate-400">15Y Weightage Heatmap</span>
                </button>

                <button
                  onClick={() => onOpenTool('mistake_journal')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-rose-500 text-slate-200" : "bg-white border-slate-200 hover:border-rose-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-rose-400 font-bold text-xs">
                    <Brain size={14} /> Mistake Journal
                  </div>
                  <span className="text-[9px] text-slate-400">Cognitive Error Fix</span>
                </button>

                <button
                  onClick={() => onOpenTool('auto_note_generator')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-amber-500 text-slate-200" : "bg-white border-slate-200 hover:border-amber-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                    <FileText size={14} /> Cornell Notes
                  </div>
                  <span className="text-[9px] text-slate-400">Auto Summaries</span>
                </button>

                <button
                  onClick={() => onOpenTool('executive_summary')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-indigo-500 text-slate-200" : "bg-white border-slate-200 hover:border-indigo-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-indigo-400 font-bold text-xs">
                    <BookOpen size={14} /> Executive Summary
                  </div>
                  <span className="text-[9px] text-slate-400">High-Yield Study</span>
                </button>

                <button
                  onClick={() => onOpenTool('ar_3d_visualizer')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-blue-500 text-slate-200" : "bg-white border-slate-200 hover:border-blue-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-blue-400 font-bold text-xs">
                    <Box size={14} /> AR / WebXR
                  </div>
                  <span className="text-[9px] text-slate-400">Spatial Models</span>
                </button>

                <button
                  onClick={() => onOpenTool('offline_mode_manager')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-sky-500 text-slate-200" : "bg-white border-slate-200 hover:border-sky-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-sky-400 font-bold text-xs">
                    <Layers size={14} /> Offline Mode
                  </div>
                  <span className="text-[9px] text-slate-400">Low-Bandwidth</span>
                </button>

                <button
                  onClick={() => onOpenTool('wellbeing_coach')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-pink-500 text-slate-200" : "bg-white border-slate-200 hover:border-pink-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-pink-400 font-bold text-xs">
                    <Zap size={14} /> Well-Being
                  </div>
                  <span className="text-[9px] text-slate-400">Stress Relief</span>
                </button>

                <button
                  onClick={() => onOpenTool('doubt_board')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-amber-500 text-slate-200" : "bg-white border-slate-200 hover:border-amber-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                    <HelpCircle size={14} /> Doubt Board
                  </div>
                  <span className="text-[9px] text-slate-400">Anonymous Q&A</span>
                </button>

                <button
                  onClick={() => onOpenTool('project_based_learning')}
                  className={cn(
                    "p-2.5 rounded-xl border flex flex-col items-start gap-1 transition text-left cursor-pointer",
                    theme === 'dark' ? "bg-slate-800/60 border-slate-700 hover:border-sky-500 text-slate-200" : "bg-white border-slate-200 hover:border-sky-400 text-slate-800 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-1.5 text-sky-400 font-bold text-xs">
                    <Sparkles size={14} /> Project-Based
                  </div>
                  <span className="text-[9px] text-slate-400">PBL Portfolios</span>
                </button>
              </div>

              {/* Chat History & Saved Sessions Highlight */}
              <button 
                onClick={() => onOpenTool('chat_history')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group relative overflow-hidden",
                  theme === 'dark' 
                    ? "bg-gradient-to-r from-indigo-950/70 via-blue-950/50 to-slate-900 border-indigo-500/50 hover:border-indigo-400 text-white" 
                    : "bg-gradient-to-r from-indigo-50 via-blue-50 to-white border-indigo-200 hover:border-indigo-400 text-slate-800"
                )}
              >
                <div className="w-8 h-8 bg-gradient-to-br from-indigo-600 to-blue-500 text-white rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform shadow-md shadow-indigo-500/30">
                  <MessageSquare size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Chat History</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-sm">FIRESTORE</span>
                  </div>
                  <div className="text-[10px] opacity-70">Saved sessions, notes & logs</div>
                </div>
              </button>

              {/* Virtual 3D Mode Highlight */}
              <button 
                onClick={() => onOpenTool('3d_classroom')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group relative overflow-hidden",
                  mode === '3d_classroom'
                    ? "bg-indigo-600 border-indigo-400 text-white shadow-lg shadow-indigo-500/30 ring-2 ring-indigo-500/20"
                    : theme === 'dark' 
                      ? "bg-gradient-to-r from-blue-950/60 via-indigo-950/40 to-slate-900 border-indigo-500/50 hover:border-indigo-400 text-white" 
                      : "bg-gradient-to-r from-blue-50 via-indigo-50 to-white border-indigo-200 hover:border-indigo-400 text-slate-800"
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform shadow-md",
                  mode === '3d_classroom' ? "bg-white text-indigo-600 shadow-indigo-900/30" : "bg-gradient-to-br from-blue-500 to-indigo-600 text-white shadow-indigo-500/30"
                )}>
                  <Box size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Virtual 3D</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-gradient-to-r from-amber-500 to-indigo-500 text-white animate-pulse">3D LAB</span>
                  </div>
                  <div className={cn("text-[10px]", mode === '3d_classroom' ? "text-indigo-100" : "opacity-70")}>3D Hall, Science Lab & Prof. Omni AI</div>
                </div>
              </button>

              {/* Universal AI Tutor Chat */}
              <button 
                onClick={() => {
                  triggerHapticFeedback(10);
                  onOpenTool('universal_ai_tutor');
                }}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group relative overflow-hidden",
                  theme === 'dark' 
                    ? "bg-gradient-to-r from-emerald-950/60 via-teal-950/40 to-slate-900 border-emerald-500/50 hover:border-emerald-400 text-white" 
                    : "bg-gradient-to-r from-emerald-50 via-teal-50 to-white border-emerald-200 hover:border-emerald-400 text-slate-800"
                )}
              >
                <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform shadow-md shadow-emerald-500/30">
                  <GraduationCap size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>AI Tutor Chat</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-gradient-to-r from-emerald-500 to-teal-500 text-white animate-pulse">SOCRATIC</span>
                  </div>
                  <div className="text-[10px] opacity-70">Multi-Board, Multi-Language Pedagogical AI</div>
                </div>
              </button>

              {/* Next-Gen STEM Simulation Suite Highlight */}
              <button 
                onClick={() => onOpenTool('nextgen_stem')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group relative overflow-hidden",
                  theme === 'dark' 
                    ? "bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-slate-900 border-indigo-500/50 hover:border-indigo-400 text-white" 
                    : "bg-gradient-to-r from-indigo-50 via-purple-50 to-white border-indigo-200 hover:border-indigo-400 text-slate-800"
                )}
              >
                <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform shadow-md shadow-indigo-500/30">
                  <Sparkles size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Next-Gen STEM Suite</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-gradient-to-r from-indigo-500 to-pink-500 text-white animate-pulse">PRO</span>
                  </div>
                  <div className="text-[10px] opacity-70">3D Geometry, Physics & Proofs</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('spatial_3d')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Box size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">3D Spatial & Molecules</div>
                  <div className="text-[10px] opacity-60">Lattices, quadrics & vector fields</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('physics_lab')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-cyan-500 text-slate-300" : "bg-white border-slate-200 hover:border-cyan-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-cyan-100 dark:bg-cyan-900/30 text-cyan-600 dark:text-cyan-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Orbit size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Advanced Physics Lab</div>
                  <div className="text-[10px] opacity-60">N-Body orbits, optics & Carnot engine</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('proof_checker')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-emerald-500 text-slate-300" : "bg-white border-slate-200 hover:border-emerald-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <ShieldCheck size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Mathematical Proof Checker</div>
                  <div className="text-[10px] opacity-60">Lean 4 deductive verification</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('chemistry_glossary')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FlaskConical size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Chemistry Glossary</div>
                  <div className="text-[10px] opacity-60">Compounds, groups & biomolecules</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('constants_calculator')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Calculator size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Physical Constants & Unit Calc</div>
                  <div className="text-[10px] opacity-60">Molar mass, Nernst cell, gas laws</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('math_tables')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Table size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Mathematical Tables</div>
                  <div className="text-[10px] opacity-60">Interactive Logarithm & Antilogarithm</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('recap_video')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Film size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">AI Study Recap Video</div>
                  <div className="text-[10px] opacity-60">Compile custom video summary of your chat</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('reaction_drill')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Flame size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Reaction Mechanism Drill</div>
                  <div className="text-[10px] opacity-60">Appendix A & B Competitive Trainer</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('chemistry_virtual_lab')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FlaskConical size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Chemistry Virtual Lab</div>
                  <div className="text-[10px] opacity-60">Titration & solubility workbench</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('quick_periodic_table')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Atom size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Quick Periodic Table</div>
                  <div className="text-[10px] opacity-60">Coordination elements & properties</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('interactive_atom_builder')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-violet-100 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Atom size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Interactive Atom Builder</div>
                  <div className="text-[10px] opacity-60">Build atoms, isotopes & ions</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('smart_glossary')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-emerald-500 text-slate-300" : "bg-white border-slate-200 hover:border-emerald-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <BookOpen size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Smart Concept Glossary</div>
                  <div className="text-[10px] opacity-60">Instant tooltips & chemistry terms</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('dynamic_lab_report')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-cyan-500 text-slate-300" : "bg-white border-slate-200 hover:border-cyan-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-cyan-100 dark:bg-cyan-900/30 text-cyan-600 dark:text-cyan-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FileText size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Dynamic Lab Report</div>
                  <div className="text-[10px] opacity-60">Stoichiometry & report generator</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('chemical_reaction_simulator')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-amber-500 text-slate-300" : "bg-white border-slate-200 hover:border-amber-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Flame size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Reaction Simulator</div>
                  <div className="text-[10px] opacity-60">Curly arrows & mechanism steps</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('chemical_reaction_animator')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Atom size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Reaction Animator</div>
                  <div className="text-[10px] opacity-60">Custom reactant SVG transforms</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('quiz')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Lightbulb size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Quiz Generator</div>
                  <div className="text-[10px] opacity-60">Test your knowledge</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('solver')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-violet-100 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Calculator size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Step Solver</div>
                  <div className="text-[10px] opacity-60">Break down problems</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('executive_summary')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <BookOpen size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Executive Study Summary</div>
                  <div className="text-[10px] opacity-60">High-yield brief & concept ladder</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('document')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FileText size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Doc Analyzer</div>
                  <div className="text-[10px] opacity-60">Summarize notes</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('pronunciation')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Volume2 size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Unit Practice</div>
                  <div className="text-[10px] opacity-60">Master scientific units</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('graph')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Globe size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Concept Map</div>
                  <div className="text-[10px] opacity-60">Visual mind mapping</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('cards')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Layers size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Spaced Repetition</div>
                  <div className="text-[10px] opacity-60">SM-2 Adaptive flashcards</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('pomodoro')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Timer size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">Study Soundscapes</div>
                  <div className="text-[10px] opacity-60">Pomodoro focus timers</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('scratchpad')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-amber-150 dark:bg-amber-900/30 text-amber-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Edit3 size={18} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold">State Scratchpad</div>
                  <div className="text-[10px] opacity-60">Interactive sketch & notes</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('seminar')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform relative">
                  <Radio size={18} className="animate-pulse" />
                  <span className="absolute -top-0.5 -right-0.5 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                  </span>
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Live Seminar</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-red-500/10 text-red-500 border border-red-500/20">LIVE</span>
                  </div>
                  <div className="text-[10px] opacity-60">Voice Q&A & simulated classroom</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('virtuallab')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-pink-100 dark:bg-pink-900/30 text-pink-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FlaskConical size={18} className="animate-pulse" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Virtual Laboratory</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-pink-500/10 text-pink-500 border border-pink-500/20">3D</span>
                  </div>
                  <div className="text-[10px] opacity-60">Immersive physics, chemistry & bio sandbox</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('analytics')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <TrendingUp size={18} className="animate-pulse" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Predictive Analytics</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-indigo-500/10 text-indigo-500 border border-indigo-500/20">AI</span>
                  </div>
                  <div className="text-[10px] opacity-60">Diagnostic heatmaps & exam simulator</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('quests')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/30 text-amber-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Gamepad2 size={18} className="animate-bounce" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Adventure Quests</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-amber-500/10 text-amber-500 border border-amber-500/20">RPG</span>
                  </div>
                  <div className="text-[10px] opacity-60">AI Concept bosses & quest lines</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('credentials')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <ShieldCheck size={18} className="animate-pulse" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Micro-Credentials</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">SECURE</span>
                  </div>
                  <div className="text-[10px] opacity-60">On-chain badges & resume exporter</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('colab_rooms')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Users size={18} className="animate-bounce" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Collaborative Rooms</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-indigo-500/10 text-indigo-500 border border-indigo-500/20">LIVE</span>
                  </div>
                  <div className="text-[10px] opacity-60">Co-working canvas & peer games</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('parent_portal')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-slate-800/50 border-slate-700 hover:border-indigo-500 text-slate-300" : "bg-white border-slate-200 hover:border-indigo-300 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-rose-100 dark:bg-rose-900/30 text-rose-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <GraduationCap size={18} className="animate-pulse" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5">
                    <span>Parent & Educator Portal</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-rose-500/10 text-rose-500 border border-rose-500/20">PORTAL</span>
                  </div>
                  <div className="text-[10px] opacity-60">Lesson assignor & diagnostic digests</div>
                </div>
              </button>

              <button 
                onClick={() => onOpenTool('persona_wizard')}
                className={cn(
                  "w-full p-3 rounded-xl border flex items-center gap-3 transition-all group cursor-pointer",
                  theme === 'dark' ? "bg-emerald-950/30 border-emerald-800/50 hover:border-emerald-500 text-slate-300" : "bg-emerald-50/60 border-emerald-200 hover:border-emerald-400 text-slate-700"
                )}
              >
                <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Wand2 size={18} className="animate-bounce" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-bold flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                    <span>Tutor Persona Wizard</span>
                    <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">AI TUTOR</span>
                  </div>
                  <div className="text-[10px] opacity-70">Customize teaching style & Socratic level</div>
                </div>
              </button>
            </div>
          )}
        </section>

        <section>
          <div className="text-xs uppercase tracking-wider text-slate-500 mb-4 font-semibold flex items-center gap-2">
            <User size={14} /> Tutor Personality
          </div>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(CONFIG.TUTORS).map(([id, t]: [string, any]) => (
              <button
                key={id}
                onClick={() => setTutor(id)}
                className={cn(
                  "p-2 rounded-xl border-2 text-center transition-all flex flex-col items-center gap-1",
                  tutor === id 
                    ? "border-indigo-500 bg-indigo-50 text-indigo-700" 
                    : (theme === 'dark' ? "border-slate-800 bg-slate-800/50 text-slate-400 hover:border-slate-700" : "border-slate-100 bg-slate-50 text-slate-500 hover:border-slate-200")
                )}
              >
                <span className="text-xl">{t.icon}</span>
                <span className="text-[10px] font-bold uppercase leading-tight">{t.name.split(' ')[0]}</span>
              </button>
            ))}
          </div>

          {/* Vocal Persona voice configuration menu inside Tutor Personality section */}
          <div className={cn(
            "mt-3.5 border-t border-dashed pt-3.5 space-y-2",
            theme === 'dark' ? "border-slate-800" : "border-slate-200/60"
          )}>
            <div className="flex items-center gap-1.5">
              <Brain size={12} className="text-indigo-500 animate-pulse" />
              <div className="text-[10px] uppercase font-black text-slate-500 dark:text-slate-400 tracking-wider">
                Vocal Persona & Voice Agent
              </div>
            </div>
            
            <select
              value={selectedPersonaId}
              onChange={(e) => onSelectPersonaId(e.target.value)}
              className={cn(
                "w-full p-2 border rounded-xl text-xs cursor-pointer outline-none transition-colors font-semibold",
                theme === 'dark' 
                  ? "bg-slate-800/60 border-slate-750 text-slate-200 hover:border-indigo-500" 
                  : "bg-white border-slate-200 text-slate-800 hover:border-indigo-300 focus:border-indigo-500"
              )}
            >
              {PERSONAS.map(p => (
                <option key={p.id} value={p.id}>
                  {p.icon} {p.name} ({p.accent} Accent)
                </option>
              ))}
            </select>
            
            {(() => {
              const activeP = PERSONAS.find(p => p.id === selectedPersonaId);
              if (!activeP) return null;
              return (
                <p className="text-[10px] text-slate-450 dark:text-slate-500 leading-normal pl-0.5">
                  {activeP.description}
                </p>
              );
            })()}
          </div>

          {/* Tutor Play Modes section below Vocal Persona */}
          <div className={cn(
            "mt-4 border-t border-dashed pt-4 space-y-2.5",
            theme === 'dark' ? "border-slate-800" : "border-slate-200/60"
          )}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Zap size={12} className="text-indigo-500 animate-pulse" />
                <div className="text-[10px] uppercase font-black text-slate-500 dark:text-slate-400 tracking-wider">
                  Tutor Play Mode
                </div>
              </div>
              <span className={cn(
                "text-[8px] px-1.5 py-0.5 rounded-md font-bold uppercase tracking-wider font-mono",
                !isLectureMode 
                  ? "bg-emerald-500/10 text-emerald-500 dark:text-emerald-400" 
                  : lectureSubMode === 'classroom' 
                    ? "bg-indigo-500/10 text-indigo-500 dark:text-indigo-400" 
                    : lectureSubMode === 'quiz' 
                      ? "bg-amber-500/10 text-amber-500 dark:text-amber-400" 
                      : lectureSubMode === 'video_classroom'
                        ? "bg-red-500/10 text-red-500 dark:text-red-400"
                        : "bg-violet-500/10 text-violet-500 dark:text-violet-400"
              )}>
                {
                  !isLectureMode ? "Casual" :
                  lectureSubMode === 'classroom' ? "Classroom" :
                  lectureSubMode === 'quiz' ? "Quiz" :
                  lectureSubMode === 'video_classroom' ? "Video Class" :
                  "Lecture"
                }
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              {/* Mode 1: Standard Chat */}
              <button
                onClick={() => {
                  setIsLectureMode(false);
                  localStorage.setItem('omni_lecture_mode', 'false');
                  playModeTransitionSound('standard');
                  showNotification?.("Standard Conversational Play active. (Fast low-latency speech sync)", "success");
                }}
                className={cn(
                  "col-span-1 px-2 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all duration-200 border cursor-pointer flex items-center justify-center gap-1 text-center",
                  !isLectureMode
                    ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-500 shadow-sm font-black"
                    : theme === 'dark' 
                      ? "bg-slate-800/40 border-slate-750 text-slate-400 hover:text-slate-200" 
                      : "bg-slate-50 border-slate-150 text-slate-600 hover:bg-slate-100/50"
                )}
                title="Classic chatbot text response layout"
              >
                <span>💬 Standard</span>
              </button>

              {/* Mode: Virtual 3D (3D Hall & Science Lab) */}
              <button
                onClick={() => {
                  onOpenTool?.('3d_classroom');
                  showNotification?.("Switched to Virtual 3D Classroom & Lab", "success");
                }}
                className={cn(
                  "col-span-1 px-2 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all duration-200 border cursor-pointer flex items-center justify-center gap-1.5 shadow-sm",
                  mode === '3d_classroom'
                    ? "bg-indigo-600 border-indigo-400 text-white shadow-sm font-black ring-2 ring-indigo-500/20"
                    : theme === 'dark' 
                      ? "bg-indigo-500/15 border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/25" 
                      : "bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100"
                )}
                title="Interactive 3D Virtual Classroom with 3D tutor, complete science lab, holograms & Prof. Omni AI"
              >
                <span>🧊 Virtual 3D</span>
              </button>

              {/* Mode 2: Classroom Slate - Hidden per user request */}
              {true && (
              <button
                onClick={() => {
                  setIsLectureMode(true);
                  setLectureSubMode('classroom');
                  localStorage.setItem('omni_lecture_mode', 'true');
                  localStorage.setItem('omni_lecture_sub_mode', 'classroom');
                  playModeTransitionSound('classroom');
                  showNotification?.("Classroom Slate Play active. (Chalk writing sound FX aligned)", "success");
                }}
                className={cn(
                  "px-2 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all duration-200 border cursor-pointer flex flex-col items-center gap-1 text-center justify-center",
                  (isLectureMode && lectureSubMode === 'classroom')
                    ? "bg-indigo-500/15 border-indigo-500/30 text-indigo-500 shadow-sm font-black"
                    : theme === 'dark' 
                      ? "bg-slate-800/40 border-slate-750 text-slate-400 hover:text-slate-200" 
                      : "bg-slate-50 border-slate-150 text-slate-600 hover:bg-slate-100/50"
                )}
                title="Classroom Lecture mode: Clean high-contrast academic view with audio narration"
              >
                <span>🎓 Classroom</span>
              </button>
              )}

              {/* Mode 3: Auto-Quiz Lecture - Hidden per user request */}
              {true && (
              <button
                onClick={() => {
                  setIsLectureMode(true);
                  setLectureSubMode('quiz');
                  localStorage.setItem('omni_lecture_mode', 'true');
                  localStorage.setItem('omni_lecture_sub_mode', 'quiz');
                  playModeTransitionSound('quiz');
                  showNotification?.("Auto-Quiz Lecture Play active. Interactive quiz check alerts ready.", "info");
                }}
                className={cn(
                  "px-2 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all duration-200 border cursor-pointer flex flex-col items-center gap-1 text-center justify-center",
                  (isLectureMode && lectureSubMode === 'quiz')
                    ? "bg-amber-500/15 border-amber-500/30 text-amber-500 shadow-sm font-black"
                    : theme === 'dark' 
                      ? "bg-slate-800/40 border-slate-750 text-slate-400 hover:text-slate-200" 
                      : "bg-slate-50 border-slate-150 text-slate-600 hover:bg-slate-100/50"
                )}
                title="AI inserts diagnostic conceptual quizzes inside the explanations"
              >
                <span>🧠 Auto-Quiz</span>
              </button>
              )}

              {/* Mode 4: Lecture - Hidden per user request */}
              {true && (
              <button
                onClick={() => {
                  setIsLectureMode(true);
                  setLectureSubMode('lecture');
                  localStorage.setItem('omni_lecture_mode', 'true');
                  localStorage.setItem('omni_lecture_sub_mode', 'lecture');
                  playModeTransitionSound('lecture');
                  showNotification?.("Lecture active. Scholarly continuous lecture play (paced at 0.92x).", "info");
                }}
                className={cn(
                  "px-2 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all duration-200 border cursor-pointer flex flex-col items-center gap-1 text-center justify-center",
                  (isLectureMode && lectureSubMode === 'lecture')
                    ? "bg-violet-500/15 border-violet-500/30 text-violet-500 shadow-sm font-black"
                    : theme === 'dark' 
                      ? "bg-slate-800/40 border-slate-750 text-slate-400 hover:text-slate-200" 
                      : "bg-slate-50 border-slate-150 text-slate-600 hover:bg-slate-100/50"
                )}
                title="A clear standard continuous lecture presentation style"
              >
                <span>🏫 Lecture</span>
              </button>
              )}

              {/* Mode 5: Diagram Play Mode - Hidden per user request */}
              {true && (
              <button
                onClick={() => {
                  onOpenTool?.('diagram_mode');
                  showNotification?.("Switched to Diagram Tutor Play Mode", "success");
                }}
                className={cn(
                  "col-span-2 px-2 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all duration-200 border cursor-pointer flex items-center justify-center gap-1.5 shadow-sm",
                  "bg-amber-500/15 border-amber-500/30 text-amber-400 hover:bg-amber-500/25"
                )}
                title="Dedicated diagram tutor play mode for studying through visual diagrams and hotspot maps"
              >
                <span>📐 Diagram Tutor Play</span>
              </button>
              )}
            </div>
            
            {/* Context status text under buttons */}
            <p className="text-[9px] text-slate-400 leading-normal pl-0.5">
              🔊 Sync: {
                !isLectureMode ? "Casual Native Engine (Fast)" :
                lectureSubMode === 'classroom' ? "Slate & Chalk (Google Cloud)" :
                lectureSubMode === 'quiz' ? "Quiz Alerts (Gemini Premium)" :
                lectureSubMode === 'video_classroom' ? "Cinema Movie Player (Hi-Fi Sync)" :
                "Prof-Lecture (Gemini 0.92x)"
              }
            </p>

            {/* Premium Integrated PWA App Installer in Sidebar - Visible on Maker's device */}
            {isMakerDevice() && (
              <div className={cn(
                "mt-3 pt-2.5 border-t border-dashed flex items-center justify-center w-full",
                theme === 'dark' ? "border-slate-800" : "border-slate-250"
              )}>
                <PWAInstallButton theme={theme} onOpenTool={onOpenTool} compact={!expanded} />
              </div>
            )}
          </div>
        </section>

      </div>
    </div>
  );
};
