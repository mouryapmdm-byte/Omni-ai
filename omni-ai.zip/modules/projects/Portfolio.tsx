export * from '../../src/modules/projects/Portfolio';
import { Portfolio } from '../../src/modules/projects/Portfolio';
export default Portfolio;
