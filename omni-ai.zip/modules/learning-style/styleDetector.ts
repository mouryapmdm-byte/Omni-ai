export * from '../../src/modules/learning-style/styleDetector';
