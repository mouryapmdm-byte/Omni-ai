import React, { useState } from 'react';
import { Download, Smartphone, Check, X, Share } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { cn } from '../lib/utils';
import { PWAInstallGuide } from './PWAInstallGuide';
import { isMakerDevice } from '../lib/makerDevice';

interface PWAInstallButtonProps {
  theme?: 'light' | 'dark';
  compact?: boolean;
  onOpenTool?: (toolId: string) => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  theme = 'dark',
  compact = false,
  onOpenTool,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);

  // Hidden on regular user devices; visible on maker's device
  if (!isMakerDevice()) {
    return null;
  }

  // If already installed and running standalone, show a premium active badge
  if (isInstalled) {
    return (
      <div
        className={cn(
          "inline-flex items-center justify-center gap-1.5 select-none font-bold min-h-[48px]",
          compact
            ? "px-3 py-2 text-[10px] rounded-xl"
            : "px-4 py-2 text-xs rounded-xl shadow-sm",
          theme === 'dark'
            ? "bg-emerald-600/10 text-emerald-400 border border-emerald-500/20"
            : "bg-emerald-50 text-emerald-600 border border-emerald-200"
        )}
      >
        <Check size={compact ? 12 : 14} className="shrink-0" />
        <span className="truncate">Installed ✔</span>
      </div>
    );
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        setJustInstalled(true);
        setTimeout(() => setJustInstalled(false), 4000);
      }
    } else if (onOpenTool) {
      onOpenTool('pwa_install');
    } else {
      setShowGuide(true);
    }
  };

  return (
    <>
      <button
        onClick={handleInstallClick}
        aria-label="Install App on Any Device"
        title="Install Omni AI as an app on your phone, tablet, or desktop"
        className={cn(
          "inline-flex items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 cursor-pointer font-bold select-none min-h-[48px]",
          compact
            ? "px-3.5 py-2 text-[10px] rounded-xl"
            : "px-4.5 py-2.5 text-xs rounded-2xl shadow-sm",
          theme === 'dark'
            ? "bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-indigo-600/20 border border-indigo-400/30"
            : "bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white shadow-indigo-600/15"
        )}
      >
        {isInstallable ? (
          <Download size={compact ? 12 : 14} className="shrink-0 animate-bounce" />
        ) : isIOS ? (
          <Share size={compact ? 12 : 14} className="shrink-0" />
        ) : (
          <Smartphone size={compact ? 12 : 14} className="shrink-0" />
        )}
        <span className="truncate">
          {compact
            ? (isIOS ? 'Install iOS' : 'Install App')
            : (isIOS ? 'Install on iPhone / iPad' : isAndroid ? 'Install on Android' : 'Install App')}
        </span>
      </button>

      {/* Cross-Device Guided Installation Modal Fallback */}
      {showGuide && (
        <div 
          className="fixed inset-0 z-[3000] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setShowGuide(false)}
        >
          <div
            className={cn(
              "w-full max-w-md rounded-3xl p-6 shadow-2xl border relative space-y-5 animate-in zoom-in-95 duration-200",
              theme === 'dark'
                ? "bg-slate-900 border-slate-700 text-slate-100 shadow-indigo-950/50"
                : "bg-white border-slate-200 text-slate-800 shadow-xl"
            )}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-indigo-500" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold tracking-tight">
                    Install on Any Device
                  </h3>
                  <p className="text-xs text-slate-400">
                    Phone, Tablet, Laptop, or Foldable Screen
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowGuide(false)}
                className="p-1.5 rounded-xl hover:bg-slate-800/20 text-slate-400 hover:text-slate-100 transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Main Interactive Guide Component */}
            <PWAInstallGuide theme={theme} onClose={() => setShowGuide(false)} />
          </div>
        </div>
      )}
    </>
  );
};
