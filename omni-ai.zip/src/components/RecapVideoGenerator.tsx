import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, Loader2, Play, Pause, Volume2, VolumeX, Download, 
  CheckCircle2, AlertCircle, X, ChevronRight, FileText, Layers, 
  Film, Copy, Check, RotateCcw, Maximize, Activity, Award, Printer, BookOpen
} from 'lucide-react';
import { generateAIResponse, generateVideo } from '../lib/gemini';
import { cn, cleanNaturalLanguageForScreen } from '../lib/utils';
import { stripAllRawMarkdown } from '../lib/streaming/cleanStreamingMarkdown';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: number;
}

interface RecapVideoGeneratorProps {
  messages: Message[];
  subject: string;
  topic: string;
  theme: 'light' | 'dark';
  onSaveToNotes: (note: {
    title: string;
    summary: string;
    keyConcepts: string[];
    subject: string;
    topic: string;
  }) => void;
  showNotification: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onClose: () => void;
}

interface Slide {
  slideTitle: string;
  narrationText: string;
  visualDescription: string;
}

interface StoryboardData {
  title: string;
  summary: string;
  keyConcepts: string[];
  slides: Slide[];
}

export const RecapVideoGenerator: React.FC<RecapVideoGeneratorProps> = ({
  messages,
  subject,
  topic,
  theme,
  onSaveToNotes,
  showNotification,
  onClose
}) => {
  // Filter messages for active learning logs
  const chatProgress = React.useMemo(() => {
    return messages.filter(m => m.id !== 'welcome' && m.content.trim() !== '');
  }, [messages]);

  const totalWords = React.useMemo(() => {
    return chatProgress.reduce((acc, m) => acc + m.content.split(/\s+/).filter(Boolean).length, 0);
  }, [chatProgress]);

  // Average reading speed ~200 words per minute
  const readingTimeMinutes = totalWords / 200;
  const readingTimeText = readingTimeMinutes < 1 
    ? `${Math.max(1, Math.round(totalWords / 3.3))} sec read` 
    : `~${readingTimeMinutes.toFixed(1)} min read`;

  // Progress towards a standard 1,000-word study session goal (capped at 100%)
  const readingProgressPercent = Math.min(100, Math.round((totalWords / 1000) * 100));

  const hasChatHistory = chatProgress.length >= 2;
  const [useFallbackTopic, setUseFallbackTopic] = useState(!hasChatHistory);

  // Core state variables
  const [isCompiling, setIsCompiling] = useState(false);
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [statusText, setStatusText] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Compiled video & details
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [storyboard, setStoryboard] = useState<StoryboardData | null>(null);
  const [activeTab, setActiveTab] = useState<'concepts' | 'storyboard' | 'study_guide'>('concepts');

  // Video playback states
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [videoProgress, setVideoProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  // Refs for video player elements
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Action feedback states
  const [copiedText, setCopiedText] = useState(false);
  const [savedToNotes, setSavedToNotes] = useState(false);

  // Safe subject display
  const subjectDisplay = (subject || 'Chemistry').replace(/_/g, ' ').toUpperCase();

  const handleCompileRecapVideo = async () => {
    setIsCompiling(true);
    setProgress(0);
    setError(null);
    setVideoUrl(null);
    setStoryboard(null);
    setSavedToNotes(false);

    const logList = [
      `[System] Initializing Omni Study Recap Compiler v3.1...`,
      `[System] Theme profile parsed: ${theme.toUpperCase()} MODE.`
    ];
    setLogs([...logList]);
    setStatusText('Reviewing your learning progress logs...');

    try {
      // Step 1: Analyze study logs & generate a detailed visual storyboard with Gemini 3
      await new Promise(resolve => setTimeout(resolve, 800));
      setProgress(15);
      setStatusText('Drafting visual slide diagrams...');

      const textLogs = chatProgress.length > 0 && !useFallbackTopic
        ? chatProgress.map(m => `${m.sender.toUpperCase()}: ${stripAllRawMarkdown(cleanNaturalLanguageForScreen(m.content))}`).join('\n\n')
        : '';

      const updatedLogs = [
        ...logList,
        textLogs 
          ? `[Data] Scanned ${chatProgress.length} conversational exchanges from current session.` 
          : `[Data] No active conversation logs. Using current curricular topic: ${topic}.`,
        `[LLM] Invoking Gemini 3 Flash to synthesize custom recap storyboard in structured layout...`
      ];
      setLogs([...updatedLogs]);

      const storyboardPrompt = `Review the following educational tutoring study progress and generate a highly engaging, structured, and customized video lesson storyboard in JSON.
${textLogs 
  ? `Based on this chat history between a student and an AI Tutor on ${subject} - ${topic}:
CHAT HISTORY:
${textLogs}`
  : `Based on the general textbook study topic of ${subject} - ${topic} for a student learning chemistry.`
}

You must output a strictly structured JSON block with EXACTLY the following JSON format. No markdown blocks, no backticks, no comments.
{
  "title": "A short, descriptive, professional title for the recap (e.g., 'Recap: Carbonyl Compounds')",
  "summary": "A concise paragraph (2-3 sentences) summarizing the core concepts learned, explanations provided, and study milestones.",
  "keyConcepts": [
    "A vital concept, rule, or formula discussed (maximum 12 words per item)",
    "Another vital item discussed",
    "Third vital item discussed"
  ],
  "slides": [
    {
      "slideTitle": "Slide 1 Title",
      "narrationText": "2-3 highly educational sentences representing the narrator's voiceover explaining this scene.",
      "visualDescription": "Detailed instructions of what is visually shown on the slide (vector schematics, chemical structures, molecular diagrams, equations)."
    },
    {
      "slideTitle": "Slide 2 Title",
      "narrationText": "2-3 highly educational sentences explaining this scene.",
      "visualDescription": "Detailed instructions of what is visually shown on the slide."
    },
    {
      "slideTitle": "Slide 3 Title",
      "narrationText": "2-3 highly educational sentences explaining this scene.",
      "visualDescription": "Detailed instructions of what is visually shown on the slide."
    }
  ]
}`;

      const aiResponse = await generateAIResponse(storyboardPrompt, {
        model: 'gemini-3.6-flash',
        responseMimeType: 'application/json'
      });

      let parsedStoryboard: StoryboardData;
      try {
        parsedStoryboard = JSON.parse(aiResponse.trim());
      } catch (e) {
        console.error("Failed to parse storyboard JSON", e);
        // Fallback storyboard structure
        parsedStoryboard = {
          title: `Study Recap: ${topic}`,
          summary: `This lesson summarized the critical foundations and theoretical formulas of ${topic} under the subject of ${subjectDisplay.toLowerCase()}.`,
          keyConcepts: [
            `Core definitions of ${topic}`,
            `Structural relationships and reaction behaviors of ${topic}`,
            `Analytical problem-solving formulas and scientific rules`
          ],
          slides: [
            {
              slideTitle: `1. Introduction to ${topic}`,
              narrationText: `Let's review the fundamental structure and properties of ${topic}. These principles form the bedrock of ${subjectDisplay.toLowerCase()}.`,
              visualDescription: `Chalkboard shows chemical equations and step-by-step structural formulas for ${topic}.`
            },
            {
              slideTitle: `2. Critical Mechanism and Rules`,
              narrationText: `Next, we analyze the reaction pathways, governing parameters, and physical laws defining these processes.`,
              visualDescription: `A neat schematic flow diagram detailing molecular states and intermediates.`
            },
            {
              slideTitle: `3. Analytical Problem Solving`,
              narrationText: `Finally, we apply our equations to solve core problems and calculate exact values under standard thermodynamic conditions.`,
              visualDescription: `Blackboard reveals standard formula derivations with clean margins.`
            }
          ]
        };
      }

      // Clean all fields of parsedStoryboard to ensure zero raw markdown or delimiters leak into presentation
      const cleanStoryboard: StoryboardData = {
        title: stripAllRawMarkdown(parsedStoryboard.title || `Study Recap: ${topic}`),
        summary: stripAllRawMarkdown(cleanNaturalLanguageForScreen(parsedStoryboard.summary || '')),
        keyConcepts: (parsedStoryboard.keyConcepts || []).map(c => stripAllRawMarkdown(cleanNaturalLanguageForScreen(c))),
        slides: (parsedStoryboard.slides || []).map(s => ({
          slideTitle: stripAllRawMarkdown(s.slideTitle || 'Lecture Key Point'),
          narrationText: stripAllRawMarkdown(cleanNaturalLanguageForScreen(s.narrationText || '')),
          visualDescription: stripAllRawMarkdown(s.visualDescription || '')
        }))
      };

      setStoryboard(cleanStoryboard);
      setProgress(50);
      setStatusText('Synthesizing professional educational voiceover tracks...');
      const finalLogsWithStoryboard = [
        ...updatedLogs,
        `[Storyboard] "${parsedStoryboard.title}" generated successfully with ${parsedStoryboard.slides.length} scenes.`,
        `[Audio] Narrations drafted. Preparing sound frequencies...`
      ];
      setLogs([...finalLogsWithStoryboard]);

      // Step 2: Invoke Video Generation Tool API
      await new Promise(resolve => setTimeout(resolve, 1000));
      setProgress(75);
      setStatusText('Invoking the Video Generation Engine...');
      const logsWithVideoStarting = [
        ...finalLogsWithStoryboard,
        `[Render] Initiating AI Video Generation using video compile pipeline...`,
        `[Render] Prompt: "Educational presentation lecture: ${parsedStoryboard.title}"`
      ];
      setLogs([...logsWithVideoStarting]);

      const videoPrompt = `An educational, high-definition presentation video illustrating: ${parsedStoryboard.title}. Visual elements: ${parsedStoryboard.slides.map(s => s.visualDescription).join(' | ')}`;
      const generatedUri = await generateVideo(videoPrompt);

      if (generatedUri) {
        setVideoUrl(generatedUri);
        setProgress(100);
        setStatusText('Compilation success!');
        setLogs(prev => [
          ...prev,
          `[Render] Finished rendering high-fidelity video file.`,
          `[System] Initializing media player controls...`
        ]);
        showNotification('Recap video compiled successfully!', 'success');
        
        // Wait a small moment before hiding loader
        setTimeout(() => {
          setIsCompiling(false);
        }, 600);
      } else {
        throw new Error("Video compiler failed to return videoUri");
      }
    } catch (err) {
      console.error(err);
      setError('An error occurred while compiling your study recap video. Please try again!');
      showNotification('Failed to compile recap video.', 'error');
      setIsCompiling(false);
    }
  };

  // Video controls
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play().catch(() => {});
    }
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleSpeedChange = (speed: number) => {
    if (!videoRef.current) return;
    videoRef.current.playbackRate = speed;
    setPlaybackSpeed(speed);
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    setVideoProgress(videoRef.current.currentTime);
  };

  const handleLoadedMetadata = () => {
    if (!videoRef.current) return;
    setDuration(videoRef.current.duration);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!videoRef.current) return;
    const time = Number(e.target.value);
    videoRef.current.currentTime = time;
    setVideoProgress(time);
  };

  const handleRestartVideo = () => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = 0;
    videoRef.current.play().catch(() => {});
    setIsPlaying(true);
  };

  // Copy Recap to Clipboard
  const handleCopyToClipboard = () => {
    if (!storyboard) return;
    const text = `📚 STUDY RECAP: ${storyboard.title.toUpperCase()}
Subject: ${subjectDisplay} | Topic: ${topic}

🎯 KEY CONCEPTS LEARNED:
${storyboard.keyConcepts.map((c, idx) => `${idx + 1}. ${c}`).join('\n')}

📖 RECAP SUMMARY:
${storyboard.summary}

📺 VIDEO LESSON STORYBOARD:
${storyboard.slides.map((s, idx) => `[Scene ${idx + 1}] ${s.slideTitle}
- Narration: ${s.narrationText}
- Blackboard: ${s.visualDescription}`).join('\n\n')}

Generated by Omni AI Study Assistant on ${new Date().toLocaleString()}`;

    navigator.clipboard.writeText(text)
      .then(() => {
        setCopiedText(true);
        showNotification('Recap copied to clipboard!', 'success');
        setTimeout(() => setCopiedText(false), 2000);
      })
      .catch(() => {
        showNotification('Failed to copy text.', 'error');
      });
  };

  // Save to study notes
  const handleSaveNotes = () => {
    if (!storyboard) return;
    onSaveToNotes({
      title: storyboard.title,
      summary: storyboard.summary,
      keyConcepts: storyboard.keyConcepts,
      subject: subject,
      topic: topic
    });
    setSavedToNotes(true);
    showNotification('Recap saved to your Study Notes!', 'success');
  };

  // Helper to format time (e.g. 0:24)
  const formatTime = (timeInSeconds: number) => {
    const mins = Math.floor(timeInSeconds / 60);
    const secs = Math.floor(timeInSeconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="w-full flex flex-col gap-6">
      {/* Intro Header & Stats Panel */}
      {!videoUrl && !isCompiling && (
        <div className={cn(
          "p-6 rounded-2xl border text-center max-w-2xl mx-auto my-4 space-y-6 animate-in fade-in zoom-in-95 duration-300",
          theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"
        )}>
          <div className="mx-auto w-14 h-14 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-500 rounded-full flex items-center justify-center shadow-md">
            <Film size={26} className="animate-pulse" />
          </div>

          <div className="space-y-2">
            <span className="text-[11px] font-black uppercase bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 px-2.5 py-1 rounded">
              {subjectDisplay}
            </span>
            <h3 className="text-xl font-bold tracking-tight text-indigo-500">
              AI Study Recap Video Compiler
            </h3>
            <p className="text-xs opacity-80 max-w-md mx-auto leading-relaxed">
              Compile an engaging, high-fidelity recap video and custom study guide detailing the exact chemical concepts, equations, and rules covered in your recent chats!
            </p>
          </div>

          {/* Chat History Status Card / Session Stats Widget */}
          <div className={cn(
            "p-5 rounded-xl border flex flex-col gap-3 text-left",
            theme === 'dark' ? "bg-slate-800/40 border-slate-700/60" : "bg-slate-50 border-slate-200"
          )}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity size={15} className="text-emerald-500" />
                <span className="text-xs font-black uppercase tracking-wider">Session Stats & Reading Time</span>
              </div>
              {hasChatHistory ? (
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full font-black uppercase">
                  <CheckCircle2 size={12} /> Ready ({chatProgress.length} msgs)
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-[10px] text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full font-black uppercase">
                  <AlertCircle size={12} /> Empty Log
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className={cn("p-3 rounded-lg border", theme === 'dark' ? "bg-slate-900/50 border-slate-700/40" : "bg-white border-slate-200/80")}>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Conversation Words</span>
                <span className="text-base font-black text-indigo-500">{totalWords} words</span>
              </div>
              <div className={cn("p-3 rounded-lg border", theme === 'dark' ? "bg-slate-900/50 border-slate-700/40" : "bg-white border-slate-200/80")}>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Est. Reading Time</span>
                <span className="text-base font-black text-emerald-500">{readingTimeText}</span>
              </div>
            </div>

            {/* Reading Time Progress Bar */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-[11px] font-bold">
                <span className="text-slate-500 dark:text-slate-400">Full Conversation Reading Progress</span>
                <span className="text-indigo-500 font-mono">{readingProgressPercent}%</span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <motion.div 
                  className="bg-indigo-600 h-full rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${readingProgressPercent}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>
          </div>

          {/* Toggle fallback option if chat is empty */}
          {!hasChatHistory && (
            <div className="text-xs p-3 rounded-lg border border-indigo-500/10 bg-indigo-500/5 text-indigo-600 dark:text-indigo-400 text-left">
              💡 <strong>System Fallback Active:</strong> We will construct a pristine learning storyboard based directly on the selected curriculum topic: <strong>{topic}</strong>.
            </div>
          )}

          {hasChatHistory && (
            <div className="flex items-center justify-center gap-4 text-xs border-t dark:border-slate-800 border-slate-100 pt-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={useFallbackTopic} 
                  onChange={(e) => setUseFallbackTopic(e.target.checked)} 
                  className="rounded text-indigo-600 border-slate-300 dark:border-slate-700 focus:ring-indigo-500"
                />
                <span>Generate textbook-standard topic recap instead of using chat history</span>
              </label>
            </div>
          )}

          {/* Compile Trigger Button */}
          <button
            onClick={handleCompileRecapVideo}
            className="w-full py-3.5 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2.5 cursor-pointer shadow-lg shadow-indigo-600/25 active:scale-98 text-sm"
          >
            <Sparkles size={16} />
            Compile Custom Study Video
          </button>
        </div>
      )}

      {/* Compiling State Terminal */}
      {isCompiling && (
        <div className={cn(
          "p-6 rounded-2xl border max-w-xl mx-auto w-full space-y-6 animate-in fade-in duration-300",
          theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-slate-50 border-slate-200"
        )}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 text-xs font-black text-indigo-500 uppercase tracking-widest">
              <Loader2 size={14} className="animate-spin" />
              <span>Compilation Terminal</span>
            </div>
            <div className="text-[10px] bg-indigo-500/10 text-indigo-500 font-bold px-2 py-0.5 rounded">
              {progress}%
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <motion.div 
              className="bg-indigo-600 h-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.4 }}
            />
          </div>

          <div className="text-center">
            <p className="text-xs font-bold text-slate-700 dark:text-slate-300 animate-pulse">
              {statusText}
            </p>
          </div>

          {/* Terminal Logs Container */}
          <div className="bg-slate-950 rounded-xl p-4 font-mono text-[10px] text-slate-400 space-y-1.5 h-44 overflow-y-auto border border-slate-800">
            {logs.map((log, index) => (
              <div key={index} className="flex gap-2 leading-relaxed">
                <span className="text-indigo-400 select-none">&gt;</span>
                <span className={cn(
                  log.includes('[System]') && "text-slate-200",
                  log.includes('[Data]') && "text-cyan-400",
                  log.includes('[LLM]') && "text-amber-400",
                  log.includes('[Render]') && "text-rose-400",
                  log.includes('[Storyboard]') && "text-emerald-400"
                )}>
                  {log}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl border border-rose-500/20 bg-rose-500/5 text-rose-500 max-w-md mx-auto flex items-start gap-3">
          <AlertCircle size={18} className="flex-shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs">
            <div className="font-bold">Compilation Failed</div>
            <div>{error}</div>
            <button 
              onClick={handleCompileRecapVideo} 
              className="mt-2 text-[10px] font-black uppercase underline hover:opacity-80"
            >
              Retry Compilation
            </button>
          </div>
        </div>
      )}

      {/* Generated Video Player & Study Guide Dashboard */}
      {videoUrl && storyboard && !isCompiling && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-in fade-in duration-300">
          
          {/* Left Column: Premium Custom Video Player */}
          <div className="lg:col-span-7 space-y-4">
            <div className={cn(
              "relative rounded-2xl overflow-hidden border bg-black shadow-2xl group",
              theme === 'dark' ? "border-slate-800" : "border-slate-200"
            )}>
              {/* Aspect Ratio Box 16:9 */}
              <div className="aspect-video relative w-full flex items-center justify-center">
                <video
                  ref={videoRef}
                  src={videoUrl}
                  onClick={togglePlay}
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  className="w-full h-full object-cover cursor-pointer"
                  loop
                />

                {/* Big Center Play Pause Overlay on Hover */}
                <AnimatePresence>
                  {!isPlaying && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      onClick={togglePlay}
                      className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full flex items-center justify-center shadow-lg transition-all scale-hover">
                        <Play size={28} className="ml-1" />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Custom Video Control bar */}
              <div className="p-3.5 bg-slate-900 text-slate-100 flex flex-col gap-2.5">
                {/* Seekbar Slider */}
                <div className="flex items-center gap-3 w-full">
                  <span className="text-[10px] font-mono opacity-80 select-none">
                    {formatTime(videoProgress)}
                  </span>
                  <input
                    type="range"
                    min={0}
                    max={duration || 100}
                    value={videoProgress}
                    onChange={handleSeek}
                    className="flex-1 accent-indigo-500 bg-slate-700 h-1 rounded-lg cursor-pointer hover:h-1.5 transition-all"
                  />
                  <span className="text-[10px] font-mono opacity-80 select-none">
                    {formatTime(duration)}
                  </span>
                </div>

                {/* Controls row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={togglePlay} 
                      className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-200 hover:text-white transition-colors cursor-pointer"
                      title={isPlaying ? "Pause" : "Play"}
                    >
                      {isPlaying ? <Pause size={15} /> : <Play size={15} />}
                    </button>

                    <button 
                      onClick={handleRestartVideo} 
                      className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-200 hover:text-white transition-colors cursor-pointer"
                      title="Restart Video"
                    >
                      <RotateCcw size={15} />
                    </button>

                    {/* Volume toggle */}
                    <button 
                      onClick={toggleMute} 
                      className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-200 hover:text-white transition-colors cursor-pointer"
                      title={isMuted ? "Unmute" : "Mute"}
                    >
                      {isMuted ? <VolumeX size={15} className="text-rose-500" /> : <Volume2 size={15} />}
                    </button>

                    {/* Speed dropdown buttons */}
                    <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-0.5 ml-1">
                      {[1, 1.5, 2].map((speed) => (
                        <button
                          key={speed}
                          onClick={() => handleSpeedChange(speed)}
                          className={cn(
                            "px-2 py-0.5 rounded text-[9px] font-black cursor-pointer transition-all",
                            playbackSpeed === speed 
                              ? "bg-indigo-600 text-white" 
                              : "text-slate-400 hover:text-slate-200"
                          )}
                        >
                          {speed}x
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Native Download */}
                    <a 
                      href={videoUrl} 
                      download={`${storyboard.title.replace(/[^a-z0-9]+/gi, '_')}.mp4`}
                      className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-200 hover:text-white transition-colors cursor-pointer flex items-center justify-center"
                      title="Download Video File"
                    >
                      <Download size={15} />
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Video Lesson Description Card */}
            <div className={cn(
              "p-4 rounded-xl border space-y-2",
              theme === 'dark' ? "bg-slate-900/40 border-slate-800" : "bg-white border-slate-200"
            )}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase text-indigo-500 tracking-wider">
                  Recap Video Active Segment
                </span>
                <span className="text-[10px] opacity-60">Compiled on {new Date().toLocaleDateString()}</span>
              </div>
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                {storyboard.title}
              </h4>
              <p className="text-xs opacity-80 leading-relaxed">
                {storyboard.summary}
              </p>
            </div>
          </div>

          {/* Right Column: Custom Study Guide, Storyboard & Saved Notes Tabs */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            
            {/* Tabs Selector row */}
            <div className={cn(
              "p-1 rounded-xl border flex gap-1",
              theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-slate-100 border-slate-200"
            )}>
              <button
                onClick={() => setActiveTab('concepts')}
                className={cn(
                  "flex-1 py-2 text-center rounded-lg text-xs font-black transition-all cursor-pointer",
                  activeTab === 'concepts'
                    ? theme === 'dark' ? "bg-slate-850 text-indigo-400 border border-slate-800" : "bg-white text-indigo-600 shadow-sm"
                    : "opacity-60 hover:opacity-100"
                )}
              >
                Concepts
              </button>
              <button
                onClick={() => setActiveTab('storyboard')}
                className={cn(
                  "flex-1 py-2 text-center rounded-lg text-xs font-black transition-all cursor-pointer",
                  activeTab === 'storyboard'
                    ? theme === 'dark' ? "bg-slate-850 text-indigo-400 border border-slate-800" : "bg-white text-indigo-600 shadow-sm"
                    : "opacity-60 hover:opacity-100"
                )}
              >
                Storyboard
              </button>
              <button
                onClick={() => setActiveTab('study_guide')}
                className={cn(
                  "flex-1 py-2 text-center rounded-lg text-xs font-black transition-all cursor-pointer",
                  activeTab === 'study_guide'
                    ? theme === 'dark' ? "bg-slate-850 text-indigo-400 border border-slate-800" : "bg-white text-indigo-600 shadow-sm"
                    : "opacity-60 hover:opacity-100"
                )}
              >
                Study Guide
              </button>
            </div>

            {/* Active Tab Panel */}
            <div className={cn(
              "flex-1 p-5 rounded-2xl border min-h-[300px] flex flex-col justify-between",
              theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"
            )}>
              <div>
                {/* 1. Concepts covered tab */}
                {activeTab === 'concepts' && (
                  <div className="space-y-4 animate-in fade-in duration-200">
                    <div className="space-y-1">
                      <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                        🎯 Core Concepts Extracted
                      </h4>
                      <p className="text-[10px] opacity-60 leading-normal">
                        Key conceptual blocks identified by analyzing your chat progress:
                      </p>
                    </div>

                    <div className="space-y-2.5">
                      {storyboard.keyConcepts.map((concept, idx) => (
                        <div 
                          key={idx} 
                          className={cn(
                            "p-3 rounded-xl border flex items-start gap-3 transition-colors",
                            theme === 'dark' ? "bg-slate-850 border-slate-800" : "bg-slate-50 border-slate-200/80"
                          )}
                        >
                          <div className="w-5 h-5 bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-black text-[10px] mt-0.5 flex-shrink-0">
                            {idx + 1}
                          </div>
                          <span className="text-xs font-medium leading-relaxed">{concept}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 2. Slide storyboards tab */}
                {activeTab === 'storyboard' && (
                  <div className="space-y-4 h-[350px] overflow-y-auto pr-1 animate-in fade-in duration-200">
                    <div className="space-y-1">
                      <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                        🎬 Video Scene Breakdown
                      </h4>
                      <p className="text-[10px] opacity-60">
                        Chalkboard actions and verbal scripts synchronized inside your generated video:
                      </p>
                    </div>

                    <div className="space-y-4 divide-y dark:divide-slate-800 divide-slate-150">
                      {storyboard.slides.map((slide, idx) => (
                        <div key={idx} className={cn("space-y-2.5", idx > 0 && "pt-4")}>
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-1.5 py-0.5 rounded font-black uppercase">
                              Scene {idx + 1}
                            </span>
                            <span className="text-xs font-bold text-indigo-500 leading-tight">
                              {slide.slideTitle}
                            </span>
                          </div>

                          <div className="space-y-1.5 text-xs">
                            <div className="p-2.5 rounded-lg bg-indigo-500/5 border border-indigo-500/10 leading-relaxed text-[11px] opacity-90">
                              🗣️ <strong>Dialogue:</strong> &ldquo;{slide.narrationText}&rdquo;
                            </div>
                            <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-850 leading-relaxed text-[10px] opacity-80">
                              ✏️ <strong>Blackboard Graphics:</strong> {slide.visualDescription}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. Study Guide Notes */}
                {activeTab === 'study_guide' && (
                  <div className="space-y-4 animate-in fade-in duration-200">
                    <div className="space-y-1">
                      <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                        📝 Markdown Study Recap
                      </h4>
                      <p className="text-[10px] opacity-60">
                        A portable study guide compiled from your tutoring session:
                      </p>
                    </div>

                    <div className={cn(
                      "p-4 rounded-xl border font-mono text-[11px] h-64 overflow-y-auto space-y-3 leading-relaxed",
                      theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-200"
                    )}>
                      <div><strong># {storyboard.title}</strong></div>
                      <div>**Subject:** {subjectDisplay} <br />**Topic:** {topic}</div>
                      
                      <div className="border-t dark:border-slate-800 border-slate-200 pt-2">
                        <strong>## 🎯 Core Learning Concepts</strong>
                        {storyboard.keyConcepts.map((c, idx) => (
                          <div key={idx}>- {c}</div>
                        ))}
                      </div>

                      <div className="border-t dark:border-slate-800 border-slate-200 pt-2">
                        <strong>## 📖 Session Summary</strong>
                        <div>{storyboard.summary}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action utilities row at the bottom of the card */}
              <div className="grid grid-cols-2 gap-2 pt-4 border-t dark:border-slate-800 border-slate-100 mt-4">
                <button
                  onClick={handleCopyToClipboard}
                  className={cn(
                    "flex items-center justify-center gap-2 py-2 px-3 rounded-xl border text-xs font-bold transition-all cursor-pointer",
                    theme === 'dark' 
                      ? "border-slate-800 hover:bg-slate-800 text-slate-300" 
                      : "border-slate-200 hover:bg-slate-50 text-slate-700"
                  )}
                >
                  {copiedText ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                  <span>{copiedText ? 'Copied!' : 'Copy to Clipboard'}</span>
                </button>

                <button
                  onClick={handleSaveNotes}
                  disabled={savedToNotes}
                  className={cn(
                    "flex items-center justify-center gap-2 py-2 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer text-white shadow-sm",
                    savedToNotes 
                      ? "bg-green-600 cursor-not-allowed" 
                      : "bg-indigo-600 hover:bg-indigo-700 active:scale-95"
                  )}
                >
                  {savedToNotes ? <Check size={14} /> : <Sparkles size={14} />}
                  <span>{savedToNotes ? 'Saved to Notes!' : 'Save to Study Notes'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Control Actions footer row */}
      <div className="flex justify-end gap-3 pt-4 border-t dark:border-slate-800 border-slate-150">
        {videoUrl && (
          <button
            onClick={() => {
              setVideoUrl(null);
              setStoryboard(null);
              setLogs([]);
              setProgress(0);
            }}
            className={cn(
              "px-4 py-2.5 rounded-xl border text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all cursor-pointer",
              theme === 'dark' ? "border-slate-800 text-slate-300" : "border-slate-200 text-slate-700"
            )}
          >
            Compile New Recap
          </button>
        )}
        <button
          onClick={onClose}
          className="px-5 py-2.5 bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900 font-bold text-xs rounded-xl hover:opacity-90 active:scale-95 transition-all cursor-pointer"
        >
          Close Utility
        </button>
      </div>
    </div>
  );
};
