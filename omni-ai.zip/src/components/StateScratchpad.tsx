import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Eraser, 
  Trash2, 
  Undo2, 
  Redo2, 
  Save, 
  Sparkles, 
  Send, 
  Check, 
  Edit3, 
  Type, 
  Download,
  BookOpen,
  ChevronRight,
  Maximize2,
  Minimize2,
  Volume2
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface StateScratchpadProps {
  theme: 'light' | 'dark';
  subject: string;
  topic: string;
  onClose: () => void;
  onSendToChat?: (text: string, imageBase64?: string) => void;
  onSaveToNotes?: (note: { title: string; summary: string; keyConcepts: string[]; subject: string; topic: string }) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onExpandFullscreen?: () => void;
}

const COLORS = [
  { name: 'Chalk White', light: '#475569', dark: '#f8fafc' },
  { name: 'Neon Amber', light: '#d97706', dark: '#f59e0b' },
  { name: 'Emerald', light: '#16a34a', dark: '#10b981' },
  { name: 'Neon Cyan', light: '#0284c7', dark: '#06b6d4' },
  { name: 'Sunset Orange', light: '#ea580c', dark: '#f97316' },
  { name: 'Royal Purple', light: '#7c3aed', dark: '#a78bfa' }
];

export const StateScratchpad: React.FC<StateScratchpadProps> = ({
  theme,
  subject,
  topic,
  onClose,
  onSendToChat,
  onSaveToNotes,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'draw' | 'notes'>('draw');
  
  // State for Canvas
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushColor, setBrushColor] = useState(theme === 'dark' ? COLORS[0].dark : COLORS[0].light);
  const [brushSize, setBrushSize] = useState(3);
  const [isEraser, setIsEraser] = useState(false);
  const [isHighlighter, setIsHighlighter] = useState(false);
  
  // History stack for Canvas Undo/Redo
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // Notes state
  const [noteText, setNoteText] = useState('');
  const [noteTitle, setNoteTitle] = useState('');
  const [isSavingNote, setIsSavingNote] = useState(false);

  // Partitioned storage keys
  const storageNoteKey = `omni_scratchpad_notes_${subject}_${topic}`;
  const storageDrawKey = `omni_scratchpad_drawing_${subject}_${topic}`;

  // Load persisted note content when topic/subject changes
  useEffect(() => {
    const savedNoteText = localStorage.getItem(storageNoteKey);
    setNoteText(savedNoteText || '');
    setNoteTitle(`${topic.replace(/_/g, ' ').toUpperCase()} Study Session Notes`);
  }, [subject, topic]);

  // Handle canvas color default update based on theme
  useEffect(() => {
    // If drawing with the default color, update it to match theme's primary color
    if (brushColor === COLORS[0].dark && theme === 'light') {
      setBrushColor(COLORS[0].light);
    } else if (brushColor === COLORS[0].light && theme === 'dark') {
      setBrushColor(COLORS[0].dark);
    }
  }, [theme]);

  // Load and apply drawing state
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Reset history when topic changes
    const savedDrawData = localStorage.getItem(storageDrawKey);
    if (savedDrawData) {
      const img = new Image();
      img.src = savedDrawData;
      img.onload = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        // Fill base background depending on theme
        ctx.fillStyle = theme === 'dark' ? '#122418' : '#faf9f6'; // blackboard vs off-white paper
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
        
        // Populate initial history state
        setHistory([savedDrawData]);
        setHistoryIndex(0);
      };
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = theme === 'dark' ? '#122418' : '#faf9f6';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      const emptyState = canvas.toDataURL();
      setHistory([emptyState]);
      setHistoryIndex(0);
    }
  }, [subject, topic, theme]);

  // Handle ResizeObserver on Canvas container
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width === 0 || height === 0) continue;

        // Create temporary canvas to preserve contents
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        const tempCtx = tempCanvas.getContext('2d');
        if (tempCtx) {
          tempCtx.drawImage(canvas, 0, 0);
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = theme === 'dark' ? '#122418' : '#faf9f6';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(tempCanvas, 0, 0, width, height);
          
          // Re-apply styles
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
        }
      }
    });

    resizeObserver.observe(container);
    return () => resizeObserver.disconnect();
  }, [theme]);

  // Save drawing state periodically or on change
  const saveDrawingToLocalStorage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL();
    localStorage.setItem(storageDrawKey, dataUrl);
  };

  const handleNoteTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setNoteText(text);
    localStorage.setItem(storageNoteKey, text);
  };

  // Drawing mouse handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    
    // Get correct coordinates
    const rect = canvas.getBoundingClientRect();
    let clientX = 0;
    let clientY = 0;

    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);

    // Context settings
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    if (isEraser) {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = theme === 'dark' ? '#122418' : '#faf9f6'; // Match background
      ctx.lineWidth = brushSize * 4;
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = brushColor;
      ctx.lineWidth = isHighlighter ? brushSize * 3 : brushSize;
      ctx.globalAlpha = isHighlighter ? 0.3 : 1.0;
    }

    // Single click dot
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let clientX = 0;
    let clientY = 0;

    if ('touches' in e) {
      // Prevent scrolling on mobile touch drawing
      if (e.cancelable) e.preventDefault();
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    saveDrawingToLocalStorage();

    // Add to history stack
    const canvas = canvasRef.current;
    if (canvas) {
      const state = canvas.toDataURL();
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(state);
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  };

  // Canvas operations
  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = theme === 'dark' ? '#122418' : '#faf9f6';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    saveDrawingToLocalStorage();
    
    const state = canvas.toDataURL();
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(state);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);

    if (showNotification) {
      showNotification('Scratchpad drawing cleared.', 'info');
    }
  };

  const handleUndo = () => {
    if (historyIndex <= 0) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prevIndex = historyIndex - 1;
    const img = new Image();
    img.src = history[prevIndex];
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      setHistoryIndex(prevIndex);
      localStorage.setItem(storageDrawKey, history[prevIndex]);
    };
  };

  const handleRedo = () => {
    if (historyIndex >= history.length - 1) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const nextIndex = historyIndex + 1;
    const img = new Image();
    img.src = history[nextIndex];
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      setHistoryIndex(nextIndex);
      localStorage.setItem(storageDrawKey, history[nextIndex]);
    };
  };

  // Send content to AI Tutor
  const sendSketchToTutor = () => {
    const canvas = canvasRef.current;
    if (!canvas || !onSendToChat) return;
    const dataUrl = canvas.toDataURL('image/png');
    
    onSendToChat(
      `I've drawn this on my classroom scratchpad for our study session on ${topic.replace(/_/g, ' ')}. Please analyze this drawing, check my mathematical work/sketches, and give me feedback on the chalkboard.`,
      dataUrl
    );
    showNotification?.('Sketch sent to your AI Tutor! Check the board.', 'success');
  };

  const sendNotesToTutor = () => {
    if (!noteText.trim() || !onSendToChat) return;
    
    onSendToChat(
      `Here are my session scratchpad notes regarding ${topic.replace(/_/g, ' ')}:\n\n"""\n${noteText}\n"""\n\nPlease review these notes, clarify any misconceptions, correct any equations, and provide a quick summarized list of takeaways or worked examples to lock in this concept.`,
    );
    showNotification?.('Notes sent to your AI Tutor! Check the board.', 'success');
  };

  // Save to ChaptersExplorer Saved Notes
  const handleSaveToNotes = () => {
    if (!noteText.trim() || !onSaveToNotes) return;
    setIsSavingNote(true);

    try {
      // Auto-extract mock key concepts from note content for formatting
      const words = noteText.split(/\s+/);
      const uniqueWords = Array.from(new Set(words))
        .filter(w => w.length > 5 && !['should', 'would', 'could', 'about', 'their', 'there'].includes(w.toLowerCase()))
        .slice(0, 3)
        .map(w => w.replace(/[^a-zA-Z]/g, ''));

      const keyConcepts = uniqueWords.length > 0 ? uniqueWords : [topic.replace(/_/g, ' ')];

      onSaveToNotes({
        title: noteTitle || `${topic.replace(/_/g, ' ').toUpperCase()} Scratchpad Notes`,
        summary: noteText,
        keyConcepts: keyConcepts,
        subject: subject,
        topic: topic
      });

      showNotification?.('Scratchpad notes saved to your Study Notes!', 'success');
    } catch (e) {
      console.error(e);
      showNotification?.('Failed to save study notes.', 'error');
    } finally {
      setIsSavingNote(false);
    }
  };

  const handleDownloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const link = document.createElement('a');
    link.download = `scratchpad-${subject}-${topic}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    showNotification?.('Scratchpad sketch downloaded!', 'success');
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-hidden border-l transition-all duration-300 shadow-2xl",
      theme === 'dark' 
        ? "bg-slate-900 border-slate-800 text-slate-100" 
        : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Header */}
      <div className={cn(
        "px-4 py-3 border-b flex items-center justify-between shrink-0",
        theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center font-bold">
            ✍️
          </div>
          <div>
            <h3 className="text-xs font-black uppercase tracking-wider">State Scratchpad</h3>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">
              {subject} · {topic.replace(/_/g, ' ')}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-400 hover:text-slate-200"
            title="Close Scratchpad"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className={cn(
        "flex border-b shrink-0",
        theme === 'dark' ? "border-slate-800 bg-slate-900/60" : "border-slate-200 bg-slate-100/50"
      )}>
        <button
          onClick={() => setActiveTab('draw')}
          className={cn(
            "flex-1 py-2.5 text-xs font-black uppercase tracking-wider border-b-2 transition-all flex items-center justify-center gap-2 cursor-pointer",
            activeTab === 'draw'
              ? "border-indigo-500 text-indigo-500"
              : "border-transparent text-slate-400 hover:text-slate-200"
          )}
        >
          <Edit3 size={14} />
          ✏️ Draw & Sketch
        </button>
        <button
          onClick={() => setActiveTab('notes')}
          className={cn(
            "flex-1 py-2.5 text-xs font-black uppercase tracking-wider border-b-2 transition-all flex items-center justify-center gap-2 cursor-pointer",
            activeTab === 'notes'
              ? "border-indigo-500 text-indigo-500"
              : "border-transparent text-slate-400 hover:text-slate-200"
          )}
        >
          <Type size={14} />
          📝 Text Notes
        </button>
      </div>

      {/* Main Panel Content */}
      <div className="flex-1 overflow-hidden relative flex flex-col min-h-0">
        {activeTab === 'draw' ? (
          <div className="flex-1 flex flex-col overflow-hidden relative h-full">
            {/* Drawing Toolbar */}
            <div className={cn(
              "px-3 py-2 border-b flex flex-wrap items-center justify-between gap-2 shrink-0 z-10",
              theme === 'dark' ? "bg-slate-950/20 border-slate-800/80" : "bg-slate-50 border-slate-200/80"
            )}>
              <div className="flex items-center gap-2.5 overflow-x-auto scrollbar-hide py-1">
                {/* Pen Colors */}
                <div className="flex items-center gap-1.5 border-r pr-2.5 border-slate-700/60 shrink-0">
                  {COLORS.map((col, idx) => {
                    const colorVal = theme === 'dark' ? col.dark : col.light;
                    const isSelected = brushColor === colorVal && !isEraser;
                    return (
                      <button
                        key={idx}
                        onClick={() => {
                          setBrushColor(colorVal);
                          setIsEraser(false);
                        }}
                        style={{ backgroundColor: colorVal }}
                        className={cn(
                          "w-5 h-5 rounded-full border-2 transition-transform active:scale-95 cursor-pointer",
                          isSelected ? "border-indigo-500 scale-110 shadow-md" : "border-transparent hover:scale-105"
                        )}
                        title={col.name}
                      />
                    );
                  })}
                </div>

                {/* Drawing Actions */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => {
                      setIsEraser(true);
                      setIsHighlighter(false);
                    }}
                    className={cn(
                      "p-1.5 rounded-lg transition-colors cursor-pointer",
                      isEraser 
                        ? "bg-amber-500/10 text-amber-500 border border-amber-500/30" 
                        : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                    )}
                    title="Chalk Eraser"
                  >
                    <Eraser size={14} />
                  </button>
                  <button
                    onClick={() => {
                      setIsHighlighter(!isHighlighter);
                      setIsEraser(false);
                    }}
                    className={cn(
                      "p-1.5 rounded-lg text-xs font-bold uppercase transition-colors cursor-pointer",
                      isHighlighter 
                        ? "bg-indigo-500/15 text-indigo-400 border border-indigo-500/30" 
                        : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                    )}
                    title="Highlighter Mode"
                  >
                    💡 Highlight
                  </button>
                </div>

                {/* Brush Size */}
                <div className="flex items-center gap-2 border-l pl-2.5 border-slate-700/60 shrink-0">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Brush</span>
                  <input
                    type="range"
                    min="1"
                    max="15"
                    value={brushSize}
                    onChange={(e) => setBrushSize(parseInt(e.target.value))}
                    className="w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-[10px] font-bold w-4 text-center">{brushSize}px</span>
                </div>
              </div>

              {/* Utility Drawing Controls */}
              <div className="flex items-center gap-1 ml-auto shrink-0">
                <button
                  onClick={handleUndo}
                  disabled={historyIndex <= 0}
                  className={cn(
                    "p-1.5 rounded-lg transition-colors cursor-pointer",
                    historyIndex <= 0 
                      ? "opacity-30 cursor-not-allowed text-slate-500" 
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                  )}
                  title="Undo stroke"
                >
                  <Undo2 size={14} />
                </button>
                <button
                  onClick={handleRedo}
                  disabled={historyIndex >= history.length - 1}
                  className={cn(
                    "p-1.5 rounded-lg transition-colors cursor-pointer",
                    historyIndex >= history.length - 1 
                      ? "opacity-30 cursor-not-allowed text-slate-500" 
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                  )}
                  title="Redo stroke"
                >
                  <Redo2 size={14} />
                </button>
                <button
                  onClick={clearCanvas}
                  className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 transition-colors cursor-pointer"
                  title="Clear blackboard"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>

            {/* Canvas Stage */}
            <div 
              ref={containerRef} 
              className="flex-1 w-full h-full relative overflow-hidden bg-[#122418]"
            >
              {/* Subtle chalkboard grid background overlay for equation/graph alignment when dark */}
              {theme === 'dark' && (
                <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />
              )}
              <canvas
                ref={canvasRef}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                className="absolute inset-0 cursor-crosshair touch-none"
              />
            </div>

            {/* Canvas Send/Save Footer */}
            <div className={cn(
              "px-4 py-3 border-t flex items-center justify-between shrink-0",
              theme === 'dark' ? "bg-slate-950/30 border-slate-800" : "bg-slate-50 border-slate-200"
            )}>
              <button
                onClick={handleDownloadCanvas}
                className="px-3 py-1.5 rounded-lg border border-slate-700/60 hover:bg-slate-800 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Download size={13} />
                Export PNG
              </button>
              
              {onSendToChat && (
                <button
                  onClick={sendSketchToTutor}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/10 active:scale-95"
                >
                  <Send size={13} />
                  Send Sketch to Tutor
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden relative h-full">
            {/* Note Metadata / Title */}
            <div className={cn(
              "px-4 py-2 border-b flex items-center gap-2 shrink-0",
              theme === 'dark' ? "bg-slate-950/10 border-slate-800/80" : "bg-slate-50 border-slate-200/80"
            )}>
              <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider">Note Title:</span>
              <input
                type="text"
                value={noteTitle}
                onChange={(e) => setNoteTitle(e.target.value)}
                className="flex-1 bg-transparent border-none text-xs font-extrabold focus:outline-none placeholder-slate-500"
                placeholder="Give your session note a title..."
              />
            </div>

            {/* Note Text Area */}
            <div className="flex-1 p-4 overflow-y-auto relative flex flex-col min-h-0">
              {/* Paper ruled guidelines overlay */}
              {theme === 'light' ? (
                <div className="absolute inset-0 bg-[linear-gradient(#f1f5f9_1px,transparent_1px)] bg-[size:100%_24px] opacity-30 pointer-events-none" />
              ) : (
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100%_24px] pointer-events-none" />
              )}
              
              <textarea
                value={noteText}
                onChange={handleNoteTextChange}
                className={cn(
                  "flex-1 w-full h-full resize-none bg-transparent border-none focus:outline-none text-sm font-sans leading-6 relative z-10",
                  theme === 'dark' ? "text-slate-100 placeholder-slate-600" : "text-slate-800 placeholder-slate-400"
                )}
                placeholder="Type your lecture notes, equations, formulas, or general takeaways here. All progress is automatically saved to local storage for this topic!
                
Example:
- Theorem: Euler's Identity: e^(iπ) + 1 = 0
- Mechanics formula: F = m * a
- Key concept to ask tutor: What is the mechanistic explanation of curl?"
              />
            </div>

            {/* Note Actions Footer */}
            <div className={cn(
              "px-4 py-3 border-t flex items-center gap-2 shrink-0 flex-wrap justify-between",
              theme === 'dark' ? "bg-slate-950/30 border-slate-800" : "bg-slate-50 border-slate-200"
            )}>
              <div className="flex gap-1.5">
                {onSaveToNotes && (
                  <button
                    onClick={handleSaveToNotes}
                    disabled={!noteText.trim() || isSavingNote}
                    className={cn(
                      "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border",
                      !noteText.trim() 
                        ? "opacity-40 cursor-not-allowed bg-slate-800/40 border-slate-800 text-slate-500"
                        : theme === 'dark' 
                          ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200 hover:border-slate-600"
                          : "bg-white border-slate-200 hover:bg-slate-50 text-slate-700 hover:border-slate-300"
                    )}
                    title="Save this note into Saved Study Notes under Chapter Explorer"
                  >
                    <Save size={13} className="text-amber-500" />
                    Save Note
                  </button>
                )}
              </div>
              
              {onSendToChat && (
                <button
                  onClick={sendNotesToTutor}
                  disabled={!noteText.trim()}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/10 active:scale-95"
                >
                  <Sparkles size={13} />
                  Ask Tutor about Notes
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
