import React, { useEffect, useRef, useState } from "react";
import Matter from "matter-js";
import { cn } from "@/src/lib/utils";

interface PhysicsSandboxProps {
  theme: 'light' | 'dark';
}

export const PhysicsSandbox: React.FC<PhysicsSandboxProps> = ({ theme }) => {
  const sceneRef = useRef<HTMLDivElement>(null);
  const [gravity, setGravity] = useState(1);
  const engineRef = useRef<Matter.Engine | null>(null);

  useEffect(() => {
    const Engine = Matter.Engine,
          Render = Matter.Render,
          Runner = Matter.Runner,
          Bodies = Matter.Bodies,
          Composite = Matter.Composite,
          Mouse = Matter.Mouse,
          MouseConstraint = Matter.MouseConstraint;

    const engine = Engine.create();
    engineRef.current = engine;
    engine.gravity.y = gravity;

    const render = Render.create({
      element: sceneRef.current!,
      engine: engine,
      options: {
        width: 400,
        height: 300,
        background: theme === 'dark' ? '#020617' : '#ffffff',
        wireframes: false,
      },
    });

    const boxA = Bodies.rectangle(200, 100, 80, 80, { render: { fillStyle: '#6366f1' } });
    const ground = Bodies.rectangle(200, 290, 400, 20, { isStatic: true, render: { fillStyle: '#94a3b8' } });

    Composite.add(engine.world, [boxA, ground]);

    const mouse = Mouse.create(render.canvas);
    const mouseConstraint = MouseConstraint.create(engine, {
      mouse: mouse,
      constraint: {
        stiffness: 0.2,
        render: { visible: false }
      }
    });
    Composite.add(engine.world, mouseConstraint);

    Render.run(render);
    const runner = Runner.create();
    Runner.run(runner, engine);

    return () => {
      Render.stop(render);
      Runner.stop(runner);
      Engine.clear(engine);
      render.canvas.remove();
    };
  }, [theme]);

  useEffect(() => {
    if (engineRef.current) {
        engineRef.current.gravity.y = gravity;
    }
  }, [gravity]);

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-2">
      <div className="flex gap-2 p-2 border-b flex-wrap text-sm">
        <label>Gravity: {gravity.toFixed(1)}</label>
        <input type="range" min="0" max="2" step="0.1" value={gravity} onChange={(e) => setGravity(parseFloat(e.target.value))} />
      </div>
      <div className="flex-1 border rounded-lg overflow-hidden" ref={sceneRef} />
    </div>
  );
};
