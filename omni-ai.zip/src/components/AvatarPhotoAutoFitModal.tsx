import React, { useState, useRef } from 'react';
import { X, Upload, Check, Sparkles, RefreshCw, Sliders, Image as ImageIcon, Volume2, Mic, Eye } from 'lucide-react';
import { cn } from '../lib/utils';

export type AvatarDisplayMode = 'circular' | 'square' | 'framed';

interface AvatarPhotoAutoFitModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPhotoUrl: string | null;
  currentDisplayMode: AvatarDisplayMode;
  onSavePhoto: (photoUrl: string | null, mode: AvatarDisplayMode) => void;
  showNotification?: (msg: string, type: 'info' | 'success' | 'warning' | 'error') => void;
}

const PRESET_AVATARS = [
  {
    id: 'default_clarity',
    name: 'Prof. Clarity (Default)',
    url: '', // Default rendered avatar
    role: 'Virtual Learning AI'
  },
  {
    id: 'khan_style',
    name: 'Sal Khan Style',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=512&h=512&q=80',
    role: 'Intuitive Educator'
  },
  {
    id: 'physics_wallah_style',
    name: 'Alakh Sir Style',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=512&h=512&q=80',
    role: 'Physics Guru'
  },
  {
    id: 'feynman_style',
    name: 'Dr. Feynman Style',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=512&h=512&q=80',
    role: 'Quantum Storyteller'
  },
  {
    id: 'montessori_style',
    name: 'Dr. Montessori Style',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=512&h=512&q=80',
    role: 'Inquiry Specialist'
  }
];

export const AvatarPhotoAutoFitModal: React.FC<AvatarPhotoAutoFitModalProps> = ({
  isOpen,
  onClose,
  currentPhotoUrl,
  currentDisplayMode,
  onSavePhoto,
  showNotification
}) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentPhotoUrl);
  const [displayMode, setDisplayMode] = useState<AvatarDisplayMode>(currentDisplayMode);
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [simulatedState, setSimulatedState] = useState<'idle' | 'speaking' | 'listening'>('speaking');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  if (!isOpen) return null;

  // Process uploaded image: auto-crop to 512x512 square with center/face bias and apply brightness/contrast
  const processImageFile = (file: File) => {
    setIsProcessing(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = canvasRef.current || document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setIsProcessing(false);
          return;
        }

        // Auto-enhance filter
        ctx.filter = `brightness(${brightness}%) contrast(${contrast}%)`;

        // Calculate square crop
        const minDim = Math.min(img.width, img.height);
        const startX = (img.width - minDim) / 2;
        // Bias slightly upwards towards top 40% for human face framing
        const startY = (img.height - minDim) * 0.35;

        ctx.drawImage(img, startX, startY, minDim, minDim, 0, 0, 512, 512);

        const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
        setPreviewUrl(dataUrl);
        setIsProcessing(false);
        showNotification?.('Photo auto-fitted and centered to 512x512 square!', 'success');
      };
      img.src = e.target?.result as string;
    };

    reader.readAsDataURL(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processImageFile(e.target.files[0]);
    }
  };

  const handleApplyAutoEnhance = () => {
    setBrightness(105);
    setContrast(108);
    showNotification?.('Auto-enhanced clarity and balanced contrast!', 'info');
  };

  const handleSave = () => {
    onSavePhoto(previewUrl, displayMode);
    onClose();
  };

  const handleResetToDefault = () => {
    setPreviewUrl(null);
    setDisplayMode('circular');
    setBrightness(100);
    setContrast(100);
    onSavePhoto(null, 'circular');
    showNotification?.('Reset to default 3D Professor Clarity avatar.', 'info');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <canvas ref={canvasRef} className="hidden" />
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      <div className="relative w-full max-w-2xl max-h-[90vh] bg-slate-900 border-2 border-indigo-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/90 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-xl shadow-lg">
              <ImageIcon size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                Avatar Photo Auto-Fit System
              </h2>
              <p className="text-xs text-slate-400">
                Upload any picture: auto-crops to 512x512 square with speaking & listening pulse rings
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* Main Preview Card */}
          <div className="flex flex-col sm:flex-row items-center gap-6 bg-slate-950/60 p-5 rounded-2xl border border-slate-800">
            {/* Live Interactive Avatar with Indicators */}
            <div className="relative flex flex-col items-center">
              <div
                className={cn(
                  "relative w-32 h-32 flex items-center justify-center transition-all duration-300",
                  displayMode === 'circular' && "rounded-full p-1",
                  displayMode === 'square' && "rounded-2xl p-1",
                  displayMode === 'framed' && "rounded-xl border-4 border-amber-500/60 p-1 bg-slate-900 shadow-2xl",
                  simulatedState === 'speaking' && "ring-4 ring-emerald-500/70 shadow-[0_0_25px_rgba(16,185,129,0.5)]",
                  simulatedState === 'listening' && "ring-4 ring-cyan-500/70 shadow-[0_0_25px_rgba(6,182,212,0.5)]",
                  simulatedState === 'idle' && "ring-2 ring-slate-700"
                )}
              >
                {previewUrl ? (
                  <img
                    src={previewUrl}
                    alt="Professor Avatar Preview"
                    className={cn(
                      "w-full h-full object-cover shadow-inner",
                      displayMode === 'circular' && "rounded-full",
                      displayMode === 'square' && "rounded-xl",
                      displayMode === 'framed' && "rounded-lg"
                    )}
                    style={{
                      filter: `brightness(${brightness}%) contrast(${contrast}%)`
                    }}
                  />
                ) : (
                  <div
                    className={cn(
                      "w-full h-full bg-gradient-to-tr from-indigo-700 via-purple-700 to-amber-600 flex flex-col items-center justify-center text-white",
                      displayMode === 'circular' && "rounded-full",
                      displayMode === 'square' && "rounded-xl",
                      displayMode === 'framed' && "rounded-lg"
                    )}
                  >
                    <span className="text-3xl">🎓</span>
                    <span className="text-[10px] font-black tracking-wider uppercase mt-1">
                      Prof. Clarity
                    </span>
                  </div>
                )}

                {/* State Badge Ping */}
                {simulatedState === 'speaking' && (
                  <span className="absolute -top-1 -right-1 flex h-4 w-4">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-slate-900"></span>
                  </span>
                )}
                {simulatedState === 'listening' && (
                  <span className="absolute -top-1 -right-1 flex h-4 w-4">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-4 w-4 bg-cyan-500 border-2 border-slate-900"></span>
                  </span>
                )}
              </div>

              {/* Simulation Status Controls */}
              <div className="flex items-center gap-1 mt-3 bg-slate-900 p-1 rounded-xl border border-slate-800">
                <button
                  onClick={() => setSimulatedState('speaking')}
                  className={cn(
                    "px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1",
                    simulatedState === 'speaking' ? "bg-emerald-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                  )}
                >
                  <Volume2 size={11} /> Speaking
                </button>
                <button
                  onClick={() => setSimulatedState('listening')}
                  className={cn(
                    "px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1",
                    simulatedState === 'listening' ? "bg-cyan-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                  )}
                >
                  <Mic size={11} /> Listening
                </button>
                <button
                  onClick={() => setSimulatedState('idle')}
                  className={cn(
                    "px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1",
                    simulatedState === 'idle' ? "bg-slate-700 text-white shadow" : "text-slate-400 hover:text-slate-200"
                  )}
                >
                  <Eye size={11} /> Idle
                </button>
              </div>
            </div>

            {/* Actions & Auto-Fit Engine */}
            <div className="flex-1 space-y-3 w-full">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md transition-all cursor-pointer"
                >
                  <Upload size={16} />
                  <span>Upload Device Photo</span>
                </button>
                <button
                  onClick={handleApplyAutoEnhance}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Sparkles size={14} />
                  <span>Auto-Enhance</span>
                </button>
                {previewUrl && (
                  <button
                    onClick={handleResetToDefault}
                    className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-rose-950/60 text-slate-300 hover:text-rose-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <RefreshCw size={13} />
                    <span>Restore 3D Avatar</span>
                  </button>
                )}
              </div>

              {/* Display Mode Selection */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Display Frame Shape:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'circular', label: 'Circular (Classic)' },
                    { id: 'square', label: 'Rounded Square' },
                    { id: 'framed', label: 'Classroom Badge' }
                  ].map((mode) => (
                    <button
                      key={mode.id}
                      onClick={() => setDisplayMode(mode.id as AvatarDisplayMode)}
                      className={cn(
                        "py-1.5 px-2 rounded-xl text-xs font-bold border transition-all text-center",
                        displayMode === mode.id
                          ? "bg-indigo-600/30 border-indigo-400 text-white shadow"
                          : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200"
                      )}
                    >
                      {mode.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sliders */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Brightness</span>
                    <span>{brightness}%</span>
                  </div>
                  <input
                    type="range"
                    min="70"
                    max="140"
                    value={brightness}
                    onChange={(e) => setBrightness(Number(e.target.value))}
                    className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Contrast</span>
                    <span>{contrast}%</span>
                  </div>
                  <input
                    type="range"
                    min="70"
                    max="140"
                    value={contrast}
                    onChange={(e) => setContrast(Number(e.target.value))}
                    className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Educator Preset Avatars */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2.5">
              Or Choose an Educator Avatar Preset:
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
              {PRESET_AVATARS.map((preset) => {
                const isSelected = (!previewUrl && preset.id === 'default_clarity') || (previewUrl === preset.url && preset.url !== '');
                return (
                  <div
                    key={preset.id}
                    onClick={() => {
                      setPreviewUrl(preset.url || null);
                      showNotification?.(`Applied ${preset.name}!`, 'info');
                    }}
                    className={cn(
                      "p-2.5 rounded-2xl border transition-all cursor-pointer flex flex-col items-center text-center",
                      isSelected
                        ? "bg-indigo-950/60 border-indigo-400 shadow-md ring-2 ring-indigo-500/30"
                        : "bg-slate-800/40 border-slate-700 hover:border-slate-600"
                    )}
                  >
                    <div className="w-12 h-12 rounded-full overflow-hidden mb-1.5 bg-slate-800 flex items-center justify-center border border-slate-700">
                      {preset.url ? (
                        <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-xl">🎓</span>
                      )}
                    </div>
                    <span className="text-xs font-bold text-white truncate w-full">
                      {preset.name}
                    </span>
                    <span className="text-[10px] text-slate-400 truncate w-full">
                      {preset.role}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
          <span>Updates avatar in 3D classroom HUD, desk dock, and voice indicator rings</span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-300 hover:bg-slate-800 font-bold transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors cursor-pointer shadow-md flex items-center gap-1.5"
            >
              <Check size={16} />
              <span>Apply Avatar</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
