export type SupportedExamType = 
  | 'cbse' 
  | 'jee-main' 
  | 'jee-adv' 
  | 'neet' 
  | 'sat' 
  | 'cuet' 
  | 'cisce';

export interface ExamSectionTemplate {
  id: string;
  name: string;
  description: string;
  totalQuestions: number;
  compulsoryQuestions?: number;
  marksPerQuestion: number;
  negativeMarksPerQuestion: number;
  questionType: 'mcq' | 'numerical' | 'subjective_short' | 'subjective_long' | 'assertion_reason' | 'case_study';
}

export interface ExamPatternTemplate {
  id: string;
  examType: SupportedExamType;
  title: string;
  subtitle: string;
  gradeLevel?: string;
  durationMinutes: number;
  totalMarks: number;
  totalQuestions: number;
  hasNegativeMarking: boolean;
  allowBackNavigation: boolean;
  sections: ExamSectionTemplate[];
  instructions: string[];
}

export interface ExamQuestionItem {
  id: string;
  sectionId: string;
  questionNumber: number;
  subject: string;
  topic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  questionType: 'mcq' | 'numerical' | 'subjective_short' | 'subjective_long' | 'assertion_reason' | 'case_study';
  marks: number;
  negativeMarks: number;
  questionText: string;
  diagramUrl?: string;
  options?: string[]; // For MCQ / Assertion
  correctOption?: string; // e.g. "A" or text
  correctNumericalValue?: number;
  numericalTolerance?: number; // e.g. 0.05
  stepWiseRubric?: Array<{
    step: string;
    marks: number;
    keyPoints: string[];
  }>;
  detailedSolution: string;
}

export interface StudentQuestionResponse {
  questionId: string;
  selectedOption?: string;
  answerText?: string;
  numericalAnswer?: number;
  timeSpent: number; // in seconds
  markedForReview: boolean;
  visited?: boolean;
}

export interface ExamAttempt {
  id: string;
  studentId: string;
  examType: SupportedExamType;
  examPatternId: string;
  examYear: number;
  subject: string;
  startedAt: string;
  completedAt: string;
  durationSecondsUsed: number;
  answers: Array<{
    questionId: string;
    selectedOption?: string;
    answerText?: string;
    numericalAnswer?: number;
    timeSpent: number;
    markedForReview: boolean;
  }>;
  score: number;
  maxScore: number;
  percentile: number;
  accuracyPercentage: number;
  speedQuestionsPerHour: number;
}

export interface QuestionEvaluationResult {
  questionId: string;
  isCorrect: boolean;
  isAttempted: boolean;
  awardedMarks: number;
  maxMarks: number;
  timeSpent: number;
  userAnswer?: string;
  correctAnswer: string;
  topic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  stepWiseBreakdown?: Array<{
    step: string;
    awarded: number;
    maxMarks: number;
    feedback: string;
  }>;
}

export interface SectionEvaluationResult {
  sectionId: string;
  sectionName: string;
  attempted: number;
  correct: number;
  incorrect: number;
  unattempted: number;
  score: number;
  maxScore: number;
  accuracy: number;
  timeSpentSeconds: number;
}

export interface TopicEvaluationResult {
  topic: string;
  totalQuestions: number;
  attempted: number;
  correct: number;
  score: number;
  maxScore: number;
  masteryPercentage: number;
}

export interface FullExamEvaluationReport {
  attemptId: string;
  examTitle: string;
  examType: SupportedExamType;
  subject: string;
  startedAt: string;
  completedAt: string;
  totalTimeSpentSeconds: number;
  totalScore: number;
  maxScore: number;
  percentage: number;
  percentile: number;
  rankEstimate: string;
  accuracyPercentage: number;
  speedIndex: string; // e.g. "1.2 mins/question"
  sections: SectionEvaluationResult[];
  topics: TopicEvaluationResult[];
  difficultyBreakdown: {
    easy: { correct: number; total: number; score: number };
    medium: { correct: number; total: number; score: number };
    hard: { correct: number; total: number; score: number };
  };
  timeManagementInsights: string[];
  recommendations: string[];
  questionResults: QuestionEvaluationResult[];
}
