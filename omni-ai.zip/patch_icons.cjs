const fs = require('fs');
const file = 'src/lib/constants.ts';
let content = fs.readFileSync(file, 'utf8');

const targetStr = `'2. Inverse Trigonometric Functions': '📐',`;
const replacementStr = `'2. Inverse Trigonometric Functions - Definition, domain, range, principal value branch, Graphs, Elementary properties': '📐',`;

if (content.includes(targetStr)) {
  content = content.replace(targetStr, replacementStr);
  fs.writeFileSync(file, content);
  console.log("Replaced TOPIC_ICONS successfully.");
} else {
  console.log("Target string not found.");
}
