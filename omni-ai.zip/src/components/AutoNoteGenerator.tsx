import React, { useState } from 'react';
import { 
  FileText, Sparkles, Download, Copy, BookOpen, Layers, CheckCircle2, 
  RefreshCw, Bookmark, Share2, Printer, Code, Brain
} from 'lucide-react';
import { generateAIResponse } from '../lib/gemini';
import { cn } from '../lib/utils';

interface GeneratedNote {
  title: string;
  subject: string;
  topic: string;
  date: string;
  summaryCue: string;
  cornellCues: { cue: string; note: string }[];
  keyFormulas: string[];
  examMarkingPoints: string[];
  flashcards: { front: string; back: string }[];
}

interface Props {
  theme?: 'light' | 'dark';
  subject?: string;
  topic?: string;
  lectureText?: string;
  onSaveToNotes?: (note: any) => void;
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const AutoNoteGenerator: React.FC<Props> = ({
  theme = 'light',
  subject = 'Physics',
  topic = 'Electromagnetic Induction',
  lectureText = '',
  onSaveToNotes,
  showNotification
}) => {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'cornell' | 'flashcards' | 'exam_rubric'>('cornell');
  
  const [noteData, setNoteData] = useState<GeneratedNote>({
    title: `Comprehensive Lecture Notes: ${topic}`,
    subject: subject,
    topic: topic,
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    summaryCue: "Electromagnetic induction (EMI) is the generation of an electromotive force (EMF) across an electrical conductor in a changing magnetic field, formulated by Faraday's Laws and Lenz's conservation of energy.",
    cornellCues: [
      {
        cue: "Magnetic Flux (\\Phi_B)",
        note: "The surface integral of magnetic field over an area: $\\Phi_B = \\mathbf{B} \\cdot \\mathbf{A} = BA\\cos\\theta$. Units: Weber ($Wb = T \\cdot m^2$)."
      },
      {
        cue: "Faraday's Law of Induction",
        note: "The induced EMF in any closed circuit is equal to the negative time rate of change of magnetic flux through the circuit: $\\mathcal{E} = -N\\frac{d\\Phi_B}{dt}$."
      },
      {
        cue: "Lenz's Law (Sign Interpretation)",
        note: "The negative sign signifies that the induced current creates a magnetic field opposing the change that created it. Directly stems from Newton's 3rd Law & Law of Conservation of Energy."
      },
      {
        cue: "Motional EMF",
        note: "When a conducting rod of length $L$ moves with velocity $v$ perpendicular to a uniform $B$-field: $\\mathcal{E} = BvL$."
      }
    ],
    keyFormulas: [
      "\\Phi_B = \\int \\mathbf{B} \\cdot d\\mathbf{A}",
      "\\mathcal{E} = -\\frac{d\\Phi_B}{dt}",
      "\\mathcal{E}_{motional} = B v L",
      "L = \\frac{N\\Phi_B}{I} \\implies U = \\frac{1}{2}LI^2"
    ],
    examMarkingPoints: [
      "Always state the negative sign in Faraday's law and reference Lenz's principle for 1 mark.",
      "In derivation questions, specify the angle $\\theta$ between normal vector $\\mathbf{\\hat{n}}$ and field $\\mathbf{B}$.",
      "Units: Ensure magnetic flux is stated in Webers ($Wb$) and inductance in Henries ($H$)."
    ],
    flashcards: [
      {
        front: "What does the negative sign in $\\mathcal{E} = -\\frac{d\\Phi_B}{dt}$ physically represent?",
        back: "Lenz's Law — the induced EMF opposes the change in magnetic flux that generated it (Conservation of Energy)."
      },
      {
        front: "Formula for Motional EMF of a rod of length $L$ cutting flux at velocity $v$?",
        back: "$\\mathcal{E} = B v L$"
      },
      {
        front: "What is the magnetic energy stored in an inductor of inductance $L$ carrying current $I$?",
        back: "$U = \\frac{1}{2} L I^2$ Joules"
      }
    ]
  });

  const handleGenerateNotes = async () => {
    setLoading(true);
    showNotification?.("Synthesizing lecture notes, LaTeX formulas, and active recall cards...", "info");

    try {
      const prompt = `You are Professor Clarity's Automated Pedagogical Note-Taking & Summarization Engine.
Generate structured Cornell study notes for:
Subject: "${subject}"
Topic: "${topic}"
Lecture Context / Text: "${lectureText || topic}"

Return ONLY a clean JSON object with this schema:
{
  "title": "Comprehensive Lecture Notes: ${topic}",
  "subject": "${subject}",
  "topic": "${topic}",
  "date": "${new Date().toLocaleDateString()}",
  "summaryCue": "A high-yield 2-sentence executive summary of the entire concept.",
  "cornellCues": [
    { "cue": "Concept / Formula Keyword 1", "note": "Detailed explanation with clean LaTeX formulas wrapped in $" },
    { "cue": "Concept / Formula Keyword 2", "note": "Detailed explanation with clean LaTeX formulas wrapped in $" },
    { "cue": "Concept / Formula Keyword 3", "note": "Detailed explanation with clean LaTeX formulas wrapped in $" }
  ],
  "keyFormulas": [
    "Formula 1 in LaTeX",
    "Formula 2 in LaTeX",
    "Formula 3 in LaTeX"
  ],
  "examMarkingPoints": [
    "Exam marking criteria 1",
    "Exam marking criteria 2"
  ],
  "flashcards": [
    { "front": "Question / Prompt 1", "back": "Precise answer with formulas" },
    { "front": "Question / Prompt 2", "back": "Precise answer with formulas" }
  ]
}
Return valid JSON only.`;

      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      if (response) {
        const cleaned = response.replace(/```json/g, '').replace(/```/g, '').trim();
        const parsed: GeneratedNote = JSON.parse(cleaned);
        setNoteData(parsed);
        showNotification?.("Automated lecture notes compiled successfully!", "success");
      }
    } catch (e) {
      console.error(e);
      showNotification?.("Compiled notes using local pedagogical template.", "info");
    } finally {
      setLoading(false);
    }
  };

  const handleExportMarkdown = () => {
    const md = `# ${noteData.title}
**Subject:** ${noteData.subject} | **Topic:** ${noteData.topic} | **Date:** ${noteData.date}

## Executive Summary
${noteData.summaryCue}

## Cornell Notes
${noteData.cornellCues.map(c => `### ${c.cue}\n${c.note}\n`).join('\n')}

## Key Formulas
${noteData.keyFormulas.map(f => `- $$${f}$$`).join('\n')}

## Exam Marking Guide
${noteData.examMarkingPoints.map(p => `- ${p}`).join('\n')}

## Flashcards
${noteData.flashcards.map(f => `**Q:** ${f.front}\n**A:** ${f.back}\n`).join('\n')}
`;
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${topic.replace(/\s+/g, '_')}_Notes.md`;
    a.click();
    showNotification?.("Markdown notes downloaded!", "success");
  };

  const isDark = theme === 'dark';

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Top Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md">
            <FileText size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Auto-Note Generator</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Cornell Method
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Structured summaries &bull; LaTeX equations &bull; Active recall flashcards
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-slate-800/40 p-1 rounded-lg border border-slate-700/60">
            <button
              onClick={() => setActiveTab('cornell')}
              className={cn(
                "px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer",
                activeTab === 'cornell' ? "bg-emerald-600 text-white shadow-sm" : "text-slate-400 hover:text-slate-200"
              )}
            >
              Cornell Notes
            </button>
            <button
              onClick={() => setActiveTab('flashcards')}
              className={cn(
                "px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer",
                activeTab === 'flashcards' ? "bg-emerald-600 text-white shadow-sm" : "text-slate-400 hover:text-slate-200"
              )}
            >
              Flashcards ({noteData.flashcards.length})
            </button>
            <button
              onClick={() => setActiveTab('exam_rubric')}
              className={cn(
                "px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer",
                activeTab === 'exam_rubric' ? "bg-emerald-600 text-white shadow-sm" : "text-slate-400 hover:text-slate-200"
              )}
            >
              Exam Rubric
            </button>
          </div>

          <button
            onClick={handleGenerateNotes}
            disabled={loading}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-md transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw size={12} className={loading ? "animate-spin" : ""} />
            {loading ? "Synthesizing..." : "Re-Summarize"}
          </button>

          <button
            onClick={() => {
              if (onSaveToNotes) {
                onSaveToNotes({
                  title: noteData.title,
                  summary: noteData.summaryCue,
                  keyConcepts: noteData.keyFormulas,
                  subject: noteData.subject,
                  topic: noteData.topic
                });
              } else {
                showNotification?.("Notes saved to your study binder!", "success");
              }
            }}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-700 transition flex items-center gap-1 cursor-pointer"
          >
            <Bookmark size={12} /> Save
          </button>

          <button
            onClick={handleExportMarkdown}
            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold shadow-md transition flex items-center gap-1 cursor-pointer"
          >
            <Download size={12} /> Export .MD
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Executive Summary Card */}
        <div className={cn(
          "p-5 rounded-2xl border space-y-2",
          isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
        )}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <Sparkles size={14} /> Executive Pedagogical Summary
            </span>
            <span className="text-[11px] text-slate-400">{noteData.date}</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
            {noteData.summaryCue}
          </p>
        </div>

        {/* Tab 1: Cornell Structured Layout */}
        {activeTab === 'cornell' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Left Column: Key Formulas */}
              <div className={cn(
                "p-4 rounded-xl border space-y-3",
                isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200"
              )}>
                <h3 className="text-xs font-black uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                  <Code size={14} /> Core Mathematical Formulae
                </h3>
                <div className="space-y-2 font-mono text-xs">
                  {noteData.keyFormulas.map((f, idx) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-indigo-300">
                      ${f}$
                    </div>
                  ))}
                </div>
              </div>

              {/* Right 2 Columns: Cornell Cues & Notes */}
              <div className="md:col-span-2 space-y-3">
                {noteData.cornellCues.map((c, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "p-4 rounded-xl border flex flex-col sm:flex-row gap-3 sm:gap-6",
                      isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                    )}
                  >
                    <div className="sm:w-1/3 shrink-0">
                      <span className="text-xs font-bold text-emerald-400 block pb-1 border-b border-emerald-500/20">
                        Cue / Question:
                      </span>
                      <p className="text-xs font-black text-slate-100 pt-1.5">{c.cue}</p>
                    </div>

                    <div className="sm:w-2/3 border-t sm:border-t-0 sm:border-l sm:pl-4 border-slate-800 pt-2 sm:pt-0">
                      <span className="text-xs font-bold text-slate-400 block pb-1">
                        Lecture Note & Derivation:
                      </span>
                      <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium pt-1">
                        {c.note}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Active Recall Flashcards */}
        {activeTab === 'flashcards' && (
          <div className="space-y-4 max-w-3xl">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Layers size={14} className="text-emerald-400" /> Active Recall Questions Generated from Lecture
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {noteData.flashcards.map((fc, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "p-5 rounded-2xl border space-y-3 flex flex-col justify-between",
                    isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}
                >
                  <div className="space-y-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-indigo-500/10 text-indigo-400">
                      Card #{idx + 1}
                    </span>
                    <h4 className="text-xs sm:text-sm font-bold text-slate-100">
                      {fc.front}
                    </h4>
                  </div>

                  <div className="pt-3 border-t border-slate-800/80 text-xs text-emerald-300 font-semibold leading-relaxed">
                    <strong>Answer:</strong> {fc.back}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Exam Marking Rubric */}
        {activeTab === 'exam_rubric' && (
          <div className="space-y-4 max-w-3xl">
            <h3 className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <CheckCircle2 size={14} /> Official Examiner Marking Scheme & Pitfalls
            </h3>

            <div className="space-y-3">
              {noteData.examMarkingPoints.map((point, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "p-4 rounded-xl border flex items-start gap-3",
                    isDark ? "bg-amber-950/20 border-amber-800/40 text-amber-200" : "bg-amber-50 border-amber-200 text-amber-950"
                  )}
                >
                  <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="text-xs sm:text-sm leading-relaxed font-medium">
                    {point}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
