import { ExamPatternTemplate, ExamQuestionItem } from './types';

export const EXAM_PATTERNS: Record<string, ExamPatternTemplate> = {
  'cbse-12-physics': {
    id: 'cbse-12-physics',
    examType: 'cbse',
    title: 'CBSE Class 12 Physics Board Examination',
    subtitle: 'Official CBSE Blueprint (Theory Paper)',
    gradeLevel: 'Class 12',
    durationMinutes: 180,
    totalMarks: 70,
    totalQuestions: 33,
    hasNegativeMarking: false,
    allowBackNavigation: true,
    sections: [
      {
        id: 'sec_a',
        name: 'Section A: Multiple Choice & Assertion-Reason',
        description: '16 Questions of 1 mark each (Q1-Q12 MCQs, Q13-Q16 Assertion-Reason)',
        totalQuestions: 16,
        compulsoryQuestions: 16,
        marksPerQuestion: 1,
        negativeMarksPerQuestion: 0,
        questionType: 'mcq'
      },
      {
        id: 'sec_b',
        name: 'Section B: Very Short Answer (VSA)',
        description: '5 Questions of 2 marks each (Q17-Q21)',
        totalQuestions: 5,
        compulsoryQuestions: 5,
        marksPerQuestion: 2,
        negativeMarksPerQuestion: 0,
        questionType: 'subjective_short'
      },
      {
        id: 'sec_c',
        name: 'Section C: Short Answer (SA)',
        description: '7 Questions of 3 marks each (Q22-Q28)',
        totalQuestions: 7,
        compulsoryQuestions: 7,
        marksPerQuestion: 3,
        negativeMarksPerQuestion: 0,
        questionType: 'subjective_short'
      },
      {
        id: 'sec_d',
        name: 'Section D: Case-Based Questions',
        description: '2 Case Studies of 4 marks each (Q29-Q30)',
        totalQuestions: 2,
        compulsoryQuestions: 2,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 0,
        questionType: 'case_study'
      },
      {
        id: 'sec_e',
        name: 'Section E: Long Answer (LA)',
        description: '3 Long Answer Questions of 5 marks each (Q31-Q33)',
        totalQuestions: 3,
        compulsoryQuestions: 3,
        marksPerQuestion: 5,
        negativeMarksPerQuestion: 0,
        questionType: 'subjective_long'
      }
    ],
    instructions: [
      'There is no overall choice. However, internal choices have been provided in some questions.',
      'Use of calculators or mathematical tables is strictly prohibited.',
      'You may use the physical constants given on the paper (c = 3x10^8 m/s, e = 1.6x10^-19 C, eps0 = 8.854x10^-12 C^2/N.m^2).'
    ]
  },

  'jee-main-full': {
    id: 'jee-main-full',
    examType: 'jee-main',
    title: 'NTA JEE Main (Computer Based Test)',
    subtitle: 'Physics, Chemistry & Mathematics CBT Paper',
    gradeLevel: 'Engineering Entrance',
    durationMinutes: 180,
    totalMarks: 300,
    totalQuestions: 75, // 25 per subject
    hasNegativeMarking: true,
    allowBackNavigation: true,
    sections: [
      {
        id: 'jee_phy_mcq',
        name: 'Physics: Section A (MCQs)',
        description: '20 Single Correct MCQs (+4 for correct, -1 for incorrect)',
        totalQuestions: 20,
        compulsoryQuestions: 20,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'mcq'
      },
      {
        id: 'jee_phy_num',
        name: 'Physics: Section B (Numerical Value)',
        description: '5 Numerical Questions to be answered as integer / decimal (+4, -1)',
        totalQuestions: 5,
        compulsoryQuestions: 5,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'numerical'
      },
      {
        id: 'jee_chem_mcq',
        name: 'Chemistry: Section A (MCQs)',
        description: '20 Single Correct MCQs (+4 for correct, -1 for incorrect)',
        totalQuestions: 20,
        compulsoryQuestions: 20,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'mcq'
      },
      {
        id: 'jee_chem_num',
        name: 'Chemistry: Section B (Numerical Value)',
        description: '5 Numerical Questions (+4, -1)',
        totalQuestions: 5,
        compulsoryQuestions: 5,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'numerical'
      },
      {
        id: 'jee_math_mcq',
        name: 'Mathematics: Section A (MCQs)',
        description: '20 Single Correct MCQs (+4 for correct, -1 for incorrect)',
        totalQuestions: 20,
        compulsoryQuestions: 20,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'mcq'
      },
      {
        id: 'jee_math_num',
        name: 'Mathematics: Section B (Numerical Value)',
        description: '5 Numerical Questions (+4, -1)',
        totalQuestions: 5,
        compulsoryQuestions: 5,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'numerical'
      }
    ],
    instructions: [
      'For MCQs, 4 marks are awarded for each correct answer and 1 mark is deducted for each incorrect answer.',
      'For Numerical Value questions, enter the calculated value. Negative marking applies (-1).',
      'The on-screen countdown timer indicates the remaining time.'
    ]
  },

  'neet-ug-full': {
    id: 'neet-ug-full',
    examType: 'neet',
    title: 'NTA NEET (UG) National Medical Entrance',
    subtitle: 'Physics, Chemistry, Botany & Zoology',
    gradeLevel: 'Medical Entrance',
    durationMinutes: 200,
    totalMarks: 720,
    totalQuestions: 180,
    hasNegativeMarking: true,
    allowBackNavigation: true,
    sections: [
      {
        id: 'neet_phy_a',
        name: 'Physics - Section A',
        description: '35 Compulsory MCQs (+4, -1)',
        totalQuestions: 35,
        compulsoryQuestions: 35,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'mcq'
      },
      {
        id: 'neet_phy_b',
        name: 'Physics - Section B',
        description: '15 Questions (Attempt any 10) (+4, -1)',
        totalQuestions: 10,
        compulsoryQuestions: 10,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'mcq'
      },
      {
        id: 'neet_chem_a',
        name: 'Chemistry - Section A',
        description: '35 Compulsory MCQs (+4, -1)',
        totalQuestions: 35,
        compulsoryQuestions: 35,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'mcq'
      },
      {
        id: 'neet_bio_a',
        name: 'Biology (Botany & Zoology)',
        description: '100 MCQs (+4, -1)',
        totalQuestions: 100,
        compulsoryQuestions: 100,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 1,
        questionType: 'mcq'
      }
    ],
    instructions: [
      'Each correct answer gives +4 marks. Each incorrect answer gives -1 mark.',
      'Unanswered questions give 0 marks.',
      'Rough work can be done on the virtual scratchpad.'
    ]
  },

  'sat-digital-math': {
    id: 'sat-digital-math',
    examType: 'sat',
    title: 'College Board Digital SAT: Math Section',
    subtitle: 'Module 1 & Module 2 Adaptive Simulation',
    gradeLevel: 'High School / College Prep',
    durationMinutes: 70,
    totalMarks: 800,
    totalQuestions: 44,
    hasNegativeMarking: false,
    allowBackNavigation: true,
    sections: [
      {
        id: 'sat_mod_1',
        name: 'Math Module 1 (Standard Routing)',
        description: '22 Questions: Algebra, Advanced Math, Problem Solving & Geometry',
        totalQuestions: 22,
        compulsoryQuestions: 22,
        marksPerQuestion: 18,
        negativeMarksPerQuestion: 0,
        questionType: 'mcq'
      },
      {
        id: 'sat_mod_2',
        name: 'Math Module 2 (Adaptive Section)',
        description: '22 Questions with Student-Produced Responses',
        totalQuestions: 22,
        compulsoryQuestions: 22,
        marksPerQuestion: 18,
        negativeMarksPerQuestion: 0,
        questionType: 'numerical'
      }
    ],
    instructions: [
      'Built-in graphing calculator is permitted on all questions.',
      'No penalty for wrong guesses. Always guess rather than leaving blank.'
    ]
  },

  'cuet-ug-domain': {
    id: 'cuet-ug-domain',
    examType: 'cuet',
    title: 'CUET (UG) Domain Subject Mock',
    subtitle: 'National Testing Agency Common University Entrance Test',
    gradeLevel: 'Undergraduate Entrance',
    durationMinutes: 45,
    totalMarks: 200,
    totalQuestions: 40,
    hasNegativeMarking: true,
    allowBackNavigation: true,
    sections: [
      {
        id: 'cuet_sec_domain',
        name: 'Domain Specific Questions',
        description: '40 Questions to be attempted out of 50 (+5 for correct, -1 for incorrect)',
        totalQuestions: 40,
        compulsoryQuestions: 40,
        marksPerQuestion: 5,
        negativeMarksPerQuestion: 1,
        questionType: 'mcq'
      }
    ],
    instructions: [
      'For every correct response, you get 5 marks.',
      'For each wrong response, 1 mark is deducted.',
      'Unanswered questions receive 0 marks.'
    ]
  },

  'cisce-isc-12': {
    id: 'cisce-isc-12',
    examType: 'cisce',
    title: 'CISCE ISC Class 12 Science Examination',
    subtitle: 'Council for the Indian School Certificate Examinations',
    gradeLevel: 'Class 12 ISC',
    durationMinutes: 180,
    totalMarks: 70,
    totalQuestions: 18,
    hasNegativeMarking: false,
    allowBackNavigation: true,
    sections: [
      {
        id: 'isc_sec_a',
        name: 'Section A (Compulsory MCQs & Short Questions)',
        description: '14 Marks (Q1 with multiple sub-parts)',
        totalQuestions: 1,
        compulsoryQuestions: 1,
        marksPerQuestion: 14,
        negativeMarksPerQuestion: 0,
        questionType: 'mcq'
      },
      {
        id: 'isc_sec_b',
        name: 'Section B (Descriptive Problems)',
        description: 'Answer any 7 questions out of 10 (4 Marks each = 28 Marks)',
        totalQuestions: 10,
        compulsoryQuestions: 7,
        marksPerQuestion: 4,
        negativeMarksPerQuestion: 0,
        questionType: 'subjective_short'
      },
      {
        id: 'isc_sec_c',
        name: 'Section C (Long Form Proofs & Derivations)',
        description: 'Answer any 4 questions out of 6 (7 Marks each = 28 Marks)',
        totalQuestions: 6,
        compulsoryQuestions: 4,
        marksPerQuestion: 7,
        negativeMarksPerQuestion: 0,
        questionType: 'subjective_long'
      }
    ],
    instructions: [
      '15 minutes reading time is provided prior to the start of writing.',
      'All working including rough work should be done clearly on the virtual sheet.'
    ]
  }
};

/**
 * Standard authentic questions library for instant offline simulation
 */
export const SAMPLE_EXAM_PAPERS: Record<string, ExamQuestionItem[]> = {
  'cbse-12-physics': [
    {
      id: 'cbse_phy_q1',
      sectionId: 'sec_a',
      questionNumber: 1,
      subject: 'Physics',
      topic: 'Electrostatics',
      difficulty: 'easy',
      questionType: 'mcq',
      marks: 1,
      negativeMarks: 0,
      questionText: 'An electric dipole of moment p is placed in a uniform electric field E. The torque acting on the dipole is given by:',
      options: [
        '\\vec{\\tau} = \\vec{p} \\cdot \\vec{E}',
        '\\vec{\\tau} = \\vec{p} \\times \\vec{E}',
        '\\vec{\\tau} = \\vec{E} \\times \\vec{p}',
        '\\vec{\\tau} = pE \\hat{n}'
      ],
      correctOption: '\\vec{\\tau} = \\vec{p} \\times \\vec{E}',
      detailedSolution: 'Torque on an electric dipole placed in a uniform electric field is given by \\vec{\\tau} = \\vec{p} \\times \\vec{E}. Magnitude is \\tau = pE \\sin\\theta.'
    },
    {
      id: 'cbse_phy_q2',
      sectionId: 'sec_a',
      questionNumber: 2,
      subject: 'Physics',
      topic: 'Current Electricity',
      difficulty: 'easy',
      questionType: 'mcq',
      marks: 1,
      negativeMarks: 0,
      questionText: 'If a wire of resistance R is stretched uniformly to double its original length, its new resistance will be:',
      options: [
        'R/2',
        '2R',
        '4R',
        'R/4'
      ],
      correctOption: '4R',
      detailedSolution: 'When stretched to length l\' = 2l, the volume remains constant: A\' = A/2. Therefore, R\' = \\rho (l\'/A\') = \\rho (2l / (A/2)) = 4\\rho(l/A) = 4R.'
    },
    {
      id: 'cbse_phy_q3',
      sectionId: 'sec_a',
      questionNumber: 3,
      subject: 'Physics',
      topic: 'Magnetism',
      difficulty: 'medium',
      questionType: 'mcq',
      marks: 1,
      negativeMarks: 0,
      questionText: 'A charged particle q enters a uniform magnetic field B with velocity v perpendicular to B. The kinetic energy of the particle after time t is:',
      options: [
        'Increases linearly with t',
        'Remains constant',
        'Decreases exponentially',
        'Becomes zero'
      ],
      correctOption: 'Remains constant',
      detailedSolution: 'Magnetic force \\vec{F} = q(\\vec{v} \\times \\vec{B}) is always perpendicular to velocity \\vec{v}. Hence work done by magnetic force is zero (dW = \\vec{F}\\cdot d\\vec{r} = 0), and kinetic energy remains constant.'
    },
    {
      id: 'cbse_phy_q4',
      sectionId: 'sec_b',
      questionNumber: 17,
      subject: 'Physics',
      topic: 'Wave Optics',
      difficulty: 'medium',
      questionType: 'subjective_short',
      marks: 2,
      negativeMarks: 0,
      questionText: 'State Huygens\' Principle. Using it, verify the law of reflection for a plane wave incident on a plane reflecting surface.',
      stepWiseRubric: [
        { step: 'Statement of Huygens secondary wavelets principle', marks: 1, keyPoints: ['Each point on wavefront is source of secondary disturbance', 'Forward envelope gives new wavefront'] },
        { step: 'Geometric ray diagram & proof angle i = angle r', marks: 1, keyPoints: ['Triangles congruence proof', 'i = r'] }
      ],
      detailedSolution: 'Huygens Principle: (1) Every point on a given wavefront acts as a source of secondary spherical wavelets traveling with speed of light in the medium. (2) The forward common tangential surface enveloping these secondary wavelets at any later time gives the new wavefront. By drawing incident plane wavefront AB and reflected wavefront CD, in right triangles \\Delta ABC and \\Delta ADC, hypotenuse AC is common and BC = AD = vt. Thus triangles are congruent, giving \\angle i = \\angle r.'
    },
    {
      id: 'cbse_phy_q5',
      sectionId: 'sec_e',
      questionNumber: 31,
      subject: 'Physics',
      topic: 'Electromagnetic Induction',
      difficulty: 'hard',
      questionType: 'subjective_long',
      marks: 5,
      negativeMarks: 0,
      questionText: 'Explain the working principle and construction of an AC generator with a labeled diagram. Derive the expression for instantaneous induced emf in a coil of N turns rotating in uniform magnetic field B.',
      stepWiseRubric: [
        { step: 'Principle based on Faraday\'s Law & Lenz Law', marks: 1, keyPoints: ['Electromagnetic induction', 'Changing magnetic flux'] },
        { step: 'Neat labeled diagram (armature, slip rings, carbon brushes, magnetic poles)', marks: 1.5, keyPoints: ['Slip rings', 'Carbon brushes', 'Field poles'] },
        { step: 'Mathematical derivation of flux \\Phi = NBA \\cos(\\omega t) and e = NBA\\omega \\sin(\\omega t)', marks: 2.5, keyPoints: ['Flux equation', 'Differentiation with respect to time', 'Peak emf e0 = NBA\\omega'] }
      ],
      detailedSolution: 'Principle: When a closed coil rotates in a uniform magnetic field at constant angular speed, the magnetic flux linked with the coil changes continuously, producing an alternating induced emf. Derivation: Let coil have N turns, area A, rotating at angular speed \\omega in field B. At time t, flux \\Phi = NBA \\cos(\\omega t). By Faraday law, e = -d\\Phi/dt = -d(NBA \\cos(\\omega t))/dt = NBA\\omega \\sin(\\omega t) = e_0 \\sin(\\omega t).'
    }
  ],

  'jee-main-full': [
    {
      id: 'jee_q1',
      sectionId: 'jee_phy_mcq',
      questionNumber: 1,
      subject: 'Physics',
      topic: 'Kinematics & Vectors',
      difficulty: 'medium',
      questionType: 'mcq',
      marks: 4,
      negativeMarks: 1,
      questionText: 'A projectile is launched from the ground with speed u at angle 45° with the horizontal. The radius of curvature of its trajectory at the highest point is:',
      options: [
        'u^2 / g',
        'u^2 / (2g)',
        '2u^2 / g',
        'u^2 / (4g)'
      ],
      correctOption: 'u^2 / (2g)',
      detailedSolution: 'At the highest point, speed is purely horizontal: v = u \\cos(45°) = u / \\sqrt{2}. The normal acceleration is g. Radius of curvature R = v^2 / a_n = (u/\\sqrt{2})^2 / g = u^2 / (2g).'
    },
    {
      id: 'jee_q2',
      sectionId: 'jee_phy_num',
      questionNumber: 21,
      subject: 'Physics',
      topic: 'Capacitance',
      difficulty: 'hard',
      questionType: 'numerical',
      marks: 4,
      negativeMarks: 1,
      questionText: 'A parallel plate capacitor of capacitance 10 \\mu F is charged to 100 V. It is then disconnected from the battery and connected in parallel to an uncharged capacitor of 40 \\mu F. The electrostatic energy lost in the process is ___ milliJoules (mJ).',
      correctNumericalValue: 40,
      numericalTolerance: 0.1,
      detailedSolution: 'Initial energy U_i = (1/2) C_1 V^2 = (1/2) * (10x10^-6) * (100)^2 = 50 mJ. Common potential V_c = (C_1 V)/(C_1 + C_2) = (10*100)/50 = 20 V. Final energy U_f = (1/2)(C_1 + C_2) V_c^2 = (1/2) * (50x10^-6) * (20)^2 = 10 mJ. Energy lost = 50 - 10 = 40 mJ.'
    }
  ]
};
