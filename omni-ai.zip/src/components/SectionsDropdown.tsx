import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronDown,
  Layers,
  Check,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { LECTURE_SECTIONS_META, LectureSectionMeta } from '@/src/lib/studyContentGenerator';

export interface SectionsDropdownProps {
  currentSection: number | 'all';
  onSelectSection: (sectionId: number | 'all') => void;
  topicTitle?: string;
  buttonLabel?: string;
  align?: 'left' | 'right';
  className?: string;
  disabled?: boolean;
}

export const SectionsDropdown: React.FC<SectionsDropdownProps> = ({
  currentSection = 'all',
  onSelectSection,
  topicTitle = '',
  buttonLabel = 'Sections ▾',
  align = 'left',
  className = '',
  disabled = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  const activeMeta = typeof currentSection === 'number' 
    ? LECTURE_SECTIONS_META.find(s => s.id === currentSection) 
    : null;

  return (
    <div ref={dropdownRef} className={cn("relative inline-block text-left shrink-0", className)}>
      {/* Dropdown Trigger Button */}
      <button
        id="lecture-sections-dropdown-trigger"
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(prev => !prev)}
        className={cn(
          "px-2.5 py-1 rounded-xl text-[10px] sm:text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border shadow-sm select-none",
          isOpen
            ? "bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400/40"
            : currentSection !== 'all'
              ? "bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-200 hover:text-white border-amber-500/50 hover:border-amber-400"
              : "bg-slate-900/95 hover:bg-slate-800 text-amber-300 hover:text-amber-200 border-amber-500/40 hover:border-amber-400",
          disabled && "opacity-50 cursor-not-allowed"
        )}
        title="Lecture Sections: Choose any of the 7 sections to teach exclusively, or select All Sections"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <Layers size={13} className={cn("shrink-0", isOpen ? "text-slate-950" : "text-amber-400")} />
        <span className="font-extrabold tracking-tight">
          {activeMeta ? `S${activeMeta.id}: ${activeMeta.shortName.slice(0, 14)}…` : 'Sections'}
        </span>
        {currentSection !== 'all' && (
          <span className={cn(
            "px-1.5 py-0.2 rounded-full text-[9px] font-black shrink-0",
            isOpen ? "bg-slate-950 text-amber-300" : "bg-amber-400/20 text-amber-300 border border-amber-400/40"
          )}>
            S{currentSection}
          </span>
        )}
        <ChevronDown
          size={12}
          className={cn("transition-transform duration-200 shrink-0", isOpen ? "rotate-180 text-slate-950" : "text-amber-400")}
        />
      </button>

      {/* Dropdown Menu Panel */}
      {isOpen && (
        <div
          className={cn(
            "absolute z-50 mt-1.5 w-[340px] sm:w-[420px] max-w-[92vw] rounded-2xl bg-slate-950/95 backdrop-blur-2xl border border-amber-500/40 shadow-2xl shadow-black/80 overflow-hidden animate-in fade-in zoom-in-95 duration-150",
            align === 'left' ? 'left-0 origin-top-left' : 'right-0 origin-top-right'
          )}
        >
          {/* Header */}
          <div className="px-3.5 py-2.5 bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1 rounded-lg bg-amber-500/20 border border-amber-500/30 text-amber-400">
                <BookOpen size={14} />
              </div>
              <div>
                <h4 className="text-xs font-black text-amber-300 tracking-wide uppercase flex items-center gap-1.5">
                  Lecture Sections
                  <span className="px-1.5 py-0.2 rounded bg-amber-400/10 text-amber-300 text-[10px] font-bold border border-amber-500/20">
                    7 Modules
                  </span>
                </h4>
                <p className="text-[10px] text-slate-400 font-medium truncate max-w-[260px]">
                  {topicTitle ? `Topic: ${topicTitle}` : 'Select a section to teach exclusively'}
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-amber-400/80 bg-slate-900/90 px-2 py-0.5 rounded-full border border-amber-500/20">
              {currentSection === 'all' ? 'All Sections' : `Section ${currentSection}`}
            </span>
          </div>

          {/* Quick Option: All Sections */}
          <div className="p-1.5 border-b border-white/5 bg-slate-900/40">
            <button
              id="section-select-all"
              type="button"
              onClick={() => {
                onSelectSection('all');
                setIsOpen(false);
              }}
              className={cn(
                "w-full text-left p-2 rounded-xl transition-all flex items-center justify-between group cursor-pointer border",
                currentSection === 'all'
                  ? "bg-amber-500/15 border-amber-400/50 text-white shadow-sm"
                  : "bg-slate-900/60 hover:bg-slate-800/80 border-white/5 text-slate-300 hover:text-white"
              )}
            >
              <div className="flex items-center gap-2">
                <div className={cn(
                  "w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold shrink-0 transition-colors",
                  currentSection === 'all' ? "bg-amber-400 text-slate-950 font-black shadow" : "bg-slate-800 text-amber-300 group-hover:bg-amber-400/20"
                )}>
                  📚
                </div>
                <div>
                  <div className="text-xs font-bold text-white group-hover:text-amber-300 flex items-center gap-1.5">
                    All Sections (Full Comprehensive Lecture)
                    {currentSection === 'all' && (
                      <span className="text-[9px] font-extrabold text-amber-400 bg-amber-400/10 px-1 rounded">Active</span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 leading-tight">
                    Deliver all 7 sections continuously (124–162+ Questions generated)
                  </div>
                </div>
              </div>
              {currentSection === 'all' && (
                <Check size={14} className="text-amber-400 shrink-0 ml-2" />
              )}
            </button>
          </div>

          {/* 7 Section Items */}
          <div className="max-h-[380px] overflow-y-auto p-1.5 space-y-1 custom-scrollbar">
            {LECTURE_SECTIONS_META.map((sec) => {
              const isSelected = currentSection === sec.id;
              return (
                <button
                  key={sec.id}
                  id={`section-select-${sec.id}`}
                  type="button"
                  onClick={() => {
                    onSelectSection(sec.id);
                    setIsOpen(false);
                  }}
                  className={cn(
                    "w-full text-left p-2 rounded-xl transition-all flex items-start justify-between group cursor-pointer border",
                    isSelected
                      ? "bg-gradient-to-r from-amber-500/20 via-slate-900 to-indigo-950/40 border-amber-400/60 text-white shadow-md ring-1 ring-amber-400/30"
                      : "bg-slate-900/40 hover:bg-slate-800/70 border-white/5 text-slate-300 hover:text-white hover:border-amber-500/30"
                  )}
                >
                  <div className="flex items-start gap-2.5">
                    <div className={cn(
                      "w-7 h-7 rounded-lg flex items-center justify-center text-sm shrink-0 font-bold mt-0.5 transition-colors",
                      isSelected ? "bg-amber-400 text-slate-950 shadow" : "bg-slate-800 text-slate-300 group-hover:bg-amber-400/20"
                    )}>
                      {sec.icon}
                    </div>
                    <div className="min-w-0 pr-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={cn(
                          "text-xs font-bold transition-colors",
                          isSelected ? "text-amber-300" : "text-white group-hover:text-amber-300"
                        )}>
                          {sec.fullName}
                        </span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-white/5">
                          {sec.questionCountInfo}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 group-hover:text-slate-300 mt-0.5 leading-snug line-clamp-2">
                        {sec.summary}
                      </p>
                    </div>
                  </div>
                  {isSelected && (
                    <div className="shrink-0 ml-2 mt-1">
                      <div className="w-5 h-5 rounded-full bg-amber-400 flex items-center justify-center text-slate-950 shadow">
                        <Check size={12} strokeWidth={3} />
                      </div>
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Footer note */}
          <div className="px-3 py-2 bg-slate-900/90 border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400">
            <span className="flex items-center gap-1">
              <Sparkles size={11} className="text-amber-400" />
              <span>Professor teaches strictly chosen section</span>
            </span>
            <span className="text-[9px] text-slate-500 font-mono">124–162+ Qs Suite</span>
          </div>
        </div>
      )}
    </div>
  );
};
