export * from '../../src/components/LearningStyleCard';
export { LearningStyleCard as default } from '../../src/components/LearningStyleCard';
