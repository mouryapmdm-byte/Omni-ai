import React, { useState, useEffect } from 'react';
import {
  X,
  Pencil,
  Save,
  RotateCcw,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  Plus,
  Calculator,
  FileText,
  Eye,
  Edit3,
  BookOpen,
  Code2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import rehypeRaw from 'rehype-raw';
import { formatMarkdownWithInlineSvgs } from '../lib/utils';
import { cleanStreamingMarkdown } from '../lib/streaming/cleanStreamingMarkdown';
import { SvgDiagramViewer } from './SvgDiagramViewer';

interface EditableQuestionSolutionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialText: string;
  onSave: (newText: string) => void;
  showNotification?: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export const EditableQuestionSolutionModal: React.FC<EditableQuestionSolutionModalProps> = ({
  isOpen,
  onClose,
  initialText,
  onSave,
  showNotification
}) => {
  const [editedText, setEditedText] = useState<string>('');
  const [originalBackup, setOriginalBackup] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'editor' | 'preview' | 'split'>('split');

  useEffect(() => {
    if (isOpen) {
      const textToLoad = initialText || '';
      setEditedText(textToLoad);
      setOriginalBackup(textToLoad);
    }
  }, [isOpen, initialText]);

  if (!isOpen) return null;

  const handleSave = () => {
    const trimmed = editedText.trim();
    if (!trimmed) {
      showNotification?.("Smartboard text cannot be empty", "warning");
      return;
    }
    onSave(trimmed);
  };

  const handleReset = () => {
    setEditedText(originalBackup);
    showNotification?.("Text reset to original content", "info");
  };

  // Helper insertion snippets
  const insertSnippet = (snippet: string) => {
    setEditedText(prev => {
      if (!prev.trim()) return snippet;
      return prev + '\n\n' + snippet;
    });
  };

  const NUMERICAL_TEMPLATE = `### ❓ Numerical Problem 1:
Given a system with parameters:
- **Given Data**: $m = 2.0\\text{ kg}$, $a = 9.8\\text{ m/s}^2$
- **Formula to Apply**: $F = m \\times a$

### ✅ Model Solution (Step-by-Step):
1. **Identify Given Quantities**:
   Mass $m = 2.0\\text{ kg}$, Acceleration $a = 9.8\\text{ m/s}^2$
2. **Apply Equation**:
   $$F = (2.0) \\times (9.8) = 19.6\\text{ N}$$
3. **Final Answer**:
   $$F = 19.6\\text{ N} \\quad (\\text{SI Units: Newtons})$$`;

  const QUESTION_TEMPLATE = `### ❓ Question:
Explain the fundamental governing law and derive the step-by-step mathematical expression.`;

  const SOLUTION_TEMPLATE = `### ✅ Model Solution (Step-by-Step):
1. **Core Principle**: State the physical law or axiom clearly.
2. **Derivation / Step-by-Step Working**:
   $$E = mc^2$$
3. **Final Conclusion & Key Takeaway**:
   Summarize the final result and physical significance.`;

  const MARKING_SCHEME_TEMPLATE = `### 📋 Marking Scheme & Key Scoring Steps:
- **Step 1 (1 Mark)**: Writing correct formula with units.
- **Step 2 (2 Marks)**: Proper algebraic substitution and intermediate calculations.
- **Step 3 (1 Mark)**: Stating final calculated answer with appropriate SI unit.`;

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-6xl max-h-[92vh] bg-slate-900 border-2 border-indigo-500/50 rounded-2xl shadow-2xl overflow-hidden flex flex-col text-slate-100">
        
        {/* MODAL HEADER */}
        <div className="px-4 py-3 sm:px-6 sm:py-4 bg-gradient-to-r from-slate-950 via-indigo-950/80 to-slate-950 border-b border-indigo-500/30 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/30 border border-indigo-400/50 flex items-center justify-center text-indigo-300 shrink-0">
              <Pencil size={18} />
            </div>
            <div className="overflow-hidden">
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black tracking-tight text-white truncate">
                  Edit Asked Question & Solution
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-bold uppercase tracking-wider hidden sm:inline-flex items-center gap-1">
                  <Sparkles size={10} className="text-amber-400" /> 3D Smartboard Live Sync
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate">
                Double-click text editor • Customize question statement, numerical values, formulas, or step-by-step solution
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* View Mode Toggle */}
            <div className="hidden sm:flex items-center p-1 rounded-xl bg-slate-950 border border-slate-800 text-xs font-bold">
              <button
                onClick={() => setActiveTab('editor')}
                className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  activeTab === 'editor' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Edit3 size={12} />
                <span>Editor</span>
              </button>
              <button
                onClick={() => setActiveTab('split')}
                className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  activeTab === 'split' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Code2 size={12} />
                <span>Split View</span>
              </button>
              <button
                onClick={() => setActiveTab('preview')}
                className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  activeTab === 'preview' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Eye size={12} />
                <span>Preview</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Close editor"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* QUICK TEMPLATE INSERTION TOOLBAR */}
        <div className="px-4 py-2 bg-slate-950/90 border-b border-slate-800/80 flex items-center gap-1.5 overflow-x-auto scrollbar-hide shrink-0 text-xs font-medium">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Plus size={12} className="text-indigo-400" /> Insert:
          </span>
          <button
            onClick={() => insertSnippet(NUMERICAL_TEMPLATE)}
            className="px-2.5 py-1 rounded-lg bg-indigo-950/70 hover:bg-indigo-900/90 border border-indigo-500/40 text-indigo-200 text-xs font-semibold flex items-center gap-1 transition-all shrink-0 cursor-pointer"
          >
            <Calculator size={12} className="text-indigo-400" />
            <span>➕ Numerical Problem</span>
          </button>
          <button
            onClick={() => insertSnippet(QUESTION_TEMPLATE)}
            className="px-2.5 py-1 rounded-lg bg-sky-950/70 hover:bg-sky-900/90 border border-sky-500/40 text-sky-200 text-xs font-semibold flex items-center gap-1 transition-all shrink-0 cursor-pointer"
          >
            <HelpCircle size={12} className="text-sky-400" />
            <span>❓ Question Block</span>
          </button>
          <button
            onClick={() => insertSnippet(SOLUTION_TEMPLATE)}
            className="px-2.5 py-1 rounded-lg bg-emerald-950/70 hover:bg-emerald-900/90 border border-emerald-500/40 text-emerald-200 text-xs font-semibold flex items-center gap-1 transition-all shrink-0 cursor-pointer"
          >
            <CheckCircle2 size={12} className="text-emerald-400" />
            <span>✅ Model Solution</span>
          </button>
          <button
            onClick={() => insertSnippet(MARKING_SCHEME_TEMPLATE)}
            className="px-2.5 py-1 rounded-lg bg-amber-950/70 hover:bg-amber-900/90 border border-amber-500/40 text-amber-200 text-xs font-semibold flex items-center gap-1 transition-all shrink-0 cursor-pointer"
          >
            <BookOpen size={12} className="text-amber-400" />
            <span>📋 Marking Scheme</span>
          </button>
        </div>

        {/* MAIN CONTENT WORKSPACE */}
        <div className="flex-1 min-h-[350px] p-3 sm:p-4 overflow-hidden flex flex-col sm:flex-row gap-3">
          
          {/* EDITOR COLUMN */}
          {(activeTab === 'editor' || activeTab === 'split') && (
            <div className={`flex-1 flex flex-col min-h-0 bg-slate-950 rounded-xl border border-slate-800 p-2.5 ${activeTab === 'split' ? 'w-full sm:w-1/2' : 'w-full'}`}>
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs font-bold text-slate-400">
                <span className="flex items-center gap-1.5 text-indigo-300">
                  <Pencil size={13} />
                  <span>Markdown Editor (Question & Solution)</span>
                </span>
                <span className="text-[11px] font-mono text-slate-500">
                  {editedText.length} chars • {editedText.split('\n').length} lines
                </span>
              </div>
              <textarea
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                placeholder="Type or edit your asked question, numerical given data, applied formula, or model solution here..."
                className="w-full flex-1 min-h-[280px] p-3 bg-slate-950 text-slate-100 font-mono text-xs sm:text-sm leading-relaxed border border-slate-800 rounded-lg focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none"
              />
            </div>
          )}

          {/* PREVIEW COLUMN */}
          {(activeTab === 'preview' || activeTab === 'split') && (
            <div className={`flex-1 flex flex-col min-h-0 bg-slate-950 rounded-xl border border-slate-800 p-3 overflow-y-auto ${activeTab === 'split' ? 'w-full sm:w-1/2' : 'w-full'}`}>
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs font-bold text-slate-400 shrink-0">
                <span className="flex items-center gap-1.5 text-emerald-300">
                  <Eye size={13} />
                  <span>3D Smartboard Live Preview</span>
                </span>
                <span className="text-[10px] text-emerald-400/80 font-semibold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                  Formatted Output
                </span>
              </div>

              <div className="prose prose-invert prose-sm max-w-none text-slate-200">
                <ReactMarkdown
                  remarkPlugins={[remarkGfm, remarkMath]}
                  rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }], rehypeRaw]}
                  components={{
                    code: ({ inline, className, children, ...props }: any) => {
                      const codeStr = Array.isArray(children)
                        ? children.map(c => (typeof c === 'string' ? c : '')).join('').trim()
                        : (typeof children === 'string' ? children.trim() : '');
                      if (!inline && codeStr.includes('<svg') && codeStr.includes('</svg>')) {
                        return (
                          <div className="my-3 not-prose w-full overflow-hidden rounded-xl border border-slate-700 bg-slate-950 p-1">
                            <SvgDiagramViewer svgCode={codeStr} theme="dark" showNotification={showNotification} />
                          </div>
                        );
                      }
                      return <code className={className} {...props}>{children}</code>;
                    },
                    p: ({ children }: any) => {
                      const text = Array.isArray(children)
                        ? children.map(c => (typeof c === 'string' ? c : '')).join('')
                        : (typeof children === 'string' ? children : '');
                      const isQuestion = /(?:^|\b)(?:Q\d*[:.]|\*\*Q|\*\*\[Category|\*\*\[NEET|\*\*\[JEE|Assertion:|Reason:)/i.test(text);
                      const isAnswer = /(?:✅|\bModel Answer|\bSolution:)/i.test(text);
                      const isCriteria = /(?:📋|\bMarking Scheme:|\bExaminer Criteria:)/i.test(text);

                      if (isQuestion) {
                        return (
                          <div className="my-3 p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border-2 border-indigo-500/40 text-slate-100 shadow-xl">
                            <div className="flex items-center gap-2 mb-2 pb-1.5 border-b border-indigo-500/30">
                              <span className="px-2 py-0.5 rounded-md bg-indigo-500/30 border border-indigo-400 text-indigo-200 text-[10px] font-black uppercase tracking-wider">
                                Asked Question
                              </span>
                            </div>
                            <div className="font-semibold text-slate-100 leading-relaxed text-sm">
                              {children}
                            </div>
                          </div>
                        );
                      }

                      if (isAnswer) {
                        return (
                          <div className="my-3 p-3.5 rounded-2xl bg-emerald-950/40 border-2 border-emerald-500/40 text-emerald-100 shadow-lg">
                            <div className="flex items-center gap-1.5 mb-1.5 text-emerald-300 font-bold text-xs uppercase tracking-wider">
                              <CheckCircle2 size={13} className="text-emerald-400" />
                              <span>Model Solution (Step-by-Step)</span>
                            </div>
                            <div className="leading-relaxed text-slate-200 text-sm">
                              {children}
                            </div>
                          </div>
                        );
                      }

                      if (isCriteria) {
                        return (
                          <div className="my-3 p-3.5 rounded-2xl bg-amber-950/30 border-2 border-amber-500/40 text-amber-100 shadow-lg">
                            <div className="flex items-center gap-1.5 mb-1.5 text-amber-300 font-bold text-xs uppercase tracking-wider">
                              <BookOpen size={13} className="text-amber-400" />
                              <span>Marking Scheme & Key Scoring Steps</span>
                            </div>
                            <div className="leading-relaxed text-slate-200 text-sm">
                              {children}
                            </div>
                          </div>
                        );
                      }

                      return <div className="mb-3 leading-relaxed text-slate-200">{children}</div>;
                    },
                    text: ({ children, node, ...props }: any) => (
                      <span
                        style={{
                          fontFamily: props['font-family'] || props.fontFamily,
                          fontSize: props['font-size'] || props.fontSize,
                          fontWeight: props['font-weight'] || props.fontWeight,
                          color: props.fill || undefined
                        }}
                      >
                        {children}
                      </span>
                    )
                  }}
                >
                  {formatMarkdownWithInlineSvgs(cleanStreamingMarkdown(editedText, false))}
                </ReactMarkdown>
              </div>
            </div>
          )}

        </div>

        {/* MODAL FOOTER */}
        <div className="px-4 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={handleReset}
            className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Reset text to original unedited AI output"
          >
            <RotateCcw size={14} />
            <span>Reset Original</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-black text-xs shadow-lg shadow-indigo-500/20 border border-indigo-400/40 flex items-center gap-2 transition-all cursor-pointer active:scale-95"
            >
              <Save size={14} />
              <span>Save & Update 3D Smartboard</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
