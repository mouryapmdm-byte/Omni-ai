/**
 * LaTeX Sanitizer and Error Prevention Engine
 * 
 * Provides robust pre-processing and sanitization for LaTeX mathematical expressions
 * to prevent parser warnings and errors, specifically:
 * "LaTeX-incompatible input and strict mode is set to 'warn': % comment has no terminating newline; 
 *  LaTeX would fail because of commenting the end of math mode (e.g. $) [commentAtEnd]"
 */

/**
 * Standard KaTeX options to prevent commentAtEnd, unknownSymbol (e.g. ₹ rupee symbol missing font metrics),
 * and strict mode parsing halts.
 */
export const safeKatexOptions = {
  throwOnError: false,
  strict: false,
  trust: true,
  macros: {
    '\\rupee': '\\text{₹}',
    '\\INR': '\\text{₹}',
    '\\Rs': '\\text{Rs. }',
  },
};

/**
 * Strips or safely extracts non-math glyphs (emojis, warning symbols like ⚠, and variation selectors like \uFE0F)
 * from inside LaTeX math blocks so KaTeX does not emit "No character metrics for ..." warnings.
 */
function cleanMathGlyphs(math: string): string {
  if (!math) return '';
  // Remove variation selector 16 (\uFE0F) and text style (\uFE0E)
  let cleaned = math.replace(/[\uFE0E\uFE0F]/g, '');
  // Remove warning symbols and general emojis that lack KaTeX font metrics
  cleaned = cleaned.replace(/[\u26A0\u26A1\u2700-\u27BF\u{1F300}-\u{1F9FF}]/gu, '');
  return cleaned;
}

/**
 * Sanitizes LaTeX input to prevent comment-related parsing errors.
 * Handles comments at end of math mode, missing newlines, and EOF issues.
 * 
 * @param latex - The raw LaTeX string to sanitize.
 * @returns - Sanitized LaTeX string safe for KaTeX / MathJax rendering.
 */
export function sanitizeLatex(latex: string): string {
  if (!latex || typeof latex !== 'string') return '';

  let sanitized = cleanMathGlyphs(latex);

  // 1. Remove or sanitize comments strictly inside inline math mode ($...%...$)
  // where % without newline would comment out the closing delimiter
  sanitized = sanitized.replace(/(?<!\$)\$(?!\$)([^$\n]*?)%([^$\n]*?)(?<!\$)\$(?!\$)/g, (_match, p1) => {
    return `$${p1.trim()}$`;
  });

  // 2. Ensure every % comment has a single terminating newline
  // Matches % and all characters up to an optional newline or EOF, and replaces with %content\n
  sanitized = sanitized.replace(/%([^\r\n]*)(?:\r?\n|$)/g, '%$1\n');

  // 3. Ensure the string ends with a newline
  if (!sanitized.endsWith('\n')) {
    sanitized += '\n';
  }

  // 4. Ensure balanced delimiters for common inline math ($...$)
  const dollarMatches = sanitized.match(/(?<!\\)\$/g) || [];
  if (dollarMatches.length % 2 !== 0) {
    sanitized = sanitized.trimEnd() + '$\n';
  }

  return sanitized;
}

/**
 * Pre-processes Markdown content containing LaTeX math blocks ($...$, $$...$$, \[...\], \(...\))
 * ensuring all mathematical equations are sanitized and will not trigger commentAtEnd warnings.
 * 
 * @param markdown - Raw markdown string containing potential LaTeX expressions
 * @returns - Sanitized markdown string
 */
export function sanitizeLatexInMarkdown(markdown: string): string {
  if (!markdown || typeof markdown !== 'string') return '';

  let result = markdown;

  // 1. Sanitize block math $$ ... $$
  result = result.replace(/\$\$([\s\S]*?)\$\$/g, (_match, mathContent) => {
    let cleanMath = cleanMathGlyphs(mathContent);
    // Ensure all % comments inside block math have trailing newlines
    cleanMath = cleanMath.replace(/%([^\n]*?)(?=\n|$)/g, '%$1\n');
    if (!cleanMath.endsWith('\n')) {
      cleanMath += '\n';
    }
    return `$$\n${cleanMath.trim()}\n$$`;
  });

  // 2. Sanitize display math \[ ... \]
  result = result.replace(/\\\[([\s\S]*?)\\\]/g, (_match, mathContent) => {
    let cleanMath = cleanMathGlyphs(mathContent);
    cleanMath = cleanMath.replace(/%([^\n]*?)(?=\n|$)/g, '%$1\n');
    if (!cleanMath.endsWith('\n')) {
      cleanMath += '\n';
    }
    return `\\[\n${cleanMath.trim()}\n\\]`;
  });

  // 3. Sanitize inline math $ ... $ (excluding $$)
  result = result.replace(/(?<!\$)\$(?!\$)(.*?)(?<!\$)\$(?!\$)/g, (_match, mathContent) => {
    // If inline math contains a % comment, strip or transform with \text{} or add space
    let cleanMath = cleanMathGlyphs(mathContent);
    if (cleanMath.includes('%')) {
      cleanMath = cleanMath.replace(/%[^\n]*/g, '').trim();
    }
    return `$${cleanMath}$`;
  });

  // 4. Handle any remaining trailing % at the absolute end of the markdown string
  result = result.replace(/%([^\n]*?)$/g, '%$1\n');

  return result;
}

/**
 * Converts mathematical interval notations commonly found in domain/range tables
 * into human-readable dual degree-and-radian explanations (No raw cryptic LaTeX).
 */
export function formatHumanReadableInterval(text: string): string {
  if (!text) return '';
  return text
    // Inverse Trig Principal Ranges
    .replace(/\\left\[\s*-\\frac\{\\pi\}\{2\}\s*,\s*\\frac\{\\pi\}\{2\}\s*\\right\]|\[\s*-\\pi\/2\s*,\s*\\pi\/2\s*\]/g, '−90° to 90° (−π/2 to π/2)')
    .replace(/\\left\[\s*0\s*,\s*\\pi\s*\\right\]|\[\s*0\s*,\s*\\pi\s*\]/g, '0° to 180° (0 to π)')
    .replace(/\\left\(\s*-\\frac\{\\pi\}\{2\}\s*,\s*\\frac\{\\pi\}\{2\}\s*\\right\)|\s*-\\pi\/2\s*,\s*\\pi\/2\s*/g, '−90° to 90° exclusive (−π/2 to π/2)')
    .replace(/\\left\(\s*0\s*,\s*\\pi\s*\\right\)|\s*0\s*,\s*\\pi\s*/g, '0° to 180° exclusive (0 to π)')
    .replace(/\\left\[\s*-1\s*,\s*1\s*\\right\]|\[\s*-1\s*,\s*1\s*\]/g, '−1 to 1 (inclusive)')
    .replace(/\\mathbb\{R\}\s*\\setminus\s*\\left\(?-1,\s*1\\right\)?|\b(?:R\s*-\s*-1,\s*1|All\s*real\s*numbers\s*except\s*-1,\s*1)/g, 'All Real Numbers outside (−1, 1)')
    .replace(/\\mathbb\{R\}|\bR\b(?=\s*[\],|])/g, 'All Real Numbers (ℝ)')
    .replace(/\\left\[/g, '[')
    .replace(/\\right\]/g, ']')
    .replace(/\\left\(/g, '(')
    .replace(/\\right\)/g, ')');
}

/**
 * Pre-processes Markdown tables to ensure all table columns, headers, and cells
 * are human-readable, beautifully aligned, and free of cryptic raw LaTeX strings.
 */
export function sanitizeTablesInMarkdown(markdown: string): string {
  if (!markdown || typeof markdown !== 'string') return '';

  return markdown.replace(/(\|.+?\|[\r\n]+(?:\|[-: ]+?\|[\r\n]+)(?:\|.+?\|[\r\n]*)+)/g, (tableMatch) => {
    const lines = tableMatch.trim().split('\n');
    const processedLines = lines.map(line => {
      // Split cells
      const cells = line.split('|');
      const formattedCells = cells.map(cell => {
        let trimmed = cell.trim();
        if (!trimmed || /^[-:]+$/.test(trimmed)) return cell;
        return ` ${formatHumanReadableInterval(trimmed)} `;
      });
      return formattedCells.join('|');
    });
    return processedLines.join('\n');
  });
}

/**
 * Test and validation suite for LaTeX parsing resilience.
 */
export interface TestCase {
  name: string;
  input: string;
  expected: string | ((result: string) => boolean);
}

export const LATEX_TEST_CASES: TestCase[] = [
  {
    name: 'Comment at end with no newline',
    input: '$x = 5$ % comment',
    expected: '$x = 5$ % comment\n',
  },
  {
    name: 'Comment inside math mode',
    input: '$x = 5 % comment\n$',
    expected: (res: string) => res.includes('$x = 5') && res.endsWith('\n'),
  },
  {
    name: 'Comment at EOF',
    input: '$y = 10$% EOF comment',
    expected: '$y = 10$% EOF comment\n',
  },
  {
    name: 'Multiple comments',
    input: '$a = 1$ % first\n$b = 2$ % second',
    expected: '$a = 1$ % first\n$b = 2$ % second\n',
  },
  {
    name: 'No comment, clean input',
    input: '$x = 5$',
    expected: '$x = 5$\n',
  },
  {
    name: 'Comment with newline already present',
    input: '$x = 5$ % comment\n',
    expected: '$x = 5$ % comment\n',
  },
  {
    name: 'Unbalanced delimiters',
    input: '$x = 5',
    expected: (res: string) => (res.match(/(?<!\\)\$/g) || []).length % 2 === 0,
  },
];

export function runLatexSanitizerTests(): { passed: number; total: number; results: { name: string; success: boolean; output: string }[] } {
  const results = LATEX_TEST_CASES.map(tc => {
    const output = sanitizeLatex(tc.input);
    let success = false;
    if (typeof tc.expected === 'function') {
      success = tc.expected(output);
    } else {
      success = output === tc.expected;
    }
    return { name: tc.name, success, output };
  });

  const passed = results.filter(r => r.success).length;
  return { passed, total: results.length, results };
}
