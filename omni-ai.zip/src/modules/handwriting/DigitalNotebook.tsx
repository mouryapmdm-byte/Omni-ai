import React, { useState, useEffect } from 'react';
import { collection, addDoc, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db, auth } from '../../lib/firebase';
import { DrawingCanvas } from './DrawingCanvas';
import { recognizeMath } from './RecognitionService';

export interface HandwritingSubmission {
  id: string;
  studentId: string;
  questionId?: string;
  imageData: string;
  recognizedLatex: string;
  isCorrect: boolean;
  errorStep?: number;
  createdAt: string;
}

export const DigitalNotebook: React.FC = () => {
  const [submissions, setSubmissions] = useState<HandwritingSubmission[]>([]);

  useEffect(() => {
    const fetchSubmissions = async () => {
      if (!auth.currentUser) return;
      const q = query(
        collection(db, 'handwritingSubmissions'),
        where('studentId', '==', auth.currentUser.uid),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(q);
      setSubmissions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as HandwritingSubmission)));
    };
    fetchSubmissions();
  }, []);

  const handleSave = async (imageData: string) => {
    if (!auth.currentUser) return;
    const recognizedLatex = await recognizeMath(imageData);
    const submission = {
      studentId: auth.currentUser.uid,
      imageData,
      recognizedLatex,
      isCorrect: false, // Default
      createdAt: new Date().toISOString()
    };
    await addDoc(collection(db, 'handwritingSubmissions'), submission);
    // Refresh list...
  };

  return (
    <div className="space-y-6">
      <DrawingCanvas onSave={handleSave} />
      <div className="grid grid-cols-2 gap-4">
        {submissions.map(sub => (
          <div key={sub.id} className="border p-4 rounded">
            <img src={sub.imageData} alt="Handwriting" className="w-full h-32 object-contain" />
            <p className="font-mono text-sm">{sub.recognizedLatex}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
