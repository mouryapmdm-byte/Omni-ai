export interface PredictiveTerm {
  id: string;
  text: string;
  category: 'phrase' | 'term' | 'formula' | 'concept';
  subject?: string;
  topic?: string;
  tags?: string[];
}

export const PREDICTIVE_DICTIONARY: PredictiveTerm[] = [
  // --- Universal Pedagogical / Inquiry Phrases ---
  {
    id: 'p1',
    text: 'Could you explain step-by-step how to solve',
    category: 'phrase',
    tags: ['explain', 'solve', 'step-by-step', 'pedagogy']
  },
  {
    id: 'p2',
    text: 'What is the physical intuition behind',
    category: 'phrase',
    tags: ['intuition', 'physics', 'concept']
  },
  {
    id: 'p3',
    text: 'Can you derive the mathematical formula for',
    category: 'phrase',
    tags: ['derive', 'formula', 'proof']
  },
  {
    id: 'p4',
    text: 'How do we evaluate the limit as x approaches',
    category: 'phrase',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['limit', 'calculus', 'evaluation']
  },
  {
    id: 'p5',
    text: 'What are the boundary conditions and assumptions for',
    category: 'phrase',
    tags: ['boundary', 'conditions', 'assumptions']
  },
  {
    id: 'p6',
    text: 'Can you provide a simple geometric visualization of',
    category: 'phrase',
    tags: ['geometric', 'visualization', 'graph']
  },
  {
    id: 'p7',
    text: 'What is the key difference between',
    category: 'phrase',
    tags: ['difference', 'compare', 'contrast']
  },
  {
    id: 'p8',
    text: 'Can you give a practical real-world application of',
    category: 'phrase',
    tags: ['application', 'real-world', 'example']
  },
  {
    id: 'p9',
    text: 'How do we verify or prove',
    category: 'phrase',
    tags: ['proof', 'verify', 'theorem']
  },
  {
    id: 'p10',
    text: 'Can you construct a counterexample for',
    category: 'phrase',
    tags: ['counterexample', 'logic', 'proof']
  },

  // --- Mathematics: Calculus & Analysis ---
  {
    id: 'm1',
    text: 'Taylor series expansion around x = 0',
    category: 'formula',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['taylor', 'series', 'expansion', 'approximation']
  },
  {
    id: 'm2',
    text: 'Partial derivative with respect to x',
    category: 'concept',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['derivative', 'multivariable', 'calculus']
  },
  {
    id: 'm3',
    text: 'Epsilon-delta definition of a limit',
    category: 'concept',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['epsilon', 'delta', 'limit', 'rigor']
  },
  {
    id: 'm4',
    text: 'Fundamental Theorem of Calculus',
    category: 'concept',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['integral', 'derivative', 'theorem']
  },
  {
    id: 'm5',
    text: 'Integration by parts formula: ∫u dv = uv - ∫v du',
    category: 'formula',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['integration', 'parts', 'calculus']
  },
  {
    id: 'm6',
    text: "L'Hôpital's Rule for indeterminate forms 0/0 and ∞/∞",
    category: 'formula',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['lhopital', 'limit', 'indeterminate']
  },
  {
    id: 'm7',
    text: 'Gradient vector and directional derivative',
    category: 'term',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['gradient', 'vector', 'directional']
  },
  {
    id: 'm8',
    text: 'Jacobian matrix and determinant transformation',
    category: 'term',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['jacobian', 'matrix', 'coordinate']
  },
  {
    id: 'm9',
    text: 'Fourier transform and frequency domain decomposition',
    category: 'concept',
    subject: 'mathematics',
    topic: 'analysis',
    tags: ['fourier', 'transform', 'frequency']
  },
  {
    id: 'm10',
    text: 'Laplacian differential operator ∇²',
    category: 'formula',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['laplacian', 'differential', 'pde']
  },
  {
    id: 'm11',
    text: 'Stokes Theorem for surface and line integrals',
    category: 'concept',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['stokes', 'vector', 'integral']
  },
  {
    id: 'm12',
    text: 'Divergence Theorem in 3D vector fields',
    category: 'concept',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['divergence', 'flux', 'vector']
  },
  {
    id: 'm13',
    text: 'Riemann sum approximation of definite integral',
    category: 'concept',
    subject: 'mathematics',
    topic: 'calculus',
    tags: ['riemann', 'integral', 'approximation']
  },

  // --- Mathematics: Linear Algebra ---
  {
    id: 'la1',
    text: 'Eigenvalues and eigenvectors det(A - λI) = 0',
    category: 'formula',
    subject: 'mathematics',
    topic: 'algebra',
    tags: ['eigenvalues', 'eigenvectors', 'matrix']
  },
  {
    id: 'la2',
    text: 'Matrix diagonalization A = PDP⁻¹',
    category: 'concept',
    subject: 'mathematics',
    topic: 'algebra',
    tags: ['matrix', 'diagonalization', 'linear']
  },
  {
    id: 'la3',
    text: 'Gram-Schmidt orthogonalization process',
    category: 'term',
    subject: 'mathematics',
    topic: 'algebra',
    tags: ['gram-schmidt', 'orthogonality', 'basis']
  },
  {
    id: 'la4',
    text: 'Gaussian elimination to Reduced Row Echelon Form (RREF)',
    category: 'term',
    subject: 'mathematics',
    topic: 'algebra',
    tags: ['gaussian', 'rref', 'system']
  },
  {
    id: 'la5',
    text: 'Cauchy-Schwarz inequality |⟨u,v⟩| ≤ ‖u‖‖v‖',
    category: 'formula',
    subject: 'mathematics',
    topic: 'algebra',
    tags: ['cauchy', 'schwarz', 'inequality']
  },
  {
    id: 'la6',
    text: 'Singular Value Decomposition (SVD) matrix factorization',
    category: 'concept',
    subject: 'mathematics',
    topic: 'algebra',
    tags: ['svd', 'decomposition', 'matrices']
  },
  {
    id: 'la7',
    text: 'Null space, column space, and Rank-Nullity Theorem',
    category: 'concept',
    subject: 'mathematics',
    topic: 'algebra',
    tags: ['rank', 'nullity', 'subspace']
  },

  // --- Mathematics: Algebra & Geometry ---
  {
    id: 'ag1',
    text: 'Quadratic formula derivation x = (-b ± √(b² - 4ac)) / (2a)',
    category: 'formula',
    subject: 'mathematics',
    topic: 'algebra',
    tags: ['quadratic', 'formula', 'roots']
  },
  {
    id: 'ag2',
    text: 'Pythagorean trigonometric identity sin²(θ) + cos²(θ) = 1',
    category: 'formula',
    subject: 'mathematics',
    topic: 'trigonometry',
    tags: ['trigonometry', 'identity', 'sine', 'cosine']
  },
  {
    id: 'ag3',
    text: 'Euler Formula e^(iπ) + 1 = 0',
    category: 'formula',
    subject: 'mathematics',
    topic: 'complex',
    tags: ['euler', 'complex', 'exponential']
  },

  // --- Physics & Engineering ---
  {
    id: 'ph1',
    text: 'Conservation of angular momentum L = Iω',
    category: 'concept',
    subject: 'physics',
    topic: 'mechanics',
    tags: ['angular', 'momentum', 'conservation']
  },
  {
    id: 'ph2',
    text: 'Time-dependent Schrödinger equation iħ ∂Ψ/∂t = ĤΨ',
    category: 'formula',
    subject: 'physics',
    topic: 'quantum',
    tags: ['schrodinger', 'quantum', 'mechanics']
  },
  {
    id: 'ph3',
    text: "Maxwell's equations for electromagnetic fields",
    category: 'concept',
    subject: 'physics',
    topic: 'electromagnetism',
    tags: ['maxwell', 'electromagnetism', 'flux']
  },
  {
    id: 'ph4',
    text: 'Second Law of Thermodynamics and entropy increase dS ≥ 0',
    category: 'concept',
    subject: 'physics',
    topic: 'thermodynamics',
    tags: ['entropy', 'thermodynamics', 'heat']
  },
  {
    id: 'ph5',
    text: 'Simple Harmonic Motion differential equation x\'\' + ω²x = 0',
    category: 'formula',
    subject: 'physics',
    topic: 'mechanics',
    tags: ['harmonic', 'oscillator', 'vibration']
  },

  // --- Computer Science & Statistics ---
  {
    id: 'cs1',
    text: 'Central Limit Theorem for sample mean convergence',
    category: 'concept',
    subject: 'statistics',
    topic: 'probability',
    tags: ['central', 'limit', 'theorem', 'normal']
  },
  {
    id: 'cs2',
    text: 'Bayes Theorem for conditional probability P(A|B) = P(B|A)P(A)/P(B)',
    category: 'formula',
    subject: 'statistics',
    topic: 'probability',
    tags: ['bayes', 'conditional', 'probability']
  },
  {
    id: 'cs3',
    text: 'Time complexity O(n log n) divide and conquer sorting',
    category: 'term',
    subject: 'computer science',
    topic: 'algorithms',
    tags: ['complexity', 'big-o', 'algorithm']
  },
  {
    id: 'cs4',
    text: 'Dynamic programming recurrence relation and memoization',
    category: 'concept',
    subject: 'computer science',
    topic: 'algorithms',
    tags: ['dynamic', 'programming', 'memoization']
  }
];

export function getPredictiveSuggestions(
  input: string,
  subject?: string,
  topic?: string,
  maxResults = 5
): PredictiveTerm[] {
  const cleanInput = input.trim().toLowerCase();
  const normalizeSubject = (subject || '').toLowerCase();
  const normalizeTopic = (topic || '').toLowerCase();

  // If input is empty, return popular pedagogical starters relevant to subject/topic
  if (!cleanInput) {
    const defaultStarters = PREDICTIVE_DICTIONARY.filter(
      item =>
        item.category === 'phrase' ||
        (item.subject && normalizeSubject.includes(item.subject)) ||
        (item.topic && normalizeTopic.includes(item.topic))
    );
    return defaultStarters.slice(0, maxResults);
  }

  // Get last word or phrase
  const words = cleanInput.split(/\s+/);
  const lastWord = words[words.length - 1] || '';

  // Calculate score for ranking matches
  const scored = PREDICTIVE_DICTIONARY.map(item => {
    const textLower = item.text.toLowerCase();
    let score = 0;

    // Direct startsWith gets highest priority
    if (textLower.startsWith(cleanInput)) {
      score += 100;
    } else if (textLower.includes(cleanInput)) {
      score += 60;
    } else if (lastWord.length >= 2 && textLower.includes(lastWord)) {
      score += 30;
    } else if (item.tags?.some(tag => tag.toLowerCase().startsWith(lastWord))) {
      score += 20;
    }

    // Boost if subject or topic matches
    if (item.subject && normalizeSubject.includes(item.subject)) {
      score += 15;
    }
    if (item.topic && normalizeTopic.includes(item.topic)) {
      score += 10;
    }

    // Exact full match should not be suggested
    if (textLower === cleanInput) {
      score = 0;
    }

    return { item, score };
  });

  return scored
    .filter(s => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .map(s => s.item)
    .slice(0, maxResults);
}
