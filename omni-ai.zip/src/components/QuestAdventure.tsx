import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, 
  Sword, 
  Shield, 
  Award, 
  Trophy, 
  Zap, 
  Heart, 
  Sparkles, 
  Skull, 
  Crown, 
  Play, 
  Lock, 
  Unlock, 
  ArrowRight, 
  RotateCcw, 
  Flame, 
  Brain, 
  CheckCircle2, 
  Volume2, 
  AlertCircle,
  Users,
  UserPlus,
  Gift,
  Link,
  Copy,
  Plus,
  Share2,
  Check,
  BookOpen,
  Timer,
  ChevronRight,
  Coins,
  MessageSquare,
  Clock,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CoopProofQuests } from './CoopProofQuests';

interface Quest {
  id: string;
  title: string;
  subtitle: string;
  story: string;
  xpReward: number;
  badge: string;
  badgeIcon: string;
  status: 'locked' | 'unlocked' | 'active' | 'completed';
  requiredLevel: number;
}

interface Boss {
  name: string;
  title: string;
  maxHp: number;
  currentHp: number;
  image: string;
  element: string;
  ability: string;
}

interface BossRiddle {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  damage: number;
  explanation: string;
}

interface ReferredClassmate {
  id: string;
  name: string;
  code: string;
  status: 'online' | 'offline' | 'studying';
  lastActivity: string;
  tokensEarned: number;
}

interface ArenaPlayer {
  id: string;
  name: string;
  avatar: string;
  score: number;
  isHost: boolean;
  isReady: boolean;
  lastAnswerCorrect?: boolean | null;
}

interface ArenaQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const INITIAL_QUESTS: Quest[] = [
  { 
    id: 'q1', 
    title: 'The Valley of Variables', 
    subtitle: 'Foundation of State & Storage', 
    story: 'Your journey begins in a quiet, mist-covered glen where primordial elements of computing are bound to memory scopes. You must harness primitive declarations and define variables to progress.',
    xpReward: 150, 
    badge: 'Scope Navigator', 
    badgeIcon: '🧭', 
    status: 'unlocked', 
    requiredLevel: 1 
  },
  { 
    id: 'q2', 
    title: 'The Function Fortress', 
    subtitle: 'Control Flow & Call Blocks', 
    story: 'A massive obsidian gate looms ahead, sealed by complex structural loops and conditional spells. Learn the ancient patterns of encapsulation and invoke functions to breach the walls.',
    xpReward: 250, 
    badge: 'Loop Wizard', 
    badgeIcon: '🌀', 
    status: 'locked', 
    requiredLevel: 2 
  },
  { 
    id: 'q3', 
    title: 'The Algorithm Abyss', 
    subtitle: 'Recursion & Time Complexity', 
    story: 'You descend into a swirling quantum vortex where time bends. The path forwards requires understanding call stacks, base cases, and optimal space complexity.',
    xpReward: 400, 
    badge: 'Stack Master', 
    badgeIcon: '⚡', 
    status: 'locked', 
    requiredLevel: 3 
  },
  { 
    id: 'q4', 
    title: 'The Data Dungeon', 
    subtitle: 'Complex Structures & Databases', 
    story: 'Inside the labyrinth of records, pointers and references entangle the unwary. Master structured relational records and search indices to recover the legendary data crystal.',
    xpReward: 600, 
    badge: 'Lattice Overlord', 
    badgeIcon: '💎', 
    status: 'locked', 
    requiredLevel: 4 
  }
];

const BOSSES: Boss[] = [
  {
    name: 'Recursion Dragon',
    title: 'Harbinger of Infinite Call Stacks',
    maxHp: 300,
    currentHp: 300,
    image: '🐉',
    element: 'Recursive Chaos',
    ability: 'Stack Overflow Strike'
  },
  {
    name: 'Quantum Matrix Overlord',
    title: 'The Multi-Dimensional Grid Master',
    maxHp: 400,
    currentHp: 400,
    image: '👾',
    element: 'Dimensional Vectors',
    ability: 'Matrix Coordinate Shatter'
  },
  {
    name: 'Thermodynamic Chimera',
    title: 'Uncontrolled Entropic Fiend',
    maxHp: 500,
    currentHp: 500,
    image: '🦁',
    element: 'Entropic Fire',
    ability: 'Enthalpic Blast'
  }
];

const BOSS_RIDDLES: Record<string, BossRiddle[]> = {
  'Recursion Dragon': [
    {
      id: 1,
      question: 'What happens to a recursive function that completely lacks a base case?',
      options: [
        'It terminates immediately returning undefined', 
        'It triggers an infinite loop leading to a Stack Overflow crash', 
        'It automatically optimizes to run in O(1) time complexity', 
        'It compiles but skips execution'
      ],
      correctIndex: 1,
      damage: 100,
      explanation: 'Without a base case, a recursive function calls itself indefinitely, appending frames to the thread\'s execution call stack until it runs out of memory, throwing a Stack Overflow error.'
    },
    {
      id: 2,
      question: 'In the recurrence relation T(n) = T(n/2) + O(1), what is the total time complexity according to the Master Theorem?',
      options: ['O(n)', 'O(n log n)', 'O(log n)', 'O(1)'],
      correctIndex: 2,
      damage: 100,
      explanation: 'Since the subproblem size is halved at each step with constant work per split, the height of the recursion tree is log n, resulting in a time complexity of O(log n).'
    },
    {
      id: 3,
      question: 'Which data structure is implicitly utilized by the system execution engine to track recursive call frames?',
      options: ['Queue', 'Hash Map', 'Heap', 'Stack'],
      correctIndex: 3,
      damage: 100,
      explanation: 'The system uses a LIFO (Last-In-First-Out) execution Call Stack to push new function frames when called, and pop them when returning values.'
    }
  ],
  'Quantum Matrix Overlord': [
    {
      id: 1,
      question: 'What is the determinant of an identity matrix of dimension n x n?',
      options: ['0', '1', 'n', 'n²'],
      correctIndex: 1,
      damage: 135,
      explanation: 'The determinant of any diagonal matrix, including the identity matrix, is the product of its diagonal elements: 1 * 1 * ... * 1 = 1.'
    },
    {
      id: 2,
      question: 'If vector A is orthogonal to vector B, what is their corresponding dot product?',
      options: ['0', '1', 'Their combined magnitudes', '-1'],
      correctIndex: 0,
      damage: 135,
      explanation: 'Orthogonal vectors have an angle of 90 degrees (π/2 radians) between them. The dot product A · B = |A||B| cos(90°) = |A||B| * 0 = 0.'
    },
    {
      id: 3,
      question: 'Which operation flips a matrix over its diagonal, switching its row indices with its column indices?',
      options: ['Inversion', 'Determinant analysis', 'Transposition', 'Eigenvector normalization'],
      correctIndex: 2,
      damage: 130,
      explanation: 'Transposition swaps rows and columns of a matrix. The element at row i, column j becomes the element at row j, column i.'
    }
  ],
  'Thermodynamic Chimera': [
    {
      id: 1,
      question: 'According to the Second Law of Thermodynamics, what state metric of an isolated system must always increase over time?',
      options: ['Enthalpy (H)', 'Gibbs Free Energy (G)', 'Entropy (S)', 'Internal Energy (U)'],
      correctIndex: 2,
      damage: 170,
      explanation: 'The Second Law of Thermodynamics states that the total entropy (S) of an isolated system can never decrease over time; isolated systems spontaneously evolve toward thermodynamic equilibrium, the state of maximum entropy.'
    },
    {
      id: 2,
      question: 'What is the absolute zero temperature in degrees Celsius?',
      options: ['0 °C', '-273.15 °C', '-100 °C', '-459.67 °C'],
      correctIndex: 1,
      damage: 170,
      explanation: 'Absolute zero, the lower limit of the thermodynamic temperature scale where all thermodynamic motion ceases, is exactly 0 Kelvin, which corresponds to -273.15 °C.'
    },
    {
      id: 3,
      question: 'Which state function is defined as a system\'s internal energy plus the product of its pressure and volume (H = U + PV)?',
      options: ['Enthalpy', 'Entropy', 'Work Done', 'Heat Capacity'],
      correctIndex: 0,
      damage: 160,
      explanation: 'Enthalpy (H) is defined as H = U + PV, capturing the total heat content of a system at constant pressure.'
    }
  ]
};

const ARENA_QUESTIONS: Record<string, ArenaQuestion[]> = {
  'CBSE Board Class XII Prep': [
    {
      question: 'According to Gauss\'s Law, what is the total electric flux through any closed surface enclosing a charge Q?',
      options: ['Q / ε₀', 'Q * ε₀', 'Q / (4πε₀)', '0'],
      correctIndex: 0,
      explanation: 'Gauss\'s Law states that the electric flux through a closed surface is equal to the net charge enclosed divided by the permittivity of free space ε₀.'
    },
    {
      question: 'What is the phase difference between current and voltage in a purely capacitive AC circuit?',
      options: ['Current leads voltage by 90° (π/2)', 'Voltage leads current by 90° (π/2)', 'They are in phase', 'They are 180° out of phase'],
      correctIndex: 0,
      explanation: 'In a purely capacitive circuit, the current leads the alternating voltage by a quarter of a cycle, which corresponds to 90 degrees or π/2 radians.'
    },
    {
      question: 'Which of the following electromagnetic waves has the highest frequency?',
      options: ['Gamma Rays', 'X-Rays', 'Ultraviolet Rays', 'Infrared Rays'],
      correctIndex: 0,
      explanation: 'In the electromagnetic spectrum, Gamma Rays have the shortest wavelength and the highest frequency (and energy).'
    }
  ],
  'JNU Entrance General Aptitude': [
    {
      question: 'In a certain code language, "KINETIC" is written as "TICDKIN". How would "DYNAMIC" be written in that code?',
      options: ['MICWDYN', 'MICDYNW', 'YNDWCMI', 'MIDCYNW'],
      correctIndex: 0,
      explanation: 'Split the word into two parts: "DYNA" and "MIC". Reversing certain halves and shifting letters gives "MICWDYN" as the mathematically derived code.'
    },
    {
      question: 'A train 120 meters long passes a telegraph post in 6 seconds. What is the speed of the train in km/h?',
      options: ['72 km/h', '60 km/h', '80 km/h', '90 km/h'],
      correctIndex: 0,
      explanation: 'Speed = Distance / Time = 120m / 6s = 20 m/s. To convert to km/h: 20 * (18/5) = 72 km/h.'
    },
    {
      question: 'Complete the sequence: 3, 5, 9, 17, 33, ...',
      options: ['65', '45', '50', '60'],
      correctIndex: 0,
      explanation: 'The difference between consecutive terms doubles each time: +2, +4, +8, +16. The next increment is +32, so 33 + 32 = 65.'
    }
  ],
  'JEE Mains Math Combat': [
    {
      question: 'If the roots of the equation x² - px + q = 0 differ by unity, then which of the following is true?',
      options: ['p² = 4q + 1', 'p² = 4q - 1', 'q² = 4p + 1', 'q² = 4p - 1'],
      correctIndex: 0,
      explanation: 'Let roots be α and β. |α - β| = 1. (α - β)² = (α + β)² - 4αβ = 1. Since sum of roots is p and product is q, we get p² - 4q = 1, so p² = 4q + 1.'
    },
    {
      question: 'The value of lim (x -> 0) [sin(x) / x] is equal to:',
      options: ['1', '0', 'Does not exist', 'Infinity'],
      correctIndex: 0,
      explanation: 'This is a standard fundamental calculus limit, which evaluates to exactly 1 using L\'Hôpital\'s Rule or Squeeze Theorem.'
    },
    {
      question: 'Find the number of ways to arrange the letters of the word "MATRIX" so that vowels never come together.',
      options: ['480', '240', '120', '720'],
      correctIndex: 0,
      explanation: 'Total letters = 6. Vowels = A, I (2). Consonants = M, T, R, X (4). Arrange consonants first: 4! = 24. There are 5 gaps around them. Place vowels in 5 gaps: 5P2 = 5 * 4 = 20. Total arrangements = 24 * 20 = 480.'
    }
  ],
  'NEET Physics Speedrun': [
    {
      question: 'A particle is moving in a circular path of radius r. The displacement after half a circle would be:',
      options: ['2r', 'πr', '0', '2πr'],
      correctIndex: 0,
      explanation: 'Half a circle starting from point A ends at the opposite end of the diameter B. The straight-line distance is the diameter, which is 2r.'
    },
    {
      question: 'Which law states that the total current entering a junction is equal to the total current leaving the junction?',
      options: ['Kirchhoff\'s Current Law (KCL)', 'Kirchhoff\'s Voltage Law (KVL)', 'Ohm\'s Law', 'Lenz\'s Law'],
      correctIndex: 0,
      explanation: 'Kirchhoff\'s First Law or Junction Rule (KCL) is based on the conservation of electric charge.'
    },
    {
      question: 'The terminal velocity of a small spherical ball falling through a viscous liquid is proportional to:',
      options: ['Square of the radius (r²)', 'Radius (r)', 'Reciprocal of radius (1/r)', 'Cube of the radius (r³)'],
      correctIndex: 0,
      explanation: 'By Stokes\' law, terminal velocity is directly proportional to r² (square of the radius of the falling sphere).'
    }
  ]
};

const SIMULATED_CLASSMATES = ['Rohan Sharma', 'Priya Nair', 'Sneha Kapoor', 'Amit Mehra', 'Vikram Sen'];

export const QuestAdventure: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  // Navigation tabs: 'quests' (Quests & Bosses), 'referrals' (Referrals), 'arenas' (Study Arenas), 'coop_proofs' (Cooperative Proofs)
  const [activeTab, setActiveTab] = useState<'quests' | 'referrals' | 'arenas' | 'coop_proofs'>('quests');

  // Gamified User Progression state (Persisted in localStorage)
  const [userLevel, setUserLevel] = useState<number>(() => {
    return parseInt(localStorage.getItem('omni_rpg_level') || '1', 10);
  });
  const [userXp, setUserXp] = useState<number>(() => {
    return parseInt(localStorage.getItem('omni_rpg_xp') || '50', 10);
  });
  const [earnedBadges, setEarnedBadges] = useState<{ name: string; icon: string }[]>(() => {
    try {
      const saved = localStorage.getItem('omni_rpg_badges');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse rpg badges', e);
    }
    return [{ name: 'Apprentice Scholar', icon: '🎓' }];
  });
  const [quests, setQuests] = useState<Quest[]>(() => {
    try {
      const saved = localStorage.getItem('omni_rpg_quests');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse rpg quests', e);
    }
    return INITIAL_QUESTS;
  });

  // Learning Tokens Balance
  const [tokens, setTokens] = useState<number>(() => {
    return parseInt(localStorage.getItem('omni_rpg_tokens') || '250', 10);
  });

  // Referral states
  const [referralCode] = useState<string>(() => {
    return localStorage.getItem('omni_rpg_ref_code') || `OMNI-REF-${Math.random().toString(36).substring(3, 8).toUpperCase()}`;
  });
  const [inputReferralCode, setInputReferralCode] = useState<string>('');
  const [referralMultiplierActive, setReferralMultiplierActive] = useState<boolean>(() => {
    return localStorage.getItem('omni_rpg_ref_active') === 'true';
  });
  const [referredClassmates, setReferredClassmates] = useState<ReferredClassmate[]>(() => {
    try {
      const saved = localStorage.getItem('omni_rpg_referred_list');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse referred classmates', e);
    }
    return [
      { id: 'ref_1', name: 'Rohan Sharma', code: 'OMNI-REF-ROH49', status: 'studying', lastActivity: 'Solving Practice Tests', tokensEarned: 150 },
      { id: 'ref_2', name: 'Priya Nair', code: 'OMNI-REF-PRI90', status: 'online', lastActivity: 'Watching circular motion video', tokensEarned: 80 }
    ];
  });
  const [referralEvents, setReferralEvents] = useState<string[]>(() => {
    return [
      '🎉 Rohan Sharma used your referral link and linked accounts! (+50 🪙 Bonus)',
      '🎉 Priya Nair linked accounts via your invite code! (+50 🪙 Bonus)'
    ];
  });
  const [referralSuccessMsg, setReferralSuccessMsg] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // Multiplayer Study Arena states
  const [selectedArenaExam, setSelectedArenaExam] = useState<string>('CBSE Board Class XII Prep');
  const [arenaDifficulty, setArenaDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [arenaState, setArenaState] = useState<'setup' | 'lobby' | 'combat' | 'podium'>('setup');
  const [arenaInviteCode, setArenaInviteCode] = useState<string>('');
  const [arenaPlayers, setArenaPlayers] = useState<ArenaPlayer[]>([]);
  const [arenaQuestions, setArenaQuestions] = useState<ArenaQuestion[]>([]);
  const [currentArenaQuestionIdx, setCurrentArenaQuestionIdx] = useState<number>(0);
  const [arenaSelectedAnswer, setArenaSelectedAnswer] = useState<number | null>(null);
  const [arenaTimer, setArenaTimer] = useState<number>(15);
  const [arenaLogs, setArenaLogs] = useState<string[]>([]);
  const [hasAnsweredArenaQuestion, setHasAnsweredArenaQuestion] = useState<boolean>(false);
  const [arenaWinner, setArenaWinner] = useState<string | null>(null);

  // Boss Battle state
  const [battleActive, setBattleActive] = useState<boolean>(false);
  const [currentBoss, setCurrentBoss] = useState<Boss | null>(null);
  const [riddles, setRiddles] = useState<BossRiddle[]>([]);
  const [currentRiddleIdx, setCurrentRiddleIdx] = useState<number>(0);
  const [selectedRiddleAns, setSelectedRiddleAns] = useState<number | null>(null);
  const [battleLog, setBattleLog] = useState<string[]>([]);
  const [playerHp, setPlayerHp] = useState<number>(100);
  const [bossHp, setBossHp] = useState<number>(300);
  const [showRiddleExplanation, setShowRiddleExplanation] = useState<boolean>(false);
  const [battleOutcome, setBattleOutcome] = useState<'victory' | 'defeat' | null>(null);

  // Synchronize gamification values to localStorage
  useEffect(() => {
    localStorage.setItem('omni_rpg_level', userLevel.toString());
    localStorage.setItem('omni_rpg_xp', userXp.toString());
    localStorage.setItem('omni_rpg_badges', JSON.stringify(earnedBadges));
    localStorage.setItem('omni_rpg_quests', JSON.stringify(quests));
    localStorage.setItem('omni_rpg_tokens', tokens.toString());
    localStorage.setItem('omni_rpg_ref_code', referralCode);
    localStorage.setItem('omni_rpg_ref_active', referralMultiplierActive ? 'true' : 'false');
    localStorage.setItem('omni_rpg_referred_list', JSON.stringify(referredClassmates));
  }, [userLevel, userXp, earnedBadges, quests, tokens, referralMultiplierActive, referredClassmates]);

  // XP progression config
  const xpNeeded = userLevel * 250;

  // Handle Leveling Up & Rewards logic
  const addXp = (xpAmount: number, badgeOption?: { name: string; icon: string }, tokenBonus: number = 50) => {
    const mult = referralMultiplierActive ? 2 : 1;
    const finalXp = xpAmount * mult;
    const finalTokens = tokenBonus * mult;

    setTokens(prev => prev + finalTokens);

    setUserXp(prev => {
      let newXp = prev + finalXp;
      let level = userLevel;
      let needed = level * 250;

      while (newXp >= needed) {
        newXp -= needed;
        level += 1;
        needed = level * 250;
      }

      setUserLevel(level);

      // Automatically unlock adjacent quests depending on level
      setQuests(curr => curr.map(q => {
        if (q.status === 'locked' && level >= q.requiredLevel) {
          return { ...q, status: 'unlocked' };
        }
        return q;
      }));

      return newXp;
    });

    if (badgeOption) {
      setEarnedBadges(curr => {
        if (curr.some(b => b.name === badgeOption.name)) return curr;
        return [...curr, badgeOption];
      });
    }

    // Custom browser notifications using native alerts or simple banners
    return { finalXp, finalTokens };
  };

  // Launch story quest progression
  const handleLaunchQuest = (quest: Quest) => {
    setQuests(curr => curr.map(q => {
      if (q.id === quest.id) {
        return { ...q, status: 'completed' };
      }
      return q;
    }));

    const reward = addXp(quest.xpReward, { name: quest.badge, icon: quest.badgeIcon }, quest.xpReward);
    
    // Add referral stream activity if applicable
    if (referralMultiplierActive) {
      const classmates = ['Rohan Sharma', 'Priya Nair'];
      const chosenClassmate = classmates[Math.floor(Math.random() * classmates.length)];
      setReferralEvents(prev => [
        `🔥 2x Active: Finished quest "${quest.title}" and classmate ${chosenClassmate} is online! Both got bonus tokens!`,
        ...prev
      ]);
    }
  };

  // Boss Encounter Launch
  const handleInitiateBossBattle = (boss: Boss) => {
    setCurrentBoss({ ...boss });
    setBossHp(boss.maxHp);
    setPlayerHp(100);
    setRiddles(BOSS_RIDDLES[boss.name] || []);
    setCurrentRiddleIdx(0);
    setSelectedRiddleAns(null);
    setShowRiddleExplanation(false);
    setBattleOutcome(null);
    setBattleLog([
      `⚔️ Battle Initiated! ${boss.name} (${boss.title}) appears!`,
      `🛡️ Prepare yourself, champion. Solve the multi-layered concept riddles to strike!`
    ]);
    setBattleActive(true);
  };

  const handleRiddleAnswer = (optIndex: number) => {
    if (selectedRiddleAns !== null) return;
    setSelectedRiddleAns(optIndex);
    setShowRiddleExplanation(true);

    const activeRiddle = riddles[currentRiddleIdx];
    const isCorrect = optIndex === activeRiddle.correctIndex;

    if (isCorrect) {
      const updatedBossHp = Math.max(0, bossHp - activeRiddle.damage);
      setBossHp(updatedBossHp);
      setBattleLog(prev => [
        `💥 Correct Answer! You strike ${currentBoss?.name} with conceptual clarity for ${activeRiddle.damage} DMG!`,
        ...prev
      ]);

      if (updatedBossHp <= 0) {
        setBattleOutcome('victory');
        setBattleLog(prev => [
          `🏆 VICTORY! You have vanquished the ${currentBoss?.name}!`,
          ...prev
        ]);
        // Reward big victory XP and Tokens
        addXp(450, { name: `${currentBoss?.name} Vanquisher`, icon: '🏆' }, 300);
      }
    } else {
      const damageTaken = 35;
      const updatedPlayerHp = Math.max(0, playerHp - damageTaken);
      setPlayerHp(updatedPlayerHp);
      setBattleLog(prev => [
        `❌ Incorrect Answer! ${currentBoss?.name} counterattacks with ${currentBoss?.ability} for ${damageTaken} DMG!`,
        ...prev
      ]);

      if (updatedPlayerHp <= 0) {
        setBattleOutcome('defeat');
        setBattleLog(prev => [
          `💀 DEFEAT! Your synaptic call stack was completely overwhelmed...`,
          ...prev
        ]);
      }
    }
  };

  const handleNextBattleStep = () => {
    if (battleOutcome) {
      setBattleActive(false);
      setCurrentBoss(null);
    } else {
      setSelectedRiddleAns(null);
      setShowRiddleExplanation(false);
      setCurrentRiddleIdx(prev => (prev + 1) % riddles.length);
    }
  };

  const handleResetAdventure = () => {
    setUserLevel(1);
    setUserXp(50);
    setEarnedBadges([{ name: 'Apprentice Scholar', icon: '🎓' }]);
    setQuests(INITIAL_QUESTS);
    setTokens(250);
    setReferralMultiplierActive(false);
    setBattleActive(false);
    setCurrentBoss(null);
    setReferredClassmates([
      { id: 'ref_1', name: 'Rohan Sharma', code: 'OMNI-REF-ROH49', status: 'studying', lastActivity: 'Solving Practice Tests', tokensEarned: 150 },
      { id: 'ref_2', name: 'Priya Nair', code: 'OMNI-REF-PRI90', status: 'online', lastActivity: 'Watching circular motion video', tokensEarned: 80 }
    ]);
    setReferralEvents([
      '🎉 Rohan Sharma used your referral link and linked accounts! (+50 🪙 Bonus)',
      '🎉 Priya Nair linked accounts via your invite code! (+50 🪙 Bonus)'
    ]);
  };

  // Referral functionality
  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleLinkReferral = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputReferralCode.trim()) return;
    
    // Simulate real database linking
    setReferralMultiplierActive(true);
    setTokens(prev => prev + 150); // Welcome tokens
    
    // Add to classmate roster
    const newClassmate: ReferredClassmate = {
      id: `ref_${Date.now()}`,
      name: SIMULATED_CLASSMATES[Math.floor(Math.random() * SIMULATED_CLASSMATES.length)],
      code: inputReferralCode.toUpperCase(),
      status: 'studying',
      lastActivity: 'Joined your study alliance',
      tokensEarned: 150
    };

    setReferredClassmates(prev => [newClassmate, ...prev]);
    setReferralEvents(prev => [
      `🔥 Connected with classmate via code ${inputReferralCode.toUpperCase()}! 2x multiplier active! (+150 🪙 Linked Bonus)`,
      ...prev
    ]);
    
    setReferralSuccessMsg(`Classmate code applied! Your study alliance is now locked with a permanent 2x multiplier!`);
    setInputReferralCode('');
    setTimeout(() => setReferralSuccessMsg(null), 5000);
  };

  // Simulate peer study event to earn coins on referrals
  const handleSimulateClassmateEvent = () => {
    const classmate = referredClassmates[Math.floor(Math.random() * referredClassmates.length)];
    if (!classmate) return;

    const studyActivities = [
      { act: 'solved the JNU Entrance Math speedrun', points: 100 },
      { act: 'finished the Chapter 2 Physics whiteboard lecture', points: 80 },
      { act: 'defeated the Recursion Dragon concept boss', points: 200 },
      { act: 'completed a CBSE preparation chemistry module', points: 120 }
    ];

    const chosenAct = studyActivities[Math.floor(Math.random() * studyActivities.length)];
    const userEarned = referralMultiplierActive ? chosenAct.points * 2 : chosenAct.points;
    const peerEarned = chosenAct.points;

    setTokens(prev => prev + userEarned);
    
    // Update classmate's record
    setReferredClassmates(prev => prev.map(c => {
      if (c.id === classmate.id) {
        return {
          ...c,
          status: 'studying',
          lastActivity: chosenAct.act,
          tokensEarned: c.tokensEarned + peerEarned
        };
      }
      return c;
    }));

    setReferralEvents(prev => [
      `⚡ Classmate ${classmate.name} ${chosenAct.act}! Rohan earned +${peerEarned} 🪙. You got the +${userEarned} 🪙 referral match!`,
      ...prev
    ]);
  };

  // Multiplayer Study Arena functionality
  const handleCreateArena = () => {
    const code = `OMNI-ARENA-${Math.random().toString(36).substring(3, 8).toUpperCase()}`;
    setArenaInviteCode(code);
    setArenaState('lobby');
    setArenaLogs([`🏟️ Study Arena lobby "${code}" is open! Waiting for players to join...`]);

    const initialHost: ArenaPlayer = {
      id: 'host_player',
      name: 'You (Learner)',
      avatar: '👑',
      score: 0,
      isHost: true,
      isReady: true
    };
    setArenaPlayers([initialHost]);

    // Simulate other classmates joining over a 1-3s interval
    setTimeout(() => {
      setArenaPlayers(prev => [
        ...prev,
        { id: 'player_1', name: 'Aarav (CBSE aspirant)', avatar: '🎓', score: 0, isHost: false, isReady: true }
      ]);
      setArenaLogs(prev => [...prev, `🎓 Aarav connected to study group.`]);
    }, 1000);

    setTimeout(() => {
      setArenaPlayers(prev => [
        ...prev,
        { id: 'player_2', name: 'Meera (JNU Prep)', avatar: '⚡', score: 0, isHost: false, isReady: true }
      ]);
      setArenaLogs(prev => [...prev, `⚡ Meera connected to study group.`]);
    }, 2000);

    setTimeout(() => {
      setArenaPlayers(prev => [
        ...prev,
        { id: 'player_3', name: 'Rohan Sharma', avatar: '🧙', score: 0, isHost: false, isReady: true }
      ]);
      setArenaLogs(prev => [...prev, `🧙 Rohan Sharma connected via invite link.`]);
    }, 3200);
  };

  const handleStartArenaCombat = () => {
    const qList = ARENA_QUESTIONS[selectedArenaExam] || ARENA_QUESTIONS['CBSE Board Class XII Prep'];
    setArenaQuestions(qList);
    setCurrentArenaQuestionIdx(0);
    setArenaSelectedAnswer(null);
    setHasAnsweredArenaQuestion(false);
    setArenaTimer(15);
    setArenaState('combat');
    setArenaLogs(prev => [
      ...prev,
      `🔥 Quiz tournament started! 15 seconds per question. Solve carefully!`
    ]);
  };

  // Process selected answer in multiplayer arena
  const handleSelectArenaAnswer = (optIndex: number) => {
    if (hasAnsweredArenaQuestion) return;
    setArenaSelectedAnswer(optIndex);
    setHasAnsweredArenaQuestion(true);

    const questionObj = arenaQuestions[currentArenaQuestionIdx];
    const isCorrect = optIndex === questionObj.correctIndex;
    const basePoints = isCorrect ? 150 : 0;

    // Simulate other classmates answering
    setArenaPlayers(prev => prev.map(player => {
      if (player.id === 'host_player') {
        return {
          ...player,
          score: player.score + basePoints,
          lastAnswerCorrect: isCorrect
        };
      } else {
        // Simulated classmates get 60% probability of answering correctly
        const classmateCorrect = Math.random() > 0.4;
        return {
          ...player,
          score: player.score + (classmateCorrect ? 120 : 0),
          lastAnswerCorrect: classmateCorrect
        };
      }
    }));

    setArenaLogs(prev => [
      ...prev,
      isCorrect ? `✨ You got Question ${currentArenaQuestionIdx + 1} right! (+150 pts)` : `❌ Incorrect answer. Keep focus!`
    ]);
  };

  // Progression through multiplayer questions
  const handleNextArenaQuestion = () => {
    if (currentArenaQuestionIdx + 1 < arenaQuestions.length) {
      setCurrentArenaQuestionIdx(prev => prev + 1);
      setArenaSelectedAnswer(null);
      setHasAnsweredArenaQuestion(false);
      setArenaTimer(15);
    } else {
      // Determine winner
      let highestScore = -1;
      let winnerName = 'You (Learner)';
      
      arenaPlayers.forEach(p => {
        if (p.score > highestScore) {
          highestScore = p.score;
          winnerName = p.name;
        }
      });

      setArenaWinner(winnerName);
      setArenaState('podium');

      // Distribute learning tokens reward
      const basePrize = winnerName.includes('You') ? 400 : 150;
      const bonusPrize = referralMultiplierActive ? basePrize * 2 : basePrize;
      setTokens(prev => prev + bonusPrize);
      addXp(winnerName.includes('You') ? 200 : 100, { name: 'Arena gladiator', icon: '🏟️' }, 0);
    }
  };

  return (
    <div id="quest-rpg-root" className="flex flex-col h-full overflow-y-auto pr-1">
      {/* RPG User Header Card */}
      <div id="rpg-user-header" className="p-5 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 mb-4 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        
        {/* Level and XP progress bar (Col 4) */}
        <div className="md:col-span-4 flex items-center gap-3.5">
          <div className="w-12 h-12 bg-indigo-600 dark:bg-indigo-700/80 rounded-2xl flex flex-col items-center justify-center text-white font-black shadow-lg">
            <span className="text-[9px] uppercase tracking-widest leading-none opacity-85">LVL</span>
            <span className="text-xl leading-none">{userLevel}</span>
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-center text-xs font-bold mb-1.5">
              <span className="text-slate-800 dark:text-slate-200 flex items-center gap-1">
                <Flame size={14} className="text-amber-500 animate-pulse" />
                Experience Score (XP)
              </span>
              <span className="font-mono text-indigo-500">{userXp} / {xpNeeded} XP</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-indigo-600 transition-all duration-300 rounded-full"
                style={{ width: `${(userXp / xpNeeded) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Tokens & Multiplier Showcase (Col 4) */}
        <div className="md:col-span-4 border-t md:border-t-0 md:border-x border-slate-200 dark:border-slate-800 py-3 md:py-0 px-0 md:px-4 flex items-center justify-between">
          <div className="text-left">
            <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 flex items-center gap-1">
              <Coins size={12} className="text-amber-500" />
              Learning Tokens
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black text-amber-500 dark:text-amber-400 flex items-center gap-1 drop-shadow-sm">
                🪙 {tokens}
              </span>
              <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                OMNI-COINS
              </span>
            </div>
          </div>

          <div className="flex flex-col items-end">
            <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider flex items-center gap-1 ${
              referralMultiplierActive 
                ? 'bg-gradient-to-r from-red-500 to-orange-500 text-white animate-pulse' 
                : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
            }`}>
              {referralMultiplierActive ? (
                <>
                  <Zap size={10} className="fill-white" />
                  2x Multiplier Active
                </>
              ) : (
                <>
                  <Lock size={10} />
                  1x Rate
                </>
              )}
            </span>
            <span className="text-[8px] text-slate-400 font-bold mt-1 uppercase tracking-widest">
              Study Alliance Rate
            </span>
          </div>
        </div>

        {/* Earned Badges Showcase (Col 2) */}
        <div className="md:col-span-2 border-t md:border-t-0 pt-3 md:pt-0">
          <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1 flex items-center gap-1">
            <Trophy size={11} className="text-amber-400" />
            Badges
          </div>
          <div id="badges-scroller" className="flex gap-1 overflow-x-auto pb-1 max-w-[120px]">
            {earnedBadges.map((badge, idx) => (
              <span
                key={idx}
                className="px-1.5 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800/40 text-[9px] font-bold flex items-center gap-1 shrink-0"
                title={badge.name}
              >
                <span>{badge.icon}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Action controls (Col 2) */}
        <div className="md:col-span-2 flex justify-end">
          <button
            id="btn-rpg-reset"
            onClick={handleResetAdventure}
            className="px-3 py-2 text-[10px] font-extrabold text-slate-400 hover:text-indigo-500 border border-slate-200 dark:border-slate-800 hover:border-indigo-500 rounded-xl transition-all cursor-pointer flex items-center gap-1 bg-white dark:bg-slate-850"
            title="Wipe levels & coins to start over"
          >
            <RotateCcw size={11} /> Reset RPG
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs Bar */}
      <div className="flex bg-slate-100 dark:bg-slate-950/60 p-1 rounded-xl border border-slate-200 dark:border-slate-850 mb-4 self-start scale-95 sm:scale-100">
        <button
          onClick={() => {
            setActiveTab('quests');
            setBattleActive(false);
          }}
          className={`px-4 py-2 text-[10px] font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'quests' 
              ? 'bg-indigo-600 text-white shadow-md' 
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          <Gamepad2 size={13} />
          🗺️ Quest Map & Bosses
        </button>
        <button
          onClick={() => {
            setActiveTab('referrals');
            setBattleActive(false);
          }}
          className={`px-4 py-2 text-[10px] font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'referrals' 
              ? 'bg-indigo-600 text-white shadow-md' 
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          <Users size={13} />
          🤝 Classmate Referrals
        </button>
        <button
          onClick={() => {
            setActiveTab('arenas');
            setBattleActive(false);
          }}
          className={`px-4 py-2 text-[10px] font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'arenas' 
              ? 'bg-indigo-600 text-white shadow-md' 
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          <Trophy size={13} />
          🏟️ Study Arenas
        </button>
        <button
          onClick={() => {
            setActiveTab('coop_proofs');
            setBattleActive(false);
          }}
          className={`px-4 py-2 text-[10px] font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'coop_proofs' 
              ? 'bg-indigo-600 text-white shadow-md' 
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
          }`}
        >
          <Sparkles size={13} />
          🤝 Coop Proofs
        </button>
      </div>

      {/* Main Tab Routing */}
      {activeTab === 'quests' && (
        <>
          {!battleActive ? (
            <div id="quest-main-panels" className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in fade-in duration-300">
              
              {/* Left panel: Quest Adventure Map (Col 7) */}
              <div className="lg:col-span-7 flex flex-col gap-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                  <div className="mb-4">
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Gamepad2 size={15} className="text-indigo-500" />
                      Academic Quest Line
                    </h3>
                    <p className="text-[10px] text-slate-500 mt-0.5">Progress through sequential learning chapters and defeat conceptual milestones to gain levels</p>
                  </div>

                  {/* Sequential Quest line layout */}
                  <div id="quest-timeline" className="flex flex-col gap-4 relative pl-4 border-l border-slate-200 dark:border-slate-800">
                    {quests.map((quest, index) => {
                      const isLocked = quest.status === 'locked';
                      const isCompleted = quest.status === 'completed';

                      return (
                        <div 
                          id={`quest-node-${quest.id}`}
                          key={quest.id} 
                          className="relative"
                        >
                          {/* Timeline indicator node */}
                          <span className={`absolute -left-[25px] top-1.5 w-4.5 h-4.5 rounded-full border-2 flex items-center justify-center text-[8px] z-10 ${
                            isCompleted 
                              ? 'bg-emerald-500 border-emerald-600 text-white' 
                              : isLocked 
                                ? 'bg-slate-200 dark:bg-slate-800 border-slate-300 text-slate-400' 
                                : 'bg-indigo-600 border-indigo-700 text-white animate-pulse'
                          }`}>
                            {isCompleted ? '✓' : index + 1}
                          </span>

                          {/* Content Card */}
                          <div className={`p-4 rounded-xl border transition-all ${
                            isCompleted 
                              ? 'bg-emerald-50/20 dark:bg-emerald-950/10 border-emerald-500/25' 
                              : isLocked 
                                ? 'bg-slate-100/40 dark:bg-slate-900/40 border-slate-200/50 dark:border-slate-800/40 opacity-60' 
                                : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-800 shadow-sm'
                          }`}>
                            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 mb-2">
                              <div>
                                <div className="flex items-center gap-2">
                                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">{quest.title}</h4>
                                  <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${
                                    isCompleted 
                                      ? 'bg-emerald-500/15 text-emerald-500' 
                                      : isLocked 
                                        ? 'bg-slate-200 dark:bg-slate-800 text-slate-500' 
                                        : 'bg-indigo-500/15 text-indigo-500 border border-indigo-500/20'
                                  }`}>
                                    {isCompleted ? 'Completed' : isLocked ? `Unlocks Level ${quest.requiredLevel}` : 'Active Quest'}
                                  </span>
                                </div>
                                <span className="text-[10px] text-slate-400 font-extrabold block">{quest.subtitle}</span>
                              </div>

                              {/* Rewards tag */}
                              <div className="flex items-center gap-1.5 text-[10px]">
                                <span className="text-indigo-500 font-black flex items-center gap-0.5" title="XP Reward">
                                  <Zap size={11} /> +{referralMultiplierActive ? quest.xpReward * 2 : quest.xpReward} XP
                                </span>
                                <span className="text-amber-500 font-bold flex items-center gap-0.5" title="Tokens Reward">
                                  🪙 +{referralMultiplierActive ? quest.xpReward * 2 : quest.xpReward}
                                </span>
                              </div>
                            </div>

                            <p className="text-[10px] text-slate-500 leading-relaxed mb-3">
                              {quest.story}
                            </p>

                            {/* Interactive CTAs */}
                            <div className="flex justify-end">
                              <button
                                id={`btn-quest-action-${quest.id}`}
                                disabled={isLocked || isCompleted}
                                onClick={() => handleLaunchQuest(quest)}
                                className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider flex items-center gap-1 transition-all cursor-pointer ${
                                  isCompleted 
                                    ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/10 cursor-not-allowed' 
                                    : isLocked 
                                      ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed border border-transparent' 
                                      : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow hover:shadow-md'
                                }`}
                              >
                                {isCompleted ? (
                                  <>
                                    <CheckCircle2 size={11} /> Done
                                  </>
                                ) : isLocked ? (
                                  <>
                                    <Lock size={11} /> Locked
                                  </>
                                ) : (
                                  <>
                                    <Play size={11} /> Complete Lesson Quest
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Right panel: AI Concept Bosses (Col 5) */}
              <div className="lg:col-span-5 flex flex-col gap-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                  <div className="mb-4">
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Skull size={15} className="text-red-500 animate-pulse" />
                      AI Concept Bosses
                    </h3>
                    <p className="text-[10px] text-slate-500 mt-0.5">Encounter ultimate diagnostic beasts. Victory grants heavy rewards & legendary honor badges</p>
                  </div>

                  {/* Bosses list */}
                  <div className="flex flex-col gap-3">
                    {BOSSES.map((boss, idx) => {
                      const requiredQuestLvl = idx + 1;
                      const isAvailable = userLevel >= requiredQuestLvl;

                      return (
                        <div 
                          id={`boss-card-${idx}`}
                          key={idx} 
                          className={`p-3.5 rounded-xl border transition-all ${
                            isAvailable 
                              ? 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-800 hover:border-red-500/40' 
                              : 'bg-slate-100/40 dark:bg-slate-900/40 border-slate-200/40 dark:border-slate-800/20 opacity-50'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-3xl filter drop-shadow animate-bounce" style={{ animationDuration: `${2.5 + idx}s` }}>
                              {boss.image}
                            </span>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="text-xs font-black text-slate-800 dark:text-slate-100">{boss.name}</h4>
                                <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest bg-red-500/10 text-red-500 border border-red-500/15 uppercase">
                                  HP: {boss.maxHp}
                                </span>
                              </div>
                              <span className="text-[9px] text-slate-400 font-extrabold block truncate">{boss.title}</span>
                              <span className="text-[9px] text-slate-500 mt-1 block">Weapon: {boss.ability}</span>
                            </div>
                          </div>

                          {/* Interactive battle action */}
                          <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-150 dark:border-slate-800">
                            <span className="text-[9px] text-slate-400 font-extrabold uppercase">
                              {isAvailable ? 'READY FOR COMBAT' : `REQUIRES LEVEL ${requiredQuestLvl}`}
                            </span>
                            
                            <button
                              id={`btn-battle-boss-${idx}`}
                              disabled={!isAvailable}
                              onClick={() => handleInitiateBossBattle(boss)}
                              className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all ${
                                isAvailable 
                                  ? 'bg-red-600 hover:bg-red-500 text-white shadow hover:shadow-red-500/20' 
                                  : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                              }`}
                            >
                              <Sword size={11} /> Battle Boss
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

            </div>
          ) : (
            /* Boss Battle Arena Layout overlay (Replacing standard panels) */
            <div id="battle-arena" className="p-4 bg-slate-950 text-white rounded-2xl border border-red-500/30 grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in zoom-in-95 duration-300 text-left">
              
              {/* Header Combatants display (Col 12) */}
              <div className="lg:col-span-12 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                {/* Player Stats */}
                <div className="flex items-center gap-3 w-full md:w-auto">
                  <div className="w-10 h-10 bg-indigo-900 rounded-full flex items-center justify-center text-xl border-2 border-indigo-500">
                    👤
                  </div>
                  <div className="flex-1 md:w-48">
                    <div className="flex justify-between items-center text-xs font-bold mb-1">
                      <span>Student (Player)</span>
                      <span className="font-mono text-red-400">{playerHp} / 100 HP</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-red-500 transition-all duration-300" 
                        style={{ width: `${playerHp}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Combat VS logo badge */}
                <div className="px-3 py-1.5 rounded bg-red-600 text-white font-black text-xs tracking-widest uppercase">
                  VS
                </div>

                {/* Boss Stats */}
                <div className="flex items-center gap-3 w-full md:w-auto text-right md:text-left justify-end">
                  <div className="flex-1 md:w-48">
                    <div className="flex justify-between items-center text-xs font-bold mb-1">
                      <span>{currentBoss?.name}</span>
                      <span className="font-mono text-red-400">{bossHp} / {currentBoss?.maxHp} HP</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-red-500 transition-all duration-300" 
                        style={{ width: `${(bossHp / (currentBoss?.maxHp || 300)) * 100}%` }}
                      />
                    </div>
                  </div>
                  <div className="w-10 h-10 bg-red-950 rounded-full flex items-center justify-center text-xl border-2 border-red-500">
                    {currentBoss?.image}
                  </div>
                </div>
              </div>

              {/* Interactive Riddle Combat Area (Col 8) */}
              <div className="lg:col-span-8 flex flex-col gap-4">
                {battleOutcome === null ? (
                  <div className="p-4 bg-slate-900/40 rounded-xl border border-slate-800">
                    <div className="flex justify-between items-center mb-3 text-[10px] text-slate-500 font-black">
                      <span>CONCEPT ATTACK STRIKE {currentRiddleIdx + 1}</span>
                      <span className="text-red-500 uppercase tracking-widest">Type: {currentBoss?.element}</span>
                    </div>

                    <h3 className="font-bold text-sm text-slate-100 mb-4 leading-relaxed">
                      {riddles[currentRiddleIdx]?.question}
                    </h3>

                    <div className="flex flex-col gap-2 mb-4">
                      {riddles[currentRiddleIdx]?.options.map((opt, oIdx) => {
                        const isSelected = selectedRiddleAns === oIdx;
                        const isCorrect = oIdx === riddles[currentRiddleIdx].correctIndex;
                        const hasAnswered = selectedRiddleAns !== null;

                        return (
                          <button
                            id={`battle-option-${oIdx}`}
                            key={oIdx}
                            disabled={hasAnswered}
                            onClick={() => handleRiddleAnswer(oIdx)}
                            className={`p-3 rounded-xl border text-left text-xs font-bold transition-all ${
                              hasAnswered
                                ? isCorrect
                                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                                  : isSelected
                                    ? 'bg-red-500/20 border-red-500 text-red-400'
                                    : 'bg-slate-900 border-slate-800 opacity-40'
                                : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 hover:border-red-500/50 cursor-pointer'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span className={`w-5 h-5 rounded flex items-center justify-center font-mono font-bold text-[10px] ${
                                hasAnswered
                                  ? isCorrect
                                    ? 'bg-emerald-500 text-white'
                                    : isSelected
                                      ? 'bg-red-500 text-white'
                                      : 'bg-slate-850 text-slate-400'
                                  : 'bg-slate-800 text-slate-400'
                              }`}>
                                {String.fromCharCode(65 + oIdx)}
                              </span>
                              <span>{opt}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {/* Riddle feedback / explanation details */}
                    {showRiddleExplanation && (
                      <div className="p-3 bg-red-500/5 border border-red-500/10 rounded-xl mb-4 text-xs leading-relaxed text-slate-300">
                        <span className="font-black text-red-400 block mb-1">🔍 CONCEPT MECHANICS</span>
                        {riddles[currentRiddleIdx]?.explanation}
                      </div>
                    )}

                    {/* Continue / next action CTA */}
                    {selectedRiddleAns !== null && (
                      <button
                        id="btn-battle-next"
                        onClick={handleNextBattleStep}
                        className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer shadow-md"
                      >
                        Next Combat Turn <ArrowRight size={14} />
                      </button>
                    )}
                  </div>
                ) : (
                  /* Battle end celebration visual screen */
                  <div className="p-6 bg-slate-900/60 rounded-xl border border-slate-800 text-center flex flex-col items-center justify-center">
                    {battleOutcome === 'victory' ? (
                      <>
                        <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mb-4 border border-emerald-500/20">
                          <Crown size={32} className="animate-bounce" />
                        </div>
                        <h3 className="text-xl font-black text-emerald-400 mb-2">Boss Defeated!</h3>
                        <p className="text-xs text-slate-400 max-w-sm mb-4 leading-relaxed">
                          Your theoretical grasp completely dismantled the <strong>{currentBoss?.name}</strong>. Legendary honors have been recorded onto your profile portfolio!
                        </p>
                        <div className="flex gap-4 mb-6 bg-slate-850 px-4 py-2 rounded-xl text-xs">
                          <span className="text-emerald-500 font-bold">+{referralMultiplierActive ? 900 : 450} XP Awarded</span>
                          <span className="text-amber-400 font-bold">Unlocking Vanquisher Badge</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mb-4 border border-red-500/20">
                          <Skull size={32} className="animate-pulse" />
                        </div>
                        <h3 className="text-xl font-black text-red-400 mb-2">You Were Defeated</h3>
                        <p className="text-xs text-slate-400 max-w-sm mb-6 leading-relaxed">
                          Your execution stack overflowed. Revise the diagnostic weakest-link topics inside heatmaps before re-entering combat.
                        </p>
                      </>
                    )}

                    <button
                      id="btn-leave-battle"
                      onClick={handleNextBattleStep}
                      className="py-2.5 px-6 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-xs uppercase tracking-wider cursor-pointer transition-all"
                    >
                      Return to world map
                    </button>
                  </div>
                )}
              </div>

              {/* Right Column: Live Combat Logs (Col 4) */}
              <div className="lg:col-span-4 flex flex-col gap-3">
                <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 h-[300px] flex flex-col">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 flex items-center gap-1">
                    <Zap size={12} className="text-red-500 animate-pulse" />
                    Live Combat log
                  </h4>

                  <div id="combat-logs-scroller" className="flex-1 overflow-y-auto flex flex-col gap-2 text-[11px] font-mono leading-relaxed pr-1">
                    {battleLog.map((log, index) => (
                      <div 
                        id={`combat-log-line-${index}`}
                        key={index} 
                        className={`pb-1.5 border-b border-slate-850 last:border-0 ${
                          log.startsWith('💥') || log.startsWith('🏆') ? 'text-emerald-400' :
                          log.startsWith('❌') || log.startsWith('💀') ? 'text-red-400' :
                          'text-slate-300'
                        }`}
                      >
                        {log}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          )}
        </>
      )}

      {/* Cooperative Proof Quests Tab */}
      {activeTab === 'coop_proofs' && (
        <div className="animate-in fade-in duration-300">
          <CoopProofQuests 
            userLevel={userLevel}
            tokens={tokens}
            addXp={(xpAmount, badgeOption, tokenBonus) => {
              const res = addXp(xpAmount, badgeOption, tokenBonus);
              return { finalXp: res.finalXp, finalTokens: res.finalTokens };
            }}
            showNotification={(msg, type) => {
              console.log(`[Notification: ${type}] ${msg}`);
            }}
          />
        </div>
      )}

      {/* Classmate Referrals Tab */}
      {activeTab === 'referrals' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 animate-in fade-in duration-300 text-left">
          {/* Left: Code Generation & Invitation Form (Col 6) */}
          <div className="lg:col-span-6 flex flex-col gap-4">
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5 mb-3">
                <div className="w-9 h-9 bg-amber-500/10 text-amber-500 rounded-xl flex items-center justify-center">
                  <Gift size={18} />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider">
                    Your Peer Invitation Portal
                  </h3>
                  <span className="text-[10px] text-slate-400 block font-medium">
                    Invite classmates to lock in the permanent 2x Study Alliance multiplier
                  </span>
                </div>
              </div>

              <div className="my-5 p-4 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-200 dark:border-slate-850">
                <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider block mb-2">
                  Share Your Unique Referral Code
                </span>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-lg font-mono text-xs font-bold text-slate-700 dark:text-slate-200 select-all flex items-center justify-between shadow-sm">
                    <span>{referralCode}</span>
                    <span className="text-[9px] bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-extrabold px-1.5 py-0.5 rounded">
                      CODE
                    </span>
                  </div>
                  <button
                    onClick={handleCopyCode}
                    className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-all active:scale-95 cursor-pointer shadow-sm"
                    title="Copy invite code"
                  >
                    {copiedCode ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-2.5 leading-relaxed">
                  When classmates link with this code and study, they earn bonus tokens and you receive an **instant 100% tokens matching bonus** in real-time!
                </p>
              </div>

              {/* Form to paste classmate's code */}
              <form onSubmit={handleLinkReferral} className="space-y-3">
                <label className="text-[9px] font-black uppercase text-slate-400 tracking-wider block">
                  Link Classmate's Invite Code
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={inputReferralCode}
                    onChange={(e) => setInputReferralCode(e.target.value)}
                    placeholder="E.g. OMNI-REF-ROH49"
                    className="flex-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-mono font-bold text-slate-800 dark:text-white uppercase placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-black uppercase tracking-wider transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
                  >
                    <UserPlus size={14} /> Link Peer
                  </button>
                </div>
              </form>

              {referralSuccessMsg && (
                <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs rounded-xl flex items-center gap-2">
                  <CheckCircle2 size={16} />
                  <span>{referralSuccessMsg}</span>
                </div>
              )}
            </div>

            {/* Simulated Live Action Sandbox to trigger learning-and-earning matches */}
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider">
                  Learn-and-Earn Sandbox
                </h4>
                <span className="text-[8px] bg-indigo-500/10 text-indigo-500 font-extrabold px-1.5 py-0.5 rounded uppercase">
                  Local Simulation
                </span>
              </div>
              <p className="text-[10px] text-slate-400 leading-relaxed mb-4">
                Since we are in a sandbox development container, you can trigger simulated classroom study events from your classmate roster to see peer learning tokens automatically streaming into your balance!
              </p>
              <button
                onClick={handleSimulateClassmateEvent}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-950/20 active:scale-95 transition-all"
              >
                <Zap size={13} className="animate-pulse text-yellow-300" />
                Simulate Classmate Study Event
              </button>
            </div>
          </div>

          {/* Right: Roster & Live Matching Stream (Col 6) */}
          <div className="lg:col-span-6 flex flex-col gap-4">
            {/* Active Classmates Roster */}
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <h3 className="text-xs font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider mb-3">
                Classmate Study Alliance
              </h3>

              <div className="flex flex-col gap-2.5">
                {referredClassmates.map((classmate) => (
                  <div key={classmate.id} className="p-3 bg-slate-50 dark:bg-slate-950/40 rounded-xl border border-slate-150 dark:border-slate-850 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-xs font-bold border border-slate-350 dark:border-slate-700">
                        {classmate.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block truncate">{classmate.name}</span>
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            classmate.status === 'studying' ? 'bg-amber-500 animate-ping' :
                            classmate.status === 'online' ? 'bg-emerald-500' : 'bg-slate-400'
                          }`} />
                        </div>
                        <span className="text-[9px] text-slate-400 font-mono tracking-wider block">{classmate.code}</span>
                        <span className="text-[9px] text-slate-500 font-medium truncate block mt-0.5">
                          Act: {classmate.lastActivity}
                        </span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs font-extrabold text-amber-500 block">
                        🪙 {classmate.tokensEarned}
                      </span>
                      <span className="text-[8px] text-slate-400 font-bold uppercase tracking-widest block">
                        COINS EARNED
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Live activity matching log stream */}
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex-1 flex flex-col">
              <h3 className="text-xs font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider mb-3">
                Live Referral Multiplier Stream
              </h3>
              <div className="flex-1 bg-slate-50 dark:bg-slate-950/60 p-3 rounded-xl border border-slate-150 dark:border-slate-850 max-h-[190px] overflow-y-auto space-y-2 font-mono text-[9px]">
                {referralEvents.map((ev, index) => (
                  <div key={index} className="pb-2 border-b border-slate-200 dark:border-slate-850 last:border-0 text-slate-600 dark:text-slate-300 leading-relaxed">
                    {ev}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Multiplayer Study Arenas Tab */}
      {activeTab === 'arenas' && (
        <div className="animate-in fade-in duration-300 text-left">
          {arenaState === 'setup' && (
            <div className="max-w-xl mx-auto p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-center space-y-5">
              <div className="w-14 h-14 bg-indigo-600/10 text-indigo-500 rounded-full flex items-center justify-center mx-auto">
                <Trophy size={28} />
              </div>

              <div>
                <h3 className="text-sm font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider">
                  Host Multiplayer Study Tournament
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Generate a friendly real-time competitive battle, invite your classmate study group, and play for massive learning tokens!
                </p>
              </div>

              {/* Setup form */}
              <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-850 space-y-4 text-left">
                <div>
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-wider block mb-1.5">
                    Select Exam Preparation Discipline
                  </label>
                  <select
                    value={selectedArenaExam}
                    onChange={(e) => setSelectedArenaExam(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs font-bold text-slate-800 dark:text-white"
                  >
                    <option value="CBSE Board Class XII Prep">📚 CBSE Board Class XII Prep (Physics / Equations)</option>
                    <option value="JNU Entrance General Aptitude">🏛️ JNU Entrance General Aptitude (Reasoning & Speed)</option>
                    <option value="JEE Mains Math Combat">📐 JEE Mains Math Combat (Calculus & Permutations)</option>
                    <option value="NEET Physics Speedrun">🧬 NEET Physics Speedrun (Motion & Mechanics)</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-wider block mb-1.5">
                      Combat Difficulty
                    </label>
                    <div className="flex bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-1">
                      {['easy', 'medium', 'hard'].map((diff) => (
                        <button
                          key={diff}
                          onClick={() => setArenaDifficulty(diff as any)}
                          className={`flex-1 py-1.5 text-[8px] font-black uppercase rounded-md transition-all ${
                            arenaDifficulty === diff 
                              ? 'bg-indigo-600 text-white' 
                              : 'text-slate-500'
                          }`}
                        >
                          {diff}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-wider block mb-1.5">
                      Prize Distribution
                    </label>
                    <div className="bg-slate-100 dark:bg-slate-900 px-3 py-2 rounded-lg text-[9px] font-extrabold text-amber-500 flex items-center justify-between border border-slate-200 dark:border-slate-800">
                      <span>🥇 1st Place</span>
                      <span>🪙 {arenaDifficulty === 'easy' ? 250 : arenaDifficulty === 'medium' ? 400 : 750}</span>
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={handleCreateArena}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs uppercase tracking-wider rounded-xl cursor-pointer shadow-lg shadow-indigo-950/30 transition-all active:scale-98"
              >
                Create Study Tournament Lobby
              </button>
            </div>
          )}

          {/* Lobby state */}
          {arenaState === 'lobby' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in zoom-in-95 duration-300">
              {/* Lobby Status and Link Card (Col 8) */}
              <div className="lg:col-span-8 flex flex-col gap-4">
                <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-150 dark:border-slate-850 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
                      <h3 className="text-xs font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider">
                        Tournament Lobby is Active
                      </h3>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-500 text-[8px] font-black uppercase">
                      Exam: {selectedArenaExam}
                    </span>
                  </div>

                  <p className="text-[10px] text-slate-500 leading-relaxed">
                    Your classmates and study groups are starting to join the tournament via your unique join invitation code. Send the lobby parameters to invite others!
                  </p>

                  <div className="p-3.5 bg-indigo-50/40 dark:bg-indigo-950/15 border border-indigo-100 dark:border-indigo-900/40 rounded-xl space-y-2">
                    <span className="text-[9px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block">
                      Study Arena Lobby Join Invitation
                    </span>
                    <div className="flex gap-2">
                      <div className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2 rounded-lg font-mono text-[10px] font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between shadow-sm">
                        <span>https://omni-ai.studio/arena/join?code={arenaInviteCode}</span>
                        <span className="text-[8px] bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-extrabold px-1.5 py-0.5 rounded">
                          ARENA LINK
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(`https://omni-ai.studio/arena/join?code=${arenaInviteCode}`);
                          alert("Arena join link copied to clipboard!");
                        }}
                        className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg cursor-pointer"
                        title="Copy Join link"
                      >
                        <Copy size={15} />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-2">
                    <button
                      onClick={handleStartArenaCombat}
                      disabled={arenaPlayers.length < 2}
                      className="flex-1 py-3 bg-red-600 hover:bg-red-500 text-white rounded-xl font-black text-xs uppercase tracking-wider cursor-pointer shadow-lg shadow-red-950/20 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      🚀 Launch Tournament Combat ({arenaPlayers.length - 1} Classmates Joined)
                    </button>
                    <button
                      onClick={() => setArenaState('setup')}
                      className="px-4 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold uppercase rounded-xl cursor-pointer transition-all"
                    >
                      Cancel
                    </button>
                  </div>
                </div>

                {/* Classmate Joining Roster Card */}
                <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                  <h4 className="text-xs font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                    <Users size={14} className="text-indigo-500" />
                    Lobby Study Group ({arenaPlayers.length} Active)
                  </h4>

                  <div className="grid grid-cols-2 gap-3">
                    {arenaPlayers.map((p) => (
                      <div key={p.id} className="p-3 bg-slate-50 dark:bg-slate-950/40 rounded-xl border border-slate-150 dark:border-slate-850 flex items-center gap-2.5">
                        <span className="text-xl">{p.avatar}</span>
                        <div>
                          <span className="text-xs font-bold text-slate-800 dark:text-white block">{p.name}</span>
                          <span className="text-[8px] font-black uppercase text-slate-400 block tracking-widest">
                            {p.isHost ? '👑 TOURNAMENT HOST' : '🎓 COMPETITOR READY'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Lobby Connections log (Col 4) */}
              <div className="lg:col-span-4 flex flex-col gap-3">
                <div className="p-4 bg-slate-900 text-slate-200 rounded-2xl border border-slate-800 h-[280px] flex flex-col">
                  <h4 className="text-[9px] font-black uppercase tracking-widest text-slate-500 mb-3">
                    Lobby connection log
                  </h4>
                  <div className="flex-1 overflow-y-auto space-y-2 font-mono text-[10px] text-slate-300 pr-1 select-none">
                    {arenaLogs.map((log, index) => (
                      <div key={index} className="pb-1.5 border-b border-slate-850 last:border-0">
                        {log}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Active combat gameplay */}
          {arenaState === 'combat' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in zoom-in-95 duration-300">
              
              {/* Question Combat Stage (Col 8) */}
              <div className="lg:col-span-8 flex flex-col gap-4">
                <div className="p-5 bg-slate-950 text-white rounded-2xl border border-indigo-500/20 space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-850 pb-3">
                    <span className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">
                      QUESTION {currentArenaQuestionIdx + 1} OF {arenaQuestions.length}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] bg-red-500/10 text-red-400 px-2.5 py-0.5 rounded-full font-bold">
                      <Clock size={11} className="animate-pulse" />
                      15s Timer Active
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-slate-100 leading-relaxed">
                    {arenaQuestions[currentArenaQuestionIdx]?.question}
                  </h3>

                  <div className="flex flex-col gap-2 pt-2">
                    {arenaQuestions[currentArenaQuestionIdx]?.options.map((opt, oIdx) => {
                      const isSelected = arenaSelectedAnswer === oIdx;
                      const isCorrect = oIdx === arenaQuestions[currentArenaQuestionIdx].correctIndex;
                      const hasAnswered = arenaSelectedAnswer !== null;

                      return (
                        <button
                          key={oIdx}
                          disabled={hasAnswered}
                          onClick={() => handleSelectArenaAnswer(oIdx)}
                          className={`p-3.5 rounded-xl border text-left text-xs font-bold transition-all ${
                            hasAnswered
                              ? isCorrect
                                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                                : isSelected
                                  ? 'bg-red-500/20 border-red-500 text-red-400'
                                  : 'bg-slate-900 border-slate-800 opacity-40'
                              : 'bg-slate-900/80 hover:bg-slate-900 border-slate-800 hover:border-indigo-500/40 cursor-pointer'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded bg-slate-800 text-slate-400 flex items-center justify-center text-[10px]">
                              {String.fromCharCode(65 + oIdx)}
                            </span>
                            <span>{opt}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {hasAnsweredArenaQuestion && (
                    <div className="p-3 bg-indigo-500/5 border border-indigo-500/10 rounded-xl text-xs text-slate-300 leading-relaxed">
                      <span className="font-black text-indigo-400 block mb-1">🔍 DIAGNOSTIC RECAP</span>
                      {arenaQuestions[currentArenaQuestionIdx]?.explanation}
                    </div>
                  )}

                  {hasAnsweredArenaQuestion && (
                    <button
                      onClick={handleNextArenaQuestion}
                      className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                    >
                      {currentArenaQuestionIdx + 1 < arenaQuestions.length ? 'Next Question' : 'Complete Challenge & View Podium'}
                      <ArrowRight size={14} />
                    </button>
                  )}
                </div>
              </div>

              {/* Live Leaderboard Display (Col 4) */}
              <div className="lg:col-span-4 flex flex-col gap-3">
                <div className="p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 flex-1 flex flex-col">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 flex items-center gap-1.5 border-b border-slate-800 pb-2">
                    <Trophy size={13} className="text-amber-500" />
                    Live Arena Scoreboard
                  </h4>

                  <div className="flex-1 space-y-2">
                    {arenaPlayers
                      .sort((a, b) => b.score - a.score)
                      .map((p, idx) => (
                        <div key={p.id} className="p-2.5 bg-slate-950 rounded-xl border border-slate-850 flex items-center justify-between">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="text-[9px] font-black text-slate-500 font-mono w-4">
                              #{idx + 1}
                            </span>
                            <span className="text-sm">{p.avatar}</span>
                            <span className="text-xs font-bold text-slate-200 truncate">{p.name}</span>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            {p.lastAnswerCorrect !== undefined && (
                              <span className={`text-[8px] font-black px-1.5 py-0.5 rounded ${
                                p.lastAnswerCorrect 
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/15' 
                                  : 'bg-red-500/10 text-red-400 border border-red-500/15'
                              }`}>
                                {p.lastAnswerCorrect ? 'CORRECT' : 'WRONG'}
                              </span>
                            )}
                            <span className="text-xs font-mono font-black text-amber-500">
                              {p.score} pt
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>

                  {/* Tournament Log Stream */}
                  <div className="mt-4 p-2.5 bg-slate-950 rounded-xl border border-slate-850 h-[100px] overflow-y-auto space-y-1 text-[9px] font-mono text-slate-400">
                    {arenaLogs.slice(-4).map((log, idx) => (
                      <div key={idx} className="pb-1 border-b border-slate-900 last:border-0">
                        {log}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* Podium Results */}
          {arenaState === 'podium' && (
            <div className="max-w-xl mx-auto p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-center space-y-6 animate-in zoom-in-95 duration-300">
              <div className="w-16 h-16 bg-amber-500/10 text-amber-500 rounded-full flex items-center justify-center mx-auto border border-amber-500/20">
                <Crown size={32} className="animate-bounce" />
              </div>

              <div>
                <h3 className="text-xl font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">
                  Tournament Completed!
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Congratulations to all competitors of our high-yield syllabus challenge! Prizes have been distributed to your portfolios.
                </p>
              </div>

              {/* High podium scoreboard */}
              <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-850 space-y-2.5 text-left">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block mb-1">
                  Final Tournament Standings
                </span>

                {arenaPlayers
                  .sort((a, b) => b.score - a.score)
                  .map((player, idx) => (
                    <div key={player.id} className="flex items-center justify-between p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xs font-mono font-black text-indigo-600 dark:text-indigo-400 w-5">
                          #{idx + 1}
                        </span>
                        <span className="text-sm">{player.avatar}</span>
                        <span className="text-xs font-black text-slate-800 dark:text-slate-100">{player.name}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-mono font-bold text-slate-400">
                          {player.score} XP Points
                        </span>
                        {idx === 0 && (
                          <span className="bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[8px] font-black uppercase px-2 py-0.5 rounded">
                            🏆 Winner
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
              </div>

              {/* Distributed reward details */}
              <div className="p-4 bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 rounded-xl text-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
                <div>
                  <span className="font-extrabold text-slate-800 dark:text-slate-200 block">
                    {arenaWinner?.includes('You') ? '👑 First Place Prize Claimed!' : '🎓 Tournament Complete'}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {arenaWinner?.includes('You') 
                      ? `Your referral active matches boosted your reward to +${referralMultiplierActive ? 800 : 400} tokens!`
                      : `You earned +${referralMultiplierActive ? 300 : 150} tokens participation match!`
                    }
                  </span>
                </div>
                <div className="bg-amber-500/10 border border-amber-500/20 px-3.5 py-1.5 rounded-xl font-bold text-amber-500 shrink-0 text-sm flex items-center gap-1">
                  🪙 +{arenaWinner?.includes('You') ? (referralMultiplierActive ? 800 : 400) : (referralMultiplierActive ? 300 : 150)} OMNI-COINS
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setArenaState('setup');
                    setArenaPlayers([]);
                  }}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-xs uppercase tracking-wider cursor-pointer shadow-md"
                >
                  Create New Arena
                </button>
                <button
                  onClick={() => {
                    setActiveTab('quests');
                    setArenaState('setup');
                    setArenaPlayers([]);
                  }}
                  className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-bold text-xs uppercase tracking-wider cursor-pointer"
                >
                  Return to Quests
                </button>
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
