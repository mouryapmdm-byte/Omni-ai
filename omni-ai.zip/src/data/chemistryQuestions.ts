export const CHEMISTRY_QUESTIONS = [
  {
    id: 'chem-q1',
    chapterId: 'solutions',
    chapterTitle: '1. Solutions',
    section: 'A',
    marks: 1,
    questionText: 'Which of the following units is useful in relating concentration of solution with its vapour pressure?',
    options: ['mole fraction', 'parts per million', 'mass percentage', 'molality'],
    correctAnswer: 'mole fraction',
    solution: 'Mole fraction is useful in relating the concentration of solutions with their vapour pressures.',
    subtopicRef: 'Concentration of solutions'
  }
];
