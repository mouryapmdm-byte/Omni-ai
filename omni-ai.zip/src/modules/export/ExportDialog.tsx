import React, { useState } from 'react';
import { exportToPDF } from './exporters/pdf';
import { exportToMarkdown } from './exporters/markdown';
import { exportToDocx } from './exporters/docx';

export const ExportDialog: React.FC<{ content: any; onClose: () => void }> = ({ content, onClose }) => {
  const [format, setFormat] = useState<'pdf' | 'markdown' | 'docx'>('pdf');

  const handleExport = async () => {
    if (format === 'pdf') await exportToPDF(content);
    else if (format === 'markdown') await exportToMarkdown(content);
    else if (format === 'docx') await exportToDocx(content);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-slate-900 p-6 rounded-2xl w-full max-w-sm space-y-4">
        <h3 className="text-lg font-bold text-white">Export Content</h3>
        <select value={format} onChange={(e) => setFormat(e.target.value as any)} className="w-full bg-slate-950 p-2 rounded">
          <option value="pdf">PDF</option>
          <option value="markdown">Markdown</option>
          <option value="docx">DOCX</option>
        </select>
        <button onClick={handleExport} className="w-full bg-indigo-500 text-white p-2 rounded">Export</button>
        <button onClick={onClose} className="w-full bg-slate-800 text-slate-300 p-2 rounded">Cancel</button>
      </div>
    </div>
  );
};
