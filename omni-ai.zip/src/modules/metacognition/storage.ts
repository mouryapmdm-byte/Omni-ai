import { CalibrationRecord, CalibrationSummary } from './types';
import { calculateCalibrationSummary, calculateTopicSummaries } from './calibration';

const STORAGE_KEY = 'omni_calibration_records_v1';
const LISTENERS: Array<() => void> = [];

export function getCalibrationRecords(): CalibrationRecord[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error('Error reading calibration records:', e);
    return [];
  }
}

export function saveCalibrationRecord(record: CalibrationRecord): void {
  try {
    const records = getCalibrationRecords();
    records.unshift(record); // newest first
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
    
    // Notify all active listeners in real-time
    LISTENERS.forEach(cb => {
      try { cb(); } catch {}
    });
  } catch (e) {
    console.error('Error saving calibration record:', e);
  }
}

export function subscribeToCalibrationUpdates(callback: () => void): () => void {
  LISTENERS.push(callback);
  return () => {
    const idx = LISTENERS.indexOf(callback);
    if (idx !== -1) LISTENERS.splice(idx, 1);
  };
}

export function getOverallCalibrationSummary(subject?: string): CalibrationSummary {
  const records = getCalibrationRecords();
  const filtered = subject ? records.filter(r => r.subject === subject) : records;
  return calculateCalibrationSummary(filtered);
}

export function getTopicCalibrationSummaries(subject?: string): CalibrationSummary[] {
  const records = getCalibrationRecords();
  const filtered = subject ? records.filter(r => r.subject === subject) : records;
  return calculateTopicSummaries(filtered);
}
