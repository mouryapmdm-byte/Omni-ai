export * from '../../src/modules/careers/CareerExplorer';
import { CareerExplorer } from '../../src/modules/careers/CareerExplorer';
export default CareerExplorer;
