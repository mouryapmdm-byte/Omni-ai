const fs = require('fs');
let code = fs.readFileSync('src/components/VideoWithOverlay.tsx', 'utf-8');
code = code.replace(
  /const handleKeyDown = \(e: React\.KeyboardEvent\) => \{\s*<div/s,
  `return (
    <div`
);
fs.writeFileSync('src/components/VideoWithOverlay.tsx', code);
