import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Camera, Upload, X, Check, RefreshCw, QrCode, BookOpen, User, AlertCircle, Sparkles } from 'lucide-react';
import { cn, triggerHapticFeedback, saveQrHistoryItem } from '../lib/utils';
import { UserProfile } from '../types';

interface QrCodeScannerProps {
  theme: 'light' | 'dark';
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  onClose?: () => void;
  showNotification: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onImportComplete?: (data: { subject?: string; topic?: string; difficulty?: string; tutor?: string; noteText?: string }) => void;
}

export interface ScannedQrData {
  rawPayload: string;
  isUrl: boolean;
  subject?: string;
  topic?: string;
  difficulty?: string;
  tutor?: string;
  lesson?: string;
  isNote?: boolean;
  sharedBy?: string;
  customText?: string;
}

export const QrCodeScanner: React.FC<QrCodeScannerProps> = ({
  theme,
  user,
  setUser,
  onClose,
  showNotification,
  onImportComplete
}) => {
  const [activeMode, setActiveMode] = useState<'camera' | 'upload'>('camera');
  const [isScanning, setIsScanning] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scannedResult, setScannedResult] = useState<ScannedQrData | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Parse raw text payload into structured study session or note parameters
  const parseQrPayload = (payload: string): ScannedQrData => {
    try {
      if (payload.startsWith('http://') || payload.startsWith('https://')) {
        const url = new URL(payload);
        const subject = url.searchParams.get('subject') || undefined;
        const topic = url.searchParams.get('topic') || undefined;
        const difficulty = url.searchParams.get('difficulty') || undefined;
        const tutor = url.searchParams.get('tutor') || undefined;
        const lesson = url.searchParams.get('lesson') || undefined;
        const isNote = url.searchParams.get('note') === 'true';
        const sharedBy = url.searchParams.get('sharedBy') || undefined;

        return {
          rawPayload: payload,
          isUrl: true,
          subject,
          topic,
          difficulty,
          tutor,
          lesson,
          isNote,
          sharedBy
        };
      }
    } catch {
      // payload is not a valid URL, treat as raw custom text or note
    }

    return {
      rawPayload: payload,
      isUrl: false,
      customText: payload
    };
  };

  const handleScanSuccess = (payload: string) => {
    triggerHapticFeedback([40, 60, 40]); // haptic feedback pattern for success scan
    stopCamera();

    const parsed = parseQrPayload(payload);
    setScannedResult(parsed);

    // Save item to history
    const title = parsed.topic
      ? `${parsed.subject || 'STEM'} • ${parsed.topic}`
      : parsed.customText
      ? parsed.customText.slice(0, 35) + (parsed.customText.length > 35 ? '...' : '')
      : 'Scanned Study Session';

    const subtitle = parsed.sharedBy
      ? `Shared by ${parsed.sharedBy}`
      : parsed.isNote
      ? 'Shared Lesson Note'
      : 'Imported Session Link';

    saveQrHistoryItem({
      type: 'scanned',
      title,
      subtitle,
      payload,
      subject: parsed.subject,
      topic: parsed.topic,
      difficulty: parsed.difficulty,
      tutor: parsed.tutor
    });

    showNotification('QR Code scanned successfully! Inspect configuration below.', 'success');
  };

  const startCamera = async () => {
    setCameraError(null);
    setIsScanning(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        scanFrame();
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setIsScanning(false);
      setCameraError('Unable to access camera. Please check camera permissions or try uploading a QR image file.');
    }
  };

  const stopCamera = () => {
    setIsScanning(false);
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const scanFrame = () => {
    if (!videoRef.current || videoRef.current.readyState !== videoRef.current.HAVE_ENOUGH_DATA) {
      animationFrameRef.current = requestAnimationFrame(scanFrame);
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvasRef.current = canvas;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'attemptBoth'
      });

      if (code && code.data) {
        handleScanSuccess(code.data);
        return;
      }
    }

    animationFrameRef.current = requestAnimationFrame(scanFrame);
  };

  useEffect(() => {
    if (activeMode === 'camera' && !scannedResult) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [activeMode, scannedResult]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingFile(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: 'attemptBoth'
          });

          setIsProcessingFile(false);
          if (code && code.data) {
            handleScanSuccess(code.data);
          } else {
            showNotification('No valid QR code detected in the uploaded image. Please try another image.', 'error');
          }
        }
      };
      img.onerror = () => {
        setIsProcessingFile(false);
        showNotification('Failed to load image file.', 'error');
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const applyImportedConfiguration = () => {
    if (!scannedResult) return;

    triggerHapticFeedback([20, 40, 60]); // haptic feedback on import apply

    const updates: Partial<UserProfile> = {};
    if (scannedResult.subject) updates.subject = scannedResult.subject;
    if (scannedResult.topic) updates.topic = scannedResult.topic;
    if (scannedResult.difficulty) updates.difficulty = scannedResult.difficulty;
    if (scannedResult.tutor) updates.tutor = scannedResult.tutor;

    setUser(prev => {
      const next = { ...prev, ...updates };
      localStorage.setItem('omni_user', JSON.stringify(next));
      return next;
    });

    if (onImportComplete) {
      onImportComplete({
        subject: scannedResult.subject,
        topic: scannedResult.topic,
        difficulty: scannedResult.difficulty,
        tutor: scannedResult.tutor,
        noteText: scannedResult.customText
      });
    }

    showNotification(
      scannedResult.topic
        ? `Imported Study Session: ${scannedResult.subject || 'STEM'} • ${scannedResult.topic}!`
        : 'Imported shared study note into session context!',
      'success'
    );

    if (onClose) onClose();
  };

  return (
    <div className={cn(
      "p-5 rounded-2xl border-2 space-y-4 animate-in fade-in duration-200",
      theme === 'dark'
        ? "bg-slate-900/95 border-indigo-500/60 shadow-2xl shadow-indigo-950/50"
        : "bg-white border-indigo-400 shadow-xl"
    )}>
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <QrCode className="text-indigo-500" size={20} />
          <div>
            <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 uppercase tracking-wider">
              Quick QR Code Scanner
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Scan or upload a study QR code to instantly sync session configurations.
            </p>
          </div>
        </div>
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X size={18} />
          </button>
        )}
      </div>

      {/* Mode Switcher */}
      {!scannedResult && (
        <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
          <button
            type="button"
            onClick={() => {
              setActiveMode('camera');
              setCameraError(null);
            }}
            className={cn(
              "py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer",
              activeMode === 'camera'
                ? "bg-indigo-600 text-white shadow-md font-black"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Camera size={14} />
            <span>Camera Feed</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveMode('upload');
              stopCamera();
            }}
            className={cn(
              "py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer",
              activeMode === 'upload'
                ? "bg-indigo-600 text-white shadow-md font-black"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Upload size={14} />
            <span>Upload QR Image</span>
          </button>
        </div>
      )}

      {/* Camera Scanning View */}
      {activeMode === 'camera' && !scannedResult && (
        <div className="space-y-3">
          {cameraError ? (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs space-y-2 text-center">
              <AlertCircle size={24} className="mx-auto text-rose-500" />
              <p className="font-semibold">{cameraError}</p>
              <button
                type="button"
                onClick={() => setActiveMode('upload')}
                className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold cursor-pointer hover:bg-rose-500 transition"
              >
                Switch to Image Upload
              </button>
            </div>
          ) : (
            <div className="relative overflow-hidden rounded-xl bg-black aspect-video flex items-center justify-center border border-slate-700 group">
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
              />
              {/* Scan Overlay Frame */}
              <div className="absolute inset-0 border-2 border-indigo-500/40 pointer-events-none flex items-center justify-center">
                <div className="w-48 h-48 border-2 border-indigo-400 rounded-2xl relative shadow-2xl">
                  {/* Glowing Animated Scan Line */}
                  <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-indigo-400 to-transparent shadow-[0_0_15px_#6366f1] animate-bounce" />
                </div>
              </div>
              <span className="absolute bottom-3 text-[10px] font-mono text-white/80 bg-black/60 px-3 py-1 rounded-full backdrop-blur-sm">
                Align QR Code within viewport
              </span>
            </div>
          )}
        </div>
      )}

      {/* File Upload View */}
      {activeMode === 'upload' && !scannedResult && (
        <div className="p-6 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-center space-y-3">
          <Upload size={32} className="mx-auto text-indigo-500" />
          <div className="space-y-1">
            <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Select or Drop a QR Code Image
            </h5>
            <p className="text-[11px] text-slate-400">
              Supports PNG, JPG, WEBP formats containing study QR codes.
            </p>
          </div>

          <label className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold cursor-pointer shadow-md transition active:scale-95">
            {isProcessingFile ? <RefreshCw size={14} className="animate-spin" /> : <Upload size={14} />}
            <span>{isProcessingFile ? 'Analyzing Image...' : 'Choose Image File'}</span>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      )}

      {/* Scanned Result & Import Options */}
      {scannedResult && (
        <div className="p-4 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 space-y-4 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="text-indigo-600 dark:text-indigo-400" size={18} />
              <h5 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-100">
                Scanned Study Configuration
              </h5>
            </div>
            <button
              type="button"
              onClick={() => setScannedResult(null)}
              className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw size={12} />
              <span>Scan Another</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {scannedResult.subject && (
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold block">Subject</span>
                <strong className="text-slate-800 dark:text-slate-200 truncate block">{scannedResult.subject}</strong>
              </div>
            )}
            {scannedResult.topic && (
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold block">Topic</span>
                <strong className="text-slate-800 dark:text-slate-200 truncate block">{scannedResult.topic}</strong>
              </div>
            )}
            {scannedResult.difficulty && (
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold block">Difficulty</span>
                <strong className="text-slate-800 dark:text-slate-200 capitalize truncate block">{scannedResult.difficulty}</strong>
              </div>
            )}
            {scannedResult.tutor && (
              <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold block">Tutor Persona</span>
                <strong className="text-slate-800 dark:text-slate-200 capitalize truncate block">{scannedResult.tutor}</strong>
              </div>
            )}
          </div>

          {scannedResult.customText && (
            <div className="p-3 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs">
              <span className="text-[10px] text-slate-400 font-bold block mb-1">Scanned Note Content</span>
              <p className="font-mono text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                {scannedResult.customText}
              </p>
            </div>
          )}

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={applyImportedConfiguration}
              className="flex-1 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-md transition cursor-pointer active:scale-95"
            >
              <Check size={16} />
              <span>Import & Sync to Session</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
