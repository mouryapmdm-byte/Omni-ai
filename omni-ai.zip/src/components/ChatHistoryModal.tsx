import React, { useState, useEffect, useMemo } from 'react';
import { 
  MessageSquare, 
  Search, 
  Trash2, 
  Edit3, 
  Check, 
  X, 
  Plus, 
  Download, 
  Clock, 
  Database, 
  Cloud, 
  CloudUpload,
  CloudOff,
  CheckCircle2,
  RefreshCw, 
  Folder, 
  Calendar, 
  Play, 
  Sparkles, 
  User, 
  Bot,
  AlertTriangle,
  ChevronRight,
  Filter,
  Layers,
  Tag
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { ChatMessage, ChatSessionRecord } from '@/src/types';
import { 
  fetchUserChatSessions, 
  saveChatSessionToFirestore, 
  renameChatSessionInFirestore, 
  deleteChatSessionFromFirestore,
  syncAllSessionsToFirestore,
  syncSingleSessionToFirestore
} from '@/src/services/chatHistoryService';
import { auth } from '@/src/lib/firebase';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';

interface ChatHistoryModalProps {
  theme: 'light' | 'dark';
  currentMessages: ChatMessage[];
  currentMessagesByMode?: Record<string, ChatMessage[]>;
  currentSubject?: string;
  currentTopic?: string;
  currentMode?: string;
  onLoadSession: (session: ChatSessionRecord) => void;
  onNewChat: () => void;
  onClose: () => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

// Relative time formatting helper (e.g., '2 hours ago', 'yesterday', 'just now')
export function formatRelativeTime(timestamp: number): string {
  if (!timestamp) return 'Recently';
  const now = Date.now();
  const diffMs = now - timestamp;

  if (diffMs < 0) return 'Just now';

  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHours = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHours / 24);
  const diffWeeks = Math.floor(diffDays / 7);

  if (diffSec < 45) return 'Just now';
  if (diffMin < 60) return `${diffMin} ${diffMin === 1 ? 'min' : 'mins'} ago`;
  if (diffHours < 24) return `${diffHours} ${diffHours === 1 ? 'hour' : 'hours'} ago`;

  const date = new Date(timestamp);
  const nowDate = new Date();

  // Check if yesterday
  const isYesterday = 
    nowDate.getDate() - date.getDate() === 1 &&
    nowDate.getMonth() === date.getMonth() &&
    nowDate.getFullYear() === date.getFullYear();

  if (isYesterday || diffDays === 1) {
    return `Yesterday at ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  }

  if (diffDays < 7) {
    return `${diffDays} days ago`;
  }

  if (diffWeeks < 4) {
    return `${diffWeeks} ${diffWeeks === 1 ? 'week' : 'weeks'} ago`;
  }

  return date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
}

type GroupingMode = 'date' | 'topic' | 'all';

export const ChatHistoryModal: React.FC<ChatHistoryModalProps> = ({
  theme,
  currentMessages,
  currentMessagesByMode,
  currentSubject = 'Mathematics',
  currentTopic = 'General Topic',
  currentMode = 'learn',
  onLoadSession,
  onNewChat,
  onClose,
  showNotification
}) => {
  const [sessions, setSessions] = useState<ChatSessionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCloud, setIsCloud] = useState(false);
  
  // Title / content search filter
  const [titleFilter, setTitleFilter] = useState('');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');
  const [groupingMode, setGroupingMode] = useState<GroupingMode>('date');
  
  const [selectedSessionForPreview, setSelectedSessionForPreview] = useState<ChatSessionRecord | null>(null);
  
  // Renaming state
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const [isRenaming, setIsRenaming] = useState(false);

  // Saving state
  const [isSavingCurrent, setIsSavingCurrent] = useState(false);
  const [customSaveTitle, setCustomSaveTitle] = useState('');
  const [showSaveDialog, setShowSaveDialog] = useState(false);

  // Deletion Confirmation Dialog state
  const [sessionToDelete, setSessionToDelete] = useState<ChatSessionRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Cloud Sync state
  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [syncingSessionId, setSyncingSessionId] = useState<string | null>(null);

  const currentUser = auth.currentUser;

  // Unsynced count calculation
  const unsyncedCount = useMemo(() => {
    return sessions.filter(s => !s.lastSyncedAt).length;
  }, [sessions]);

  // Load sessions from Firestore
  const loadSessions = async () => {
    setLoading(true);
    try {
      const { sessions: fetchedSessions, isCloud: cloudSynced } = await fetchUserChatSessions(currentUser?.uid);
      setSessions(fetchedSessions);
      setIsCloud(cloudSynced);
      if (fetchedSessions.length > 0 && !selectedSessionForPreview) {
        setSelectedSessionForPreview(fetchedSessions[0]);
      }
    } catch (err) {
      console.error('Failed to load sessions:', err);
      showNotification?.('Could not load sessions from Firestore', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSessions();
  }, [currentUser]);

  // Handle Google Login
  const handleGoogleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      showNotification?.('Signed in! Syncing sessions with Firestore...', 'success');
      loadSessions();
    } catch (err: any) {
      console.error('Login error:', err);
      showNotification?.('Sign in failed. Check popup permissions.', 'error');
    }
  };

  // Handle Manual Sync All Sessions to Cloud
  const handleSyncAllToCloud = async () => {
    if (!currentUser) {
      showNotification?.('Signing in with Google to enable Cloud Sync...', 'info');
      try {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(auth, provider);
      } catch (err) {
        showNotification?.('Google sign in required to push sessions to Firestore Cloud.', 'warning');
        return;
      }
    }

    setIsSyncingAll(true);
    try {
      const result = await syncAllSessionsToFirestore(auth.currentUser?.uid);
      setSessions(result.sessions);
      setIsCloud(true);
      if (selectedSessionForPreview) {
        const updatedSelected = result.sessions.find(s => s.id === selectedSessionForPreview.id);
        if (updatedSelected) setSelectedSessionForPreview(updatedSelected);
      }
      showNotification?.(
        `Successfully synced ${result.syncedCount} session${result.syncedCount === 1 ? '' : 's'} to Firestore Cloud!`,
        'success'
      );
    } catch (err: any) {
      console.error('Cloud sync all error:', err);
      showNotification?.(err?.message || 'Failed to sync sessions to Firestore Cloud', 'error');
    } finally {
      setIsSyncingAll(false);
    }
  };

  // Handle Manual Sync Single Session to Cloud
  const handleSyncSingleSession = async (session: ChatSessionRecord, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) {
      showNotification?.('Signing in with Google to enable Cloud Sync...', 'info');
      try {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(auth, provider);
      } catch (err) {
        showNotification?.('Sign in required to push session to Firestore.', 'warning');
        return;
      }
    }

    setSyncingSessionId(session.id);
    try {
      const updated = await syncSingleSessionToFirestore(session.id, auth.currentUser?.uid);
      setSessions(prev => prev.map(s => s.id === session.id ? updated : s));
      if (selectedSessionForPreview?.id === session.id) {
        setSelectedSessionForPreview(updated);
      }
      setIsCloud(true);
      showNotification?.(`Session "${session.title}" synced to Firestore Cloud!`, 'success');
    } catch (err: any) {
      console.error('Sync single session error:', err);
      showNotification?.(err?.message || 'Failed to sync session to Firestore', 'error');
    } finally {
      setSyncingSessionId(null);
    }
  };

  // Filtered Sessions by title input & subject filter
  const filteredSessions = useMemo(() => {
    return sessions.filter(session => {
      const matchesTitle = 
        !titleFilter.trim() ||
        session.title.toLowerCase().includes(titleFilter.toLowerCase()) ||
        (session.topic && session.topic.toLowerCase().includes(titleFilter.toLowerCase())) ||
        (session.subject && session.subject.toLowerCase().includes(titleFilter.toLowerCase())) ||
        (session.preview && session.preview.toLowerCase().includes(titleFilter.toLowerCase()));

      const matchesSubject = 
        selectedSubjectFilter === 'all' || 
        (session.subject && session.subject.toLowerCase() === selectedSubjectFilter.toLowerCase());

      return matchesTitle && matchesSubject;
    });
  }, [sessions, titleFilter, selectedSubjectFilter]);

  // Unique Subjects for filter tabs
  const subjectList = useMemo(() => {
    const subs = new Set<string>();
    sessions.forEach(s => {
      if (s.subject) subs.add(s.subject);
    });
    return Array.from(subs);
  }, [sessions]);

  // Grouped Sessions calculation (by Date Range or by Topic/Subject)
  const groupedSessions = useMemo(() => {
    if (groupingMode === 'all') {
      return [{ key: 'All Sessions', label: 'All Sessions', items: filteredSessions }];
    }

    if (groupingMode === 'topic') {
      const groups: Record<string, ChatSessionRecord[]> = {};
      filteredSessions.forEach(session => {
        const key = session.subject || session.topic || 'General Studies';
        if (!groups[key]) groups[key] = [];
        groups[key].push(session);
      });

      return Object.entries(groups).map(([topic, items]) => ({
        key: topic,
        label: topic.replace(/_/g, ' '),
        items
      }));
    }

    // Default: Group by Date Range ('Today', 'Yesterday', 'This Week', 'This Month', 'Older')
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const yesterdayStart = todayStart - 24 * 60 * 60 * 1000;
    const weekStart = todayStart - 6 * 24 * 60 * 60 * 1000;
    const monthStart = todayStart - 29 * 24 * 60 * 60 * 1000;

    const todayItems: ChatSessionRecord[] = [];
    const yesterdayItems: ChatSessionRecord[] = [];
    const thisWeekItems: ChatSessionRecord[] = [];
    const thisMonthItems: ChatSessionRecord[] = [];
    const olderItems: ChatSessionRecord[] = [];

    filteredSessions.forEach(session => {
      const time = session.updatedAt || session.createdAt || 0;
      if (time >= todayStart) {
        todayItems.push(session);
      } else if (time >= yesterdayStart) {
        yesterdayItems.push(session);
      } else if (time >= weekStart) {
        thisWeekItems.push(session);
      } else if (time >= monthStart) {
        thisMonthItems.push(session);
      } else {
        olderItems.push(session);
      }
    });

    const result = [];
    if (todayItems.length > 0) result.push({ key: 'today', label: 'Today', items: todayItems });
    if (yesterdayItems.length > 0) result.push({ key: 'yesterday', label: 'Yesterday', items: yesterdayItems });
    if (thisWeekItems.length > 0) result.push({ key: 'this_week', label: 'This Week', items: thisWeekItems });
    if (thisMonthItems.length > 0) result.push({ key: 'this_month', label: 'This Month', items: thisMonthItems });
    if (olderItems.length > 0) result.push({ key: 'older', label: 'Older Sessions', items: olderItems });

    return result;
  }, [filteredSessions, groupingMode]);

  // Handle Save Current Chat Session
  const handleSaveCurrentSession = async () => {
    if (!currentMessages || currentMessages.length === 0) {
      showNotification?.('Cannot save empty chat session.', 'warning');
      return;
    }

    setIsSavingCurrent(true);
    try {
      const defaultTitle = customSaveTitle.trim() || `${currentSubject} - ${currentTopic} (${new Date().toLocaleDateString()})`;
      const saved = await saveChatSessionToFirestore({
        title: defaultTitle,
        subject: currentSubject,
        topic: currentTopic,
        mode: currentMode,
        messages: currentMessages,
        messagesByMode: currentMessagesByMode,
      }, currentUser?.uid);

      showNotification?.(`Session "${saved.title}" saved to Firestore!`, 'success');
      setShowSaveDialog(false);
      setCustomSaveTitle('');
      await loadSessions();
      setSelectedSessionForPreview(saved);
    } catch (err) {
      console.error('Save session error:', err);
      showNotification?.('Failed to save session to Firestore', 'error');
    } finally {
      setIsSavingCurrent(false);
    }
  };

  // Handle Start Rename
  const handleStartRename = (session: ChatSessionRecord, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(session.id);
    setEditingTitle(session.title);
  };

  // Handle Submit Rename
  const handleSubmitRename = async (sessionId: string, e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!editingTitle.trim()) {
      showNotification?.('Title cannot be empty', 'warning');
      return;
    }

    setIsRenaming(true);
    try {
      await renameChatSessionInFirestore(sessionId, editingTitle.trim(), currentUser?.uid);
      setSessions(prev => prev.map(s => s.id === sessionId ? { ...s, title: editingTitle.trim(), updatedAt: Date.now() } : s));
      if (selectedSessionForPreview?.id === sessionId) {
        setSelectedSessionForPreview(prev => prev ? { ...prev, title: editingTitle.trim() } : null);
      }
      showNotification?.('Session renamed successfully!', 'success');
      setEditingSessionId(null);
    } catch (err) {
      console.error('Rename error:', err);
      showNotification?.('Failed to rename session in Firestore', 'error');
    } finally {
      setIsRenaming(false);
    }
  };

  // Open Deletion Confirmation Dialog
  const handleRequestDelete = (session: ChatSessionRecord, e: React.MouseEvent) => {
    e.stopPropagation();
    setSessionToDelete(session);
  };

  // Execute Confirmed Deletion
  const handleConfirmDelete = async () => {
    if (!sessionToDelete) return;

    setIsDeleting(true);
    const targetId = sessionToDelete.id;
    try {
      await deleteChatSessionFromFirestore(targetId, currentUser?.uid);
      
      const remaining = sessions.filter(s => s.id !== targetId);
      setSessions(remaining);
      
      if (selectedSessionForPreview?.id === targetId) {
        setSelectedSessionForPreview(remaining[0] || null);
      }
      
      showNotification?.(`Deleted "${sessionToDelete.title}" from Firestore`, 'info');
      setSessionToDelete(null);
    } catch (err) {
      console.error('Delete error:', err);
      showNotification?.('Failed to delete session from Firestore', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  // Handle Load Session
  const handleLoad = (session: ChatSessionRecord) => {
    onLoadSession(session);
    showNotification?.(`Loaded session: "${session.title}"`, 'success');
    onClose();
  };

  // Handle Export Session
  const handleExportSession = (session: ChatSessionRecord, format: 'markdown' | 'json', e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      let content = '';
      let filename = `${session.title.replace(/[^a-zA-Z0-9_-]/g, '_')}_${session.id}`;
      let mimeType = 'text/plain';

      if (format === 'json') {
        content = JSON.stringify(session, null, 2);
        filename += '.json';
        mimeType = 'application/json';
      } else {
        filename += '.md';
        mimeType = 'text/markdown';
        content = `# ${session.title}\n\n`;
        content += `- **Subject:** ${session.subject || 'N/A'}\n`;
        content += `- **Topic:** ${session.topic || 'N/A'}\n`;
        content += `- **Mode:** ${session.mode || 'learn'}\n`;
        content += `- **Date:** ${new Date(session.createdAt).toLocaleString()} (${formatRelativeTime(session.createdAt)})\n`;
        content += `- **Total Messages:** ${session.messageCount || session.messages.length}\n\n`;
        content += `---\n\n`;

        session.messages.forEach(msg => {
          const senderName = msg.sender === 'user' ? 'Student' : 'Professor Clarity (AI)';
          const time = new Date(msg.timestamp).toLocaleTimeString();
          content += `### ${senderName} [${time}]\n\n${msg.content}\n\n---\n\n`;
        });
      }

      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      showNotification?.(`Exported session as ${format.toUpperCase()}`, 'success');
    } catch (err) {
      console.error('Export error:', err);
      showNotification?.('Failed to export session', 'error');
    }
  };

  return (
    <div className="flex flex-col h-[85vh] max-h-[780px] w-full max-w-6xl mx-auto overflow-hidden bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl relative">
      {/* Top Header Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-950/80 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 shadow-sm">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black tracking-tight">Chat History & Saved Sessions</h2>
              {isCloud ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 shadow-sm">
                  <Cloud className="w-3.5 h-3.5 animate-pulse" />
                  Firestore Synced
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                  <Database className="w-3.5 h-3.5" />
                  Local Cache
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Browse, filter by title, group by date or topic, and restore past study sessions from Firestore.
            </p>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Manual Force Sync to Cloud Button */}
          <button
            onClick={handleSyncAllToCloud}
            disabled={isSyncingAll}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95",
              unsyncedCount > 0
                ? "bg-amber-600 hover:bg-amber-700 text-white animate-pulse"
                : "bg-emerald-600 hover:bg-emerald-700 text-white"
            )}
            title="Manually force push all local sessions to Firestore Cloud"
          >
            <CloudUpload className={cn("w-3.5 h-3.5", isSyncingAll && "animate-spin")} />
            <span>
              {isSyncingAll 
                ? 'Syncing...' 
                : unsyncedCount > 0 
                  ? `Sync to Cloud (${unsyncedCount} unsynced)` 
                  : 'Sync to Cloud'}
            </span>
          </button>

          {!currentUser && (
            <button
              onClick={handleGoogleLogin}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95"
              title="Sign in with Google to sync sessions across all devices"
            >
              <Cloud className="w-3.5 h-3.5" />
              Sign In
            </button>
          )}

          <button
            onClick={() => setShowSaveDialog(true)}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800/60 text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Save Current Chat
          </button>

          <button
            onClick={() => {
              onNewChat();
              onClose();
            }}
            className="px-3.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition flex items-center gap-1.5 active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            New Chat
          </button>

          <button
            onClick={loadSessions}
            disabled={loading}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition active:scale-95"
            title="Refresh from Firestore"
          >
            <RefreshCw className={cn("w-4 h-4", loading && "animate-spin text-indigo-500")} />
          </button>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Save Modal Popup */}
      <AnimatePresence>
        {showSaveDialog && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 bg-indigo-50 dark:bg-indigo-950/80 border-b border-indigo-200 dark:border-indigo-800/80 flex flex-wrap items-center justify-between gap-3 shrink-0"
          >
            <div className="flex-1 min-w-[280px]">
              <label className="block text-xs font-bold text-indigo-900 dark:text-indigo-200 mb-1">
                Save active message session to Firestore
              </label>
              <input
                type="text"
                value={customSaveTitle}
                onChange={(e) => setCustomSaveTitle(e.target.value)}
                placeholder={`e.g., ${currentSubject} - ${currentTopic} Study Session`}
                className="w-full px-3 py-1.5 rounded-xl border border-indigo-300 dark:border-indigo-700 bg-white dark:bg-slate-900 text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveCurrentSession();
                  if (e.key === 'Escape') setShowSaveDialog(false);
                }}
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleSaveCurrentSession}
                disabled={isSavingCurrent}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95"
              >
                <Check className="w-4 h-4" />
                {isSavingCurrent ? 'Saving...' : 'Save to Firestore'}
              </button>
              <button
                onClick={() => setShowSaveDialog(false)}
                className="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold transition"
              >
                Cancel
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content Area (Sidebar List + Detail Preview) */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Left Column: Session List */}
        <div className="w-full md:w-5/12 lg:w-4/12 border-r border-slate-200 dark:border-slate-800 flex flex-col bg-white/50 dark:bg-slate-950/40">
          
          {/* Search by Title & Grouping Controls */}
          <div className="p-3 border-b border-slate-200 dark:border-slate-800 space-y-2.5">
            {/* Title Filter Input Box */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-indigo-500 pointer-events-none" />
              <input
                id="session-title-filter-input"
                type="text"
                value={titleFilter}
                onChange={(e) => setTitleFilter(e.target.value)}
                placeholder="Filter sessions by title, topic..."
                className="w-full pl-9 pr-8 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all shadow-sm"
              />
              {titleFilter && (
                <button
                  onClick={() => setTitleFilter('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition"
                  title="Clear title filter"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Grouping Mode Tabs & Counter */}
            <div className="flex items-center justify-between gap-2 pt-0.5">
              <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500 dark:text-slate-400">
                <Layers className="w-3.5 h-3.5 text-indigo-500" />
                <span>Group by:</span>
              </div>
              <div className="flex items-center bg-slate-100 dark:bg-slate-900 p-0.5 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px]">
                <button
                  onClick={() => setGroupingMode('date')}
                  className={cn(
                    "px-2 py-0.5 rounded-md font-bold transition-all",
                    groupingMode === 'date'
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
                  )}
                >
                  Date Range
                </button>
                <button
                  onClick={() => setGroupingMode('topic')}
                  className={cn(
                    "px-2 py-0.5 rounded-md font-bold transition-all",
                    groupingMode === 'topic'
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
                  )}
                >
                  Topic
                </button>
                <button
                  onClick={() => setGroupingMode('all')}
                  className={cn(
                    "px-2 py-0.5 rounded-md font-bold transition-all",
                    groupingMode === 'all'
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
                  )}
                >
                  All
                </button>
              </div>
            </div>

            {/* Subject Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-[11px]">
              <button
                onClick={() => setSelectedSubjectFilter('all')}
                className={cn(
                  "px-2.5 py-1 rounded-lg font-bold whitespace-nowrap transition",
                  selectedSubjectFilter === 'all'
                    ? "bg-indigo-600 text-white shadow-sm"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200"
                )}
              >
                All Subjects ({sessions.length})
              </button>
              {subjectList.map(subj => (
                <button
                  key={subj}
                  onClick={() => setSelectedSubjectFilter(subj)}
                  className={cn(
                    "px-2.5 py-1 rounded-lg font-bold whitespace-nowrap capitalize transition",
                    selectedSubjectFilter.toLowerCase() === subj.toLowerCase()
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200"
                  )}
                >
                  {subj.replace(/_/g, ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Session Cards Scrollable List */}
          <div className="flex-1 overflow-y-auto p-2 space-y-4">
            {loading ? (
              <div className="p-8 text-center flex flex-col items-center justify-center gap-2 text-slate-400">
                <RefreshCw className="w-6 h-6 animate-spin text-indigo-500" />
                <p className="text-xs">Loading sessions from Firestore...</p>
              </div>
            ) : filteredSessions.length === 0 ? (
              <div className="p-8 text-center flex flex-col items-center justify-center gap-3 text-slate-400">
                <div className="p-3 rounded-full bg-slate-100 dark:bg-slate-900">
                  <Folder className="w-8 h-8 text-slate-400" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-300">No matching sessions found</p>
                  <p className="text-xs mt-1 text-slate-500">
                    {titleFilter ? `No sessions matching "${titleFilter}"` : 'Click "Save Current Chat" to create your first Firestore session'}
                  </p>
                </div>
              </div>
            ) : (
              groupedSessions.map(group => {
                if (group.items.length === 0) return null;

                return (
                  <div key={group.key} className="space-y-2">
                    {/* Group Header Badge */}
                    <div className="flex items-center justify-between px-2 py-1">
                      <div className="flex items-center gap-1.5 text-xs font-black tracking-wide text-slate-700 dark:text-slate-300 uppercase">
                        {groupingMode === 'date' ? <Calendar className="w-3.5 h-3.5 text-indigo-500" /> : <Tag className="w-3.5 h-3.5 text-indigo-500" />}
                        <span>{group.label}</span>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                        {group.items.length}
                      </span>
                    </div>

                    {/* Group Items */}
                    <div className="space-y-2">
                      {group.items.map(session => {
                        const isSelected = selectedSessionForPreview?.id === session.id;
                        const isEditing = editingSessionId === session.id;
                        const formattedTime = formatRelativeTime(session.updatedAt || session.createdAt);

                        return (
                          <div
                            key={session.id}
                            onClick={() => setSelectedSessionForPreview(session)}
                            className={cn(
                              "p-3 rounded-2xl border text-left transition-all cursor-pointer relative group",
                              isSelected
                                ? "bg-indigo-500/10 border-indigo-500/40 ring-1 ring-indigo-500/30 shadow-sm"
                                : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700"
                            )}
                          >
                            {/* Top Row: Title or Inline Edit */}
                            <div className="flex items-start justify-between gap-2 mb-1.5">
                              {isEditing ? (
                                <form
                                  onSubmit={(e) => handleSubmitRename(session.id, e)}
                                  className="flex-1 flex items-center gap-1.5"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <input
                                    type="text"
                                    value={editingTitle}
                                    onChange={(e) => setEditingTitle(e.target.value)}
                                    className="w-full px-2 py-1 rounded-lg border border-indigo-500 bg-white dark:bg-slate-950 text-xs font-bold outline-none"
                                    autoFocus
                                    onKeyDown={(e) => {
                                      if (e.key === 'Escape') setEditingSessionId(null);
                                    }}
                                  />
                                  <button
                                    type="submit"
                                    disabled={isRenaming}
                                    className="p-1 rounded-md bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm"
                                    title="Save Title"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingSessionId(null)}
                                    className="p-1 rounded-md bg-slate-200 dark:bg-slate-800 text-slate-500 hover:text-slate-800"
                                    title="Cancel"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </form>
                              ) : (
                                <div className="flex-1 min-w-0">
                                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate flex items-center gap-1.5">
                                    {session.title}
                                  </h4>
                                </div>
                              )}

                              {/* Card Action Icons (Sync, Rename & Explicit Delete with confirmation) */}
                              {!isEditing && (
                                <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 shrink-0">
                                  {/* Quick Single Session Sync Button */}
                                  <button
                                    onClick={(e) => handleSyncSingleSession(session, e)}
                                    disabled={syncingSessionId === session.id}
                                    className="p-1 rounded-md text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition"
                                    title={session.lastSyncedAt ? `Re-sync to Cloud (Last synced: ${formatRelativeTime(session.lastSyncedAt)})` : "Push session to Firestore Cloud"}
                                  >
                                    <CloudUpload className={cn("w-3 h-3", syncingSessionId === session.id && "animate-spin text-emerald-500")} />
                                  </button>

                                  <button
                                    onClick={(e) => handleStartRename(session, e)}
                                    className="p-1 rounded-md text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                    title="Rename session"
                                  >
                                    <Edit3 className="w-3 h-3" />
                                  </button>
                                  
                                  {/* Delete button requiring confirmation dialog */}
                                  <button
                                    onClick={(e) => handleRequestDelete(session, e)}
                                    className="p-1 rounded-md text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                                    title="Delete session from Firestore"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              )}
                            </div>

                            {/* Metadata Badges with Formatted Relative Timestamp & Cloud Sync Indicator */}
                            <div className="flex flex-wrap items-center gap-1.5 mb-1.5 text-[10px]">
                              {session.subject && (
                                <span className="px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold uppercase">
                                  {session.subject.replace(/_/g, ' ')}
                                </span>
                              )}
                              {session.mode && (
                                <span className="px-1.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-medium">
                                  {session.mode}
                                </span>
                              )}

                              {/* Visual Indicator: Last Successful Cloud Sync Time */}
                              {session.lastSyncedAt ? (
                                <span 
                                  className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold border border-emerald-500/20"
                                  title={`Last successful cloud sync: ${new Date(session.lastSyncedAt).toLocaleString()}`}
                                >
                                  <CheckCircle2 className="w-2.5 h-2.5 text-emerald-500" />
                                  <span>Synced {formatRelativeTime(session.lastSyncedAt)}</span>
                                </span>
                              ) : (
                                <span 
                                  className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400 font-semibold border border-amber-500/20"
                                  title="Local cache only - Click sync to push to Firestore Cloud"
                                >
                                  <CloudOff className="w-2.5 h-2.5 text-amber-500" />
                                  <span>Local Only</span>
                                </span>
                              )}
                              
                              {/* Formatted Relative Timestamp Badge */}
                              <span 
                                className="text-indigo-600 dark:text-indigo-400 font-bold ml-auto flex items-center gap-1 bg-indigo-50 dark:bg-indigo-950/80 px-2 py-0.5 rounded-md border border-indigo-100 dark:border-indigo-900/60"
                                title={`Last modified: ${new Date(session.updatedAt || session.createdAt).toLocaleString()}`}
                              >
                                <Clock className="w-2.5 h-2.5" />
                                {formattedTime}
                              </span>
                            </div>

                            {/* Preview Snippet */}
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                              {session.preview || 'No messages snippet'}
                            </p>

                            {/* Bottom row: Message count, explicit Delete button & Load session button */}
                            <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between gap-2">
                              <span className="text-[10px] text-slate-400 font-medium">
                                {session.messageCount || session.messages.length} messages
                              </span>
                              
                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={(e) => handleRequestDelete(session, e)}
                                  className="px-2 py-1 rounded-lg text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-[11px] font-bold transition flex items-center gap-1"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  Delete
                                </button>
                                
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleLoad(session);
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold transition flex items-center gap-1 shadow-sm active:scale-95"
                                >
                                  <Play className="w-2.5 h-2.5 fill-current" />
                                  Load
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Detailed Session Preview & Actions */}
        <div className="flex-1 flex flex-col bg-slate-100/50 dark:bg-slate-900/40 overflow-hidden">
          {selectedSessionForPreview ? (
            <div className="flex-1 flex flex-col h-full overflow-hidden">
              {/* Preview Header */}
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 flex flex-wrap items-center justify-between gap-2 shrink-0">
                <div className="flex-1 min-w-[200px]">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-slate-900 dark:text-slate-100 truncate">
                      {selectedSessionForPreview.title}
                    </h3>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold">
                      {selectedSessionForPreview.messageCount || selectedSessionForPreview.messages.length} msgs
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-1.5 flex-wrap">
                    <span>{selectedSessionForPreview.subject || 'General'}</span>
                    <span>•</span>
                    <span>{selectedSessionForPreview.topic || 'Classroom Study'}</span>
                    <span>•</span>
                    <span className="text-indigo-600 dark:text-indigo-400 font-bold">
                      {formatRelativeTime(selectedSessionForPreview.updatedAt || selectedSessionForPreview.createdAt)}
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      ({new Date(selectedSessionForPreview.updatedAt || selectedSessionForPreview.createdAt).toLocaleString()})
                    </span>
                  </p>

                  {/* Cloud Sync Status Indicator in Detail View */}
                  <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-800/60">
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="font-semibold text-slate-500 dark:text-slate-400">Cloud Sync:</span>
                      {selectedSessionForPreview.lastSyncedAt ? (
                        <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20 text-[11px]" title={`Last Synced: ${new Date(selectedSessionForPreview.lastSyncedAt).toLocaleString()}`}>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                          <span>Synced {formatRelativeTime(selectedSessionForPreview.lastSyncedAt)} ({new Date(selectedSessionForPreview.lastSyncedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20 text-[11px]" title="Local cache only">
                          <CloudOff className="w-3.5 h-3.5 text-amber-500" />
                          <span>Local Cache Only (Not Synced to Firestore)</span>
                        </span>
                      )}
                    </div>

                    <button
                      onClick={(e) => handleSyncSingleSession(selectedSessionForPreview, e)}
                      disabled={syncingSessionId === selectedSessionForPreview.id}
                      className="ml-auto px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-600 dark:text-emerald-400 text-xs font-bold border border-emerald-200 dark:border-emerald-800/60 transition flex items-center gap-1 active:scale-95 shadow-sm"
                      title="Force push this session to Firestore Cloud"
                    >
                      <CloudUpload className={cn("w-3.5 h-3.5", syncingSessionId === selectedSessionForPreview.id && "animate-spin")} />
                      <span>{syncingSessionId === selectedSessionForPreview.id ? 'Syncing...' : 'Sync to Cloud'}</span>
                    </button>
                  </div>
                </div>

                {/* Primary Action Buttons */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => handleRequestDelete(selectedSessionForPreview, e)}
                    className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 text-xs font-bold border border-rose-200 dark:border-rose-900/60 transition flex items-center gap-1.5 active:scale-95"
                    title="Delete session"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete
                  </button>

                  <button
                    onClick={(e) => handleExportSession(selectedSessionForPreview, 'markdown', e)}
                    className="p-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold border border-slate-200 dark:border-slate-700 transition flex items-center gap-1.5 active:scale-95"
                    title="Export as Markdown notes"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Export MD
                  </button>

                  <button
                    onClick={() => handleLoad(selectedSessionForPreview)}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-indigo-500/20 active:scale-95"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    Load Active Session
                  </button>
                </div>
              </div>

              {/* Messages Preview Scroll Feed */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {selectedSessionForPreview.messages.map((msg, idx) => {
                  const isAi = msg.sender === 'ai';
                  return (
                    <div
                      key={msg.id || idx}
                      className={cn(
                        "flex gap-3 max-w-2xl",
                        isAi ? "mr-auto" : "ml-auto flex-row-reverse"
                      )}
                    >
                      <div className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold shadow-sm",
                        isAi 
                          ? "bg-indigo-600 text-white" 
                          : "bg-slate-300 dark:bg-slate-700 text-slate-800 dark:text-slate-200"
                      )}>
                        {isAi ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                      </div>

                      <div className={cn(
                        "p-3.5 rounded-2xl text-xs leading-relaxed max-w-[85%]",
                        isAi
                          ? "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 shadow-sm"
                          : "bg-indigo-600 text-white"
                      )}>
                        <div className="flex items-center justify-between gap-2 mb-1 text-[10px] opacity-70">
                          <span className="font-bold">{isAi ? 'Professor Clarity' : 'Student'}</span>
                          <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        <div className="whitespace-pre-wrap font-sans">
                          {msg.content.replace(/<svg[\s\S]*?<\/svg>/g, '[📐 Dynamic Interactive Vector Diagram]')}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
              <MessageSquare className="w-12 h-12 text-slate-300 dark:text-slate-700 mb-3" />
              <h4 className="text-sm font-bold text-slate-600 dark:text-slate-400">Select a session to preview</h4>
              <p className="text-xs mt-1 max-w-sm">
                Choose a conversation on the left to review messages, rename the topic, or load it into your live classroom.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Dialog Modal */}
      <AnimatePresence>
        {sessionToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-start gap-3">
                <div className="p-3 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20 shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-slate-100">
                    Delete Chat Session?
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Are you sure you want to delete this study session from your Firestore cloud database? This action cannot be undone.
                  </p>
                </div>
              </div>

              {/* Session Info Preview Card */}
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                <div className="font-bold text-slate-800 dark:text-slate-200 truncate">
                  {sessionToDelete.title}
                </div>
                <div className="text-[11px] text-slate-500 flex items-center gap-2">
                  <span>{sessionToDelete.subject || 'General'}</span>
                  <span>•</span>
                  <span>{sessionToDelete.messageCount || sessionToDelete.messages.length} messages</span>
                  <span>•</span>
                  <span>{formatRelativeTime(sessionToDelete.updatedAt || sessionToDelete.createdAt)}</span>
                </div>
              </div>

              {/* Confirmation Action Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  onClick={() => setSessionToDelete(null)}
                  disabled={isDeleting}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmDelete}
                  disabled={isDeleting}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-rose-600/30 active:scale-95"
                >
                  {isDeleting ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Trash2 className="w-3.5 h-3.5" />
                  )}
                  {isDeleting ? 'Deleting...' : 'Yes, Delete Session'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
