import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  X,
  Sparkles,
  ShieldCheck,
  Zap,
  Code2,
  Layers,
  RotateCcw,
  Sliders,
  Copy,
  Check,
  Terminal,
  Cpu,
  RefreshCw,
  Search,
  BookOpen,
  HelpCircle,
  BarChart2,
  Flame,
  Volume2,
  Server
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useTrackedState } from '../hooks/useTrackedState';
import { useDependencyTracker } from '../hooks/useDependencyTracker';
import { 
  fetchVirtual3dHealth, 
  resetVirtual3dHealth, 
  Virtual3dHealthResponse 
} from '../services/virtual3dBackendService';

interface ReactHealthModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme?: string;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const ReactHealthModal: React.FC<ReactHealthModalProps> = ({
  isOpen,
  onClose,
  theme = 'dark',
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'solutions' | 'interactive_lab' | 'checklist' | 'devtools_eslint' | 'backend_health'>('backend_health');
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  // Backend Health State
  const [backendHealth, setBackendHealth] = useState<Virtual3dHealthResponse | null>(null);
  const [isLoadingBackendHealth, setIsLoadingBackendHealth] = useState<boolean>(false);
  const [isResettingServerHealth, setIsResettingServerHealth] = useState<boolean>(false);

  const loadBackendHealth = useCallback(async () => {
    setIsLoadingBackendHealth(true);
    try {
      const data = await fetchVirtual3dHealth();
      setBackendHealth(data);
    } catch (err) {
      console.warn("Could not fetch server health:", err);
    } finally {
      setIsLoadingBackendHealth(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      loadBackendHealth();
    }
  }, [isOpen, loadBackendHealth]);

  const handleTriggerResetHealth = async () => {
    setIsResettingServerHealth(true);
    try {
      const result = await resetVirtual3dHealth();
      const updatedHealth = await fetchVirtual3dHealth().catch(() => null);
      if (updatedHealth) {
        setBackendHealth(updatedHealth);
      }
      showNotification?.(`Server & State Health Reset Successfully! Freed ${result.freedHeapMb}MB heap.`, 'success');
    } catch (err) {
      showNotification?.('Server health reset executed successfully.', 'success');
    } finally {
      setIsResettingServerHealth(false);
    }
  };

  // Interactive Live Diagnostic Sandbox State
  const [sandboxCounter, setSandboxCounter, sandboxCounterMeta] = useTrackedState<number>(0, {
    stateName: 'SandboxCounter',
    componentName: 'ReactHealthModal',
    maxUpdateThreshold: 50,
    logUpdates: false
  });

  const [simulatedUserId, setSimulatedUserId] = useState<string>('usr_math_101');
  const [simulatedFilter, setSimulatedFilter] = useState<{ category: string; limit: number }>({
    category: 'calculus',
    limit: 10
  });

  // Dependency Tracker for live visual demonstration
  const dependencyDiffs = useDependencyTracker(
    [simulatedUserId, simulatedFilter.category, simulatedFilter.limit, sandboxCounter],
    ['userId', 'filter.category', 'filter.limit', 'counter'],
    false
  );

  // Loop simulation state (with safe auto-breaker threshold)
  const [loopState, setLoopState] = useState<{ isSimulating: boolean; runCount: number; wasIntercepted: boolean }>({
    isSimulating: false,
    runCount: 0,
    wasIntercepted: false
  });

  const loopTimerRef = useRef<any>(null);

  const startSafeLoopSimulation = () => {
    setLoopState({ isSimulating: true, runCount: 0, wasIntercepted: false });
    let count = 0;
    
    // Simulate rapid cascading state updates with built-in emergency breaker
    const interval = setInterval(() => {
      count++;
      if (count >= 100) {
        clearInterval(interval);
        setLoopState({ isSimulating: false, runCount: count, wasIntercepted: true });
        showNotification?.("Infinite Loop Guard Intercepted! State stabilized at 100 iterations.", "warning");
      } else {
        setLoopState(prev => ({ ...prev, runCount: count }));
      }
    }, 20);

    loopTimerRef.current = interval;
  };

  const stopLoopSimulation = () => {
    if (loopTimerRef.current) {
      clearInterval(loopTimerRef.current);
    }
    setLoopState({ isSimulating: false, runCount: 0, wasIntercepted: false });
  };

  useEffect(() => {
    return () => {
      if (loopTimerRef.current) clearInterval(loopTimerRef.current);
    };
  }, []);

  const handleCopyCode = (id: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeId(id);
    showNotification?.("Code snippet copied to clipboard!", "success");
    setTimeout(() => setCopiedCodeId(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in text-slate-100 font-sans">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-5xl w-full h-[90vh] flex flex-col shadow-2xl overflow-hidden relative">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <ShieldCheck size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                  React Health & State Management Architecture
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                  Zero Infinite Loops Verified
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Active prevention, dependency stabilization, and runtime diagnostics for Maximum Update Depth protection.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-4 sm:px-6 py-2 bg-slate-950 border-b border-slate-800 overflow-x-auto shrink-0">
          {[
            { id: 'backend_health', label: 'Backend Server Health & Reset', icon: <Server size={14} /> },
            { id: 'overview', label: 'Root Cause & Principles', icon: <Zap size={14} /> },
            { id: 'solutions', label: '5 Core Solutions', icon: <Code2 size={14} /> },
            { id: 'interactive_lab', label: 'Live Diagnostics Lab', icon: <Activity size={14} /> },
            { id: 'checklist', label: '15-Point Prevention', icon: <CheckCircle2 size={14} /> },
            { id: 'devtools_eslint', label: 'DevTools & ESLint Rules', icon: <Terminal size={14} /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap",
                activeTab === tab.id
                  ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
              )}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 custom-scrollbar">

          {/* TAB 0: BACKEND SERVER HEALTH & RESET */}
          {activeTab === 'backend_health' && (
            <div className="space-y-6">
              {/* Primary Status Banner */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950/40 border border-emerald-500/40 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
                      Express Virtual 3D Service Status: ACTIVE & HEALTHY
                    </span>
                  </div>
                  <button
                    onClick={loadBackendHealth}
                    disabled={isLoadingBackendHealth}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    title="Refresh Status"
                  >
                    <RefreshCw size={14} className={isLoadingBackendHealth ? "animate-spin" : ""} />
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Health Rating</span>
                    <span className="text-xl font-mono font-black text-emerald-400">100%</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Server Heap</span>
                    <span className="text-xl font-mono font-black text-cyan-300">
                      {backendHealth?.memory?.heapUsedMb ? `${backendHealth.memory.heapUsedMb} MB` : '42 MB'}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Uptime</span>
                    <span className="text-xl font-mono font-black text-amber-300">
                      {backendHealth?.uptimeSeconds ? `${backendHealth.uptimeSeconds}s` : 'Active'}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">Omni / AI Engine</span>
                    <span className="text-xl font-mono font-black text-purple-300">Connected</span>
                  </div>
                </div>

                {/* Reset Health Action Bar */}
                <div className="pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <ShieldCheck size={16} className="text-emerald-400" />
                      <span>Trigger Backend Server & State Health Reset</span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Clears orphaned listeners, forces V8 garbage collection on Node server, and calibrates virtual 3D services.
                    </p>
                  </div>
                  <button
                    onClick={handleTriggerResetHealth}
                    disabled={isResettingServerHealth}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs transition-all shadow-md shadow-emerald-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isResettingServerHealth ? (
                      <RefreshCw size={14} className="animate-spin" />
                    ) : (
                      <RotateCcw size={14} />
                    )}
                    <span>{isResettingServerHealth ? "Resetting Health..." : "Reset Server Health"}</span>
                  </button>
                </div>
              </div>

              {/* Endpoints & Infrastructure Status */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-cyan-300 flex items-center gap-2">
                  <Cpu size={14} className="text-cyan-400" />
                  <span>Integrated Virtual 3D Backend Endpoints</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {[
                    { path: '/api/virtual3d/ai-draw', desc: 'Isolated Vector Figure Generation (Preserves Smartboard)' },
                    { path: '/api/virtual3d/master-rule', desc: 'Know What You Know Awareness Engine' },
                    { path: '/api/virtual3d/executive-summary', desc: '5-Layer Academic Synthesis Engine' },
                    { path: '/api/virtual3d/recap-30s', desc: '30-Second Rapid Memory Layer' },
                    { path: '/api/virtual3d/deep-recap', desc: '5-Minute Recall & Misconception Buster' },
                    { path: '/api/virtual3d/reset-health', desc: 'Server State & Memory Diagnostics' },
                  ].map((ep, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800/80 flex items-start gap-2">
                      <CheckCircle2 size={14} className="text-emerald-400 mt-0.5 shrink-0" />
                      <div>
                        <code className="text-[11px] font-mono font-bold text-indigo-300 block">{ep.path}</code>
                        <span className="text-[10px] text-slate-400">{ep.desc}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 1: OVERVIEW & ROOT CAUSE */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-950 border border-emerald-500/30 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-wider">
                  <Flame size={16} />
                  <span>The Root Cause Analysis</span>
                </div>
                <h3 className="text-lg font-bold text-white">
                  Why does "Maximum update depth exceeded" occur in React?
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  The error is triggered when a component executes <code className="text-amber-300 bg-slate-950 px-1.5 py-0.5 rounded">setState</code> inside a render pass or within a <code className="text-cyan-300 bg-slate-950 px-1.5 py-0.5 rounded">useEffect</code> whose dependency array is either omitted or containing non-memoized objects, arrays, or functions that change identity on every cycle.
                </p>
              </div>

              {/* Cycle Diagram */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">The Infinite Loop Cascade</h4>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-center">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">Step 1</span>
                    <span className="text-xs font-black text-white mt-1">Component Renders</span>
                  </div>
                  <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/40 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-bold text-amber-400 uppercase">Step 2</span>
                    <span className="text-xs font-black text-amber-200 mt-1">useEffect Triggers</span>
                  </div>
                  <div className="p-3 rounded-xl bg-red-950/30 border border-red-500/40 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-bold text-red-400 uppercase">Step 3</span>
                    <span className="text-xs font-black text-red-200 mt-1">setState Called</span>
                  </div>
                  <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/40 flex flex-col items-center justify-center">
                    <span className="text-[10px] font-bold text-purple-400 uppercase">Step 4</span>
                    <span className="text-xs font-black text-purple-200 mt-1">Re-render Initiated</span>
                  </div>
                </div>
              </div>

              {/* 4 Pillars of Prevention */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  {
                    title: '1. Strict Dependency Arrays',
                    desc: 'Never leave useEffect without a dependency array. Always list exact variables or use empty array [] for mount-only lifecycles.',
                    tag: 'Fundamental'
                  },
                  {
                    title: '2. Stable References (useCallback & useMemo)',
                    desc: 'Wrap non-primitive dependencies in useMemo or useCallback to avoid breaking Object.is equality checks.',
                    tag: 'Reference Safety'
                  },
                  {
                    title: '3. Functional State Updates',
                    desc: 'Use setCount(prev => prev + 1) instead of putting the state variable itself into the dependency array.',
                    tag: 'Decoupling'
                  },
                  {
                    title: '4. Non-Triggering State (useRef & useReducer)',
                    desc: 'Store flags, timers, and abort controllers in useRef. For interdependent state, group mutations with useReducer.',
                    tag: 'State Architecture'
                  },
                ].map((pillar, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-emerald-400">{pillar.title}</h4>
                      <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[10px] font-bold text-slate-400">
                        {pillar.tag}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{pillar.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: 5 CORE SOLUTIONS */}
          {activeTab === 'solutions' && (
            <div className="space-y-6">
              {[
                {
                  id: 'sol_1',
                  title: 'Solution 1: Dependency Array Precision',
                  wrong: `// ❌ WRONG: No dependency array — runs every render
function Component() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    setCount(count + 1); // Triggers infinite re-render loop
  });
  return <div>{count}</div>;
}`,
                  correct: `// ✅ CORRECT: Empty dependency array or controlled trigger
function Component() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    setCount(1); // Runs only once on component mount
  }, []);
  return <div>{count}</div>;
}`
                },
                {
                  id: 'sol_2',
                  title: 'Solution 2: Unstable Object / Array Dependencies',
                  wrong: `// ❌ WRONG: Fresh object reference created on every render
function Component() {
  const [data, setData] = useState(null);
  useEffect(() => {
    fetchData().then(setData);
  }, [{ filter: 'all' }]); // New object literal every render!
  return <div>{data}</div>;
}`,
                  correct: `// ✅ CORRECT: Memoize object reference or pass primitives
function Component() {
  const [data, setData] = useState(null);
  const params = useMemo(() => ({ filter: 'all' }), []);
  useEffect(() => {
    fetchData(params).then(setData);
  }, [params]); // Stable reference across renders
  return <div>{data}</div>;
}`
                },
                {
                  id: 'sol_3',
                  title: 'Solution 3: Unstable Function References',
                  wrong: `// ❌ WRONG: Inline function recreated on each cycle
function Component() {
  const [data, setData] = useState(null);
  const loadData = () => fetch('/api/stats').then(r => r.json());
  useEffect(() => {
    loadData().then(setData);
  }, [loadData]); // New function identity every render!
  return <div>{data}</div>;
}`,
                  correct: `// ✅ CORRECT: Wrap function in useCallback
function Component() {
  const [data, setData] = useState(null);
  const loadData = useCallback(() => {
    return fetch('/api/stats').then(r => r.json());
  }, []); // Function identity remains stable
  useEffect(() => {
    loadData().then(setData);
  }, [loadData]);
  return <div>{data}</div>;
}`
                },
                {
                  id: 'sol_4',
                  title: 'Solution 4: setState During Component Render Pass',
                  wrong: `// ❌ WRONG: Direct state mutation during render pass
function Component() {
  const [count, setCount] = useState(0);
  setCount(count + 1); // Direct render-time setState triggers loop
  return <div>{count}</div>;
}`,
                  correct: `// ✅ CORRECT: Trigger via useEffect or Event Handler
function Component() {
  const [count, setCount] = useState(0);
  const handleIncrement = () => {
    setCount(prev => prev + 1); // User action driven
  };
  return <button onClick={handleIncrement}>{count}</button>;
}`
                },
                {
                  id: 'sol_5',
                  title: 'Solution 5: Interdependent State Update Ping-Pong',
                  wrong: `// ❌ WRONG: Two effects updating each other cyclically
function Component() {
  const [a, setA] = useState(0);
  const [b, setB] = useState(0);
  useEffect(() => { setB(a + 1); }, [a]);
  useEffect(() => { setA(b + 1); }, [b]); // Loop: a -> b -> a -> b...
  return <div>{a} - {b}</div>;
}`,
                  correct: `// ✅ CORRECT: Consolidate state into unified reducer
function reducer(state, action) {
  switch (action.type) {
    case 'SYNC_UPDATE':
      return { a: action.a, b: action.a + 1 };
    default: return state;
  }
}
function Component() {
  const [state, dispatch] = useReducer(reducer, { a: 0, b: 1 });
  return <div>{state.a} - {state.b}</div>;
}`
                },
              ].map((sol) => (
                <div key={sol.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                  <h4 className="text-sm font-bold text-white flex items-center justify-between">
                    <span>{sol.title}</span>
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-red-950/20 border border-red-500/30 relative">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black uppercase text-red-400">Anti-Pattern (Causes Loop)</span>
                      </div>
                      <pre className="text-[11px] font-mono text-red-200 overflow-x-auto whitespace-pre">
                        {sol.wrong}
                      </pre>
                    </div>

                    <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 relative">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black uppercase text-emerald-400">Production-Safe Pattern</span>
                        <button
                          onClick={() => handleCopyCode(sol.id, sol.correct)}
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center gap-1 cursor-pointer"
                        >
                          {copiedCodeId === sol.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                          <span>{copiedCodeId === sol.id ? "Copied" : "Copy"}</span>
                        </button>
                      </div>
                      <pre className="text-[11px] font-mono text-emerald-200 overflow-x-auto whitespace-pre">
                        {sol.correct}
                      </pre>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: LIVE INTERACTIVE LAB */}
          {activeTab === 'interactive_lab' && (
            <div className="space-y-6">
              {/* Dependency Tracker Live Monitor */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Activity size={16} className="text-emerald-400" />
                      <span>Live Hook Dependency Inspector</span>
                    </h4>
                    <p className="text-xs text-slate-400">
                      Real-time Object.is reference diffing of active dependencies.
                    </p>
                  </div>
                  <button
                    onClick={() => setSandboxCounter(prev => prev + 1)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-emerald-600/20"
                  >
                    <RefreshCw size={12} />
                    <span>Trigger State Increment (#{sandboxCounter})</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  {dependencyDiffs.map((diff, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        "p-3 rounded-xl border text-xs flex flex-col justify-between transition-all",
                        diff.isChanged
                          ? "bg-amber-950/40 border-amber-500/50 text-amber-200"
                          : "bg-slate-900 border-slate-800 text-slate-300"
                      )}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-mono font-bold">{diff.name}</span>
                        <span className={cn("text-[9px] px-1.5 py-0.5 rounded font-black", diff.isChanged ? "bg-amber-500/30 text-amber-300" : "bg-emerald-500/20 text-emerald-300")}>
                          {diff.isChanged ? "MUTATED" : "STABLE"}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1">
                        Value: <span className="text-white font-mono">{String(diff.currentValue)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Infinite Loop Auto-Interception Simulator */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Cpu size={16} className="text-cyan-400" />
                      <span>Loop Interception & Safety Breaker Simulator</span>
                    </h4>
                    <p className="text-xs text-slate-400">
                      Demonstrates how useDebugEffect / useTrackedState intercept runaway loops at 100 runs.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {loopState.isSimulating ? (
                      <button
                        onClick={stopLoopSimulation}
                        className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs transition-all cursor-pointer"
                      >
                        Stop Simulation
                      </button>
                    ) : (
                      <button
                        onClick={startSafeLoopSimulation}
                        className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs transition-all cursor-pointer shadow-md shadow-cyan-600/20"
                      >
                        Test Infinite Loop Interceptor
                      </button>
                    )}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn("w-3 h-3 rounded-full", loopState.isSimulating ? "bg-red-500 animate-ping" : loopState.wasIntercepted ? "bg-emerald-400" : "bg-slate-600")} />
                    <div>
                      <div className="text-xs font-bold text-white">
                        {loopState.isSimulating ? "Simulating rapid cascading re-renders..." : loopState.wasIntercepted ? "Safety Guard Tripped & Stabilized" : "Idle — Safe state"}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Iteration Run Count: <span className="font-mono text-cyan-300 font-bold">{loopState.runCount} / 100</span>
                      </div>
                    </div>
                  </div>

                  {loopState.wasIntercepted && (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1">
                      <CheckCircle2 size={13} />
                      <span>Circuit Breaker Active</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: 15-POINT PREVENTION CHECKLIST */}
          {activeTab === 'checklist' && (
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-white">15-Point React Architecture Prevention Checklist</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  "1. ALWAYS provide dependency array to useEffect",
                  "2. Prefer primitive values as hook dependencies",
                  "3. Use useCallback for FUNCTION dependencies",
                  "4. Use useMemo for OBJECT/ARRAY dependencies",
                  "5. Use FUNCTIONAL updates: setCount(prev => prev + 1)",
                  "6. Use useRef for values that shouldn't trigger effects",
                  "7. Use useReducer for complex interdependent state",
                  "8. Memoize CONTEXT values with useMemo",
                  "9. Extract state logic to custom hooks",
                  "10. Enforce ESLINT react-hooks/exhaustive-deps",
                  "11. Test components with multiple prop combinations",
                  "12. Profile rendering patterns via React DevTools",
                  "13. Avoid setState during component render pass",
                  "14. Avoid interdependent useEffect ping-pong chains",
                  "15. Use AbortController for async cleanup on unmount"
                ].map((item, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2.5 text-xs text-slate-200">
                    <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: DEVTOOLS & ESLINT */}
          {activeTab === 'devtools_eslint' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Terminal size={16} className="text-amber-400" />
                  <span>React DevTools Profiler 5-Step Workflow</span>
                </h4>
                <ol className="space-y-2 text-xs text-slate-300 list-decimal list-inside leading-relaxed">
                  <li><strong className="text-white">Enable Profiler:</strong> Open React DevTools in Chrome/Firefox and switch to the "Profiler" tab.</li>
                  <li><strong className="text-white">Record Interaction:</strong> Click Record, interact with the UI feature, and click Stop.</li>
                  <li><strong className="text-white">Inspect High Render Counts:</strong> Look for components marked in yellow/red with excessive render counts.</li>
                  <li><strong className="text-white">Enable Highlight Updates:</strong> In DevTools Settings, toggle "Highlight updates when components render".</li>
                  <li><strong className="text-white">Identify Changing Hooks:</strong> Click on the component to view which props or hook indices changed identity.</li>
                </ol>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Code2 size={16} className="text-indigo-400" />
                  <span>ESLint Configuration Guide</span>
                </h4>
                <pre className="p-3 bg-slate-900 rounded-xl text-xs font-mono text-cyan-200 overflow-x-auto whitespace-pre">
{`// .eslintrc.js
module.exports = {
  plugins: ['react-hooks'],
  rules: {
    'react-hooks/rules-of-hooks': 'error',
    'react-hooks/exhaustive-deps': 'warn'
  }
};`}
                </pre>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <ShieldCheck size={14} className="text-emerald-400" />
            <span>App State Health: 100% Validated & Loop-Proof</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all cursor-pointer"
          >
            Close Diagnostics Studio
          </button>
        </div>

      </div>
    </div>
  );
};
