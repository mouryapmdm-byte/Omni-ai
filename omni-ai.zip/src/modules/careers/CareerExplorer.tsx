import React, { useState } from 'react';
import { 
  careerDatabase, Career 
} from './careerDatabase';
import { 
  generateCareerRecommendations, CareerRecommendation 
} from './recommendationEngine';
import { 
  Compass, DollarSign, TrendingUp, Sparkles, BookOpen, GraduationCap, ChevronRight, CheckCircle2, UserCheck, Star, Award, Landmark, Building, MapPin, Settings, AlertCircle, Sparkle, Target, Brain, ArrowUpRight
} from 'lucide-react';

interface CareerExplorerProps {
  theme: 'light' | 'dark';
  onEnroll: (careerTitle: string) => void;
  onNavigateToTab?: (tabId: 'explorer' | 'videos' | 'college') => void;
}

// Full 10-skill mappings for each curriculum chapter, satisfying Requirement 2 (Skill Mapping)
export const chapterSkillsMap: Record<string, string[]> = {
  physics_vectors: [
    'Resolving Multi-directional forces',
    'Orthogonal Vector Decomposition',
    '3D Spatial Coordinate Transformations',
    'Vector Cross Product Calculations',
    'Dot Product Scaling & Alignments',
    'Rotational Torque Calculations',
    'Unit Vector Matrix Modeling',
    'Static Equilibrium Balancing',
    'Cartesian Navigation Grid Layouts',
    'Stress Vector Tensor Analysis'
  ],
  physics_kinematics: [
    'Velocity Instantaneous Derivatives',
    'Fluid-Drag Coefficient Profiling',
    'Constant Acceleration Equation Modeling',
    'Braking Distance and Safety Calculations',
    'Atmospheric Trajectory Vector Projection',
    'Projectile Launch Angle Optimization',
    'Absolute Motion Tracking & Calibration',
    'Differential Acceleration Velocities',
    'Relative Frame Reference Transforms',
    'Impact Force and Momentum Predictions'
  ],
  math_vectors: [
    'Linear Matrix Coordinate Scaling',
    'Eigenvalue & Eigenvector Computations',
    'High-Dimensional State Space Reduction',
    'Rigid-Body Rotation Quaternion Algebra',
    'Linear Independent Vector Spans',
    'Scalar Product Angle Projections',
    'Vector Direction Angle Isolation',
    '3D Vertex Geometry Mesh Plotting',
    'Vector Gradient Field Formulations',
    'Geometric Proof Synthesis Systems'
  ],
  biology_photosynthesis: [
    'Light-Dependent Photon Capture Calculations',
    'Calvin Cycle Metabolic Pathway Mapping',
    'Electron Transport Chain Kinetic Rates',
    'Chloroplast Genetic Sequence Isolation',
    'Bio-chemical Redox Reaction Formulas',
    'Cellular Respiration Stoichiometry Ratios',
    'ADP-ATP Phosphorylation Efficiency',
    'Enzymatic Catalyst Speed Coefficients',
    'Carbon Sequestration Biomass Metrics',
    'Plant-Tissue Microscopic Structure Analysis'
  ],
  chem_reactions: [
    'Organic Condensation Synthesis Pathway Maps',
    'Stochiometric Yield & Limit Reactants',
    'Activational Energy Barrier Configurations',
    'Stereochemical Isomer 3D Structural Modeling',
    'Peptide Polymer Interlocking Alignments',
    'Acid-Base Titration pH Buffer Curves',
    'Catalytic Reaction Acceleration Ratios',
    'Chemical Equilibrium Constant K-eq Equations',
    'Precision Laboratory Micropipetting Protocols',
    'Spectrometry Molecular Mass Determination'
  ],
  math_calculus_diff: [
    'Ordinary Differential Equations (ODEs) Derivation',
    'Logistic Population Carrying Capacity Formulas',
    'Dynamic Rate of Change Tangent Calculations',
    'Gradient Descent Optimizing Slopes',
    'Partial Derivatives & Options Greeks Math',
    'Taylor Series Expansion Approximations',
    'Runge-Kutta ODE Numerical Estimators',
    'Physical Boundary Condition Fitments',
    'Euler Iteration Step Approximations',
    'Exponential Compounding Growth Forecasts'
  ],
  math_trig: [
    'Sinusoidal Wave Amplitude Equations',
    'Harmonic Frequency Signal Modeling',
    'Inverse Trig Coordinate Solvers (atan2)',
    'Three-Point Geolocation Triangulation',
    'Phase Shift & Wave Interference Tuning',
    'Fourier Series Sine Wave Transformations',
    'Polar-to-Cartesian Coordinate Mapping',
    'Angular Frequency Waveform Scaling',
    'Sinusoidal Altitude Calculation Algorithms',
    'Cyclical Peak-and-Valley Trend Forecasting'
  ],
  chem_thermo: [
    'Gibbs Free Energy Spontaneity (ΔG = ΔH - TΔS)',
    'Enthalpy of Formation Reaction Heat Profiles',
    'Thermal Conduction Dissipation Vectors',
    'Reversible Carnot Cycle Mechanical Efficiency',
    'Entropy Decay Rate Estimations',
    'Microwave RF Heat Sink Architecture Designs',
    'Bomb Calorimetry Heat Capacity Measures',
    'Thermodynamic Transition State Coordinates',
    'Temperature Gradient Interface Profiles',
    'Kinetic Molecule Collision Energy Thresholds'
  ]
};

export const CareerExplorer: React.FC<CareerExplorerProps> = ({ theme, onEnroll, onNavigateToTab }) => {
  const [selectedCareer, setSelectedCareer] = useState<Career | null>(careerDatabase[0]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Quiz preference state with grades support for personal touch
  const [favoriteSubjects, setFavoriteSubjects] = useState<string[]>(['Physics', 'Mathematics']);
  const [interests, setInterests] = useState<string[]>(['coding', 'space']);
  const [grades, setGrades] = useState<Record<string, number>>({
    Physics: 90,
    Chemistry: 80,
    Biology: 75,
    Mathematics: 92,
    'Computer Science': 88
  });
  const [recommendations, setRecommendations] = useState<CareerRecommendation[]>([]);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [activeChapterFilter, setActiveChapterFilter] = useState<string>('all');

  const toggleSubject = (sub: string) => {
    setFavoriteSubjects(prev => 
      prev.includes(sub) ? prev.filter(s => s !== sub) : [...prev, sub]
    );
  };

  const toggleInterest = (interest: string) => {
    setInterests(prev => 
      prev.includes(interest) ? prev.filter(i => i !== interest) : [...prev, interest]
    );
  };

  const handleGradeChange = (subject: string, val: number) => {
    setGrades(prev => ({ ...prev, [subject]: val }));
  };

  const runRecommendations = () => {
    // Format grades to pass to the engine
    const performanceData = Object.entries(grades).map(([sub, score]) => ({
      subject: sub,
      score
    }));
    const recs = generateCareerRecommendations('current_user', favoriteSubjects, interests, performanceData);
    setRecommendations(recs);
    setQuizSubmitted(true);
    
    // Automatically select the top recommended career if present
    if (recs.length > 0) {
      const topCareer = careerDatabase.find(c => c.id === recs[0].careerId);
      if (topCareer) setSelectedCareer(topCareer);
    }
  };

  // Filter careers based on search input and active chapter filter
  const filteredCareers = careerDatabase.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.keySkills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          c.requiredSubjects.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesChapter = activeChapterFilter === 'all' || 
                           c.chapterConnections.some(conn => conn.chapterId === activeChapterFilter);
    
    return matchesSearch && matchesChapter;
  });

  return (
    <div className="space-y-6">
      
      {/* Quiz Guidance Panel */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 border border-indigo-900/40 rounded-3xl p-6 space-y-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-400 animate-pulse" />
              Syllabus-to-Career Matchmaking Engine
            </h3>
            <p className="text-xs text-slate-400 max-w-xl">
              Specify your subject interest levels and current class performance to map your curriculum strengths directly into highly accurate, high-demand 2026+ technology careers.
            </p>
          </div>
          <span className="text-[10px] font-mono font-bold tracking-widest text-indigo-400 bg-indigo-950/80 border border-indigo-800/80 px-3 py-1 rounded-full uppercase shrink-0">
            Powered by Stochastic Scoring
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
          {/* Favorite Subjects Selector */}
          <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-2xl space-y-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-sky-400" />
              1. Favorite Subjects
            </span>
            <div className="flex flex-wrap gap-1.5">
              {['Physics', 'Chemistry', 'Biology', 'Mathematics', 'Computer Science'].map((sub) => {
                const active = favoriteSubjects.includes(sub);
                return (
                  <button
                    key={sub}
                    type="button"
                    onClick={() => toggleSubject(sub)}
                    className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-semibold transition ${
                      active 
                        ? 'bg-sky-500/20 border-sky-500 text-sky-400 shadow-md shadow-sky-500/5' 
                        : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    {sub}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Interests Selector */}
          <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-2xl space-y-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-emerald-400" />
              2. Areas of Passion
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'coding', label: 'Software & Algos' },
                { id: 'space', label: 'Space & Orbit' },
                { id: 'healthcare', label: 'Biotech & Medicine' },
                { id: 'environment', label: 'Climate & Solar' },
                { id: 'building', label: 'Hardware & CAD' },
                { id: 'math_puzzles', label: 'Math Formulas' }
              ].map((item) => {
                const active = interests.includes(item.id);
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => toggleInterest(item.id)}
                    className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-semibold transition ${
                      active 
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 shadow-md shadow-emerald-500/5' 
                        : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Academic Performance inputs */}
          <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-2xl space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Brain className="w-3.5 h-3.5 text-indigo-400" />
              3. Average Classroom Marks
            </span>
            <div className="space-y-2 max-h-[110px] overflow-y-auto pr-1">
              {['Physics', 'Mathematics', 'Chemistry', 'Biology'].map((subject) => (
                <div key={subject} className="flex items-center justify-between gap-3">
                  <span className="text-[10px] font-medium text-slate-400 w-20 truncate">{subject}</span>
                  <input
                    type="range"
                    min="50"
                    max="100"
                    value={grades[subject] || 80}
                    onChange={(e) => handleGradeChange(subject, parseInt(e.target.value))}
                    className="w-24 accent-indigo-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-[10px] font-mono text-indigo-400 font-bold w-6 text-right">
                    {grades[subject]}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-slate-800/80 pt-4 gap-4">
          <p className="text-[10px] text-slate-500 leading-normal max-w-md">
            * Note: This engine dynamically calculates matching points by correlating course vectors and your scores with global hiring metrics for specialized hardware, aerospace, and medical engineering projects.
          </p>
          <button
            onClick={runRecommendations}
            className="bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-500 hover:opacity-90 text-white font-bold py-2 px-6 rounded-xl text-xs transition shadow-lg shrink-0 flex items-center gap-1.5"
          >
            <Sparkle className="w-3.5 h-3.5 animate-spin-slow" />
            Calculate Tailored Career Path
          </button>
        </div>
      </div>

      {/* Main split explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left list Panel */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 space-y-4 shadow-xl">
            
            {/* Catalog Filter controls */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">
                  {quizSubmitted ? 'Top Alignments' : 'Career Index'}
                </span>
                <span className="text-[10px] text-indigo-400 font-mono">
                  {filteredCareers.length} Found
                </span>
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search titles, subjects, or skills..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 placeholder:text-slate-600 font-medium"
              />
              
              {/* Chapter filter selector */}
              <div className="space-y-1">
                <label className="text-[9px] text-slate-500 font-mono uppercase tracking-wider block">Filter by Active Chapter</label>
                <select
                  value={activeChapterFilter}
                  onChange={(e) => setActiveChapterFilter(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">-- Show All Chapters --</option>
                  <option value="physics_vectors">Physics: Vectors</option>
                  <option value="physics_kinematics">Physics: Kinematics</option>
                  <option value="math_vectors">Mathematics: Vectors</option>
                  <option value="math_trig">Mathematics: Trigonometry</option>
                  <option value="math_calculus_diff">Mathematics: Calculus & Differential Equations</option>
                  <option value="biology_photosynthesis">Biology: Photosynthesis</option>
                  <option value="chem_reactions">Chemistry: Organic Reactions</option>
                  <option value="chem_thermo">Chemistry: Thermodynamics</option>
                </select>
              </div>
            </div>

            {/* List entries */}
            {quizSubmitted && recommendations.length > 0 ? (
              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                {recommendations.map((rec) => {
                  const career = careerDatabase.find(c => c.id === rec.careerId);
                  if (!career) return null;
                  const active = selectedCareer?.id === career.id;

                  return (
                    <div
                      key={rec.careerId}
                      onClick={() => setSelectedCareer(career)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer flex justify-between items-center ${
                        active
                          ? 'bg-indigo-950/20 border-indigo-500 shadow-md shadow-indigo-500/5'
                          : 'bg-slate-950 border-slate-950 hover:border-slate-800'
                      }`}
                    >
                      <div className="space-y-0.5 overflow-hidden">
                        <h5 className="text-xs font-bold text-white truncate">{career.title}</h5>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[9px] font-mono text-slate-400 capitalize bg-slate-900 border border-slate-800 px-1 rounded truncate">
                            {career.growthOutlook} Growth
                          </span>
                        </div>
                      </div>
                      <span className="text-[11px] font-bold text-indigo-400 bg-indigo-950/50 border border-indigo-900/60 px-2 py-0.5 rounded font-mono shrink-0">
                        {rec.matchScore}%
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                {filteredCareers.map((career) => {
                  const active = selectedCareer?.id === career.id;
                  return (
                    <div
                      key={career.id}
                      onClick={() => setSelectedCareer(career)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex justify-between items-center ${
                        active
                          ? 'bg-indigo-950/20 border-indigo-500 shadow-md shadow-indigo-500/5'
                          : 'bg-slate-950 border-slate-950 hover:border-slate-800'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <h5 className="text-xs font-bold text-white">{career.title}</h5>
                        <span className="text-[9px] text-slate-500 font-mono">
                          {career.requiredSubjects.slice(0, 2).join(' • ')}
                        </span>
                      </div>
                      <span className={`text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                        career.growthOutlook === 'high'
                          ? 'bg-emerald-950/20 border border-emerald-900 text-emerald-400'
                          : 'bg-amber-950/20 border border-amber-900 text-amber-400'
                      }`}>
                        {career.growthOutlook}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Details Panel */}
        {selectedCareer && (
          <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded-3xl p-6 space-y-6 shadow-2xl relative overflow-hidden">
            <div className="absolute right-0 top-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>
            
            {/* Header Title bar */}
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-slate-800/80 pb-5">
              <div className="space-y-2 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  {selectedCareer.requiredSubjects.map((sub, index) => (
                    <span key={index} className="text-[9px] font-mono text-sky-400 font-bold uppercase bg-sky-950/40 border border-sky-900/60 px-2 py-0.5 rounded">
                      {sub}
                    </span>
                  ))}
                  <span className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded border ${
                    selectedCareer.growthOutlook === 'high' 
                      ? 'bg-emerald-950/20 border-emerald-900 text-emerald-400' 
                      : 'bg-amber-950/20 border-amber-900 text-amber-400'
                  }`}>
                    {selectedCareer.growthOutlook} growth outlook
                  </span>
                </div>
                <h3 className="text-2xl font-extrabold text-white tracking-tight leading-none">{selectedCareer.title}</h3>
                <p className="text-slate-400 text-xs leading-relaxed font-medium">{selectedCareer.description}</p>
              </div>

              {/* Salary card */}
              <div className="bg-slate-900/60 border border-slate-800/80 p-4 rounded-2xl shrink-0 text-center space-y-1 w-full md:w-auto">
                <span className="text-[10px] font-mono text-slate-500 uppercase block tracking-wider">Median Industry Salary</span>
                <span className="text-lg font-extrabold text-emerald-400 font-mono block">
                  ${selectedCareer.avgSalaryRange.min.toLocaleString()} - ${selectedCareer.avgSalaryRange.max.toLocaleString()}
                </span>
                <span className="text-[9px] text-slate-500 block font-mono font-bold uppercase tracking-widest">{selectedCareer.avgSalaryRange.currency} / Year</span>
              </div>
            </div>

            {/* If recommended, show matching reasons */}
            {quizSubmitted && recommendations.some(r => r.careerId === selectedCareer.id) && (
              <div className="bg-indigo-950/20 border border-indigo-900/40 p-4 rounded-2xl space-y-2">
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider block flex items-center gap-1.5">
                  <Target className="w-4 h-4" />
                  Your Match Blueprint Profile
                </span>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {recommendations.find(r => r.careerId === selectedCareer.id)?.reasons.map((r, i) => (
                    <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                      <span className="text-indigo-400 mt-1">•</span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Concept mappings connection with detailed "This chapter builds these 10 skills" mapping */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Syllabus Chapter Integration</span>
                <span className="text-[10px] font-mono text-slate-500 italic">Click chapter to reveal 10 active skills</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {selectedCareer.chapterConnections.map((conn, idx) => {
                  const skills = chapterSkillsMap[conn.chapterId] || [];
                  return (
                    <div key={idx} className="bg-slate-900/40 border border-slate-800 p-4 rounded-2xl space-y-3 flex flex-col justify-between">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-1.5">
                          <BookOpen className="w-4 h-4 text-sky-400" />
                          <span className="text-xs font-extrabold text-white capitalize">{conn.chapterId.replace(/_/g, ' ')}</span>
                        </div>
                        <p className="text-xs text-slate-400 leading-relaxed italic">"{conn.application}"</p>
                      </div>
                      
                      {/* Interactive skills drawer for this chapter */}
                      {skills.length > 0 && (
                        <div className="border-t border-slate-800/60 pt-3 mt-2">
                          <span className="text-[10px] font-mono font-bold text-sky-400 uppercase tracking-widest block mb-2">
                            🚀 Builds 10 Core Skills:
                          </span>
                          <div className="space-y-1 max-h-[140px] overflow-y-auto pr-1 bg-slate-950/40 p-2 rounded-xl border border-slate-800/40">
                            {skills.map((skill, sIdx) => (
                              <div key={sIdx} className="flex items-center gap-2 text-[10px] text-slate-300 font-medium leading-tight">
                                <span className="w-4 h-4 rounded bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-[8px] border border-emerald-900/40">
                                  0{sIdx+1}
                                </span>
                                <span>{skill}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Key skills built */}
            <div className="space-y-3">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Key Technical Competencies Required</span>
              <div className="flex flex-wrap gap-1.5">
                {selectedCareer.keySkills.map((skill, idx) => (
                  <span key={idx} className="bg-slate-900 border border-slate-800 text-slate-300 text-[10px] font-mono px-2.5 py-1 rounded-xl font-semibold hover:border-slate-700 transition">
                    ✓ {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Academic milestones pathway map */}
            <div className="space-y-3">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Required Academic Education Pathway</span>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {selectedCareer.educationPath.map((edu, idx) => (
                  <div key={idx} className="flex flex-col gap-1.5 bg-slate-900/30 p-3 rounded-xl border border-slate-800/80">
                    <span className="w-5 h-5 rounded-full bg-indigo-500/15 border border-indigo-500/20 text-indigo-400 flex items-center justify-center font-extrabold text-[10px] font-mono">
                      0{idx+1}
                    </span>
                    <span className="text-[11px] text-slate-300 font-bold leading-normal">{edu}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action buttons & Cross-discovery prompts */}
            <div className="flex flex-col md:flex-row gap-3 border-t border-slate-800/80 pt-5">
              <button
                onClick={() => onEnroll(selectedCareer.title)}
                className="flex-1 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold py-3 rounded-xl text-xs transition shadow-lg flex items-center justify-center gap-1.5"
              >
                <Award className="w-4 h-4" />
                Enroll in {selectedCareer.title} Pathway Track
              </button>
              
              {onNavigateToTab && (
                <button
                  onClick={() => onNavigateToTab('videos')}
                  className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white font-bold px-4 py-3 rounded-xl text-xs transition flex items-center justify-center gap-1.5 shrink-0"
                >
                  <span>Watch Vlog Clips</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
