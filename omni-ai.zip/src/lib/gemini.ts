
import { buildStandardOmniStudyContent } from './studyContentGenerator';

export enum Type {
  TYPE_UNSPECIFIED = "TYPE_UNSPECIFIED",
  STRING = "STRING",
  NUMBER = "NUMBER",
  INTEGER = "INTEGER",
  BOOLEAN = "BOOLEAN",
  ARRAY = "ARRAY",
  OBJECT = "OBJECT",
  NULL = "NULL",
}

export enum ThinkingLevel {
  THINKING_LEVEL_UNSPECIFIED = "THINKING_LEVEL_UNSPECIFIED",
  MINIMAL = "MINIMAL",
  LOW = "LOW",
  HIGH = "HIGH",
}

async function safeParseJsonResponse<T = any>(response: Response): Promise<{ success: boolean; data?: T; rawText: string; isHtml: boolean }> {
  try {
    const rawText = await response.text();
    const trimmed = rawText.trim();
    if (trimmed.startsWith("<") || trimmed.toLowerCase().includes("<!doctype")) {
      return { success: false, rawText, isHtml: true };
    }
    const data = JSON.parse(trimmed) as T;
    return { success: true, data, rawText, isHtml: false };
  } catch {
    return { success: false, rawText: "", isHtml: false };
  }
}

export async function generateAIResponse(prompt: string, config?: {
  model?: string;
  systemInstruction?: string;
  history?: { role: string; parts: { text: string }[] }[];
  responseMimeType?: string;
  responseSchema?: any;
  contents?: any;
  thinkingLevel?: ThinkingLevel;
  mode?: string;
  language?: string;
}) {
  const modelsToTry = [
    config?.model || 'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-3.5-flash-lite',
    'gemini-flash-latest'
  ];

  let lastError: any = null;

  for (const modelToUse of modelsToTry) {
    const requestConfig = {
      ...config,
      model: modelToUse
    };

    const maxAttempts = 2;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const response = await fetch("/api/gemini", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "generateText",
            prompt,
            config: requestConfig
          }),
        });
        
        const parsed = await safeParseJsonResponse<{ text?: string; error?: string; details?: string; code?: string }>(response);

        if (!response.ok || !parsed.success) {
          let errorMsg = `Server error ${response.status}`;
          let isTemporary = false;
          let isQuotaExhausted = response.status === 429;
          
          if (parsed.success && parsed.data) {
            errorMsg = parsed.data.error || parsed.data.details || errorMsg;
            if (parsed.data.code === "TEMPORARY_HIGH_DEMAND" || response.status === 503 || response.status === 429 || errorMsg.toLowerCase().includes('quota') || errorMsg.toLowerCase().includes('resource_exhausted')) {
              isTemporary = true;
              if (response.status === 429 || errorMsg.toLowerCase().includes('quota') || errorMsg.toLowerCase().includes('resource_exhausted')) {
                isQuotaExhausted = true;
              }
            }
          } else if (parsed.isHtml || response.status === 502 || response.status === 503 || response.status === 504 || response.status === 404) {
            isTemporary = true;
            errorMsg = "API server connection warming up. Retrying request...";
          }

          if (isQuotaExhausted) {
            // Break out of inner model attempt and try next model or fallback
            break;
          }
          
          if (isTemporary && attempt < maxAttempts) {
            await new Promise((resolve) => setTimeout(resolve, attempt * 600));
            continue;
          }
          throw new Error(errorMsg);
        }
        
        if (parsed.data?.text) {
          return parsed.data.text;
        }
        throw new Error("No text content returned in response");
      } catch (err: any) {
        lastError = err;
        if (err.message && (err.message.toLowerCase().includes('quota') || err.message.toLowerCase().includes('429') || err.message.toLowerCase().includes('resource_exhausted'))) {
          break; // Try next model
        }
        if (attempt < maxAttempts) {
          await new Promise((resolve) => setTimeout(resolve, attempt * 500));
        }
      }
    }
  }

  // Graceful Curriculum Engine Fallback when API quotas/limits are exhausted
  console.warn("API Quota exceeded or connection issue. Activating Master Curriculum Engine fallback.");
  const curriculumFallback = buildStandardOmniStudyContent(prompt, undefined, 'en');
  return `### ⚡ Master Curriculum Engine Fallback (API Quota Safeguard)\n\n*Note: Upstream AI API rate limits or token quotas were reached. The application has instantly activated local curriculum fallback mode to provide zero-disruption study notes, LaTeX equations, and SVG diagrams.*\n\n${curriculumFallback}`;
}

// Minimal implementation of streaming for compatibility
export async function generateAIResponseStream(prompt: string, config: {
  model?: string;
  systemInstruction?: string;
  history?: { role: string; parts: { text: string }[] }[];
}) {
  // For now, we fallback to non-streaming or we could implement SSE
  // But let's keep it simple as a first step
  const text = await generateAIResponse(prompt, config);
  
  // Return an async iterator that yields the whole text as one chunk
  // This is a minimal mock of the stream result
  return (async function* () {
    yield { text };
  })();
}

const speechCache = new Map<string, string>();
const MAX_CACHE_SIZE = 60;

export async function generateSpeech(text: string, voiceName: string = 'Kore') {
  const cacheKey = `${voiceName}:${text.trim().toLowerCase()}`;
  if (speechCache.has(cacheKey)) {
    return speechCache.get(cacheKey)!;
  }

  try {
    const response = await fetch("/api/gemini", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "speech",
        prompt: text,
        voiceName
      }),
    });
    
    const parsed = await safeParseJsonResponse<{ audio?: string; error?: string; details?: string }>(response);
    if (!response.ok || !parsed.success) {
      throw new Error(parsed.data?.details || parsed.data?.error || "Failed to generate speech");
    }
    const data = parsed.data;
    if (data?.audio) {
      if (speechCache.size >= MAX_CACHE_SIZE) {
        const firstKey = speechCache.keys().next().value;
        if (firstKey) speechCache.delete(firstKey);
      }
      speechCache.set(cacheKey, data.audio);
    }
    return data?.audio || null;
  } catch (error) {
    console.error("Failed to generate speech:", error);
    return null;
  }
}

export async function generateGoogleSpeech(text: string, lang: string = 'en') {
  const cacheKey = `google:${lang}:${text.trim().toLowerCase()}`;
  if (speechCache.has(cacheKey)) {
    return speechCache.get(cacheKey)!;
  }

  try {
    const response = await fetch("/api/gemini", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "googleSpeech",
        prompt: text,
        voiceName: lang
      }),
    });
    
    const parsed = await safeParseJsonResponse<{ audio?: string; error?: string; details?: string }>(response);
    if (!response.ok || !parsed.success) {
      throw new Error(parsed.data?.details || parsed.data?.error || "Failed to generate Google speech");
    }
    const data = parsed.data;
    if (data?.audio) {
      if (speechCache.size >= MAX_CACHE_SIZE) {
        const firstKey = speechCache.keys().next().value;
        if (firstKey) speechCache.delete(firstKey);
      }
      speechCache.set(cacheKey, data.audio);
    }
    return data?.audio || null;
  } catch (error) {
    console.error("Failed to generate Google speech:", error);
    return null;
  }
}

export function convertPcmToWav(pcmBase64: string, sampleRate: number = 24000): string {
  const binaryString = atob(pcmBase64);
  const len = binaryString.length;
  const pcmBytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    pcmBytes[i] = binaryString.charCodeAt(i);
  }

  const wavBuffer = new ArrayBuffer(44 + len);
  const view = new DataView(wavBuffer);

  view.setUint32(0, 0x52494646, false); // "RIFF" (Big Endian)
  view.setUint32(4, 36 + len, true); // Little Endian
  view.setUint32(8, 0x57415645, false); // "WAVE" (Big Endian)
  view.setUint32(12, 0x666d7420, false); // "fmt " (Big Endian)
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // 1 = PCM
  view.setUint16(22, 1, true); // 1 = Mono
  view.setUint32(24, sampleRate, true); // 24000
  view.setUint32(28, sampleRate * 2, true); // 24000 * 2 = 48000
  view.setUint16(32, 2, true); // 2
  view.setUint16(34, 16, true); // 16
  view.setUint32(36, 0x64617461, false); // "data" (Big Endian)
  view.setUint32(40, len, true);

  const wavBytes = new Uint8Array(wavBuffer);
  wavBytes.set(pcmBytes, 44);

  let binary = '';
  const chunk = 16384;
  for (let i = 0; i < wavBytes.length; i += chunk) {
    const sub = wavBytes.subarray(i, Math.min(i + chunk, wavBytes.length));
    binary += String.fromCharCode.apply(null, sub as unknown as number[]);
  }
  return btoa(binary);
}

export async function generateImage(prompt: string, config?: {
  aspectRatio?: "1:1" | "3:4" | "4:3" | "9:16" | "16:9" | "21:9" | "2:3" | "3:2" | string;
  quality?: "standard" | "studio";
  drawingStyle?: "hand-drawn" | "clean-academic";
  lightingPreset?: string;
  lightingDirective?: string;
} | string, drawingStyleParam?: "hand-drawn" | "clean-academic"): Promise<string | undefined> {
  try {
    const configObj = typeof config === 'string' ? { aspectRatio: config } : (config || {});
    const style = configObj.drawingStyle || drawingStyleParam;
    const response = await fetch("/api/gemini", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "generateImage",
        prompt,
        drawingStyle: style,
        ...configObj
      }),
    });
    
    const parsed = await safeParseJsonResponse<{ imageUrl?: string }>(response);
    if (!response.ok || !parsed.success) return undefined;
    return parsed.data?.imageUrl || undefined;
  } catch (error) {
    console.error("Failed to generate image:", error);
    return undefined;
  }
}

export async function generateVideo(prompt: string, config?: {
  aspectRatio?: "16:9" | "9:16";
  imageBase64?: string;
  imageMimeType?: string;
}): Promise<string | undefined> {
  try {
    const response = await fetch("/api/gemini", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "generateVideo",
        prompt,
        ...config
      }),
    });
    
    const parsed = await safeParseJsonResponse<{ videoUri?: string }>(response);
    if (!response.ok || !parsed.success) return undefined;
    return parsed.data?.videoUri || undefined;
  } catch (error) {
    console.error("Failed to generate video:", error);
    return undefined;
  }
}

export async function transcribeAudio(audioBase64: string, mimeType: string) {
  const response = await fetch("/api/gemini", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      action: "transcribe",
      audioBase64,
      mimeType
    }),
  });
  
  const parsed = await safeParseJsonResponse<{ text?: string; error?: string }>(response);
  if (!response.ok || !parsed.success) {
    throw new Error(parsed.data?.error || "Failed to transcribe audio");
  }
  
  return parsed.data?.text || "";
}
