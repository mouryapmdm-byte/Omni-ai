import React, { useState, useMemo } from 'react';
import {
  Sliders,
  Layers,
  Activity,
  Zap,
  Eye,
  Info,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  HelpCircle,
  Maximize2,
  Check,
  ChevronRight,
  ChevronLeft,
  Volume2
} from 'lucide-react';
import { cn } from '../lib/utils';
import {
  SchematicBreakdownModel,
  SchematicComponentPart,
  SchematicTechnique,
  SubsystemType,
  SchematicFlowChannel,
  SchematicChallengeQuestion
} from '../types/visualMap';

interface InteractiveSchematicCanvasProps {
  schematicModel: SchematicBreakdownModel;
  selectedTechnique: SchematicTechnique;
  selectedPartId: string | null;
  onSelectPart: (partId: string) => void;
  explodedRatio: number;
  layerDepthIndex: number;
  cutawaySlicePosition: number;
  isGhostXRayActive: boolean;
  isFlowAnimationActive: boolean;
  selectedSubsystemFilter: SubsystemType | 'all';
  onSpeak?: (text: string) => void;
}

export const InteractiveSchematicCanvas: React.FC<InteractiveSchematicCanvasProps> = ({
  schematicModel,
  selectedTechnique,
  selectedPartId,
  onSelectPart,
  explodedRatio,
  layerDepthIndex,
  cutawaySlicePosition,
  isGhostXRayActive,
  isFlowAnimationActive,
  selectedSubsystemFilter,
  onSpeak
}) => {
  const [hoveredPartId, setHoveredPartId] = useState<string | null>(null);
  const [activeFailurePartId, setActiveFailurePartId] = useState<string | null>(null);
  const [assemblyStep, setAssemblyStep] = useState<number>(10);
  const [activeQuizIndex, setActiveQuizIndex] = useState<number>(0);
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [showQuizExplanation, setShowQuizExplanation] = useState<boolean>(false);
  const [showChallengeMode, setShowChallengeMode] = useState<boolean>(false);

  // Flatten all components from sections
  const allComponents = useMemo(() => {
    const list: { part: SchematicComponentPart; sectionLetter: string; sectionName: string }[] = [];
    schematicModel.sections.forEach(sec => {
      sec.components.forEach(comp => {
        list.push({ part: comp, sectionLetter: sec.sectionLetter, sectionName: sec.name });
      });
    });
    return list;
  }, [schematicModel]);

  // Active Selected Part
  const activePartData = useMemo(() => {
    return allComponents.find(c => c.part.id === selectedPartId) || allComponents[0];
  }, [allComponents, selectedPartId]);

  // Subsystem Color Helpers
  const getSubsystemColor = (subsystem: SubsystemType) => {
    switch (subsystem) {
      case 'electrical':
        return { fill: '#ef4444', stroke: '#f87171', glow: 'rgba(239, 68, 68, 0.4)', text: 'text-red-400', bg: 'bg-red-950/70 border-red-500/40' };
      case 'fluid_plumbing':
        return { fill: '#06b6d4', stroke: '#38bdf8', glow: 'rgba(6, 182, 212, 0.4)', text: 'text-cyan-400', bg: 'bg-cyan-950/70 border-cyan-500/40' };
      case 'control_logic':
        return { fill: '#10b981', stroke: '#34d399', glow: 'rgba(16, 185, 129, 0.4)', text: 'text-emerald-400', bg: 'bg-emerald-950/70 border-emerald-500/40' };
      case 'thermal':
        return { fill: '#f59e0b', stroke: '#fbbf24', glow: 'rgba(245, 158, 11, 0.4)', text: 'text-amber-400', bg: 'bg-amber-950/70 border-amber-500/40' };
      case 'structural':
      default:
        return { fill: '#6366f1', stroke: '#818cf8', glow: 'rgba(99, 102, 241, 0.4)', text: 'text-indigo-400', bg: 'bg-indigo-950/70 border-indigo-500/40' };
    }
  };

  const viewBoxW = schematicModel.blueprintSvgConfig?.viewBoxWidth || 900;
  const viewBoxH = schematicModel.blueprintSvgConfig?.viewBoxHeight || 520;

  // Toggle failure simulation
  const handleToggleFailure = (partId: string) => {
    setActiveFailurePartId(prev => (prev === partId ? null : partId));
  };

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Top Interactive Canvas Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-slate-900/90 border border-indigo-500/30 rounded-2xl">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-indigo-600/30 text-indigo-400 flex items-center justify-center border border-indigo-500/40">
            <Sliders size={16} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400">
                Vector Schematic Blueprint
              </span>
              {activeFailurePartId && (
                <span className="text-[10px] font-black uppercase text-red-400 bg-red-950/80 px-2 py-0.5 rounded-full border border-red-500/40 animate-pulse flex items-center gap-1">
                  <AlertTriangle size={10} /> Stress / Fault Injection Active
                </span>
              )}
            </div>
            <h4 className="text-sm font-black text-white">{schematicModel.title}</h4>
          </div>
        </div>

        {/* Quick Canvas Mode Toggles */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowChallengeMode(prev => !prev)}
            className={cn(
              "px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 cursor-pointer",
              showChallengeMode
                ? "bg-amber-600 text-white border-amber-400 shadow-md shadow-amber-600/30"
                : "bg-slate-800 text-slate-300 border-slate-700 hover:text-white"
            )}
          >
            <HelpCircle size={13} />
            {showChallengeMode ? 'Exit Diagnostic Quiz' : 'Part Identification Quiz'}
          </button>

          {activePartData && (
            <button
              onClick={() => handleToggleFailure(activePartData.part.id)}
              className={cn(
                "px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 cursor-pointer",
                activeFailurePartId === activePartData.part.id
                  ? "bg-red-600 text-white border-red-400 shadow-md shadow-red-600/30"
                  : "bg-slate-800 text-slate-300 border-slate-700 hover:text-red-300 hover:border-red-500/40"
              )}
              title="Simulate failure / inhibition of the selected component"
            >
              <AlertTriangle size={13} />
              {activeFailurePartId === activePartData.part.id ? 'Reset Normal State' : `Inhibit [${activePartData.part.sectionCode}]`}
            </button>
          )}
        </div>
      </div>

      {/* Challenge Quiz Banner (if active) */}
      {showChallengeMode && schematicModel.challengeQuestions && schematicModel.challengeQuestions.length > 0 && schematicModel.challengeQuestions[activeQuizIndex] && (
        <div className="p-4 bg-gradient-to-r from-amber-950/90 via-slate-900 to-indigo-950/90 border-2 border-amber-500/50 rounded-2xl space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase text-amber-400 flex items-center gap-1.5">
                <Sparkles size={14} />
                Diagnostic Schematic Quiz • Question {activeQuizIndex + 1} of {schematicModel.challengeQuestions.length}
              </span>
              <div className="flex items-center gap-1">
                {schematicModel.challengeQuestions.map((_, qIdx) => (
                  <button
                    key={qIdx}
                    onClick={() => {
                      setActiveQuizIndex(qIdx);
                      setSelectedQuizOption(null);
                      setShowQuizExplanation(false);
                    }}
                    className={cn(
                      "w-6 h-6 rounded-lg text-xs font-bold transition-all",
                      activeQuizIndex === qIdx
                        ? "bg-amber-500 text-slate-950 font-black shadow-md"
                        : "bg-slate-800 text-slate-400 hover:text-white"
                    )}
                  >
                    {qIdx + 1}
                  </button>
                ))}
              </div>
            </div>

            {(() => {
              const currentQuiz = schematicModel.challengeQuestions![activeQuizIndex];
              if (!currentQuiz) return null;
              return (
                <>
                  <h4 className="text-sm font-bold text-white leading-relaxed">
                    {currentQuiz.question}
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {currentQuiz.options.map((opt, oIdx) => {
                      const isSelected = selectedQuizOption === oIdx;
                      const isCorrect = oIdx === currentQuiz.correctOptionIndex;
              return (
                <button
                  key={oIdx}
                  onClick={() => {
                    setSelectedQuizOption(oIdx);
                    setShowQuizExplanation(true);
                  }}
                  className={cn(
                    "p-2.5 rounded-xl text-left text-xs font-medium transition-all border flex items-center justify-between gap-2 cursor-pointer",
                    selectedQuizOption === null
                      ? "bg-slate-900/90 border-slate-700 hover:border-amber-400 text-slate-200"
                      : isCorrect
                      ? "bg-emerald-950/80 border-emerald-500 text-emerald-100 font-bold"
                      : isSelected
                      ? "bg-red-950/80 border-red-500 text-red-100"
                      : "bg-slate-900/40 border-slate-800 text-slate-500 opacity-60"
                  )}
                >
                  <span>{opt}</span>
                  {showQuizExplanation && isCorrect && <Check size={14} className="text-emerald-400 shrink-0" />}
                </button>
              );
            })}
          </div>

          {showQuizExplanation && (
            <div className="p-3 bg-slate-950/90 rounded-xl border border-amber-500/30 text-xs text-amber-200/90 leading-relaxed flex items-start gap-2">
              <Info size={15} className="text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong>Explanation:</strong> {currentQuiz.explanation}
              </div>
            </div>
          )}
                </>
              );
            })()}
        </div>
      )}

      {/* MAIN VECTOR SVG SCHEMATIC CANVAS */}
      <div className="relative w-full aspect-[16/9] min-h-[380px] max-h-[560px] bg-slate-950 rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl flex items-center justify-center select-none group">
        
        {/* SVG Blueprint Engine */}
        <svg
          viewBox={`0 0 ${viewBoxW} ${viewBoxH}`}
          className="w-full h-full object-contain"
          style={{
            background: 'radial-gradient(circle at 50% 50%, #0f172a 0%, #020617 100%)'
          }}
        >
          <defs>
            {/* Grid Blueprint Pattern */}
            <pattern id="cadGrid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(99, 102, 241, 0.08)" strokeWidth="0.8" />
              <circle cx="0" cy="0" r="1" fill="rgba(99, 102, 241, 0.2)" />
            </pattern>

            {/* Glowing Flow Filters */}
            <filter id="glowCyan" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <filter id="glowAmber" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <filter id="glowRed" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <filter id="glowEmerald" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>

            {/* Animated Flow Particles */}
            <marker id="arrowHeadCyan" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
              <polygon points="0 0, 6 3, 0 6" fill="#38bdf8" />
            </marker>
            <marker id="arrowHeadAmber" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
              <polygon points="0 0, 6 3, 0 6" fill="#fbbf24" />
            </marker>
            <marker id="arrowHeadEmerald" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
              <polygon points="0 0, 6 3, 0 6" fill="#34d399" />
            </marker>
          </defs>

          {/* Background Grid */}
          <rect width={viewBoxW} height={viewBoxH} fill="url(#cadGrid)" />

          {/* Blueprint Border Framing */}
          <rect
            x="10"
            y="10"
            width={viewBoxW - 20}
            height={viewBoxH - 20}
            fill="none"
            stroke="rgba(99, 102, 241, 0.25)"
            strokeWidth="1.5"
            strokeDasharray="4 4"
          />

          {/* Corner Blueprint Markers */}
          <path d="M 20 30 L 20 20 L 30 20" fill="none" stroke="#818cf8" strokeWidth="2" />
          <path d={`M ${viewBoxW - 30} 20 L ${viewBoxW - 20} 20 L ${viewBoxW - 20} 30`} fill="none" stroke="#818cf8" strokeWidth="2" />
          <path d={`M 20 ${viewBoxH - 30} L 20 ${viewBoxH - 20} L 30 ${viewBoxH - 20}`} fill="none" stroke="#818cf8" strokeWidth="2" />
          <path d={`M ${viewBoxW - 30} ${viewBoxH - 20} L ${viewBoxW - 20} ${viewBoxH - 20} L ${viewBoxW - 20} ${viewBoxH - 30}`} fill="none" stroke="#818cf8" strokeWidth="2" />

          {/* Blueprint Annotations */}
          {schematicModel.blueprintSvgConfig?.annotations?.map(ann => (
            <g key={ann.id} className="pointer-events-none">
              <text
                x={ann.x}
                y={ann.y}
                fill="rgba(148, 163, 184, 0.7)"
                fontSize="10"
                fontFamily="monospace"
                fontWeight="bold"
                letterSpacing="1"
              >
                {ann.text}
              </text>
            </g>
          ))}

          {/* Section Cutaway Slice Line Overlay (if cutaway technique is selected) */}
          {selectedTechnique === 'section_cutaway' && (
            <g className="transition-all duration-300 pointer-events-none">
              <line
                x1={(viewBoxW * cutawaySlicePosition) / 100}
                y1="20"
                x2={(viewBoxW * cutawaySlicePosition) / 100}
                y2={viewBoxH - 20}
                stroke="#ec4899"
                strokeWidth="2.5"
                strokeDasharray="6 3"
              />
              <text
                x={(viewBoxW * cutawaySlicePosition) / 100 + 6}
                y="35"
                fill="#ec4899"
                fontSize="11"
                fontWeight="bold"
                fontFamily="monospace"
              >
                CUT PLANE [{cutawaySlicePosition}%]
              </text>
              {/* Shaded Cutaway Region */}
              <rect
                x="20"
                y="20"
                width={Math.max(0, (viewBoxW * cutawaySlicePosition) / 100 - 20)}
                height={viewBoxH - 40}
                fill="rgba(236, 72, 153, 0.06)"
              />
            </g>
          )}

          {/* Animated Flow Channels / Wire Conduits */}
          {schematicModel.flowChannels?.map(channel => {
            const isSubsystemVisible = selectedSubsystemFilter === 'all' || selectedSubsystemFilter === channel.subsystem;
            const isFailed = activeFailurePartId && (channel.sourcePartId === activeFailurePartId || channel.targetPartId === activeFailurePartId);

            return (
              <g key={channel.id} opacity={isSubsystemVisible ? 1 : 0.15} className="transition-opacity duration-300">
                {/* Channel Base Wire */}
                <path
                  d={channel.pathD}
                  fill="none"
                  stroke={isFailed ? '#ef4444' : channel.color}
                  strokeWidth={isFailed ? 3 : 2.5}
                  strokeOpacity={isFailed ? 0.9 : 0.6}
                />

                {/* Animated Glowing Energy / Matter Trail */}
                {isFlowAnimationActive && !isFailed && (
                  <path
                    d={channel.pathD}
                    fill="none"
                    stroke={channel.color}
                    strokeWidth={2}
                    strokeDasharray="8 12"
                    className="animate-pulse"
                    style={{
                      animation: 'dashAnimation 2s linear infinite'
                    }}
                  />
                )}

                {/* Flow Channel Label */}
                {channel.label && (
                  <text
                    fontSize="9"
                    fontFamily="sans-serif"
                    fontWeight="bold"
                    fill={channel.color}
                    dy="-4"
                  >
                    <textPath href={`#${channel.id}`} startOffset="50%" textAnchor="middle">
                      {channel.label}
                    </textPath>
                  </text>
                )}
              </g>
            );
          })}

          {/* Render All Schematic Components */}
          {allComponents.map(({ part, sectionLetter }) => {
            const coord = part.schematicCoordinate || { x: 200, y: 200, width: 80, height: 50, shape: 'rect' };
            const isSelected = selectedPartId === part.id;
            const isHovered = hoveredPartId === part.id;
            const isSubsystemMatch = selectedSubsystemFilter === 'all' || selectedSubsystemFilter === part.subsystem;
            const isFailed = activeFailurePartId === part.id;

            // Exploded offsets calculation
            const effExplodeX = selectedTechnique === 'exploded_view' ? part.explodedOffsetX * explodedRatio : 0;
            const effExplodeY = selectedTechnique === 'exploded_view' ? part.explodedOffsetY * explodedRatio : 0;
            const posX = coord.x + effExplodeX;
            const posY = coord.y + effExplodeY;
            const w = coord.width || 90;
            const h = coord.height || 54;

            // Layer reveal visibility
            let opacity = 1.0;
            if (selectedTechnique === 'layered_reveal') {
              if (part.layerIndex > layerDepthIndex) opacity = 0.2;
            } else if (isGhostXRayActive || selectedTechnique === 'ghost_view') {
              if (part.layerIndex === 0) opacity = 0.25;
            }

            if (!isSubsystemMatch) opacity = Math.min(opacity, 0.2);

            const colors = getSubsystemColor(part.subsystem);

            return (
              <g
                key={part.id}
                transform={`translate(${posX}, ${posY})`}
                opacity={opacity}
                className="cursor-pointer transition-all duration-300"
                onClick={() => onSelectPart(part.id)}
                onMouseEnter={() => setHoveredPartId(part.id)}
                onMouseLeave={() => setHoveredPartId(null)}
              >
                {/* Exploded View Tether Projection Line */}
                {selectedTechnique === 'exploded_view' && explodedRatio > 0.05 && (
                  <line
                    x1={0}
                    y1={0}
                    x2={-effExplodeX}
                    y2={-effExplodeY}
                    stroke="rgba(129, 140, 248, 0.4)"
                    strokeWidth="1.2"
                    strokeDasharray="3 3"
                  />
                )}

                {/* Component Shadow / Glow Halo */}
                {(isSelected || isHovered || isFailed) && (
                  <rect
                    x={-w / 2 - 4}
                    y={-h / 2 - 4}
                    width={w + 8}
                    height={h + 8}
                    rx="12"
                    fill="none"
                    stroke={isFailed ? '#ef4444' : isSelected ? '#38bdf8' : colors.stroke}
                    strokeWidth="2.5"
                    strokeOpacity="0.8"
                    filter={isFailed ? 'url(#glowRed)' : 'url(#glowCyan)'}
                  />
                )}

                {/* Main Component Body Shape */}
                {coord.shape === 'circle' ? (
                  <circle
                    r={w / 2}
                    fill={isFailed ? '#450a0a' : isSelected ? '#082f49' : '#0f172a'}
                    stroke={isFailed ? '#ef4444' : isSelected ? '#38bdf8' : colors.stroke}
                    strokeWidth={isSelected ? '2.5' : '1.8'}
                  />
                ) : coord.shape === 'pill' ? (
                  <rect
                    x={-w / 2}
                    y={-h / 2}
                    width={w}
                    height={h}
                    rx={h / 2}
                    fill={isFailed ? '#450a0a' : isSelected ? '#082f49' : '#0f172a'}
                    stroke={isFailed ? '#ef4444' : isSelected ? '#38bdf8' : colors.stroke}
                    strokeWidth={isSelected ? '2.5' : '1.8'}
                  />
                ) : (
                  <rect
                    x={-w / 2}
                    y={-h / 2}
                    width={w}
                    height={h}
                    rx="8"
                    fill={isFailed ? '#450a0a' : isSelected ? '#082f49' : '#0f172a'}
                    stroke={isFailed ? '#ef4444' : isSelected ? '#38bdf8' : colors.stroke}
                    strokeWidth={isSelected ? '2.5' : '1.8'}
                  />
                )}

                {/* Section Code Badge */}
                <rect
                  x={-w / 2 + 5}
                  y={-h / 2 + 5}
                  width="22"
                  height="14"
                  rx="4"
                  fill={colors.fill}
                  fillOpacity="0.9"
                />
                <text
                  x={-w / 2 + 16}
                  y={-h / 2 + 15}
                  textAnchor="middle"
                  fontSize="8"
                  fontFamily="monospace"
                  fontWeight="black"
                  fill="#ffffff"
                >
                  {part.sectionCode}
                </text>

                {/* Component Name */}
                <text
                  x="0"
                  y="2"
                  textAnchor="middle"
                  fontSize="9.5"
                  fontFamily="sans-serif"
                  fontWeight="bold"
                  fill={isSelected ? '#ffffff' : '#e2e8f0'}
                  className="pointer-events-none"
                >
                  {part.name.length > 14 ? part.name.substring(0, 13) + '…' : part.name}
                </text>

                {/* Subtitle / Subsystem */}
                <text
                  x="0"
                  y="15"
                  textAnchor="middle"
                  fontSize="7.5"
                  fontFamily="sans-serif"
                  fill={isFailed ? '#fca5a5' : colors.stroke}
                  className="pointer-events-none uppercase tracking-wider font-semibold"
                >
                  {isFailed ? '⚠️ INHIBITED' : part.subsystem}
                </text>

                {/* Pin Connections / Terminals */}
                {part.pinConnections?.map(pin => (
                  <circle
                    key={pin.id}
                    cx={pin.x}
                    cy={pin.y}
                    r="3"
                    fill={colors.fill}
                    stroke="#ffffff"
                    strokeWidth="1"
                  />
                ))}

                {/* Annotated Dimension Callout Flag (if annotated breakdown is selected) */}
                {selectedTechnique === 'annotated_breakdown' && (
                  <g transform={`translate(${w / 2 + 4}, -10)`} className="pointer-events-none">
                    <rect
                      x="0"
                      y="0"
                      width="110"
                      height="24"
                      rx="4"
                      fill="rgba(15, 23, 42, 0.92)"
                      stroke="#818cf8"
                      strokeWidth="1"
                    />
                    <text x="5" y="10" fontSize="7.5" fontFamily="monospace" fill="#38bdf8" fontWeight="bold">
                      SPEC: {part.materialOrSpec.substring(0, 18)}…
                    </text>
                    <text x="5" y="19" fontSize="7" fontFamily="sans-serif" fill="#94a3b8">
                      Layer {part.layerIndex} • {part.operatingPrinciple.substring(0, 20)}…
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>

        {/* Bottom Floating Canvas Controls */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between p-2.5 bg-slate-900/90 backdrop-blur-md rounded-xl border border-indigo-500/30 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-indigo-400 font-bold uppercase">
              Target: [{activePartData?.part.sectionCode}] {activePartData?.part.name}
            </span>
            {activePartData?.part.materialOrSpec && (
              <span className="hidden sm:inline-block text-[10px] text-slate-400 truncate max-w-xs">
                • {activePartData.part.materialOrSpec}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {onSpeak && activePartData && (
              <button
                onClick={() => onSpeak(`${activePartData.part.name}. ${activePartData.part.workingFunction}. Operating Principle: ${activePartData.part.operatingPrinciple}`)}
                className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-all"
              >
                <Volume2 size={12} />
                Narrate Part
              </button>
            )}
          </div>
        </div>
      </div>

      {/* COMPONENT DEEP BREAKDOWN & TELEMETRY CARD */}
      {activePartData && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          
          {/* Column 1: Functional Specifications & Physics Law */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-2">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-[10px] font-black uppercase text-indigo-400 flex items-center gap-1">
                <Info size={12} /> 🗣️ Plain-English Mechanism & Role
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-indigo-300 border border-slate-800">
                Part [{activePartData.part.sectionCode}]
              </span>
            </div>
            <h5 className="text-xs font-bold text-white leading-relaxed">{activePartData.part.operatingPrinciple}</h5>
            <div className="text-[11px] text-slate-300 pt-1">
              <strong>Primary Human Role:</strong> {activePartData.part.workingFunction}
            </div>
            {activePartData.part.materialOrSpec && (
              <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-indigo-200">
                <strong>Specification / Details:</strong> {activePartData.part.materialOrSpec}
              </div>
            )}
          </div>

          {/* Column 2: Live Parameters & Telemetry */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-2">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-[10px] font-black uppercase text-cyan-400 flex items-center gap-1">
                <Activity size={12} /> ☕ Live State & Diagnostic Values
              </span>
              <span className="text-[10px] font-bold text-emerald-400">Working Normally</span>
            </div>

            {activePartData.part.stateParameters && activePartData.part.stateParameters.length > 0 ? (
              <div className="space-y-1.5">
                {activePartData.part.stateParameters.map((param, pIdx) => (
                  <div key={pIdx} className="flex items-center justify-between p-1.5 rounded-lg bg-slate-950 text-xs">
                    <span className="text-slate-400">{param.parameter}:</span>
                    <span className="font-mono text-cyan-300 font-bold">
                      {param.value} {param.unit}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-1.5 text-xs text-slate-300">
                <div className="flex items-center justify-between p-1.5 rounded-lg bg-slate-950">
                  <span className="text-slate-400">Subsystem:</span>
                  <span className="font-mono text-cyan-300 font-bold uppercase">{activePartData.part.subsystem}</span>
                </div>
                <div className="flex items-center justify-between p-1.5 rounded-lg bg-slate-950">
                  <span className="text-slate-400">Section Group:</span>
                  <span className="font-mono text-cyan-300 font-bold">[{activePartData.sectionLetter}] {activePartData.sectionName}</span>
                </div>
              </div>
            )}

            {activePartData.part.examMarkingTip && (
              <div className="p-2 rounded-xl bg-amber-950/50 border border-amber-800/50 text-[11px] text-amber-200">
                💡 <strong>Golden Exam Key:</strong> {activePartData.part.examMarkingTip}
              </div>
            )}
          </div>

          {/* Column 3: Failure Modes & Conceptual Diagnostics */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-2">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-[10px] font-black uppercase text-red-400 flex items-center gap-1">
                <AlertTriangle size={12} /> ⚠️ Failure Mode & System Effect
              </span>
              <button
                onClick={() => handleToggleFailure(activePartData.part.id)}
                className="text-[10px] font-bold text-red-300 hover:text-white underline cursor-pointer"
              >
                {activeFailurePartId === activePartData.part.id ? 'Clear Fault' : 'Test Fault Simulation'}
              </button>
            </div>

            {activePartData.part.failureMode ? (
              <div className="space-y-1.5 text-xs">
                <div className="text-slate-300">
                  <strong>What triggers failure:</strong> {activePartData.part.failureMode.description}
                </div>
                <div className="p-2 rounded-xl bg-red-950/60 border border-red-800/60 text-red-200 text-[11px]">
                  <strong>What happens to the system:</strong> {activePartData.part.failureMode.systemicConsequence}
                </div>
              </div>
            ) : (
              <div className="space-y-1.5 text-xs text-slate-400 leading-relaxed">
                <p>If [{activePartData.part.sectionCode}] is blocked or damaged, downstream flow through section [{activePartData.sectionLetter}] stops, shutting down energy conversion.</p>
              </div>
            )}
          </div>

        </div>
      )}
    </div>
  );
};
