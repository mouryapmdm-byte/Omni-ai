import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '../lib/utils';
import { Copy, Calculator, Plus, Minus, X, ArrowRight, RotateCcw, BookOpen, CheckCircle2 } from 'lucide-react';

interface MatrixCalculatorModalProps {
  theme: string;
  onClose: () => void;
}

type Matrix3x3 = number[][];

export function MatrixCalculatorModal({ theme, onClose }: MatrixCalculatorModalProps) {
  const [sizeA, setSizeA] = useState({ rows: 3, cols: 3 });
  const [sizeB, setSizeB] = useState({ rows: 3, cols: 3 });
  const [activeTab, setActiveTab] = useState<'calculator' | 'tutorial'>('calculator');
  
  const [matrixA, setMatrixA] = useState<Matrix3x3>(Array(3).fill(0).map(() => Array(3).fill(0)));
  const [matrixB, setMatrixB] = useState<Matrix3x3>(Array(3).fill(0).map(() => Array(3).fill(0)));
  
  const [operation, setOperation] = useState<'add' | 'subtract' | 'multiply' | 'detA' | 'detB' | 'invA' | 'invB' | 'scalarA' | 'scalarB' | 'refA' | 'refB' | 'rankA' | 'rankB' | null>(null);
  const [scalarA, setScalarA] = useState<number>(2);
  const [scalarB, setScalarB] = useState<number>(2);

  // Practice question states for interactive solver
  const [showQ1Answer, setShowQ1Answer] = useState(false);
  const [showQ2Answer, setShowQ2Answer] = useState(false);
  
  const handleCellChange = (matrix: 'A' | 'B', row: number, col: number, value: string) => {
    const num = value === '' || value === '-' ? 0 : parseFloat(value);
    if (matrix === 'A') {
      const newM = [...matrixA.map(r => [...r])];
      newM[row][col] = isNaN(num) ? 0 : num;
      setMatrixA(newM);
    } else {
      const newM = [...matrixB.map(r => [...r])];
      newM[row][col] = isNaN(num) ? 0 : num;
      setMatrixB(newM);
    }
  };

  const handleTranspose = (matrix: 'A' | 'B') => {
    if (matrix === 'A') {
      const newM = Array(3).fill(0).map(() => Array(3).fill(0));
      for (let i = 0; i < sizeA.rows; i++) {
        for (let j = 0; j < sizeA.cols; j++) {
          newM[j][i] = matrixA[i][j];
        }
      }
      setMatrixA(newM);
      setSizeA({ rows: sizeA.cols, cols: sizeA.rows });
    } else {
      const newM = Array(3).fill(0).map(() => Array(3).fill(0));
      for (let i = 0; i < sizeB.rows; i++) {
        for (let j = 0; j < sizeB.cols; j++) {
          newM[j][i] = matrixB[i][j];
        }
      }
      setMatrixB(newM);
      setSizeB({ rows: sizeB.cols, cols: sizeB.rows });
    }
  };

  
  const copyToInput = (target: 'A' | 'B', result: number[][], rows: number, cols: number) => {
    const padded = Array(3).fill(0).map(() => Array(3).fill(0));
    for(let i=0; i<Math.min(rows, 3); i++) {
      for(let j=0; j<Math.min(cols, 3); j++) {
        padded[i][j] = result[i][j];
      }
    }
    if (target === 'A') {
      setMatrixA(padded);
      setSizeA({ rows: Math.min(rows, 3), cols: Math.min(cols, 3) });
    } else {
      setMatrixB(padded);
      setSizeB({ rows: Math.min(rows, 3), cols: Math.min(cols, 3) });
    }
  };

  const renderCopyButtons = (result: number[][], rows: number, cols: number) => (
    <div className="flex flex-col gap-2 ml-4 border-l pl-4 border-slate-300 dark:border-slate-700">
      <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Copy Result To</p>
      <div className="flex gap-2">
        <button 
          onClick={() => copyToInput('A', result, rows, cols)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5", theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-300" : "bg-slate-100 hover:bg-slate-200 text-slate-700")}
        >
          <Copy size={14} /> Matrix A
        </button>
        <button 
          onClick={() => copyToInput('B', result, rows, cols)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5", theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-300" : "bg-slate-100 hover:bg-slate-200 text-slate-700")}
        >
          <Copy size={14} /> Matrix B
        </button>
      </div>
    </div>
  );

  const getDeterminant = (M: Matrix3x3, size: {rows: number, cols: number}) => {
    if (size.rows === 1) return M[0][0];
    if (size.rows === 2) return M[0][0]*M[1][1] - M[0][1]*M[1][0];
    const a = M[0][0], b = M[0][1], c = M[0][2];
    const d = M[1][0], e = M[1][1], f = M[1][2];
    const g = M[2][0], h = M[2][1], i = M[2][2];
    return a*(e*i - f*h) - b*(d*i - f*g) + c*(d*h - e*g);
  };

  const getInverse = (M: Matrix3x3, size: {rows: number, cols: number}) => {
    const det = getDeterminant(M, size);
    if (det === 0) return null;
    
    if (size.rows === 1) {
      return [[1/M[0][0], 0, 0], [0, 0, 0], [0, 0, 0]];
    }
    if (size.rows === 2) {
      const inv = Array(3).fill(0).map(() => Array(3).fill(0));
      inv[0][0] = M[1][1] / det;
      inv[0][1] = -M[0][1] / det;
      inv[1][0] = -M[1][0] / det;
      inv[1][1] = M[0][0] / det;
      return inv;
    }
    if (size.rows === 3) {
      const inv = Array(3).fill(0).map(() => Array(3).fill(0));
      const a = M[0][0], b = M[0][1], c = M[0][2];
      const d = M[1][0], e = M[1][1], f = M[1][2];
      const g = M[2][0], h = M[2][1], i = M[2][2];
      
      inv[0][0] = (e*i - f*h) / det;
      inv[0][1] = (c*h - b*i) / det;
      inv[0][2] = (b*f - c*e) / det;
      
      inv[1][0] = (f*g - d*i) / det;
      inv[1][1] = (a*i - c*g) / det;
      inv[1][2] = (c*d - a*f) / det;
      
      inv[2][0] = (d*h - e*g) / det;
      inv[2][1] = (b*g - a*h) / det;
      inv[2][2] = (a*e - b*d) / det;
      
      return inv;
    }
    return null;
  };

    const getREF = (M: Matrix3x3, rows: number, cols: number) => {
    const A = M.slice(0, rows).map(r => r.slice(0, cols).map(val => Number(val)));
    let lead = 0;
    for (let r = 0; r < rows; r++) {
      if (cols <= lead) return A;
      let i = r;
      while (Math.abs(A[i][lead]) < 1e-10) {
        i++;
        if (rows === i) {
          i = r;
          lead++;
          if (cols === lead) return A;
        }
      }
      
      let temp = A[i];
      A[i] = A[r];
      A[r] = temp;
      
      let val = A[r][lead];
      for (let j = 0; j < cols; j++) {
        A[r][j] = A[r][j] / val;
      }
      
      for (let i = r + 1; i < rows; i++) {
        let val2 = A[i][lead];
        for (let j = 0; j < cols; j++) {
          A[i][j] = A[i][j] - val2 * A[r][j];
        }
      }
      lead++;
    }
    return A;
  };

  const getRank = (M: Matrix3x3, rows: number, cols: number) => {
    const refMatrix = getREF(M, rows, cols);
    let rank = 0;
    for (let i = 0; i < rows; i++) {
      let isNonZero = false;
      for (let j = 0; j < cols; j++) {
        if (Math.abs(refMatrix[i][j]) > 1e-10) {
          isNonZero = true;
          break;
        }
      }
      if (isNonZero) rank++;
    }
    return rank;
  };

  const getDet3x3Steps = (M: Matrix3x3) => {
    if (sizeA.rows === 2 && sizeA.cols === 2) {
      const det = M[0][0] * M[1][1] - M[0][1] * M[1][0];
      return `Det = (${M[0][0]} × ${M[1][1]}) - (${M[0][1]} × ${M[1][0]})\nDet = ${M[0][0]*M[1][1]} - ${M[0][1]*M[1][0]}\nDet = ${det}`;
    }
    const a = M[0][0], b = M[0][1], c = M[0][2];
    const d = M[1][0], e = M[1][1], f = M[1][2];
    const g = M[2][0], h = M[2][1], i = M[2][2];
    
    const term1 = e*i - f*h;
    const term2 = d*i - f*g;
    const term3 = d*h - e*g;
    
    const det = a*term1 - b*term2 + c*term3;
    
    return `Det = ${a}(${e}×${i} - ${f}×${h}) - ${b}(${d}×${i} - ${f}×${g}) + ${c}(${d}×${h} - ${e}×${g})\nDet = ${a}(${term1}) - ${b}(${term2}) + ${c}(${term3})\nDet = ${a*term1} - ${b*term2} + ${c*term3}\nDet = ${det}`;
  };

  const renderAddition = () => {
    if (sizeA.rows !== sizeB.rows || sizeA.cols !== sizeB.cols) {
      return <p className="text-red-500 font-bold p-4">Error: Matrices must have the same dimensions for addition.</p>;
    }
    
    const result = matrixA.slice(0, sizeA.rows).map((row, i) => 
      row.slice(0, sizeA.cols).map((val, j) => val + matrixB[i][j])
    );
    
    return (
      <div className="space-y-4">
        <h3 className="font-bold">Step-by-step Addition:</h3>
        <div className="flex gap-4 items-center flex-wrap">
           <MatrixDisplay M={matrixA} rows={sizeA.rows} cols={sizeA.cols} />
           <span className="font-bold">+</span>
           <MatrixDisplay M={matrixB} rows={sizeB.rows} cols={sizeB.cols} />
           <span className="font-bold">=</span>
           <div className="grid gap-1 border-l-2 border-r-2 border-slate-400 p-1" style={{ gridTemplateColumns: `repeat(${sizeA.cols}, minmax(0, 1fr))` }}>
              {Array(sizeA.rows).fill(0).map((_, i) => (
                Array(sizeA.cols).fill(0).map((_, j) => (
                  <div key={`${i}-${j}`} className="px-2 py-1 text-center whitespace-nowrap bg-indigo-500/10 rounded">
                    {matrixA[i][j]} + {matrixB[i][j]}
                  </div>
                ))
              ))}
           </div>
           <span className="font-bold">=</span>
           <MatrixDisplay M={result} rows={sizeA.rows} cols={sizeA.cols} />
           {renderCopyButtons(result, sizeA.rows, sizeA.cols)}
        </div>
      </div>
    );
  };

  
  const renderSubtraction = () => {
    if (sizeA.rows !== sizeB.rows || sizeA.cols !== sizeB.cols) {
      return <p className="text-red-500 font-bold p-4">Error: Matrices must have the same dimensions for subtraction.</p>;
    }
    
    const result = matrixA.slice(0, sizeA.rows).map((row, i) => 
      row.slice(0, sizeA.cols).map((val, j) => val - matrixB[i][j])
    );
    
    return (
      <div className="space-y-4 overflow-x-auto">
        <h3 className="font-bold">Step-by-step Subtraction:</h3>
        <div className="flex gap-4 items-center w-max">
           <MatrixDisplay M={matrixA} rows={sizeA.rows} cols={sizeA.cols} />
           <span className="font-bold">-</span>
           <MatrixDisplay M={matrixB} rows={sizeB.rows} cols={sizeB.cols} />
           <span className="font-bold">=</span>
           <div className="grid gap-1 border-l-2 border-r-2 border-slate-400 p-1" style={{ gridTemplateColumns: `repeat(${sizeA.cols}, minmax(0, 1fr))` }}>
              {Array(sizeA.rows).fill(0).map((_, i) => (
                Array(sizeA.cols).fill(0).map((_, j) => (
                  <div key={`${i}-${j}`} className="px-2 py-1 text-center whitespace-nowrap bg-indigo-500/10 rounded">
                    {matrixA[i][j]} - {matrixB[i][j]}
                  </div>
                ))
              ))}
           </div>
           <span className="font-bold">=</span>
           <MatrixDisplay M={result} rows={sizeA.rows} cols={sizeA.cols} />
           {renderCopyButtons(result, sizeA.rows, sizeA.cols)}
        </div>
      </div>
    );
  };

  const renderMultiplication = () => {
    if (sizeA.cols !== sizeB.rows) {
      return <p className="text-red-500 font-bold p-4">Error: Columns of Matrix A must equal Rows of Matrix B for multiplication.</p>;
    }
    
    const result = Array(sizeA.rows).fill(0).map((_, i) => 
      Array(sizeB.cols).fill(0).map((_, j) => {
        let sum = 0;
        for (let k = 0; k < sizeA.cols; k++) {
          sum += matrixA[i][k] * matrixB[k][j];
        }
        return sum;
      })
    );
    
    return (
      <div className="space-y-4 overflow-x-auto pb-4">
        <h3 className="font-bold">Step-by-step Multiplication:</h3>
        <div className="flex gap-4 items-center w-max">
           <MatrixDisplay M={matrixA} rows={sizeA.rows} cols={sizeA.cols} />
           <span className="font-bold">×</span>
           <MatrixDisplay M={matrixB} rows={sizeB.rows} cols={sizeB.cols} />
           <span className="font-bold">=</span>
           <div className="grid gap-1 border-l-2 border-r-2 border-slate-400 p-1" style={{ gridTemplateColumns: `repeat(${sizeB.cols}, minmax(0, 1fr))` }}>
              {Array(sizeA.rows).fill(0).map((_, i) => (
                Array(sizeB.cols).fill(0).map((_, j) => (
                  <div key={`${i}-${j}`} className="px-2 py-1 text-center whitespace-nowrap bg-indigo-500/10 rounded text-xs md:text-sm">
                    {Array(sizeA.cols).fill(0).map((_, k) => `(${matrixA[i][k]} × ${matrixB[k][j]})`).join(' + ')}
                  </div>
                ))
              ))}
           </div>
           <span className="font-bold">=</span>
           <MatrixDisplay M={result} rows={sizeA.rows} cols={sizeB.cols} />
           {renderCopyButtons(result, sizeA.rows, sizeB.cols)}
        </div>
      </div>
    );
  };

  const renderDeterminant = (matrix: 'A' | 'B') => {
    const M = matrix === 'A' ? matrixA : matrixB;
    const size = matrix === 'A' ? sizeA : sizeB;
    if (size.rows !== size.cols) {
      return <p className="text-red-500 font-bold p-4">Error: Determinant can only be calculated for square matrices.</p>;
    }
    if (size.rows > 3) {
       return <p className="text-red-500 font-bold p-4">Error: Determinant calculation is only supported up to 3x3.</p>;
    }

    return (
      <div className="space-y-4">
        <h3 className="font-bold">Step-by-step Determinant of Matrix {matrix}:</h3>
        <div className="flex gap-4 items-start flex-col md:flex-row">
           <div className="flex flex-col gap-2 shrink-0">
             <MatrixDisplay M={M} rows={size.rows} cols={size.cols} isDet />
           </div>
           <pre className={cn("p-4 rounded-lg font-mono text-sm whitespace-pre-wrap flex-1", theme === 'dark' ? "bg-slate-900" : "bg-slate-100")}>
             {size.rows === 1 ? `Det = ${M[0][0]}` : getDet3x3Steps(M)}
           </pre>
        </div>
      </div>
    );
  };

  const renderInverse = (matrix: 'A' | 'B') => {
    const M = matrix === 'A' ? matrixA : matrixB;
    const size = matrix === 'A' ? sizeA : sizeB;
    if (size.rows !== size.cols) {
      return <p className="text-red-500 font-bold p-4">Error: Inverse can only be calculated for square matrices.</p>;
    }
    if (size.rows > 3) {
       return <p className="text-red-500 font-bold p-4">Error: Inverse calculation is only supported up to 3x3.</p>;
    }
    
    const det = getDeterminant(M, size);
    if (det === 0) {
      return <p className="text-red-500 font-bold p-4">Error: Matrix is not invertible (Determinant is 0).</p>;
    }

    const inv = getInverse(M, size);

    return (
      <div className="space-y-4">
        <h3 className="font-bold">Inverse of Matrix {matrix}:</h3>
        <div className="flex gap-4 items-center">
           <MatrixDisplay M={M} rows={size.rows} cols={size.cols} />
           <span className="font-bold">→</span>
           <MatrixDisplay M={inv!.map(r => r.map(v => parseFloat(v.toFixed(4))))} rows={size.rows} cols={size.cols} />
           {renderCopyButtons(inv!, size.rows, size.cols)}
        </div>
        <p className="text-sm mt-4">Determinant: {det}</p>
      </div>
    );
  };

    const renderScalar = (matrix: 'A' | 'B') => {
    const M = matrix === 'A' ? matrixA : matrixB;
    const size = matrix === 'A' ? sizeA : sizeB;
    const scalar = matrix === 'A' ? scalarA : scalarB;
    
    const result = M.slice(0, size.rows).map(r => r.slice(0, size.cols).map(val => val * scalar));
    
    return (
      <div className="space-y-4 overflow-x-auto">
        <h3 className="font-bold">Scalar Multiplication (Matrix {matrix}):</h3>
        <div className="flex gap-4 items-center w-max">
           <span className="font-bold">{scalar} ×</span>
           <MatrixDisplay M={M} rows={size.rows} cols={size.cols} />
           <span className="font-bold">=</span>
           <MatrixDisplay M={result.map(r => r.map(v => parseFloat(v.toFixed(4))))} rows={size.rows} cols={size.cols} />
           {renderCopyButtons(result, size.rows, size.cols)}
        </div>
      </div>
    );
  };

  const renderREF = (matrix: 'A' | 'B') => {
    const M = matrix === 'A' ? matrixA : matrixB;
    const size = matrix === 'A' ? sizeA : sizeB;
    
    const refMatrix = getREF(M, size.rows, size.cols);
    
    return (
      <div className="space-y-4 overflow-x-auto">
        <h3 className="font-bold">Row Echelon Form (REF) of Matrix {matrix}:</h3>
        <div className="flex gap-4 items-center w-max">
           <MatrixDisplay M={M} rows={size.rows} cols={size.cols} />
           <span className="font-bold">→</span>
           <MatrixDisplay M={refMatrix.map(r => r.map(v => parseFloat(v.toFixed(4)) === 0 ? 0 : parseFloat(v.toFixed(4))))} rows={size.rows} cols={size.cols} />
           {renderCopyButtons(refMatrix, size.rows, size.cols)}
        </div>
      </div>
    );
  };

  const renderRank = (matrix: 'A' | 'B') => {
    const M = matrix === 'A' ? matrixA : matrixB;
    const size = matrix === 'A' ? sizeA : sizeB;
    
    const rank = getRank(M, size.rows, size.cols);
    const refMatrix = getREF(M, size.rows, size.cols);
    
    return (
      <div className="space-y-4 overflow-x-auto">
        <h3 className="font-bold">Rank of Matrix {matrix}:</h3>
        <div className="flex gap-4 items-center w-max">
           <MatrixDisplay M={M} rows={size.rows} cols={size.cols} />
           <span className="font-bold">→</span>
           <MatrixDisplay M={refMatrix.map(r => r.map(v => parseFloat(v.toFixed(4)) === 0 ? 0 : parseFloat(v.toFixed(4))))} rows={size.rows} cols={size.cols} />
           {renderCopyButtons(refMatrix, size.rows, size.cols)}
        </div>
        <p className="text-lg mt-4 font-bold text-indigo-600">Rank = {rank}</p>
        <p className="text-sm">The rank is the number of non-zero rows in the Row Echelon Form.</p>
      </div>
    );
  };

  return (
    <div className={cn(
      "flex flex-col h-full overflow-hidden",
      theme === 'dark' ? "bg-slate-950 text-white" : "bg-white text-slate-900"
    )}>
      {/* Header */}
      <div className={cn(
        "flex-none px-6 py-4 border-b flex items-center justify-between sticky top-0 z-10 flex-wrap gap-4",
        theme === 'dark' ? "bg-slate-900/90 border-slate-800" : "bg-slate-50/90 border-slate-200 backdrop-blur-md"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-500">
            <Calculator size={24} />
          </div>
          <div>
            <h2 className="font-bold text-lg leading-tight">Matrix Studio & Tutorial</h2>
            <p className={cn("text-xs", theme === 'dark' ? "text-slate-400" : "text-slate-500")}>
              Calculator, Equality Theorems, and Step-by-Step NCERT Practice
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold">
            <span>🛡️ CISCE / ICSE & ISC Class 12 Aligned</span>
          </div>
          <button
            onClick={() => setActiveTab('calculator')}
            className={cn("px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2", activeTab === 'calculator' ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20" : (theme === 'dark' ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-700 hover:bg-slate-200"))}
          >
            <Calculator size={16} /> Calculator
          </button>
          <button
            onClick={() => setActiveTab('tutorial')}
            className={cn("px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2", activeTab === 'tutorial' ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20" : (theme === 'dark' ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-700 hover:bg-slate-200"))}
          >
            <BookOpen size={16} /> ICSE/ISC Tutorial & Practice
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8">
        {activeTab === 'tutorial' ? (
          <div className="space-y-8 max-w-4xl mx-auto pb-12">
            <div className={cn("p-6 rounded-2xl border shadow-sm", theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200")}>
              <h2 className="text-2xl font-bold mb-4 text-indigo-500 flex items-center gap-2">
                <BookOpen size={24} /> आव्यूह (Matrices): समानता, कोटि एवं विस्तृत अभ्यास
              </h2>
              <p className="text-sm leading-relaxed mb-4 opacity-90">
                व्यापक गणितीय पाठ्यक्रम के अनुसार आव्यूह (Matrix) एक आयताकार सरणी है। इसे इस प्रकार निरूपित किया जाता है:
              </p>
              <div className="bg-slate-950 text-indigo-300 p-4 rounded-xl font-mono text-center my-4 overflow-x-auto text-sm">
                A = [a_ij]_(m × n)
              </div>
              <p className="text-sm leading-relaxed mb-4">
                संक्षिप्त रूप में इसे <code className="bg-slate-500/20 px-1.5 py-0.5 rounded font-mono">A = [a_ij]_(m × n)</code> लिखा जाता है, जहाँ:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-sm opacity-90">
                <li><strong className="text-indigo-400">i</strong> पंक्ति का सूचकांक है (<span className="font-mono">1 &le; i &le; m</span>)</li>
                <li><strong className="text-indigo-400">j</strong> स्तंभ का सूचकांक है (<span className="font-mono">1 &le; j &le; n</span>)</li>
                <li><strong className="text-indigo-400">a<sub>ij</sub></strong> उस अवयव को दर्शाता है जो i-वीं पंक्ति और j-वें स्तंभ के प्रतिच्छेदन पर स्थित है।</li>
              </ul>
            </div>

            {/* Section 2: Taxonomy & Types of Matrices */}
            <div className={cn("p-6 rounded-2xl border shadow-sm", theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200")}>
              <h3 className="text-xl font-bold mb-3 text-indigo-400">2. आकार एवं संरचना के आधार पर आव्यूह के प्रकार (Taxonomy of Matrices)</h3>
              <p className="text-sm leading-relaxed mb-4 opacity-90">
                आव्यूह को उनकी पंक्तियों, स्तंभों, विकर्ण अवयवों एवं विशिष्ट संरचनात्मक गुणों के आधार पर वर्गीकृत किया जाता है:
              </p>
              
              {/* Interactive Vector Board */}
              <div className="w-full overflow-hidden rounded-xl border border-slate-700 bg-slate-950 p-2 shadow-inner my-4">
                <svg viewBox="0 0 1000 500" width="100%" height="100%" className="w-full h-auto max-h-[500px]" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <marker id="tax-arrow-indigo" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                      <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#818cf8"/>
                    </marker>
                    <marker id="tax-arrow-purple" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                      <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#a855f7"/>
                    </marker>
                    <marker id="tax-ptr-cyan" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
                      <polygon points="0,2 8,5 0,8" fill="#38bdf8"/>
                    </marker>
                    <linearGradient id="tax-bg-blue" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#0f172a" stopOpacity="0.95"/>
                      <stop offset="100%" stopColor="#0284c7" stopOpacity="0.15"/>
                    </linearGradient>
                    <linearGradient id="tax-bg-purple" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#0f172a" stopOpacity="0.95"/>
                      <stop offset="100%" stopColor="#6366f1" stopOpacity="0.15"/>
                    </linearGradient>
                    <linearGradient id="tax-bg-emerald" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#0f172a" stopOpacity="0.95"/>
                      <stop offset="100%" stopColor="#059669" stopOpacity="0.15"/>
                    </linearGradient>
                    <linearGradient id="tax-bg-amber" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#0f172a" stopOpacity="0.95"/>
                      <stop offset="100%" stopColor="#d97706" stopOpacity="0.15"/>
                    </linearGradient>
                  </defs>

                  <rect width="1000" height="500" fill="#0f172a" rx="14"/>
                  <rect x="10" y="10" width="980" height="480" fill="none" stroke="#334155" strokeWidth="2.5" rx="12"/>

                  {/* Header */}
                  <g transform="translate(500, 42)">
                    <text x="0" y="0" fontFamily="'Plus Jakarta Sans', sans-serif" fontSize="20" fontWeight="800" fill="#f8fafc" textAnchor="middle">
                      आकार एवं संरचना के आधार पर आव्यूह के प्रकार
                    </text>
                    <text x="0" y="22" fontFamily="monospace" fontSize="12" fontWeight="600" fill="#38bdf8" textAnchor="middle">
                      (Taxonomy &amp; Classification of Matrices)
                    </text>
                    <line x1="-300" y1="32" x2="300" y2="32" stroke="#0284c7" strokeWidth="1.5" opacity="0.6"/>
                  </g>

                  {/* Column 1: Row / Column (x=40) */}
                  <g transform="translate(40, 90)">
                    <rect width="280" height="185" fill="url(#tax-bg-blue)" stroke="#0284c7" strokeWidth="1.5" rx="8"/>
                    <text x="140" y="24" fontFamily="sans-serif" fontSize="13" fontWeight="700" fill="#38bdf8" textAnchor="middle">1. पंक्ति एवं स्तंभ आव्यूह</text>
                    <line x1="15" y1="34" x2="265" y2="34" stroke="#0284c7" strokeWidth="1" opacity="0.3"/>

                    <g transform="translate(15, 46)">
                      <text x="0" y="20" fontFamily="sans-serif" fontSize="12" fill="#94a3b8" fontWeight="600">Row Vector:</text>
                      <g transform="translate(90, 4)">
                        <path d="M 0 0 h -5 v 26 h 5" stroke="#38bdf8" strokeWidth="1.8" fill="none"/>
                        <text x="8" y="17" fill="#f1f5f9" fontFamily="monospace" fontSize="12" fontWeight="600">a₁₁   a₁₂   a₁₃</text>
                        <path d="M 90 0 h 5 v 26 h -5" stroke="#38bdf8" strokeWidth="1.8" fill="none"/>
                      </g>
                      <rect x="202" y="8" width="42" height="18" rx="4" fill="#0c4a6e" stroke="#0284c7" strokeWidth="1"/>
                      <text x="223" y="21" fill="#38bdf8" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">1×3</text>
                      <path d="M 75 16 L 85 16" stroke="#38bdf8" strokeWidth="1.2" markerEnd="url(#tax-ptr-cyan)"/>
                    </g>

                    <g transform="translate(15, 106)">
                      <text x="0" y="24" fontFamily="sans-serif" fontSize="12" fill="#94a3b8" fontWeight="600">Col Vector:</text>
                      <g transform="translate(90, 0)">
                        <path d="M 0 0 h -5 v 42 h 5" stroke="#38bdf8" strokeWidth="1.8" fill="none"/>
                        <text x="10" y="17" fill="#f1f5f9" fontFamily="monospace" fontSize="12" fontWeight="600">b₁₁</text>
                        <text x="10" y="35" fill="#f1f5f9" fontFamily="monospace" fontSize="12" fontWeight="600">b₂₁</text>
                        <path d="M 38 0 h 5 v 42 h -5" stroke="#38bdf8" strokeWidth="1.8" fill="none"/>
                      </g>
                      <rect x="202" y="12" width="42" height="18" rx="4" fill="#0c4a6e" stroke="#0284c7" strokeWidth="1"/>
                      <text x="223" y="25" fill="#38bdf8" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">2×1</text>
                      <path d="M 72 20 L 85 20" stroke="#38bdf8" strokeWidth="1.2" markerEnd="url(#tax-ptr-cyan)"/>
                    </g>
                  </g>

                  {/* Column 1 Bottom: Main Diagonal (x=40) */}
                  <g transform="translate(40, 290)">
                    <rect width="280" height="185" fill="url(#tax-bg-amber)" stroke="#d97706" strokeWidth="1.5" strokeDasharray="5 3" rx="8"/>
                    <text x="140" y="24" fontFamily="sans-serif" fontSize="13" fontWeight="700" fill="#fbbf24" textAnchor="middle">मुख्य विकर्ण (Main Diagonal)</text>
                    <line x1="15" y1="34" x2="265" y2="34" stroke="#d97706" strokeWidth="1" opacity="0.3"/>
                    <text x="15" y="55" fontFamily="sans-serif" fontSize="11" fill="#cbd5e1">• केवल वर्ग आव्यूह में (In Square Matrix)</text>
                    <text x="15" y="75" fontFamily="sans-serif" fontSize="11" fill="#cbd5e1">• अवयव: a₁₁, a₂₂, a₃₃ ...</text>
                    <g transform="translate(15, 95)">
                      <rect width="250" height="65" rx="6" fill="#1e1b4b" fillOpacity="0.85" stroke="#f59e0b" strokeWidth="1.2"/>
                      <text x="125" y="22" fontFamily="sans-serif" fontSize="11" fontWeight="bold" fill="#fbbf24" textAnchor="middle">अनुरेख (Trace of Matrix):</text>
                      <text x="125" y="46" fontFamily="monospace" fontSize="12" fontWeight="bold" fill="#f1f5f9" textAnchor="middle">Trace(A) = Σ aᵢᵢ = a₁₁ + a₂₂ + ...</text>
                    </g>
                  </g>

                  {/* Column 2: Square Hierarchy (x=360) [40px GAP] */}
                  <g transform="translate(360, 90)">
                    <rect width="280" height="385" fill="url(#tax-bg-purple)" stroke="#6366f1" strokeWidth="1.5" rx="8"/>
                    <text x="140" y="24" fontFamily="sans-serif" fontSize="13" fontWeight="700" fill="#818cf8" textAnchor="middle">2. वर्ग आव्यूह एवं उप-प्रकार</text>
                    <line x1="15" y1="34" x2="265" y2="34" stroke="#6366f1" strokeWidth="1" opacity="0.3"/>

                    {/* Step 1: Square */}
                    <g transform="translate(15, 45)">
                      <rect width="250" height="75" rx="6" fill="#1e1b4b" fillOpacity="0.9" stroke="#6366f1" strokeWidth="1.2"/>
                      <text x="125" y="20" fontFamily="sans-serif" fontSize="12" fontWeight="700" fill="#c7d2fe" textAnchor="middle">वर्ग आव्यूह (Square Matrix: m = n)</text>
                      <g transform="translate(80, 28)">
                        <path d="M 0 0 h -5 v 34 h 5" stroke="#818cf8" strokeWidth="1.8" fill="none"/>
                        <text x="6" y="15" fill="#f1f5f9" fontFamily="monospace" fontSize="11">a₁₁   a₁₂</text>
                        <text x="6" y="30" fill="#f1f5f9" fontFamily="monospace" fontSize="11">a₂₁   a₂₂</text>
                        <path d="M 58 0 h 5 v 34 h -5" stroke="#818cf8" strokeWidth="1.8" fill="none"/>
                      </g>
                      <rect x="190" y="34" width="42" height="18" rx="4" fill="#312e81" stroke="#818cf8" strokeWidth="1"/>
                      <text x="211" y="47" fill="#c7d2fe" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">2×2</text>
                    </g>

                    <path d="M 140 120 L 140 144" stroke="#818cf8" strokeWidth="2" markerEnd="url(#tax-arrow-indigo)"/>
                    <rect x="75" y="125" width="130" height="16" rx="8" fill="#0f172a" stroke="#818cf8" strokeWidth="1"/>
                    <text x="140" y="137" fill="#c7d2fe" fontSize="9" fontFamily="monospace" fontWeight="bold" textAnchor="middle">aᵢⱼ = 0  (i ≠ j)</text>

                    {/* Step 2: Diagonal */}
                    <g transform="translate(15, 148)">
                      <rect width="250" height="75" rx="6" fill="#2e1065" fillOpacity="0.9" stroke="#a855f7" strokeWidth="1.2"/>
                      <text x="125" y="20" fontFamily="sans-serif" fontSize="12" fontWeight="700" fill="#e9d5ff" textAnchor="middle">विकर्ण आव्यूह (Diagonal Matrix)</text>
                      <g transform="translate(90, 28)">
                        <path d="M 0 0 h -5 v 34 h 5" stroke="#a855f7" strokeWidth="1.8" fill="none"/>
                        <text x="8" y="15" fontFamily="monospace" fontSize="11"><tspan fill="#fbbf24" fontWeight="bold">3</tspan>   <tspan fill="#64748b">0</tspan></text>
                        <text x="8" y="30" fontFamily="monospace" fontSize="11"><tspan fill="#64748b">0</tspan>   <tspan fill="#fbbf24" fontWeight="bold">5</tspan></text>
                        <path d="M 48 0 h 5 v 34 h -5" stroke="#a855f7" strokeWidth="1.8" fill="none"/>
                      </g>
                    </g>

                    <path d="M 140 223 L 140 247" stroke="#a855f7" strokeWidth="2" markerEnd="url(#tax-arrow-purple)"/>
                    <rect x="70" y="228" width="140" height="16" rx="8" fill="#0f172a" stroke="#a855f7" strokeWidth="1"/>
                    <text x="140" y="240" fill="#e9d5ff" fontSize="9" fontFamily="monospace" fontWeight="bold" textAnchor="middle">विकर्ण अवयव = 1 (k = 1)</text>

                    {/* Step 3: Identity */}
                    <g transform="translate(15, 252)">
                      <rect width="250" height="115" rx="6" fill="#4c0519" fillOpacity="0.9" stroke="#ec4899" strokeWidth="1.2"/>
                      <text x="125" y="20" fontFamily="sans-serif" fontSize="12" fontWeight="700" fill="#fbcfe8" textAnchor="middle">तत्समक आव्यूह (Identity Matrix I)</text>
                      <g transform="translate(90, 28)">
                        <path d="M 0 0 h -5 v 34 h 5" stroke="#ec4899" strokeWidth="1.8" fill="none"/>
                        <text x="8" y="15" fontFamily="monospace" fontSize="12"><tspan fill="#f43f5e" fontWeight="bold">1</tspan>   <tspan fill="#64748b">0</tspan></text>
                        <text x="8" y="30" fontFamily="monospace" fontSize="12"><tspan fill="#64748b">0</tspan>   <tspan fill="#f43f5e" fontWeight="bold">1</tspan></text>
                        <path d="M 48 0 h 5 v 34 h -5" stroke="#ec4899" strokeWidth="1.8" fill="none"/>
                      </g>
                      <text x="125" y="92" fontFamily="monospace" fontSize="11" fontWeight="bold" fill="#fda4af" textAnchor="middle">गुणधर्म: I · A = A · I = A</text>
                    </g>
                  </g>

                  {/* Column 3: Zero & Scalar (x=680) [40px GAP] */}
                  <g transform="translate(680, 90)">
                    {/* Zero */}
                    <g transform="translate(0, 0)">
                      <rect width="280" height="185" fill="url(#tax-bg-emerald)" stroke="#059669" strokeWidth="1.5" rx="8"/>
                      <text x="140" y="24" fontFamily="sans-serif" fontSize="13" fontWeight="700" fill="#34d399" textAnchor="middle">3. शून्य आव्यूह (Zero Matrix O)</text>
                      <line x1="15" y1="34" x2="265" y2="34" stroke="#059669" strokeWidth="1" opacity="0.3"/>
                      <text x="140" y="55" fontFamily="sans-serif" fontSize="11" fill="#94a3b8" textAnchor="middle">सभी अवयव शून्य (aᵢⱼ = 0,  ∀ i, j)</text>
                      <g transform="translate(35, 75)">
                        <text x="0" y="26" fill="#34d399" fontFamily="monospace" fontSize="13" fontWeight="bold">O₂×₃ =</text>
                        <g transform="translate(62, 0)">
                          <path d="M 0 0 h -5 v 42 h 5" stroke="#34d399" strokeWidth="1.8" fill="none"/>
                          <text x="12" y="17" fill="#a7f3d0" fontFamily="monospace" fontSize="12">0   0   0</text>
                          <text x="12" y="34" fill="#a7f3d0" fontFamily="monospace" fontSize="12">0   0   0</text>
                          <path d="M 95 0 h 5 v 42 h -5" stroke="#34d399" strokeWidth="1.8" fill="none"/>
                        </g>
                      </g>
                      <rect x="30" y="135" width="220" height="28" rx="6" fill="#064e3b" fillOpacity="0.6" stroke="#34d399" strokeWidth="1"/>
                      <text x="140" y="153" fill="#a7f3d0" fontFamily="monospace" fontSize="11" fontWeight="bold" textAnchor="middle">योग तत्समक: A + O = A</text>
                    </g>

                    {/* Scalar (x=0, y=200 relative -> y=290 absolute) */}
                    <g transform="translate(0, 200)">
                      <rect width="280" height="185" fill="url(#tax-bg-blue)" stroke="#0284c7" strokeWidth="1.5" rx="8"/>
                      <text x="140" y="24" fontFamily="sans-serif" fontSize="13" fontWeight="700" fill="#22d3ee" textAnchor="middle">अदिश आव्यूह (Scalar Matrix)</text>
                      <line x1="15" y1="34" x2="265" y2="34" stroke="#0284c7" strokeWidth="1" opacity="0.3"/>
                      <g transform="translate(15, 45)">
                        <text x="0" y="14" fontFamily="sans-serif" fontSize="11" fill="#94a3b8">Scalar Matrix:</text>
                        <text x="80" y="14" fontFamily="sans-serif" fontSize="11" fill="#22d3ee" fontWeight="bold">(aᵢᵢ = k)</text>
                      </g>
                      <g transform="translate(50, 75)">
                        <g transform="translate(0, 0)">
                          <path d="M 0 0 h -5 v 38 h 5" stroke="#22d3ee" strokeWidth="1.8" fill="none"/>
                          <text x="8" y="16" fontFamily="monospace" fontSize="12"><tspan fill="#22d3ee" fontWeight="bold">k</tspan>   <tspan fill="#64748b">0</tspan></text>
                          <text x="8" y="32" fontFamily="monospace" fontSize="12"><tspan fill="#64748b">0</tspan>   <tspan fill="#22d3ee" fontWeight="bold">k</tspan></text>
                          <path d="M 48 0 h 5 v 38 h -5" stroke="#22d3ee" strokeWidth="1.8" fill="none"/>
                        </g>
                        <text x="75" y="24" fill="#e0f2fe" fontFamily="monospace" fontSize="13" fontWeight="bold">=  k · I</text>
                        <path d="M -15 16 L -5 16" stroke="#22d3ee" strokeWidth="1.2" markerEnd="url(#tax-ptr-cyan)"/>
                      </g>
                      <rect x="25" y="130" width="230" height="32" rx="6" fill="#0c4a6e" fillOpacity="0.8" stroke="#0284c7" strokeWidth="1"/>
                      <text x="140" y="150" fill="#e0f2fe" fontFamily="sans-serif" fontSize="11" fontWeight="600" textAnchor="middle">यदि k = 1 ➔ तत्समक आव्यूह (I)</text>
                    </g>
                  </g>
                </svg>
              </div>
            </div>

            {/* Section 3: Equality */}
            <div className={cn("p-6 rounded-2xl border shadow-sm", theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200")}>
              <h3 className="text-xl font-bold mb-3 text-indigo-400">3. आव्यूहों की समानता (Equality of Matrices)</h3>
              <p className="text-sm leading-relaxed mb-3">
                दो आव्यूह <span className="font-mono">A = [a_ij]</span> तथा <span className="font-mono">B = [b_ij]</span> समान कहलाते हैं (अर्थात् <span className="font-mono">A = B</span>), यदि और केवल यदि वे निम्नलिखित दो अनिवार्य शर्तों को पूरा करते हों:
              </p>
              <ol className="list-decimal pl-6 space-y-2 text-sm opacity-90 mb-4">
                <li><strong>समान कोटि (Same Order):</strong> दोनों आव्यूहों की कोटि समान होनी चाहिए (जैसे, दोनों m × n कोटि के हों)।</li>
                <li><strong>संगत अवयवों की समानता (Equality of Corresponding Elements):</strong> आव्यूह A का प्रत्येक अवयव, आव्यूह B के संगत अवयव के बराबर होना चाहिए (<span className="font-mono">a_ij = b_ij</span>)।</li>
              </ol>
              <div className={cn("p-4 rounded-xl border italic text-sm space-y-2", theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-indigo-50/50 border-indigo-100")}>
                <p className="font-bold not-italic mb-1 text-indigo-300">प्रोफेसर और छात्र की शंका संवाद:</p>
                <p><strong>छात्र:</strong> "प्रोफेसर, एक शंका है! यदि मेरे पास दो आव्यूह हैं—एक की कोटि 2 × 3 है और दूसरे की कोटि 3 × 2 है, तथा दोनों में बिल्कुल समान छह संख्याएँ मौजूद हैं, तो क्या हम उन्हें समान आव्यूह मान सकते हैं?"</p>
                <p><strong>प्रोफेसर का स्पष्टीकरण:</strong> नहीं, वे कदापि समान नहीं हो सकते। आव्यूह की समानता की प्रथम शर्त ही यह है कि उनकी <strong>कोटि (Order) पूर्णतः समान</strong> होनी चाहिए। कोटि भिन्न होने पर अवयवों का संगत स्थान (positional correspondence) ही परिभाषित नहीं हो पाता। अतः 2 × 3 कोटि का आव्यूह 3 × 2 कोटि के आव्यूह के बराबर नहीं हो सकता।</p>
              </div>
            </div>

            {/* Section 4: Worked Example */}
            <div className={cn("p-6 rounded-2xl border shadow-sm", theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200")}>
              <h3 className="text-xl font-bold mb-3 text-indigo-400">4. विस्तृत उदाहरण (Detailed Step-by-Step Worked-Out Example)</h3>
              <p className="text-sm font-semibold mb-3">
                <strong>प्रश्न:</strong> यदि <span className="font-mono">[x + 3, z + 4; 2y - 7, 4a - 6] = [0, 6; 3y, 2a]</span> हो, तो अज्ञात राशियों x, y, z, तथा a के मान ज्ञात कीजिए।
              </p>
              <div className="space-y-3 text-sm opacity-90 pl-4 border-l-2 border-indigo-500">
                <p><strong>चरण 1: आव्यूहों की कोटि का परीक्षण।</strong> बायाँ आव्यूह 2 × 2 कोटि का है और दायाँ आव्यूह भी 2 × 2 कोटि का है। दोनों की कोटि समान है।</p>
                <p><strong>चरण 2: समानता की परिभाषा लागू करना।</strong> चूँकि दोनों आव्यूह समान हैं, इनके संगत अवयव भी परस्पर बराबर होंगे (<span className="font-mono">a_ij = b_ij</span>)।</p>
                <p><strong>चरण 3: समीकरण निर्मित करना एवं हल करना।</strong></p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                  <div className="bg-slate-500/10 p-3 rounded-xl font-mono text-xs">
                    1. (a₁₁): x + 3 = 0 <span className="text-emerald-400 font-bold">&rArr; x = -3</span>
                  </div>
                  <div className="bg-slate-500/10 p-3 rounded-xl font-mono text-xs">
                    2. (a₁₂): z + 4 = 6 <span className="text-emerald-400 font-bold">&rArr; z = 2</span>
                  </div>
                  <div className="bg-slate-500/10 p-3 rounded-xl font-mono text-xs">
                    3. (a₂₁): 2y - 7 = 3y <span className="text-emerald-400 font-bold">&rArr; y = -7</span>
                  </div>
                  <div className="bg-slate-500/10 p-3 rounded-xl font-mono text-xs">
                    4. (a₂₂): 4a - 6 = 2a <span className="text-emerald-400 font-bold">&rArr; a = 3</span>
                  </div>
                </div>
                <p className="font-bold text-emerald-400 pt-2 text-base">अंतिम उत्तर: x = -3, y = -7, z = 2, a = 3</p>
              </div>
            </div>

            {/* Section 5: Checkpoint & Practice Questions with Interactive Solvers */}
            <div className={cn("p-6 rounded-2xl border shadow-sm", theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200")}>
              <h3 className="text-xl font-bold mb-3 text-indigo-400">5. समझ की जाँच एवं अभ्यास प्रश्न (Checkpoint & Practice Questions)</h3>
              <p className="text-sm mb-4 opacity-90">आगे बढ़ने से पूर्व, निम्नलिखित दो मानक अभ्यास प्रश्नों को हल करके अपनी समझ की पुष्टि कीजिए:</p>
              
              {/* Question 1 */}
              <div className={cn("p-4 rounded-xl border mb-6", theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-200")}>
                <h4 className="font-bold text-sm mb-2 text-indigo-300">प्रश्न 1:</h4>
                <p className="text-sm mb-3">
                  एक 2 × 2 आव्यूह <span className="font-mono">A = [a_ij]</span> की रचना कीजिए जिसके अवयव <span className="font-mono">a_ij = (i - 2j)^2 / 2</span> द्वारा दिए गए हैं। आव्यूह A के सभी अवयवों को चरणबद्ध रूप से ज्ञात कीजिए।
                </p>
                <button
                  onClick={() => setShowQ1Answer(!showQ1Answer)}
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-all flex items-center gap-2 shadow"
                >
                  <CheckCircle2 size={16} /> {showQ1Answer ? 'हल छुपाएं (Hide Solution)' : 'चरणबद्ध हल देखें (Show Step-by-Step Solution)'}
                </button>
                {showQ1Answer && (
                  <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="mt-4 space-y-2 text-xs font-mono bg-slate-950 p-4 rounded-xl border border-indigo-500/30 text-indigo-200">
                    <p>• a₁₁ = (1 - 2(1))² / 2 = (-1)² / 2 = 1/2 = 0.5</p>
                    <p>• a₁₂ = (1 - 2(2))² / 2 = (-3)² / 2 = 9/2 = 4.5</p>
                    <p>• a₂₁ = (2 - 2(1))² / 2 = (0)² / 2 = 0</p>
                    <p>• a₂₂ = (2 - 2(2))² / 2 = (-2)² / 2 = 4/2 = 2</p>
                    <div className="mt-3 p-3 bg-indigo-950/50 rounded border border-indigo-500/40 text-center font-bold text-sm text-white">
                      आव्यूह A = <span className="font-mono">[0.5, 4.5; 0, 2]</span>
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Question 2 */}
              <div className={cn("p-4 rounded-xl border", theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-200")}>
                <h4 className="font-bold text-sm mb-2 text-indigo-300">प्रश्न 2:</h4>
                <p className="text-sm mb-3">
                  यदि निम्नलिखित आव्यूह समान हैं, तो a, b, c और d के मान ज्ञात कीजिए:<br/>
                  <code className="bg-slate-500/20 px-2.5 py-1.5 rounded inline-block my-2 text-xs font-mono">
                    [a - b, 2a + c; 2a - b, 3c + d] = [-1, 5; 0, 13]
                  </code>
                </p>
                <button
                  onClick={() => setShowQ2Answer(!showQ2Answer)}
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-all flex items-center gap-2 shadow"
                >
                  <CheckCircle2 size={16} /> {showQ2Answer ? 'हल छुपाएं (Hide Solution)' : 'चरणबद्ध हल देखें (Show Step-by-Step Solution)'}
                </button>
                {showQ2Answer && (
                  <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="mt-4 space-y-2 text-xs font-mono bg-slate-950 p-4 rounded-xl border border-indigo-500/30 text-indigo-200">
                    <p>1. a - b = -1 तथा 2a - b = 0 &rArr; b = 2a</p>
                    <p>2. a - 2a = -1 &rArr; -a = -1 &rArr; <strong className="text-emerald-400">a = 1</strong>, <strong className="text-emerald-400">b = 2</strong></p>
                    <p>3. 2a + c = 5 &rArr; 2(1) + c = 5 &rArr; <strong className="text-emerald-400">c = 3</strong></p>
                    <p>4. 3c + d = 13 &rArr; 3(3) + d = 13 &rArr; 9 + d = 13 &rArr; <strong className="text-emerald-400">d = 4</strong></p>
                    <div className="mt-3 p-3 bg-indigo-950/50 rounded border border-indigo-500/40 text-center font-bold text-sm text-white">
                      अंतिम उत्तर: a = 1, b = 2, c = 3, d = 4
                    </div>
                  </motion.div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
          {/* Matrix A Input */}
          <div className={cn("p-4 rounded-2xl border flex flex-col items-center", theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200")}>
            <div className="flex justify-between items-center mb-4 w-full">
               <h3 className="font-bold">Matrix A</h3>
               <div className="flex gap-2 text-sm items-center flex-wrap">
                 <div className="flex items-center gap-1 border-r pr-2 mr-1 border-slate-300/50">
                    <label className="text-xs">k=</label>
                    <input 
                      type="number" 
                      value={scalarA} 
                      onChange={e => setScalarA(parseFloat(e.target.value) || 0)} 
                      className={cn("w-12 p-1 rounded border text-xs", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                    />
                 </div>
                 <button 
                   onClick={() => handleTranspose('A')}
                   className={cn("px-2 py-1 rounded border text-xs font-medium transition-all", theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-300" : "bg-white border-slate-300 hover:bg-slate-100 text-slate-700")}
                 >
                   Transpose
                 </button>
                 <label>Size:</label>
                 <select 
                   className={cn("p-1 rounded border", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                   value={`${sizeA.rows}x${sizeA.cols}`}
                   onChange={(e) => {
                     const [r, c] = e.target.value.split('x').map(Number);
                     setSizeA({ rows: r, cols: c });
                   }}
                 >
                   {[1,2,3].map(r => [1,2,3].map(c => <option key={`${r}x${c}`} value={`${r}x${c}`}>{r}x{c}</option>))}
                 </select>
               </div>
            </div>
            <div className="flex justify-center border-l-2 border-r-2 border-slate-500 px-2 py-4">
               <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${sizeA.cols}, minmax(0, 1fr))` }}>
                 {Array(sizeA.rows).fill(0).map((_, i) => (
                   Array(sizeA.cols).fill(0).map((_, j) => (
                     <input
                       key={`A-${i}-${j}`}
                       type="number"
                       className={cn("w-12 h-12 text-center rounded bg-transparent border focus:ring-2 outline-none transition-all", theme === 'dark' ? "border-slate-700 focus:border-indigo-500" : "border-slate-300 focus:border-indigo-500")}
                       value={matrixA[i][j]}
                       onChange={(e) => handleCellChange('A', i, j, e.target.value)}
                     />
                   ))
                 ))}
               </div>
            </div>
          </div>

          {/* Matrix B Input */}
          <div className={cn("p-4 rounded-2xl border flex flex-col items-center", theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-slate-50 border-slate-200")}>
            <div className="flex justify-between items-center mb-4 w-full">
               <h3 className="font-bold">Matrix B</h3>
               <div className="flex gap-2 text-sm items-center flex-wrap">
                 <div className="flex items-center gap-1 border-r pr-2 mr-1 border-slate-300/50">
                    <label className="text-xs">k=</label>
                    <input 
                      type="number" 
                      value={scalarB} 
                      onChange={e => setScalarB(parseFloat(e.target.value) || 0)} 
                      className={cn("w-12 p-1 rounded border text-xs", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                    />
                 </div>
                 <button 
                   onClick={() => handleTranspose('B')}
                   className={cn("px-2 py-1 rounded border text-xs font-medium transition-all", theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-300" : "bg-white border-slate-300 hover:bg-slate-100 text-slate-700")}
                 >
                   Transpose
                 </button>
                 <label>Size:</label>
                 <select 
                   className={cn("p-1 rounded border", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                   value={`${sizeB.rows}x${sizeB.cols}`}
                   onChange={(e) => {
                     const [r, c] = e.target.value.split('x').map(Number);
                     setSizeB({ rows: r, cols: c });
                   }}
                 >
                   {[1,2,3].map(r => [1,2,3].map(c => <option key={`${r}x${c}`} value={`${r}x${c}`}>{r}x{c}</option>))}
                 </select>
               </div>
            </div>
            <div className="flex justify-center border-l-2 border-r-2 border-slate-500 px-2 py-4">
               <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${sizeB.cols}, minmax(0, 1fr))` }}>
                 {Array(sizeB.rows).fill(0).map((_, i) => (
                   Array(sizeB.cols).fill(0).map((_, j) => (
                     <input
                       key={`B-${i}-${j}`}
                       type="number"
                       className={cn("w-12 h-12 text-center rounded bg-transparent border focus:ring-2 outline-none transition-all", theme === 'dark' ? "border-slate-700 focus:border-indigo-500" : "border-slate-300 focus:border-indigo-500")}
                       value={matrixB[i][j]}
                       onChange={(e) => handleCellChange('B', i, j, e.target.value)}
                     />
                   ))
                 ))}
               </div>
            </div>
          </div>
        </div>

        {/* Operations */}
        <div className="flex gap-4 justify-center flex-wrap">
          <button 
            onClick={() => setOperation('add')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2", operation === 'add' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            <Plus size={16} /> Add (A + B)
          </button>
          <button 
            onClick={() => setOperation('subtract')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2", operation === 'subtract' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            <Minus size={16} /> Subtract (A - B)
          </button>
          <button 
            onClick={() => setOperation('multiply')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2", operation === 'multiply' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            <X size={16} /> Multiply (A × B)
          </button>
          <button 
            onClick={() => setOperation('detA')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'detA' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Calculate Determinant (A)
          </button>
          <button 
            onClick={() => setOperation('detB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'detB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Calculate Determinant (B)
          </button>
          <button 
            onClick={() => setOperation('invA')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'invA' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Inv(A)
          </button>
          <button 
            onClick={() => setOperation('invB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'invB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Inv(B)
          </button>
          <button 
            onClick={() => setOperation('scalarA')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'scalarA' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            k×A
          </button>
          <button 
            onClick={() => setOperation('scalarB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'scalarB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            k×B
          </button>
          <button 
            onClick={() => setOperation('refA')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'refA' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            REF(A)
          </button>
          <button 
            onClick={() => setOperation('refB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'refB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            REF(B)
          </button>
          <button 
            onClick={() => setOperation('rankA')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'rankA' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Rank(A)
          </button>
          <button 
            onClick={() => setOperation('rankB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'rankB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Rank(B)
          </button>
          <button 
            onClick={() => {
              setMatrixA(Array(3).fill(0).map(() => Array(3).fill(0)));
              setMatrixB(Array(3).fill(0).map(() => Array(3).fill(0)));
              setOperation(null);
            }}
            className={cn("px-4 py-2 rounded-xl font-bold flex items-center gap-2", theme === 'dark' ? "bg-rose-500/20 text-rose-400 hover:bg-rose-500/30" : "bg-rose-100 text-rose-600 hover:bg-rose-200")}
          >
            <RotateCcw size={16} /> Reset
          </button>
        </div>

        {/* Results */}
        {operation && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={cn("p-6 rounded-2xl border", theme === 'dark' ? "bg-slate-900 border-indigo-500/30" : "bg-white border-indigo-200 shadow-xl shadow-indigo-100/50")}
          >
            {operation === 'add' && renderAddition()}
            {operation === 'subtract' && renderSubtraction()}
            {operation === 'multiply' && renderMultiplication()}
            {operation === 'detA' && renderDeterminant('A')}
            {operation === 'detB' && renderDeterminant('B')}
            {operation === 'invA' && renderInverse('A')}
            {operation === 'invB' && renderInverse('B')}
            {operation === 'scalarA' && renderScalar('A')}
            {operation === 'scalarB' && renderScalar('B')}
            {operation === 'refA' && renderREF('A')}
            {operation === 'refB' && renderREF('B')}
            {operation === 'rankA' && renderRank('A')}
            {operation === 'rankB' && renderRank('B')}
          </motion.div>
        )}
          </div>
        )}
      </div>
    </div>
  );
}

function MatrixDisplay({ M, rows, cols, isDet = false }: { M: number[][], rows: number, cols: number, isDet?: boolean }) {
  return (
    <div className={cn("grid gap-2 px-2 py-2 border-slate-500", isDet ? "border-l border-r" : "border-l-2 border-r-2")} style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
      {Array(rows).fill(0).map((_, i) => (
        Array(cols).fill(0).map((_, j) => (
          <div key={`${i}-${j}`} className="w-10 h-10 flex items-center justify-center font-mono font-bold bg-slate-500/10 rounded text-sm">
            {M[i]?.[j] ?? 0}
          </div>
        ))
      ))}
    </div>
  );
}
