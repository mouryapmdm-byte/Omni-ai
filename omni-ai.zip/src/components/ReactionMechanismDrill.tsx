import React, { useState, useEffect } from 'react';
import { cn } from '@/src/lib/utils';
import { Beaker, Sparkles, CheckCircle2, XCircle, HelpCircle, ArrowRight, RotateCcw, Award, Flame, BookOpen, ExternalLink, ShieldAlert, Zap, Lightbulb } from 'lucide-react';

interface DrillProblem {
  id: string;
  type: 'name_reaction' | 'interconversion';
  title: string;
  subtitle: string;
  reactants: string;
  reagents: string;
  options: string[];
  correctAnswer: string;
  mechanismSteps: string[];
  explanation: string;
  chapterRef: string;
  chapterNumber: number;
  difficulty: 'Easy' | 'Medium' | 'Advanced (JEE/NEET)';
}

const DRILL_PROBLEMS: DrillProblem[] = [
  {
    id: 'nr-1',
    type: 'name_reaction',
    title: 'Reimer-Tiemann Reaction',
    subtitle: 'Phenol to Salicylaldehyde',
    reactants: 'Phenol + $\\text{CHCl}_3$ + $\\text{NaOH}$',
    reagents: 'Chloroform, Aqueous Sodium Hydroxide ($\\Delta$) followed by $\\text{H}^+$',
    options: [
      'Salicylaldehyde (2-Hydroxybenzaldehyde)',
      'Benzoic Acid',
      'Salicylic Acid (2-Hydroxybenzoic acid)',
      'Benzyl Alcohol'
    ],
    correctAnswer: 'Salicylaldehyde (2-Hydroxybenzaldehyde)',
    mechanismSteps: [
      'Base ($\\text{OH}^-$) abstracts a proton from chloroform ($\\text{CHCl}_3$) to form trichloromethide ion ($\\text{CCl}_3^-$).',
      'Loss of chloride ion gives electrophilic divalent carbon species: dichlorocarbene ($\\text{:CCl}_2$).',
      'Phenoxide ion attacks dichlorocarbene to form a substituted benzal chloride intermediate.',
      'Hydrolysis with aqueous alkali yields Salicylaldehyde with formyl group (-CHO) ortho to -OH.'
    ],
    explanation: 'Reimer-Tiemann reaction involves the introduction of an aldehyde group (-CHO) into the benzene ring of phenol ortho to the hydroxyl group using chloroform and base via dichlorocarbene intermediate.',
    chapterRef: '11. Alcohols, Phenols and Ethers',
    chapterNumber: 11,
    difficulty: 'Medium'
  },
  {
    id: 'nr-2',
    type: 'name_reaction',
    title: 'Cannizzaro Reaction',
    subtitle: 'Self-oxidation and reduction of aldehydes without $\\alpha$-hydrogens',
    reactants: '2 $\\text{HCHO}$ or 2 $\\text{C}_6\\text{H}_5\\text{CHO}$',
    reagents: 'Concentrated $\\text{NaOH}$ or $\\text{KOH}$ (50%)',
    options: [
      'Sodium salt of acid + Alcohol (Disproportionation)',
      'Only Carboxylic Acid',
      'Only Primary Alcohol',
      'Ester formation via Tishchenko reaction'
    ],
    correctAnswer: 'Sodium salt of acid + Alcohol (Disproportionation)',
    mechanismSteps: [
      'Hydroxide ion attacks the carbonyl carbon of the non-$\\alpha$-hydrogen aldehyde.',
      'Hydride ion ($\\text{H}^-$) is transferred from the resulting tetrahedral intermediate to another molecule of aldehyde.',
      'Oxidation product (carboxylate anion) and reduction product (primary alcohol) are formed simultaneously.'
    ],
    explanation: 'Aldehydes without $\\alpha$-hydrogen atoms undergo self-oxidation and reduction (disproportionation) on treatment with concentrated alkali.',
    chapterRef: '12. Aldehydes, Ketones and Carboxylic Acids',
    chapterNumber: 12,
    difficulty: 'Medium'
  },
  {
    id: 'nr-3',
    type: 'name_reaction',
    title: 'Aldol Condensation',
    subtitle: 'Reaction of aldehydes/ketones possessing $\\alpha$-hydrogens',
    reactants: '2 $\\text{CH}_3\\text{CHO}$',
    reagents: 'Dilute $\\text{NaOH}$ or $\\text{Ba(OH)}_2$',
    options: [
      '3-Hydroxybutanal (Aldol) $\\xrightarrow{\\Delta}$ But-2-enal',
      'Ethanol and Ethanoic Acid',
      'Diethyl Ether',
      'Acetone'
    ],
    correctAnswer: '3-Hydroxybutanal (Aldol) $\\xrightarrow{\\Delta}$ But-2-enal',
    mechanismSteps: [
      'Dilute base abstracts an $\\alpha$-hydrogen to generate a resonance-stabilized enolate ion.',
      'Enolate ion acts as a nucleophile and attacks the carbonyl carbon of another aldehyde molecule.',
      'Protonation yields $\\beta$-hydroxy aldehyde (aldol).',
      'Heating causes dehydration (loss of $\\text{H}_2\\text{O}$) to form $\\alpha,\\beta$-unsaturated carbonyl compound.'
    ],
    explanation: 'Aldehydes and ketones with at least one $\\alpha$-hydrogen undergo base-catalyzed addition to form $\\beta$-hydroxy compounds which readily dehydrate.',
    chapterRef: '12. Aldehydes, Ketones and Carboxylic Acids',
    chapterNumber: 12,
    difficulty: 'Easy'
  },
  {
    id: 'nr-4',
    type: 'name_reaction',
    title: "Kolbe's Reaction",
    subtitle: 'Kolbe-Schmitt Carboxylation of Phenol',
    reactants: 'Phenol + $\\text{NaOH}$ + $\\text{CO}_2$',
    reagents: '(i) $\\text{NaOH}$, $\\text{CO}_2$ ($400\\text{ K}, 4-7\\text{ atm}$) (ii) $\\text{H}^+$',
    options: [
      'Salicylic Acid (2-Hydroxybenzoic acid)',
      'Salicylaldehyde',
      'Phthalic Acid',
      'Benzoic Acid'
    ],
    correctAnswer: 'Salicylic Acid (2-Hydroxybenzoic acid)',
    mechanismSteps: [
      'Phenol is converted to sodium phenoxide with $\\text{NaOH}$, making it a stronger nucleophile for electrophilic attack.',
      'Phenoxide ion undergoes electrophilic substitution with weak electrophile $\\text{CO}_2$.',
      'Acidification yields 2-hydroxybenzoic acid (Salicylic acid), the precursor for aspirin.'
    ],
    explanation: 'Sodium phenoxide when heated with carbon dioxide under pressure followed by acid hydrolysis yields salicylic acid as the major product.',
    chapterRef: '11. Alcohols, Phenols and Ethers',
    chapterNumber: 11,
    difficulty: 'Advanced (JEE/NEET)'
  },
  {
    id: 'nr-5',
    type: 'name_reaction',
    title: 'Sandmeyer Reaction',
    subtitle: 'Transformation of Aryl Diazonium Salts',
    reactants: '$\\text{ArN}_2^+\\text{X}^-$',
    reagents: '$\\text{Cu}_2\\text{Cl}_2 / \\text{HCl}$ or $\\text{Cu}_2\\text{Br}_2 / \\text{HBr}$ or $\\text{CuCN} / \\text{KCN}$',
    options: [
      'Aryl Chloride, Bromide, or Cyanide',
      'Aryl Iodide',
      'Aryl Fluoride via Balz-Schiemann',
      'Phenol via hydrolysis'
    ],
    correctAnswer: 'Aryl Chloride, Bromide, or Cyanide',
    mechanismSteps: [
      'Aryl diazonium salt is prepared from primary aromatic amine via diazotization ($0-5^{\\circ}\\text{C}$).',
      'Treatment with cuprous halide ($\\text{Cu}_2\\text{Cl}_2$ or $\\text{Cu}_2\\text{Br}_2$) replaces the diazonium group with halogen.',
      'Nitrogen gas ($\\text{N}_2$) escapes as a stable leaving group driving the reaction to completion.'
    ],
    explanation: 'Sandmeyer reaction allows introduction of chloro, bromo, or cyano groups into the aromatic ring via copper(I) salt catalysis.',
    chapterRef: '13. Organic Compounds Containing Nitrogen',
    chapterNumber: 13,
    difficulty: 'Medium'
  },
  {
    id: 'ic-1',
    type: 'interconversion',
    title: 'Interconversion: Ethanol to Propan-2-ol',
    subtitle: 'Ascent of series and functional group transformation',
    reactants: 'Ethanol ($\\text{CH}_3\\text{CH}_2\\text{OH}$)',
    reagents: 'Multi-step sequence: (1) $\\text{PBr}_3$ (2) $\\text{KCN}$ (3) $\\text{H}_3\\text{O}^+, \\Delta$ (4) $\\text{LiAlH}_4$ (5) $\\text{Cu} / 573\\text{K}$ (6) $\\text{CH}_3\\text{MgBr}$ then $\\text{H}_3\\text{O}^+',
    options: [
      'Ethanol $\\to$ Bromoethane $\\to$ Propionitrile $\\to$ Propanoic acid $\\to$ Propan-1-ol $\\to$ Propanal $\\to$ Propan-2-ol',
      'Ethanol $\\to$ Ethene $\\to$ Propane',
      'Direct oxidation with $\\text{KMnO}_4$',
      'Reaction with $\\text{NaOH}$ and $\\text{I}_2$'
    ],
    correctAnswer: 'Ethanol $\\to$ Bromoethane $\\to$ Propionitrile $\\to$ Propanoic acid $\\to$ Propan-1-ol $\\to$ Propanal $\\to$ Propan-2-ol',
    mechanismSteps: [
      'Convert ethanol to bromoethane with $\\text{PBr}_3$.',
      'Treat with alcoholic $\\text{KCN}$ to increase carbon chain length (Propionitrile).',
      'Hydrolyze nitrile to Propanoic acid.',
      'Reduce with $\\text{LiAlH}_4$ to Propan-1-ol, oxidize to propanal, and react with methylmagnesium bromide followed by hydrolysis to yield Propan-2-ol.'
    ],
    explanation: 'This classic interconversion tests chain extension (ascent of series) using cyanide followed by Grignard addition or reduction pathways.',
    chapterRef: 'Appendix [B]: Interconversion of Organic Compounds',
    chapterNumber: 13,
    difficulty: 'Advanced (JEE/NEET)'
  },
  {
    id: 'ic-2',
    type: 'interconversion',
    title: 'Interconversion: Benzene to Acetophenone',
    subtitle: 'Friedel-Crafts Acylation',
    reactants: 'Benzene ($\\text{C}_6\\text{H}_6$)',
    reagents: 'Acetyl chloride ($\\text{CH}_3\\text{COCl}$) in the presence of anhydrous $\\text{AlCl}_3$',
    options: [
      'Acetophenone ($\\text{C}_6\\text{H}_5\\text{COCH}_3$)',
      'Benzaldehyde',
      'Toluene',
      'Benzoic Acid'
    ],
    correctAnswer: 'Acetophenone ($\\text{C}_6\\text{H}_5\\text{COCH}_3$)',
    mechanismSteps: [
      'Acetyl chloride reacts with Lewis acid catalyst anhydrous $\\text{AlCl}_3$ to generate acylium cation electrophile ($\\text{CH}_3\\text{C}^+=\\text{O}$).',
      'Electrophilic aromatic substitution of benzene ring by acylium ion.',
      'Complex decomposition with water yields Acetophenone.'
    ],
    explanation: 'Friedel-Crafts acylation of benzene with an acyl chloride in the presence of anhydrous aluminum chloride directly introduces an acyl group ($\\text{-COR}$), forming aryl ketones without rearrangement.',
    chapterRef: '12. Aldehydes, Ketones and Carboxylic Acids',
    chapterNumber: 12,
    difficulty: 'Medium'
  },
  {
    id: 'ic-3',
    type: 'interconversion',
    title: 'Interconversion: Aniline to Benzoic Acid',
    subtitle: 'Diazotization and Sandmeyer/Hydrolysis Sequence',
    reactants: 'Aniline ($\\text{C}_6\\text{H}_5\\text{NH}_2$)',
    reagents: '(i) $\\text{NaNO}_2 + \\text{HCl} \\ (0-5^{\\circ}\\text{C})$ (ii) $\\text{CuCN} / \\text{KCN}$ (iii) $\\text{H}_3\\text{O}^+, \\Delta$',
    options: [
      'Benzoic Acid (via Benzonitrile intermediate)',
      'Phenol',
      'Chlorobenzene',
      'Nitrobenzene'
    ],
    correctAnswer: 'Benzoic Acid (via Benzonitrile intermediate)',
    mechanismSteps: [
      'Convert aniline to benzenediazonium chloride using nitrous acid at $0-5^{\\circ}\\text{C}$.',
      'Treat diazonium salt with cuprous cyanide ($\\text{CuCN}$) to form benzonitrile (Sandmeyer cyanogen replacement).',
      'Acidic hydrolysis of benzonitrile yields Benzoic acid.'
    ],
    explanation: 'Conversion of aromatic amines to carboxylic acids requires diazotization, replacement with cyano group, and complete hydrolysis of the nitrile.',
    chapterRef: '13. Organic Compounds Containing Nitrogen',
    chapterNumber: 13,
    difficulty: 'Advanced (JEE/NEET)'
  }
];

interface ReactionMechanismDrillProps {
  theme: 'light' | 'dark';
  onOpenChapter: (chapterNumber: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const ReactionMechanismDrill: React.FC<ReactionMechanismDrillProps> = ({
  theme,
  onOpenChapter,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'name_reaction' | 'interconversion'>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [showMechanism, setShowMechanism] = useState(false);
  const [completedIds, setCompletedIds] = useState<string[]>([]);

  const filteredProblems = DRILL_PROBLEMS.filter(p => {
    const matchesTab = activeTab === 'all' || p.type === activeTab;
    const matchesDiff = selectedDifficulty === 'All' || p.difficulty === selectedDifficulty;
    return matchesTab && matchesDiff;
  });

  const currentProblem = filteredProblems[currentIndex] || filteredProblems[0];

  const handleSelectOption = (opt: string) => {
    if (isAnswerSubmitted) return;
    setSelectedOption(opt);
  };

  const handleSubmitAnswer = () => {
    if (!selectedOption || isAnswerSubmitted || !currentProblem) return;
    setIsAnswerSubmitted(true);
    const correct = selectedOption === currentProblem.correctAnswer;
    if (correct) {
      setScore(prev => prev + 100);
      setStreak(prev => prev + 1);
      if (!completedIds.includes(currentProblem.id)) {
        setCompletedIds(prev => [...prev, currentProblem.id]);
      }
      showNotification?.('Correct mechanism! +100 XP', 'success');
    } else {
      setStreak(0);
      showNotification?.('Incorrect. Review the mechanism steps below.', 'error');
    }
  };

  const handleNextProblem = () => {
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setShowMechanism(false);
    if (currentIndex < filteredProblems.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const resetDrill = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setShowMechanism(false);
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-y-auto p-6 md:p-8 selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-slate-50/50 text-slate-900"
    )}>
      {/* Header Banner */}
      <div className={cn(
        "p-6 rounded-3xl border mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl",
        theme === 'dark' ? "bg-gradient-to-r from-amber-950/60 via-slate-900 to-indigo-950/40 border-amber-900/40" : "bg-gradient-to-r from-amber-50 via-white to-indigo-50 border-amber-100"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-amber-500/30">
            <Flame size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                Competitive Mode Arena
              </span>
              <span className="text-[10px] font-bold text-slate-500">Appendix [A] & [B] Specialist Trainer</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Reaction Mechanism & Interconversion Drill
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Master high-yield name reactions, electron-pushing pathways, and multi-step organic interconversions for elite entrance tests (JEE/NEET).
            </p>
          </div>
        </div>

        {/* Stats Pill */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-amber-500/10 text-amber-600 dark:text-amber-400 px-4 py-2 rounded-2xl font-bold text-xs border border-amber-500/20">
            <Award size={16} />
            <span>Score: {score} XP</span>
          </div>
          <div className="flex items-center gap-2 bg-orange-500/10 text-orange-600 dark:text-orange-400 px-4 py-2 rounded-2xl font-bold text-xs border border-orange-500/20">
            <Flame size={16} />
            <span>Streak: {streak}x</span>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
          {[
            { id: 'all', label: 'All Problems' },
            { id: 'name_reaction', label: 'Appendix [A] Name Reactions' },
            { id: 'interconversion', label: 'Appendix [B] Interconversions' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id as any); setCurrentIndex(0); setSelectedOption(null); setIsAnswerSubmitted(false); }}
              className={cn(
                "px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap active:scale-95",
                activeTab === tab.id
                  ? "bg-amber-600 text-white shadow-lg shadow-amber-500/30"
                  : theme === 'dark'
                  ? "bg-slate-800 text-slate-300 hover:bg-slate-700"
                  : "bg-white text-slate-700 hover:bg-slate-100 border border-slate-200"
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <span className="text-xs font-bold text-slate-400">Difficulty:</span>
          <select
            value={selectedDifficulty}
            onChange={(e) => { setSelectedDifficulty(e.target.value); setCurrentIndex(0); setSelectedOption(null); setIsAnswerSubmitted(false); }}
            className={cn(
              "px-3 py-2 rounded-xl text-xs font-bold border outline-none cursor-pointer",
              theme === 'dark' ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-900"
            )}
          >
            <option value="All">All Levels</option>
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Advanced (JEE/NEET)">Advanced (JEE/NEET)</option>
          </select>
        </div>
      </div>

      {/* Main Drill Card */}
      {filteredProblems.length === 0 ? (
        <div className="p-12 rounded-3xl border text-center my-auto">
          <HelpCircle className="mx-auto text-slate-400 mb-3" size={36} />
          <h3 className="text-lg font-bold">No problems found for this filter</h3>
          <p className="text-sm text-slate-500 mt-1">Try switching categories or difficulty filters.</p>
        </div>
      ) : (
        <div className={cn(
          "p-6 md:p-8 rounded-3xl border shadow-xl flex flex-col transition-all",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          {/* Question Header */}
          <div className="flex items-center justify-between gap-4 mb-4 pb-4 border-b border-slate-100 dark:border-slate-700/60">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className={cn(
                  "text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-lg",
                  currentProblem.type === 'name_reaction' ? "bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20" : "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20"
                )}>
                  {currentProblem.type === 'name_reaction' ? 'Appendix [A] Name Reaction' : 'Appendix [B] Interconversion'}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                  {currentProblem.difficulty}
                </span>
              </div>
              <h2 className="text-xl md:text-2xl font-black tracking-tight">{currentProblem.title}</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">{currentProblem.subtitle}</p>
            </div>

            <div className="text-right">
              <span className="text-xs font-bold text-slate-400">
                Problem {currentIndex + 1} of {filteredProblems.length}
              </span>
            </div>
          </div>

          {/* Reaction Equation Box */}
          <div className={cn(
            "p-5 rounded-2xl border mb-6 flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-sm shadow-inner",
            theme === 'dark' ? "bg-slate-900/80 border-slate-700" : "bg-slate-50 border-slate-200"
          )}>
            <div>
              <div className="text-[10px] font-sans font-black uppercase tracking-widest text-slate-400 mb-1">Reactants / Starting Material</div>
              <div className="font-bold text-amber-600 dark:text-amber-400">{currentProblem.reactants}</div>
            </div>
            <div className="text-center px-4 py-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 dark:text-indigo-400 text-xs font-sans font-bold">
              {currentProblem.reagents}
            </div>
            <div className="text-right">
              <div className="text-[10px] font-sans font-black uppercase tracking-widest text-slate-400 mb-1">Target Product / Pathway</div>
              <div className="font-bold text-emerald-600 dark:text-emerald-400">?</div>
            </div>
          </div>

          {/* Options List */}
          <div className="space-y-3 mb-6">
            <div className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
              Select Correct Product or Sequence:
            </div>
            {currentProblem.options.map((opt, idx) => {
              const isSelected = selectedOption === opt;
              const isCorrect = opt === currentProblem.correctAnswer;
              let optionStyle = theme === 'dark' ? "bg-slate-900/60 border-slate-700 hover:border-amber-500/50" : "bg-slate-50 border-slate-200 hover:border-amber-300";

              if (isAnswerSubmitted) {
                if (isCorrect) {
                  optionStyle = "bg-emerald-500/10 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-bold";
                } else if (isSelected && !isCorrect) {
                  optionStyle = "bg-red-500/10 border-red-500 text-red-700 dark:text-red-300";
                }
              } else if (isSelected) {
                optionStyle = "bg-amber-500/10 border-amber-500 text-amber-700 dark:text-amber-300 font-bold";
              }

              return (
                <button
                  key={idx}
                  disabled={isAnswerSubmitted}
                  onClick={() => handleSelectOption(opt)}
                  className={cn(
                    "w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between gap-3 cursor-pointer",
                    optionStyle
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-xs font-bold shrink-0">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="text-sm">{opt}</span>
                  </div>
                  {isAnswerSubmitted && isCorrect && <CheckCircle2 className="text-emerald-500 shrink-0" size={18} />}
                  {isAnswerSubmitted && isSelected && !isCorrect && <XCircle className="text-red-500 shrink-0" size={18} />}
                </button>
              );
            })}
          </div>

          {/* Action / Submit Toolbar */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-700/60">
            <button
              onClick={() => setShowMechanism(!showMechanism)}
              className="flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline cursor-pointer"
            >
              <Lightbulb size={16} />
              <span>{showMechanism ? "Hide Step-by-Step Mechanism" : "View Mechanism & Explanation"}</span>
            </button>

            {!isAnswerSubmitted ? (
              <button
                disabled={!selectedOption}
                onClick={handleSubmitAnswer}
                className={cn(
                  "px-6 py-3 rounded-2xl font-bold text-sm transition-all shadow-lg flex items-center gap-2",
                  selectedOption
                    ? "bg-amber-600 hover:bg-amber-500 text-white shadow-amber-500/30 cursor-pointer active:scale-95"
                    : "bg-slate-300 dark:bg-slate-700 text-slate-500 cursor-not-allowed opacity-60"
                )}
              >
                <span>Submit Answer</span>
                <ArrowRight size={16} />
              </button>
            ) : (
              <button
                onClick={handleNextProblem}
                className="px-6 py-3 rounded-2xl font-bold text-sm bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/30 transition-all flex items-center gap-2 cursor-pointer active:scale-95"
              >
                <span>Next Problem</span>
                <ArrowRight size={16} />
              </button>
            )}
          </div>

          {/* Mechanism & Explanation Panel */}
          {showMechanism && (
            <div className={cn(
              "mt-6 p-6 rounded-2xl border animate-in fade-in slide-in-from-top-2 duration-300",
              theme === 'dark' ? "bg-slate-900 border-amber-500/30" : "bg-amber-50/50 border-amber-200"
            )}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  <Sparkles size={16} />
                  <span>Step-by-Step Electron Pushing Mechanism</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  <BookOpen size={14} />
                  <span>{currentProblem.chapterRef}</span>
                  <button
                    onClick={() => onOpenChapter(currentProblem.chapterNumber)}
                    className="p-1 hover:bg-indigo-500/10 rounded transition-colors"
                    title="Open Chapter in Explorer"
                  >
                    <ExternalLink size={12} />
                  </button>
                </div>
              </div>

              <div className="space-y-3 mb-4">
                {currentProblem.mechanismSteps.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-3 text-xs md:text-sm">
                    <div className="w-6 h-6 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </div>
                    <div className="leading-relaxed text-slate-700 dark:text-slate-300">{step}</div>
                  </div>
                ))}
              </div>

              <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border border-slate-200 dark:border-slate-700">
                <span className="font-bold text-slate-900 dark:text-white">Conceptual Summary: </span>
                {currentProblem.explanation}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
