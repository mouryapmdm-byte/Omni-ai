import { CalibrationRecord, CalibrationSummary, QuadrantPoint, QuadrantType } from './types';

/**
 * Normalizes 1-5 confidence rating to 0.2 - 1.0 scale
 */
export function normalizeConfidence(rating: number): number {
  return Math.min(1, Math.max(0.2, rating / 5));
}

/**
 * Classifies a single answer record into one of 4 metacognitive quadrants
 */
export function classifyQuadrant(confidenceRating: number, isCorrect: boolean): QuadrantType {
  const isHighConfidence = confidenceRating >= 3.5;

  if (isHighConfidence && isCorrect) return 'mastered';
  if (isHighConfidence && !isCorrect) return 'dangerous';
  if (!isHighConfidence && isCorrect) return 'underconfident';
  return 'learning';
}

/**
 * Calculates calibration metrics across a collection of records
 */
export function calculateCalibrationSummary(
  records: CalibrationRecord[],
  topicId: string = 'overall',
  topicTitle: string = 'Overall Metacognition'
): CalibrationSummary {
  if (!records || records.length === 0) {
    return {
      topicId,
      topicTitle,
      subject: 'All Subjects',
      totalAnswers: 0,
      avgConfidence: 0,
      rawAvgConfidence: 0,
      accuracy: 0,
      calibrationScore: 1.0, // Perfect baseline default when no data
      masteredCount: 0,
      dangerousCount: 0,
      underconfidentCount: 0,
      learningCount: 0
    };
  }

  let totalRawConfidence = 0;
  let correctCount = 0;
  let masteredCount = 0;
  let dangerousCount = 0;
  let underconfidentCount = 0;
  let learningCount = 0;

  records.forEach(r => {
    totalRawConfidence += r.confidenceRating;
    if (r.isCorrect) correctCount++;

    const quad = classifyQuadrant(r.confidenceRating, r.isCorrect);
    if (quad === 'mastered') masteredCount++;
    else if (quad === 'dangerous') dangerousCount++;
    else if (quad === 'underconfident') underconfidentCount++;
    else if (quad === 'learning') learningCount++;
  });

  const rawAvgConfidence = totalRawConfidence / records.length;
  const avgConfidence = normalizeConfidence(rawAvgConfidence);
  const accuracy = correctCount / records.length;

  // Calibration score = 1 - |avg_confidence - accuracy|
  const rawDiff = Math.abs(avgConfidence - accuracy);
  const calibrationScore = Math.max(0, Math.min(1, 1 - rawDiff));

  return {
    topicId,
    topicTitle,
    subject: records[0]?.subject || 'General',
    totalAnswers: records.length,
    avgConfidence: Number(avgConfidence.toFixed(2)),
    rawAvgConfidence: Number(rawAvgConfidence.toFixed(2)),
    accuracy: Number(accuracy.toFixed(2)),
    calibrationScore: Number(calibrationScore.toFixed(2)),
    masteredCount,
    dangerousCount,
    underconfidentCount,
    learningCount
  };
}

/**
 * Groups records by topic and calculates summary for each topic
 */
export function calculateTopicSummaries(records: CalibrationRecord[]): CalibrationSummary[] {
  const map = new Map<string, CalibrationRecord[]>();

  records.forEach(r => {
    const existing = map.get(r.topicId) || [];
    existing.push(r);
    map.set(r.topicId, existing);
  });

  const summaries: CalibrationSummary[] = [];

  map.forEach((topicRecords, topicId) => {
    const topicTitle = topicRecords[0]?.topicTitle || topicId;
    summaries.push(calculateCalibrationSummary(topicRecords, topicId, topicTitle));
  });

  // Sort by highest dangerous count first, then lowest calibration score
  return summaries.sort((a, b) => {
    if (b.dangerousCount !== a.dangerousCount) {
      return b.dangerousCount - a.dangerousCount;
    }
    return a.calibrationScore - b.calibrationScore;
  });
}

/**
 * Converts records into scatter plot points for 2x2 Quadrant Chart
 */
export function mapRecordsToQuadrantPoints(records: CalibrationRecord[]): QuadrantPoint[] {
  return records.map(r => ({
    id: `quad_${r.questionId}_${r.timestamp}`,
    questionId: r.questionId,
    topicId: r.topicId,
    topicTitle: r.topicTitle,
    confidenceNormalized: normalizeConfidence(r.confidenceRating),
    rawConfidence: r.confidenceRating,
    isCorrect: r.isCorrect,
    quadrant: classifyQuadrant(r.confidenceRating, r.isCorrect),
    timestamp: r.timestamp
  }));
}
