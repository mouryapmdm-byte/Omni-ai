import React, { useEffect, useRef } from 'react';
import { cn } from '@/src/lib/utils';

interface WaveformVisualizerProps {
  isAnimating: boolean;
  color?: string;
  className?: string;
  analyser?: AnalyserNode | null;
}

export const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({ isAnimating, color = 'bg-indigo-500', className, analyser }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!isAnimating) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    const dataArray = analyser ? new Uint8Array(analyser.frequencyBinCount) : null;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const bars = 12;
      const barWidth = 3;
      const gap = 2;
      const xStart = (canvas.width - (bars * (barWidth + gap))) / 2;

      if (analyser && dataArray) {
        analyser.getByteFrequencyData(dataArray);
      }

      for (let i = 0; i < bars; i++) {
        let h;
        if (analyser && dataArray) {
          // Use real-time audio data
          const step = Math.floor(dataArray.length / bars);
          const val = dataArray[i * step] / 255;
          h = Math.max(2, val * canvas.height * 1.2);
        } else {
          // Fallback to random animation
          h = Math.random() * canvas.height;
        }

        ctx.fillStyle = color.includes('indigo') ? '#6366f1' : color.includes('amber') ? '#f59e0b' : '#10b981';
        ctx.fillRect(xStart + i * (barWidth + gap), (canvas.height - h) / 2, barWidth, h);
      }
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isAnimating]);

  return (
    <canvas 
      ref={canvasRef} 
      width={60} 
      height={20} 
      className={cn("transition-opacity duration-300", isAnimating ? "opacity-100" : "opacity-0", className)}
    />
  );
};
