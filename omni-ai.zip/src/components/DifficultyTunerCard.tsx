import React from 'react';
import { 
  DifficultyState, 
  DifficultyLevel, 
  FlowStateZone 
} from '../modules/difficulty/types';
import { DifficultyEngine } from '../modules/difficulty/difficultyEngine';
import { 
  Gauge, 
  Flame, 
  AlertOctagon, 
  TrendingUp, 
  TrendingDown, 
  Sparkles, 
  Zap, 
  Coffee, 
  HelpCircle, 
  RotateCcw,
  CheckCircle,
  XCircle,
  ShieldAlert
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface DifficultyTunerCardProps {
  state: DifficultyState;
  onSetLevel?: (level: DifficultyLevel) => void;
  onReset?: () => void;
  onDismissIntervention?: () => void;
  className?: string;
}

export const DifficultyTunerCard: React.FC<DifficultyTunerCardProps> = ({
  state,
  onSetLevel,
  onReset,
  onDismissIntervention,
  className
}) => {
  const levelName = DifficultyEngine.getLevelName(state.currentLevel);
  const expectedAcc = DifficultyEngine.getExpectedAccuracyLabel(state.currentLevel);

  // Flow zone styling
  const getFlowZoneInfo = (zone: FlowStateZone) => {
    switch (zone) {
      case 'boredom':
        return {
          label: 'Boredom Zone (>90% Acc)',
          desc: 'Too easy. Scaling up challenge to prevent boredom.',
          color: 'text-amber-500 bg-amber-500/10 border-amber-500/20'
        };
      case 'frustration':
        return {
          label: 'Frustration Zone (<60% Acc)',
          desc: 'Too hard. Auto-tuning down & providing scaffolded hints.',
          color: 'text-rose-500 bg-rose-500/10 border-rose-500/20'
        };
      case 'flow':
      case 'optimal':
      default:
        return {
          label: 'Optimal Flow State (70-85%)',
          desc: 'In the Zone. "Just hard enough" for maximum retention.',
          color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20'
        };
    }
  };

  const flowInfo = getFlowZoneInfo(state.flowState);

  return (
    <div className={cn("p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg flex flex-col gap-5", className)}>
      {/* Header: Title + Adaptive Rate Tier */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center border border-indigo-500/20 shrink-0">
            <Gauge size={22} className="animate-pulse" />
          </div>
          <div>
            <h4 className="text-sm sm:text-base font-black text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
              Difficulty Auto-Tuner
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                Real-Time
              </span>
            </h4>
            <p className="text-xs text-slate-500">
              Adapts difficulty dynamically to lock you into the 70–85% Flow State
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold text-slate-400">
            Rate: <span className="uppercase text-indigo-600 dark:text-indigo-400 font-bold">{state.adaptiveRate}</span>
          </span>
          {onReset && (
            <button
              onClick={onReset}
              title="Reset Difficulty Tuning"
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <RotateCcw size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Proactive Intervention Alert (Frustration / Boredom Prevention) */}
      {state.intervention && state.interventionMessage && (
        <div className={cn(
          "p-3.5 rounded-2xl border flex items-start justify-between gap-3 text-xs leading-relaxed animate-in fade-in duration-300",
          state.intervention === 'suggest_break_review' 
            ? "bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/50 text-rose-900 dark:text-rose-200"
            : state.intervention === 'harder_variant'
              ? "bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-900/50 text-purple-900 dark:text-purple-200"
              : "bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/50 text-amber-900 dark:text-amber-200"
        )}>
          <div className="flex items-start gap-2.5">
            {state.intervention === 'suggest_break_review' ? (
              <Coffee size={18} className="text-rose-500 shrink-0 mt-0.5" />
            ) : state.intervention === 'harder_variant' ? (
              <Sparkles size={18} className="text-purple-500 shrink-0 mt-0.5" />
            ) : (
              <HelpCircle size={18} className="text-amber-500 shrink-0 mt-0.5" />
            )}
            <div>
              <span className="font-bold block mb-0.5">
                {state.intervention === 'suggest_break_review' ? 'Cognitive Breather Suggested' :
                 state.intervention === 'harder_variant' ? 'Olympiad Challenge Unlocked' :
                 'Scaffolded Assistance Active'}
              </span>
              <span>{state.interventionMessage}</span>
            </div>
          </div>

          {onDismissIntervention && (
            <button
              onClick={onDismissIntervention}
              className="text-[11px] font-bold underline opacity-70 hover:opacity-100 cursor-pointer"
            >
              Dismiss
            </button>
          )}
        </div>
      )}

      {/* Main Status Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* 1. Current Level Badge */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex flex-col justify-between">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            Current Tier
          </span>
          <div className="my-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400">
              Level {state.currentLevel}
            </span>
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              ({levelName})
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            {expectedAcc} &bull; Rating: {state.fineDifficulty.toFixed(2)}
          </span>
        </div>

        {/* 2. Flow State Target */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex flex-col justify-between">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            Flow State Zone
          </span>
          <div className="my-1">
            <span className={cn("px-2.5 py-1 rounded-lg text-xs font-bold border inline-flex items-center gap-1.5", flowInfo.color)}>
              <Zap size={13} /> {flowInfo.label}
            </span>
          </div>
          <span className="text-[11px] text-slate-400 leading-tight">
            {flowInfo.desc}
          </span>
        </div>

        {/* 3. Rolling Window (Last 5 Answers) */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex flex-col justify-between">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
            <span>Last 5 Answers</span>
            <span className="text-indigo-600 dark:text-indigo-400 font-bold">
              {Math.round(state.rollingAccuracy * 100)}%
            </span>
          </span>

          <div className="my-2 flex items-center gap-2">
            {Array.from({ length: 5 }).map((_, i) => {
              const res = state.rollingWindow[i];
              if (res === undefined) {
                return (
                  <div key={i} className="w-5 h-5 rounded-full border border-dashed border-slate-300 dark:border-slate-600" />
                );
              }
              return res ? (
                <div key={i} title="Correct" className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-bold shadow-sm">
                  ✓
                </div>
              ) : (
                <div key={i} title="Wrong" className="w-5 h-5 rounded-full bg-rose-500 text-white flex items-center justify-center text-[10px] font-bold shadow-sm">
                  ✗
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            {state.consecutiveCorrect > 0 && (
              <span className="text-emerald-500 font-semibold flex items-center gap-0.5">
                <Flame size={12} /> {state.consecutiveCorrect} streak (3 = Level Up)
              </span>
            )}
            {state.consecutiveWrong > 0 && (
              <span className="text-rose-500 font-semibold flex items-center gap-0.5">
                <AlertOctagon size={12} /> {state.consecutiveWrong} misses (2 = Level Down)
              </span>
            )}
            {state.consecutiveCorrect === 0 && state.consecutiveWrong === 0 && (
              <span>Ready for next question</span>
            )}
          </div>
        </div>
      </div>

      {/* Manual Difficulty Level Selector */}
      {onSetLevel && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <span className="text-xs font-semibold text-slate-500">
            Manual Override Level:
          </span>

          <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
            {([1, 2, 3, 4, 5] as DifficultyLevel[]).map((lvl) => {
              const isSelected = state.currentLevel === lvl;
              return (
                <button
                  key={lvl}
                  onClick={() => onSetLevel(lvl)}
                  className={cn(
                    "px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border",
                    isSelected
                      ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/25"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-400"
                  )}
                >
                  Lvl {lvl} ({DifficultyEngine.getLevelName(lvl)})
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
