export * from '../../src/modules/projects/PeerShowcase';
import { PeerShowcase } from '../../src/modules/projects/PeerShowcase';
export default PeerShowcase;
