import { 
  ExamAttempt, 
  ExamQuestionItem, 
  ExamPatternTemplate, 
  FullExamEvaluationReport, 
  QuestionEvaluationResult, 
  SectionEvaluationResult, 
  TopicEvaluationResult,
  StudentQuestionResponse
} from './types';

export class AutoEvaluator {
  /**
   * Evaluates an individual question response
   */
  static evaluateQuestion(
    question: ExamQuestionItem,
    response?: StudentQuestionResponse
  ): QuestionEvaluationResult {
    const timeSpent = response?.timeSpent || 0;

    if (!response || (!response.selectedOption && !response.answerText && response.numericalAnswer === undefined)) {
      return {
        questionId: question.id,
        isCorrect: false,
        isAttempted: false,
        awardedMarks: 0,
        maxMarks: question.marks,
        timeSpent,
        correctAnswer: question.correctOption || (question.correctNumericalValue !== undefined ? String(question.correctNumericalValue) : 'See rubric'),
        topic: question.topic,
        difficulty: question.difficulty
      };
    }

    // MCQ Evaluation
    if (question.questionType === 'mcq' || question.questionType === 'assertion_reason') {
      const userSelected = (response.selectedOption || '').trim();
      const correct = (question.correctOption || '').trim();
      const isCorrect = userSelected.length > 0 && userSelected.toLowerCase() === correct.toLowerCase();
      const awardedMarks = isCorrect ? question.marks : (question.negativeMarks > 0 ? -question.negativeMarks : 0);

      return {
        questionId: question.id,
        isCorrect,
        isAttempted: true,
        awardedMarks,
        maxMarks: question.marks,
        timeSpent,
        userAnswer: userSelected,
        correctAnswer: correct,
        topic: question.topic,
        difficulty: question.difficulty
      };
    }

    // Numerical Evaluation
    if (question.questionType === 'numerical') {
      const userVal = response.numericalAnswer;
      const targetVal = question.correctNumericalValue;
      const tol = question.numericalTolerance || 0.01;
      
      let isCorrect = false;
      if (userVal !== undefined && targetVal !== undefined) {
        isCorrect = Math.abs(userVal - targetVal) <= tol;
      }
      const awardedMarks = isCorrect ? question.marks : (question.negativeMarks > 0 ? -question.negativeMarks : 0);

      return {
        questionId: question.id,
        isCorrect,
        isAttempted: userVal !== undefined,
        awardedMarks,
        maxMarks: question.marks,
        timeSpent,
        userAnswer: userVal !== undefined ? String(userVal) : undefined,
        correctAnswer: targetVal !== undefined ? String(targetVal) : 'N/A',
        topic: question.topic,
        difficulty: question.difficulty
      };
    }

    // Subjective Short / Long / Case Study (Step-Wise Rubric Evaluation)
    const userText = (response.answerText || '').trim().toLowerCase();
    const rubric = question.stepWiseRubric || [
      { step: 'Core Conceptual Explanation', marks: question.marks * 0.5, keyPoints: ['principle', 'law', 'concept'] },
      { step: 'Mathematical Derivation / Proof', marks: question.marks * 0.5, keyPoints: ['formula', 'proof', 'step'] }
    ];

    let totalAwarded = 0;
    const stepBreakdown = rubric.map(r => {
      // Check keyword density
      const matchedPoints = r.keyPoints.filter(kp => userText.includes(kp.toLowerCase()));
      const fraction = r.keyPoints.length > 0 ? matchedPoints.length / r.keyPoints.length : 0.5;
      const stepAwarded = Number((r.marks * Math.min(1.0, fraction + (userText.length > 80 ? 0.3 : 0))).toFixed(1));
      totalAwarded += stepAwarded;

      return {
        step: r.step,
        awarded: Math.min(r.marks, stepAwarded),
        maxMarks: r.marks,
        feedback: matchedPoints.length > 0 
          ? `Identified key criteria: ${matchedPoints.join(', ')}`
          : `Missing standard board criteria: ${r.keyPoints.join(', ')}`
      };
    });

    const isCorrect = totalAwarded >= question.marks * 0.7;

    return {
      questionId: question.id,
      isCorrect,
      isAttempted: userText.length > 5,
      awardedMarks: Math.min(question.marks, Number(totalAwarded.toFixed(1))),
      maxMarks: question.marks,
      timeSpent,
      userAnswer: response.answerText,
      correctAnswer: question.detailedSolution,
      topic: question.topic,
      difficulty: question.difficulty,
      stepWiseBreakdown: stepBreakdown
    };
  }

  /**
   * Generates comprehensive evaluation report
   */
  static generateReport(
    attempt: ExamAttempt,
    template: ExamPatternTemplate,
    questions: ExamQuestionItem[]
  ): FullExamEvaluationReport {
    const responsesMap = new Map(attempt.answers.map(a => [a.questionId, a]));
    
    // Evaluate all questions
    const questionResults: QuestionEvaluationResult[] = questions.map(q => {
      const resp = responsesMap.get(q.id);
      return this.evaluateQuestion(q, resp);
    });

    // Score calculations
    const totalScore = Number(questionResults.reduce((acc, q) => acc + q.awardedMarks, 0).toFixed(1));
    const maxScore = questions.reduce((acc, q) => acc + q.marks, 0);
    const percentage = Number(((Math.max(0, totalScore) / maxScore) * 100).toFixed(1));

    // Section-wise Breakdown
    const sections: SectionEvaluationResult[] = template.sections.map(sec => {
      const secQuestions = questions.filter(q => q.sectionId === sec.id);
      const secResults = questionResults.filter(qr => secQuestions.some(q => q.id === qr.questionId));

      const attempted = secResults.filter(r => r.isAttempted).length;
      const correct = secResults.filter(r => r.isCorrect).length;
      const incorrect = attempted - correct;
      const unattempted = secResults.length - attempted;
      const score = Number(secResults.reduce((acc, r) => acc + r.awardedMarks, 0).toFixed(1));
      const secMax = secQuestions.reduce((acc, q) => acc + q.marks, 0);
      const accuracy = attempted > 0 ? Number(((correct / attempted) * 100).toFixed(1)) : 0;
      const timeSpentSeconds = secResults.reduce((acc, r) => acc + r.timeSpent, 0);

      return {
        sectionId: sec.id,
        sectionName: sec.name,
        attempted,
        correct,
        incorrect,
        unattempted,
        score,
        maxScore: secMax,
        accuracy,
        timeSpentSeconds
      };
    });

    // Topic-wise Analysis
    const topicMap = new Map<string, ExamQuestionItem[]>();
    questions.forEach(q => {
      if (!topicMap.has(q.topic)) topicMap.set(q.topic, []);
      topicMap.get(q.topic)!.push(q);
    });

    const topics: TopicEvaluationResult[] = Array.from(topicMap.entries()).map(([topicName, qList]) => {
      const qIds = new Set(qList.map(q => q.id));
      const tResults = questionResults.filter(r => qIds.has(r.questionId));
      const attempted = tResults.filter(r => r.isAttempted).length;
      const correct = tResults.filter(r => r.isCorrect).length;
      const score = Number(tResults.reduce((acc, r) => acc + r.awardedMarks, 0).toFixed(1));
      const tMax = qList.reduce((acc, q) => acc + q.marks, 0);
      const mastery = tMax > 0 ? Number(((Math.max(0, score) / tMax) * 100).toFixed(1)) : 0;

      return {
        topic: topicName,
        totalQuestions: qList.length,
        attempted,
        correct,
        score,
        maxScore: tMax,
        masteryPercentage: mastery
      };
    });

    // Difficulty breakdown
    const difficultyBreakdown = {
      easy: { correct: 0, total: 0, score: 0 },
      medium: { correct: 0, total: 0, score: 0 },
      hard: { correct: 0, total: 0, score: 0 }
    };
    questionResults.forEach(qr => {
      const d = qr.difficulty || 'medium';
      difficultyBreakdown[d].total += 1;
      if (qr.isCorrect) difficultyBreakdown[d].correct += 1;
      difficultyBreakdown[d].score += qr.awardedMarks;
    });

    // Percentile estimation using normal distribution model
    const normalizedZ = (percentage - 50) / 18;
    const percentile = Math.min(99.9, Math.max(10.0, Number((50 + 50 * Math.tanh(normalizedZ * 0.8)).toFixed(1))));

    let rankEstimate = `Top ${(100 - percentile).toFixed(1)}% of Test Takers`;
    if (percentile >= 99) rankEstimate = 'National Top 1% (AIR < 1,500)';
    else if (percentile >= 95) rankEstimate = 'Top 5% (AIR < 7,500)';
    else if (percentile >= 90) rankEstimate = 'Top 10% (AIR < 15,000)';

    const totalAttempted = questionResults.filter(r => r.isAttempted).length;
    const totalCorrect = questionResults.filter(r => r.isCorrect).length;
    const accuracyPercentage = totalAttempted > 0 ? Number(((totalCorrect / totalAttempted) * 100).toFixed(1)) : 0;

    const totalTimeSpentSeconds = attempt.durationSecondsUsed || 3600;
    const minutesPerQ = totalAttempted > 0 ? (totalTimeSpentSeconds / 60 / totalAttempted).toFixed(1) : '0';

    // Actionable Insights
    const timeManagementInsights: string[] = [];
    if (totalTimeSpentSeconds < (template.durationMinutes * 60 * 0.5)) {
      timeManagementInsights.push('⚡ Fast Pacing: You finished early. Allocating 15-20 more minutes for double-checking could prevent minor silly errors.');
    } else if (totalTimeSpentSeconds > (template.durationMinutes * 60 * 0.95)) {
      timeManagementInsights.push('⏳ High Time Pressure: You used near maximum time. Focus on rapid elimination in Section A to save buffer for Section E derivations.');
    } else {
      timeManagementInsights.push('🎯 Optimal Time Allocation: Balanced pace across sections with sufficient review margin.');
    }

    if (difficultyBreakdown.hard.correct / Math.max(1, difficultyBreakdown.hard.total) > 0.6) {
      timeManagementInsights.push('🧠 High-Order Analytical Strength: Demonstrated strong grasp on multi-step and conceptual derivation problems.');
    }

    // Recommendations
    const recommendations: string[] = [];
    const weakTopics = topics.filter(t => t.masteryPercentage < 65).map(t => t.topic);
    if (weakTopics.length > 0) {
      recommendations.push(`Revise foundational derivations for: ${weakTopics.slice(0, 2).join(', ')}.`);
    }
    if (accuracyPercentage < 80) {
      recommendations.push('Practice active elimination on Assertion-Reason questions to eliminate negative marks.');
    }
    recommendations.push('Attempt a targeted 45-minute timed drill on your weakest section this week.');

    return {
      attemptId: attempt.id,
      examTitle: template.title,
      examType: attempt.examType,
      subject: attempt.subject,
      startedAt: attempt.startedAt,
      completedAt: attempt.completedAt,
      totalTimeSpentSeconds,
      totalScore,
      maxScore,
      percentage,
      percentile,
      rankEstimate,
      accuracyPercentage,
      speedIndex: `${minutesPerQ} min/Q`,
      sections,
      topics,
      difficultyBreakdown,
      timeManagementInsights,
      recommendations,
      questionResults
    };
  }
}
