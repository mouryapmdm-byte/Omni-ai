import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  GraduationCap, 
  HelpCircle, 
  CheckCircle2, 
  Clock, 
  Bookmark, 
  Plus, 
  ChevronRight, 
  Sparkles, 
  Sliders, 
  X, 
  Play, 
  Zap, 
  Users,
  Award
} from 'lucide-react';
import { cn, formatDuration } from '@/src/lib/utils';
import { VerbalLectureQuestion, LectureBookmark, TutorPersonaConfig, PersonaArchetype } from '@/src/types';

export interface TimelineMarker {
  id: string;
  type: 'checkpoint_question' | 'professor_shift' | 'bookmark';
  timestampSec: number;
  title: string;
  description?: string;
  status?: 'pending' | 'correct' | 'incorrect';
  professorStyle?: 'strict' | 'mentor';
  personaConfig?: TutorPersonaConfig;
  archetype?: PersonaArchetype;
  subMode?: 'classroom' | 'quiz' | 'lecture' | 'video_classroom';
  messageId?: string;
  createdAt: string;
}

interface LectureProgressTimelineProps {
  isLectureMode: boolean;
  lectureSubMode: 'classroom' | 'quiz' | 'lecture' | 'video_classroom';
  lectureProfessorStyle?: 'strict' | 'mentor';
  tutorPersonaConfig?: TutorPersonaConfig;
  onToggleProfessorStyle: () => void;
  activeVerbalQuestion: VerbalLectureQuestion | null;
  activeBookmark: LectureBookmark | null;
  timelineMarkers: TimelineMarker[];
  onAddCheckpointQuestion: () => void;
  onSelectMarker: (marker: TimelineMarker) => void;
  currentElapsedSec?: number;
  totalDurationSec?: number;
  className?: string;
  theme?: 'dark' | 'light';
  variant?: 'full' | 'line';
}

export const LectureProgressTimeline: React.FC<LectureProgressTimelineProps> = ({
  isLectureMode,
  lectureSubMode,
  lectureProfessorStyle,
  onToggleProfessorStyle,
  activeVerbalQuestion,
  activeBookmark,
  timelineMarkers,
  onAddCheckpointQuestion,
  onSelectMarker,
  currentElapsedSec = 180,
  totalDurationSec = 600,
  className,
  theme = 'dark',
  variant = 'full'
}) => {
  const [selectedMarker, setSelectedMarker] = useState<TimelineMarker | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'checkpoint' | 'shift'>('all');
  const [isMinimized, setIsMinimized] = useState<boolean>(false);

  if (!isLectureMode) return null;

  const filteredMarkers = timelineMarkers.filter(m => {
    if (filterType === 'checkpoint') return m.type === 'checkpoint_question';
    if (filterType === 'shift') return m.type === 'professor_shift';
    return true;
  });

  const progressPercent = Math.min(100, Math.max(0, (currentElapsedSec / totalDurationSec) * 100));

  // Render minimal single line layout at the bottom
  if (variant === 'line') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 10 }}
        className={cn("w-full py-1.5 px-2 select-none relative z-20", className)}
      >
        {/* Top Info Bar above line */}
        <div className="flex items-center justify-between text-[10px] font-mono mb-1.5 px-0.5">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 font-black uppercase text-[10px] tracking-wider text-indigo-400">
              <GraduationCap size={13} className="text-indigo-400" />
              <span>Classroom Timeline</span>
            </span>
            {timelineMarkers.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-indigo-500/20 text-[9px] font-bold text-indigo-300 border border-indigo-500/30">
                {timelineMarkers.length} markers
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <span className="text-slate-400 text-[10px] font-bold">
              <span className="text-indigo-400">{formatDuration(currentElapsedSec)}</span> / {formatDuration(totalDurationSec)}
            </span>
            <span className="text-[10px] font-mono font-black text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">
              {Math.round(progressPercent)}%
            </span>
          </div>
        </div>

        {/* Timeline Line Track */}
        <div className="relative h-2 w-full bg-slate-800/90 rounded-full overflow-hidden border border-white/10 shadow-inner">
          <motion.div
            className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 rounded-full shadow-sm"
            style={{ width: `${progressPercent}%` }}
            transition={{ type: 'spring', stiffness: 120, damping: 20 }}
          />
        </div>

        {/* Marker Dots on the Line */}
        <div className="relative w-full h-0 pointer-events-none">
          {filteredMarkers.map((marker) => {
            const posPercent = Math.min(98, Math.max(2, (marker.timestampSec / totalDurationSec) * 100));

            let markerColor = "bg-amber-400 border-amber-200 text-slate-950 shadow-amber-500/50";
            if (marker.type === 'professor_shift') {
              const arch = marker.archetype || marker.personaConfig?.archetype;
              if (arch === 'socratic_specialist') {
                markerColor = "bg-purple-400 border-purple-200 text-slate-950 shadow-purple-500/50";
              } else if (arch === 'high_energy') {
                markerColor = "bg-rose-400 border-rose-200 text-slate-950 shadow-rose-500/50";
              } else if (arch === 'conceptual_storyteller') {
                markerColor = "bg-amber-400 border-amber-200 text-slate-950 shadow-amber-500/50";
              } else if (arch === 'gentle_mentor') {
                markerColor = "bg-emerald-400 border-emerald-200 text-slate-950 shadow-emerald-500/50";
              } else {
                markerColor = marker.professorStyle === 'strict' || arch === 'strict_academic'
                  ? "bg-indigo-400 border-indigo-200 text-slate-950 shadow-indigo-500/50"
                  : "bg-emerald-400 border-emerald-200 text-slate-950 shadow-emerald-500/50";
              }
            } else if (marker.type === 'checkpoint_question') {
              markerColor = marker.status === 'correct'
                ? "bg-emerald-500 border-emerald-200 text-white"
                : marker.status === 'incorrect'
                  ? "bg-rose-500 border-rose-200 text-white"
                  : "bg-amber-400 border-amber-200 text-slate-950 animate-pulse";
            }

            return (
              <button
                key={marker.id}
                type="button"
                onClick={() => {
                  setSelectedMarker(marker);
                  onSelectMarker(marker);
                }}
                style={{ left: `${posPercent}%` }}
                className={cn(
                  "absolute -top-3 -translate-x-1/2 w-4 h-4 rounded-full border border-white/60 flex items-center justify-center shadow-md cursor-pointer pointer-events-auto transition-transform hover:scale-150 z-10",
                  markerColor
                )}
                title={`${marker.title} (${formatDuration(marker.timestampSec)})`}
              >
                {marker.type === 'checkpoint_question' ? <HelpCircle size={9} /> : <GraduationCap size={9} />}
              </button>
            );
          })}
        </div>

        {/* Popup Tooltip if a marker is clicked */}
        <AnimatePresence>
          {selectedMarker && (
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 5 }}
              className="mt-2 p-2 rounded-xl bg-slate-950/95 border border-indigo-500/40 shadow-xl flex items-center justify-between text-xs text-white"
            >
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                  {formatDuration(selectedMarker.timestampSec)}
                </span>
                <span className="font-bold text-xs truncate max-w-[200px] sm:max-w-[300px]">{selectedMarker.title}</span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => onSelectMarker(selectedMarker)}
                  className="px-2 py-0.5 rounded bg-indigo-600 hover:bg-indigo-500 text-[10px] font-black uppercase text-white cursor-pointer"
                >
                  Jump
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedMarker(null)}
                  className="p-1 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X size={12} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      className={cn(
        "sticky top-2 z-40 mb-4 rounded-2xl border shadow-2xl backdrop-blur-md overflow-hidden transition-all",
        theme === 'dark' 
          ? "bg-slate-950/90 border-indigo-500/30 text-white shadow-indigo-950/40" 
          : "bg-white/95 border-indigo-200 text-slate-900 shadow-indigo-100",
        className
      )}
    >
      {/* Header Bar */}
      <div className="px-4 py-2.5 flex items-center justify-between border-b border-white/10 bg-gradient-to-r from-indigo-950/50 via-slate-900/40 to-slate-950/50">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <GraduationCap size={16} />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-black uppercase tracking-wider text-indigo-300">
              Lecture Mode Timeline
            </span>
            <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-500/40 text-[10px] font-mono text-indigo-300">
              {filteredMarkers.length} Markers
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Professor Mode Shift Switcher */}
          <button
            type="button"
            onClick={onToggleProfessorStyle}
            className={cn(
              "px-2.5 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider border transition-all cursor-pointer flex items-center gap-1.5 shadow-sm",
              lectureProfessorStyle === 'strict'
                ? "bg-indigo-500/20 border-indigo-500/40 text-indigo-300 hover:bg-indigo-500/30"
                : "bg-emerald-500/20 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30"
            )}
            title="Click to shift Professor Mode style"
          >
            <span>{lectureProfessorStyle === 'strict' ? '🎓 Strict Professor' : '🤝 Interactive Mentor'}</span>
          </button>

          {/* Quick Add Checkpoint Question */}
          <button
            type="button"
            onClick={onAddCheckpointQuestion}
            className="px-2.5 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30 transition-all cursor-pointer flex items-center gap-1"
            title="Insert Checkpoint Question Marker"
          >
            <Plus size={12} />
            <span>+ Checkpoint</span>
          </button>

          {/* Minimize toggle */}
          <button
            type="button"
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            {isMinimized ? <ChevronRight size={14} className="rotate-90" /> : <X size={14} />}
          </button>
        </div>
      </div>

      {!isMinimized && (
        <div className="p-3.5 space-y-3">
          {/* Progress Bar & Markers Track */}
          <div className="relative pt-3 pb-2 px-1">
            {/* Timeline Track Line */}
            <div className="relative h-2.5 w-full bg-slate-800/80 rounded-full overflow-hidden border border-white/5">
              <motion.div 
                className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 rounded-full"
                style={{ width: `${progressPercent}%` }}
                transition={{ type: 'spring', stiffness: 100 }}
              />
            </div>

            {/* Marker Nodes Overlay */}
            <div className="absolute inset-x-1 top-2.5 h-2.5 pointer-events-none">
              {filteredMarkers.map((marker) => {
                const posPercent = Math.min(98, Math.max(2, (marker.timestampSec / totalDurationSec) * 100));
                const isSelected = selectedMarker?.id === marker.id;

                let markerBg = "bg-amber-400 border-amber-200 text-slate-950 shadow-amber-500/50";
                if (marker.type === 'professor_shift') {
                  const arch = marker.archetype || marker.personaConfig?.archetype;
                  if (arch === 'socratic_specialist') {
                    markerBg = "bg-purple-400 border-purple-200 text-slate-950 shadow-purple-500/50";
                  } else if (arch === 'high_energy') {
                    markerBg = "bg-rose-400 border-rose-200 text-slate-950 shadow-rose-500/50";
                  } else if (arch === 'conceptual_storyteller') {
                    markerBg = "bg-amber-400 border-amber-200 text-slate-950 shadow-amber-500/50";
                  } else if (arch === 'gentle_mentor') {
                    markerBg = "bg-emerald-400 border-emerald-200 text-slate-950 shadow-emerald-500/50";
                  } else {
                    markerBg = marker.professorStyle === 'strict' || arch === 'strict_academic'
                      ? "bg-indigo-400 border-indigo-200 text-slate-950 shadow-indigo-500/50" 
                      : "bg-emerald-400 border-emerald-200 text-slate-950 shadow-emerald-500/50";
                  }
                } else if (marker.type === 'checkpoint_question') {
                  if (marker.status === 'correct') {
                    markerBg = "bg-emerald-500 border-emerald-200 text-white shadow-emerald-500/50";
                  } else if (marker.status === 'incorrect') {
                    markerBg = "bg-rose-500 border-rose-200 text-white shadow-rose-500/50";
                  } else {
                    markerBg = "bg-amber-400 border-amber-200 text-slate-950 shadow-amber-400/50 animate-pulse";
                  }
                }

                return (
                  <button
                    key={marker.id}
                    type="button"
                    onClick={() => {
                      setSelectedMarker(marker);
                      onSelectMarker(marker);
                    }}
                    style={{ left: `${posPercent}%` }}
                    className={cn(
                      "absolute -top-1.5 -translate-x-1/2 w-5 h-5 rounded-full border-2 flex items-center justify-center font-black text-[9px] shadow-lg cursor-pointer pointer-events-auto transition-transform hover:scale-125 z-10",
                      markerBg,
                      isSelected && "ring-2 ring-white scale-125 z-20"
                    )}
                    title={`${marker.title} (${formatDuration(marker.timestampSec)})`}
                  >
                    {marker.type === 'checkpoint_question' && <HelpCircle size={10} />}
                    {marker.type === 'professor_shift' && <GraduationCap size={10} />}
                    {marker.type === 'bookmark' && <Bookmark size={10} />}
                  </button>
                );
              })}
            </div>

            {/* Time labels */}
            <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mt-2">
              <span>0:00</span>
              <span className="text-indigo-400 font-bold">Elapsed: {formatDuration(currentElapsedSec)}</span>
              <span>{formatDuration(totalDurationSec)}</span>
            </div>
          </div>

          {/* Category Filter Chips & Legend */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-white/10 text-[10px]">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-400 font-bold uppercase tracking-wider mr-1">Filter:</span>
              <button
                type="button"
                onClick={() => setFilterType('all')}
                className={cn(
                  "px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer",
                  filterType === 'all' ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
                )}
              >
                All ({timelineMarkers.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterType('checkpoint')}
                className={cn(
                  "px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1",
                  filterType === 'checkpoint' ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-400 hover:text-white"
                )}
              >
                <HelpCircle size={10} /> Checkpoints
              </button>
              <button
                type="button"
                onClick={() => setFilterType('shift')}
                className={cn(
                  "px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1",
                  filterType === 'shift' ? "bg-indigo-500 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
                )}
              >
                <GraduationCap size={10} /> Professor Shifts
              </button>
            </div>

            {/* Keyboard Shortcuts Hint */}
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono bg-black/30 px-2.5 py-1 rounded-xl border border-white/10">
              <span className="font-bold text-indigo-400">Shortcuts:</span>
              <span className="bg-slate-800 px-1.5 py-0.5 rounded text-white font-bold">Space</span> Play/Pause
              <span className="bg-slate-800 px-1.5 py-0.5 rounded text-white font-bold">← / →</span> ±5s
              <span className="bg-slate-800 px-1.5 py-0.5 rounded text-white font-bold">M</span> Mute
            </div>

            {/* Selected Marker Detail Card */}
            <AnimatePresence>
              {selectedMarker && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="w-full mt-2 p-2.5 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded bg-indigo-500/20 text-indigo-300 font-mono text-[10px]">
                      {formatDuration(selectedMarker.timestampSec)}
                    </span>
                    <div>
                      <p className="font-bold text-white text-xs">{selectedMarker.title}</p>
                      {selectedMarker.description && (
                        <p className="text-[11px] text-slate-400 line-clamp-1">{selectedMarker.description}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => onSelectMarker(selectedMarker)}
                      className="px-2 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-black uppercase cursor-pointer"
                    >
                      Jump
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedMarker(null)}
                      className="p-1 rounded hover:bg-white/10 text-slate-400 cursor-pointer"
                    >
                      <X size={12} />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      )}
    </motion.div>
  );
};
