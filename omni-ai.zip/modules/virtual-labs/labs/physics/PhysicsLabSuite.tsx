export * from '../../../../src/modules/virtual-labs/labs/physics/PhysicsLabSuite';
import { PhysicsLabSuite } from '../../../../src/modules/virtual-labs/labs/physics/PhysicsLabSuite';
export default PhysicsLabSuite;
