import React, { useState, useRef, useEffect, useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';
import rehypeRaw from 'rehype-raw';
import { Volume2, VolumeX, Play, Pause, RotateCcw, Activity, Sliders, ChevronDown, Award, Copy, Check } from 'lucide-react';
import { cleanStreamingMarkdown } from '../../lib/streaming/cleanStreamingMarkdown';

interface AIResponseProps {
  content: string;
  onSynthesizeSpeech?: (text: string, voice: string) => Promise<string>; // base64 audio
}

export const AIResponse: React.FC<AIResponseProps> = ({ content, onSynthesizeSpeech }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingSpeech, setIsLoadingSpeech] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [selectedVoice, setSelectedVoice] = useState<string>('Zephyr');
  const [showVoiceControls, setShowVoiceControls] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const VOICES = [
    { id: 'Zephyr', name: 'Professor Zephyr (Clear & Articulate)', lang: 'en' },
    { id: 'Kore', name: 'Professor Kore (Warm & Encouraging)', lang: 'en' },
    { id: 'Puck', name: 'Professor Puck (Energetic & Fun)', lang: 'en' },
    { id: 'Charon', name: 'Professor Charon (Academic & Precise)', lang: 'en' },
    { id: 'Fenrir', name: 'Professor Fenrir (Deep & Resonant)', lang: 'en' }
  ];

  // Stop audio on unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  // Handle speed change on active audio
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  // Clean raw markup, bracketed directives, and unrendered delimiters
  const sanitizedContent = useMemo(() => {
    if (!content) return '';

    let text = content;

    // 1. Strip machine directives and robotic tags like [AVATAR:...], [SMARTBOARD:...], [Phase:...], etc.
    text = text.replace(/\[(?:AVATAR|SMARTBOARD|Type|Draw|Pause|Animation|Phase|Action|Scene|Gesture|Voice|Board):[^\]]*\]/gi, '');
    text = text.replace(/\[(?:TEACHING_GOLDEN_RULE|ANALOGY_METHOD|QUESTION_FIRST_METHOD|STORY_METHOD|BREAKDOWN_METHOD|CONNECTION_METHOD|SIMPLIFICATION_METHOD|DEMONSTRATION_METHOD|MISCONCEPTION_FIRST_METHOD|RELEVANCE_METHOD|MNEMONIC_METHOD|FORMULA_PRACTICE_FLOW_MANDATE|RULE_[A-Z_]+|DYNAMIC_FIGURE_[A-Z_]+|FIGURE_CONSTRUCTION_SEQUENCE|COMPLETE_FIGURE_OVERVIEW|ELEMENT_SPOTLIGHT|CONNECTION_TRACING|COMPARATIVE_HIGHLIGHTING|LAYERED_COMPLEXITY|INTERACTIVE_FIGURE_ENGAGEMENT)[^\]]*\]/gi, '');

    // 2. Convert raw brackets delimiters \( ... \) and \[ ... \] to standard LaTeX $...$ and $$...$$
    text = text.replace(/\\\[([\s\S]*?)\\\]/g, '$$\n$1\n$$');
    text = text.replace(/\\\(([\s\S]*?)\\\)/g, '$$$1$$');

    // 3. Fix unrendered isolated double dollar or single dollar lines
    text = text.replace(/(?:\r?\n|^)\s*\$\$\s*(?:\r?\n|$)/g, '\n\n');

    // 4. Sanitize markdown using centralized cleaner
    const cleaned = cleanStreamingMarkdown(text, false);
    return cleaned.trim();
  }, [content]);

  const copyCode = (codeStr: string, id: string) => {
    navigator.clipboard.writeText(codeStr);
    setCopiedCodeIndex(id);
    setTimeout(() => setCopiedCodeIndex(null), 2000);
  };

  // Convert LaTeX math and characters into natural, readable words for smooth TTS speech
  const cleanTextForSpeech = (rawText: string): string => {
    let clean = rawText;

    // 1. Remove SVG tags
    clean = clean.replace(/<svg[\s\S]*?<\/svg>/g, ' visual diagram shown on board ');

    // 2. Format common formulas into natural speech
    clean = clean.replace(/\\frac\{(.*?)\}\{(.*?)\}/g, ' $1 divided by $2 ');
    clean = clean.replace(/\\sqrt\{(.*?)\}/g, ' square root of $1 ');
    clean = clean.replace(/(\w+)\^\{(\d+)\}/g, ' $1 squared ');
    clean = clean.replace(/\\int/g, ' integral ');
    clean = clean.replace(/\\Delta/g, ' delta ');
    clean = clean.replace(/\\pi/g, ' pi ');
    clean = clean.replace(/\\theta/g, ' theta ');
    clean = clean.replace(/\\sigma/g, ' sigma ');
    clean = clean.replace(/\\infty/g, ' infinity ');
    clean = clean.replace(/\\sum/g, ' sum of ');

    // 3. Remove Markdown operators & delimiters
    clean = clean.replace(/\*\*/g, '');
    clean = clean.replace(/###/g, '');
    clean = clean.replace(/##/g, '');
    clean = clean.replace(/#/g, '');
    clean = clean.replace(/\$/g, '');
    clean = clean.replace(/_/g, ' ');
    clean = clean.replace(/`{1,3}/g, '');

    // 4. Clean up any weird character arrays
    clean = clean.replace(/\\text\{(.*?)\}/g, ' $1 ');

    return clean;
  };

  const handleToggleSpeech = async () => {
    if (isPlaying) {
      audioRef.current?.pause();
      setIsPlaying(false);
      return;
    }

    if (audioUrl) {
      if (audioRef.current) {
        audioRef.current.playbackRate = playbackSpeed;
        audioRef.current.play();
        setIsPlaying(true);
      }
      return;
    }

    if (!onSynthesizeSpeech) return;

    setIsLoadingSpeech(true);
    try {
      const cleanText = cleanTextForSpeech(sanitizedContent || content);
      const base64Audio = await onSynthesizeSpeech(cleanText, selectedVoice);
      const url = `data:audio/mp3;base64,${base64Audio}`;
      setAudioUrl(url);

      const audio = new Audio(url);
      audio.playbackRate = playbackSpeed;
      audio.onended = () => {
        setIsPlaying(false);
      };
      audio.onerror = (e) => {
        console.error("Audio playback error", e);
        setIsPlaying(false);
      };
      audioRef.current = audio;
      audio.play();
      setIsPlaying(true);
    } catch (err) {
      console.error("Failed to generate speech", err);
    } finally {
      setIsLoadingSpeech(false);
    }
  };

  const resetSpeech = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setIsPlaying(false);
    setAudioUrl(null);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3.5 shadow-md relative group transition-all text-slate-100 overflow-hidden">
      
      {/* Pristine Formatted Response content without raw markdowns or delimiters */}
      <div className="space-y-3 text-xs leading-relaxed font-normal text-slate-200">
        <ReactMarkdown
          remarkPlugins={[remarkMath, remarkGfm]}
          rehypePlugins={[rehypeKatex, rehypeRaw]}
          components={{
            h1: ({ children }) => (
              <h3 className="text-sm font-black text-indigo-300 mt-3 mb-1.5 flex items-center gap-1.5 border-b border-slate-800 pb-1">
                <Award className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>{children}</span>
              </h3>
            ),
            h2: ({ children }) => (
              <h4 className="text-xs font-black text-indigo-300 mt-2.5 mb-1 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                <span>{children}</span>
              </h4>
            ),
            h3: ({ children }) => (
              <h5 className="text-xs font-extrabold text-amber-300 mt-2 mb-1">
                {children}
              </h5>
            ),
            p: ({ children }) => (
              <p className="text-xs text-slate-300 leading-relaxed my-1.5">
                {children}
              </p>
            ),
            strong: ({ children }) => (
              <strong className="text-white font-extrabold">{children}</strong>
            ),
            em: ({ children }) => (
              <em className="text-indigo-200 italic">{children}</em>
            ),
            ul: ({ children }) => (
              <ul className="space-y-1 my-2 pl-4 list-disc marker:text-indigo-400 text-slate-300">
                {children}
              </ul>
            ),
            ol: ({ children }) => (
              <ol className="space-y-1 my-2 pl-4 list-decimal marker:text-amber-400 marker:font-bold text-slate-300">
                {children}
              </ol>
            ),
            li: ({ children }) => (
              <li className="leading-relaxed pl-1 text-slate-300">
                {children}
              </li>
            ),
            blockquote: ({ children }) => (
              <blockquote className="my-2.5 p-2.5 bg-indigo-950/40 border-l-3 border-indigo-400 rounded-r-xl text-indigo-200 italic shadow-inner">
                {children}
              </blockquote>
            ),
            code: ({ inline, className, children, ...props }: any) => {
              const codeStr = String(children).replace(/\n$/, '');
              const match = /language-(\w+)/.exec(className || '');

              if (inline) {
                return (
                  <code className="mx-0.5 px-1.5 py-0.5 bg-slate-950/80 border border-slate-700/60 rounded text-indigo-300 font-mono text-[11px] font-semibold">
                    {children}
                  </code>
                );
              }

              const codeId = `code_${codeStr.slice(0, 10)}`;
              const isCopied = copiedCodeIndex === codeId;

              return (
                <div className="my-2.5 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 shadow-inner">
                  <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-800/80 text-[10px] text-slate-400 font-mono">
                    <span className="uppercase font-bold text-indigo-400">{match ? match[1] : 'Code / Equation'}</span>
                    <button
                      type="button"
                      onClick={() => copyCode(codeStr, codeId)}
                      className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
                      title="Copy code"
                    >
                      {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{isCopied ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <pre className="p-3 overflow-x-auto text-[11px] font-mono text-slate-200 leading-normal">
                    <code>{children}</code>
                  </pre>
                </div>
              );
            },
            table: ({ children }) => (
              <div className="my-2.5 overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left border-collapse text-xs">
                  {children}
                </table>
              </div>
            ),
            thead: ({ children }) => (
              <thead className="bg-slate-800/80 text-indigo-300 font-bold border-b border-slate-700">
                {children}
              </thead>
            ),
            tbody: ({ children }) => (
              <tbody className="divide-y divide-slate-800/50 bg-slate-900/40">
                {children}
              </tbody>
            ),
            tr: ({ children }) => (
              <tr className="hover:bg-slate-800/30 transition-colors">
                {children}
              </tr>
            ),
            th: ({ children }) => (
              <th className="p-2 font-black uppercase text-[10px] tracking-wider text-slate-300">
                {children}
              </th>
            ),
            td: ({ children }) => (
              <td className="p-2 text-slate-300">
                {children}
              </td>
            ),
            text: ({ children, node, ...props }: any) => (
              <span
                style={{
                  fontFamily: props['font-family'] || props.fontFamily,
                  fontSize: props['font-size'] || props.fontSize,
                  fontWeight: props['font-weight'] || props.fontWeight,
                  color: props.fill || undefined
                }}
              >
                {children}
              </span>
            )
          }}
        >
          {sanitizedContent}
        </ReactMarkdown>
      </div>

      {/* TTS Audio Section */}
      {onSynthesizeSpeech && (
        <div className="border-t border-slate-800/80 pt-3 flex flex-col gap-2.5">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleToggleSpeech}
                disabled={isLoadingSpeech}
                className={`p-2 rounded-xl text-white shadow-sm transition-all flex items-center justify-center ${
                  isLoadingSpeech 
                    ? 'bg-slate-700 animate-pulse cursor-not-allowed' 
                    : isPlaying
                      ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/20'
                      : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/20'
                }`}
                title={isPlaying ? "Pause voice lecture" : "Listen to explanation"}
              >
                {isLoadingSpeech ? (
                  <Activity className="w-4 h-4 animate-spin" />
                ) : isPlaying ? (
                  <Pause className="w-4 h-4" />
                ) : (
                  <Play className="w-4 h-4 ml-0.5" />
                )}
              </button>

              {audioUrl && (
                <button
                  onClick={resetSpeech}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all border border-slate-700"
                  title="Reset voice generation"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}

              {/* Simulated active speech waveform */}
              {isPlaying && (
                <div className="flex items-center gap-0.5 h-4 px-2 select-none">
                  <span className="w-0.5 bg-indigo-400 rounded-full animate-bounce" style={{ height: '70%', animationDelay: '0.1s' }}></span>
                  <span className="w-0.5 bg-indigo-400 rounded-full animate-bounce" style={{ height: '100%', animationDelay: '0.3s' }}></span>
                  <span className="w-0.5 bg-indigo-400 rounded-full animate-bounce" style={{ height: '40%', animationDelay: '0.5s' }}></span>
                  <span className="w-0.5 bg-indigo-400 rounded-full animate-bounce" style={{ height: '80%', animationDelay: '0.2s' }}></span>
                  <span className="text-[10px] text-indigo-300 font-extrabold tracking-wide uppercase ml-1.5">Lecture Voice Stream</span>
                </div>
              )}
            </div>

            {/* Speeds and voice selector controls toggle */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setShowVoiceControls(!showVoiceControls)}
                className={`text-xs font-bold px-2.5 py-1.5 rounded-xl border flex items-center gap-1 transition-all ${
                  showVoiceControls 
                    ? 'bg-indigo-600/30 border-indigo-500 text-indigo-300' 
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750 hover:text-white'
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                <span>Audio Settings</span>
                <ChevronDown className={`w-3 h-3 transition-transform ${showVoiceControls ? 'rotate-180' : ''}`} />
              </button>
            </div>
          </div>

          {/* Voice controls panel */}
          {showVoiceControls && (
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 shadow-inner grid grid-cols-1 md:grid-cols-2 gap-3 animate-fadeIn">
              
              {/* Professor Voice Persona selection */}
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Tutor Persona</label>
                <select
                  value={selectedVoice}
                  onChange={(e) => { setSelectedVoice(e.target.value); resetSpeech(); }}
                  className="w-full text-xs font-bold text-slate-200 bg-slate-900 border border-slate-700 p-2 rounded-lg outline-none focus:border-indigo-400"
                >
                  {VOICES.map((v) => (
                    <option key={v.id} value={v.id} className="bg-slate-900 text-slate-200">{v.name}</option>
                  ))}
                </select>
              </div>

              {/* Speed Slider control */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Speaking Speed</label>
                  <span className="text-[10px] font-extrabold text-indigo-300 bg-indigo-950 px-1.5 py-0.5 rounded-md border border-indigo-800/60">{playbackSpeed}x</span>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[10px] font-bold text-slate-400">0.5x</span>
                  <input
                    type="range"
                    min="0.5"
                    max="2"
                    step="0.25"
                    value={playbackSpeed}
                    onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                    className="flex-1 accent-indigo-500 h-1.5 bg-slate-800 rounded-full outline-none cursor-pointer"
                  />
                  <span className="text-[10px] font-bold text-slate-400">2.0x</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

