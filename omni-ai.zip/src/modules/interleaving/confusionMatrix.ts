export interface ConfusionPair {
  topicA: string;
  topicB: string;
  confusionCount: number;
  lastConfusedAt: string;
}

const LOCAL_STORAGE_KEY = 'omni_confusion_matrix_v1';

/**
 * Load confusion pairs from localStorage
 */
export function getConfusionPairs(): ConfusionPair[] {
  try {
    const data = localStorage.getItem(LOCAL_STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error('Error loading confusion matrix', e);
    return [];
  }
}

/**
 * Save confusion pairs to localStorage
 */
export function saveConfusionPairs(pairs: ConfusionPair[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(pairs));
  } catch (e) {
    console.error('Error saving confusion matrix', e);
  }
}

/**
 * Records a confusion between two concepts (A and B).
 * Always stores the pair in a stable sorted order so A vs B and B vs A map to the same entry.
 */
export function recordConfusion(topicA: string, topicB: string): ConfusionPair[] {
  if (!topicA || !topicB || topicA === topicB) return getConfusionPairs();

  const pairs = getConfusionPairs();
  
  // Normalize order to prevent duplicate (A,B) and (B,A) entries
  const [sortedA, sortedB] = [topicA, topicB].sort();

  const existingIdx = pairs.findIndex(
    p => p.topicA === sortedA && p.topicB === sortedB
  );

  if (existingIdx !== -1) {
    pairs[existingIdx].confusionCount += 1;
    pairs[existingIdx].lastConfusedAt = new Date().toISOString();
  } else {
    pairs.push({
      topicA: sortedA,
      topicB: sortedB,
      confusionCount: 1,
      lastConfusedAt: new Date().toISOString()
    });
  }

  // Sort by confusionCount descending
  pairs.sort((a, b) => b.confusionCount - a.confusionCount);
  
  saveConfusionPairs(pairs);
  return pairs;
}

/**
 * Returns the top confused pairs
 */
export function getTopConfusedPairs(limit: number = 3): ConfusionPair[] {
  const pairs = getConfusionPairs();
  return pairs.slice(0, limit);
}

/**
 * Resolves or decreases confusion count when student gets a discrimination question correct
 */
export function recordSuccessfulDiscrimination(topicA: string, topicB: string): ConfusionPair[] {
  const pairs = getConfusionPairs();
  const [sortedA, sortedB] = [topicA, topicB].sort();

  const existingIdx = pairs.findIndex(
    p => p.topicA === sortedA && p.topicB === sortedB
  );

  if (existingIdx !== -1) {
    // Decrease the confusion count as they showed successful discrimination
    pairs[existingIdx].confusionCount = Math.max(0, pairs[existingIdx].confusionCount - 1);
    pairs[existingIdx].lastConfusedAt = new Date().toISOString();
    
    // Clean up empty ones
    const filtered = pairs.filter(p => p.confusionCount > 0);
    saveConfusionPairs(filtered);
    return filtered;
  }

  return pairs;
}

/**
 * Analyzes the confusion matrix and generates user-friendly actionable insights
 */
export function getConfusionInsights(): string[] {
  const pairs = getConfusionPairs().filter(p => p.confusionCount >= 2);
  
  if (pairs.length === 0) {
    return [
      "No major concept confusions detected yet. Keep practicing to build strong cognitive boundaries!"
    ];
  }

  return pairs.map(p => {
    return `You often confuse "${p.topicA}" and "${p.topicB}" (${p.confusionCount} times). We recommend doing a targeted discrimination drill to lock in the differences!`;
  });
}
