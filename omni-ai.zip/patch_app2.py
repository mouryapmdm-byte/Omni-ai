with open('src/App.tsx', 'r') as f:
    code = f.read()

target = """                <Chat 
                  messages={messages}
                  onSendMessage={handleSendMessage}"""

replacement = """                <Chat 
                  messages={messages}
                  zoomLevel={zoomLevel}
                  setZoomLevel={setZoomLevel}
                  contentWidth={contentWidth}
                  setContentWidth={setContentWidth}
                  onSendMessage={handleSendMessage}"""

if target in code:
    with open('src/App.tsx', 'w') as f:
        f.write(code.replace(target, replacement))
    print("Patched!")
else:
    print("Target not found")
