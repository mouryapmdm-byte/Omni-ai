export * from '../../src/modules/personalization/exampleGenerator';
