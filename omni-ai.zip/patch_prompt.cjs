const fs = require('fs');
const file = 'src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

// Update Strict Professor Mode
content = content.replace(
  "         - Autonomously draw visual diagrams (<DRAW_IMAGE>...</DRAW_IMAGE>) with annotated hotspots (<ANNOTATIONS>[...]</ANNOTATIONS>) for every core concept, teaching directly from the visual board.`",
  "         - Autonomously draw visual diagrams (<DRAW_IMAGE>...</DRAW_IMAGE>) with annotated hotspots (<ANNOTATIONS>[...]</ANNOTATIONS>) for every core concept, teaching directly from the visual board.\n         - CRITICAL AUTOMATED GRAPHING UTILITY: Whenever a mathematical function $f(x)$ or equation is detected in the chat, YOU MUST AUTOMATICALLY output an image prompt in <DRAW_IMAGE>...</DRAW_IMAGE> to visualize the curve and relevant geometric properties.`"
);

// Update Interactive Mentor Mode
content = content.replace(
  "         - Autonomously draw visual diagrams (<DRAW_IMAGE>...</DRAW_IMAGE>) and walk the student step-by-step through each visual element.`",
  "         - Autonomously draw visual diagrams (<DRAW_IMAGE>...</DRAW_IMAGE>) and walk the student step-by-step through each visual element.\n         - CRITICAL AUTOMATED GRAPHING UTILITY: Whenever a mathematical function $f(x)$ or equation is detected in the chat, YOU MUST AUTOMATICALLY output an image prompt in <DRAW_IMAGE>...</DRAW_IMAGE> to visualize the curve and relevant geometric properties.`"
);

// Update Professor Mode
content = content.replace(
  "         - Whenever explaining mathematics, physics, chemistry, biology, set theory, computer science, geometry, logic, history, or step-by-step mechanisms, YOU MUST AUTOMATICALLY output an image prompt wrapped in <DRAW_IMAGE>...</DRAW_IMAGE> tags followed by interactive hotspot annotations in <ANNOTATIONS>[...]</ANNOTATIONS>.",
  "         - Whenever explaining mathematics, physics, chemistry, biology, set theory, computer science, geometry, logic, history, or step-by-step mechanisms, YOU MUST AUTOMATICALLY output an image prompt wrapped in <DRAW_IMAGE>...</DRAW_IMAGE> tags followed by interactive hotspot annotations in <ANNOTATIONS>[...]</ANNOTATIONS>.\n         - CRITICAL AUTOMATED GRAPHING UTILITY: Whenever a mathematical function $f(x)$ or equation is detected in the chat, YOU MUST AUTOMATICALLY output an image prompt in <DRAW_IMAGE>...</DRAW_IMAGE> to visualize the curve and relevant geometric properties."
);

// Update Standard Mode
content = content.replace(
  "         - Generate visual figures or diagrams (<DRAW_IMAGE>...</DRAW_IMAGE> and <ANNOTATIONS>...</ANNOTATIONS>) ONLY when the user explicitly requests a diagram, figure, or drawing, or when explaining inherently spatial geometry or circuit layouts.",
  "         - Generate visual figures or diagrams (<DRAW_IMAGE>...</DRAW_IMAGE> and <ANNOTATIONS>...</ANNOTATIONS>) ONLY when the user explicitly requests a diagram, figure, or drawing, or when explaining inherently spatial geometry or circuit layouts.\n         - CRITICAL AUTOMATED GRAPHING UTILITY: Whenever a mathematical function $f(x)$ or equation is detected in the chat, YOU MUST AUTOMATICALLY output an image prompt in <DRAW_IMAGE>...</DRAW_IMAGE> to visualize the curve and relevant geometric properties."
);

fs.writeFileSync(file, content);
console.log("Patched App.tsx with Graphing Utility requirement");
