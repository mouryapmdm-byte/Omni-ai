import React, { useState } from 'react';
import { 
  Share2, Download, Upload, ExternalLink, CheckCircle2, 
  Layers, FileSpreadsheet, Copy, Sparkles, BookOpen
} from 'lucide-react';
import { cn } from '../lib/utils';

interface Props {
  theme?: 'light' | 'dark';
  subject?: string;
  topic?: string;
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const PlatformIntegrator: React.FC<Props> = ({
  theme = 'light',
  subject = 'Physics',
  topic = 'Electromagnetism',
  showNotification
}) => {
  const [selectedPlatform, setSelectedPlatform] = useState<'google_classroom' | 'canvas' | 'anki' | 'notion' | 'quizlet'>('anki');
  const [exportSuccess, setExportSuccess] = useState(false);

  const platforms = [
    {
      id: 'anki',
      name: 'Anki Flashcard Deck (.tsv)',
      description: 'Export all formulas and active recall questions into standard tab-separated format for Anki spaced repetition import.',
      badge: 'Spaced Repetition'
    },
    {
      id: 'google_classroom',
      name: 'Google Classroom',
      description: 'Generate structured homework assignment with rubrics and share directly into student stream.',
      badge: 'LMS Standard'
    },
    {
      id: 'canvas',
      name: 'Canvas LMS (Instructure)',
      description: 'Export Common Cartridge / QTI format quizzes and lesson syllabi into Canvas modules.',
      badge: 'Higher Ed'
    },
    {
      id: 'notion',
      name: 'Notion Workspace Template',
      description: 'Export as Cornell notes markdown with embedded LaTeX equations and toggles into your personal Notion study binder.',
      badge: 'Study Binder'
    },
    {
      id: 'quizlet',
      name: 'Quizlet Study Set',
      description: 'Generate 2-column vocabulary and definition pairs ready to copy-paste into Quizlet.',
      badge: 'Vocabulary'
    }
  ];

  const handleExport = () => {
    if (selectedPlatform === 'anki') {
      const ankiData = `What does Lenz's law state?\tThe induced EMF opposes the magnetic flux change that produced it (Conservation of Energy)
Formula for Motional EMF\t\\mathcal{E} = B v L
Energy stored in an Inductor\tU = \\frac{1}{2} L I^2
Faraday's Law of Induction\t\\mathcal{E} = -N \\frac{d\\Phi_B}{dt}`;
      const blob = new Blob([ankiData], { type: 'text/tab-separated-values' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${topic}_Anki_Deck.tsv`;
      a.click();
    }
    setExportSuccess(true);
    showNotification?.(`Exported ${topic} content to ${selectedPlatform.toUpperCase()} format!`, "success");
    setTimeout(() => setExportSuccess(false), 3000);
  };

  const isDark = theme === 'dark';

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Top Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md">
            <Share2 size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Educational Platform Integrator</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-purple-500/10 text-purple-400 border border-purple-500/20">
                LMS & Anki Export
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Seamlessly bridge Professor Clarity into Google Classroom, Canvas, Notion, Anki & Quizlet
            </p>
          </div>
        </div>

        <button
          onClick={handleExport}
          className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-lg text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
        >
          <Download size={13} />
          {exportSuccess ? "Exported!" : "Export Selected Content"}
        </button>
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {platforms.map((p) => {
            const isSelected = selectedPlatform === p.id;
            return (
              <div
                key={p.id}
                onClick={() => setSelectedPlatform(p.id as any)}
                className={cn(
                  "p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3",
                  isSelected
                    ? (isDark ? "bg-purple-950/40 border-purple-500 ring-2 ring-purple-500/20" : "bg-purple-50 border-purple-400 ring-2 ring-purple-400/20")
                    : (isDark ? "bg-slate-950/60 border-slate-800 hover:border-slate-700" : "bg-white border-slate-200 hover:border-slate-300 shadow-sm")
                )}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider text-purple-400">
                      {p.badge}
                    </span>
                    {isSelected && <CheckCircle2 size={16} className="text-purple-400" />}
                  </div>
                  <h4 className="text-sm font-bold text-slate-100">{p.name}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {p.description}
                  </p>
                </div>

                <div className="text-[11px] font-semibold text-slate-400 pt-2 border-t border-slate-800/60 flex items-center justify-between">
                  <span>Target: {subject} / {topic}</span>
                  <span className="text-purple-400 hover:underline flex items-center gap-1">
                    Select <ExternalLink size={11} />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
