/**
 * Study Content Generator Engine
 * Transforms any STEM chapter/topic into Professor Clarity's 7 Active Pedagogy Sections.
 * 
 * Strict Topic Adherence:
 * Teaches EXCLUSIVELY and ONLY the selected chapter/topic across all 7 sections according to their headings.
 */

import { buildComprehensiveHindiStudyContent } from './hindiStudyContentGenerator';
import { getCurriculumProfile, TopicCurriculumProfile } from './topicCurriculumKnowledge';

export interface LectureSectionMeta {
  id: number;
  icon: string;
  name: string;
  fullName: string;
  shortName: string;
  summary: string;
  questionCountInfo: string;
}

export const LECTURE_SECTIONS_META: LectureSectionMeta[] = [
  {
    id: 1,
    icon: '⚛️',
    name: 'Core Conceptual Foundation & Active Pedagogy',
    fullName: '⚛️ Section 1: Core Conceptual Foundation & Active Pedagogy',
    shortName: 'Core Pedagogy',
    summary: 'First-Principles Intuition, physical conservation laws, field boundaries & dynamic multi-stage SVG diagrams',
    questionCountInfo: 'Concept & Vectors'
  },
  {
    id: 2,
    icon: '📐',
    name: 'Master 10-Step Formula & Algorithmic Problem-Solving Framework',
    fullName: '📐 Section 2: Master 10-Step Formula & Algorithmic Problem-Solving Framework',
    shortName: '10-Step Formula',
    summary: '10-Step Derivation Protocol table dissecting equations & Technique 11 multi-level practice engine (Levels 1–5)',
    questionCountInfo: '5 Practice Questions'
  },
  {
    id: 3,
    icon: '📊',
    name: 'Master Tabular Summaries & Comparative Matrix Suite',
    fullName: '📊 Section 3: Master Tabular Summaries & Comparative Matrix Suite',
    shortName: 'Tabular Matrix',
    summary: 'Side-by-side analytical tables, quick-reference specifications & diagnostic decision matrix',
    questionCountInfo: 'Comparative Matrix'
  },
  {
    id: 4,
    icon: '📝',
    name: 'Academic & Board Exam Preparation Suite',
    fullName: '📝 Section 4: Academic & Board Exam Preparation Suite',
    shortName: 'Board Exam Suite',
    summary: '8 structured academic categories: VSA, SA-I, SA-II, LAQ, A&R, Case-Based, Numerical, Diagram-Based',
    questionCountInfo: '16–24 Questions'
  },
  {
    id: 5,
    icon: '🎯',
    name: 'Competitive Entrance Exam Vault (NEET / JEE / AIIMS)',
    fullName: '🎯 Section 5: Competitive Entrance Exam Vault (NEET / JEE / AIIMS)',
    shortName: 'Competitive Vault',
    summary: '10 specialized categories: Single/Multi-correct, Numerical, Match Matrix, Statement I vs II, HOTS, PYQ',
    questionCountInfo: '20–30 Questions'
  },
  {
    id: 6,
    icon: '🗣️',
    name: 'High-Yield Question Bank, Vocabulary Masterclass & Spoken Units Guide',
    fullName: '🗣️ Section 6: High-Yield Question Bank, Vocabulary Masterclass & Spoken Units Guide',
    shortName: 'High-Yield Bank',
    summary: 'Rapid fire questions + Vocabulary Masterclass (Etymology) + Interactive Spoken Units Guide',
    questionCountInfo: 'High-Yield Bank'
  },
  {
    id: 7,
    icon: '⚡',
    name: 'The 5-Layer Progressive High Voltage Summary (The Final Section)',
    fullName: '⚡ Section 7: The 5-Layer Progressive High Voltage Summary (The Final Section)',
    shortName: 'High Voltage Summary',
    summary: 'Layer 1 (30s) → Layer 2 (First Principles) → Layer 3 (Golden Equations) → Layer 4 (Traps) → Layer 5 (Visual Mental Schema)',
    questionCountInfo: '5 Progressive Layers'
  }
];

/**
 * Builds individual section markdown strictly for the given curriculum profile.
 */
function buildSectionMarkdown(profile: TopicCurriculumProfile, sectionId: number): string {
  const cleanTitle = profile.title;

  switch (sectionId) {
    case 1: {
      return `# ⚛️ Section 1: Core Conceptual Foundation & Active Pedagogy

*Welcome, students! I am **Professor Clarity**. Today, we are transforming **${cleanTitle}** into a living, intuitive mental picture in natural human language, breaking down every principle with vivid real-world analogies and active visual intuition.*

### Chapter / Topic: ${cleanTitle}

${profile.introConcept}

---

#### 💡 The Real-World Physical Analogy (Everyday Intuition)
${profile.analogy}

#### ❓ The Curiosity Question (Check for Understanding)
${profile.questionFirst}

---

#### 🎨 Dynamic Interactive Scientific Vector Schematic
${profile.svgDiagram}

---
*Observe this dynamic figure carefully: it highlights the primary physical balances, active conservation laws, and interaction boundaries governing **${cleanTitle}**.*`;
    }

    case 2: {
      return `# 📐 Section 2: Master 10-Step Formula & Algorithmic Problem-Solving Framework

### Chapter / Topic: ${cleanTitle}

Every formula in this module follows Professor Clarity's 10-step pedagogical transformation and flows directly into multi-level question practice:

### 🎯 Core Governing Equation: ${profile.governingEquationName}
$$${profile.governingEquationLatex}$$

| Step # | Protocol Phase | Plain-English Human Explanation | Scientific Formula / Value | Golden Exam Trap & Tip |
| :--- | :--- | :--- | :--- | :--- |
${profile.tenStepProtocol.map(s => `| **Step ${s.step}** | **${s.phase}** | ${s.explanation} | $${s.formulaOrValue}$ | ${s.trapAndTip} |`).join('\n')}

---

### 🧪 Technique 11: The Natural Formula-to-Practice Flow (Levels 1–5 Adaptive Practice Questions)

Now that we have derived the governing equation for **${cleanTitle}**, let us immediately transition into multi-level practice questions to test and cement your understanding:

${profile.technique11Questions.map(q => `#### ${q.level === 1 ? '🟢' : q.level === 2 ? '🟡' : q.level === 3 ? '🟠' : q.level === 4 ? '🔴' : '🟣'} Level ${q.level}: ${q.levelName} (${q.difficulty})
- **Question:** ${q.question}
- **Formula Application:** ${q.formulaApplication}
- **Step-by-Step Solution:**
${q.stepByStepSolution.map((step, idx) => `  ${idx + 1}. ${step}`).join('\n')}
- **👉 Answer:** ${q.answer}
`).join('\n')}`;
    }

    case 3: {
      return `# 📊 Section 3: Master Tabular Summaries & Comparative Matrix Suite

### Chapter / Topic: ${cleanTitle}

A comprehensive comparative analysis of key regimes, states, and variable mappings for **${cleanTitle}**:

${profile.comparativeMatrices.map(mat => `### 📊 ${mat.title}

| ${mat.headers.join(' | ')} |
| ${mat.headers.map(() => ':---').join(' | ')} |
${mat.rows.map(row => `| ${row.join(' | ')} |`).join('\n')}
`).join('\n\n')}

---

### 🧭 ${profile.diagnosticDecisionMatrix.title}

| ${profile.diagnosticDecisionMatrix.headers.join(' | ')} |
| ${profile.diagnosticDecisionMatrix.headers.map(() => ':---').join(' | ')} |
${profile.diagnosticDecisionMatrix.rows.map(row => `| ${row.join(' | ')} |`).join('\n')}`;
    }

    case 4: {
      return `# 📝 Section 4: Academic & Board Exam Preparation Suite

### Chapter / Topic: ${cleanTitle}

Structured 8-category board preparation designed according to latest official curriculum marking schemes:

${profile.academicQuestions.map((q, i) => `#### 📝 Question ${i + 1} [${q.category}] (${q.marks} Mark${q.marks > 1 ? 's' : ''})
- **Question:** ${q.question}
- **Official Model Answer:** ${q.answer}
- **Marking Scheme:**
${q.markingScheme.map(m => `  - ✓ ${m}`).join('\n')}
`).join('\n')}`;
    }

    case 5: {
      return `# 🎯 Section 5: Competitive Entrance Exam Vault (NEET / JEE / AIIMS)

### Chapter / Topic: ${cleanTitle}

High-yield problem solving, elimination shortcuts, and negative-marking traps strictly for **${cleanTitle}**:

${profile.competitiveQuestions.map((q, i) => `#### 🎯 Challenge ${i + 1}: ${q.category}
- **Question:** ${q.question}
${q.options && q.options.length ? q.options.map(opt => `  - ${opt}`).join('\n') : ''}
${q.correctOption ? `- **👉 Correct Option:** ${q.correctOption}` : ''}
- **Detailed Solution:** ${q.solution}
- **⚡ Speed Trick / Heuristic:** ${q.speedTrick}
- **⚠️ Negative Marking Trap:** ${q.negativeMarkingTrap}
`).join('\n')}`;
    }

    case 6: {
      return `# 🗣️ Section 6: High-Yield Question Bank, Vocabulary Masterclass & Spoken Units Guide

### Chapter / Topic: ${cleanTitle}

### ⚡ Rapid-Fire High-Yield Question Bank for ${cleanTitle}
${profile.rapidFireQuestions.map(q => `**Q${q.qNumber}. ${q.question}**  
- *Answer:* ${q.answer}  
- *Key Insight:* ${q.shortExplanation}
`).join('\n')}

---

### 📖 Scientific Vocabulary & Etymology Masterclass: ${cleanTitle}
| Scientific Keyword | Classical Etymology | Precise Definition | Memory Hook |
| :--- | :--- | :--- | :--- |
${profile.vocabularyMasterclass.map(v => `| **${v.term}** | ${v.etymology} | ${v.definition} | *${v.memoryHook}* |`).join('\n')}

---

### 🎙️ Spoken Units & Pronunciation Guide for ${cleanTitle}
| Symbol / Quantity | Scientific Unit | How Professor Clarity Pronounces It | Physical Context in ${cleanTitle} |
| :--- | :--- | :--- | :--- |
${profile.spokenUnits.map(u => `| **${u.symbol}** | ${u.unitName} | *"${u.spokenForm}"* | ${u.physicalMeaning} |`).join('\n')}

---

### 🎙️ Rules for Natural Spoken Speech Delivery:
- **Never Recite Formatting Marks**: Bullets, asterisks, hyphens, and ellipses remain completely silent to create natural conversational pauses.
- **Read Operators Intuitively**: Say *"plus"*, *"gives"*, *"divided by"*, and speak formulas in natural human words.
- **Separate Variables from Units**: Clearly distinguish algebraic variables from measurement units.`;
    }

    case 7: {
      return `# ⚡ Section 7: The 5-Layer Progressive High Voltage Summary (The Final Section)

### Chapter / Topic: ${cleanTitle}

#### ⚡ Layer 1: 30-Second Ultra-Compressed Core
${profile.fiveLayerSummary.layer1UltraRapid}

#### 🎯 Layer 2: 5-Bullet First Principles
${profile.fiveLayerSummary.layer2FirstPrinciples.map(p => `- ${p}`).join('\n')}

#### 📐 Layer 3: Golden Formula Hub
${profile.fiveLayerSummary.layer3GoldenEquations.map(e => `$$${e}$$`).join('\n')}

#### ⚠️ Layer 4: Common Pitfalls & High-Frequency Traps
${profile.fiveLayerSummary.layer4ExaminerTraps.map(t => `- 🚨 **Pitfall:** ${t}`).join('\n')}

#### 🧠 Layer 5: Visual Smartboard Mental Schema
\`\`\`
${profile.fiveLayerSummary.layer5VisualMentalSchema}
\`\`\``;
    }

    default:
      return '';
  }
}

/**
 * Extracts a specific section (1 to 7) from raw lecture text if present.
 */
function extractSectionFromRawText(rawText: string, sectionNumber: number): string | null {
  if (!rawText || rawText.length < 50) return null;

  const patterns: { [key: number]: RegExp } = {
    1: /(?:^|\n)(?:#+\s*|)(?:(?:⚛️\s*)?Section\s*1\b|Part\s*1\b|Core\s*Concept).*?(?=(?:\n#+\s*(?:(?:📐\s*)?Section\s*2\b|Part\s*2\b|Master\s*10-Step)|$))/is,
    2: /(?:^|\n)(?:#+\s*|)(?:(?:📐\s*)?Section\s*2\b|Part\s*2\b|Master\s*10-Step|10-Step\s*Formula).*?(?=(?:\n#+\s*(?:(?:📊\s*)?Section\s*3\b|Part\s*3\b|Master\s*Tabular)|$))/is,
    3: /(?:^|\n)(?:#+\s*|)(?:(?:📊\s*)?Section\s*3\b|Part\s*3\b|Master\s*Tabular|Tabular\s*Summaries|Comparative\s*Matrix).*?(?=(?:\n#+\s*(?:(?:📝\s*)?Section\s*4\b|Part\s*4\b|Academic\s*&?\s*Board)|$))/is,
    4: /(?:^|\n)(?:#+\s*|)(?:(?:📝\s*)?Section\s*4\b|Part\s*4\b|Academic\s*&?\s*Board|Board\s*Exam\s*Prep).*?(?=(?:\n#+\s*(?:(?:🎯\s*)?Section\s*5\b|Part\s*5\b|Competitive\s*Entrance)|$))/is,
    5: /(?:^|\n)(?:#+\s*|)(?:(?:🎯\s*)?Section\s*5\b|Part\s*5\b|Competitive\s*Entrance|NEET\s*\/\s*JEE).*?(?=(?:\n#+\s*(?:(?:🗣️\s*)?Section\s*6\b|Part\s*6\b|High-Yield\s*Question)|$))/is,
    6: /(?:^|\n)(?:#+\s*|)(?:(?:🗣️\s*)?Section\s*6\b|Part\s*6\b|High-Yield\s*Question\s*Bank|Question\s*Bank|Vocabulary\s*Masterclass).*?(?=(?:\n#+\s*(?:(?:⚡\s*)?Section\s*7\b|Part\s*7\b|5-Layer|High\s*Voltage)|$))/is,
    7: /(?:^|\n)(?:#+\s*|)(?:(?:⚡\s*)?Section\s*7\b|Part\s*7\b|5-Layer\s*Progressive|High\s*Voltage\s*Summary).*$/is
  };

  const reg = patterns[sectionNumber];
  if (!reg) return null;

  const match = rawText.match(reg);
  if (match && match[0] && match[0].trim().length > 80) {
    return match[0].trim();
  }

  return null;
}

/**
 * Breaks down lecture content into all 7 structured sections.
 * Guarantees that every section is strictly and specifically about the selected topicTitle.
 */
export function breakdownLectureIntoSections(
  topicTitle: string,
  baseLectureText?: string,
  targetLanguage: string = 'en'
): Map<number | 'all', string> {
  const cleanTitle = (topicTitle || 'Universal Mathematical Foundations').replace(/^(###\s*|Topic:\s*)/i, '').trim();

  // Hindi support routing
  const isHindi = targetLanguage === 'hi' || targetLanguage.toLowerCase() === 'hindi';
  if (isHindi || (baseLectureText && /[\u0900-\u097F]/.test(baseLectureText))) {
    const hindiMap = new Map<number | 'all', string>();
    for (let i = 1; i <= 7; i++) {
      hindiMap.set(i, buildComprehensiveHindiStudyContent(cleanTitle, baseLectureText, i as 1 | 2 | 3 | 4 | 5 | 6 | 7));
    }
    hindiMap.set('all', buildComprehensiveHindiStudyContent(cleanTitle, baseLectureText, 'all'));
    return hindiMap;
  }

  const profile = getCurriculumProfile(cleanTitle);
  const sectionsMap = new Map<number | 'all', string>();

  // Process each of the 7 sections
  for (let secId = 1; secId <= 7; secId++) {
    const meta = LECTURE_SECTIONS_META.find(s => s.id === secId)!;
    let sectionContent = '';

    // If baseLectureText is available, try extracting this section
    const extracted = baseLectureText ? extractSectionFromRawText(baseLectureText, secId) : null;
    if (extracted && extracted.length > 100) {
      // Clean up extracted section heading to match standard format
      const cleanedBody = extracted
        .replace(/^#+\s*(?:[⚛️📐📊📝🎯🗣️⚡]\s*)?Section\s*\d+[:\s-].*?\n/i, '')
        .replace(/^###\s*Chapter\s*\/\s*Topic:.*?\n/i, '')
        .trim();

      sectionContent = `# ${meta.fullName}\n\n### Chapter / Topic: ${cleanTitle}\n\n${cleanedBody}`;
    } else if (secId === 1 && baseLectureText && baseLectureText.trim().length > 60 && !baseLectureText.includes('# Section 2')) {
      // If baseLectureText is a single lecture body focused on topic, use it as Section 1
      const cleanedBody = baseLectureText
        .replace(/^#+\s*(?:[⚛️📐📊📝🎯🗣️⚡]\s*)?Section\s*1[:\s-].*?\n/i, '')
        .replace(/^###\s*Chapter\s*\/\s*Topic:.*?\n/i, '')
        .trim();

      sectionContent = `# ${meta.fullName}\n\n### Chapter / Topic: ${cleanTitle}\n\n${cleanedBody}`;
    } else {
      // Generate authoritative section content strictly about cleanTitle
      sectionContent = buildSectionMarkdown(profile, secId);
    }

    sectionsMap.set(secId, sectionContent);
  }

  // Build the combined "all" sections view
  const allSectionsCombined = [
    sectionsMap.get(1)!,
    sectionsMap.get(2)!,
    sectionsMap.get(3)!,
    sectionsMap.get(4)!,
    sectionsMap.get(5)!,
    sectionsMap.get(6)!,
    sectionsMap.get(7)!
  ].join('\n\n---\n\n');

  sectionsMap.set('all', allSectionsCombined);
  return sectionsMap;
}

/**
 * Builds full comprehensive study material containing all requested core study features,
 * or returns exclusively the specific section requested (Section 1 to 7).
 */
export function buildComprehensiveStudyContent(
  topicTitle: string, 
  baseLectureText?: string, 
  targetLanguage: string = 'en',
  sectionId?: number | 'all'
): string {
  const isHindi = targetLanguage === 'hi' || targetLanguage.toLowerCase() === 'hindi';
  const cleanTitle = (topicTitle || 'Universal Mathematical Foundations').replace(/^(###\s*|Topic:\s*)/i, '').trim();

  // If Hindi requested or baseLectureText is in Hindi, return standard Hindi study content
  if (isHindi || (baseLectureText && /[\u0900-\u097F]/.test(baseLectureText))) {
    return buildStandardOmniStudyContent(cleanTitle, baseLectureText, 'hi');
  }

  return buildStandardOmniStudyContent(cleanTitle, baseLectureText, targetLanguage);
}

/**
 * Checks whether a topic title corresponds to a whole chapter introduction.
 */
export function isChapterIntro(topicTitle: string): boolean {
  if (!topicTitle) return false;
  const clean = topicTitle.trim().toLowerCase();
  return (
    clean.startsWith('introduction') ||
    clean.startsWith('intro to') ||
    clean.startsWith('introduction to') ||
    clean.includes('chapter introduction') ||
    clean.includes('chapter overview') ||
    clean.includes('full syllabus') ||
    clean.includes('complete chapter') ||
    clean.includes('परिचय') ||
    clean.includes('अध्याय परिचय')
  );
}

/**
 * Checks whether a topic title or prompt explicitly asks for numerical questions/problems.
 */
export function isNumericalRequest(topicTitle: string): boolean {
  if (!topicTitle) return false;
  const clean = topicTitle.trim().toLowerCase();
  return (
    clean.includes('numerical') ||
    clean.includes('numericals') ||
    clean.includes('calculation') ||
    clean.includes('calculations') ||
    clean.includes('solved example') ||
    clean.includes('solved examples') ||
    clean.includes('solved problem') ||
    clean.includes('solved problems') ||
    clean.includes('practice problem') ||
    clean.includes('practice problems') ||
    clean.includes('numerical question') ||
    clean.includes('numerical questions') ||
    clean.includes('math problem') ||
    clean.includes('math problems') ||
    clean.includes('physics problem') ||
    clean.includes('physics problems') ||
    clean.includes('formula practice') ||
    clean.includes('exercise problem') ||
    clean.includes('exercise problems') ||
    clean.includes('आंकिक प्रश्न') ||
    clean.includes('संख्यात्मक प्रश्न') ||
    clean.includes('न्यूमेरिकल') ||
    clean.includes('प्रश्न हल') ||
    clean.includes('सवाल हल')
  );
}

/**
 * Builds standard mode curriculum content for Professor Omni AI.
 * Teaches strictly according to what is asked in the question/selection.
 * If the user demands numerical questions, starts directly from a numerical question without an introduction.
 */
export function buildStandardOmniStudyContent(
  topicTitle: string,
  baseText?: string,
  targetLanguage: string = 'en',
  isExplicitIntro?: boolean
): string {
  const cleanTitle = (topicTitle || 'Universal Mathematical Foundations').replace(/^(###\s*|Topic:\s*)/i, '').trim();
  const isHindi = targetLanguage === 'hi' || targetLanguage.toLowerCase() === 'hindi';

  const isNumerical = isNumericalRequest(cleanTitle);
  const isIntro = isNumerical ? false : (isExplicitIntro !== undefined ? isExplicitIntro : isChapterIntro(cleanTitle));
  const profile = getCurriculumProfile(cleanTitle);

  if (baseText && baseText.trim().length > 150) {
    const hasFiveStepTemplate =
      baseText.includes('1. Conceptual Foundational') ||
      baseText.includes('1. मुख्य सैद्धांतिक आधार') ||
      baseText.includes('5. Key Formula Sheet');
    if (!hasFiveStepTemplate || isIntro) {
      return baseText.trim();
    }
  }

  // 0. DIRECT NUMERICAL DEMAND HANDLING: Starts DIRECTLY from a numerical question
  if (isNumerical) {
    const numQuestions = profile.technique11Questions && profile.technique11Questions.length > 0
      ? profile.technique11Questions
      : [
          {
            level: 1,
            levelName: 'Level 1: Direct Substitution',
            difficulty: 'Standard Application',
            question: `Standard numerical problem applying the core equations of ${cleanTitle}.`,
            formulaApplication: profile.governingEquationName,
            stepByStepSolution: [
              'Identify the given physical quantities and convert them into standard SI units.',
              `Apply the primary governing relation: $$${profile.governingEquationLatex}$$.`,
              'Substitute the numerical values step-by-step and compute the final result.'
            ],
            answer: 'Standard Numerical Solution'
          }
        ];

    if (isHindi) {
      return `# 🔢 आंकिक प्रश्न एवं चरणबद्ध हल (Numerical Questions & Solutions): ${cleanTitle}

*नमस्ते छात्रों! मैं **प्रोफेसर ओम्नी एआई** हूँ। आपकी मांग के अनुसार **${cleanTitle}** के आंकिक प्रश्नों (Numerical Questions) से सीधे शुरुआत करते हैं।*

${numQuestions.map((q, idx) => `## 🔢 आंकिक प्रश्न ${idx + 1} (${q.levelName || 'मानक स्तर'} - ${q.difficulty || 'Direct Application'})
**प्रश्न:** ${q.question}

**दिया गया डेटा एवं प्रयुक्त सूत्र:** \`${q.formulaApplication}\`

**चरणबद्ध हल:**
${q.stepByStepSolution.map((s, sIdx) => `${sIdx + 1}. ${s}`).join('\n')}

**👉 उत्तर:** **${q.answer}**
`).join('\n---\n\n')}

### 📊 आवश्यक सूत्र संदर्भ एवं परीक्षा चेतावनी
- **मूल समीकरण:** $$${profile.governingEquationLatex}$$
- **परीक्षा में ध्यान देने योग्य सावधानी:** ⚠️ ${profile.fiveLayerSummary.layer4ExaminerTraps[0] || 'हमेशा मानक SI इकाइयों और चिह्नों की परिपाटी का ध्यान रखें।'}
`;
    }

    return `# 🔢 Numerical Questions & Step-by-Step Problem Solving: ${cleanTitle}

*Welcome, students! I am **Professor Omni AI**. As requested, we begin DIRECTLY with numerical problems and step-by-step mathematical solutions for **${cleanTitle}** without any introductory preamble.*

${numQuestions.map((q, idx) => `## 🔢 Numerical Problem ${idx + 1} (${q.levelName || `Level ${idx + 1}`} - ${q.difficulty || 'Direct Application'})
**Problem Statement:** ${q.question}

**Given Data & Applied Formula:** \`${q.formulaApplication}\`

**Step-by-Step Solution:**
${q.stepByStepSolution.map((s, sIdx) => `${sIdx + 1}. ${s}`).join('\n')}

**👉 Final Result:** **${q.answer}**
`).join('\n---\n\n')}

### 📊 Governing Formula & Exam Warning
- **Core Formula:** $$${profile.governingEquationLatex}$$
- **Key Exam Trap:** ⚠️ ${profile.fiveLayerSummary.layer4ExaminerTraps[0] || 'Always convert all parameters to standard SI units before substituting.'}
`;
  }

  // 1. RULE-BASED 5-STEP TEACHING: Valid ONLY for introduction of a chapter
  if (isIntro) {
    if (isHindi) {
      return `# ⚡ प्रोफेसर ओम्नी एआई (अध्याय परिचय): ${cleanTitle}

*नमस्ते छात्रों! मैं **प्रोफेसर ओम्नी एआई (Professor Omni AI)** हूँ। आज हम **${cleanTitle}** के संपूर्ण अध्याय का एक व्यापक परिचय और आधारभूत रूपरेखा समझेंगे।*

## 💡 1. मुख्य सैद्धांतिक आधार एवं संकल्पना (Core Conceptual Foundation)
${profile.introConcept}

### ❓ विचारणीय जिज्ञासा प्रश्न (Curiosity Question)
${profile.questionFirst}

### 🌍 दैनिक जीवन का उदाहरण एवं भौतिक अंतर्दृष्टि (Everyday Intuition)
${profile.analogy}

### 🎨 संवादात्मक वैज्ञानिक आरेख (Scientific Vector Schematic)
${profile.svgDiagram}

## 📐 2. गणितीय सूत्र, समीकरण एवं चरणबद्ध निगमन (Governing Equations & LaTeX Derivations)
**मूल समीकरण:**
$$${profile.governingEquationLatex}$$

**चरणबद्ध निगमन एवं भौतिक राशियां (Natural Step-by-Step Flow):**
${profile.tenStepProtocol.map(step => `- **चरण ${step.step} (${step.phase}):** ${step.explanation}\n  $$${step.formulaOrValue}$$\n  *छात्रों के लिए मुख्य बिंदु:* ${step.trapAndTip}`).join('\n\n')}

## 🔬 3. हल किए गए उदाहरण (Step-by-Step Worked Numerical Examples)
${profile.technique11Questions.slice(0, 2).map((q, idx) => `
### उदाहरण ${idx + 1}: ${q.levelName} (${q.difficulty})
**प्रश्न:** ${q.question}

**प्रयुक्त सूत्र:** \`${q.formulaApplication}\`

**चरणबद्ध हल:**
${q.stepByStepSolution.map(s => `- ${s}`).join('\n')}

**👉 उत्तर:** **${q.answer}**
`).join('\n')}

## 📝 4. अभ्यास प्रश्न एवं उत्तर (Standard Practice Questions for Students)
${profile.academicQuestions.slice(0, 3).map((q, idx) => `
### अभ्यास प्रश्न ${idx + 1} [${q.category} - ${q.marks} Marks]:
**प्रश्न:** ${q.question}

**आदर्श उत्तर एवं मूल्यांकन रूब्रिक:**
${q.answer}
`).join('\n')}

## ⚡ 5. प्रमुख सूत्र सारांश एवं परीक्षा युक्तियाँ (Key Formula Summary)
${profile.fiveLayerSummary.layer3GoldenEquations.map(eq => `- **सूत्र:** $$${eq}$$`).join('\n')}

**सामान्य त्रुटियां एवं सावधानियां:**
${profile.fiveLayerSummary.layer4ExaminerTraps.map(trap => `- ⚠️ ${trap}`).join('\n')}
`;
    }

    return `# ⚡ Professor Omni AI — Chapter Introduction: ${cleanTitle}

*Welcome, students! I am **Professor Omni AI**. Today we will introduce the complete chapter structure for **${cleanTitle}** in natural human language, building a solid foundation across all core principles.*

## 💡 1. Conceptual Foundation & Core Principles
${profile.introConcept}

### ❓ The Curiosity Hook (Check for Understanding)
${profile.questionFirst}

### 🌍 Real-World Physical Significance & Analogy
${profile.analogy}

### 🎨 Dynamic Interactive Scientific Vector Schematic
${profile.svgDiagram}

## 📐 2. Governing Equations & Step-by-Step Derivations
**Core Law / Governing Equation:**
$$${profile.governingEquationLatex}$$

### Step-by-Step Mathematical Framework (Natural Step Progression)
${profile.tenStepProtocol.map(step => `- **Step ${step.step} (${step.phase}):** ${step.explanation}\n  $$${step.formulaOrValue}$$\n  *Key Takeaway for Students:* ${step.trapAndTip}`).join('\n\n')}

## 🔬 3. Solved Worked-Out Examples (Technique 11 Practice Flow)
${profile.technique11Questions.slice(0, 2).map((q, idx) => `
### Example ${idx + 1} (${q.levelName} - ${q.difficulty}):
**Problem Statement:** ${q.question}

**Applied Formula:** \`${q.formulaApplication}\`

**Step-by-Step Solution:**
${q.stepByStepSolution.map(s => `1. ${s}`).join('\n')}

**Final Result:** **${q.answer}**
`).join('\n')}

## 📝 4. Standard Practice Questions & Solutions
${profile.academicQuestions.slice(0, 3).map((q, idx) => `
### Practice Problem ${idx + 1} [${q.category} - ${q.marks} Marks]:
**Question:** ${q.question}

**Model Answer & Marking Rubric:**
${q.answer}
`).join('\n')}

## ⚡ 5. Key Formula Sheet & Summary Takeaways
${profile.fiveLayerSummary.layer3GoldenEquations.map(eq => `- **Formula:** $$${eq}$$`).join('\n')}

**Core Pitfalls to Avoid:**
${profile.fiveLayerSummary.layer4ExaminerTraps.map(trap => `- ⚠️ ${trap}`).join('\n')}
`;
  }

  // 2. QUESTION-RESPONSIVE TEACHING: Valid for all questions, subtopics, and specific concepts
  // Teaches strictly according to what is asked in the question!
  if (isHindi) {
    return `# ⚡ प्रोफेसर ओम्नी एआई: ${cleanTitle}

*नमस्ते छात्रों! मैं **प्रोफेसर ओम्नी एआई** हूँ। आइए सीधे उस प्रश्न और संकल्पना को समझें जो **${cleanTitle}** में पूछी गई है।*

## 🎯 पूछे गए प्रश्न का सीधा और स्पष्ट उत्तर (Direct Answer to What is Asked)
${profile.introConcept}

### 🌍 व्यावहारिक अंतर्दृष्टि एवं भौतिक उदाहरण (Intuitive Real-World Meaning)
${profile.analogy}

${profile.svgDiagram ? `### 🎨 संवादात्मक वैज्ञानिक आरेख\n${profile.svgDiagram}\n` : ''}

## 📐 आवश्यक सूत्र एवं व्याख्या (Governing Equation for this Question)
**संबंधित मुख्य नियम:**
$$${profile.governingEquationLatex}$$

${profile.tenStepProtocol.length > 0 ? `### प्रश्न से संबंधित मुख्य चरण (Direct Breakdown):\n${profile.tenStepProtocol.slice(0, 3).map(step => `- **चरण ${step.step}:** ${step.explanation}\n  $$${step.formulaOrValue}$$`).join('\n\n')}\n` : ''}

${profile.technique11Questions.length > 0 ? `## 💡 प्रश्न पर आधारित उदाहरण हल (Applied Solution)\n**प्रश्न स्थिति:** ${profile.technique11Questions[0].question}\n\n**प्रयुक्त सूत्र:** \`${profile.technique11Questions[0].formulaApplication}\`\n\n**हल:**\n${profile.technique11Questions[0].stepByStepSolution.map(s => `- ${s}`).join('\n')}\n\n**👉 उत्तर:** **${profile.technique11Questions[0].answer}**\n` : ''}

## 📌 निष्कर्ष एवं स्मरण योग्य मुख्य बिंदु (Final Takeaway)
- **मुख्य सूत्र / सार:** ${profile.fiveLayerSummary.layer3GoldenEquations[0] ? `$$${profile.fiveLayerSummary.layer3GoldenEquations[0]}$$` : profile.introConcept.slice(0, 120)}
- **परीक्षा सावधानी:** ⚠️ ${profile.fiveLayerSummary.layer4ExaminerTraps[0] || 'हमेशा SI इकाइयों और मान्य सीमाओं का ध्यान रखें।'}
`;
  }

  return `# ⚡ Professor Omni AI: ${cleanTitle}

*Welcome, students! I am **Professor Omni AI**. Today we are focusing directly on what is asked in **${cleanTitle}**, providing a clear, rigorous, and intuitive explanation without unnecessary boilerplate.*

## 🎯 Direct Answer & Core Explanation
${profile.introConcept}

### 🌍 Physical Intuition & Practical Context
${profile.analogy}

${profile.svgDiagram ? `### 🎨 Scientific Vector Schematic\n${profile.svgDiagram}\n` : ''}

## 📐 Governing Mathematics & Essential Formulations
**Primary Governing Equation for this Question:**
$$${profile.governingEquationLatex}$$

${profile.tenStepProtocol.length > 0 ? `### Step-by-Step Analytical Breakdown (Addressing the Question):\n${profile.tenStepProtocol.slice(0, 3).map(step => `- **Step ${step.step} (${step.phase}):** ${step.explanation}\n  $$${step.formulaOrValue}$$\n  *Key Insight:* ${step.trapAndTip}`).join('\n\n')}\n` : ''}

${profile.technique11Questions.length > 0 ? `## 💡 Direct Solved Demonstration for this Problem
**Problem Context:** ${profile.technique11Questions[0].question}

**Applied Formula:** \`${profile.technique11Questions[0].formulaApplication}\`

**Step-by-Step Resolution:**
${profile.technique11Questions[0].stepByStepSolution.map(s => `1. ${s}`).join('\n')}

**Final Result:** **${profile.technique11Questions[0].answer}**
` : ''}

## 📌 Direct Conclusion & Key Takeaway
- **Core Summary:** ${profile.fiveLayerSummary.layer3GoldenEquations[0] ? `$$${profile.fiveLayerSummary.layer3GoldenEquations[0]}$$` : profile.introConcept.slice(0, 140)}
- **Key Exam / Problem-Solving Warning:** ⚠️ ${profile.fiveLayerSummary.layer4ExaminerTraps[0] || 'Always verify standard SI units and boundary conditions.'}
`;
}
