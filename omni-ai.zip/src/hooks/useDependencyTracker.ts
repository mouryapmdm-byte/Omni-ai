import { useEffect, useRef } from 'react';

export interface DependencyDiffItem {
  name?: string;
  index: number;
  prevValue: any;
  currentValue: any;
  isChanged: boolean;
  type: string;
}

/**
 * Tracks and visualizes dependency changes in useEffect or useMemo hooks.
 * Returns an array of diff items indicating which dependencies mutated between renders.
 */
export function useDependencyTracker(
  deps: any[],
  namesOrLabel?: string[] | string,
  logToConsole: boolean = false
): DependencyDiffItem[] {
  const prevDepsRef = useRef<any[]>(deps);
  const renderCountRef = useRef<number>(0);

  const label = typeof namesOrLabel === 'string' ? namesOrLabel : 'DependencyTracker';
  const depNames = Array.isArray(namesOrLabel) ? namesOrLabel : [];

  renderCountRef.current++;

  const diffItems: DependencyDiffItem[] = deps.map((dep, index) => {
    const prevDep = prevDepsRef.current[index];
    const isChanged = !Object.is(dep, prevDep);
    return {
      name: depNames[index] || `dep_${index}`,
      index,
      prevValue: prevDep,
      currentValue: dep,
      isChanged,
      type: typeof dep
    };
  });

  useEffect(() => {
    if (logToConsole) {
      const changed = diffItems.filter(d => d.isChanged);
      if (changed.length > 0) {
        console.groupCollapsed(
          `%c[DependencyTracker: ${label}] 🔄 ${changed.length} Dependency Changes detected (Render #${renderCountRef.current})`,
          'background: #f59e0b; color: black; padding: 2px 6px; border-radius: 4px; font-weight: bold;'
        );
        diffItems.forEach(d => {
          console.log(
            `%c ${d.name} [%c${d.type}%c]: ${d.isChanged ? '❌ MUTATED' : '✅ STABLE'} -> prev:`,
            'font-weight: bold;',
            'color: #8b5cf6;',
            'color: inherit;',
            d.prevValue,
            'current:',
            d.currentValue
          );
        });
        console.groupEnd();
      }
    }
    prevDepsRef.current = deps;
  });

  return diffItems;
}
