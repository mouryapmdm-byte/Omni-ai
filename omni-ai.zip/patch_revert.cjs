const fs = require('fs');
const file = 'src/components/Chat.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(
    'if (!(msg.metadata?.image || msg.metadata?.mathGraphFunctions)) return;', 
    'if (!msg.metadata?.image) return;'
);
content = content.replace(
    'const imageUrl = (msg.metadata?.image || msg.metadata?.mathGraphFunctions);',
    'const imageUrl = msg.metadata?.image;'
);
content = content.replace(
    'if (!(msg.metadata?.image || msg.metadata?.mathGraphFunctions)) return;',
    'if (!msg.metadata?.image) return;'
);
content = content.replace(
    '{(msg.metadata?.image || msg.metadata?.mathGraphFunctions) && (\n                      <div className={cn(\n                        "space-y-3",',
    '{msg.metadata?.image && (\n                      <div className={cn(\n                        "space-y-3",'
);
content = content.replace(
    '{(msg.metadata?.image || msg.metadata?.mathGraphFunctions) && (\n                      <div className="mb-3.5 rounded-2xl overflow-hidden max-w-sm border border-slate-200/20 shadow-md">',
    '{msg.metadata?.image && (\n                      <div className="mb-3.5 rounded-2xl overflow-hidden max-w-sm border border-slate-200/20 shadow-md">'
);

fs.writeFileSync(file, content);
