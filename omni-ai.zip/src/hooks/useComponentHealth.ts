import { useEffect, useRef, useState } from 'react';

export interface ComponentHealthMetrics {
  renderCount: number;
  lastRenderTimeMs: number;
  averageRenderTimeMs: number;
  isHighRenderFrequency: boolean;
  isHealthy: boolean;
  reRenderSpeedPerSec: number;
}

/**
 * Monitors component render health, calculation time, and rapid cycle frequencies.
 */
export function useComponentHealth(
  componentName: string,
  thresholds: { maxRendersPerSec?: number; warningRenderCount?: number } = {}
): ComponentHealthMetrics {
  const { maxRendersPerSec = 30, warningRenderCount = 100 } = thresholds;

  const renderCountRef = useRef<number>(0);
  const startTimeRef = useRef<number>(performance.now());
  const renderTimingsRef = useRef<number[]>([]);
  const renderTimestampsRef = useRef<number[]>([]);

  renderCountRef.current++;
  const currentRender = renderCountRef.current;
  const now = performance.now();
  const renderDuration = now - startTimeRef.current;

  renderTimestampsRef.current.push(now);
  renderTimestampsRef.current = renderTimestampsRef.current.filter(t => now - t <= 1000);
  const speed = renderTimestampsRef.current.length;

  renderTimingsRef.current.push(renderDuration);
  if (renderTimingsRef.current.length > 50) {
    renderTimingsRef.current.shift();
  }

  const avgDuration =
    renderTimingsRef.current.reduce((a, b) => a + b, 0) / renderTimingsRef.current.length;

  const isHighFreq = speed > maxRendersPerSec;
  const isUnhealthy = isHighFreq || currentRender > warningRenderCount;

  useEffect(() => {
    startTimeRef.current = performance.now();
  });

  return {
    renderCount: currentRender,
    lastRenderTimeMs: Number(renderDuration.toFixed(2)),
    averageRenderTimeMs: Number(avgDuration.toFixed(2)),
    isHighRenderFrequency: isHighFreq,
    isHealthy: !isUnhealthy,
    reRenderSpeedPerSec: speed,
  };
}
