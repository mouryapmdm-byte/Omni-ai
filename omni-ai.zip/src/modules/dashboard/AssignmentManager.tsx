import React from 'react';

export const AssignmentManager: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-bold text-white">Assignment Manager</h2>
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
        <label className="block text-slate-400">Select Chapter</label>
        <select className="w-full bg-slate-950 text-white p-2 rounded mt-2">
            <option>Calculus Basics</option>
            <option>Mechanics</option>
        </select>
        <button className="bg-indigo-500 text-white px-4 py-2 rounded mt-4">Create Assignment</button>
      </div>
    </div>
  );
};
