import React from 'react';
import { motion } from 'motion/react';
import { 
  ShieldAlert, RefreshCw, ExternalLink, Globe, HelpCircle, 
  CheckCircle2, AlertCircle, Play, SlidersHorizontal, Activity,
  Clock, Layers, Lock, Trash2
} from 'lucide-react';
import { PlaybackDiagnostic } from '../lib/videoHealth';
import { RecoveryStrategy } from '../lib/mediaErrorMonitor';

interface MediaRecoveryPanelProps {
  diagnosticReport: PlaybackDiagnostic;
  playbackError: string | null;
  currentStrategy: RecoveryStrategy;
  retryCount: number;
  isRetrying: boolean;
  src: string;
  isBlob: boolean;
  onSelectStrategy: (strategy: RecoveryStrategy) => void;
  onDismiss: () => void;
}

export const MediaRecoveryPanel: React.FC<MediaRecoveryPanelProps> = ({
  diagnosticReport,
  playbackError,
  currentStrategy,
  retryCount,
  isRetrying,
  src,
  isBlob,
  onSelectStrategy,
  onDismiss
}) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 bg-slate-950/95 backdrop-blur-xl flex flex-col justify-between p-5 md:p-6 text-left z-30 overflow-y-auto"
    >
      <div className="space-y-4">
        {/* Header with animated integrity radar */}
        <div className="flex items-start justify-between border-b border-slate-800/85 pb-3">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping" />
              <div className="w-9 h-9 bg-rose-600/15 text-rose-400 rounded-xl border border-rose-500/30 flex items-center justify-center relative">
                <ShieldAlert size={20} />
              </div>
            </div>
            <div>
              <h3 className="text-xs md:text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                Playback Integrity Protection System
                <span className="text-[9px] bg-red-500/15 text-red-500 font-bold px-1.5 py-0.5 rounded border border-red-500/25 uppercase">
                  Active Shield
                </span>
              </h3>
              <p className="text-[10px] text-slate-400 font-mono">
                Instance Monitor: Error Code {diagnosticReport.code} ({diagnosticReport.codeName})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="text-[10px] bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-full font-mono text-slate-400 flex items-center gap-1.5">
              <Activity size={10} className="text-indigo-400 animate-pulse" />
              <span>Retry Queue: {retryCount}/2</span>
            </div>
            <button
              onClick={onDismiss}
              className="text-slate-500 hover:text-white text-xs font-mono p-1 rounded hover:bg-slate-900 transition"
              title="Dismiss Alert"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Diagnostic Breakdown */}
        <div className="space-y-2">
          <div className="text-[10px] font-black text-rose-400 uppercase tracking-widest flex items-center gap-1.5">
            <AlertCircle size={12} /> Live Exception Summary
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-semibold bg-slate-900/50 border border-slate-900 rounded-xl p-3">
            {diagnosticReport.summary}
          </p>
        </div>

        {/* Advanced Technical Troubleshooting Diagnostics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Background Processing Section */}
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-3 space-y-2 text-xs">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold uppercase tracking-wider text-[10px]">
              <Clock size={12} /> Background Processing
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Large or high-definition uploads take anywhere from a few minutes to an hour to fully compile and optimize on our servers. During background encoding, streams might temporarily trigger format warnings.
            </p>
          </div>

          {/* Browser State & App Cache Section */}
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-3 space-y-2 text-xs">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold uppercase tracking-wider text-[10px]">
              <Layers size={12} /> Browser & App Cache
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Your browser may be loading an older, cached memory state from before the video successfully uploaded. Clearing local storage and IndexedDB blocks can force immediate, raw media re-fetching.
            </p>
          </div>

          {/* DRM / Security Filters Section */}
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-3 space-y-2 text-xs">
            <div className="flex items-center gap-1.5 text-rose-400 font-bold uppercase tracking-wider text-[10px]">
              <Lock size={12} /> DRM & Security Filters
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              If the media contains copyright-restricted lectures or DRM encrypted fragments, browser security shields might pause playback. Playing in a native tab bypassing frame security can resolve this.
            </p>
          </div>
        </div>

        {/* Real-time self-healing radar checklist */}
        <div className="bg-slate-900/40 border border-slate-900 rounded-2xl p-4 space-y-3">
          <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
            <SlidersHorizontal size={12} className="text-indigo-400" />
            Central Integrity Check & Recovery Checklist
          </span>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Checklist Step 1 */}
            <div className="flex items-center justify-between bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/40 text-xs">
              <span className="text-slate-400 font-bold">1. Network Handshake Integrity</span>
              <span className="text-emerald-400 font-black flex items-center gap-1">
                <CheckCircle2 size={12} /> SECURE
              </span>
            </div>

            {/* Checklist Step 2 */}
            <div className="flex items-center justify-between bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/40 text-xs">
              <span className="text-slate-400 font-bold">2. Codec & MIME Decoding</span>
              {isBlob ? (
                <span className="text-amber-400 font-black flex items-center gap-1">
                  ⚠️ BLOB RESTRICTED
                </span>
              ) : (
                <span className="text-emerald-400 font-black flex items-center gap-1">
                  <CheckCircle2 size={12} /> VERIFIED
                </span>
              )}
            </div>

            {/* Checklist Step 3 */}
            <div className="flex items-center justify-between bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/40 text-xs">
              <span className="text-slate-400 font-bold">3. Server Proxy Routing</span>
              {isBlob ? (
                <span className="text-slate-500 font-black flex items-center gap-1">
                  🚫 BYPASSED (LOCAL FILE)
                </span>
              ) : currentStrategy === 'proxy' ? (
                <span className="text-indigo-400 font-black flex items-center gap-1 animate-pulse">
                  🔄 ROUTING ACTIVE
                </span>
              ) : (
                <span className="text-slate-500 font-black">READY</span>
              )}
            </div>

            {/* Checklist Step 4 */}
            <div className="flex items-center justify-between bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/40 text-xs">
              <span className="text-slate-400 font-bold">4. Auto Self-Healing Stream</span>
              {currentStrategy === 'fallback' ? (
                <span className="text-emerald-400 font-black flex items-center gap-1 animate-bounce">
                  🚀 STAGE 3 fall-back
                </span>
              ) : isRetrying ? (
                <span className="text-amber-400 font-black flex items-center gap-1 animate-pulse">
                  🔄 ATTEMPTING REPAIR
                </span>
              ) : (
                <span className="text-indigo-400 font-bold">MONITORING</span>
              )}
            </div>
          </div>
        </div>

        {/* Detailed action guide */}
        <div className="space-y-1.5 text-xs text-slate-300">
          <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider block">
            Suggested Manual Troubleshooting
          </span>
          <ul className="space-y-1 list-disc list-inside bg-slate-900/20 border border-slate-900/50 rounded-xl p-3 text-slate-400 font-medium">
            {diagnosticReport.troubleshooting.map((step, idx) => (
              <li key={idx} className="leading-relaxed">{step}</li>
            ))}
          </ul>
        </div>
      </div>

      {/* Control Actions Panel */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800/80 mt-4">
        <div className="text-[10px] text-slate-500 font-mono truncate max-w-[200px] md:max-w-xs">
          Source URL: <span className="text-indigo-400 font-bold select-all">{src}</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Action: Open Direct in Native Tab */}
          <button
            type="button"
            onClick={() => window.open(src, '_blank')}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white rounded-xl font-bold text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer border border-slate-800"
          >
            <ExternalLink size={13} /> Native Play
          </button>

          {/* Action: Try Proxy Recovery */}
          {!isBlob && (
            <button
              type="button"
              onClick={() => onSelectStrategy('proxy')}
              disabled={currentStrategy === 'proxy'}
              className={`px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer border ${
                currentStrategy === 'proxy'
                  ? 'bg-indigo-950/20 text-indigo-500 border-indigo-950 cursor-not-allowed opacity-50'
                  : 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border-slate-800'
              }`}
            >
              <Globe size={13} /> Reroute Proxy
            </button>
          )}

          {/* Action: Clear Cache Hard Reset */}
          <button
            type="button"
            onClick={() => {
              if (confirm("Are you sure you want to perform a hard reset on the local video cache? This will clear all offline IndexedDB video chunks.")) {
                try {
                  localStorage.removeItem('omni_media_error_telemetry');
                  indexedDB.deleteDatabase('omni_lecture_offline_cache');
                } catch (e) {
                  console.error(e);
                }
              }
            }}
            className="px-3.5 py-2 bg-rose-950/20 hover:bg-rose-950/40 text-rose-400 hover:text-rose-300 rounded-xl font-bold text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer border border-rose-500/20"
          >
            <Trash2 size={13} /> Clear App Cache
          </button>

          {/* Action: Reset Original Stream */}
          <button
            type="button"
            onClick={() => onSelectStrategy('original')}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white rounded-xl font-bold text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer border border-slate-800"
          >
            <RefreshCw size={13} /> Reload Original
          </button>

          {/* Action: Auto-Repair Safe Fallback */}
          <button
            type="button"
            onClick={() => onSelectStrategy('fallback')}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-extrabold text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-lg shadow-indigo-600/20"
          >
            <CheckCircle2 size={13} /> Force Safe Stream
          </button>
        </div>
      </div>
    </motion.div>
  );
};
export default MediaRecoveryPanel;
