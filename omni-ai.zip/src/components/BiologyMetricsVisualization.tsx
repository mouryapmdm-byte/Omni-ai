import React, { useState, useMemo, useEffect } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';
import { Activity, TrendingUp, Dna, Sun, Info, Save, RotateCcw, Zap, AlertTriangle } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { validateBioVariable, BIO_RULES } from '@/src/lib/bioValidation';

interface BiologyMetricsVisualizationProps {
  theme?: 'light' | 'dark';
  initialMetricTab?: 'population' | 'enzyme' | 'dna' | 'respiration';
  onSaveSnapshotNote?: (title: string, summary: string, concepts: string[]) => void;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
}

export const BiologyMetricsVisualization: React.FC<BiologyMetricsVisualizationProps> = ({
  theme = 'light',
  initialMetricTab = 'population',
  onSaveSnapshotNote,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<'population' | 'enzyme' | 'dna' | 'respiration'>(initialMetricTab);

  // --- 1. Population Growth State ---
  const [n0, setN0] = useState<number>(50);
  const [rRate, setRRate] = useState<number>(0.18);
  const [carryingCapacityK, setCarryingCapacityK] = useState<number>(500);
  const [timeSpan, setTimeSpan] = useState<number>(30);

  // --- 2. Enzyme Kinetics State ---
  const [vMax, setVMax] = useState<number>(100);
  const [kM, setKM] = useState<number>(25);
  const [enzymeFactor, setEnzymeFactor] = useState<'substrate' | 'temperature' | 'ph'>('substrate');
  const [selectedEnzyme, setSelectedEnzyme] = useState<'pepsin' | 'amylase' | 'trypsin'>('amylase');

  // --- 3. DNA Hybridization & Melting Curve State ---
  const [gcPercent, setGcPercent] = useState<number>(55);
  const [saltConc, setSaltConc] = useState<number>(0.15); // Molar NaCl

  // --- 4. Cellular Respiration State ---
  const [oxygenLevel, setOxygenLevel] = useState<number>(21); // % O2

  // Lab state communication
  useEffect(() => {
    const handleQuery = () => {
      window.dispatchEvent(new CustomEvent('lab_state_update', { 
        detail: { 
          type: 'enzyme_kinetics', 
          data: { vMax, kM, enzymeFactor, selectedEnzyme } 
        } 
      }));
    };

    window.addEventListener('query_lab_state', handleQuery);
    return () => window.removeEventListener('query_lab_state', handleQuery);
  }, [vMax, kM, enzymeFactor, selectedEnzyme]);

  // Real-time updates
  useEffect(() => {
    window.dispatchEvent(new CustomEvent('lab_state_update', { 
      detail: { 
        type: 'enzyme_kinetics_update', 
        data: { vMax, kM, enzymeFactor, selectedEnzyme } 
      } 
    }));
  }, [vMax, kM, enzymeFactor, selectedEnzyme]);

  // -------------------------------------------------------------
  // Data Generation 1: Population Growth Data (Exponential vs Logistic)
  // -------------------------------------------------------------
  const populationData = useMemo(() => {
    const data = [];
    for (let t = 0; t <= timeSpan; t += 1) {
      // Exponential: N_t = N0 * e^(r*t)
      const exponential = Math.round(n0 * Math.exp(rRate * t));
      
      // Logistic: N_t = K / (1 + ((K - N0)/N0) * e^(-r*t))
      const logistic = Math.round(
        carryingCapacityK / (1 + ((carryingCapacityK - n0) / n0) * Math.exp(-rRate * t))
      );

      data.push({
        time: `Day ${t}`,
        t,
        Exponential: Math.min(exponential, carryingCapacityK * 2.5),
        Logistic: Math.min(logistic, carryingCapacityK)
      });
    }
    return data;
  }, [n0, rRate, carryingCapacityK, timeSpan]);

  // Inflection Point calculation (N = K/2)
  const inflectionPointDay = useMemo(() => {
    if (carryingCapacityK <= n0) return 0;
    const day = Math.log((carryingCapacityK - n0) / n0) / rRate;
    return Math.max(0, Math.round(day * 10) / 10);
  }, [carryingCapacityK, n0, rRate]);

  // -------------------------------------------------------------
  // Data Generation 2: Enzyme Kinetics Data
  // -------------------------------------------------------------
  const enzymeData = useMemo(() => {
    const data = [];
    if (enzymeFactor === 'substrate') {
      for (let s = 0; s <= 150; s += 5) {
        // Michaelis-Menten: v = (Vmax * [S]) / (Km + [S])
        const v = (vMax * s) / (kM + s);
        data.push({
          substrate: s,
          velocity: Math.round(v * 10) / 10,
          halfVmax: Math.round((vMax / 2) * 10) / 10
        });
      }
    } else if (enzymeFactor === 'temperature') {
      for (let temp = 0; temp <= 70; temp += 2) {
        // Optimal temp around 37C with sharp heat denaturation past 45C
        let activity = 0;
        if (temp <= 37) {
          activity = Math.pow(2, (temp - 37) / 10) * 100;
        } else {
          activity = Math.max(0, 100 - Math.pow((temp - 37) / 1.8, 2));
        }
        data.push({
          temperature: `${temp}°C`,
          tempVal: temp,
          activity: Math.round(activity)
        });
      }
    } else if (enzymeFactor === 'ph') {
      const optimalPH = selectedEnzyme === 'pepsin' ? 2.0 : selectedEnzyme === 'amylase' ? 6.8 : 8.5;
      for (let ph = 0; ph <= 12; ph += 0.5) {
        // Gaussian bell curve centered at optimal pH
        const activity = Math.max(0, 100 * Math.exp(-Math.pow(ph - optimalPH, 2) / 2.5));
        data.push({
          ph: ph.toFixed(1),
          phVal: ph,
          activity: Math.round(activity)
        });
      }
    }
    return data;
  }, [vMax, kM, enzymeFactor, selectedEnzyme]);

  // -------------------------------------------------------------
  // Data Generation 3: DNA Hybridization & Tm Curve
  // -------------------------------------------------------------
  // Marmur-Doty formula: Tm = 69.3 + 0.41*(%GC) + 16.6*log10([Na+])
  const calculatedTm = useMemo(() => {
    const tm = 69.3 + 0.41 * gcPercent + 16.6 * Math.log10(saltConc);
    return Math.round(tm * 10) / 10;
  }, [gcPercent, saltConc]);

  const dnaMeltingData = useMemo(() => {
    const data = [];
    for (let temp = 50; temp <= 105; temp += 2) {
      // Sigmoidal hyperchromic shift from 1.0 (dsDNA) to 1.37 (ssDNA)
      const fractionDenatured = 1 / (1 + Math.exp(-(temp - calculatedTm) / 2.2));
      const absorbance260 = 1.0 + 0.37 * fractionDenatured;
      const hybridizationPct = Math.round((1 - fractionDenatured) * 100);

      data.push({
        temp: `${temp}°C`,
        tempVal: temp,
        absorbance: Math.round(absorbance260 * 1000) / 1000,
        hybridizationPct
      });
    }
    return data;
  }, [calculatedTm]);

  // -------------------------------------------------------------
  // Data Generation 4: Cellular Respiration & ATP Kinetics Curve
  // -------------------------------------------------------------
  const respirationData = useMemo(() => {
    const data = [];
    // Substrate Glucose Concentration vs ATP Generation Rate
    for (let substrate = 0; substrate <= 100; substrate += 5) {
      const o2Factor = Math.min(1.2, oxygenLevel / 21);
      const maxAtp = 38 * o2Factor;
      const rate = (maxAtp * substrate) / (15 + substrate);
      data.push({
        substrate,
        rate: Math.round(rate * 10) / 10,
        compensationLine: 0
      });
    }
    return data;
  }, [oxygenLevel]);

  // Save Snapshot Event Handler
  const handleSaveSnapshot = () => {
    let title = 'Biology Lab Metric Study';
    let summary = '';
    let concepts: string[] = [];

    if (activeTab === 'population') {
      title = 'Population Growth Kinetics (Exponential vs Logistic)';
      summary = `Simulated population growth with Initial N0=${n0}, Intrinsic rate r=${rRate}, Carrying Capacity K=${carryingCapacityK}. Inflection point (K/2) occurs at Day ${inflectionPointDay}.`;
      concepts = ['Exponential Growth (dN/dt = rN)', 'Logistic Growth (dN/dt = rN(K-N)/K)', 'Carrying Capacity K', 'Ecological Population Dynamics'];
    } else if (activeTab === 'enzyme') {
      title = 'Enzyme Kinetics & Catalytic Velocity Analysis';
      summary = `Michaelis-Menten kinetic analysis with Vmax=${vMax} µmol/min, Km=${kM} mM. Studied factor: ${enzymeFactor}.`;
      concepts = ['Michaelis-Menten Equation', 'Vmax & Km Substrate Affinity', 'Enzyme Denaturation', 'Optimum Temperature and pH'];
    } else if (activeTab === 'dna') {
      title = 'DNA Thermal Denaturation & Hybridization Melting Curve';
      summary = `Evaluated DNA duplex stability with ${gcPercent}% GC content and ${saltConc} M Na+ concentration. Derived Melting Temperature Tm = ${calculatedTm}°C.`;
      concepts = ['Hyperchromic Effect (A260)', 'Melting Temperature (Tm)', 'GC Content 3-Hydrogen Bonding', 'DNA Renaturation & Hybridization'];
    } else if (activeTab === 'respiration') {
      title = 'Cellular Respiration & Aerobic ATP Generation Curve';
      summary = `Simulated ATP synthesis velocity and oxidative phosphorylation under ${oxygenLevel}% O2 concentration.`;
      concepts = ['Glycolysis & Krebs Cycle', 'Oxidative Phosphorylation', 'Cytochrome c Oxidase Kinetics', 'Theoretical ATP Yield (36-38 ATP)'];
    }

    if (onSaveSnapshotNote) {
      onSaveSnapshotNote(title, summary, concepts);
    } else {
      window.dispatchEvent(
        new CustomEvent('save_omni_note', {
          detail: {
            title,
            summary,
            keyConcepts: concepts,
            subject: 'Science (Biology)',
            topic: title
          }
        })
      );
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
      {/* Top Navigation Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('population')}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap",
              activeTab === 'population'
                ? "bg-emerald-500 text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            )}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            1. Population Growth
          </button>
          <button
            onClick={() => setActiveTab('enzyme')}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap",
              activeTab === 'enzyme'
                ? "bg-emerald-500 text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            )}
          >
            <Activity className="w-3.5 h-3.5" />
            2. Enzyme Kinetics
          </button>
          <button
            onClick={() => setActiveTab('dna')}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap",
              activeTab === 'dna'
                ? "bg-emerald-500 text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            )}
          >
            <Dna className="w-3.5 h-3.5" />
            3. DNA Melting ($T_m$)
          </button>
          <button
            onClick={() => setActiveTab('respiration')}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap",
              activeTab === 'respiration'
                ? "bg-emerald-500 text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            )}
          >
            <Zap className="w-3.5 h-3.5" />
            4. Cellular Respiration
          </button>
        </div>

        <button
          onClick={handleSaveSnapshot}
          className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition shrink-0"
          title="Save metric analysis into Study Notes"
        >
          <Save className="w-3.5 h-3.5" />
          <span>Save Note Snapshot</span>
        </button>
      </div>

      {/* Main Interactive Screen */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left Side: Parameters & Configuration Controls */}
        <div className="w-full lg:w-[320px] bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 p-4 overflow-y-auto flex flex-col justify-between">
          {activeTab === 'population' && (
            <div className="space-y-4">
              <div>
                <span className="text-[10px] uppercase font-bold text-emerald-500 tracking-wider">Ecology Module</span>
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Growth Kinetics Parameters</h3>
              </div>

              {/* N0 Initial Population */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-600 dark:text-slate-400">Initial Pop ($N_0$)</span>
                  <span className="font-mono font-bold text-emerald-600">{n0}</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="500"
                  step="10"
                  value={n0}
                  onChange={(e) => {
                    const raw = parseInt(e.target.value);
                    const res = validateBioVariable('n0', raw, showNotification);
                    setN0(res.value);
                  }}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded appearance-none cursor-pointer"
                />
              </div>

              {/* Intrinsic rate r */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-600 dark:text-slate-400">Intrinsic Rate ($r$)</span>
                  <span className="font-mono font-bold text-emerald-600">{rRate.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.40"
                  step="0.01"
                  value={rRate}
                  onChange={(e) => setRRate(parseFloat(e.target.value))}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded appearance-none cursor-pointer"
                />
              </div>

              {/* Carrying capacity K */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-600 dark:text-slate-400">Carrying Capacity ($K$)</span>
                  <span className="font-mono font-bold text-emerald-600">{carryingCapacityK}</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="2000"
                  step="50"
                  value={carryingCapacityK}
                  onChange={(e) => {
                    const raw = parseInt(e.target.value);
                    const res = validateBioVariable('carryingCapacityK', raw, showNotification);
                    setCarryingCapacityK(res.value);
                  }}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded appearance-none cursor-pointer"
                />
              </div>

              {/* Formula & Key Metrics Summary */}
              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
                <div className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-amber-500" /> Key Model Output
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Max Growth Rate at:</span>
                  <span className="font-mono font-bold text-slate-700 dark:text-slate-200">N = {carryingCapacityK / 2}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Inflection Point:</span>
                  <span className="font-mono font-bold text-blue-500">Day {inflectionPointDay}</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'enzyme' && (
            <div className="space-y-4">
              <div>
                <span className="text-[10px] uppercase font-bold text-emerald-500 tracking-wider">Biochemistry Module</span>
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Enzyme Kinetics Settings</h3>
              </div>

              {/* Factor Switcher */}
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-600 dark:text-slate-400">Investigated Variable</label>
                <div className="grid grid-cols-3 gap-1">
                  <button
                    onClick={() => setEnzymeFactor('substrate')}
                    className={cn(
                      "text-[10px] py-1 font-semibold rounded border transition",
                      enzymeFactor === 'substrate'
                        ? "bg-emerald-500 text-white border-emerald-600"
                        : "border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 text-slate-600 dark:text-slate-400"
                    )}
                  >
                    Substrate [S]
                  </button>
                  <button
                    onClick={() => setEnzymeFactor('temperature')}
                    className={cn(
                      "text-[10px] py-1 font-semibold rounded border transition",
                      enzymeFactor === 'temperature'
                        ? "bg-emerald-500 text-white border-emerald-600"
                        : "border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 text-slate-600 dark:text-slate-400"
                    )}
                  >
                    Temp (°C)
                  </button>
                  <button
                    onClick={() => setEnzymeFactor('ph')}
                    className={cn(
                      "text-[10px] py-1 font-semibold rounded border transition",
                      enzymeFactor === 'ph'
                        ? "bg-emerald-500 text-white border-emerald-600"
                        : "border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 text-slate-600 dark:text-slate-400"
                    )}
                  >
                    pH Profile
                  </button>
                </div>
              </div>

              {enzymeFactor === 'substrate' && (
                <>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-slate-600 dark:text-slate-400">Max Velocity (V_max)</span>
                      <span className="font-mono font-bold text-emerald-600">{vMax} µmol/min</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="200"
                      step="10"
                      value={vMax}
                      onChange={(e) => setVMax(parseInt(e.target.value))}
                      className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded appearance-none cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-slate-600 dark:text-slate-400">Michaelis Constant ($K_m$)</span>
                      <span className="font-mono font-bold text-emerald-600">{kM} mM</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="60"
                      step="5"
                      value={kM}
                      onChange={(e) => setKM(parseInt(e.target.value))}
                      className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded appearance-none cursor-pointer"
                    />
                    <span className="text-[10px] text-slate-400">Lower $K_m$ indicates higher enzyme-substrate affinity.</span>
                  </div>
                </>
              )}

              {enzymeFactor === 'ph' && (
                <div className="space-y-2">
                  <label className="text-xs font-medium text-slate-600 dark:text-slate-400">Select Digestive Enzyme</label>
                  <div className="space-y-1">
                    {[
                      { id: 'pepsin', label: 'Pepsin (Stomach)', ph: 'pH ~2.0' },
                      { id: 'amylase', label: 'Salivary Amylase (Mouth)', ph: 'pH ~6.8' },
                      { id: 'trypsin', label: 'Trypsin (Small Intestine)', ph: 'pH ~8.5' }
                    ].map(e => (
                      <button
                        key={e.id}
                        onClick={() => setSelectedEnzyme(e.id as any)}
                        className={cn(
                          "w-full text-left p-2 rounded-lg text-xs font-medium border flex justify-between items-center transition",
                          selectedEnzyme === e.id
                            ? "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-800 dark:text-emerald-300"
                            : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900"
                        )}
                      >
                        <span>{e.label}</span>
                        <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">{e.ph}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'dna' && (
            <div className="space-y-4">
              <div>
                <span className="text-[10px] uppercase font-bold text-emerald-500 tracking-wider">Molecular Genetics</span>
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">DNA Duplex Melting Controls</h3>
              </div>

              {/* GC Content slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-600 dark:text-slate-400">G-C Base Pair Ratio</span>
                  <span className="font-mono font-bold text-emerald-600">{gcPercent}% GC</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="80"
                  step="2"
                  value={gcPercent}
                  onChange={(e) => setGcPercent(parseInt(e.target.value))}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded appearance-none cursor-pointer"
                />
                <span className="text-[10px] text-slate-400">G-C pairs form 3 hydrogen bonds vs 2 H-bonds in A-T pairs.</span>
              </div>

              {/* Salt conc */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-600 dark:text-slate-400">Ionic Strength ($[Na^+]$)</span>
                  <span className="font-mono font-bold text-emerald-600">{saltConc} M</span>
                </div>
                <input
                  type="range"
                  min="0.01"
                  max="1.50"
                  step="0.02"
                  value={saltConc}
                  onChange={(e) => {
                    const raw = parseFloat(e.target.value);
                    const res = validateBioVariable('saltConc', raw, showNotification);
                    setSaltConc(res.value);
                  }}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded appearance-none cursor-pointer"
                />
              </div>

              {/* Output Tm metric box */}
              <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs space-y-1">
                <span className="text-[10px] font-bold uppercase text-emerald-600 dark:text-emerald-400">Calculated Melting Temp ($T_m$)</span>
                <div className="text-2xl font-bold font-mono text-emerald-700 dark:text-emerald-300">
                  {calculatedTm} °C
                </div>
                <p className="text-[10px] text-emerald-800 dark:text-emerald-200">
                  Temperature where 50% of the DNA duplex is denatured into single strands.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'respiration' && (
            <div className="space-y-4">
              <div>
                <span className="text-[10px] uppercase font-bold text-emerald-500 tracking-wider">Cellular Metabolism & ATP Kinetics</span>
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">Cellular Respiration Kinetics</h3>
              </div>

              {/* Oxygen saturation slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-600 dark:text-slate-400">Ambient $O_2$ Saturation</span>
                  <span className="font-mono font-bold text-emerald-600">{oxygenLevel}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="1"
                  value={oxygenLevel}
                  onChange={(e) => {
                    const raw = parseInt(e.target.value);
                    const res = validateBioVariable('oxygenLevel', raw, showNotification);
                    setOxygenLevel(res.value);
                  }}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded appearance-none cursor-pointer"
                />
              </div>

              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs space-y-2">
                <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Info className="w-3.5 h-3.5 text-blue-500" /> Oxidative Phosphorylation
                </span>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                  Oxygen acts as the terminal electron acceptor in the mitochondrial electron transport chain, generating ATP through proton chemiosmosis.
                </p>
              </div>
            </div>
          )}

          {/* Quick Theory / Subtopic Reference footer */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 space-y-1">
            <span className="font-semibold text-slate-700 dark:text-slate-300">Curriculum Link:</span>
            <p>CBSE Class 12 Biology • NCERT Syllabus Standardized Dataset</p>
          </div>
        </div>

        {/* Right Side: Recharts Graphical Render Screen */}
        <div className="flex-1 p-4 bg-slate-50 dark:bg-slate-900 flex flex-col justify-between overflow-hidden">
          <div className="flex-1 min-h-[300px] w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col relative shadow-sm">
            {/* Chart Title Header */}
            <div className="flex justify-between items-center mb-3">
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  {activeTab === 'population' && 'Population Size $N_t$ over Time (Days)'}
                  {activeTab === 'enzyme' && (enzymeFactor === 'substrate' ? 'Reaction Velocity $v$ vs Substrate Concentration $[S]$' : enzymeFactor === 'temperature' ? 'Relative Enzyme Activity (%) vs Temperature (°C)' : 'Relative Enzyme Activity (%) vs pH')}
                  {activeTab === 'dna' && 'DNA Absorbance ($A_{260}$) & Hybridization (%) vs Temperature'}
                  {activeTab === 'respiration' && 'ATP Generation Rate vs Glucose Substrate Conc (mM)'}
                </h4>
              </div>
            </div>

            {/* Recharts Render Canvas */}
            <div className="flex-1 w-full min-h-[220px]">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                {activeTab === 'population' ? (
                  <AreaChart data={populationData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorLog" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                      </linearGradient>
                      <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                    <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} />
                    <YAxis stroke="#94a3b8" fontSize={11} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                        borderColor: '#334155',
                        borderRadius: '8px',
                        fontSize: '12px'
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px' }} />
                    <ReferenceLine y={carryingCapacityK} label={`Carrying Capacity K = ${carryingCapacityK}`} stroke="#ef4444" strokeDasharray="4 4" />
                    <Area type="monotone" dataKey="Logistic" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorLog)" />
                    <Area type="monotone" dataKey="Exponential" stroke="#3b82f6" strokeWidth={2} strokeDasharray="4 4" fillOpacity={1} fill="url(#colorExp)" />
                  </AreaChart>
                ) : activeTab === 'enzyme' ? (
                  <LineChart data={enzymeData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                    {enzymeFactor === 'substrate' && (
                      <>
                        <XAxis dataKey="substrate" stroke="#94a3b8" fontSize={11} label={{ value: 'Substrate [S] (mM)', position: 'insideBottom', offset: -5, fontSize: 10 }} />
                        <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'Velocity v', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                        <Tooltip />
                        <Legend />
                        <ReferenceLine y={vMax / 2} label={`Vmax/2 = ${vMax / 2}`} stroke="#a855f7" strokeDasharray="3 3" />
                        <ReferenceLine x={kM} label={`Km = ${kM}`} stroke="#3b82f6" strokeDasharray="3 3" />
                        <Line type="monotone" dataKey="velocity" name="Reaction Rate v" stroke="#10b981" strokeWidth={2.5} dot={false} />
                      </>
                    )}
                    {enzymeFactor === 'temperature' && (
                      <>
                        <XAxis dataKey="temperature" stroke="#94a3b8" fontSize={11} />
                        <YAxis stroke="#94a3b8" fontSize={11} />
                        <Tooltip />
                        <ReferenceLine x="37°C" label="Optimum Temp (37°C)" stroke="#ef4444" strokeDasharray="3 3" />
                        <Line type="monotone" dataKey="activity" name="Enzyme Activity (%)" stroke="#f59e0b" strokeWidth={2.5} dot={{ r: 2 }} />
                      </>
                    )}
                    {enzymeFactor === 'ph' && (
                      <>
                        <XAxis dataKey="ph" stroke="#94a3b8" fontSize={11} label={{ value: 'pH Scale', position: 'insideBottom', offset: -5, fontSize: 10 }} />
                        <YAxis stroke="#94a3b8" fontSize={11} />
                        <Tooltip />
                        <Line type="monotone" dataKey="activity" name="Enzyme Activity (%)" stroke="#a855f7" strokeWidth={2.5} dot={false} />
                      </>
                    )}
                  </LineChart>
                ) : activeTab === 'dna' ? (
                  <LineChart data={dnaMeltingData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                    <XAxis dataKey="temp" stroke="#94a3b8" fontSize={11} />
                    <YAxis yAxisId="left" stroke="#10b981" fontSize={11} domain={[0.9, 1.5]} label={{ value: 'Absorbance (260nm)', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#3b82f6" fontSize={11} domain={[0, 100]} label={{ value: 'Hybridization %', angle: 90, position: 'insideRight', fontSize: 10 }} />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine yAxisId="left" x={`${Math.round(calculatedTm)}°C`} label={`Tm = ${calculatedTm}°C`} stroke="#ef4444" strokeDasharray="4 4" />
                    <Line yAxisId="left" type="monotone" dataKey="absorbance" name="Hyperchromic Absorbance A260" stroke="#10b981" strokeWidth={2.5} dot={false} />
                    <Line yAxisId="right" type="monotone" dataKey="hybridizationPct" name="Double-Stranded Hybridization %" stroke="#3b82f6" strokeWidth={2} strokeDasharray="3 3" dot={false} />
                  </LineChart>
                ) : (
                  <AreaChart data={respirationData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorResp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                    <XAxis dataKey="substrate" stroke="#94a3b8" fontSize={11} label={{ value: 'Glucose Substrate [S] (mM)', position: 'insideBottom', offset: -5, fontSize: 10 }} />
                    <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'ATP Rate (mol ATP/hr)', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                    <Tooltip />
                    <ReferenceLine y={0} label="Basal Rate" stroke="#64748b" strokeWidth={1} />
                    <Area type="monotone" dataKey="rate" name="ATP Synthesis Rate" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorResp)" />
                  </AreaChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>

          {/* Key Formula & Conceptual Takeaway Banner */}
          <div className="mt-3 p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
            <div className="text-xs">
              <span className="font-bold text-slate-700 dark:text-slate-300">Governing Mathematical Equation: </span>
              <code className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-900 font-mono text-emerald-600 dark:text-emerald-400 font-bold ml-1">
                {activeTab === 'population' && 'dN/dt = rN × ((K - N) / K)'}
                {activeTab === 'enzyme' && (enzymeFactor === 'substrate' ? 'v = (Vmax × [S]) / (Km + [S])' : enzymeFactor === 'temperature' ? 'Arrhenius Equation & Heat Denaturation' : 'Gaussian pH Optima Curve')}
                {activeTab === 'dna' && 'Tm = 69.3 + 0.41(%GC) + 16.6 log10([Na+])'}
                {activeTab === 'respiration' && 'C_6H_12O_6 + 6O_2 → 6CO_2 + 6H_2O + 38 ATP'}
              </code>
            </div>

            <span className="text-[10px] text-slate-400 font-medium">
              Interactive Recharts Visualization Component
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
