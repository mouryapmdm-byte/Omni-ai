import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, 
  Play, 
  Pause, 
  RotateCcw, 
  Sparkles, 
  Sliders, 
  Type, 
  FastForward, 
  Bookmark, 
  Plus, 
  Trash2, 
  Check, 
  ListOrdered, 
  Clock, 
  Wand2, 
  ChevronRight, 
  ChevronDown,
  AlignLeft,
  Volume2
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { generateAIResponse } from '@/src/lib/gemini';

export interface ChapterMarker {
  id: string;
  timestamp: number; // in seconds
  title: string;
  category?: 'shift' | 'formula' | 'slide' | 'summary' | 'general';
}

interface TeleprompterDockProps {
  recordingTimeSeconds?: number;
  isRecording?: boolean;
  onAddChapter?: (marker: ChapterMarker) => void;
  chapters?: ChapterMarker[];
  onSeekToTimestamp?: (seconds: number) => void;
  theme?: 'light' | 'dark';
}

export const TeleprompterDock: React.FC<TeleprompterDockProps> = ({
  recordingTimeSeconds = 0,
  isRecording = false,
  onAddChapter,
  chapters = [],
  onSeekToTimestamp,
  theme = 'dark'
}) => {
  const [activeTab, setActiveTab] = useState<'prompter' | 'outline' | 'chapters'>('prompter');

  // Script & Prompter state
  const [scriptText, setScriptText] = useState<string>(
    "Welcome to today's lesson. Today we will explore fundamental physics principles and calculus concepts.\n\n" +
    "Part 1: Introduction to Motion and Velocity.\n" +
    "Let's review the derivative of position with respect to time v(t) = ds/dt.\n\n" +
    "Part 2: Applying the Fundamental Theorem of Calculus.\n" +
    "Notice how displacement is calculated as the integral of velocity over a time interval.\n\n" +
    "Part 3: Solving Example Problem & Real-world Applications.\n" +
    "Let's step through the problem together and verify our units."
  );

  const [isPrompterPlaying, setIsPrompterPlaying] = useState<boolean>(false);
  const [scrollSpeed, setScrollSpeed] = useState<number>(3); // 1 to 10 scale
  const [fontSize, setFontSize] = useState<number>(18); // 14 to 32 px
  const [topicPrompt, setTopicPrompt] = useState<string>('');
  const [isGeneratingScript, setIsGeneratingScript] = useState<boolean>(false);
  const [newChapterTitle, setNewChapterTitle] = useState<string>('');

  const prompterContainerRef = useRef<HTMLDivElement>(null);
  const prompterIntervalRef = useRef<any>(null);

  // Auto-scroll loop
  useEffect(() => {
    if (isPrompterPlaying) {
      prompterIntervalRef.current = setInterval(() => {
        if (prompterContainerRef.current) {
          prompterContainerRef.current.scrollTop += scrollSpeed * 0.8;
          // Loop back if reached bottom
          if (
            prompterContainerRef.current.scrollTop + prompterContainerRef.current.clientHeight >=
            prompterContainerRef.current.scrollHeight - 5
          ) {
            setIsPrompterPlaying(false);
          }
        }
      }, 50);
    } else {
      if (prompterIntervalRef.current) clearInterval(prompterIntervalRef.current);
    }

    return () => {
      if (prompterIntervalRef.current) clearInterval(prompterIntervalRef.current);
    };
  }, [isPrompterPlaying, scrollSpeed]);

  // Extract outlines/sections from scriptText
  const scriptSections = scriptText
    .split('\n')
    .filter(line => line.trim().length > 0)
    .map((line, idx) => ({
      id: `sec_${idx}`,
      text: line,
      isHeading: line.toLowerCase().includes('part') || line.toLowerCase().includes('chapter') || line.toLowerCase().includes('section') || line.startsWith('#') || line.length < 40
    }));

  const handleGenerateAIScript = async () => {
    if (!topicPrompt.trim()) return;
    setIsGeneratingScript(true);
    try {
      const prompt = `Generate a structured, engaging teleprompter script and outline for a live educational video lesson on the topic: "${topicPrompt}".
Structure the output into clear sections (Part 1, Part 2, Part 3) with clear narration text for an instructor to read aloud clearly. Keep it under 250 words.`;
      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      if (response && response.trim()) {
        setScriptText(response.trim());
      }
    } catch (e) {
      console.error("Failed to generate AI teleprompter script:", e);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleAddLiveChapter = (title?: string) => {
    const chapterName = title || newChapterTitle || `Chapter @ ${formatTime(recordingTimeSeconds)}`;
    if (onAddChapter) {
      onAddChapter({
        id: `chap_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        timestamp: recordingTimeSeconds,
        title: chapterName,
        category: 'shift'
      });
    }
    setNewChapterTitle('');
  };

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '00:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl border shadow-xl overflow-hidden transition-all duration-300",
      theme === 'dark' ? "bg-slate-900/95 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Header Tabs */}
      <div className={cn(
        "px-3 py-2 border-b flex items-center justify-between shrink-0 gap-1",
        theme === 'dark' ? "bg-slate-950/80 border-slate-800" : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-center gap-1 p-0.5 bg-slate-900/60 rounded-xl border border-slate-800/80">
          <button
            type="button"
            onClick={() => setActiveTab('prompter')}
            className={cn(
              "px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition-all cursor-pointer",
              activeTab === 'prompter' ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-slate-200"
            )}
          >
            <AlignLeft size={13} /> Prompter
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('outline')}
            className={cn(
              "px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition-all cursor-pointer",
              activeTab === 'outline' ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-slate-200"
            )}
          >
            <ListOrdered size={13} /> Outline
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('chapters')}
            className={cn(
              "px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition-all cursor-pointer relative",
              activeTab === 'chapters' ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-slate-200"
            )}
          >
            <Bookmark size={13} /> Chapters ({chapters.length})
          </button>
        </div>

        {isRecording && (
          <button
            type="button"
            onClick={() => handleAddLiveChapter()}
            className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center gap-1 shadow-md transition-all active:scale-95 cursor-pointer"
          >
            <Plus size={12} /> Drop Chapter
          </button>
        )}
      </div>

      {/* Main Dock Body */}
      <div className="flex-1 overflow-hidden p-3 flex flex-col relative">
        {/* Tab 1: Smart Teleprompter */}
        {activeTab === 'prompter' && (
          <div className="flex-1 flex flex-col h-full space-y-3">
            {/* Prompter Controls Bar */}
            <div className="flex items-center justify-between gap-2 p-2 bg-slate-950/60 rounded-xl border border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPrompterPlaying(!isPrompterPlaying)}
                  className={cn(
                    "p-1.5 rounded-lg font-bold text-white transition-all active:scale-95 cursor-pointer flex items-center gap-1",
                    isPrompterPlaying ? "bg-amber-600 hover:bg-amber-500" : "bg-emerald-600 hover:bg-emerald-500"
                  )}
                  title={isPrompterPlaying ? "Pause Auto-scroll" : "Start Auto-scroll"}
                >
                  {isPrompterPlaying ? <Pause size={14} /> : <Play size={14} className="fill-current" />}
                  <span>{isPrompterPlaying ? "Pause" : "Scroll"}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (prompterContainerRef.current) prompterContainerRef.current.scrollTop = 0;
                  }}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg cursor-pointer"
                  title="Reset to Top"
                >
                  <RotateCcw size={14} />
                </button>
              </div>

              {/* Speed & Font sliders */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400">
                  <FastForward size={12} />
                  <span>Speed {scrollSpeed}x</span>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={scrollSpeed}
                    onChange={(e) => setScrollSpeed(Number(e.target.value))}
                    className="w-14 accent-indigo-500 cursor-pointer"
                  />
                </div>

                <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400">
                  <Type size={12} />
                  <input
                    type="range"
                    min="14"
                    max="30"
                    value={fontSize}
                    onChange={(e) => setFontSize(Number(e.target.value))}
                    className="w-14 accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Prompter Scrolling Container */}
            <div
              ref={prompterContainerRef}
              className="flex-1 overflow-y-auto p-4 bg-slate-950/90 rounded-xl border border-slate-800 text-slate-100 font-medium leading-relaxed shadow-inner select-none space-y-4 scroll-smooth"
              style={{ fontSize: `${fontSize}px` }}
            >
              {scriptText.split('\n').map((paragraph, idx) => (
                <p key={idx} className={cn(
                  paragraph.toLowerCase().startsWith('part') ? "text-indigo-400 font-bold border-b border-indigo-500/20 pb-1" : ""
                )}>
                  {paragraph}
                </p>
              ))}
            </div>

            {/* AI Prompt Generator */}
            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                placeholder="Enter topic to generate AI teleprompter script..."
                value={topicPrompt}
                onChange={(e) => setTopicPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleGenerateAIScript()}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="button"
                onClick={handleGenerateAIScript}
                disabled={isGeneratingScript || !topicPrompt.trim()}
                className="px-3 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md disabled:opacity-50 cursor-pointer"
              >
                {isGeneratingScript ? <Wand2 size={13} className="animate-spin" /> : <Sparkles size={13} />}
                <span>AI Script</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Interactive Outline Dock */}
        {activeTab === 'outline' && (
          <div className="flex-1 flex flex-col h-full space-y-3 overflow-y-auto pr-1">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Structured Lesson Outline</span>
              <span className="text-[10px] text-indigo-400">Click section to timestamp chapter</span>
            </div>

            <div className="space-y-2">
              {scriptSections.map((sec, idx) => (
                <div
                  key={sec.id}
                  onClick={() => {
                    if (isRecording) {
                      handleAddLiveChapter(sec.text.slice(0, 40));
                    }
                  }}
                  className={cn(
                    "p-3 rounded-xl border transition-all cursor-pointer flex items-start justify-between group",
                    sec.isHeading
                      ? "bg-indigo-950/40 border-indigo-500/30 text-indigo-200 hover:bg-indigo-900/50"
                      : "bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-850"
                  )}
                >
                  <div className="space-y-1 pr-2">
                    <span className="text-[10px] font-mono text-indigo-400 font-bold">Section {idx + 1}</span>
                    <p className="text-xs font-semibold leading-snug">{sec.text}</p>
                  </div>

                  {isRecording && (
                    <button
                      type="button"
                      className="p-1.5 bg-rose-600/20 text-rose-400 border border-rose-500/30 rounded-lg text-[10px] font-bold opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                    >
                      + Chapter
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Dynamic Chapters List */}
        {activeTab === 'chapters' && (
          <div className="flex-1 flex flex-col h-full space-y-3 overflow-y-auto pr-1">
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="New chapter title..."
                value={newChapterTitle}
                onChange={(e) => setNewChapterTitle(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddLiveChapter()}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="button"
                onClick={() => handleAddLiveChapter()}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-md cursor-pointer"
              >
                <Plus size={13} /> Add
              </button>
            </div>

            {chapters.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center text-slate-500 space-y-2 p-6">
                <Bookmark size={32} className="text-slate-700" />
                <p className="text-xs font-medium">No chapters dropped yet.</p>
                <p className="text-[10px]">Chapters added during recording or playback will appear here with clickable timeline timestamps.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {chapters.map((chap) => (
                  <div
                    key={chap.id}
                    onClick={() => onSeekToTimestamp?.(chap.timestamp)}
                    className="p-2.5 bg-slate-950/80 border border-slate-800 hover:border-indigo-500/50 rounded-xl flex items-center justify-between text-xs transition-all cursor-pointer group"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-mono text-[10px] font-bold rounded-md border border-indigo-500/30 flex items-center gap-1">
                        <Clock size={10} />
                        {formatTime(chap.timestamp)}
                      </span>
                      <span className="font-bold text-slate-200">{chap.title}</span>
                    </div>

                    <ChevronRight size={14} className="text-slate-500 group-hover:text-indigo-400 group-hover:translate-x-0.5 transition-all" />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
