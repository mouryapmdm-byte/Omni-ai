const fs = require('fs');
const file = 'src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

const targetStr = `const systemInstruction = \`You are Omni AI, a universal education system. \${skillPrompt}`;

if (content.includes(targetStr)) {
  console.log("Found systemInstruction");
}
