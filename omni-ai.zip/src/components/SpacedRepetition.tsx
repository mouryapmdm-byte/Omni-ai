import React, { useState, useEffect } from 'react';
import { 
  Plus, Trash2, Brain, Sparkles, CheckCircle, 
  RotateCcw, BookOpen, AlertCircle, BarChart3, 
  Layers, Download, Upload, Eye, Check, RefreshCw
} from 'lucide-react';
import { generateAIResponse } from '../lib/gemini';
import { cn } from '../lib/utils';

interface Flashcard {
  id: string;
  front: string;
  back: string;
  subject: string;
  topic: string;
  interval: number; // days
  repetitions: number;
  easeFactor: number;
  nextReviewDate: string; // ISO string
}

interface SpacedRepetitionProps {
  subject: string;
  topic: string;
  theme?: 'light' | 'dark';
  showNotification: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

const DEFAULT_CARDS: Flashcard[] = [
  {
    id: '1',
    front: 'What is the fundamental theorem of Calculus?',
    back: 'It establishes a connection between differentiation and integration, stating that differentiation and integration are inverse operations. If f is continuous on [a, b], then the integral of f from a to b equals F(b) - F(a) where F\' = f.',
    subject: 'mathematics',
    topic: 'calculus',
    interval: 1,
    repetitions: 1,
    easeFactor: 2.5,
    nextReviewDate: new Date().toISOString()
  },
  {
    id: '2',
    front: 'What is Euler\'s Identity?',
    back: 'e^(i * pi) + 1 = 0. It is considered the most beautiful mathematical formula because it links five fundamental constants: e, i, pi, 1, and 0 using basic arithmetic operations.',
    subject: 'mathematics',
    topic: 'algebra',
    interval: 1,
    repetitions: 1,
    easeFactor: 2.5,
    nextReviewDate: new Date().toISOString()
  },
  {
    id: '3',
    front: 'Define Newton\'s Second Law of Motion.',
    back: 'The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass: F = m * a.',
    subject: 'physics',
    topic: 'mechanics',
    interval: 1,
    repetitions: 1,
    easeFactor: 2.5,
    nextReviewDate: new Date().toISOString()
  }
];

export const SpacedRepetition: React.FC<SpacedRepetitionProps> = ({
  subject,
  topic,
  theme = 'light',
  showNotification
}) => {
  const [cards, setCards] = useState<Flashcard[]>([]);
  const [activeTab, setActiveTab] = useState<'study' | 'manage' | 'analytics'>('study');
  
  // Study session state
  const [studyQueue, setStudyQueue] = useState<Flashcard[]>([]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [studyMode, setStudyMode] = useState<'due' | 'all'>('due');
  
  // Manual card creation form
  const [newFront, setNewFront] = useState('');
  const [newBack, setNewBack] = useState('');
  const [newSubject, setNewSubject] = useState(subject || 'mathematics');
  const [newTopic, setNewTopic] = useState(topic || 'general');
  
  // AI generation state
  const [isGenerating, setIsGenerating] = useState(false);

  // Load from local storage
  useEffect(() => {
    const stored = localStorage.getItem('omni_spaced_repetition');
    if (stored) {
      try {
        setCards(JSON.parse(stored));
      } catch (e) {
        setCards(DEFAULT_CARDS);
      }
    } else {
      setCards(DEFAULT_CARDS);
      localStorage.setItem('omni_spaced_repetition', JSON.stringify(DEFAULT_CARDS));
    }
  }, []);

  // Sync to local storage
  const saveCards = (updatedCards: Flashcard[]) => {
    setCards(updatedCards);
    localStorage.setItem('omni_spaced_repetition', JSON.stringify(updatedCards));
  };

  // Build Study Queue
  useEffect(() => {
    const now = new Date();
    const due = cards.filter(card => {
      if (studyMode === 'all') return true;
      return new Date(card.nextReviewDate) <= now;
    });
    
    // Sort so older/more urgent ones come first
    due.sort((a, b) => new Date(a.nextReviewDate).getTime() - new Date(b.nextReviewDate).getTime());
    
    setStudyQueue(due);
    setCurrentCardIndex(0);
    setIsFlipped(false);
  }, [cards, studyMode]);

  // SM-2 Adaptive Algorithm Implementation
  const handleScoreCard = (score: number) => {
    if (studyQueue.length === 0) return;
    const card = studyQueue[currentCardIndex];
    
    let nextInterval = 1;
    let nextRepetitions = card.repetitions;
    let nextEaseFactor = card.easeFactor;

    if (score >= 3) {
      // Correct answer
      if (card.repetitions === 0) {
        nextInterval = 1;
      } else if (card.repetitions === 1) {
        nextInterval = 6;
      } else {
        nextInterval = Math.round(card.interval * card.easeFactor);
      }
      nextRepetitions = card.repetitions + 1;
    } else {
      // Incorrect answer, reset interval
      nextInterval = 1;
      nextRepetitions = 0;
    }

    // Ease factor adjustment formula
    nextEaseFactor = card.easeFactor + (0.1 - (5 - score) * (0.08 + (5 - score) * 0.02));
    if (nextEaseFactor < 1.3) nextEaseFactor = 1.3;

    // Schedule next review date
    const nextReview = new Date();
    nextReview.setDate(nextReview.getDate() + nextInterval);

    // Update state
    const updatedCards = cards.map(c => {
      if (c.id === card.id) {
        return {
          ...c,
          interval: nextInterval,
          repetitions: nextRepetitions,
          easeFactor: parseFloat(nextEaseFactor.toFixed(2)),
          nextReviewDate: nextReview.toISOString()
        };
      }
      return c;
    });

    saveCards(updatedCards);
    showNotification(`Card rescheduled! Next review in ${nextInterval} day(s).`, 'success');

    // Move to next card
    if (currentCardIndex < studyQueue.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
      setIsFlipped(false);
    } else {
      // Finished all cards in queue
      setStudyQueue([]);
      showNotification('Congratulations! You completed all cards in this study run.', 'success');
    }
  };

  // Add Card Manually
  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFront.trim() || !newBack.trim()) {
      showNotification('Please fill in both Front and Back.', 'error');
      return;
    }

    const card: Flashcard = {
      id: Date.now().toString(),
      front: newFront.trim(),
      back: newBack.trim(),
      subject: newSubject,
      topic: newTopic,
      interval: 1,
      repetitions: 0,
      easeFactor: 2.5,
      nextReviewDate: new Date().toISOString()
    };

    const updated = [card, ...cards];
    saveCards(updated);
    
    setNewFront('');
    setNewBack('');
    showNotification('New flashcard added successfully!', 'success');
  };

  // Delete Card
  const handleDeleteCard = (id: string) => {
    const updated = cards.filter(c => c.id !== id);
    saveCards(updated);
    showNotification('Flashcard deleted.', 'info');
  };

  // AI Card Generator
  const handleAIGenerate = async () => {
    setIsGenerating(true);
    showNotification(`Analyzing syllabus for ${topic || 'current lessons'} to generate cards...`, 'info');
    
    try {
      const prompt = `Generate 5 academic study flashcards for the topic "${topic || 'General study topics'}" in the subject of "${subject || 'general science/math'}".
      Return a JSON array of objects matching this schema exactly, with NO markdown formatting, no backticks, or enclosing wrapping other than standard JSON:
      [
        {
          "front": "The clear question, formula, or definition prompt (high quality and academic)",
          "back": "The comprehensive explanation, proof, or standard solution (rigorous and helpful)"
        }
      ]
      Generate high-quality questions.`;

      const responseText = await generateAIResponse(prompt, {
        responseMimeType: 'application/json'
      });

      let parsed: { front: string; back: string }[] = [];
      if (responseText) {
        // Clean markdown backticks if returned in worst case
        const cleanJson = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
        parsed = JSON.parse(cleanJson);
      }

      if (Array.isArray(parsed) && parsed.length > 0) {
        const newFlashcards: Flashcard[] = parsed.map((item, index) => ({
          id: `ai_${Date.now()}_${index}`,
          front: item.front,
          back: item.back,
          subject: subject || 'general',
          topic: topic || 'general',
          interval: 1,
          repetitions: 0,
          easeFactor: 2.5,
          nextReviewDate: new Date().toISOString()
        }));

        saveCards([...newFlashcards, ...cards]);
        showNotification(`AI successfully generated ${newFlashcards.length} adaptive flashcards!`, 'success');
      } else {
        throw new Error("Invalid format returned from model");
      }
    } catch (err) {
      console.error(err);
      showNotification('AI Generation failed. Adding helpful mock syllabus cards instead.', 'warning');
      
      // Fallback fallback cards to guarantee high quality experience
      const fallback: Flashcard[] = [
        {
          id: `fallback_${Date.now()}_1`,
          front: `Define Core concept in ${topic || 'current chapter'}`,
          back: `The fundamental principles of ${topic || 'this subject'} include definitions, experimental methods, and structural equations standard for ${subject}.`,
          subject: subject || 'general',
          topic: topic || 'general',
          interval: 1,
          repetitions: 0,
          easeFactor: 2.5,
          nextReviewDate: new Date().toISOString()
        }
      ];
      saveCards([...fallback, ...cards]);
    } finally {
      setIsGenerating(false);
    }
  };

  // Export to JSON
  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(cards, null, 2));
    const dlAnchorElem = document.createElement('a');
    dlAnchorElem.setAttribute("href",     dataStr     );
    dlAnchorElem.setAttribute("download", `spaced_repetition_deck_${subject || 'all'}.json`);
    dlAnchorElem.click();
    showNotification('Flashcard deck exported successfully.', 'success');
  };

  // Analytics helper variables
  const now = new Date();
  const dueCount = cards.filter(c => new Date(c.nextReviewDate) <= now).length;
  const learningCount = cards.filter(c => c.repetitions <= 2).length;
  const reviewCount = cards.filter(c => c.repetitions > 2 && c.repetitions <= 6).length;
  const masteredCount = cards.filter(c => c.repetitions > 6).length;

  return (
    <div className={cn(
      "w-full rounded-2xl border flex flex-col overflow-hidden shadow-sm h-[580px]",
      theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
    )}>
      {/* Tab Headers */}
      <div className={cn(
        "border-b px-6 py-4 flex flex-wrap items-center justify-between gap-4",
        theme === 'dark' ? "border-slate-800 bg-slate-900/60" : "border-slate-200 bg-slate-50/60"
      )}>
        <div className="flex items-center gap-2">
          <Layers className="text-indigo-500" size={20} />
          <h3 className="font-bold text-sm tracking-wide uppercase text-slate-700 dark:text-slate-200">
            Adaptive Spaced Repetition (SM-2)
          </h3>
        </div>
        <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl gap-1">
          <button
            onClick={() => setActiveTab('study')}
            className={cn(
              "px-4 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5",
              activeTab === 'study'
                ? "bg-white dark:bg-slate-750 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
            )}
          >
            <BookOpen size={14} /> Study
          </button>
          <button
            onClick={() => setActiveTab('manage')}
            className={cn(
              "px-4 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5",
              activeTab === 'manage'
                ? "bg-white dark:bg-slate-750 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
            )}
          >
            <Plus size={14} /> Manage Deck ({cards.length})
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={cn(
              "px-4 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5",
              activeTab === 'analytics'
                ? "bg-white dark:bg-slate-750 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
            )}
          >
            <BarChart3 size={14} /> Analytics
          </button>
        </div>
      </div>

      {/* Main Panel Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {activeTab === 'study' && (
          <div className="h-full flex flex-col justify-between space-y-6">
            <div className="flex justify-between items-center bg-indigo-50 dark:bg-indigo-950/20 p-3 rounded-xl">
              <div className="flex items-center gap-2">
                <Brain className="text-indigo-500 animate-pulse" size={16} />
                <span className="text-xs font-bold text-indigo-800 dark:text-indigo-300">
                  Topic: <span className="capitalize">{topic || 'All Topics'}</span> ({subject})
                </span>
              </div>
              <div className="flex items-center gap-2 bg-white dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-indigo-150 shadow-xs">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest cursor-pointer">
                  Study Run:
                </label>
                <select
                  value={studyMode}
                  onChange={(e) => setStudyMode(e.target.value as 'due' | 'all')}
                  className="text-xs font-extrabold text-indigo-600 bg-transparent outline-none border-none p-0 cursor-pointer"
                >
                  <option value="due">Due Cards ({cards.filter(c => new Date(c.nextReviewDate) <= now).length})</option>
                  <option value="all">All Cards ({cards.length})</option>
                </select>
              </div>
            </div>

            {studyQueue.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl bg-slate-50/50 dark:bg-slate-900/30">
                <div className="w-16 h-16 bg-green-50 dark:bg-green-950/30 text-green-500 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle size={32} />
                </div>
                <h4 className="font-extrabold text-slate-800 dark:text-slate-100 mb-1 text-base">You are completely caught up!</h4>
                <p className="text-xs text-slate-400 dark:text-slate-500 max-w-sm leading-relaxed mb-6">
                  {studyMode === 'due' 
                    ? "No flashcards are due for review. Switch to 'All Cards' above or use the AI Generator to expand your knowledge base!"
                    : "Your active deck is empty. Create some cards or generate them with AI!"}
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={handleAIGenerate}
                    disabled={isGenerating}
                    className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full text-xs font-bold shadow-lg shadow-indigo-200 dark:shadow-none flex items-center gap-2 transition-all disabled:opacity-50"
                  >
                    <Sparkles size={14} className={isGenerating ? 'animate-spin' : ''} />
                    {isGenerating ? 'Generating...' : 'AI Generate Decks'}
                  </button>
                  <button
                    onClick={() => setStudyMode('all')}
                    className="px-5 py-2.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full text-xs font-bold hover:bg-slate-350 transition-all"
                  >
                    Study All Cards
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col justify-between">
                {/* Progress bar */}
                <div className="flex items-center gap-4 text-xs font-extrabold text-slate-400 mb-2">
                  <div className="flex-1 bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-indigo-500 h-full transition-all duration-300"
                      style={{ width: `${((currentCardIndex) / studyQueue.length) * 100}%` }}
                    />
                  </div>
                  <span>{currentCardIndex + 1} / {studyQueue.length}</span>
                </div>

                {/* Interactive Flippable Card Frame */}
                <div 
                  onClick={() => setIsFlipped(!isFlipped)}
                  className={cn(
                    "flex-1 min-h-[220px] rounded-3xl border-2 p-8 flex flex-col justify-between cursor-pointer transition-all duration-500 relative select-none transform hover:-translate-y-1 shadow-md hover:shadow-lg",
                    isFlipped 
                      ? "bg-slate-50 dark:bg-slate-850/60 border-indigo-200 dark:border-indigo-900" 
                      : "bg-white dark:bg-slate-800 border-slate-150 dark:border-slate-700"
                  )}
                >
                  <div className="flex justify-between items-start text-[10px] font-black uppercase tracking-widest text-slate-400">
                    <span>{studyQueue[currentCardIndex].subject} / {studyQueue[currentCardIndex].topic}</span>
                    <span className="bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 px-2 py-0.5 rounded-md">
                      {isFlipped ? "Answer Side" : "Question Side"}
                    </span>
                  </div>

                  <div className="text-center py-6 flex items-center justify-center flex-1">
                    <p className={cn(
                      "text-base md:text-lg font-bold text-slate-800 dark:text-slate-100 leading-relaxed max-w-xl transition-all",
                      isFlipped ? "font-normal" : "font-extrabold"
                    )}>
                      {isFlipped ? studyQueue[currentCardIndex].back : studyQueue[currentCardIndex].front}
                    </p>
                  </div>

                  <div className="text-center text-[10px] text-slate-400 font-extrabold italic">
                    {isFlipped ? "Click anywhere to see question" : "Click anywhere to flip and reveal answer"}
                  </div>
                </div>

                {/* Actions Panel */}
                <div className="mt-6 flex flex-col items-center space-y-3">
                  {!isFlipped ? (
                    <button
                      onClick={() => setIsFlipped(true)}
                      className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-xs font-bold transition-all shadow-md shadow-indigo-200 dark:shadow-none uppercase tracking-wider flex items-center justify-center gap-2"
                    >
                      <Eye size={16} /> Flip Card
                    </button>
                  ) : (
                    <div className="w-full grid grid-cols-4 gap-2">
                      <button
                        onClick={() => handleScoreCard(1)}
                        className="py-3 bg-red-100 hover:bg-red-200 text-red-700 rounded-xl text-xs font-bold transition-all flex flex-col items-center justify-center"
                      >
                        <span className="font-extrabold">Again</span>
                        <span className="text-[9px] opacity-65 font-normal">Forgot (1d)</span>
                      </button>
                      <button
                        onClick={() => handleScoreCard(3)}
                        className="py-3 bg-amber-100 hover:bg-amber-200 text-amber-700 rounded-xl text-xs font-bold transition-all flex flex-col items-center justify-center"
                      >
                        <span className="font-extrabold">Hard</span>
                        <span className="text-[9px] opacity-65 font-normal">Slightly (1d)</span>
                      </button>
                      <button
                        onClick={() => handleScoreCard(4)}
                        className="py-3 bg-green-100 hover:bg-green-200 text-green-700 rounded-xl text-xs font-bold transition-all flex flex-col items-center justify-center"
                      >
                        <span className="font-extrabold">Good</span>
                        <span className="text-[9px] opacity-65 font-normal">Recalled (3d)</span>
                      </button>
                      <button
                        onClick={() => handleScoreCard(5)}
                        className="py-3 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-xl text-xs font-bold transition-all flex flex-col items-center justify-center"
                      >
                        <span className="font-extrabold">Easy</span>
                        <span className="text-[9px] opacity-65 font-normal">Perfect (6d+)</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'manage' && (
          <div className="space-y-6">
            {/* Quick Generator + Manual Add Box */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Form Add */}
              <form onSubmit={handleAddCard} className="space-y-4 p-5 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-750 rounded-2xl">
                <h4 className="font-extrabold text-slate-800 dark:text-slate-200 text-xs uppercase tracking-widest">
                  Create Custom Flashcard
                </h4>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Front Question</label>
                  <textarea
                    rows={2}
                    value={newFront}
                    onChange={(e) => setNewFront(e.target.value)}
                    placeholder="e.g. What is the derivative of sin(x)?"
                    className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-500 uppercase">Back Answer</label>
                  <textarea
                    rows={2}
                    value={newBack}
                    onChange={(e) => setNewBack(e.target.value)}
                    placeholder="e.g. The derivative is cos(x)."
                    className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Subject</label>
                    <input
                      type="text"
                      value={newSubject}
                      onChange={(e) => setNewSubject(e.target.value.toLowerCase())}
                      className="w-full p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Topic</label>
                    <input
                      type="text"
                      value={newTopic}
                      onChange={(e) => setNewTopic(e.target.value.toLowerCase())}
                      className="w-full p-2 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full py-2 bg-slate-850 hover:bg-slate-900 dark:bg-indigo-650 dark:hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                >
                  <Plus size={14} /> Add Card
                </button>
              </form>

              {/* AI Auto generator control */}
              <div className="p-5 border-2 border-dashed border-indigo-100 dark:border-indigo-900/40 rounded-2xl flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
                    <Sparkles size={18} />
                    <h4 className="font-black text-xs uppercase tracking-widest">
                      AI Active Curriculum Generator
                    </h4>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    Automatically generate highly customizable adaptive spaced repetition flashcards optimized specifically for your currently active syllabus topic: 
                    <strong className="text-indigo-600 dark:text-indigo-400 capitalize bg-indigo-50 dark:bg-indigo-950/20 px-1.5 py-0.5 rounded-md ml-1 inline-block">
                      {topic || 'All Chapters'}
                    </strong>.
                  </p>
                </div>
                <div className="space-y-3">
                  <button
                    onClick={handleAIGenerate}
                    disabled={isGenerating}
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-150 dark:shadow-none flex items-center justify-center gap-2 transition-all"
                  >
                    <Sparkles className={cn("w-4 h-4", isGenerating && "animate-spin")} />
                    {isGenerating ? "Synthesizing Deck..." : `Generate cards for ${topic || 'current'}`}
                  </button>
                  <div className="flex gap-2">
                    <button
                      onClick={handleExport}
                      className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                    >
                      <Download size={13} /> Export
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* List Of Current Deck Cards */}
            <div className="space-y-3 mt-4">
              <h4 className="font-extrabold text-slate-700 dark:text-slate-300 text-xs uppercase tracking-widest">
                Flashcard Ledger ({cards.length} cards)
              </h4>
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-2">
                {cards.map((card) => (
                  <div 
                    key={card.id}
                    className="p-3.5 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800 flex justify-between items-center text-xs group"
                  >
                    <div className="space-y-1 flex-1 pr-4">
                      <div className="font-bold text-slate-800 dark:text-slate-200 truncate">
                        {card.front}
                      </div>
                      <div className="text-[10px] text-slate-400 dark:text-slate-500 flex items-center gap-2.5 flex-wrap">
                        <span className="bg-indigo-50 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 px-1.5 py-0.5 rounded-md font-bold text-[9px] uppercase">
                          {card.subject}
                        </span>
                        <span>Interval: {card.interval}d</span>
                        <span>Ease: {card.easeFactor}</span>
                        <span>Next review: {new Date(card.nextReviewDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteCard(card.id)}
                      className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 opacity-60 group-hover:opacity-100 transition-opacity"
                      title="Delete card"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-6">
            {/* Box Stats Overview */}
            <div className="grid grid-cols-4 gap-4">
              <div className="p-4 bg-indigo-50 dark:bg-indigo-950/20 rounded-2xl border border-indigo-100 dark:border-indigo-900/30 text-center">
                <div className="text-xl font-black text-indigo-600 dark:text-indigo-400">{dueCount}</div>
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide mt-1">Due Today</div>
              </div>
              <div className="p-4 bg-red-50 dark:bg-red-950/20 rounded-2xl border border-red-100 dark:border-red-900/30 text-center">
                <div className="text-xl font-black text-red-600 dark:text-red-400">{learningCount}</div>
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide mt-1">Learning</div>
              </div>
              <div className="p-4 bg-amber-50 dark:bg-amber-950/20 rounded-2xl border border-amber-100 dark:border-amber-900/30 text-center">
                <div className="text-xl font-black text-amber-600 dark:text-amber-400">{reviewCount}</div>
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide mt-1">In Review</div>
              </div>
              <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-2xl border border-green-100 dark:border-green-900/30 text-center">
                <div className="text-xl font-black text-green-600 dark:text-green-400">{masteredCount}</div>
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide mt-1">Mastered</div>
              </div>
            </div>

            {/* Leitner Box counts visual bar */}
            <div className="p-5 bg-slate-50 dark:bg-slate-800/40 border border-slate-150 dark:border-slate-750 rounded-2xl space-y-4">
              <h4 className="font-extrabold text-slate-700 dark:text-slate-300 text-xs uppercase tracking-widest">
                Leitner Box System Retention Distribution
              </h4>
              <div className="h-6 bg-slate-150 dark:bg-slate-800 rounded-full flex overflow-hidden">
                <div 
                  className="bg-red-500 h-full flex items-center justify-center text-[10px] text-white font-extrabold"
                  style={{ width: `${(learningCount / (cards.length || 1)) * 100}%` }}
                  title="Box 1 (Learning)"
                >
                  {learningCount > 0 && `${Math.round((learningCount / cards.length) * 100)}%`}
                </div>
                <div 
                  className="bg-amber-500 h-full flex items-center justify-center text-[10px] text-white font-extrabold"
                  style={{ width: `${(reviewCount / (cards.length || 1)) * 100}%` }}
                  title="Box 2 (In Review)"
                >
                  {reviewCount > 0 && `${Math.round((reviewCount / cards.length) * 100)}%`}
                </div>
                <div 
                  className="bg-green-500 h-full flex items-center justify-center text-[10px] text-white font-extrabold"
                  style={{ width: `${(masteredCount / (cards.length || 1)) * 100}%` }}
                  title="Box 3 (Mastered)"
                >
                  {masteredCount > 0 && `${Math.round((masteredCount / cards.length) * 100)}%`}
                </div>
              </div>
              <p className="text-[11px] text-slate-450 dark:text-slate-500 leading-normal">
                The Leitner spaced repetition system schedules intervals based on correct answers. Mastered cards (high repetitions) appear less frequently to allow cognitive assimilation into long-term crystalline memory.
              </p>
            </div>

            {/* Retention advice */}
            <div className="p-4 bg-indigo-50/50 dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 rounded-xl flex items-start gap-3">
              <AlertCircle className="text-indigo-500 shrink-0" size={16} />
              <div className="space-y-1">
                <h5 className="font-extrabold text-xs text-indigo-900 dark:text-indigo-300">Cognitive Retention Tip</h5>
                <p className="text-[11px] text-indigo-750 dark:text-slate-400 leading-relaxed">
                  For optimal adaptive SM-2 efficiency, review cards first thing every morning. Your neuroplasticity peaks immediately after sleep cycles, allowing faster visual-verbal integration of complex formulas.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
