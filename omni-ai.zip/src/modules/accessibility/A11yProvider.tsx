import React, { useState, useEffect, useCallback } from 'react';
import { AccessibilityPreferences, LiveAnnouncement } from './types';
import { A11yContext, A11yContextValue } from './useA11y';

const STORAGE_KEY_A11Y = 'omni_a11y_preferences_v2';

const DEFAULT_PREFERENCES: AccessibilityPreferences = {
  studentId: 'student_alex',
  highContrast: false,
  contrastRatio: 'AA',
  dyslexiaFont: false,
  dyslexiaTheme: 'default',
  fontScale: 1.0,
  letterSpacing: 'normal',
  lineSpacing: 'normal',
  reducedMotion: false,
  screenReader: true,
  captionsEnabled: true,
  audioDescriptions: true,
  mathMLMode: true,
  keyboardNavigationHints: true,
  updatedAt: new Date().toISOString()
};

export const A11yProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [preferences, setPreferences] = useState<AccessibilityPreferences>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_A11Y);
      if (stored) {
        return { ...DEFAULT_PREFERENCES, ...JSON.parse(stored) };
      }
    } catch (e) {
      // ignore
    }
    return DEFAULT_PREFERENCES;
  });

  const [liveAnnouncement, setLiveAnnouncement] = useState<LiveAnnouncement | null>(null);

  // Announce live message to assistive technologies
  const announce = useCallback((message: string, priority: 'polite' | 'assertive' = 'polite') => {
    const ann: LiveAnnouncement = {
      id: 'ann_' + Date.now(),
      message,
      priority,
      timestamp: Date.now()
    };
    setLiveAnnouncement(ann);
  }, []);

  const updatePreferences = useCallback((partial: Partial<AccessibilityPreferences>) => {
    setPreferences(prev => {
      const updated = {
        ...prev,
        ...partial,
        updatedAt: new Date().toISOString()
      };
      try {
        localStorage.setItem(STORAGE_KEY_A11Y, JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to persist a11y preferences', e);
      }
      return updated;
    });
  }, []);

  const resetPreferences = useCallback(() => {
    setPreferences(DEFAULT_PREFERENCES);
    try {
      localStorage.setItem(STORAGE_KEY_A11Y, JSON.stringify(DEFAULT_PREFERENCES));
    } catch (e) {
      // ignore
    }
    announce('Accessibility settings reset to default', 'polite');
  }, [announce]);

  const toggleHighContrast = useCallback(() => {
    updatePreferences({ highContrast: !preferences.highContrast });
    announce(preferences.highContrast ? 'Standard contrast restored' : 'High contrast mode enabled', 'polite');
  }, [preferences.highContrast, updatePreferences, announce]);

  const toggleDyslexiaFont = useCallback(() => {
    updatePreferences({ dyslexiaFont: !preferences.dyslexiaFont });
    announce(preferences.dyslexiaFont ? 'Standard font restored' : 'Dyslexia-friendly font enabled', 'polite');
  }, [preferences.dyslexiaFont, updatePreferences, announce]);

  const setFontScale = useCallback((scale: number) => {
    const clamped = Math.min(2.0, Math.max(0.8, scale));
    updatePreferences({ fontScale: clamped });
    announce(`Font zoom adjusted to ${Math.round(clamped * 100)} percent`, 'polite');
  }, [updatePreferences, announce]);

  const toggleReducedMotion = useCallback(() => {
    updatePreferences({ reducedMotion: !preferences.reducedMotion });
    announce(preferences.reducedMotion ? 'Standard motion enabled' : 'Reduced motion mode active', 'polite');
  }, [preferences.reducedMotion, updatePreferences, announce]);

  // Synchronize CSS variables and root classes with document
  useEffect(() => {
    const root = document.documentElement;

    // 1. Font scaling
    root.style.setProperty('--a11y-font-scale', `${preferences.fontScale}`);

    // 2. Letter spacing & line spacing
    if (preferences.letterSpacing === 'wide') {
      root.style.setProperty('--a11y-letter-spacing', '0.08em');
    } else if (preferences.letterSpacing === 'wider') {
      root.style.setProperty('--a11y-letter-spacing', '0.14em');
    } else {
      root.style.removeProperty('--a11y-letter-spacing');
    }

    if (preferences.lineSpacing === 'relaxed') {
      root.style.setProperty('--a11y-line-height', '1.75');
    } else if (preferences.lineSpacing === 'loose') {
      root.style.setProperty('--a11y-line-height', '2.1');
    } else {
      root.style.removeProperty('--a11y-line-height');
    }

    // 3. Classes
    if (preferences.dyslexiaFont) {
      root.classList.add('a11y-dyslexia-font');
    } else {
      root.classList.remove('a11y-dyslexia-font');
    }

    if (preferences.highContrast) {
      root.classList.add('a11y-high-contrast');
    } else {
      root.classList.remove('a11y-high-contrast');
    }

    if (preferences.reducedMotion) {
      root.classList.add('a11y-reduced-motion');
    } else {
      root.classList.remove('a11y-reduced-motion');
    }

    if (preferences.dyslexiaTheme === 'cream') {
      root.classList.add('a11y-cream-bg');
    } else {
      root.classList.remove('a11y-cream-bg');
    }
  }, [preferences]);

  const contextValue: A11yContextValue = {
    preferences,
    updatePreferences,
    resetPreferences,
    announce,
    liveAnnouncement,
    toggleHighContrast,
    toggleDyslexiaFont,
    setFontScale,
    toggleReducedMotion
  };

  return (
    <A11yContext.Provider value={contextValue}>
      {/* Accessible Skip to Content Link */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[9999] focus:px-4 focus:py-2.5 focus:bg-amber-400 focus:text-slate-950 focus:font-bold focus:rounded-xl focus:shadow-2xl focus:ring-4 focus:ring-amber-500 transition"
      >
        Skip to main content (Press Enter)
      </a>

      {/* Screen Reader Off-Screen Live Announcement Regions */}
      <div
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
        id="a11y-polite-announcer"
      >
        {liveAnnouncement?.priority === 'polite' ? liveAnnouncement.message : ''}
      </div>

      <div
        aria-live="assertive"
        aria-atomic="true"
        className="sr-only"
        id="a11y-assertive-announcer"
      >
        {liveAnnouncement?.priority === 'assertive' ? liveAnnouncement.message : ''}
      </div>

      {children}
    </A11yContext.Provider>
  );
};
