import React, { useState, useMemo, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  Sparkles, 
  Check, 
  X, 
  ChevronRight, 
  ChevronDown,
  ChevronUp,
  GraduationCap, 
  Globe, 
  Layers, 
  Atom, 
  Dna, 
  Orbit, 
  Cpu, 
  Compass,
  Award,
  BookMarked,
  Loader2,
  ListTree,
  FileText,
  Bookmark,
  Sliders
} from 'lucide-react';
import { getBoardCurriculum, EDUCATION_BOARDS, getDetailedBoardCurriculum, EducationBoard } from '../data/boards';
import { CONFIG } from '../lib/constants';
import { CurriculumSelection } from '../types';
import { TEACHER_PEDAGOGY_STYLES, TeacherPedagogyStyle } from '../data/teacherStyles';

export interface TopicSelectorProps {
  currentTopic?: string;
  currentSubject?: string;
  currentBoard?: string;
  currentLevel?: string;
  currentChapter?: string;
  currentSubtopic?: string;
  selectedBoard?: {
    nation: string;
    acronym: string;
  } | null;
  onSelectTopic: (topicName: string, curriculumDetails?: CurriculumSelection) => void;
  onClose?: () => void;
  isOpen?: boolean;
  isLoading?: boolean;
  currentTeacherStyleId?: string;
  onSelectTeacherStyle?: (styleId: string) => void;
}

const SUBJECT_ICONS: Record<string, React.ReactNode> = {
  mathematics: <Layers size={15} className="text-blue-400" />,
  physics: <Atom size={15} className="text-cyan-400" />,
  chemistry: <Orbit size={15} className="text-purple-400" />,
  biology: <Dna size={15} className="text-emerald-400" />,
  computer_science: <Cpu size={15} className="text-amber-400" />,
  astronomy: <Globe size={15} className="text-indigo-400" />,
  economics: <GraduationCap size={15} className="text-rose-400" />
};

const STANDARD_LEVELS = [
  'Class 9 / Grade 9',
  'Class 10 / Grade 10',
  'Class 11 / Grade 11',
  'Class 12 / Grade 12',
  'Undergraduate / College',
  'Competitive (NEET / JEE / AIIMS / AP / SAT / IB)'
];

export const TopicSelector: React.FC<TopicSelectorProps> = ({
  currentTopic = 'Differential Calculus',
  currentSubject = 'mathematics',
  currentBoard,
  currentLevel,
  currentChapter,
  currentSubtopic,
  selectedBoard,
  onSelectTopic,
  onClose,
  isOpen = true,
  isLoading = false,
  currentTeacherStyleId = 'clarity_default',
  onSelectTeacherStyle
}) => {
  // Mode selection: 'browse' syllabus or 'custom' explicit 6-parameter form
  const [selectionMode, setSelectionMode] = useState<'browse' | 'custom_hierarchy'>('browse');

  // 1. Board Selection State
  const [activeBoard, setActiveBoard] = useState<{ nation: string; acronym: string; name?: string }>(() => {
    if (selectedBoard?.nation && selectedBoard?.acronym) {
      return { nation: selectedBoard.nation, acronym: selectedBoard.acronym };
    }
    if (currentBoard) {
      const match = EDUCATION_BOARDS.find(b => b.acronym.toLowerCase() === currentBoard.toLowerCase() || b.name.toLowerCase().includes(currentBoard.toLowerCase()));
      if (match) return { nation: match.nation, acronym: match.acronym, name: match.name };
      return { nation: 'India', acronym: currentBoard };
    }
    return { nation: 'India', acronym: 'CBSE' };
  });

  // 2. Level / Class State
  const [activeLevel, setActiveLevel] = useState<string>(() => {
    return currentLevel || 'Class 12 / Grade 12';
  });

  // 3. Subject State
  const [activeSubject, setActiveSubject] = useState<string>(() => {
    const s = (currentSubject || 'mathematics').toLowerCase();
    if (CONFIG.SUBJECTS.includes(s as any)) return s;
    return 'mathematics';
  });

  // 4. Chapter State
  const [activeChapter, setActiveChapter] = useState<string>(() => {
    return currentChapter || currentTopic || 'Differential Calculus';
  });

  // 5. Topic State
  const [activeTopicState, setActiveTopicState] = useState<string>(() => {
    return currentTopic || 'Core Derivatives & Limits';
  });

  // 6. Subtopic State
  const [activeSubtopic, setActiveSubtopic] = useState<string>(() => {
    return currentSubtopic || 'First Principles, Chain Rule & Rate of Change';
  });

  // Custom Explicit Input State for the 6 fields
  const [customForm, setCustomForm] = useState<{
    board: string;
    level: string;
    subject: string;
    chapter: string;
    topic: string;
    subtopic: string;
  }>({
    board: activeBoard.acronym,
    level: activeLevel,
    subject: activeSubject,
    chapter: activeChapter,
    topic: activeTopicState,
    subtopic: activeSubtopic
  });

  // State for curriculum content fetching spinner
  const [isFetchingCurriculum, setIsFetchingCurriculum] = useState<boolean>(false);

  // Trigger elegant curriculum loading animation when board or subject changes
  useEffect(() => {
    if (isOpen) {
      setIsFetchingCurriculum(true);
      const timer = setTimeout(() => {
        setIsFetchingCurriculum(false);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [activeBoard, activeSubject, activeLevel, isOpen]);

  // State for search query
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Compute available subjects for the board
  const boardCurriculum = useMemo(() => {
    return getBoardCurriculum(activeBoard.nation, activeBoard.acronym);
  }, [activeBoard]);

  const availableSubjects = useMemo(() => {
    if (boardCurriculum?.subjects && boardCurriculum.subjects.length > 0) {
      return boardCurriculum.subjects;
    }
    return ['mathematics', 'physics', 'chemistry', 'biology', 'computer_science', 'economics'];
  }, [boardCurriculum]);

  // Detailed syllabus data for the selected board, level, and subject
  const detailedCurriculum = useMemo(() => {
    return getDetailedBoardCurriculum(activeBoard.nation, activeBoard.acronym, activeLevel, activeSubject);
  }, [activeBoard, activeLevel, activeSubject]);

  // Compute structured chapters list
  const structuredChapters = useMemo(() => {
    if (detailedCurriculum && detailedCurriculum.chapters && detailedCurriculum.chapters.length > 0) {
      return detailedCurriculum.chapters;
    }
    return [];
  }, [detailedCurriculum]);

  // Compute topics & chapters for active subject & board
  const topicList = useMemo(() => {
    const list: Array<{ 
      title: string; 
      chapterName: string;
      topics: string[];
      subtopics?: string[]; 
      source: string 
    }> = [];

    // 1. Try detailed board curriculum
    if (structuredChapters.length > 0) {
      structuredChapters.forEach((chap) => {
        list.push({
          title: chap.title,
          chapterName: chap.chapterName || chap.title,
          topics: chap.topics.map(t => typeof t === 'string' ? t : (t as any).title || String(t)),
          subtopics: chap.subtopics,
          source: `${activeBoard.acronym} Official Syllabus`
        });
      });
    }

    // 2. Try standard board curriculum topics if detailed was empty
    if (list.length === 0 && boardCurriculum?.topics && boardCurriculum.topics[activeSubject]) {
      boardCurriculum.topics[activeSubject].forEach((top) => {
        list.push({
          title: top,
          chapterName: top,
          topics: [top, `${top} Applications`, `${top} Problem Solving`],
          subtopics: ['Core Definitions', 'Mathematical Modeling', 'Exam Traps & Solutions'],
          source: `${activeBoard.acronym} Curriculum`
        });
      });
    }

    // 3. Fallback to CONFIG.TOPICS
    if (list.length === 0) {
      const configTopics = (CONFIG.TOPICS as Record<string, string[]>)[activeSubject];
      if (configTopics) {
        configTopics.forEach((top) => {
          list.push({
            title: top,
            chapterName: top,
            topics: [top, `${top} Mechanics`, `${top} Real World Cases`],
            subtopics: ['Fundamental Theorems', 'Standard Equations', 'High-Yield Exam Questions'],
            source: 'Core Curriculum'
          });
        });
      }
    }

    // 4. Default baseline list if still empty
    if (list.length === 0) {
      list.push(
        { 
          title: `${activeSubject.toUpperCase()} Core Principles & Fundamentals`, 
          chapterName: `${activeSubject.toUpperCase()} Foundations`,
          topics: ['Core Theorems', 'Worked Examples', 'Verification'],
          subtopics: ['Intuitive Concept', 'Mathematical Formulation', 'Board Practice'],
          source: 'Core Module' 
        },
        { 
          title: `Advanced ${activeSubject.toUpperCase()} Problem Solving`, 
          chapterName: `Advanced ${activeSubject.toUpperCase()}`,
          topics: ['Complex Problems', 'Analytical Strategies', 'Boundary Cases'],
          subtopics: ['Algebraic Techniques', 'Algorithmic Flow', 'Step-by-step Mastery'],
          source: 'Core Module' 
        }
      );
    }

    return list;
  }, [activeBoard, activeSubject, structuredChapters, boardCurriculum]);

  // Filtered topics based on search
  const filteredTopics = useMemo(() => {
    if (!searchQuery.trim()) return topicList;
    const q = searchQuery.toLowerCase();
    return topicList.filter(item => 
      item.title.toLowerCase().includes(q) || 
      item.chapterName.toLowerCase().includes(q) ||
      (item.topics && item.topics.some(t => t.toLowerCase().includes(q))) ||
      (item.subtopics && item.subtopics.some(sub => sub.toLowerCase().includes(q)))
    );
  }, [topicList, searchQuery]);

  // State for selected staged topic waiting for Start button click
  const [stagedTopic, setStagedTopic] = useState<string>(currentTopic);
  const [expandedChapterIndex, setExpandedChapterIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleApplyCurriculum = (
    boardVal: string,
    levelVal: string,
    subjectVal: string,
    chapterVal: string,
    topicVal: string,
    subtopicVal: string
  ) => {
    const primaryTopicTitle = chapterVal || topicVal || 'Core Academic Lecture';
    const curriculumPayload: CurriculumSelection = {
      board: boardVal || activeBoard.acronym,
      level: levelVal || activeLevel,
      subject: subjectVal || activeSubject,
      chapter: chapterVal || activeChapter,
      topic: topicVal || activeTopicState,
      subtopic: subtopicVal || activeSubtopic,
      nation: activeBoard.nation,
      acronym: activeBoard.acronym
    };

    onSelectTopic(primaryTopicTitle, curriculumPayload);
    if (onClose) onClose();
  };

  const handleSelectFromList = (item: typeof topicList[0]) => {
    const selectedChap = item.chapterName || item.title;
    const selectedTop = item.topics && item.topics.length > 0 ? item.topics[0] : selectedChap;
    const selectedSub = item.subtopics && item.subtopics.length > 0 ? item.subtopics[0] : 'Core Mechanism & Key Proofs';

    setActiveChapter(selectedChap);
    setActiveTopicState(selectedTop);
    setActiveSubtopic(selectedSub);
    setStagedTopic(selectedChap);

    handleApplyCurriculum(
      activeBoard.acronym,
      activeLevel,
      activeSubject,
      selectedChap,
      selectedTop,
      selectedSub
    );
  };

  const handleSelectSpecificTopicAndSubtopic = (
    item: typeof topicList[0],
    specificTopic?: string,
    specificSubtopic?: string
  ) => {
    const selectedChap = item.chapterName || item.title;
    const selectedTop = specificTopic || (item.topics && item.topics.length > 0 ? item.topics[0] : selectedChap);
    const selectedSub = specificSubtopic || (item.subtopics && item.subtopics.length > 0 ? item.subtopics[0] : 'Core Mechanism & Key Proofs');

    setActiveChapter(selectedChap);
    setActiveTopicState(selectedTop);
    setActiveSubtopic(selectedSub);
    setStagedTopic(`${selectedChap} - ${selectedTop}`);

    handleApplyCurriculum(
      activeBoard.acronym,
      activeLevel,
      activeSubject,
      selectedChap,
      selectedTop,
      selectedSub
    );
  };

  const handleCustomFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customForm.chapter.trim() && !customForm.topic.trim()) return;

    handleApplyCurriculum(
      customForm.board.trim() || activeBoard.acronym,
      customForm.level.trim() || activeLevel,
      customForm.subject.trim() || activeSubject,
      customForm.chapter.trim() || 'Custom Chapter',
      customForm.topic.trim() || 'Custom Topic',
      customForm.subtopic.trim() || 'Core Subtopic Focus'
    );
  };

  // Featured top boards for quick switching
  const popularBoards = EDUCATION_BOARDS.slice(0, 10);

  return (
    <div className="fixed inset-0 z-[120] bg-slate-950/85 backdrop-blur-2xl flex items-center justify-center p-3 sm:p-5 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        
        {/* Header Bar */}
        <div className="p-5 border-b border-slate-800/80 bg-slate-900/90 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-inner">
              <BookOpen size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                  Curriculum & Chapter Configurator
                </h2>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {activeBoard.acronym}
                </span>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 hidden sm:inline-block">
                  6-Hierarchy Input
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Specify your exact <strong>Board</strong>, <strong>Level</strong>, <strong>Subject</strong>, <strong>Chapter</strong>, <strong>Topic</strong>, and <strong>Subtopic</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Mode Switch: Browse Syllabus vs. Custom 6-Parameter Form */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-0.5 flex items-center text-xs">
              <button
                type="button"
                onClick={() => setSelectionMode('browse')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  selectionMode === 'browse'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <ListTree size={13} />
                <span>Browse Syllabus</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectionMode('custom_hierarchy')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  selectionMode === 'custom_hierarchy'
                    ? 'bg-cyan-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sliders size={13} />
                <span>Custom 6 Inputs</span>
              </button>
            </div>

            {onClose && (
              <button
                onClick={onClose}
                className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer border border-slate-700/50"
                title="Close Configurator"
              >
                <X size={18} />
              </button>
            )}
          </div>
        </div>

        {/* Dedicated Teacher Persona Selector Row */}
        {onSelectTeacherStyle && (
          <div className="px-5 py-2.5 border-b border-slate-800/80 bg-slate-950/80 flex items-center gap-2 overflow-x-auto scrollbar-none">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 flex items-center gap-1 shrink-0 mr-1">
              <Sparkles size={12} className="text-amber-400" />
              Teaching Professor:
            </span>
            {TEACHER_PEDAGOGY_STYLES.map((t) => {
              const isSelected = currentTeacherStyleId === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => onSelectTeacherStyle(t.id)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 cursor-pointer border ${
                    isSelected
                      ? t.id === 'omni_ai'
                        ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 border-amber-300 shadow-md font-black'
                        : 'bg-indigo-600 text-white border-indigo-400 shadow-md'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
                  }`}
                >
                  <span>{t.avatarIcon}</span>
                  <span>{t.name}</span>
                  <span className="text-[9px] opacity-75 hidden sm:inline">({t.badge})</span>
                </button>
              );
            })}
          </div>
        )}

        {/* 1. Board Switcher Selector */}
        <div className="px-5 py-2.5 border-b border-slate-800 bg-slate-950/60 flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 flex items-center gap-1 shrink-0 mr-1">
            <Globe size={12} className="text-indigo-400" />
            1. Board:
          </span>
          {popularBoards.map((b) => (
            <button
              key={`${b.nation}-${b.acronym}`}
              onClick={() => {
                setActiveBoard({ nation: b.nation, acronym: b.acronym, name: b.name });
                setCustomForm(prev => ({ ...prev, board: b.acronym }));
              }}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 cursor-pointer border ${
                activeBoard.acronym === b.acronym && activeBoard.nation === b.nation
                  ? 'bg-indigo-600 text-white border-indigo-400/50 shadow-md shadow-indigo-600/20'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
              }`}
            >
              <span className="text-[10px] text-slate-400">[{b.nation}]</span>
              <span>{b.acronym}</span>
            </button>
          ))}
        </div>

        {/* 2. Level / Class Selector & 3. Subject Selector Tabs */}
        <div className="px-5 py-2.5 border-b border-slate-800 bg-slate-950/40 grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Level / Class */}
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 shrink-0">
              2. Level:
            </span>
            {STANDARD_LEVELS.map((lvl) => {
              const shortLvl = lvl.split(' / ')[0].replace(' (NEET / JEE / AIIMS / AP / SAT / IB)', '');
              const isSelected = activeLevel.includes(shortLvl) || activeLevel === lvl;
              return (
                <button
                  key={lvl}
                  onClick={() => {
                    setActiveLevel(lvl);
                    setCustomForm(prev => ({ ...prev, level: lvl }));
                  }}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all shrink-0 cursor-pointer border ${
                    isSelected
                      ? 'bg-indigo-600/40 border-indigo-500 text-white shadow-sm'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {shortLvl}
                </button>
              );
            })}
          </div>

          {/* Subject Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 shrink-0">
              3. Subject:
            </span>
            {availableSubjects.map((subj) => {
              const formatted = subj.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
              const icon = SUBJECT_ICONS[subj] || <GraduationCap size={13} className="text-indigo-400" />;
              const isActive = activeSubject === subj;

              return (
                <button
                  key={subj}
                  onClick={() => {
                    setActiveSubject(subj);
                    setCustomForm(prev => ({ ...prev, subject: subj }));
                    setSearchQuery('');
                  }}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 cursor-pointer border ${
                    isActive
                      ? 'bg-slate-800 text-white border-indigo-500/60 shadow-inner'
                      : 'bg-slate-950/40 text-slate-400 border-slate-800 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  {icon}
                  <span>{formatted}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Mode Content Body */}
        {selectionMode === 'custom_hierarchy' ? (
          /* Custom 6-Parameter Explicit Form */
          <div className="flex-1 overflow-y-auto p-6 scrollbar-thin scrollbar-thumb-slate-800 bg-slate-950/50">
            <div className="max-w-3xl mx-auto space-y-5">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <Sliders size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">Direct 6-Parameter Curriculum Entry</h3>
                  <p className="text-xs text-slate-400">
                    Provide all 6 academic parameters to let Professor Clarity generate a precisely calibrated lecture.
                  </p>
                </div>
              </div>

              <form onSubmit={handleCustomFormSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* 1. Board */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px] flex items-center justify-center font-bold">1</span>
                      Education Board
                    </label>
                    <input
                      type="text"
                      value={customForm.board}
                      onChange={(e) => setCustomForm({ ...customForm, board: e.target.value })}
                      placeholder="e.g., CBSE, ICSE, Cambridge IGCSE, AP, IB, State Board"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all"
                      required
                    />
                  </div>

                  {/* 2. Level / Class */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px] flex items-center justify-center font-bold">2</span>
                      Academic Level / Class / Standard
                    </label>
                    <input
                      type="text"
                      value={customForm.level}
                      onChange={(e) => setCustomForm({ ...customForm, level: e.target.value })}
                      placeholder="e.g., Class 12, Class 10, Grade 11, JEE Advanced, NEET"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all"
                      required
                    />
                  </div>

                  {/* 3. Subject */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px] flex items-center justify-center font-bold">3</span>
                      Subject
                    </label>
                    <input
                      type="text"
                      value={customForm.subject}
                      onChange={(e) => setCustomForm({ ...customForm, subject: e.target.value })}
                      placeholder="e.g., Physics, Chemistry, Mathematics, Biology, Economics"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all"
                      required
                    />
                  </div>

                  {/* 4. Chapter */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px] flex items-center justify-center font-bold">4</span>
                      Chapter Name
                    </label>
                    <input
                      type="text"
                      value={customForm.chapter}
                      onChange={(e) => setCustomForm({ ...customForm, chapter: e.target.value })}
                      placeholder="e.g., Chapter 5: Magnetism and Matter / Thermodynamics / Cell Cycle"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all"
                      required
                    />
                  </div>

                  {/* 5. Topic */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px] flex items-center justify-center font-bold">5</span>
                      Topic Name
                    </label>
                    <input
                      type="text"
                      value={customForm.topic}
                      onChange={(e) => setCustomForm({ ...customForm, topic: e.target.value })}
                      placeholder="e.g., Bar Magnet as an Equivalent Solenoid / First Law / Mitosis"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all"
                      required
                    />
                  </div>

                  {/* 6. Subtopic */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <span className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px] flex items-center justify-center font-bold">6</span>
                      Subtopic / Specific Focus Area
                    </label>
                    <input
                      type="text"
                      value={customForm.subtopic}
                      onChange={(e) => setCustomForm({ ...customForm, subtopic: e.target.value })}
                      placeholder="e.g., Magnetic Field Lines, Potential Energy Derivation, Traps"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-all"
                      required
                    />
                  </div>
                </div>

                <div className="pt-3 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectionMode('browse')}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
                  >
                    Back to Syllabus
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-black uppercase tracking-wider shadow-lg shadow-cyan-600/30 ring-2 ring-cyan-400/50 cursor-pointer flex items-center gap-2"
                  >
                    <Sparkles size={14} className="text-amber-300" />
                    <span>Launch 3D Lecture with These 6 Inputs</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        ) : (
          /* Browse Syllabus Mode */
          <>
            {/* Search Filter Bar */}
            <div className="p-4 border-b border-slate-800 bg-slate-950/40 flex items-center gap-3">
              <div className="relative flex-1">
                <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={`Search ${activeBoard.acronym} ${activeSubject} chapters, topics, subtopics...`}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500/80 transition-all"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white cursor-pointer"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>

              <div className="text-[11px] text-slate-400 shrink-0 font-medium">
                {filteredTopics.length} Chapters Found
              </div>
            </div>

            {/* Chapters & Topics List Grid */}
            <div className="flex-1 overflow-y-auto custom-scrollbar touch-pan-y overscroll-contain p-5">
              {isFetchingCurriculum || isLoading ? (
                <div className="flex flex-col items-center justify-center py-16 bg-slate-950/40 rounded-2xl border border-slate-800/60 p-8 space-y-4 animate-fade-in my-auto">
                  <div className="relative flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin" />
                    <div className="absolute w-10 h-10 rounded-full border-4 border-purple-500/20 border-b-purple-500 animate-spin [animation-duration:1.5s]" />
                    <Sparkles size={20} className="absolute text-indigo-400 animate-pulse" />
                  </div>
                  <div className="text-center space-y-1">
                    <p className="text-xs font-bold text-white tracking-wide flex items-center justify-center gap-1.5">
                      <span>Fetching {activeBoard.acronym} {activeSubject.replace(/_/g, ' ')} Curriculum</span>
                      <Loader2 size={13} className="animate-spin text-indigo-400" />
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Loading official chapters, subtopics, and formula derivations...
                    </p>
                  </div>
                </div>
              ) : filteredTopics.length === 0 ? (
                <div className="text-center py-12 bg-slate-950/40 rounded-2xl border border-slate-800/60 p-6">
                  <Compass size={36} className="mx-auto text-slate-600 mb-2 animate-bounce" />
                  <p className="text-xs font-bold text-slate-400">No exact matches for &quot;{searchQuery}&quot;</p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Switch to <strong>&quot;Custom 6 Inputs&quot;</strong> tab above to type any specific chapter/topic directly!
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredTopics.map((item, idx) => {
                    const isSelected = stagedTopic.toLowerCase() === item.title.toLowerCase() || stagedTopic.toLowerCase() === item.chapterName.toLowerCase() || stagedTopic.toLowerCase().includes(item.chapterName.toLowerCase());
                    const isCurrent = currentTopic.toLowerCase() === item.title.toLowerCase() || currentTopic.toLowerCase() === item.chapterName.toLowerCase();
                    const isExpanded = expandedChapterIndex === idx;

                    return (
                      <div
                        key={`${item.title}-${idx}`}
                        className={`p-4 rounded-2xl border text-left transition-all flex flex-col justify-between group relative overflow-hidden ${
                          isSelected
                            ? 'bg-emerald-600/15 border-emerald-500/80 text-white shadow-lg shadow-emerald-500/20 ring-2 ring-emerald-500/40'
                            : isCurrent
                            ? 'bg-indigo-600/15 border-indigo-500/60 text-white shadow-md'
                            : 'bg-slate-950/40 border-slate-800 text-slate-300 hover:bg-slate-850/60 hover:border-slate-700 hover:text-white'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div 
                            className="flex-1 cursor-pointer"
                            onClick={() => handleSelectFromList(item)}
                          >
                            <div className="text-xs font-black tracking-wide flex items-center gap-1.5">
                              {isSelected ? (
                                <Check size={14} className="text-emerald-400 shrink-0 animate-pulse" />
                              ) : isCurrent ? (
                                <Check size={14} className="text-indigo-400 shrink-0" />
                              ) : null}
                              <span className={isSelected ? 'text-emerald-300 font-extrabold' : ''}>{item.title}</span>
                            </div>

                            {/* Topics preview & interactive chips */}
                            {item.topics && item.topics.length > 0 && (
                              <div className="mt-2 space-y-1">
                                <div className="text-[11px] text-indigo-300/90 font-semibold flex items-center gap-1">
                                  <Bookmark size={11} className="text-indigo-400 shrink-0" />
                                  <span>Topics ({item.topics.length}):</span>
                                </div>
                                <div className="flex flex-wrap gap-1.5 pt-0.5">
                                  {item.topics.map((top, tIdx) => {
                                    const isTopActive = activeTopicState.toLowerCase() === top.toLowerCase();
                                    return (
                                      <button
                                        key={tIdx}
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          const matchingSub = item.subtopics && item.subtopics[tIdx] ? item.subtopics[tIdx] : item.subtopics?.[0];
                                          handleSelectSpecificTopicAndSubtopic(item, top, matchingSub);
                                        }}
                                        className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                                          isTopActive
                                            ? 'bg-indigo-500 text-white border-indigo-400 shadow-sm'
                                            : 'bg-slate-900/90 text-indigo-200 border-indigo-500/30 hover:bg-indigo-900/40 hover:text-white'
                                        }`}
                                        title={`Select Topic: ${top}`}
                                      >
                                        {top}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            )}

                            {/* Subtopics listing */}
                            {item.subtopics && item.subtopics.length > 0 && (
                              <div className="mt-2.5 space-y-1">
                                <div className="text-[10px] text-slate-400 flex items-center justify-between">
                                  <span className="flex items-center gap-1 font-medium">
                                    <FileText size={10} className="text-slate-500 shrink-0" />
                                    <span>Subtopics:</span>
                                  </span>
                                  {item.subtopics.length > 1 && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setExpandedChapterIndex(isExpanded ? null : idx);
                                      }}
                                      className="text-[10px] text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-0.5 cursor-pointer ml-auto"
                                    >
                                      <span>{isExpanded ? 'Collapse' : `View all (${item.subtopics.length})`}</span>
                                      {isExpanded ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
                                    </button>
                                  )}
                                </div>

                                <div className="space-y-1">
                                  {(isExpanded ? item.subtopics : item.subtopics.slice(0, 2)).map((sub, sIdx) => {
                                    const isSubActive = activeSubtopic.toLowerCase() === sub.toLowerCase() || activeSubtopic.toLowerCase().includes(sub.split(':')[0].toLowerCase());
                                    return (
                                      <div
                                        key={sIdx}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          const correspondingTop = item.topics && item.topics[sIdx] ? item.topics[sIdx] : item.topics?.[0];
                                          handleSelectSpecificTopicAndSubtopic(item, correspondingTop, sub);
                                        }}
                                        className={`p-1.5 rounded-lg border text-[10px] transition-all cursor-pointer flex items-center justify-between gap-1.5 ${
                                          isSubActive
                                            ? 'bg-emerald-950/60 border-emerald-500/60 text-emerald-200'
                                            : 'bg-slate-900/50 border-slate-800 text-slate-300 hover:bg-slate-800/80 hover:text-white'
                                        }`}
                                      >
                                        <span className="line-clamp-1 flex-1">{sub}</span>
                                        <ChevronRight size={10} className="text-slate-500 shrink-0" />
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="flex flex-col items-end gap-1 shrink-0">
                            <span className="text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-slate-400">
                              {item.source}
                            </span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setExpandedChapterIndex(isExpanded ? null : idx);
                              }}
                              className="p-1 rounded-md bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-all cursor-pointer"
                              title={isExpanded ? 'Collapse' : 'Expand full details'}
                            >
                              {isExpanded ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                            </button>
                          </div>
                        </div>

                        <div className="mt-3 pt-2.5 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-400">
                          <span className="font-medium flex items-center gap-1">
                            <Award size={12} className={isSelected ? 'text-emerald-400' : 'text-indigo-400'} />
                            <span>{activeLevel.split(' / ')[0]} Syllabus</span>
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSelectFromList(item);
                            }}
                            className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center gap-1 transition-all cursor-pointer shadow-md ${
                              isSelected
                                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-600/30 ring-2 ring-emerald-400/50'
                                : 'bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 hover:text-white border border-indigo-500/40'
                            }`}
                          >
                            <span>Select &amp; Teach</span>
                            <ChevronRight size={12} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}

        {/* Footer Bar with prominent START LESSON button */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/90 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
            <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2">
              <span className="text-slate-400">Hierarchy Target:</span>
              <span className="text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 flex-wrap">
                <span className="text-cyan-400">[{activeBoard.acronym}]</span>
                <span className="text-slate-500">•</span>
                <span className="text-indigo-300">{activeLevel.split(' / ')[0]}</span>
                <span className="text-slate-500">•</span>
                <span className="capitalize text-emerald-300">{activeSubject.replace(/_/g, ' ')}</span>
                <span className="text-slate-500">•</span>
                <span className="text-white font-bold">{stagedTopic}</span>
                {activeSubtopic && (
                  <>
                    <span className="text-slate-500">•</span>
                    <span className="text-slate-400 text-[11px] font-normal truncate max-w-[200px]" title={activeSubtopic}>
                      Subtopic: {activeSubtopic.split(':')[0]}
                    </span>
                  </>
                )}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={() => {
                if (onClose) onClose();
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                if (selectionMode === 'custom_hierarchy') {
                  handleApplyCurriculum(
                    customForm.board,
                    customForm.level,
                    customForm.subject,
                    customForm.chapter,
                    customForm.topic,
                    customForm.subtopic
                  );
                } else {
                  handleApplyCurriculum(
                    activeBoard.acronym,
                    activeLevel,
                    activeSubject,
                    activeChapter || stagedTopic,
                    activeTopicState || stagedTopic,
                    activeSubtopic
                  );
                }
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black uppercase tracking-wider shadow-lg shadow-emerald-600/30 ring-2 ring-emerald-400/50 cursor-pointer flex items-center gap-2"
            >
              <Sparkles size={14} className="text-amber-300" />
              <span>Start 3D Lecture</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
