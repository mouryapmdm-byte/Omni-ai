import React, { useEffect } from 'react';
import {
  FileText,
  BookOpen,
  HelpCircle,
  Award,
  Settings,
  Sparkles,
  Sliders,
  Maximize2,
  X,
  Volume2,
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface RadialMenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  action: () => void;
}

interface BubbleRadialMenuProps {
  isOpen: boolean;
  position: { x: number; y: number };
  onClose: () => void;
  onSelectAction: (actionId: string) => void;
  customItems?: RadialMenuItem[];
}

export const BubbleRadialMenu: React.FC<BubbleRadialMenuProps> = ({
  isOpen,
  position,
  onClose,
  onSelectAction,
  customItems,
}) => {
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      onClose();
    };
    if (isOpen) {
      window.addEventListener('click', handleOutsideClick);
      return () => window.removeEventListener('click', handleOutsideClick);
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const defaultItems: RadialMenuItem[] = [
    {
      id: 'notes',
      label: 'Notes',
      icon: <FileText size={18} />,
      color: 'from-blue-600 to-indigo-600 text-blue-100',
      action: () => onSelectAction('notes'),
    },
    {
      id: 'ask',
      label: 'Ask',
      icon: <HelpCircle size={18} />,
      color: 'from-amber-500 to-orange-600 text-amber-100',
      action: () => onSelectAction('ask'),
    },
    {
      id: 'topics',
      label: 'Topics',
      icon: <BookOpen size={18} />,
      color: 'from-emerald-500 to-teal-600 text-emerald-100',
      action: () => onSelectAction('topics'),
    },
    {
      id: 'style',
      label: 'Pedagogy',
      icon: <Sparkles size={18} />,
      color: 'from-purple-500 to-pink-600 text-purple-100',
      action: () => onSelectAction('style'),
    },
    {
      id: 'progress',
      label: 'Progress',
      icon: <Award size={18} />,
      color: 'from-cyan-500 to-blue-600 text-cyan-100',
      action: () => onSelectAction('progress'),
    },
    {
      id: 'lab',
      label: 'Lab Tools',
      icon: <Sliders size={18} />,
      color: 'from-red-500 to-rose-600 text-rose-100',
      action: () => onSelectAction('lab'),
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: <Settings size={18} />,
      color: 'from-slate-600 to-slate-800 text-slate-100',
      action: () => onSelectAction('settings'),
    },
    {
      id: 'fullscreen',
      label: 'Stage',
      icon: <Maximize2 size={18} />,
      color: 'from-indigo-600 to-violet-700 text-indigo-100',
      action: () => onSelectAction('fullscreen'),
    },
  ];

  const items = customItems || defaultItems;
  const radius = 95; // pixels from centre
  const total = items.length;

  // Clamp position within window bounds
  const clampedX = Math.min(Math.max(position.x, 120), window.innerWidth - 120);
  const clampedY = Math.min(Math.max(position.y, 120), window.innerHeight - 120);

  return (
    <div
      className="fixed z-50 pointer-events-auto select-none animate-in zoom-in-50 duration-200"
      style={{
        left: `${clampedX}px`,
        top: `${clampedY}px`,
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Centre Dismiss Button */}
      <button
        onClick={onClose}
        className="absolute -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-slate-950/95 border-2 border-indigo-400 text-indigo-300 shadow-2xl flex items-center justify-center hover:bg-slate-900 transition-all cursor-pointer z-20 group"
        title="Close Radial Menu"
      >
        <X size={18} className="group-hover:rotate-90 transition-transform duration-200" />
      </button>

      {/* Radial Items arranged in a circle */}
      {items.map((item, index) => {
        const angle = (index * 2 * Math.PI) / total - Math.PI / 2;
        const x = Math.round(radius * Math.cos(angle));
        const y = Math.round(radius * Math.sin(angle));

        return (
          <div
            key={item.id}
            className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group transition-all duration-200 z-10"
            style={{
              transform: `translate(${x}px, ${y}px) translate(-50%, -50%)`,
            }}
          >
            <button
              onClick={() => {
                item.action();
                onClose();
              }}
              className={cn(
                "w-11 h-11 rounded-full bg-gradient-to-tr shadow-xl flex items-center justify-center border border-white/20 transition-all duration-200 hover:scale-115 active:scale-95 cursor-pointer",
                item.color
              )}
              title={item.label}
            >
              {item.icon}
            </button>
            <span className="mt-1 text-[10px] font-bold text-white bg-slate-950/90 border border-slate-800 px-1.5 py-0.5 rounded-md shadow pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-150 whitespace-nowrap">
              {item.label}
            </span>
          </div>
        );
      })}
    </div>
  );
};
