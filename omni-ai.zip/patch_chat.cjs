const fs = require('fs');
const file = 'src/components/Chat.tsx';
let content = fs.readFileSync(file, 'utf8');

const target1 = `                    </ReactMarkdown>
                  </div>`;
const replacement1 = `                    </ReactMarkdown>
                  </div>
                  {(() => {
                    const c = localTranslations[msg.id] || msg.content;
                    if (c && (c.includes('Newton-Raphson') || c.includes('न्यूटन-राफसन')) && (c.includes('x^3 - x - 2') || c.includes('x3 - x - 2') || c.includes('x³ - x - 2') || c.includes('x**3 - x - 2'))) {
                      return <NewtonRaphsonGraph funcStr="x**3 - x - 2" derivStr="3*x**2 - 1" x0={2} iterations={4} theme={theme} />;
                    }
                    return null;
                  })()}`;

const target2 = `                              isRecordingAi={isRecordingAi}
                            />
                          </div>`;
const replacement2 = `                              isRecordingAi={isRecordingAi}
                            />
                          </div>
                          {(() => {
                            const c = localTranslations[msg.id] || msg.content;
                            if (c && (c.includes('Newton-Raphson') || c.includes('न्यूटन-राफसन')) && (c.includes('x^3 - x - 2') || c.includes('x3 - x - 2') || c.includes('x³ - x - 2') || c.includes('x**3 - x - 2'))) {
                              return <NewtonRaphsonGraph funcStr="x**3 - x - 2" derivStr="3*x**2 - 1" x0={2} iterations={4} theme={theme} />;
                            }
                            return null;
                          })()}`;

if (content.includes(target1)) {
  content = content.replace(target1, replacement1);
  console.log("Replaced target1");
}

if (content.includes(target2)) {
  content = content.replace(target2, replacement2);
  console.log("Replaced target2");
}

fs.writeFileSync(file, content);
