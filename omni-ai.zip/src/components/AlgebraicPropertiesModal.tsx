import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../lib/utils';
import { Plus, X, ChevronRight, Calculator, Grid3X3, Beaker } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';

interface AlgebraicPropertiesModalProps {
  theme: string;
  onClose: () => void;
}

export function AlgebraicPropertiesModal({ theme, onClose }: AlgebraicPropertiesModalProps) {
  const [activeTab, setActiveTab] = useState<'addition' | 'scalar' | 'determinant'>('addition');

  const tabs = [
    { id: 'addition', label: 'Matrix Addition', icon: Plus },
    { id: 'scalar', label: 'Scalar Multiplication', icon: X },
    { id: 'determinant', label: 'Determinant Rules', icon: Grid3X3 },
  ] as const;

  const content = {
    addition: `
### Properties of Matrix Addition
Let $A$, $B$, and $C$ be matrices of the same order $m \\times n$.

1. **Commutative Law:**
   $A + B = B + A$
   
2. **Associative Law:**
   $(A + B) + C = A + (B + C)$
   
3. **Existence of Additive Identity:**
   Let $O$ be the $m \\times n$ zero matrix. Then,
   $A + O = O + A = A$
   
4. **Existence of Additive Inverse:**
   For every matrix $A = [a_{ij}]_{m \\times n}$, there exists a matrix $-A = [-a_{ij}]_{m \\times n}$ such that:
   $A + (-A) = (-A) + A = O$
   (where $O$ is the zero matrix)
    `,
    scalar: `
### Properties of Scalar Multiplication
Let $A = [a_{ij}]$ and $B = [b_{ij}]$ be two matrices of the same order $m \\times n$, and let $k$ and $l$ be scalars.

1. **Distributive over Matrix Addition:**
   $k(A + B) = kA + kB$
   
2. **Distributive over Scalar Addition:**
   $(k + l)A = kA + lA$
   
3. **Associative over Scalar Multiplication:**
   $(kl)A = k(lA) = l(kA)$
   
4. **Multiplication by 1:**
   $1 \\cdot A = A$
   
5. **Multiplication by -1:**
   $(-1)A = -A$
    `,
    determinant: `
### Properties of Determinants
Let $A$ and $B$ be square matrices of order $n$.

1. **Reflection Property:** The determinant of a matrix is equal to the determinant of its transpose.
   $|A| = |A^T|$
   
2. **Row/Column Switch:** If any two rows (or columns) of a matrix are interchanged, the sign of the determinant changes.

3. **Zero Determinant (Identical Rows/Columns):** If any two rows (or columns) of a matrix are identical, the determinant is zero.

4. **Scalar Multiple of a Row/Column:** If all elements of a row (or column) are multiplied by a scalar $k$, the determinant is multiplied by $k$.
   As a consequence for the whole matrix: $|kA| = k^n|A|$

5. **Sum Property:** If some or all elements of a row/column are expressed as a sum of two terms, the determinant can be expressed as sum of two determinants.

6. **Invariance under Row Addition:** The determinant remains unchanged if a scalar multiple of one row/column is added to another row/column.
   $R_i \\to R_i + k R_j$

7. **Multiplicative Property:** 
   $|AB| = |A| |B|$
    `
  };

  return (
    <div className={cn(
      "flex flex-col h-full overflow-hidden",
      theme === 'dark' ? "bg-slate-950 text-white" : "bg-white text-slate-900"
    )}>
      {/* Header */}
      <div className={cn(
        "flex-none px-6 py-4 border-b flex items-center justify-between sticky top-0 z-10",
        theme === 'dark' ? "bg-slate-900/90 border-slate-800" : "bg-slate-50/90 border-slate-200 backdrop-blur-md"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-500">
            <Calculator size={24} />
          </div>
          <div>
            <h2 className="font-bold text-lg leading-tight">Algebraic Properties</h2>
            <p className={cn("text-xs", theme === 'dark' ? "text-slate-400" : "text-slate-500")}>
              Quick reference for matrices and determinants
            </p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
        {/* Sidebar Tabs */}
        <div className={cn(
          "w-full md:w-64 flex-none border-b md:border-b-0 md:border-r overflow-y-auto p-4 space-y-2",
          theme === 'dark' ? "border-slate-800 bg-slate-900/50" : "border-slate-200 bg-slate-50"
        )}>
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                activeTab === tab.id
                  ? (theme === 'dark' ? "bg-indigo-500/20 text-indigo-300 shadow-sm" : "bg-indigo-50 text-indigo-700 shadow-sm")
                  : (theme === 'dark' ? "hover:bg-white/5 text-slate-400" : "hover:bg-slate-100 text-slate-600")
              )}
            >
              <tab.icon size={16} className={activeTab === tab.id ? "text-indigo-500" : "opacity-50"} />
              <span className="text-left flex-1">{tab.label}</span>
              {activeTab === tab.id && <ChevronRight size={14} className="opacity-50" />}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="max-w-3xl mx-auto"
            >
              <div className={cn(
                "prose prose-sm max-w-none prose-h3:text-xl prose-h3:font-bold prose-h3:mb-6",
                theme === 'dark' 
                  ? "prose-invert prose-p:text-slate-300 prose-li:text-slate-300 prose-strong:text-white" 
                  : "prose-slate prose-p:text-slate-600 prose-li:text-slate-600 prose-strong:text-slate-900"
              )}>
                <ReactMarkdown
                  remarkPlugins={[remarkMath, remarkGfm]}
                  rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
                >
                  {content[activeTab]}
                </ReactMarkdown>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
