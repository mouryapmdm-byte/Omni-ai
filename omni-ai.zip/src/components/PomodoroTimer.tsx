import React, { useState, useEffect, useRef } from 'react';
import { 
  Timer, Play, Pause, RotateCcw, Coffee, Brain, 
  Bell, Settings, Volume2, VolumeX, Music, Waves, CloudRain, Star 
} from 'lucide-react';
import { cn } from '../lib/utils';

interface PomodoroTimerProps {
  onSessionComplete?: (type: 'work' | 'break') => void;
  theme?: 'light' | 'dark';
}

// Procedural Web Audio Ambient Soundscapes Synthesizer
class AmbientAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private sources: any[] = [];
  private isPlaying = false;
  private timers: any[] = [];

  start(type: string, volume: number) {
    this.stop();
    if (type === 'none') return;

    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      this.ctx = new AudioContextClass();
      this.isPlaying = true;

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(volume / 100, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      if (type === 'binaural') {
        // Binaural Alpha waves for deep focus: Left 200Hz, Right 210Hz (10Hz frequency differential)
        const merger = this.ctx.createChannelMerger(2);
        
        const oscL = this.ctx.createOscillator();
        oscL.frequency.setValueAtTime(200, this.ctx.currentTime);
        const gainL = this.ctx.createGain();
        gainL.gain.setValueAtTime(0.4, this.ctx.currentTime);
        oscL.connect(gainL);
        
        const oscR = this.ctx.createOscillator();
        oscR.frequency.setValueAtTime(210, this.ctx.currentTime);
        const gainR = this.ctx.createGain();
        gainR.gain.setValueAtTime(0.4, this.ctx.currentTime);
        oscR.connect(gainR);
        
        gainL.connect(merger, 0, 0);
        gainR.connect(merger, 0, 1);
        
        merger.connect(this.masterGain);
        oscL.start();
        oscR.start();
        
        this.sources.push(oscL, oscR);
      } else if (type === 'rain') {
        // Procedural rainfall: White noise + random droplet crackles
        const bufferSize = 2 * this.ctx.sampleRate;
        const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = Math.random() * 2 - 1;
        }

        const whiteNoise = this.ctx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(700, this.ctx.currentTime);

        whiteNoise.connect(filter);
        filter.connect(this.masterGain);
        whiteNoise.start();
        this.sources.push(whiteNoise);

        // Random raindrop droplets
        const playDroplet = () => {
          if (!this.isPlaying || !this.ctx || !this.masterGain) return;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(900 + Math.random() * 1000, this.ctx.currentTime);
          osc.frequency.exponentialRampToValueAtTime(80, this.ctx.currentTime + 0.05);

          gain.gain.setValueAtTime(0.01 + Math.random() * 0.03, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

          osc.connect(gain);
          gain.connect(this.masterGain);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.06);

          const t = setTimeout(playDroplet, 150 + Math.random() * 250);
          this.timers.push(t);
        };
        playDroplet();
      } else if (type === 'lofi') {
        // Slow peaceful ambient chord progression (Fm9 - Bbm9)
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(350, this.ctx.currentTime);
        filter.Q.setValueAtTime(1.5, this.ctx.currentTime);
        filter.connect(this.masterGain);

        const chords = [
          [174.61, 207.65, 261.63, 311.13, 349.23], // Fm9 (F3, Ab3, C4, Eb4, G4)
          [233.08, 277.18, 349.23, 415.30, 466.16]  // Bbm9 (Bb3, Db4, F4, Ab4, C5)
        ];

        let chordIndex = 0;
        const playChords = () => {
          if (!this.isPlaying || !this.ctx) return;
          const activeNotes = chords[chordIndex];
          const now = this.ctx.currentTime;

          const currentOscs: any[] = [];
          activeNotes.forEach(freq => {
            if (!this.ctx) return;
            const osc = this.ctx.createOscillator();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, now);

            const gain = this.ctx.createGain();
            gain.gain.setValueAtTime(0, now);
            gain.gain.linearRampToValueAtTime(0.12, now + 1.5);
            gain.gain.setValueAtTime(0.12, now + 5.5);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 7.9);

            // Subtle LFO vibrato
            const lfo = this.ctx.createOscillator();
            lfo.frequency.setValueAtTime(0.5 + Math.random() * 0.3, now);
            const lfoGain = this.ctx.createGain();
            lfoGain.gain.setValueAtTime(1.5, now);
            lfo.connect(lfoGain);
            lfoGain.connect(osc.frequency);
            
            lfo.start();
            osc.connect(gain);
            gain.connect(filter);
            osc.start();
            osc.stop(now + 8);

            this.sources.push(osc, lfo);
          });

          chordIndex = (chordIndex + 1) % chords.length;
          const t = setTimeout(playChords, 8000);
          this.timers.push(t);
        };
        playChords();
      } else if (type === 'nebula') {
        // Deep evolving stellar pad drone
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(180, this.ctx.currentTime);
        filter.connect(this.masterGain);

        const osc1 = this.ctx.createOscillator();
        osc1.type = 'sawtooth';
        osc1.frequency.setValueAtTime(110, this.ctx.currentTime); // A2

        const osc2 = this.ctx.createOscillator();
        osc2.type = 'sawtooth';
        osc2.frequency.setValueAtTime(165, this.ctx.currentTime); // E3

        const gain1 = this.ctx.createGain();
        gain1.gain.setValueAtTime(0.12, this.ctx.currentTime);
        
        const gain2 = this.ctx.createGain();
        gain2.gain.setValueAtTime(0.08, this.ctx.currentTime);

        // Slow filter envelope sweep
        const sweep = () => {
          if (!this.isPlaying || !this.ctx) return;
          const now = this.ctx.currentTime;
          filter.frequency.linearRampToValueAtTime(100 + Math.random() * 220, now + 6);
          const t = setTimeout(sweep, 6000);
          this.timers.push(t);
        };
        sweep();

        osc1.connect(gain1);
        gain1.connect(filter);
        osc2.connect(gain2);
        gain2.connect(filter);

        osc1.start();
        osc2.start();
        this.sources.push(osc1, osc2);
      } else if (type === 'waves') {
        // Organic coastal shore waves
        const bufferSize = 2 * this.ctx.sampleRate;
        const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = Math.random() * 2 - 1;
        }

        const whiteNoise = this.ctx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(300, this.ctx.currentTime);

        const waveGain = this.ctx.createGain();
        waveGain.gain.setValueAtTime(0.08, this.ctx.currentTime);

        whiteNoise.connect(filter);
        filter.connect(waveGain);
        waveGain.connect(this.masterGain);
        whiteNoise.start();
        this.sources.push(whiteNoise);

        // Cyclic volume swells for surf rhythm
        const modulateSurf = () => {
          if (!this.isPlaying || !this.ctx) return;
          const now = this.ctx.currentTime;
          waveGain.gain.linearRampToValueAtTime(0.04 + Math.random() * 0.28, now + 4.5);
          filter.frequency.linearRampToValueAtTime(120 + Math.random() * 320, now + 4.5);

          const t = setTimeout(modulateSurf, 4500);
          this.timers.push(t);
        };
        modulateSurf();
      }
    } catch (e) {
      console.warn("Audio Context blocked or failed initialization", e);
    }
  }

  setVolume(volume: number) {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.linearRampToValueAtTime(volume / 100, this.ctx.currentTime + 0.1);
    }
  }

  playAlertChime() {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const chimeCtx = new AudioContextClass();
      
      const master = chimeCtx.createGain();
      master.gain.setValueAtTime(0.25, chimeCtx.currentTime);
      master.connect(chimeCtx.destination);

      // Sweet arpeggiated focus chord (C Major Pentatonic)
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = chimeCtx.createOscillator();
        const gain = chimeCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, chimeCtx.currentTime + idx * 0.12);
        
        gain.gain.setValueAtTime(0, chimeCtx.currentTime + idx * 0.12);
        gain.gain.linearRampToValueAtTime(0.12, chimeCtx.currentTime + idx * 0.12 + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, chimeCtx.currentTime + idx * 0.12 + 1.2);
        
        osc.connect(gain);
        gain.connect(master);
        osc.start(chimeCtx.currentTime + idx * 0.12);
        osc.stop(chimeCtx.currentTime + idx * 0.12 + 1.3);
      });
    } catch (e) {
      console.warn("Chime playback failed", e);
    }
  }

  stop() {
    this.isPlaying = false;
    this.timers.forEach(t => clearTimeout(t));
    this.timers = [];
    this.sources.forEach(s => {
      try { s.stop(); } catch (e) {}
    });
    this.sources = [];
    if (this.ctx) {
      try { this.ctx.close(); } catch(e) {}
      this.ctx = null;
    }
    this.masterGain = null;
  }
}

export const PomodoroTimer: React.FC<PomodoroTimerProps> = ({ 
  onSessionComplete,
  theme = 'light' 
}) => {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState({ work: 25, break: 5 });

  // Soundscape states
  const [selectedSoundscape, setSelectedSoundscape] = useState<string>('none');
  const [soundscapeVolume, setSoundscapeVolume] = useState<number>(40);
  const [isSoundscapePlaying, setIsSoundscapePlaying] = useState<boolean>(false);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioEngineRef = useRef<AmbientAudioEngine | null>(null);

  // Initialize audio engine
  useEffect(() => {
    audioEngineRef.current = new AmbientAudioEngine();
    return () => {
      audioEngineRef.current?.stop();
    };
  }, []);

  // Sync volume
  useEffect(() => {
    if (audioEngineRef.current && isSoundscapePlaying) {
      audioEngineRef.current.setVolume(soundscapeVolume);
    }
  }, [soundscapeVolume, isSoundscapePlaying]);

  // Handle ambient synthesis start/stop on soundscape state change
  useEffect(() => {
    if (audioEngineRef.current) {
      if (isSoundscapePlaying && selectedSoundscape !== 'none') {
        audioEngineRef.current.start(selectedSoundscape, soundscapeVolume);
      } else {
        audioEngineRef.current.stop();
      }
    }
  }, [selectedSoundscape, isSoundscapePlaying]);

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleSessionEnd();
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const handleSessionEnd = () => {
    setIsActive(false);
    if (timerRef.current) clearInterval(timerRef.current);
    
    const nextMode = mode === 'work' ? 'break' : 'work';
    setMode(nextMode);
    setTimeLeft(nextMode === 'work' ? settings.work * 60 : settings.break * 60);
    
    if (mode === 'work') {
      setSessionsCompleted(prev => prev + 1);
    }
    
    // Play sweet synthesized gong alert
    audioEngineRef.current?.playAlertChime();
    
    onSessionComplete?.(mode);
    
    // Show system notification
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(mode === 'work' ? 'Work Session Complete!' : 'Break Over!', {
        body: mode === 'work' ? 'Time for a short break.' : 'Back to work!'
      });
    }
  };

  const toggleTimer = () => {
    setIsActive(!isActive);
    // Auto-play soundscape if starting work session
    if (!isActive && selectedSoundscape !== 'none' && !isSoundscapePlaying) {
      setIsSoundscapePlaying(true);
    }
  };

  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === 'work' ? settings.work * 60 : settings.break * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'work' 
    ? (1 - timeLeft / (settings.work * 60)) * 100 
    : (1 - timeLeft / (settings.break * 60)) * 100;

  return (
    <div className="space-y-8 py-4">
      {/* Modes Buttons */}
      <div className="flex justify-center gap-4">
        <button
          onClick={() => {
            setMode('work');
            setTimeLeft(settings.work * 60);
            setIsActive(false);
          }}
          className={cn(
            "px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 shadow-xs",
            mode === 'work' 
              ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100 dark:shadow-none" 
              : "bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700"
          )}
        >
          <Brain size={15} /> Work Focus
        </button>
        <button
          onClick={() => {
            setMode('break');
            setTimeLeft(settings.break * 60);
            setIsActive(false);
          }}
          className={cn(
            "px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 shadow-xs",
            mode === 'break' 
              ? "bg-green-600 text-white shadow-lg shadow-green-100 dark:shadow-none" 
              : "bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700"
          )}
        >
          <Coffee size={15} /> Break Rest
        </button>
      </div>

      {/* Main progress ring clock */}
      <div className="relative w-64 h-64 mx-auto flex items-center justify-center">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="128"
            cy="128"
            r="116"
            stroke="currentColor"
            strokeWidth="7"
            fill="transparent"
            className="text-slate-100 dark:text-slate-800"
          />
          <circle
            cx="128"
            cy="128"
            r="116"
            stroke="currentColor"
            strokeWidth="8"
            fill="transparent"
            strokeDasharray={728.85}
            strokeDashoffset={728.85 - (728.85 * progress) / 100}
            strokeLinecap="round"
            className={cn(
              "transition-all duration-1000",
              mode === 'work' ? "text-indigo-600" : "text-green-600"
            )}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center space-y-1">
          <span className="text-5xl font-black font-mono tracking-tighter text-slate-800 dark:text-slate-150">
            {formatTime(timeLeft)}
          </span>
          <span className="text-[9px] font-black text-slate-450 dark:text-slate-450 uppercase tracking-widest flex items-center gap-1">
            {isActive ? (
              <span className="flex h-2 w-2 relative">
                <span className={cn(
                  "animate-ping absolute inline-flex h-full w-full rounded-full opacity-75",
                  mode === 'work' ? "bg-indigo-400" : "bg-green-400"
                )}></span>
                <span className={cn(
                  "relative inline-flex rounded-full h-2 w-2",
                  mode === 'work' ? "bg-indigo-500" : "bg-green-500"
                )}></span>
              </span>
            ) : null}
            {mode} session
          </span>
        </div>
      </div>

      {/* Main Core action trigger keys */}
      <div className="flex justify-center items-center gap-6">
        <button
          onClick={resetTimer}
          className="p-3.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-all active:scale-95"
          title="Reset clock"
        >
          <RotateCcw size={20} />
        </button>
        <button
          onClick={toggleTimer}
          className={cn(
            "p-5.5 rounded-full text-white transition-all shadow-xl hover:scale-105 active:scale-95",
            isActive 
              ? "bg-amber-500 hover:bg-amber-600 shadow-amber-100 dark:shadow-none" 
              : "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100 dark:shadow-none"
          )}
        >
          {isActive ? <Pause size={28} /> : <Play size={28} className="ml-1" />}
        </button>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className={cn(
            "p-3.5 rounded-2xl transition-all active:scale-95",
            showSettings 
              ? "bg-indigo-50 dark:bg-indigo-950 text-indigo-600" 
              : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
          )}
          title="Configure timers"
        >
          <Settings size={20} />
        </button>
      </div>

      {/* IMPRESSIVE PROCEDURAL FOCUS SOUNDSCAPES MODULE */}
      <div className="p-5 border border-slate-150 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 rounded-3xl space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Music className="text-indigo-500" size={16} />
            <span className="text-xs font-extrabold uppercase tracking-widest text-slate-600 dark:text-slate-300">
              Immersive Study Soundscapes
            </span>
          </div>
          <button
            onClick={() => setIsSoundscapePlaying(!isSoundscapePlaying)}
            disabled={selectedSoundscape === 'none'}
            className={cn(
              "px-3 py-1 rounded-lg text-[10px] font-bold uppercase transition-all flex items-center gap-1 border",
              isSoundscapePlaying
                ? "bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border-indigo-200"
                : "bg-slate-100 hover:bg-slate-200 text-slate-500 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700"
            )}
          >
            {isSoundscapePlaying ? <Volume2 size={12} /> : <VolumeX size={12} />}
            {isSoundscapePlaying ? "Playing" : "Muted"}
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {[
            { id: 'none', label: '🔇 Ambient Off', icon: null },
            { id: 'lofi', label: '🎹 Lo-Fi Chords', icon: <Star size={12} /> },
            { id: 'rain', label: '🌧️ Rain Droplets', icon: <CloudRain size={12} /> },
            { id: 'waves', label: '🌊 Coastal Waves', icon: <Waves size={12} /> },
            { id: 'nebula', label: '🌌 Cosmic Nebula', icon: <Star size={12} /> },
            { id: 'binaural', label: '🧠 Binaural Focus', icon: <Brain size={12} /> },
          ].map(sc => (
            <button
              key={sc.id}
              onClick={() => {
                setSelectedSoundscape(sc.id);
                if (sc.id !== 'none') {
                  setIsSoundscapePlaying(true);
                } else {
                  setIsSoundscapePlaying(false);
                }
              }}
              className={cn(
                "p-2.5 text-left text-xs font-bold rounded-xl border transition-all flex items-center gap-2",
                selectedSoundscape === sc.id
                  ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border-indigo-300 dark:border-indigo-900 shadow-xs"
                  : "bg-transparent text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300"
              )}
            >
              {sc.label}
            </button>
          ))}
        </div>

        {selectedSoundscape !== 'none' && (
          <div className="space-y-1.5 pt-2 animate-in fade-in">
            <div className="flex justify-between text-[10px] text-slate-400 font-extrabold uppercase">
              <span>Soundscape Volume</span>
              <span>{soundscapeVolume}%</span>
            </div>
            <div className="flex items-center gap-3">
              <VolumeX size={12} className="text-slate-400" />
              <input
                type="range"
                min="0"
                max="100"
                value={soundscapeVolume}
                onChange={(e) => setSoundscapeVolume(parseInt(e.target.value))}
                className="flex-1 accent-indigo-500 cursor-pointer"
              />
              <Volume2 size={12} className="text-slate-400" />
            </div>
          </div>
        )}
      </div>

      {showSettings && (
        <div className="p-6 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-150 dark:border-slate-800 space-y-4 animate-in fade-in slide-in-from-top-4">
          <h4 className="font-extrabold text-slate-700 dark:text-slate-300 text-xs uppercase tracking-widest">
            Timer Adjustments
          </h4>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Work Session (min)
              </label>
              <input 
                type="number" 
                value={settings.work} 
                onChange={(e) => {
                  const val = Math.max(1, parseInt(e.target.value) || 1);
                  setSettings(prev => ({ ...prev, work: val }));
                  if (mode === 'work') setTimeLeft(val * 60);
                }}
                className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-750 rounded-xl text-sm"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Break Session (min)
              </label>
              <input 
                type="number" 
                value={settings.break} 
                onChange={(e) => {
                  const val = Math.max(1, parseInt(e.target.value) || 1);
                  setSettings(prev => ({ ...prev, break: val }));
                  if (mode === 'break') setTimeLeft(val * 60);
                }}
                className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-750 rounded-xl text-sm"
              />
            </div>
          </div>
        </div>
      )}

      <div className="text-center">
        <p className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
          Completed Pomodoros: {sessionsCompleted}
        </p>
      </div>
    </div>
  );
};
