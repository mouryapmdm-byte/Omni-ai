import React, { useState, useEffect } from 'react';
import { cn } from '../lib/utils';
import { MATH_QUESTIONS } from '../data/mathQuestions';
import { PHYSICS_QUESTIONS } from '../data/physicsQuestions';
import { CHEMISTRY_QUESTIONS } from '../data/chemistryQuestions';
import { BIOLOGY_QUESTIONS } from '../data/biologyQuestions';
import { getBoardCurriculum } from '../data/boards';
import {
  FileText,
  Clock,
  Award,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  RotateCcw,
  Printer,
  Download,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  HelpCircle,
  Check,
  X,
  Target,
  Brain,
  GraduationCap,
  BookOpen,
  Timer,
  Play
} from 'lucide-react';
import { useDifficulty } from '../hooks/useDifficulty';
import { DifficultyTunerCard } from './DifficultyTunerCard';

export interface PracticeExamModuleProps {
  theme?: 'light' | 'dark';
  subject?: 'Mathematics' | 'Physics' | 'Chemistry' | 'Biology';
  onClose?: () => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onRewardXp?: (xp: number) => void;
}

interface ExamQuestion {
  id: string;
  chapterId: string;
  chapterTitle: string;
  section: 'A' | 'B' | 'C' | 'D' | 'E';
  marks: number;
  questionText: string;
  options?: string[];
  correctAnswer: string;
  solution: string;
  subtopicRef: string;
}

export const PracticeExamModule: React.FC<PracticeExamModuleProps> = ({
  theme = 'dark',
  subject = 'Mathematics',
  onClose,
  showNotification,
  onRewardXp
}) => {
  const getQuestionsForSubject = (subj: 'Mathematics' | 'Physics' | 'Chemistry' | 'Biology') => {
    if (subj === 'Mathematics') return MATH_QUESTIONS;
    if (subj === 'Physics') return PHYSICS_QUESTIONS;
    if (subj === 'Chemistry') return CHEMISTRY_QUESTIONS;
    return BIOLOGY_QUESTIONS;
  };
  const curriculum = getBoardCurriculum('India-CBSE', subject, '12');
  const questions = getQuestionsForSubject(subject);

  const [examStarted, setExamStarted] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(10800); // 3 hours in seconds (180 mins)
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [examSubmitted, setExamSubmitted] = useState<boolean>(false);
  const [selectedSection, setSelectedSection] = useState<'ALL' | 'A' | 'B' | 'C' | 'D' | 'E'>('ALL');

  // Timer countdown effect
  useEffect(() => {
    if (!examStarted || examSubmitted) return;
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [examStarted, examSubmitted]);

  /*
    {
      id: 'q6',
      chapterId: 'applications_derivatives',
      chapterTitle: '6. Applications of Derivatives',
      section: 'A',
      marks: 1,
      questionText: 'The function f(x) = x³ - 3x² + 3x - 100 is:',
      options: ['strictly increasing on real numbers R', 'strictly decreasing on real numbers R', 'neither increasing nor decreasing', 'increasing on (-∞, 1) only'],
      correctAnswer: 'strictly increasing on real numbers R',
      solution: "f'(x) = 3(x-1)² ≥ 0 for all real x ∈ R. Since f'(x) > 0 for x ≠ 1, f is strictly increasing.",
      subtopicRef: 'Increasing and decreasing functions'
    },
    {
      id: 'q7',
      chapterId: 'integrals',
      chapterTitle: '7. Integrals',
      section: 'A',
      marks: 1,
      questionText: 'Evaluate ∫ dx / (x² + 2x + 2):',
      options: ['tan⁻¹(x+1) + C', 'log|x² + 2x + 2| + C', '(1/2)tan⁻¹(x+1) + C', '-1/(x+1) + C'],
      correctAnswer: 'tan⁻¹(x+1) + C',
      solution: '∫ dx / ((x+1)² + 1²) = tan⁻¹(x+1) + C.',
      subtopicRef: 'Evaluation of simple integrals of standard types'
    },
    {
      id: 'q8',
      chapterId: 'applications_integrals',
      chapterTitle: '8. Applications of Integrals',
      section: 'A',
      marks: 1,
      questionText: 'The area of the region bounded by the circle x² + y² = 16 is:',
      options: ['4π sq units', '8π sq units', '16π sq units', '32π sq units'],
      correctAnswer: '16π sq units',
      solution: 'Area = π r² = π (4)² = 16π sq units.',
      subtopicRef: 'Area under simple curves'
    },
    {
      id: 'q9',
      chapterId: 'differential_equations',
      chapterTitle: '9. Differential Equations',
      section: 'A',
      marks: 1,
      questionText: 'The order and degree of the differential equation x(d²y/dx²)³ + (dy/dx)⁴ = y³ are:',
      options: ['Order 2, Degree 3', 'Order 2, Degree 4', 'Order 3, Degree 2', 'Order 1, Degree 4'],
      correctAnswer: 'Order 2, Degree 3',
      solution: 'Highest order derivative is d²y/dx² (order 2), and its power is 3 (degree 3).',
      subtopicRef: 'Order and degree of differential equation'
    },
    {
      id: 'q10',
      chapterId: 'vectors',
      chapterTitle: '10. Vectors',
      section: 'A',
      marks: 1,
      questionText: 'If vector a = i + j + k and vector b = i - j, then the angle between them is:',
      options: ['π/3', 'π/2', 'π/4', '2π/3'],
      correctAnswer: 'π/2',
      solution: 'vector a · vector b = 1(1) + 1(-1) + 1(0) = 0. Since the dot product is 0, the angle is π/2.',
      subtopicRef: 'Scalar (dot) product of vectors'
    },
    {
      id: 'q11',
      chapterId: 'three_dimensional_geometry',
      chapterTitle: '11. Three Dimensional Geometry',
      section: 'A',
      marks: 1,
      questionText: 'The direction cosines of a line parallel to the z-axis are:',
      options: ['(1, 1, 1)', '(0, 0, 1)', '(1, 0, 0)', '(0, 1, 0)'],
      correctAnswer: '(0, 0, 1)',
      solution: 'A line parallel to the z-axis makes angles 90°, 90°, 0° with x, y, z axes. Thus cos(90°) = 0, cos(90°) = 0, cos(0°) = 1.',
      subtopicRef: 'Direction cosines and direction ratios'
    },
    {
      id: 'q12',
      chapterId: 'linear_programming',
      chapterTitle: '12. Linear Programming',
      section: 'A',
      marks: 1,
      questionText: 'In a linear programming problem, the objective function is always:',
      options: ['A quadratic function', 'A linear function', 'A rational function', 'An exponential function'],
      correctAnswer: 'A linear function',
      solution: 'The objective function in LPP is a linear function to be maximized or minimized.',
      subtopicRef: 'Terminology: constraints, objective function, optimization'
    },
    {
      id: 'q13',
      chapterId: 'probability',
      chapterTitle: '13. Probability',
      section: 'A',
      marks: 1,
      questionText: 'If P(A) = 3/5 and P(B) = 1/5, and A and B are independent events, then P(A ∩ B) is:',
      options: ['3/25', '4/25', '2/5', '4/5'],
      correctAnswer: '3/25',
      solution: 'For independent events, P(A ∩ B) = P(A) · P(B) = (3/5) × (1/5) = 3/25.',
      subtopicRef: 'Independent events and multiplication theorem'
    },
    {
      id: 'q14',
      chapterId: 'linear_regression',
      chapterTitle: '14. Linear Regression and Correlation',
      section: 'A',
      marks: 1,
      questionText: 'If regression coefficients are b_yx = -1.6 and b_xy = -0.4, the correlation coefficient r is:',
      options: ['0.8', '-0.8', '0.64', '-0.64'],
      correctAnswer: '-0.8',
      solution: 'r = -√(b_yx · b_xy) = -√((-1.6)(-0.4)) = -√(0.64) = -0.8.',
      subtopicRef: 'Properties of regression lines and correlation coefficient'
    },
    {
      id: 'q15',
      chapterId: 'matrices',
      chapterTitle: '3. Matrices',
      section: 'A',
      marks: 1,
      questionText: 'If matrix A is both symmetric and skew-symmetric, then A is a:',
      options: ['Diagonal matrix', 'Zero matrix', 'Identity matrix', 'Scalar matrix'],
      correctAnswer: 'Zero matrix',
      solution: "A = A' (symmetric) and A = -A' (skew-symmetric) ⇒ A = -A ⇒ 2A = 0 ⇒ A = 0.",
      subtopicRef: 'Symmetric and skew-symmetric matrices'
    },
    {
      id: 'q16',
      chapterId: 'determinants',
      chapterTitle: '4. Determinants',
      section: 'A',
      marks: 1,
      questionText: 'If A is an invertible square matrix of order 2, then |A⁻¹| is equal to:',
      options: ['|A|', '1/|A|', '|A|²', '0'],
      correctAnswer: '1/|A|',
      solution: 'Since A · A⁻¹ = I, |A| |A⁻¹| = |I| = 1 ⇒ |A⁻¹| = 1/|A|.',
      subtopicRef: 'Inverse of a square matrix using determinants'
    },
    {
      id: 'q17',
      chapterId: 'continuity_differentiability',
      chapterTitle: '5. Continuity and Differentiability',
      section: 'A',
      marks: 1,
      questionText: 'The derivative of sin(x²) with respect to x² is:',
      options: ['cos(x²)', '2x cos(x²)', '-cos(x²)', '2x sin(x²)'],
      correctAnswer: 'cos(x²)',
      solution: 'Let t = x². d(sin t)/dt = cos t = cos(x²).',
      subtopicRef: 'Derivative of composite functions and chain rule'
    },
    {
      id: 'q18',
      chapterId: 'integrals',
      chapterTitle: '7. Integrals',
      section: 'A',
      marks: 1,
      questionText: 'Evaluate the definite integral from -1 to 1 of x³ cos³(x) dx:',
      options: ['0', '2', '1', 'π'],
      correctAnswer: '0',
      solution: 'The integrand f(x) = x³ cos³(x) is an odd function because f(-x) = -f(x). Hence the integral over [-1, 1] is 0.',
      subtopicRef: 'Properties of definite integrals'
    },
    {
      id: 'q19',
      chapterId: 'vectors',
      chapterTitle: '10. Vectors',
      section: 'A',
      marks: 1,
      questionText: 'Assertion (A): The vectors vector a = 2i - 3j + 5k and vector b = -4i + 6j - 10k are collinear.\nReason (R): Two non-zero vectors vector a and vector b are collinear if vector a = λ vector b for some scalar λ.',
      options: [
        'Both A and R are true and R is the correct explanation of A',
        'Both A and R are true but R is not the correct explanation of A',
        'A is true but R is false',
        'A is false but R is true'
      ],
      correctAnswer: 'Both A and R are true and R is the correct explanation of A',
      solution: 'vector a = (-1/2) vector b, so they are collinear. Reason correctly states the definition.',
      subtopicRef: 'Types of vectors (collinear)'
    },
    {
      id: 'q20',
      chapterId: 'probability',
      chapterTitle: '13. Probability',
      section: 'A',
      marks: 1,
      questionText: 'Assertion (A): If P(A|B) > P(A), then P(B|A) > P(B).\nReason (R): Conditional probability satisfies P(A|B) = P(A ∩ B) / P(B).',
      options: [
        'Both A and R are true and R is the correct explanation of A',
        'Both A and R are true but R is not the correct explanation of A',
        'A is true but R is false',
        'A is false but R is true'
      ],
      correctAnswer: 'Both A and R are true and R is the correct explanation of A',
      solution: 'P(A|B) > P(A) ⇒ P(A ∩ B) > P(A)P(B) ⇒ P(B|A) > P(B) symmetrically. Reason is the standard definition.',
      subtopicRef: 'Conditional probability and Bayes Theorem'
    },

    // --- SECTION B: Q21 to Q25 (5 Very Short Answer questions, 2 marks each) ---
    {
      id: 'q21',
      chapterId: 'inverse_trig',
      chapterTitle: '2. Inverse Trigonometric Functions',
      section: 'B',
      marks: 2,
      questionText: 'Find the value of tan⁻¹(1) + cos⁻¹(-1/2) + sin⁻¹(-1/2).',
      correctAnswer: '3π/4',
      solution: 'tan⁻¹(1) = π/4, cos⁻¹(-1/2) = 2π/3, sin⁻¹(-1/2) = -π/6. Sum = π/4 + 2π/3 - π/6 = (3π + 8π - 2π)/12 = 9π/12 = 3π/4.',
      subtopicRef: 'Principal value branch and elementary properties'
    },
    {
      id: 'q22',
      chapterId: 'continuity_differentiability',
      chapterTitle: '5. Continuity and Differentiability',
      section: 'B',
      marks: 2,
      questionText: 'Find dy/dx if x = a t² and y = 2a t.',
      correctAnswer: '1/t',
      solution: 'dx/dt = 2at, dy/dt = 2a. Then dy/dx = (dy/dt) / (dx/dt) = (2a) / (2at) = 1/t.',
      subtopicRef: 'Derivatives of functions in parametric form'
    },
    {
      id: 'q23',
      chapterId: 'applications_derivatives',
      chapterTitle: '6. Applications of Derivatives',
      section: 'B',
      marks: 2,
      questionText: 'Find the rate of change of the area of a circle with respect to its radius r when r = 6 cm.',
      correctAnswer: '12π cm²/cm',
      solution: 'Area A = π r². Rate of change dA/dr = 2π r. At r = 6, dA/dr = 12π cm²/cm.',
      subtopicRef: 'Rate of change of quantities'
    },
    {
      id: 'q24',
      chapterId: 'vectors',
      chapterTitle: '10. Vectors',
      section: 'B',
      marks: 2,
      questionText: 'Find the projection of vector a = 2i + 3j + 2k on vector b = i + 2j + k.',
      correctAnswer: '10/√6',
      solution: 'Projection = (vector a · vector b) / |vector b| = (2(1) + 3(2) + 2(1)) / √(1 + 4 + 1) = (2 + 6 + 2) / √6 = 10/√6.',
      subtopicRef: 'Scalar (dot) product and projection'
    },
    {
      id: 'q25',
      chapterId: 'three_dimensional_geometry',
      chapterTitle: '11. Three Dimensional Geometry',
      section: 'B',
      marks: 2,
      questionText: 'Find the angle between the lines whose direction ratios are ⟨1, 2, 2⟩ and ⟨-3, 2, 6⟩.',
      correctAnswer: 'cos⁻¹(13/21)',
      solution: 'cos(θ) = (1(-3) + 2(2) + 2(6)) / (√(1+4+4) · √(9+4+36)) = (-3 + 4 + 12) / (3 × 7) = 13/21.',
      subtopicRef: 'Angle between two lines in 3D space'
    },

    // --- SECTION C: Q26 to Q31 (6 Short Answer questions, 3 marks each) ---
    {
      id: 'q26',
      chapterId: 'relations_functions',
      chapterTitle: '1. Relations and Functions',
      section: 'C',
      marks: 3,
      questionText: 'Check whether the relation R defined in the set of real numbers R as R = {(a, b) : a ≤ b³} is reflexive, symmetric or transitive.',
      correctAnswer: 'Neither reflexive, nor symmetric, nor transitive',
      solution: 'Reflexive fails for 1/2 (since 1/2 ≤ (1/2)³ = 1/8 is false). Symmetric fails for (1, 2) since 1 ≤ 8 holds but 2 ≤ 1 does not. Transitive fails for (3, 2) and (2, 1.5).',
      subtopicRef: 'Reflexive, symmetric, transitive relations'
    },
    {
      id: 'q27',
      chapterId: 'determinants',
      chapterTitle: '4. Determinants',
      section: 'C',
      marks: 3,
      questionText: 'Using matrix method, solve the system of linear equations: x - y + 2z = 7, 3x + 4y - 5z = -5, 2x - y + 3z = 12.',
      correctAnswer: 'x = 2, y = 1, z = 3',
      solution: 'Writing as A X = B, find A⁻¹ using adj(A) and |A|. Matrix multiplication gives X = A⁻¹ B = [2, 1, 3]ᵀ.',
      subtopicRef: 'Matrix method for solving system of linear equations'
    },
    {
      id: 'q28',
      chapterId: 'integrals',
      chapterTitle: '7. Integrals',
      section: 'C',
      marks: 3,
      questionText: 'Evaluate the definite integral from 0 to π/2 of (sin x) / (sin x + cos x) dx.',
      correctAnswer: 'π/4',
      solution: 'Using property ∫ [a to b] f(x) dx = ∫ [a to b] f(a+b-x) dx, I = ∫ [0 to π/2] (cos x)/(cos x + sin x) dx. Adding both equations gives 2I = ∫ [0 to π/2] 1 dx = π/2 ⇒ I = π/4.',
      subtopicRef: 'Properties of definite integrals'
    },
    {
      id: 'q29',
      chapterId: 'differential_equations',
      chapterTitle: '9. Differential Equations',
      section: 'C',
      marks: 3,
      questionText: 'Solve the differential equation: dy/dx + y/x = x².',
      correctAnswer: 'x y = x⁴/4 + C',
      solution: 'Linear differential equation with P = 1/x, Q = x². Integrating factor I.F. = e^(∫ 1/x dx) = x. Solution: x y = ∫ x³ dx = x⁴/4 + C.',
      subtopicRef: 'Linear differential equations dy/dx + Py = Q'
    },
    {
      id: 'q30',
      chapterId: 'vectors',
      chapterTitle: '10. Vectors',
      section: 'C',
      marks: 3,
      questionText: 'Find a unit vector perpendicular to each of the vectors (vector a + vector b) and (vector a - vector b), where vector a = i + j + k and vector b = i + 2j + 3k.',
      correctAnswer: '± (-i + 2j - k)/√6',
      solution: 'vector a + vector b = 2i + 3j + 4k, vector a - vector b = -j - 2k. Cross product gives perpendicular vector -2i + 4j - 2k. Dividing by magnitude yields ± (-i + 2j - k)/√6.',
      subtopicRef: 'Vector (cross) product of vectors'
    },
    {
      id: 'q31',
      chapterId: 'probability',
      chapterTitle: '13. Probability',
      section: 'C',
      marks: 3,
      questionText: 'Bag I contains 3 red and 4 black balls, while Bag II contains 5 red and 6 black balls. One ball is drawn at random from one of the bags and it is found to be red. Find the probability that it was drawn from Bag II.',
      correctAnswer: '35/71',
      solution: 'Let E1, E2 be choosing Bag I and Bag II (P(E1) = P(E2) = 1/2). Let A be drawing a red ball. P(A|E1) = 3/7, P(A|E2) = 5/11. By Bayes Theorem, P(E2|A) = ((1/2)(5/11)) / ((1/2)(3/7) + (1/2)(5/11)) = (5/11) / (3/7 + 5/11) = 35 / (33 + 35) = 35/71.',
      subtopicRef: 'Bayes Theorem and total probability'
    },

    // --- SECTION D: Q32 to Q35 (4 Long Answer questions, 5 marks each) ---
    {
      id: 'q32',
      chapterId: 'matrices',
      chapterTitle: '3. Matrices',
      section: 'D',
      marks: 5,
      questionText: 'If matrix A = [[1, -1, 0], [2, 3, 4], [0, 1, 2]], find A⁻¹. Hence, solve the system of equations x - y = 3, 2x + 3y + 4z = 17, y + 2z = 7.',
      correctAnswer: 'x = 2, y = -1, z = 4',
      solution: "Compute |A| = 1(6-4) - (-1)(4-0) = 2 + 4 = 6 ≠ 0. Find cofactors and adjoint. A⁻¹ = (1/6) adj(A). System of equations corresponds to A' X = B, giving solutions.",
      subtopicRef: 'Invertible matrices and matrix method for solving equations'
    },
    {
      id: 'q33',
      chapterId: 'applications_derivatives',
      chapterTitle: '6. Applications of Derivatives',
      section: 'D',
      marks: 5,
      questionText: 'Find the maximum area of an isosceles triangle inscribed in the ellipse x²/a² + y²/b² = 1 with its vertex at one end of the major axis.',
      correctAnswer: '(3√3 / 4) ab',
      solution: 'Set vertex at (a, 0). Other vertices at (-a cos θ, b sin θ) and (-a cos θ, -b sin θ). Area A = (1/2) × base × height = (1/2)(2b sin θ)(a + a cos θ). Maximize A(θ) to get (3√3 / 4) ab.',
      subtopicRef: 'Applied problems on maxima and minima'
    },
    {
      id: 'q34',
      chapterId: 'applications_integrals',
      chapterTitle: '8. Applications of Integrals',
      section: 'D',
      marks: 5,
      questionText: 'Find the area of the region bounded by the parabola y² = 4ax and its latus rectum x = a using integration.',
      correctAnswer: '8a²/3 sq units',
      solution: 'Area = 2 ∫ [0 to a] √(4ax) dx = 4√a ∫ [0 to a] x^(1/2) dx = 4√a [ (x^(3/2)) / (3/2) ] from 0 to a = (8/3) a² sq units.',
      subtopicRef: 'Area under simple curves (parabolas)'
    },
    {
      id: 'q35',
      chapterId: 'three_dimensional_geometry',
      chapterTitle: '11. Three Dimensional Geometry',
      section: 'D',
      marks: 5,
      questionText: 'Find the shortest distance between the lines vector r = (i + 2j + k) + λ(i - j + k) and vector r = (2i - j - k) + μ(2i + j + k).',
      correctAnswer: '4/√3 units',
      solution: 'Use shortest distance formula d = |(vector a2 - vector a1) · (vector b1 × vector b2)| / |vector b1 × vector b2|. Substituting vectors gives 4/√3 units.',
      subtopicRef: 'Shortest distance between two skew lines'
    },

    // --- SECTION E: Q36 to Q38 (3 Case Study-based questions, 4 marks each) ---
    {
      id: 'q36',
      chapterId: 'linear_programming',
      chapterTitle: '12. Linear Programming',
      section: 'E',
      marks: 4,
      questionText: 'Case Study 1: A cooperative society of farmers deals in two crop types X and Y. Profits are ₹50 per acre for crop X and ₹30 per acre for crop Y. Total available land is 80 acres. Weed herbicide constraint requires total herbicide units not to exceed 1000 litres, with crop X taking 10 L/acre and crop Y taking 5 L/acre.\n(i) Formulate the LPP.\n(ii) Find the maximum profit.',
      correctAnswer: 'Max Z = 50x + 30y subject to x+y <= 80, 10x+5y <= 1000, x>=0, y>=0. Max profit = ₹3200 at (40, 40).',
      solution: 'Corner points of feasible region: (0,0), (80,0), (0,200), and intersection of x+y=80 and 10x+5y=1000 (x=40, y=40). Evaluating Z at (40,40) gives 50(40)+30(40) = ₹3200.',
      subtopicRef: 'Mathematical formulation and graphical optimal solution of LPP'
    },
    {
      id: 'q37',
      chapterId: 'probability',
      chapterTitle: '13. Probability',
      section: 'E',
      marks: 4,
      questionText: 'Case Study 2: In an examination, 30% of students failed in Mathematics, 20% failed in Physics, and 10% failed in both Mathematics and Physics. A student is selected at random.\n(i) What is the probability that the student failed in Mathematics given that they failed in Physics?\n(ii) What is the probability that the student failed in Mathematics or Physics?',
      correctAnswer: '(i) 1/2 (0.5), (ii) 0.4',
      solution: 'Let M be failing Math (P(M) = 0.3), P be failing Physics (P(P) = 0.2), P(M ∩ P) = 0.1. (i) P(M|P) = P(M ∩ P)/P(P) = 0.1/0.2 = 1/2. (ii) P(M ∪ P) = P(M) + P(P) - P(M ∩ P) = 0.3 + 0.2 - 0.1 = 0.4.',
      subtopicRef: 'Conditional probability and addition theorem'
    },
    {
      id: 'q38',
      chapterId: 'continuity_differentiability',
      chapterTitle: '5. Continuity and Differentiability',
      section: 'E',
      marks: 4,
      questionText: 'Case Study 3: The motion of a particle along a straight line is given by s(t) = t³ - 6t² + 9t + 4 metres at time t seconds.\n(i) Find the velocity at t = 2 seconds.\n(ii) Find the intervals of time in which the particle is moving strictly forward (increasing motion).',
      correctAnswer: '(i) -3 m/s, (ii) (-∞, 1) ∪ (3, ∞)',
      solution: 'Velocity v(t) = ds/dt = 3t² - 12t + 9. At t = 2, v(2) = 3(4) - 12(2) + 9 = 12 - 24 + 9 = -3 m/s. For increasing motion, v(t) > 0 ⇒ 3(t² - 4t + 3) > 0 ⇒ (t-1)(t-3) > 0 ⇒ t ∈ (-∞, 1) ∪ (3, ∞).',
      subtopicRef: 'Rate of change and increasing/decreasing motion'
    }
  ];
  */

  const [answers, setAnswers] = useState<Record<string, string>>({});
  const {
    difficultyState,
    recordAnswer,
    setLevelManually,
    resetDifficulty,
    dismissIntervention
  } = useDifficulty('student_default', subject ? subject.toLowerCase() : 'general');
  const [scoreResult, setScoreResult] = useState<{
    obtained: number;
    total: number;
    percentage: number;
    passed: boolean;
  } | null>(null);

  const handleSelectOption = (questionId: string, option: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: option }));
    const question = questions.find(q => q.id === questionId);
    if (question) {
      const isCorrect = option.trim().toLowerCase() === question.correctAnswer.trim().toLowerCase();
      recordAnswer(isCorrect);
    }
  };

  const handleSubmitExam = () => {
    let obtained = 0;
    let total = 0;

    questions.forEach(q => {
      total += q.marks;
      const userAns = answers[q.id]?.trim().toLowerCase();
      const correctAns = q.correctAnswer.trim().toLowerCase();
      if (userAns && (userAns === correctAns || userAns.includes(correctAns) || correctAns.includes(userAns))) {
        obtained += q.marks;
      }
    });

    const percentage = Math.round((obtained / total) * 100);
    const passed = percentage >= 33;

    setScoreResult({ obtained, total, percentage, passed });
    setExamSubmitted(true);

    if (passed) {
      const xpEarned = 750;
      onRewardXp?.(xpEarned);
      showNotification?.(`Exam completed successfully! Scored ${percentage}%. Awarded +${xpEarned} XP!`, 'success');
    } else {
      showNotification?.(`Exam submitted. Score: ${percentage}%. Keep practicing!`, 'info');
    }
  };

  const handleResetExam = () => {
    setExamStarted(false);
    setExamSubmitted(false);
    setAnswers({});
    setScoreResult(null);
    setTimeLeft(10800);
  };

  return (
    <div
      className={cn(
        'w-full min-h-full pb-20 px-4 sm:px-6 lg:px-8 transition-colors',
        theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'
      )}
    >
      {/* Header */}
      <div
        className={cn(
          'sticky top-0 z-40 py-4 mb-6 border-b flex flex-wrap items-center justify-between gap-4 backdrop-blur-md',
          theme === 'dark'
            ? 'bg-slate-950/80 border-slate-800/80'
            : 'bg-slate-50/80 border-slate-200/80'
        )}
      >
        <div className="flex items-center gap-3">
          <div
            className={cn(
              'w-10 h-10 rounded-2xl flex items-center justify-center font-bold shadow-sm',
              theme === 'dark'
                ? 'bg-violet-500/20 text-violet-400 border border-violet-500/30'
                : 'bg-violet-600 text-white shadow-violet-200'
            )}
          >
            <GraduationCap size={20} />
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
              India-CBSE {subject} Class 12 Practice Exam (38 Questions)
              <span className="text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider bg-violet-500/10 text-violet-400 border border-violet-500/20">
                Official Exam Paper (80 Marks)
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Complete official board examination paper across all 5 Sections (A, B, C, D, E) pulling from <code className="text-violet-400">src/data/boards.ts</code>.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {examStarted && !examSubmitted && (
            <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-black">
              <Timer size={14} className="animate-pulse" />
              <span>
                Time Left: {Math.floor(timeLeft / 3600)}h {Math.floor((timeLeft % 3600) / 60)}m {timeLeft % 60}s
              </span>
            </div>
          )}

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className={cn(
                'px-4 py-2 rounded-xl text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95',
                'bg-violet-600 hover:bg-violet-500 text-white shadow-violet-600/20'
              )}
            >
              <X size={14} />
              <span>Close Practice Exam</span>
            </button>
          )}
        </div>
      </div>

      {!examStarted ? (
        /* Exam Instructions & Setup View */
        <div className="max-w-4xl mx-auto space-y-6">
          <div
            className={cn(
              'p-8 rounded-3xl border shadow-xl relative overflow-hidden',
              theme === 'dark' ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'
            )}
          >
            <div className="absolute top-0 right-0 transform translate-x-8 -translate-y-8 w-48 h-48 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center gap-3 mb-4">
              <span className="text-xs font-extrabold uppercase tracking-wider px-3 py-1 rounded-full bg-violet-500/10 text-violet-400 border border-violet-500/20">
                CBSE Board Examination Guidelines (Code 041)
              </span>
              <span className="text-xs font-bold text-slate-400">Academic Year 2026-2027</span>
            </div>

            <h2 className="text-2xl font-black tracking-tight mb-3">{subject} (Code: {subject === 'Mathematics' ? '041' : subject === 'Physics' ? '042' : subject === 'Chemistry' ? '043' : '044'}) - Class XII</h2>
            <p className="text-sm text-slate-400 leading-relaxed mb-6">
              This official mock exam paper contains <strong>38 questions</strong> divided into <strong>5 Sections (A, B, C, D, and E)</strong> matching the exact CBSE Class 12 board examination pattern.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-8">
              <div className="p-4 rounded-2xl border bg-slate-950/40 border-slate-800 space-y-1">
                <span className="text-xs font-bold text-slate-400 uppercase">Total Questions</span>
                <p className="text-xl font-black text-violet-400">38 Questions</p>
              </div>
              <div className="p-4 rounded-2xl border bg-slate-950/40 border-slate-800 space-y-1">
                <span className="text-xs font-bold text-slate-400 uppercase">Maximum Marks</span>
                <p className="text-xl font-black text-emerald-400">80 Marks</p>
              </div>
              <div className="p-4 rounded-2xl border bg-slate-950/40 border-slate-800 space-y-1">
                <span className="text-xs font-bold text-slate-400 uppercase">Time Allowed</span>
                <p className="text-xl font-black text-amber-400">3 Hours (180 Mins)</p>
              </div>
              <div className="p-4 rounded-2xl border bg-slate-950/40 border-slate-800 space-y-1">
                <span className="text-xs font-bold text-slate-400 uppercase">Passing Criteria</span>
                <p className="text-xl font-black text-indigo-400">33% (26.5 Marks)</p>
              </div>
            </div>

            <div className="space-y-3 mb-8">
              <h3 className="text-sm font-extrabold text-slate-200 uppercase tracking-wider">Structure of Question Paper:</h3>
              <ul className="list-disc list-inside space-y-2 text-xs text-slate-400 leading-relaxed">
                <li><strong>Section A</strong>: Q1 to Q20 are Multiple Choice Questions (MCQs) and Assertion-Reasoning types carrying 1 mark each (20 Marks).</li>
                <li><strong>Section B</strong>: Q21 to Q25 are Very Short Answer (VSA) type questions carrying 2 marks each (10 Marks).</li>
                <li><strong>Section C</strong>: Q26 to Q31 are Short Answer (SA) type questions carrying 3 marks each (18 Marks).</li>
                <li><strong>Section D</strong>: Q32 to Q35 are Long Answer (LA) type questions carrying 5 marks each (20 Marks).</li>
                <li><strong>Section E</strong>: Q36 to Q38 are Case Study-based questions carrying 4 marks each with internal sub-parts (12 Marks).</li>
              </ul>
            </div>

            {curriculum && (
              <div className="mb-8 p-4 rounded-2xl border bg-slate-950/30 border-slate-800">
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-violet-400 mb-3">
                  Included CBSE Class 12 Curriculum Units ({(curriculum.topics[subject.toLowerCase()]?.length || 0)} Topics):
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {curriculum.topics[subject.toLowerCase()]?.map((topic, index) => (
                    <div key={index} className="flex items-center gap-2 text-xs text-slate-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-violet-500 shrink-0" />
                      <span className="truncate">{topic}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setExamStarted(true)}
                className="px-6 py-3 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-extrabold text-sm tracking-wider uppercase shadow-lg shadow-violet-600/30 flex items-center gap-2 cursor-pointer active:scale-95 transition"
              >
                <Play size={16} className="fill-current" />
                <span>Start Practice Exam Now</span>
              </button>
            </div>
          </div>
        </div>
      ) : !examSubmitted ? (
        /* Active Exam Paper View */
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Section Filter Bar */}
          <div className="flex items-center justify-between gap-2 overflow-x-auto pb-2">
            <div className="flex items-center gap-2">
              {(['ALL', 'A', 'B', 'C', 'D', 'E'] as const).map(sec => (
                <button
                  key={sec}
                  type="button"
                  onClick={() => setSelectedSection(sec)}
                  className={cn(
                    'px-4 py-2 rounded-xl text-xs font-extrabold uppercase tracking-wider transition cursor-pointer',
                    selectedSection === sec
                      ? 'bg-violet-600 text-white shadow-md shadow-violet-600/20'
                      : theme === 'dark'
                      ? 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                      : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                  )}
                >
                  {sec === 'ALL' ? 'All Questions (38)' : `Section ${sec}`}
                </button>
              ))}
            </div>

            <span className="text-xs font-bold text-slate-400">
              Answered: {Object.keys(answers).length} / {questions.length}
            </span>
          </div>

          {/* Real-time Difficulty Auto-Tuner Bar */}
          <DifficultyTunerCard
            state={difficultyState}
            onSetLevel={setLevelManually}
            onReset={resetDifficulty}
            onDismissIntervention={dismissIntervention}
            className="mb-4"
          />

          {/* Question Cards */}
          <div className="space-y-6">
            {questions
              .filter(q => selectedSection === 'ALL' || q.section === selectedSection)
              .map((q, idx) => {
                const isAnswered = !!answers[q.id];
                return (
                  <div
                    key={q.id}
                    className={cn(
                      'p-6 rounded-2xl border transition-all space-y-4',
                      theme === 'dark' ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'
                    )}
                  >
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xs font-black px-2.5 py-1 rounded-lg bg-violet-500/10 text-violet-400 border border-violet-500/20">
                          Q{questions.indexOf(q) + 1} • Section {q.section}
                        </span>
                        <span className="text-xs font-bold text-slate-400">
                          {q.chapterTitle}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-extrabold text-amber-400">
                          [{q.marks} {q.marks === 1 ? 'Mark' : 'Marks'}]
                        </span>
                        {isAnswered && (
                          <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 size={13} />
                            Answered
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="text-sm font-bold text-slate-100 leading-relaxed whitespace-pre-line">
                      {q.questionText}
                    </p>

                    {q.options ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                        {q.options.map((opt, oIdx) => {
                          const isSelected = answers[q.id] === opt;
                          return (
                            <button
                              key={oIdx}
                              type="button"
                              onClick={() => handleSelectOption(q.id, opt)}
                              className={cn(
                                'p-3.5 rounded-xl border text-left text-xs font-semibold transition cursor-pointer flex items-center gap-3',
                                isSelected
                                  ? 'bg-violet-600/20 border-violet-500 text-violet-200'
                                  : theme === 'dark'
                                  ? 'bg-slate-950/50 border-slate-800 text-slate-300 hover:border-slate-700'
                                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                              )}
                            >
                              <span
                                className={cn(
                                  'w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black shrink-0',
                                  isSelected
                                    ? 'bg-violet-600 text-white'
                                    : 'bg-slate-800 text-slate-400'
                                )}
                              >
                                {String.fromCharCode(65 + oIdx)}
                              </span>
                              <span>{opt}</span>
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="pt-2">
                        <textarea
                          rows={3}
                          value={answers[q.id] || ''}
                          onChange={e => handleSelectOption(q.id, e.target.value)}
                          placeholder="Type your step-by-step solution / final answer here..."
                          className={cn(
                            'w-full p-3.5 rounded-xl text-xs border outline-none font-medium transition',
                            theme === 'dark'
                              ? 'bg-slate-950 border-slate-800 text-slate-200 focus:border-violet-500'
                              : 'bg-slate-50 border-slate-200 text-slate-800 focus:border-violet-500'
                          )}
                        />
                      </div>
                    )}
                  </div>
                );
              })}
          </div>

          {/* Submit Exam Action Bar */}
          <div className="p-6 rounded-t-2xl border-t border-slate-800 bg-slate-900/95 flex items-center justify-between gap-4 sticky bottom-0 backdrop-blur-md shadow-2xl z-50">
            <div className="flex-1">
              <input
                type="text"
                placeholder="Search questions..."
                className="w-full p-3 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 text-xs outline-none focus:border-violet-500"
                onChange={(e) => {
                  // Implement search logic here
                  console.log("Search:", e.target.value);
                }}
              />
            </div>
            <div className="flex items-center gap-4">
              <div>
                <p className="text-xs font-extrabold text-slate-300">Ready to submit your paper?</p>
                <p className="text-[10px] text-slate-400">Make sure all 38 questions are answered before submission.</p>
              </div>
              <button
                type="button"
                onClick={handleSubmitExam}
                className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-600/30 flex items-center gap-2 cursor-pointer active:scale-95 transition"
              >
                <CheckCircle2 size={16} />
                <span>Submit & Evaluate Paper</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Exam Score & Detailed Solutions Report View */
        <div className="max-w-4xl mx-auto space-y-6">
          {scoreResult && (
            <div
              className={cn(
                'p-8 rounded-3xl border shadow-2xl relative overflow-hidden text-center space-y-4',
                scoreResult.passed
                  ? theme === 'dark'
                    ? 'bg-gradient-to-b from-emerald-950/40 to-slate-900 border-emerald-500/30'
                    : 'bg-emerald-50 border-emerald-200'
                  : theme === 'dark'
                  ? 'bg-gradient-to-b from-rose-950/40 to-slate-900 border-rose-500/30'
                  : 'bg-rose-50 border-rose-200'
              )}
            >
              <div className="inline-flex p-4 rounded-full bg-slate-900 border border-slate-800 text-amber-400 mb-2 shadow-inner">
                <Award size={36} />
              </div>

              <h2 className="text-3xl font-black tracking-tight">
                {scoreResult.passed ? '🎉 Congratulations! Exam Passed!' : 'Practice Exam Completed'}
              </h2>
              <p className="text-xs text-slate-400 max-w-lg mx-auto">
                {scoreResult.passed
                  ? 'You successfully met the CBSE Mathematics passing criteria (33%) and earned +750 Mastery XP!'
                  : 'Review the step-by-step solutions below to strengthen your weak areas before the board exam.'}
              </p>

              <div className="flex items-center justify-center gap-6 py-4">
                <div className="text-center">
                  <span className="text-xs font-bold uppercase text-slate-400">Score Obtained</span>
                  <p className="text-3xl font-black text-violet-400">
                    {scoreResult.obtained} / {scoreResult.total} Marks
                  </p>
                </div>
                <div className="w-px h-12 bg-slate-800" />
                <div className="text-center">
                  <span className="text-xs font-bold uppercase text-slate-400">Percentage</span>
                  <p className={cn('text-3xl font-black', scoreResult.passed ? 'text-emerald-400' : 'text-rose-400')}>
                    {scoreResult.percentage}%
                  </p>
                </div>
                <div className="w-px h-12 bg-slate-800" />
                <div className="text-center">
                  <span className="text-xs font-bold uppercase text-slate-400">Result Status</span>
                  <p className={cn('text-lg font-black uppercase mt-1', scoreResult.passed ? 'text-emerald-400' : 'text-rose-400')}>
                    {scoreResult.passed ? 'Passed (A+)' : 'Needs Practice'}
                  </p>
                </div>
              </div>

              <div className="flex justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleResetExam}
                  className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-extrabold uppercase tracking-wider flex items-center gap-2 cursor-pointer transition active:scale-95 shadow-lg shadow-violet-600/20"
                >
                  <RotateCcw size={14} />
                  <span>Retake Practice Exam</span>
                </button>
              </div>
            </div>
          )}

          {/* Detailed Solutions Review */}
          <div className="space-y-4">
            <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2">
              <BookOpen size={18} className="text-violet-400" />
              <span>Comprehensive Solutions & CBSE Subtopic References (38 Questions)</span>
            </h3>

            {questions.map((q, idx) => {
              const userAns = answers[q.id]?.trim().toLowerCase() || '';
              const correctAns = q.correctAnswer.trim().toLowerCase();
              const isCorrect = userAns && (userAns === correctAns || userAns.includes(correctAns) || correctAns.includes(userAns));

              return (
                <div
                  key={q.id}
                  className={cn(
                    'p-6 rounded-2xl border space-y-3',
                    theme === 'dark' ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'
                  )}
                >
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-xs font-bold text-slate-400">
                      Q{idx + 1} • Section {q.section} • {q.chapterTitle}
                    </span>
                    <span
                      className={cn(
                        'text-xs font-black uppercase px-2 py-0.5 rounded-md',
                        isCorrect
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      )}
                    >
                      {isCorrect ? `Correct (+${q.marks} Marks)` : `Incorrect / Review`}
                    </span>
                  </div>

                  <p className="text-sm font-bold text-slate-200 whitespace-pre-line">{q.questionText}</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800">
                      <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Your Answer</span>
                      <p className="font-semibold text-slate-300">{answers[q.id] || '(No Answer Provided)'}</p>
                    </div>
                    <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
                      <span className="text-[10px] font-bold uppercase text-emerald-400 block mb-1">Correct Answer</span>
                      <p className="font-semibold text-emerald-200">{q.correctAnswer}</p>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-violet-950/20 border border-violet-500/30 space-y-1.5">
                    <span className="text-[10px] font-black uppercase tracking-wider text-violet-400 block">
                      CBSE Curriculum Subtopic Reference: {q.subtopicRef}
                    </span>
                    <p className="text-xs text-slate-300 leading-relaxed font-medium">{q.solution}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
