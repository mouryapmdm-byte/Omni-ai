with open('src/App.tsx', 'r') as f:
    code = f.read()

target = """      {/* Floating Screen Resizer Controls */}
      <div className="fixed bottom-[115px] left-1/2 -translate-x-1/2 z-[2500] select-none transition-all duration-300 ease-out opacity-0 hover:opacity-100 scale-95 hover:scale-100 group">
        <div className={cn(
          "flex items-center gap-1 p-1.5 rounded-2xl backdrop-blur-md border shadow-2xl transition-all duration-300",
          theme === 'dark' 
            ? "bg-slate-900/90 border-slate-800/80 hover:border-indigo-500/50 hover:shadow-indigo-505/5" 
            : "bg-white/95 border-slate-200/80 hover:border-indigo-300 hover:shadow-indigo-500/10"
        )}>
          {/* Label / Status Symbol only */}
          <div className="flex items-center px-2 py-1.5 rounded-xl bg-slate-100/50 dark:bg-slate-800/40">
            <Monitor size={14} className="text-indigo-500 dark:text-indigo-400 animate-pulse" />
          </div>

          <div className="h-4 w-[1px] bg-slate-200 dark:bg-slate-800/80 mx-1" />

          {/* Width Tuning: Shrink/Expand Buttons */}
          <div className="flex items-center gap-0.5" title="Page Width adjustment">
            <button
              onClick={() => setContentWidth(prev => Math.max(70, prev - 5))}
              className={cn(
                "p-1.5 rounded-xl transition-all duration-200 flex items-center justify-center cursor-pointer",
                theme === 'dark' 
                  ? "text-slate-400 hover:text-indigo-400 hover:bg-slate-800/60" 
                  : "text-slate-600 hover:text-indigo-600 hover:bg-slate-100"
              )}
              title="Narrow Screen (<)"
            >
              <ChevronLeft size={14} className="stroke-[2.5]" />
            </button>
            <button
              onClick={() => setContentWidth(prev => Math.min(100, prev + 5))}
              className={cn(
                "p-1.5 rounded-xl transition-all duration-200 flex items-center justify-center cursor-pointer",
                theme === 'dark' 
                  ? "text-slate-400 hover:text-indigo-400 hover:bg-slate-800/60" 
                  : "text-slate-600 hover:text-indigo-600 hover:bg-slate-100"
              )}
              title="Widen Screen (>)"
            >
              <ChevronRight size={14} className="stroke-[2.5]" />
            </button>
          </div>

          <div className="h-4 w-[1px] bg-slate-200 dark:bg-slate-800/80 mx-1" />

          {/* Scale Tuning: Zoom Out / Zoom In */}
          <div className="flex items-center gap-0.5" title="Interface zoom level">
            <button
              onClick={() => setZoomLevel(prev => Math.max(0.7, prev - 0.05))}
              className={cn(
                "p-1.5 rounded-xl transition-all duration-200 flex items-center justify-center cursor-pointer",
                theme === 'dark' 
                  ? "text-slate-400 hover:text-indigo-400 hover:bg-slate-800/60" 
                  : "text-slate-600 hover:text-indigo-600 hover:bg-slate-100"
              )}
              title="Zoom Out (-)"
            >
              <Minus size={14} className="stroke-[2.5]" />
            </button>
            <button
              onClick={() => setZoomLevel(prev => Math.min(1.3, prev + 0.05))}
              className={cn(
                "p-1.5 rounded-xl transition-all duration-200 flex items-center justify-center cursor-pointer",
                theme === 'dark' 
                  ? "text-slate-400 hover:text-indigo-400 hover:bg-slate-800/60" 
                  : "text-slate-600 hover:text-indigo-600 hover:bg-slate-100"
              )}
              title="Zoom In (+)"
            >
              <Plus size={14} className="stroke-[2.5]" />
            </button>
          </div>

          <div className="h-4 w-[1px] bg-slate-200 dark:bg-slate-800/80 mx-1" />

          {/* Display & Reset */}
          <button
            onClick={() => {
              setZoomLevel(1);
              setContentWidth(100);
              showNotification('Screen zoom and width reset to defaults', 'info');
            }}
            className={cn(
              "flex items-center gap-1.5 px-2 py-1 rounded-xl transition-all duration-200 group/reset cursor-pointer",
              theme === 'dark'
                ? "bg-indigo-950/40 text-indigo-300 border border-indigo-900/40 hover:bg-indigo-900/40 hover:border-indigo-800"
                : "bg-indigo-50 text-indigo-700 border border-indigo-100 hover:bg-indigo-100/80 hover:border-indigo-200"
            )}
            title="Reset to default (100% Zoom | 100% Width)"
          >
            <span className="text-[10.5px] font-mono font-bold tracking-tight">
              {Math.round(zoomLevel * 100)}% | {contentWidth}%
            </span>
            <RotateCcw size={11} className="transition-transform duration-300 group-hover/reset:rotate-[-60deg] opacity-70" />
          </button>
        </div>
      </div>"""

if target in code:
    with open('src/App.tsx', 'w') as f:
        f.write(code.replace(target, ""))
    print("Patched!")
else:
    print("Target not found")
