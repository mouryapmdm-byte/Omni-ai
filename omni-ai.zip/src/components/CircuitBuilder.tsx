import React, { useState } from "react";
import { cn } from "@/src/lib/utils";

interface Component {
  id: string;
  type: 'battery' | 'resistor' | 'capacitor';
  x: number;
  y: number;
  value: number;
}

export const CircuitBuilder: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [components, setComponents] = useState<Component[]>([]);
  const [selectedType, setSelectedType] = useState<'battery' | 'resistor' | 'capacitor'>('resistor');

  const addComponent = (type: 'battery' | 'resistor' | 'capacitor') => {
    setComponents([...components, { 
      id: Date.now().toString(), 
      type, 
      x: 50 + Math.random() * 200, 
      y: 50 + Math.random() * 150,
      value: 10 
    }]);
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-2">
      <div className="flex gap-2 p-2 border-b flex-wrap text-sm">
        <button className="px-2 py-1 bg-sky-500 text-white rounded" onClick={() => addComponent('battery')}>Battery</button>
        <button className="px-2 py-1 bg-sky-500 text-white rounded" onClick={() => addComponent('resistor')}>Resistor</button>
        <button className="px-2 py-1 bg-sky-500 text-white rounded" onClick={() => addComponent('capacitor')}>Capacitor</button>
        <button className="px-2 py-1 bg-red-500 text-white rounded" onClick={() => setComponents([])}>Clear</button>
      </div>
      <div className="flex-1 border rounded-lg overflow-hidden relative bg-slate-50 dark:bg-slate-900">
        {components.map(comp => (
          <div 
            key={comp.id}
            className="absolute w-16 h-8 border flex items-center justify-center bg-white dark:bg-slate-800 cursor-move"
            style={{ left: comp.x, top: comp.y }}
          >
            {comp.type}
          </div>
        ))}
        <div className="absolute bottom-2 left-2 p-2 bg-slate-200 dark:bg-slate-800 rounded text-xs">
          Multimeter: 0.0V / 0.0A
        </div>
      </div>
    </div>
  );
};
