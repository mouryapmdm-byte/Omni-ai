import React, { useState, useEffect, useMemo } from 'react';
import { 
  HelpCircle, Search, Plus, Filter, ThumbsUp, MessageSquare, ShieldCheck, 
  Sparkles, CheckCircle2, AlertTriangle, ArrowUpDown, X, Image as ImageIcon, 
  Upload, Eye, HeartHandshake, BookOpen, Clock, Lock, Sparkle
} from 'lucide-react';
import { Doubt, DoubtSortOption, DuplicateMatch } from '../modules/doubt-board/types';
import { DoubtService } from '../modules/doubt-board/doubtService';
import { DoubtThread } from './DoubtThread';
import { cn } from '../lib/utils';

interface DoubtBoardProps {
  chapterId?: string;
  chapterTitle?: string;
  topicId?: string;
  topicTitle?: string;
  onClose?: () => void;
  isDark?: boolean;
}

export const DoubtBoard: React.FC<DoubtBoardProps> = ({
  chapterId = 'electromagnetism',
  chapterTitle = 'Electromagnetic Induction',
  topicId,
  topicTitle,
  onClose,
  isDark = true
}) => {
  const [doubts, setDoubts] = useState<Doubt[]>(() => DoubtService.getAllDoubts());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<string>('all');
  const [sortOption, setSortOption] = useState<DoubtSortOption>('recent');
  const [activeDoubt, setActiveDoubt] = useState<Doubt | null>(null);

  // Ask question modal state
  const [isAsking, setIsAsking] = useState(false);
  const [questionText, setQuestionText] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [postTopic, setPostTopic] = useState(topicTitle || 'Core Concepts');
  const [isPosting, setIsPosting] = useState(false);
  const [postError, setPostError] = useState<string | null>(null);

  // Duplicate detection state
  const [duplicateMatches, setDuplicateMatches] = useState<DuplicateMatch[]>([]);
  const [isCheckingDuplicates, setIsCheckingDuplicates] = useState(false);

  // Rate limit
  const rateLimitStatus = useMemo(() => DoubtService.getRateLimitStatus(), [doubts]);

  // Load doubts
  const refreshDoubts = () => {
    setDoubts(DoubtService.getAllDoubts());
  };

  // Live duplicate detection with debounce
  useEffect(() => {
    if (!questionText || questionText.trim().length < 8) {
      setDuplicateMatches([]);
      return;
    }

    const timer = setTimeout(async () => {
      setIsCheckingDuplicates(true);
      const matches = await DoubtService.detectDuplicates(questionText, chapterId);
      setDuplicateMatches(matches);
      setIsCheckingDuplicates(false);
    }, 350);

    return () => clearTimeout(timer);
  }, [questionText, chapterId]);

  // Extract distinct topics for filtering
  const availableTopics = useMemo(() => {
    const topics = new Set<string>();
    doubts.forEach(d => {
      if (d.topicTitle) topics.add(d.topicTitle);
    });
    return Array.from(topics);
  }, [doubts]);

  // Filtered & sorted doubts
  const filteredDoubts = useMemo(() => {
    let result = doubts.filter(d => {
      // If chapter matches or is generic
      const matchesChapter = !chapterId || d.chapterId.toLowerCase() === chapterId.toLowerCase();
      // Topic filter
      const matchesTopic = selectedTopic === 'all' || d.topicTitle === selectedTopic;
      // Search query
      const matchesSearch = !searchQuery.trim() || 
        d.questionText.toLowerCase().includes(searchQuery.toLowerCase()) ||
        d.topicTitle?.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesChapter && matchesTopic && matchesSearch;
    });

    // Sorting
    result.sort((a, b) => {
      if (sortOption === 'recent') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (sortOption === 'upvoted') {
        return b.upvotes - a.upvotes;
      }
      if (sortOption === 'unanswered') {
        return (a.answerCount || 0) - (b.answerCount || 0);
      }
      return 0;
    });

    return result;
  }, [doubts, chapterId, selectedTopic, searchQuery, sortOption]);

  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPostError(null);

    if (!questionText.trim()) return;

    setIsPosting(true);
    const res = await DoubtService.postDoubt({
      chapterId,
      chapterTitle,
      topicId: topicId || 'general',
      topicTitle: postTopic,
      questionText: questionText.trim(),
      imageUrl: imageUrl.trim() || undefined
    });

    setIsPosting(false);

    if (res.error) {
      setPostError(res.error);
    } else if (res.doubt) {
      setQuestionText('');
      setImageUrl('');
      setDuplicateMatches([]);
      setIsAsking(false);
      refreshDoubts();
      setActiveDoubt(res.doubt);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setPostError('Image size should be under 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        setImageUrl(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // If viewing a specific thread
  if (activeDoubt) {
    return (
      <DoubtThread
        doubt={activeDoubt}
        onBack={() => {
          setActiveDoubt(null);
          refreshDoubts();
        }}
        onDoubtUpdated={refreshDoubts}
        isDark={isDark}
      />
    );
  }

  return (
    <div className={cn(
      "w-full rounded-2xl border transition-all p-4 md:p-6 space-y-6 max-w-5xl mx-auto",
      isDark ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-900 shadow-md"
    )}>
      {/* Header with Normalization & Anonymity Pledge */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b pb-5 border-slate-700/50">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <HelpCircle size={18} />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">
              Anonymous Doubt Board
            </h1>
            <span className="text-[11px] px-2 py-0.5 rounded-full font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <Lock size={10} /> 100% Anonymous
            </span>
          </div>
          <p className="text-xs md:text-sm text-slate-400">
            Chapter: <strong className="text-slate-200">{chapterTitle}</strong> • Never hesitate to ask "basic" questions.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          <button
            onClick={() => setIsAsking(true)}
            className="w-full md:w-auto px-4 py-2.5 rounded-xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
          >
            <Plus size={16} />
            <span>Ask Anonymously</span>
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className={cn(
                "p-2 rounded-xl transition-all",
                isDark ? "hover:bg-slate-800 text-slate-400 hover:text-white" : "hover:bg-slate-100 text-slate-500 hover:text-slate-800"
              )}
              title="Close Doubt Board"
            >
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Normalization Banner: Removing Shame */}
      <div className={cn(
        "rounded-xl p-4 border flex items-center gap-3 relative overflow-hidden",
        isDark ? "bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-slate-900 border-indigo-500/30" : "bg-gradient-to-r from-indigo-50 via-purple-50 to-white border-indigo-200"
      )}>
        <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-500/30">
          <HeartHandshake size={20} />
        </div>
        <div className="text-xs md:text-sm space-y-0.5">
          <div className="font-bold text-slate-200 flex items-center gap-1.5">
            <span>Asking is how geniuses are made.</span>
            <span className="text-xs text-indigo-400 font-normal">Over 84% of students share your exact confusion.</span>
          </div>
          <p className="text-slate-400 text-xs">
            Your name and account are stripped. Each post uses a fresh, rotating anonymous codename. Professor Clarity AI answers within 30 seconds!
          </p>
        </div>
      </div>

      {/* Search, Filter, Sort Bar */}
      <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        {/* Search */}
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search doubts or keywords (e.g. Lenz's law, minus sign, heat)..."
            className={cn(
              "w-full pl-10 pr-4 py-2 rounded-xl text-sm border focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all",
              isDark ? "bg-slate-800/80 border-slate-700 text-slate-100 placeholder:text-slate-500" : "bg-white border-slate-300 text-slate-900 placeholder:text-slate-400"
            )}
          />
        </div>

        {/* Topic filter dropdown */}
        <div className="flex items-center gap-2">
          <select
            value={selectedTopic}
            onChange={(e) => setSelectedTopic(e.target.value)}
            className={cn(
              "px-3 py-2 rounded-xl text-xs font-semibold border focus:outline-none focus:ring-2 focus:ring-indigo-500",
              isDark ? "bg-slate-800 border-slate-700 text-slate-200" : "bg-white border-slate-300 text-slate-800"
            )}
          >
            <option value="all">All Topics</option>
            {availableTopics.map(t => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>

          {/* Sort tabs */}
          <div className={cn(
            "p-1 rounded-xl flex items-center border",
            isDark ? "bg-slate-800/80 border-slate-700" : "bg-slate-100 border-slate-300"
          )}>
            <button
              onClick={() => setSortOption('recent')}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition-all",
                sortOption === 'recent'
                  ? isDark ? "bg-indigo-600 text-white" : "bg-white text-indigo-600 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              )}
            >
              Recent
            </button>
            <button
              onClick={() => setSortOption('upvoted')}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition-all",
                sortOption === 'upvoted'
                  ? isDark ? "bg-indigo-600 text-white" : "bg-white text-indigo-600 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              )}
            >
              Upvoted
            </button>
            <button
              onClick={() => setSortOption('unanswered')}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition-all",
                sortOption === 'unanswered'
                  ? isDark ? "bg-indigo-600 text-white" : "bg-white text-indigo-600 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              )}
            >
              Unanswered
            </button>
          </div>
        </div>
      </div>

      {/* Doubts List */}
      <div className="space-y-3.5">
        {filteredDoubts.length === 0 ? (
          <div className={cn(
            "p-12 text-center rounded-2xl border space-y-3",
            isDark ? "bg-slate-800/30 border-slate-800 text-slate-400" : "bg-slate-50 border-slate-200 text-slate-500"
          )}>
            <HelpCircle size={40} className="mx-auto text-indigo-400 opacity-50" />
            <p className="font-bold text-base text-slate-300">No questions found</p>
            <p className="text-xs max-w-md mx-auto">
              Be the first to ask! No question is too basic, and your identity is completely protected.
            </p>
            <button
              onClick={() => setIsAsking(true)}
              className="mt-2 px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-500 transition-all inline-flex items-center gap-1.5"
            >
              <Plus size={14} /> Ask First Doubt
            </button>
          </div>
        ) : (
          filteredDoubts.map((doubt) => {
            const answers = DoubtService.getAnswersForDoubt(doubt.id);
            const verified = answers.find(a => a.answerType === 'professor-verified');
            const ai = answers.find(a => a.answerType === 'ai');

            return (
              <div
                key={doubt.id}
                onClick={() => setActiveDoubt(doubt)}
                className={cn(
                  "group p-4 md:p-5 rounded-xl border transition-all cursor-pointer hover:shadow-md relative overflow-hidden",
                  isDark ? "bg-slate-800/60 hover:bg-slate-800 border-slate-700/80" : "bg-white hover:bg-slate-50 border-slate-200"
                )}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      {doubt.topicTitle || 'General'}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      By {doubt.anonId}
                    </span>
                  </div>

                  {/* Normalization tag */}
                  <div className="text-[11px] font-semibold text-rose-300/90 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20 flex items-center gap-1">
                    <HeartHandshake size={12} className="text-rose-400" />
                    <span>{doubt.confusedCount || 1} students also confused</span>
                  </div>
                </div>

                <h3 className="text-base font-bold text-slate-100 group-hover:text-indigo-400 transition-colors mb-2 line-clamp-2">
                  {doubt.questionText}
                </h3>

                {/* Answer Preview / Highlights */}
                {verified ? (
                  <div className="text-xs text-amber-300/90 bg-amber-500/10 p-2.5 rounded-lg border border-amber-500/20 flex items-start gap-2 mb-3">
                    <ShieldCheck size={14} className="shrink-0 text-amber-400 mt-0.5" />
                    <div className="line-clamp-2">
                      <strong>Verified Answer:</strong> {verified.answerText}
                    </div>
                  </div>
                ) : ai ? (
                  <div className="text-xs text-indigo-300/90 bg-indigo-500/10 p-2.5 rounded-lg border border-indigo-500/20 flex items-start gap-2 mb-3">
                    <Sparkles size={14} className="shrink-0 text-indigo-400 mt-0.5" />
                    <div className="line-clamp-2">
                      <strong>AI Explanation:</strong> {ai.answerText}
                    </div>
                  </div>
                ) : null}

                {/* Card footer */}
                <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-700/40">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <ThumbsUp size={13} className={doubt.userHasUpvoted ? "text-emerald-400" : ""} />
                      <span>{doubt.upvotes} upvotes</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={13} />
                      <span>{doubt.answerCount || answers.length} answers</span>
                    </span>
                    {doubt.imageUrl && (
                      <span className="flex items-center gap-1 text-cyan-400">
                        <ImageIcon size={13} /> Diagram
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1 text-[11px]">
                    <Clock size={12} />
                    <span>{new Date(doubt.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Ask Question Modal */}
      {isAsking && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className={cn(
            "w-full max-w-xl rounded-2xl border shadow-2xl p-6 space-y-4 my-8",
            isDark ? "bg-slate-900 border-slate-700 text-slate-100" : "bg-white border-slate-300 text-slate-900"
          )}>
            <div className="flex items-center justify-between border-b pb-3 border-slate-700/50">
              <div className="flex items-center gap-2">
                <HelpCircle size={20} className="text-indigo-400" />
                <h3 className="text-lg font-bold">Ask an Anonymous Doubt</h3>
              </div>
              <button
                onClick={() => setIsAsking(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X size={18} />
              </button>
            </div>

            {/* Rate limit status info */}
            <div className="flex items-center justify-between text-xs px-3 py-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-300">
              <span>Rate Limit: Max 5 questions/day</span>
              <span className="font-bold font-mono">
                {rateLimitStatus.remainingToday}/{rateLimitStatus.maxPerDay} remaining today
              </span>
            </div>

            {postError && (
              <div className="text-xs text-rose-400 bg-rose-500/10 p-3 rounded-lg border border-rose-500/20 flex items-center gap-2">
                <AlertTriangle size={15} className="shrink-0" />
                <span>{postError}</span>
              </div>
            )}

            <form onSubmit={handlePostSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Topic / Subtopic
                </label>
                <input
                  type="text"
                  value={postTopic}
                  onChange={(e) => setPostTopic(e.target.value)}
                  placeholder="e.g. Lenz's Law, Conservation of Energy"
                  className={cn(
                    "w-full px-3 py-2 rounded-lg text-sm border focus:outline-none focus:ring-2 focus:ring-indigo-500",
                    isDark ? "bg-slate-800 border-slate-700 text-slate-100" : "bg-slate-50 border-slate-300 text-slate-900"
                  )}
                  maxLength={60}
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Your Question (Max 500 chars)
                  </label>
                  <span className={cn(
                    "text-[11px] font-mono",
                    questionText.length > 450 ? "text-amber-400 font-bold" : "text-slate-400"
                  )}>
                    {questionText.length}/500
                  </span>
                </div>
                <textarea
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  placeholder="State your doubt clearly... (e.g. Why does the induced magnetic field always oppose the movement in Lenz's law?)"
                  maxLength={500}
                  rows={4}
                  required
                  className={cn(
                    "w-full p-3 rounded-lg text-sm border focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none",
                    isDark ? "bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500" : "bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400"
                  )}
                />
              </div>

              {/* LIVE DUPLICATE DETECTION BANNER (>80% accuracy) */}
              {isCheckingDuplicates && (
                <div className="text-xs text-indigo-400 flex items-center gap-1.5 animate-pulse">
                  <Sparkles size={13} />
                  <span>Checking for similar doubts across chapter database...</span>
                </div>
              )}

              {duplicateMatches.length > 0 && (
                <div className={cn(
                  "p-3 rounded-xl border space-y-2 text-xs",
                  isDark ? "bg-amber-950/30 border-amber-500/40 text-amber-200" : "bg-amber-50 border-amber-300 text-amber-900"
                )}>
                  <div className="flex items-center gap-2 font-bold text-amber-300">
                    <Sparkles size={14} className="text-amber-400" />
                    <span>Similar question already asked ({duplicateMatches[0].similarityScore}% match):</span>
                  </div>
                  <p className="italic font-medium">"{duplicateMatches[0].doubt.questionText}"</p>
                  {duplicateMatches[0].topAnswer && (
                    <div className="text-[11px] bg-black/20 p-2 rounded border border-amber-500/20">
                      <strong>Existing Answer:</strong> {duplicateMatches[0].topAnswer.answerText.slice(0, 120)}...
                    </div>
                  )}
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-amber-300/80">Checking existing answers reduces clutter!</span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAsking(false);
                        setActiveDoubt(duplicateMatches[0].doubt);
                      }}
                      className="px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-all text-[11px]"
                    >
                      View Existing Answer
                    </button>
                  </div>
                </div>
              )}

              {/* Optional Diagram Upload / URL */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Optional Diagram or Figure
                </label>
                <div className="flex items-center gap-2">
                  <label className={cn(
                    "px-3 py-2 rounded-lg text-xs font-semibold border cursor-pointer flex items-center gap-1.5 transition-all",
                    isDark ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-300" : "bg-slate-100 border-slate-300 hover:bg-slate-200 text-slate-700"
                  )}>
                    <Upload size={13} /> Upload File
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                  <input
                    type="url"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="Or paste image URL (https://...)"
                    className={cn(
                      "flex-1 px-3 py-2 rounded-lg text-xs border focus:outline-none focus:ring-2 focus:ring-indigo-500",
                      isDark ? "bg-slate-800 border-slate-700 text-slate-100" : "bg-slate-50 border-slate-300 text-slate-900"
                    )}
                  />
                </div>
                {imageUrl && (
                  <div className="mt-2 relative inline-block">
                    <img src={imageUrl} alt="Diagram preview" className="h-16 rounded border border-slate-600 object-cover" />
                    <button
                      type="button"
                      onClick={() => setImageUrl('')}
                      className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full p-0.5 text-[10px]"
                    >
                      <X size={10} />
                    </button>
                  </div>
                )}
              </div>

              {/* Anonymous Guarantee & Submit */}
              <div className="pt-2 border-t border-slate-700/50 flex flex-col md:flex-row items-center justify-between gap-3">
                <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                  <Lock size={12} className="text-emerald-400" />
                  <span>Will post as <strong>{DoubtService.getRotatingAnonId()}</strong></span>
                </div>

                <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                  <button
                    type="button"
                    onClick={() => setIsAsking(false)}
                    className={cn(
                      "px-3 py-2 rounded-lg text-xs font-semibold",
                      isDark ? "hover:bg-slate-800 text-slate-400" : "hover:bg-slate-100 text-slate-600"
                    )}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isPosting || !questionText.trim() || !rateLimitStatus.allowed}
                    className="px-4 py-2 rounded-lg text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition-all disabled:opacity-50 cursor-pointer flex items-center gap-1.5 shadow-md"
                  >
                    {isPosting ? 'Posting & Triggering AI...' : 'Post Anonymous Question'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
