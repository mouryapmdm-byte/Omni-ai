import { StreamingEdgeCaseHandler } from './StreamingEdgeCaseHandler';

/**
 * StreamingBuffer
 * Buffers streaming text and releases safe-to-render markdown/LaTeX blocks.
 * Incomplete tokens stay hidden until they can render cleanly without syntax flashing.
 */
export class StreamingBuffer {
  private rawBuffer = '';
  private safeContent = '';
  private pendingContent = '';

  /**
   * Append a new chunk from AI streaming or typewriter.
   * Returns content that is safe to render immediately.
   */
  append(chunk: string): string {
    this.rawBuffer += chunk;
    this.processBuffer();
    return this.safeContent;
  }

  /**
   * Process raw buffer and calculate safe vs. pending content boundary.
   */
  private processBuffer(): void {
    const safeBoundary = this.findSafeBoundary(this.rawBuffer);
    const unicodeSafeBoundary = StreamingEdgeCaseHandler.safeUnicodeSplit(this.rawBuffer, safeBoundary);

    this.safeContent = this.rawBuffer.substring(0, unicodeSafeBoundary);
    this.pendingContent = this.rawBuffer.substring(unicodeSafeBoundary);
  }

  /**
   * Find the last character index that is structurally safe to render.
   */
  private findSafeBoundary(text: string): number {
    let lastSafeIndex = text.length;

    // 1. Incomplete code fences (```)
    const codeFenceCount = (text.match(/```/g) || []).length;
    if (codeFenceCount % 2 !== 0) {
      const idx = text.lastIndexOf('```');
      if (idx !== -1) lastSafeIndex = Math.min(lastSafeIndex, idx);
    }

    // 2. Incomplete display math ($$...$$)
    const displayMathMatches = text.match(/\$\$/g) || [];
    if (displayMathMatches.length % 2 !== 0) {
      const idx = text.lastIndexOf('$$');
      if (idx !== -1) lastSafeIndex = Math.min(lastSafeIndex, idx);
    }

    // 3. Incomplete inline math ($...$)
    const inlineMathBounds = this.findInlineMathBoundaries(text);
    if (inlineMathBounds.incomplete) {
      lastSafeIndex = Math.min(lastSafeIndex, inlineMathBounds.startIndex);
    }

    // 4. Incomplete LaTeX delimiters \( ... \) or \[ ... \]
    const openParenMath = (text.match(/\\\(/g) || []).length;
    const closeParenMath = (text.match(/\\\)/g) || []).length;
    if (openParenMath > closeParenMath) {
      const idx = text.lastIndexOf('\\(');
      if (idx !== -1) lastSafeIndex = Math.min(lastSafeIndex, idx);
    }

    const openBracketMath = (text.match(/\\\[/g) || []).length;
    const closeBracketMath = (text.match(/\\\]/g) || []).length;
    if (openBracketMath > closeBracketMath) {
      const idx = text.lastIndexOf('\\[');
      if (idx !== -1) lastSafeIndex = Math.min(lastSafeIndex, idx);
    }

    // 5. Incomplete markdown headers (e.g. trailing "####", "###", "##", "#" or "#### (क)")
    const trailingHeaderMatch = text.match(/(?:^|\n)(#{1,6}\s*[^\n]*)$/);
    if (trailingHeaderMatch) {
      const startIdx = text.lastIndexOf(trailingHeaderMatch[0]);
      const endIdx = startIdx + trailingHeaderMatch[0].length;
      if (endIdx === text.length && !text.endsWith('\n')) {
        // Still streaming header line — hide until newline or completed text
        // If header has actual text and not just raw hash tokens, allow it or wait for newline
        const hashOnly = trailingHeaderMatch[0].replace(/^[\n\r]+/, '').trim();
        if (/^#{1,6}(\s*\([a-zA-Z0-9\u0900-\u097F]+\))?\s*$/.test(hashOnly)) {
          lastSafeIndex = Math.min(lastSafeIndex, startIdx);
        }
      }
    }

    // 6. Incomplete bold (**...**)
    const boldCount = (text.match(/\*\*/g) || []).length;
    if (boldCount % 2 !== 0) {
      const idx = text.lastIndexOf('**');
      if (idx !== -1) lastSafeIndex = Math.min(lastSafeIndex, idx);
    }

    // 7. Incomplete italic (*...*)
    const italicMatches = text.match(/(?<!\*)\*(?!\*)/g) || [];
    if (italicMatches.length % 2 !== 0) {
      const idx = text.lastIndexOf('*');
      if (idx !== -1) lastSafeIndex = Math.min(lastSafeIndex, idx);
    }

    // 8. Partial table boundary
    const tableBoundary = StreamingEdgeCaseHandler.findPartialTable(text);
    if (tableBoundary < text.length) {
      lastSafeIndex = Math.min(lastSafeIndex, tableBoundary);
    }

    // 9. Nested markdown check
    const nestedBoundary = StreamingEdgeCaseHandler.findNestedMarkdown(text);
    if (nestedBoundary < text.length) {
      lastSafeIndex = Math.min(lastSafeIndex, nestedBoundary);
    }

    // 10. Incomplete bracketed system/meta directive tag e.g. "[AVATAR: turn_to_smartboard" or "[SMARTBOARD:"
    const openBracketTagMatch = text.match(/\[\s*(?:AVATAR|SMARTBOARD|ANIMATION|FIGURE|ELEMENT|COMPLETE|CONNECTION|COMPARATIVE|LAYERED|INTERACTIVE|EXAM|DYNAMIC|STEP|PHASE|STAGE|DRAW|TYPE|SCROLL|PAUSE|LABEL|SPOTLIGHT|HIGHLIGHT|ZOOM|AUDIO|CAMERA|ACTION|SYNC|SCENE|NOTE|DIRECTIVE|PROMPT|TRIGGER|GESTURE|EXPRESSION|ZONE|INSTRUCTION|[A-Z0-9_]{3,})\b[^\]]*$/i);
    if (openBracketTagMatch) {
      const idx = text.lastIndexOf(openBracketTagMatch[0]);
      if (idx !== -1) lastSafeIndex = Math.min(lastSafeIndex, idx);
    }

    return Math.max(0, lastSafeIndex);
  }

  /**
   * Find boundaries for unclosed inline math ($...$).
   */
  private findInlineMathBoundaries(text: string): { incomplete: boolean; startIndex: number } {
    // Remove escaped dollar signs and display math pairs
    const cleaned = text.replace(/\\\$/g, '').replace(/\$\$/g, '  ');

    const dollarIndices: number[] = [];
    for (let i = 0; i < cleaned.length; i++) {
      if (cleaned[i] === '$') {
        dollarIndices.push(i);
      }
    }

    if (dollarIndices.length % 2 !== 0) {
      return {
        incomplete: true,
        startIndex: dollarIndices[dollarIndices.length - 1],
      };
    }

    return { incomplete: false, startIndex: -1 };
  }

  /**
   * Get pending content waiting for completion.
   */
  getPending(): string {
    return this.pendingContent;
  }

  /**
   * Get current safe content.
   */
  getSafeContent(): string {
    return this.safeContent;
  }

  /**
   * Get the full raw buffer.
   */
  getRawBuffer(): string {
    return this.rawBuffer;
  }

  /**
   * Flush all buffered text when stream completes.
   */
  flush(): string {
    this.safeContent = this.rawBuffer;
    this.pendingContent = '';
    return this.safeContent;
  }

  /**
   * Reset the buffer for a new stream session.
   */
  reset(): void {
    this.rawBuffer = '';
    this.safeContent = '';
    this.pendingContent = '';
  }

  /**
   * Calculates the next character pointer jump for typewriter animation.
   * Atomically steps over Markdown tokens (####, **, $$, \() and LaTeX command names
   * so they are never typed out character-by-character as raw syntax.
   */
  static getNextSafeTypewriterStep(text: string, currentPointer: number, defaultStep = 1): number {
    if (currentPointer >= text.length) return text.length;

    const remaining = text.substring(currentPointer);

    // 1. Markdown Heading markers: jump across "#### ", "### ", "## ", "# ", "#### (क) ", etc.
    const headingMatch = remaining.match(/^#{1,6}(?:\s+|\s*\([a-zA-Z0-9\u0900-\u097F]+\)\s*)?/);
    if (headingMatch && headingMatch[0].length > 0) {
      return currentPointer + headingMatch[0].length;
    }

    // 2. Section Bullet markers like "(क) ", "(ख) ", "(1) ", "(A) ", "- ", "* ", "1. "
    const bulletMatch = remaining.match(/^(?:\([a-zA-Z0-9\u0900-\u097F]+\)\s*|[-*]\s+|\d+\.\s+)/);
    if (bulletMatch && bulletMatch[0].length > 0) {
      return currentPointer + bulletMatch[0].length;
    }

    // 3. Bold / Italic markers: jump across bold phrases atomically if closed
    if (remaining.startsWith('**')) {
      const closingIdx = remaining.indexOf('**', 2);
      if (closingIdx !== -1 && closingIdx <= 60) {
        return currentPointer + closingIdx + 2;
      }
      return currentPointer + 2;
    }
    const styleMatch = remaining.match(/^(?:\*{1,3}|_{1,3})/);
    if (styleMatch && styleMatch[0].length > 0) {
      return currentPointer + styleMatch[0].length;
    }

    // 4. Display Math & Inline Math delimiters: jump across entire math blocks atomically
    if (remaining.startsWith('$$')) {
      const closingIdx = remaining.indexOf('$$', 2);
      if (closingIdx !== -1) {
        return currentPointer + closingIdx + 2;
      }
      return currentPointer + 2;
    }
    if (remaining.startsWith('$')) {
      const closingIdx = remaining.indexOf('$', 1);
      if (closingIdx !== -1) {
        return currentPointer + closingIdx + 1;
      }
      return currentPointer + 1;
    }

    // 5. LaTeX delimiters: jump across "\(" or "\[" or "\)" or "\]"
    if (remaining.startsWith('\\(')) {
      const closingIdx = remaining.indexOf('\\)');
      if (closingIdx !== -1) {
        return currentPointer + closingIdx + 2;
      }
      return currentPointer + 2;
    }
    if (remaining.startsWith('\\[')) {
      const closingIdx = remaining.indexOf('\\]');
      if (closingIdx !== -1) {
        return currentPointer + closingIdx + 2;
      }
      return currentPointer + 2;
    }
    if (remaining.startsWith('\\)') || remaining.startsWith('\\]')) {
      return currentPointer + 2;
    }

    // 6. LaTeX commands: jump across "\frac{", "\sqrt{", "\text{", "\mathbf{", "\vec{", "\hat{", "\alpha", "\beta", "\nu", "\lambda", etc.
    const latexCmdMatch = remaining.match(/^\\[a-zA-Z]+(?:\{)?/);
    if (latexCmdMatch && latexCmdMatch[0].length > 0) {
      return currentPointer + latexCmdMatch[0].length;
    }

    // 7. Math superscripts and subscripts: jump across "^2", "^3", "^{...}", "_0", "_{max}", etc.
    const mathSubSupMatch = remaining.match(/^[\^_](?:\{[^}]*\}|[a-zA-Z0-9+-]+)/);
    if (mathSubSupMatch && mathSubSupMatch[0].length > 0) {
      return currentPointer + mathSubSupMatch[0].length;
    }

    // 8. Code fence / backtick tokens
    const codeMatch = remaining.match(/^(?:```[a-zA-Z]*\n?|`)/);
    if (codeMatch && codeMatch[0].length > 0) {
      return currentPointer + codeMatch[0].length;
    }

    // 9. Inline SVG blocks or HTML tags: jump across entire tag if encountered
    if (remaining.startsWith('<svg')) {
      const svgEnd = remaining.indexOf('</svg>');
      if (svgEnd !== -1) {
        return currentPointer + svgEnd + 6;
      }
    } else if (remaining.startsWith('<')) {
      const tagEnd = remaining.indexOf('>');
      if (tagEnd !== -1 && tagEnd <= 40) {
        return currentPointer + tagEnd + 1;
      }
    }

    // Default step forward (1 or 2 chars for natural pace)
    return Math.min(text.length, currentPointer + defaultStep);
  }

  /**
   * Instant sanitizer for live typewriter display strings.
   * Converts in-flight partial markdown/LaTeX text into clean visual text with zero raw syntax flashing.
   */
  static sanitizeLiveStreamText(text: string): string {
    if (!text) return '';

    let clean = text;

    // 0. Strip complete and incomplete internal system directive tags, stage directions, and prompt meta-tags
    clean = clean.replace(/\[\s*(?:SMARTBOARD|AVATAR|ANIMATION|FIGURE|ELEMENT|COMPLETE|CONNECTION|COMPARATIVE|LAYERED|INTERACTIVE|EXAM|DYNAMIC|STEP|PHASE|STAGE|DRAW|TYPE|SCROLL|PAUSE|LABEL|SPOTLIGHT|HIGHLIGHT|ZOOM|AUDIO|CAMERA|ACTION|SYNC|SCENE|NOTE|DIRECTIVE|PROMPT|TRIGGER|GESTURE|EXPRESSION|ZONE|INSTRUCTION)\b[^\]]*\]/gi, '');
    clean = clean.replace(/\[[A-Z0-9_\-\s]{2,}\]/g, '');
    clean = clean.replace(/\[[^\]\n]{1,120}\|[^\]\n]{1,120}\]/g, '');
    clean = clean.replace(/(?:^|\n)\s*(?:❌\s*READING:[^\n]*|✅\s*TEACHING:\s*)/gi, '$1');
    clean = clean.replace(/(?:^|\n)\s*Directive:\s*[^\n]*/gi, '$1');
    clean = clean.replace(/\[\s*(?:AVATAR|SMARTBOARD|ANIMATION|FIGURE|ELEMENT|COMPLETE|CONNECTION|COMPARATIVE|LAYERED|INTERACTIVE|EXAM|DYNAMIC|STEP|PHASE|STAGE|DRAW|TYPE|SCROLL|PAUSE|LABEL|SPOTLIGHT|HIGHLIGHT|ZOOM|AUDIO|CAMERA|ACTION|SYNC|SCENE|NOTE|DIRECTIVE|PROMPT|TRIGGER|GESTURE|EXPRESSION|ZONE|INSTRUCTION|[A-Z0-9_]{3,})\b[^\]]*$/gi, '');

    // 1. Remove dangling trailing markdown hashes on empty/incomplete lines (e.g. "#### ", "###", "##", "#", "#### (")
    clean = clean.replace(/(?:^|\n)[ \t]*#{1,6}\s*(?:\([a-zA-Z0-9\u0900-\u097F]*\)?\s*)?$/g, '');
    clean = clean.replace(/^[ \t]+(#{1,6})\s+/gm, '$1 ');
    clean = clean.replace(/^([ \t]*[-*+•]\s*)#{1,6}\s*/gm, '$1');

    // 2. Handle trailing unclosed bold/italic markers (*, **, ***, _, __, ___)
    if (clean.endsWith('*') && !clean.endsWith('**') && !clean.endsWith('***')) {
      clean = clean.slice(0, -1);
    }
    if (clean.endsWith('_') && !clean.endsWith('__') && !clean.endsWith('___')) {
      clean = clean.slice(0, -1);
    }

    // Auto-balance unclosed ** so text renders bold immediately without raw asterisks
    const boldMatches = clean.match(/\*\*/g) || [];
    if (boldMatches.length % 2 !== 0) {
      const lastBoldIdx = clean.lastIndexOf('**');
      if (lastBoldIdx !== -1) {
        const boldContent = clean.substring(lastBoldIdx + 2);
        if (boldContent.length === 0) {
          // Just "**" at the end -> hide it until content arrives
          clean = clean.substring(0, lastBoldIdx);
        } else {
          // Auto-close with virtual **
          clean = clean + '**';
        }
      }
    }

    // 3. Handle unclosed Display Math ($$...$$): HIDE in-flight equation until closed so broken LaTeX never flashes
    const displayMathMatches = clean.match(/\$\$/g) || [];
    if (displayMathMatches.length % 2 !== 0) {
      const lastDisplayIdx = clean.lastIndexOf('$$');
      if (lastDisplayIdx !== -1) {
        clean = clean.substring(0, lastDisplayIdx);
      }
    }

    // 4. Handle unclosed Inline Math ($...$): HIDE in-flight inline math until closed
    const withoutDisplay = clean.replace(/\\\$/g, '').replace(/\$\$/g, '  ');
    const inlineDollarCount = (withoutDisplay.match(/\$/g) || []).length;
    if (inlineDollarCount % 2 !== 0) {
      const lastDollarIdx = clean.lastIndexOf('$');
      if (lastDollarIdx !== -1) {
        clean = clean.substring(0, lastDollarIdx);
      }
    }

    // 5. Handle unclosed LaTeX \( ... \)
    const openParenMath = (clean.match(/\\\(/g) || []).length;
    const closeParenMath = (clean.match(/\\\)/g) || []).length;
    if (openParenMath > closeParenMath) {
      const lastIdx = clean.lastIndexOf('\\(');
      if (lastIdx !== -1) {
        const mathBody = clean.substring(lastIdx + 2);
        if (mathBody.trim().length === 0) {
          clean = clean.substring(0, lastIdx);
        } else {
          let safeMath = mathBody.replace(/\\[a-zA-Z]{0,4}$/, '');
          clean = clean.substring(0, lastIdx) + '\\(' + safeMath + '\\)';
        }
      }
    }

    // 6. Handle unclosed LaTeX \[ ... \]
    const openBracketMath = (clean.match(/\\\[/g) || []).length;
    const closeBracketMath = (clean.match(/\\\]/g) || []).length;
    if (openBracketMath > closeBracketMath) {
      const lastIdx = clean.lastIndexOf('\\[');
      if (lastIdx !== -1) {
        const mathBody = clean.substring(lastIdx + 2);
        if (mathBody.trim().length === 0) {
          clean = clean.substring(0, lastIdx);
        } else {
          let safeMath = mathBody.replace(/\\[a-zA-Z]{0,4}$/, '');
          clean = clean.substring(0, lastIdx) + '\\[\n' + safeMath.trim() + '\n\\]';
        }
      }
    }

    // 7. Strip trailing stray backslashes
    clean = clean.replace(/\\+$/g, '');

    return clean;
  }
}
