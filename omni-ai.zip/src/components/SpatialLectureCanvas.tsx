import React, { useState, useEffect, useRef } from 'react';
import { 
  motion, 
  AnimatePresence 
} from 'motion/react';
import { 
  Plus, 
  Trash2, 
  Maximize2, 
  Minimize2, 
  Sliders, 
  Code, 
  Tv, 
  Volume2, 
  Zap, 
  Settings, 
  RefreshCw, 
  Users, 
  Share2, 
  HelpCircle, 
  Boxes, 
  Cpu, 
  Play, 
  Check, 
  Radio, 
  PenTool, 
  Eraser,
  MousePointer,
  Undo2,
  RotateCcw,
  Palette,
  Info,
  Maximize,
  Layers,
  Eye,
  EyeOff,
  X
} from 'lucide-react';
import { CollaborativeWhiteboard } from './CollaborativeWhiteboard';
import { PhysicsSandbox } from './PhysicsSandbox';
import { CircuitBuilder } from './CircuitBuilder';
import { WaveExplorer } from './WaveExplorer';
import { ChemistryLab } from './ChemistryLab';
import { BiologyLab } from './BiologyLab';
import { cn } from '@/src/lib/utils';
import * as THREE from 'three';

// Define the Node interface for spatial widgets
export interface SpatialNode {
  id: string;
  type: 'blackboard' | 'math3d' | 'code' | 'audio_norm' | 'peers' | 'whiteboard' | 'physics' | 'circuit' | 'wave' | 'chemistry' | 'biology';
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  isMaximized?: boolean;
}

export interface DrawingStroke {
  id: string;
  points: { x: number; y: number }[];
  color: string;
  width: number;
  hidden?: boolean;
  timestamp?: number;
}

interface SpatialLectureCanvasProps {
  theme: 'light' | 'dark';
  subject: string;
  topic: string;
  chatContent: string;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  onClose?: () => void;
  isClassroomMode?: boolean;
}

export const SpatialLectureCanvas: React.FC<SpatialLectureCanvasProps> = ({
  theme,
  subject,
  topic,
  chatContent,
  showNotification,
  onClose,
  isClassroomMode
}) => {
  const canvasRef = useRef<HTMLDivElement>(null);
  
  // Lecture synchronized state variables
  const [globalTopic, setGlobalTopic] = useState(topic || "Quantum Mechanics & Differential Equations");
  const [pitchStability, setPitchStability] = useState<number>(98); // % pitch lock
  const [timbrePreset, setTimbrePreset] = useState<'warm' | 'resonant' | 'studio' | 'low-pass'>('resonant');
  const [amplitudeGain, setAmplitudeGain] = useState<number>(1.2); // normalizer gain multiplier
  const [mathFrequency, setMathFrequency] = useState<number>(2.5); // 3D mathematical formula factor
  const [liveCode, setLiveCode] = useState<string>(`// Dynamic Classroom Synchronizer\nfunction syncVisuals(freq) {\n  const wave = Math.sin(freq * Math.PI);\n  console.log("State normalizer updating with amplitude: " + wave.toFixed(4));\n  return wave;\n}\nsyncVisuals(${mathFrequency.toFixed(1)});`);
  const [peersOnline, setPeersOnline] = useState<number>(4);
  const [isAudioFilterActive, setIsAudioFilterActive] = useState<boolean>(true);
  
  // Spatial dragging state variables
  const [nodes, setNodes] = useState<SpatialNode[]>([
    { id: 'node-blackboard', type: 'blackboard', title: 'Chalkboard Core Ledger', x: 40, y: 100, width: 440, height: 320, color: 'emerald' },
    { id: 'node-math3d', type: 'math3d', title: 'Vector Math Visualizer', x: 510, y: 100, width: 400, height: 320, color: 'indigo' },
    { id: 'node-code', type: 'code', title: 'Code Algorithmic Sandbox', x: 40, y: 450, width: 440, height: 300, color: 'slate' },
    { id: 'node-audio-norm', type: 'audio_norm', title: 'Voice Pipeline & Normalizer', x: 510, y: 450, width: 400, height: 300, color: 'rose' },
    { id: 'node-peers', type: 'peers', title: 'Synced Classroom Roster', x: 930, y: 100, width: 280, height: 420, color: 'amber' },
    { id: 'node-physics', type: 'physics', title: 'Physics Sandbox', x: 930, y: 550, width: 400, height: 320, color: 'sky' },
    { id: 'node-circuit', type: 'circuit', title: 'Virtual Circuit Builder', x: 40, y: 800, width: 400, height: 320, color: 'cyan' },
    { id: 'node-wave', type: 'wave', title: 'Wave Interference Explorer', x: 510, y: 800, width: 400, height: 320, color: 'violet' },
    { id: 'node-chemistry', type: 'chemistry', title: 'Molecular & Reaction Engine', x: 930, y: 800, width: 400, height: 320, color: 'emerald' },
    { id: 'node-biology', type: 'biology', title: 'Biology Systems & Process Explorer', x: 40, y: 1150, width: 400, height: 320, color: 'lime' }
  ]);
  
  const [activeDragId, setActiveDragId] = useState<string | null>(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });
  const [connectionPulse, setConnectionPulse] = useState<boolean>(true);

  // Drawing Canvas & Eraser state variables
  const [activeTool, setActiveTool] = useState<'select' | 'pen' | 'eraser'>('select');
  const [strokeColor, setStrokeColor] = useState<string>('#38bdf8');
  const [strokeWidth, setStrokeWidth] = useState<number>(4);
  const [eraserRadius, setEraserRadius] = useState<number>(20);
  const [strokes, setStrokes] = useState<DrawingStroke[]>([]);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [currentStroke, setCurrentStroke] = useState<{ x: number; y: number }[]>([]);
  const [eraserCursorPos, setEraserCursorPos] = useState<{ x: number; y: number } | null>(null);
  const [showStrokeStack, setShowStrokeStack] = useState<boolean>(false);
  const [highlightedStrokeId, setHighlightedStrokeId] = useState<string | null>(null);

  const handleToggleStrokeVisibility = (strokeId: string) => {
    setStrokes(prev => prev.map(s => s.id === strokeId ? { ...s, hidden: !s.hidden } : s));
  };

  const handleToggleAllStrokesVisibility = (hidden: boolean) => {
    setStrokes(prev => prev.map(s => ({ ...s, hidden })));
    showNotification?.(hidden ? "Hidden all strokes" : "Showed all strokes", "info");
  };

  const handleDeleteStroke = (strokeId: string) => {
    setStrokes(prev => prev.filter(s => s.id !== strokeId));
    showNotification?.("Removed stroke from history stack", "info");
  };

  // Shortest distance from point (px, py) to line segment (x1, y1) -> (x2, y2)
  const pointToSegmentDist = (px: number, py: number, x1: number, y1: number, x2: number, y2: number) => {
    const dx = x2 - x1;
    const dy = y2 - y1;
    if (dx === 0 && dy === 0) return Math.hypot(px - x1, py - y1);
    const t = Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)));
    return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
  };

  // Erase specific strokes that contact the eraser cursor at (x, y)
  const eraseStrokesAt = (x: number, y: number) => {
    setStrokes(prevStrokes => {
      let erasedAny = false;
      const remaining = prevStrokes.filter(stroke => {
        if (stroke.points.length === 0) return false;
        if (stroke.points.length === 1) {
          const hit = Math.hypot(x - stroke.points[0].x, y - stroke.points[0].y) <= (eraserRadius + stroke.width / 2);
          if (hit) erasedAny = true;
          return !hit;
        }
        for (let i = 0; i < stroke.points.length - 1; i++) {
          const p1 = stroke.points[i];
          const p2 = stroke.points[i + 1];
          const dist = pointToSegmentDist(x, y, p1.x, p1.y, p2.x, p2.y);
          if (dist <= (eraserRadius + stroke.width / 2)) {
            erasedAny = true;
            return false; // Remove this specific stroke!
          }
        }
        return true;
      });

      if (erasedAny && prevStrokes.length > remaining.length) {
        showNotification?.("Erased stroke from canvas", "info");
      }
      return remaining;
    });
  };

  const strokeToSvgPath = (points: { x: number; y: number }[]) => {
    if (!points || points.length === 0) return '';
    if (points.length === 1) {
      return `M ${points[0].x} ${points[0].y} L ${points[0].x + 0.1} ${points[0].y + 0.1}`;
    }
    let path = `M ${points[0].x} ${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
      path += ` L ${points[i].x} ${points[i].y}`;
    }
    return path;
  };

  const handleUndoStroke = () => {
    if (strokes.length === 0) return;
    setStrokes(prev => prev.slice(0, -1));
    showNotification?.("Undid last stroke.", "info");
  };

  const handleClearAllStrokes = () => {
    if (strokes.length === 0) return;
    setStrokes([]);
    showNotification?.("Cleared all drawing strokes.", "warning");
  };

  const getStageCoords = (e: React.MouseEvent) => {
    if (!canvasRef.current) return { x: 0, y: 0 };
    const rect = canvasRef.current.getBoundingClientRect();
    return {
      x: e.clientX - rect.left + canvasRef.current.scrollLeft,
      y: e.clientY - rect.top + canvasRef.current.scrollTop
    };
  };

  const handleStageMouseDown = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (activeTool === 'select' && (target.closest('button') || target.closest('input') || target.closest('textarea') || target.closest('.rounded-2xl'))) {
      return;
    }

    const coords = getStageCoords(e);
    if (activeTool === 'pen') {
      setIsDrawing(true);
      setCurrentStroke([{ x: coords.x, y: coords.y }]);
    } else if (activeTool === 'eraser') {
      setIsDrawing(true);
      setEraserCursorPos({ x: coords.x, y: coords.y });
      eraseStrokesAt(coords.x, coords.y);
    }
  };

  const handleStageMouseMove = (e: React.MouseEvent) => {
    const coords = getStageCoords(e);

    if (activeTool === 'eraser') {
      setEraserCursorPos({ x: coords.x, y: coords.y });
    }

    if (isDrawing) {
      if (activeTool === 'pen') {
        setCurrentStroke(prev => [...prev, { x: coords.x, y: coords.y }]);
      } else if (activeTool === 'eraser') {
        eraseStrokesAt(coords.x, coords.y);
      }
    } else if (activeDragId) {
      handleMouseMove(e);
    }
  };

  const handleStageMouseUp = () => {
    if (isDrawing) {
      if (activeTool === 'pen' && currentStroke.length > 0) {
        setStrokes(prev => [
          ...prev,
          {
            id: `stroke-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            points: currentStroke,
            color: strokeColor,
            width: strokeWidth
          }
        ]);
        setCurrentStroke([]);
      }
      setIsDrawing(false);
    }
    setActiveDragId(null);
  };

  // Periodic pulse effect on state link arrows to represent visual sync
  useEffect(() => {
    const interval = setInterval(() => {
      setConnectionPulse(prev => !prev);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Update live code when math frequency updates to demonstrate "inter-component integration"
  useEffect(() => {
    setLiveCode(`// Dynamic Classroom Synchronizer\nfunction syncVisuals(freq) {\n  const wave = Math.sin(freq * Math.PI);\n  console.log("State normalizer updating with amplitude: " + wave.toFixed(4));\n  return wave;\n}\nsyncVisuals(${mathFrequency.toFixed(1)});`);
  }, [mathFrequency]);

  // Dynamic Visual Instantiation Handler
  const handleAddNode = (type: 'blackboard' | 'math3d' | 'code' | 'audio_norm' | 'peers') => {
    const titles = {
      blackboard: 'Custom Sketchpad Node',
      math3d: 'Dynamic Function Plotter',
      code: 'Algorithm Simulator',
      audio_norm: 'Telemetry Monitor',
      peers: 'Peer Collaboration Pod',
      whiteboard: 'Collaborative Whiteboard',
      physics: 'Physics Sandbox',
      circuit: 'Virtual Circuit Builder',
      wave: 'Wave Interference Explorer',
      chemistry: 'Molecular & Reaction Engine',
      biology: 'Biology Systems & Process Explorer'
    };

    const colors = {
      blackboard: 'emerald',
      math3d: 'indigo',
      code: 'slate',
      audio_norm: 'rose',
      peers: 'amber',
      whiteboard: 'blue',
      physics: 'sky',
      circuit: 'cyan',
      wave: 'violet',
      chemistry: 'emerald',
      biology: 'lime'
    };

    // Calculate spawning position with slight offset to avoid overlaps
    const count = nodes.filter(n => n.type === type).length;
    const spawnX = 150 + (count * 40);
    const spawnY = 150 + (count * 40);

    const newNode: SpatialNode = {
      id: `node-spawn-${Date.now()}`,
      type,
      title: `${titles[type]} #${count + 1}`,
      x: spawnX,
      y: spawnY,
      width: type === 'peers' ? 280 : 380,
      height: 280,
      color: colors[type]
    };

    setNodes([...nodes, newNode]);
    showNotification?.(`Instantiated new spatial ${titles[type]} component!`, 'success');
  };

  const handleRemoveNode = (id: string) => {
    setNodes(nodes.filter(n => n.id !== id));
    showNotification?.("Spatial component decommissioned.", "warning");
  };

  const handleToggleMaximize = (id: string) => {
    setNodes(nodes.map(n => {
      if (n.id === id) {
        const next = !n.isMaximized;
        if (next) {
          showNotification?.(`${n.title} focused in isolated spatial workspace.`, 'info');
        }
        return { ...n, isMaximized: next };
      }
      return n;
    }));
  };

  // Node Drag Handlers (custom absolute coordinate layout to ensure full cross-browser spatial canvas experience)
  const handleMouseDown = (e: React.MouseEvent, id: string) => {
    // If clicking a button, input, or interactive slider, don't drag
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('input') || target.closest('select') || target.closest('textarea')) {
      return;
    }
    
    e.preventDefault();
    setActiveDragId(id);
    const node = nodes.find(n => n.id === id);
    if (node && canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      dragOffsetRef.current = {
        x: e.clientX - rect.left - node.x,
        y: e.clientY - rect.top - node.y
      };
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!activeDragId || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = Math.max(10, Math.min(rect.width - 200, e.clientX - rect.left - dragOffsetRef.current.x));
    const y = Math.max(10, Math.min(rect.height - 150, e.clientY - rect.top - dragOffsetRef.current.y));

    setNodes(prev => prev.map(n => {
      if (n.id === activeDragId) {
        return { ...n, x, y };
      }
      return n;
    }));
  };

  const handleMouseUp = () => {
    setActiveDragId(null);
  };

  // Dynamic Math Mesh simulation component inside nodes
  const MathThreeDPreview: React.FC<{ frequency: number }> = ({ frequency }) => {
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
      if (!containerRef.current) return;
      const width = containerRef.current.clientWidth || 300;
      const height = containerRef.current.clientHeight || 200;

      const scene = new THREE.Scene();
      scene.background = new THREE.Color(theme === 'dark' ? 0x0f172a : 0xf1f5f9);

      const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
      camera.position.set(0, 3, 5);
      camera.lookAt(0, 0, 0);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      containerRef.current.appendChild(renderer.domElement);

      // Create a waving parametric math function mesh to represent live waveform
      const group = new THREE.Group();
      scene.add(group);

      // Create central sphere grid
      const gridHelper = new THREE.GridHelper(4, 16, 0x4f46e5, 0x334155);
      gridHelper.position.y = -0.5;
      scene.add(gridHelper);

      // Create vector lines for math frequency
      const geometry = new THREE.TorusGeometry(1, 0.25, 12, 48);
      const material = new THREE.MeshPhongMaterial({
        color: 0x6366f1,
        wireframe: true,
        emissive: 0x4338ca
      });
      const torus = new THREE.Mesh(geometry, material);
      group.add(torus);

      const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
      scene.add(ambientLight);

      const pointLight = new THREE.PointLight(0xffffff, 1);
      pointLight.position.set(5, 5, 5);
      scene.add(pointLight);

      let animId: number;
      const animate = () => {
        animId = requestAnimationFrame(animate);
        group.rotation.y += 0.01;
        group.rotation.x = Math.sin(Date.now() * 0.001) * 0.2;
        
        // Scale with frequency
        const scaleFactor = 0.7 + Math.sin(Date.now() * 0.003 * frequency) * 0.15;
        torus.scale.set(scaleFactor, scaleFactor, scaleFactor);
        
        renderer.render(scene, camera);
      };

      animate();

      return () => {
        cancelAnimationFrame(animId);
        if (containerRef.current && renderer.domElement) {
          containerRef.current.removeChild(renderer.domElement);
        }
        geometry.dispose();
        material.dispose();
      };
    }, [frequency, theme]);

    return <div ref={containerRef} className="w-full h-full min-h-[140px] rounded-xl overflow-hidden relative border border-indigo-500/10" />;
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-hidden relative",
      theme === 'dark' ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-800"
    )}>
      {/* Central control board header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 z-50",
        theme === 'dark' ? "bg-slate-900/90 border-slate-800" : "bg-white border-slate-200 shadow-sm"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-md shadow-indigo-500/20">
            <Boxes className="text-white" size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight uppercase">Spatial Lecture Canvas</h2>
              <span className="text-[9px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider animate-pulse">
                STATE SYNCED
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">
              Subject: {subject || "Quantum Mechanics"} • Inter-component Telemetry Active
            </p>
          </div>
        </div>

        {/* Global state synchronization sliders & control selectors */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 bg-slate-800/40 dark:bg-slate-900/50 border border-slate-700/30 rounded-xl px-3 py-1.5">
            <Sliders size={12} className="text-indigo-400" />
            <span className="text-[10px] font-bold uppercase text-slate-400">Sync Frequency:</span>
            <input 
              type="range" 
              min="0.5" 
              max="5" 
              step="0.1" 
              value={mathFrequency} 
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setMathFrequency(val);
                showNotification?.(`Synchronized spatial wave frequency to ${val.toFixed(1)}Hz`, 'info');
              }}
              className="w-24 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
            <span className="text-[10px] font-mono font-bold text-indigo-400 w-8">{mathFrequency.toFixed(1)}Hz</span>
          </div>

          {/* Quick Instantiators Menu */}
          <div className="flex items-center gap-1.5">
            <button 
              onClick={() => handleAddNode('blackboard')}
              className="p-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
              title="Spawn new Board"
            >
              <Plus size={10} /> Board
            </button>
            <button 
              onClick={() => handleAddNode('math3d')}
              className="p-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
              title="Spawn new 3D Space"
            >
              <Plus size={10} /> 3D Plot
            </button>
            <button 
              onClick={() => handleAddNode('code')}
              className="p-1.5 bg-slate-500/10 hover:bg-slate-500/20 border border-slate-500/30 text-slate-400 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
              title="Spawn new Algorithmic Sandbox"
            >
              <Plus size={10} /> Sandbox
            </button>
            <button 
              onClick={() => handleAddNode('audio_norm')}
              className="p-1.5 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-400 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
              title="Spawn new Normalizer monitor"
            >
              <Plus size={10} /> Audio Node
            </button>
          </div>

          {onClose && (
            <button 
              onClick={onClose}
              className="p-2 hover:bg-slate-800/40 border border-slate-700/30 rounded-xl transition-all cursor-pointer text-slate-400 hover:text-white"
            >
              <Minimize2 size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Main Interactive Stage */}
      <div 
        ref={canvasRef}
        onMouseDown={handleStageMouseDown}
        onMouseMove={handleStageMouseMove}
        onMouseUp={handleStageMouseUp}
        onMouseLeave={handleStageMouseUp}
        className={cn(
          "flex-1 overflow-hidden relative select-none",
          activeTool === 'pen' ? "cursor-crosshair" : activeTool === 'eraser' ? "cursor-none" : "cursor-default",
          theme === 'dark' 
            ? "bg-[radial-gradient(#334155_1px,transparent_1px)] bg-[size:24px_24px] bg-[#020617]" 
            : "bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] bg-[size:24px_24px] bg-[#f8fafc]"
        )}
      >
        {/* Floating Spatial Drawing & Eraser Toolbar */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-50 flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-slate-900/90 border border-slate-700/80 shadow-2xl backdrop-blur-md">
          {/* Active Tool Selector */}
          <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => {
                setActiveTool('select');
                showNotification?.("Select Mode: Drag nodes and interact with components.", "info");
              }}
              className={cn(
                "p-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                activeTool === 'select'
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
              )}
              title="Select & Move Mode"
            >
              <MousePointer size={14} />
              <span className="text-[10px] hidden sm:inline font-black uppercase">Move</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTool('pen');
                showNotification?.("Pen Mode: Freehand draw on the spatial canvas.", "info");
              }}
              className={cn(
                "p-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                activeTool === 'pen'
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
              )}
              title="Freehand Pen Tool"
            >
              <PenTool size={14} />
              <span className="text-[10px] hidden sm:inline font-black uppercase">Pen</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTool('eraser');
                showNotification?.("Eraser Mode: Click or drag over specific strokes to remove them.", "info");
              }}
              className={cn(
                "p-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                activeTool === 'eraser'
                  ? "bg-rose-600 text-white shadow-md shadow-rose-500/30 animate-pulse"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
              )}
              title="Stroke Eraser Tool"
            >
              <Eraser size={14} />
              <span className="text-[10px] hidden sm:inline font-black uppercase">Eraser</span>
            </button>
          </div>

          {/* Pen Controls */}
          {activeTool === 'pen' && (
            <div className="flex items-center gap-2 pl-1 border-l border-slate-800">
              {/* Color Swatches */}
              <div className="flex items-center gap-1">
                {['#38bdf8', '#10b981', '#f59e0b', '#f43f5e', '#a855f7', '#ffffff'].map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setStrokeColor(c)}
                    style={{ backgroundColor: c }}
                    className={cn(
                      "w-4 h-4 rounded-full border border-black/30 cursor-pointer transition-transform",
                      strokeColor === c ? "scale-125 ring-2 ring-indigo-400 ring-offset-1 ring-offset-slate-900" : "hover:scale-110 opacity-80"
                    )}
                  />
                ))}
              </div>

              {/* Stroke Thickness Slider */}
              <div className="flex items-center gap-2 bg-slate-950/80 px-2 py-1 rounded-lg border border-slate-800 text-[10px] font-mono">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider hidden md:inline">
                  Thickness:
                </span>
                <input
                  type="range"
                  min="1"
                  max="32"
                  value={strokeWidth}
                  onChange={(e) => setStrokeWidth(Number(e.target.value))}
                  className="w-16 sm:w-24 accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  title={`Stroke thickness: ${strokeWidth}px`}
                />
                <div className="flex items-center gap-1.5 min-w-[42px] justify-end">
                  <span
                    className="rounded-full shrink-0 transition-all inline-block border border-black/20"
                    style={{
                      width: Math.max(3, Math.min(16, strokeWidth)),
                      height: Math.max(3, Math.min(16, strokeWidth)),
                      backgroundColor: strokeColor
                    }}
                  />
                  <span className="text-indigo-300 font-bold text-[10px]">{strokeWidth}px</span>
                </div>
              </div>
            </div>
          )}

          {/* Eraser Controls */}
          {activeTool === 'eraser' && (
            <div className="flex items-center gap-2 pl-1 border-l border-slate-800">
              <span className="text-[9px] font-bold text-rose-400 uppercase tracking-wider hidden md:inline">
                Eraser Radius:
              </span>
              <div className="flex items-center gap-1 bg-slate-950/80 px-1.5 py-0.5 rounded-lg border border-slate-800 text-[10px] font-mono">
                {[
                  { label: 'S', size: 10 },
                  { label: 'M', size: 20 },
                  { label: 'L', size: 35 },
                  { label: 'XL', size: 50 }
                ].map(eItem => (
                  <button
                    key={eItem.label}
                    type="button"
                    onClick={() => setEraserRadius(eItem.size)}
                    className={cn(
                      "px-1.5 py-0.5 rounded cursor-pointer font-bold",
                      eraserRadius === eItem.size ? "bg-rose-600 text-white" : "text-slate-400 hover:text-white"
                    )}
                  >
                    {eItem.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Actions: Undo & Clear */}
          <div className="flex items-center gap-1 pl-1 border-l border-slate-800">
            <button
              type="button"
              onClick={handleUndoStroke}
              disabled={strokes.length === 0}
              className="p-1.5 text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed rounded-lg hover:bg-slate-800/50 cursor-pointer transition-all"
              title="Undo last stroke"
            >
              <Undo2 size={13} />
            </button>
            <button
              type="button"
              onClick={handleClearAllStrokes}
              disabled={strokes.length === 0}
              className="p-1.5 text-slate-400 hover:text-rose-400 disabled:opacity-30 disabled:cursor-not-allowed rounded-lg hover:bg-rose-500/10 cursor-pointer transition-all"
              title="Clear all strokes"
            >
              <RotateCcw size={13} />
            </button>
          </div>

          {/* Stroke Stack / History List Toggle Button */}
          <div className="flex items-center gap-1 pl-1 border-l border-slate-800">
            <button
              type="button"
              onClick={() => setShowStrokeStack(!showStrokeStack)}
              className={cn(
                "p-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer",
                showStrokeStack
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
              )}
              title="Toggle Stroke History Stack & Visibility"
            >
              <Layers size={14} />
              <span className="text-[10px] hidden sm:inline font-black uppercase">Layers</span>
            </button>
          </div>

          {strokes.length > 0 && (
            <span className="text-[9px] font-mono font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/20 shrink-0">
              {strokes.filter(s => !s.hidden).length}/{strokes.length} visible
            </span>
          )}
        </div>

        {/* Visual Stroke Stack / History List Panel */}
        <AnimatePresence>
          {showStrokeStack && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              className="absolute top-16 right-4 z-50 w-72 max-h-[26rem] flex flex-col rounded-2xl bg-slate-900/95 border border-slate-700/90 shadow-2xl backdrop-blur-xl overflow-hidden"
            >
              {/* Header */}
              <div className="p-3 border-b border-slate-800/80 flex items-center justify-between bg-slate-950/70">
                <div className="flex items-center gap-2">
                  <div className="p-1 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    <Layers size={14} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white leading-none">Stroke Layers Stack</h4>
                    <p className="text-[10px] text-slate-400 mt-0.5">Toggle visibility of specific strokes</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowStrokeStack(false)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer transition-colors"
                >
                  <X size={14} />
                </button>
              </div>

              {/* Global Quick Action Controls */}
              <div className="px-3 py-2 bg-slate-900/60 border-b border-slate-800/60 flex items-center justify-between text-[11px]">
                <span className="text-slate-400 font-medium">
                  {strokes.filter(s => !s.hidden).length} visible of {strokes.length}
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleToggleAllStrokesVisibility(false)}
                    disabled={strokes.length === 0}
                    className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 disabled:opacity-40 cursor-pointer transition-colors flex items-center gap-1"
                  >
                    <Eye size={10} /> Show All
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleAllStrokesVisibility(true)}
                    disabled={strokes.length === 0}
                    className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 disabled:opacity-40 cursor-pointer transition-colors flex items-center gap-1"
                  >
                    <EyeOff size={10} /> Hide All
                  </button>
                </div>
              </div>

              {/* Stroke Stack Items List (Newest first) */}
              <div className="flex-1 overflow-y-auto p-2 space-y-1.5 max-h-64">
                {strokes.length === 0 ? (
                  <div className="p-6 text-center text-slate-500 text-xs">
                    <p className="font-medium">No drawing strokes on canvas.</p>
                    <p className="text-[10px] text-slate-600 mt-1">Use the Pen tool on the stage to start drawing.</p>
                  </div>
                ) : (
                  [...strokes].reverse().map((stroke, index) => {
                    const originalIdx = strokes.length - index;
                    return (
                      <div
                        key={stroke.id}
                        onMouseEnter={() => setHighlightedStrokeId(stroke.id)}
                        onMouseLeave={() => setHighlightedStrokeId(null)}
                        className={cn(
                          "p-2 rounded-xl border transition-all flex items-center justify-between gap-2 group",
                          stroke.hidden
                            ? "bg-slate-950/40 border-slate-800/50 opacity-60"
                            : highlightedStrokeId === stroke.id
                            ? "bg-indigo-900/40 border-indigo-500/60 shadow-md shadow-indigo-500/10"
                            : "bg-slate-800/40 border-slate-800 hover:bg-slate-800/80"
                        )}
                      >
                        {/* Stroke Preview Swatch & Details */}
                        <div className="flex items-center gap-2.5 min-w-0 flex-1">
                          <div className="relative flex items-center justify-center shrink-0">
                            <span
                              className="w-4 h-4 rounded-full border border-black/30 shadow-inner block"
                              style={{ backgroundColor: stroke.color }}
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-semibold text-slate-200 truncate">
                                Stroke #{originalIdx}
                              </span>
                              <span className="text-[9px] font-mono text-slate-400 bg-slate-900/80 px-1.5 py-0.5 rounded border border-slate-800">
                                {stroke.points.length} pts
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 truncate font-mono">
                              Thickness: {stroke.width}px
                            </p>
                          </div>
                        </div>

                        {/* Visibility Toggle & Delete Action */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleToggleStrokeVisibility(stroke.id)}
                            className={cn(
                              "p-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer",
                              stroke.hidden
                                ? "bg-slate-800 text-slate-500 hover:text-slate-300"
                                : "bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30"
                            )}
                            title={stroke.hidden ? "Show stroke" : "Hide stroke"}
                          >
                            {stroke.hidden ? <EyeOff size={13} /> : <Eye size={13} />}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteStroke(stroke.id)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer transition-colors opacity-80 group-hover:opacity-100"
                            title="Delete stroke"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Drawing Canvas Overlay Layer for Freehand Strokes & Eraser Cursor */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-30">
          {/* Render Completed Strokes */}
          {strokes.map((stroke) => {
            if (stroke.hidden) return null;
            const isHighlighted = highlightedStrokeId === stroke.id;
            return (
              <path
                key={stroke.id}
                d={strokeToSvgPath(stroke.points)}
                stroke={stroke.color}
                strokeWidth={isHighlighted ? stroke.width + 3 : stroke.width}
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
                className={cn("transition-all", isHighlighted && "animate-pulse stroke-indigo-400")}
              />
            );
          })}

          {/* Render Active Drawing Stroke */}
          {isDrawing && activeTool === 'pen' && currentStroke.length > 0 && (
            <path
              d={strokeToSvgPath(currentStroke)}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Visual Eraser Ring Cursor */}
          {activeTool === 'eraser' && eraserCursorPos && (
            <circle
              cx={eraserCursorPos.x}
              cy={eraserCursorPos.y}
              r={eraserRadius}
              fill="rgba(244, 63, 94, 0.2)"
              stroke="#f43f5e"
              strokeWidth={1.5}
              strokeDasharray="3,3"
            />
          )}
        </svg>

        {/* Dynamic Connected Lines overlaying coordinates */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
          <defs>
            <linearGradient id="edge-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#ec4899" stopOpacity="0.6" />
            </linearGradient>
          </defs>
          
          {/* We link the Blackboard Node to the 3D Math Node and to the Audio Node dynamically */}
          {(() => {
            const bNode = nodes.find(n => n.id === 'node-blackboard');
            const mNode = nodes.find(n => n.id === 'node-math3d');
            const cNode = nodes.find(n => n.id === 'node-code');
            const aNode = nodes.find(n => n.id === 'node-audio-norm');
            
            if (!bNode || bNode.isMaximized) return null;
            
            return (
              <>
                {/* Board -> Math3D connection path */}
                {mNode && !mNode.isMaximized && (
                  <g>
                    <path 
                      d={`M ${bNode.x + bNode.width} ${bNode.y + bNode.height / 2} C ${bNode.x + bNode.width + 100} ${bNode.y + bNode.height / 2}, ${mNode.x - 100} ${mNode.y + mNode.height / 2}, ${mNode.x} ${mNode.y + mNode.height / 2}`}
                      fill="none"
                      stroke="url(#edge-grad)"
                      strokeWidth={2}
                      strokeDasharray={connectionPulse ? "6,6" : "0"}
                      className="transition-all duration-1000"
                    />
                    <circle 
                      cx={(bNode.x + bNode.width + mNode.x) / 2} 
                      cy={(bNode.y + bNode.height / 2 + mNode.y + mNode.height / 2) / 2}
                      r={4}
                      fill="#818cf8"
                    />
                  </g>
                )}
                
                {/* Code -> Audio Node connection path */}
                {cNode && aNode && !cNode.isMaximized && !aNode.isMaximized && (
                  <g>
                    <path 
                      d={`M ${cNode.x + cNode.width} ${cNode.y + cNode.height / 2} C ${cNode.x + cNode.width + 100} ${cNode.y + cNode.height / 2}, ${aNode.x - 100} ${aNode.y + aNode.height / 2}, ${aNode.x} ${aNode.y + aNode.height / 2}`}
                      fill="none"
                      stroke="url(#edge-grad)"
                      strokeWidth={1.5}
                      strokeDasharray="4,8"
                    />
                  </g>
                )}
              </>
            );
          })()}
        </svg>

        {/* Floating Spatial Cards */}
        <AnimatePresence>
          {nodes.map((node) => {
            const isDragging = activeDragId === node.id;
            
            return (
              <motion.div
                key={node.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ 
                  opacity: 1, 
                  scale: 1,
                  zIndex: isDragging ? 100 : 10,
                  boxShadow: isDragging 
                    ? "0 25px 50px -12px rgba(0, 0, 0, 0.5)" 
                    : "0 10px 15px -3px rgba(0, 0, 0, 0.1)"
                }}
                exit={{ opacity: 0, scale: 0.8 }}
                style={node.isMaximized ? {
                  position: 'absolute',
                  top: '12px',
                  left: '12px',
                  right: '12px',
                  bottom: '12px',
                  width: 'calc(100% - 24px)',
                  height: 'calc(100% - 24px)',
                  zIndex: 200,
                } : {
                  position: 'absolute',
                  left: `${node.x}px`,
                  top: `${node.y}px`,
                  width: `${node.width}px`,
                  height: `${node.height}px`,
                }}
                className={cn(
                  "rounded-2xl border flex flex-col overflow-hidden select-text transition-shadow duration-200",
                  theme === 'dark' 
                    ? "bg-slate-900/95 border-slate-800 text-slate-100" 
                    : "bg-white/95 border-slate-200 text-slate-800"
                )}
              >
                {/* Node Titlebar / Grabber */}
                <div 
                  onMouseDown={(e) => !node.isMaximized && handleMouseDown(e, node.id)}
                  className={cn(
                    "px-4 py-2.5 flex items-center justify-between shrink-0 select-none",
                    !node.isMaximized ? "cursor-grab active:cursor-grabbing" : "",
                    node.color === 'emerald' ? "bg-emerald-500/10 text-emerald-400 border-b border-emerald-500/20" :
                    node.color === 'indigo' ? "bg-indigo-500/10 text-indigo-400 border-b border-indigo-500/20" :
                    node.color === 'rose' ? "bg-rose-500/10 text-rose-400 border-b border-rose-500/20" :
                    node.color === 'amber' ? "bg-amber-500/10 text-amber-400 border-b border-amber-500/20" :
                    "bg-slate-800/50 text-slate-300 border-b border-slate-700/50"
                  )}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-current animate-pulse" />
                    <span className="text-[10px] font-black uppercase tracking-widest">{node.title}</span>
                  </div>
                  
                  <div className="flex items-center gap-1.5">
                    <button 
                      onClick={() => handleToggleMaximize(node.id)}
                      className="p-1 hover:bg-white/10 rounded transition-all cursor-pointer text-slate-400 hover:text-white"
                      title={node.isMaximized ? "Restore" : "Maximize"}
                    >
                      {node.isMaximized ? <Minimize2 size={10} /> : <Maximize2 size={10} />}
                    </button>
                    <button 
                      onClick={() => handleRemoveNode(node.id)}
                      className="p-1 hover:bg-rose-500/20 rounded transition-all cursor-pointer text-slate-400 hover:text-rose-400"
                      title="Decommission Node"
                    >
                      <Trash2 size={10} />
                    </button>
                  </div>
                </div>

                {/* Node Specific Contents */}
                <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                  
                  {/* TYPE A: Chalkboard Ledger */}
                  {node.type === 'blackboard' && (
                    <div className="space-y-3 h-full flex flex-col justify-between">
                      <div className="space-y-2">
                        <label className="text-[9px] font-bold text-emerald-500 uppercase tracking-wider block">Lecture Visual Synthesis</label>
                        <div className="w-full bg-slate-950/80 border border-slate-800 text-emerald-400 text-xs px-2.5 py-2 rounded-lg font-bold font-mono h-20 overflow-y-auto">
                          {chatContent.split('\n').filter(line => line.length > 20).slice(-3).join('\n') || "Awaiting lecture input..."}
                        </div>
                      </div>

                      <div className="bg-slate-900 border border-slate-700/80 rounded-xl p-3 text-slate-200 font-mono text-[10px] space-y-2 relative flex-1 mt-2 shadow-inner overflow-hidden">
                        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none opacity-40" />
                        <div className="relative z-10 flex items-center justify-between">
                          <span className="text-yellow-200 font-bold">🎯 Synthesis:</span>
                          <span className="text-[8px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded uppercase font-black">Digital Slate</span>
                        </div>
                        <p className="pl-2 text-[9px] text-slate-300 relative z-10 line-clamp-4">
                          {chatContent.slice(-200) || "Start chatting to see synthesis..."}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* TYPE B: Math 3D visualizer */}
                  {node.type === 'math3d' && (
                    <div className="h-full flex flex-col justify-between space-y-3">
                      <MathThreeDPreview frequency={mathFrequency} />
                      <div className="flex items-center justify-between text-[10px] shrink-0 bg-indigo-500/5 border border-indigo-500/10 p-2 rounded-xl">
                        <div className="flex items-center gap-1.5">
                          <Cpu size={12} className="text-indigo-400" />
                          <span className="font-bold text-slate-400">Torus Knot Vector</span>
                        </div>
                        <span className="font-mono text-indigo-400 font-extrabold text-[9px]">F(t) = {mathFrequency.toFixed(1)}Hz</span>
                      </div>
                    </div>
                  )}

                  {/* TYPE C: Code Sandbox */}
                  {node.type === 'code' && (
                    <div className="h-full flex flex-col justify-between space-y-2">
                      <div className="flex-1 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden p-2">
                        <textarea
                          value={liveCode}
                          onChange={(e) => setLiveCode(e.target.value)}
                          className="w-full h-full bg-transparent text-slate-300 text-[10px] font-mono p-1 outline-none resize-none overflow-y-auto leading-relaxed"
                          spellCheck={false}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 pt-1 border-t border-slate-800">
                        <span>Compiler: Javascript v8</span>
                        <span className="text-emerald-400 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Runnable
                        </span>
                      </div>
                    </div>
                  )}

                  {/* TYPE D: Audio Normalizer & Timbre Standardization */}
                  {node.type === 'audio_norm' && (
                    <div className="space-y-3 h-full flex flex-col justify-between">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider">AI Voice Lock</span>
                          <button 
                            onClick={() => {
                              setIsAudioFilterActive(!isAudioFilterActive);
                              showNotification?.(isAudioFilterActive ? "Audio Normalizer Bypass Activated" : "Standard pitch/timbre lock active", 'info');
                            }}
                            className={cn(
                              "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider transition-all",
                              isAudioFilterActive ? "bg-rose-500/20 text-rose-400 border border-rose-500/30" : "bg-slate-800 text-slate-500"
                            )}
                          >
                            {isAudioFilterActive ? "LOCK ACTIVE" : "BYPASS"}
                          </button>
                        </div>
                        
                        {/* Audio pipeline parameter monitors */}
                        <div className="grid grid-cols-2 gap-2 text-[10px] font-bold">
                          <div className="bg-slate-950/40 border border-slate-800 p-2 rounded-xl">
                            <div className="text-slate-500 uppercase text-[8px]">Pitch lock stability</div>
                            <div className="text-rose-400 font-mono text-xs font-black mt-0.5">{pitchStability}%</div>
                          </div>
                          <div className="bg-slate-950/40 border border-slate-800 p-2 rounded-xl">
                            <div className="text-slate-500 uppercase text-[8px]">Standard Timbre</div>
                            <div className="text-rose-400 font-mono text-xs font-black uppercase mt-0.5">{timbrePreset} EQ</div>
                          </div>
                          <div className="bg-slate-950/40 border border-slate-800 p-2 rounded-xl">
                            <div className="text-slate-500 uppercase text-[8px]">Lowpass Cutoff</div>
                            <div className="text-slate-300 font-mono mt-0.5">6.8 kHz</div>
                          </div>
                          <div className="bg-slate-950/40 border border-slate-800 p-2 rounded-xl">
                            <div className="text-slate-500 uppercase text-[8px]">Dynamics Threshold</div>
                            <div className="text-slate-300 font-mono mt-0.5">-22 dB</div>
                          </div>
                        </div>
                      </div>

                      {/* Moving Audio Wave visualizer simulation */}
                      <div className={cn("h-10 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-center gap-0.5 px-3 overflow-hidden relative", isClassroomMode ? "hidden" : "hidden md:flex")}>
                        {Array.from({ length: 32 }).map((_, waveIdx) => {
                          const heightFactor = isAudioFilterActive 
                            ? (Math.sin(waveIdx * 0.4 + Date.now() * 0.005) * 12 + 16) 
                            : (Math.random() * 24 + 4);
                          return (
                            <div 
                              key={waveIdx}
                              style={{ height: `${heightFactor}px` }}
                              className={cn(
                                "w-1 rounded-full transition-all duration-100",
                                isAudioFilterActive ? "bg-rose-500/80" : "bg-slate-700"
                              )}
                            />
                          );
                        })}
                        <span className="absolute bottom-1 right-2 text-[7px] font-mono font-black text-rose-500/50">NORMALIZER SPECTROGRAM</span>
                      </div>
                    </div>
                  )}

                  {/* TYPE G: Physics Sandbox */}
                  {node.type === 'physics' && (
                    <PhysicsSandbox theme={theme} />
                  )}
                  
                  {/* TYPE H: Virtual Circuit Builder */}
                  {node.type === 'circuit' && (
                    <CircuitBuilder theme={theme} />
                  )}

                  {/* TYPE K: Biology Systems & Process Explorer */}
                  {node.type === 'biology' && (
                    <BiologyLab theme={theme} onSendMessage={() => {}} />
                  )}

                  {/* TYPE J: Molecular & Reaction Engine */}
                  {node.type === 'chemistry' && (
                    <ChemistryLab theme={theme} />
                  )}

                  {/* TYPE I: Wave Interference Explorer */}
                  {node.type === 'wave' && (
                    <WaveExplorer theme={theme} />
                  )}

                  {/* TYPE F: Collaborative Whiteboard */}
                  {node.type === 'whiteboard' && (
                    <CollaborativeWhiteboard theme={theme} />
                  )}

                  {/* TYPE E: Synced Classroom Peers Roster */}
                  {node.type === 'peers' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-[10px] font-bold border-b border-slate-800 pb-2">
                        <span className="text-amber-500 uppercase tracking-wider flex items-center gap-1">
                          <Users size={12} /> Classmates
                        </span>
                        <span className="text-slate-400 font-mono">{peersOnline} Active</span>
                      </div>

                      <div className="space-y-2">
                        {[
                          { name: "Devin K.", role: "Student", active: "Waverider mesh", action: "Visualizing 3D vector knot", color: "bg-blue-500" },
                          { name: "Siddharth M.", role: "Moderator", active: "Ledger synchronized", action: "Modifying blackboard equations", color: "bg-amber-500" },
                          { name: "Elena R.", role: "Student", active: "Running javascript v8", action: "Pushed sync frequency slider", color: "bg-emerald-500" },
                          { name: "Liam O.", role: "Observer", active: "Audio standardizer bypassed", action: "Calibrating voice compression", color: "bg-indigo-500" }
                        ].map((peer, pIdx) => (
                          <div key={pIdx} className="bg-slate-950/40 border border-slate-800/40 p-2 rounded-xl text-[10px] flex items-start gap-2">
                            <div className={cn("w-2 h-2 rounded-full mt-1.5 shrink-0 animate-pulse", peer.color)} />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-slate-300 truncate">{peer.name}</span>
                                <span className="text-[8px] text-slate-500 uppercase tracking-widest">{peer.role}</span>
                              </div>
                              <div className="text-[9px] text-slate-400 truncate mt-0.5">{peer.action}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Floating hints footer */}
      <div className={cn(
        "px-6 py-2.5 border-t flex items-center justify-between text-[9px] font-bold uppercase tracking-wider shrink-0",
        theme === 'dark' ? "bg-slate-900/60 border-slate-800 text-slate-400" : "bg-slate-50 border-slate-200 text-slate-500"
      )}>
        <div className="flex items-center gap-1.5 text-indigo-400">
          <Info size={12} />
          <span>Double-click empty canvas space or use instantiators to spawn study objects dynamically!</span>
        </div>
        <span className="font-mono">Spatial-Node-Sync v2.4</span>
      </div>
    </div>
  );
};
