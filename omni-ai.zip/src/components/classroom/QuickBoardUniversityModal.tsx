import React, { useState, useMemo } from 'react';
import { Search, X, Check, Globe, GraduationCap, Building2, BookOpen } from 'lucide-react';
import { EDUCATION_BOARDS, EducationBoard } from '../../data/boards';

interface QuickBoardUniversityModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedBoard?: { nation: string; acronym: string } | null;
  onSelectBoard: (board: EducationBoard) => void;
  theme?: 'light' | 'dark';
}

export const QuickBoardUniversityModal: React.FC<QuickBoardUniversityModalProps> = ({
  isOpen,
  onClose,
  selectedBoard,
  onSelectBoard,
  theme = 'dark'
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'national' | 'state' | 'university' | 'international'>('all');
  const [nationFilter, setNationFilter] = useState<string>('all');

  const nations = useMemo(() => {
    const list = Array.from(new Set(EDUCATION_BOARDS.map(b => b.nation))).filter(Boolean);
    return ['all', ...list];
  }, []);

  const filteredBoards = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return EDUCATION_BOARDS.filter(board => {
      const matchSearch =
        !q ||
        board.acronym.toLowerCase().includes(q) ||
        board.name.toLowerCase().includes(q) ||
        board.nation.toLowerCase().includes(q) ||
        board.jurisdiction.toLowerCase().includes(q) ||
        board.curriculumFocus.toLowerCase().includes(q);

      const matchCategory =
        categoryFilter === 'all'
          ? true
          : categoryFilter === 'university'
          ? board.type === 'university' || board.type === 'technical-university'
          : board.type === categoryFilter;

      const matchNation = nationFilter === 'all' || board.nation.toLowerCase() === nationFilter.toLowerCase();

      return matchSearch && matchCategory && matchNation;
    });
  }, [searchQuery, categoryFilter, nationFilter]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <GraduationCap size={24} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>Select Board & University</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                  {filteredBoards.length} Available
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Switch board or university to align syllabus, exams, and teaching depth in the 3D classroom
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="p-3 sm:p-4 border-b border-slate-800 bg-slate-900/90 space-y-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search board or university (e.g., CBSE, ICSE, MIT, IIT, Stanford, State Board)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                autoFocus
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Nation Filter Dropdown */}
            <select
              value={nationFilter}
              onChange={e => setNationFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              <option value="all">🌍 All Nations</option>
              {nations.filter(n => n !== 'all').map(nation => (
                <option key={nation} value={nation}>
                  {nation}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-hide touch-pan-x pb-1 text-xs">
            <button
              onClick={() => setCategoryFilter('all')}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
                categoryFilter === 'all'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              All Types
            </button>
            <button
              onClick={() => setCategoryFilter('national')}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
                categoryFilter === 'national'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              🏛️ National Boards
            </button>
            <button
              onClick={() => setCategoryFilter('state')}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
                categoryFilter === 'state'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              📍 State Boards
            </button>
            <button
              onClick={() => setCategoryFilter('university')}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
                categoryFilter === 'university'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              🎓 Universities & Tech
            </button>
            <button
              onClick={() => setCategoryFilter('international')}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
                categoryFilter === 'international'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              🌐 International
            </button>
          </div>
        </div>

        {/* Board Cards Grid */}
        <div className="flex-1 overflow-y-auto custom-scrollbar touch-pan-y overscroll-contain p-3 sm:p-5 grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredBoards.map(board => {
            const isSelected =
              selectedBoard?.acronym?.toLowerCase() === board.acronym.toLowerCase() &&
              (!selectedBoard.nation || selectedBoard.nation.toLowerCase() === board.nation.toLowerCase());

            return (
              <div
                key={`${board.nation}-${board.acronym}`}
                onClick={() => {
                  onSelectBoard(board);
                  onClose();
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer text-left flex flex-col justify-between group ${
                  isSelected
                    ? 'bg-indigo-950/70 border-indigo-500 ring-2 ring-indigo-500/40'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black text-white group-hover:text-indigo-300 transition-colors">
                          {board.acronym}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            board.type === 'university' || board.type === 'technical-university'
                              ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                              : board.type === 'national'
                              ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                              : 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                          }`}
                        >
                          {board.type.toUpperCase()}
                        </span>
                      </div>
                      <h4 className="text-xs font-semibold text-slate-300 mt-1 line-clamp-1">{board.name}</h4>
                    </div>

                    {isSelected ? (
                      <div className="p-1 rounded-full bg-emerald-500 text-slate-950 shrink-0">
                        <Check size={14} strokeWidth={3} />
                      </div>
                    ) : (
                      <span className="text-xs text-slate-500 group-hover:text-indigo-400 transition-colors">Select ➔</span>
                    )}
                  </div>

                  <p className="text-[11px] text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {board.description || board.curriculumFocus}
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500">
                  <span className="flex items-center gap-1 font-medium">
                    <Globe size={11} className="text-slate-400" />
                    {board.nation} • {board.jurisdiction}
                  </span>
                  <span className="font-mono text-slate-400">{board.classesCovered}</span>
                </div>
              </div>
            );
          })}

          {filteredBoards.length === 0 && (
            <div className="col-span-full py-12 text-center text-slate-400">
              <Building2 size={36} className="mx-auto text-slate-600 mb-2" />
              <p className="text-sm font-semibold">No board or university found matching your criteria.</p>
              <p className="text-xs text-slate-500 mt-1">Try clearing filters or changing your search terms.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
