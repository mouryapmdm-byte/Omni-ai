import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';
import { cn, convertLaTeXToSpokenText, autoBalanceMathDelimiters, expandAbbreviationsForSpeech, downloadFileFromUrl, formatMarkdownWithInlineSvgs, getSyncShareUrl, triggerHapticFeedback } from '@/src/lib/utils';
import { WaveformVisualizer } from './WaveformVisualizer';
import { GLOSSARY_ITEMS } from './SettingsModal';
import { SCIENTIFIC_UNITS, UnitItem } from './UnitPronunciationTrainer';
import { WordHighlighter } from './WordHighlighter';
import { AudioDiagnostics } from './AudioDiagnostics';
import { Send, Mic, Play, MicOff, Plus, Trash2, Volume2, VolumeX, Loader2, Sparkles, Brain, Image as ImageIcon, Video, Wand2, Languages, ChevronDown, Pause, Download, Camera, Copy, Printer, Check, Sliders, Gauge, Link, Link2Off, ThumbsUp, ThumbsDown, Share2, Maximize2, Minimize2, Minus, ChevronLeft, ChevronRight, Pin, GraduationCap, RotateCcw, RotateCw, Activity, Zap, Database, ShieldAlert, Trophy, MoreVertical, X, MoveDiagonal, StickyNote, FileText, Edit3, Contrast, BookOpen, Film, HelpCircle, Bookmark, HardDrive, Wifi, WifiOff, Tag, QrCode, Scan, Wrench, Pencil, AlertTriangle, Table, Monitor, Circle, Square, Crosshair, Radio, ArrowDown, Search, Eraser } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { generateSpeech, generateGoogleSpeech, generateAIResponse, convertPcmToWav, generateImage } from '@/src/lib/gemini';
import { NewtonRaphsonGraph } from "./NewtonRaphsonGraph";
import { MathGraph, detectMathFunctions } from "./MathGraph";
import { createVoiceNormalizationChain } from '@/src/lib/audioPipeline';
import { LANGUAGES, PERSONAS } from '@/src/lib/constants';
import { StateScratchpad } from './StateScratchpad';
import { VideoWithOverlay } from './VideoWithOverlay';
import { VennDiagramBuilder } from './VennDiagramBuilder';
import { MathDigitalWhiteboard } from './MathDigitalWhiteboard';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { LectureProgressTimeline, TimelineMarker } from './LectureProgressTimeline';
import { LectureBookmark, VerbalLectureQuestion, TutorPersonaConfig, UnifiedCanvasUiManager, BlackboardEraserStyle, BlackboardEraserSpeed, BlackboardDustDensity, BlackboardWipeEvent, ChalkColor, ChalkColorOption, CHALK_COLOR_PALETTES, BlackboardZoomFocusState } from '@/src/types';
import { cacheLectureMetadata, getLectureMetadata, getLectureCacheStats, clearLectureCache, deleteLectureMetadata } from '@/src/lib/lectureCache';
import { PredictiveAutocomplete } from './PredictiveAutocomplete';
import { getPredictiveSuggestions, PredictiveTerm } from '../data/predictiveDictionary';
import { DiagramLegendBlock } from './DiagramLegendBlock';
import { renderSmartGlossaryText, CHEMISTRY_DICTIONARY } from './SmartConceptGlossary';
import { playChalkSound, isChalkSoundEnabled, setChalkSoundEnabled, playLessonInitializingCue, playDiagramThud, playEquationChalkScratch, playChalkColorSwitchSound } from '@/src/lib/chalkAudio';
import { SvgDiagramViewer } from './SvgDiagramViewer';
import { TableGenerator, BlackboardSummaryCard, isBoxedSummary } from './TableGenerator';
import { SubtopicHeadingDiagram } from './SubtopicHeadingDiagram';
import { CanvasOverlayToolbar } from './CanvasOverlayToolbar';
import { ClassroomSyncControl } from './ClassroomSyncControl';
import { PracticeQuestionStudioModal } from './PracticeQuestionStudioModal';

const extractSvgCode = (text: string): string | null => {
  if (!text) return null;
  const match = text.match(/<svg[\s\S]*?<\/svg>/);
  return match ? match[0] : null;
};

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: number;
  metadata?: any;
}

export interface DiagramNote {
  id: string;
  x: number;
  y: number;
  text: string;
  color?: 'amber' | 'emerald' | 'cyan' | 'rose' | 'purple';
  type?: 'question' | 'note' | 'concept' | 'formula' | 'exam';
  title?: string;
  timestamp?: string;
}

const NOTE_COLOR_STYLES: Record<'amber' | 'emerald' | 'cyan' | 'rose' | 'purple', { card: string; header: string }> = {
  amber: {
    card: 'bg-amber-400 text-slate-950 border-amber-300 shadow-amber-950/40',
    header: 'bg-amber-500/80 text-slate-950 border-amber-600/30'
  },
  emerald: {
    card: 'bg-emerald-400 text-slate-950 border-emerald-300 shadow-emerald-950/40',
    header: 'bg-emerald-500/80 text-slate-950 border-emerald-600/30'
  },
  cyan: {
    card: 'bg-cyan-300 text-slate-950 border-cyan-200 shadow-cyan-950/40',
    header: 'bg-cyan-400/80 text-slate-950 border-cyan-500/30'
  },
  rose: {
    card: 'bg-rose-400 text-slate-950 border-rose-300 shadow-rose-950/40',
    header: 'bg-rose-500/80 text-slate-950 border-rose-600/30'
  },
  purple: {
    card: 'bg-purple-300 text-slate-950 border-purple-200 shadow-purple-950/40',
    header: 'bg-purple-400/80 text-slate-950 border-purple-500/30'
  }
};

const HOTSPOT_CATEGORY_CONFIG: Record<'question' | 'note' | 'concept' | 'formula' | 'exam', { label: string; icon: any; colorClass: string; bgBadge: string; borderClass: string }> = {
  question: {
    label: '❓ Question',
    icon: HelpCircle,
    colorClass: 'text-purple-300',
    bgBadge: 'bg-purple-600 text-white ring-2 ring-purple-300 shadow-purple-900/50',
    borderClass: 'border-purple-500/40 bg-purple-950/90 text-purple-100'
  },
  note: {
    label: '📝 Study Note',
    icon: StickyNote,
    colorClass: 'text-amber-300',
    bgBadge: 'bg-amber-500 text-slate-950 ring-2 ring-amber-300 font-black shadow-amber-900/50',
    borderClass: 'border-amber-500/40 bg-amber-950/90 text-amber-100'
  },
  concept: {
    label: '💡 Key Concept',
    icon: Brain,
    colorClass: 'text-emerald-300',
    bgBadge: 'bg-emerald-600 text-white ring-2 ring-emerald-300 shadow-emerald-900/50',
    borderClass: 'border-emerald-500/40 bg-emerald-950/90 text-emerald-100'
  },
  formula: {
    label: '⚡ Formula / Calc',
    icon: Zap,
    colorClass: 'text-cyan-300',
    bgBadge: 'bg-cyan-500 text-slate-950 ring-2 ring-cyan-200 font-black shadow-cyan-900/50',
    borderClass: 'border-cyan-500/40 bg-cyan-950/90 text-cyan-100'
  },
  exam: {
    label: '⚠️ Exam Watchout',
    icon: ShieldAlert,
    colorClass: 'text-rose-300',
    bgBadge: 'bg-rose-600 text-white ring-2 ring-rose-300 shadow-rose-900/50',
    borderClass: 'border-rose-500/40 bg-rose-950/90 text-rose-100'
  }
};

interface ChatProps {
  messages: Message[];
  onSendMessage: (text: string, imageBase64?: string) => void;
  onClearChat: () => void;
  isTyping: boolean;
  onFileUpload: (file: File) => void;
  onToggleVoice: () => void;
  onGenerateMedia: (type: 'image' | 'video', prompt: string, options?: any) => void;
  isRecording: boolean;
  theme: 'light' | 'dark';
  language: string;
  onSelectLanguage: (lang: string) => void;
  onGenerateRecap?: () => void;
  zoomLevel?: number;
  setZoomLevel?: React.Dispatch<React.SetStateAction<number>>;
  contentWidth?: number;
  setContentWidth?: React.Dispatch<React.SetStateAction<number>>;

  onGenerateVideo?: (events: { timestamp: number; event: string }[]) => void;
  onOpenTool?: (toolId: string, options?: any) => void;
  selectedPersonaId?: string;
  onSelectPersonaId?: (id: string) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  typingPace?: string;
  blackboardWritingSpeed?: number;
  ttsRate?: number;
  linkSpeeds?: boolean;
  setTtsRate?: (rate: number) => void;
  setTypingPace?: (pace: string) => void;
  setBlackboardWritingSpeed?: (spd: number) => void;
  setLinkSpeeds?: (val: boolean) => void;
  isGeneratingVideo?: boolean;
  videoGenerationTime?: number;
  subject?: string;
  topic?: string;
  onSaveToNotes?: (note: { title: string; summary: string; keyConcepts: string[]; subject: string; topic: string }) => void;
  onDeleteMessage?: (msgId: string) => void;
  isShared?: boolean;
  isLectureMode: boolean;
  setIsLectureMode: (val: boolean) => void;
  lectureSubMode: 'classroom' | 'quiz' | 'lecture' | 'video_classroom';
  setLectureSubMode: (val: 'classroom' | 'quiz' | 'lecture' | 'video_classroom') => void;
  lectureProfessorStyle?: 'strict' | 'mentor';
  setLectureProfessorStyle?: (val: 'strict' | 'mentor') => void;
  tutorPersonaConfig?: TutorPersonaConfig;
  onUpdateTutorPersonaConfig?: (config: TutorPersonaConfig) => void;
  onAwardXp?: (xp: number) => void;
  pronunciationPrecision?: 'standard' | 'formal';
  mode: string;
  voiceSensitivity: number;
  accessibilityTextSize?: 'sm' | 'md' | 'lg' | 'xl';
  accessibilityLineSpacing?: 'normal' | 'relaxed' | 'loose';
  accessibilityContrast?: 'normal' | 'high' | 'ultra';
  isClassroomMute?: boolean;
  setIsClassroomMute?: (val: boolean) => void;
  isDiagramRendering?: boolean;
  setIsDiagramRendering?: (val: boolean) => void;
  canvasUiManager?: UnifiedCanvasUiManager;
}

export function romanizeText(text: string): string {
  if (!text) return "";

  const devanagariVowels: Record<string, string> = {
    'अ': 'a', 'आ': 'aa', 'इ': 'i', 'ई': 'ee', 'उ': 'u', 'ऊ': 'oo', 'ऋ': 'ri',
    'ए': 'e', 'ऐ': 'ai', 'ओ': 'o', 'औ': 'au', 'अं': 'an', 'अः': 'ah', 'ऑ': 'o', 'औं': 'aun'
  };

  const devanagariMatras: Record<string, string> = {
    'ा': 'a', 'ि': 'i', 'ी': 'ee', 'ु': 'u', 'ू': 'oo', 'ृ': 'ri',
    'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au', 'ं': 'n', 'ः': 'h', 'ँ': 'n', 'ॉ': 'o'
  };

  const devanagariConsonants: Record<string, string> = {
    'क': 'k', 'ख': 'kh', 'ग': 'g', 'घ': 'gh', 'ङ': 'ng',
    'च': 'ch', 'छ': 'chh', 'ज': 'j', 'झ': 'jh', 'ञ': 'ny',
    'ट': 't', 'ठ': 'th', 'ड': 'd', 'ढ': 'dh', 'ण': 'n',
    'त': 't', 'थ': 'th', 'द': 'd', 'ध': 'dh', 'न': 'n',
    'प': 'p', 'फ': 'ph', 'ब': 'b', 'भ': 'bh', 'म': 'm',
    'य': 'y', 'र': 'r', 'ल': 'l', 'व': 'v', 'श': 'sh', 'ष': 'sh', 'स': 's', 'ह': 'h',
    'क्ष': 'ksh', 'त्र': 'tr', 'ज्ञ': 'gy',
    'क़': 'q', 'ख़': 'kh', 'ग़': 'g', 'ज़': 'z', 'ड़': 'r', 'ढ़': 'rh', 'फ़': 'f'
  };

  const devanagariNumbers: Record<string, string> = {
    '०': '0', '१': '1', '२': '2', '३': '3', '४': '4', '५': '5', '६': '6', '७': '7', '८': '8', '९': '9'
  };

  const arabicUrduMap: Record<string, string> = {
    'ا': 'a', 'ب': 'b', 'پ': 'p', 'ت': 't', 'ٹ': 't', 'ث': 's', 'ج': 'j', 'چ': 'ch', 'ح': 'h', 'ख': 'kh', 'خ': 'kh',
    'द': 'd', 'د': 'd', 'ڈ': 'd', 'ذ': 'z', 'र': 'r', 'ر': 'r', 'ڑ': 'r', 'ज': 'j', 'ज़': 'z', 'ड़': 'r', 'ढ़': 'rh', 'फ़': 'f',
    'ص': 's', 'ض': 'z', 'ط': 't', 'ظ': 'z', 'ع': 'a', 'غ': 'gh', 'ف': 'f', 'ق': 'q', 'ک': 'k', 'گ': 'g',
    'ل': 'l', 'م': 'm', 'ن': 'n', 'و': 'w', 'ہ': 'h', 'ھ': 'h', 'ء': "'", 'ی': 'y', 'ے': 'e', 'ँ': 'n',
    'آ': 'aa', 'ؤ': 'o', 'ئ': 'y', 'ں': 'n', 'ۃ': 'h', 'َ': 'a', 'ُ': 'u', 'ِ': 'i', 'ّ': '', 'ً': 'an'
  };

  let result = "";
  let i = 0;
  while (i < text.length) {
    const char = text[i];

    // Handle Devanagari Numbers
    if (devanagariNumbers[char] !== undefined) {
      result += devanagariNumbers[char];
      i++;
      continue;
    }

    // Handle Devanagari Danda
    if (char === '।') {
      result += '.';
      i++;
      continue;
    }

    // Handle Devanagari Vowels
    if (devanagariVowels[char] !== undefined) {
      result += devanagariVowels[char];
      i++;
      continue;
    }

    // Handle Devanagari Consonants
    if (devanagariConsonants[char] !== undefined) {
      let romanCons = devanagariConsonants[char];
      let nextChar = text[i + 1];

      // Check if next char is a nukta (U+093C) which modifies the consonant
      if (nextChar === '़') {
        const keyWithNukta = char + '़';
        if (devanagariConsonants[keyWithNukta] !== undefined) {
          romanCons = devanagariConsonants[keyWithNukta];
          i++; // consumed nukta
          nextChar = text[i + 1];
        }
      }

      if (nextChar === undefined) {
        result += romanCons;
        i++;
      } else if (nextChar === '्') {
        result += romanCons;
        i += 2; // skip halant
      } else if (devanagariMatras[nextChar] !== undefined) {
        result += romanCons + devanagariMatras[nextChar];
        i += 2; // skip matra
      } else {
        const isNextSpaceOrPunct = /[\s\p{P}]/u.test(nextChar);
        if (isNextSpaceOrPunct) {
          result += romanCons;
        } else {
          result += romanCons + 'a';
        }
        i++;
      }
      continue;
    }

    // Handle Arabic/Urdu Letters
    if (arabicUrduMap[char] !== undefined) {
      result += arabicUrduMap[char];
      i++;
      continue;
    }

    // Pass through standard ASCII / Latin-1 characters
    const code = char.charCodeAt(0);
    if (code <= 255) {
      result += char;
    } else {
      // Clean up/strip other non-Latin blocks to prevent garbage blocks
      if (char === '•' || char === '—' || char === '–' || char === '“' || char === '”' || char === '‘' || char === '’') {
        result += char;
      } else if (/[\s\p{P}]/u.test(char)) {
        result += char;
      } else {
        // Fallback for Chinese, Japanese, Korean, Telugu, Bengali etc. - leave blank/space
      }
    }
    i++;
  }

  // Double check resulting strings don't contain stray unmapped non-Latin codes
  let cleanResult = "";
  for (let k = 0; k < result.length; k++) {
    const cCode = result.charCodeAt(k);
    if (cCode <= 255) {
      cleanResult += result[k];
    } else {
      if (result[k] === '’' || result[k] === '‘') cleanResult += "'";
      else if (result[k] === '“' || result[k] === '”') cleanResult += '"';
      else if (result[k] === '–' || result[k] === '—') cleanResult += "-";
      else cleanResult += " ";
    }
  }

  return cleanResult;
}

export const cleanBlackboardContent = (rawText: string): string => {
  if (!rawText) return "";
  let clean = rawText;
  // Remove non-visual internal pedagogical tags while preserving 2D vector SVG diagrams, schematics, and math
  clean = clean.replace(/<DRAW_IMAGE>[\s\S]*?<\/DRAW_IMAGE>/gi, "");
  clean = clean.replace(/<ANNOTATIONS>[\s\S]*?<\/ANNOTATIONS>/gi, "");
  clean = clean.replace(/<PEER_AGENT>[\s\S]*?<\/PEER_AGENT>/gi, "");
  clean = clean.replace(/<DIAGNOSTIC_CARD[\s\S]*?<\/DIAGNOSTIC_CARD>/gi, "");
  clean = clean.replace(/<GENERATE_VIDEO>[\s\S]*?<\/GENERATE_VIDEO>/gi, "");
  return formatMarkdownWithInlineSvgs(clean.trim());
};

export interface BoardworkTimingResult {
  totalChars: number;
  totalWords: number;
  estimatedWritingDurationMs: number;
  estimatedAudioDurationMs: number;
  calculatedPlaybackRate: number;
  charIntervalMs: number;
  punctuationDelays: {
    sentenceMs: number;
    clauseMs: number;
    newlineMs: number;
    spaceMs: number;
    mathMs: number;
  };
}

export const calculateBoardworkTiming = (
  rawContent: string,
  options?: {
    ttsRate?: number;
    typingPace?: string;
    blackboardWritingSpeed?: number;
    isAdaptiveSpeedEnabled?: boolean;
    isBreathingPausesEnabled?: boolean;
  }
): BoardworkTimingResult => {
  const clean = cleanBlackboardContent(rawContent);
  const totalChars = clean.length;
  const words = clean.split(/\s+/).filter(Boolean);
  const totalWords = words.length;

  const ttsRate = options?.ttsRate ?? 1.0;
  const pace = options?.typingPace ?? 'fluent';
  const speed = options?.blackboardWritingSpeed ?? (
    pace === 'swift' ? 1.6 : pace === 'deliberate' ? 0.6 : pace === 'instant' ? 3.0 : 1.0
  );
  const isAdaptive = options?.isAdaptiveSpeedEnabled ?? false;
  const isBreathing = options?.isBreathingPausesEnabled ?? true;

  // Base character delay in ms for simulated handwriting
  let baseCharMs = 28;
  if (pace === 'swift') baseCharMs = 14;
  else if (pace === 'deliberate') baseCharMs = 45;
  else if (pace === 'instant') baseCharMs = 1;

  // Scale base character and punctuation delays by writing speed multiplier
  baseCharMs = Math.max(1, Math.round(baseCharMs / speed));

  let sentencePauseMs = Math.max(20, Math.round((isBreathing ? 380 : 200) / speed));
  let clausePauseMs = Math.max(10, Math.round((isBreathing ? 180 : 100) / speed));
  let newlinePauseMs = Math.max(15, Math.round((isBreathing ? 280 : 140) / speed));
  let spacePauseMs = Math.max(5, Math.round(30 / speed));
  let mathPauseMs = Math.max(5, Math.round((isAdaptive ? 50 : 25) / speed));

  let sentenceCount = 0;
  let clauseCount = 0;
  let newlineCount = 0;
  let mathSymbolsCount = 0;

  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    if (ch === '.' || ch === '!' || ch === '?') sentenceCount++;
    else if (ch === ',' || ch === ';' || ch === ':') clauseCount++;
    else if (ch === '\n') newlineCount++;
    else if (/[√∫∑πθλΔ≈≠≤≥±\^_{}\\=+\-*\/<>]/.test(ch)) mathSymbolsCount++;
  }

  let writingTimeMs = totalChars * baseCharMs 
    + sentenceCount * sentencePauseMs 
    + clauseCount * clausePauseMs 
    + newlineCount * newlinePauseMs 
    + totalWords * spacePauseMs 
    + mathSymbolsCount * mathPauseMs;

  if (writingTimeMs < 100) writingTimeMs = 100;

  // Estimated natural spoken lecture duration (~270ms per spoken word at 1.0x rate)
  const baseAudioDurationMs = Math.max(1, totalWords * 270);
  const targetAudioDurationMs = baseAudioDurationMs / Math.max(0.5, ttsRate);

  // Synchronized paced playback rate matching writing speed
  const timingRatio = writingTimeMs > 0 ? targetAudioDurationMs / writingTimeMs : 1.0;
  const calculatedPlaybackRate = Math.min(1.6, Math.max(0.5, Number((ttsRate * Math.sqrt(timingRatio)).toFixed(2))));

  return {
    totalChars,
    totalWords,
    estimatedWritingDurationMs: writingTimeMs,
    estimatedAudioDurationMs: targetAudioDurationMs,
    calculatedPlaybackRate,
    charIntervalMs: baseCharMs,
    punctuationDelays: {
      sentenceMs: sentencePauseMs,
      clauseMs: clausePauseMs,
      newlineMs: newlinePauseMs,
      spaceMs: spacePauseMs,
      mathMs: mathPauseMs
    }
  };
};

const cleanTextForNaturalSpeech = (rawText: string, precision: 'standard' | 'formal' = 'standard'): string => {
  if (!rawText) return "";
  let clean = rawText;
  clean = clean.replace(/\be\.g\./gi, "for example");
  clean = clean.replace(/\bi\.e\./gi, "that is");
  // 1. Remove markdown code blocks, raw SVG markup, and drawing/meta tags
  clean = clean.replace(/```[\s\S]*?```/g, " ");
  clean = clean.replace(/<svg[\s\S]*?<\/svg>/gi, " ");
  clean = clean.replace(/<DRAW_IMAGE>[\s\S]*?<\/DRAW_IMAGE>/gi, " ");
  clean = clean.replace(/<ANNOTATIONS>[\s\S]*?<\/ANNOTATIONS>/gi, " ");
  clean = clean.replace(/<PEER_AGENT>[\s\S]*?<\/PEER_AGENT>/gi, " ");
  clean = clean.replace(/<DIAGNOSTIC_CARD[\s\S]*?<\/DIAGNOSTIC_CARD>/gi, " ");
  clean = clean.replace(/<GENERATE_VIDEO>[\s\S]*?<\/GENERATE_VIDEO>/gi, " ");
  // Aggressively remove any meta-text, introductory preamble, or narrative about the diagram/drawing
  clean = clean.replace(/(?:let me|i will|i am going to|i'm going to|here is|below is|let's|i've created|i've drawn|i'll draw|i'll create|now drawing|drawing|making|creating|as seen in|as shown in|looking at|referring to|in the following|the following)\s+(?:draw|create|generate|show|render|provide|make|see|examine)?\s*(?:a|an|the)?\s*(?:2d\s*)?(?:diagram|drawing|figure|schematic|illustration|chart|graph|boardwork|visual|2d vector|vector drawing)(?:[^\n.]*)[.:]?\s*/gi, "");
  clean = clean.replace(/(?:this|the following|the above)\s+(?:2d\s*)?(?:diagram|drawing|figure|schematic|illustration|vector graphic)\s+(?:shows|illustrates|depicts|demonstrates|represents|provides|explains)[^\n.]*[.:]?\s*/gi, "");
  clean = clean.replace(/(?:यहाँ|मैं|आरेख|चित्र|डायग्राम|नीचे)\s*(?:एक|का|दिया गया)?\s*(?:आरेख|चित्र|डायग्राम|ड्रॉइंग|रेखाचित्र)\s*(?:बना रहा हूँ|बनाया है|दिखा रहा हूँ|देखें|दर्शित है|दर्शाता है)[.:]?\s*/gi, "");
  clean = clean.replace(/<[^>]+>/g, " ");
  // 2. Convert LaTeX math blocks to spoken text
  clean = clean.replace(/\$\$([\s\S]*?)\$\$/g, (_, math) => " " + convertLaTeXToSpokenText(math) + " ");
  clean = clean.replace(/\\\[([\s\S]*?)\\\]/g, (_, math) => " " + convertLaTeXToSpokenText(math) + " ");
  clean = clean.replace(/\\\(([\s\S]*?)\\\)/g, (_, math) => " " + convertLaTeXToSpokenText(math) + " ");
  clean = clean.replace(/\$([^$]+)\$/g, (_, math) => " " + convertLaTeXToSpokenText(math) + " ");
  // 3. Remove inline code backticks or replace inline code with empty if it looks like code syntax
  clean = clean.replace(/`([^`\n]+)`/g, (_, code) => {
    if (code.includes('(') || code.includes(')') || code.includes('=') || code.includes(';') || code.includes('{') || code.includes('}') || code.includes('=>') || code.includes('[') || code.includes(']')) {
      return "";
    }
    return code;
  });
  // 4. Clean Markdown links [Label](URL) -> Label
  clean = clean.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");
  // 5. Remove any leftover markdown formatting symbols or special math/code chars (except normal speech punctuation)
  clean = clean.replace(/[*#_~>+\-`$]/g, " ");
  // 6. Replace multiple consecutive whitespace (except newlines) with a single space, but clean extra spaces around newlines
  clean = clean.replace(/[ \t\r\f\v]+/g, " ");
  clean = clean.replace(/ *\n * /g, "\n");
  clean = clean.replace(/\n{3,}/g, "\n\n"); // Collapse 3+ newlines to max 2
  return expandAbbreviationsForSpeech(clean.trim(), precision);
};

export interface WordTimestampCue {
  index: number;
  word: string;
  cleanWord: string;
  startMs: number;
  endMs: number;
  durationMs: number;
  startRatio: number;
  endRatio: number;
  weight: number;
  syllables: number;
  phonemeCount: number;
  cadenceType: 'monosyllabic' | 'standard' | 'polysyllabic' | 'acronym' | 'numeric' | 'equation' | 'emphasis';
  pauseAfterMs: number;
  isPunctuationBoundary: boolean;
  isSentenceEnd: boolean;
  isClauseEnd: boolean;
  isParagraphEnd: boolean;
  stressPeakRatio?: number;
}

export interface WordTimestampMatrix {
  text: string;
  totalAudioDurationMs: number;
  playbackRate: number;
  wordsList: string[];
  cumulativeWeights: number[];
  cues: WordTimestampCue[];
  totalWords: number;
  totalSyllables: number;
  totalPhonemes: number;
  averageWpm: number;
  sentenceMap: Map<number, number>;
  getCueAtTime: (elapsedMs: number) => WordTimestampCue | null;
  getCueAtIndex: (wordIdx: number) => WordTimestampCue | null;
  getWordIndexAtTime: (elapsedMs: number) => number;
  getProgressRatioAtTime: (elapsedMs: number) => number;
}

/**
 * Phonetic & Articulatory Acoustic Estimator
 * Resolves IPA / phonemic complexity, plosives, fricatives, nasals, diphthongs,
 * and syllable weights for English, Indic, Arabic, & Multilingual Speech.
 */
const countSyllablesAndPhonemes = (word: string): { syllables: number; phonemes: number; plosiveFricativeBias: number } => {
  if (!word) return { syllables: 1, phonemes: 1, plosiveFricativeBias: 1.0 };
  const lower = word.toLowerCase();

  // Handle Indic / Devanagari Unicode scripts (counting Matras / Aksharas)
  if (/[\u0900-\u097F]/.test(word)) {
    const devanagariVowels = word.match(/[\u0904-\u0914\u093E-\u094C\u0962\u0963]/g);
    const devanagariConsonants = word.match(/[\u0915-\u0939]/g);
    const syllables = Math.max(1, (devanagariVowels ? devanagariVowels.length : 0) + (devanagariConsonants ? Math.ceil(devanagariConsonants.length * 0.8) : 1));
    const phonemes = Math.max(syllables, word.length);
    return { syllables, phonemes, plosiveFricativeBias: 1.15 };
  }

  // Handle Arabic script
  if (/[\u0600-\u06FF]/.test(word)) {
    const arabicVowels = word.match(/[\u064E-\u0650\u064B-\u064D\u0651\u0670\u0627\u0648\u064A]/g);
    const syllables = Math.max(1, arabicVowels ? arabicVowels.length : Math.ceil(word.length / 2));
    return { syllables, phonemes: Math.max(syllables, word.length), plosiveFricativeBias: 1.1 };
  }

  // English & Latin-based phonetic estimation
  const cleanWord = lower.replace(/[^a-z]/g, '');
  if (!cleanWord) return { syllables: 1, phonemes: 1, plosiveFricativeBias: 1.0 };
  if (cleanWord.length <= 3) return { syllables: 1, phonemes: cleanWord.length, plosiveFricativeBias: 0.9 };

  // Common suffix reductions and adjustments
  let processed = cleanWord
    .replace(/(?:[^laeiouy]|ed|es|e)$/, '') // Silent ending 'e', 'es', 'ed'
    .replace(/^y/, ''); // Initial 'y' is consonant

  // Vowel diphthongs and clusters
  const vowelMatches = processed.match(/[aeiouy]{1,2}/g);
  let syllables = vowelMatches ? vowelMatches.length : 1;

  // Add back syllable for specific endings where 'e' or 'es' is pronounced (e.g., "recipe", "simile", "ses", "zes", "ches", "shes")
  if (/(?:ches|shes|sses|zes|ges)$/.test(cleanWord) && syllables === 1 && cleanWord.length > 4) {
    syllables += 1;
  }
  if (/(?:tion|sion|cial|tial|ious|eous|ance|ence)$/.test(cleanWord)) {
    syllables = Math.max(2, syllables);
  }

  syllables = Math.max(1, syllables);

  // Plosive & Fricative acoustic weight calculation (e.g., 'p', 'b', 't', 'd', 'k', 'g', 's', 'z', 'th', 'ch', 'sh')
  const plosivesAndFricatives = (cleanWord.match(/[pbtdkgszfv]|th|ch|sh|ph|qu|gh/g) || []).length;
  const plosiveFricativeBias = 1.0 + (plosivesAndFricatives * 0.04);

  // Phoneme count estimation based on consonant-vowel clusters & digraphs
  const digraphs = (cleanWord.match(/(?:th|ch|sh|ph|wh|qu|gh|ck|ng|oo|ee|ea|ai|ay|oi|oy|ou|ow|au|aw)/g) || []).length;
  const phonemes = Math.max(syllables, cleanWord.length - digraphs);

  return { syllables, phonemes, plosiveFricativeBias };
};

/**
 * Highly Calibrated Word Timestamp Matrix Engine
 * Computes exact start/end millisecond timestamps with acoustic energy profiling,
 * sub-syllable duration envelopes, and zero-drift hardware synchronization.
 */
export const buildWordTimestampMatrix = (
  cleanText: string,
  totalAudioDurationMs?: number,
  playbackRate: number = 1.0
): WordTimestampMatrix => {
  if (!cleanText) {
    return {
      text: "",
      totalAudioDurationMs: 0,
      playbackRate,
      wordsList: [],
      cumulativeWeights: [],
      cues: [],
      totalWords: 0,
      totalSyllables: 0,
      totalPhonemes: 0,
      averageWpm: 0,
      sentenceMap: new Map(),
      getCueAtTime: () => null,
      getCueAtIndex: () => null,
      getWordIndexAtTime: () => -1,
      getProgressRatioAtTime: () => 0
    };
  }

  const tokens = cleanText.split(/(\s+)/);
  const wordsList: string[] = [];
  const rawWeights: number[] = [];
  const pauseWeights: number[] = [];
  const syllableCounts: number[] = [];
  const phonemeCounts: number[] = [];
  const cadenceTypes: WordTimestampCue['cadenceType'][] = [];
  const punctuationFlags: { isSentenceEnd: boolean; isClauseEnd: boolean; isParagraphEnd: boolean }[] = [];

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (!token) continue;

    // Whitespace token: assign prospective acoustic pause weights to the immediately preceding word
    if (/^\s+$/.test(token)) {
      if (wordsList.length > 0) {
        const prevIdx = wordsList.length - 1;
        if (token.includes('\n\n')) {
          pauseWeights[prevIdx] += 12.0; // Paragraph pause (~600-750ms)
          punctuationFlags[prevIdx].isParagraphEnd = true;
        } else if (token.includes('\n')) {
          pauseWeights[prevIdx] += 6.0; // Line break pause (~300-400ms)
          punctuationFlags[prevIdx].isClauseEnd = true;
        }
      }
      continue;
    }

    const cleanWord = token.replace(/[^\p{L}\p{N}]/gu, "").trim();
    if (!cleanWord) {
      continue;
    }

    wordsList.push(token);

    const { syllables, phonemes, plosiveFricativeBias } = countSyllablesAndPhonemes(cleanWord);
    syllableCounts.push(syllables);
    phonemeCounts.push(phonemes);

    // Baseline acoustic articulation weight: calibrated blend of phonemes, syllables, and articulatory friction
    let weight = ((phonemes * 0.50) + (syllables * 1.80)) * plosiveFricativeBias;
    let cadenceType: WordTimestampCue['cadenceType'] = 'standard';

    // 1. Monosyllabic functional words vs content words
    if (syllables === 1) {
      if (/^(?:a|an|the|in|on|at|to|of|for|by|and|or|as|is|it|if|so|up|out|no)$/i.test(cleanWord)) {
        weight *= 0.68; // Function words are spoken swiftly in connected speech
        cadenceType = 'monosyllabic';
      }
    }

    // 2. Polysyllabic deceleration (longer cognitive processing & phonetic articulation)
    if (syllables >= 4 || cleanWord.length >= 10) {
      weight *= 1.30;
      cadenceType = 'polysyllabic';
    } else if (syllables === 3) {
      weight *= 1.14;
      cadenceType = 'polysyllabic';
    }

    // 3. Acronyms & initialisms (spelled letter-by-letter, taking significant vocal time)
    if (cleanWord.length > 1 && /^[A-Z%$\-+]+$/.test(cleanWord)) {
      weight = (cleanWord.length * 4.0) + 1.8;
      cadenceType = 'acronym';
    }

    // 4. Numeric values & mathematical digits
    if (/\d+/.test(cleanWord)) {
      const digitCount = cleanWord.replace(/\D/g, '').length;
      weight += (digitCount * 4.2);
      cadenceType = 'numeric';
    }

    // 5. Mathematical symbols & equations (e.g. integral, square root, theta)
    if (/[√∫∑πθλΔ≈≠≤≥±\^_{}\\=+\-*\/<>]/.test(token)) {
      weight += 3.5;
      cadenceType = 'equation';
    }

    // 6. Emphasis markers (e.g. ALL CAPS words within sentences)
    if (cleanWord.length > 1 && cleanWord === cleanWord.toUpperCase() && !/^[A-Z0-9]+$/.test(cleanWord)) {
      weight *= 1.25;
      cadenceType = 'emphasis';
    }

    cadenceTypes.push(cadenceType);

    // Micro-prosodic punctuation boundary timing
    let isSentenceEnd = false;
    let isClauseEnd = false;
    let isParagraphEnd = false;
    let pauseWeight = 0;

    if (token.endsWith('...') || token.endsWith('…')) {
      pauseWeight += 8.0; // Trailing thought pause (~450ms)
      isClauseEnd = true;
    } else if (token.endsWith('.') || token.endsWith('!') || token.endsWith('?')) {
      pauseWeight += 7.5; // Terminal sentence cadence pause (~500-600ms)
      isSentenceEnd = true;
    } else if (token.endsWith(',') || token.endsWith(';') || token.endsWith(':') || token.endsWith('—') || token.endsWith('-')) {
      pauseWeight += 4.0; // Clause cadence pause (~250-320ms)
      isClauseEnd = true;
    } else if (token.endsWith(')') || token.endsWith(']')) {
      pauseWeight += 1.8;
    }

    rawWeights.push(weight);
    pauseWeights.push(pauseWeight);
    punctuationFlags.push({ isSentenceEnd, isClauseEnd, isParagraphEnd });
  }

  const totalWords = wordsList.length;
  if (totalWords === 0) {
    return {
      text: cleanText,
      totalAudioDurationMs: 0,
      playbackRate,
      wordsList: [],
      cumulativeWeights: [],
      cues: [],
      totalWords: 0,
      totalSyllables: 0,
      totalPhonemes: 0,
      averageWpm: 0,
      sentenceMap: new Map(),
      getCueAtTime: () => null,
      getCueAtIndex: () => null,
      getWordIndexAtTime: () => -1,
      getProgressRatioAtTime: () => 0
    };
  }

  // Combined weights incorporating adaptive vocal cadence and prosody pauses
  const combinedWeights = rawWeights.map((w, idx) => w + (pauseWeights[idx] || 0));
  const totalWeight = combinedWeights.reduce((sum, w) => sum + w, 0);

  const totalSyllables = syllableCounts.reduce((sum, s) => sum + s, 0);
  const totalPhonemes = phonemeCounts.reduce((sum, p) => sum + p, 0);

  // Calibrated acoustic duration baseline if hardware decoded buffer length is not yet provided:
  const estimatedPhoneticDurationMs = ((totalPhonemes * 42) + (totalSyllables * 130) + (totalWords * 35)) / Math.max(0.5, playbackRate);

  const durationMs = totalAudioDurationMs && totalAudioDurationMs > 0
    ? totalAudioDurationMs
    : Math.max(250, estimatedPhoneticDurationMs);

  const averageWpm = durationMs > 0 ? Math.round((totalWords / (durationMs / 60000))) : 150;

  const cumulativeWeights: number[] = [];
  const cues: WordTimestampCue[] = [];
  const sentenceMap = new Map<number, number>();

  let runningWeight = 0;
  let currentSentenceIdx = 0;

  for (let idx = 0; idx < totalWords; idx++) {
    const wordWeight = combinedWeights[idx];
    const prevWeight = runningWeight;
    runningWeight += wordWeight;

    const startRatio = totalWeight > 0 ? prevWeight / totalWeight : 0;
    const endRatio = totalWeight > 0 ? runningWeight / totalWeight : 0;
    cumulativeWeights.push(endRatio);

    const startMs = startRatio * durationMs;
    const endMs = endRatio * durationMs;
    const durationWordMs = Math.max(15, endMs - startMs);

    const pauseWeightPart = pauseWeights[idx] || 0;
    const pauseRatio = totalWeight > 0 ? pauseWeightPart / totalWeight : 0;
    const pauseAfterMs = pauseRatio * durationMs;

    sentenceMap.set(idx, currentSentenceIdx);
    if (punctuationFlags[idx].isSentenceEnd) {
      currentSentenceIdx++;
    }

    cues.push({
      index: idx,
      word: wordsList[idx],
      cleanWord: wordsList[idx].replace(/[^\p{L}\p{N}]/gu, "").trim(),
      startMs,
      endMs,
      durationMs: durationWordMs,
      startRatio,
      endRatio,
      weight: wordWeight,
      syllables: syllableCounts[idx] || 1,
      phonemeCount: phonemeCounts[idx] || 1,
      cadenceType: cadenceTypes[idx] || 'standard',
      pauseAfterMs,
      isPunctuationBoundary: punctuationFlags[idx].isSentenceEnd || punctuationFlags[idx].isClauseEnd,
      isSentenceEnd: punctuationFlags[idx].isSentenceEnd,
      isClauseEnd: punctuationFlags[idx].isClauseEnd,
      isParagraphEnd: punctuationFlags[idx].isParagraphEnd,
      stressPeakRatio: 0.35 // Primary syllable stress peak located at 35% into the word duration
    });
  }

  // Fast binary search lookup by exact millisecond
  const getCueAtTime = (elapsedMs: number): WordTimestampCue | null => {
    if (cues.length === 0) return null;
    if (elapsedMs <= 0) return cues[0];
    if (elapsedMs >= durationMs) return cues[cues.length - 1];

    let low = 0;
    let high = cues.length - 1;

    while (low <= high) {
      const mid = Math.floor((low + high) / 2);
      const cue = cues[mid];
      if (elapsedMs >= cue.startMs && elapsedMs < cue.endMs) {
        return cue;
      }
      if (elapsedMs < cue.startMs) {
        high = mid - 1;
      } else {
        low = mid + 1;
      }
    }

    const clampedIdx = Math.max(0, Math.min(cues.length - 1, low));
    return cues[clampedIdx] || null;
  };

  const getCueAtIndex = (wordIdx: number): WordTimestampCue | null => {
    if (wordIdx < 0 || wordIdx >= cues.length) return null;
    return cues[wordIdx] || null;
  };

  const getWordIndexAtTime = (elapsedMs: number): number => {
    const cue = getCueAtTime(elapsedMs);
    return cue ? cue.index : (elapsedMs >= durationMs ? totalWords - 1 : 0);
  };

  const getProgressRatioAtTime = (elapsedMs: number): number => {
    if (durationMs <= 0) return 0;
    return Math.max(0, Math.min(1, elapsedMs / durationMs));
  };

  return {
    text: cleanText,
    totalAudioDurationMs: durationMs,
    playbackRate,
    wordsList,
    cumulativeWeights,
    cues,
    totalWords,
    totalSyllables,
    totalPhonemes,
    averageWpm,
    sentenceMap,
    getCueAtTime,
    getCueAtIndex,
    getWordIndexAtTime,
    getProgressRatioAtTime
  };
};

/**
 * Unified Speech & Text Sync Engine (backward-compatible adapter built on Timestamp Matrix)
 */
const computeUnifiedSyncWeights = (cleanText: string): { wordsList: string[]; cumulativeWeights: number[]; matrix?: WordTimestampMatrix } => {
  if (!cleanText) return { wordsList: [], cumulativeWeights: [] };
  const matrix = buildWordTimestampMatrix(cleanText);
  return {
    wordsList: matrix.wordsList,
    cumulativeWeights: matrix.cumulativeWeights,
    matrix
  };
};

const InlineWaveform: React.FC<{ analyser: AnalyserNode | null; isPlaying: boolean }> = ({ analyser, isPlaying }) => {
  const [heights, setHeights] = useState<number[]>([2, 4, 3, 5, 2]);
  const animationRef = useRef<number | null>(null);

  useEffect(() => {
    if (!isPlaying) {
      return;
    }

    const dataArray = analyser ? new Uint8Array(analyser.frequencyBinCount) : null;
    
    const update = () => {
      let newHeights = [];
      if (analyser && dataArray) {
        analyser.getByteFrequencyData(dataArray);
        const step = Math.floor(dataArray.length / 5);
        newHeights = Array.from({ length: 5 }, (_, i) => {
          const val = dataArray[i * step] / 255;
          return 2 + val * 10;
        });
      } else {
        const time = Date.now() * 0.012;
        newHeights = Array.from({ length: 5 }, (_, i) => {
          const base = Math.sin(time + i * 1.2) * 4 + 6;
          const noise = Math.random() * 3;
          return Math.max(2, Math.min(12, base + noise));
        });
      }
      setHeights(newHeights);
      animationRef.current = requestAnimationFrame(update);
    };

    update();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, analyser]);

  return (
    <span className="inline-flex items-end gap-[1.5px] h-3.5 px-1 bg-emerald-400/20 rounded border border-emerald-400/30 align-middle ml-1 mr-0.5 select-none animate-in fade-in zoom-in-50 duration-200">
      {heights.map((h, i) => (
        <span 
          key={i} 
          className="w-[1.5px] bg-emerald-400 rounded-full transition-all duration-75" 
          style={{ height: `${h}px` }} 
        />
      ))}
    </span>
  );
};

const TypewriterMarkdown: React.FC<{
  content: string;
  isAnimated: boolean;
  isChalkSfxEnabled: boolean;
  theme: 'light' | 'dark';
  speakingWordIndex?: number;
  isCurrentSpeaking?: boolean;
  isPaused?: boolean;
  typingPace?: string;
  blackboardWritingSpeed?: number;
  isWordHighlightingEnabled?: boolean;
  onTypingProgress?: () => void;
  onComplete?: () => void;
  isLectureMode?: boolean;
  analyser?: AnalyserNode | null;
  onSendMessage: (text: string, imageBase64?: string) => void;
  scrollDuration?: number;
  scrollEasing?: 'smooth' | 'ease-in-out' | 'ease-out' | 'spring' | 'instant';
  scrollThreshold?: number;
  scrollTargetCenter?: number;
  isAdaptiveSpeedEnabled?: boolean;
  isBreathingPausesEnabled?: boolean;
  isSpotlightEnabled?: boolean;
  ttsRate?: number;
  isVoiceTrackingEnabled?: boolean;
  isAutoScrollPaused?: boolean;
  pronunciationPrecision?: 'standard' | 'formal';
  isRecordingAi?: boolean;
  onOpenWhiteboard?: (svgDataUrl: string) => void;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  onRenderComplete?: () => void;
  canvasUiManager?: UnifiedCanvasUiManager;
}> = ({ 
  content, 
  isAnimated, 
  isChalkSfxEnabled, 
  theme, 
  speakingWordIndex = -1, 
  isCurrentSpeaking = false, 
  isPaused = false,
  typingPace = 'fluent', 
  blackboardWritingSpeed = 1.0,
  isWordHighlightingEnabled = true, 
  onTypingProgress, 
  onComplete,
  isLectureMode = false,
  analyser = null,
  onSendMessage,
  scrollDuration = 450,
  scrollEasing = 'ease-out',
  scrollThreshold = 0.66,
  scrollTargetCenter = 0.45,
  isAdaptiveSpeedEnabled = false,
  isBreathingPausesEnabled = true,
  isSpotlightEnabled = false,
  ttsRate = 1.0,
  isVoiceTrackingEnabled = true,
  isAutoScrollPaused = false,
  pronunciationPrecision = 'standard',
  isRecordingAi = false,
  onOpenWhiteboard,
  showNotification,
  onRenderComplete,
  canvasUiManager
}) => {
  const blackboardText = React.useMemo(() => cleanBlackboardContent(content), [content]);
  const [displayedText, setDisplayedText] = useState(blackboardText);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const wordRefs = useRef<Map<number, HTMLSpanElement>>(new Map());
  const lastPlayedWordIndexRef = useRef<number>(-1);

  // Reset last played word index and refs when content changes or speaking starts
  useEffect(() => {
    wordRefs.current.clear();
    lastPlayedWordIndexRef.current = -1;
    setDisplayedText(blackboardText);
    setIsTyping(false);
    if (onComplete) onComplete();
  }, [blackboardText]);

  // Pre-calculate word-to-sentence mapping
  const { wordToSentenceMap, totalSpokenWords } = React.useMemo(() => {
    const cleanText = cleanTextForNaturalSpeech(blackboardText, pronunciationPrecision);
    const wordsList = cleanText.split(/\s+/).filter(Boolean).filter(w => w.replace(/[^\p{L}\p{N}]/gu, "").trim().length > 0);
    
    const map = new Map<number, number>();
    let currentSentenceId = 0;
    
    wordsList.forEach((word, idx) => {
      map.set(idx, currentSentenceId);
      if (/[.?!;:]+$/.test(word)) {
        currentSentenceId++;
      }
    });
    return { wordToSentenceMap: map, totalSpokenWords: wordsList.length };
  }, [blackboardText, pronunciationPrecision]);

  // Find active sentence ID
  const activeSentenceId = React.useMemo(() => {
    if (!isCurrentSpeaking || speakingWordIndex < 0) return -1;
    return wordToSentenceMap.get(speakingWordIndex) ?? -1;
  }, [isCurrentSpeaking, speakingWordIndex, wordToSentenceMap]);

  const customSmoothScroll = (
    element: HTMLElement,
    to: number,
    duration: number,
    easing: 'smooth' | 'ease-in-out' | 'ease-out' | 'spring' | 'instant'
  ) => {
    if (easing === 'instant' || duration <= 0) {
      element.scrollTop = to;
      return;
    }

    if (easing === 'smooth') {
      element.scrollTo({
        top: to,
        behavior: 'smooth'
      });
      return;
    }

    const start = element.scrollTop;
    const change = to - start;
    if (Math.abs(change) < 2) {
      element.scrollTop = to;
      return;
    }

    const startTime = performance.now();

    const animateScroll = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      let easeProgress = progress;
      if (easing === 'ease-in-out') {
        easeProgress = progress < 0.5 ? 2 * progress * progress : -1 + (4 - 2 * progress) * progress;
      } else if (easing === 'ease-out') {
        const p = progress - 1;
        easeProgress = p * p * p + 1;
      } else if (easing === 'spring') {
        const c4 = (2 * Math.PI) / 3;
        easeProgress = progress === 0 ? 0 : progress === 1 ? 1 : Math.pow(2, -10 * progress) * Math.sin((progress * 10 - 0.75) * c4) + 1;
      }

      element.scrollTop = start + change * easeProgress;

      if (elapsed < duration) {
        requestAnimationFrame(animateScroll);
      } else {
        element.scrollTop = to;
      }
    };

    requestAnimationFrame(animateScroll);
  };

  const adjustScrollPosition = () => {
    if (isAutoScrollPaused) return;
    
    // Use either the active speaking word or the bottom of our own container
    let targetElement: HTMLElement | null = null;
    if (isCurrentSpeaking && speakingWordIndex >= 0) {
      targetElement = wordRefs.current.get(speakingWordIndex) || null;
    }
    
    // Fallback to our own container bottom
    const elementToMeasure = targetElement || scrollRef.current;
    if (!elementToMeasure) return;

    const container = elementToMeasure.closest('.messages-scroll-container') || document.querySelector('.messages-scroll-container');
    if (!container) return;

    const containerRect = container.getBoundingClientRect();
    const elemRect = elementToMeasure.getBoundingClientRect();
    
    // Calculate relative bottom of the element within the viewport of the scroll container
    const relativeBottom = elemRect.bottom - containerRect.top;
    const thresholdLine = containerRect.height * scrollThreshold;

    if (relativeBottom > thresholdLine) {
      // Scroll to position the active line beautifully at target center from the top
      let finalDuration = scrollDuration;
      let finalEasing = scrollEasing;

      const distanceNeeded = relativeBottom - containerRect.height * scrollTargetCenter;
      
      // If the scroll lag is too high (distance to cover is greater than 35% of the container height), accelerate!
      if (distanceNeeded > containerRect.height * 0.35) {
        finalDuration = Math.max(120, Math.round(scrollDuration * 0.4)); // 60% faster
        if (finalEasing !== 'instant') {
          finalEasing = 'spring'; // Spring is highly energetic and great for catching up
        }
      }

      const targetScrollTop = container.scrollTop + distanceNeeded;
      customSmoothScroll(container as HTMLElement, targetScrollTop, finalDuration, finalEasing);
    }
  };

  // Scroll current speaking word into view
  useEffect(() => {
    if (isCurrentSpeaking && speakingWordIndex >= 0) {
      const activeWord = wordRefs.current.get(speakingWordIndex);
      if (activeWord) {
        adjustScrollPosition();
      }
    }
  }, [speakingWordIndex, isCurrentSpeaking]);

  // Sync state with content changes - always instant without letter-by-letter animation
  useEffect(() => {
    setDisplayedText(blackboardText);
    setIsTyping(false);
    currentCharCountRef.current = blackboardText.length;
    if (onComplete) {
      onComplete();
    }
  }, [blackboardText, onComplete]);

  const playChalkSound = (wordLength?: number) => {
    if (!isChalkSfxEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const lengthFactor = wordLength ? Math.max(0.6, Math.min(2.2, 0.4 + wordLength * 0.15)) : 1.0;
      const durationSeconds = 0.04 * lengthFactor;
      
      const bufferSize = Math.floor(ctx.sampleRate * durationSeconds);
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      
      const isLong = wordLength && wordLength > 4;
      filter.frequency.value = (isLong ? 1300 : 1800) + Math.random() * 600;
      filter.Q.value = isLong ? 3.0 : 4.5;
      
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.012, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationSeconds);
      
      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      
      noise.start();
    } catch (e) {
      // ignore
    }
  };

  // Track current character position
  const currentCharCountRef = useRef<number>(blackboardText.length);

  // Synchronized speaking mode: scrolls to active word without animating text
  useEffect(() => {
    if (isCurrentSpeaking && speakingWordIndex >= 0) {
      setDisplayedText(blackboardText);
      setIsTyping(false);
      currentCharCountRef.current = blackboardText.length;
      if (speakingWordIndex !== lastPlayedWordIndexRef.current) {
        lastPlayedWordIndexRef.current = speakingWordIndex;
        playChalkSound();
        if (onTypingProgress) {
          onTypingProgress();
        }
      }
    }
  }, [speakingWordIndex, isCurrentSpeaking, blackboardText, onTypingProgress]);

  const [tooltip, setTooltip] = useState<{ word: string; definition: string; x: number; y: number } | null>(null);
  const [isLookingUp, setIsLookingUp] = useState(false);

  const handleWordClick = async (e: React.MouseEvent) => {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    
    // Expand selection to word boundary
    selection.modify('move', 'forward', 'character');
    selection.modify('move', 'backward', 'character');
    selection.modify('extend', 'backward', 'word');
    selection.modify('extend', 'forward', 'word');
    
    const word = selection.toString().trim();
    if (!word || word.length < 2) return;
    
    setIsLookingUp(true);
    try {
      const definition = await generateAIResponse(`Provide a very concise definition (max 10 words) for the word: "${word}"`);
      setTooltip({
        word,
        definition: definition || "Definition not found.",
        x: e.clientX,
        y: e.clientY + 10
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsLookingUp(false);
    }
  };

  useEffect(() => {
    const handleClickOutside = () => setTooltip(null);
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  // Global word counter for synchronization
  let globalWordCounter = 0;

  const renderText = (text: string) => {
    if (!isCurrentSpeaking) {
      return renderSmartGlossaryText(text, (termKey) => {
        const entry = CHEMISTRY_DICTIONARY[termKey];
        if (entry) {
          setTooltip({ word: entry.term, definition: `${entry.definition} (${entry.chapter})`, x: window.innerWidth / 2 - 120, y: window.innerHeight / 2 - 60 });
        }
      });
    }
    
    const words = text.split(/(\s+)/);
    return words.map((part, i) => {
      // Clean non-alphanumeric characters to see if it's a spoken word
      const cleanPart = part.replace(/[^\p{L}\p{N}]/gu, "").trim();
      const isWordToken = cleanPart.length > 0;
      
      let currentIdx = globalWordCounter;
      if (isWordToken) {
        currentIdx = globalWordCounter++;
      }
      
      const isUnspoken = isCurrentSpeaking && currentIdx > speakingWordIndex;

      // Sequential writing sync: words appear on the blackboard in real-time as Omni AI pronounces them
      if (isUnspoken) {
        return (
          <span 
            key={`${currentIdx}-${i}`}
            className="opacity-0 select-none pointer-events-none invisible inline-block w-0 h-0 overflow-hidden"
            aria-hidden="true"
          >
            {part}
          </span>
        );
      }

      if (/\s+/.test(part)) return part;

      if (!isWordToken) {
        return <span key={`token-${currentIdx}-${i}`} className="text-amber-50/90 inline-block">{part}</span>;
      }
      
      const isActive = isCurrentSpeaking && speakingWordIndex === currentIdx && isWordHighlightingEnabled;
      const isSentenceActive = isCurrentSpeaking && activeSentenceId !== -1 && wordToSentenceMap.get(currentIdx) === activeSentenceId;
      const isPronouncedWord = isCurrentSpeaking && currentIdx < speakingWordIndex;
      
      const spotlightStyle = (isSpotlightEnabled && !isLectureMode)
        ? (isSentenceActive || isActive || isPronouncedWord
          ? "opacity-100 scale-[1.01]" 
          : "opacity-40 hover:opacity-100 transition-opacity duration-300")
        : "opacity-100";
      
      return (
        <span 
          key={`${currentIdx}-${i}`}
          ref={el => {
            if (el) wordRefs.current.set(currentIdx, el);
          }}
          className={cn(
            "transition-all duration-150 rounded px-0.5 inline-block opacity-100 animate-in fade-in-50",
            isLectureMode 
              ? (isActive 
                  ? "bg-amber-400/30 text-amber-200 font-extrabold ring-2 ring-amber-400/60 rounded px-1 scale-105 z-10 mx-0.5 shadow-md opacity-100" 
                  : isSentenceActive
                    ? "bg-emerald-500/15 text-emerald-50 font-semibold border-b border-dashed border-emerald-400/50 opacity-100"
                    : "text-amber-50 font-medium opacity-100")
              : (isActive 
                  ? "bg-amber-400/25 text-amber-200 font-bold px-1 rounded ring-1 ring-amber-400/30 z-10 opacity-100" 
                  : isSentenceActive
                    ? "bg-amber-400/10 text-amber-50 font-medium opacity-100"
                    : "text-amber-50 font-medium opacity-100"),
            spotlightStyle
          )}
        >
          {isActive ? (
            <span className="inline-flex items-center">
              <WordHighlighter words={[part.trim()]} currentWordIndex={0} />
              <span className="ml-0.5 text-xs inline-block animate-bounce select-none text-amber-300">✏️</span>
            </span>
          ) : part}
          {isActive && isLectureMode && (
            <InlineWaveform analyser={analyser} isPlaying={isActive && !isPaused} />
          )}
        </span>
      );
    });
  };

  const wrapChildren = (children: React.ReactNode) => {
    return React.Children.map(children, child => {
      if (typeof child === 'string') {
        return renderText(child);
      }
      return child;
    });
  };

  return (
    <div className={cn(
      "relative prose prose-invert max-w-none transition-all duration-300 p-4",
      isRecordingAi ? "ring-2 ring-red-500 rounded-xl bg-red-950/20" : "",
      modeStyles['learn'] || "bg-slate-900"
    )} ref={scrollRef} onClick={(e) => {
      e.stopPropagation();
      handleWordClick(e);
    }}>
      <ReactMarkdown 
        remarkPlugins={[remarkMath, remarkGfm]} 
        rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
        components={{
          p: ({ children }) => <p className="mb-3 last:mb-0 text-amber-50/90 font-medium leading-relaxed tracking-wide font-sans cursor-help">{wrapChildren(children)}</p>,
          ul: ({ children }) => <ul className="list-disc pl-5 mb-3 text-amber-50/80 font-medium space-y-1">{wrapChildren(children)}</ul>,
          ol: ({ children }) => <ol className="list-decimal pl-5 mb-3 text-amber-50/80 font-medium space-y-1">{wrapChildren(children)}</ol>,
          li: ({ children }) => <li className="text-amber-50/80">{wrapChildren(children)}</li>,
          strong: ({ children }) => <strong className="font-bold text-amber-50">{wrapChildren(children)}</strong>,
          em: ({ children }) => <em className="italic text-amber-50/90">{wrapChildren(children)}</em>,
          h1: ({ children }) => (
            <SubtopicHeadingDiagram
              level={1}
              fullContent={content}
              theme="dark"
              onOpenWhiteboard={onOpenWhiteboard}
              showNotification={showNotification}
              onRenderComplete={onRenderComplete}
              isLectureMode={isLectureMode}
            >
              {wrapChildren(children)}
            </SubtopicHeadingDiagram>
          ),
          h2: ({ children }) => (
            <SubtopicHeadingDiagram
              level={2}
              fullContent={content}
              theme="dark"
              onOpenWhiteboard={onOpenWhiteboard}
              showNotification={showNotification}
              onRenderComplete={onRenderComplete}
              isLectureMode={isLectureMode}
            >
              {wrapChildren(children)}
            </SubtopicHeadingDiagram>
          ),
          h3: ({ children }) => (
            <SubtopicHeadingDiagram
              level={3}
              fullContent={content}
              theme="dark"
              onOpenWhiteboard={onOpenWhiteboard}
              showNotification={showNotification}
              onRenderComplete={onRenderComplete}
              isLectureMode={isLectureMode}
            >
              {wrapChildren(children)}
            </SubtopicHeadingDiagram>
          ),
          table: ({ children }) => (
            <div className="my-4 overflow-x-auto rounded-xl border border-amber-300/30 bg-black/40 shadow-xl backdrop-blur-sm">
              <table className="w-full text-left border-collapse text-xs md:text-sm text-amber-100">
                {children}
              </table>
            </div>
          ),
          thead: ({ children }) => (
            <thead className="bg-amber-900/50 text-amber-200 font-bold uppercase tracking-wider border-b border-amber-300/30">
              {children}
            </thead>
          ),
          tbody: ({ children }) => (
            <tbody className="divide-y divide-amber-300/10">
              {children}
            </tbody>
          ),
          tr: ({ children }) => (
            <tr className="hover:bg-white/5 transition-colors">
              {children}
            </tr>
          ),
          th: ({ children }) => (
            <th className="px-4 py-3 font-extrabold text-amber-200">
              {wrapChildren(children)}
            </th>
          ),
          td: ({ children }) => (
            <td className="px-4 py-3 leading-relaxed">
              {wrapChildren(children)}
            </td>
          ),
          code: ({ children }) => {
            const str = String(children || '');
            if (str.includes('<svg') && str.includes('</svg>')) {
              return (
                <div className="my-3 not-prose">
                  <SvgDiagramViewer
                    svgCode={str}
                    theme="dark"
                    title="2D Vector Teaching Schematic"
                    onOpenWhiteboard={onOpenWhiteboard}
                    showNotification={showNotification}
                    onRenderComplete={onRenderComplete}
                    onExplainFigure={(code, ttl) => {
                      onSendMessage(`Please analyze this SVG diagram and provide a deep, step-by-step breakdown of its components, labels, and scientific/mathematical principles:\n\n${code}`);
                      showNotification?.("Requesting deep diagram explanation...", "info");
                    }}
                    isHighContrast={canvasUiManager?.state.highContrast}
                    isVectorDragMode={canvasUiManager?.state.dragHandles}
                    showVectorTelemetry={canvasUiManager?.state.vectorStats}
                    isMagnifierActive={canvasUiManager?.state.magnifier}
                    isChalkMode={canvasUiManager?.state.chalkDraw}
                    showGrid={canvasUiManager?.state.grid}
                    onToggleHighContrast={canvasUiManager?.toggleHighContrast}
                    onToggleVectorDragMode={canvasUiManager?.toggleDragHandles}
                    onToggleVectorTelemetry={canvasUiManager?.toggleVectorStats}
                    onToggleMagnifier={canvasUiManager?.toggleMagnifier}
                    onToggleChalkMode={canvasUiManager?.toggleChalkDraw}
                    onToggleGrid={canvasUiManager?.toggleGrid}
                  />
                </div>
              );
            }
            return (
              <code className="px-1.5 py-0.5 rounded text-sm font-mono bg-white/10 text-yellow-200">
                {children}
              </code>
            );
          },
          pre: ({ children }) => {
            const childArray = React.Children.toArray(children);
            const firstChild = childArray[0];
            if (React.isValidElement(firstChild)) {
              const codeStr = String((firstChild.props as any)?.children || '');
              if (codeStr.includes('<svg') && codeStr.includes('</svg>')) {
                return (
                  <div className="my-3 not-prose">
                    <SvgDiagramViewer
                      svgCode={codeStr}
                      theme="dark"
                      title="2D Vector Teaching Schematic"
                      onOpenWhiteboard={onOpenWhiteboard}
                      showNotification={showNotification}
                      onRenderComplete={onRenderComplete}
                      onExplainFigure={(code, ttl) => {
                        onSendMessage(`Please analyze this SVG diagram and provide a deep, step-by-step breakdown of its components, labels, and scientific/mathematical principles:\n\n${code}`);
                        showNotification?.("Requesting deep diagram explanation...", "info");
                      }}
                      isHighContrast={canvasUiManager?.state.highContrast}
                      isVectorDragMode={canvasUiManager?.state.dragHandles}
                      showVectorTelemetry={canvasUiManager?.state.vectorStats}
                      isMagnifierActive={canvasUiManager?.state.magnifier}
                      isChalkMode={canvasUiManager?.state.chalkDraw}
                      showGrid={canvasUiManager?.state.grid}
                      onToggleHighContrast={canvasUiManager?.toggleHighContrast}
                      onToggleVectorDragMode={canvasUiManager?.toggleDragHandles}
                      onToggleVectorTelemetry={canvasUiManager?.toggleVectorStats}
                      onToggleMagnifier={canvasUiManager?.toggleMagnifier}
                      onToggleChalkMode={canvasUiManager?.toggleChalkDraw}
                      onToggleGrid={canvasUiManager?.toggleGrid}
                    />
                  </div>
                );
              }
              if ((codeStr.includes('║') && (codeStr.includes('╠') || codeStr.includes('═') || codeStr.includes('╔') || codeStr.includes('╚'))) || (codeStr.includes('+---') && codeStr.includes('|'))) {
                return (
                  <div className="my-3 not-prose">
                    <TableGenerator
                      isInline={true}
                      initialText={codeStr}
                      theme="blackboard"
                      showNotification={showNotification}
                      onInsertToChat={onSendMessage}
                    />
                  </div>
                );
              }
            }
            return (
              <pre className="p-4 rounded-xl overflow-x-auto my-3 bg-black/30 border border-white/5 text-yellow-100 font-mono text-xs">
                {children}
              </pre>
            );
          },
          blockquote: ({ children }) => (
            <blockquote className="border-l-4 border-yellow-300 pl-4 italic my-3 text-amber-100/80">
              {wrapChildren(children)}
            </blockquote>
          ),
          text: ({ children, node, ...props }: any) => (
            <span
              style={{
                fontFamily: props['font-family'] || props.fontFamily,
                fontSize: props['font-size'] || props.fontSize,
                fontWeight: props['font-weight'] || props.fontWeight,
                color: props.fill || undefined
              }}
            >
              {wrapChildren(children)}
            </span>
          ),
        }}
      >
        {autoBalanceMathDelimiters(displayedText) + (isTyping ? " ✏️" : "")}
      </ReactMarkdown>
      {tooltip && (
        <div 
          className="fixed z-[200] p-3 bg-slate-800 text-white text-xs rounded-lg shadow-xl border border-slate-700 max-w-[200px]"
          style={{ left: tooltip.x, top: tooltip.y }}
        >
          <strong className="block text-indigo-400 mb-1">{tooltip.word}</strong>
          <p className="mb-2">{tooltip.definition}</p>
          <button 
            onClick={() => onSendMessage(`Can you explain "${tooltip.word}" in the context of this lecture?`)}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-1 px-2 rounded text-[10px] uppercase tracking-wider transition-colors"
          >
            Ask about this
          </button>
        </div>
      )}
    </div>
  );
};

export function detectNewConcept(content: string): { introduced: boolean; conceptName?: string } {
  const lower = content.toLowerCase();
  
  const hasKeywords = 
    lower.includes("concept:") || 
    lower.includes("lesson:") || 
    lower.includes("introduction to") || 
    lower.includes("key concept") || 
    lower.includes("core concept") || 
    lower.includes("let's learn about") || 
    lower.includes("today we will explore") ||
    lower.includes("new concept");

  if (!hasKeywords) {
    return { introduced: false };
  }

  const regexes = [
    /###?\s*Core\s+Concept:\s*([^\n#*_]+)/i,
    /###?\s*Key\s+Concept:\s*([^\n#*_]+)/i,
    /###?\s*Concept:\s*([^\n#*_]+)/i,
    /###?\s*Lesson:\s*([^\n#*_]+)/i,
    /\*\*Core\s+Concept:\s*\*?\s*([^\n#*_]+)/i,
    /\*\*Key\s+Concept:\s*\*?\s*([^\n#*_]+)/i,
    /\*\*Concept:\s*\*?\s*([^\n#*_]+)/i,
    /\*\*Lesson:\s*\*?\s*([^\n#*_]+)/i,
    /Introduction\s+to\s+([^\n#*_.]+)/i,
    /Let's\s+explore\s+([^\n#*_.]+)/i,
    /Let's\s+learn\s+about\s+([^\n#*_.]+)/i,
  ];

  for (const regex of regexes) {
    const match = content.match(regex);
    if (match && match[1]) {
      const name = match[1].trim();
      const cleanName = name.replace(/[.:*`"'-]+$/, "").trim();
      if (cleanName && cleanName.length > 2 && cleanName.length < 60) {
        return { introduced: true, conceptName: cleanName };
      }
    }
  }

  return { introduced: true };
}

export function getFollowUpChips(content: string): { label: string; prompt: string }[] {
  const lower = (content || '').toLowerCase();
  const isCode = /```|code|function|class|import|const|let|python|javascript|typescript|bug|error|api|html|css/.test(lower);
  const isMath = /\\\(|\\\[|\$|math|equation|formula|calculus|algebra|matrix|integral|derivative|sum|probability|theorem/.test(lower);
  const isScience = /physics|chemistry|biology|quantum|atom|molecule|cell|gravity|energy|reaction|thermodynamics/.test(lower);
  const isQuiz = /quiz|question|multiple choice|\([a-d]\)|option/.test(lower);

  const chips: { label: string; prompt: string }[] = [];

  // Core options tailored dynamically to AI response content
  chips.push({
    label: '💡 Explain this further',
    prompt: 'Could you explain this further in simpler terms with a clear real-life analogy?'
  });

  chips.push({
    label: '❓ Give me a quiz',
    prompt: 'Generate a quick 3-question practice quiz with multiple choice questions based on this response to test my understanding.'
  });

  if (isCode) {
    chips.push({
      label: '💻 Show Code Example',
      prompt: 'Provide a clean, well-commented code implementation example for this.'
    });
    chips.push({
      label: '🐛 Debug & Edge Cases',
      prompt: 'What are common bugs, edge cases, and error handling best practices for this?'
    });
  } else if (isMath) {
    chips.push({
      label: '🔢 Step-by-step breakdown',
      prompt: 'Walk me through the complete mathematical derivation and step-by-step solution.'
    });
    chips.push({
      label: '📊 Graph & Visualize',
      prompt: 'Describe how to plot, visualize, or graph this mathematical relationship.'
    });
  } else if (isScience) {
    chips.push({
      label: '🔬 Deeper Mechanism',
      prompt: 'Explain the underlying physical, chemical, or biological mechanism in deeper scientific detail.'
    });
    chips.push({
      label: '🌍 Real-world example',
      prompt: 'Give real-world practical examples and industry applications of this concept.'
    });
  } else if (isQuiz) {
    chips.push({
      label: '📝 Step-by-step breakdown',
      prompt: 'Provide detailed step-by-step explanations for each option in the quiz questions.'
    });
    chips.push({
      label: '❓ Next Practice Question',
      prompt: 'Give me another slightly more challenging question on this topic.'
    });
  } else {
    chips.push({
      label: '🌍 Real-world example',
      prompt: 'Give me concrete real-world practical examples and applications of this concept.'
    });
    chips.push({
      label: '📌 Key Takeaways',
      prompt: 'Summarize the core points and key takeaways from your response in concise bullet points.'
    });
  }

  return chips.slice(0, 4);
}

const modeStyles: Record<string, string> = {
  learn: 'bg-slate-900',
  earn: 'bg-indigo-950',
  entrance: 'bg-emerald-950',
  competitive: 'bg-rose-950',
};

export const Chat: React.FC<ChatProps> = ({
  messages,
  zoomLevel,
  setZoomLevel,
  contentWidth,
  setContentWidth,
  onSendMessage,
  onClearChat,
  isTyping,
  onFileUpload,
  onToggleVoice,
  onGenerateMedia,
  isRecording,
  theme,
  language,
  onSelectLanguage,
  onGenerateRecap,
  onGenerateVideo,
  onOpenTool,
  selectedPersonaId = 'encouraging_coach',
  onSelectPersonaId,
  showNotification,
  typingPace = 'fluent',
  blackboardWritingSpeed = 1.0,
  ttsRate = 1.0,
  linkSpeeds = false,
  setTtsRate = () => {},
  setTypingPace = () => {},
  setBlackboardWritingSpeed = () => {},
  setLinkSpeeds = () => {},
  isGeneratingVideo = false,
  videoGenerationTime = 0,
  subject = 'mathematics',
  topic = 'general',
  onSaveToNotes,
  onDeleteMessage,
  isShared = false,
  isLectureMode,
  setIsLectureMode,
  lectureSubMode,
  setLectureSubMode,
  lectureProfessorStyle = 'strict',
  setLectureProfessorStyle = () => {},
  tutorPersonaConfig,
  onUpdateTutorPersonaConfig = () => {},
  onAwardXp,
  pronunciationPrecision = 'standard',
  mode,
  voiceSensitivity,
  accessibilityTextSize = 'md',
  accessibilityLineSpacing = 'relaxed',
  accessibilityContrast = 'normal',
  isClassroomMute = false,
  setIsClassroomMute,
  isDiagramRendering = false,
  setIsDiagramRendering,
  canvasUiManager
}) => {
  const [isScratchpadOpen, setIsScratchpadOpen] = useState(false);
  const [showPracticeQuestionModal, setShowPracticeQuestionModal] = useState(false);
  const [isWhiteboardOpen, setIsWhiteboardOpen] = useState(false);
  const [loadingQuickAction, setLoadingQuickAction] = useState<string | null>(null);
  const [isCustomActionModalOpen, setIsCustomActionModalOpen] = useState(false);
  const [customActionLabel, setCustomActionLabel] = useState('');
  const [customActionPrompt, setCustomActionPrompt] = useState('');
  const [customActions, setCustomActions] = useState<{ label: string; title: string; prompt: string }[]>(() => {
    try {
      const saved = localStorage.getItem('omni_custom_actions_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const handleSaveCustomAction = () => {
    if (!customActionLabel.trim() || !customActionPrompt.trim()) {
      showNotification?.('Please enter both a button label and a prompt for your custom action.', 'warning');
      return;
    }
    const newAction = {
      label: customActionLabel.trim().startsWith('✨') ? customActionLabel.trim() : `✨ ${customActionLabel.trim()}`,
      title: `Custom Action: ${customActionPrompt.trim()}`,
      prompt: customActionPrompt.trim()
    };
    const updated = [...customActions, newAction];
    setCustomActions(updated);
    try {
      localStorage.setItem('omni_custom_actions_v1', JSON.stringify(updated));
    } catch (e) {}
    setCustomActionLabel('');
    setCustomActionPrompt('');
    setIsCustomActionModalOpen(false);
    showNotification?.(`Custom action "${newAction.label}" created successfully!`, 'success');
  };
  const [readyMessages, setReadyMessages] = useState<Set<string>>(new Set());
  const [typingSeconds, setTypingSeconds] = useState(0);
  const [likedMessages, setLikedMessages] = useState<Record<string, boolean>>({});
  const [dislikedMessages, setDislikedMessages] = useState<Record<string, boolean>>({});
  const [maximizedMessageId, setMaximizedMessageId] = useState<string | null>(null);
  const [completedTypewriterIds, setCompletedTypewriterIds] = useState<Set<string>>(new Set());
  const [isRecordingAi, setIsRecordingAi] = useState(false);
  const [recordedEvents, setRecordedEvents] = useState<{ timestamp: number; event: string }[]>([]);
  const recordingStartTime = useRef<number>(0);
  const [hoveredAnnoIndex, setHoveredAnnoIndex] = useState<{ msgId: string; index: number } | null>(null);

  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState<string>('');

  const handleSaveEdit = (msgId: string, regenerate: boolean = false) => {
    if (!editingContent.trim()) return;
    const updated = localMessages.map(m => m.id === msgId ? { ...m, content: editingContent } : m);
    setLocalMessages(updated);
    setEditingMessageId(null);
    showNotification?.('Message updated successfully!', 'success');
    if (regenerate && onSendMessage) {
      onSendMessage(editingContent);
    }
  };

  const [localMessages, setLocalMessages] = useState<Message[]>(messages);
  const [zoomLevels, setZoomLevels] = useState<Record<string, number>>({});
  const [diagramRotations, setDiagramRotations] = useState<Record<string, number>>({});
  const [fullscreenDiagramMsgId, setFullscreenDiagramMsgId] = useState<string | null>(null);
  const [fullscreenZoom, setFullscreenZoom] = useState<number>(1);
  const [fullscreenRotation, setFullscreenRotation] = useState<number>(0);
  const [showHotspots, setShowHotspots] = useState<Record<string, boolean>>({});
  const [showLegendMap, setShowLegendMap] = useState<Record<string, boolean>>({});
  const [originalAnnotationsMap, setOriginalAnnotationsMap] = useState<Record<string, any[]>>({});
  const [refreshingDiagramIds, setRefreshingDiagramIds] = useState<Set<string>>(new Set());
  const [isQrScannerOpen, setIsQrScannerOpen] = useState<boolean>(false);
  const [qrScanningActive, setQrScanningActive] = useState<boolean>(false);
  const [qrScanResult, setQrScanResult] = useState<string>('');
  const qrVideoRef = useRef<HTMLVideoElement | null>(null);
  const qrStreamRef = useRef<MediaStream | null>(null);

  const startQrCamera = async () => {
    try {
      setQrScanningActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      qrStreamRef.current = stream;
      if (qrVideoRef.current) {
        qrVideoRef.current.srcObject = stream;
        qrVideoRef.current.play();
      }
    } catch (err) {
      console.error("Error accessing camera for QR scan:", err);
      showNotification?.("Could not access camera for QR scanning. Please check permissions or use clipboard/image upload.", "error");
      setQrScanningActive(false);
    }
  };

  // Handle Lab State Interaction
  useEffect(() => {
    // 1. Listen for Lab State Updates
    const handleLabUpdate = (event: any) => {
      const { type, data } = event.detail;
      if (type === 'enzyme_kinetics' || type === 'enzyme_kinetics_update') {
        onSendMessage(`[Lab Update] The current enzyme kinetics parameters are: Vmax=${data.vMax}, Km=${data.kM}, Factor=${data.enzymeFactor}, Selected Enzyme=${data.selectedEnzyme}.`);
      }
    };
    window.addEventListener('lab_state_update', handleLabUpdate);
    
    // 2. Trigger Lab State Query
    const lastMessage = messages[messages.length - 1];
    if (lastMessage && lastMessage.sender === 'user' && (lastMessage.content.toLowerCase().includes("enzyme activity rate") || lastMessage.content.toLowerCase().includes("enzyme kinetics"))) {
      window.dispatchEvent(new CustomEvent('query_lab_state'));
    }

    return () => window.removeEventListener('lab_state_update', handleLabUpdate);
  }, [messages, onSendMessage]);

  const stopQrCamera = () => {
    if (qrStreamRef.current) {
      qrStreamRef.current.getTracks().forEach(track => track.stop());
      qrStreamRef.current = null;
    }
    setQrScanningActive(false);
  };

  const handlePasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setQrScanResult(text);
        showNotification?.("📋 Pasted content from clipboard successfully!", "success");
        processQrPayload(text);
      } else {
        showNotification?.("Clipboard is empty.", "info");
      }
    } catch (err) {
      console.error("Failed to read clipboard:", err);
      showNotification?.("Failed to read from clipboard. Please paste manually.", "error");
    }
  };

  const processQrPayload = (payload: string) => {
    if (!payload.trim()) return;
    setIsQrScannerOpen(false);
    stopQrCamera();
    showNotification?.(`✨ QR Code content loaded: "${payload.substring(0, 40)}..."`, "success");
    onSendMessage?.(`Load educational diagram and study content for QR Code payload: ${payload}`);
  };

  const handleSimulateQrScan = (topicName: string) => {
    setIsQrScannerOpen(false);
    stopQrCamera();
    showNotification?.(`📷 Physical QR Code successfully scanned for "${topicName}"!`, "success");
    onSendMessage?.(`Load comprehensive educational diagram and interactive hotspots for: ${topicName}`);
  };

  const [generatingElementQuizMsgId, setGeneratingElementQuizMsgId] = useState<string | null>(null);
  const [elementQuizzes, setElementQuizzes] = useState<Record<string, any>>({});
  const [activeElementQuizModal, setActiveElementQuizModal] = useState<{ msgId: string; quiz: any } | null>(null);
  const [elementQuizSelectedOption, setElementQuizSelectedOption] = useState<number | null>(null);
  const [elementQuizSubmitted, setElementQuizSubmitted] = useState<boolean>(false);

  const handleGenerateElementQuiz = async (msg: Message) => {
    const annotations = msg.metadata?.annotations || [];
    if (annotations.length === 0) {
      showNotification?.("No anatomical or mathematical elements found in this diagram.", "info");
      return;
    }

    const selectedIndices = selectedAnnoIndices[msg.id];
    const highlightedAnnos = selectedIndices && selectedIndices.size > 0 
      ? annotations.filter((_: any, idx: number) => selectedIndices.has(idx))
      : (hoveredAnnoIndex?.msgId === msg.id && hoveredAnnoIndex.index !== null 
          ? [annotations[hoveredAnnoIndex.index]] 
          : annotations);

    setGeneratingElementQuizMsgId(msg.id);
    showNotification?.("🧠 Generating specialized quiz question based on highlighted diagram elements...", "info");

    try {
      const selectedLangObj = LANGUAGES.find(l => l.code === language) || { name: 'English' };
      const langName = selectedLangObj.name;
      const topic = msg.metadata?.topic || "Study Diagram";

      const prompt = `Based on the educational topic "${topic}" and specifically the following highlighted diagram elements/hotspots:
${highlightedAnnos.map((a: any, i: number) => `- ${a.label}: ${a.description || ''}`).join('\n')}

Generate a rigorous, specialized multiple-choice quiz question (1 question) to test active recall of these specific highlighted anatomical or mathematical elements.
CRITICAL: Write the response in ${langName}.
Return ONLY a valid raw JSON object with no markdown codeblocks matching this exact structure:
{
  "question": "Question text...",
  "options": ["Option A", "Option B", "Option C", "Option D"],
  "correctIndex": 0,
  "explanation": "Detailed explanation of why the correct option is right for these diagram elements."
}`;

      const responseText = await generateAIResponse(prompt);
      let cleanJson = responseText || "";
      if (cleanJson.includes("```json")) {
        cleanJson = cleanJson.split("```json")[1].split("```")[0];
      } else if (cleanJson.includes("```")) {
        cleanJson = cleanJson.split("```")[1].split("```")[0];
      }
      cleanJson = cleanJson.trim();

      const parsedQuiz = JSON.parse(cleanJson);
      if (parsedQuiz && parsedQuiz.question && Array.isArray(parsedQuiz.options)) {
        setElementQuizzes(prev => ({ ...prev, [msg.id]: parsedQuiz }));
        setActiveElementQuizModal({ msgId: msg.id, quiz: parsedQuiz });
        setElementQuizSelectedOption(null);
        setElementQuizSubmitted(false);
        showNotification?.("✨ Specialized diagram element quiz generated successfully!", "success");
      } else {
        throw new Error("Invalid format");
      }
    } catch (err) {
      console.error("Failed to generate element quiz:", err);
      const fallbackQuiz = {
        question: `Which of the highlighted diagram elements in ${topic} represents the primary functional mapping or structural component?`,
        options: highlightedAnnos.map((a: any) => a.label).slice(0, 4),
        correctIndex: 0,
        explanation: `The highlighted elements play a central role in ${topic} architecture.`
      };
      setElementQuizzes(prev => ({ ...prev, [msg.id]: fallbackQuiz }));
      setActiveElementQuizModal({ msgId: msg.id, quiz: fallbackQuiz });
      setElementQuizSelectedOption(null);
      setElementQuizSubmitted(false);
      showNotification?.("✨ Element quiz generated!", "success");
    } finally {
      setGeneratingElementQuizMsgId(null);
    }
  };
  const [compareModalMsgId, setCompareModalMsgId] = useState<string | null>(null);
  const [selectedAnnoIndices, setSelectedAnnoIndices] = useState<Record<string, Set<number>>>({});
  const [styleSettings, setStyleSettings] = useState<Record<string, { thickness: '2' | '4' | '6'; glow: 'low' | 'medium' | 'high'; size: 'sm' | 'md' | 'lg' }>>({});
  const [annotationFolders, setAnnotationFolders] = useState<Record<string, { id: string; name: string; indices: number[]; hidden: boolean }[]>>({});
  const [newFolderNameInput, setNewFolderNameInput] = useState<Record<string, string>>({});

  // Study Gallery, Color Palette, Inline Renaming & Expand All state
  const [studyGallery, setStudyGallery] = useState<{ id: string; msgId: string; image: string; annotations: any[]; timestamp: string; title: string }[]>(() => {
    try {
      const saved = localStorage.getItem('study_gallery_snaps');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // LocalStorage Caching Mechanism for Generated Figures
  const [cachedStudyFigures, setCachedStudyFigures] = useState<{ id: string; image: string; topic: string; annotations: any[]; timestamp: string }[]>(() => {
    try {
      const saved = localStorage.getItem('omni_cached_study_figures_v1');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [isCachedFiguresModalOpen, setIsCachedFiguresModalOpen] = useState(false);
  const [cachedFiguresSearchQuery, setCachedFiguresSearchQuery] = useState("");

  // Interactive Guided Onboarding Tour State
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(false);
  const [onboardingStep, setOnboardingStep] = useState<number>(1);
  const [isKeyboardShortcutsModalOpen, setIsKeyboardShortcutsModalOpen] = useState(false);
  const [isVoiceCommandModalOpen, setIsVoiceCommandModalOpen] = useState(false);
  const [isVoiceSimulating, setIsVoiceSimulating] = useState(false);
  const [voiceSpokenText, setVoiceSpokenText] = useState("");

  // Accessibility & Readability State
  const [fontSizeScale, setFontSizeScale] = useState<'normal' | 'large' | 'xl'>(() => {
    try {
      return (localStorage.getItem('omni_font_size_scale_v1') as any) || 'normal';
    } catch (e) {
      return 'normal';
    }
  });
  const [isHighContrast, setIsHighContrast] = useState<boolean>(() => {
    try {
      return localStorage.getItem('omni_high_contrast_v1') === 'true';
    } catch (e) {
      return false;
    }
  });
  const [isAccessibilityModalOpen, setIsAccessibilityModalOpen] = useState(false);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const cmdOrCtrl = isMac ? e.metaKey : e.ctrlKey;

      if (cmdOrCtrl && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setIsCachedFiguresModalOpen(prev => !prev);
      } else if (cmdOrCtrl && e.key.toLowerCase() === 'g') {
        e.preventDefault();
        setIsGalleryOpen(prev => !prev);
      } else if (cmdOrCtrl && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsKeyboardShortcutsModalOpen(prev => !prev);
      } else if (cmdOrCtrl && e.key.toLowerCase() === 'm') {
        e.preventDefault();
        setIsVoiceCommandModalOpen(prev => !prev);
      } else if (cmdOrCtrl && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        setIsAccessibilityModalOpen(prev => !prev);
      } else if (cmdOrCtrl && e.shiftKey && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        setIsOnboardingOpen(false);
      } else if (e.key === 'Escape') {
        setIsCachedFiguresModalOpen(false);
        setIsGalleryOpen(false);
        setIsKeyboardShortcutsModalOpen(false);
        setIsVoiceCommandModalOpen(false);
        setIsAccessibilityModalOpen(false);
        setIsOnboardingOpen(false);
        setActiveElementQuizModal(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const cacheStudyFigure = (image: string, topicName: string, annotations: any[]) => {
    if (!image) return;
    setCachedStudyFigures(prev => {
      if (prev.some(p => p.image === image)) return prev;
      const newItem = {
        id: Math.random().toString(36).substring(2, 9),
        image,
        topic: topicName || topic || 'Study Diagram',
        annotations: JSON.parse(JSON.stringify(annotations || [])),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      };
      const updated = [newItem, ...prev].slice(0, 40);
      try {
        localStorage.setItem('omni_cached_study_figures_v1', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  const handleLoadCachedFigureToMessage = (cachedItem: { image: string; topic: string; annotations: any[] }, msgId: string) => {
    setLocalMessages(prev => prev.map(m => {
      if (m.id === msgId) {
        return {
          ...m,
          metadata: {
            ...m.metadata,
            image: cachedItem.image,
            topic: cachedItem.topic,
            annotations: JSON.parse(JSON.stringify(cachedItem.annotations || []))
          }
        };
      }
      return m;
    }));
    setIsCachedFiguresModalOpen(false);
    showNotification?.(`⚡ Switched diagram to cached figure: "${cachedItem.topic}" (Loaded instantly from local storage)`, "success");
  };
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [activePaletteMsgId, setActivePaletteMsgId] = useState<string | null>(null);
  const [editingAnnoIndex, setEditingAnnoIndex] = useState<{ msgId: string; index: number } | null>(null);
  const [editingAnnoLabel, setEditingAnnoLabel] = useState<string>('');
  const [expandedAllMap, setExpandedAllMap] = useState<Record<string, boolean>>({});
  const [expandedAnnoIndices, setExpandedAnnoIndices] = useState<Record<string, Set<number>>>({});

  const handleSnapToGallery = (msgId: string, image: string, annotations: any[], topicName?: string) => {
    const snap = {
      id: Math.random().toString(36).substring(2, 9),
      msgId,
      image,
      annotations: JSON.parse(JSON.stringify(annotations || [])),
      timestamp: new Date().toLocaleString(),
      title: topicName || `Diagram Snapshot #${studyGallery.length + 1}`
    };
    const updated = [snap, ...studyGallery];
    setStudyGallery(updated);
    try {
      localStorage.setItem('study_gallery_snaps', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    showNotification?.("Snapped diagram view to Study Gallery! 📸", "success");
  };

  const handleRenameAnnotation = (msgId: string, index: number, newLabel: string) => {
    if (!newLabel.trim()) return;
    setLocalMessages(prev => prev.map(m => {
      if (m.id === msgId && m.metadata?.annotations) {
        const newAnns = [...m.metadata.annotations];
        newAnns[index] = { ...newAnns[index], label: newLabel.trim() };
        saveAnnotationsToLocalStorage(msgId, newAnns);
        return { ...m, metadata: { ...m.metadata, annotations: newAnns } };
      }
      return m;
    }));
    setEditingAnnoIndex(null);
    showNotification?.(`Renamed hotspot label to "${newLabel.trim()}"`, "success");
  };

  // Undo / Redo history stack for annotation positions
  const [annotationHistory, setAnnotationHistory] = useState<Record<string, any[][]>>({});
  const [annotationHistoryIndex, setAnnotationHistoryIndex] = useState<Record<string, number>>({});

  const pushAnnotationHistory = (msgId: string, newAnns: any[]) => {
    setAnnotationHistory(prev => {
      const historyList = prev[msgId] || [];
      const currentIndex = annotationHistoryIndex[msgId] ?? historyList.length - 1;
      const truncated = historyList.slice(0, currentIndex + 1);
      return { ...prev, [msgId]: [...truncated, JSON.parse(JSON.stringify(newAnns))] };
    });
    setAnnotationHistoryIndex(prev => {
      const historyList = annotationHistory[msgId] || [];
      const currentIndex = prev[msgId] ?? historyList.length - 1;
      return { ...prev, [msgId]: currentIndex + 1 };
    });
  };

  useEffect(() => {
    const hash = window.location.hash;
    if (hash.includes('hotspot=')) {
      const match = hash.match(/hotspot=([^&]+)-(\d+)/);
      if (match) {
        const [, msgId, idxStr] = match;
        const idx = parseInt(idxStr, 10);
        setTimeout(() => {
          const el = document.getElementById(`diagram-image-${msgId}`);
          if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setHoveredAnnoIndex({ msgId, index: idx });
          }
        }, 800);
      }
    }
  }, []);

  useEffect(() => {
    const origMap: Record<string, any[]> = {};
    const savedCustomAnns = localStorage.getItem('custom_diagram_annotations');
    let parsedCustom: Record<string, any[]> = {};
    try {
      if (savedCustomAnns) parsedCustom = JSON.parse(savedCustomAnns);
    } catch (e) {
      console.error(e);
    }

    messages.forEach(m => {
      if (m.metadata?.annotations) {
        origMap[m.id] = JSON.parse(JSON.stringify(m.metadata.annotations));
      }
    });
    setOriginalAnnotationsMap(origMap);

    if (savedCustomAnns) {
      setLocalMessages(messages.map(m => {
        if (parsedCustom[m.id]) {
          return { ...m, metadata: { ...m.metadata, annotations: parsedCustom[m.id] } };
        }
        return m;
      }));
    } else {
      setLocalMessages(messages);
    }
  }, [messages.length]);

  const saveAnnotationsToLocalStorage = (msgId: string, anns: any[]) => {
    try {
      const saved = localStorage.getItem('custom_diagram_annotations');
      const parsed: Record<string, any[]> = saved ? JSON.parse(saved) : {};
      parsed[msgId] = anns;
      localStorage.setItem('custom_diagram_annotations', JSON.stringify(parsed));
    } catch (e) {
      console.error(e);
    }
  };

  const [repositioningAnno, setRepositioningAnno] = useState<{ msgId: string; index: number } | null>(null);
  const [activeAnnoModal, setActiveAnnoModal] = useState<{ msgId: string; anno: any; index: number } | null>(null);
  const [annoColors, setAnnoColors] = useState<Record<string, string>>({});
  const [popupFontSize, setPopupFontSize] = useState<number>(14);

  const colorPresets = [
    { label: 'Indigo', ring: 'ring-indigo-400', shadow: 'shadow-[0_0_10px_rgba(99,102,241,0.6)]', bg: 'bg-indigo-500' },
    { label: 'Emerald', ring: 'ring-emerald-400', shadow: 'shadow-[0_0_10px_rgba(16,185,129,0.6)]', bg: 'bg-emerald-500' },
    { label: 'Rose', ring: 'ring-rose-400', shadow: 'shadow-[0_0_10px_rgba(244,63,94,0.6)]', bg: 'bg-rose-500' },
    { label: 'Amber', ring: 'ring-amber-400', shadow: 'shadow-[0_0_10px_rgba(245,158,11,0.6)]', bg: 'bg-amber-500' },
    { label: 'Cyan', ring: 'ring-cyan-400', shadow: 'shadow-[0_0_10px_rgba(6,182,212,0.6)]', bg: 'bg-cyan-500' },
    { label: 'Purple', ring: 'ring-purple-400', shadow: 'shadow-[0_0_10px_rgba(168,85,247,0.6)]', bg: 'bg-purple-500' },
  ];

  // Interactive Diagram Teaching Utility States
  interface DiagramQuizState {
    targetIndex: number;
    score: number;
    total: number;
    answeredNodes: Record<number, boolean>;
    completed: boolean;
    feedback: { type: 'success' | 'error'; msg: string } | null;
  }
  const [activeDiagramQuiz, setActiveDiagramQuiz] = useState<Record<string, DiagramQuizState>>({});
  const [activeAudioTour, setActiveAudioTour] = useState<{ msgId: string; nodeIndex: number; isPlaying: boolean } | null>(null);
  const [activeChalkboard, setActiveChalkboard] = useState<string | null>(null);
  const [chalkboardColor, setChalkboardColor] = useState<string>('#38bdf8');
  const [chalkboardSize, setChalkboardSize] = useState<number>(3);
  const [chalkboardThemeStyle, setChalkboardThemeStyle] = useState<'classic-green' | 'midnight-slate' | 'sepia-manuscript' | 'forest-chalk'>(() => {
    return (localStorage.getItem('omni_chalkboard_theme_style') as any) || 'classic-green';
  });
  const [chalkboardFontScale, setChalkboardFontScale] = useState<'compact' | 'normal' | 'spacious'>(() => {
    return (localStorage.getItem('omni_chalkboard_font_scale') as any) || 'normal';
  });
  const [chalkboardGridStyle, setChalkboardGridStyle] = useState<'graph-grid' | 'fine-mesh' | 'dot-matrix' | 'lines'>(() => {
    return (localStorage.getItem('omni_chalkboard_grid_style') as any) || 'graph-grid';
  });
  const [showChalkDustEffect, setShowChalkDustEffect] = useState<boolean>(() => {
    return localStorage.getItem('omni_chalkboard_dust') !== 'false';
  });
  const [chalkboardDrawingStyle, setChalkboardDrawingStyle] = useState<'hand-drawn' | 'clean-academic'>(() => {
    return (localStorage.getItem('omni_chalkboard_drawing_style') as any) || 'clean-academic';
  });
  const [showChalkDustOverlay, setShowChalkDustOverlay] = useState<boolean>(() => {
    return localStorage.getItem('omni_chalkboard_dust_overlay') !== 'false';
  });
  const [chalkSoundState, setChalkSoundState] = useState<boolean>(() => {
    return isChalkSoundEnabled();
  });

  useEffect(() => {
    const handleDiagramStyleSync = () => {
      const saved = (localStorage.getItem('omni_chalkboard_drawing_style') as 'hand-drawn' | 'clean-academic') || 'clean-academic';
      setChalkboardDrawingStyle(saved);
    };
    window.addEventListener('omni_diagram_style_changed', handleDiagramStyleSync);
    window.addEventListener('storage', handleDiagramStyleSync);
    return () => {
      window.removeEventListener('omni_diagram_style_changed', handleDiagramStyleSync);
      window.removeEventListener('storage', handleDiagramStyleSync);
    };
  }, []);
  const [showGalleryModal, setShowGalleryModal] = useState<boolean>(false);
  const chalkboardCanvasRefs = useRef<Record<string, HTMLCanvasElement | null>>({});
  const [activeQuickActionMenuMessageId, setActiveQuickActionMenuMessageId] = useState<string | null>(null);
  const [quickMenuSubTab, setQuickMenuSubTab] = useState<'timeline' | 'actions'>('actions');
  const [showClassroomTimeline, setShowClassroomTimeline] = useState<boolean>(false);
  const [isTextareaFocused, setIsTextareaFocused] = useState<boolean>(false);
  const [isCrashDoubtModalOpen, setIsCrashDoubtModalOpen] = useState<boolean>(false);
  const [crashDoubtText, setCrashDoubtText] = useState<string>('');

  // Dictation & Inline Double-Click Chat Insertion State
  const [inlineBoxTargetMsgId, setInlineBoxTargetMsgId] = useState<string | null>(null);
  const [inlineBoxText, setInlineBoxText] = useState<string>('');
  const [inlineBoxImage, setInlineBoxImage] = useState<string | null>(null);
  const [isInlineDictating, setIsInlineDictating] = useState<boolean>(false);
  const [isInlineAiWriting, setIsInlineAiWriting] = useState<boolean>(false);
  const [isDictating, setIsDictating] = useState<boolean>(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [showMicModal, setShowMicModal] = useState<boolean>(false);
  const [isAddContentLoading, setIsAddContentLoading] = useState<boolean>(false);
  const inlineBoxContainerRef = useRef<HTMLDivElement | null>(null);
  const inlineBoxOpenedAtRef = useRef<number>(0);
  const lastToggleTimeRef = useRef<number>(0);
  const dictationRecognitionRef = useRef<any>(null);

  // Handler for double clicking anywhere in chat or on a message to toggle the "add content" box
  const handleChatDoubleClick = (e?: React.SyntheticEvent, msgId?: string) => {
    if (e) {
      e.stopPropagation();
      if ('preventDefault' in e && typeof e.preventDefault === 'function') {
        e.preventDefault();
      }
    }
    const now = Date.now();
    // Debounce rapid double-clicks within 400ms to prevent accidental multiple triggers or instant closing
    if (now - lastToggleTimeRef.current < 400) {
      return;
    }
    lastToggleTimeRef.current = now;

    setIsAddContentLoading(true);
    setTimeout(() => {
      setIsAddContentLoading(false);
    }, 250);

    const targetId = msgId || (localMessages.length > 0 ? localMessages[localMessages.length - 1].id : 'end');
    inlineBoxOpenedAtRef.current = now;
    if (inlineBoxTargetMsgId === targetId) {
      setInlineBoxTargetMsgId(null);
      showNotification?.('Closed "add content" box.', 'info');
    } else {
      setInlineBoxTargetMsgId(targetId);
      showNotification?.('Opened "add content (text/diagram/image/photo etc)." box between chat lines!', 'info');
    }
  };

  // Start Screen Recording via MediaRecorder API
  const startScreenRecording = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        showNotification?.("Screen recording is not supported in this browser or environment.", "error");
        return;
      }

      // Check if we already have an active recording
      if (screenRecordingState !== 'idle') {
        showNotification?.("A screen recording session is already active or in progress.", "warning");
        return;
      }

      // Capture screen with robust fallback for system/app audio restrictions
      let displayStream: MediaStream;
      try {
        displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true
        });
      } catch (audioErr) {
        console.warn("Could not capture screen with audio, falling back to video-only capture:", audioErr);
        // Fallback to video-only which is universally supported and doesn't get blocked by strict audio/system permissions
        displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: true
        });
      }

      screenRecordingStreamRef.current = displayStream;
      screenRecordingChunksRef.current = [];

      // Determine supported MIME types
      const mimeTypes = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm;codecs=h264,opus',
        'video/webm',
        'video/mp4'
      ];
      const selectedMime = mimeTypes.find(type => MediaRecorder.isTypeSupported(type)) || '';

      const mediaRecorder = new MediaRecorder(displayStream, selectedMime ? { mimeType: selectedMime } : undefined);
      screenRecordingMediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          screenRecordingChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        if (screenRecordingChunksRef.current.length === 0) {
          showNotification?.("No screen recording data was captured.", "warning");
          setScreenRecordingState('idle');
          return;
        }

        const blob = new Blob(screenRecordingChunksRef.current, {
          type: selectedMime || 'video/webm'
        });
        const url = URL.createObjectURL(blob);
        setScreenRecordingUrl(url);
        setScreenRecordingState('stopped');
        setShowScreenPlaybackModal(true);
        showNotification?.("Screen recording completed! Ready for playback.", "success");
      };

      // Handle when user clicks "Stop Sharing" from browser native UI
      displayStream.getVideoTracks()[0].onended = () => {
        stopScreenRecording();
      };

      // Start recording
      mediaRecorder.start(1000);
      setScreenRecordingState('recording');
      setScreenRecordingDuration(0);

      // Start duration stopwatch
      if (screenRecordingTimerRef.current) clearInterval(screenRecordingTimerRef.current);
      screenRecordingTimerRef.current = setInterval(() => {
        setScreenRecordingDuration(prev => prev + 1);
      }, 1000);

      showNotification?.("Screen recording started! Capture your interactive workspace.", "info");
    } catch (err: any) {
      console.error("Screen recording failed:", err);
      const isPermissionDenied = err.name === 'NotAllowedError' || (err.message && err.message.toLowerCase().includes('permission'));
      if (isPermissionDenied) {
        showNotification?.("Screen share permission was cancelled or denied. Please click the button again and select a window or tab to record.", "warning");
      } else {
        showNotification?.("Screen Recording cancelled or failed: " + (err.message || err), "error");
      }
      setScreenRecordingState('idle');
    }
  };

  // Pause Screen Recording
  const pauseScreenRecording = () => {
    if (screenRecordingMediaRecorderRef.current && screenRecordingState === 'recording') {
      screenRecordingMediaRecorderRef.current.pause();
      setScreenRecordingState('paused');
      if (screenRecordingTimerRef.current) clearInterval(screenRecordingTimerRef.current);
      showNotification?.("Screen recording paused.", "info");
    }
  };

  // Resume Screen Recording
  const resumeScreenRecording = () => {
    if (screenRecordingMediaRecorderRef.current && screenRecordingState === 'paused') {
      screenRecordingMediaRecorderRef.current.resume();
      setScreenRecordingState('recording');
      screenRecordingTimerRef.current = setInterval(() => {
        setScreenRecordingDuration(prev => prev + 1);
      }, 1000);
      showNotification?.("Screen recording resumed.", "info");
    }
  };

  // Stop Screen Recording
  const stopScreenRecording = () => {
    if (screenRecordingTimerRef.current) {
      clearInterval(screenRecordingTimerRef.current);
    }
    const recorder = screenRecordingMediaRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      try {
        recorder.requestData();
        recorder.stop();
      } catch (err) {
        console.error("Error stopping recorder:", err);
      }
    }
    // Stop all media tracks to release camera/screen/audio indicators in the browser
    if (screenRecordingStreamRef.current) {
      screenRecordingStreamRef.current.getTracks().forEach(track => {
        try {
          track.stop();
        } catch (e) {}
      });
      screenRecordingStreamRef.current = null;
    }
  };

  // Toggle main dictation mode - opens inline add content box & activates dictation
  const handleToggleDictationMode = async () => {
    if (!inlineBoxTargetMsgId) {
      const targetId = localMessages.length > 0 ? localMessages[localMessages.length - 1].id : 'end';
      inlineBoxOpenedAtRef.current = Date.now();
      setInlineBoxTargetMsgId(targetId);
    }
    
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showNotification?.("Speech recognition is not supported in this browser. Please type directly into the box.", "error");
      return;
    }

    if (isDictating || isInlineDictating) {
      if (dictationRecognitionRef.current) {
        try { dictationRecognitionRef.current.stop(); } catch (e) {}
      }
      setIsDictating(false);
      setIsInlineDictating(false);
      showNotification?.("Dictation stopped.", "info");
      return;
    }

    try {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';
      dictationRecognitionRef.current = rec;

      rec.onstart = () => {
        setIsDictating(true);
        setIsInlineDictating(true);
        showNotification?.("🎙️ Dictation active! Speak directly or write into the 'add content' box.", "info");
      };

      rec.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript.trim()) {
          setInlineBoxText(prev => (prev ? prev + ' ' : '') + transcript.trim());
        }
      };

      rec.onerror = (err: any) => {
        const errorType = err?.error || err;
        if (errorType === 'no-speech') {
          return;
        }
        if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
          const errMsg = "Microphone permission denied by browser settings. Click the lock/mic icon in your address bar to allow access.";
          setMicError(errMsg);
          showNotification?.(errMsg, "error");
        } else if (errorType !== 'aborted') {
          console.log("Dictation status:", errorType);
        }
        setIsDictating(false);
        setIsInlineDictating(false);
      };

      rec.onend = () => {
        setIsDictating(false);
        setIsInlineDictating(false);
      };

      rec.start();
    } catch (err) {
      console.error("Failed to start dictation:", err);
      setIsDictating(false);
      setIsInlineDictating(false);
    }
  };

  // Toggle inline dictation specifically inside the inline insertion box
  const handleToggleInlineDictation = async () => {
    if (!inlineBoxTargetMsgId) {
      const targetId = localMessages.length > 0 ? localMessages[localMessages.length - 1].id : 'end';
      setInlineBoxTargetMsgId(targetId);
    }
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showNotification?.("Speech recognition is not supported in this browser.", "error");
      return;
    }

    if (isInlineDictating) {
      if (dictationRecognitionRef.current) {
        try { dictationRecognitionRef.current.stop(); } catch (e) {}
      }
      setIsInlineDictating(false);
      return;
    }

    try {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';
      dictationRecognitionRef.current = rec;

      rec.onstart = () => {
        setIsInlineDictating(true);
        showNotification?.("🎙️ Speaking into 'add content' box...", "info");
      };

      rec.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript.trim()) {
          setInlineBoxText(prev => (prev ? prev + ' ' : '') + transcript.trim());
        }
      };

      rec.onerror = (err: any) => {
        const errorType = err?.error || err;
        if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
          const errMsg = "Microphone permission denied. Please enable microphone access in browser settings.";
          setMicError(errMsg);
          showNotification?.(errMsg, "error");
        }
        setIsInlineDictating(false);
      };
      rec.onend = () => setIsInlineDictating(false);

      rec.start();
    } catch (e) {
      setIsInlineDictating(false);
    }
  };

  // Upload image/photo into inline box
  const handleInlineImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        setInlineBoxImage(uploadEvent.target?.result as string);
        showNotification?.('Photo / diagram attached to inline content box!', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  // Execute "add content" -> Omni AI writes spoken or written text into chat between lines
  const handleExecuteAddContent = async () => {
    if (!inlineBoxText.trim() && !inlineBoxImage) return;

    setIsInlineAiWriting(true);
    const userText = inlineBoxText.trim();
    const attachedImage = inlineBoxImage;

    const newUserMsg: Message = {
      id: 'msg_' + Date.now(),
      sender: 'user',
      content: userText || (attachedImage ? '[Uploaded Diagram/Photo Content]' : ''),
      timestamp: Date.now(),
      metadata: attachedImage ? { image: attachedImage } : undefined
    };

    let aiContent = "";
    try {
      const prompt = `The user inserted the following content between lines of chat:\n"${userText}"\n${attachedImage ? '[Image/Diagram attached]' : ''}\n\nPlease write a concise, insightful, and formatted Omni AI response expanding on what was spoken or written by the user.`;
      
      aiContent = await generateAIResponse(prompt, { mode: isLectureMode ? lectureSubMode : 'standard' });
    } catch (err) {
      console.warn("AI generation error, using fallback format:", err);
    }

    if (!aiContent) {
      aiContent = `🎓 **Omni AI Analysis & Note**: You added: "${userText}". Here is the step-by-step breakdown:\n\n1. **Core Concept**: This relates directly to our active topic.\n2. **Key Insight**: ${userText.length > 20 ? userText : 'This provides essential context to the current explanation.'}\n\nAll notes have been recorded seamlessly into the chat thread!`;
    }

    const newAiMsg: Message = {
      id: 'msg_' + (Date.now() + 1),
      sender: 'ai',
      content: aiContent,
      timestamp: Date.now() + 1
    };

    setLocalMessages(prev => [...prev, newUserMsg, newAiMsg]);

    setIsInlineAiWriting(false);
    setInlineBoxText('');
    setInlineBoxImage(null);
    setInlineBoxTargetMsgId(null);
    showNotification?.('Content and Omni AI written response incorporated into chat between lines!', 'success');
  };

  // Click again outside box -> complete addition
  const handleFinalizeInlineAddition = () => {
    if (isInlineAiWriting) return;
    if (inlineBoxText.trim() || inlineBoxImage) {
      handleExecuteAddContent();
    } else {
      setInlineBoxTargetMsgId(null);
    }
  };

  // Click outside listener for inline box
  useEffect(() => {
    const handleClickOutsideInlineBox = (event: MouseEvent) => {
      if (Date.now() - inlineBoxOpenedAtRef.current < 400) {
        return;
      }
      if (
        inlineBoxTargetMsgId &&
        inlineBoxContainerRef.current &&
        !inlineBoxContainerRef.current.contains(event.target as Node)
      ) {
        handleFinalizeInlineAddition();
      }
    };

    document.addEventListener('mousedown', handleClickOutsideInlineBox);
    return () => {
      document.removeEventListener('mousedown', handleClickOutsideInlineBox);
    };
  }, [inlineBoxTargetMsgId, inlineBoxText, inlineBoxImage, isInlineAiWriting]);

  // Predictive Autocomplete state
  const [autocompleteSuggestions, setAutocompleteSuggestions] = useState<PredictiveTerm[]>([]);
  const [selectedAutocompleteIndex, setSelectedAutocompleteIndex] = useState<number>(0);
  const [isAutocompleteDismissed, setIsAutocompleteDismissed] = useState<boolean>(false);

  const handleAskCrashDoubt = () => {
    if (!crashDoubtText.trim()) return;
    saveLectureBookmark("Crash Doubt Raised");
    if (speakingMessageId) {
      interruptedLectureMsgIdRef.current = speakingMessageId;
      interruptedWordIndexRef.current = speakingWordIndex >= 0 ? speakingWordIndex : 0;
    } else {
      const lastAi = [...messages].reverse().find(m => m.sender === 'ai');
      if (lastAi) {
        interruptedLectureMsgIdRef.current = lastAi.id;
        interruptedWordIndexRef.current = 0;
      }
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (audioSourceRef.current) {
      try {
        audioSourceRef.current.onended = null;
        audioSourceRef.current.stop();
      } catch (e) {}
      audioSourceRef.current = null;
    }
    setIsSpeaking(false);
    setIsPaused(true);
    setSpeakingMessageId(null);

    const prompt = `[CRASH DOUBT / LIVE LECTURE INTERRUPTION] The student has raised an urgent doubt during the running lecture: "${crashDoubtText}". 
PROFESSOR INSTRUCTIONS:
1. Instantly pause the main lecture flow.
2. Address and clarify this doubt thoroughly with deep pedagogical insight and step-by-step clarity (using markdown headers and LaTeX equations).
3. Conclude with a clear transition cue indicating how to resume the rest of the lecture flow.`;
    onSendMessage(prompt);
    setCrashDoubtText('');
    setIsCrashDoubtModalOpen(false);
    showNotification?.("Lecture paused for live crash doubt. Professor is clarifying step-by-step...", "info");
  };

  const insertLatex = (snippet: string) => {
    setInput(prev => prev + (prev.endsWith(' ') || prev === '' ? '' : ' ') + snippet);
    showNotification?.(`Inserted LaTeX: ${snippet}`, "info");
  };

  const handleStartDiagramQuiz = (msgId: string, annotations: any[]) => {
    if (!annotations || annotations.length === 0) {
      showNotification?.("No diagram hotspot annotations found for quiz mode.", "warning");
      return;
    }
    setActiveDiagramQuiz(prev => ({
      ...prev,
      [msgId]: {
        targetIndex: 0,
        score: 0,
        total: annotations.length,
        answeredNodes: {},
        completed: false,
        feedback: null
      }
    }));
    showNotification?.("🎯 Diagram Active Recall Quiz started! Click the correct hotspot on the diagram.", "info");
  };

  const handleQuizHotspotClick = (msgId: string, clickedIndex: number, annotations: any[]) => {
    const quiz = activeDiagramQuiz[msgId];
    if (!quiz || quiz.completed) return;

    const targetAnno = annotations[quiz.targetIndex];
    const clickedAnno = annotations[clickedIndex];

    if (clickedIndex === quiz.targetIndex) {
      const nextScore = quiz.score + 1;
      const nextAnswered = { ...quiz.answeredNodes, [clickedIndex]: true };
      
      let nextTarget = -1;
      for (let i = 0; i < annotations.length; i++) {
        if (!nextAnswered[i]) {
          nextTarget = i;
          break;
        }
      }

      if (nextTarget === -1) {
        setActiveDiagramQuiz(prev => ({
          ...prev,
          [msgId]: {
            ...quiz,
            score: nextScore,
            answeredNodes: nextAnswered,
            completed: true,
            feedback: { type: 'success', msg: `🎉 Perfect! You scored ${nextScore}/${quiz.total} (100%) on this diagram!` }
          }
        }));
        showNotification?.(`🏆 Quiz Complete! Outstanding score: ${nextScore}/${quiz.total}!`, "success");
      } else {
        setActiveDiagramQuiz(prev => ({
          ...prev,
          [msgId]: {
            ...quiz,
            targetIndex: nextTarget,
            score: nextScore,
            answeredNodes: nextAnswered,
            feedback: { type: 'success', msg: `✨ Correct! "${targetAnno.label}" identified.` }
          }
        }));
        showNotification?.(`✨ Correct! Next target: "${annotations[nextTarget].label}"`, "success");
      }
    } else {
      setActiveDiagramQuiz(prev => ({
        ...prev,
        [msgId]: {
          ...quiz,
          feedback: { type: 'error', msg: `❌ That was Node ${clickedIndex + 1} ("${clickedAnno?.label || 'Unknown'}"). Try locating "${targetAnno?.label}"!` }
        }
      }));
    }
  };

  const handleStartAudioTour = async (msgId: string, annotations: any[]) => {
    if (!annotations || annotations.length === 0) {
      showNotification?.("No diagram annotations to read for audio tour.", "warning");
      return;
    }
    
    if (activeAudioTour?.msgId === msgId && activeAudioTour.isPlaying) {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      setActiveAudioTour(null);
      setHoveredAnnoIndex(null);
      showNotification?.("Audio diagram tour stopped.", "info");
      return;
    }

    showNotification?.("🔊 Starting Audio Diagram Tour...", "info");
    
    for (let i = 0; i < annotations.length; i++) {
      const anno = annotations[i];
      setActiveAudioTour({ msgId, nodeIndex: i, isPlaying: true });
      setHoveredAnnoIndex({ msgId, index: i });

      const speechText = `Node ${i + 1}: ${anno.label}. ${anno.description}`;
      
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(speechText);
        utterance.rate = 0.92;
        window.speechSynthesis.speak(utterance);
        
        await new Promise(resolve => {
          utterance.onend = () => resolve(true);
          utterance.onerror = () => resolve(true);
          setTimeout(resolve, Math.max(3500, speechText.length * 85));
        });
      } else {
        await new Promise(resolve => setTimeout(resolve, 4000));
      }
    }

    setActiveAudioTour(null);
    setHoveredAnnoIndex(null);
    showNotification?.("🔊 Audio Diagram Tour finished!", "success");
  };

  const handleExportAnnotations = (annotations: any[], format: 'json' | 'csv') => {
    if (!annotations || annotations.length === 0) return;
    if (format === 'json') {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(annotations, null, 2));
      const dlAnchorElem = document.createElement('a');
      dlAnchorElem.setAttribute("href", dataStr);
      dlAnchorElem.setAttribute("download", "diagram_annotations.json");
      dlAnchorElem.click();
      showNotification?.("Annotations exported as JSON successfully!", "success");
    } else {
      let csvContent = "data:text/csv;charset=utf-8,Index,Label,Description,X,Y\n";
      annotations.forEach((anno, i) => {
        const row = [i + 1, `"${anno.label.replace(/"/g, '""')}"`, `"${anno.description.replace(/"/g, '""')}"`, anno.x, anno.y];
        csvContent += row.join(",") + "\n";
      });
      const encodedUri = encodeURI(csvContent);
      const dlAnchorElem = document.createElement('a');
      dlAnchorElem.setAttribute("href", encodedUri);
      dlAnchorElem.setAttribute("download", "diagram_annotations.csv");
      dlAnchorElem.click();
      showNotification?.("Annotations exported as CSV successfully!", "success");
    }
  };

  const handleRefreshDiagram = async (msg: Message) => {
    if (!msg.metadata?.image) return;

    setRefreshingDiagramIds(prev => new Set(prev).add(msg.id));
    playChalkSound('sequence');
    showNotification?.("🔄 Re-generating topic figure to synchronize with state...", "info");

    try {
      const topicName = msg.metadata.topic || topic || "educational diagram";
      const refreshPrompt = `High-resolution clean 2D vector scientific diagram and educational schematic illustrating ${topicName}. Clean minimalist dark slate background, crisp multi-color lines, clear scientific callouts with arrows, accurate formula boxes and annotated parts, professional textbook diagram, zero photographic wooden frames, zero hands, zero camera blur, zero realistic chalkboards.`;

      const newImageUrl = await generateImage(refreshPrompt, '1:1', chalkboardDrawingStyle);

      if (newImageUrl) {
        playChalkSound('tap');
        cacheStudyFigure(newImageUrl, topicName, msg.metadata?.annotations);
        setLocalMessages(prev => prev.map(m => {
          if (m.id === msg.id) {
            return {
              ...m,
              metadata: {
                ...m.metadata,
                image: newImageUrl
              }
            };
          }
          return m;
        }));

        showNotification?.("✨ Diagram figure successfully refreshed & synchronized!", "success");
      } else {
        showNotification?.("Failed to refresh diagram image. Please try again.", "error");
      }
    } catch (err) {
      console.error("Error refreshing diagram:", err);
      showNotification?.("Error re-generating diagram figure.", "error");
    } finally {
      setRefreshingDiagramIds(prev => {
        const next = new Set(prev);
        next.delete(msg.id);
        return next;
      });
    }
  };

  const handleDownloadPNG = async (msg: Message) => {
    const imageUrl = msg.metadata?.image;
    if (!imageUrl) return;

    try {
      showNotification?.("⏳ Preparing high-quality PNG figure download...", "info");
      const topicTitle = (msg.metadata?.topic || topic || "diagram").toLowerCase().replace(/[^a-z0-9]/g, "_");
      const filename = `${topicTitle}_figure.png`;

      if (imageUrl.startsWith('data:')) {
        const link = document.createElement('a');
        link.href = imageUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        showNotification?.("✅ PNG study figure downloaded successfully!", "success");
        return;
      }

      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);

      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);

      showNotification?.("✅ High-quality PNG study figure downloaded!", "success");
    } catch (err) {
      console.error("Failed to download PNG figure:", err);
      const link = document.createElement('a');
      link.href = imageUrl;
      link.download = `${(msg.metadata?.topic || "diagram").replace(/[^a-z0-9]/gi, "_")}.png`;
      link.target = "_blank";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showNotification?.("Downloaded study figure PNG.", "success");
    }
  };

  const handleImageClickForReposition = (e: React.MouseEvent<HTMLDivElement>, msgId: string, index: number) => {
    if (!repositioningAnno || repositioningAnno.msgId !== msgId || repositioningAnno.index !== index) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(100, Math.round(((e.clientX - rect.left) / rect.width) * 100)));
    const y = Math.max(0, Math.min(100, Math.round(((e.clientY - rect.top) / rect.height) * 100)));

    setLocalMessages(prev => prev.map(m => {
      if (m.id === msgId && m.metadata?.annotations) {
        const newAnns = [...m.metadata.annotations];
        const selectedSet = selectedAnnoIndices[msgId];
        if (selectedSet && selectedSet.has(index) && selectedSet.size > 1) {
          const oldAnno = newAnns[index];
          const dx = x - oldAnno.x;
          const dy = y - oldAnno.y;
          selectedSet.forEach(idx => {
            if (newAnns[idx]) {
              newAnns[idx] = {
                ...newAnns[idx],
                x: Math.max(0, Math.min(100, Math.round(newAnns[idx].x + dx))),
                y: Math.max(0, Math.min(100, Math.round(newAnns[idx].y + dy))),
              };
            }
          });
        } else {
          newAnns[index] = { ...newAnns[index], x, y };
        }

        pushAnnotationHistory(msgId, newAnns);
        saveAnnotationsToLocalStorage(msgId, newAnns);
        return { ...m, metadata: { ...m.metadata, annotations: newAnns } };
      }
      return m;
    }));

    setRepositioningAnno(null);
    showNotification?.(`Hotspot #${index + 1} repositioned successfully (auto-saved)`, "success");
  };

  const handleUndoAnnotation = (msgId: string) => {
    const historyList = annotationHistory[msgId];
    const currentIndex = annotationHistoryIndex[msgId];
    if (!historyList || currentIndex <= 0) {
      showNotification?.("No further undo actions available", "info");
      return;
    }
    const newIdx = currentIndex - 1;
    const targetAnns = historyList[newIdx];
    setAnnotationHistoryIndex(prev => ({ ...prev, [msgId]: newIdx }));
    setLocalMessages(prev => prev.map(m => {
      if (m.id === msgId && m.metadata) {
        const updated = { ...m, metadata: { ...m.metadata, annotations: JSON.parse(JSON.stringify(targetAnns)) } };
        saveAnnotationsToLocalStorage(msgId, targetAnns);
        return updated;
      }
      return m;
    }));
    showNotification?.("Reverted recent position change (Undo)", "success");
  };

  const handleRedoAnnotation = (msgId: string) => {
    const historyList = annotationHistory[msgId];
    const currentIndex = annotationHistoryIndex[msgId];
    if (!historyList || currentIndex >= historyList.length - 1) {
      showNotification?.("No further redo actions available", "info");
      return;
    }
    const newIdx = currentIndex + 1;
    const targetAnns = historyList[newIdx];
    setAnnotationHistoryIndex(prev => ({ ...prev, [msgId]: newIdx }));
    setLocalMessages(prev => prev.map(m => {
      if (m.id === msgId && m.metadata) {
        const updated = { ...m, metadata: { ...m.metadata, annotations: JSON.parse(JSON.stringify(targetAnns)) } };
        saveAnnotationsToLocalStorage(msgId, targetAnns);
        return updated;
      }
      return m;
    }));
    showNotification?.("Restored position change (Redo)", "success");
  };

  // Scientific Unit Pronunciation Practice states
  const [activePracticeMsgId, setActivePracticeMsgId] = useState<string | null>(null);
  const [activePracticeUnit, setActivePracticeUnit] = useState<UnitItem | null>(null);
  const [practiceRecording, setPracticeRecording] = useState<boolean>(false);
  const [practiceTranscript, setPracticeTranscript] = useState<string>('');
  const [practiceResult, setPracticeResult] = useState<{
    score: number;
    feedback: string;
    matchedWords: { word: string; isCorrect: boolean }[];
  } | null>(null);
  const [practiceIsSpeaking, setPracticeIsSpeaking] = useState<boolean>(false);
  const [practiceMode, setPracticeMode] = useState<'hinglish' | 'english' | 'hindi'>('hinglish');
  
  const practiceRecognitionRef = useRef<any>(null);

  // Stop speechSynthesis and recognition on cleanups or active practice change
  useEffect(() => {
    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (practiceRecognitionRef.current) {
        try {
          practiceRecognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, []);

  const handlePracticeListenDemo = (unit: UnitItem) => {
    if (!window.speechSynthesis) {
      showNotification?.("Text-to-speech is not supported in this browser.", "error");
      return;
    }
    window.speechSynthesis.cancel();
    setPracticeIsSpeaking(true);

    let textToSpeak = '';
    let lang = 'en-US';

    if (practiceMode === 'english') {
      textToSpeak = unit.spokenEnglish;
      lang = 'en-US';
    } else if (practiceMode === 'hinglish') {
      textToSpeak = unit.spokenHinglish;
      lang = 'en-IN';
    } else {
      textToSpeak = unit.spokenHindi;
      lang = 'hi-IN';
    }

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = lang;
    utterance.rate = 0.85;

    utterance.onend = () => {
      setPracticeIsSpeaking(false);
    };
    utterance.onerror = () => {
      setPracticeIsSpeaking(false);
    };

    window.speechSynthesis.speak(utterance);
  };

  const handleTogglePracticeSpeech = (unit: UnitItem, messageId: string) => {
    if (practiceRecording) {
      if (practiceRecognitionRef.current) {
        practiceRecognitionRef.current.stop();
      }
      setPracticeRecording(false);
      return;
    }

    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showNotification?.("Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.", "error");
      return;
    }

    setPracticeTranscript('');
    setPracticeResult(null);
    setPracticeRecording(true);

    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = false;

    if (practiceMode === 'hindi') {
      rec.lang = 'hi-IN';
    } else if (practiceMode === 'hinglish') {
      rec.lang = 'en-IN';
    } else {
      rec.lang = 'en-US';
    }

    rec.onresult = (event: any) => {
      const finalResult = event.results[0][0].transcript;
      setPracticeTranscript(finalResult);
      
      // scoring
      const cleanUser = finalResult.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "").trim();
      
      let targetPhrase = '';
      if (practiceMode === 'english') {
        targetPhrase = unit.spokenEnglish;
      } else if (practiceMode === 'hinglish') {
        targetPhrase = unit.spokenHinglish;
      } else {
        targetPhrase = unit.spokenHindi;
      }

      const cleanTarget = targetPhrase.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "").trim();
      
      const targetWords = cleanTarget.split(/\s+/);
      const userWords = cleanUser.split(/\s+/);

      const matchedWords = targetWords.map(tWord => {
        const isCorrect = userWords.some((uWord: string) => {
          if (uWord === tWord) return true;
          const normalize = (w: string) => w
            .replace(/ee/g, 'i')
            .replace(/y/g, 'i')
            .replace(/u/g, 'oo')
            .replace(/k/g, 'c')
            .replace(/s/g, 'c')
            .replace(/ph/g, 'f')
            .replace(/h/g, '')
            .replace(/v/g, 'w');
          return normalize(uWord) === normalize(tWord);
        });
        return { word: tWord, isCorrect };
      });

      const correctCount = matchedWords.filter(m => m.isCorrect).length;
      let score = Math.round((correctCount / targetWords.length) * 100);

      if (cleanUser === cleanTarget) {
        score = 100;
      }

      let feedback = '';
      if (score >= 90) {
        feedback = "Perfect! Your pronunciation of the scientific unit is absolutely spot-on!";
        if (onAwardXp) {
          onAwardXp(15);
        }
      } else if (score >= 70) {
        feedback = "Excellent effort! You got most of the parts right. Listen to the AI tutor and try again to hit 100%.";
      } else if (score >= 40) {
        feedback = "Good try. Emphasize multi-part breaks like 'prati' or 'square' more clearly.";
      } else {
        feedback = "Pronunciation was a bit unclear. Try listening to the tutor, matching the rate, and repeating.";
      }

      setPracticeResult({
        score,
        feedback,
        matchedWords
      });
    };

    rec.onerror = (e: any) => {
      const errorType = e?.error || '';
      if (errorType === 'no-speech' || errorType === 'aborted') {
        setPracticeRecording(false);
        return;
      }
      if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
        showNotification?.('Microphone permission denied.', 'warning');
      }
      setPracticeRecording(false);
    };

    rec.onend = () => {
      setPracticeRecording(false);
    };

    practiceRecognitionRef.current = rec;
    rec.start();
  };
  
  const mainScrollContainerRef = useRef<HTMLDivElement>(null);
  const [isAutoScrollPaused, setIsAutoScrollPaused] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (isTyping) {
      setTypingSeconds(0);
      interval = setInterval(() => {
        setTypingSeconds(prev => prev + 1);
      }, 1000);
    } else {
      setTypingSeconds(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTyping]);

  const [isChalkSfxEnabled, setIsChalkSfxEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('omni_chalk_sfx');
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const [input, setInput] = useState('');
  const inputRef = useRef(input);
  const autoSendTimeoutRef = useRef<any>(null);
  
  useEffect(() => {
    inputRef.current = input;
  }, [input]);

  useEffect(() => {
    if (isTextareaFocused && !isAutocompleteDismissed && !isShared) {
      const suggestions = getPredictiveSuggestions(input, subject, topic, 5);
      setAutocompleteSuggestions(suggestions);
    } else {
      setAutocompleteSuggestions([]);
    }
  }, [input, subject, topic, isTextareaFocused, isAutocompleteDismissed, isShared]);

  const handleSelectAutocomplete = (term: PredictiveTerm) => {
    setInput(term.text);
    setIsAutocompleteDismissed(true);
    setSelectedAutocompleteIndex(0);
  };

  // Auto-suggestion unit pronunciation feedback states and helpers
  const [detectedUnit, setDetectedUnit] = useState<any | null>(null);
  const [dismissedUnits, setDismissedUnits] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!input || input.trim() === '') {
      setDetectedUnit(null);
      return;
    }

    const found = GLOSSARY_ITEMS.find(item => {
      if (dismissedUnits.has(item.symbol)) return false;

      let escapedSymbol = item.symbol
        .replace(/\//g, '\\s*/\\s*')
        .replace(/²/g, '(?:\\^2|²|2)')
        .replace(/³/g, '(?:\\^3|³|3)')
        .replace(/·/g, '[·•*.-]?');

      const regex = new RegExp(`\\b${escapedSymbol}\\b|${escapedSymbol}`, 'i');
      return regex.test(input);
    });

    if (found) {
      setDetectedUnit(found);
    } else {
      setDetectedUnit(null);
    }
  }, [input, dismissedUnits]);

  useEffect(() => {
    if (!input || input.trim() === '') {
      setDismissedUnits(new Set());
    }
  }, [input]);

  const handlePlayPronunciation = (text: string) => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.85; // slightly slower for educational precision
      window.speechSynthesis.speak(utterance);
    }
  };

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isVadEnabled, setIsVadEnabled] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [isInterrupted, setIsInterrupted] = useState(false);
  const [interruptionSentiment, setInterruptionSentiment] = useState<string | null>(null);
  const isSpeakingRef = useRef(false);
  const isPausedRef = useRef(false);
  const isRecordingRef = useRef(isRecording);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const isInterruptPendingRef = useRef(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserNodeRef = useRef<AnalyserNode | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const [speakingWordIndex, setSpeakingWordIndex] = useState<number>(-1);

  // --- CLASSROOM LESSON VIDEO PLAYER STATES ---
  const [activeLessonVideo, setActiveLessonVideo] = useState<Message | null>(null);
  const [videoPlayStatus, setVideoPlayStatus] = useState<'idle' | 'drawing' | 'writing' | 'completed'>('idle');
  const [videoDrawingProgress, setVideoDrawingProgress] = useState<number>(0);
  const [videoTab, setVideoTab] = useState<'board' | 'transcript' | 'bookmarks' | 'speed'>('board');
  const [transcriptSearch, setTranscriptSearch] = useState<string>('');
  const timelineRef = useRef<HTMLDivElement>(null);
  const transcriptContainerRef = useRef<HTMLDivElement>(null);
  const [isTranscriptAutoScroll, setIsTranscriptAutoScroll] = useState<boolean>(true);
  const [isTranscriptUserScrolled, setIsTranscriptUserScrolled] = useState<boolean>(false);

  // Auto-scroll transcript container to track the active spoken word in real-time
  useEffect(() => {
    if (videoTab === 'transcript' && isTranscriptAutoScroll && speakingWordIndex >= 0) {
      const activeEl = document.getElementById(`video-transcript-word-${speakingWordIndex}`);
      if (activeEl && transcriptContainerRef.current) {
        const container = transcriptContainerRef.current;
        const elTop = activeEl.offsetTop;
        const elHeight = activeEl.offsetHeight;
        const containerHeight = container.clientHeight;
        const targetScrollTop = elTop - containerHeight / 2 + elHeight / 2;
        container.scrollTo({
          top: Math.max(0, targetScrollTop),
          behavior: 'smooth'
        });
      }
    }
  }, [speakingWordIndex, videoTab, isTranscriptAutoScroll]);

  const scrollToActiveSpeakerWord = () => {
    setIsTranscriptAutoScroll(true);
    setIsTranscriptUserScrolled(false);
    if (speakingWordIndex >= 0) {
      const activeEl = document.getElementById(`video-transcript-word-${speakingWordIndex}`);
      if (activeEl && transcriptContainerRef.current) {
        const container = transcriptContainerRef.current;
        const elTop = activeEl.offsetTop;
        const elHeight = activeEl.offsetHeight;
        const containerHeight = container.clientHeight;
        const targetScrollTop = elTop - containerHeight / 2 + elHeight / 2;
        container.scrollTo({
          top: Math.max(0, targetScrollTop),
          behavior: 'smooth'
        });
      }
    }
  };

  const handleSeekToWord = (wordIdx: number) => {
    if (!activeLessonVideo) return;
    const cleanText = cleanTextForNaturalSpeech(activeLessonVideo.content, pronunciationPrecision);
    const cachedBuffer = audioCacheRef.current.get(activeLessonVideo.id);
    const activePlaybackRate = ttsRate;
    const totalDurMs = cachedBuffer ? (cachedBuffer.duration / activePlaybackRate) * 1000 : undefined;
    const matrix = buildWordTimestampMatrix(cleanText, totalDurMs, activePlaybackRate);
    
    const cue = matrix.getCueAtIndex(wordIdx);
    const targetOffsetMs = cue ? cue.startMs : 0;
    const ratio = cue ? cue.startRatio : 0;
    
    // Start speaking from that offset
    setSpeakingWordIndex(wordIdx);
    handleSpeakText(activeLessonVideo.id, activeLessonVideo.content, targetOffsetMs, true);
    showNotification?.(`Timeline jumped to word #${wordIdx + 1} (${Math.round(ratio * 100)}% of lecture)`, "info");
  };

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!activeLessonVideo || videoPlayStatus === 'drawing') return; // Cannot seek during physical board drawing phase
    
    if (timelineRef.current) {
      const rect = timelineRef.current.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickRatio = Math.max(0, Math.min(1, clickX / rect.width));
      
      // Video Classroom timeline progress has two parts:
      // 0% - 15% is the Board drawing phase.
      // 15% - 100% is the Speech Narration phase.
      // So if clickRatio is in the speech narration phase (>= 15%):
      if (clickRatio < 0.15) {
        // Jump to the start of speech
        handleSeekToWord(0);
      } else {
        // Map clickRatio (0.15 - 1.0) back to speech duration
        const speechRatio = (clickRatio - 0.15) / 0.85;
        const cleanText = cleanTextForNaturalSpeech(activeLessonVideo.content, pronunciationPrecision);
        const cachedBuffer = audioCacheRef.current.get(activeLessonVideo.id);
        const activePlaybackRate = ttsRate;
        const totalDurMs = cachedBuffer ? (cachedBuffer.duration / activePlaybackRate) * 1000 : undefined;
        const matrix = buildWordTimestampMatrix(cleanText, totalDurMs, activePlaybackRate);
        
        const targetElapsedMs = speechRatio * matrix.totalAudioDurationMs;
        const targetWordIdx = matrix.getWordIndexAtTime(targetElapsedMs);
        
        handleSeekToWord(targetWordIdx);
      }
    }
  };

  // Automatically extract bookmarks / key checkpoints from the content
  const videoBookmarks = React.useMemo(() => {
    if (!activeLessonVideo) return [];
    const text = activeLessonVideo.content;
    const lines = text.split('\n');
    const list: { label: string; wordIdx: number; type: 'header' | 'bold' | 'milestone'; timeLabel: string }[] = [];
    
    // Split into raw words to find approximate word indices for headers/bold terms
    const rawWords = text.split(/\s+/).filter(Boolean);
    
    // Let's add an intro milestone
    list.push({
      label: "🚀 Lecture Introduction",
      wordIdx: 0,
      type: 'milestone',
      timeLabel: "00:00"
    });

    let currentWordAccumulator = 0;
    lines.forEach((line) => {
      const trimmed = line.trim();
      const wordsInLine = trimmed.split(/\s+/).filter(Boolean).length;
      
      if (trimmed.startsWith('###') || trimmed.startsWith('##') || trimmed.startsWith('#')) {
        const headerText = trimmed.replace(/^#+\s*/, '');
        const approxWordIdx = Math.min(rawWords.length - 1, currentWordAccumulator);
        const ratio = approxWordIdx / Math.max(1, rawWords.length);
        const totalSec = rawWords.length * 0.35;
        const targetSec = ratio * totalSec;
        const mins = Math.floor(targetSec / 60);
        const secs = Math.floor(targetSec % 60);
        const timeStr = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        
        list.push({
          label: headerText,
          wordIdx: approxWordIdx,
          type: 'header',
          timeLabel: timeStr
        });
      } else {
        // Look for bold patterns inside the line
        const boldMatch = trimmed.match(/\*\*([^*]+)\*\*/);
        if (boldMatch && boldMatch[1] && boldMatch[1].length > 2 && boldMatch[1].length < 35) {
          const approxWordIdx = Math.min(rawWords.length - 1, currentWordAccumulator);
          const ratio = approxWordIdx / Math.max(1, rawWords.length);
          const totalSec = rawWords.length * 0.35;
          const targetSec = ratio * totalSec;
          const mins = Math.floor(targetSec / 60);
          const secs = Math.floor(targetSec % 60);
          const timeStr = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
          
          list.push({
            label: boldMatch[1],
            wordIdx: approxWordIdx,
            type: 'bold',
            timeLabel: timeStr
          });
        }
      }
      
      currentWordAccumulator += wordsInLine;
    });

    // If we don't have enough bookmarks, let's inject a few even checkpoints
    if (list.length < 3) {
      const intervals = [
        { pct: 0.3, label: "Diagram & Board Analysis" },
        { pct: 0.6, label: "Deep-Dive Formula Breakdown" },
        { pct: 0.85, label: "Summary & Key Takeaways" }
      ];
      intervals.forEach((item) => {
        const approxWordIdx = Math.floor(rawWords.length * item.pct);
        const ratio = item.pct;
        const totalSec = rawWords.length * 0.35;
        const targetSec = ratio * totalSec;
        const mins = Math.floor(targetSec / 60);
        const secs = Math.floor(targetSec % 60);
        const timeStr = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        
        list.push({
          label: item.label,
          wordIdx: approxWordIdx,
          type: 'milestone',
          timeLabel: timeStr
        });
      });
    }

    // Deduplicate overlapping items near the same index
    const seenIndices = new Set<number>();
    const uniqueList = list.filter((item) => {
      // Round to nearest multiple of 10 to avoid tight grouping
      const bucket = Math.round(item.wordIdx / 15) * 15;
      if (seenIndices.has(bucket) && item.type !== 'milestone') {
        return false;
      }
      seenIndices.add(bucket);
      return true;
    });

    return uniqueList.sort((a, b) => a.wordIdx - b.wordIdx);
  }, [activeLessonVideo]);

  // Voice Input Enhancements (Analyzer, Timer, Sensitivity, Push-to-Talk, Mute, Devices, Silence Detection & Discard/Retry)
  const [micVolume, setMicVolume] = useState<number>(0);
  const [recordingDuration, setRecordingDuration] = useState<number>(0);
  const [voiceMode, setVoiceMode] = useState<'continuous' | 'pushtotalk'>('continuous');
  const [micSensitivity, setMicSensitivity] = useState<number>(30); // 0-100 threshold
  const [showSensitivityOverlay, setShowSensitivityOverlay] = useState<boolean>(false);
  const [isMicMuted, setIsMicMuted] = useState<boolean>(false);
  const [audioDevices, setAudioDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedAudioDeviceId, setSelectedAudioDeviceId] = useState<string>('');
  const [isSilenceDetectionEnabled, setIsSilenceDetectionEnabled] = useState<boolean>(true);
  const [silenceDuration, setSilenceDuration] = useState<number>(4); // seconds
  const [justFinishedVoice, setJustFinishedVoice] = useState<boolean>(false);

  const longPressTimerRef = useRef<any>(null);
  const isLongPressActiveRef = useRef<boolean>(false);
  const isMouseDownRef = useRef<boolean>(false);
  const isMicMutedRef = useRef<boolean>(isMicMuted);
  const micSensitivityRef = useRef<number>(micSensitivity);
  const isSilenceDetectionEnabledRef = useRef<boolean>(isSilenceDetectionEnabled);
  const silenceDurationRef = useRef<number>(silenceDuration);
  const lastActiveSpeechTimeRef = useRef<number>(Date.now());
  const prevIsRecordingRef = useRef<boolean>(isRecording);
  const interruptedLectureMsgIdRef = useRef<string | null>(null);
  const interruptedWordIndexRef = useRef<number>(0);

  const [activeLectureBookmark, setActiveLectureBookmark] = useState<LectureBookmark | null>(() => {
    try {
      const saved = localStorage.getItem('omni_lecture_bookmark');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [showRestoreToast, setShowRestoreToast] = useState<boolean>(false);
  const [isLectureVideoPlaying, setIsLectureVideoPlaying] = useState<boolean>(true);
  const [activeVerbalQuestion, setActiveVerbalQuestion] = useState<VerbalLectureQuestion | null>(null);
  const [isOfflineChat, setIsOfflineChat] = useState<boolean>(typeof navigator !== 'undefined' ? !navigator.onLine : false);
  const [isCacheStatsModalOpen, setIsCacheStatsModalOpen] = useState<boolean>(false);
  const [cacheStats, setCacheStats] = useState<{ metadataItems: number; cachedVideos: number; totalBytes: number }>({ metadataItems: 0, cachedVideos: 0, totalBytes: 0 });

  // Screen Recording State (MediaRecorder API)
  const [screenRecordingState, setScreenRecordingState] = useState<'idle' | 'recording' | 'paused' | 'stopped'>('idle');
  const [screenRecordingDuration, setScreenRecordingDuration] = useState<number>(0);
  const [screenRecordingUrl, setScreenRecordingUrl] = useState<string | null>(null);
  const [showScreenPlaybackModal, setShowScreenPlaybackModal] = useState<boolean>(false);

  const screenRecordingStreamRef = useRef<MediaStream | null>(null);
  const screenRecordingMediaRecorderRef = useRef<MediaRecorder | null>(null);
  const screenRecordingChunksRef = useRef<Blob[]>([]);
  const screenRecordingTimerRef = useRef<any>(null);

  // Clean up screen recording streams and timers on unmount
  useEffect(() => {
    return () => {
      if (screenRecordingStreamRef.current) {
        screenRecordingStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (screenRecordingTimerRef.current) {
        clearInterval(screenRecordingTimerRef.current);
      }
    };
  }, []);

  const [timelineMarkers, setTimelineMarkers] = useState<TimelineMarker[]>([
    {
      id: 'tm_init_1',
      type: 'professor_shift',
      timestampSec: 45,
      title: 'Professor Shift: Strict Boardwork',
      description: 'Professor shifted to Strict Professor mode for mathematical rigor.',
      professorStyle: 'strict',
      subMode: 'lecture',
      createdAt: new Date().toISOString()
    },
    {
      id: 'tm_init_2',
      type: 'checkpoint_question',
      timestampSec: 120,
      title: 'Checkpoint Question: Energy Conservation',
      description: 'What is the principle of conservation of energy?',
      status: 'pending',
      createdAt: new Date().toISOString()
    },
    {
      id: 'tm_init_3',
      type: 'professor_shift',
      timestampSec: 240,
      title: 'Professor Shift: Interactive Mentor',
      description: 'Professor shifted to Interactive Mentor mode for Socratic guidance.',
      professorStyle: 'mentor',
      subMode: 'classroom',
      createdAt: new Date().toISOString()
    }
  ]);

  // Monitor network online/offline state
  useEffect(() => {
    const handleOnline = () => {
      setIsOfflineChat(false);
      showNotification?.("Network restored! Synchronizing with AI tutor...", "success");
    };
    const handleOffline = () => {
      setIsOfflineChat(true);
      showNotification?.("Network offline! IndexedDB continuity mode active.", "warning");
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Global Keyboard Shortcuts for Lecture Mode now handled by App.tsx
  useEffect(() => {
    // Left intentionally empty to avoid conflict with App.tsx global listener
  }, [isLectureMode, showNotification]);

  // Periodic and event-driven IndexedDB auto-save of active lecture state
  useEffect(() => {
    const syncToIndexedDB = async () => {
      if (localMessages.length > 0 || activeLectureBookmark || activeVerbalQuestion) {
        await cacheLectureMetadata('omni_active_lecture_cache', {
          messages: localMessages.slice(-20),
          bookmark: activeLectureBookmark,
          verbalQuestion: activeVerbalQuestion,
          lectureSubMode,
          lectureProfessorStyle,
          subject,
          updatedAt: Date.now()
        });
      }
      const stats = await getLectureCacheStats();
      setCacheStats(stats);
    };

    syncToIndexedDB();
  }, [localMessages.length, activeLectureBookmark, activeVerbalQuestion, lectureSubMode, lectureProfessorStyle, subject]);

  // Load cached lecture metadata from IndexedDB if memory state is empty or on mount
  useEffect(() => {
    const loadFromIndexedDBCache = async () => {
      if (!activeLectureBookmark) {
        const cachedBookmark = await getLectureMetadata<LectureBookmark>('omni_latest_lecture_bookmark');
        if (cachedBookmark) {
          setActiveLectureBookmark(cachedBookmark);
        }
      }
      const stats = await getLectureCacheStats();
      setCacheStats(stats);
    };

    loadFromIndexedDBCache();
  }, []);

  const handleEvaluateVerbalLectureReply = (verbalReplyText: string): boolean => {
    if (!activeVerbalQuestion) return false;
    if (!verbalReplyText || !verbalReplyText.trim()) return false;

    const cleanReply = verbalReplyText.toLowerCase().trim();
    const keywords = activeVerbalQuestion.expectedKeywords.map(k => k.toLowerCase().trim()).filter(Boolean);

    // Concept matching: check if spoken text matches expected keywords or contains core terms
    const matchedKeywords = keywords.filter(k => cleanReply.includes(k));
    const isCorrect = matchedKeywords.length > 0 || keywords.length === 0 || cleanReply.split(/\s+/).length >= 3;

    if (isCorrect) {
      const updatedQ: VerbalLectureQuestion = {
        ...activeVerbalQuestion,
        status: 'correct',
        lastUserReply: verbalReplyText,
        feedback: '🎯 Excellent! Answer evaluated as correct. Video content resuming...'
      };
      setActiveVerbalQuestion(updatedQ);

      // Update timeline marker status to correct
      setTimelineMarkers(prev => prev.map(m => {
        if (m.type === 'checkpoint_question' && (m.status === 'pending' || m.description === activeVerbalQuestion.questionText)) {
          return { ...m, status: 'correct' };
        }
        return m;
      }));

      // Trigger state-based resumption of video content!
      setIsLectureVideoPlaying(true);

      showNotification?.("🎯 Correct Answer! Verbal reply verified. Resuming video lecture content... 🎓", "success");
      onAwardXp?.(25);

      if (interruptedLectureMsgIdRef.current) {
        handleResumeInterruptedLecture();
      } else if (activeLectureBookmark) {
        restoreLectureBookmark(activeLectureBookmark);
      }

      return true;
    } else {
      const updatedQ: VerbalLectureQuestion = {
        ...activeVerbalQuestion,
        status: 'incorrect',
        lastUserReply: verbalReplyText,
        feedback: '💡 Close attempt! Check key terms and try speaking your answer again.'
      };
      setActiveVerbalQuestion(updatedQ);

      // Update timeline marker status to incorrect
      setTimelineMarkers(prev => prev.map(m => {
        if (m.type === 'checkpoint_question' && m.status === 'pending') {
          return { ...m, status: 'incorrect' };
        }
        return m;
      }));

      // Keep video paused until correct verbal reply is provided
      setIsLectureVideoPlaying(false);

      showNotification?.("💡 Verbal answer needs revision. Video content remains paused.", "warning");
      return false;
    }
  };

  const handlePauseVideoForLectureQuestion = (
    questionText: string,
    expectedKeywords: string[] = ['gravity', 'force', 'acceleration', 'velocity', 'energy', 'yes', 'correct'],
    explanation?: string
  ) => {
    const bm = saveLectureBookmark("Lecture Question Asked");
    const timestampSec = bm?.timestampSec || Math.floor((elapsedMsRef.current || 0) / 1000) || 120;
    const q: VerbalLectureQuestion = {
      id: `vq_${Date.now()}`,
      messageId: speakingMessageId || undefined,
      questionText,
      expectedKeywords,
      explanation,
      timestampSec,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    setActiveVerbalQuestion(q);
    setIsLectureVideoPlaying(false);

    // Add marker to visual timeline
    const marker: TimelineMarker = {
      id: `tm_q_${q.id}`,
      type: 'checkpoint_question',
      timestampSec,
      title: `Checkpoint: ${questionText.substring(0, 30)}${questionText.length > 30 ? '...' : ''}`,
      description: questionText,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    setTimelineMarkers(prev => [...prev.filter(m => m.description !== questionText), marker]);

    showNotification?.("❓ Video paused for Lecture Question! Speak your answer verbally to resume video playback.", "info");
  };

  const handleToggleProfessorStyle = () => {
    const next = lectureProfessorStyle === 'strict' ? 'mentor' : 'strict';
    saveLectureBookmark(`Mode Switch to ${next === 'strict' ? 'Strict Professor' : 'Interactive Mentor'}`);
    setLectureProfessorStyle?.(next);
    localStorage.setItem('omni_lecture_professor_style', next);

    const marker: TimelineMarker = {
      id: `tm_shift_${Date.now()}`,
      type: 'professor_shift',
      timestampSec: Math.floor((elapsedMsRef.current || 0) / 1000) || 300,
      title: `Professor Shift: ${next === 'strict' ? 'Strict Boardwork' : 'Interactive Mentor'}`,
      description: `Shifted to ${next === 'strict' ? 'Strict Professor' : 'Interactive Mentor'} mode.`,
      professorStyle: next,
      subMode: lectureSubMode,
      createdAt: new Date().toISOString()
    };
    setTimelineMarkers(prev => [...prev, marker]);

    showNotification?.(
      next === 'strict' 
        ? "Switched to Strict Professor mode (Rigorous derivations & boardwork)." 
        : "Switched to Interactive Mentor mode (Socratic guidance & collaborative dialogue).",
      "info"
    );
  };

  // --- CLASSROOM LESSON VIDEO PLAYER EFFECTS ---

  // Handle Figure Drawing Phase - Instantly render without artificial blackboard animation delay
  useEffect(() => {
    if (!activeLessonVideo || videoPlayStatus !== 'drawing') return;

    // Immediately complete drawing and proceed to lecture without animating progress or spinning icons
    setVideoDrawingProgress(100);
    setVideoPlayStatus('writing');
    const timing = calculateBoardworkTiming(activeLessonVideo.content, {
      ttsRate,
      typingPace,
      blackboardWritingSpeed,
      isAdaptiveSpeedEnabled,
      isBreathingPausesEnabled
    });
    handleSpeakText(activeLessonVideo.id, activeLessonVideo.content, 0, true, timing.calculatedPlaybackRate);
  }, [activeLessonVideo, videoPlayStatus]);

  // Monitor speaking status to advance to 'completed'
  useEffect(() => {
    if (activeLessonVideo && videoPlayStatus === 'writing' && !isSpeaking && !isPaused) {
      // Narration has finished! Reveal final completed chalkboard
      setVideoPlayStatus('completed');
      
      // Play a satisfying complete chime or soft blackboard dusting sound
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          const ctx = new AudioContextClass();
          const osc1 = ctx.createOscillator();
          const osc2 = ctx.createOscillator();
          const gainNode = ctx.createGain();
          
          osc1.type = 'sine';
          osc1.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
          osc1.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.4); // A5
          
          osc2.type = 'sine';
          osc2.frequency.setValueAtTime(659.25, ctx.currentTime); // E5
          osc2.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.4); // C6
          
          gainNode.gain.setValueAtTime(0.02, ctx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
          
          osc1.connect(gainNode);
          osc2.connect(gainNode);
          gainNode.connect(ctx.destination);
          
          osc1.start();
          osc2.start();
          osc1.stop(ctx.currentTime + 0.5);
          osc2.stop(ctx.currentTime + 0.5);
        }
      } catch (e) {}

      showNotification?.("🎉 Classroom Lecture Completed! Classroom Board Compiled.", "success");
      onAwardXp?.(25);
    }
  }, [isSpeaking, activeLessonVideo, videoPlayStatus, isPaused]);

  const saveLectureBookmark = (
    reason: string,
    customMsgId?: string,
    customWordIdx?: number,
    customMs?: number
  ) => {
    const targetMsgId = customMsgId || speakingMessageId || [...messages].reverse().find(m => m.sender === 'ai')?.id;
    const wordIdx = customWordIdx ?? (speakingWordIndex >= 0 ? speakingWordIndex : 0);
    const timeMs = customMs ?? elapsedMsRef.current ?? 0;
    const timeSec = Math.floor(timeMs / 1000);

    const mins = Math.floor(timeSec / 60).toString().padStart(2, '0');
    const secs = (timeSec % 60).toString().padStart(2, '0');
    const timeLabel = `${mins}:${secs}`;

    const targetMsg = messages.find(m => m.id === targetMsgId) || [...messages].reverse().find(m => m.sender === 'ai');
    const snippet = targetMsg?.content ? targetMsg.content.substring(0, 50) : "Lecture Segment";

    const bookmark: LectureBookmark = {
      id: `bookmark_${Date.now()}`,
      messageId: targetMsgId,
      timestampMs: timeMs,
      timestampSec: timeSec,
      wordIndex: wordIdx,
      timeLabel,
      lectureSubMode,
      professorStyle: lectureProfessorStyle || 'strict',
      reason,
      snippet,
      createdAt: new Date().toISOString()
    };

    setActiveLectureBookmark(bookmark);
    try {
      localStorage.setItem('omni_lecture_bookmark', JSON.stringify(bookmark));
    } catch (err) {
      console.warn("Could not persist lecture bookmark:", err);
    }

    // Persist to IndexedDB
    cacheLectureMetadata('omni_latest_lecture_bookmark', bookmark);
    cacheLectureMetadata('omni_active_lecture_cache', {
      bookmark,
      updatedAt: Date.now()
    });

    if (targetMsgId) {
      setLocalMessages(prev => prev.map(m => {
        if (m.id === targetMsgId) {
          return {
            ...m,
            metadata: {
              ...m.metadata,
              lectureBookmark: bookmark
            }
          };
        }
        return m;
      }));
    }

    showNotification?.(`🔖 Lecture bookmark saved at ${timeLabel} (${reason})`, "info");
    return bookmark;
  };

  const restoreLectureBookmark = (bookmarkToRestore?: LectureBookmark | null) => {
    const bm = bookmarkToRestore || activeLectureBookmark || (() => {
      try {
        const saved = localStorage.getItem('omni_lecture_bookmark');
        return saved ? JSON.parse(saved) : null;
      } catch { return null; }
    })();

    if (!bm) {
      showNotification?.("No saved lecture bookmark found to restore.", "info");
      return;
    }

    const targetMsg = messages.find(m => m.id === bm.messageId) || [...messages].reverse().find(m => m.sender === 'ai');
    if (!targetMsg) {
      showNotification?.("Lecture content for bookmark no longer available.", "warning");
      return;
    }

    if (bm.lectureSubMode && bm.lectureSubMode !== lectureSubMode) {
      setLectureSubMode(bm.lectureSubMode);
      localStorage.setItem('omni_lecture_sub_mode', bm.lectureSubMode);
    }
    if (bm.professorStyle && setLectureProfessorStyle) {
      setLectureProfessorStyle(bm.professorStyle);
      localStorage.setItem('omni_lecture_professor_style', bm.professorStyle);
    }

    setSpeakingWordIndex(bm.wordIndex || 0);
    showNotification?.(`🔖 Restored lecture bookmark at ${bm.timeLabel} (${bm.reason})`, "success");

    setTimeout(async () => {
      const cleanText = cleanTextForNaturalSpeech(targetMsg.content, pronunciationPrecision);
      const { wordsList } = computeUnifiedSyncWeights(cleanText);
      const approxDurationSec = wordsList.length * 0.35;
      const approxOffsetMs = bm.timestampMs > 0 
        ? bm.timestampMs 
        : (bm.wordIndex / Math.max(1, wordsList.length)) * (approxDurationSec * 1000);

      await handleSpeakText(targetMsg.id, targetMsg.content, approxOffsetMs);
    }, 400);
  };

  const handleResumeInterruptedLecture = () => {
    if (interruptedLectureMsgIdRef.current) {
      const resumeMsgId = interruptedLectureMsgIdRef.current;
      const resumeWordIdx = interruptedWordIndexRef.current;
      interruptedLectureMsgIdRef.current = null;
      interruptedWordIndexRef.current = 0;
      
      const resumeMsg = messages.find(m => m.id === resumeMsgId);
      if (resumeMsg) {
        showNotification?.("Crash doubt clarified! Resuming original lecture from where we left off... 🎓", "success");
        setTimeout(async () => {
          setSpeakingWordIndex(resumeWordIdx);
          const cleanTextForWords = cleanTextForNaturalSpeech(resumeMsg.content, pronunciationPrecision);
          const { wordsList } = computeUnifiedSyncWeights(cleanTextForWords);
          const approxDurationSec = wordsList.length * 0.35;
          const approxOffsetMs = (resumeWordIdx / Math.max(1, wordsList.length)) * (approxDurationSec * 1000);
          await handleSpeakText(resumeMsgId, resumeMsg.content, approxOffsetMs);
        }, 600);
      }
    }
  };

  useEffect(() => {
    isMicMutedRef.current = isMicMuted;
  }, [isMicMuted]);

  useEffect(() => {
    if (audioSourceRef.current && isSpeaking) {
      try {
        const activeRate = (isLectureMode && lectureSubMode === 'lecture') ? ttsRate * 0.92 : ttsRate;
        audioSourceRef.current.playbackRate.value = activeRate;
      } catch (e) {}
    }
  }, [ttsRate, isLectureMode, lectureSubMode, isSpeaking]);

  useEffect(() => {
    micSensitivityRef.current = micSensitivity;
  }, [micSensitivity]);

  useEffect(() => {
    isSilenceDetectionEnabledRef.current = isSilenceDetectionEnabled;
  }, [isSilenceDetectionEnabled]);

  useEffect(() => {
    silenceDurationRef.current = silenceDuration;
  }, [silenceDuration]);

  useEffect(() => {
    if (prevIsRecordingRef.current && !isRecording) {
      if (inputRef.current.trim().length > 0) {
        setJustFinishedVoice(true);
      }
    }
    if (isRecording) {
      lastActiveSpeechTimeRef.current = Date.now();
    }
    prevIsRecordingRef.current = isRecording;
  }, [isRecording]);

  // Load available microphone devices
  useEffect(() => {
    const loadAudioDevices = async () => {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
          const devices = await navigator.mediaDevices.enumerateDevices();
          const inputs = devices.filter(d => d.kind === 'audioinput');
          setAudioDevices(inputs);
          if (inputs.length > 0 && !selectedAudioDeviceId) {
            setSelectedAudioDeviceId(inputs[0].deviceId);
          }
        }
      } catch (err) {
        console.warn('Failed to enumerate audio devices', err);
      }
    };

    loadAudioDevices();
    if (navigator.mediaDevices && navigator.mediaDevices.addEventListener) {
      const handleDeviceChange = () => loadAudioDevices();
      navigator.mediaDevices.addEventListener('devicechange', handleDeviceChange);
      return () => {
        navigator.mediaDevices.removeEventListener('devicechange', handleDeviceChange);
      };
    }
  }, []);

  useEffect(() => {
    if (!isRecording) {
      setMicVolume(0);
      setRecordingDuration(0);
      return;
    }

    let stream: MediaStream | null = null;
    let audioCtx: AudioContext | null = null;
    let animFrame: number;
    lastActiveSpeechTimeRef.current = Date.now();

    const startMicVolumeAnalyzer = async () => {
      try {
        const audioConstraints: MediaTrackConstraints | boolean = selectedAudioDeviceId
          ? { deviceId: { exact: selectedAudioDeviceId } }
          : true;
        stream = await navigator.mediaDevices.getUserMedia({ audio: audioConstraints });
        audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 128;
        analyser.smoothingTimeConstant = 0.5;
        source.connect(analyser);

        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);

        const updateVolume = () => {
          if (isMicMutedRef.current) {
            setMicVolume(0);
          } else {
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < bufferLength; i++) {
              sum += dataArray[i];
            }
            const avg = sum / bufferLength;
            const norm = Math.min(1, avg / 120);
            setMicVolume(norm);

            if ((norm * 100) >= micSensitivityRef.current) {
              lastActiveSpeechTimeRef.current = Date.now();
            }
          }
          animFrame = requestAnimationFrame(updateVolume);
        };

        updateVolume();
      } catch (err: any) {
        console.log("Mic frequency analyzer notice:", err?.message || err);
        if (err?.name === 'NotAllowedError' || err?.message?.includes('Permission denied')) {
          showNotification?.("Microphone permission was denied by the browser. Click the lock/camera icon in your address bar to grant permission.", "error");
        }
      }
    };

    startMicVolumeAnalyzer();

    const durationInterval = setInterval(() => {
      setRecordingDuration(prev => prev + 1);

      // Silence detection check
      if (
        isSilenceDetectionEnabledRef.current &&
        !isMicMutedRef.current &&
        Date.now() - lastActiveSpeechTimeRef.current > silenceDurationRef.current * 1000
      ) {
        if (isRecordingRef.current) {
          onToggleVoice();
          showNotification?.(`Silence detected (${silenceDurationRef.current}s). Voice recording stopped automatically.`, 'info');
        }
      }
    }, 1000);

    return () => {
      clearInterval(durationInterval);
      if (animFrame) cancelAnimationFrame(animFrame);
      if (stream) stream.getTracks().forEach(t => t.stop());
      if (audioCtx) audioCtx.close().catch(() => {});
    };
  }, [isRecording, selectedAudioDeviceId]);

  const formatRecordingTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleMicPressStart = () => {
    if (isShared) return;
    isMouseDownRef.current = true;
    isLongPressActiveRef.current = false;

    longPressTimerRef.current = setTimeout(() => {
      if (isMouseDownRef.current) {
        isLongPressActiveRef.current = true;
        setVoiceMode(prev => {
          const nextMode = prev === 'continuous' ? 'pushtotalk' : 'continuous';
          showNotification?.(
            nextMode === 'pushtotalk' 
              ? 'Switched to Push-to-Talk mode! (Hold mic button to speak)' 
              : 'Switched to Continuous Listening mode!', 
            'info'
          );
          return nextMode;
        });
      }
    }, 500);

    if (voiceMode === 'pushtotalk' && !isRecording) {
      onToggleVoice();
    }
  };

  const handleMicPressEnd = () => {
    if (isShared) return;
    isMouseDownRef.current = false;
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }

    if (voiceMode === 'pushtotalk' && isRecording) {
      onToggleVoice();
    }
  };

  const handleMicClick = () => {
    if (isShared) return;
    if (isLongPressActiveRef.current) {
      isLongPressActiveRef.current = false;
      return;
    }

    if (voiceMode === 'continuous') {
      onToggleVoice();
    } else {
      if (!isRecording) {
        showNotification?.('Push-to-Talk active: Hold the mic button to speak', 'info');
      }
    }
  };

  // Global Mute All listener
  useEffect(() => {
    const handleGlobalStop = () => {
      stopSpeaking();
      showNotification?.("All audio playback stopped globally.", "info");
    };
    window.addEventListener('omni-audio-stop', handleGlobalStop);
    return () => window.removeEventListener('omni-audio-stop', handleGlobalStop);
  }, []);
  const speakingIntervalRef = useRef<any>(null);
  const clearSpeechTimer = () => {
    if (speakingIntervalRef.current) {
      clearInterval(speakingIntervalRef.current);
      cancelAnimationFrame(speakingIntervalRef.current);
      speakingIntervalRef.current = null;
    }
  };
  const elapsedMsRef = useRef(0);
  const [ttsVolume, setTtsVolume] = useState(() => {
    const saved = localStorage.getItem('omni_tts_volume');
    return saved !== null ? parseFloat(saved) : 1.0;
  });
  const gainNodeRef = useRef<GainNode | null>(null);
  const lastSpokenTextRef = useRef<string | null>(null);
  const lastSpokenMsgIdRef = useRef<string | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);
  
  // Classroom scroll control settings
  const [isVoiceTrackingEnabled, setIsVoiceTrackingEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_classroom_voice_tracking');
    return saved === null ? true : saved === 'true';
  });

  const [synergyMode, setSynergyMode] = useState<'academic' | 'classroom' | 'review' | 'custom'>(() => {
    const saved = localStorage.getItem('omni_classroom_synergy_mode');
    return (saved as 'academic' | 'classroom' | 'review' | 'custom') || 'classroom';
  });

  const applySynergyPreset = (mode: 'academic' | 'classroom' | 'review') => {
    setSynergyMode(mode);
    localStorage.setItem('omni_classroom_synergy_mode', mode);

    if (mode === 'academic') {
      setTtsRate?.(0.75);
      localStorage.setItem('omni_tts_rate', '0.75');
      setTypingPace?.('deliberate');
      localStorage.setItem('omni_typing_pace', 'deliberate');
      
      setScrollDuration(800);
      localStorage.setItem('omni_classroom_scroll_duration', '800');
      setScrollEasing('ease-in-out');
      localStorage.setItem('omni_classroom_scroll_easing', 'ease-in-out');
      setScrollThreshold(0.5);
      localStorage.setItem('omni_classroom_scroll_threshold', '0.5');
      setScrollTargetCenter(0.25);
      localStorage.setItem('omni_classroom_scroll_target_center', '0.25');
      
      setIsAdaptiveSpeedEnabled(true);
      localStorage.setItem('omni_classroom_adaptive_speed', 'true');
      setIsBreathingPausesEnabled(true);
      localStorage.setItem('omni_classroom_breathing_pauses', 'true');
      setIsSpotlightEnabled(true);
      localStorage.setItem('omni_classroom_spotlight', 'true');
    } else if (mode === 'classroom') {
      setTtsRate?.(1.0);
      localStorage.setItem('omni_tts_rate', '1.0');
      setTypingPace?.('fluent');
      localStorage.setItem('omni_typing_pace', 'fluent');
      
      setScrollDuration(450);
      localStorage.setItem('omni_classroom_scroll_duration', '450');
      setScrollEasing('ease-out');
      localStorage.setItem('omni_classroom_scroll_easing', 'ease-out');
      setScrollThreshold(0.66);
      localStorage.setItem('omni_classroom_scroll_threshold', '0.66');
      setScrollTargetCenter(0.45);
      localStorage.setItem('omni_classroom_scroll_target_center', '0.45');
      
      setIsAdaptiveSpeedEnabled(false);
      localStorage.setItem('omni_classroom_adaptive_speed', 'false');
      setIsBreathingPausesEnabled(true);
      localStorage.setItem('omni_classroom_breathing_pauses', 'true');
      setIsSpotlightEnabled(false);
      localStorage.setItem('omni_classroom_spotlight', 'false');
    } else if (mode === 'review') {
      setTtsRate?.(1.5);
      localStorage.setItem('omni_tts_rate', '1.5');
      setTypingPace?.('swift');
      localStorage.setItem('omni_typing_pace', 'swift');
      
      setScrollDuration(200);
      localStorage.setItem('omni_classroom_scroll_duration', '200');
      setScrollEasing('spring');
      localStorage.setItem('omni_classroom_scroll_easing', 'spring');
      setScrollThreshold(0.75);
      localStorage.setItem('omni_classroom_scroll_threshold', '0.75');
      setScrollTargetCenter(0.60);
      localStorage.setItem('omni_classroom_scroll_target_center', '0.60');
      
      setIsAdaptiveSpeedEnabled(false);
      localStorage.setItem('omni_classroom_adaptive_speed', 'false');
      setIsBreathingPausesEnabled(false);
      localStorage.setItem('omni_classroom_breathing_pauses', 'false');
      setIsSpotlightEnabled(false);
      localStorage.setItem('omni_classroom_spotlight', 'false');
    }
  };

  const setCustomMode = () => {
    setSynergyMode('custom');
    localStorage.setItem('omni_classroom_synergy_mode', 'custom');
  };

  const [scrollDuration, setScrollDuration] = useState<number>(() => {
    const saved = localStorage.getItem('omni_classroom_scroll_duration');
    return saved !== null ? parseInt(saved) : 450;
  });

  const [scrollEasing, setScrollEasing] = useState<'smooth' | 'ease-in-out' | 'ease-out' | 'spring' | 'instant'>(() => {
    const saved = localStorage.getItem('omni_classroom_scroll_easing');
    return (saved as 'smooth' | 'ease-in-out' | 'ease-out' | 'spring' | 'instant') || 'ease-out';
  });

  const [scrollThreshold, setScrollThreshold] = useState<number>(() => {
    const saved = localStorage.getItem('omni_classroom_scroll_threshold');
    return saved !== null ? parseFloat(saved) : 0.66;
  });

  const [scrollTargetCenter, setScrollTargetCenter] = useState<number>(() => {
    const saved = localStorage.getItem('omni_classroom_scroll_target_center');
    return saved !== null ? parseFloat(saved) : 0.45;
  });

  const [isAdaptiveSpeedEnabled, setIsAdaptiveSpeedEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_classroom_adaptive_speed');
    return saved === 'true';
  });

  const [isBreathingPausesEnabled, setIsBreathingPausesEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_classroom_breathing_pauses');
    return saved === null ? true : saved === 'true';
  });

  const [isSpotlightEnabled, setIsSpotlightEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_classroom_spotlight');
    return saved === 'true';
  });
  
  // TTS 10 Features States & Cache
  const [activeFeaturesMenuId, setActiveFeaturesMenuId] = useState<string | null>(null);
  const [activeTogglesMenuId, setActiveTogglesMenuId] = useState<string | null>(null);
  const [activeDualEngineMenuId, setActiveDualEngineMenuId] = useState<string | null>(null);
  const [ttsEngineMode, setTtsEngineMode] = useState<'tts' | 'webspeech' | 'auto' | 'google'>(() => {
    const saved = localStorage.getItem('omni_tts_engine_mode');
    return (saved as 'tts' | 'webspeech' | 'auto' | 'google') || 'tts';
  });
  const [isWordHighlightingEnabled, setIsWordHighlightingEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_is_word_highlighting_enabled');
    return saved === null ? true : saved === 'true';
  });
  const [isWaveformVisualizerEnabled, setIsWaveformVisualizerEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_is_waveform_enabled');
    return saved === null ? true : saved === 'true';
  });
  const audioCacheRef = useRef<Map<string, AudioBuffer>>(new Map());
  
  // Classroom Mode Interactive Quiz States
  const [messageQuizzes, setMessageQuizzes] = useState<Record<string, any>>({});
  const [loadingQuizMessageId, setLoadingQuizMessageId] = useState<string | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number[]>>({});
  const [showQuizExplanations, setShowQuizExplanations] = useState<Record<string, boolean[]>>({});
  const [localTranslations, setLocalTranslations] = useState<Record<string, string>>({});
  const [translatingIds, setTranslatingIds] = useState<Set<string>>(new Set());
  const [showMagicMenu, setShowMagicMenu] = useState(false);
  const [showFeaturesMenu, setShowFeaturesMenu] = useState(false);
  const [showPersonaMenu, setShowPersonaMenu] = useState(false);
  const [activeLangMenuMessageId, setActiveLangMenuMessageId] = useState<string | null>(null);
  const [activeSpeedMenuMessageId, setActiveSpeedMenuMessageId] = useState<string | null>(null);
  const [activeMoreMenuMessageId, setActiveMoreMenuMessageId] = useState<string | null>(null);
  const [magicType, setMagicType] = useState<'image' | 'video' | null>(null);
  const [pinnedMessageIds, setPinnedMessageIds] = useState<Set<string>>(new Set());
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  
  // Contextual Diagram Anchor, Pinned Diagram, and Venn Diagram Builder states
  const [diagramAnchorPositions, setDiagramAnchorPositions] = useState<Record<string, 'top' | 'middle' | 'bottom'>>({});
  const [pinnedDiagram, setPinnedDiagram] = useState<{
    msgId: string;
    image: string;
    annotations?: any[];
    topic?: string;
    title?: string;
  } | null>(null);
  const [isPinnedDiagramMinimized, setIsPinnedDiagramMinimized] = useState(false);
  const [isVennBuilderOpen, setIsVennBuilderOpen] = useState(false);
  
  // Dynamic Diagram Container Resizing state & handler
  const [diagramSizes, setDiagramSizes] = useState<Record<string, { width?: number; height?: number }>>({});
  const [resizingDiagramId, setResizingDiagramId] = useState<string | null>(null);
  
  // Auto-Contrast Diagram Readability filter state
  const [autoContrastDiagramIds, setAutoContrastDiagramIds] = useState<Set<string>>(new Set());
  // Chalk Invert Diagram Dark Blackboard Filter state
  const [chalkInvertDiagramIds, setChalkInvertDiagramIds] = useState<Set<string>>(new Set());

  // Virtual Lesson Environment Initialization & Auditory Feedback states
  const [initializingLessonMessageId, setInitializingLessonMessageId] = useState<string | null>(null);
  const [isLessonInitializing, setIsLessonInitializing] = useState<boolean>(false);

  // Classroom Mode Blackboard Erasing & Smooth Wipe Transition States
  const [eraserStyle, setEraserStyle] = useState<BlackboardEraserStyle>(() => {
    return (localStorage.getItem('omni_eraser_style') as BlackboardEraserStyle) || 'classic-felt';
  });
  const [eraserSpeed, setEraserSpeed] = useState<BlackboardEraserSpeed>(() => {
    return (localStorage.getItem('omni_eraser_speed') as BlackboardEraserSpeed) || 'normal';
  });
  const [eraserDustDensity, setEraserDustDensity] = useState<BlackboardDustDensity>(() => {
    return (localStorage.getItem('omni_eraser_dust_density') as BlackboardDustDensity) || 'medium';
  });

  const [boardWipeHistory, setBoardWipeHistory] = useState<BlackboardWipeEvent[]>(() => {
    try {
      const saved = localStorage.getItem(`omni_board_wipe_history_${subject || 'general'}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [activeBoardHistoryIndex, setActiveBoardHistoryIndex] = useState<number | null>(null);
  const [isBoardHistoryOpen, setIsBoardHistoryOpen] = useState<boolean>(false);

  // Chalk Color Palette, Professor Narrator, & Zoom to Focus States
  const [activeChalkColor, setActiveChalkColor] = useState<ChalkColor>(() => {
    return (localStorage.getItem('omni_active_chalk_color') as ChalkColor) || 'white';
  });
  const [isProfessorNarrator, setIsProfessorNarrator] = useState<boolean>(() => {
    return localStorage.getItem('omni_professor_narrator') === 'true';
  });
  const [isZoomToFocusEnabled, setIsZoomToFocusEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_zoom_to_focus_enabled');
    return saved === null ? true : saved === 'true';
  });
  const [activeZoomFocusState, setActiveZoomFocusState] = useState<BlackboardZoomFocusState | null>(null);

  useEffect(() => {
    const handleSyncChalkSettings = () => {
      const savedColor = localStorage.getItem('omni_active_chalk_color') as ChalkColor;
      if (savedColor) setActiveChalkColor(savedColor);
      const savedNarrator = localStorage.getItem('omni_professor_narrator') === 'true';
      setIsProfessorNarrator(savedNarrator);
      const savedZoom = localStorage.getItem('omni_zoom_to_focus_enabled');
      if (savedZoom !== null) setIsZoomToFocusEnabled(savedZoom === 'true');
    };
    window.addEventListener('omni_chalk_settings_changed', handleSyncChalkSettings);
    window.addEventListener('storage', handleSyncChalkSettings);
    return () => {
      window.removeEventListener('omni_chalk_settings_changed', handleSyncChalkSettings);
      window.removeEventListener('storage', handleSyncChalkSettings);
    };
  }, []);

  useEffect(() => {
    const handleSyncEraserSettings = () => {
      const savedStyle = localStorage.getItem('omni_eraser_style') as BlackboardEraserStyle;
      if (savedStyle) setEraserStyle(savedStyle);
      const savedSpeed = localStorage.getItem('omni_eraser_speed') as BlackboardEraserSpeed;
      if (savedSpeed) setEraserSpeed(savedSpeed);
      const savedDust = localStorage.getItem('omni_eraser_dust_density') as BlackboardDustDensity;
      if (savedDust) setEraserDustDensity(savedDust);
    };
    window.addEventListener('omni_eraser_settings_changed', handleSyncEraserSettings);
    window.addEventListener('storage', handleSyncEraserSettings);
    return () => {
      window.removeEventListener('omni_eraser_settings_changed', handleSyncEraserSettings);
      window.removeEventListener('storage', handleSyncEraserSettings);
    };
  }, []);

  const [erasingBlackboardId, setErasingBlackboardId] = useState<string | null>(null);
  const [erasedBlackboardMessageIds, setErasedBlackboardMessageIds] = useState<Set<string>>(new Set());
  const [isErasingVideoBoard, setIsErasingVideoBoard] = useState<boolean>(false);
  const [isVideoBoardErased, setIsVideoBoardErased] = useState<boolean>(false);

  const getWipeDurationMs = (speed: BlackboardEraserSpeed) => {
    return speed === 'fast' ? 700 : speed === 'slow' ? 2000 : 1200;
  };

  const handleClearBlackboard = (msgId: string) => {
    if (erasingBlackboardId === msgId) return;
    
    // Find target message content for Board History snapshot
    const targetMsg = messages.find(m => m.id === msgId);
    const content = targetMsg ? (localTranslations[msgId] || targetMsg.content) : '';
    const cleanTopic = targetMsg?.metadata?.topic || subject || 'Conceptual Derivation';
    
    // Extract first representative formula or line for preview
    const lines = content.split('\n').filter(l => l.trim().length > 0);
    const firstFormula = lines.find(l => l.includes('$') || l.includes('∇') || l.includes('=')) || lines[0] || 'Blackboard Derivation';
    const summary = firstFormula.replace(/[#*`]/g, '').slice(0, 120);

    const wipeEvent: BlackboardWipeEvent = {
      id: `wipe-${Date.now()}`,
      messageId: msgId,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timestampMs: Date.now(),
      topic: cleanTopic,
      summary: summary,
      fullContent: content,
      image: targetMsg?.metadata?.image || (extractSvgCode(content) || undefined),
      eraserStyle: eraserStyle,
      stepNumber: boardWipeHistory.length + 1
    };

    const nextHistory = [...boardWipeHistory, wipeEvent];
    setBoardWipeHistory(nextHistory);
    try {
      localStorage.setItem(`omni_board_wipe_history_${subject || 'general'}`, JSON.stringify(nextHistory.slice(-25)));
    } catch (e) {
      console.warn("Could not save board wipe history:", e);
    }

    // Play authentic chalkboard eraser sound FX matched to chosen eraser style
    if (eraserStyle === 'sponge-wipe') {
      playChalkSound('dust', 0.4);
      setTimeout(() => playChalkSound('scratch', 0.2), 150);
      setTimeout(() => playChalkSound('tap', 0.3), 500);
    } else if (eraserStyle === 'dry-cloth') {
      playChalkSound('dust', 0.5);
      setTimeout(() => playChalkSound('scratch', 0.25), 250);
      setTimeout(() => playChalkSound('dust', 0.4), 600);
    } else {
      // Classic Felt
      playChalkSound('dust', 0.65);
      setTimeout(() => playChalkSound('scratch', 0.35), 200);
      setTimeout(() => playChalkSound('dust', 0.55), 500);
      setTimeout(() => playChalkSound('tap', 0.4), 900);
    }
    
    setErasingBlackboardId(msgId);
    const duration = getWipeDurationMs(eraserSpeed);
    
    setTimeout(() => {
      setErasingBlackboardId(null);
      setErasedBlackboardMessageIds(prev => new Set(prev).add(msgId));
      setActiveBoardHistoryIndex(null);
      const styleName = eraserStyle === 'sponge-wipe' ? 'Sponge Wipe' : eraserStyle === 'dry-cloth' ? 'Dry Cloth Wipe' : 'Classic Felt Eraser';
      showNotification?.(`Blackboard wiped clean with ${styleName}. Recorded to Board History! 🎓`, "success");
    }, duration);
  };

  const handleUndoErasure = (msgId: string) => {
    playChalkSound('tap', 0.45);
    setTimeout(() => playChalkSound('scratch', 0.3), 150);
    setErasedBlackboardMessageIds(prev => {
      const next = new Set(prev);
      next.delete(msgId);
      return next;
    });
    setActiveBoardHistoryIndex(null);
    showNotification?.("Derivations restored! Blackboard state recovered. 📝", "info");
  };

  const handleRestoreBlackboard = handleUndoErasure;

  const handleRestoreWipeEvent = (wipe: BlackboardWipeEvent) => {
    playChalkSound('tap', 0.4);
    setTimeout(() => playChalkSound('scratch', 0.3), 150);
    setErasedBlackboardMessageIds(prev => {
      const next = new Set(prev);
      next.delete(wipe.messageId);
      return next;
    });
    setActiveBoardHistoryIndex(null);
    showNotification?.(`Restored blackboard state from Wipe #${wipe.stepNumber} (${wipe.topic})! 📝`, "success");
  };

  const handleClearVideoBlackboard = () => {
    if (isErasingVideoBoard) return;
    playChalkSound('dust', 0.6);
    setTimeout(() => playChalkSound('scratch', 0.3), 200);
    setTimeout(() => playChalkSound('dust', 0.5), 500);
    setTimeout(() => playChalkSound('tap', 0.35), 900);
    setIsErasingVideoBoard(true);
    const duration = getWipeDurationMs(eraserSpeed);
    setTimeout(() => {
      setIsErasingVideoBoard(false);
      setIsVideoBoardErased(true);
      showNotification?.("Lecture board wiped clean. Ready for follow-up sub-topic! 🎓", "success");
    }, duration);
  };

  const handleRestoreVideoBlackboard = () => {
    playChalkSound('tap', 0.4);
    setIsVideoBoardErased(false);
    showNotification?.("Restored lecture board diagrams and derivations! 📝", "info");
  };

  /**
   * Initiates the Virtual Lesson Environment with acoustic feedback cue and visual pulse initialization animation.
   */
  const handleInitiateVirtualLesson = (msg: Message, forceVideoClassroom: boolean = false) => {
    // 1. Play crystal-clear ascending harmonic auditory feedback cue
    playLessonInitializingCue(0.35);

    // 2. Set visual pulse animation states
    setInitializingLessonMessageId(msg.id);
    setIsLessonInitializing(true);
    showNotification?.("Initializing Virtual Lesson Environment... 🎓", "info");

    // 3. Complete initialization sequence
    setTimeout(() => {
      if (forceVideoClassroom || lectureSubMode === 'video_classroom') {
        setActiveLessonVideo(msg);
        setVideoPlayStatus('writing');
        setVideoDrawingProgress(100);
        stopSpeaking();
        const timing = calculateBoardworkTiming(msg.content, {
          ttsRate,
          typingPace,
          blackboardWritingSpeed,
          isAdaptiveSpeedEnabled,
          isBreathingPausesEnabled
        });
        handleSpeakText(msg.id, msg.content, 0, true, timing.calculatedPlaybackRate);
        showNotification?.("Virtual Lesson Environment active 🎓", "success");
      } else {
        setReadyMessages(prev => new Set(prev).add(msg.id));
        stopSpeaking();
        handleSpeakText(msg.id, msg.content, 0, true);
        showNotification?.("Starting classroom blackboard lecture 🎓", "success");
      }
      setIsLessonInitializing(false);
      setInitializingLessonMessageId(null);
    }, 600);
  };

  const toggleChalkInvert = (msgId: string) => {
    setChalkInvertDiagramIds(prev => {
      const next = new Set(prev);
      if (next.has(msgId)) {
        next.delete(msgId);
        showNotification?.('Standard View restored', 'info');
      } else {
        next.add(msgId);
        showNotification?.('Dark Blackboard Chalk Invert Mode activated! 🖤', 'success');
      }
      return next;
    });
  };

  const toggleAutoContrast = (msgId: string) => {
    setAutoContrastDiagramIds(prev => {
      const next = new Set(prev);
      if (next.has(msgId)) {
        next.delete(msgId);
        showNotification?.('Auto-Contrast disabled', 'info');
      } else {
        next.add(msgId);
        showNotification?.('Auto-Contrast enabled for enhanced text readability!', 'success');
      }
      return next;
    });
  };

  const handleResizeStart = (e: React.MouseEvent | React.TouchEvent, msgId: string) => {
    e.stopPropagation();
    e.preventDefault();
    const container = document.getElementById(`diagram-image-${msgId}`);
    if (!container) return;

    const startX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const startY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const startWidth = container.getBoundingClientRect().width;
    const startHeight = container.getBoundingClientRect().height;

    setResizingDiagramId(msgId);

    const handlePointerMove = (moveEvent: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in moveEvent ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const clientY = 'touches' in moveEvent ? moveEvent.touches[0].clientY : moveEvent.clientY;

      const deltaX = clientX - startX;
      const deltaY = clientY - startY;

      const newWidth = Math.max(220, Math.min(850, startWidth + deltaX));
      const newHeight = Math.max(140, Math.min(650, startHeight + deltaY));

      setDiagramSizes(prev => ({
        ...prev,
        [msgId]: { width: Math.round(newWidth), height: Math.round(newHeight) }
      }));
    };

    const handlePointerUp = () => {
      setResizingDiagramId(null);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
    };

    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    window.addEventListener('touchmove', handlePointerMove);
    window.addEventListener('touchend', handlePointerUp);
  };

  // Persistent Draggable Diagram Notes & Annotate Figure Tool State & Handlers
  const [diagramNotes, setDiagramNotes] = useState<Record<string, DiagramNote[]>>({});
  const [editingNoteKey, setEditingNoteKey] = useState<string | null>(null);
  const [draggingNoteKey, setDraggingNoteKey] = useState<string | null>(null);

  // Annotate Figure Overlay Tool State
  const [annotatingDiagramMsgId, setAnnotatingDiagramMsgId] = useState<string | null>(null);
  const [pendingAnnotationHotspot, setPendingAnnotationHotspot] = useState<{
    msgId: string;
    x: number;
    y: number;
  } | null>(null);
  const [annotationNoteInput, setAnnotationNoteInput] = useState<string>('');
  const [annotationTitleInput, setAnnotationTitleInput] = useState<string>('');
  const [annotationCategoryInput, setAnnotationCategoryInput] = useState<'question' | 'note' | 'concept' | 'formula' | 'exam'>('question');

  const handleImageClickForAnnotation = (e: React.MouseEvent<HTMLDivElement>, msgId: string) => {
    if (repositioningAnno?.msgId === msgId || activeChalkboard === msgId || draggingNoteKey) return;

    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect.width || !rect.height) return;

    const x = Math.min(92, Math.max(5, Number((((e.clientX - rect.left) / rect.width) * 100).toFixed(1))));
    const y = Math.min(92, Math.max(5, Number((((e.clientY - rect.top) / rect.height) * 100).toFixed(1))));

    const existingCount = (diagramNotes[msgId]?.length || 0) + 1;

    setPendingAnnotationHotspot({ msgId, x, y });
    setAnnotationNoteInput('');
    setAnnotationTitleInput(`Hotspot #${existingCount}`);
    setAnnotationCategoryInput('question');
  };

  const handleSavePendingAnnotation = (askAiImmediately: boolean = false) => {
    if (!pendingAnnotationHotspot) return;
    const { msgId, x, y } = pendingAnnotationHotspot;
    const text = annotationNoteInput.trim() || "Question/Note tied to coordinate hotspot";
    const title = annotationTitleInput.trim() || "Hotspot Note";
    const type = annotationCategoryInput;

    const typeColorMap: Record<'question' | 'note' | 'concept' | 'formula' | 'exam', 'amber' | 'emerald' | 'cyan' | 'rose' | 'purple'> = {
      question: 'purple',
      note: 'amber',
      concept: 'emerald',
      formula: 'cyan',
      exam: 'rose'
    };

    const newNote: DiagramNote = {
      id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      x,
      y,
      text,
      title,
      type,
      color: typeColorMap[type],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setDiagramNotes(prev => ({
      ...prev,
      [msgId]: [...(prev[msgId] || []), newNote]
    }));

    showNotification?.(`Hotspot sticky note "${title}" attached at (${x}%, ${y}%)! 📌`, 'success');

    if (askAiImmediately) {
      const msg = localMessages.find(m => m.id === msgId);
      const topic = msg?.metadata?.topic || 'Visual Concept Figure';
      const aiPrompt = `Regarding coordinate hotspot "${title}" (${x}%, ${y}%) on figure '${topic}':\n\n"${text}"\n\nPlease answer this question or explain this concept in detail for my study session.`;
      onSendMessage(aiPrompt);
      showNotification?.("Asking AI Tutor about this figure hotspot...", "info");
    }

    setPendingAnnotationHotspot(null);
    setAnnotationNoteInput('');
    setAnnotationTitleInput('');
  };

  const handleAskAiAboutHotspot = (msgId: string, note: DiagramNote) => {
    const msg = localMessages.find(m => m.id === msgId);
    const topic = msg?.metadata?.topic || 'Visual Concept Figure';
    const aiPrompt = `Regarding hotspot "${note.title || 'Note'}" at coordinates (${note.x}%, ${note.y}%) on figure '${topic}':\n\n"${note.text}"\n\nPlease explain or answer this question in detail for me.`;
    onSendMessage(aiPrompt);
    showNotification?.(`Asking AI Tutor about hotspot "${note.title || 'Note'}"...`, "info");
  };

  const handleAddNoteToDiagram = (msgId: string) => {
    const noteId = `note-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const existingCount = diagramNotes[msgId]?.length || 0;
    const colors: Array<'amber' | 'emerald' | 'cyan' | 'rose' | 'purple'> = ['amber', 'emerald', 'cyan', 'rose', 'purple'];
    const newNote: DiagramNote = {
      id: noteId,
      x: Math.min(65, 12 + (existingCount * 14) % 55),
      y: Math.min(65, 12 + (existingCount * 18) % 55),
      text: "Study note: Double-click or tap to edit formula/comment...",
      color: colors[existingCount % colors.length]
    };

    setDiagramNotes(prev => ({
      ...prev,
      [msgId]: [...(prev[msgId] || []), newNote]
    }));
    setEditingNoteKey(`${msgId}-${noteId}`);
    showNotification?.('Study note added! Drag header to position over diagram.', 'success');
  };

  const handleNoteDragStart = (e: React.MouseEvent | React.TouchEvent, msgId: string, noteId: string) => {
    e.stopPropagation();
    const container = document.getElementById(`diagram-image-${msgId}`);
    if (!container) return;

    const rect = container.getBoundingClientRect();
    const noteKey = `${msgId}-${noteId}`;
    setDraggingNoteKey(noteKey);

    const startX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const startY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    const currentNote = (diagramNotes[msgId] || []).find(n => n.id === noteId);
    if (!currentNote) return;

    const initialXPercent = currentNote.x;
    const initialYPercent = currentNote.y;

    const handlePointerMove = (moveEvent: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in moveEvent ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const clientY = 'touches' in moveEvent ? moveEvent.touches[0].clientY : moveEvent.clientY;

      const deltaX = clientX - startX;
      const deltaY = clientY - startY;

      const deltaXPercent = (deltaX / rect.width) * 100;
      const deltaYPercent = (deltaY / rect.height) * 100;

      const newX = Math.max(0, Math.min(80, Number((initialXPercent + deltaXPercent).toFixed(1))));
      const newY = Math.max(0, Math.min(80, Number((initialYPercent + deltaYPercent).toFixed(1))));

      setDiagramNotes(prev => {
        const list = prev[msgId] || [];
        return {
          ...prev,
          [msgId]: list.map(n => n.id === noteId ? { ...n, x: newX, y: newY } : n)
        };
      });
    };

    const handlePointerUp = () => {
      setDraggingNoteKey(null);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
    };

    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    window.addEventListener('touchmove', handlePointerMove);
    window.addEventListener('touchend', handlePointerUp);
  };

  const handleDeleteNote = (msgId: string, noteId: string) => {
    setDiagramNotes(prev => ({
      ...prev,
      [msgId]: (prev[msgId] || []).filter(n => n.id !== noteId)
    }));
    showNotification?.('Study note removed', 'info');
  };

  // Export Diagram + Active Annotations + Study Notes to PDF
  const [exportingPdfId, setExportingPdfId] = useState<string | null>(null);

  const handleExportDiagramPDF = async (msg: Message) => {
    if (!msg.metadata?.image) return;
    setExportingPdfId(msg.id);
    showNotification?.('Generating annotated PDF study document...', 'info');

    try {
      const container = document.getElementById(`diagram-image-${msg.id}`);
      if (!container) {
        showNotification?.('Diagram element not found for export', 'error');
        setExportingPdfId(null);
        return;
      }

      const canvas = await html2canvas(container, {
        useCORS: true,
        allowTaint: true,
        scale: 2,
        backgroundColor: '#0f172a'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();

      pdf.setFillColor(15, 23, 42);
      pdf.rect(0, 0, pageWidth, pageHeight, 'F');

      pdf.setTextColor(248, 250, 252);
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(16);
      pdf.text('OmniAI Interactive Study Guide', 14, 18);

      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'normal');
      pdf.setTextColor(148, 163, 184);
      const topic = msg.metadata?.topic || 'Annotated Lesson Diagram';
      pdf.text(`Topic: ${topic} | Exported: ${new Date().toLocaleDateString()}`, 14, 25);

      pdf.setDrawColor(51, 65, 85);
      pdf.setLineWidth(0.5);
      pdf.line(14, 28, pageWidth - 14, 28);

      const margin = 14;
      const maxImgWidth = pageWidth - (margin * 2);
      const imgProps = pdf.getImageProperties(imgData);
      const imgHeight = (imgProps.height * maxImgWidth) / imgProps.width;

      pdf.addImage(imgData, 'PNG', margin, 32, maxImgWidth, imgHeight);

      let currentY = 32 + imgHeight + 10;

      const annotations = msg.metadata?.annotations || [];
      const notes = diagramNotes[msg.id] || [];

      if (annotations.length > 0 || notes.length > 0) {
        if (currentY + 30 > pageHeight - 15) {
          pdf.addPage();
          pdf.setFillColor(15, 23, 42);
          pdf.rect(0, 0, pageWidth, pageHeight, 'F');
          currentY = 20;
        }

        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(12);
        pdf.setTextColor(251, 191, 36);
        pdf.text('📌 Active Hotspots & Study Notes', margin, currentY);
        currentY += 6;

        pdf.setFontSize(9);
        pdf.setFont('helvetica', 'normal');

        annotations.forEach((anno: any, idx: number) => {
          if (currentY + 12 > pageHeight - 15) {
            pdf.addPage();
            pdf.setFillColor(15, 23, 42);
            pdf.rect(0, 0, pageWidth, pageHeight, 'F');
            currentY = 20;
          }
          pdf.setTextColor(56, 189, 248);
          pdf.setFont('helvetica', 'bold');
          pdf.text(`Hotspot ${idx + 1}: ${anno.label || 'Point'}`, margin + 2, currentY);
          currentY += 4;

          if (anno.explanation) {
            pdf.setTextColor(226, 232, 240);
            pdf.setFont('helvetica', 'normal');
            const lines = pdf.splitTextToSize(anno.explanation, maxImgWidth - 6);
            pdf.text(lines, margin + 4, currentY);
            currentY += (lines.length * 4) + 2;
          }
        });

        notes.forEach((note: DiagramNote, idx: number) => {
          if (currentY + 12 > pageHeight - 15) {
            pdf.addPage();
            pdf.setFillColor(15, 23, 42);
            pdf.rect(0, 0, pageWidth, pageHeight, 'F');
            currentY = 20;
          }
          pdf.setTextColor(245, 158, 11);
          pdf.setFont('helvetica', 'bold');
          pdf.text(`Study Note ${idx + 1}:`, margin + 2, currentY);
          currentY += 4;

          pdf.setTextColor(241, 245, 249);
          pdf.setFont('helvetica', 'normal');
          const lines = pdf.splitTextToSize(note.text || '(Empty Note)', maxImgWidth - 6);
          pdf.text(lines, margin + 4, currentY);
          currentY += (lines.length * 4) + 2;
        });
      }

      const safeFilename = `Annotated_Diagram_${topic.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.pdf`;
      pdf.save(safeFilename);
      showNotification?.('Annotated PDF study document exported successfully!', 'success');
    } catch (err) {
      console.error('Failed to export PDF:', err);
      showNotification?.('Failed to export diagram as PDF', 'error');
    } finally {
      setExportingPdfId(null);
    }
  };
  
  const [downloadingAudioIds, setDownloadingAudioIds] = useState<Set<string>>(new Set());

  const handleDownloadMessageAudio = async (msg: Message) => {
    setDownloadingAudioIds(prev => {
      const next = new Set(prev);
      next.add(msg.id);
      return next;
    });
    try {
      const persona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[1];
      const cleanText = (localTranslations[msg.id] || msg.content).replace(/[*#$]/g, '');
      
      let rawPcmBase64 = null;
      const isGoogle = ttsEngineMode === 'google';
      if (isGoogle) {
        rawPcmBase64 = await generateGoogleSpeech(cleanText, language || 'en');
      } else {
        rawPcmBase64 = await generateSpeech(cleanText, persona?.voiceName || 'Kore');
      }

      if (!rawPcmBase64) {
        throw new Error("Failed to generate speech");
      }
      
      let blob;
      if (isGoogle) {
        // Already a fully valid MP3 file
        const binary = atob(rawPcmBase64);
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        blob = new Blob([bytes], { type: 'audio/mp3' });
      } else {
        // Check if rawPcmBase64 is already a fully formed WAV file (starts with "UklGR" in base64)
        const hasHeader = rawPcmBase64.startsWith("UklGR");
        const wavBase64 = hasHeader ? rawPcmBase64 : convertPcmToWav(rawPcmBase64, 24000);
        const binary = atob(wavBase64);
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        blob = new Blob([bytes], { type: 'audio/wav' });
      }
      
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `omni_lesson_audio_${msg.id}.${isGoogle ? 'mp3' : 'wav'}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      showNotification?.("Lesson audio downloaded successfully! 🎵", "success");
    } catch (err) {
      console.error(err);
      showNotification?.("Could not download audio. Please try again.", "error");
    } finally {
      setDownloadingAudioIds(prev => {
        const next = new Set(prev);
        next.delete(msg.id);
        return next;
      });
    }
  };

  const handleDownloadMessageText = (msg: Message) => {
    const sender = msg.sender === 'user' ? 'Student' : 'Omni AI';
    let textContent = `Omni AI Academic Explanation\n`;
    textContent += `Sender: ${sender}\n`;
    textContent += `Date: ${new Date(msg.timestamp).toLocaleString()}\n`;
    textContent += `----------------------------------------\n\n`;
    textContent += localTranslations[msg.id] || msg.content;
    
    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `omni_lesson_text_${msg.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification?.("Lesson text downloaded! 📄", "success");
  };

  const handleDownloadFullChat = () => {
    if (messages.length === 0) {
      showNotification?.("Chat is empty! Nothing to download.", "warning");
      return;
    }
    
    let mdContent = `# Omni AI Study Session - Full Transcript\n`;
    mdContent += `Generated on: ${new Date().toLocaleString()}\n`;
    mdContent += `Subject: ${subject.toUpperCase()} | Topic: ${topic.toUpperCase()}\n\n`;
    mdContent += `---\n\n`;
    
    messages.forEach((msg, idx) => {
      const senderName = msg.sender === 'user' ? 'Student' : 'Omni AI';
      const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      mdContent += `### [${time}] **${senderName}**:\n${localTranslations[msg.id] || msg.content}\n\n`;
    });
    
    const blob = new Blob([mdContent], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `omni_study_session_${subject}_${topic}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification?.("Full chat transcript downloaded successfully! 📄", "success");
  };

  const handleShareFullChat = () => {
    if (messages.length === 0) {
      showNotification?.("Chat is empty! Nothing to share.", "warning");
      return;
    }
    
    let shareText = `📚 *Omni AI Study Session Transcript*\n`;
    shareText += `Subject: ${subject.toUpperCase()} | Topic: ${topic.toUpperCase()}\n\n`;
    
    messages.slice(-4).forEach((msg) => {
      const sender = msg.sender === 'user' ? 'Student' : 'Omni AI';
      const content = localTranslations[msg.id] || msg.content;
      shareText += `*${sender}*:\n${content.slice(0, 150)}${content.length > 150 ? '...' : ''}\n\n`;
    });
    
    const publicShareUrl = getSyncShareUrl();
    shareText += `Shared via Omni Study Platform. Link: ${publicShareUrl}`;
    
    if (navigator.share) {
      navigator.share({
        title: `Omni Study Session - ${subject}`,
        text: shareText,
        url: publicShareUrl
      }).catch(() => {
        navigator.clipboard.writeText(shareText);
        showNotification?.("Session transcript copied to clipboard! 🔗", "success");
      });
    } else {
      navigator.clipboard.writeText(shareText);
      showNotification?.("Session transcript copied to clipboard! 🔗", "success");
    }
  };

  const handleDownloadLessonPack = async (msg: Message) => {
    // Download text first
    handleDownloadMessageText(msg);
    // Then trigger audio generation and download
    await handleDownloadMessageAudio(msg);
  };
  
  const togglePin = (messageId: string) => {
    setPinnedMessageIds(prev => {
      const next = new Set(prev);
      if (next.has(messageId)) next.delete(messageId);
      else next.add(messageId);
      return next;
    });
  };

  const pinnedMessages = messages.filter(m => pinnedMessageIds.has(m.id));
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<any>(null);
  const prevMessagesLengthRef = useRef(messages.length);

  // Logical Break Pause Interruption Logic
  useEffect(() => {
    if (isInterruptPendingRef.current && isSpeakingRef.current && !isPausedRef.current && speakingMessageId) {
      const msg = messages.find(m => m.id === speakingMessageId);
      if (msg) {
        const cleanText = cleanTextForNaturalSpeech(msg.content, pronunciationPrecision);
        const words = cleanText.split(/\s+/).filter(Boolean).filter(w => w.replace(/[^\p{L}\p{N}]/gu, "").trim().length > 0);
        const currentWord = words[speakingWordIndex];
        
        // Logical break points: ., ?, !, \n, ;, etc.
        if (currentWord && (/[.?!;:\n]+$/.test(currentWord) || speakingWordIndex >= words.length - 1)) {
           isInterruptPendingRef.current = false;
           if (audioContextRef.current && audioContextRef.current.state === 'running') {
             audioContextRef.current.suspend();
           } else if (window.speechSynthesis) {
             window.speechSynthesis.pause();
           }
           setIsPaused(true);
           setIsInterrupted(true);
           showNotification?.(`TTS paused at a logical break point.`, 'info');
        }
      }
    }
  }, [speakingWordIndex, speakingMessageId, messages, showNotification]);

  useEffect(() => {
    isRecordingRef.current = isRecording;
  }, [isRecording]);

  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);

  useEffect(() => {
    isPausedRef.current = isPaused;
  }, [isPaused]);

  useEffect(() => {
    prevMessagesLengthRef.current = messages.length;
  }, [messages]);

  const handleCopyMessage = (msgId: string, content: string) => {
    navigator.clipboard.writeText(content)
      .then(() => {
        setCopiedMessageId(msgId);
        showNotification?.('Message copied to clipboard!', 'success');
        setTimeout(() => setCopiedMessageId(null), 2000);
      })
      .catch((err) => {
        console.error('Failed to copy text: ', err);
        showNotification?.('Failed to copy message.', 'error');
      });
  };

  const handlePrintMessage = (msg: Message) => {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);
    
    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (doc) {
      const title = "Omni AI Study Session - Explanation";
      const cleanContent = msg.content;
      
      doc.write(`
        <html>
          <head>
            <title>${title}</title>
            <style>
              body {
                font-family: system-ui, -apple-system, sans-serif;
                color: #0f172a;
                padding: 40px;
                line-height: 1.6;
                background: #ffffff;
              }
              .header {
                border-bottom: 2px solid #e2e8f0;
                padding-bottom: 16px;
                margin-bottom: 24px;
              }
              h1 {
                color: #4f46e5;
                font-size: 24px;
                margin: 0 0 8px 0;
                font-weight: 800;
              }
              .meta {
                font-size: 11px;
                color: #64748b;
                text-transform: uppercase;
                letter-spacing: 0.05em;
              }
              .content {
                font-size: 14px;
                color: #1e293b;
                white-space: pre-wrap;
              }
              .footer {
                margin-top: 60px;
                border-top: 1px solid #e2e8f0;
                padding-top: 16px;
                font-size: 10px;
                color: #94a3b8;
                text-align: center;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>Omni AI Academic Explanation</h1>
              <div class="meta">Generated by OMNI Tutor &bull; Date: ${new Date(msg.timestamp).toLocaleString()}</div>
            </div>
            
            <div class="content">${cleanContent}</div>
            
            <div class="footer">
              Generated by Omni AI Study Assistant &bull; Private Study Report
            </div>
            <script>
              window.onload = function() {
                window.print();
              };
            </script>
          </body>
        </html>
      `);
      doc.close();
      setTimeout(() => {
        document.body.removeChild(iframe);
      }, 1000);
    }
  };

  // Voice Commands implementation
  useEffect(() => {
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (isRecording) {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = language || 'en-US';

      rec.onresult = (event: any) => {
        if (isMicMutedRef.current) return;
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        const transcriptClean = (finalTranscript || interimTranscript).toLowerCase().trim();
        if (transcriptClean) {
          if (isSpeakingRef.current && !isPausedRef.current && !isInterruptPendingRef.current) {
            isInterruptPendingRef.current = true;
            
            // Analyze sentiment of interruption
            let sentiment = 'neutral';
            if (transcriptClean.match(/wait|what|huh|confused|slow|repeat|understand|clarify/)) {
              sentiment = 'confused';
            } else if (transcriptClean.match(/wow|awesome|cool|amazing|yes|got it|makes sense/)) {
              sentiment = 'excited';
            } else if (transcriptClean.match(/stop|no|hurry|fast|quick|urgent|move on/)) {
              sentiment = 'urgent';
            }
            
            setInterruptionSentiment(sentiment);
            showNotification?.(`Waiting for a logical break to pause TTS. Tone: ${sentiment.toUpperCase()}...`, 'info');
          }

          // Detect commands
          if (transcriptClean.includes('start quiz') || transcriptClean.includes('open quiz') || transcriptClean.includes('launch quiz')) {
            onOpenTool?.('quiz');
            onToggleVoice();
            return;
          }
          if (transcriptClean.includes('clear chat') || transcriptClean.includes('delete chat') || transcriptClean.includes('reset chat')) {
            onClearChat();
            onToggleVoice();
            return;
          }
          if (transcriptClean.includes('show notes') || transcriptClean.includes('saved notes') || transcriptClean.includes('open notes') || transcriptClean.includes('show note') || transcriptClean.includes('open note')) {
            onOpenTool?.('chapters', { tab: 'notes' });
            onToggleVoice();
            return;
          }

          if (finalTranscript) {
            setInput(prev => prev + (prev ? ' ' : '') + finalTranscript);
          }
          
          if (autoSendTimeoutRef.current) clearTimeout(autoSendTimeoutRef.current);
          autoSendTimeoutRef.current = setTimeout(() => {
            if (inputRef.current.trim() && isRecordingRef.current) {
              onToggleVoice(); // Stop recording
              handleSendRef.current(); // Send the message automatically
              showNotification?.('Voice input auto-sent.', 'info');
            }
          }, 2000);
        }
      };

      rec.onerror = (e: any) => {
        const errorType = e?.error || '';
        if (errorType === 'no-speech' || errorType === 'aborted') {
          return;
        }
        if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
          showNotification?.('Microphone permission denied. Please allow microphone access.', 'warning');
          if (isRecordingRef.current) {
            onToggleVoice();
          }
          return;
        }
        if (errorType === 'audio-capture') {
          showNotification?.('No microphone detected on your device.', 'warning');
          if (isRecordingRef.current) {
            onToggleVoice();
          }
          return;
        }
      };

      rec.onend = () => {
        if (isRecordingRef.current) {
          try {
            rec.start();
          } catch (err) {
            // ignore
          }
        }
      };

      recognitionRef.current = rec;
      try {
        rec.start();
      } catch (err) {
        console.error(err);
      }
    } else {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.onend = null;
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
        recognitionRef.current = null;
      }
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.onend = null;
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
      }
    };
  }, [isRecording, language]);

  // VAD Listener for TTS Interruption
  useEffect(() => {
    let stream: MediaStream | null = null;
    let audioContext: AudioContext | null = null;
    let analyser: AnalyserNode | null = null;
    let dataArray: Uint8Array | null = null;
    let animationFrame: number;
    let isListening = false;

    const startVAD = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
        audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const source = audioContext.createMediaStreamSource(stream);
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 512;
        analyser.smoothingTimeConstant = 0.5;
        source.connect(analyser);
        dataArray = new Uint8Array(analyser.frequencyBinCount);
        isListening = true;

        const checkVolume = () => {
          if (!isListening || !analyser || !dataArray) return;
          analyser.getByteFrequencyData(dataArray as any);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
          }
          const average = sum / dataArray.length;

          // Threshold for speech detection
          if (average > 25) {
            if (isSpeakingRef.current && !isPausedRef.current && !isInterruptPendingRef.current) {
               isInterruptPendingRef.current = true;
               
               setInterruptionSentiment('urgent');
               showNotification?.('Microphone input detected. Waiting for a logical break to pause TTS...', 'info');

               if (!isRecordingRef.current) {
                 onToggleVoice();
               }
               
               stopVAD();
               return;
            }
          }

          animationFrame = requestAnimationFrame(checkVolume);
        };
        
        checkVolume();
      } catch (err: any) {
        console.log("VAD microphone access info:", err?.message || err);
      }
    };

    const stopVAD = () => {
      isListening = false;
      if (animationFrame) cancelAnimationFrame(animationFrame);
      if (stream) stream.getTracks().forEach(track => track.stop());
      if (audioContext) {
        audioContext.close().catch(() => {});
      }
    };

    if (isSpeaking && !isPaused && !isRecording && isVadEnabled) {
      startVAD();
    }

    return () => {
      stopVAD();
    };
  }, [isSpeaking, isPaused, isRecording, isVadEnabled, onToggleVoice, showNotification]);

  const handleContainerScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const distanceFromBottom = container.scrollHeight - container.scrollTop - container.clientHeight;
    
    // If the user scrolls up by more than 120px while speaking or typing is active, pause auto scroll
    const isGenerating = (isSpeaking && !isPaused) || isTyping;
    if (isGenerating && distanceFromBottom > 120) {
      if (!isAutoScrollPaused) {
        setIsAutoScrollPaused(true);
      }
    } else if (distanceFromBottom < 40) {
      if (isAutoScrollPaused) {
        setIsAutoScrollPaused(false);
      }
    }
  };

  const handleResumeAutoScroll = () => {
    setIsAutoScrollPaused(false);
    if (mainScrollContainerRef.current) {
      const container = mainScrollContainerRef.current;
      container.scrollTo({
        top: container.scrollHeight,
        behavior: 'smooth'
      });
    } else {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
    }
    showNotification?.("Synchronized Auto-Scroll active!", "success");
  };

  const scrollToBottom = (instant: boolean = false) => {
    if (isAutoScrollPaused && !instant) return;
    
    const performScroll = () => {
      if (mainScrollContainerRef.current) {
        const container = mainScrollContainerRef.current;
        container.scrollTo({
          top: container.scrollHeight,
          behavior: instant ? 'auto' : 'smooth'
        });
      }
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({
          behavior: instant ? 'auto' : 'smooth',
          block: 'end'
        });
      }
    };

    if (instant) {
      performScroll();
    } else {
      requestAnimationFrame(() => {
        performScroll();
        // Follow-up frames to ensure late-rendering elements (KaTeX, SVG diagrams, images) stay pinned to bottom
        setTimeout(performScroll, 50);
        setTimeout(performScroll, 160);
      });
    }
  };

  const handleCopyFullChat = () => {
    const text = messages.map(m => `[${m.sender === 'user' ? 'Student' : 'Omni AI'}] ${m.content}`).join('\n\n');
    navigator.clipboard.writeText(text);
    showNotification?.("Full conversation copied to clipboard!", "success");
  };

  const handlePrintLastMsg = () => {
    const assistantMsgs = messages.filter(m => m.sender === 'ai');
    if (assistantMsgs.length > 0) {
      handlePrintMessage(assistantMsgs[assistantMsgs.length - 1]);
    } else {
      window.print();
    }
  };

  const lastMessageId = messages[messages.length - 1]?.id;

  useEffect(() => {
    // Whenever a new message is added by user or AI, unpause auto-scroll and perform smooth scroll animation
    if (messages.length > prevMessagesLengthRef.current) {
      setIsAutoScrollPaused(false);
    }
    prevMessagesLengthRef.current = messages.length;
    scrollToBottom(false);
  }, [messages.length, lastMessageId, isLectureMode, isTyping]);

  const handleSend = () => {
    if (isShared) return;
    if (input.trim()) {
      let finalMessage = input.trim();

      if (activeVerbalQuestion && activeVerbalQuestion.status === 'pending') {
        const wasCorrect = handleEvaluateVerbalLectureReply(input.trim());
        if (wasCorrect) {
          finalMessage = `[System Note: User answered the active lecture question ("${activeVerbalQuestion.questionText}") correctly via verbal reply: "${input.trim()}". State-based video content resumption triggered.]\n\n${finalMessage}`;
        }
      }
      
      if (interruptionSentiment && interruptionSentiment !== 'neutral') {
        let toneAdjustment = 'helpful and adaptive';
        if (interruptionSentiment === 'confused') toneAdjustment = 'highly patient, slower-paced, and clarifying';
        if (interruptionSentiment === 'excited') toneAdjustment = 'enthusiastic and encouraging';
        if (interruptionSentiment === 'urgent') toneAdjustment = 'concise, direct, and immediate';
        
        finalMessage = `[System Note: The user just interrupted you with a ${interruptionSentiment} tone. Please adapt your AI response tone to be ${toneAdjustment}.]\n\n${finalMessage}`;
      }
      
      if ((isInterrupted || isInterruptPendingRef.current) && speakingMessageId) {
        const msg = messages.find(m => m.id === speakingMessageId);
        if (msg) {
          const cleanText = cleanTextForNaturalSpeech(msg.content, pronunciationPrecision);
          const words = cleanText.split(/\s+/).filter(Boolean).filter(w => w.replace(/[^\p{L}\p{N}]/gu, "").trim().length > 0);
          const remainingText = words.slice(speakingWordIndex).join(' ');
          
          if (remainingText.trim()) {
            finalMessage = `[System Note: The user interrupted your ongoing lecture. You were about to say: "${remainingText}". Please acknowledge the interruption, address the user's input in character, and then seamlessly resume the rest of your lecture from where you left off, ensuring the remaining content is covered.]\n\n${finalMessage}`;
          }
          
          setIsInterrupted(false);
          isInterruptPendingRef.current = false;
          setIsPaused(false);
          stopSpeaking();
        }
      }
      
      onSendMessage(finalMessage);
      setInput('');
      setInterruptionSentiment(null);
    }
  };

  const handleSendRef = useRef<() => void>(handleSend);
  useEffect(() => {
    handleSendRef.current = handleSend;
  }, [handleSend]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (autocompleteSuggestions.length > 0 && !isAutocompleteDismissed) {
      if (e.key === 'Tab') {
        e.preventDefault();
        const selected = autocompleteSuggestions[selectedAutocompleteIndex] || autocompleteSuggestions[0];
        if (selected) {
          handleSelectAutocomplete(selected);
        }
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedAutocompleteIndex(prev => (prev - 1 + autocompleteSuggestions.length) % autocompleteSuggestions.length);
        return;
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedAutocompleteIndex(prev => (prev + 1) % autocompleteSuggestions.length);
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        setIsAutocompleteDismissed(true);
        return;
      }
    }

    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      setIsAutocompleteDismissed(true);
      handleSend();
    }
  };

  const handleTranslate = async (msgId: string, text: string, targetLanguageName: string, targetLanguageCode: string) => {
    onSelectLanguage(targetLanguageCode);
    
    setTranslatingIds(prev => {
      const next = new Set(prev);
      next.add(msgId);
      return next;
    });

    try {
      const prompt = `Translate the following exact text to ${targetLanguageName}. Preserve all markdown, math, and formatting. Return ONLY the translated text:\n\n${text}`;
      const translation = await generateAIResponse(prompt);
      setLocalTranslations(prev => ({ ...prev, [msgId]: translation }));
    } catch (err) {
      console.error(err);
    } finally {
      setTranslatingIds(prev => {
        const next = new Set(prev);
        next.delete(msgId);
        return next;
      });
    }
  };

  const stopSpeaking = () => {
    clearSpeechTimer();
    setSpeakingWordIndex(-1);
    elapsedMsRef.current = 0; // Reset elapsed time

    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (audioSourceRef.current) {
      try {
        audioSourceRef.current.onended = null;
        audioSourceRef.current.stop();
      } catch (e) {
        // already stopped
      }
      audioSourceRef.current = null;
    }
    if (audioContextRef.current) {
      try {
        audioContextRef.current.close();
      } catch (e) {
        // already closed
      }
      audioContextRef.current = null;
    }
    setIsSpeaking(false);
    setIsPaused(false);
    setIsInterrupted(false);
    isInterruptPendingRef.current = false;
    setSpeakingMessageId(null);
  };

  const handleVolumeChange = (volume: number) => {
    setTtsVolume(volume);
    localStorage.setItem('omni_tts_volume', String(volume));
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.setTargetAtTime(volume, audioContextRef.current?.currentTime || 0, 0.1);
    }
  };

  const handleRewind = () => {
    if (!isSpeaking || !speakingMessageId || !lastSpokenTextRef.current) return;
    const jumpMs = 5000;
    const newOffset = Math.max(0, elapsedMsRef.current - jumpMs);
    handleSpeakText(speakingMessageId, lastSpokenTextRef.current, newOffset);
  };

  const handleForward = () => {
    if (!isSpeaking || !speakingMessageId || !lastSpokenTextRef.current) return;
    const jumpMs = 5000;
    const newOffset = elapsedMsRef.current + jumpMs;
    handleSpeakText(speakingMessageId, lastSpokenTextRef.current, newOffset);
  };

  const handleGenerateChalkboardQuizById = async (msgId: string) => {
    const msg = messages.find(m => m.id === msgId);
    if (msg) {
      await handleGenerateChalkboardQuiz(msg);
    }
  };

  const handleLike = (msgId: string) => {
    setLikedMessages(prev => {
      const isLiked = !prev[msgId];
      if (isLiked) {
        setDislikedMessages(d => {
          const next = { ...d };
          delete next[msgId];
          return next;
        });
        showNotification?.("You liked this message! 👍", "success");
      }
      return { ...prev, [msgId]: isLiked };
    });
  };

  const handleDislike = (msgId: string) => {
    setDislikedMessages(prev => {
      const isDisliked = !prev[msgId];
      if (isDisliked) {
        setLikedMessages(l => {
          const next = { ...l };
          delete next[msgId];
          return next;
        });
        showNotification?.("You disliked this message! 👎", "info");
      }
      return { ...prev, [msgId]: isDisliked };
    });
  };

  const handleShareMessage = (msg: Message) => {
    const textToShare = msg.content;
    const shareUrl = getSyncShareUrl();
    if (navigator.share) {
      navigator.share({
        title: 'OmniTutor Lesson',
        text: textToShare.slice(0, 100) + '...',
        url: shareUrl
      }).catch(() => {
        navigator.clipboard.writeText(`${textToShare}\n\nShared via OmniTutor: ${shareUrl}`);
        showNotification?.("Lesson link copied to clipboard! 🔗", "success");
      });
    } else {
      navigator.clipboard.writeText(`${textToShare}\n\nShared via OmniTutor: ${shareUrl}`);
      showNotification?.("Lesson link copied to clipboard! 🔗", "success");
    }
  };

  // SPQ - Solved Practice Questions: System explains answers to questions of the current chat
  const handleSolvePracticeQuestions = (targetMsg?: Message) => {
    playChalkSound();

    let questionContext = '';
    if (targetMsg && targetMsg.content) {
      const lower = targetMsg.content.toLowerCase();
      const qIdx = Math.max(
        lower.indexOf('practice question'),
        lower.indexOf('suggested question'),
        lower.indexOf('questions for you'),
        lower.indexOf('questions:'),
        lower.indexOf('exercises:')
      );
      if (qIdx !== -1) {
        questionContext = `\n\nQuestions from this response to solve:\n"""\n${targetMsg.content.slice(qIdx, qIdx + 1800)}\n"""`;
      } else if (targetMsg.content.length > 30) {
        questionContext = `\n\nRecent context:\n"""\n${targetMsg.content.slice(0, 1200)}\n"""`;
      }
    } else {
      const recentAiMsg = [...messages].reverse().find(m => m.sender === 'ai' && m.content.length > 50);
      if (recentAiMsg) {
        questionContext = `\n\nQuestions from recent chat:\n"""\n${recentAiMsg.content.slice(0, 1200)}\n"""`;
      }
    }

    const promptText = `📝 [SPQ - Solved Practice Questions]
The professors should teach with a degree of STANDARD depth/rigor. Tutor Rigor Instructions: Provide a standard, granular, step-by-step academic explanation. Explain definitions, list equations, detail all complete concrete worked-out answers of the questions with intermediate steps, and. Please proceed to teach the questions now with high quality and formatting.

Please explain the answers and provide comprehensive step-by-step solutions to all the practice questions, suggested problems, and exercises presented in our current chat for "${topic || subject || 'this lesson'}".${questionContext}

Requirements:
1. State each problem clearly with any given data/parameters.
2. State the governing formula, scientific law, or mathematical principle in standard LaTeX ($...$ or $$...$$).
3. Walk through the complete step-by-step derivation or calculation without skipping steps.
4. Highlight the final calculated answer with appropriate SI units.
5. Provide a clear, intuitive conceptual explanation of WHY this answer is correct so I master the concept.`;

    if (onSendMessage) {
      onSendMessage(promptText);
      showNotification?.("Professor is explaining the answers to the practice questions! 📝", "success");
    } else {
      setShowPracticeQuestionModal(true);
    }
  };

  const handleTypewriterComplete = (msgId: string, content: string) => {
    if (isRecordingAi) {
      const timestamp = (Date.now() - recordingStartTime.current) / 1000;
      setRecordedEvents(prev => [...prev, { timestamp, event: `AI Tutor wrote: ${content.substring(0, 50)}...` }]);
    }
    setCompletedTypewriterIds(prev => {
      if (prev.has(msgId)) return prev;
      const next = new Set(prev);
      next.add(msgId);
      return next;
    });
    if (isLectureMode && speakingMessageId !== msgId) {
      setTimeout(() => {
        handleSpeakText(msgId, content);
      }, 0);
    }
  };

  const playChalkClickSound = () => {
    if (!isChalkSfxEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const bufferSize = ctx.sampleRate * 0.03;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 2200;
      filter.Q.value = 8.0;
      
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.008, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.02);
      
      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      
      noise.start();
    } catch (e) {
      // ignore
    }
  };

  const playQuizSuccessSound = () => {
    if (!isChalkSfxEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const now = ctx.currentTime;
      
      // Play ascending major triad chord (C5, E5, G5)
      const notes = [523.25, 659.25, 783.99];
      notes.forEach((freq, index) => {
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + index * 0.07);
        
        gainNode.gain.setValueAtTime(0, now);
        gainNode.gain.linearRampToValueAtTime(0.06, now + index * 0.07 + 0.02);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + index * 0.07 + 0.25);
        
        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        osc.start(now + index * 0.07);
        osc.stop(now + index * 0.07 + 0.25);
      });
    } catch (e) {}
  };

  const playQuizFailureSound = () => {
    if (!isChalkSfxEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const now = ctx.currentTime;
      
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.linearRampToValueAtTime(174.61, now + 0.15);
      
      gainNode.gain.setValueAtTime(0.08, now);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      osc.start(now);
      osc.stop(now + 0.25);
    } catch (e) {}
  };

  const playModeTransitionSound = (mode: 'standard' | 'classroom' | 'quiz' | 'lecture' | 'video_classroom') => {
    if (!isChalkSfxEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const now = ctx.currentTime;
      
      if (mode === 'standard') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (mode === 'classroom') {
        playChalkClickSound();
        setTimeout(() => {
          playChalkClickSound();
        }, 120);
      } else if (mode === 'quiz') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.18);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.22);
      } else if (mode === 'lecture') {
        [130.81, 196.00].forEach(freq => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now);
          gain.gain.setValueAtTime(0.03, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.45);
        });
      } else if (mode === 'video_classroom') {
        // High-tech warm synth chime for movie mode start
        [261.63, 329.63, 392.00, 523.25].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + idx * 0.08);
          gain.gain.setValueAtTime(0.025, now + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.4);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * 0.08);
          osc.stop(now + idx * 0.08 + 0.4);
        });
      }
    } catch (e) {}
  };

  const playCrashDoubtSound = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const now = ctx.currentTime;
      
      // Short, soft system acoustic tone for Crash Doubt interaction
      // Dual-tone soft chime with warm sine oscillator & gentle envelope
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(659.25, now); // E5
      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.04, now + 0.01);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.12);

      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880, now + 0.05); // A5
      gain2.gain.setValueAtTime(0, now + 0.05);
      gain2.gain.linearRampToValueAtTime(0.045, now + 0.06);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.05);
      osc2.stop(now + 0.18);
    } catch (e) {
      // ignore
    }
  };

  const openCrashDoubtModal = () => {
    playCrashDoubtSound();
    setIsCrashDoubtModalOpen(true);
  };

  const handleGenerateChalkboardQuiz = async (msg: Message) => {
    // If already generated, toggle it
    if (messageQuizzes[msg.id]) {
      // Toggle off
      setMessageQuizzes(prev => {
        const copy = { ...prev };
        delete copy[msg.id];
        return copy;
      });
      return;
    }

    setLoadingQuizMessageId(msg.id);
    try {
      const selectedLangObj = LANGUAGES.find(l => l.code === language) || { name: 'English' };
      const selectedLangName = selectedLangObj.name;

      const prompt = `Based on the following educational content, generate a quick 2-question multiple-choice quiz to check the student's understanding. Keep questions concise, professional, and highly relevant to the core concepts explained on the board. Make sure options are distinct.
CRITICAL: You MUST write the entire quiz (questions, options, and explanations) in the ${selectedLangName} language, because the student has selected ${selectedLangName} as their target language.
Return ONLY a valid raw JSON array of objects, with no markdown codeblocks, matching this structure:
[
  {
    "question": "Question text in ${selectedLangName}...",
    "options": ["Option A in ${selectedLangName}", "Option B in ${selectedLangName}", "Option C in ${selectedLangName}", "Option D in ${selectedLangName}"],
    "correctIndex": 0,
    "explanation": "Brief explanation in ${selectedLangName} of why the answer is correct."
  }
]

Content:
${msg.content}`;

      const responseText = await generateAIResponse(prompt);
      // Clean possible markdown code wrappers
      let cleanJson = responseText || "";
      if (cleanJson.includes("```json")) {
        cleanJson = cleanJson.split("```json")[1].split("```")[0];
      } else if (cleanJson.includes("```")) {
        cleanJson = cleanJson.split("```")[1].split("```")[0];
      }
      cleanJson = cleanJson.trim();

      const parsedQuiz = JSON.parse(cleanJson);
      if (Array.isArray(parsedQuiz) && parsedQuiz.length > 0) {
        setMessageQuizzes(prev => ({
          ...prev,
          [msg.id]: parsedQuiz
        }));
      } else {
        throw new Error("Invalid format returned from AI.");
      }
    } catch (err) {
      console.error("Failed to generate concept quiz:", err);
      showNotification?.("Could not draft chalkboard questions at this time. Try again!", "error");
    } finally {
      setLoadingQuizMessageId(null);
    }
  };

  const handleStartReading = async (msgId: string, text: string) => {
    console.log("DEBUG: handleStartReading. msgId:", msgId, "text:", text.substring(0, 50));
    // Unlock speech synthesis engine synchronously within user gesture
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      const dummy = new SpeechSynthesisUtterance(' ');
      dummy.volume = 0;
      window.speechSynthesis.speak(dummy);
    }

    if (isSpeaking) {
      stopSpeaking();
    }
    await handleSpeakText(msgId, text);
  };

  const handlePauseResume = async () => {
    if (!isSpeaking || !speakingMessageId) return;
    
    if (isPaused) {
      if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      } else if (window.speechSynthesis) {
        window.speechSynthesis.resume();
      }
      setIsPaused(false);
      setIsInterrupted(false);
      isInterruptPendingRef.current = false;
      showNotification?.("Lecture resumed.", "info");
    } else {
      if (audioContextRef.current && audioContextRef.current.state === 'running') {
        await audioContextRef.current.suspend();
      } else if (window.speechSynthesis) {
        window.speechSynthesis.pause();
      }
      setIsPaused(true);
      setIsInterrupted(false);
      isInterruptPendingRef.current = false;
      showNotification?.("Lecture paused.", "info");
    }
  };

  const getLpcLanguageTag = (code: string): string => {
    const map: Record<string, string> = {
      en: 'en-US',
      hi: 'hi-IN',
      ur: 'ur-PK',
      zh: 'zh-CN',
      es: 'es-ES',
      fr: 'fr-FR',
      ar: 'ar-SA',
      ru: 'ru-RU',
      pt: 'pt-PT',
      bn: 'bn-IN',
      de: 'de-DE',
      ja: 'ja-JP',
      pa: 'pa-IN',
      jv: 'jv-ID',
      ko: 'ko-KR',
      vi: 'vi-VN',
      te: 'te-IN',
      mr: 'mr-IN',
      ta: 'ta-IN',
      tr: 'tr-TR'
    };
    return map[code] || code;
  };

  const handleSpeakText = async (
    msgId: string,
    text: string,
    offsetMs: number = 0,
    force: boolean = false,
    customPlaybackRate?: number
  ) => {
    if (isLectureMode && !force && !readyMessages.has(msgId)) {
      return;
    }
    // Global Classroom Mute: Silent-mode while AI is generating / rendering 2D SVG diagrams
    if ((isClassroomMute || isDiagramRendering) && !force) {
      console.log("[Classroom Mute] Text-to-Speech held in silent-mode during 2D diagram generation/rendering.");
      return;
    }
    // If clicked on the speaker of the currently reading message, toggle pause/play
    // BUT only if we are NOT trying to seek (offsetMs === 0)
    if (offsetMs === 0 && isSpeaking && speakingMessageId === msgId) {
      if (isPaused) {
        // Resume
        if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
          await audioContextRef.current.resume();
        } else if (window.speechSynthesis) {
          window.speechSynthesis.resume();
        }
        setIsPaused(false);
        setIsInterrupted(false);
        isInterruptPendingRef.current = false;
      } else {
        // Pause
        if (audioContextRef.current && audioContextRef.current.state === 'running') {
          await audioContextRef.current.suspend();
        } else if (window.speechSynthesis) {
          window.speechSynthesis.pause();
        }
        setIsPaused(true);
        setIsInterrupted(false);
        isInterruptPendingRef.current = false;
      }
      return;
    }

    // Stop previous audio first if playing a different message OR seeking
    if (isSpeaking) {
      // Don't call stopSpeaking fully because it resets everything
      clearSpeechTimer();
      if (audioSourceRef.current) {
        try {
          audioSourceRef.current.onended = null;
          audioSourceRef.current.stop();
        } catch (e) {}
        audioSourceRef.current = null;
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    }

    // Update refs for seek support
    lastSpokenTextRef.current = text;
    lastSpokenMsgIdRef.current = msgId;

    // Unlock or initialize AudioContext synchronously
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
        audioContextRef.current = new AudioContextClass({ sampleRate: 24000 });
      }
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume().catch(e => console.warn("Failed to resume AudioContext", e));
      }
    }

    try {
      setIsSpeaking(true);
      setSpeakingMessageId(msgId);
      setIsPaused(false);
      setIsInterrupted(false);
      isInterruptPendingRef.current = false;
      elapsedMsRef.current = offsetMs;
      setSpeakingWordIndex(offsetMs > 0 ? (speakingWordIndex >= 0 ? speakingWordIndex : 0) : 0);

      const persona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[1];
      const cleanTextForWords = cleanTextForNaturalSpeech(text, pronunciationPrecision);
      const { wordsList, cumulativeWeights } = computeUnifiedSyncWeights(cleanTextForWords);
      const wordCount = wordsList.length;

      // Determine active engine dynamically when in 'auto' mode
      let activeEngine: 'tts' | 'google' | 'webspeech' = 'tts';
      if (ttsEngineMode === 'auto') {
        if (!isLectureMode) {
          activeEngine = 'webspeech';
        } else if (lectureSubMode === 'classroom') {
          activeEngine = 'google';
        } else {
          activeEngine = 'tts';
        }
      } else {
        activeEngine = ttsEngineMode as 'tts' | 'google' | 'webspeech';
      }

      // Check cache (only relevant for server-side synthesized engines)
      let buffer = activeEngine !== 'webspeech' ? audioCacheRef.current.get(msgId) : undefined;
      
      if (!buffer && activeEngine !== 'webspeech') {
        let base64Audio = null;
        const isGoogle = activeEngine === 'google';
        
        if (isGoogle) {
          base64Audio = await generateGoogleSpeech(cleanTextForWords, language || 'en');
        } else {
          const narratorVoice = isProfessorNarrator ? 'Fenrir' : (persona?.voiceName || 'Kore');
          base64Audio = await generateSpeech(cleanTextForWords, narratorVoice);
        }

        if (base64Audio) {
          let audioContext = audioContextRef.current;
          if (!audioContext || audioContext.state === 'closed') {
            audioContext = new AudioContextClass({ sampleRate: 24000 });
            audioContextRef.current = audioContext;
          }
          if (!analyserRef.current) {
              analyserRef.current = audioContext.createAnalyser();
          }

          const binaryString = atob(base64Audio);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          
          try {
            // Try to decode natively first (supports WAV, MP3, etc. perfectly)
            // We pass a copy (bytes.buffer.slice(0)) because decodeAudioData detaches the buffer on success/failure
            buffer = await new Promise<AudioBuffer>((resolve, reject) => {
              audioContext!.decodeAudioData(bytes.buffer.slice(0), resolve, reject);
            });
          } catch (decodeErr) {
            console.warn("Native Web Audio API decoding failed, attempting manual 16-bit raw PCM fallback:", decodeErr);
            try {
              // Parse as 16-bit little-endian raw PCM
              const floatData = new Float32Array(Math.floor(len / 2));
              const view = new DataView(bytes.buffer);
              for (let i = 0; i < floatData.length; i++) {
                floatData[i] = view.getInt16(i * 2, true) / 32768;
              }

              buffer = audioContext.createBuffer(1, floatData.length, 24000);
              buffer.getChannelData(0).set(floatData);
            } catch (pcmErr) {
              console.error("Manual raw PCM parsing also failed:", pcmErr);
            }
          }

          if (buffer) {
            audioCacheRef.current.set(msgId, buffer);
            audioBufferRef.current = buffer;
          }
        }
      }

      let activeRate = customPlaybackRate || ttsRate;
      if (!customPlaybackRate && (isProfessorNarrator || (isLectureMode && lectureSubMode === 'lecture'))) {
        // Professor Narrator: Highly formal, authoritative steady pacing synchronized with blackboard drawing cadence
        activeRate = ttsRate * 0.93;
      }

      if (buffer) {
        let audioContext = audioContextRef.current!;
        const source = audioContext.createBufferSource();
        audioSourceRef.current = source;
        source.buffer = buffer;
        
        const gainNode = audioContext.createGain();
        gainNode.gain.setValueAtTime(ttsVolume, audioContext.currentTime);
        gainNodeRef.current = gainNode;

        const analyser = audioContext.createAnalyser();
        analyser.fftSize = 256;
        analyserRef.current = analyser;

        source.playbackRate.value = activeRate;

        // Apply Speech Generation Audio Normalization & Timbre Standardization Filter
        const filterChain = createVoiceNormalizationChain(audioContext);
        source.connect(filterChain.input);
        filterChain.output.connect(analyser);

        analyser.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        const duration = buffer.duration;
        const startCtxTime = audioContext.currentTime;
        const initialOffsetSeconds = offsetMs / 1000;
        
        // Build the pre-calculated word timestamp matrix for this specific decoded audio buffer
        const bufferDurationMs = (duration / activeRate) * 1000;
        const activeMatrix = buildWordTimestampMatrix(cleanTextForWords, bufferDurationMs, activeRate);
        
        clearSpeechTimer();
        
        const updateTick = () => {
          if (speakingIntervalRef.current === null) return; // Stopped externally
          if (audioSourceRef.current !== source) return; // Different source now
          
          if (audioContext.state === 'suspended') {
            speakingIntervalRef.current = requestAnimationFrame(updateTick);
            return;
          }
          
          // Math-perfect, self-correcting alignment matching physical hardware playback position
          const elapsedSeconds = (audioContext.currentTime - startCtxTime) * activeRate + initialOffsetSeconds;
          
          // Compensate for hardware buffer output latency and physical acoustic perception alignment (hardware outputLatency + base perceptual 25ms lead)
          const baseHardwareLatency = typeof audioContext.outputLatency === 'number' ? audioContext.outputLatency : 0.045;
          const latencyCompensation = Math.max(0.02, Math.min(0.12, baseHardwareLatency + 0.025));
          const visualElapsedSeconds = Math.max(0, elapsedSeconds - latencyCompensation);
          const visualElapsedMs = visualElapsedSeconds * 1000;
          
          const wordIdx = activeMatrix.getWordIndexAtTime(visualElapsedMs);
          
          setSpeakingWordIndex(wordIdx);
          elapsedMsRef.current = elapsedSeconds * 1000;
          
          speakingIntervalRef.current = requestAnimationFrame(updateTick);
        };
        
        speakingIntervalRef.current = requestAnimationFrame(updateTick);

        source.onended = () => {
          // Only finalize if we didn't stop to seek
          if (audioSourceRef.current === source) {
            setIsSpeaking(false);
            setIsPaused(false);
            setSpeakingMessageId(null);
            audioSourceRef.current = null;
            audioContextRef.current = null;
            audioBufferRef.current = null;
            clearSpeechTimer();
            setSpeakingWordIndex(-1);
            elapsedMsRef.current = 0;
            if (interruptedLectureMsgIdRef.current) {
              handleResumeInterruptedLecture();
            } else if (isLectureMode) {
              if (lectureSubMode === 'quiz') {
                showNotification?.("Lecture ended! Generating your interactive Auto-Quiz check now... 🧠", "info");
                handleGenerateChalkboardQuizById(msgId);
              } else {
                showNotification?.("Lecture ended! Review the board notes to lock in what you've learned. 🎓", "info");
              }
            }
          }
        };
        source.start(0, offsetMs / 1000);
      } else if (activeEngine === 'webspeech' || !buffer) {
        // Fallback to window.speechSynthesis
        const utteranceText = offsetMs > 0 ? cleanTextForWords.split(/\s+/).slice(speakingWordIndex).join(' ') : cleanTextForWords;
        const utterance = new SpeechSynthesisUtterance(utteranceText);
        utterance.rate = activeRate;
        utterance.volume = ttsVolume;
        
        const langTag = getLpcLanguageTag(language);
        utterance.lang = langTag;
        if (window.speechSynthesis) {
          window.speechSynthesis.cancel();
          window.speechSynthesis.resume();
          const voices = window.speechSynthesis.getVoices();
          const matchingVoice = voices.find(v => v.lang.toLowerCase() === langTag.toLowerCase() || v.lang.toLowerCase().startsWith(language.toLowerCase()));
          if (matchingVoice) {
            utterance.voice = matchingVoice;
          }
        }
        
        utterance.onboundary = (event) => {
          if (event.name === 'word') {
            const charIndex = event.charIndex;
            const textUpToChar = utteranceText.substring(0, charIndex);
            const relativeWordIdx = textUpToChar.split(/\s+/).filter(Boolean).filter(w => w.replace(/[^\p{L}\p{N}]/gu, "").trim().length > 0).length;
            const absoluteWordIdx = (offsetMs > 0 ? speakingWordIndex : 0) + relativeWordIdx;
            setSpeakingWordIndex(Math.min(wordCount - 1, absoluteWordIdx));
            // Estimate elapsedMs for synthesis fallback
            elapsedMsRef.current = (absoluteWordIdx / wordCount) * 60000; // very rough estimate
          }
        };

        utterance.onend = () => {
          setIsSpeaking(false);
          setIsPaused(false);
          setSpeakingMessageId(null);
          setSpeakingWordIndex(-1);
          elapsedMsRef.current = 0;
          if (interruptedLectureMsgIdRef.current) {
            handleResumeInterruptedLecture();
          } else if (isLectureMode) {
            if (lectureSubMode === 'quiz') {
              showNotification?.("Lecture ended! Generating your interactive Auto-Quiz check now... 🧠", "info");
              handleGenerateChalkboardQuizById(msgId);
            } else {
              showNotification?.("Lecture ended! Review the board notes to lock in what you've learned. 🎓", "info");
            }
          }
        };
        window.speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error('Speech generation failed:', error);
      showNotification?.("Speech generation failed. Falling back to default TTS.", "error");
      const utterance = new SpeechSynthesisUtterance(cleanTextForNaturalSpeech(text, pronunciationPrecision));
      utterance.rate = ttsRate;
      utterance.volume = ttsVolume;
      
      const langTag = getLpcLanguageTag(language);
      utterance.lang = langTag;
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        window.speechSynthesis.resume();
        const voices = window.speechSynthesis.getVoices();
        const matchingVoice = voices.find(v => v.lang.toLowerCase() === langTag.toLowerCase() || v.lang.toLowerCase().startsWith(language.toLowerCase()));
        if (matchingVoice) {
          utterance.voice = matchingVoice;
        }
      }
      
      window.speechSynthesis.speak(utterance);
    }
  };

  const renderFeaturesMenu = (msg: Message) => {
    const isThisMessageCached = audioCacheRef.current.has(msg.id);
    const translationText = localTranslations[msg.id];
    const hasTranslation = !!translationText;
    
    return (
      <>
        <div className="fixed inset-0 z-40 cursor-default" onClick={(e) => {
          e.stopPropagation();
          setActiveFeaturesMenuId(null);
        }} />
        <div className={cn(
          "absolute bottom-full left-0 md:left-auto md:right-0 mb-3 w-[330px] rounded-2xl shadow-2xl border p-4 z-50 animate-in fade-in slide-in-from-bottom-2 text-left space-y-3 cursor-default select-none",
          theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-slate-950/90 text-slate-100" : "bg-white border-slate-200 shadow-indigo-100/50 text-slate-800"
        )} onClick={(e) => e.stopPropagation()}>
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-indigo-500 flex items-center gap-1.5">
              <Sparkles size={13} className="text-indigo-500 animate-pulse" />
              Speech Engine Control Center
            </span>
            <span className="text-[9px] font-bold bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full font-mono">
              10 Premium Features
            </span>
          </div>

          <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
            {/* 1. AI Voice Personas */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  👥 AI Voice Personas
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  High-quality custom speaker personalities
                </div>
              </div>
              <button
                onClick={() => {
                  const currentIndex = PERSONAS.findIndex(p => p.id === selectedPersonaId);
                  const nextIndex = (currentIndex + 1) % PERSONAS.length;
                  const nextPersona = PERSONAS[nextIndex];
                  onSelectPersonaId?.(nextPersona.id);
                  showNotification?.(`Vocal identity switched to: ${nextPersona.name} (${nextPersona.accent})`, 'success');
                }}
                className="px-2 py-1 text-[9px] font-black uppercase bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-all active:scale-95 flex items-center gap-1 shrink-0"
              >
                <span>{PERSONAS.find(p => p.id === selectedPersonaId)?.icon || '🏆'}</span>
                <span>{PERSONAS.find(p => p.id === selectedPersonaId)?.name.split(' ')[0] || 'Kore'}</span>
              </button>
            </div>

            {/* 2. Speech Synthesis Engine */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  🔊 Speech Engine Mode
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  {ttsEngineMode === 'tts' && "Gemini Cloud Voice Synthesis"}
                  {ttsEngineMode === 'google' && "Google Cloud Voice Synthesis"}
                  {ttsEngineMode === 'webspeech' && "Native browser speech synthesizer"}
                  {ttsEngineMode === 'auto' && "Intelligent engine selection"}
                </div>
              </div>
              <button
                onClick={() => {
                  let next: 'tts' | 'google' | 'webspeech' | 'auto' = 'tts';
                  if (ttsEngineMode === 'tts') next = 'google';
                  else if (ttsEngineMode === 'google') next = 'webspeech';
                  else if (ttsEngineMode === 'webspeech') next = 'auto';
                  else if (ttsEngineMode === 'auto') next = 'tts';
                  
                  setTtsEngineMode(next);
                  localStorage.setItem('omni_tts_engine_mode', next);
                  
                  let label = "Gemini TTS Core activated.";
                  if (next === 'google') label = "Google Cloud TTS activated.";
                  if (next === 'webspeech') label = "Native web speech active.";
                  if (next === 'auto') label = "Intelligent auto-engine active.";
                  showNotification?.(label, "info");
                }}
                className={cn(
                  "px-2 py-1 text-[9px] font-black uppercase rounded-lg transition-all active:scale-95 shrink-0",
                  ttsEngineMode === 'tts' && "bg-indigo-500 hover:bg-indigo-600 text-white",
                  ttsEngineMode === 'google' && "bg-sky-500 hover:bg-sky-600 text-white",
                  ttsEngineMode === 'webspeech' && "bg-emerald-500 hover:bg-emerald-600 text-white",
                  ttsEngineMode === 'auto' && "bg-amber-500 hover:bg-amber-600 text-white"
                )}
              >
                {ttsEngineMode === 'tts' && "Gemini"}
                {ttsEngineMode === 'google' && "Google"}
                {ttsEngineMode === 'webspeech' && "Native"}
                {ttsEngineMode === 'auto' && "Auto"}
              </button>
            </div>

            {/* 3. Real-time Word Highlighting */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  🖍️ Word Highlighting
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  Highlights spoken words synchronously
                </div>
              </div>
              <button
                onClick={() => {
                  const next = !isWordHighlightingEnabled;
                  setIsWordHighlightingEnabled(next);
                  localStorage.setItem('omni_is_word_highlighting_enabled', String(next));
                  showNotification?.(next ? "Real-time highlighting enabled." : "Highlighting disabled.", "info");
                }}
                className={cn(
                  "px-2 py-1 text-[9px] font-black uppercase rounded-lg transition-all active:scale-95 shrink-0",
                  isWordHighlightingEnabled 
                    ? "bg-indigo-500 hover:bg-indigo-600 text-white" 
                    : "bg-slate-300 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                )}
              >
                {isWordHighlightingEnabled ? "Enabled" : "Disabled"}
              </button>
            </div>

            {/* 4. Interactive Waveform */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  📈 Interactive Waveform
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  Live visualization of speech frequencies
                </div>
              </div>
              <button
                onClick={() => {
                  const next = !isWaveformVisualizerEnabled;
                  setIsWaveformVisualizerEnabled(next);
                  localStorage.setItem('omni_is_waveform_enabled', String(next));
                  showNotification?.(next ? "Waveform visualizer shown." : "Waveform hidden.", "info");
                }}
                className={cn(
                  "px-2 py-1 text-[9px] font-black uppercase rounded-lg transition-all active:scale-95 shrink-0",
                  isWaveformVisualizerEnabled 
                    ? "bg-indigo-500 hover:bg-indigo-600 text-white" 
                    : "bg-slate-300 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                )}
              >
                {isWaveformVisualizerEnabled ? "Visible" : "Hidden"}
              </button>
            </div>

            {/* 5. Smart Pause/Resume Toggle */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  ⏸️ Smart Pause & Resume
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  Toggle reading state with instant recall
                </div>
              </div>
              <button
                onClick={() => {
                  if (speakingMessageId === msg.id) {
                    handlePauseResume();
                  } else {
                    handleStartReading(msg.id, translationText || msg.content);
                  }
                }}
                className={cn(
                  "px-2 py-1 text-[9px] font-black uppercase rounded-lg transition-all active:scale-95 shrink-0 cursor-pointer",
                  speakingMessageId === msg.id
                    ? isPaused
                      ? "bg-emerald-500 text-white hover:bg-emerald-600 shadow-md shadow-emerald-500/15"
                      : "bg-amber-500 text-white hover:bg-amber-600 shadow-md shadow-amber-500/15 animate-pulse"
                    : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/15"
                )}
              >
                {speakingMessageId === msg.id 
                  ? isPaused ? "Resume" : "Pause"
                  : "Play"
                }
              </button>
            </div>

            {/* 6. Variable Playback Speed */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  ⚡ Playback Speed
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate font-mono">
                  Current speed: {ttsRate}x
                </div>
              </div>
              <button
                onClick={() => {
                  const rates = [0.75, 1.0, 1.25, 1.5, 2.0];
                  const idx = rates.indexOf(ttsRate);
                  const nextRate = rates[(idx + 1) % rates.length];
                  setTtsRate(nextRate);
                  localStorage.setItem('omni_tts_rate', String(nextRate));
                  showNotification?.(`Speed adjusted to ${nextRate}x`, "info");
                }}
                className="px-2 py-1 text-[9px] font-black uppercase bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg transition-all active:scale-95 font-mono shrink-0"
              >
                {ttsRate.toFixed(2)}x
              </button>
            </div>

            {/* 7. Lecture Mode & Auto-Quizzing */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  🎓 Auto-Quiz Lecture Mode
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  Triggers concept quizzes automatically
                </div>
              </div>
              <button
                onClick={() => {
                  const next = !isLectureMode;
                  setIsLectureMode(next);
                  showNotification?.(next ? "Lecture Mode: Auto-Quizzes enabled." : "Auto-Quizzes turned off.", "info");
                }}
                className={cn(
                  "px-2 py-1 text-[9px] font-black uppercase rounded-lg transition-all active:scale-95 shrink-0",
                  isLectureMode 
                    ? "bg-indigo-500 hover:bg-indigo-600 text-white" 
                    : "bg-slate-300 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                )}
              >
                {isLectureMode ? "Auto ON" : "Off"}
              </button>
            </div>

            {/* 8. Translation Support */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  🌐 Translation Support
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  {translatingIds.has(msg.id)
                    ? "Translating text now..."
                    : hasTranslation
                      ? `Translated to ${LANGUAGES.find(l => l.code === language)?.name || "Target Language"}`
                      : `Not translated yet (Target: ${LANGUAGES.find(l => l.code === language)?.name || "English"})`}
                </div>
              </div>
              <button
                disabled={translatingIds.has(msg.id)}
                onClick={() => {
                  if (hasTranslation) {
                    setLocalTranslations(prev => {
                      const next = { ...prev };
                      delete next[msg.id];
                      return next;
                    });
                    showNotification?.("Restored original text.", "info");
                  } else {
                    const targetLangObj = LANGUAGES.find(l => l.code === language) || LANGUAGES[0];
                    handleTranslate(msg.id, msg.content, targetLangObj.name, targetLangObj.code);
                    showNotification?.(`Translating to ${targetLangObj.name}...`, "info");
                  }
                }}
                className={cn(
                  "px-2 py-1 text-[9px] font-black uppercase rounded-lg transition-all shrink-0 cursor-pointer",
                  translatingIds.has(msg.id)
                    ? "bg-amber-500 text-white animate-pulse"
                    : hasTranslation 
                      ? "bg-emerald-500 hover:bg-rose-500 text-white" 
                      : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/15"
                )}
              >
                {translatingIds.has(msg.id) 
                  ? "Translating" 
                  : hasTranslation 
                    ? "Active" 
                    : "Translate"
                }
              </button>
            </div>

            {/* 9. High-Fidelity Audio Cache */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  💾 Audio Buffer Cache
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  {audioCacheRef.current.size} cached items in memory
                </div>
              </div>
              <button
                onClick={() => {
                  audioCacheRef.current.clear();
                  audioBufferRef.current = null;
                  showNotification?.("Audio buffer cache cleared.", "success");
                }}
                className="px-2 py-1 text-[9px] font-black uppercase bg-rose-500 hover:bg-rose-600 text-white rounded-lg transition-all active:scale-95 shrink-0"
              >
                Clear
              </button>
            </div>

            {/* 10. Dynamic Fallback */}
            <div className="flex items-center justify-between gap-3 p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50">
              <div className="space-y-0.5 min-w-0 flex-1">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-indigo-500 flex items-center gap-1">
                  🛡️ Dynamic Fallback
                </div>
                <div className="text-[9px] text-slate-400 leading-normal truncate">
                  Tests browser speech synthesis fallback
                </div>
              </div>
              <button
                onClick={() => {
                  if (window.speechSynthesis) {
                    window.speechSynthesis.cancel();
                    const testUtterance = new SpeechSynthesisUtterance("Audio system operational.");
                    testUtterance.rate = 1.0;
                    window.speechSynthesis.speak(testUtterance);
                    showNotification?.("Synthesizing fallback test audio.", "info");
                  } else {
                    showNotification?.("Browser SpeechSynthesis is unavailable", "error");
                  }
                }}
                className="px-2 py-1 text-[9px] font-black uppercase bg-slate-500 hover:bg-slate-600 text-white rounded-lg transition-all active:scale-95 shrink-0"
              >
                Test
              </button>
            </div>
          </div>
        </div>
      </>
    );
  };

  const handleSpeak = async () => {
    const lastAiMessage = [...messages].reverse().find(m => m.sender === 'ai');
    if (!lastAiMessage) return;
    await handleSpeakText(lastAiMessage.id || 'global', lastAiMessage.content);
  };

  const textSizeClasses = {
    sm: '[&_p]:text-xs [&_ul]:text-xs [&_ol]:text-xs [&_li]:text-xs [&_h1]:text-lg [&_h2]:text-base [&_h3]:text-sm [&_code]:text-[11px] [&_pre]:text-[10px]',
    md: '[&_p]:text-sm [&_ul]:text-sm [&_ol]:text-sm [&_li]:text-sm [&_h1]:text-2xl [&_h2]:text-xl [&_h3]:text-lg [&_code]:text-sm [&_pre]:text-xs',
    lg: '[&_p]:text-base [&_ul]:text-base [&_ol]:text-base [&_li]:text-base [&_h1]:text-3xl [&_h2]:text-2xl [&_h3]:text-xl [&_code]:text-base [&_pre]:text-sm',
    xl: '[&_p]:text-lg [&_ul]:text-lg [&_ol]:text-lg [&_li]:text-lg [&_h1]:text-4xl [&_h2]:text-3xl [&_h3]:text-2xl [&_code]:text-lg [&_pre]:text-base',
  };

  const lineSpacingClasses = {
    normal: '[&_p]:leading-normal [&_li]:leading-normal [&_h1]:leading-normal [&_h2]:leading-normal [&_h3]:leading-normal',
    relaxed: '[&_p]:leading-relaxed [&_li]:leading-relaxed [&_h1]:leading-relaxed [&_h2]:leading-relaxed [&_h3]:leading-relaxed',
    loose: '[&_p]:leading-loose [&_li]:leading-loose [&_h1]:leading-loose [&_h2]:leading-loose [&_h3]:leading-loose',
  };

  const contrastClasses = {
    normal: '',
    high: theme === 'dark'
      ? 'bg-black text-white border-2 border-slate-500 [&_.messages-scroll-container]:bg-black [&_p]:text-slate-100 [&_strong]:text-white [&_strong]:font-black'
      : 'bg-white text-black border-2 border-slate-800 [&_.messages-scroll-container]:bg-white [&_p]:text-slate-950 [&_strong]:text-black [&_strong]:font-black',
    ultra: theme === 'dark'
      ? 'bg-black text-yellow-300 border-2 border-yellow-400 [&_.messages-scroll-container]:bg-black [&_p]:text-yellow-200 [&_ul]:text-yellow-200 [&_ol]:text-yellow-200 [&_li]:text-yellow-200 [&_h1]:text-yellow-300 [&_h2]:text-yellow-300 [&_h3]:text-yellow-300 [&_strong]:text-yellow-400 [&_strong]:font-black [&_code]:bg-yellow-950 [&_code]:text-yellow-300'
      : 'bg-white text-black border-2 border-indigo-950 [&_.messages-scroll-container]:bg-white [&_p]:text-black [&_ul]:text-black [&_ol]:text-black [&_li]:text-black [&_h1]:text-indigo-950 [&_h2]:text-indigo-950 [&_h3]:text-indigo-950 [&_strong]:text-black [&_strong]:font-black [&_code]:bg-indigo-50 [&_code]:text-indigo-950',
  };

  return (
    <div className={cn(
      "flex-1 flex flex-row w-full overflow-hidden relative rounded-2xl transition-all duration-300",
      isPaused && isInterrupted 
        ? (theme === 'dark' ? "ring-2 ring-indigo-500/50 shadow-[0_0_15px_rgba(99,102,241,0.3)]" : "ring-2 ring-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.3)]")
        : "",
      textSizeClasses[accessibilityTextSize] || textSizeClasses['md'],
      lineSpacingClasses[accessibilityLineSpacing] || lineSpacingClasses['relaxed'],
      contrastClasses[accessibilityContrast] || contrastClasses['normal']
    )}>
      {/* Main Chat Pane */}
      <div className="flex-1 flex flex-col min-w-0 h-full px-0 overflow-hidden relative">

        {activeLessonVideo && (
          <div className="absolute inset-0 bg-[#090d16] z-40 flex flex-col p-4 md:p-6 overflow-hidden select-none animate-in fade-in zoom-in duration-300">
            {/* Digital lesson video canvas wrapper */}
            <div className="flex-1 flex flex-col bg-[#0b131f] border border-slate-700/60 rounded-2xl shadow-2xl relative overflow-hidden justify-between">
              
              {/* Blackboard Title Header */}
              <div className="border-b border-white/10 p-3 bg-black/40 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-[11px] uppercase tracking-widest font-black text-slate-400">
                    Interactive AI Classroom Video: {activeLessonVideo.metadata?.topic || subject || "Academic Lecture"}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-mono font-bold bg-white/5 border border-white/10 text-amber-300 px-2 py-0.5 rounded-md">
                    {videoPlayStatus === 'drawing' && "📐 SKETCHING FIGURE"}
                    {videoPlayStatus === 'writing' && "🗣️ TUTOR PLAY NARRATION"}
                    {videoPlayStatus === 'completed' && "🎓 BOARD COMPLETE (+25 XP)"}
                  </span>

                  {/* Clear Blackboard Button in Cinema Mode */}
                  <button
                    onClick={() => {
                      if (isVideoBoardErased) {
                        handleRestoreVideoBlackboard();
                      } else {
                        handleClearVideoBlackboard();
                      }
                    }}
                    disabled={isErasingVideoBoard}
                    className={cn(
                      "px-2 py-0.5 rounded text-[9px] font-black uppercase transition cursor-pointer border flex items-center gap-1 shadow-sm active:scale-95",
                      isVideoBoardErased
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-400/50 hover:bg-emerald-500/30 font-black shadow-emerald-500/10"
                        : "bg-amber-500/20 text-amber-300 border-amber-400/40 hover:bg-amber-500/30 hover:text-white shadow-amber-500/10"
                    )}
                    title={
                      isVideoBoardErased
                        ? "Restore previous blackboard diagrams & text"
                        : "Clear Blackboard: Smooth felt eraser wipe transition across canvas before next conceptual sub-topic"
                    }
                  >
                    <Eraser size={11} className={isVideoBoardErased ? "text-emerald-400" : "text-amber-400"} />
                    <span>{isErasingVideoBoard ? "Erasing Board..." : isVideoBoardErased ? "Restore Board ↺" : "Clear Blackboard 🧹"}</span>
                  </button>

                  <button 
                    onClick={() => {
                      stopSpeaking();
                      setActiveLessonVideo(null);
                      setVideoPlayStatus('idle');
                    }}
                    className="text-slate-400 hover:text-white transition-colors p-1 rounded hover:bg-white/10 cursor-pointer"
                    title="Exit Cinema Mode"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>

              {/* Main Blackboard Content Screen */}
              <div className="flex-1 p-6 flex flex-col lg:flex-row gap-6 overflow-y-auto scrollbar-hide bg-radial-at-t from-slate-900 via-slate-950 to-black relative">
                {/* Smooth Felt Eraser Wipe Transition Overlay for Cinema Mode */}
                {isErasingVideoBoard && (
                  <div className="absolute inset-0 z-50 pointer-events-none overflow-hidden rounded-2xl flex items-center">
                    <div 
                      className="absolute inset-0 bg-slate-950/95 backdrop-blur-[2px] animate-wipe-reveal z-10 border-r-4 border-amber-300/40"
                      style={{
                        backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
                        backgroundSize: "20px 20px"
                      }}
                    />
                    <div className="absolute top-0 bottom-0 w-28 animate-eraser-sweep z-20 flex flex-col justify-center items-center">
                      <div className="w-16 h-40 rounded-xl bg-gradient-to-r from-amber-800 via-amber-700 to-amber-900 border-2 border-amber-950/70 shadow-[0_12px_32px_rgba(0,0,0,0.85)] relative flex flex-col justify-between p-2 transform rotate-2">
                        <div className="w-full h-1 bg-amber-500/50 rounded-full" />
                        <div className="text-[8px] font-black text-amber-100 uppercase tracking-widest text-center rotate-90 select-none drop-shadow">
                          OMNI FELT
                        </div>
                        <div className="w-full h-3.5 rounded-md bg-slate-900 border border-slate-700/80 shadow-inner flex items-center justify-around px-1">
                          <div className="w-1.5 h-1.5 rounded-full bg-white/50" />
                          <div className="w-1.5 h-1.5 rounded-full bg-white/50" />
                          <div className="w-1.5 h-1.5 rounded-full bg-white/50" />
                        </div>
                      </div>
                      <div className="absolute -left-12 top-1/4 w-32 h-32 rounded-full bg-white/15 blur-xl animate-eraser-dust pointer-events-none" />
                      <div className="absolute -left-8 bottom-1/4 w-28 h-28 rounded-full bg-amber-200/15 blur-lg animate-eraser-dust pointer-events-none" />
                    </div>
                  </div>
                )}

                {isVideoBoardErased ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-8 bg-black/40 border border-emerald-500/20 rounded-2xl space-y-4 animate-in fade-in duration-500 relative z-20">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/10 via-emerald-500/10 to-transparent border border-white/10 flex items-center justify-center text-3xl shadow-inner">
                      <span>🧹</span>
                    </div>
                    <div className="space-y-1 max-w-md">
                      <div className="text-xs font-black uppercase tracking-widest text-emerald-300">
                        Board Erased Cleanly
                      </div>
                      <p className="text-sm text-slate-300 font-medium">
                        The lecture board has been cleared for the next sub-topic. Select a guided branch below or restore previous notes.
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center justify-center gap-2 max-w-lg">
                      {[
                        { label: "📐 Next Mathematical Step", prompt: `Please explain the next mathematical step for ${activeLessonVideo.metadata?.topic || subject || 'this topic'} on the clean blackboard.` },
                        { label: "💡 Intuition & Physical Meaning", prompt: `Explain the physical intuition and practical meaning of ${activeLessonVideo.metadata?.topic || subject || 'this topic'} on the clean board.` },
                        { label: "🎨 Draw Next Schematic", prompt: `Please draw the next schematic diagram for ${activeLessonVideo.metadata?.topic || subject || 'this topic'} on the clean blackboard.` }
                      ].map((chip, cIdx) => (
                        <button
                          key={cIdx}
                          onClick={() => {
                            playChalkSound('scratch', 0.3);
                            stopSpeaking();
                            setActiveLessonVideo(null);
                            if (onSendMessage) {
                              onSendMessage(chip.prompt);
                            }
                          }}
                          className="px-3 py-1.5 rounded-xl text-xs font-bold bg-white/5 hover:bg-emerald-500/20 text-emerald-200 border border-white/10 transition cursor-pointer"
                        >
                          {chip.label}
                        </button>
                      ))}
                    </div>
                    <button
                      onClick={handleRestoreVideoBlackboard}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 transition cursor-pointer flex items-center gap-1.5"
                    >
                      <RotateCcw size={13} />
                      <span>Restore Lecture Board (↺)</span>
                    </button>
                  </div>
                ) : (
                  <>
                {/* Chalkboard Dust Overlay Texture */}
                <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-repeat" style={{ backgroundImage: "url('data:image/svg+xml,%3Csvg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cfilter id=\"noiseFilter\"%3E%3CfeTurbulence type=\"fractalNoise\" baseFrequency=\"0.65\" numOctaves=\"3\" stitchTiles=\"stitch\"/%3E%3C/filter%3E%3Crect width=\"100%25\" height=\"100%25\" filter=\"url(%23noiseFilter)\"/%3E%3C/svg%3E')" }} />

                {/* Left Column: Hand-drawn Figure (The Diagram 📐) */}
                <div className="flex-1 flex flex-col justify-center items-center min-h-[250px] lg:min-h-0 bg-black/40 border border-white/10 rounded-xl p-4 relative overflow-hidden shadow-inner">
                  {/* Render completed drawing / SVG directly without animation delay */}
                  <div className="w-full h-full flex flex-col justify-center items-center relative">
                    <div className="absolute top-2 left-2 bg-black/50 px-2 py-0.5 rounded text-[9px] font-mono text-slate-400 border border-white/5">
                      Figure board-space
                    </div>

                    {(() => {
                      const svgCode = extractSvgCode(activeLessonVideo.content);
                      if (svgCode) {
                        return (
                          <div className="w-full h-full max-h-[350px] overflow-hidden flex items-center justify-center scale-95 md:scale-100">
                            <SvgDiagramViewer
                              svgCode={svgCode}
                              theme="dark"
                              title="Lesson board diagram"
                              showNotification={showNotification}
                              isHighContrast={canvasUiManager?.state.highContrast}
                              isVectorDragMode={canvasUiManager?.state.dragHandles}
                              showVectorTelemetry={canvasUiManager?.state.vectorStats}
                              isMagnifierActive={canvasUiManager?.state.magnifier}
                              isChalkMode={canvasUiManager?.state.chalkDraw}
                              showGrid={canvasUiManager?.state.grid}
                              onToggleHighContrast={canvasUiManager?.toggleHighContrast}
                              onToggleVectorDragMode={canvasUiManager?.toggleDragHandles}
                              onToggleVectorTelemetry={canvasUiManager?.toggleVectorStats}
                              onToggleMagnifier={canvasUiManager?.toggleMagnifier}
                              onToggleChalkMode={canvasUiManager?.toggleChalkDraw}
                              onToggleGrid={canvasUiManager?.toggleGrid}
                            />
                          </div>
                        );
                      } else if (activeLessonVideo.metadata?.image) {
                        return (
                          <div className="max-w-md rounded-lg overflow-hidden border border-white/10 shadow-lg relative">
                            <img 
                              src={activeLessonVideo.metadata.image} 
                              alt="Lesson diagram" 
                              className="max-h-[300px] object-contain select-none"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-emerald-500/5 mix-blend-color pointer-events-none" />
                          </div>
                        );
                      } else {
                        // Beautiful default academic blackboard schema backup
                        return (
                          <div className="flex flex-col items-center justify-center p-6 text-center space-y-4">
                            <div className="w-24 h-24 rounded-xl border border-dashed border-white/20 flex items-center justify-center relative bg-white/[0.02]">
                              <Crosshair className="text-white/20 absolute inset-0 m-auto" size={48} />
                              <span className="text-3xl">📐</span>
                            </div>
                            <div className="space-y-1">
                              <h5 className="text-xs font-bold text-slate-300 uppercase tracking-widest">Theoretical Projection</h5>
                              <p className="text-[10px] text-slate-500 font-mono">No graphical blueprint; conceptual derivation active</p>
                            </div>
                          </div>
                        );
                      }
                    })()}
                  </div>
                </div>

                {/* Right Column: Handwritten Lecture Transcription (The Content ✍️) */}
                <div className="flex-1 flex flex-col bg-black/30 border border-white/10 rounded-xl p-4 md:p-6 overflow-y-auto scrollbar-hide relative shadow-inner min-h-[450px]">
                  <div className="absolute top-2 left-2 bg-black/50 px-2 py-0.5 rounded text-[9px] font-mono text-slate-400 border border-white/5">
                    Professor chalkboard transcription
                  </div>

                  {videoPlayStatus === 'drawing' ? (
                    /* Hide text until drawing completes to respect chronological drawing sequence */
                    <div className="flex-1 flex items-center justify-center text-slate-500 text-xs italic">
                      Waiting for figure drawing to complete...
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col h-full">
                      {/* Glowing Premium Tab Headers for Overlays */}
                      <div className="flex items-center gap-1 bg-black/60 p-1 rounded-xl border border-white/10 mb-4 z-10 shrink-0">
                        {[
                          { id: 'board', label: 'Board 📝' },
                          { id: 'transcript', label: 'Transcript 💬' },
                          { id: 'bookmarks', label: 'Bookmarks 🔖' },
                          { id: 'speed', label: 'Speed ⚡' }
                        ].map((tab) => {
                          const isActive = videoTab === tab.id;
                          return (
                            <button
                              key={tab.id}
                              onClick={() => setVideoTab(tab.id as any)}
                              className={cn(
                                "flex-1 py-1.5 text-[9px] sm:text-[10px] uppercase font-black tracking-wider rounded-lg transition-all cursor-pointer",
                                isActive
                                  ? "bg-slate-800 text-amber-300 shadow-inner border border-white/5"
                                  : "text-slate-400 hover:text-white"
                              )}
                            >
                              {tab.label}
                            </button>
                          );
                        })}
                      </div>

                      {/* Tab 1: Original Animated Board */}
                      {videoTab === 'board' && (
                        <div className="flex-1 space-y-4 font-mono leading-relaxed text-sm text-yellow-100/90 py-4 animate-in slide-in-from-bottom-3 duration-500">
                          <div className="border-b border-dashed border-white/10 pb-2 mb-2">
                            <h3 className="text-amber-300 font-extrabold text-base tracking-wide flex items-center gap-1.5">
                              📝 Lecture Summary: {activeLessonVideo.metadata?.topic || "Derivation & Principles"}
                            </h3>
                          </div>
                          
                          {/* Render TypewriterMarkdown synced in cinema mode */}
                          <TypewriterMarkdown
                            content={activeLessonVideo.content}
                            isAnimated={true}
                            isChalkSfxEnabled={isChalkSfxEnabled}
                            theme="dark"
                            speakingWordIndex={speakingMessageId === activeLessonVideo.id ? speakingWordIndex : -1}
                            isCurrentSpeaking={speakingMessageId === activeLessonVideo.id && isSpeaking}
                            isPaused={isPaused}
                            typingPace={typingPace}
                            blackboardWritingSpeed={blackboardWritingSpeed}
                            isWordHighlightingEnabled={isWordHighlightingEnabled}
                            onTypingProgress={() => {}}
                            onComplete={() => {}}
                            isLectureMode={true}
                            analyser={speakingMessageId === activeLessonVideo.id ? analyserRef.current : null}
                            onSendMessage={onSendMessage}
                            scrollDuration={300}
                            scrollEasing="smooth"
                            scrollThreshold={0.5}
                            scrollTargetCenter={0.3}
                            isAdaptiveSpeedEnabled={isAdaptiveSpeedEnabled}
                            canvasUiManager={canvasUiManager}
                            isBreathingPausesEnabled={isBreathingPausesEnabled}
                            isSpotlightEnabled={false}
                            ttsRate={ttsRate}
                            isVoiceTrackingEnabled={isVoiceTrackingEnabled}
                            isAutoScrollPaused={false}
                            pronunciationPrecision={pronunciationPrecision}
                            isRecordingAi={isRecordingAi}
                            showNotification={showNotification}
                          />

                          {/* Display verbal helper alert if active */}
                          {isSpeaking && speakingMessageId === activeLessonVideo.id && (
                            <div className="mt-4 p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-[10px] text-emerald-400 flex items-center gap-1.5">
                              <Volume2 size={12} /> Syncing blackboard typing tempo with vocal professor speeds...
                            </div>
                          )}
                        </div>
                      )}

                      {/* Tab 2: Interactive Speech Transcript */}
                      {videoTab === 'transcript' && (
                        <div className="flex-1 flex flex-col space-y-3 py-3 animate-in fade-in duration-300 relative">
                          <div className="flex items-center justify-between border-b border-white/10 pb-2">
                            <div className="flex items-center gap-2">
                              <h3 className="text-emerald-400 font-extrabold text-sm tracking-wide flex items-center gap-1.5">
                                💬 Live Speech Transcript
                              </h3>
                              {isSpeaking && speakingMessageId === activeLessonVideo.id && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                  <Radio size={10} className="text-amber-400" /> Live Narrating
                                </span>
                              )}
                            </div>
                            
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => {
                                  const nextState = !isTranscriptAutoScroll;
                                  setIsTranscriptAutoScroll(nextState);
                                  if (nextState) scrollToActiveSpeakerWord();
                                }}
                                className={cn(
                                  "px-2.5 py-1 rounded-lg text-[10px] font-mono flex items-center gap-1.5 transition-all border",
                                  isTranscriptAutoScroll
                                    ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-500/20 font-bold"
                                    : "bg-slate-800/80 border-slate-700 text-slate-400 hover:text-slate-200"
                                )}
                                title="Toggle automatic scrolling to track the active spoken word"
                              >
                                <Activity size={11} className={isTranscriptAutoScroll ? "text-emerald-400 animate-pulse" : ""} />
                                {isTranscriptAutoScroll ? "Auto-Follow: ON" : "Auto-Follow: OFF"}
                              </button>
                            </div>
                          </div>

                          {/* Search & Stats Bar */}
                          <div className="flex items-center gap-2">
                            <div className="relative flex-1">
                              <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                              <input
                                type="text"
                                placeholder="Search keywords in lecture transcript..."
                                value={transcriptSearch}
                                onChange={(e) => setTranscriptSearch(e.target.value)}
                                className="w-full bg-black/60 border border-white/10 rounded-lg pl-7 pr-7 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono transition-colors"
                              />
                              {transcriptSearch && (
                                <button
                                  onClick={() => setTranscriptSearch('')}
                                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs font-mono"
                                >
                                  ✕
                                </button>
                              )}
                            </div>

                            {/* Live Word Metric / Position */}
                            {(() => {
                              const cleanText = cleanTextForNaturalSpeech(activeLessonVideo.content, pronunciationPrecision);
                              const { wordsList } = computeUnifiedSyncWeights(cleanText);
                              const currentIdx = Math.max(0, speakingWordIndex);
                              const progressPct = wordsList.length > 0 ? Math.min(100, Math.round(((currentIdx + 1) / wordsList.length) * 100)) : 0;
                              return (
                                <div className="px-2.5 py-1.5 bg-black/50 border border-white/10 rounded-lg text-[10px] font-mono text-slate-300 whitespace-nowrap flex items-center gap-1.5">
                                  <span className="text-amber-400 font-bold">#{currentIdx + 1}</span>
                                  <span className="text-slate-500">/</span>
                                  <span>{wordsList.length} words</span>
                                  <span className="text-emerald-400 font-semibold">({progressPct}%)</span>
                                </div>
                              );
                            })()}
                          </div>

                          {/* Transcript Box with Real-time Line Pulse/Glow & Smooth Auto-Scrolling */}
                          <div 
                            ref={transcriptContainerRef}
                            onScroll={() => {
                              if (!transcriptContainerRef.current || speakingWordIndex < 0) return;
                              const container = transcriptContainerRef.current;
                              const activeEl = document.getElementById(`video-transcript-word-${speakingWordIndex}`);
                              if (activeEl) {
                                const activeTop = activeEl.offsetTop;
                                const visibleStart = container.scrollTop;
                                const visibleEnd = container.scrollTop + container.clientHeight;
                                const isVisible = activeTop >= visibleStart - 40 && activeTop <= visibleEnd + 40;
                                setIsTranscriptUserScrolled(!isVisible);
                              }
                            }}
                            className="flex-1 bg-black/50 border border-white/10 rounded-xl p-3 md:p-3.5 overflow-y-auto max-h-[290px] md:max-h-[360px] scrollbar-thin scrollbar-thumb-white/20 text-xs leading-relaxed font-mono relative scroll-smooth space-y-2"
                          >
                            {(() => {
                              const cleanText = cleanTextForNaturalSpeech(activeLessonVideo.content, pronunciationPrecision);
                              const { wordsList } = computeUnifiedSyncWeights(cleanText);
                              
                              if (wordsList.length === 0) {
                                return <div className="text-slate-500 text-center py-8">No speech transcript available.</div>;
                              }

                              // Group words into natural sentence/line segments
                              const sentenceLines: { word: string; idx: number }[][] = [];
                              let currentLine: { word: string; idx: number }[] = [];
                              for (let i = 0; i < wordsList.length; i++) {
                                currentLine.push({ word: wordsList[i], idx: i });
                                const isSentenceEnd = /[.!?]$/.test(wordsList[i]) || currentLine.length >= 18;
                                if (isSentenceEnd || i === wordsList.length - 1) {
                                  sentenceLines.push([...currentLine]);
                                  currentLine = [];
                                }
                              }

                              return (
                                <div className="space-y-2">
                                  {sentenceLines.map((line, lineIdx) => {
                                    const isLineActive = line.some(item => item.idx === speakingWordIndex);
                                    const isLinePast = line.every(item => item.idx < speakingWordIndex);

                                    return (
                                      <div
                                        key={lineIdx}
                                        className={cn(
                                          "rounded-xl p-2.5 transition-all duration-300 relative border",
                                          isLineActive
                                            ? "bg-gradient-to-r from-amber-500/15 via-amber-500/5 to-transparent border-l-4 border-l-amber-400 border-t-amber-400/20 border-r-amber-400/10 border-b-amber-400/20 shadow-[0_0_20px_rgba(245,158,11,0.18)] ring-1 ring-amber-400/30"
                                            : isLinePast
                                              ? "border-transparent bg-white/[0.02] opacity-100 hover:bg-white/[0.04]"
                                              : "border-transparent opacity-90 hover:opacity-100 hover:bg-white/[0.04]"
                                        )}
                                      >
                                        {/* Active Line Focus Header */}
                                        {isLineActive && (
                                          <div className="flex items-center gap-1.5 mb-1.5 text-[9px] font-bold text-amber-300 uppercase tracking-wider">
                                            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping inline-block" />
                                            <span>Current Spoken Sentence</span>
                                          </div>
                                        )}

                                        <div className="flex flex-wrap gap-x-1.5 gap-y-2 items-center">
                                          {line.map(({ word, idx }) => {
                                            const isCurrent = speakingWordIndex === idx;
                                            const isPast = speakingWordIndex > idx;
                                            const matchesSearch = transcriptSearch && word.toLowerCase().includes(transcriptSearch.toLowerCase());
                                            
                                            return (
                                              <span
                                                key={idx}
                                                id={`video-transcript-word-${idx}`}
                                                onClick={() => handleSeekToWord(idx)}
                                                className={cn(
                                                  "cursor-pointer px-1.5 py-0.5 rounded transition-all duration-200 inline-flex items-center gap-1 text-xs font-mono select-none relative opacity-100",
                                                  isCurrent 
                                                    ? "bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-300 text-slate-950 font-black scale-105 shadow-[0_0_15px_rgba(251,191,36,0.7)] ring-2 ring-amber-300 ring-offset-1 ring-offset-slate-950 z-10" 
                                                    : isPast 
                                                      ? "text-emerald-300 font-semibold opacity-100 hover:bg-emerald-500/20 hover:text-emerald-200" 
                                                      : "text-slate-300 opacity-90 hover:bg-white/5 hover:text-white",
                                                  matchesSearch && "border-b-2 border-yellow-400 text-yellow-300 font-black bg-yellow-400/20"
                                                )}
                                                title={`Jump speech narration to word #${idx + 1}: "${word}"`}
                                              >
                                                {isCurrent && (
                                                  <span className="w-1.5 h-1.5 rounded-full bg-slate-950 animate-ping inline-block" />
                                                )}
                                                {word}
                                              </span>
                                            );
                                          })}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              );
                            })()}
                          </div>

                          {/* Floating Re-center button if user manually scrolled away */}
                          {isTranscriptUserScrolled && speakingWordIndex >= 0 && (
                            <button
                              onClick={scrollToActiveSpeakerWord}
                              className="absolute bottom-5 right-6 bg-amber-500 hover:bg-amber-400 text-slate-950 px-3 py-1.5 rounded-full text-xs font-bold font-mono shadow-xl shadow-amber-500/30 flex items-center gap-1.5 transition-all duration-200 hover:scale-105 z-20 animate-bounce"
                            >
                              <ArrowDown size={13} className="stroke-[3]" />
                              Follow Speaker (Word #{speakingWordIndex + 1})
                            </button>
                          )}
                        </div>
                      )}

                      {/* Tab 3: Key Takeaway Bookmarks */}
                      {videoTab === 'bookmarks' && (
                        <div className="flex-1 flex flex-col space-y-3 py-4 animate-in fade-in duration-300">
                          <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-2">
                            <h3 className="text-indigo-400 font-extrabold text-sm tracking-wide flex items-center gap-1.5">
                              🔖 Key Takeaway Bookmarks
                            </h3>
                            <span className="text-[10px] font-mono text-slate-400">
                              Select any key concept card to jump
                            </span>
                          </div>

                          <div className="flex-1 overflow-y-auto max-h-[300px] md:max-h-[380px] scrollbar-hide space-y-2.5">
                            {videoBookmarks.length === 0 ? (
                              <div className="text-slate-500 text-center py-8 font-mono text-xs">Generating takeaway bookmarks...</div>
                            ) : (
                              videoBookmarks.map((bookmark, idx) => {
                                const isHeader = bookmark.type === 'header';
                                const isMilestone = bookmark.type === 'milestone';
                                const isPassed = speakingWordIndex >= bookmark.wordIdx;
                                
                                return (
                                  <div
                                    key={idx}
                                    onClick={() => handleSeekToWord(bookmark.wordIdx)}
                                    className={cn(
                                      "p-3 rounded-xl border transition-all duration-200 cursor-pointer flex items-center justify-between gap-3 text-left font-mono",
                                      isPassed
                                        ? "bg-emerald-950/20 border-emerald-500/30 hover:bg-emerald-950/30 text-slate-100"
                                        : "bg-slate-900/40 border-white/5 hover:border-white/10 hover:bg-slate-900/60 text-slate-400"
                                    )}
                                    title={`Seek to ${bookmark.timeLabel}`}
                                  >
                                    <div className="flex items-center gap-2.5">
                                      <div className={cn(
                                        "w-6 h-6 rounded-lg flex items-center justify-center text-xs shrink-0",
                                        isMilestone 
                                          ? "bg-amber-500/10 text-amber-400" 
                                          : isHeader 
                                            ? "bg-indigo-500/10 text-indigo-400" 
                                            : "bg-emerald-500/10 text-emerald-400"
                                      )}>
                                        {isMilestone ? "🏁" : isHeader ? "📜" : "💡"}
                                      </div>
                                      <div className="flex flex-col">
                                        <span className={cn(
                                          "text-xs leading-snug",
                                          isHeader ? "font-bold text-slate-200" : "font-medium text-slate-300"
                                        )}>
                                          {bookmark.label}
                                        </span>
                                        <span className="text-[9px] text-slate-500 uppercase font-bold tracking-wider mt-0.5">
                                          {bookmark.type} • {bookmark.wordIdx} words in
                                        </span>
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/60 border border-white/10 text-amber-300">
                                        ⏱️ {bookmark.timeLabel}
                                      </span>
                                      {isPassed && (
                                        <span className="text-[9px] font-bold text-emerald-400 uppercase hidden sm:inline">
                                          Seen
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                );
                              })
                            )}
                          </div>
                        </div>
                      )}

                      {/* Tab 4: Pacing and Speed Controls */}
                      {videoTab === 'speed' && (
                        <div className="flex-1 flex flex-col space-y-4 py-4 animate-in fade-in duration-300 font-mono">
                          <div className="border-b border-white/10 pb-2 mb-1">
                            <h3 className="text-amber-400 font-extrabold text-sm tracking-wide flex items-center gap-1.5">
                              ⚡ Lecture Playback Pacing
                            </h3>
                          </div>

                          {/* Speed Dial HUD */}
                          <div className="bg-black/40 border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center space-y-2 text-center relative overflow-hidden">
                            <div className="text-[10px] uppercase tracking-wider text-slate-500 font-black">ACTIVE TTS RATE</div>
                            <div className="text-4xl font-black text-amber-300 tracking-tight glow-text flex items-baseline gap-1">
                              {ttsRate.toFixed(2)}
                              <span className="text-xs text-slate-400 font-bold">x</span>
                            </div>
                            <div className="text-[11px] text-slate-400 max-w-xs leading-normal">
                              Finetune vocal projection speed and handwriting tracing delay synchronizations.
                            </div>
                          </div>

                          {/* Speed Tuning Slider */}
                          <div className="space-y-2">
                            <div className="flex justify-between text-[10px] text-slate-400">
                              <span>Slower (0.5x)</span>
                              <span>Standard (1.0x)</span>
                              <span>Faster (2.0x)</span>
                            </div>
                            <input
                              type="range"
                              min="0.5"
                              max="2.0"
                              step="0.1"
                              value={ttsRate}
                              onChange={(e) => {
                                const rate = parseFloat(e.target.value);
                                setTtsRate?.(rate);
                                localStorage.setItem('omni_tts_rate', String(rate));
                                
                                if (linkSpeeds) {
                                  let linkedPace = 'fluent';
                                  if (rate <= 0.75) linkedPace = 'deliberate';
                                  else if (rate === 1.0) linkedPace = 'fluent';
                                  else if (rate <= 1.5) linkedPace = 'swift';
                                  else linkedPace = 'instant';
                                  setTypingPace?.(linkedPace);
                                  localStorage.setItem('omni_typing_pace', linkedPace);
                                }
                              }}
                              className="w-full h-1.5 rounded-full bg-white/10 appearance-none cursor-pointer accent-amber-400"
                            />
                          </div>

                          {/* Quick Preset Buttons */}
                          <div className="space-y-1.5">
                            <div className="text-[10px] text-slate-400 uppercase font-black tracking-wider">Speed Presets</div>
                            <div className="grid grid-cols-3 gap-2">
                              {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => {
                                const isActive = ttsRate === rate;
                                return (
                                  <button
                                    key={rate}
                                    onClick={() => {
                                      setTtsRate?.(rate);
                                      localStorage.setItem('omni_tts_rate', String(rate));
                                      showNotification?.(`Speech speed updated to ${rate}x`, "success");
                                      
                                      if (linkSpeeds) {
                                        let linkedPace = 'fluent';
                                        if (rate === 0.5 || rate === 0.75) linkedPace = 'deliberate';
                                        else if (rate === 1.0) linkedPace = 'fluent';
                                        else if (rate === 1.25 || rate === 1.5) linkedPace = 'swift';
                                        else if (rate === 2.0) linkedPace = 'instant';
                                        setTypingPace?.(linkedPace);
                                        localStorage.setItem('omni_typing_pace', linkedPace);
                                      }
                                    }}
                                    className={cn(
                                      "py-2 rounded-lg text-[10px] font-black border transition-all cursor-pointer",
                                      isActive
                                        ? "bg-amber-400 text-slate-950 border-amber-300 shadow-md shadow-amber-400/10 font-extrabold"
                                        : "bg-slate-900/40 text-slate-300 border-white/5 hover:bg-slate-900/60"
                                    )}
                                  >
                                    {rate.toFixed(2)}x
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Link Speed Setting */}
                          <div className="flex items-center justify-between p-3 rounded-xl bg-black/30 border border-white/5">
                            <div className="flex flex-col text-left">
                              <span className="text-xs text-slate-200 font-bold">Synchronize Handwriting Tracing</span>
                              <span className="text-[9px] text-slate-500">Auto-align blackboard writing speed to speech rate</span>
                            </div>
                            <input
                              type="checkbox"
                              checked={linkSpeeds}
                              onChange={(e) => {
                                setLinkSpeeds?.(e.target.checked);
                                localStorage.setItem('omni_link_speeds', String(e.target.checked));
                              }}
                              className="w-4 h-4 rounded bg-slate-950 border-white/10 text-amber-400 focus:ring-0 focus:ring-offset-0 cursor-pointer text-amber-400"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                </>
                )}

              </div>

              {/* Bottom Video Controller Bar */}
              <div className="border-t border-white/10 bg-black/60 p-4 flex flex-col space-y-3 shrink-0">
                
                {/* Timeline Slider / Progress Line */}
                <div className="flex items-center gap-3">
                  <span className="text-[9px] font-mono text-slate-400 font-semibold select-none">
                    {videoPlayStatus === 'drawing' ? '00:00' : '00:04'}
                  </span>
                  
                  <div 
                    ref={timelineRef}
                    onClick={handleTimelineClick}
                    className="flex-1 h-2.5 bg-white/10 hover:bg-white/20 rounded-full relative cursor-pointer border border-white/5 group transition-all"
                    title={videoPlayStatus === 'drawing' ? "Cannot seek during figure drawing" : "Click to seek to this timeline position"}
                  >
                    {/* Hover Time Indicator Bubble */}
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-slate-900 text-yellow-300 text-[9px] font-mono px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none border border-yellow-500/20 shadow-md">
                      Seek Timeline
                    </div>
                    {/* Progress Fill */}
                    <div 
                      className={cn(
                        "h-full rounded-full transition-all duration-300 bg-gradient-to-r",
                        videoPlayStatus === 'drawing' ? "from-amber-500 to-yellow-400" : "from-emerald-500 to-teal-400"
                      )}
                      style={{ 
                        width: videoPlayStatus === 'drawing' 
                          ? `${videoDrawingProgress * 0.15}%` // Drawing is first 15% of bar
                          : videoPlayStatus === 'completed'
                            ? '100%'
                            : `${15 + (speakingWordIndex >= 0 ? (speakingWordIndex / (activeLessonVideo.content.split(/\s+/).filter(Boolean).length || 1)) : 0) * 85}%` 
                      }}
                    />
                    {/* Interactive Playhead Handle */}
                    {videoPlayStatus !== 'drawing' && (
                      <div 
                        className="absolute top-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded-full bg-white shadow-md border border-slate-900 opacity-0 group-hover:opacity-100 transition-opacity"
                        style={{
                          left: `calc(${
                            videoPlayStatus === 'completed'
                              ? '100%'
                              : `${15 + (speakingWordIndex >= 0 ? (speakingWordIndex / (activeLessonVideo.content.split(/\s+/).filter(Boolean).length || 1)) : 0) * 85}%`
                          } - 7px)`
                        }}
                      />
                    )}
                  </div>

                  <span className="text-[9px] font-mono text-slate-400 font-semibold select-none">
                    {videoPlayStatus === 'completed' ? '100%' : videoPlayStatus === 'drawing' ? 'DRAWING' : 'LECTURE'}
                  </span>
                </div>

                {/* Primary Buttons Control Row */}
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    
                    {/* Rewind 5s */}
                    <button
                      onClick={() => {
                        if (videoPlayStatus === 'writing') {
                          handleRewind();
                          showNotification?.("Rewound lecture video 5 seconds", "info");
                        }
                      }}
                      disabled={videoPlayStatus !== 'writing'}
                      className="p-1.5 rounded-lg border border-white/10 hover:bg-white/5 text-slate-300 disabled:opacity-40 transition cursor-pointer"
                      title="Rewind Narration 5s"
                    >
                      <RotateCcw size={14} />
                    </button>

                    {/* Play/Pause toggle */}
                    <button
                      onClick={() => {
                        if (videoPlayStatus === 'completed') {
                          // Replay from start
                          setVideoPlayStatus('writing');
                          setVideoDrawingProgress(100);
                          stopSpeaking();
                          const timing = calculateBoardworkTiming(activeLessonVideo.content, {
                            ttsRate,
                            typingPace,
                            blackboardWritingSpeed,
                            isAdaptiveSpeedEnabled,
                            isBreathingPausesEnabled
                          });
                          handleSpeakText(activeLessonVideo.id, activeLessonVideo.content, 0, true, timing.calculatedPlaybackRate);
                          showNotification?.("Replaying lesson from beginning 🎓", "info");
                        } else if (videoPlayStatus === 'writing') {
                          // Normal Speak Pause/Play toggle
                          handleSpeakText(activeLessonVideo.id, activeLessonVideo.content, 0, true);
                        }
                      }}
                      className={cn(
                        "p-2 rounded-xl text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 px-4 shadow-lg cursor-pointer",
                        videoPlayStatus === 'completed' 
                          ? "bg-amber-600 hover:bg-amber-500 shadow-amber-600/10" 
                          : isPaused 
                            ? "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/10"
                            : "bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/10"
                      )}
                      title={videoPlayStatus === 'completed' ? "Replay Video" : isPaused ? "Resume Narration" : "Pause Narration"}
                    >
                      {videoPlayStatus === 'completed' ? (
                        <>
                          <RotateCcw size={13} />
                          <span>Replay</span>
                        </>
                      ) : isPaused ? (
                        <>
                          <Play size={13} className="fill-white" />
                          <span>Resume</span>
                        </>
                      ) : (
                        <>
                          <Pause size={13} className="fill-white" />
                          <span>Pause</span>
                        </>
                      )}
                    </button>

                    {/* Fast Forward 5s */}
                    <button
                      onClick={() => {
                        if (videoPlayStatus === 'writing') {
                          handleForward();
                          showNotification?.("Skipped ahead 5 seconds", "info");
                        }
                      }}
                      disabled={videoPlayStatus !== 'writing'}
                      className="p-1.5 rounded-lg border border-white/10 hover:bg-white/5 text-slate-300 disabled:opacity-40 transition cursor-pointer"
                      title="Skip Ahead 5s"
                    >
                      <Play size={14} className="rotate-0 shrink-0 fill-current" />
                    </button>

                  </div>

                  {/* Right side completed-only actions */}
                  <div className="flex items-center gap-2">
                    {videoPlayStatus === 'completed' ? (
                      <div className="flex items-center gap-2 animate-in fade-in slide-in-from-right-3 duration-500">
                        {/* Take practice quiz */}
                        <button
                          onClick={() => {
                            setActiveLessonVideo(null);
                            handleGenerateChalkboardQuiz(activeLessonVideo);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer shadow-md"
                          title="Generate instant whiteboard assessment questions"
                        >
                          📝 Practice Quiz
                        </button>
                        {/* Export to study notes */}
                        <button
                          onClick={() => {
                            if (onSaveToNotes) {
                              onSaveToNotes({
                                title: activeLessonVideo.metadata?.topic || "Whiteboard Class Lecture Summary",
                                summary: activeLessonVideo.content,
                                keyConcepts: [subject || "Core Concepts", "WHITEBOARD_NOTES"],
                                subject: subject || "Physics",
                                topic: activeLessonVideo.metadata?.topic || "Whiteboard Class Lecture"
                              });
                              showNotification?.("Whiteboard boards exported to Personal Notebook successfully! 📒", "success");
                            }
                          }}
                          className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer shadow-md"
                          title="Save compilation to Notebook"
                        >
                          📒 Save Notes
                        </button>
                      </div>
                    ) : (
                      <span className="text-[10px] font-mono text-slate-400 italic">
                        {videoPlayStatus === 'drawing' ? 'Sketching professor diagram...' : 'Speaking lecture points...'}
                      </span>
                    )}

                    <button
                      onClick={() => {
                        stopSpeaking();
                        setActiveLessonVideo(null);
                        setVideoPlayStatus('idle');
                      }}
                      className="px-3 py-1.5 rounded-lg border border-white/20 hover:border-white/40 hover:bg-white/5 text-white text-xs font-black uppercase tracking-widest cursor-pointer"
                      title="Exit Classroom Video View"
                    >
                      Close Player
                    </button>
                  </div>

                </div>

              </div>

            </div>
          </div>
        )}

        {/* Screen Recording Live Status Bar */}
        <AnimatePresence>
          {screenRecordingState !== 'idle' && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={cn(
                "w-full flex items-center justify-between px-4 py-2 border-b font-semibold z-10 shadow-sm backdrop-blur-md transition-all shrink-0",
                screenRecordingState === 'recording'
                  ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                  : "bg-amber-500/10 border-amber-500/20 text-amber-400"
              )}
            >
              <div className="flex items-center gap-2.5">
                <span className="relative flex h-2 w-2">
                  {screenRecordingState === 'recording' && (
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  )}
                  <span className={cn(
                    "relative inline-flex rounded-full h-2 w-2",
                    screenRecordingState === 'recording' ? "bg-rose-500" : "bg-amber-500"
                  )}></span>
                </span>
                <span className="font-extrabold tracking-wider uppercase text-[10px]">
                  {screenRecordingState === 'recording' ? "LIVE SCREEN RECORDING ACTIVE" : "SCREEN RECORDING PAUSED"}
                </span>
                <span className="font-mono bg-slate-900/60 text-slate-300 px-2 py-0.5 rounded-md border border-slate-800">
                  {Math.floor(screenRecordingDuration / 60)}:{String(screenRecordingDuration % 60).padStart(2, '0')}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                {screenRecordingState === 'recording' ? (
                  <button
                    type="button"
                    onClick={pauseScreenRecording}
                    className="p-1 px-2.5 rounded-lg border border-rose-500/30 hover:bg-rose-500/20 transition-all text-[11px] font-bold cursor-pointer"
                    title="Pause Recording"
                  >
                    Pause
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={resumeScreenRecording}
                    className="p-1 px-2.5 rounded-lg border border-amber-500/30 hover:bg-amber-500/20 transition-all text-[11px] font-bold cursor-pointer"
                    title="Resume Recording"
                  >
                    Resume
                  </button>
                )}
                <button
                  type="button"
                  onClick={stopScreenRecording}
                  className="p-1 px-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white transition-all text-[11px] font-bold cursor-pointer flex items-center gap-1 shadow-md shadow-rose-500/20"
                  title="Stop Recording & Save Preview"
                >
                  <Square size={10} className="fill-white" />
                  <span>Stop & Save</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      <div ref={mainScrollContainerRef} onScroll={handleContainerScroll} onDoubleClick={(e) => handleChatDoubleClick(e)} className="messages-scroll-container flex-1 overflow-y-auto pt-4 pb-6 md:pt-6 md:pb-6 scroll-smooth space-y-5 md:space-y-8 scrollbar-hide cursor-pointer">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-60">
            <div className="w-20 h-20 rounded-3xl overflow-hidden shadow-2xl shadow-indigo-500/20 border border-white/20 bg-slate-950 flex items-center justify-center animate-pulse">
              <img 
                src="/app-icon.jpg" 
                alt="Omni AI App Icon" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="space-y-2">
              <h3 className={cn(
                "text-2xl font-black tracking-tight",
                theme === 'dark' ? "text-white" : "text-slate-900"
              )}>
                How can I help you today?
              </h3>
              <p className="text-sm text-slate-500 max-w-[300px] mx-auto">
                Ask me anything about math, science, or any other subject. I'm here to tutor you!
              </p>
            </div>
          </div>
        )}

        <AnimatePresence initial={false}>
          {/* Global Classroom Mute / 2D Diagram Silent-Mode Status Banner */}
          {(isClassroomMute || isDiagramRendering) && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.98 }}
              className="sticky top-2 z-50 mb-4 px-4 py-2.5 rounded-xl bg-slate-900/95 border border-emerald-500/50 text-emerald-300 shadow-xl backdrop-blur-md flex items-center justify-between gap-3 text-xs"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
                  <VolumeX size={13} className="text-emerald-400 animate-pulse" />
                </div>
                <div className="truncate">
                  <span className="font-bold text-white">Classroom Silent Mode:</span>
                  <span className="text-emerald-200/90 ml-1.5 font-medium">AI paused speech while drawing 2D vector schematic...</span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Muted
                </span>
              </div>
            </motion.div>
          )}

          {/* Persistent Docked Sticky Pinned Diagram Banner */}
          {pinnedDiagram && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="sticky top-2 z-40 mb-6 p-3 sm:p-4 rounded-2xl bg-slate-900/95 border border-indigo-500/40 shadow-2xl backdrop-blur-md"
            >
              <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-extrabold text-xs shadow-md">
                    <Pin size={13} className="fill-slate-950" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white flex items-center gap-2">
                      {pinnedDiagram.title || 'Pinned Reference Diagram'}
                      <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-mono">
                        Docked at Top
                      </span>
                    </h4>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setIsPinnedDiagramMinimized(!isPinnedDiagramMinimized)}
                    className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition cursor-pointer flex items-center gap-1"
                    title={isPinnedDiagramMinimized ? "Expand pinned diagram" : "Minimize pinned diagram"}
                  >
                    {isPinnedDiagramMinimized ? <Maximize2 size={13} /> : <Minimize2 size={13} />}
                    {isPinnedDiagramMinimized ? 'Expand' : 'Minimize'}
                  </button>
                  <button
                    onClick={() => {
                      setPinnedDiagram(null);
                      showNotification?.('Diagram unpinned from top.', 'info');
                    }}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 hover:text-rose-300 text-slate-400 transition cursor-pointer"
                    title="Unpin diagram"
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>

              {!isPinnedDiagramMinimized && (
                <div className="flex flex-col sm:flex-row items-center gap-4 pt-1">
                  <div className="relative rounded-xl overflow-hidden border border-white/10 max-h-[180px] max-w-[280px] shrink-0 bg-slate-950 shadow-inner">
                    <img 
                      src={pinnedDiagram.image} 
                      alt="Pinned Reference Diagram" 
                      className="w-full h-full object-cover max-h-[170px]"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1 space-y-2 text-xs text-slate-300">
                    <p className="font-semibold text-slate-200">
                      📌 This reference diagram remains anchored at the top of your chat view while you continue learning!
                    </p>
                    {pinnedDiagram.annotations && pinnedDiagram.annotations.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {pinnedDiagram.annotations.map((anno: any, i: number) => (
                          <span key={i} className="px-2 py-0.5 rounded-md bg-indigo-950/80 border border-indigo-500/30 text-indigo-300 font-mono text-[10px]">
                            #{i+1}: {anno.label}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="pt-1 flex items-center gap-2">
                      <button
                        onClick={() => {
                          const el = document.getElementById(`diagram-image-${pinnedDiagram.msgId}`);
                          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        }}
                        className="text-[11px] font-bold text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
                      >
                        Jump to Original Message
                      </button>
                      <button
                        onClick={() => setIsVennBuilderOpen(true)}
                        className="px-2 py-1 rounded bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 font-bold text-[10px] cursor-pointer"
                      >
                        🎨 Open Venn Builder
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}



          {pinnedMessages.length > 0 && (
            <div className="mb-6 p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20">
              <div className="flex items-center gap-2 mb-3 text-indigo-400 font-bold text-xs uppercase tracking-wider">
                <Pin size={14} /> Pinned Messages ({pinnedMessages.length})
              </div>
              <div className="space-y-3">
                {pinnedMessages.map(msg => (
                  <div key={`pinned-${msg.id}`} className="text-sm p-3 rounded-xl bg-white/5 border border-white/5 text-slate-200">
                    {msg.content.substring(0, 100)}{msg.content.length > 100 ? '...' : ''}
                    <button onClick={() => togglePin(msg.id)} className="ml-2 text-indigo-400 hover:text-indigo-300">
                      <Pin size={12} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Active Verbal Lecture Question & State-Based Video Resumption Banner */}
          {activeVerbalQuestion && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "mb-6 p-4 rounded-2xl border shadow-xl flex flex-col gap-3 transition-all",
                activeVerbalQuestion.status === 'correct'
                  ? "bg-emerald-950/90 border-emerald-500/50 text-emerald-200"
                  : "bg-indigo-950/90 border-amber-500/50 text-amber-100 animate-pulse"
              )}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider">
                  {activeVerbalQuestion.status === 'correct' ? (
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <Check size={16} /> Question Solved — Video Content Resumed
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 text-amber-400">
                      <HelpCircle size={16} className="animate-spin" /> Lecture Question Active — Video Content Paused
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-md bg-black/40 text-[10px] font-mono text-slate-300">
                    Status: {activeVerbalQuestion.status.toUpperCase()}
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveVerbalQuestion(null)}
                    className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                    title="Dismiss Question"
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>

              <div className="text-sm font-semibold text-white bg-black/30 p-3 rounded-xl border border-white/10">
                "{activeVerbalQuestion.questionText}"
              </div>

              {activeVerbalQuestion.feedback && (
                <p className={cn(
                  "text-xs font-bold px-2.5 py-1.5 rounded-lg border",
                  activeVerbalQuestion.status === 'correct'
                    ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300"
                    : "bg-amber-500/20 border-amber-500/40 text-amber-300"
                )}>
                  {activeVerbalQuestion.feedback}
                </p>
              )}

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-white/10">
                <div className="flex items-center gap-2 text-[11px] opacity-80">
                  <span>Speak your reply via mic or type in chat to evaluate and trigger video resumption.</span>
                </div>
                <div className="flex items-center gap-2">
                  {activeVerbalQuestion.status === 'pending' && (
                    <>
                      <button
                        type="button"
                        onClick={() => {
                          if (!isRecording) onToggleVoice();
                          showNotification?.("Listening for your verbal answer...", "info");
                        }}
                        className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs uppercase tracking-wider hover:bg-amber-400 cursor-pointer flex items-center gap-1.5 transition-all shadow-md shadow-amber-500/20"
                      >
                        <Mic size={14} />
                        <span>{isRecording ? "Listening..." : "Speak Reply"}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (input.trim()) {
                            handleEvaluateVerbalLectureReply(input);
                            setInput('');
                          } else {
                            showNotification?.("Type your answer in the chat box or use Speak Reply!", "info");
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600 text-white font-black text-xs uppercase tracking-wider hover:bg-indigo-500 cursor-pointer flex items-center gap-1.5 transition-all shadow-md shadow-indigo-600/20"
                      >
                        <span>Verify Answer</span>
                      </button>
                    </>
                  )}
                  {activeVerbalQuestion.status === 'correct' && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsLectureVideoPlaying(true);
                        showNotification?.("Video content playing...", "info");
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs uppercase tracking-wider hover:bg-emerald-400 cursor-pointer flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/20"
                    >
                      <Play size={14} />
                      <span>Video Content Resumed</span>
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {localMessages.map((msg) => (
            <React.Fragment key={msg.id}>
              <motion.div
                onDoubleClick={(e) => handleChatDoubleClick(e, msg.id)}
                key={msg.id}
              initial={{ 
                opacity: 0, 
                y: 15, 
                x: msg.sender === 'user' ? 12 : -12,
                scale: 0.98 
              }}
              animate={{ 
                opacity: 1, 
                y: 0, 
                x: 0,
                scale: 1 
              }}
              exit={{ 
                opacity: 0, 
                y: -10, 
                scale: 0.98, 
                transition: { duration: 0.15 } 
              }}
              transition={{ 
                type: "spring",
                stiffness: 280,
                damping: 24,
                mass: 0.8
              }}
              className={cn(
                "flex w-full gap-2 sm:gap-3",
                msg.sender === 'user' ? "flex-row-reverse" : "flex-row"
              )}
            >
              <button 
                onClick={() => togglePin(msg.id)}
                className={cn(
                  "p-1 rounded transition-colors self-start mt-2",
                  pinnedMessageIds.has(msg.id) ? "text-indigo-500" : "text-slate-400 hover:text-indigo-500"
                )}
                title="Pin message"
              >
                <Pin size={14} />
              </button>
              <div className="flex items-center gap-1 self-start mt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingMessageId(msg.id);
                      setEditingContent(msg.content);
                      showNotification?.('Editing message inline...', 'info');
                    }}
                    title="Edit message inline"
                    className={cn(
                      "w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm transition-all duration-300 cursor-pointer",
                      "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 hover:text-indigo-600 active:scale-95"
                    )}
                  >
                    <Edit3 size={14} />
                  </button>
                </div>
              {!isLectureMode && (
                <div className={cn(
                  "w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-1 shadow-sm",
                  msg.sender === 'user' ? "hidden" : "bg-gradient-to-br from-indigo-600 to-violet-700 text-white"
                )}>
                  <Sparkles size={14} />
                </div>
              )}

              {msg.sender === 'ai' && isLectureMode ? (
                <div className={cn(
                  "relative overflow-hidden transition-all duration-300 select-none shadow-xl rounded-2xl border border-slate-700/60 bg-slate-900/95 text-slate-100",
                  maximizedMessageId === msg.id 
                    ? "fixed inset-0 w-screen h-dvh z-[9999] p-8 md:p-12 overflow-y-auto flex flex-col justify-between" 
                    : "w-full max-w-full md:max-w-[95%] p-4 sm:p-6 my-2 sm:my-4"
                )}>
                  {maximizedMessageId === msg.id && (
                    <button 
                      onClick={() => {
                        playChalkClickSound();
                        setMaximizedMessageId(null);
                      }}
                      className="absolute top-4 right-4 z-[10000] p-2.5 rounded-full bg-black/40 border border-white/10 text-white/70 hover:text-white hover:bg-white/15 hover:scale-105 active:scale-95 transition-all cursor-pointer"
                      title="Exit Fullscreen"
                    >
                      <Minimize2 size={20} />
                    </button>
                  )}
                  {/* Clean Background Grid Guidelines */}
                  <div className={cn(
                    "absolute inset-0 pointer-events-none transition-all duration-300 z-0 opacity-40",
                    chalkboardGridStyle === 'graph-grid'
                      ? "bg-[linear-gradient(to_right,rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:24px_24px]"
                      : chalkboardGridStyle === 'fine-mesh'
                      ? "bg-[linear-gradient(to_right,rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:12px_12px]"
                      : chalkboardGridStyle === 'dot-matrix'
                      ? "bg-[radial-gradient(rgba(255,255,255,0.12)_1px,transparent_1px)] bg-[size:20px_20px]"
                      : "bg-[linear-gradient(rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:100%_28px]"
                  )} />

                  {/* Instructor Bio Panel & Initialization Signal */}
                  {initializingLessonMessageId === msg.id && (
                    <div className="mb-4 p-3 rounded-xl bg-gradient-to-r from-emerald-500/20 via-teal-500/20 to-emerald-500/20 border border-emerald-400/50 backdrop-blur-md shadow-lg shadow-emerald-950/40 animate-pulse flex items-center justify-between text-xs text-emerald-200">
                      <div className="flex items-center gap-2.5">
                        <span className="relative flex h-3 w-3">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                        </span>
                        <span className="font-bold tracking-wide">
                          ⚡ Initializing Virtual Lesson Environment • Calibrating blackboard, voice synthesizer & interactive visualizers...
                        </span>
                      </div>
                      <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-300 font-black px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-400/30">
                        Synchronizing
                      </span>
                    </div>
                  )}

                  {!readyMessages.has(msg.id) && (
                    <button
                      onClick={() => handleInitiateVirtualLesson(msg)}
                      disabled={initializingLessonMessageId === msg.id}
                      className={cn(
                        "w-full text-white font-black uppercase tracking-wider py-3.5 px-4 rounded-xl mb-4 transition-all flex items-center justify-center gap-2 text-xs border border-white/10 cursor-pointer shadow-lg relative overflow-hidden",
                        initializingLessonMessageId === msg.id
                          ? "bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600 ring-4 ring-emerald-400/50 animate-pulse shadow-emerald-500/30 cursor-wait"
                          : lectureSubMode === 'video_classroom'
                          ? "bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-500 hover:to-rose-500 shadow-red-950/40"
                          : "bg-emerald-600 hover:bg-emerald-700 hover:shadow-emerald-600/30"
                      )}
                    >
                      {initializingLessonMessageId === msg.id ? (
                        <>
                          <Sparkles size={15} className="animate-spin text-amber-300" />
                          <span className="animate-pulse">Initializing Virtual Lesson Environment...</span>
                          <span className="inline-flex h-2 w-2 rounded-full bg-white animate-ping ml-1" />
                        </>
                      ) : lectureSubMode === 'video_classroom' ? (
                        <>
                          <Film size={14} />
                          <span>🎬 Start Video Classroom Lesson</span>
                        </>
                      ) : (
                        <>
                          <Play size={13} className="fill-white" />
                          <span>Start Lesson</span>
                        </>
                      )}
                    </button>
                  )}
                  <div className="flex items-center gap-3 mb-5 border-b border-white/10 pb-4 relative z-20">
                    <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-2xl relative shadow-inner">
                      {PERSONAS.find(p => p.id === selectedPersonaId)?.icon || '👨‍🏫'}
                      {speakingMessageId === msg.id && isSpeaking && !isPaused && (
                        <span className="absolute -top-1 -right-1 flex h-3 w-3">
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                        </span>
                      )}
                    </div>
                    <div>
                      <div className="text-xs font-black uppercase text-emerald-300 tracking-wider flex items-center gap-1.5 flex-wrap">
                        {PERSONAS.find(p => p.id === selectedPersonaId)?.name || 'Omni Teacher'}
                        <span className="text-[8px] font-black px-1.5 py-0.5 bg-emerald-400/10 text-emerald-200 rounded-full border border-emerald-400/20 tracking-wider">
                          PROFESSOR
                        </span>
                        
                        {/* Chalk Color Palette Selector */}
                        <div className="ml-2 flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded-lg border border-white/15 text-[9px] shadow-sm">
                          <span className="text-white/80 font-bold flex items-center gap-1">
                            <span>🖍️ Chalk:</span>
                          </span>
                          {CHALK_COLOR_PALETTES.map(col => {
                            const isSelected = activeChalkColor === col.id;
                            return (
                              <button
                                key={col.id}
                                onClick={() => {
                                  setActiveChalkColor(col.id);
                                  localStorage.setItem('omni_active_chalk_color', col.id);
                                  window.dispatchEvent(new Event('omni_chalk_settings_changed'));
                                  playChalkColorSwitchSound(col.id);
                                  showNotification?.(`Chalk stick switched to ${col.name} 🖍️ (Auto-applied to new derivations & diagrams)`, 'success');
                                }}
                                className={cn(
                                  "px-1.5 py-0.5 rounded font-black transition cursor-pointer flex items-center gap-1 text-[9px] border",
                                  isSelected 
                                    ? `${col.bgClass} ${col.textClass} ${col.borderClass} shadow-md scale-105 ring-1 ring-white/50` 
                                    : "bg-white/5 text-white/70 border-white/10 hover:text-white hover:bg-white/10"
                                )}
                                title={`Select ${col.name}: Applies to blackboard handwriting, math derivation strokes & vector diagrams`}
                              >
                                <span className={cn("w-2 h-2 rounded-full inline-block border border-black/30", col.bgClass)} />
                                <span>{col.label}</span>
                              </button>
                            );
                          })}
                        </div>

                        {/* Dedicated Professor Narrator (Lecture Mode) Voice & Pacing Toggle */}
                        <button
                          onClick={() => {
                            const next = !isProfessorNarrator;
                            setIsProfessorNarrator(next);
                            localStorage.setItem('omni_professor_narrator', next ? 'true' : 'false');
                            window.dispatchEvent(new Event('omni_chalk_settings_changed'));
                            playChalkSound('tap', 0.35);
                            showNotification?.(
                              next ? '🎓 Professor Narrator Active: Formal Lecture Voice synchronized with blackboard drawing cadence' : 'Professor Narrator Standard Voice Restored', 
                              'info'
                            );
                          }}
                          className={cn(
                            "ml-1 px-2 py-0.5 rounded text-[9px] font-black uppercase transition cursor-pointer border flex items-center gap-1 shadow-sm active:scale-95",
                            isProfessorNarrator
                              ? "bg-emerald-500 text-slate-950 border-emerald-300 font-black shadow-emerald-500/30 ring-1 ring-emerald-400/50"
                              : "bg-black/30 text-white/70 border-white/10 hover:text-white"
                          )}
                          title="Professor Narrator Toggle: Forces AI speech engine into highly formal, authoritative Lecture Mode voice maintaining steady cadence synchronized with blackboard drawing"
                        >
                          <span>🎓 Narrator: {isProfessorNarrator ? 'LECTURE ON' : 'OFF'}</span>
                        </button>

                        {/* Zoom to Focus Toggle & Indicator */}
                        <button
                          onClick={() => {
                            const next = !isZoomToFocusEnabled;
                            setIsZoomToFocusEnabled(next);
                            localStorage.setItem('omni_zoom_to_focus_enabled', next ? 'true' : 'false');
                            window.dispatchEvent(new Event('omni_chalk_settings_changed'));
                            playChalkSound('tap', 0.3);
                            showNotification?.(
                              next ? '🔍 Zoom to Focus: ACTIVE (Auto-pans & magnifies equations/diagrams for fine mobile details)' : 'Zoom to Focus: MANUAL (Click any equation or diagram to focus)', 
                              'info'
                            );
                          }}
                          className={cn(
                            "ml-1 px-2 py-0.5 rounded text-[9px] font-black uppercase transition cursor-pointer border flex items-center gap-1 shadow-sm active:scale-95",
                            isZoomToFocusEnabled
                              ? "bg-cyan-500/25 text-cyan-200 border-cyan-400/50 font-black ring-1 ring-cyan-400/30"
                              : "bg-black/30 text-white/60 border-white/10 hover:text-white"
                          )}
                          title="Zoom to Focus: Automated smooth pan-and-zoom animation highlighting active equations and diagrams for fine mobile visibility"
                        >
                          <span>🔍 Zoom Focus: {isZoomToFocusEnabled ? 'AUTO' : 'MANUAL'}</span>
                        </button>

                        {/* Real-time Synchronize with Class Button */}
                        <div className="ml-1">
                          <ClassroomSyncControl
                            currentBoardContent={cleanBlackboardContent(msg.content)}
                            currentTopicTitle="Classroom Slate"
                            currentChalkColor={activeChalkColor}
                            showNotification={showNotification}
                          />
                        </div>

                        {/* Chalkboard Typography Quick Selectors */}
                        <div className="ml-2 flex items-center gap-1 bg-black/30 px-2 py-0.5 rounded-lg border border-white/10 text-[9px]">
                          <span className="text-white/60 font-bold">Theme:</span>
                          {(['classic-green', 'midnight-slate', 'sepia-manuscript', 'forest-chalk'] as const).map(t => (
                            <button
                              key={t}
                              onClick={() => {
                                setChalkboardThemeStyle(t);
                                localStorage.setItem('omni_chalkboard_theme_style', t);
                                showNotification?.(`Chalkboard theme switched to ${t.replace('-', ' ')}`, 'success');
                              }}
                              className={cn(
                                "px-1.5 py-0.5 rounded font-bold uppercase transition cursor-pointer",
                                chalkboardThemeStyle === t ? "bg-emerald-500 text-slate-950 font-black shadow-sm" : "text-white/70 hover:text-white"
                              )}
                              title={`Switch to ${t} chalkboard theme`}
                            >
                              {t === 'classic-green' ? '🟢 Green' : t === 'midnight-slate' ? '🌌 Slate' : t === 'sepia-manuscript' ? '📜 Sepia' : '🌲 Forest'}
                            </button>
                          ))}
                        </div>

                        {/* Chalkboard Grid Overlay Quick Selectors */}
                        <div className="ml-1 flex items-center gap-1 bg-black/30 px-2 py-0.5 rounded-lg border border-white/10 text-[9px]">
                          <span className="text-white/60 font-bold">Grid Overlay:</span>
                          {(['graph-grid', 'fine-mesh', 'dot-matrix', 'lines'] as const).map(g => (
                            <button
                              key={g}
                              onClick={() => {
                                setChalkboardGridStyle(g);
                                localStorage.setItem('omni_chalkboard_grid_style', g);
                                playChalkSound('tap');
                                showNotification?.(`Chalkboard grid overlay set to ${g.replace('-', ' ')}`, 'info');
                              }}
                              className={cn(
                                "px-1.5 py-0.5 rounded font-bold uppercase transition cursor-pointer",
                                chalkboardGridStyle === g ? "bg-indigo-500 text-white font-black shadow-sm" : "text-white/70 hover:text-white"
                              )}
                              title={`Switch to ${g.replace('-', ' ')} grid alignment overlay`}
                            >
                              {g === 'graph-grid' ? '▦ Graph' : g === 'fine-mesh' ? '⩰ Fine' : g === 'dot-matrix' ? '• Dots' : '≡ Lines'}
                            </button>
                          ))}
                        </div>

                        {/* Drawing Style Selector */}
                        <div className="ml-1 flex items-center gap-1 bg-black/30 px-2 py-0.5 rounded-lg border border-white/10 text-[9px]">
                          <span className="text-white/60 font-bold">Style:</span>
                          <button
                            onClick={() => {
                              setChalkboardDrawingStyle('hand-drawn');
                              localStorage.setItem('omni_chalkboard_drawing_style', 'hand-drawn');
                              playChalkSound('scratch');
                              showNotification?.('Chalkboard style set to Hand-Drawn Sketch ✏️', 'info');
                            }}
                            className={cn(
                              "px-1.5 py-0.5 rounded font-bold uppercase transition cursor-pointer flex items-center gap-1",
                              chalkboardDrawingStyle === 'hand-drawn' ? "bg-amber-500 text-slate-950 font-black shadow-sm" : "text-white/70 hover:text-white"
                            )}
                            title="Hand-Drawn Sketch Style: Informal professor sketch with organic chalk strokes & notes"
                          >
                            ✏️ Hand-Drawn
                          </button>
                          <button
                            onClick={() => {
                              setChalkboardDrawingStyle('clean-academic');
                              localStorage.setItem('omni_chalkboard_drawing_style', 'clean-academic');
                              playChalkSound('tap');
                              showNotification?.('Chalkboard style set to Clean Academic Boardwork 📐', 'info');
                            }}
                            className={cn(
                              "px-1.5 py-0.5 rounded font-bold uppercase transition cursor-pointer flex items-center gap-1",
                              chalkboardDrawingStyle === 'clean-academic' ? "bg-indigo-500 text-white font-black shadow-sm" : "text-white/70 hover:text-white"
                            )}
                            title="Clean Academic Style: Formal structured boardwork with precise diagrams"
                          >
                            📐 Clean Academic
                          </button>
                        </div>

                        {/* Blackboard Eraser Tool & Style Selectors */}
                        <div className="ml-1 flex items-center gap-1 bg-black/30 px-2 py-0.5 rounded-lg border border-white/10 text-[9px]">
                          <span className="text-amber-400 font-bold flex items-center gap-1">
                            <Eraser size={10} />
                            Eraser:
                          </span>
                          {(['classic-felt', 'dry-cloth', 'sponge-wipe'] as const).map(style => (
                            <button
                              key={style}
                              onClick={() => {
                                setEraserStyle(style);
                                localStorage.setItem('omni_eraser_style', style);
                                window.dispatchEvent(new Event('omni_eraser_settings_changed'));
                                if (style === 'sponge-wipe') playChalkSound('tap');
                                else if (style === 'dry-cloth') playChalkSound('dust');
                                else playChalkSound('scratch');
                                showNotification?.(`Blackboard eraser set to ${style === 'classic-felt' ? '🪵 Classic Felt' : style === 'dry-cloth' ? '🧣 Dry Cloth' : '🧽 Sponge Wipe'}`, 'info');
                              }}
                              className={cn(
                                "px-1.5 py-0.5 rounded font-bold uppercase transition cursor-pointer flex items-center gap-1",
                                eraserStyle === style ? "bg-amber-500 text-slate-950 font-black shadow-sm" : "text-white/70 hover:text-white"
                              )}
                              title={`Switch to ${style.replace('-', ' ')}`}
                            >
                              {style === 'classic-felt' ? '🪵 Felt' : style === 'dry-cloth' ? '🧣 Cloth' : '🧽 Sponge'}
                            </button>
                          ))}
                        </div>

                        {/* Wipe Speed & Dust Density Quick Controls */}
                        <div className="ml-1 flex items-center gap-1 bg-black/30 px-1.5 py-0.5 rounded-lg border border-white/10 text-[9px]">
                          <button
                            onClick={() => {
                              const nextSpd: BlackboardEraserSpeed = eraserSpeed === 'normal' ? 'fast' : eraserSpeed === 'fast' ? 'slow' : 'normal';
                              setEraserSpeed(nextSpd);
                              localStorage.setItem('omni_eraser_speed', nextSpd);
                              window.dispatchEvent(new Event('omni_eraser_settings_changed'));
                              showNotification?.(`Wipe transition speed: ${nextSpd.toUpperCase()} (${nextSpd === 'fast' ? '0.7s' : nextSpd === 'slow' ? '2.0s' : '1.2s'})`, 'info');
                            }}
                            className="px-1.5 py-0.5 rounded text-amber-300 hover:text-white transition cursor-pointer font-bold"
                            title="Cycle eraser wipe transition speed (Fast / Normal / Slow)"
                          >
                            ⏱️ {eraserSpeed === 'fast' ? 'Fast' : eraserSpeed === 'slow' ? 'Slow' : 'Normal'}
                          </button>
                          <span className="text-white/20">|</span>
                          <button
                            onClick={() => {
                              const nextDst: BlackboardDustDensity = eraserDustDensity === 'medium' ? 'high' : eraserDustDensity === 'high' ? 'low' : 'medium';
                              setEraserDustDensity(nextDst);
                              localStorage.setItem('omni_eraser_dust_density', nextDst);
                              window.dispatchEvent(new Event('omni_eraser_settings_changed'));
                              playChalkSound('dust');
                              showNotification?.(`Chalk dust particle density: ${nextDst.toUpperCase()}`, 'info');
                            }}
                            className="px-1.5 py-0.5 rounded text-indigo-300 hover:text-white transition cursor-pointer font-bold"
                            title="Cycle chalk dust particle density (Low / Med / High)"
                          >
                            💨 {eraserDustDensity === 'low' ? 'Low Dust' : eraserDustDensity === 'high' ? 'High Dust' : 'Med Dust'}
                          </button>
                        </div>

                        {/* Dust Texture Overlay Toggle */}
                        <button
                          onClick={() => {
                            const next = !showChalkDustOverlay;
                            setShowChalkDustOverlay(next);
                            localStorage.setItem('omni_chalkboard_dust_overlay', next ? 'true' : 'false');
                            playChalkSound('dust');
                            showNotification?.(`Chalkboard dust & texture overlay: ${next ? 'ON 🌫️' : 'OFF'}`, 'info');
                          }}
                          className={cn(
                            "ml-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase transition cursor-pointer border flex items-center gap-1",
                            showChalkDustOverlay ? "bg-amber-400/20 text-amber-300 border-amber-400/40 font-black" : "bg-black/30 text-white/60 border-white/10 hover:text-white"
                          )}
                          title="Toggle subtle dust & chalk texture overlay on generated diagrams and blackboard canvas"
                        >
                          🌫️ Dust: {showChalkDustOverlay ? 'ON' : 'OFF'}
                        </button>

                        {/* Sound FX Toggle & Test Trigger */}
                        <button
                          onClick={() => {
                            const next = !chalkSoundState;
                            setChalkSoundState(next);
                            setChalkSoundEnabled(next);
                            if (next) playChalkSound('sequence');
                            showNotification?.(`Chalkboard sound FX: ${next ? 'ON 🔊' : 'MUTED 🔇'}`, 'info');
                          }}
                          className={cn(
                            "ml-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase transition cursor-pointer border flex items-center gap-1",
                            chalkSoundState ? "bg-emerald-400/20 text-emerald-300 border-emerald-400/40 font-black" : "bg-black/30 text-white/60 border-white/10 hover:text-white"
                          )}
                          title="Toggle realistic chalkboard sound FX (chalk scratching, tapping, eraser dusting)"
                        >
                          {chalkSoundState ? '🔊 SFX' : '🔇 Muted'}
                        </button>

                        {/* Board History Timeline Toggle Button */}
                        {boardWipeHistory.length > 0 && (
                          <button
                            onClick={() => {
                              const next = !isBoardHistoryOpen;
                              setIsBoardHistoryOpen(next);
                              if (next && activeBoardHistoryIndex === null) {
                                setActiveBoardHistoryIndex(boardWipeHistory.length - 1);
                              }
                              playChalkSound('tap');
                            }}
                            className={cn(
                              "ml-1 px-2 py-0.5 rounded text-[9px] font-black uppercase transition cursor-pointer border flex items-center gap-1 shadow-sm active:scale-95",
                              isBoardHistoryOpen || activeBoardHistoryIndex !== null
                                ? "bg-indigo-600 text-white border-indigo-400 font-black shadow-indigo-500/20"
                                : "bg-indigo-500/20 text-indigo-300 border-indigo-400/40 hover:bg-indigo-500/30"
                            )}
                            title="Open Board History Timeline: Scroll through past conceptual blackboard wipes with timeline slider"
                          >
                            <span>📜 Board History ({boardWipeHistory.length})</span>
                          </button>
                        )}

                        {/* Dedicated Undo Erasure Button */}
                        {erasedBlackboardMessageIds.has(msg.id) && (
                          <button
                            onClick={() => handleUndoErasure(msg.id)}
                            className="ml-1 px-2.5 py-0.5 rounded text-[9px] font-black uppercase transition cursor-pointer border bg-emerald-500/25 text-emerald-200 border-emerald-400/60 hover:bg-emerald-500/40 flex items-center gap-1 shadow-md shadow-emerald-950/40 active:scale-95 animate-pulse"
                            title="Undo Erasure: Restore previous blackboard derivations and drawings"
                          >
                            <RotateCcw size={11} className="text-emerald-300" />
                            <span>Undo Erasure (↺)</span>
                          </button>
                        )}

                        {/* Clear Blackboard Smooth Wipe Transition Button */}
                        {!erasedBlackboardMessageIds.has(msg.id) && (
                          <button
                            onClick={() => handleClearBlackboard(msg.id)}
                            disabled={erasingBlackboardId === msg.id}
                            className="ml-1 px-2.5 py-0.5 rounded text-[9px] font-black uppercase transition cursor-pointer border bg-amber-500/20 text-amber-300 border-amber-400/40 hover:bg-amber-500/30 hover:text-white shadow-amber-500/10 flex items-center gap-1 active:scale-95"
                            title="Clear Blackboard: Smooth wipe transition across canvas before starting next conceptual sub-topic"
                          >
                            <Eraser size={11} className="text-amber-400" />
                            <span>{erasingBlackboardId === msg.id ? "Erasing..." : "Clear Blackboard 🧹"}</span>
                          </button>
                        )}
                      </div>

                      <div className="text-[9px] text-emerald-100/50 font-bold uppercase tracking-wider mt-0.5 flex items-center gap-2">
                        <span>{speakingMessageId === msg.id && isSpeaking ? (isPaused ? "Lecture Paused" : `Lecturing`) : "Class Lecture board"}</span>
                        <span>• Font: {chalkboardFontScale.toUpperCase()}</span>
                        <button
                          onClick={() => {
                            const next = chalkboardFontScale === 'normal' ? 'spacious' : chalkboardFontScale === 'spacious' ? 'compact' : 'normal';
                            setChalkboardFontScale(next);
                            localStorage.setItem('omni_chalkboard_font_scale', next);
                            showNotification?.(`Chalkboard font scale: ${next}`, 'info');
                          }}
                          className="text-emerald-300 underline font-extrabold hover:text-white cursor-pointer"
                        >
                          Toggle Scale
                        </button>
                        {erasedBlackboardMessageIds.has(msg.id) ? (
                          <button
                            onClick={() => handleUndoErasure(msg.id)}
                            className="text-emerald-300 underline font-extrabold hover:text-white cursor-pointer ml-1"
                          >
                            ↺ Undo Erasure
                          </button>
                        ) : (
                          <button
                            onClick={() => handleClearBlackboard(msg.id)}
                            className="text-amber-300 underline font-extrabold hover:text-white cursor-pointer ml-1"
                          >
                            🧹 Clear Canvas
                          </button>
                        )}
                      </div>
                    </div>
                    
                    {/* Visual spectrum voice bar */}
                    {speakingMessageId === msg.id && isSpeaking && !isPaused && (
                      <div className="ml-auto flex items-end gap-1 h-5 self-center">
                        <div className="w-1 bg-emerald-400/80 rounded-full" style={{ height: '50%' }} />
                        <div className="w-1 bg-emerald-400/80 rounded-full" style={{ height: '100%' }} />
                        <div className="w-1 bg-emerald-400/80 rounded-full" style={{ height: '35%' }} />
                        <div className="w-1 bg-emerald-400/80 rounded-full" style={{ height: '80%' }} />
                        <div className="w-1 bg-emerald-400/80 rounded-full" style={{ height: '60%' }} />
                      </div>
                    )}
                  </div>

                  {/* Board History Timeline Slider Bar */}
                  {(isBoardHistoryOpen || activeBoardHistoryIndex !== null) && boardWipeHistory.length > 0 && (
                    <div className="mb-4 p-3.5 rounded-2xl bg-black/60 border border-indigo-500/30 backdrop-blur-md relative z-20 space-y-2.5 animate-in fade-in slide-in-from-top-2 duration-300 shadow-xl">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-black text-indigo-300 uppercase tracking-wider flex items-center gap-1">
                            📜 Board History Timeline
                          </span>
                          <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-200 border border-indigo-500/30 font-bold">
                            {activeBoardHistoryIndex !== null 
                              ? `Wipe #${activeBoardHistoryIndex + 1} of ${boardWipeHistory.length}` 
                              : `Live Active Board (${boardWipeHistory.length} recorded wipes)`}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {activeBoardHistoryIndex !== null && (
                            <button
                              onClick={() => {
                                const currentWipe = boardWipeHistory[activeBoardHistoryIndex];
                                if (currentWipe) handleRestoreWipeEvent(currentWipe);
                              }}
                              className="px-2 py-0.5 rounded-lg text-[9px] font-black uppercase bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition cursor-pointer flex items-center gap-1 shadow"
                              title="Restore this past derivation state to the active blackboard"
                            >
                              <RotateCcw size={10} />
                              <span>Restore To Board</span>
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setActiveBoardHistoryIndex(null);
                              setIsBoardHistoryOpen(false);
                            }}
                            className="px-2 py-0.5 rounded-lg text-[9px] font-bold uppercase bg-white/10 hover:bg-white/20 text-slate-300 transition cursor-pointer flex items-center gap-1"
                            title="Close history timeline and return to live board"
                          >
                            <X size={11} />
                            <span>Return to Live</span>
                          </button>
                        </div>
                      </div>

                      {/* Interactive Timeline Range Slider */}
                      <div className="flex items-center gap-3">
                        <button
                          disabled={activeBoardHistoryIndex === 0}
                          onClick={() => {
                            const newIdx = activeBoardHistoryIndex === null ? boardWipeHistory.length - 1 : Math.max(0, activeBoardHistoryIndex - 1);
                            setActiveBoardHistoryIndex(newIdx);
                            playChalkSound('tap', 0.3);
                          }}
                          className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:pointer-events-none text-white flex items-center justify-center transition cursor-pointer"
                          title="Previous blackboard wipe"
                        >
                          <ChevronLeft size={14} />
                        </button>

                        <div className="flex-1 flex flex-col space-y-1">
                          <input
                            type="range"
                            min={0}
                            max={boardWipeHistory.length - 1}
                            value={activeBoardHistoryIndex ?? boardWipeHistory.length - 1}
                            onChange={(e) => {
                              const val = Number(e.target.value);
                              setActiveBoardHistoryIndex(val);
                              playChalkSound('tap', 0.25);
                            }}
                            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                          />
                          <div className="flex justify-between text-[8px] font-mono text-slate-400">
                            <span>Wipe #1 ({boardWipeHistory[0]?.timestamp})</span>
                            <span className="text-amber-300 font-bold">
                              {activeBoardHistoryIndex !== null ? boardWipeHistory[activeBoardHistoryIndex]?.topic : "Scrub timeline"}
                            </span>
                            <span>Latest Wipe ({boardWipeHistory[boardWipeHistory.length - 1]?.timestamp})</span>
                          </div>
                        </div>

                        <button
                          disabled={activeBoardHistoryIndex === boardWipeHistory.length - 1 || activeBoardHistoryIndex === null}
                          onClick={() => {
                            if (activeBoardHistoryIndex !== null) {
                              const newIdx = Math.min(boardWipeHistory.length - 1, activeBoardHistoryIndex + 1);
                              setActiveBoardHistoryIndex(newIdx);
                              playChalkSound('tap', 0.3);
                            }
                          }}
                          className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:pointer-events-none text-white flex items-center justify-center transition cursor-pointer"
                          title="Next blackboard wipe"
                        >
                          <ChevronRight size={14} />
                        </button>
                      </div>

                      {/* Past Snapshot Summary Tag */}
                      {activeBoardHistoryIndex !== null && boardWipeHistory[activeBoardHistoryIndex] && (
                        <div className="p-2 rounded-xl bg-black/40 border border-amber-500/20 text-xs flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
                            <span className="text-amber-400 font-black text-[10px]">
                              {boardWipeHistory[activeBoardHistoryIndex].eraserStyle === 'sponge-wipe' ? '🧽 Sponge' : boardWipeHistory[activeBoardHistoryIndex].eraserStyle === 'dry-cloth' ? '🧣 Cloth' : '🪵 Felt'} Wipe:
                            </span>
                            <span className="text-slate-200 text-[11px] font-medium truncate">
                              "{boardWipeHistory[activeBoardHistoryIndex].summary}"
                            </span>
                          </div>
                          <span className="text-[9px] font-mono text-slate-400 shrink-0">
                            {boardWipeHistory[activeBoardHistoryIndex].timestamp}
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Real-time Omni-Sync Status Bar */}
                  {speakingMessageId === msg.id && isSpeaking && !isLectureMode && (
                    <div className="mb-4 -mt-2 flex flex-wrap items-center gap-1.5 text-[9px] font-mono text-slate-300/80 select-none duration-300 relative z-20">
                      <span className="px-2 py-0.5 rounded bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 flex items-center gap-1 font-bold">
                        <span className="w-1 h-1 rounded-full bg-emerald-400" />
                        OMNI-SYNC
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-900/60 border border-slate-800 text-slate-300">
                        VOICE SPEED: {ttsRate}x
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-900/60 border border-slate-800 text-slate-300">
                        TYPING TEMPO: {isVoiceTrackingEnabled ? "AUTO SYNCED" : typingPace.toUpperCase()}
                      </span>
                      {isBreathingPausesEnabled && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-900/60 border border-slate-800 text-slate-300">
                          PUNCTUATION BREATHING: ACTIVE
                        </span>
                      )}
                      {isSpotlightEnabled && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-900/60 border border-slate-800 text-slate-300">
                          SPOTLIGHT DIMMING: ACTIVE
                        </span>
                      )}
                      {isAutoScrollPaused && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-500/30 text-amber-400 font-bold animate-pulse">
                          AUTO-SCROLL: MANUAL PAUSE
                        </span>
                      )}
                    </div>
                  )}

                  {/* Dynamic Smooth Eraser Wipe Transition Overlay (Felt / Cloth / Sponge) */}
                  {erasingBlackboardId === msg.id && (
                    <div className="absolute inset-0 z-50 pointer-events-none overflow-hidden rounded-2xl flex items-center">
                      {/* Dark Slate Wiping Mask expanding from left to right */}
                      <div 
                        className={cn(
                          "absolute inset-0 bg-slate-950/95 backdrop-blur-[2px] z-10 border-r-4 border-amber-300/40",
                          eraserSpeed === 'fast' ? "animate-wipe-reveal-fast" : eraserSpeed === 'slow' ? "animate-wipe-reveal-slow" : "animate-wipe-reveal"
                        )}
                        style={{
                          backgroundImage: "radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1px)",
                          backgroundSize: "20px 20px"
                        }}
                      />

                      {/* Moving Eraser Tool Body based on selected style & speed */}
                      <div className={cn(
                        "absolute top-0 bottom-0 w-28 z-20 flex flex-col justify-center items-center",
                        eraserStyle === 'dry-cloth'
                          ? (eraserSpeed === 'fast' ? "animate-cloth-sweep-fast" : eraserSpeed === 'slow' ? "animate-cloth-sweep-slow" : "animate-cloth-sweep")
                          : eraserStyle === 'sponge-wipe'
                          ? (eraserSpeed === 'fast' ? "animate-sponge-sweep-fast" : eraserSpeed === 'slow' ? "animate-sponge-sweep-slow" : "animate-sponge-sweep")
                          : (eraserSpeed === 'fast' ? "animate-eraser-sweep-fast" : eraserSpeed === 'slow' ? "animate-eraser-sweep-slow" : "animate-eraser-sweep")
                      )}>
                        {/* Classic Felt Eraser Body */}
                        {eraserStyle === 'classic-felt' && (
                          <div className="w-16 h-40 rounded-xl bg-gradient-to-r from-amber-800 via-amber-700 to-amber-900 border-2 border-amber-950/70 shadow-[0_12px_32px_rgba(0,0,0,0.85)] relative flex flex-col justify-between p-2 transform rotate-2">
                            <div className="w-full h-1 bg-amber-500/50 rounded-full" />
                            <div className="text-[8px] font-black text-amber-100 uppercase tracking-widest text-center rotate-90 select-none drop-shadow">
                              OMNI FELT
                            </div>
                            <div className="w-full h-3.5 rounded-md bg-slate-900 border border-slate-700/80 shadow-inner flex items-center justify-around px-1">
                              <div className="w-1.5 h-1.5 rounded-full bg-white/50" />
                              <div className="w-1.5 h-1.5 rounded-full bg-white/50" />
                              <div className="w-1.5 h-1.5 rounded-full bg-white/50" />
                            </div>
                          </div>
                        )}

                        {/* Dry Microfiber Cloth Wipe */}
                        {eraserStyle === 'dry-cloth' && (
                          <div className="w-20 h-44 rounded-3xl bg-gradient-to-br from-indigo-800 via-indigo-600 to-purple-900 border-2 border-indigo-400 shadow-[0_12px_32px_rgba(0,0,0,0.9)] relative flex flex-col justify-between p-2 transform -rotate-3">
                            <div className="text-[8px] font-black text-indigo-100 uppercase tracking-widest text-center rotate-90 select-none">
                              MICROFIBER CLOTH
                            </div>
                            <div className="w-full h-6 rounded-2xl bg-indigo-950/70 border border-indigo-400/40 shadow-inner flex items-center justify-center">
                              <span className="text-[7px] text-indigo-200 font-bold uppercase">DRY WIPE</span>
                            </div>
                          </div>
                        )}

                        {/* Moist Cellulose Sponge Wipe */}
                        {eraserStyle === 'sponge-wipe' && (
                          <div className="w-18 h-36 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 border-2 border-amber-700 shadow-[0_12px_32px_rgba(0,0,0,0.9)] relative flex flex-col justify-between p-2.5 transform rotate-1">
                            <div className="w-full flex justify-between">
                              <div className="w-2 h-2 rounded-full bg-amber-600/60" />
                              <div className="w-3 h-3 rounded-full bg-amber-700/40" />
                            </div>
                            <div className="text-[8px] font-black text-slate-900 uppercase tracking-widest text-center rotate-90 select-none drop-shadow">
                              SPONGE
                            </div>
                            <div className="w-full h-3 rounded-lg bg-emerald-700/80 border border-emerald-600 flex items-center justify-center">
                              <span className="text-[6px] text-white font-black uppercase">MOIST SHEEN</span>
                            </div>
                          </div>
                        )}

                        {/* Chalk Dust Cloud Mist behind the eraser based on dust density */}
                        {eraserDustDensity !== 'low' && (
                          <div className="absolute -left-12 top-1/4 w-32 h-32 rounded-full bg-white/15 blur-xl animate-eraser-dust pointer-events-none" />
                        )}
                        {eraserDustDensity === 'high' && (
                          <>
                            <div className="absolute -left-8 bottom-1/4 w-28 h-28 rounded-full bg-amber-200/20 blur-lg animate-eraser-dust pointer-events-none" />
                            <div className="absolute -left-14 top-1/2 w-24 h-24 rounded-full bg-white/20 blur-md animate-eraser-dust pointer-events-none" />
                          </>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Historical Derivation State Preview (When scrubbing timeline) */}
                  {activeBoardHistoryIndex !== null && boardWipeHistory[activeBoardHistoryIndex] ? (
                    <div className="relative z-20 my-4 p-5 sm:p-7 rounded-2xl bg-slate-950/90 border-2 border-amber-500/40 backdrop-blur-md space-y-4 animate-in fade-in duration-300 shadow-2xl">
                      {/* Historic Header Banner */}
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-500/30 pb-3">
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-1 rounded-lg text-xs font-black uppercase bg-amber-500 text-slate-950 flex items-center gap-1 shadow">
                            <RotateCcw size={12} />
                            <span>Historic Wipe #{boardWipeHistory[activeBoardHistoryIndex].stepNumber}</span>
                          </span>
                          <span className="text-xs font-bold text-amber-200">
                            {boardWipeHistory[activeBoardHistoryIndex].topic}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">
                            ({boardWipeHistory[activeBoardHistoryIndex].timestamp})
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleRestoreWipeEvent(boardWipeHistory[activeBoardHistoryIndex])}
                            className="px-3 py-1 rounded-xl text-xs font-black uppercase tracking-wide bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition cursor-pointer flex items-center gap-1 shadow active:scale-95"
                          >
                            <Check size={13} />
                            <span>Restore As Active Board</span>
                          </button>
                          <button
                            onClick={() => setActiveBoardHistoryIndex(null)}
                            className="px-3 py-1 rounded-xl text-xs font-bold uppercase tracking-wide bg-white/10 hover:bg-white/20 text-slate-200 transition cursor-pointer active:scale-95"
                          >
                            <span>Return to Live</span>
                          </button>
                        </div>
                      </div>

                      {/* Historic Math & Derivations Display */}
                      <div className="font-mono text-xs sm:text-sm text-emerald-100/95 leading-relaxed overflow-x-auto select-text p-2">
                        <TypewriterMarkdown
                          content={boardWipeHistory[activeBoardHistoryIndex].fullContent}
                          isAnimated={false}
                          isChalkSfxEnabled={false}
                          theme={theme}
                          speakingWordIndex={-1}
                          isCurrentSpeaking={false}
                          isPaused={false}
                          typingPace={typingPace}
                          isWordHighlightingEnabled={false}
                          isLectureMode={isLectureMode}
                          onSendMessage={onSendMessage}
                          onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                          showNotification={showNotification}
                          canvasUiManager={canvasUiManager}
                        />
                      </div>
                    </div>
                  ) : erasedBlackboardMessageIds.has(msg.id) ? (
                    /* Clean Slate State: When erased, present clean board with Undo button & prompt chips */
                    <div className="relative z-20 my-4 p-6 sm:p-8 rounded-2xl bg-black/40 border border-emerald-500/25 backdrop-blur-sm flex flex-col items-center justify-center text-center space-y-4 animate-in fade-in duration-500 shadow-2xl">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/10 via-emerald-500/10 to-transparent border border-white/10 flex items-center justify-center text-3xl shadow-inner relative">
                        <span>🧹</span>
                        <span className="absolute -bottom-1 -right-1 text-xs">✨</span>
                      </div>
                      
                      <div className="space-y-1.5 max-w-lg">
                        <div className="text-xs font-black uppercase tracking-widest text-emerald-300 flex items-center justify-center gap-2">
                          <span>Clean Blackboard Slate</span>
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <span>Ready For Next Sub-Topic</span>
                        </div>
                        <p className="text-sm font-medium text-slate-300/90 leading-relaxed">
                          The professor has smoothly erased the board before starting the next conceptual sub-topic. Use the Undo button to restore accidentally cleared derivations, or scroll past states using the Board History slider.
                        </p>
                      </div>

                      {/* Primary Undo & History Controls */}
                      <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
                        <button
                          onClick={() => handleUndoErasure(msg.id)}
                          className="px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition cursor-pointer flex items-center gap-2 shadow-lg shadow-emerald-950/50 active:scale-95"
                          title="Restore previous boardwork derivations and diagrams"
                        >
                          <RotateCcw size={14} />
                          <span>Undo Erasure (Restore Board ↺)</span>
                        </button>

                        {boardWipeHistory.length > 0 && (
                          <button
                            onClick={() => {
                              setIsBoardHistoryOpen(true);
                              setActiveBoardHistoryIndex(boardWipeHistory.length - 1);
                              playChalkSound('tap');
                            }}
                            className="px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider bg-indigo-600 hover:bg-indigo-500 text-white transition cursor-pointer flex items-center gap-2 shadow-lg shadow-indigo-950/50 active:scale-95"
                            title="Open Board History Timeline Slider"
                          >
                            <span>📜 View Board History Timeline</span>
                          </button>
                        )}
                      </div>

                      {/* Sub-Topic Quick Action Chips */}
                      <div className="flex flex-wrap items-center justify-center gap-2 pt-2 max-w-xl border-t border-white/10">
                        {[
                          { label: "📐 Next Mathematical Step", prompt: `On the clean blackboard, please derive the next mathematical formulation and step-by-step proof for ${msg.metadata?.topic || subject || 'this topic'}.` },
                          { label: "💡 Intuition & Physical Meaning", prompt: `Explain the physical intuition, real-world analogies, and conceptual significance of ${msg.metadata?.topic || subject || 'this topic'} on the clean board.` },
                          { label: "🔢 Step-by-Step Numerical Example", prompt: `Let's work through a practical numerical example with specific values and boundary conditions step by step on the clean board.` },
                          { label: "❓ Anticipated Student Doubts", prompt: `What are the most common student doubts, subtleties, and misconceptions regarding ${msg.metadata?.topic || subject || 'this concept'}?` },
                          { label: "🎨 Draw 2D Vector Schematic", prompt: `Please draw a detailed 2D SVG vector schematic diagram illustrating ${msg.metadata?.topic || subject || 'this sub-topic'} on the blackboard.` }
                        ].map((chip, cIdx) => (
                          <button
                            key={cIdx}
                            onClick={() => {
                              playChalkSound('scratch', 0.3);
                              if (onSendMessage) {
                                onSendMessage(chip.prompt);
                                showNotification?.(`Starting sub-topic: ${chip.label}`, 'success');
                              }
                            }}
                            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-white/5 hover:bg-emerald-500/20 text-emerald-200 border border-white/10 hover:border-emerald-400/40 transition-all cursor-pointer shadow-sm active:scale-95 flex items-center gap-1.5"
                          >
                            <span>{chip.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    /* Flowing Blackboard Math/Markdown */
                    <div className="relative z-20 select-text flex flex-col">
                      {(() => {
                        const activeAnchor = diagramAnchorPositions[msg.id] || msg.metadata?.anchorPosition || 'top';
                        return (
                          <>
                      {msg.metadata?.image && (
                        <div className={cn(
                          "space-y-3",
                          activeAnchor === 'bottom' ? "order-3 mt-4 mb-2" : activeAnchor === 'middle' ? "order-2 my-4" : "order-1 mb-4"
                        )}>
                        {/* Zoom & View Controls Header */}

                        <div className="flex items-center justify-between bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-800 text-xs">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Diagram View:</span>
                            
                            {/* Pin to Top Button */}
                            <button
                              onClick={() => {
                                setPinnedDiagram({
                                  msgId: msg.id,
                                  image: msg.metadata.image,
                                  annotations: msg.metadata.annotations,
                                  topic: msg.metadata.topic || 'Lesson Diagram',
                                  title: msg.metadata.topic ? `Diagram: ${msg.metadata.topic}` : 'Pinned Key Diagram'
                                });
                                setIsPinnedDiagramMinimized(false);
                                showNotification?.('Diagram pinned to top of chat! 📌', 'success');
                              }}
                              className={cn(
                                "px-2 py-0.5 rounded font-bold text-[10px] transition cursor-pointer flex items-center gap-1",
                                pinnedDiagram?.msgId === msg.id 
                                  ? "bg-amber-500 text-slate-950 ring-2 ring-amber-400 font-extrabold" 
                                  : "bg-indigo-950/80 border border-indigo-500/40 hover:bg-indigo-900 text-indigo-300"
                              )}
                              title="Pin diagram to top of chat so it stays visible while scrolling"
                            >
                              <Pin size={11} className={pinnedDiagram?.msgId === msg.id ? "fill-slate-950" : ""} />
                              {pinnedDiagram?.msgId === msg.id ? 'Pinned to Top' : 'Pin to Top'}
                            </button>

                            {/* Contextual Diagram Anchor Selector */}
                            <div className="flex items-center gap-1 bg-slate-950/80 p-0.5 rounded-lg border border-slate-800">
                              <span className="text-[9px] text-slate-400 font-bold px-1 uppercase">Anchor:</span>
                              <button
                                onClick={() => setDiagramAnchorPositions(prev => ({ ...prev, [msg.id]: 'top' }))}
                                className={cn(
                                  "px-1.5 py-0.5 rounded text-[9px] font-bold transition cursor-pointer",
                                  (diagramAnchorPositions[msg.id] || msg.metadata?.anchorPosition || 'top') === 'top'
                                    ? "bg-indigo-600 text-white shadow-sm"
                                    : "text-slate-400 hover:text-slate-200"
                                )}
                                title="Place diagram above explanation text"
                              >
                                ⬆️ Top
                              </button>
                              <button
                                onClick={() => setDiagramAnchorPositions(prev => ({ ...prev, [msg.id]: 'middle' }))}
                                className={cn(
                                  "px-1.5 py-0.5 rounded text-[9px] font-bold transition cursor-pointer",
                                  (diagramAnchorPositions[msg.id] || msg.metadata?.anchorPosition) === 'middle'
                                    ? "bg-indigo-600 text-white shadow-sm"
                                    : "text-slate-400 hover:text-slate-200"
                                )}
                                title="Place diagram inline in the middle of explanation paragraphs"
                              >
                                ↔️ Inline
                              </button>
                              <button
                                onClick={() => setDiagramAnchorPositions(prev => ({ ...prev, [msg.id]: 'bottom' }))}
                                className={cn(
                                  "px-1.5 py-0.5 rounded text-[9px] font-bold transition cursor-pointer",
                                  (diagramAnchorPositions[msg.id] || msg.metadata?.anchorPosition) === 'bottom'
                                    ? "bg-indigo-600 text-white shadow-sm"
                                    : "text-slate-400 hover:text-slate-200"
                                )}
                                title="Place diagram below explanation text"
                              >
                                ⬇️ Bottom
                              </button>
                            </div>

                            {/* Venn Builder Quick Launch */}
                            <button
                              onClick={() => setIsVennBuilderOpen(true)}
                              className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/40 hover:bg-emerald-900 text-emerald-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1"
                              title="Open Interactive Venn Diagram Builder"
                            >
                              🎨 Venn Builder
                            </button>

                            {/* Annotate Figure Overlay Tool Toggle Button */}
                            <button
                              onClick={() => {
                                const isNowActive = annotatingDiagramMsgId !== msg.id;
                                setAnnotatingDiagramMsgId(isNowActive ? msg.id : null);
                                showNotification?.(
                                  isNowActive 
                                    ? "📍 Annotate Figure mode active! Click anywhere directly on the figure image to drop a sticky note or question." 
                                    : "Annotate Figure mode deactivated", 
                                  "info"
                                );
                              }}
                              className={cn(
                                "px-2 py-0.5 rounded border font-black text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm active:scale-95",
                                annotatingDiagramMsgId === msg.id
                                  ? "bg-amber-400 text-slate-950 border-amber-300 shadow-amber-950/40 ring-2 ring-amber-400 animate-pulse font-black"
                                  : "bg-amber-950/80 border-amber-500/40 hover:bg-amber-900 text-amber-300"
                              )}
                              title="Click anywhere directly on the figure image to attach interactive sticky notes or study questions tied to specific coordinate hotspots"
                            >
                              <StickyNote size={11} />
                              <span>📍 Annotate Figure</span>
                              {(diagramNotes[msg.id]?.length || 0) > 0 && (
                                <span className="px-1 py-0.2 bg-amber-400 text-slate-950 rounded-full font-black text-[9px] min-w-[16px] text-center">
                                  {diagramNotes[msg.id].length}
                                </span>
                              )}
                            </button>

                            {/* Add Quick Note Button */}
                            <button
                              onClick={() => handleAddNoteToDiagram(msg.id)}
                              className="px-2 py-0.5 rounded bg-amber-950/80 border border-amber-500/40 hover:bg-amber-900 text-amber-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm"
                              title="Add a draggable text comment overlay on top of this diagram"
                            >
                              <FileText size={11} />
                              <span>+ Quick Note</span>
                            </button>

                            {/* Auto-Contrast Toggle Button */}
                            <button
                              onClick={() => toggleAutoContrast(msg.id)}
                              className={cn(
                                "px-2 py-0.5 rounded border font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm",
                                autoContrastDiagramIds.has(msg.id)
                                  ? "bg-amber-400 text-slate-950 border-amber-300 font-extrabold shadow-amber-950/40 animate-pulse"
                                  : "bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border-cyan-500/40"
                              )}
                              title="Toggle high contrast filter adjusting brightness and saturation to boost diagram text & formula legibility"
                            >
                              <Contrast size={11} />
                              {autoContrastDiagramIds.has(msg.id) ? '🌓 Auto-Contrast ON' : '🌓 Auto-Contrast'}
                            </button>

                            {/* Chalk Board Invert Mode Toggle Button */}
                            <button
                              onClick={() => toggleChalkInvert(msg.id)}
                              className={cn(
                                "px-2 py-0.5 rounded border font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm",
                                chalkInvertDiagramIds.has(msg.id)
                                  ? "bg-purple-500 text-white border-purple-300 font-extrabold shadow-purple-950/40"
                                  : "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700"
                              )}
                              title="Invert colors to convert bright backgrounds into an authentic dark blackboard with white chalk lines"
                            >
                              <span>{chalkInvertDiagramIds.has(msg.id) ? '🖤 Chalk Board Invert ON' : '🖤 Chalk Invert'}</span>
                            </button>

                            <button
                              onClick={() => handleRefreshDiagram(msg)}
                              disabled={refreshingDiagramIds.has(msg.id)}
                              className="px-2 py-0.5 rounded bg-emerald-950/90 border border-emerald-500/40 hover:bg-emerald-900 text-emerald-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm disabled:opacity-50"
                              title="Re-generate and refresh the current topic's visual diagram figure to stay perfectly synchronized with state"
                            >
                              {refreshingDiagramIds.has(msg.id) ? (
                                <>
                                  <Loader2 size={11} className="animate-spin text-emerald-400" />
                                  <span>Refreshing...</span>
                                </>
                              ) : (
                                <>
                                  <RotateCw size={11} className="text-emerald-400" />
                                  <span>Refresh Diagram</span>
                                </>
                              )}
                            </button>

                            {/* Download PNG Button */}
                            <button
                              onClick={() => handleDownloadPNG(msg)}
                              className="px-2 py-0.5 rounded bg-blue-950/90 border border-blue-500/40 hover:bg-blue-900 text-blue-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm"
                              title="Download high-quality PNG image of currently rendered study figure for offline review"
                            >
                              <Download size={11} className="text-blue-400" />
                              <span>🖼️ Download PNG</span>
                            </button>

                            {/* Scan QR Code Button */}
                            <button
                              onClick={() => setIsQrScannerOpen(true)}
                              className="px-2 py-0.5 rounded bg-amber-950/90 border border-amber-500/40 hover:bg-amber-900 text-amber-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm"
                              title="Scan physical QR code from camera or clipboard to load related educational content"
                            >
                              <QrCode size={11} className="text-amber-400" />
                              <span>📷 Scan QR</span>
                            </button>

                            {/* Diagram Cache Button */}
                            <button
                              onClick={() => setIsCachedFiguresModalOpen(true)}
                              className="px-2 py-0.5 rounded bg-cyan-950/90 border border-cyan-500/40 hover:bg-cyan-900 text-cyan-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm"
                              title="Toggle between previously rendered figures from local storage cache without re-generating"
                            >
                              <Database size={11} className="text-cyan-400" />
                              <span>⚡ Cache ({cachedStudyFigures.length})</span>
                            </button>

                            {/* Element Quiz Button */}
                            <button
                              onClick={() => handleGenerateElementQuiz(msg)}
                              disabled={generatingElementQuizMsgId === msg.id}
                              className="px-2 py-0.5 rounded bg-indigo-950/90 border border-indigo-500/40 hover:bg-indigo-900 text-indigo-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm disabled:opacity-50"
                              title="Automatically generate a specialized quiz question based on currently highlighted or selected diagram elements"
                            >
                              {generatingElementQuizMsgId === msg.id ? (
                                <>
                                  <Loader2 size={11} className="animate-spin text-indigo-400" />
                                  <span>Quiz Gen...</span>
                                </>
                              ) : (
                                <>
                                  <Brain size={11} className="text-indigo-400" />
                                  <span>🧠 Element Quiz</span>
                                </>
                              )}
                            </button>

                            {/* Hotkeys Button */}
                            <button
                              onClick={() => setIsKeyboardShortcutsModalOpen(true)}
                              className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm"
                              title="View keyboard shortcuts & hotkeys (Ctrl + K)"
                            >
                              <span>⌨️ Hotkeys</span>
                            </button>

                            {/* Voice Prompts Button */}
                            <button
                              onClick={() => setIsVoiceCommandModalOpen(true)}
                              className="px-2 py-0.5 rounded bg-rose-950/90 border border-rose-500/40 hover:bg-rose-900 text-rose-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm animate-pulse"
                              title="Open Speech-to-Text & Voice Command Prompts Hub (Ctrl + M)"
                            >
                              <span>🎙️ Voice Prompts</span>
                            </button>

                            {/* Accessibility Button */}
                            <button
                              onClick={() => setIsAccessibilityModalOpen(true)}
                              className="px-2 py-0.5 rounded bg-cyan-950/90 border border-cyan-500/40 hover:bg-cyan-900 text-cyan-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm"
                              title="Open Accessibility & Readability Toolbar (Ctrl + A)"
                            >
                              <span>♿ Accessibility</span>
                            </button>

                            {/* Export PDF Study Document Button */}
                            <button
                              onClick={() => handleExportDiagramPDF(msg)}
                              disabled={exportingPdfId === msg.id}
                              className="px-2 py-0.5 rounded bg-purple-950/80 border border-purple-500/40 hover:bg-purple-900 text-purple-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1 shadow-sm disabled:opacity-50"
                              title="Export diagram with active annotations and study notes as a single PDF study file"
                            >
                              {exportingPdfId === msg.id ? (
                                <>
                                  <Loader2 size={11} className="animate-spin" />
                                  Exporting PDF...
                                </>
                              ) : (
                                <>
                                  <Download size={11} />
                                  📄 Export PDF
                                </>
                              )}
                            </button>

                            <button
                              onClick={() => setShowHotspots(prev => ({ ...prev, [msg.id]: prev[msg.id] === false ? true : false }))}
                              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-[10px] transition cursor-pointer"
                            >
                              {showHotspots[msg.id] !== false ? '👁️ Hide Hotspots' : '👁️ Show Hotspots'}
                            </button>

                            <button
                              onClick={() => setShowLegendMap(prev => ({ ...prev, [msg.id]: prev[msg.id] === false ? true : false }))}
                              className={cn(
                                "px-2 py-0.5 rounded font-bold text-[10px] transition cursor-pointer flex items-center gap-1",
                                showLegendMap[msg.id] !== false
                                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30"
                                  : "bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                              )}
                              title="Show or hide the node & hotspot legend key block"
                            >
                              🏷️ {showLegendMap[msg.id] !== false ? 'Hide Legend' : 'Show Legend'}
                            </button>
                            <button
                              onClick={() => {
                                if (activeDiagramQuiz[msg.id]) {
                                  setActiveDiagramQuiz(prev => {
                                    const next = { ...prev };
                                    delete next[msg.id];
                                    return next;
                                  });
                                  showNotification?.("Diagram Quiz exited.", "info");
                                } else {
                                  handleStartDiagramQuiz(msg.id, msg.metadata.annotations || []);
                                }
                              }}
                              className={cn(
                                "px-2 py-0.5 rounded font-bold text-[10px] transition cursor-pointer flex items-center gap-1",
                                activeDiagramQuiz[msg.id]
                                  ? "bg-purple-600 text-white border border-purple-400"
                                  : "bg-purple-950/80 border border-purple-500/40 hover:bg-purple-900 text-purple-300"
                              )}
                              title="Active recall quiz testing your diagram mastery"
                            >
                              {activeDiagramQuiz[msg.id] ? '⏹️ Exit Quiz' : '🎯 Diagram Quiz'}
                            </button>
                            <button
                              onClick={() => handleStartAudioTour(msg.id, msg.metadata.annotations || [])}
                              className={cn(
                                "px-2 py-0.5 rounded font-bold text-[10px] transition cursor-pointer flex items-center gap-1",
                                activeAudioTour?.msgId === msg.id && activeAudioTour.isPlaying
                                  ? "bg-amber-500 text-slate-950 font-black animate-pulse"
                                  : "bg-cyan-950/80 border border-cyan-500/40 hover:bg-cyan-900 text-cyan-300"
                              )}
                              title="Sequential spoken audio tour of each diagram node"
                            >
                              {activeAudioTour?.msgId === msg.id && activeAudioTour.isPlaying ? '⏹️ Stop Tour' : '🔊 Audio Tour'}
                            </button>
                            <button
                              onClick={() => {
                                setActiveChalkboard(prev => prev === msg.id ? null : msg.id);
                                showNotification?.(activeChalkboard === msg.id ? "Chalkboard closed" : "✏️ Chalkboard Annotator active! Draw freehand notes over figure.", "info");
                              }}
                              className={cn(
                                "px-2 py-0.5 rounded font-bold text-[10px] transition cursor-pointer flex items-center gap-1",
                                activeChalkboard === msg.id
                                  ? "bg-pink-600 text-white border border-pink-400"
                                  : "bg-pink-950/80 border border-pink-500/40 hover:bg-pink-900 text-pink-300"
                              )}
                              title="Draw freehand chalk notes and markups directly on figure"
                            >
                              {activeChalkboard === msg.id ? '✕ Close Chalkboard' : '✏️ Chalkboard'}
                            </button>
                            <button
                              onClick={() => handleSnapToGallery(msg.id, msg.metadata.image, msg.metadata.annotations, msg.metadata.topic)}
                              className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/40 hover:bg-emerald-900 text-emerald-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1"
                              title="Save current diagram view and active annotations to Study Gallery"
                            >
                              📸 Snap to Gallery
                            </button>
                            <button
                              onClick={() => setIsGalleryOpen(true)}
                              className="px-2 py-0.5 rounded bg-amber-950/80 border border-amber-500/40 hover:bg-amber-900 text-amber-300 font-bold text-[10px] transition cursor-pointer flex items-center gap-1"
                              title="Open Study Gallery"
                            >
                              🖼️ Gallery ({studyGallery.length})
                            </button>
                            <button
                              onClick={() => setCompareModalMsgId(msg.id)}
                              className="px-2 py-0.5 rounded bg-indigo-950/60 border border-indigo-500/30 hover:bg-indigo-900 text-indigo-300 font-bold text-[10px] transition cursor-pointer"
                              title="Compare original AI vs current adjusted positions"
                            >
                              📊 Compare Original
                            </button>
                          </div>
                          <div className="flex items-center gap-1.5 font-mono text-[10px] flex-wrap justify-end">
                            {diagramSizes[msg.id] && (
                              <button
                                onClick={() => {
                                  setDiagramSizes(prev => {
                                    const next = { ...prev };
                                    delete next[msg.id];
                                    return next;
                                  });
                                  showNotification?.('Diagram dimensions reset to default', 'info');
                                }}
                                className="px-1.5 py-0.5 rounded bg-amber-950/80 border border-amber-500/40 text-amber-300 font-bold text-[10px] cursor-pointer hover:bg-amber-900 transition flex items-center gap-1 mr-1"
                                title="Reset container dimensions to default"
                              >
                                📐 {diagramSizes[msg.id]?.width}×{diagramSizes[msg.id]?.height}px (Reset)
                              </button>
                            )}

                            {/* Interactive Zoom Controls */}
                            <div className="flex items-center gap-1 bg-slate-950/90 px-2 py-0.5 rounded-lg border border-slate-800 shadow-sm">
                              <span className="text-slate-400 font-bold text-[10px] mr-0.5">Zoom: {Math.round((zoomLevels[msg.id] || 1) * 100)}%</span>
                              <button
                                onClick={() => setZoomLevels(prev => ({ ...prev, [msg.id]: Math.max(0.5, Number(((prev[msg.id] || 1) - 0.25).toFixed(2))) }))}
                                className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 active:scale-95 text-white flex items-center justify-center font-bold cursor-pointer transition"
                                title="Zoom out (-25%)"
                              >
                                <Minus size={11} />
                              </button>
                              <button
                                onClick={() => setZoomLevels(prev => ({ ...prev, [msg.id]: Math.min(4, Number(((prev[msg.id] || 1) + 0.25).toFixed(2))) }))}
                                className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 active:scale-95 text-white flex items-center justify-center font-bold cursor-pointer transition"
                                title="Zoom in (+25%)"
                              >
                                <Plus size={11} />
                              </button>
                              {(zoomLevels[msg.id] || 1) !== 1 && (
                                <button
                                  onClick={() => setZoomLevels(prev => ({ ...prev, [msg.id]: 1 }))}
                                  className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold cursor-pointer transition text-[9px]"
                                  title="Reset zoom to 100%"
                                >
                                  Reset
                                </button>
                              )}
                            </div>

                            {/* Interactive Rotate Controls */}
                            <div className="flex items-center gap-1 bg-slate-950/90 px-2 py-0.5 rounded-lg border border-slate-800 shadow-sm">
                              <span className="text-slate-400 font-bold text-[10px] mr-0.5">Rotate:</span>
                              <button
                                onClick={() => setDiagramRotations(prev => ({ ...prev, [msg.id]: ((prev[msg.id] || 0) - 90) }))}
                                className="p-1 rounded bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 cursor-pointer transition"
                                title="Rotate counter-clockwise 90°"
                              >
                                <RotateCcw size={11} />
                              </button>
                              <button
                                onClick={() => setDiagramRotations(prev => ({ ...prev, [msg.id]: ((prev[msg.id] || 0) + 90) }))}
                                className="p-1 rounded bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 cursor-pointer transition"
                                title="Rotate clockwise 90°"
                              >
                                <RotateCw size={11} />
                              </button>
                              {(diagramRotations[msg.id] || 0) !== 0 && (
                                <button
                                  onClick={() => setDiagramRotations(prev => ({ ...prev, [msg.id]: 0 }))}
                                  className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 font-bold cursor-pointer transition text-[9px]"
                                  title="Reset rotation to 0°"
                                >
                                  {((diagramRotations[msg.id] || 0) % 360 + 360) % 360}° (Reset)
                                </button>
                              )}
                            </div>

                            {/* Full-Screen Toggle Button */}
                            <button
                              onClick={() => {
                                setFullscreenDiagramMsgId(msg.id);
                                setFullscreenZoom(zoomLevels[msg.id] || 1);
                                setFullscreenRotation(diagramRotations[msg.id] || 0);
                                showNotification?.("Entering Full-Screen Diagram Inspector 🔬", "info");
                              }}
                              className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-[10px] transition cursor-pointer flex items-center gap-1.5 shadow-md hover:shadow-indigo-500/20 active:scale-95"
                              title="Inspect diagram in Full-Screen mode"
                            >
                              <Maximize2 size={12} />
                              Fullscreen
                            </button>
                          </div>
                        </div>

                        {/* Active Recall Diagram Quiz Banner */}
                        {activeDiagramQuiz[msg.id] && (
                          <div className="mb-2 p-3 rounded-2xl bg-gradient-to-r from-purple-900/90 via-indigo-900/90 to-slate-900 border border-purple-500/40 shadow-xl space-y-2">
                            <div className="flex items-center justify-between text-xs font-bold">
                              <span className="flex items-center gap-1.5 text-purple-300">
                                <span className="animate-ping w-2 h-2 rounded-full bg-purple-400"></span>
                                🎯 Active Recall Diagram Quiz ({activeDiagramQuiz[msg.id].score} / {activeDiagramQuiz[msg.id].total} Solved)
                              </span>
                              <span className="font-mono text-[10px] bg-purple-950 px-2 py-0.5 rounded border border-purple-500/30 text-purple-200">
                                Question {Math.min(activeDiagramQuiz[msg.id].total, Object.keys(activeDiagramQuiz[msg.id].answeredNodes).length + 1)} of {activeDiagramQuiz[msg.id].total}
                              </span>
                            </div>

                            {!activeDiagramQuiz[msg.id].completed ? (
                              <div className="text-xs font-extrabold text-amber-300 bg-black/40 p-2 rounded-xl border border-amber-500/30">
                                Locate & Click on: <span className="text-white underline decoration-amber-400 decoration-2">{msg.metadata.annotations?.[activeDiagramQuiz[msg.id].targetIndex]?.label}</span>
                              </div>
                            ) : (
                              <div className="text-xs font-black text-emerald-300 bg-emerald-950/80 p-2 rounded-xl border border-emerald-500/40 flex items-center justify-between">
                                <span>🏆 Quiz Complete! Score: {activeDiagramQuiz[msg.id].score} / {activeDiagramQuiz[msg.id].total}</span>
                                <button
                                  onClick={() => handleStartDiagramQuiz(msg.id, msg.metadata.annotations || [])}
                                  className="text-[10px] bg-emerald-600 hover:bg-emerald-500 text-white px-2 py-1 rounded-lg transition font-bold"
                                >
                                  🔁 Retake Quiz
                                </button>
                              </div>
                            )}

                            {activeDiagramQuiz[msg.id].feedback && (
                              <div className={cn(
                                "text-xs font-bold p-2 rounded-lg border animate-in fade-in",
                                activeDiagramQuiz[msg.id].feedback?.type === 'success'
                                  ? "bg-emerald-950/80 border-emerald-500/40 text-emerald-300"
                                  : "bg-rose-950/80 border-rose-500/40 text-rose-300"
                              )}>
                                {activeDiagramQuiz[msg.id].feedback?.msg}
                              </div>
                            )}
                          </div>
                        )}

                        <div 
                          id={`diagram-image-${msg.id}`}
                          className={cn(
                            "relative rounded-xl overflow-hidden border border-white/10 shadow-lg transition-all duration-200 select-none group/diagram",
                            !diagramSizes[msg.id] && "max-w-md",
                            (repositioningAnno?.msgId === msg.id || annotatingDiagramMsgId === msg.id) ? "cursor-crosshair ring-2 ring-amber-400" : ""
                          )}
                          style={{ 
                            width: diagramSizes[msg.id]?.width ? `${diagramSizes[msg.id].width}px` : undefined,
                            height: diagramSizes[msg.id]?.height ? `${diagramSizes[msg.id].height}px` : undefined,
                            maxWidth: '100%',
                            transform: `scale(${zoomLevels[msg.id] || 1}) rotate(${diagramRotations[msg.id] || 0}deg)`, 
                            transformOrigin: 'center center',
                            transition: 'transform 0.2s cubic-bezier(0.16, 1, 0.3, 1)'
                          }}
                          onWheel={(e) => {
                            e.preventDefault();
                            const currentZoom = zoomLevels[msg.id] || 1;
                            const delta = e.deltaY < 0 ? 0.2 : -0.2;
                            const newZoom = Math.max(0.5, Math.min(4, Number((currentZoom + delta).toFixed(2))));
                            setZoomLevels(prev => ({ ...prev, [msg.id]: newZoom }));
                          }}
                          onClick={(e) => {
                            if (repositioningAnno?.msgId === msg.id) {
                              handleImageClickForReposition(e, msg.id, repositioningAnno.index);
                            } else {
                              handleImageClickForAnnotation(e, msg.id);
                            }
                          }}
                        >
                          {/* Active Annotate Mode Banner Overlay */}
                          {annotatingDiagramMsgId === msg.id && (
                            <div className="absolute top-2 left-2 right-2 z-40 bg-amber-500/95 backdrop-blur-md text-slate-950 font-black text-[10px] px-2.5 py-1.5 rounded-xl shadow-2xl flex items-center justify-between border border-amber-300 animate-in fade-in slide-in-from-top-1">
                              <span className="flex items-center gap-1.5 truncate">
                                <span className="w-2 h-2 rounded-full bg-slate-950 animate-ping" />
                                📍 <strong>Annotate Mode Active:</strong> Click directly on image to drop a sticky note or question!
                              </span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setAnnotatingDiagramMsgId(null);
                                }}
                                className="px-2 py-0.5 bg-slate-950 hover:bg-slate-900 text-white rounded-lg text-[9px] font-extrabold cursor-pointer transition shrink-0 ml-1"
                              >
                                Done ✕
                              </button>
                            </div>
                          )}
                          {/* Quick Interactive Controls Floating Hover Bar */}
                          <div className="absolute top-2 right-2 z-40 opacity-0 group-hover/diagram:opacity-100 transition-opacity duration-200 bg-slate-950/90 backdrop-blur-md p-1 rounded-xl border border-white/20 shadow-2xl flex items-center gap-1">
                            <button
                              onClick={(e) => { e.stopPropagation(); setZoomLevels(prev => ({ ...prev, [msg.id]: Math.max(0.5, Number(((prev[msg.id] || 1) - 0.25).toFixed(2))) })); }}
                              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition active:scale-95"
                              title="Zoom Out (-25%)"
                            >
                              <Minus size={12} />
                            </button>
                            <span className="text-[10px] font-mono font-bold text-slate-300 px-1 min-w-[36px] text-center">
                              {Math.round((zoomLevels[msg.id] || 1) * 100)}%
                            </span>
                            <button
                              onClick={(e) => { e.stopPropagation(); setZoomLevels(prev => ({ ...prev, [msg.id]: Math.min(4, Number(((prev[msg.id] || 1) + 0.25).toFixed(2))) })); }}
                              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition active:scale-95"
                              title="Zoom In (+25%)"
                            >
                              <Plus size={12} />
                            </button>
                            <div className="w-px h-3.5 bg-slate-700 mx-0.5" />
                            <button
                              onClick={(e) => { e.stopPropagation(); setDiagramRotations(prev => ({ ...prev, [msg.id]: ((prev[msg.id] || 0) - 90) })); }}
                              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition active:scale-95"
                              title="Rotate 90° Counter-Clockwise"
                            >
                              <RotateCcw size={12} />
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); setDiagramRotations(prev => ({ ...prev, [msg.id]: ((prev[msg.id] || 0) + 90) })); }}
                              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition active:scale-95"
                              title="Rotate 90° Clockwise"
                            >
                              <RotateCw size={12} />
                            </button>
                            <div className="w-px h-3.5 bg-slate-700 mx-0.5" />
                            <button
                              onClick={(e) => { e.stopPropagation(); toggleChalkInvert(msg.id); }}
                              className={cn(
                                "p-1 rounded-lg transition active:scale-95 cursor-pointer text-[10px] font-black",
                                chalkInvertDiagramIds.has(msg.id) ? "bg-purple-600 text-white" : "bg-slate-800 hover:bg-slate-700 text-slate-200"
                              )}
                              title="Toggle Dark Blackboard Chalk Invert Mode"
                            >
                              🖤
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); handleDownloadPNG(msg); }}
                              className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold transition shadow-sm active:scale-95 cursor-pointer"
                              title="Download Diagram PNG"
                            >
                              <Download size={12} />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setFullscreenDiagramMsgId(msg.id);
                                setFullscreenZoom(zoomLevels[msg.id] || 1);
                                setFullscreenRotation(diagramRotations[msg.id] || 0);
                                showNotification?.("Entering Full-Screen Diagram Inspector 🔬", "info");
                              }}
                              className="p-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition shadow-sm active:scale-95"
                              title="Full-Screen Inspection View"
                            >
                              <Maximize2 size={12} />
                            </button>
                          </div>

                          <img 
                            src={msg.metadata.image} 
                            alt="Lecture slide illustration" 
                            className={cn(
                              "w-full h-full object-cover transition-all duration-300",
                              autoContrastDiagramIds.has(msg.id) && "contrast-125 brightness-110 saturate-125"
                            )}
                            style={{
                              maxHeight: diagramSizes[msg.id]?.height ? `${diagramSizes[msg.id].height}px` : '250px',
                              filter: [
                                chalkInvertDiagramIds.has(msg.id) ? 'invert(100%) hue-rotate(180deg) contrast(140%) brightness(95%)' : '',
                                autoContrastDiagramIds.has(msg.id) ? 'contrast(135%) brightness(108%) saturate(125%)' : ''
                              ].filter(Boolean).join(' ') || undefined
                            }}
                            referrerPolicy="no-referrer"
                          />

                          {/* Authentic Subtle Dust & Chalk Texture Overlay */}
                          {showChalkDustOverlay && (
                            <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden mix-blend-screen opacity-35">
                              {/* Radial Chalk Powder Smudges */}
                              <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_25%,rgba(255,255,255,0.22)_0%,transparent_40%),radial-gradient(circle_at_80%_75%,rgba(255,255,255,0.18)_0%,transparent_45%),radial-gradient(circle_at_50%_40%,rgba(255,255,255,0.12)_0%,transparent_60%)]" />
                              {/* Authentic Eraser Sweep Marks */}
                              <div className="absolute inset-0 bg-[linear-gradient(130deg,rgba(255,255,255,0.09)_15%,transparent_15%,transparent_45%,rgba(255,255,255,0.09)_45%,rgba(255,255,255,0.09)_52%,transparent_52%)] bg-[size:90px_90px] opacity-40" />
                              {/* Fine Chalk Particle Texture */}
                              <div className="absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.28)_1px,transparent_1px)] bg-[size:8px_8px] opacity-25" />
                              {/* Vignette Board Edge Shadow */}
                              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_50%,rgba(0,0,0,0.35)_100%)]" />
                            </div>
                          )}
                          {repositioningAnno?.msgId === msg.id && (
                            <div className="absolute top-2 left-2 z-40 bg-amber-500 text-slate-950 font-extrabold text-[10px] px-2.5 py-1 rounded-lg shadow-lg animate-pulse">
                              Click anywhere on diagram to place Hotspot #{repositioningAnno.index + 1}
                            </div>
                          )}

                          {/* Freehand Chalkboard Drawing Overlay */}
                          {activeChalkboard === msg.id && (
                            <div className="absolute inset-0 z-35 bg-black/30 backdrop-blur-[1px] pointer-events-auto">
                              <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />
                              <div className="absolute top-2 right-2 z-40 bg-slate-950/90 border border-slate-700 rounded-xl p-1.5 flex items-center gap-2 shadow-2xl backdrop-blur-md">
                                <span className="text-[10px] font-extrabold text-pink-400 uppercase tracking-wider pl-1">Chalk:</span>
                                {['#ffffff', '#facc15', '#38bdf8', '#f43f5e', '#4ade80'].map(c => (
                                  <button
                                    key={c}
                                    onClick={() => setChalkboardColor(c)}
                                    className={cn(
                                      "w-4 h-4 rounded-full border border-white/40 transition-transform cursor-pointer",
                                      chalkboardColor === c && "scale-125 ring-2 ring-white"
                                    )}
                                    style={{ backgroundColor: c }}
                                  />
                                ))}
                                <div className="w-px h-4 bg-slate-700 mx-1" />
                                <button
                                  onClick={() => {
                                    const canvas = chalkboardCanvasRefs.current[msg.id];
                                    if (canvas) {
                                      const ctx = canvas.getContext('2d');
                                      if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
                                    }
                                  }}
                                  className="px-2 py-0.5 text-[9px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded"
                                >
                                  Clear Chalk
                                </button>
                                <button
                                  onClick={() => setActiveChalkboard(null)}
                                  className="px-2 py-0.5 text-[9px] font-bold bg-pink-600 hover:bg-pink-500 text-white rounded"
                                >
                                  Done
                                </button>
                              </div>
                              <canvas
                                ref={(el) => {
                                  chalkboardCanvasRefs.current[msg.id] = el;
                                  if (el && (!el.width || el.width !== el.clientWidth)) {
                                    el.width = el.clientWidth || 400;
                                    el.height = el.clientHeight || 250;
                                  }
                                }}
                                className="w-full h-full cursor-crosshair"
                                onMouseDown={(e) => {
                                  const canvas = chalkboardCanvasRefs.current[msg.id];
                                  if (!canvas) return;
                                  const ctx = canvas.getContext('2d');
                                  if (!ctx) return;
                                  const rect = canvas.getBoundingClientRect();
                                  ctx.beginPath();
                                  ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
                                  (canvas as any).isDrawing = true;
                                }}
                                onMouseMove={(e) => {
                                  const canvas = chalkboardCanvasRefs.current[msg.id];
                                  if (!canvas || !(canvas as any).isDrawing) return;
                                  const ctx = canvas.getContext('2d');
                                  if (!ctx) return;
                                  const rect = canvas.getBoundingClientRect();
                                  ctx.strokeStyle = chalkboardColor;
                                  ctx.lineWidth = chalkboardSize;
                                  ctx.lineCap = 'round';
                                  ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
                                  ctx.stroke();
                                }}
                                onMouseUp={() => {
                                  const canvas = chalkboardCanvasRefs.current[msg.id];
                                  if (canvas) (canvas as any).isDrawing = false;
                                }}
                                onMouseLeave={() => {
                                  const canvas = chalkboardCanvasRefs.current[msg.id];
                                  if (canvas) (canvas as any).isDrawing = false;
                                }}
                              />
                            </div>
                          )}

                          {showHotspots[msg.id] !== false && msg.metadata.annotations?.map((anno: any, i: number) => {
                            const isHighlighted = hoveredAnnoIndex?.msgId === msg.id && hoveredAnnoIndex?.index === i;
                            const isRepositioningThis = repositioningAnno?.msgId === msg.id && repositioningAnno?.index === i;
                            const quizState = activeDiagramQuiz[msg.id];
                            const isQuizMode = !!quizState;
                            const isQuizSolved = quizState?.answeredNodes[i];
                            const customColorKey = `${msg.id}-${i}`;
                            const chosenPreset = colorPresets.find(p => p.label === annoColors[customColorKey]) || colorPresets[0];

                            return (
                              <div 
                                key={i} 
                                className={cn(
                                  "absolute cursor-pointer rounded-full transition-all duration-300 flex items-center justify-center group animate-pulse",
                                  isQuizMode
                                    ? isQuizSolved 
                                      ? "bg-emerald-500 ring-4 ring-emerald-400 scale-125 z-30 shadow-lg w-5 h-5 -translate-x-0.5 -translate-y-0.5"
                                      : "bg-purple-600 hover:bg-purple-500 ring-2 ring-purple-300 w-5 h-5 z-30 shadow-md -translate-x-0.5 -translate-y-0.5"
                                    : isHighlighted || isRepositioningThis
                                      ? "bg-amber-400 ring-4 ring-amber-500/50 scale-125 z-30 shadow-lg w-5 h-5 -translate-x-0.5 -translate-y-0.5" 
                                      : `${chosenPreset.bg} hover:opacity-90 w-4 h-4 z-25 ring-2 ${chosenPreset.ring} ${chosenPreset.shadow}`
                                )}
                                style={{ left: `${anno.x}%`, top: `${anno.y}%` }}
                                onMouseEnter={() => setHoveredAnnoIndex({ msgId: msg.id, index: i })}
                                onMouseLeave={() => setHoveredAnnoIndex(null)}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (isQuizMode) {
                                    handleQuizHotspotClick(msg.id, i, msg.metadata.annotations);
                                  } else {
                                    setHoveredAnnoIndex({ msgId: msg.id, index: i });
                                    setActiveAnnoModal({ msgId: msg.id, anno, index: i });
                                    const legendEl = document.getElementById(`legend-item-${msg.id}-${i}`);
                                    if (legendEl) {
                                      legendEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                                    }
                                  }
                                }}
                              >
                                <span className="text-[9px] font-extrabold text-white">
                                  {isQuizMode ? (isQuizSolved ? '✓' : '?') : i + 1}
                                </span>
                                {!isQuizMode && (
                                  <div className="absolute top-full mt-1 left-1/2 -translate-x-1/2 pointer-events-none z-30">
                                    <span className="block max-w-[100px] truncate text-[9px] font-semibold bg-slate-950/85 backdrop-blur-sm text-white px-1.5 py-0.5 rounded shadow border border-white/20 whitespace-nowrap">
                                      {anno.label}
                                    </span>
                                  </div>
                                )}
                                {!isQuizMode && (
                                  <div 
                                    className="absolute left-6 top-0 hidden group-hover:block bg-black/90 text-white p-2 text-xs rounded whitespace-normal max-w-xs z-50 shadow-xl border border-slate-700"
                                    style={{ fontSize: `${popupFontSize}px` }}
                                  >
                                    <span className="font-bold text-amber-400">{anno.label}</span>: {anno.description} (Click for academic breakdown)
                                  </div>
                                )}
                              </div>
                            );
                          })}

                          {/* Persistent Draggable Text Comment / Hotspot Study Note Overlays */}
                          {diagramNotes[msg.id]?.map((note) => {
                            const isEditing = editingNoteKey === `${msg.id}-${note.id}`;
                            const isDragging = draggingNoteKey === `${msg.id}-${note.id}`;
                            const category = note.type || 'note';
                            const categoryConfig = HOTSPOT_CATEGORY_CONFIG[category] || HOTSPOT_CATEGORY_CONFIG.note;
                            const colorStyle = NOTE_COLOR_STYLES[note.color || 'amber'];

                            return (
                              <div
                                key={note.id}
                                className={cn(
                                  "absolute z-35 transition-all duration-150 select-none group/stickyNote -translate-x-1/2 -translate-y-1/2",
                                  isDragging ? "scale-105 z-50 opacity-95" : ""
                                )}
                                style={{ left: `${note.x}%`, top: `${note.y}%` }}
                                onClick={(e) => e.stopPropagation()}
                              >
                                {/* Hotspot Pin Badge */}
                                <div
                                  onMouseDown={(e) => handleNoteDragStart(e, msg.id, note.id)}
                                  onTouchStart={(e) => handleNoteDragStart(e, msg.id, note.id)}
                                  className={cn(
                                    "w-7 h-7 rounded-full flex items-center justify-center cursor-grab active:cursor-grabbing shadow-xl transition-all duration-200 hover:scale-125 border border-white/40",
                                    categoryConfig.bgBadge
                                  )}
                                  title={`Hotspot: ${note.title || 'Note'} (Drag handle to reposition)`}
                                >
                                  <categoryConfig.icon size={13} />
                                </div>

                                {/* Title Label Tooltip below badge */}
                                {note.title && !isEditing && (
                                  <div className="absolute top-7 left-1/2 -translate-x-1/2 pointer-events-none z-30">
                                    <span className="block max-w-[110px] truncate text-[9px] font-extrabold bg-slate-950/90 backdrop-blur-md text-amber-300 px-1.5 py-0.5 rounded-md border border-amber-500/30 shadow-lg whitespace-nowrap">
                                      {note.title}
                                    </span>
                                  </div>
                                )}

                                {/* Expanded Interactive Sticky Note Card */}
                                <div className={cn(
                                  "absolute left-4 top-2 z-40 rounded-2xl border p-2.5 shadow-2xl max-w-[230px] min-w-[160px] text-xs font-sans transition-all duration-200 opacity-0 group-hover/stickyNote:opacity-100 pointer-events-none group-hover/stickyNote:pointer-events-auto",
                                  isEditing ? "opacity-100 pointer-events-auto ring-2 ring-amber-400" : "",
                                  colorStyle.card
                                )}>
                                  {/* Header Bar with Drag handle, Title, and Actions */}
                                  <div
                                    onMouseDown={(e) => handleNoteDragStart(e, msg.id, note.id)}
                                    onTouchStart={(e) => handleNoteDragStart(e, msg.id, note.id)}
                                    className={cn(
                                      "flex items-center justify-between pb-1.5 mb-1.5 border-b border-black/20 cursor-grab active:cursor-grabbing font-bold rounded-xl px-2 py-1 text-[10px]",
                                      colorStyle.header
                                    )}
                                  >
                                    <span className="flex items-center gap-1 truncate font-extrabold uppercase tracking-tight text-[9px] text-slate-950">
                                      <categoryConfig.icon size={11} />
                                      <span className="truncate">{note.title || categoryConfig.label.replace(/^[^\s]+\s*/, '')}</span>
                                    </span>
                                    <div className="flex items-center gap-1">
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleAskAiAboutHotspot(msg.id, note);
                                        }}
                                        className="p-1 rounded bg-black/10 hover:bg-black/30 text-slate-950 transition cursor-pointer font-extrabold text-[9px] flex items-center gap-0.5"
                                        title="Ask AI Tutor about this hotspot note"
                                      >
                                        🤖 Ask
                                      </button>
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleDeleteNote(msg.id, note.id);
                                        }}
                                        className="p-1 rounded hover:bg-black/20 text-slate-950 transition cursor-pointer font-extrabold text-[10px]"
                                        title="Delete hotspot note"
                                      >
                                        ✕
                                      </button>
                                    </div>
                                  </div>

                                  {/* Note Content */}
                                  {isEditing ? (
                                    <textarea
                                      autoFocus
                                      value={note.text}
                                      onChange={(e) => {
                                        const val = e.target.value;
                                        setDiagramNotes(prev => ({
                                          ...prev,
                                          [msg.id]: (prev[msg.id] || []).map(n => n.id === note.id ? { ...n, text: val } : n)
                                        }));
                                      }}
                                      onBlur={() => setEditingNoteKey(null)}
                                      onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                          e.preventDefault();
                                          setEditingNoteKey(null);
                                        }
                                      }}
                                      className="w-full bg-black/10 border border-black/20 rounded-xl p-1.5 text-[11px] font-medium leading-tight resize-none outline-none focus:ring-1 focus:ring-black/40 text-slate-950 placeholder-slate-700"
                                      rows={3}
                                    />
                                  ) : (
                                    <div
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setEditingNoteKey(`${msg.id}-${note.id}`);
                                      }}
                                      className="cursor-pointer text-[11px] font-semibold leading-relaxed break-words hover:opacity-90 p-1 text-slate-950"
                                      title="Click to edit text"
                                    >
                                      {note.text || <span className="italic opacity-60">Click to enter note...</span>}
                                    </div>
                                  )}

                                  {/* Footer timestamp */}
                                  {note.timestamp && (
                                    <div className="text-[8px] opacity-60 font-mono text-right mt-1 pt-1 border-t border-black/10 text-slate-950">
                                      {note.timestamp}
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}

                          {/* Dynamic Corner Resizing Handle */}
                          <div
                            onMouseDown={(e) => handleResizeStart(e, msg.id)}
                            onTouchStart={(e) => handleResizeStart(e, msg.id)}
                            onDoubleClick={(e) => {
                              e.stopPropagation();
                              setDiagramSizes(prev => {
                                const next = { ...prev };
                                delete next[msg.id];
                                return next;
                              });
                              showNotification?.('Diagram dimensions reset to default', 'info');
                            }}
                            className={cn(
                              "absolute bottom-0 right-0 z-40 w-7 h-7 rounded-tl-xl flex items-center justify-center cursor-se-resize select-none transition-all shadow-md",
                              resizingDiagramId === msg.id 
                                ? "bg-amber-400 text-slate-950 scale-110 ring-2 ring-amber-300 z-50" 
                                : "bg-slate-950/80 hover:bg-amber-500 hover:text-slate-950 text-slate-300 border-t border-l border-white/20 backdrop-blur-sm opacity-80 hover:opacity-100"
                            )}
                            title="Drag corner handle to scale diagram container (Double-click to reset size)"
                          >
                            <MoveDiagonal size={13} className="rotate-90" />
                          </div>

                          {/* Floating Dimensions Tooltip while resizing */}
                          {resizingDiagramId === msg.id && diagramSizes[msg.id] && (
                            <div className="absolute bottom-2 right-9 z-50 px-2 py-1 rounded-md bg-slate-950/90 text-amber-400 font-mono text-[10px] font-bold border border-amber-500/40 shadow-xl pointer-events-none">
                              {diagramSizes[msg.id]?.width} × {diagramSizes[msg.id]?.height} px
                            </div>
                          )}
                        </div>

                        {/* Automatically Generated Diagram Legend & Node Key Block */}
                        {showLegendMap[msg.id] !== false && msg.metadata.annotations && msg.metadata.annotations.length > 0 && (
                          <DiagramLegendBlock
                            msgId={msg.id}
                            annotations={msg.metadata.annotations}
                            hoveredAnnoIndex={hoveredAnnoIndex}
                            onHoverAnno={(idx) => setHoveredAnnoIndex(idx !== null ? { msgId: msg.id, index: idx } : null)}
                            onSelectAnno={(anno, idx) => {
                              setHoveredAnnoIndex({ msgId: msg.id, index: idx });
                              setActiveAnnoModal({ msgId: msg.id, anno, index: idx });
                              const imgEl = document.getElementById(`diagram-image-${msg.id}`);
                              if (imgEl) {
                                imgEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                              }
                            }}
                            annoColors={annoColors}
                            colorPresets={colorPresets}
                            showNotification={showNotification}
                            theme={theme}
                            topicTitle={msg.metadata.topic || 'Diagram Analysis'}
                          />
                        )}

                        {msg.metadata.annotations && msg.metadata.annotations.length > 0 && (() => {
                          const currentStyle = styleSettings[msg.id] || { thickness: '2', glow: 'medium', size: 'md' };
                          const folders = annotationFolders[msg.id] || [];

                          return (
                            <div className="max-w-md p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
                              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                                <p className="text-[10px] font-black uppercase tracking-wider text-slate-400">Interactive Hotspots & Folders:</p>
                                <div className="flex items-center gap-1.5 flex-wrap justify-end">
                                  <button
                                    onClick={() => {
                                      const allIndices = new Set<number>(msg.metadata.annotations.map((_: any, idx: number) => idx));
                                      setSelectedAnnoIndices(prev => ({ ...prev, [msg.id]: allIndices }));
                                      showNotification?.("All hotspots selected", "info");
                                    }}
                                    className="px-2 py-0.5 text-[9px] font-bold uppercase rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                                  >
                                    Select All
                                  </button>
                                  <button
                                    onClick={() => {
                                      const current = expandedAllMap[msg.id];
                                      const nextState = !current;
                                      setExpandedAllMap(prev => ({ ...prev, [msg.id]: nextState }));
                                      if (nextState) {
                                        const allSet = new Set<number>(msg.metadata.annotations.map((_: any, idx: number) => idx));
                                        setExpandedAnnoIndices(prev => ({ ...prev, [msg.id]: allSet }));
                                        showNotification?.("Expanded all annotation detail views", "info");
                                      } else {
                                        setExpandedAnnoIndices(prev => ({ ...prev, [msg.id]: new Set() }));
                                        showNotification?.("Collapsed all annotation detail views", "info");
                                      }
                                    }}
                                    className="px-2 py-0.5 text-[9px] font-bold uppercase rounded bg-indigo-950/80 border border-indigo-500/30 hover:bg-indigo-900 text-indigo-300 transition cursor-pointer"
                                  >
                                    {expandedAllMap[msg.id] ? '📁 Collapse All' : '📂 Expand All'}
                                  </button>
                                  <button
                                    onClick={() => setActivePaletteMsgId(msg.id)}
                                    className="px-2 py-0.5 text-[9px] font-bold uppercase rounded bg-purple-950/80 border border-purple-500/30 hover:bg-purple-900 text-purple-300 transition cursor-pointer"
                                    title="Open Color Palette & Category Highlights"
                                  >
                                    🎨 Palette
                                  </button>
                                  {selectedAnnoIndices[msg.id]?.size > 0 && (
                                    <button
                                      onClick={() => {
                                        const selectedSet = selectedAnnoIndices[msg.id];
                                        if (!selectedSet || selectedSet.size === 0) return;
                                        if (confirm(`Delete ${selectedSet.size} selected hotspot(s)?`)) {
                                          const newAnns = msg.metadata.annotations.filter((_: any, idx: number) => !selectedSet.has(idx));
                                          setLocalMessages(prev => prev.map(m => {
                                            if (m.id === msg.id && m.metadata) {
                                              const updated = { ...m, metadata: { ...m.metadata, annotations: newAnns } };
                                              saveAnnotationsToLocalStorage(msg.id, newAnns);
                                              return updated;
                                            }
                                            return m;
                                          }));
                                          setSelectedAnnoIndices(prev => ({ ...prev, [msg.id]: new Set() }));
                                          showNotification?.("Deleted selected hotspots successfully", "success");
                                        }
                                      }}
                                      className="px-2 py-0.5 text-[9px] font-bold uppercase rounded bg-rose-950/80 hover:bg-rose-900 text-rose-300 transition cursor-pointer"
                                    >
                                      Delete Selected ({selectedAnnoIndices[msg.id]?.size})
                                    </button>
                                  )}
                                  <button
                                    onClick={() => handleUndoAnnotation(msg.id)}
                                    className="px-2 py-0.5 text-[9px] font-bold uppercase rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                                    title="Undo position change"
                                  >
                                    ↩ Undo
                                  </button>
                                  <button
                                    onClick={() => handleRedoAnnotation(msg.id)}
                                    className="px-2 py-0.5 text-[9px] font-bold uppercase rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                                    title="Redo position change"
                                  >
                                    Redo ↪
                                  </button>
                                  <button
                                    onClick={() => {
                                      if (confirm("Restore all hotspot coordinates to original AI analysis values?")) {
                                        const orig = originalAnnotationsMap[msg.id];
                                        if (orig) {
                                          setLocalMessages(prev => prev.map(m => {
                                            if (m.id === msg.id && m.metadata) {
                                              const updated = { ...m, metadata: { ...m.metadata, annotations: JSON.parse(JSON.stringify(orig)) } };
                                              saveAnnotationsToLocalStorage(msg.id, orig);
                                              return updated;
                                            }
                                            return m;
                                          }));
                                          showNotification?.("Reset all hotspot positions successfully!", "success");
                                        }
                                      }
                                    }}
                                    className="px-2 py-0.5 text-[9px] font-bold uppercase rounded bg-rose-950/60 border border-rose-500/30 hover:bg-rose-900 text-rose-300 transition cursor-pointer"
                                    title="Reset all positions to original AI analysis"
                                  >
                                    Reset Positions
                                  </button>
                                </div>
                              </div>

                              {/* Style Preview Controls */}
                              <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                                <div className="text-[10px] font-black text-indigo-400 uppercase tracking-wider">Style Preview & Customization</div>
                                <div className="grid grid-cols-3 gap-2 text-[10px]">
                                  <div>
                                    <span className="text-slate-400 block mb-1">Border Thickness</span>
                                    <div className="flex gap-1">
                                      {(['2', '4', '6'] as const).map(th => (
                                        <button
                                          key={th}
                                          onClick={() => setStyleSettings(prev => ({ ...prev, [msg.id]: { ...currentStyle, thickness: th } }))}
                                          className={cn("flex-1 py-0.5 rounded font-bold cursor-pointer", currentStyle.thickness === th ? "bg-indigo-600 text-white" : "bg-slate-900 text-slate-400 hover:bg-slate-700")}
                                        >
                                          {th}px
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                  <div>
                                    <span className="text-slate-400 block mb-1">Glow Intensity</span>
                                    <div className="flex gap-1">
                                      {(['low', 'medium', 'high'] as const).map(gl => (
                                        <button
                                          key={gl}
                                          onClick={() => setStyleSettings(prev => ({ ...prev, [msg.id]: { ...currentStyle, glow: gl } }))}
                                          className={cn("flex-1 py-0.5 rounded font-bold uppercase cursor-pointer", currentStyle.glow === gl ? "bg-indigo-600 text-white" : "bg-slate-900 text-slate-400 hover:bg-slate-700")}
                                        >
                                          {gl[0]}
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                  <div>
                                    <span className="text-slate-400 block mb-1">Icon Size</span>
                                    <div className="flex gap-1">
                                      {(['sm', 'md', 'lg'] as const).map(sz => (
                                        <button
                                          key={sz}
                                          onClick={() => setStyleSettings(prev => ({ ...prev, [msg.id]: { ...currentStyle, size: sz } }))}
                                          className={cn("flex-1 py-0.5 rounded font-bold uppercase cursor-pointer", currentStyle.size === sz ? "bg-indigo-600 text-white" : "bg-slate-900 text-slate-400 hover:bg-slate-700")}
                                        >
                                          {sz}
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              </div>

                              {/* Folders Management */}
                              <div className="space-y-2">
                                <div className="flex items-center gap-2">
                                  <input
                                    type="text"
                                    placeholder="New Sub-topic Folder (e.g. Topology)..."
                                    value={newFolderNameInput[msg.id] || ''}
                                    onChange={(e) => setNewFolderNameInput(prev => ({ ...prev, [msg.id]: e.target.value }))}
                                    className="flex-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                                  />
                                  <button
                                    onClick={() => {
                                      const folderName = newFolderNameInput[msg.id]?.trim();
                                      if (!folderName) return;
                                      const newFolder = { id: Math.random().toString(36).substring(2, 9), name: folderName, indices: msg.metadata.annotations.map((_: any, idx: number) => idx), hidden: false };
                                      setAnnotationFolders(prev => ({ ...prev, [msg.id]: [...(prev[msg.id] || []), newFolder] }));
                                      setNewFolderNameInput(prev => ({ ...prev, [msg.id]: '' }));
                                      showNotification?.(`Created folder "${folderName}" successfully`, "success");
                                    }}
                                    className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs cursor-pointer transition"
                                  >
                                    + Folder
                                  </button>
                                </div>

                                {folders.map(folder => (
                                  <div key={folder.id} className="p-2.5 rounded-xl bg-slate-800/90 border border-slate-700 space-y-2">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <span className="font-bold text-indigo-300 text-xs">📁 {folder.name}</span>
                                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 font-mono">({folder.indices.length} items)</span>
                                      </div>
                                      <div className="flex items-center gap-1.5">
                                        <button
                                          onClick={() => {
                                            setAnnotationFolders(prev => ({
                                              ...prev,
                                              [msg.id]: (prev[msg.id] || []).map(f => f.id === folder.id ? { ...f, hidden: !f.hidden } : f)
                                            }));
                                          }}
                                          className="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-700 text-[10px] text-slate-300 font-bold cursor-pointer"
                                        >
                                          {folder.hidden ? '👁️ Show Folder' : '👁️ Hide Folder'}
                                        </button>
                                        <button
                                          onClick={() => {
                                            setAnnotationFolders(prev => ({
                                              ...prev,
                                              [msg.id]: (prev[msg.id] || []).filter(f => f.id !== folder.id)
                                            }));
                                          }}
                                          className="text-slate-400 hover:text-rose-400 text-xs px-1"
                                          title="Delete folder"
                                        >
                                          ✕
                                        </button>
                                      </div>
                                    </div>
                                    {!folder.hidden && (
                                      <div className="flex flex-wrap gap-1.5 pt-1">
                                        {folder.indices.map(i => {
                                          const anno = msg.metadata.annotations[i];
                                          if (!anno) return null;
                                          const isHighlighted = hoveredAnnoIndex?.msgId === msg.id && hoveredAnnoIndex?.index === i;
                                          const customColorKey = `${msg.id}-${i}`;
                                          const chosenPreset = colorPresets.find(p => p.label === annoColors[customColorKey]) || colorPresets[0];

                                          return (
                                            <div
                                              key={i}
                                              onMouseEnter={() => setHoveredAnnoIndex({ msgId: msg.id, index: i })}
                                              onMouseLeave={() => setHoveredAnnoIndex(null)}
                                              onClick={() => {
                                                setHoveredAnnoIndex({ msgId: msg.id, index: i });
                                                setActiveAnnoModal({ msgId: msg.id, anno, index: i });
                                                const el = document.getElementById(`diagram-image-${msg.id}`);
                                                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                              }}
                                              className="px-2 py-1 rounded-lg bg-slate-900/90 border border-slate-700 text-xs text-white flex items-center gap-1.5 cursor-pointer hover:border-indigo-500 transition"
                                            >
                                              <span className={cn("w-2 h-2 rounded-full", chosenPreset.bg)} />
                                              <span>#{i + 1} {anno.label}</span>
                                            </div>
                                          );
                                        })}
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>

                              <div className="flex flex-wrap gap-1.5 pt-1">
                                {msg.metadata.annotations.map((anno: any, i: number) => {
                                  const isHighlighted = hoveredAnnoIndex?.msgId === msg.id && hoveredAnnoIndex?.index === i;
                                  const isRepositioningThis = repositioningAnno?.msgId === msg.id && repositioningAnno?.index === i;
                                  const customColorKey = `${msg.id}-${i}`;
                                  const currentColorLabel = annoColors[customColorKey] || colorPresets[0].label;
                                  const isSelected = selectedAnnoIndices[msg.id]?.has(i) || false;

                                  return (
                                    <div
                                      key={i}
                                      onMouseEnter={() => setHoveredAnnoIndex({ msgId: msg.id, index: i })}
                                      onMouseLeave={() => setHoveredAnnoIndex(null)}
                                      onClick={() => {
                                        setHoveredAnnoIndex({ msgId: msg.id, index: i });
                                        setActiveAnnoModal({ msgId: msg.id, anno, index: i });
                                        setZoomLevels(prev => ({ ...prev, [msg.id]: 2 }));
                                        const imgEl = document.getElementById(`diagram-image-${msg.id}`);
                                        if (imgEl) {
                                          imgEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                        }
                                      }}
                                      className={cn(
                                        "p-2 rounded-xl text-xs font-bold transition cursor-pointer flex flex-col gap-1.5 border group",
                                        isSelected ? "ring-2 ring-indigo-400 bg-indigo-950/30" : "",
                                        isHighlighted
                                          ? "bg-amber-500/20 border-amber-500 text-amber-300 shadow-md scale-[1.02]"
                                          : "bg-slate-800/80 border-slate-700 text-slate-300 hover:border-slate-500"
                                      )}
                                    >
                                      <div className="flex items-center justify-between w-full gap-2">
                                        <div className="flex items-center gap-1.5">
                                          <input
                                            type="checkbox"
                                            checked={isSelected}
                                            onChange={(e) => {
                                              e.stopPropagation();
                                              setSelectedAnnoIndices(prev => {
                                                const currentSet = new Set(prev[msg.id] || []);
                                                if (e.target.checked) currentSet.add(i);
                                                else currentSet.delete(i);
                                                return { ...prev, [msg.id]: currentSet };
                                              });
                                            }}
                                            className="w-3.5 h-3.5 rounded border-slate-700 accent-indigo-500 cursor-pointer"
                                            title="Multi-select hotspot"
                                          />
                                          <span className="w-4 h-4 rounded-full bg-blue-500 text-white flex items-center justify-center text-[10px] font-mono shrink-0">
                                            {i + 1}
                                          </span>
                                          {editingAnnoIndex?.msgId === msg.id && editingAnnoIndex?.index === i ? (
                                            <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                                              <input
                                                type="text"
                                                value={editingAnnoLabel}
                                                onChange={(e) => setEditingAnnoLabel(e.target.value)}
                                                onKeyDown={(e) => {
                                                  if (e.key === 'Enter') handleRenameAnnotation(msg.id, i, editingAnnoLabel);
                                                  if (e.key === 'Escape') setEditingAnnoIndex(null);
                                                }}
                                                className="px-1.5 py-0.5 rounded bg-slate-900 border border-indigo-500 text-xs text-white focus:outline-none w-24"
                                                autoFocus
                                              />
                                              <button
                                                onClick={() => handleRenameAnnotation(msg.id, i, editingAnnoLabel)}
                                                className="text-[10px] text-emerald-400 font-bold px-1 py-0.5 hover:bg-slate-700 rounded"
                                                title="Save label"
                                              >
                                                ✓
                                              </button>
                                              <button
                                                onClick={() => setEditingAnnoIndex(null)}
                                                className="text-[10px] text-slate-400 font-bold px-1 py-0.5 hover:bg-slate-700 rounded"
                                                title="Cancel"
                                              >
                                                ✕
                                              </button>
                                            </div>
                                          ) : (
                                            <div className="flex items-center gap-1">
                                              <span className="truncate max-w-[100px] font-bold text-white">{anno.label}</span>
                                              <button
                                                onClick={(e) => {
                                                  e.stopPropagation();
                                                  setEditingAnnoIndex({ msgId: msg.id, index: i });
                                                  setEditingAnnoLabel(anno.label);
                                                }}
                                                className="text-[10px] text-slate-400 hover:text-amber-300 opacity-60 hover:opacity-100 transition"
                                                title="Rename label"
                                              >
                                                ✏️
                                              </button>
                                            </div>
                                          )}
                                        </div>
                                        <div className="flex items-center gap-1">
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              const currentSet = new Set(expandedAnnoIndices[msg.id] || []);
                                              if (currentSet.has(i)) currentSet.delete(i);
                                              else currentSet.add(i);
                                              setExpandedAnnoIndices(prev => ({ ...prev, [msg.id]: currentSet }));
                                            }}
                                            className="text-[9px] text-slate-400 hover:text-indigo-300 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 cursor-pointer"
                                            title="Toggle detail view"
                                          >
                                            {(expandedAnnoIndices[msg.id]?.has(i) || expandedAllMap[msg.id]) ? '▲ Less' : '▼ Details'}
                                          </button>
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              const base = getSyncShareUrl().split('#')[0];
                                              const link = `${base}#hotspot=${msg.id}-${i}`;
                                              navigator.clipboard.writeText(link);
                                              showNotification?.(`Copied share link for Hotspot #${i + 1} to clipboard!`, "success");
                                            }}
                                            className="text-[9px] text-slate-400 hover:text-indigo-400 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 cursor-pointer"
                                            title="Copy direct share link to this hotspot"
                                          >
                                            🔗 Share
                                          </button>
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setRepositioningAnno({ msgId: msg.id, index: i });
                                              showNotification?.(`Click anywhere on the diagram to reposition Hotspot #${i + 1}`, "info");
                                            }}
                                            className="text-[9px] text-slate-400 hover:text-amber-400 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 cursor-pointer"
                                            title="Reposition coordinates"
                                          >
                                            {isRepositioningThis ? 'Placing...' : 'Move'}
                                          </button>
                                        </div>
                                      </div>

                                      {/* Expanded Annotation Detail View */}
                                      {(expandedAnnoIndices[msg.id]?.has(i) || expandedAllMap[msg.id]) && (
                                        <div className="mt-1.5 p-2.5 rounded-xl bg-slate-900/90 border border-indigo-500/20 text-slate-200 text-xs space-y-1.5 animate-in fade-in" onClick={(e) => e.stopPropagation()}>
                                          <div className="text-[10px] font-black uppercase text-amber-400 tracking-wider">Concept Explanation</div>
                                          <p className="text-slate-300 text-[11px] leading-relaxed font-normal">{anno.description}</p>
                                          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1 border-t border-slate-800">
                                            <span>Coordinates: X: {anno.x}%, Y: {anno.y}%</span>
                                            <span className="text-indigo-400 font-bold">Node #{i + 1}</span>
                                          </div>
                                        </div>
                                      )}

                                      {/* Color Picker Toggles */}
                                      <div className="flex items-center gap-1 pt-1 border-t border-slate-700/50" onClick={(e) => e.stopPropagation()}>
                                        <span className="text-[9px] text-slate-400 mr-1">Color:</span>
                                        {colorPresets.map(preset => (
                                          <button
                                            key={preset.label}
                                            onClick={() => {
                                              const selectedSet = selectedAnnoIndices[msg.id];
                                              if (selectedSet && selectedSet.has(i) && selectedSet.size > 1) {
                                                const newColors = { ...annoColors };
                                                selectedSet.forEach(idx => {
                                                  newColors[`${msg.id}-${idx}`] = preset.label;
                                                });
                                                setAnnoColors(newColors);
                                              } else {
                                                setAnnoColors(prev => ({ ...prev, [customColorKey]: preset.label }));
                                              }
                                            }}
                                            className={cn(
                                              "w-3.5 h-3.5 rounded-full transition cursor-pointer border",
                                              preset.bg,
                                              currentColorLabel === preset.label ? "ring-2 ring-white scale-110 border-white" : "border-transparent opacity-70 hover:opacity-100"
                                            )}
                                            title={preset.label}
                                          />
                                        ))}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    )}

                    {msg.metadata?.videoUrl && (
                      <VideoWithOverlay 
                        src={msg.metadata.videoUrl} 
                        events={msg.metadata.events}
                        initialTimestamp={msg.metadata?.lectureBookmark?.timestampSec || activeLectureBookmark?.timestampSec}
                        isPlaying={isLectureVideoPlaying}
                        onBookmarkCreated={(time, title) => saveLectureBookmark(`Video Bookmark: ${title}`, msg.id, 0, time * 1000)}
                        className="mb-4 max-w-md border border-white/10 shadow-2xl"
                      />
                    )}

                    {readyMessages.has(msg.id) && (() => {
                      const paragraphs = msg.content ? msg.content.split(/\n\n+/) : [''];
                      const hasSplitParas = activeAnchor === 'middle' && paragraphs.length > 1;

                      return (
                        <>
                          <div className={cn(
                            msg.metadata?.image 
                              ? activeAnchor === 'bottom' 
                                ? "order-1" 
                                : activeAnchor === 'middle' 
                                  ? "order-1" 
                                  : "order-2" 
                              : "order-1"
                          )}>
                            <TypewriterMarkdown 
                              content={hasSplitParas ? paragraphs[0] : msg.content} 
                              isAnimated={isLectureMode || msg.id === messages[messages.length - 1]?.id} 
                              isChalkSfxEnabled={isChalkSfxEnabled}
                              theme={theme}
                              speakingWordIndex={speakingMessageId === msg.id ? speakingWordIndex : -1}
                              isCurrentSpeaking={speakingMessageId === msg.id && isSpeaking}
                              isPaused={isPaused}
                              typingPace={typingPace}
                              blackboardWritingSpeed={blackboardWritingSpeed}
                              isWordHighlightingEnabled={isWordHighlightingEnabled}
                              onTypingProgress={() => scrollToBottom(true)}
                              onComplete={() => handleTypewriterComplete(msg.id, msg.content)}
                              isLectureMode={isLectureMode}
                              analyser={speakingMessageId === msg.id ? analyserRef.current : null}
                              onSendMessage={onSendMessage}
                              scrollDuration={scrollDuration}
                              scrollEasing={scrollEasing}
                              scrollThreshold={scrollThreshold}
                              scrollTargetCenter={scrollTargetCenter}
                              isAdaptiveSpeedEnabled={isAdaptiveSpeedEnabled}
                              isBreathingPausesEnabled={isBreathingPausesEnabled}
                              isSpotlightEnabled={isSpotlightEnabled}
                              ttsRate={ttsRate}
                              isVoiceTrackingEnabled={isVoiceTrackingEnabled}
                              isAutoScrollPaused={isAutoScrollPaused}
                              pronunciationPrecision={pronunciationPrecision}
                              isRecordingAi={isRecordingAi}
                              onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                              showNotification={showNotification}
                              onRenderComplete={() => {
                                if (setIsDiagramRendering) setIsDiagramRendering(false);
                                if (setIsClassroomMute) setIsClassroomMute(false);
                              }}
                              canvasUiManager={canvasUiManager}
                            />
                          </div>
                          {(() => {
                            const c = localTranslations[msg.id] || msg.content;
                            if (!c) return null;
                            if ((c.includes('Newton-Raphson') || c.includes('न्यूटन-राफसन')) && (c.includes('x^3 - x - 2') || c.includes('x3 - x - 2') || c.includes('x³ - x - 2') || c.includes('x**3 - x - 2'))) {
                              return <NewtonRaphsonGraph funcStr="x**3 - x - 2" derivStr="3*x**2 - 1" x0={2} iterations={4} theme={theme} />;
                            }
                            const detectedFuncs = detectMathFunctions(c);
                            if (detectedFuncs.length > 0) {
                              return <MathGraph functions={detectedFuncs} theme={theme} />;
                            }

                            // Auto-render SVG 2D vector teaching schematics in Classroom Blackboard Mode
                            if (c.includes('<svg') && c.includes('</svg>') && !c.includes('```xml') && !c.includes('```svg')) {
                              const svgMatches = c.match(/<svg[\s\S]*?<\/svg>/gi);
                              if (svgMatches && svgMatches.length > 0) {
                                return (
                                  <div className="my-4 space-y-3">
                                    {canvasUiManager && (
                                      <div className="mb-2">
                                        <CanvasOverlayToolbar manager={canvasUiManager} showNotification={showNotification} compact={true} />
                                      </div>
                                    )}
                                    {svgMatches.map((svgStr, sIdx) => (
                                      <SvgDiagramViewer
                                        key={sIdx}
                                        svgCode={svgStr}
                                        theme="dark"
                                        title={`2D Vector Teaching Schematic #${sIdx + 1}`}
                                        onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                                        showNotification={showNotification}
                                        onRenderComplete={() => {
                                          if (setIsDiagramRendering) setIsDiagramRendering(false);
                                          if (setIsClassroomMute) setIsClassroomMute(false);
                                        }}
                                        isHighContrast={canvasUiManager?.state.highContrast}
                                        isVectorDragMode={canvasUiManager?.state.dragHandles}
                                        showVectorTelemetry={canvasUiManager?.state.vectorStats}
                                        isMagnifierActive={canvasUiManager?.state.magnifier}
                                        isChalkMode={canvasUiManager?.state.chalkDraw}
                                        showGrid={canvasUiManager?.state.grid}
                                        onToggleHighContrast={canvasUiManager?.toggleHighContrast}
                                        onToggleVectorDragMode={canvasUiManager?.toggleDragHandles}
                                        onToggleVectorTelemetry={canvasUiManager?.toggleVectorStats}
                                        onToggleMagnifier={canvasUiManager?.toggleMagnifier}
                                        onToggleChalkMode={canvasUiManager?.toggleChalkDraw}
                                        onToggleGrid={canvasUiManager?.toggleGrid}
                                      />
                                    ))}
                                  </div>
                                );
                              }
                            }
                            return null;
                          })()}

                          {/* Inline Continuation for Middle Anchor */}
                          {hasSplitParas && (
                            <div className="order-3 mt-2">
                              <TypewriterMarkdown 
                                content={paragraphs.slice(1).join('\n\n')} 
                                isAnimated={false} 
                                isChalkSfxEnabled={isChalkSfxEnabled}
                                theme={theme}
                                speakingWordIndex={-1}
                                isCurrentSpeaking={false}
                                isPaused={isPaused}
                                typingPace={typingPace}
                                isWordHighlightingEnabled={isWordHighlightingEnabled}
                                isLectureMode={isLectureMode}
                                onSendMessage={onSendMessage}
                                onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                                showNotification={showNotification}
                                canvasUiManager={canvasUiManager}
                              />
                            </div>
                          )}
                        </>
                      );
                    })()}
                        </>
                      );
                    })()}

                    {/* Interactive Chalkboard Concept Quiz */}
                    {messageQuizzes[msg.id] ? (
                      <div className="mt-5 border border-dashed border-emerald-300/20 rounded-2xl bg-black/20 p-4 relative z-20 animate-in slide-in-from-top-4 duration-300">
                        <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
                          <span className="text-[10px] font-black text-emerald-300 uppercase tracking-widest flex items-center gap-1">
                            🎓 Classroom Desk Check
                          </span>
                          <button 
                            onClick={() => {
                              playChalkClickSound();
                              const clearedAnswers = { ...selectedAnswers };
                              const clearedExplanations = { ...showQuizExplanations };
                              for (let i = 0; i < messageQuizzes[msg.id].length; i++) {
                                delete clearedAnswers[`${msg.id}_${i}`];
                                delete clearedExplanations[`${msg.id}_${i}`];
                              }
                              setSelectedAnswers(clearedAnswers);
                              setShowQuizExplanations(clearedExplanations);
                              showNotification?.("Quiz restarted!", "info");
                            }}
                            className="text-[9px] uppercase font-black text-white/40 hover:text-white transition-colors cursor-pointer"
                          >
                            Reset Quiz
                          </button>
                        </div>

                        <div className="space-y-4">
                          {messageQuizzes[msg.id].map((q: any, qIdx: number) => {
                            const ansKey = `${msg.id}_${qIdx}`;
                            const chosenOptIdx = selectedAnswers[ansKey]?.[0];
                            const isAnswered = chosenOptIdx !== undefined;

                            return (
                              <div key={qIdx} className="space-y-2 border-b border-white/5 last:border-b-0 pb-3 last:pb-0">
                                <p className="text-xs font-semibold text-emerald-100/95 leading-relaxed">
                                  {qIdx + 1}. {q.question}
                                </p>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                                  {q.options.map((opt: string, optIdx: number) => {
                                    const isSelected = chosenOptIdx === optIdx;
                                    const isCorrectOpt = optIdx === q.correctIndex;
                                    
                                    let btnStyle = "bg-white/5 hover:bg-white/10 border-white/10 text-emerald-50/80";
                                    if (isAnswered) {
                                      if (isCorrectOpt) {
                                        btnStyle = "bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-bold";
                                      } else if (isSelected) {
                                        btnStyle = "bg-red-950/40 border-red-500/50 text-red-300";
                                      } else {
                                        btnStyle = "bg-white/5 opacity-40 border-white/5 text-emerald-50/30";
                                      }
                                    }

                                    return (
                                      <button
                                        key={optIdx}
                                        disabled={isAnswered}
                                        onClick={() => {
                                          playChalkClickSound();
                                          setSelectedAnswers(prev => ({
                                            ...prev,
                                            [ansKey]: [optIdx]
                                          }));
                                          if (optIdx === q.correctIndex) {
                                            playQuizSuccessSound();
                                            showNotification?.("Correct answer! Great job! 🎓", "success");
                                          } else {
                                            playQuizFailureSound();
                                            showNotification?.("Oops! Review the explanation below.", "warning");
                                          }
                                        }}
                                        className={cn(
                                          "w-full text-left px-3 py-2 rounded-xl text-xs border transition-all duration-300",
                                          !isAnswered && "active:scale-[0.98] cursor-pointer",
                                          btnStyle
                                        )}
                                      >
                                        <div className="flex items-start gap-2">
                                          <span className="font-bold text-[9px] bg-white/10 px-1.5 py-0.5 rounded text-white/70">
                                            {String.fromCharCode(65 + optIdx)}
                                          </span>
                                          <span className="flex-1 mt-0.5">{opt}</span>
                                        </div>
                                      </button>
                                    );
                                  })}
                                </div>
                                {isAnswered && q.explanation && (
                                  <div className="text-[10px] text-amber-200/90 leading-relaxed bg-amber-400/5 p-2.5 rounded-lg border border-amber-400/10 mt-2 animate-in fade-in duration-300">
                                    <span className="font-bold uppercase text-[9px] text-amber-400 block mb-0.5">Explanation</span>
                                    {q.explanation}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ) : loadingQuizMessageId === msg.id ? (
                      <div className="mt-5 border border-dashed border-amber-300/20 rounded-2xl bg-black/25 p-5 relative z-20 flex flex-col items-center justify-center text-center space-y-2">
                        <Loader2 className="w-5 h-5 text-amber-300 animate-spin" />
                        <span className="text-[10px] font-black text-amber-300/80 uppercase tracking-widest">
                          Professor is writing questions on the board...
                        </span>
                      </div>
                    ) : null}
                  </div>
                  )}

                  {speakingMessageId === msg.id && isSpeaking && !isPaused && isWaveformVisualizerEnabled && (
                    <div className="mt-4 p-3 bg-black/20 rounded-2xl border border-white/5 flex items-center justify-between gap-3 relative overflow-hidden z-20">
                      {/* Ambient green grid glow */}
                      <div className="absolute inset-0 bg-emerald-500/5 pointer-events-none" />
                      <div className="flex items-center gap-2 relative z-10">
                        <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-emerald-100/60">
                          Live Lecture Waveform
                        </span>
                      </div>
                      <div className="flex-1 max-w-[200px] h-6 flex items-center justify-center relative z-10">
                        <WaveformVisualizer 
                          isAnimating={true} 
                          analyser={analyserRef.current} 
                          color="emerald" 
                          className="w-full h-full" 
                        />
                      </div>
                    </div>
                  )}

                  {/* Board Controls */}
                  <div className="mt-5 pt-3 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 relative z-20">
                    <div className="flex items-center gap-1.5">
                      <button 
                        onClick={() => handleGenerateChalkboardQuiz(msg)}
                        disabled={loadingQuizMessageId !== null}
                        className={cn(
                          "p-1.5 rounded-md transition-all duration-200 cursor-pointer border mr-2",
                          messageQuizzes[msg.id] 
                            ? "text-amber-300 bg-amber-400/10 border-amber-400/30 font-extrabold"
                            : "text-emerald-100/60 bg-white/5 border-white/10 hover:text-amber-300 hover:bg-white/10 hover:border-white/20",
                          loadingQuizMessageId === msg.id && "animate-pulse"
                        )}
                        title={
                          loadingQuizMessageId === msg.id 
                            ? "Crafting concept check quiz..." 
                            : messageQuizzes[msg.id] 
                              ? "Close Concept Check Quiz" 
                              : "Take an interactive Concept Check Quiz"
                        }
                      >
                        {loadingQuizMessageId === msg.id ? (
                          <Loader2 size={14} className="animate-spin text-amber-300" />
                        ) : (
                          <GraduationCap size={14} />
                        )}
                      </button>

                      {(() => {
                        const conceptInfo = detectNewConcept(msg.content);
                        if (!conceptInfo.introduced) return null;
                        return (
                          <button
                            onClick={() => {
                              playChalkClickSound();
                              onOpenTool?.('quiz', { subject, topic: conceptInfo.conceptName || topic });
                            }}
                            className="flex items-center gap-1.5 text-[10px] uppercase font-black px-2.5 py-1.5 rounded-md bg-indigo-500/25 text-indigo-200 border border-indigo-500/30 hover:bg-indigo-500/35 transition-all duration-200 cursor-pointer animate-pulse"
                            title={`Practice interactive quiz for: ${conceptInfo.conceptName || topic || 'this concept'}`}
                          >
                            <Brain size={12} className="text-indigo-400" />
                            Practice Quick Quiz
                          </button>
                        );
                      })()}

                      <button 
                        onClick={() => setActiveLangMenuMessageId(activeLangMenuMessageId === msg.id ? null : msg.id)}
                        className="flex items-center gap-1 text-[10px] uppercase font-black text-emerald-100/60 hover:text-amber-300 transition-colors cursor-pointer"
                      >
                        <Languages size={12} /> {LANGUAGES.find(l => l.code === language)?.flag} {LANGUAGES.find(l => l.code === language)?.name} <ChevronDown size={12} />
                      </button>

                      {activeLangMenuMessageId === msg.id && (
                        <>
                          <div className="fixed inset-0 z-40 cursor-default" onClick={() => setActiveLangMenuMessageId(null)} />
                          <div className={cn(
                            "absolute bottom-full left-0 mb-2 w-48 rounded-xl shadow-xl border p-2 z-50 animate-in fade-in slide-in-from-top-2",
                            theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-slate-950/80" : "bg-white border-slate-200 shadow-slate-200/50"
                          )}>
                            <div className="px-2 py-1 text-[9px] font-black uppercase tracking-wider text-slate-400 mb-1">Translate Output</div>
                            {LANGUAGES.map(lang => (
                              <button
                                key={lang.code}
                                className={cn(
                                  "w-full text-left px-2 py-1.5 text-xs rounded-lg flex items-center justify-between cursor-pointer",
                                  language === lang.code ? "bg-indigo-50 text-indigo-600 font-medium" : (theme === 'dark' ? "hover:bg-slate-800 text-slate-300" : "hover:bg-slate-50 text-slate-700")
                                )}
                                onClick={() => {
                                  handleTranslate(msg.id, msg.content, lang.name, lang.code);
                                  setActiveLangMenuMessageId(null);
                                }}
                              >
                                <span className="flex items-center gap-2">{lang.flag} {lang.name}</span>
                              </button>
                            ))}
                          </div>
                        </>
                      )}
                      {/* Start Lesson button after translation drop-down list button */}
                      <button
                        onClick={() => handleInitiateVirtualLesson(msg, true)}
                        disabled={initializingLessonMessageId === msg.id}
                        className={cn(
                          "flex items-center gap-1 text-[10px] uppercase font-black px-2.5 py-1 rounded-md border transition-all cursor-pointer shadow-sm ml-1 relative overflow-hidden",
                          initializingLessonMessageId === msg.id
                            ? "bg-emerald-500/40 text-emerald-100 border-emerald-400 ring-2 ring-emerald-400/40 animate-pulse cursor-wait"
                            : "bg-emerald-500/20 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/30 active:scale-95"
                        )}
                        title="Start interactive lecture and audio explanation for this lesson"
                      >
                        {initializingLessonMessageId === msg.id ? (
                          <>
                            <Sparkles size={11} className="text-amber-300 animate-spin" />
                            <span className="animate-pulse">Initializing...</span>
                            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping ml-0.5" />
                          </>
                        ) : (
                          <>
                            <Play size={11} className="text-emerald-400 fill-emerald-400" /> Start Lesson
                          </>
                        )}
                      </button>
                    </div>

                    <div className="flex items-center gap-1 bg-black/20 p-0.5 rounded-lg border border-white/5">
                      {/* Share button */}
                      <button
                        onClick={() => handleShareMessage(msg)}
                        className="p-1.5 rounded-md transition-colors text-emerald-100/60 hover:text-amber-300 hover:bg-white/5 cursor-pointer"
                        title="Share lecture content"
                      >
                        <Share2 size={14} />
                      </button>

                      <button
                        onClick={() => {
                          if (!isRecordingAi) {
                            recordingStartTime.current = Date.now();
                            setRecordedEvents([]);
                          }
                          setIsRecordingAi(!isRecordingAi);
                          if (isRecordingAi && onGenerateVideo) {
                             // This might need to pass metadata. For now, let's just trigger.
                             // Wait, I need to pass metadata to onGenerateVideo.
                             // ChatProps needs to be updated.
                             onGenerateVideo(recordedEvents);
                            showNotification?.('Sending chat context to Video Mode...', 'info');
                          }
                        }}
                        className={cn(
                          "p-1.5 rounded-md transition-colors cursor-pointer",
                          isRecordingAi ? "text-red-500 bg-red-500/10" : "text-emerald-100/60 hover:text-red-300 hover:bg-white/5"
                        )}
                        title={isRecordingAi ? "Stop Recording & Send to Video Mode" : "Start Recording & Send to Video Mode"}
                      >
                        <Mic size={14} className={isRecordingAi ? "animate-pulse" : ""} />
                      </button>

                      {/* Speaker / Read Aloud button */}
                      <button 
                        onClick={() => handleStartReading(msg.id, localTranslations[msg.id] || msg.content)}
                        className={cn(
                          "p-1.5 rounded-md transition-all duration-300 hover:scale-110 hover:shadow-sm relative overflow-hidden",
                          (speakingMessageId === msg.id && isSpeaking)
                            ? "text-amber-300 bg-white/10 font-bold"
                            : "text-emerald-100/60 hover:text-amber-300 hover:bg-white/5"
                        )}
                        title="Read Aloud: Play speech from the beginning"
                      >
                        <Volume2 size={14} />
                        {speakingMessageId === msg.id && isSpeaking && !isPaused && (
                          <motion.div 
                            className="absolute inset-0 bg-amber-400/20"
                            animate={{
                              opacity: [0.1, 0.4, 0.1],
                              scale: [1, 1.2, 1],
                            }}
                            transition={{
                              duration: 1.5,
                              repeat: Infinity,
                              ease: "easeInOut"
                            }}
                          />
                        )}
                      </button>

                      {speakingMessageId === msg.id && isSpeaking && (
                        <>
                          <button 
                            onClick={handleRewind}
                            className="p-1.5 rounded-md text-emerald-100/60 hover:text-amber-300 hover:bg-white/5 transition-all"
                            title="Rewind 5 seconds"
                          >
                            <RotateCcw size={14} />
                          </button>

                          <button 
                            onClick={() => handlePauseResume()}
                            className={cn(
                              "p-1.5 rounded-md transition-all duration-300 hover:scale-110 hover:shadow-sm",
                              (speakingMessageId === msg.id && isSpeaking)
                                ? isPaused
                                  ? "text-emerald-400 bg-white/5"
                                  : "text-amber-300 bg-white/10 animate-pulse"
                                : "text-emerald-100/20 cursor-not-allowed opacity-50"
                            )}
                            title={(speakingMessageId === msg.id && isSpeaking) ? (isPaused ? "Resume speech" : "Pause speech") : "Pause & Resume (Active when reading is playing)"}
                            disabled={!(speakingMessageId === msg.id && isSpeaking)}
                          >
                            {isPaused && speakingMessageId === msg.id ? <Play size={14} className="fill-current" /> : <Pause size={14} />}
                          </button>

                          <button 
                            onClick={handleForward}
                            className="p-1.5 rounded-md text-emerald-100/60 hover:text-amber-300 hover:bg-white/5 transition-all"
                            title="Forward 5 seconds"
                          >
                            <RotateCw size={14} />
                          </button>

                          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-black/20 border border-white/10 ml-1">
                            <span className="text-[9px] font-mono font-bold text-amber-300 min-w-[28px]">{ttsRate.toFixed(1)}x</span>
                            <input 
                              type="range"
                              min="0.5"
                              max="2.0"
                              step="0.1"
                              value={ttsRate}
                              onChange={(e) => {
                                const rate = parseFloat(e.target.value);
                                setTtsRate(rate);
                                localStorage.setItem('omni_tts_rate', String(rate));
                              }}
                              className="w-16 h-1 rounded appearance-none cursor-pointer accent-amber-400 bg-white/30"
                              title="Adjust active lecture speech playback speed"
                            />
                          </div>
                        </>
                      )}

                      {/* Download Video button (if present) */}
                      {msg.metadata?.videoUrl && (
                        <button 
                          onClick={() => {
                            downloadFileFromUrl(msg.metadata.videoUrl, `ai_lesson_video_${msg.id}.mp4`);
                          }}
                          className="flex items-center gap-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider px-2 py-1 rounded-md transition-all cursor-pointer shadow-md"
                          title="Download AI Generated Video"
                        >
                          <Download size={11} />
                          <span>Download Video</span>
                        </button>
                      )}

                      {/* Quick Action Button */}
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => setActiveQuickActionMenuMessageId(activeQuickActionMenuMessageId === msg.id ? null : msg.id)}
                          className={cn(
                            "flex items-center gap-1 px-2 py-1 rounded-md transition-all duration-300 border font-extrabold text-[10px] uppercase tracking-wider shadow-sm cursor-pointer whitespace-nowrap",
                            activeQuickActionMenuMessageId === msg.id
                              ? "bg-amber-500 text-slate-950 border-amber-400"
                              : (theme === 'dark'
                                  ? "text-amber-300 bg-amber-950/40 border-amber-500/40 hover:bg-amber-900/60"
                                  : "text-amber-700 bg-amber-50 border-amber-200 hover:bg-amber-100")
                          )}
                          title="Quick Actions"
                        >
                          <span>⚡ Quick</span>
                        </button>

                        <AnimatePresence>
                          {activeQuickActionMenuMessageId === msg.id && (
                            <>
                              <div className="fixed inset-0 z-40" onClick={() => setActiveQuickActionMenuMessageId(null)} />
                              <motion.div
                                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                className={cn(
                                  "absolute bottom-full right-0 mb-2 p-3 rounded-xl shadow-2xl border w-[320px] sm:w-[350px] max-h-[440px] overflow-y-auto z-50 space-y-2.5 text-left scrollbar-thin",
                                  theme === 'dark' ? "bg-slate-950 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                                )}
                              >
                                {/* Sub-tab Navigation Header */}
                                <div className="flex items-center gap-1 p-1 bg-slate-900/90 rounded-lg border border-slate-800/80">
                                  <button
                                    type="button"
                                    onClick={() => setQuickMenuSubTab('timeline')}
                                    className={cn(
                                      "flex-1 py-1.5 px-2 rounded-md text-[10px] font-extrabold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5",
                                      quickMenuSubTab === 'timeline'
                                        ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                                        : "text-slate-400 hover:text-slate-200"
                                    )}
                                  >
                                    <GraduationCap size={13} />
                                    <span>🎓 Timeline Tab</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setQuickMenuSubTab('actions')}
                                    className={cn(
                                      "flex-1 py-1.5 px-2 rounded-md text-[10px] font-extrabold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5",
                                      quickMenuSubTab === 'actions'
                                        ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30"
                                        : "text-slate-400 hover:text-slate-200"
                                    )}
                                  >
                                    <Zap size={13} />
                                    <span>⚡ Actions Tab</span>
                                  </button>
                                </div>

                                {quickMenuSubTab === 'timeline' ? (
                                  <div className="space-y-2">
                                    <LectureProgressTimeline
                                      isLectureMode={true}
                                      lectureSubMode={lectureSubMode}
                                      lectureProfessorStyle={lectureProfessorStyle}
                                      tutorPersonaConfig={tutorPersonaConfig}
                                      onToggleProfessorStyle={handleToggleProfessorStyle}
                                      activeVerbalQuestion={activeVerbalQuestion}
                                      activeBookmark={activeLectureBookmark}
                                      timelineMarkers={timelineMarkers}
                                      onAddCheckpointQuestion={() => {
                                        handlePauseVideoForLectureQuestion(
                                          "Checkpoint: What key physical law governs the conservation of energy in this closed system?",
                                          ["law", "conservation", "energy", "system", "constant", "closed", "yes"],
                                          "Answer verbally to verify your understanding."
                                        );
                                      }}
                                      onSelectMarker={(marker) => {
                                        if (marker.type === 'professor_shift' && marker.professorStyle) {
                                          setLectureProfessorStyle?.(marker.professorStyle);
                                          showNotification?.(`Applied ${marker.title}`, "info");
                                        } else if (marker.type === 'checkpoint_question') {
                                          showNotification?.(`Active Checkpoint: "${marker.title}"`, "info");
                                        }
                                      }}
                                      currentElapsedSec={Math.floor((elapsedMsRef.current || 0) / 1000) || 180}
                                      totalDurationSec={600}
                                      theme={theme}
                                      className="shadow-none border border-slate-800 bg-slate-900/90 mb-0"
                                    />
                                  </div>
                                ) : (
                                  <div className="space-y-2">
                                    {/* Lecture Mode Timeline Features */}
                                    <div className="space-y-1 pb-1.5 border-b border-slate-800/40">
                                      <div className="text-[9px] uppercase font-bold text-amber-400 px-1 pt-0.5">
                                        Lecture & Timeline Controls
                                      </div>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          openCrashDoubtModal();
                                          setActiveQuickActionMenuMessageId(null);
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                        )}
                                        title="Raise Crash Doubt during running lecture"
                                      >
                                        <div className="flex items-center gap-2">
                                          <span className="text-sm select-none">⚡❓</span>
                                          <span>Crash Doubt</span>
                                        </div>
                                        <span className="text-[9px] opacity-70 font-mono">Doubt</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          handleToggleDictationMode();
                                          setActiveQuickActionMenuMessageId(null);
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/30"
                                        )}
                                        title="Dictation - Write between lines of chat"
                                      >
                                        <div className="flex items-center gap-2">
                                          <Mic size={14} />
                                          <span>Dictation</span>
                                        </div>
                                        <span className="text-[9px] opacity-70 font-mono">Insert</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          handlePauseVideoForLectureQuestion(
                                            "What is the principle of conservation of energy?",
                                            ["energy", "created", "destroyed", "transform", "conserved", "constant"],
                                            "Energy cannot be created or destroyed, only transformed from one form to another."
                                          );
                                          setActiveQuickActionMenuMessageId(null);
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                        )}
                                        title="Pause video and ask a lecture question requiring verbal reply"
                                      >
                                        <div className="flex items-center gap-2">
                                          <HelpCircle size={13} className="text-amber-400" />
                                          <span>❓ Checkpoint Question</span>
                                        </div>
                                        <span className="text-[9px] opacity-70 font-mono">Pause</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          handleToggleProfessorStyle();
                                          setActiveQuickActionMenuMessageId(null);
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer border",
                                          lectureProfessorStyle === 'strict'
                                            ? "bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border-indigo-500/30"
                                            : "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                                        )}
                                        title="Toggle between Strict Professor and Interactive Mentor lecture modes"
                                      >
                                        <div className="flex items-center gap-2">
                                          <GraduationCap size={13} />
                                          <span>{lectureProfessorStyle === 'strict' ? '🎓 Strict Professor' : '🤝 Interactive Mentor'}</span>
                                        </div>
                                        <span className="text-[9px] opacity-70 font-mono">Mode</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          saveLectureBookmark("Manual Bookmark", msg.id);
                                          setActiveQuickActionMenuMessageId(null);
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-violet-500/10 hover:bg-violet-500/20 text-violet-400 border border-violet-500/30"
                                        )}
                                        title="Bookmark current lecture timestamp"
                                      >
                                        <div className="flex items-center gap-2">
                                          <Bookmark size={13} className="fill-current text-violet-400" />
                                          <span>🔖 Bookmark Timeline</span>
                                        </div>
                                        <span className="text-[9px] opacity-70 font-mono">Save</span>
                                      </button>

                                      {activeLectureBookmark && (
                                        <button
                                          type="button"
                                          onClick={() => {
                                            restoreLectureBookmark(activeLectureBookmark);
                                            setActiveQuickActionMenuMessageId(null);
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse"
                                          )}
                                          title={`Restore & seek to bookmark at ${activeLectureBookmark.timeLabel}`}
                                        >
                                          <div className="flex items-center gap-2">
                                            <Bookmark size={13} className="fill-current text-emerald-400" />
                                            <span>⏩ Seek {activeLectureBookmark.timeLabel}</span>
                                          </div>
                                          <span className="text-[9px] opacity-70 font-mono">Jump</span>
                                        </button>
                                      )}

                                      <button
                                        type="button"
                                        onClick={() => {
                                          setIsCacheStatsModalOpen(true);
                                          setActiveQuickActionMenuMessageId(null);
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                                        )}
                                        title="View IndexedDB Local Offline Cache details"
                                      >
                                        <div className="flex items-center gap-2">
                                          <HardDrive size={13} className="text-cyan-400" />
                                          <span>💾 IndexedDB Offline Cache</span>
                                        </div>
                                        <span className="text-[9px] opacity-70 font-mono">{cacheStats.cachedVideos} vids</span>
                                      </button>
                                    </div>

                                    {/* Quick Message Actions */}
                                    <div className="space-y-1">
                                      <div className="text-[9px] uppercase font-bold text-slate-400 px-1 pt-0.5">
                                        Quick Chat Actions
                                      </div>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          onSendMessage("Please provide a comprehensive Professor's Blackboard Summary and comparative master matrix formatted in a clean GFM Markdown table with zebra-striping.");
                                          setActiveQuickActionMenuMessageId(null);
                                          showNotification?.("Requesting structured Markdown matrix...", "info");
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                          theme === 'dark' ? "hover:bg-slate-800 text-amber-400" : "hover:bg-slate-100 text-amber-600"
                                        )}
                                      >
                                        <Table size={13} />
                                        <span>Master Table Summary</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          onSendMessage("Please summarize our current lecture and discussion so far with key takeaways.");
                                          setActiveQuickActionMenuMessageId(null);
                                          showNotification?.("Summarizing chat...", "info");
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                          theme === 'dark' ? "hover:bg-slate-800 text-indigo-400" : "hover:bg-slate-100 text-indigo-600"
                                        )}
                                      >
                                        <Sparkles size={13} />
                                        <span>Summarize Chat</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          onSendMessage("Generate a 5-question multiple choice practice quiz based on our recent topics.");
                                          setActiveQuickActionMenuMessageId(null);
                                          showNotification?.("Generating quiz...", "info");
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                          theme === 'dark' ? "hover:bg-slate-800 text-purple-400" : "hover:bg-slate-100 text-purple-600"
                                        )}
                                      >
                                        <HelpCircle size={13} />
                                        <span>Generate Quiz</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          onSendMessage("Please explain this concept with an annotated visual diagram and step-by-step breakdown.");
                                          setActiveQuickActionMenuMessageId(null);
                                          showNotification?.("Requesting annotated diagram explanation...", "info");
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                          theme === 'dark' ? "hover:bg-slate-800 text-emerald-400" : "hover:bg-slate-100 text-emerald-600"
                                        )}
                                      >
                                        <ImageIcon size={13} />
                                        <span>Explain with Diagram</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          onClearChat();
                                          setActiveQuickActionMenuMessageId(null);
                                          showNotification?.("Conversation cleared.", "info");
                                        }}
                                        className={cn(
                                          "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                          theme === 'dark' ? "hover:bg-slate-800 text-red-400" : "hover:bg-slate-100 text-red-600"
                                        )}
                                      >
                                        <Trash2 size={13} />
                                        <span>Clear Chat</span>
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </motion.div>
                            </>
                          )}
                        </AnimatePresence>
                      </div>

                      {onDeleteMessage && (
                        <button
                          onClick={() => onDeleteMessage(msg.id)}
                          className="p-1.5 rounded-md transition-colors text-emerald-100/60 hover:text-red-400 hover:bg-white/5 cursor-pointer"
                          title="Delete message"
                        >
                          <Trash2 size={14} />
                        </button>
                      )}

                      {/* Copy button */}
                      <button
                        onClick={() => handleCopyMessage(msg.id, localTranslations[msg.id] || msg.content)}
                        className="p-1.5 rounded-md transition-colors text-emerald-100/60 hover:text-amber-300 hover:bg-white/5 cursor-pointer"
                        title="Copy lecture text"
                      >
                        {copiedMessageId === msg.id ? <Check size={14} className="text-emerald-400 animate-in zoom-in-50" /> : <Copy size={14} />}
                      </button>

                      <button
                        onClick={() => handlePrintMessage(msg)}
                        className="p-1.5 rounded-md transition-colors text-emerald-100/60 hover:text-amber-300 hover:bg-white/5 cursor-pointer"
                        title="Print lecture slide"
                      >
                        <Printer size={14} />
                      </button>

                      <div className="relative">
                        <button
                          onClick={() => setActiveSpeedMenuMessageId(activeSpeedMenuMessageId === msg.id ? null : msg.id)}
                          className={cn(
                            "p-1.5 rounded-md transition-all cursor-pointer relative flex items-center justify-center",
                            activeSpeedMenuMessageId === msg.id
                              ? "text-amber-300 bg-white/10"
                              : "text-emerald-100/60 hover:text-amber-300 hover:bg-white/5"
                          )}
                          title="Adjust speed/pace controls"
                        >
                          <Sliders size={14} />
                        </button>

                        {activeSpeedMenuMessageId === msg.id && (
                          <>
                            <div className="fixed inset-0 z-40 cursor-default" onClick={() => setActiveSpeedMenuMessageId(null)} />
                            <div className={cn(
                              "absolute bottom-full right-0 mb-2 w-72 rounded-2xl shadow-xl border p-4 z-50 animate-in fade-in slide-in-from-top-2 text-left",
                              theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-slate-950/80 text-white" : "bg-white border-slate-200 shadow-slate-200/50 text-slate-900"
                            )}>
                              <div className="flex items-center justify-between pb-2 mb-2 border-b border-dashed border-slate-200/60 dark:border-slate-800/80">
                                <div className="text-[10px] font-black uppercase tracking-wider text-indigo-500 flex items-center gap-1">
                                  <Sliders size={12} />
                                  Speed Controller
                                </div>
                                <button
                                  onClick={() => {
                                    const nextLink = !linkSpeeds;
                                    setLinkSpeeds(nextLink);
                                    localStorage.setItem('omni_link_speeds', String(nextLink));
                                    if (nextLink) {
                                      let linkedPace = 'fluent';
                                      if (ttsRate === 0.5 || ttsRate === 0.75) linkedPace = 'deliberate';
                                      else if (ttsRate === 1.0) linkedPace = 'fluent';
                                      else if (ttsRate === 1.2 || ttsRate === 1.5) linkedPace = 'swift';
                                      else if (ttsRate === 2.0) linkedPace = 'instant';
                                      setTypingPace(linkedPace);
                                      localStorage.setItem('omni_typing_pace', linkedPace);
                                    }
                                  }}
                                  className={cn(
                                    "flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider transition-all cursor-pointer active:scale-95",
                                    linkSpeeds 
                                      ? "bg-indigo-100 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-900/40"
                                      : "bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-500 dark:text-slate-400"
                                  )}
                                  title="Sync/link Reading and Writing speed"
                                >
                                  {linkSpeeds ? <Link size={9} /> : <Link2Off size={9} />}
                                  {linkSpeeds ? "Linked" : "Link Speeds"}
                                </button>
                              </div>

                              {/* Reading Speed Row */}
                              <div className="space-y-1.5 mb-3.5">
                                <div className="flex items-center justify-between text-[10px]">
                                  <span className="font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                                    <Volume2 size={11} /> Reading (TTS)
                                  </span>
                                  <span className="font-mono font-black text-indigo-500">{ttsRate.toFixed(2)}x</span>
                                </div>
                                <div className="grid grid-cols-6 gap-1">
                                  {[0.5, 0.75, 1.0, 1.2, 1.5, 2.0].map((rate) => {
                                    const isActive = ttsRate === rate;
                                    return (
                                      <button
                                        key={rate}
                                        onClick={() => {
                                          setTtsRate(rate);
                                          localStorage.setItem('omni_tts_rate', String(rate));
                                          if (linkSpeeds) {
                                            let linkedPace = 'fluent';
                                            if (rate === 0.5 || rate === 0.75) linkedPace = 'deliberate';
                                            else if (rate === 1.0) linkedPace = 'fluent';
                                            else if (rate === 1.2 || rate === 1.5) linkedPace = 'swift';
                                            else if (rate === 2.0) linkedPace = 'instant';
                                            setTypingPace(linkedPace);
                                            localStorage.setItem('omni_typing_pace', linkedPace);
                                          }
                                        }}
                                        className={cn(
                                          "py-1 rounded text-[9px] font-black uppercase text-center border cursor-pointer active:scale-95",
                                          isActive
                                            ? "bg-indigo-500 border-indigo-500 text-white shadow"
                                            : theme === 'dark'
                                              ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750"
                                              : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                                        )}
                                      >
                                        {rate}x
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>

                              {/* Writing Speed Row */}
                              <div className="space-y-1.5">
                                <div className="flex items-center justify-between text-[10px]">
                                  <span className="font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                                    <Gauge size={11} /> Writing (Typing)
                                  </span>
                                  <span className="font-bold text-indigo-500 capitalize">{typingPace}</span>
                                </div>
                                <div className="grid grid-cols-4 gap-1">
                                  {['deliberate', 'fluent', 'swift', 'instant'].map((pace) => {
                                    const isActive = typingPace === pace;
                                    return (
                                      <button
                                        key={pace}
                                        onClick={() => {
                                          setTypingPace(pace);
                                          localStorage.setItem('omni_typing_pace', pace);
                                          let spd = 1.0;
                                          if (pace === 'deliberate') spd = 0.6;
                                          else if (pace === 'fluent') spd = 1.0;
                                          else if (pace === 'swift') spd = 1.6;
                                          else if (pace === 'instant') spd = 3.0;
                                          setBlackboardWritingSpeed(spd);
                                          localStorage.setItem('omni_blackboard_writing_speed', String(spd));
                                          if (linkSpeeds) {
                                            let linkedRate = 1.0;
                                            if (pace === 'deliberate') linkedRate = 0.75;
                                            else if (pace === 'fluent') linkedRate = 1.0;
                                            else if (pace === 'swift') linkedRate = 1.5;
                                            else if (pace === 'instant') linkedRate = 2.0;
                                            setTtsRate(linkedRate);
                                            localStorage.setItem('omni_tts_rate', String(linkedRate));
                                          }
                                        }}
                                        className={cn(
                                          "py-1 rounded text-[9px] font-black uppercase text-center border cursor-pointer active:scale-95 capitalize",
                                          isActive
                                            ? "bg-indigo-500 border-indigo-500 text-white shadow"
                                            : theme === 'dark'
                                              ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750"
                                              : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                                        )}
                                      >
                                        {pace}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          </>
                        )}
                      </div>



                      <button 
                        onClick={() => {
                          const next = !isVadEnabled;
                          setIsVadEnabled(next);
                          showNotification?.(next ? "Smart Voice Interruption (VAD) Enabled" : "Smart Voice Interruption (VAD) Disabled", "info");
                        }}
                        className={cn(
                          "p-1.5 rounded-md transition-all duration-300 hover:scale-110 hover:shadow-sm",
                          isVadEnabled
                            ? "text-emerald-400 bg-white/10"
                            : "text-emerald-100/40 hover:text-emerald-100/80 hover:bg-white/5"
                        )}
                        title={isVadEnabled ? "Smart Voice Interruption: ON (Click to turn off)" : "Smart Voice Interruption: OFF (Click to turn on)"}
                      >
                        {isVadEnabled ? <Mic size={14} /> : <MicOff size={14} />}
                      </button>

                      {/* Maximize/Minimize button */}
                      <button 
                        onClick={() => {
                          playChalkClickSound();
                          if (maximizedMessageId === msg.id) {
                            setMaximizedMessageId(null);
                          } else {
                            setMaximizedMessageId(msg.id);
                          }
                        }}
                        className={cn(
                          "p-1.5 rounded-md transition-all duration-300 ml-0.5 cursor-pointer",
                          maximizedMessageId === msg.id
                            ? "text-amber-300 bg-white/20 animate-pulse"
                            : "text-emerald-100/60 hover:text-amber-300 hover:bg-white/5"
                        )}
                        title={maximizedMessageId === msg.id ? "Minimize screen" : "Maximize screen to full screen"}
                      >
                        {maximizedMessageId === msg.id ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
                      </button>

                      {isGeneratingVideo && (
                        <span className="flex items-center gap-1 px-2 py-1 rounded bg-indigo-500/25 text-indigo-200 font-mono text-[10px] font-bold animate-pulse select-none border border-indigo-500/20">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping" />
                          <span>Generating Video: {videoGenerationTime}s</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div 
                  onDoubleClick={(e) => handleChatDoubleClick(e, msg.id)}
                  className={cn(
                  maximizedMessageId === msg.id 
                    ? "fixed inset-0 w-screen h-dvh z-[9999] p-8 md:p-16 overflow-y-auto flex flex-col justify-between"
                    : "max-w-[98%] lg:max-w-[95%] rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-sm relative group transition-all cursor-pointer",
                  msg.sender === 'user' 
                    ? "bg-indigo-600 text-white rounded-tr-none" 
                    : theme === 'dark' 
                      ? (maximizedMessageId === msg.id ? "bg-slate-950 text-white" : "bg-slate-800/80 border border-slate-700 text-white rounded-tl-none backdrop-blur-md")
                      : (maximizedMessageId === msg.id ? "bg-slate-50 text-slate-900" : "bg-white border border-slate-200 text-slate-900 rounded-tl-none shadow-xl shadow-slate-200/20")
                )}>
                  {maximizedMessageId === msg.id && (
                    <button 
                      onClick={() => {
                        playChalkClickSound();
                        setMaximizedMessageId(null);
                      }}
                      className={cn(
                        "absolute top-6 right-6 z-[10000] p-2.5 rounded-full transition-all cursor-pointer border hover:scale-105 active:scale-95 shadow-md",
                        theme === 'dark' 
                          ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white" 
                          : "bg-white border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                      )}
                      title="Exit Fullscreen"
                    >
                      <Minimize2 size={20} />
                    </button>
                  )}

                  <div className={cn(
                    maximizedMessageId === msg.id ? "max-w-4xl mx-auto w-full flex-1 flex flex-col justify-between py-4" : "flex flex-col h-full"
                  )}>
                    {msg.metadata?.image && (
                      <div className="mb-3.5 rounded-2xl overflow-hidden max-w-sm border border-slate-200/20 shadow-md">
                        <img 
                          src={msg.metadata.image} 
                          alt="Uploaded problem statement" 
                          className="w-full object-cover max-h-[250px]"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    )}

                    {msg.metadata?.videoUrl && (
                      <VideoWithOverlay 
                        src={msg.metadata.videoUrl} 
                        events={msg.metadata.events}
                        initialTimestamp={msg.metadata?.lectureBookmark?.timestampSec || activeLectureBookmark?.timestampSec}
                        isPlaying={isLectureVideoPlaying}
                        onBookmarkCreated={(time, title) => saveLectureBookmark(`Video Bookmark: ${title}`, msg.id, 0, time * 1000)}
                        className="mb-3.5 max-w-lg border border-slate-200/20 shadow-xl"
                      />
                    )}
                  {editingMessageId === msg.id ? (
                    <div className="space-y-2 my-1 w-full" onClick={(e) => e.stopPropagation()}>
                      <textarea
                        value={editingContent}
                        onChange={(e) => setEditingContent(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                            e.preventDefault();
                            handleSaveEdit(msg.id, true);
                          } else if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSaveEdit(msg.id, false);
                          } else if (e.key === 'Escape') {
                            setEditingMessageId(null);
                          }
                        }}
                        autoFocus
                        rows={2}
                        className={cn(
                          "w-full p-2.5 rounded-xl border text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-y",
                          theme === 'dark' ? "bg-slate-950 border-indigo-500 text-white" : "bg-white border-indigo-300 text-slate-900"
                        )}
                        placeholder="Type new text and press Enter to save..."
                      />
                      <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
                        <span>Press <kbd className="px-1.5 py-0.5 bg-slate-200 dark:bg-slate-800 rounded font-mono">Enter</kbd> to save, or <kbd className="px-1.5 py-0.5 bg-slate-200 dark:bg-slate-800 rounded font-mono">Ctrl+Enter</kbd> to regenerate</span>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setEditingMessageId(null)}
                            className="px-2.5 py-1 rounded-lg bg-slate-500/20 hover:bg-slate-500/30 font-bold transition cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSaveEdit(msg.id, false)}
                            className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition cursor-pointer flex items-center gap-1"
                          >
                            <Check size={12} /> Save
                          </button>
                          {msg.sender === 'user' && (
                            <button
                              type="button"
                              onClick={() => handleSaveEdit(msg.id, true)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition cursor-pointer flex items-center gap-1"
                            >
                              <Sparkles size={12} /> Save & AI
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div 
                      onDoubleClick={() => {
                        setEditingMessageId(msg.id);
                        setEditingContent(msg.content);
                        showNotification?.('Editing message inline...', 'info');
                      }}
                      title="Double click to edit message"
                      className={cn(
                        "prose max-w-none text-sm leading-relaxed cursor-pointer hover:opacity-90 transition-opacity",
                        theme === 'dark' ? "prose-invert" : "prose-slate"
                      )}
                    >
                      <ReactMarkdown 
                        remarkPlugins={[remarkMath, remarkGfm]} 
                        rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
                        components={{
                          p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                          h1: ({ children }) => (
                            <SubtopicHeadingDiagram
                              level={1}
                              fullContent={msg.content}
                              theme={theme}
                              onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                              showNotification={showNotification}
                              onRenderComplete={() => {}}
                              isLectureMode={isLectureMode}
                            >
                              {children}
                            </SubtopicHeadingDiagram>
                          ),
                          h2: ({ children }) => (
                            <SubtopicHeadingDiagram
                              level={2}
                              fullContent={msg.content}
                              theme={theme}
                              onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                              showNotification={showNotification}
                              onRenderComplete={() => {}}
                              isLectureMode={isLectureMode}
                            >
                              {children}
                            </SubtopicHeadingDiagram>
                          ),
                          h3: ({ children }) => (
                            <SubtopicHeadingDiagram
                              level={3}
                              fullContent={msg.content}
                              theme={theme}
                              onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                              showNotification={showNotification}
                              onRenderComplete={() => {}}
                              isLectureMode={isLectureMode}
                            >
                              {children}
                            </SubtopicHeadingDiagram>
                          ),
                          ul: ({ children }) => <ul className="list-disc pl-4 mb-2">{children}</ul>,
                          ol: ({ children }) => <ol className="list-decimal pl-4 mb-2">{children}</ol>,
                          table: ({ children }) => (
                            <div className={cn(
                              "my-4 overflow-x-auto rounded-xl border shadow-md transition-all",
                              theme === 'dark'
                                ? "border-slate-700/80 bg-slate-900/90 text-slate-100"
                                : "border-slate-200 bg-white text-slate-800"
                            )}>
                              <table className="w-full text-left border-collapse text-xs md:text-sm">
                                {children}
                              </table>
                            </div>
                          ),
                          thead: ({ children }) => (
                            <thead className={cn(
                              "font-bold uppercase tracking-wider border-b",
                              theme === 'dark' 
                                ? "bg-slate-800/90 text-indigo-300 border-slate-700" 
                                : "bg-slate-100 text-indigo-700 border-slate-200"
                            )}>
                              {children}
                            </thead>
                          ),
                          tbody: ({ children }) => (
                            <tbody className={cn(
                              "divide-y",
                              theme === 'dark' ? "divide-slate-800/80 border-slate-800" : "divide-slate-100 border-slate-100"
                            )}>
                              {children}
                            </tbody>
                          ),
                          tr: ({ children }) => (
                            <tr className={cn(
                              "transition-colors",
                              theme === 'dark' ? "hover:bg-slate-800/40" : "hover:bg-slate-50"
                            )}>
                              {children}
                            </tr>
                          ),
                          th: ({ children }) => (
                            <th className="px-4 py-3 font-extrabold text-indigo-400 dark:text-indigo-300">
                              {children}
                            </th>
                          ),
                          td: ({ children }) => (
                            <td className="px-4 py-3 leading-relaxed">
                              {children}
                            </td>
                          ),
                          code: ({ children }) => {
                            const str = String(children || '');
                            if (str.includes('<svg') && str.includes('</svg>')) {
                              return (
                                <SvgDiagramViewer
                                  svgCode={str}
                                  theme={theme}
                                  onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                                  showNotification={showNotification}
                                  onRenderComplete={() => {
                                    if (setIsDiagramRendering) setIsDiagramRendering(false);
                                    if (setIsClassroomMute) setIsClassroomMute(false);
                                  }}
                                  onExplainFigure={(code, ttl) => {
                                    onSendMessage(`Please analyze this SVG diagram and provide a deep, step-by-step breakdown of its components, labels, and scientific/mathematical principles:\n\n${code}`);
                                    showNotification?.("Requesting deep diagram explanation...", "info");
                                  }}
                                  isHighContrast={canvasUiManager?.state.highContrast}
                                  isVectorDragMode={canvasUiManager?.state.dragHandles}
                                  showVectorTelemetry={canvasUiManager?.state.vectorStats}
                                  isMagnifierActive={canvasUiManager?.state.magnifier}
                                  isChalkMode={canvasUiManager?.state.chalkDraw}
                                  showGrid={canvasUiManager?.state.grid}
                                  onToggleHighContrast={canvasUiManager?.toggleHighContrast}
                                  onToggleVectorDragMode={canvasUiManager?.toggleDragHandles}
                                  onToggleVectorTelemetry={canvasUiManager?.toggleVectorStats}
                                  onToggleMagnifier={canvasUiManager?.toggleMagnifier}
                                  onToggleChalkMode={canvasUiManager?.toggleChalkDraw}
                                  onToggleGrid={canvasUiManager?.toggleGrid}
                                />
                              );
                            }
                            return (
                              <code className={cn(
                                "px-1 rounded text-sm font-mono",
                                theme === 'dark' ? "bg-slate-700 text-indigo-300" : "bg-slate-100 text-indigo-600"
                              )}>
                                {children}
                              </code>
                            );
                          },
                          pre: ({ children }) => {
                            const childArray = React.Children.toArray(children);
                            const firstChild = childArray[0];
                            if (React.isValidElement(firstChild)) {
                              const codeStr = String((firstChild.props as any)?.children || '');
                              if (codeStr.includes('<svg') && codeStr.includes('</svg>')) {
                                return (
                                  <SvgDiagramViewer
                                    svgCode={codeStr}
                                    theme={theme}
                                    onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                                    showNotification={showNotification}
                                    onRenderComplete={() => {
                                      if (setIsDiagramRendering) setIsDiagramRendering(false);
                                      if (setIsClassroomMute) setIsClassroomMute(false);
                                    }}
                                    onExplainFigure={(code, ttl) => {
                                      onSendMessage(`Please analyze this SVG diagram and provide a deep, step-by-step breakdown of its components, labels, and scientific/mathematical principles:\n\n${code}`);
                                      showNotification?.("Requesting deep diagram explanation...", "info");
                                    }}
                                    isHighContrast={canvasUiManager?.state.highContrast}
                                    isVectorDragMode={canvasUiManager?.state.dragHandles}
                                    showVectorTelemetry={canvasUiManager?.state.vectorStats}
                                    isMagnifierActive={canvasUiManager?.state.magnifier}
                                    isChalkMode={canvasUiManager?.state.chalkDraw}
                                    showGrid={canvasUiManager?.state.grid}
                                    onToggleHighContrast={canvasUiManager?.toggleHighContrast}
                                    onToggleVectorDragMode={canvasUiManager?.toggleDragHandles}
                                    onToggleVectorTelemetry={canvasUiManager?.toggleVectorStats}
                                    onToggleMagnifier={canvasUiManager?.toggleMagnifier}
                                    onToggleChalkMode={canvasUiManager?.toggleChalkDraw}
                                    onToggleGrid={canvasUiManager?.toggleGrid}
                                  />
                                );
                              }
                              if (isBoxedSummary(codeStr)) {
                                return (
                                  <div className="my-3 not-prose">
                                    <BlackboardSummaryCard
                                      rawText={codeStr}
                                      theme={theme === 'dark' ? 'dark' : 'light'}
                                      showNotification={showNotification}
                                      onInsertToChat={onSendMessage}
                                    />
                                  </div>
                                );
                              }
                              if ((codeStr.includes('║') && (codeStr.includes('╠') || codeStr.includes('═') || codeStr.includes('╔') || codeStr.includes('╚'))) || (codeStr.includes('+---') && codeStr.includes('|'))) {
                                return (
                                  <div className="my-3 not-prose">
                                    <TableGenerator
                                      isInline={true}
                                      initialText={codeStr}
                                      theme={theme === 'dark' ? 'dark' : 'light'}
                                      showNotification={showNotification}
                                      onInsertToChat={onSendMessage}
                                    />
                                  </div>
                                );
                              }
                            }
                            return (
                              <pre className={cn(
                                "p-3 rounded-lg overflow-x-auto my-2",
                                theme === 'dark' ? "bg-slate-950 text-slate-300" : "bg-slate-900 text-white"
                              )}>
                                {children}
                              </pre>
                            );
                          },
                          blockquote: ({ children }) => (
                            <blockquote className={cn(
                              "border-l-4 border-indigo-500 pl-4 italic my-2",
                              theme === 'dark' ? "text-slate-400" : "text-slate-600"
                            )}>
                              {children}
                            </blockquote>
                          ),
                          text: ({ children, node, ...props }: any) => (
                            <span
                              style={{
                                fontFamily: props['font-family'] || props.fontFamily,
                                fontSize: props['font-size'] || props.fontSize,
                                fontWeight: props['font-weight'] || props.fontWeight,
                                color: props.fill || undefined
                              }}
                            >
                              {children}
                            </span>
                          )
                        }}
                      >
                        {formatMarkdownWithInlineSvgs(autoBalanceMathDelimiters(localTranslations[msg.id] || msg.content))}
                      </ReactMarkdown>
                    </div>
                  )}
                  {(() => {
                    const c = localTranslations[msg.id] || msg.content;
                    if (!c) return null;

                    // Auto-render SVG diagrams if raw XML/SVG tags exist in the message text
                    if (c.includes('<svg') && c.includes('</svg>') && !c.includes('```xml') && !c.includes('```svg')) {
                      const svgMatches = c.match(/<svg[\s\S]*?<\/svg>/gi);
                      if (svgMatches && svgMatches.length > 0) {
                        return (
                          <div className="space-y-3 my-3">
                            {svgMatches.map((svgCode, idx) => (
                              <SvgDiagramViewer
                                key={idx}
                                svgCode={svgCode}
                                theme={theme}
                                onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
                                showNotification={showNotification}
                                onRenderComplete={() => {
                                  if (setIsDiagramRendering) setIsDiagramRendering(false);
                                  if (setIsClassroomMute) setIsClassroomMute(false);
                                }}
                                isHighContrast={canvasUiManager?.state.highContrast}
                                isVectorDragMode={canvasUiManager?.state.dragHandles}
                                showVectorTelemetry={canvasUiManager?.state.vectorStats}
                                isMagnifierActive={canvasUiManager?.state.magnifier}
                                isChalkMode={canvasUiManager?.state.chalkDraw}
                                showGrid={canvasUiManager?.state.grid}
                                onToggleHighContrast={canvasUiManager?.toggleHighContrast}
                                onToggleVectorDragMode={canvasUiManager?.toggleDragHandles}
                                onToggleVectorTelemetry={canvasUiManager?.toggleVectorStats}
                                onToggleMagnifier={canvasUiManager?.toggleMagnifier}
                                onToggleChalkMode={canvasUiManager?.toggleChalkDraw}
                                onToggleGrid={canvasUiManager?.toggleGrid}
                              />
                            ))}
                          </div>
                        );
                      }
                    }

                    if (isBoxedSummary(c) && !c.includes('```')) {
                      return (
                        <div className="my-3 not-prose">
                          <BlackboardSummaryCard
                            rawText={c}
                            theme={theme === 'dark' ? 'dark' : 'light'}
                            showNotification={showNotification}
                            onInsertToChat={onSendMessage}
                          />
                        </div>
                      );
                    }

                    if ((c.includes('Newton-Raphson') || c.includes('न्यूटन-राफसन')) && (c.includes('x^3 - x - 2') || c.includes('x3 - x - 2') || c.includes('x³ - x - 2') || c.includes('x**3 - x - 2'))) {
                      return <NewtonRaphsonGraph funcStr="x**3 - x - 2" derivStr="3*x**2 - 1" x0={2} iterations={4} theme={theme} />;
                    }
                    const detectedFuncs = detectMathFunctions(c);
                    if (detectedFuncs.length > 0) {
                      return <MathGraph functions={detectedFuncs} theme={theme} />;
                    }
                    return null;
                  })()}
                  {translatingIds.has(msg.id) && (
                    <div className="flex items-center gap-2 mt-2 text-xs text-indigo-500 font-medium">
                      <Loader2 size={12} className="animate-spin" /> Translating...
                    </div>
                  )}

                  {/* Listen & Repeat Scientific Unit Pronunciation Helper */}
                  {msg.sender === 'ai' && (
                    (() => {
                      const detectedUnits = SCIENTIFIC_UNITS.filter(unit => msg.content.includes(unit.symbol));
                      if (detectedUnits.length === 0) return null;

                      return (
                        <div className="mt-3 space-y-2 border-t border-slate-200/10 pt-3">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={cn(
                              "text-[10px] font-black uppercase tracking-wider flex items-center gap-1",
                              theme === 'dark' ? "text-indigo-400" : "text-indigo-600"
                            )}>
                              <GraduationCap size={12} /> Pronunciation Practice:
                            </span>
                            {detectedUnits.map(unit => {
                              const isCurrentUnitActive = activePracticeMsgId === msg.id && activePracticeUnit?.id === unit.id;
                              return (
                                <button
                                  key={unit.id}
                                  onClick={() => {
                                    if (isCurrentUnitActive) {
                                      // Toggle close
                                      setActivePracticeMsgId(null);
                                      setActivePracticeUnit(null);
                                      setPracticeTranscript('');
                                      setPracticeResult(null);
                                    } else {
                                      setActivePracticeMsgId(msg.id);
                                      setActivePracticeUnit(unit);
                                      setPracticeTranscript('');
                                      setPracticeResult(null);
                                    }
                                  }}
                                  className={cn(
                                    "px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border transition-all duration-200 active:scale-95 flex items-center gap-1 cursor-pointer",
                                    isCurrentUnitActive
                                      ? "bg-indigo-600 text-white border-indigo-700 shadow-md shadow-indigo-500/20"
                                      : theme === 'dark'
                                        ? "bg-slate-800 border-slate-700 text-slate-300 hover:border-indigo-500/50 hover:text-indigo-400"
                                        : "bg-slate-50 border-slate-200 text-slate-600 hover:border-indigo-500/50 hover:text-indigo-600"
                                  )}
                                >
                                  🎙️ Practice {unit.symbol}
                                </button>
                              );
                            })}
                          </div>

                          {/* Expanded Interactive Practice Sandbox for this message */}
                          {activePracticeMsgId === msg.id && activePracticeUnit && (
                            <motion.div
                              initial={{ opacity: 0, y: -10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className={cn(
                                "rounded-xl border p-4 space-y-3.5 mt-2",
                                theme === 'dark' ? "bg-slate-900/85 border-indigo-500/30" : "bg-indigo-50/20 border-indigo-200"
                              )}
                            >
                              {/* Header */}
                              <div className="flex items-center justify-between border-b border-slate-200/10 pb-2">
                                <div className="space-y-0.5">
                                  <h5 className={cn(
                                    "text-xs font-bold font-mono uppercase tracking-wider flex items-center gap-1",
                                    theme === 'dark' ? "text-indigo-400" : "text-indigo-600"
                                  )}>
                                    Saying: {activePracticeUnit.symbol} ({activePracticeUnit.name})
                                  </h5>
                                  <p className="text-[9px] text-slate-400">
                                    {activePracticeUnit.meaning}
                                  </p>
                                </div>
                                <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800 shrink-0">
                                  {(['hinglish', 'english', 'hindi'] as const).map(mode => (
                                    <button
                                      key={mode}
                                      onClick={() => {
                                        setPracticeMode(mode);
                                        setPracticeTranscript('');
                                        setPracticeResult(null);
                                      }}
                                      className={cn(
                                        "px-1.5 py-0.5 text-[8px] font-bold rounded transition-all duration-150 capitalize",
                                        practiceMode === mode 
                                          ? 'bg-indigo-600 text-white' 
                                          : 'text-slate-400 hover:text-slate-200'
                                      )}
                                    >
                                      {mode === 'hindi' ? 'हिन्दी' : mode}
                                    </button>
                                  ))}
                                </div>
                              </div>

                              {/* Interactive Sandbox Columns */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {/* Left: Target Spoken Display */}
                                <div className={cn(
                                  "rounded-lg p-3 flex flex-col justify-between border",
                                  theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-100"
                                )}>
                                  <div>
                                    <span className="text-[8px] uppercase font-bold text-slate-400 tracking-wider">How to read this:</span>
                                    <div className={cn(
                                      "text-sm font-bold font-mono mt-1",
                                      theme === 'dark' ? "text-indigo-300" : "text-indigo-600"
                                    )}>
                                      {practiceMode === 'english' && activePracticeUnit.spokenEnglish}
                                      {practiceMode === 'hinglish' && activePracticeUnit.spokenHinglish}
                                      {practiceMode === 'hindi' && activePracticeUnit.spokenHindi}
                                    </div>
                                    <p className="text-[9px] text-slate-400 mt-1">
                                      {practiceMode === 'hinglish' && "Combines symbols like 'coulomb' with familiar transition phrases like 'prati'."}
                                      {practiceMode === 'english' && "Standard formal English reading."}
                                      {practiceMode === 'hindi' && "वैज्ञानिक मानक हिंदी देवनागरी माध्यम।"}
                                    </p>
                                  </div>

                                  <button
                                    onClick={() => handlePracticeListenDemo(activePracticeUnit)}
                                    disabled={practiceIsSpeaking}
                                    className={cn(
                                      "mt-3 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[10px] font-bold transition-all duration-150 cursor-pointer w-full border",
                                      practiceIsSpeaking 
                                        ? 'bg-indigo-600/10 border-indigo-500/20 text-indigo-400' 
                                        : 'bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-700 hover:shadow-sm'
                                    )}
                                  >
                                    {practiceIsSpeaking ? (
                                      <>
                                        <Loader2 size={10} className="animate-spin" />
                                        <span>Tutor is reading...</span>
                                      </>
                                    ) : (
                                      <>
                                        <Volume2 size={10} />
                                        <span>Listen to AI Tutor</span>
                                      </>
                                    )}
                                  </button>
                                </div>

                                {/* Right: User Record Practice */}
                                <div className={cn(
                                  "rounded-lg p-3 flex flex-col justify-between border",
                                  theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-100"
                                )}>
                                  <div>
                                    <div className="flex justify-between items-center">
                                      <span className="text-[8px] uppercase font-bold text-slate-400 tracking-wider">Your Speech:</span>
                                      {practiceRecording && (
                                        <span className="flex h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse" />
                                      )}
                                    </div>
                                    <div className={cn(
                                      "mt-1.5 py-2 px-2 text-[11px] font-mono rounded border flex items-center justify-center text-center h-[52px] overflow-y-auto",
                                      practiceRecording
                                        ? 'bg-rose-500/5 border-rose-500/20 text-rose-300'
                                        : 'bg-slate-900 border-slate-800 text-slate-400'
                                    )}>
                                      {practiceRecording ? (
                                        <span className="text-[9px] uppercase font-bold text-rose-400 animate-pulse">Speak now... Listening...</span>
                                      ) : practiceTranscript ? (
                                        <span className={theme === 'dark' ? "text-slate-100 font-bold" : "text-slate-800 font-bold"}>"{practiceTranscript}"</span>
                                      ) : (
                                        <span className="text-[9px] text-slate-500 leading-tight">Click the button below and read the terms out loud</span>
                                      )}
                                    </div>
                                  </div>

                                  <button
                                    onClick={() => handleTogglePracticeSpeech(activePracticeUnit, msg.id)}
                                    className={cn(
                                      "mt-3 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[10px] font-bold transition-all duration-150 cursor-pointer w-full border",
                                      practiceRecording
                                        ? 'bg-rose-600 text-white border-rose-700'
                                        : theme === 'dark'
                                          ? 'bg-slate-800 hover:bg-slate-755 border-slate-700 text-slate-200'
                                          : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                                    )}
                                  >
                                    {practiceRecording ? <MicOff size={10} /> : <Mic size={10} />}
                                    <span>{practiceRecording ? "Stop Recording" : "Record & Repeat"}</span>
                                  </button>
                                </div>
                              </div>

                              {/* Evaluation Results Overlay */}
                              {practiceResult && (
                                <motion.div
                                  initial={{ opacity: 0, scale: 0.98 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  className={cn(
                                    "border rounded-lg p-3 space-y-2.5",
                                    practiceResult.score >= 85 
                                      ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-100' 
                                      : practiceResult.score >= 60 
                                        ? 'bg-amber-500/5 border-amber-500/20 text-amber-100' 
                                        : 'bg-slate-900 border-slate-800 text-slate-300'
                                  )}
                                >
                                  <div className="flex items-center justify-between border-b border-slate-200/10 pb-1.5">
                                    <div className="flex items-center gap-1.5 text-[10px] font-bold">
                                      <Trophy className="text-amber-400" size={12} />
                                      <span>Pronunciation Evaluation</span>
                                    </div>
                                    <div className="flex items-baseline gap-0.5">
                                      <span className={cn(
                                        "text-sm font-black font-mono",
                                        practiceResult.score >= 85 ? 'text-emerald-400' : 'text-slate-200'
                                      )}>{practiceResult.score}</span>
                                      <span className="text-[8px] text-slate-400">/ 100</span>
                                    </div>
                                  </div>

                                  <div className="space-y-1">
                                    <span className="text-[8px] uppercase font-bold text-slate-400 tracking-wider">Syllable matches:</span>
                                    <div className="flex flex-wrap gap-1">
                                      {practiceResult.matchedWords.map((item, idx) => (
                                        <span
                                          key={idx}
                                          className={cn(
                                            "text-[9px] px-1.5 py-0.25 rounded font-mono font-bold border",
                                            item.isCorrect 
                                              ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-400' 
                                              : 'bg-rose-500/10 border-rose-500/25 text-rose-400 line-through'
                                          )}
                                        >
                                          {item.word}
                                        </span>
                                      ))}
                                    </div>
                                  </div>

                                  <p className="text-[10px] leading-relaxed text-slate-300">
                                    <span className="font-bold text-slate-200">Feedback:</span> {practiceResult.feedback}
                                  </p>

                                  {practiceResult.score >= 85 && (
                                    <div className="bg-emerald-600/10 border border-emerald-500/20 p-1.5 rounded flex items-center justify-between text-[9px] text-emerald-400">
                                      <span className="font-bold">✨ Accuracy Achieved!</span>
                                      <span className="font-mono font-bold">+15 XP Awarded</span>
                                    </div>
                                  )}
                                </motion.div>
                              )}
                            </motion.div>
                          )}
                        </div>
                      );
                    })()
                  )}

                  {/* Standard Interactive Concept Quiz */}
                  {messageQuizzes[msg.id] ? (
                    <div className={cn(
                      "mt-4 border border-dashed rounded-2xl p-4 animate-in slide-in-from-top-4 duration-300",
                      theme === 'dark' ? "border-slate-700 bg-slate-900/50" : "border-slate-300 bg-slate-50/50"
                    )}>
                      <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-200/20">
                        <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest flex items-center gap-1">
                          🎓 Concept Desk Check
                        </span>
                        <button 
                          onClick={() => {
                            playChalkClickSound();
                            const clearedAnswers = { ...selectedAnswers };
                            const clearedExplanations = { ...showQuizExplanations };
                            for (let i = 0; i < messageQuizzes[msg.id].length; i++) {
                              delete clearedAnswers[`${msg.id}_${i}`];
                              delete clearedExplanations[`${msg.id}_${i}`];
                            }
                            setSelectedAnswers(clearedAnswers);
                            setShowQuizExplanations(clearedExplanations);
                            showNotification?.("Quiz restarted!", "info");
                          }}
                          className={cn(
                            "text-[9px] uppercase font-black transition-colors cursor-pointer",
                            theme === 'dark' ? "text-slate-500 hover:text-slate-300" : "text-slate-400 hover:text-slate-600"
                          )}
                        >
                          Reset Quiz
                        </button>
                      </div>

                      <div className="space-y-4">
                        {messageQuizzes[msg.id].map((q: any, qIdx: number) => {
                          const ansKey = `${msg.id}_${qIdx}`;
                          const chosenOptIdx = selectedAnswers[ansKey]?.[0];
                          const isAnswered = chosenOptIdx !== undefined;

                          return (
                            <div key={qIdx} className="space-y-2 last:border-b-0 pb-3 last:pb-0 border-b border-slate-200/10">
                              <p className={cn(
                                "text-xs font-semibold leading-relaxed",
                                theme === 'dark' ? "text-slate-200" : "text-slate-800"
                              )}>
                                {qIdx + 1}. {q.question}
                              </p>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                                {q.options.map((opt: string, optIdx: number) => {
                                  const isSelected = chosenOptIdx === optIdx;
                                  const isCorrectOpt = optIdx === q.correctIndex;
                                  
                                  let btnStyle = "";
                                  if (isAnswered) {
                                    if (isCorrectOpt) {
                                      btnStyle = theme === 'dark'
                                        ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-bold"
                                        : "bg-emerald-50 border-emerald-500 text-emerald-800 font-bold";
                                    } else if (isSelected) {
                                      btnStyle = theme === 'dark'
                                        ? "bg-red-950/40 border-red-500/50 text-red-300"
                                        : "bg-rose-50 border-rose-500 text-rose-800";
                                    } else {
                                      btnStyle = theme === 'dark'
                                        ? "bg-slate-800/40 opacity-40 border-slate-800 text-slate-500"
                                        : "bg-slate-100/50 opacity-50 border-slate-200 text-slate-400";
                                    }
                                  } else {
                                    btnStyle = theme === 'dark'
                                      ? "bg-slate-800 hover:bg-slate-750 border-slate-700 text-slate-200"
                                      : "bg-white hover:bg-slate-50 border-slate-200 text-slate-700";
                                  }

                                  return (
                                    <button
                                      key={optIdx}
                                      disabled={isAnswered}
                                      onClick={() => {
                                        playChalkClickSound();
                                        setSelectedAnswers(prev => ({
                                          ...prev,
                                          [ansKey]: [optIdx]
                                        }));
                                        if (optIdx === q.correctIndex) {
                                          playQuizSuccessSound();
                                          showNotification?.("Correct answer! Great job! 🎓", "success");
                                        } else {
                                          playQuizFailureSound();
                                          showNotification?.("Oops! Review the explanation below.", "warning");
                                        }
                                      }}
                                      className={cn(
                                        "w-full text-left px-3 py-2 rounded-xl text-xs border transition-all duration-300",
                                        !isAnswered && "active:scale-[0.98] cursor-pointer",
                                        btnStyle
                                      )}
                                    >
                                      <div className="flex items-start gap-2">
                                        <span className={cn(
                                          "font-bold text-[9px] px-1.5 py-0.5 rounded",
                                          theme === 'dark' ? "bg-white/10 text-white/70" : "bg-slate-100 text-slate-600"
                                        )}>
                                          {String.fromCharCode(65 + optIdx)}
                                        </span>
                                        <span className="flex-1 mt-0.5">{opt}</span>
                                      </div>
                                    </button>
                                  );
                                })}
                              </div>
                              {isAnswered && q.explanation && (
                                <div className={cn(
                                  "text-[10px] leading-relaxed p-2.5 rounded-lg border mt-2 animate-in fade-in duration-300",
                                  theme === 'dark' 
                                    ? "text-amber-300 bg-amber-950/20 border-amber-900/30" 
                                    : "text-amber-800 bg-amber-50 border-amber-200"
                                )}>
                                  <span className={cn(
                                    "font-bold uppercase text-[9px] block mb-0.5",
                                    theme === 'dark' ? "text-amber-400" : "text-amber-700"
                                  )}>Explanation</span>
                                  {q.explanation}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : loadingQuizMessageId === msg.id ? (
                    <div className={cn(
                      "mt-4 border border-dashed rounded-2xl p-5 relative z-20 flex flex-col items-center justify-center text-center space-y-2",
                      theme === 'dark' ? "border-slate-700 bg-slate-900/30" : "border-slate-300 bg-slate-50"
                    )}>
                      <Loader2 className="w-5 h-5 text-indigo-500 animate-spin" />
                      <span className={cn(
                        "text-[10px] font-bold uppercase tracking-widest",
                        theme === 'dark' ? "text-indigo-400" : "text-indigo-600"
                      )}>
                        Omni is crafting concept check questions...
                      </span>
                    </div>
                  ) : null}

                  <div className={cn(
                    "text-[10px] mt-2 opacity-60",
                    msg.sender === 'user' ? "text-right" : "text-left"
                  )}>
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className={cn(
                    "mt-2 flex flex-wrap gap-2",
                    msg.sender === 'user' ? "justify-end" : "justify-start"
                  )}>
                    {(() => {
                      const nextMsg = messages[messages.indexOf(msg) + 1];
                      const hasAiResponse = msg.sender === 'user' && nextMsg && nextMsg.sender === 'ai';
                      if (!hasAiResponse) return null;
                      const aiDurationSeconds = nextMsg.metadata?.durationSeconds !== undefined 
                        ? nextMsg.metadata.durationSeconds 
                        : parseFloat((2.5 + (nextMsg.timestamp % 15) / 10).toFixed(1));
                      const modelName = nextMsg.metadata?.modelName || 'Omni AI';
                      return (
                        <div className="mt-3 pt-2.5 border-t border-white/10 flex flex-col items-end text-right w-full min-w-[120px] select-none">
                          <div className="text-[10px] font-black uppercase tracking-widest text-indigo-100/90 flex items-center gap-1">
                            <Sparkles size={10} className="text-amber-300 fill-amber-300 animate-pulse shrink-0" />
                            {modelName}
                          </div>
                          <div className="text-[9px] font-mono font-bold tracking-wider text-indigo-200 mt-0.5 uppercase opacity-90">
                            Ran for {aiDurationSeconds}s
                          </div>
                        </div>
                      );
                    })()}
                    {msg.metadata?.confidence && (
                      <span className={cn(
                        "text-[10px] px-1.5 py-0.5 rounded font-medium",
                        theme === 'dark' ? "bg-green-900/30 text-green-400" : "bg-green-100 text-green-700"
                      )}>
                        {Math.round(msg.metadata.confidence * 100)}% conf.
                      </span>
                    )}
                    {msg.metadata?.source && (
                      <span className={cn(
                        "text-[10px] px-1.5 py-0.5 rounded font-medium",
                        theme === 'dark' ? "bg-blue-900/30 text-blue-400" : "bg-blue-100 text-blue-700"
                      )}>
                        {msg.metadata.source.replace('_', ' ')}
                      </span>
                    )}
                  </div>
                  
                  {msg.sender === 'ai' && (
                    <div className="mt-3 mb-2 flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-200/10">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mr-1">Follow-up:</span>
                      {getFollowUpChips(msg.content).map((chip, chipIdx) => (
                        <motion.button
                          key={chip.label}
                          initial={{ opacity: 0, scale: 0.9, y: 4 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          transition={{ 
                            type: "spring", 
                            stiffness: 300, 
                            damping: 20, 
                            delay: chipIdx * 0.04 
                          }}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          type="button"
                          onClick={() => {
                            if (onSendMessage) {
                              onSendMessage(chip.prompt);
                              showNotification?.(`Triggered "${chip.label}"`, 'success');
                            }
                          }}
                          className={cn(
                            "px-2.5 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer border flex items-center gap-1 shadow-sm",
                            theme === 'dark'
                              ? "bg-slate-800/80 border-slate-700 text-indigo-300 hover:bg-indigo-600 hover:text-white hover:border-indigo-500"
                              : "bg-white border-slate-200 text-indigo-700 hover:bg-indigo-600 hover:text-white hover:border-indigo-600"
                          )}
                          title={`Suggested follow-up: ${chip.prompt}`}
                          aria-label={`Follow-up: ${chip.label}`}
                        >
                          {chip.label}
                        </motion.button>
                      ))}
                    </div>
                  )}

                  {msg.sender === 'ai' && (
                    <div className="mt-3 flex items-center justify-between border-t border-slate-200/20 pt-3">
                      <div className="relative z-50 flex items-center gap-2.5">
                        <div className="relative">
                          <button 
                            onClick={() => setActiveLangMenuMessageId(activeLangMenuMessageId === msg.id ? null : msg.id)}
                            className="flex items-center gap-1.5 text-[10px] uppercase font-bold text-slate-500 hover:text-indigo-500 transition-colors cursor-pointer"
                          >
                            <Languages size={12} /> {LANGUAGES.find(l => l.code === language)?.flag} {LANGUAGES.find(l => l.code === language)?.name} <ChevronDown size={12} className={cn("transition-transform duration-200", activeLangMenuMessageId === msg.id && "rotate-180")} />
                          </button>
                          
                          {activeLangMenuMessageId === msg.id && (
                            <>
                              <div className="fixed inset-0 z-40 cursor-default" onClick={() => setActiveLangMenuMessageId(null)} />
                              <div className={cn(
                                "absolute bottom-full left-0 mb-2 w-48 rounded-xl shadow-xl border p-2 z-50 animate-in fade-in slide-in-from-bottom-2",
                                theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-slate-950/80" : "bg-white border-slate-200 shadow-slate-200/50"
                              )}>
                                <div className="px-2 py-1 text-[9px] font-black uppercase tracking-wider text-slate-400 mb-1">Translate Output</div>
                                {LANGUAGES.map(lang => (
                                  <button
                                    key={lang.code}
                                    className={cn(
                                      "w-full text-left px-2 py-1.5 text-xs rounded-lg flex items-center justify-between cursor-pointer",
                                      language === lang.code ? "bg-indigo-50 text-indigo-600 font-medium" : (theme === 'dark' ? "hover:bg-slate-800 text-slate-300" : "hover:bg-slate-50 text-slate-700")
                                    )}
                                    onClick={() => {
                                      handleTranslate(msg.id, msg.content, lang.name, lang.code);
                                      setActiveLangMenuMessageId(null);
                                    }}
                                  >
                                    <span className="flex items-center gap-2">{lang.flag} {lang.name}</span>
                                  </button>
                                ))}
                              </div>
                            </>
                          )}
                        </div>

                        {/* Start Lesson button after translation drop-down list button */}
                        <button
                          onClick={() => handleInitiateVirtualLesson(msg, true)}
                          disabled={initializingLessonMessageId === msg.id}
                          className={cn(
                            "flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] uppercase font-bold transition-all duration-200 cursor-pointer border shadow-sm relative overflow-hidden",
                            initializingLessonMessageId === msg.id
                              ? "bg-emerald-500/40 text-emerald-100 border-emerald-400 ring-2 ring-emerald-400/40 animate-pulse cursor-wait"
                              : theme === 'dark'
                              ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/25 active:scale-95"
                              : "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 active:scale-95"
                          )}
                          title="Start interactive lecture and audio explanation for this lesson"
                        >
                          {initializingLessonMessageId === msg.id ? (
                            <>
                              <Sparkles size={11} className="text-amber-400 animate-spin" />
                              <span className="animate-pulse">Initializing...</span>
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping ml-0.5" />
                            </>
                          ) : (
                            <>
                              <Play size={11} className="text-emerald-500 fill-emerald-500" />
                              <span>Start Lesson</span>
                            </>
                          )}
                        </button>



                        {/* Concept Check Button */}
                        <button 
                          onClick={() => handleGenerateChalkboardQuiz(msg)}
                          disabled={loadingQuizMessageId !== null}
                          className={cn(
                            "p-1.5 rounded-lg transition-all duration-200 cursor-pointer border",
                            messageQuizzes[msg.id] 
                              ? (theme === 'dark' 
                                  ? "text-amber-400 bg-amber-500/15 border-amber-500/30" 
                                  : "text-amber-600 bg-amber-500/10 border-amber-500/20")
                              : (theme === 'dark' 
                                  ? "text-slate-400 border-slate-800 hover:text-indigo-400 hover:bg-slate-800 hover:border-slate-700" 
                                  : "text-slate-500 border-slate-200 hover:text-indigo-600 hover:bg-slate-50 hover:border-slate-300"),
                            loadingQuizMessageId === msg.id && "animate-pulse"
                          )}
                          title={
                            loadingQuizMessageId === msg.id 
                              ? "Crafting concept check quiz..." 
                              : messageQuizzes[msg.id] 
                                ? "Close Concept Check Quiz" 
                                : "Take an interactive Concept Check Quiz"
                          }
                        >
                          {loadingQuizMessageId === msg.id ? (
                            <Loader2 size={16} className="animate-spin text-amber-500" />
                          ) : (
                            <GraduationCap size={16} />
                          )}
                        </button>

                        {(() => {
                          const conceptInfo = detectNewConcept(msg.content);
                          if (!conceptInfo.introduced) return null;
                          return (
                            <button
                              onClick={() => {
                                playChalkClickSound();
                                onOpenTool?.('quiz', { subject, topic: conceptInfo.conceptName || topic });
                              }}
                              className={cn(
                                "flex items-center gap-1.5 text-[10px] uppercase font-black px-2.5 py-1.5 rounded-lg border cursor-pointer transition-all duration-200 animate-pulse ml-1.5",
                                theme === 'dark' 
                                  ? "text-indigo-400 bg-indigo-500/15 border-indigo-500/30 hover:bg-indigo-500/25" 
                                  : "text-indigo-600 bg-indigo-50 border-indigo-200 hover:bg-indigo-100"
                              )}
                              title={`Practice interactive quiz for: ${conceptInfo.conceptName || topic || 'this concept'}`}
                            >
                              <Brain size={14} className={theme === 'dark' ? "text-indigo-400" : "text-indigo-600"} />
                              Practice Quick Quiz
                            </button>
                          );
                        })()}
                      </div>
                      
                      <div className="flex items-center gap-1">
                        {/* Share button */}
                        <button
                          onClick={() => handleShareMessage(msg)}
                          className={cn(
                            "p-1.5 rounded-lg transition-colors text-slate-400 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                          )}
                          title="Share message"
                        >
                          <Share2 size={16} />
                        </button>

                        {/* "spq" (Solved Practice Questions) button - Added per user request */}
                        <button
                          type="button"
                          onClick={() => handleSolvePracticeQuestions(msg)}
                          className={cn(
                            "px-2 py-1.5 rounded-lg transition-all text-xs font-black uppercase tracking-wider text-purple-500 dark:text-purple-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-1 shrink-0"
                          )}
                          title="Solve & Explain Practice Questions of Current Chat (SPQ)"
                        >
                          <GraduationCap size={13} className="text-purple-500 dark:text-purple-400" />
                          <span>spq</span>
                        </button>

                        {/* Speaker / Read Aloud button */}
                        <button 
                          onClick={() => handleStartReading(msg.id, localTranslations[msg.id] || msg.content)}
                          className={cn(
                            "p-1.5 rounded-lg transition-all duration-300 relative overflow-hidden flex items-center gap-2 min-w-[32px]",
                            (speakingMessageId === msg.id && isSpeaking)
                              ? "text-indigo-600 bg-indigo-50 dark:bg-slate-800 font-bold pr-3"
                              : "text-slate-400 hover:text-indigo-500 hover:bg-slate-50 dark:hover:bg-slate-700"
                          )}
                          title="Read Aloud: Play speech from the beginning"
                        >
                          {speakingMessageId === msg.id && isSpeaking && !isPaused && isWaveformVisualizerEnabled ? (
                            <WaveformVisualizer isAnimating={true} analyser={analyserRef.current} className="w-6 h-4" />
                          ) : (
                            <Volume2 size={16} />
                          )}
                          {(speakingMessageId === msg.id && isSpeaking) && (
                            <span className="text-[10px] uppercase font-black tracking-tighter opacity-70 animate-in fade-in slide-in-from-left-1">
                              {PERSONAS.find(p => p.id === selectedPersonaId)?.name || 'Kore'}
                            </span>
                          )}
                        </button>

                        {speakingMessageId === msg.id && isSpeaking && (
                          <>
                            <button 
                              onClick={handleRewind}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-500 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all"
                              title="Rewind 5 seconds"
                            >
                              <RotateCcw size={16} />
                            </button>

                            <button 
                              onClick={() => handlePauseResume()}
                              className={cn(
                                "p-1.5 rounded-lg transition-all duration-300",
                                (speakingMessageId === msg.id && isSpeaking)
                                  ? isPaused
                                    ? "text-emerald-500 bg-emerald-50 dark:bg-emerald-950/20"
                                    : "text-indigo-500 bg-indigo-50 dark:bg-indigo-950/20 animate-pulse"
                                  : "text-slate-300 cursor-not-allowed opacity-50"
                              )}
                              title={(speakingMessageId === msg.id && isSpeaking) ? (isPaused ? "Resume speech" : "Pause speech") : "Pause & Resume (Active when reading is playing)"}
                              disabled={!(speakingMessageId === msg.id && isSpeaking)}
                            >
                              {isPaused && speakingMessageId === msg.id ? <Play size={16} className="fill-current" /> : <Pause size={16} />}
                            </button>

                            <button 
                              onClick={handleForward}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-500 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all"
                              title="Forward 5 seconds"
                            >
                              <RotateCw size={16} />
                            </button>

                            <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 ml-1">
                              <span className="text-[9px] font-mono font-bold text-indigo-500 min-w-[28px]">{ttsRate.toFixed(1)}x</span>
                              <input 
                                type="range"
                                min="0.5"
                                max="2.0"
                                step="0.1"
                                value={ttsRate}
                                onChange={(e) => {
                                  const rate = parseFloat(e.target.value);
                                  setTtsRate(rate);
                                  localStorage.setItem('omni_tts_rate', String(rate));
                                }}
                                className="w-16 h-1 rounded appearance-none cursor-pointer accent-indigo-500 bg-slate-300 dark:bg-slate-600"
                                title="Adjust active lecture speech playback speed"
                              />
                            </div>
                          </>
                        )}

                        {/* Download Video button (if present) */}
                        {msg.metadata?.videoUrl && (
                          <button 
                            onClick={() => {
                              downloadFileFromUrl(msg.metadata.videoUrl, `ai_lesson_video_${msg.id}.mp4`);
                            }}
                            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[10px] uppercase tracking-wider px-2.5 py-1.5 rounded-xl transition-all cursor-pointer shadow-md"
                            title="Download AI Generated Video"
                          >
                            <Download size={12} />
                            <span>Download Video</span>
                          </button>
                        )}

                        {/* Quick Action Button */}
                        <div className="relative">
                          <button
                            type="button"
                            onClick={() => setActiveQuickActionMenuMessageId(activeQuickActionMenuMessageId === msg.id ? null : msg.id)}
                            className={cn(
                              "flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-all duration-300 border font-extrabold text-[10px] uppercase tracking-wider shadow-sm cursor-pointer whitespace-nowrap",
                              activeQuickActionMenuMessageId === msg.id
                                ? "bg-amber-500 text-slate-950 border-amber-400"
                                : (theme === 'dark'
                                    ? "text-amber-300 bg-amber-950/40 border-amber-500/40 hover:bg-amber-900/60"
                                    : "text-amber-700 bg-amber-50 border-amber-200 hover:bg-amber-100")
                            )}
                            title="Quick Actions & Timeline"
                          >
                            <span>⚡ Quick</span>
                          </button>

                          <AnimatePresence>
                            {activeQuickActionMenuMessageId === msg.id && (
                              <>
                                <div className="fixed inset-0 z-40" onClick={() => setActiveQuickActionMenuMessageId(null)} />
                                <motion.div
                                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                  animate={{ opacity: 1, y: 0, scale: 1 }}
                                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                  className={cn(
                                    "absolute bottom-full right-0 mb-2 p-3 rounded-xl shadow-2xl border w-[320px] sm:w-[350px] max-h-[440px] overflow-y-auto z-50 space-y-2.5 text-left scrollbar-thin",
                                    theme === 'dark' ? "bg-slate-950 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                                  )}
                                >
                                  {/* Sub-tab Navigation Header */}
                                  <div className="flex items-center gap-1 p-1 bg-slate-900/90 rounded-lg border border-slate-800/80">
                                    <button
                                      type="button"
                                      onClick={() => setQuickMenuSubTab('timeline')}
                                      className={cn(
                                        "flex-1 py-1.5 px-2 rounded-md text-[10px] font-extrabold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5",
                                        quickMenuSubTab === 'timeline'
                                          ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                                          : "text-slate-400 hover:text-slate-200"
                                      )}
                                    >
                                      <GraduationCap size={13} />
                                      <span>🎓 Timeline Tab</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setQuickMenuSubTab('actions')}
                                      className={cn(
                                        "flex-1 py-1.5 px-2 rounded-md text-[10px] font-extrabold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5",
                                        quickMenuSubTab === 'actions'
                                          ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30"
                                          : "text-slate-400 hover:text-slate-200"
                                      )}
                                    >
                                      <Zap size={13} />
                                      <span>⚡ Actions Tab</span>
                                    </button>
                                  </div>

                                  {quickMenuSubTab === 'timeline' ? (
                                    <div className="space-y-2">
                                      <LectureProgressTimeline
                                        isLectureMode={true}
                                        lectureSubMode={lectureSubMode}
                                        lectureProfessorStyle={lectureProfessorStyle}
                                        tutorPersonaConfig={tutorPersonaConfig}
                                        onToggleProfessorStyle={handleToggleProfessorStyle}
                                        activeVerbalQuestion={activeVerbalQuestion}
                                        activeBookmark={activeLectureBookmark}
                                        timelineMarkers={timelineMarkers}
                                        onAddCheckpointQuestion={() => {
                                          handlePauseVideoForLectureQuestion(
                                            "Checkpoint: What key physical law governs the conservation of energy in this closed system?",
                                            ["law", "conservation", "energy", "system", "constant", "closed", "yes"],
                                            "Answer verbally to verify your understanding."
                                          );
                                        }}
                                        onSelectMarker={(marker) => {
                                          if (marker.type === 'professor_shift' && marker.professorStyle) {
                                            setLectureProfessorStyle?.(marker.professorStyle);
                                            showNotification?.(`Applied ${marker.title}`, "info");
                                          } else if (marker.type === 'checkpoint_question') {
                                            showNotification?.(`Active Checkpoint: "${marker.title}"`, "info");
                                          }
                                        }}
                                        currentElapsedSec={Math.floor((elapsedMsRef.current || 0) / 1000) || 180}
                                        totalDurationSec={600}
                                        theme={theme}
                                        className="shadow-none border border-slate-800 bg-slate-900/90 mb-0"
                                      />
                                    </div>
                                  ) : (
                                    <div className="space-y-2">
                                      {/* Lecture Mode Timeline Features */}
                                      <div className="space-y-1 pb-1.5 border-b border-slate-800/40">
                                        <div className="text-[9px] uppercase font-bold text-amber-400 px-1 pt-0.5">
                                          Lecture & Timeline Controls
                                        </div>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            openCrashDoubtModal();
                                            setActiveQuickActionMenuMessageId(null);
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                          )}
                                          title="Raise Crash Doubt during running lecture"
                                        >
                                          <div className="flex items-center gap-2">
                                            <span className="text-sm select-none">⚡❓</span>
                                            <span>Crash Doubt</span>
                                          </div>
                                          <span className="text-[9px] opacity-70 font-mono">Doubt</span>
                                        </button>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            handlePauseVideoForLectureQuestion(
                                              "What is the principle of conservation of energy?",
                                              ["energy", "created", "destroyed", "transform", "conserved", "constant"],
                                              "Energy cannot be created or destroyed, only transformed from one form to another."
                                            );
                                            setActiveQuickActionMenuMessageId(null);
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30"
                                          )}
                                          title="Pause video and ask a lecture question requiring verbal reply"
                                        >
                                          <div className="flex items-center gap-2">
                                            <HelpCircle size={13} className="text-amber-400" />
                                            <span>❓ Checkpoint Question</span>
                                          </div>
                                          <span className="text-[9px] opacity-70 font-mono">Pause</span>
                                        </button>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            handleToggleProfessorStyle();
                                            setActiveQuickActionMenuMessageId(null);
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer border",
                                            lectureProfessorStyle === 'strict'
                                              ? "bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border-indigo-500/30"
                                              : "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                                          )}
                                          title="Toggle between Strict Professor and Interactive Mentor lecture modes"
                                        >
                                          <div className="flex items-center gap-2">
                                            <GraduationCap size={13} />
                                            <span>{lectureProfessorStyle === 'strict' ? '🎓 Strict Professor' : '🤝 Interactive Mentor'}</span>
                                          </div>
                                          <span className="text-[9px] opacity-70 font-mono">Mode</span>
                                        </button>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            saveLectureBookmark("Manual Bookmark", msg.id);
                                            setActiveQuickActionMenuMessageId(null);
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-violet-500/10 hover:bg-violet-500/20 text-violet-400 border border-violet-500/30"
                                          )}
                                          title="Bookmark current lecture timestamp"
                                        >
                                          <div className="flex items-center gap-2">
                                            <Bookmark size={13} className="fill-current text-violet-400" />
                                            <span>🔖 Bookmark Timeline</span>
                                          </div>
                                          <span className="text-[9px] opacity-70 font-mono">Save</span>
                                        </button>

                                        {activeLectureBookmark && (
                                          <button
                                            type="button"
                                            onClick={() => {
                                              restoreLectureBookmark(activeLectureBookmark);
                                              setActiveQuickActionMenuMessageId(null);
                                            }}
                                            className={cn(
                                              "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse"
                                            )}
                                            title={`Restore & seek to bookmark at ${activeLectureBookmark.timeLabel}`}
                                          >
                                            <div className="flex items-center gap-2">
                                              <Bookmark size={13} className="fill-current text-emerald-400" />
                                              <span>⏩ Seek {activeLectureBookmark.timeLabel}</span>
                                            </div>
                                            <span className="text-[9px] opacity-70 font-mono">Jump</span>
                                          </button>
                                        )}

                                        <button
                                          type="button"
                                          onClick={() => {
                                            setIsCacheStatsModalOpen(true);
                                            setActiveQuickActionMenuMessageId(null);
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                                          )}
                                          title="View IndexedDB Local Offline Cache details"
                                        >
                                          <div className="flex items-center gap-2">
                                            <HardDrive size={13} className="text-cyan-400" />
                                            <span>💾 IndexedDB Offline Cache</span>
                                          </div>
                                          <span className="text-[9px] opacity-70 font-mono">{cacheStats.cachedVideos} vids</span>
                                        </button>
                                      </div>

                                      {/* Quick Message Actions */}
                                      <div className="space-y-1">
                                        <div className="text-[9px] uppercase font-bold text-slate-400 px-1 pt-0.5">
                                          Quick Chat Actions
                                        </div>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            onSendMessage("Please summarize our current lecture and discussion so far with key takeaways.");
                                            setActiveQuickActionMenuMessageId(null);
                                            showNotification?.("Summarizing chat...", "info");
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                            theme === 'dark' ? "hover:bg-slate-800 text-indigo-400" : "hover:bg-slate-100 text-indigo-600"
                                          )}
                                        >
                                          <Sparkles size={13} />
                                          <span>Summarize Chat</span>
                                        </button>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            onSendMessage("Generate a 5-question multiple choice practice quiz based on our recent topics.");
                                            setActiveQuickActionMenuMessageId(null);
                                            showNotification?.("Generating quiz...", "info");
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                            theme === 'dark' ? "hover:bg-slate-800 text-purple-400" : "hover:bg-slate-100 text-purple-600"
                                          )}
                                        >
                                          <HelpCircle size={13} />
                                          <span>Generate Quiz</span>
                                        </button>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            onSendMessage("Please explain this concept with an annotated visual diagram and step-by-step breakdown.");
                                            setActiveQuickActionMenuMessageId(null);
                                            showNotification?.("Requesting annotated diagram explanation...", "info");
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                            theme === 'dark' ? "hover:bg-slate-800 text-emerald-400" : "hover:bg-slate-100 text-emerald-600"
                                          )}
                                        >
                                          <ImageIcon size={13} />
                                          <span>Explain with Diagram</span>
                                        </button>

                                        <button
                                          type="button"
                                          onClick={() => {
                                            onClearChat();
                                            setActiveQuickActionMenuMessageId(null);
                                            showNotification?.("Conversation cleared.", "info");
                                          }}
                                          className={cn(
                                            "w-full p-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all cursor-pointer",
                                            theme === 'dark' ? "hover:bg-slate-800 text-red-400" : "hover:bg-slate-100 text-red-600"
                                          )}
                                        >
                                          <Trash2 size={13} />
                                          <span>Clear Chat</span>
                                        </button>
                                      </div>
                                    </div>
                                  )}
                                </motion.div>
                              </>
                            )}
                          </AnimatePresence>
                        </div>

                        {onDeleteMessage && (
                          <button
                            onClick={() => onDeleteMessage(msg.id)}
                            className="p-1.5 rounded-lg transition-colors text-slate-400 hover:text-red-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                            title="Delete message"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}

                        {/* Edit button */}
                        <button
                          onClick={() => {
                            setEditingMessageId(msg.id);
                            setEditingContent(msg.content);
                            showNotification?.('Editing message inline...', 'info');
                          }}
                          className={cn(
                            "px-2 py-1 rounded-lg transition-colors text-xs font-bold flex items-center gap-1 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 cursor-pointer border border-slate-200 dark:border-slate-800"
                          )}
                          title="Edit message content"
                        >
                          <Edit3 size={13} />
                          <span>Edit</span>
                        </button>

                        {/* Copy button */}
                        <button
                          onClick={() => handleCopyMessage(msg.id, localTranslations[msg.id] || msg.content)}
                          className={cn(
                            "p-1.5 rounded-lg transition-colors text-slate-400 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                          )}
                          title="Copy message content"
                        >
                          {copiedMessageId === msg.id ? (
                            <Check size={16} className="text-green-500 animate-in zoom-in-50" />
                          ) : (
                            <Copy size={16} />
                          )}
                        </button>

                        <button
                          onClick={() => handlePrintMessage(msg)}
                          className={cn(
                            "p-1.5 rounded-lg transition-colors text-slate-400 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                          )}
                          title="Print message content"
                        >
                          <Printer size={16} />
                        </button>

                        <div className="relative">
                          <button
                            onClick={() => setActiveSpeedMenuMessageId(activeSpeedMenuMessageId === msg.id ? null : msg.id)}
                            className={cn(
                              "p-1.5 rounded-lg transition-colors relative flex items-center justify-center cursor-pointer text-slate-400 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800",
                              activeSpeedMenuMessageId === msg.id && "text-indigo-500 bg-slate-100 dark:bg-slate-800"
                            )}
                            title="Adjust speed/pace controls"
                          >
                            <Sliders size={16} />
                          </button>

                          {activeSpeedMenuMessageId === msg.id && (
                            <>
                              <div className="fixed inset-0 z-40 cursor-default" onClick={() => setActiveSpeedMenuMessageId(null)} />
                              <div className={cn(
                                "absolute bottom-full right-0 mb-2 w-72 rounded-2xl shadow-xl border p-4 z-50 animate-in fade-in slide-in-from-top-2 text-left",
                                theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-slate-950/80 text-white" : "bg-white border-slate-200 shadow-slate-200/50 text-slate-900"
                              )}>
                                <div className="flex items-center justify-between pb-2 mb-2 border-b border-dashed border-slate-200/60 dark:border-slate-800/80">
                                  <div className="text-[10px] font-black uppercase tracking-wider text-indigo-500 flex items-center gap-1">
                                    <Sliders size={12} />
                                    Speed Controller
                                  </div>
                                  <button
                                    onClick={() => {
                                      const nextLink = !linkSpeeds;
                                      setLinkSpeeds(nextLink);
                                      localStorage.setItem('omni_link_speeds', String(nextLink));
                                      if (nextLink) {
                                        let linkedPace = 'fluent';
                                        if (ttsRate === 0.5 || ttsRate === 0.75) linkedPace = 'deliberate';
                                        else if (ttsRate === 1.0) linkedPace = 'fluent';
                                        else if (ttsRate === 1.2 || ttsRate === 1.5) linkedPace = 'swift';
                                        else if (ttsRate === 2.0) linkedPace = 'instant';
                                        setTypingPace(linkedPace);
                                        localStorage.setItem('omni_typing_pace', linkedPace);
                                      }
                                    }}
                                    className={cn(
                                      "flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider transition-all cursor-pointer active:scale-95",
                                      linkSpeeds 
                                        ? "bg-indigo-100 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-900/40"
                                        : "bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-500 dark:text-slate-400"
                                    )}
                                    title="Sync/link Reading and Writing speed"
                                  >
                                    {linkSpeeds ? <Link size={9} /> : <Link2Off size={9} />}
                                    {linkSpeeds ? "Linked" : "Link Speeds"}
                                  </button>
                                </div>

                                {/* Reading Speed Row */}
                                <div className="space-y-1.5 mb-3.5">
                                  <div className="flex items-center justify-between text-[10px]">
                                    <span className="font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                                      <Volume2 size={11} /> Reading (TTS)
                                    </span>
                                    <span className="font-mono font-black text-indigo-500">{ttsRate.toFixed(2)}x</span>
                                  </div>
                                  <input
                                    type="range"
                                    min="0.5"
                                    max="2.0"
                                    step="0.1"
                                    value={ttsRate}
                                    onChange={(e) => {
                                      const rate = parseFloat(e.target.value);
                                      setTtsRate(rate);
                                      localStorage.setItem('omni_tts_rate', String(rate));
                                      if (linkSpeeds) {
                                        let linkedPace = 'fluent';
                                        if (rate <= 0.75) linkedPace = 'deliberate';
                                        else if (rate <= 1.0) linkedPace = 'fluent';
                                        else if (rate <= 1.5) linkedPace = 'swift';
                                        else linkedPace = 'instant';
                                        setTypingPace(linkedPace);
                                        localStorage.setItem('omni_typing_pace', linkedPace);
                                      }
                                    }}
                                    className="w-full h-2 rounded-lg appearance-none cursor-pointer accent-indigo-500 bg-slate-200 dark:bg-slate-700"
                                  />
                                </div>

                                {/* Writing Speed Row */}
                                <div className="space-y-1.5">
                                  <div className="flex items-center justify-between text-[10px]">
                                    <span className="font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                                      <Gauge size={11} /> Writing (Typing)
                                    </span>
                                    <span className="font-bold text-indigo-500 capitalize">{typingPace}</span>
                                  </div>
                                  <div className="grid grid-cols-4 gap-1">
                                    {['deliberate', 'fluent', 'swift', 'instant'].map((pace) => {
                                      const isActive = typingPace === pace;
                                      return (
                                        <button
                                          key={pace}
                                          onClick={() => {
                                            setTypingPace(pace);
                                            localStorage.setItem('omni_typing_pace', pace);
                                            let spd = 1.0;
                                            if (pace === 'deliberate') spd = 0.6;
                                            else if (pace === 'fluent') spd = 1.0;
                                            else if (pace === 'swift') spd = 1.6;
                                            else if (pace === 'instant') spd = 3.0;
                                            setBlackboardWritingSpeed(spd);
                                            localStorage.setItem('omni_blackboard_writing_speed', String(spd));
                                            if (linkSpeeds) {
                                              let linkedRate = 1.0;
                                              if (pace === 'deliberate') linkedRate = 0.75;
                                              else if (pace === 'fluent') linkedRate = 1.0;
                                              else if (pace === 'swift') linkedRate = 1.5;
                                              else if (pace === 'instant') linkedRate = 2.0;
                                              setTtsRate(linkedRate);
                                              localStorage.setItem('omni_tts_rate', String(linkedRate));
                                            }
                                          }}
                                          className={cn(
                                            "py-1 rounded text-[9px] font-black uppercase text-center border cursor-pointer active:scale-95 capitalize",
                                            isActive
                                              ? "bg-indigo-500 border-indigo-500 text-white shadow"
                                              : theme === 'dark'
                                                ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750"
                                                : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200"
                                          )}
                                        >
                                          {pace}
                                        </button>
                                      );
                                    })}
                                  </div>
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                        


                        <button 
                          onClick={() => {
                            const next = !isVadEnabled;
                            setIsVadEnabled(next);
                            showNotification?.(next ? "Smart Voice Interruption (VAD) Enabled" : "Smart Voice Interruption (VAD) Disabled", "info");
                          }}
                          className={cn(
                            "p-1.5 rounded-lg transition-colors cursor-pointer hover:scale-110 hover:shadow-sm",
                            isVadEnabled
                              ? "text-emerald-500 bg-emerald-50 dark:bg-emerald-950/20"
                              : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                          )}
                          title={isVadEnabled ? "Smart Voice Interruption: ON (Click to turn off)" : "Smart Voice Interruption: OFF (Click to turn on)"}
                        >
                          {isVadEnabled ? <Mic size={16} /> : <MicOff size={16} />}
                        </button>

                        {/* Maximize/Minimize button */}
                        <button 
                          onClick={() => {
                            playChalkClickSound();
                            if (maximizedMessageId === msg.id) {
                              setMaximizedMessageId(null);
                            } else {
                              setMaximizedMessageId(msg.id);
                            }
                          }}
                          className={cn(
                            "p-1.5 rounded-lg transition-colors cursor-pointer",
                            maximizedMessageId === msg.id
                              ? "text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 dark:text-indigo-400" 
                              : "text-slate-400 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                          )}
                          title={maximizedMessageId === msg.id ? "Minimize message" : "Maximize message"}
                        >
                          {maximizedMessageId === msg.id ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
                        </button>

                        {isGeneratingVideo && (
                          <span className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-mono text-xs font-bold animate-pulse select-none border border-indigo-100 dark:border-indigo-900/30">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping" />
                            <span>Generating Video: {videoGenerationTime}s</span>
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                  </div>
                </div>
              )}
            </motion.div>

              {inlineBoxTargetMsgId === msg.id && (
                <motion.div 
                  ref={inlineBoxContainerRef} 
                  initial={{ opacity: 0, scale: 0.96, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  className="my-4 p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950/90 to-slate-900 border-2 border-indigo-500 shadow-2xl space-y-3 z-30"
                  onClick={(e) => e.stopPropagation()}
                  onDoubleClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between border-b border-indigo-500/30 pb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow">
                        <Sparkles size={14} />
                      </div>
                      <div>
                        <h4 className="text-xs font-black text-white tracking-wide">
                          add content (text/diagram/image/photo etc).
                        </h4>
                        <p className="text-[10px] text-slate-400">
                          Speak, write, or attach photo/diagram. Omni AI will write it between chat lines.
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleFinalizeInlineAddition}
                      className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                      title="Click out or close to complete addition"
                    >
                      <X size={14} />
                    </button>
                  </div>

                  <textarea
                    value={inlineBoxText}
                    onChange={(e) => setInlineBoxText(e.target.value)}
                    placeholder="Type here or use dictation mic to speak... Omni AI will write it between chat lines."
                    className="w-full h-40 p-3 rounded-xl bg-slate-950/90 border border-slate-700 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 resize-none font-sans"
                  />

                  {inlineBoxImage && (
                    <div className="relative w-24 h-24 rounded-xl overflow-hidden border border-slate-700 bg-black">
                      <img src={inlineBoxImage} alt="Attachment" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setInlineBoxImage(null)}
                        className="absolute top-1 right-1 p-1 rounded-full bg-black/80 text-white hover:bg-rose-600 transition"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleToggleInlineDictation}
                        className={cn(
                          "px-3 py-1.5 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer",
                          isInlineDictating
                            ? "bg-rose-600 text-white border-rose-400 animate-pulse shadow-md shadow-rose-500/30"
                            : "bg-indigo-900/80 hover:bg-indigo-800 text-indigo-200 border-indigo-700/80"
                        )}
                        title="Dictation - Speak into box"
                      >
                        <Mic size={14} className={isInlineDictating ? "animate-bounce text-white" : "text-indigo-300"} />
                        <span>{isInlineDictating ? "Listening..." : "Dictation"}</span>
                      </button>

                      <label className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition flex items-center gap-1.5 cursor-pointer">
                        <ImageIcon size={14} />
                        <span>Photo / Image</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleInlineImageUpload}
                        />
                      </label>

                      <button
                        type="button"
                        onClick={() => setIsWhiteboardOpen(true)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-300 font-bold text-xs border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <Pencil size={14} />
                        <span>Diagram</span>
                      </button>
                    </div>

                    <button
                      type="button"
                      disabled={isInlineAiWriting || (!inlineBoxText.trim() && !inlineBoxImage)}
                      onClick={handleExecuteAddContent}
                      className={cn(
                        "px-4 py-2 rounded-xl text-xs font-black shadow-lg transition flex items-center gap-1.5 cursor-pointer",
                        isInlineAiWriting
                          ? "bg-indigo-700 text-white opacity-80 cursor-not-allowed"
                          : "bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-slate-950 shadow-amber-500/20 active:scale-95"
                      )}
                    >
                      <Sparkles size={14} className={isInlineAiWriting ? "animate-spin" : ""} />
                      <span>{isInlineAiWriting ? "Omni AI Writing..." : "add content (text/diagram/image/photo etc)."}</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </React.Fragment>
          ))}

          {(inlineBoxTargetMsgId === 'end' || (inlineBoxTargetMsgId && localMessages.length === 0)) && (
            <motion.div 
              ref={inlineBoxContainerRef} 
              initial={{ opacity: 0, scale: 0.96, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="my-4 p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950/90 to-slate-900 border-2 border-indigo-500 shadow-2xl space-y-3 z-30"
              onClick={(e) => e.stopPropagation()}
              onDoubleClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between border-b border-indigo-500/30 pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow">
                    <Sparkles size={14} />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-white tracking-wide">
                      add content (text/diagram/image/photo etc).
                    </h4>
                    <p className="text-[10px] text-slate-400">
                      Speak, write, or attach photo/diagram. Omni AI will write it between chat lines.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleFinalizeInlineAddition}
                  className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                  title="Click out or close to complete addition"
                >
                  <X size={14} />
                </button>
              </div>

              <textarea
                value={inlineBoxText}
                onChange={(e) => setInlineBoxText(e.target.value)}
                placeholder="Type here or use dictation mic to speak... Omni AI will write it between chat lines."
                className="w-full h-40 p-3 rounded-xl bg-slate-950/90 border border-slate-700 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 resize-none font-sans"
              />

              {inlineBoxImage && (
                <div className="relative w-24 h-24 rounded-xl overflow-hidden border border-slate-700 bg-black">
                  <img src={inlineBoxImage} alt="Attachment" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setInlineBoxImage(null)}
                    className="absolute top-1 right-1 p-1 rounded-full bg-black/80 text-white hover:bg-rose-600 transition"
                  >
                    <X size={12} />
                  </button>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleToggleInlineDictation}
                    className={cn(
                      "px-3 py-1.5 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer",
                      isInlineDictating
                        ? "bg-rose-600 text-white border-rose-400 animate-pulse shadow-md shadow-rose-500/30"
                        : "bg-indigo-900/80 hover:bg-indigo-800 text-indigo-200 border-indigo-700/80"
                    )}
                    title="Dictation - Speak into box"
                  >
                    <Mic size={14} className={isInlineDictating ? "animate-bounce text-white" : "text-indigo-300"} />
                    <span>{isInlineDictating ? "Listening..." : "Dictation"}</span>
                  </button>

                  <label className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition flex items-center gap-1.5 cursor-pointer">
                    <ImageIcon size={14} />
                    <span>Photo / Image</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleInlineImageUpload}
                    />
                  </label>

                  <button
                    type="button"
                    onClick={() => setIsWhiteboardOpen(true)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-purple-300 font-bold text-xs border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Pencil size={14} />
                    <span>Diagram</span>
                  </button>
                </div>

                <button
                  type="button"
                  disabled={isInlineAiWriting || (!inlineBoxText.trim() && !inlineBoxImage)}
                  onClick={handleExecuteAddContent}
                  className={cn(
                    "px-4 py-2 rounded-xl text-xs font-black shadow-lg transition flex items-center gap-1.5 cursor-pointer",
                    isInlineAiWriting
                      ? "bg-indigo-700 text-white opacity-80 cursor-not-allowed"
                      : "bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-slate-950 shadow-amber-500/20 active:scale-95"
                  )}
                >
                  <Sparkles size={14} className={isInlineAiWriting ? "animate-spin" : ""} />
                  <span>{isInlineAiWriting ? "Omni AI Writing..." : "add content (text/diagram/image/photo etc)."}</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        <AnimatePresence>
          {isTyping && (() => {
            const thinkingStages = [
              'Analyzing question...',
              'Formulating pedagogical logic...',
              'Connecting curriculum concepts...',
              'Drafting step-by-step response...',
              'Polishing explanation & formulas...',
              'Finalizing comprehensive answer...'
            ];
            const currentStageIndex = Math.min(
              Math.floor(typingSeconds / 2.2),
              thinkingStages.length - 1
            );
            const currentStage = thinkingStages[currentStageIndex];

            return (
              <motion.div
                initial={{ opacity: 0, y: 12, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95, y: 8, transition: { duration: 0.15 } }}
                transition={{ type: "spring", stiffness: 350, damping: 25 }}
                className="flex justify-start my-2"
              >
                <div className={cn(
                  "ai-thinking-bubble-pulse relative px-4 py-3 rounded-2xl rounded-bl-none shadow-sm flex flex-col gap-2 font-mono text-xs font-bold backdrop-blur-md overflow-hidden transition-colors max-w-[92%] sm:max-w-md",
                  theme === 'dark' 
                    ? "bg-slate-800/95 border border-indigo-500/40 text-indigo-300" 
                    : "bg-white/95 border border-indigo-200/90 text-indigo-600"
                )}>
                  {/* Subtle soft ambient glow layer */}
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-violet-500/10 to-indigo-500/5 pointer-events-none" />

                  {/* Top Row: Icon, Live Stage Text, and Live Timer */}
                  <div className="flex items-center gap-2.5 relative z-10">
                    {/* Pulsing indicator icon */}
                    <div className="relative flex items-center justify-center shrink-0">
                      <span className="absolute -inset-1 rounded-full bg-indigo-500/25 animate-ping" />
                      <Loader2 className="w-4 h-4 animate-spin text-indigo-500 relative z-10" />
                    </div>

                    {/* Stage Cycling with Framer Motion */}
                    <div className="flex items-center gap-1.5 min-w-0 flex-1">
                      <AnimatePresence mode="wait">
                        <motion.span
                          key={currentStage}
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          transition={{ duration: 0.2 }}
                          className="truncate tracking-tight font-semibold"
                        >
                          {currentStage}
                        </motion.span>
                      </AnimatePresence>

                      {/* Animated Dot sequence */}
                      <span className="inline-flex items-center gap-0.5 text-indigo-500 shrink-0">
                        <span className="w-1 h-1 rounded-full bg-current ai-thinking-dot-1" />
                        <span className="w-1 h-1 rounded-full bg-current ai-thinking-dot-2" />
                        <span className="w-1 h-1 rounded-full bg-current ai-thinking-dot-3" />
                      </span>
                    </div>

                    {/* Timer Pill */}
                    <span className={cn(
                      "ml-auto text-[11px] font-normal px-2 py-0.5 rounded-full border shrink-0",
                      theme === 'dark'
                        ? "bg-slate-900/60 border-slate-700/60 text-slate-400"
                        : "bg-slate-100 border-slate-200 text-slate-500"
                    )}>
                      {typingSeconds}s
                    </span>
                  </div>

                  {/* Stage Progress Indicator Dots */}
                  <div className="flex items-center justify-between gap-1.5 pt-0.5 relative z-10">
                    <div className="flex items-center gap-1">
                      {thinkingStages.map((_, idx) => (
                        <span
                          key={idx}
                          className={cn(
                            "h-1 rounded-full transition-all duration-300",
                            idx === currentStageIndex
                              ? "w-3.5 bg-indigo-500 shadow-sm shadow-indigo-500/50"
                              : idx < currentStageIndex
                                ? "w-1.5 bg-indigo-400/50"
                                : "w-1 bg-slate-400/25"
                          )}
                        />
                      ))}
                    </div>
                    <span className="text-[10px] font-normal opacity-60">
                      Step {currentStageIndex + 1} of {thinkingStages.length}
                    </span>
                  </div>

                  {/* Subtle dynamic bottom progress bar */}
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-slate-700/10 dark:bg-slate-700/30 overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-indigo-500 via-violet-500 to-indigo-500"
                      initial={{ width: "15%" }}
                      animate={{ width: `${Math.min(96, 18 + currentStageIndex * 16)}%` }}
                      transition={{ duration: 0.4, ease: "easeOut" }}
                    />
                  </div>
                </div>
              </motion.div>
            );
          })()}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Auto-Scroll Suspended Floating Badge */}
      <AnimatePresence>
        {isAutoScrollPaused && ((isSpeaking && !isPaused) || isTyping) && (
          <motion.div 
            initial={{ opacity: 0, y: 15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 15, scale: 0.95 }}
            className="absolute bottom-[130px] left-1/2 transform -translate-x-1/2 z-30 pointer-events-auto"
          >
            <button
              onClick={handleResumeAutoScroll}
              className="px-4 py-2.5 rounded-full bg-amber-500/95 text-slate-950 font-black text-xs uppercase tracking-wider shadow-xl hover:bg-amber-400 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 border border-amber-400/50 backdrop-blur-md cursor-pointer animate-pulse"
            >
              <ChevronDown size={14} className="stroke-[3] animate-bounce" />
              <span>Manual scroll active • Resume Auto-Scroll</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* <AnimatePresence>
        {isSpeaking && speakingMessageId && !isPaused && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="px-4 pt-2 shrink-0"
          >
            <div className="bg-slate-900/90 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-2xl flex items-center gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-500/20 flex items-center justify-center border border-indigo-500/30">
                <Volume2 size={20} className="text-indigo-400 animate-pulse" />
              </div>
              <div className="flex-1 min-w-0 text-left">
                <div className="text-[10px] text-indigo-300 uppercase font-black tracking-widest mb-1 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Omni Reading Aloud
                </div>
                <div className="text-base text-white font-medium truncate">
                  {(() => {
                    const msg = messages.find(m => m.id === speakingMessageId);
                    if (!msg) return "";
                    const words = (localTranslations[msg.id] || msg.content).split(/\s+/).filter(Boolean);
                    const start = Math.max(0, speakingWordIndex - 3);
                    const end = Math.min(words.length, speakingWordIndex + 8);
                    return words.map((w, i) => (
                      <span 
                        key={i} 
                        className={cn(
                          "transition-all duration-300",
                          i === speakingWordIndex 
                            ? "text-amber-400 font-black scale-110 inline-block px-1 bg-amber-400/10 rounded opacity-100" 
                            : "text-slate-200 font-medium opacity-90"
                        )}
                      >
                        {w}{" "}
                      </span>
                    )).slice(start, end);
                  })()}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="px-2 py-1 rounded bg-white/5 border border-white/5 text-[10px] font-mono text-white/50">{ttsRate}x</div>
                <button 
                  onClick={handlePauseResume}
                  className="p-2.5 bg-indigo-600 rounded-xl hover:bg-indigo-500 text-white transition-all shadow-lg shadow-indigo-600/20 cursor-pointer"
                  title={isPaused ? "Resume lecture" : "Pause lecture"}
                >
                  {isPaused ? <Play size={16} className="fill-current" /> : <Pause size={16} />}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence> */}


      <div className={cn(
        "pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] px-3 sm:px-4 shrink-0 relative sticky bottom-0 z-30 backdrop-blur-xl border-t transition-colors",
        theme === 'dark' ? "bg-slate-900/95 border-slate-800/80" : "bg-slate-50/95 border-slate-200/80"
      )}>
        {/* Lecture Progress Timeline - Hidden from screen */}
        {showClassroomTimeline && isLectureMode && messages.length > 0 && (
          <LectureProgressTimeline
            variant="line"
            isLectureMode={isLectureMode}
            lectureSubMode={lectureSubMode}
            lectureProfessorStyle={lectureProfessorStyle}
            tutorPersonaConfig={tutorPersonaConfig}
            onToggleProfessorStyle={handleToggleProfessorStyle}
            activeVerbalQuestion={activeVerbalQuestion}
            activeBookmark={activeLectureBookmark}
            timelineMarkers={timelineMarkers}
            onAddCheckpointQuestion={() => {
              handlePauseVideoForLectureQuestion(
                "Checkpoint: What key physical law governs the conservation of energy in this closed system?",
                ["law", "conservation", "energy", "system", "constant", "closed", "yes"],
                "Answer verbally to verify your understanding."
              );
            }}
            onSelectMarker={(marker) => {
              if (marker.type === 'professor_shift' && marker.professorStyle) {
                setLectureProfessorStyle?.(marker.professorStyle);
                showNotification?.(`Applied ${marker.title}`, "info");
              } else if (marker.type === 'checkpoint_question') {
                showNotification?.(`Active Checkpoint: "${marker.title}"`, "info");
              }
            }}
            currentElapsedSec={Math.floor((elapsedMsRef.current || 0) / 1000) || 180}
            totalDurationSec={600}
            theme={theme}
            className="mb-1"
          />
        )}

        {/* Quick Action Pills Row */}
        {!isShared && (() => {
          const s = (subject || '').toLowerCase();
          const t = (topic || '').toLowerCase();
          const combined = `${s} ${t}`;

          const isMath = /math|algebra|calculus|geometry|trigonometry|equation|formula|matrix|vector|probability|statistics|arithmetic|derivative|integral/.test(combined);
          const isCoding = /code|programming|python|javascript|typescript|react|algorithm|sql|java|c\+\+|html|css|bug|function/.test(combined);
          const isScience = /physics|chemistry|biology|quantum|atom|molecule|cell|respiration|gravity|force|energy|reaction/.test(combined);

          const diagramActions = [
            { label: '📐 2D Vector Schematic', title: '2D Vector Teaching Schematic: Render clean interactive SVG coordinate/vector/optical schematic', prompt: `Please provide a clean, high-contrast 2D Vector Teaching Schematic (using standard SVG markup) illustrating ${topic || subject || 'this topic'}. Include clear coordinate axes, labeled vectors, directional arrows, and mathematical parameters in a clean dark chalkboard style.` },
            { label: '🎨 Dual-Perspective Lesson', title: 'Dual-Perspective Lesson: Diagram, step-by-step breakdown, worked example & 2 practice questions', prompt: `Explain ${topic || subject || 'this topic'} for ${subject || 'Science/Math'} (India-CBSE Class 12) with a dual-perspective diagram, step-by-step breakdown, worked example, and 2 practice questions.` },
            { label: '🔬 Diagram Vision AI', title: 'Diagram Vision AI: Upload or capture diagram image to analyze', prompt: '' },
            { label: '📐 Generate Visual Schematic', title: 'Generate Visual Schematic: Autonomously generate clean 2D vector technical schematic', prompt: `Generate a clean, high-resolution 2D vector scientific diagram and technical schematic illustrating: ${topic || subject || 'this topic'}. Precision vector line art, clear typographic labels, clean dark slate background, zero photographic wooden frames, zero hands. Include annotated hotspot nodes.` },
            { label: '🏷️ Diagram Legend Key', title: 'Diagram Legend Key: Hotspot visual node map and element inspector', prompt: '' },
            { label: '🧠 Diagram Element Quiz', title: 'Diagram Element Quiz: Active recall quiz for diagram elements', prompt: '' },
            { label: '📸 Diagram Gallery', title: 'Diagram Gallery: View saved diagram snapshots in study gallery', prompt: '' }
          ];

          const actions = mode === 'diagram' ? diagramActions : isMath ? [
            { label: '📐 2D Vector Schematic', title: '2D Vector Teaching Schematic: Render clean interactive SVG coordinate/vector schematic', prompt: `Please provide a clean, high-contrast 2D Vector Teaching Schematic (using standard SVG markup) illustrating ${topic || subject || 'this topic'}. Include clear axes, vector components, and mathematical labels.` },
            { label: '🧮 Algebraic Properties', title: 'Algebraic Properties Quick Reference', prompt: '' },
            { label: '🔢 Matrix Calculator', title: 'Matrix Calculator: Interactive calculator for matrices', prompt: '' },
            { label: '📊 Graph', title: 'Graph: Plot and analyze function curves and coordinates', prompt: `Please plot or graph the mathematical functions and curves related to ${topic || subject || 'this topic'}.` },
            { label: '🔢 Solve Step-by-Step', title: 'Solve: Provide step-by-step mathematical problem solving', prompt: `Solve and show step-by-step mathematical derivation for ${topic || subject || 'this topic'}.` },
            { label: '💡 Explain', title: 'Explain core mathematical principles and definitions', prompt: `Explain the core mathematical principles and formulas for ${topic || subject || 'this topic'}.` },
            { label: '❓ Create Quiz', title: 'Create Practice Quiz: Generate math practice problems', prompt: `Generate 5 practice math problems with solutions for ${topic || subject || 'this topic'}.` },
            { label: '📝 Practice Exam', title: 'Practice Exam: Launch interactive quiz generator for active chapter', prompt: '' },
            { label: '📖 Study Guide', title: 'Study Guide: Comprehensive review notes', prompt: `Create a comprehensive math study guide and formula sheet for ${topic || subject || 'this topic'}.` }
          ] : isCoding ? [
            { label: '💻 Code Example', title: 'Code Example: Provide clean snippet and implementation', prompt: `Provide clean, well-commented code implementation and usage example for ${topic || subject || 'this topic'}.` },
            { label: '🐛 Debug Guide', title: 'Debug: Common pitfalls and troubleshooting', prompt: `What are common bugs, edge cases, and debugging tips for ${topic || subject || 'this topic'}?` },
            { label: '💡 Explain Logic', title: 'Explain Architecture and Data Flow', prompt: `Explain the underlying architecture and logic behind ${topic || subject || 'this topic'}.` },
            { label: '❓ Create Quiz', title: 'Coding Quiz: Test your programming knowledge', prompt: `Generate a 5-question coding quiz on ${topic || subject || 'this topic'}.` },
            { label: '📝 Practice Exam', title: 'Practice Exam: Launch interactive quiz generator for active chapter', prompt: '' },
            { label: '📖 Best Practices', title: 'Best Practices & Performance', prompt: `What are the best practices, security considerations, and performance optimizations for ${topic || subject || 'this topic'}?` }
          ] : isScience ? [
            { label: '📐 2D Vector Schematic', title: '2D Vector Teaching Schematic: Render clean interactive SVG coordinate/wave/ray schematic', prompt: `Please provide a clean, high-contrast 2D Vector Teaching Schematic (using standard SVG markup) illustrating ${topic || subject || 'this topic'}. Include clear orthogonal axes, vector orientations, ray geometry, and formula annotations.` },
            { label: '🔬 Mechanism', title: 'Mechanism: Detailed scientific process breakdown', prompt: `Explain the detailed scientific mechanism and step-by-step process for ${topic || subject || 'this topic'}.` },
            { label: '📌 Summarize', title: 'Summarize Key Takeaways', prompt: `Summarize the key scientific takeaways and principles of ${topic || subject || 'this topic'}.` },
            { label: '💡 Explain', title: 'Explain Concepts & Laws', prompt: `Explain the core scientific laws and concepts behind ${topic || subject || 'this topic'}.` },
            { label: '❓ Create Quiz', title: 'Science Quiz: Test comprehension', prompt: `Generate a 5-question science quiz on ${topic || subject || 'this topic'}.` },
            { label: '📝 Practice Exam', title: 'Practice Exam: Launch interactive quiz generator for active chapter', prompt: '' },
            { label: '📖 Study Guide', title: 'Comprehensive Study Notes', prompt: `Create a detailed study guide for ${topic || subject || 'this topic'}.` }
          ] : [
            { label: '📌 Summarize', title: 'Summarize: Provide a high-level summary and key takeaways of the current topic', prompt: `Please summarize our current discussion and key takeaways for ${topic || subject || 'this topic'}.` },
            { label: '💡 Explain', title: 'Explain: Provide an in-depth step-by-step breakdown and examples for the current topic', prompt: `Please explain ${topic || subject || 'this topic'} in depth with clear step-by-step breakdown and examples.` },
            { label: '❓ Create Quiz', title: 'Create Quiz: Generate a 5-question multiple choice practice quiz for the current topic', prompt: `Generate a 5-question multiple choice practice quiz for ${topic || subject || 'this topic'}.` },
            { label: '📝 Practice Exam', title: 'Practice Exam: Launch interactive quiz generator for active chapter', prompt: '' },
            { label: '📐 Key Formulas', title: 'Key Formulas: List and explain core formulas, principles, and equations', prompt: `List and explain all key formulas, principles, and core equations for ${topic || subject || 'this topic'}.` },
            { label: '📖 Study Guide', title: 'Study Guide: Create a comprehensive study guide and revision notes', prompt: `Create a comprehensive study guide and revision notes for ${topic || subject || 'this topic'}.` }
          ];

          const allActions = [...actions, ...customActions];

          return (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 mb-1.5 scrollbar-none text-xs">
              {allActions.map(action => {
                const isLoading = loadingQuickAction === action.label;
                return (
                  <button
                    key={action.label}
                    type="button"
                    title={action.title}
                    aria-label={action.title}
                    disabled={isLoading}
                    onClick={() => {
                      if (action.label === '📝 Practice Exam') {
                        onOpenTool?.('quiz', { subject, topic: topic || subject });
                        showNotification?.(`Launched Practice Exam for ${topic || subject || 'active chapter'}`, 'success');
                      } else if (action.label === '🧮 Algebraic Properties') {
                        onOpenTool?.('algebraic_properties');
                      } else if (action.label === '🔢 Matrix Calculator') {
                        onOpenTool?.('matrix_calculator');
                      } else if (action.label === '🔬 Diagram Vision AI') {
                        onOpenTool?.('diagram_analyzer');
                        showNotification?.('Opened Diagram Vision AI', 'info');
                      } else if (action.label === '🏷️ Diagram Legend Key') {
                        const latestDiagramMsg = [...localMessages].reverse().find(m => m.metadata?.image);
                        if (latestDiagramMsg) {
                          setFullscreenDiagramMsgId(latestDiagramMsg.id);
                          showNotification?.('Opened Diagram Legend Key & Hotspot Inspector', 'info');
                        } else {
                          showNotification?.('Ask Diagram Tutor to generate a diagram first!', 'warning');
                        }
                      } else if (action.label === '🧠 Diagram Element Quiz') {
                        const latestDiagramMsg = [...localMessages].reverse().find(m => m.metadata?.image && m.metadata?.annotations?.length > 0);
                        if (latestDiagramMsg) {
                          handleStartDiagramQuiz(latestDiagramMsg.id, latestDiagramMsg.metadata.annotations || []);
                          showNotification?.('Started Diagram Element Recall Quiz!', 'success');
                        } else {
                          showNotification?.('No diagram with hotspot annotations found. Ask Diagram Tutor to generate a diagram first!', 'warning');
                        }
                      } else if (action.label === '📸 Diagram Gallery') {
                        setShowGalleryModal(true);
                      } else if (action.label === '🎬 Summarize to Video') {
                        if (messages.length < 2) {
                          showNotification?.('Start a conversation before generating a video summary!', 'warning');
                        } else {
                          onGenerateVideo?.([]);
                        }
                      } else if (onSendMessage && !loadingQuickAction && action.prompt) {
                        setLoadingQuickAction(action.label);
                        onSendMessage(action.prompt);
                        showNotification?.(`Triggered "${action.label}" for ${topic || subject || 'current topic'}`, 'success');
                        setTimeout(() => {
                          setLoadingQuickAction(null);
                        }, 1600);
                      }
                    }}
                    className={cn(
                      "px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer border flex items-center gap-1 shadow-sm shrink-0",
                      isLoading && "opacity-80 animate-pulse",
                      theme === 'dark'
                        ? "bg-slate-800/90 border-slate-700 text-indigo-300 hover:bg-indigo-600 hover:text-white hover:border-indigo-500"
                        : "bg-white border-slate-200 text-indigo-700 hover:bg-indigo-600 hover:text-white hover:border-indigo-600"
                    )}
                  >
                    {isLoading && <Loader2 size={12} className="animate-spin text-current inline-block" />}
                    {action.label}
                  </button>
                );
              })}

              <button
                type="button"
                onClick={() => setIsCustomActionModalOpen(true)}
                title="Create a custom AI prompt action pill"
                aria-label="Create Custom Action"
                className={cn(
                  "px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer border flex items-center gap-1 shadow-sm shrink-0 border-dashed",
                  theme === 'dark'
                    ? "bg-slate-900 border-slate-700 text-cyan-300 hover:bg-cyan-950 hover:border-cyan-500"
                    : "bg-slate-100 border-slate-300 text-cyan-700 hover:bg-cyan-50 hover:border-cyan-600"
                )}
              >
                <span>+ Custom Action</span>
              </button>
            </div>
          );
        })()}

        <PredictiveAutocomplete
          suggestions={autocompleteSuggestions}
          inputValue={input}
          selectedIndex={selectedAutocompleteIndex}
          onSelectSuggestion={handleSelectAutocomplete}
          theme={theme}
          isVisible={isTextareaFocused && autocompleteSuggestions.length > 0 && !isAutocompleteDismissed && !isShared}
          subject={subject}
          topic={topic}
        />
        <AnimatePresence>
          {((isTextareaFocused || input.trim().length > 0) && !isShared) && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.98 }}
              className={cn(
                "absolute bottom-full left-4 right-4 mb-2 p-2 rounded-2xl shadow-xl border backdrop-blur-md z-40 flex items-center gap-1.5 overflow-x-auto",
                theme === 'dark' ? "bg-slate-900/90 border-slate-700/80 text-white" : "bg-white/90 border-slate-200 text-slate-800"
              )}
            >
              <span className="text-[10px] font-black uppercase tracking-wider text-indigo-500 px-2 shrink-0">LaTeX:</span>
              {[
                { label: 'Fraction', snippet: '\\frac{numerator}{denominator}', display: '\\frac{a}{b}' },
                { label: 'Integral', snippet: '\\int_{a}^{b} f(x) dx', display: '\\int' },
                { label: 'Square Root', snippet: '\\sqrt{x}', display: '\\sqrt{x}' },
                { label: 'Summation', snippet: '\\sum_{i=1}^{n}', display: '\\sum' },
                { label: 'Infinity', snippet: '\\infty', display: '\\infty' },
                { label: 'Partial', snippet: '\\partial', display: '\\partial' },
                { label: 'Alpha', snippet: '\\alpha', display: '\\alpha' },
                { label: 'Beta', snippet: '\\beta', display: '\\beta' },
                { label: 'Theta', snippet: '\\theta', display: '\\theta' },
                { label: 'Matrix', snippet: '\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}', display: '矩阵' }
              ].map(item => (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => insertLatex(item.snippet)}
                  className={cn(
                    "px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all shrink-0 cursor-pointer border",
                    theme === 'dark'
                      ? "bg-slate-800 border-slate-700 hover:bg-indigo-600 hover:text-white text-slate-200"
                      : "bg-slate-100 border-slate-200 hover:bg-indigo-600 hover:text-white text-slate-700"
                  )}
                  title={`Insert ${item.label}`}
                >
                  {item.display}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
        <AnimatePresence>
          {detectedUnit && (
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className={cn(
                "absolute bottom-full left-4 right-4 mb-3 p-4 rounded-2xl shadow-2xl border backdrop-blur-xl z-50 flex flex-col md:flex-row md:items-center justify-between gap-3",
                theme === 'dark' 
                  ? "bg-slate-900/95 border-slate-850 text-white shadow-indigo-950/40" 
                  : "bg-white/95 border-slate-200 text-slate-800 shadow-slate-200/55"
              )}
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 shrink-0">
                  <Sparkles size={18} className="animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-widest text-indigo-500">Correct Pronunciation?</span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-black bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {detectedUnit.symbol}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 mt-1">
                    {detectedUnit.name}
                  </h4>
                  <p className="text-[11px] text-slate-550 dark:text-slate-400 mt-1 leading-relaxed">
                    Say <span className="font-bold text-slate-700 dark:text-slate-200">"{detectedUnit.spokenEnglish}"</span> (or <span className="font-bold text-indigo-600 dark:text-indigo-400">"{detectedUnit.spokenHindi}"</span> in Hindi) when speaking!
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                <button
                  type="button"
                  onClick={() => handlePlayPronunciation(detectedUnit.spokenEnglish)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider bg-indigo-600 text-white hover:bg-indigo-500 shadow-lg shadow-indigo-600/15 cursor-pointer transition-all"
                >
                  <Volume2 size={13} />
                  <span>Listen</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDismissedUnits(prev => {
                      const next = new Set(prev);
                      next.add(detectedUnit.symbol);
                      return next;
                    });
                  }}
                  className={cn(
                    "px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer",
                    theme === 'dark' 
                      ? "text-slate-400 hover:text-white hover:bg-slate-800" 
                      : "text-slate-500 hover:text-slate-800 hover:bg-slate-100"
                  )}
                >
                  Dismiss
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Persistent Microphone Status Indicator & Error Banner above text input */}
        <div className="mb-2 space-y-2">
          {/* Persistent Small Status Indicator Icon */}
          <div className="flex items-center justify-between px-2">
            {/* Mic Ready button - Hidden per user request */}
            {false && (
              <button
                onClick={() => setShowMicModal(true)}
                className={cn(
                  "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider border shadow-sm transition-all cursor-pointer",
                  (isRecording || isRecordingAi)
                    ? "bg-rose-500/15 border-rose-500/40 text-rose-400 shadow-rose-500/10 animate-pulse"
                    : (isDictating || isInlineDictating)
                      ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-400 shadow-emerald-500/10 animate-pulse"
                      : micError
                        ? "bg-amber-500/15 border-amber-500/40 text-amber-400 hover:bg-amber-500/25"
                        : (theme === 'dark'
                            ? "bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-indigo-300 hover:border-indigo-500/40"
                            : "bg-slate-100 border-slate-200 text-slate-600 hover:text-indigo-600 hover:border-indigo-300")
                )}
                title="Click to check microphone permissions & settings"
              >
                <span className="relative flex h-2 w-2">
                  <span className={cn(
                    "animate-ping absolute inline-flex h-full w-full rounded-full opacity-75",
                    (isRecording || isRecordingAi) ? "bg-rose-400" : (isDictating || isInlineDictating) ? "bg-emerald-400" : micError ? "bg-amber-400" : "hidden"
                  )} />
                  <span className={cn(
                    "relative inline-flex rounded-full h-2 w-2",
                    (isRecording || isRecordingAi) ? "bg-rose-500" : (isDictating || isInlineDictating) ? "bg-emerald-500" : micError ? "bg-amber-500" : "bg-slate-400"
                  )} />
                </span>
                <Mic size={12} />
                <span>
                  {(isRecording || isRecordingAi)
                    ? "Recording Voice"
                    : (isDictating || isInlineDictating)
                      ? "Listening / Dictating"
                      : micError
                        ? "Mic Error (Fix)"
                        : "Mic Ready"}
                </span>
              </button>
            )}
            {/* Mic Settings & Info button - Hidden per user request */}
            {false && (
              <button
                onClick={() => setShowMicModal(true)}
                className="text-[10px] font-bold text-slate-400 hover:text-indigo-400 transition-colors cursor-pointer ml-auto"
              >
                Mic Settings & Info
              </button>
            )}
          </div>

          {/* Error-Handling Banner when Microphone Access Fails */}
          <AnimatePresence>
            {micError && (
              <motion.div
                initial={{ opacity: 0, y: 8, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.98 }}
                className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-red-500/15 border border-amber-500/40 text-slate-200 shadow-xl backdrop-blur-md flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0">
                    <AlertTriangle size={16} className="animate-pulse" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-extrabold text-amber-300 text-[10px] uppercase tracking-wider flex items-center gap-1.5">
                      Microphone Access Alert
                    </div>
                    <div className="text-[11px] text-slate-300 truncate font-medium">
                      {micError}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={async () => {
                      setMicError(null);
                      try {
                        if (navigator.mediaDevices?.getUserMedia) {
                          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                          stream.getTracks().forEach(t => t.stop());
                          showNotification?.("Microphone test successful!", "success");
                        }
                      } catch (err: any) {
                        setMicError("Microphone permission denied. Click the lock/mic icon in your address bar to grant access.");
                      }
                    }}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider transition-all cursor-pointer shadow-md"
                  >
                    Retry
                  </button>
                  <button
                    onClick={() => setShowMicModal(true)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[10px] border border-slate-700 transition-all cursor-pointer"
                  >
                    Check Settings
                  </button>
                  <button
                    onClick={() => setMicError(null)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer"
                    title="Dismiss"
                  >
                    <X size={14} />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className={cn(
          "relative flex items-end gap-1.5 border rounded-[2rem] p-1.5 sm:p-2 shadow-2xl transition-all duration-500",
          isRecording && "ring-2 ring-rose-500 border-rose-500/80 shadow-rose-500/25 shadow-2xl",
          theme === 'dark' 
            ? "bg-slate-800/80 border-slate-700/50 focus-within:border-indigo-500/50 focus-within:bg-slate-800 backdrop-blur-xl" 
            : "bg-white/80 border-slate-200/50 focus-within:border-indigo-400/50 focus-within:bg-white backdrop-blur-xl",
          isShared && "opacity-65 select-none"
        )}>
          {/* Visual Pulse Animation Overlay when Microphone is Actively Listening */}
          <AnimatePresence>
            {isRecording && (
              <>
                {/* Background Ambient Pulse Glow */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.12, 0.35, 0.12] }}
                  exit={{ opacity: 0 }}
                  transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}
                  className="absolute inset-0 bg-gradient-to-r from-rose-600/25 via-red-500/20 to-amber-500/20 pointer-events-none rounded-[2rem]"
                />

                {/* Animated Pulsing Top & Bottom Edge Glow Lines */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.3, 0.9, 0.3] }}
                  exit={{ opacity: 0 }}
                  transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
                  className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-rose-500 to-transparent pointer-events-none"
                />
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.3, 0.9, 0.3] }}
                  exit={{ opacity: 0 }}
                  transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
                  className="absolute bottom-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-rose-500 to-transparent pointer-events-none"
                />

                {/* Top Badge: Actively Listening audio status indicator with visual equalizer frequency bars and recording progress */}
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="absolute top-1 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1 px-3 py-1.5 rounded-full bg-slate-950/95 border border-rose-500/60 shadow-lg shadow-rose-500/25 backdrop-blur-md pointer-events-none select-none min-w-[180px]"
                >
                  <div className="flex items-center gap-2">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                    </span>
                    <span className="text-[9px] font-black uppercase tracking-widest text-rose-300">
                      {isMicMuted ? "Microphone Muted" : "Listening..."}
                    </span>
                    
                    {/* Visual Voice Speaking Duration Timer */}
                    <span className="font-mono text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-0.5 ml-1 animate-pulse">
                      <span>🎤</span>
                      <span>{formatRecordingTime(recordingDuration)}</span>
                    </span>

                    {!isMicMuted && (
                      <div className="flex items-center gap-0.5 h-2.5 ml-1">
                        {[0.5, 0.9, 0.4, 1.0, 0.6, 0.8, 0.3].map((h, idx) => (
                          <motion.span
                            key={idx}
                            animate={{
                              scaleY: [
                                0.3 + (micVolume || h) * 0.7,
                                1.0,
                                0.2 + (micVolume || h) * 0.5
                              ]
                            }}
                            transition={{
                              repeat: Infinity,
                              duration: 0.35 + idx * 0.08,
                              ease: "easeInOut"
                            }}
                            className="w-0.5 h-full bg-rose-400 rounded-full origin-bottom"
                          />
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Progressive visual track bar representing elapsed speaking time (up to 60s recommended segment before wrapping) */}
                  <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden mt-0.5 relative">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, (recordingDuration % 60) * (100 / 60))}%` }}
                      transition={{ duration: 0.5, ease: "linear" }}
                      className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-rose-500 to-amber-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]"
                    />
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
          <div className="flex items-center gap-0.5 sm:gap-1 pl-1 pb-1 shrink-0">
            {/* Dictation Button - Hidden per user request */}
            {false && (
              <button
                type="button"
                onClick={handleToggleDictationMode}
                className={cn(
                  "flex items-center justify-center p-1.5 sm:p-2 rounded-xl border transition-all cursor-pointer shrink-0",
                  isDictating || isInlineDictating
                    ? "bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-500/30 animate-pulse"
                    : (theme === 'dark' 
                        ? "bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border-amber-500/30" 
                        : "bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-300")
                )}
                title="Dictation - Double click in chat to write between lines (Voice & Content Insertion)"
              >
                <Mic size={16} className={isDictating || isInlineDictating ? "animate-bounce text-white" : ""} />
              </button>
            )}

            {/* Summarize to Video Button - Hidden per user request */}
            {false && (
              <button
                type="button"
                onClick={() => {
                  if (isShared) return;
                  if (!onGenerateVideo) {
                    showNotification?.("Video generation is not available.", "warning");
                    return;
                  }
                  if (messages.length < 2) {
                    showNotification?.("Start a conversation before generating a video summary!", "warning");
                    return;
                  }
                  onGenerateVideo?.([]);
                }}
                disabled={isShared || isGeneratingVideo}
                className={cn(
                  "flex items-center justify-center p-1.5 sm:p-2 rounded-xl border transition-all cursor-pointer shrink-0",
                  isGeneratingVideo
                    ? "bg-rose-500/20 text-rose-400 border-rose-500/40 animate-pulse"
                    : (theme === 'dark' 
                        ? "bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border-rose-500/30" 
                        : "bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200"),
                  isShared && "opacity-40 cursor-not-allowed"
                )}
                title="Summarize to Video - Create an AI educational video summarizing this chat"
                aria-label="Summarize to Video"
              >
                {isGeneratingVideo ? (
                  <Loader2 size={16} className="animate-spin text-rose-500" />
                ) : (
                  <Film size={16} className="text-rose-500" />
                )}
              </button>
            )}

            {/* Screen Recording Button - Hidden per user request */}
            {false && (
              <button
                type="button"
                onClick={() => {
                  if (isShared) return;
                  if (screenRecordingState === 'recording') {
                    stopScreenRecording();
                  } else if (screenRecordingState === 'paused') {
                    resumeScreenRecording();
                  } else {
                    startScreenRecording();
                  }
                }}
                disabled={isShared}
                className={cn(
                  "flex items-center justify-center p-1.5 sm:p-2 rounded-xl border transition-all cursor-pointer shrink-0 relative",
                  screenRecordingState === 'recording'
                    ? "bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-500/30 animate-pulse"
                    : screenRecordingState === 'paused'
                      ? "bg-amber-500 text-white border-amber-400 shadow-md shadow-amber-500/20"
                      : (theme === 'dark' 
                          ? "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/30" 
                          : "bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200"),
                  isShared && "opacity-40 cursor-not-allowed"
                )}
                title={
                  screenRecordingState === 'recording'
                    ? `Recording active (${Math.floor(screenRecordingDuration / 60)}:${String(screenRecordingDuration % 60).padStart(2, '0')}). Click to stop and preview.`
                    : screenRecordingState === 'paused'
                      ? "Recording paused. Click to resume."
                      : "Enable Screen Recording - Capture screen session with MediaRecorder API"
                }
                aria-label="Screen Recording"
              >
                {screenRecordingState === 'recording' ? (
                  <div className="relative flex items-center justify-center">
                    <Monitor size={16} className="text-white" />
                    <span className="absolute -top-1 -right-1 flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                    </span>
                  </div>
                ) : screenRecordingState === 'paused' ? (
                  <Play size={16} className="text-white" />
                ) : (
                  <Monitor size={16} className="text-emerald-500" />
                )}
              </button>
            )}

            <div className="relative">
              <button 
                className={cn(
                  "p-2 rounded-xl border transition-all duration-300 cursor-pointer flex items-center justify-center",
                  showMagicMenu 
                    ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-500/25" 
                    : (theme === 'dark' ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white" : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"),
                  isShared && "opacity-30 cursor-not-allowed"
                )}
                onClick={() => !isShared && setShowMagicMenu(!showMagicMenu)}
                title={isShared ? "Disabled on shared links" : "Open Tool-Kit Menu (Scratchpad, whiteboard, screen recording & utilities)"}
                aria-label="Open Tool-Kit Menu"
                disabled={isShared}
              >
                <Wrench size={18} className={cn(showMagicMenu ? "text-white" : "text-indigo-400")} />
              </button>

              <AnimatePresence>
                {showMagicMenu && !isShared && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className={cn(
                      "absolute bottom-full left-0 mb-3 p-2 rounded-2xl shadow-2xl border w-64 max-h-[70vh] sm:max-h-[420px] overflow-y-auto overscroll-contain z-50 flex flex-col gap-1",
                      theme === 'dark' ? "bg-slate-900 border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-900"
                    )}
                  >
                    {!magicType ? (
                      <>
                        {/* Media Config / AI Content Generation - Hidden per user request */}
                        {false && (
                          <>
                            <div className="px-2 py-1 text-[10px] font-black text-slate-400 uppercase tracking-widest">AI Content Generation</div>
                            <button 
                              onClick={() => setMagicType('image')}
                              className={cn(
                                "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 transition-colors",
                                theme === 'dark' ? "hover:bg-slate-800 text-indigo-400" : "hover:bg-slate-50 text-indigo-600"
                              )}
                            >
                              <ImageIcon size={14} />
                              Generate Image
                            </button>
                            {/* Generate Video - Hidden per user request */}
                            {false && (
                            <button 
                              onClick={() => setMagicType('video')}
                              className={cn(
                                "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 transition-colors",
                                theme === 'dark' ? "hover:bg-slate-800 text-violet-400" : "hover:bg-slate-50 text-violet-600"
                              )}
                            >
                              <Video size={14} />
                              Generate Video
                            </button>
                            )}

                            <div className="h-px w-full bg-slate-300 dark:bg-slate-800 my-1 shrink-0" />
                          </>
                        )}
                        <div className="px-2 py-1 text-[10px] font-black text-slate-400 uppercase tracking-widest">Tools & Utilities</div>

                        {/* State Scratchpad */}
                        <button
                          onClick={() => {
                            const next = !isScratchpadOpen;
                            setIsScratchpadOpen(next);
                            setShowMagicMenu(false);
                            showNotification?.(next ? 'State Scratchpad docked on right side.' : 'State Scratchpad closed.', 'info');
                          }}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            isScratchpadOpen 
                              ? "bg-amber-500/10 text-amber-500" 
                              : theme === 'dark' ? "hover:bg-slate-800 text-slate-300" : "hover:bg-slate-100 text-slate-700"
                          )}
                        >
                          <span>✍️</span>
                          {isScratchpadOpen ? 'Scratchpad: Open' : 'State Scratchpad'}
                        </button>

                        {/* Chat History & Saved Firestore Sessions */}
                        <button
                          onClick={() => {
                            onOpenTool?.('chat_history');
                            setShowMagicMenu(false);
                            showNotification?.('Chat History & Saved Sessions opened.', 'info');
                          }}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            theme === 'dark' ? "hover:bg-slate-800 text-indigo-400" : "hover:bg-slate-100 text-indigo-600"
                          )}
                        >
                          <Database size={14} />
                          Chat History & Sessions
                        </button>

                        {/* Record Screen - Hidden per user request */}
                        {false && (
                        <button
                          onClick={() => {
                            onOpenTool?.('screenrecord');
                            setShowMagicMenu(false);
                            showNotification?.('Screen Recording Studio opened.', 'info');
                          }}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            theme === 'dark' ? "hover:bg-slate-800 text-rose-400" : "hover:bg-slate-100 text-rose-500"
                          )}
                        >
                          <Video size={14} />
                          Record Screen
                        </button>
                        )}

                        {/* Venn Builder */}
                        <button
                          onClick={() => {
                            setIsVennBuilderOpen(true);
                            setShowMagicMenu(false);
                            showNotification?.('Interactive Venn Diagram Builder & Formula Solver opened!', 'info');
                          }}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            theme === 'dark' ? "hover:bg-slate-800 text-emerald-400" : "hover:bg-slate-100 text-emerald-500"
                          )}
                        >
                          <span>🎨</span>
                          Venn Builder
                        </button>

                        {/* Digital Math Whiteboard */}
                        <button
                          onClick={() => {
                            setIsWhiteboardOpen(true);
                            setShowMagicMenu(false);
                            showNotification?.('Digital Math Whiteboard opened!', 'info');
                          }}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            theme === 'dark' ? "hover:bg-slate-800 text-indigo-400" : "hover:bg-slate-100 text-indigo-500"
                          )}
                        >
                          <Edit3 size={14} />
                          Math Whiteboard
                        </button>

                        <div className="h-px w-full bg-slate-300 dark:bg-slate-800 my-1 shrink-0" />

                        {/* Viewport controls */}
                        <div className="px-3 py-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className={cn("text-[10px] uppercase font-bold", theme === 'dark' ? "text-slate-500" : "text-slate-400")}>Width: {contentWidth || 100}%</span>
                            <div className="flex items-center gap-1">
                              <button onClick={() => setContentWidth?.(prev => Math.max(70, prev - 5))} className={cn("p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700")}><ChevronLeft size={12} /></button>
                              <button onClick={() => setContentWidth?.(prev => Math.min(100, prev + 5))} className={cn("p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700")}><ChevronRight size={12} /></button>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className={cn("text-[10px] uppercase font-bold", theme === 'dark' ? "text-slate-500" : "text-slate-400")}>Zoom: {Math.round((zoomLevel || 1) * 100)}%</span>
                            <div className="flex items-center gap-1">
                              <button onClick={() => setZoomLevel?.(prev => Math.max(0.7, prev - 0.05))} className={cn("p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700")}><Minus size={12} /></button>
                              <button onClick={() => setZoomLevel?.(prev => Math.min(1.3, prev + 0.05))} className={cn("p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700")}><Plus size={12} /></button>
                            </div>
                          </div>
                        </div>

                        <div className="h-px w-full bg-slate-300 dark:bg-slate-800 my-1 shrink-0" />

                        {/* Clear */}
                        <button
                          onClick={() => {
                            onClearChat();
                            setShowMagicMenu(false);
                          }}
                          disabled={messages.length === 0}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            messages.length === 0
                              ? "opacity-40 cursor-not-allowed"
                              : theme === 'dark' ? "hover:bg-red-900/20 text-red-400" : "hover:bg-red-50 text-red-500"
                          )}
                        >
                          <RotateCcw size={14} />
                          Clear Chat
                        </button>

                        {/* Recap - Hidden per user request */}
                        {false && (
                        <button
                          onClick={() => {
                            onGenerateRecap?.();
                            setShowMagicMenu(false);
                          }}
                          disabled={!onGenerateRecap || messages.length === 0}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            messages.length === 0
                              ? "opacity-40 cursor-not-allowed"
                              : theme === 'dark' ? "hover:bg-slate-800 text-indigo-300" : "hover:bg-slate-100 text-indigo-700"
                          )}
                        >
                          <BookOpen size={14} />
                          Recap
                        </button>
                        )}

                        {/* Summarize to Video - Hidden per user request */}
                        {false && (
                        <button
                          onClick={() => {
                            onGenerateVideo?.([]);
                            setShowMagicMenu(false);
                          }}
                          disabled={!onGenerateVideo || messages.length === 0}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            messages.length === 0
                              ? "opacity-40 cursor-not-allowed"
                              : theme === 'dark' ? "hover:bg-slate-800 text-rose-300" : "hover:bg-slate-100 text-rose-700"
                          )}
                        >
                          <Film size={14} />
                          Summarize to Video
                        </button>
                        )}

                        {/* Export Chat */}
                        <button
                          onClick={() => {
                            handleDownloadFullChat();
                            setShowMagicMenu(false);
                          }}
                          disabled={messages.length === 0}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            messages.length === 0
                              ? "opacity-40 cursor-not-allowed"
                              : theme === 'dark' ? "hover:bg-slate-800 text-emerald-300" : "hover:bg-slate-100 text-emerald-700"
                          )}
                        >
                          <Download size={14} />
                          Export Chat
                        </button>

                        {/* Share Chat */}
                        <button
                          onClick={() => {
                            handleShareFullChat();
                            setShowMagicMenu(false);
                          }}
                          disabled={messages.length === 0}
                          className={cn(
                            "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2.5 cursor-pointer transition-colors",
                            messages.length === 0
                              ? "opacity-40 cursor-not-allowed"
                              : theme === 'dark' ? "hover:bg-slate-800 text-blue-400" : "hover:bg-slate-100 text-blue-600"
                          )}
                        >
                          <Share2 size={14} />
                          Share Chat
                        </button>
                      </>
                    ) : (
                      <div className="space-y-4 p-1">
                        <div className="flex items-center justify-between">
                          <button onClick={() => setMagicType(null)} className="text-xs font-bold text-indigo-500 cursor-pointer">← Back</button>
                          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Media Config</div>
                        </div>
                        
                        <div className="space-y-2">
                          <label className="text-[10px] font-bold text-slate-500 uppercase">Aspect Ratio</label>
                          <div className="grid grid-cols-3 gap-1">
                            {['1:1', '16:9', '9:16', '4:3', '3:2', '21:9'].map(ratio => (
                              <button 
                                key={ratio}
                                onClick={() => setAspectRatio(ratio)}
                                className={cn(
                                  "py-1 px-2 rounded text-[10px] font-bold border transition-all cursor-pointer",
                                  aspectRatio === ratio
                                    ? "bg-indigo-500 border-indigo-500 text-white"
                                    : (theme === "dark" ? "border-slate-800 text-slate-400 hover:border-slate-700" : "border-slate-200 text-slate-600 hover:border-indigo-200")
                                )}
                              >
                                {ratio}
                              </button>
                            ))}
                          </div>
                        </div>

                        <button 
                          className="w-full py-2 bg-indigo-600 text-white rounded-xl font-black text-xs shadow-lg shadow-indigo-500/20 cursor-pointer"
                          onClick={() => {
                            if (input.trim()) {
                              onGenerateMedia(magicType, input.trim(), { aspectRatio });
                              setInput('');
                              setMagicType(null);
                              setShowMagicMenu(false);
                            } else {
                              showNotification?.('Please enter a prompt in the message box first.', 'warning');
                            }
                          }}
                        >
                          GENERATE {magicType.toUpperCase()}
                        </button>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Digital Math Whiteboard Button - Hidden per user request */}
            {false && (
              <button 
                className={cn(
                  "p-1.5 sm:p-2 rounded-xl transition-all duration-300",
                  theme === 'dark' ? "text-slate-400 hover:text-indigo-400 hover:bg-slate-700" : "text-slate-500 hover:text-indigo-600 hover:bg-slate-50",
                  isShared && "opacity-30 cursor-not-allowed"
                )}
                onClick={() => {
                  if (isShared) return;
                  setIsWhiteboardOpen(true);
                  showNotification?.('Digital Math Whiteboard opened!', 'info');
                }}
                title={isShared ? "Disabled on shared links" : "Digital Math Whiteboard"}
                disabled={isShared}
              >
                <Edit3 size={18} />
              </button>
            )}

            <button 
              className={cn(
                "p-1.5 sm:p-2 rounded-xl transition-all duration-300",
                theme === 'dark' ? "text-slate-400 hover:text-indigo-400 hover:bg-slate-700" : "text-slate-500 hover:text-indigo-600 hover:bg-slate-50",
                isShared && "opacity-30 cursor-not-allowed"
              )}
              onClick={() => !isShared && cameraInputRef.current?.click()}
              title={isShared ? "Disabled on shared links" : "Capture image with Camera"}
              disabled={isShared}
            >
              <Camera size={18} />
            </button>

            <button 
              className={cn(
                "p-1.5 sm:p-2 rounded-xl transition-all duration-300",
                theme === 'dark' ? "text-slate-400 hover:text-indigo-400 hover:bg-slate-700" : "text-slate-500 hover:text-indigo-600 hover:bg-slate-50",
                isShared && "opacity-30 cursor-not-allowed"
              )}
              onClick={() => !isShared && fileInputRef.current?.click()}
              title={isShared ? "Disabled on shared links" : "Upload file (Image/Video/Audio)"}
              disabled={isShared}
            >
              <Plus size={18} />
            </button>
          </div>

          <input 
            type="file" 
            ref={cameraInputRef} 
            accept="image/*" 
            capture="environment" 
            className="hidden" 
            onChange={(e) => e.target.files?.[0] && onFileUpload(e.target.files[0])} 
          />

          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={(e) => e.target.files?.[0] && onFileUpload(e.target.files[0])} 
          />
          
          <textarea
            className={cn(
              "flex-1 bg-transparent border-none outline-none p-2.5 sm:p-3 text-sm resize-none max-h-[200px] min-h-[44px] leading-relaxed w-full font-medium",
              theme === 'dark' ? "text-white placeholder:text-slate-500" : "text-slate-900 placeholder:text-slate-400",
              isShared && "cursor-not-allowed opacity-50"
            )}
            placeholder={isShared ? "Chat is disabled on shared links." : (isPaused && isInterrupted) ? "Listening to your interruption..." : isRecording ? "Listening..." : "Type your message..."}
            value={input}
            onChange={(e) => {
              if (!isShared) {
                setInput(e.target.value);
                setIsAutocompleteDismissed(false);
                setSelectedAutocompleteIndex(0);
              }
            }}
            onKeyDown={handleKeyDown}
            onFocus={() => setIsTextareaFocused(true)}
            onBlur={() => setIsTextareaFocused(false)}
            rows={1}
            disabled={isShared}
          />

            {/* Chat Features & Control Button - Hidden per user request */}
            {false && (
            <div className="relative">
              <button 
                className={cn(
                  "p-2 rounded-xl transition-all duration-300 border shadow-sm cursor-pointer flex items-center justify-center shrink-0",
                  showFeaturesMenu 
                    ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20" 
                    : (theme === 'dark' 
                        ? "text-slate-300 bg-slate-900 border-slate-800 hover:text-indigo-400 hover:bg-slate-800 hover:border-slate-700" 
                        : "text-slate-700 bg-slate-50 border-slate-200 hover:text-indigo-600 hover:bg-white hover:border-slate-300"),
                  isShared && "opacity-30 cursor-not-allowed"
                )}
                onClick={() => !isShared && setShowFeaturesMenu(!showFeaturesMenu)}
                title={isShared ? "Disabled on shared links" : "Chat Features & Controls"}
                disabled={isShared}
              >
                <Sliders size={18} />
              </button>
              
              <AnimatePresence>
                {showFeaturesMenu && !isShared && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowFeaturesMenu(false)} />
                    <motion.div 
                      initial={{ opacity: 0, y: 15, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 15, scale: 0.95 }}
                      className={cn(
                        "absolute bottom-full right-0 mb-4 p-3 rounded-2xl shadow-2xl border w-[290px] z-50 space-y-3 text-left max-h-[70vh] sm:max-h-[500px] overflow-y-auto pr-1.5 overscroll-contain",
                        theme === 'dark' ? "bg-slate-950 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                      )}
                    >
                      <div className="px-1 pb-1.5 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-800/40 flex items-center justify-between">
                        <span>Chat Features Menu</span>
                        <span className="text-[9px] lowercase font-normal opacity-60">Lecture & AI Tools</span>
                      </div>
                      
                      {/* Section 0: Lecture & Cache Tools */}
                      <div className="space-y-1 pb-1 border-b border-slate-800/40">
                        <span className="text-[10px] uppercase tracking-wider font-extrabold text-amber-400 flex items-center gap-1.5 px-1 py-0.5">
                          <Zap size={12} className="text-amber-400" /> Lecture & Cache Tools
                        </span>

                        <button 
                          onClick={() => { openCrashDoubtModal(); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30"
                          )}
                          title="Raise Crash Doubt during active lecture"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-sm select-none">⚡❓</span>
                            <span>Crash Doubt</span>
                          </div>
                          <span className="text-[10px] opacity-70 font-mono">Cont</span>
                        </button>

                        <button 
                          onClick={() => { handleToggleDictationMode(); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/30"
                          )}
                          title="Dictation - Double click in chat to write between lines"
                        >
                          <div className="flex items-center gap-2">
                            <Mic size={14} />
                            <span>Dictation</span>
                          </div>
                          <span className="text-[10px] opacity-70 font-mono">Insert</span>
                        </button>

                        <button 
                          onClick={() => {
                            handlePauseVideoForLectureQuestion(
                              "What is the principle of conservation of energy?",
                              ["energy", "created", "destroyed", "transform", "conserved", "constant"],
                              "Energy cannot be created or destroyed, only transformed from one form to another."
                            );
                            setShowFeaturesMenu(false);
                          }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30"
                          )}
                          title="Pause video and ask a lecture question"
                        >
                          <div className="flex items-center gap-2">
                            <HelpCircle size={14} className="text-amber-400" />
                            <span>❓ Lecture Question</span>
                          </div>
                          <span className="text-[10px] opacity-70 font-mono">Verbal Quiz</span>
                        </button>

                        <button 
                          onClick={() => { setIsCacheStatsModalOpen(true); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                          )}
                          title="View IndexedDB Local Offline Cache details"
                        >
                          <div className="flex items-center gap-2">
                            <HardDrive size={14} className="text-cyan-400" />
                            <span>💾 IndexedDB Offline Cache</span>
                          </div>
                          <span className="text-[10px] opacity-70 font-mono">{cacheStats.cachedVideos} vids</span>
                        </button>

                        <button 
                          onClick={() => { handleToggleProfessorStyle(); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer border",
                            lectureProfessorStyle === 'strict'
                              ? "bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border-indigo-500/30"
                              : "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                          )}
                          title="Toggle between Strict Professor and Interactive Mentor mode"
                        >
                          <div className="flex items-center gap-2">
                            <GraduationCap size={14} />
                            <span>{lectureProfessorStyle === 'strict' ? '🎓 Strict Professor' : '🤝 Interactive Mentor'}</span>
                          </div>
                          <span className="text-[10px] opacity-70 font-mono">Style</span>
                        </button>

                        <button 
                          onClick={() => { saveLectureBookmark("Manual Bookmark"); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-violet-500/10 hover:bg-violet-500/20 text-violet-400 border border-violet-500/30"
                          )}
                          title="Bookmark current timestamp"
                        >
                          <div className="flex items-center gap-2">
                            <Bookmark size={14} className="fill-current text-violet-400" />
                            <span>🔖 Bookmark Lecture Time</span>
                          </div>
                          <span className="text-[10px] opacity-70 font-mono">Save Spot</span>
                        </button>

                        {activeLectureBookmark && (
                          <button 
                            onClick={() => { if (activeLectureBookmark) restoreLectureBookmark(activeLectureBookmark); setShowFeaturesMenu(false); }}
                            className={cn(
                              "w-full p-2 rounded-lg flex items-center justify-between text-xs font-bold transition-all cursor-pointer bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse"
                            )}
                            title={`Seek to bookmark at ${activeLectureBookmark?.timeLabel || ''}`}
                          >
                            <div className="flex items-center gap-2">
                              <Bookmark size={14} className="fill-current text-emerald-400" />
                              <span>⏩ Seek {activeLectureBookmark?.timeLabel || ''}</span>
                            </div>
                            <span className="text-[10px] opacity-70 font-mono">Jump</span>
                          </button>
                        )}
                      </div>
                      
                      {/* Section 1: Standard Chat Actions */}
                      <div className="space-y-1">
                        <button 
                          onClick={() => { onOpenTool?.('chat_history'); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center gap-2.5 text-xs font-semibold transition-all cursor-pointer",
                            theme === 'dark' ? "hover:bg-slate-800/60 text-indigo-300" : "hover:bg-slate-100 text-indigo-700"
                          )}
                        >
                          <Database size={14} className="text-indigo-500" />
                          <span>0. Chat History & Sessions</span>
                        </button>

                        <button 
                          onClick={() => { handleShareFullChat(); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center gap-2.5 text-xs font-semibold transition-all cursor-pointer",
                            theme === 'dark' ? "hover:bg-slate-800/60 text-slate-300" : "hover:bg-slate-100 text-slate-700"
                          )}
                        >
                          <Share2 size={14} className="text-blue-500" />
                          <span>1. Share Chat Link</span>
                        </button>

                        <button 
                          onClick={() => { onClearChat(); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center gap-2.5 text-xs font-semibold transition-all cursor-pointer",
                            theme === 'dark' ? "hover:bg-slate-800/60 text-slate-300" : "hover:bg-slate-100 text-slate-700"
                          )}
                        >
                          <Trash2 size={14} className="text-red-500" />
                          <span>2. Clear Conversation</span>
                        </button>

                        <button 
                          onClick={() => { handleCopyFullChat(); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center gap-2.5 text-xs font-semibold transition-all cursor-pointer",
                            theme === 'dark' ? "hover:bg-slate-800/60 text-slate-300" : "hover:bg-slate-100 text-slate-700"
                          )}
                        >
                          <Copy size={14} className="text-emerald-500" />
                          <span>3. Copy Full Chat Log</span>
                        </button>

                        <button 
                          onClick={() => { handlePrintLastMsg(); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center gap-2.5 text-xs font-semibold transition-all cursor-pointer",
                            theme === 'dark' ? "hover:bg-slate-800/60 text-slate-300" : "hover:bg-slate-100 text-slate-700"
                          )}
                        >
                          <Printer size={14} className="text-amber-500" />
                          <span>4. Print Last Lecture Slide</span>
                        </button>

                        <button 
                          onClick={() => { setIsWhiteboardOpen(true); setShowFeaturesMenu(false); }}
                          className={cn(
                            "w-full p-2 rounded-lg flex items-center gap-2.5 text-xs font-bold transition-all cursor-pointer bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30"
                          )}
                        >
                          <Edit3 size={14} className="text-indigo-400" />
                          <span>5. Digital Math Whiteboard</span>
                        </button>
                      </div>

                      {/* Section 2: Interactive Controls */}
                      <div className="space-y-2 border-t border-slate-800/40 pt-2.5">
                        {/* 6. Speed Adjust */}
                        <div className="flex items-center justify-between p-1.5 rounded-lg bg-transparent border border-slate-800/60">
                          <span className="text-[11px] font-medium text-slate-300 flex items-center gap-1.5">
                            <Gauge size={13} className="text-indigo-400" /> 6. Speech Rate
                          </span>
                          <div className="flex gap-1">
                            {[0.75, 1.0, 1.5, 2.0].map((rate) => (
                              <button
                                key={rate}
                                onClick={() => {
                                  setTtsRate?.(rate);
                                  showNotification?.(`Speech rate updated to ${rate}x`, 'success');
                                }}
                                className={cn(
                                  "px-1.5 py-0.5 rounded text-[9px] font-bold border transition-all cursor-pointer bg-transparent",
                                  ttsRate === rate 
                                    ? "border-indigo-500 text-indigo-400 font-extrabold shadow-sm shadow-indigo-500/10" 
                                    : "border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
                                )}
                              >
                                {rate}x
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* 7. Lecture Mode Action Toggles */}
                        <div className="flex flex-col gap-1.5 p-2 rounded-lg border border-slate-800/60 bg-transparent">
                          <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 flex items-center gap-1.5">
                            <Sliders size={12} className="text-amber-400" /> 7. Action Toggles
                          </span>
                          <div className="grid grid-cols-2 gap-1">
                            {[
                              { mode: 'standard', label: 'Standard Chat', act: () => { saveLectureBookmark("Mode Switch to Standard Chat"); setIsLectureMode(false); localStorage.setItem('omni_lecture_mode', 'false'); } },
                              { mode: 'classroom', label: 'Classroom Slate', act: () => { saveLectureBookmark("Mode Switch to Classroom Slate"); setIsLectureMode(true); setLectureSubMode('classroom'); localStorage.setItem('omni_lecture_mode', 'true'); localStorage.setItem('omni_lecture_sub_mode', 'classroom'); } },
                              { mode: 'quiz', label: 'Auto-Quiz', act: () => { saveLectureBookmark("Mode Switch to Auto-Quiz"); setIsLectureMode(true); setLectureSubMode('quiz'); localStorage.setItem('omni_lecture_mode', 'true'); localStorage.setItem('omni_lecture_sub_mode', 'quiz'); } },
                              { mode: 'lecture', label: 'Lecture Mode', act: () => { saveLectureBookmark("Mode Switch to Lecture Mode"); setIsLectureMode(true); setLectureSubMode('lecture'); localStorage.setItem('omni_lecture_mode', 'true'); localStorage.setItem('omni_lecture_sub_mode', 'lecture'); } }
                            ].map((item) => {
                              const isActive = item.mode === 'standard' ? !isLectureMode : (isLectureMode && lectureSubMode === item.mode);
                              return (
                                <button
                                  key={item.mode}
                                  onClick={() => {
                                    item.act();
                                    showNotification?.(`${item.label} mode enabled`, 'info');
                                  }}
                                  className={cn(
                                    "py-1 px-1.5 rounded text-[9px] font-bold text-center truncate border transition-all cursor-pointer bg-transparent",
                                    isActive 
                                      ? "border-indigo-500 text-indigo-400 font-extrabold shadow-sm shadow-indigo-500/10" 
                                      : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                  )}
                                >
                                  {item.label}
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* 8. Intelligent Audio Engine */}
                        <div className="flex flex-col gap-1.5 p-2 rounded-lg border border-slate-800/60 bg-transparent">
                          <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 flex items-center gap-1.5">
                            <Brain size={12} className="text-emerald-400" /> 8. Dual Engine Audio
                          </span>
                          <div className="grid grid-cols-4 gap-1">
                            {[
                              { mode: 'tts', label: 'Gemini' },
                              { mode: 'google', label: 'Google' },
                              { mode: 'webspeech', label: 'Native' },
                              { mode: 'auto', label: 'Auto' }
                            ].map((item) => (
                              <button
                                key={item.mode}
                                onClick={() => {
                                  setTtsEngineMode(item.mode as any);
                                  localStorage.setItem('omni_tts_engine_mode', item.mode);
                                  showNotification?.(`${item.label} audio engine selected`, 'success');
                                }}
                                className={cn(
                                  "py-1 px-0.5 rounded text-[8px] font-black text-center truncate border transition-all cursor-pointer bg-transparent",
                                  ttsEngineMode === item.mode 
                                    ? "border-indigo-500 text-indigo-400 font-extrabold shadow-sm shadow-indigo-500/10" 
                                    : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                )}
                              >
                                {item.label}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* 9. Vocal Persona */}
                        <div className="flex items-center justify-between p-1.5 rounded-lg bg-transparent border border-slate-800/60">
                          <span className="text-[11px] font-medium text-slate-300 flex items-center gap-1.5">
                            <Sliders size={13} className="text-purple-400" /> 9. Vocal Persona
                          </span>
                          <button
                            onClick={() => {
                              const currentIndex = PERSONAS.findIndex(p => p.id === selectedPersonaId);
                              const nextIndex = (currentIndex + 1) % PERSONAS.length;
                              const nextPersona = PERSONAS[nextIndex];
                              onSelectPersonaId?.(nextPersona.id);
                              showNotification?.(`Vocal identity switched to: ${nextPersona.name}`, 'success');
                            }}
                            className="px-2 py-1 text-[9px] font-bold border border-indigo-500/30 text-indigo-400 hover:text-indigo-300 hover:border-indigo-500 bg-transparent rounded transition-all flex items-center gap-1 shrink-0 cursor-pointer"
                          >
                            <span>{PERSONAS.find(p => p.id === selectedPersonaId)?.icon || '👨‍🏫'}</span>
                            <span>{PERSONAS.find(p => p.id === selectedPersonaId)?.name.split(' ')[0] || 'Teacher'}</span>
                          </button>
                        </div>

                        {/* 10. Volume */}
                        <div className="flex items-center justify-between p-1.5 rounded-lg bg-transparent border border-slate-800/60">
                          <span className="text-[11px] font-medium text-slate-300 flex items-center gap-1.5">
                            <Volume2 size={13} className="text-cyan-400" /> 10. Volume ({Math.round(ttsVolume * 100)}%)
                          </span>
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.1"
                            value={ttsVolume}
                            onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                            className="w-20 accent-indigo-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                          />
                        </div>

                        {/* 11. Smart Voice Interruption */}
                        <div className="flex items-center justify-between p-1.5 rounded-lg bg-transparent border border-slate-800/60">
                          <span className="text-[11px] font-medium text-slate-300 flex items-center gap-1.5">
                            <Zap size={13} className="text-rose-400" /> 11. Interruption (VAD)
                          </span>
                          <button
                            onClick={() => {
                              const next = !isVadEnabled;
                              setIsVadEnabled(next);
                              showNotification?.(next ? "Smart Voice Interruption (VAD) Enabled" : "Smart Voice Interruption (VAD) Disabled", "info");
                            }}
                            className={cn(
                              "px-2 py-0.5 rounded text-[9px] font-bold border transition-all cursor-pointer bg-transparent",
                              isVadEnabled 
                                ? "border-emerald-500 text-emerald-400 font-extrabold shadow-sm shadow-emerald-500/10" 
                                : "border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
                            )}
                          >
                            {isVadEnabled ? "ON" : "OFF"}
                          </button>
                        </div>

                        {/* 12. Classroom Scroll Control */}
                        <div className="flex flex-col gap-2.5 p-2 rounded-lg border border-slate-800/60 bg-transparent">
                          <div className="flex items-center justify-between border-b border-slate-800/40 pb-1.5">
                            <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 flex items-center gap-1.5">
                              <GraduationCap size={13} className="text-cyan-400" /> 12. Classroom Controls
                            </span>
                          </div>

                          {/* Synergy Harmony Presets */}
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] text-slate-300 font-bold">Omni-Sync Harmony Mode:</span>
                              <span className={cn(
                                "text-[7px] px-1 py-0.5 rounded font-black uppercase tracking-wider",
                                synergyMode === 'academic' ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                                synergyMode === 'classroom' ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20" :
                                synergyMode === 'review' ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" :
                                "bg-slate-500/10 text-slate-400 border border-slate-500/20"
                              )}>
                                {synergyMode}
                              </span>
                            </div>
                            <div className="grid grid-cols-4 gap-1">
                              {[
                                { val: 'academic', label: 'Academic' },
                                { val: 'classroom', label: 'Classroom' },
                                { val: 'review', label: 'Review' },
                                { val: 'custom', label: 'Custom' }
                              ].map((sm) => (
                                <button
                                  key={sm.val}
                                  onClick={() => {
                                    if (sm.val === 'custom') {
                                      setCustomMode();
                                      showNotification?.("Custom manual mode unlocked!", "info");
                                    } else {
                                      applySynergyPreset(sm.val as any);
                                      showNotification?.(`Synchronized Pace Harmony preset: ${sm.label}`, 'success');
                                    }
                                  }}
                                  className={cn(
                                    "py-1 px-0.5 rounded text-[8px] font-bold text-center border transition-all cursor-pointer bg-transparent truncate",
                                    synergyMode === sm.val
                                      ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                      : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                  )}
                                >
                                  {sm.label}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Voice-Tracking Auto-Tempo */}
                          <div className="flex items-center justify-between pt-1 border-t border-slate-800/20">
                            <div className="flex flex-col">
                              <span className="text-[9px] text-slate-300 font-bold flex items-center gap-1">
                                <Zap size={10} className="text-amber-400" /> Voice-Tracking Tempo:
                              </span>
                              <span className="text-[8px] text-slate-500">Auto-align typing delay to voice speed</span>
                            </div>
                            <button
                              onClick={() => {
                                const next = !isVoiceTrackingEnabled;
                                setIsVoiceTrackingEnabled(next);
                                localStorage.setItem('omni_classroom_voice_tracking', String(next));
                                showNotification?.(next ? "Voice-tracking tempo active!" : "Voice-tracking tempo deactivated", "info");
                                if (synergyMode !== 'custom') setCustomMode();
                              }}
                              className={cn(
                                "py-0.5 px-2 rounded text-[8px] font-black border transition-all cursor-pointer bg-transparent",
                                isVoiceTrackingEnabled 
                                  ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                  : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                              )}
                            >
                              {isVoiceTrackingEnabled ? 'SYNC ON' : 'OFF'}
                            </button>
                          </div>
                          
                          {/* Duration Select */}
                          <div className="space-y-1 pt-1.5 border-t border-slate-800/20">
                            <span className="text-[9px] text-slate-400 block font-bold">Auto-Scroll Duration:</span>
                            <div className="grid grid-cols-5 gap-1">
                              {[0, 200, 450, 800, 1500].map((d) => (
                                <button
                                  key={d}
                                  onClick={() => {
                                    setScrollDuration(d);
                                    localStorage.setItem('omni_classroom_scroll_duration', String(d));
                                    showNotification?.(`Auto-scroll duration set to ${d}ms`, 'success');
                                    setCustomMode();
                                  }}
                                  className={cn(
                                    "py-1 px-0.5 rounded text-[8px] font-bold text-center border transition-all cursor-pointer bg-transparent",
                                    scrollDuration === d 
                                      ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                      : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                  )}
                                >
                                  {d === 0 ? '0ms' : `${d}ms`}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Easing Select */}
                          <div className="space-y-1">
                            <span className="text-[9px] text-slate-400 block font-bold">Auto-Scroll Curve Smoothness:</span>
                            <div className="grid grid-cols-3 gap-1">
                              {[
                                { val: 'instant', label: 'Instant' },
                                { val: 'smooth', label: 'Default' },
                                { val: 'ease-out', label: 'Ease Out' },
                                { val: 'ease-in-out', label: 'Ease InOut' },
                                { val: 'spring', label: 'Springy' }
                              ].map((e) => (
                                <button
                                  key={e.val}
                                  onClick={() => {
                                    setScrollEasing(e.val as any);
                                    localStorage.setItem('omni_classroom_scroll_easing', e.val);
                                    showNotification?.(`Auto-scroll easing curve set to ${e.label}`, 'success');
                                    setCustomMode();
                                  }}
                                  className={cn(
                                    "py-1 px-0.5 rounded text-[8px] font-bold text-center border transition-all cursor-pointer bg-transparent truncate",
                                    scrollEasing === e.val 
                                      ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                      : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                  )}
                                >
                                  {e.label}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Trigger Line Threshold */}
                          <div className="space-y-1 pt-1 border-t border-slate-800/20">
                            <span className="text-[9px] text-slate-400 block font-bold">Scroll Trigger Threshold (Screen Height):</span>
                            <div className="grid grid-cols-3 gap-1">
                              {[
                                { val: 0.5, label: '50% (Center)' },
                                { val: 0.66, label: '66% (Lower 1/3)' },
                                { val: 0.75, label: '75% (Lower 1/4)' }
                              ].map((t) => (
                                <button
                                  key={t.val}
                                  onClick={() => {
                                    setScrollThreshold(t.val);
                                    localStorage.setItem('omni_classroom_scroll_threshold', String(t.val));
                                    showNotification?.(`Scroll trigger threshold set to ${t.label}`, 'success');
                                    setCustomMode();
                                  }}
                                  className={cn(
                                    "py-1 px-0.5 rounded text-[8px] font-bold text-center border transition-all cursor-pointer bg-transparent truncate",
                                    Math.abs(scrollThreshold - t.val) < 0.05 
                                      ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                      : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                  )}
                                >
                                  {t.label}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Focus Target Center */}
                          <div className="space-y-1 pt-1">
                            <span className="text-[9px] text-slate-400 block font-bold">Scroll Focus Alignment Position:</span>
                            <div className="grid grid-cols-3 gap-1">
                              {[
                                { val: 0.25, label: '25% (High Focus)' },
                                { val: 0.45, label: '45% (Balanced)' },
                                { val: 0.60, label: '60% (Context)' }
                              ].map((tc) => (
                                <button
                                  key={tc.val}
                                  onClick={() => {
                                    setScrollTargetCenter(tc.val);
                                    localStorage.setItem('omni_classroom_scroll_target_center', String(tc.val));
                                    showNotification?.(`Scroll focus position set to ${tc.label}`, 'success');
                                    setCustomMode();
                                  }}
                                  className={cn(
                                    "py-1 px-0.5 rounded text-[8px] font-bold text-center border transition-all cursor-pointer bg-transparent truncate",
                                    Math.abs(scrollTargetCenter - tc.val) < 0.05 
                                      ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                      : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                  )}
                                >
                                  {tc.label}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Toggle Options: Spotlight / Adaptive Speed / Breathing Pauses */}
                          <div className="space-y-2.5 pt-2 border-t border-slate-800/20">
                            {/* Spotlight */}
                            <div className="flex items-center justify-between">
                              <div className="flex flex-col">
                                <span className="text-[9px] text-slate-300 font-bold">Sentence-Spotlight Dimming:</span>
                                <span className="text-[8px] text-slate-500">Dim passive sentences for laser focus</span>
                              </div>
                              <button
                                onClick={() => {
                                  const next = !isSpotlightEnabled;
                                  setIsSpotlightEnabled(next);
                                  localStorage.setItem('omni_classroom_spotlight', String(next));
                                  showNotification?.(next ? "Spotlight mode active!" : "Spotlight mode deactivated", "info");
                                  setCustomMode();
                                }}
                                className={cn(
                                  "py-0.5 px-2 rounded text-[8px] font-black border transition-all cursor-pointer bg-transparent",
                                  isSpotlightEnabled 
                                    ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                    : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                )}
                              >
                                {isSpotlightEnabled ? 'ACTIVE' : 'OFF'}
                              </button>
                            </div>

                            {/* Adaptive Word Complexity Speed */}
                            <div className="flex items-center justify-between">
                              <div className="flex flex-col">
                                <span className="text-[9px] text-slate-300 font-bold">Adaptive Complex-Word Pacing:</span>
                                <span className="text-[8px] text-slate-500">Auto-slows typing on technical terms</span>
                              </div>
                              <button
                                onClick={() => {
                                  const next = !isAdaptiveSpeedEnabled;
                                  setIsAdaptiveSpeedEnabled(next);
                                  localStorage.setItem('omni_classroom_adaptive_speed', String(next));
                                  showNotification?.(next ? "Adaptive pacing enabled!" : "Adaptive pacing deactivated", "info");
                                  setCustomMode();
                                }}
                                className={cn(
                                  "py-0.5 px-2 rounded text-[8px] font-black border transition-all cursor-pointer bg-transparent",
                                  isAdaptiveSpeedEnabled 
                                    ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                    : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                )}
                              >
                                {isAdaptiveSpeedEnabled ? 'ADAPTIVE' : 'OFF'}
                              </button>
                            </div>

                            {/* Punctuation Breathing Pauses */}
                            <div className="flex items-center justify-between">
                              <div className="flex flex-col">
                                <span className="text-[9px] text-slate-300 font-bold">Natural Breathing Pauses:</span>
                                <span className="text-[8px] text-slate-500">Micro-delays at periods & commas</span>
                              </div>
                              <button
                                onClick={() => {
                                  const next = !isBreathingPausesEnabled;
                                  setIsBreathingPausesEnabled(next);
                                  localStorage.setItem('omni_classroom_breathing_pauses', String(next));
                                  showNotification?.(next ? "Punctuation breathing enabled!" : "Punctuation breathing deactivated", "info");
                                  setCustomMode();
                                }}
                                className={cn(
                                  "py-0.5 px-2 rounded text-[8px] font-black border transition-all cursor-pointer bg-transparent",
                                  isBreathingPausesEnabled 
                                    ? "border-cyan-500 text-cyan-400 font-extrabold shadow-sm shadow-cyan-500/10" 
                                    : "border-slate-800/40 text-slate-400 hover:border-slate-700 hover:text-white"
                                )}
                              >
                                {isBreathingPausesEnabled ? 'BREATHING' : 'OFF'}
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* 13. Microphone & Voice Input Settings */}
                        <div className="flex flex-col gap-2 p-2 rounded-lg border border-slate-800/60 bg-transparent">
                          <div className="flex items-center justify-between border-b border-slate-800/40 pb-1.5">
                            <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 flex items-center gap-1.5">
                              <Sliders size={13} className="text-rose-400" /> 13. Mic & Voice Input
                            </span>
                          </div>

                          {/* Input Microphone Selector */}
                          <div className="space-y-1">
                            <span className="text-[9px] text-slate-300 font-bold block">Input Microphone Device:</span>
                            <select
                              value={selectedAudioDeviceId}
                              onChange={(e) => {
                                setSelectedAudioDeviceId(e.target.value);
                                showNotification?.('Microphone input device updated', 'info');
                              }}
                              className="w-full bg-slate-900 text-slate-200 text-[10px] font-medium rounded-md p-1.5 border border-slate-800 outline-none focus:border-rose-500 cursor-pointer"
                            >
                              {audioDevices.length > 0 ? (
                                audioDevices.map((device, i) => (
                                  <option key={device.deviceId || i} value={device.deviceId}>
                                    {device.label || `Microphone ${i + 1}`}
                                  </option>
                                ))
                              ) : (
                                <option value="">Default System Microphone</option>
                              )}
                            </select>
                          </div>

                          {/* Sensitivity Threshold */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-[9px] text-slate-300">
                              <span className="font-bold">Mic Sensitivity Threshold:</span>
                              <span className="font-mono font-bold text-rose-400">{micSensitivity}%</span>
                            </div>
                            <input
                              type="range"
                              min="5"
                              max="95"
                              value={micSensitivity}
                              onChange={(e) => setMicSensitivity(Number(e.target.value))}
                              className="w-full accent-rose-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                            />
                          </div>

                          {/* Live Mic Level */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-[9px] text-slate-400 font-medium">
                              <span>Live Mic Level:</span>
                              <span className={cn(
                                "font-mono font-bold",
                                isMicMuted ? "text-rose-400" : (micVolume * 100) >= micSensitivity ? "text-emerald-400" : "text-slate-400"
                              )}>
                                {isMicMuted ? "MUTED 🔇" : (micVolume * 100) >= micSensitivity ? "Speech Active 🟢" : "Below Threshold ⚪"}
                              </span>
                            </div>
                            <div className="relative h-2.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800 p-0.5">
                              <div
                                className={cn(
                                  "h-full rounded-full transition-all duration-75",
                                  isMicMuted ? "bg-rose-900/50" : (micVolume * 100) >= micSensitivity ? "bg-gradient-to-r from-emerald-500 to-rose-500" : "bg-slate-700"
                                )}
                                style={{ width: `${Math.min(100, Math.max(0, micVolume * 100))}%` }}
                              />
                              <div
                                className="absolute top-0 bottom-0 w-0.5 bg-yellow-400 z-10 shadow-sm"
                                style={{ left: `${micSensitivity}%` }}
                                title={`Threshold: ${micSensitivity}%`}
                              />
                            </div>
                          </div>

                          {/* Silence Detection */}
                          <div className="space-y-1.5 pt-1.5 border-t border-slate-800/40">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] text-slate-300 font-bold">Silence Auto-Stop:</span>
                              <button
                                onClick={() => {
                                  const nextState = !isSilenceDetectionEnabled;
                                  setIsSilenceDetectionEnabled(nextState);
                                  showNotification?.(nextState ? 'Silence detection enabled' : 'Silence detection disabled', 'info');
                                }}
                                className={cn(
                                  "px-2 py-0.5 rounded text-[8px] font-black border transition-all cursor-pointer bg-transparent",
                                  isSilenceDetectionEnabled 
                                    ? "border-emerald-500 text-emerald-400 font-extrabold shadow-sm shadow-emerald-500/10" 
                                    : "border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white"
                                )}
                              >
                                {isSilenceDetectionEnabled ? 'ACTIVE' : 'OFF'}
                              </button>
                            </div>
                            {isSilenceDetectionEnabled && (
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-[8px] text-slate-400">Stop recording after:</span>
                                <select
                                  value={silenceDuration}
                                  onChange={(e) => setSilenceDuration(Number(e.target.value))}
                                  className="bg-slate-900 text-rose-300 text-[9px] font-mono rounded px-2 py-0.5 border border-slate-800 outline-none cursor-pointer"
                                >
                                  <option value={3}>3 seconds</option>
                                  <option value={4}>4 seconds</option>
                                  <option value={5}>5 seconds</option>
                                  <option value={8}>8 seconds</option>
                                </select>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
            )}

            <div className="relative flex items-center gap-1.5">
              {/* Dynamic Ripple Effect Rings driven by Audio Frequency/Volume */}
              {isRecording && !isMicMuted && (
                <>
                  <span
                    className="absolute rounded-2xl bg-rose-500/40 transition-all duration-75 pointer-events-none"
                    style={{
                      inset: `-${4 + micVolume * 14}px`,
                      opacity: 0.35 + micVolume * 0.55,
                      transform: `scale(${1 + micVolume * 0.25})`,
                      boxShadow: `0 0 ${12 + micVolume * 24}px rgba(244, 63, 94, ${0.4 + micVolume * 0.5})`
                    }}
                  />
                  <span
                    className="absolute rounded-2xl bg-rose-500/20 transition-all duration-100 pointer-events-none"
                    style={{
                      inset: `-${8 + micVolume * 22}px`,
                      opacity: 0.2 + micVolume * 0.4,
                      transform: `scale(${1 + micVolume * 0.45})`
                    }}
                  />
                  <span
                    className="absolute rounded-3xl bg-rose-500/10 blur-md pointer-events-none"
                    style={{
                      inset: `-${12 + micVolume * 30}px`,
                      opacity: 0.15 + micVolume * 0.35
                    }}
                  />
                </>
              )}

              {/* Microphone Action Button */}
              <button
                className={cn(
                  "relative z-10 p-2 rounded-xl transition-all duration-300 flex items-center gap-2 cursor-pointer select-none",
                  isRecording
                    ? isMicMuted 
                      ? "bg-slate-800 text-rose-400 shadow-lg border border-rose-500/40 ring-2 ring-rose-500/30"
                      : "bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-xl shadow-rose-500/30 ring-2 ring-rose-300/60"
                    : theme === 'dark' ? "text-slate-400 hover:text-indigo-400 hover:bg-slate-700" : "text-slate-500 hover:text-indigo-600 hover:bg-slate-50",
                  isShared && "opacity-30 cursor-not-allowed"
                )}
                onMouseDown={handleMicPressStart}
                onMouseUp={handleMicPressEnd}
                onMouseLeave={handleMicPressEnd}
                onTouchStart={handleMicPressStart}
                onTouchEnd={handleMicPressEnd}
                onClick={handleMicClick}
                title={
                  isShared
                    ? "Disabled on shared links"
                    : `Voice input (${voiceMode === 'pushtotalk' ? 'Push-to-Talk' : 'Continuous Listening'}) • Hold 0.5s to switch mode`
                }
                disabled={isShared}
              >
                <Mic
                  size={20}
                  className={cn(
                    "transition-transform duration-150",
                    isRecording && !isMicMuted && "scale-110",
                    micVolume > 0.3 && !isMicMuted && "animate-bounce"
                  )}
                />

                {isRecording && (
                  <div className="flex items-center gap-2">
                    <span className="flex items-center gap-1.5 text-xs font-semibold px-2 py-0.5 rounded-lg bg-white/20 backdrop-blur-sm text-white select-none">
                      <span className="relative flex h-2 w-2">
                        <span className={cn("animate-ping absolute inline-flex h-full w-full rounded-full opacity-75", isMicMuted ? "bg-rose-400" : "bg-white")}></span>
                        <span className={cn("relative inline-flex rounded-full h-2 w-2", isMicMuted ? "bg-rose-400" : "bg-white")}></span>
                      </span>
                      <span>{isMicMuted ? "Muted" : "Listening..."}</span>
                    </span>

                    {/* Duration Counter */}
                    <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-lg bg-black/40 text-rose-200 border border-white/10 flex items-center gap-1">
                      {formatRecordingTime(recordingDuration)}
                    </span>
                  </div>
                )}
              </button>




            </div>
            {isRecording && <WaveformVisualizer isAnimating={isRecording} analyser={null} className="ml-2" />}

            {/* Discard and Retry Button */}
            {justFinishedVoice && input.trim() && !isRecording && (
              <button
                onClick={() => {
                  setInput('');
                  setJustFinishedVoice(false);
                  if (!isRecording) onToggleVoice();
                  showNotification?.('Previous voice input discarded. Restarting voice recording...', 'info');
                }}
                className="p-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 transition-all flex items-center justify-center shadow-sm cursor-pointer select-none animate-in fade-in slide-in-from-right-2"
                title="Discard transcript and retry voice recording"
              >
                <RotateCcw size={14} />
              </button>
            )}

            <button 
              className={cn(
                "p-2.5 rounded-2xl transition-all duration-500 flex items-center justify-center",
                input.trim() && !isShared
                  ? "bg-gradient-to-br from-indigo-600 to-violet-700 text-white shadow-lg shadow-indigo-500/30 hover:scale-105 active:scale-95 cursor-pointer" 
                  : "text-slate-300 bg-slate-100 dark:bg-slate-700/50 cursor-not-allowed"
              )}
              onClick={handleSend}
              disabled={isShared || !input.trim()}
              title={isShared ? "Chat is disabled on shared links" : "Send message"}
            >
              <Send size={18} className={cn(input.trim() && !isShared && "translate-x-0.5 -translate-y-0.5")} />
            </button>

            {/* Delete Question Chat Button at Bottom - Hidden per user request */}
            {false && (
            <button
              type="button"
              onClick={() => {
                triggerHapticFeedback(10);
                if (confirm("Are you sure you want to delete and clear all messages in this question chat?")) {
                  onClearChat();
                  showNotification?.("Question chat deleted successfully", "info");
                }
              }}
              disabled={isShared}
              className={cn(
                "p-2.5 rounded-2xl transition-all duration-300 flex items-center justify-center border shadow-sm shrink-0 cursor-pointer active:scale-95",
                theme === 'dark' 
                  ? "bg-rose-500/10 text-rose-400 border-rose-500/30 hover:bg-rose-500/20 hover:text-rose-300 hover:border-rose-500/50" 
                  : "bg-rose-50 text-rose-600 border-rose-200 hover:bg-rose-100 hover:border-rose-300",
                isShared && "opacity-30 cursor-not-allowed"
              )}
              title={isShared ? "Disabled on shared links" : "Delete Question Chat History"}
            >
              <Trash2 size={18} className="shrink-0" />
            </button>
            )}
          </div>
        </div>
        <p className="text-[10px] text-center text-slate-500 mt-1.5 font-medium uppercase tracking-widest opacity-50">
          Omni AI can make mistakes. Check important info.
        </p>
      </div>

    {/* Dockable State Scratchpad */}
    {isScratchpadOpen && (
        <div className="w-full md:w-[380px] lg:w-[440px] shrink-0 h-full z-40 border-l border-slate-200 dark:border-slate-800 absolute right-0 top-0 md:relative md:translate-x-0 shadow-2xl md:shadow-none animate-in slide-in-from-right duration-300">
          <StateScratchpad
            theme={theme}
            subject={subject}
            topic={topic}
            onClose={() => setIsScratchpadOpen(false)}
            onSendToChat={(text, img) => {
              onSendMessage(text, img);
            }}
            onSaveToNotes={onSaveToNotes}
            showNotification={showNotification}
          />
        </div>
      )}

      {/* spq Suggested Practice Questions Modal */}
      <PracticeQuestionStudioModal
        isOpen={showPracticeQuestionModal}
        onClose={() => setShowPracticeQuestionModal(false)}
        topicTitle={topic || 'general'}
        subjectTitle={subject}
        subject={subject}
        initialMode="academic"
        theme={theme}
        showNotification={showNotification}
      />

      {/* Context-Aware Academic Explanation Modal */}
      {activeAnnoModal && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className={cn(
            "w-full rounded-3xl p-6 border shadow-2xl space-y-5 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto transition-all duration-200",
            popupFontSize > 18 ? "max-w-2xl" : "max-w-lg",
            theme === 'dark' ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-900"
          )}>
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/50 flex-wrap gap-2">
              <div className="flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-indigo-600 text-white font-black text-sm flex items-center justify-center shadow-md flex-shrink-0">
                  {activeAnnoModal.index + 1}
                </span>
                <div>
                  <h3 
                    className="font-black tracking-tight text-indigo-400 leading-tight"
                    style={{ fontSize: `${Math.max(16, popupFontSize + 4)}px` }}
                  >
                    {activeAnnoModal.anno.label}
                  </h3>
                  <p className="text-xs text-slate-400">Interactive Hotspot Academic Analysis</p>
                </div>
              </div>

              {/* Expandable Font Size Toolbar */}
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-xl p-1 text-xs gap-1 shadow-inner">
                  <span className="text-[10px] uppercase font-mono font-bold text-slate-400 px-1">Font</span>
                  <button
                    onClick={() => setPopupFontSize(prev => Math.max(12, prev - 2))}
                    disabled={popupFontSize <= 12}
                    className="px-2 py-1 rounded-lg hover:bg-slate-700 disabled:opacity-30 text-slate-200 font-extrabold transition cursor-pointer"
                    title="Decrease Pop-up Font Size (A-)"
                  >
                    A-
                  </button>
                  <span className="px-1.5 font-mono text-[11px] text-amber-400 font-bold min-w-[36px] text-center bg-slate-950/60 rounded py-0.5">
                    {popupFontSize}px
                  </span>
                  <button
                    onClick={() => setPopupFontSize(prev => Math.min(28, prev + 2))}
                    disabled={popupFontSize >= 28}
                    className="px-2 py-1 rounded-lg hover:bg-slate-700 disabled:opacity-30 text-slate-200 font-extrabold transition cursor-pointer"
                    title="Expand Pop-up Font Size (A+)"
                  >
                    A+
                  </button>
                  {popupFontSize !== 14 && (
                    <button
                      onClick={() => setPopupFontSize(14)}
                      className="px-1.5 py-1 rounded-lg hover:bg-slate-700 text-[10px] text-slate-400 font-bold hover:text-white transition cursor-pointer"
                      title="Reset Font Size"
                    >
                      Reset
                    </button>
                  )}
                </div>

                <button
                  onClick={() => setActiveAnnoModal(null)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                  title="Close Pop-up"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="space-y-4 leading-relaxed">
              <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-200 space-y-1">
                <div className="text-[10px] font-black uppercase tracking-wider text-indigo-400">Core Description</div>
                <p className="font-medium" style={{ fontSize: `${popupFontSize}px`, lineHeight: '1.5' }}>
                  {activeAnnoModal.anno.description}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                <div className="text-[10px] font-black uppercase tracking-wider text-amber-400">In-Depth Academic Explanation</div>
                <p className="text-slate-300 leading-relaxed" style={{ fontSize: `${popupFontSize}px`, lineHeight: '1.6' }}>
                  In mathematical analysis and set theory, this hotspot represents <strong className="text-white" style={{ fontSize: `${popupFontSize}px` }}>{activeAnnoModal.anno.label}</strong> positioned at coordinates ({activeAnnoModal.anno.x}%, {activeAnnoModal.anno.y}%). It plays a fundamental role in defining mappings, domain-codomain relationships, and algebraic structures within the lecture context.
                </p>
              </div>

              <div className="flex items-center justify-between text-slate-400 px-1 font-mono" style={{ fontSize: `${Math.max(10, popupFontSize - 3)}px` }}>
                <span>Position: X: {activeAnnoModal.anno.x}%, Y: {activeAnnoModal.anno.y}%</span>
                <span className="text-emerald-400 font-bold">Verified Diagram Node</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-700/50">
              <button
                onClick={() => {
                  const mId = activeAnnoModal.msgId;
                  const idx = activeAnnoModal.index;
                  setActiveAnnoModal(null);
                  setRepositioningAnno({ msgId: mId, index: idx });
                  showNotification?.(`Click anywhere on the diagram to reposition Hotspot #${idx + 1}`, "info");
                }}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
              >
                Reposition Hotspot
              </button>
              <button
                onClick={() => setActiveAnnoModal(null)}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Physical QR Code Scanner Modal */}
      {isQrScannerOpen && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl p-6 border shadow-2xl space-y-6 bg-slate-900 border-slate-700 text-white animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-lg">
                  <QrCode size={22} />
                </div>
                <div>
                  <h3 className="font-black text-lg text-amber-300 tracking-tight">QR Code Educational Scanner</h3>
                  <p className="text-xs text-slate-400">Scan physical QR code via camera or load from clipboard / file</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsQrScannerOpen(false);
                  stopQrCamera();
                }}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Close Scanner"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Camera Viewfinder Box */}
              <div className="relative w-full h-64 bg-slate-950 rounded-2xl border-2 border-dashed border-slate-700 overflow-hidden flex flex-col items-center justify-center">
                {qrScanningActive ? (
                  <>
                    <video 
                      ref={qrVideoRef} 
                      className="absolute inset-0 w-full h-full object-cover" 
                      playsInline 
                      muted 
                    />
                    <div className="absolute inset-0 border-4 border-amber-500/50 rounded-2xl pointer-events-none animate-pulse flex items-center justify-center">
                      <div className="w-40 h-40 border-2 border-dashed border-amber-400 rounded-xl flex items-center justify-center">
                        <span className="text-[10px] font-mono bg-black/60 px-2 py-1 rounded text-amber-300 font-bold">Align QR Code Here</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center p-6 space-y-3">
                    <Camera size={40} className="mx-auto text-slate-600" />
                    <div>
                      <p className="text-sm font-bold text-slate-300">Camera Live Scanner Paused</p>
                      <p className="text-xs text-slate-500 mt-1">Start camera or paste content from clipboard / upload image</p>
                    </div>
                    <button
                      onClick={startQrCamera}
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-black text-xs transition shadow-lg cursor-pointer flex items-center gap-2 mx-auto"
                    >
                      <Camera size={14} />
                      <span>Start Camera Scanner</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Action Buttons: Clipboard & Quick Sample QR Simulation */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={handlePasteFromClipboard}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <Copy size={14} className="text-indigo-400" />
                  <span>Paste from Clipboard</span>
                </button>

                <label className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer shadow-sm">
                  <ImageIcon size={14} className="text-emerald-400" />
                  <span>Upload QR Image</span>
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        showNotification?.(`Uploaded QR image: ${file.name}. Processing content...`, "success");
                        setTimeout(() => {
                          handleSimulateQrScan("Advanced Calculus & Multivariable Analysis");
                        }, 800);
                      }
                    }}
                  />
                </label>
              </div>

              {/* Quick Preset Educational QR Topics */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-[10px] font-black uppercase tracking-wider text-slate-400">Quick Test QR Presets (Scan Simulator):</div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleSimulateQrScan("Schrödinger Equation & Wavefunctions")}
                    className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-left text-xs transition cursor-pointer group"
                  >
                    <div className="font-bold text-amber-300 group-hover:text-amber-200">⚛️ Quantum Wavefunction</div>
                    <div className="text-[10px] text-slate-400">Schrödinger Equation QR</div>
                  </button>
                  <button
                    onClick={() => handleSimulateQrScan("Maxwell's Equations & Electromagnetism")}
                    className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-left text-xs transition cursor-pointer group"
                  >
                    <div className="font-bold text-cyan-300 group-hover:text-cyan-200">⚡ Maxwell's Equations</div>
                    <div className="text-[10px] text-slate-400">Electromagnetism QR</div>
                  </button>
                </div>
              </div>

              {qrScanResult && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono">
                  <div className="font-bold text-[10px] text-emerald-400 mb-1">Detected Payload:</div>
                  <div className="break-all">{qrScanResult}</div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-700/60">
              <button
                onClick={() => {
                  setIsQrScannerOpen(false);
                  stopQrCamera();
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              {qrScanningActive && (
                <button
                  onClick={() => {
                    stopQrCamera();
                    handleSimulateQrScan("Multivariate Calculus & Partial Derivatives");
                  }}
                  className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-black text-xs transition shadow-lg cursor-pointer"
                >
                  Capture & Scan QR Now
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Specialized Diagram Element Quiz Modal */}
      {activeElementQuizModal && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl p-6 border shadow-2xl space-y-6 bg-slate-900 border-slate-700 text-white animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shadow-lg">
                  <Brain size={22} />
                </div>
                <div>
                  <h3 className="font-black text-lg text-indigo-300 tracking-tight">Highlighted Element Quiz</h3>
                  <p className="text-xs text-slate-400">Specialized active recall for diagram hotspot elements</p>
                </div>
              </div>
              <button
                onClick={() => setActiveElementQuizModal(null)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Close Quiz"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-sm font-semibold leading-relaxed text-slate-100">
                {activeElementQuizModal.quiz.question}
              </div>

              <div className="space-y-2.5">
                {activeElementQuizModal.quiz.options.map((opt: string, optIdx: number) => {
                  const isSelected = elementQuizSelectedOption === optIdx;
                  const isCorrect = optIdx === activeElementQuizModal.quiz.correctIndex;
                  let btnStyle = "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200";

                  if (elementQuizSubmitted) {
                    if (isCorrect) {
                      btnStyle = "bg-emerald-950 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500/50 font-bold";
                    } else if (isSelected && !isCorrect) {
                      btnStyle = "bg-rose-950 border-rose-500 text-rose-200 ring-2 ring-rose-500/50 font-bold";
                    } else {
                      btnStyle = "bg-slate-900/50 border-slate-800 text-slate-500 opacity-60";
                    }
                  } else if (isSelected) {
                    btnStyle = "bg-indigo-950 border-indigo-500 text-indigo-200 ring-2 ring-indigo-500/50 font-bold";
                  }

                  return (
                    <button
                      key={optIdx}
                      disabled={elementQuizSubmitted}
                      onClick={() => setElementQuizSelectedOption(optIdx)}
                      className={cn(
                        "w-full text-left p-3.5 rounded-xl border transition-all text-xs flex items-center justify-between cursor-pointer",
                        btnStyle
                      )}
                    >
                      <span className="flex items-center gap-2.5">
                        <span className="w-6 h-6 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-mono font-bold text-[11px] text-indigo-400">
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span>{opt}</span>
                      </span>
                      {elementQuizSubmitted && isCorrect && (
                        <span className="text-emerald-400 font-bold text-xs">✓ Correct</span>
                      )}
                      {elementQuizSubmitted && isSelected && !isCorrect && (
                        <span className="text-rose-400 font-bold text-xs">✗ Incorrect</span>
                      )}
                    </button>
                  );
                })}
              </div>

              {elementQuizSubmitted && activeElementQuizModal.quiz.explanation && (
                <div className="p-3.5 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-200 text-xs leading-relaxed">
                  <div className="font-bold text-[11px] text-indigo-400 mb-1">Explanation:</div>
                  {activeElementQuizModal.quiz.explanation}
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-700/60">
              <button
                onClick={() => setActiveElementQuizModal(null)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Close
              </button>
              {!elementQuizSubmitted ? (
                <button
                  disabled={elementQuizSelectedOption === null}
                  onClick={() => {
                    if (elementQuizSelectedOption === null) return;
                    setElementQuizSubmitted(true);
                    const isCorrect = elementQuizSelectedOption === activeElementQuizModal.quiz.correctIndex;
                    if (isCorrect) {
                      showNotification?.("🏆 Correct! Excellent mastery of highlighted diagram elements.", "success");
                    } else {
                      showNotification?.("Review the explanation above to strengthen your understanding.", "info");
                    }
                  }}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-black text-xs transition shadow-lg cursor-pointer"
                >
                  Submit Answer
                </button>
              ) : (
                <button
                  onClick={() => {
                    setActiveElementQuizModal(null);
                  }}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs transition shadow-lg cursor-pointer"
                >
                  Done
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Study Gallery Modal */}
      {isGalleryOpen && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className={cn(
            "w-full max-w-3xl rounded-3xl p-6 border shadow-2xl space-y-5 animate-in zoom-in-95 max-h-[85vh] overflow-y-auto",
            theme === 'dark' ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-900"
          )}>
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/50 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="text-2xl">📸</span>
                <div>
                  <h3 
                    className="font-black tracking-tight text-emerald-400"
                    style={{ fontSize: `${Math.max(16, popupFontSize + 3)}px` }}
                  >
                    Study Gallery & Diagram Snapshots
                  </h3>
                  <p className="text-xs text-slate-400">Review, organize, and reference your saved diagram views and hotspot annotations.</p>
                </div>
              </div>

              {/* Expandable Font Size Toolbar */}
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-xl p-1 text-xs gap-1 shadow-inner">
                  <span className="text-[10px] uppercase font-mono font-bold text-slate-400 px-1">Font</span>
                  <button
                    onClick={() => setPopupFontSize(prev => Math.max(12, prev - 2))}
                    disabled={popupFontSize <= 12}
                    className="px-2 py-1 rounded-lg hover:bg-slate-700 disabled:opacity-30 text-slate-200 font-extrabold transition cursor-pointer"
                    title="Decrease Pop-up Font Size (A-)"
                  >
                    A-
                  </button>
                  <span className="px-1.5 font-mono text-[11px] text-amber-400 font-bold min-w-[36px] text-center bg-slate-950/60 rounded py-0.5">
                    {popupFontSize}px
                  </span>
                  <button
                    onClick={() => setPopupFontSize(prev => Math.min(28, prev + 2))}
                    disabled={popupFontSize >= 28}
                    className="px-2 py-1 rounded-lg hover:bg-slate-700 disabled:opacity-30 text-slate-200 font-extrabold transition cursor-pointer"
                    title="Expand Pop-up Font Size (A+)"
                  >
                    A+
                  </button>
                  {popupFontSize !== 14 && (
                    <button
                      onClick={() => setPopupFontSize(14)}
                      className="px-1.5 py-1 rounded-lg hover:bg-slate-700 text-[10px] text-slate-400 font-bold hover:text-white transition cursor-pointer"
                      title="Reset Font Size"
                    >
                      Reset
                    </button>
                  )}
                </div>

                <button
                  onClick={() => setIsGalleryOpen(false)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                  title="Close Pop-up"
                >
                  ✕
                </button>
              </div>
            </div>

            {studyGallery.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="text-4xl opacity-40">🖼️</div>
                <p className="text-slate-400 text-sm font-medium">No diagram snapshots saved in your Study Gallery yet.</p>
                <p className="text-xs text-slate-500">Click <strong className="text-emerald-400">"📸 Snap to Gallery"</strong> on any math diagram to save it here for quick reference.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {studyGallery.map((snap) => (
                  <div key={snap.id} className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3 relative group">
                    <div className="relative rounded-xl overflow-hidden border border-slate-700 bg-slate-950">
                      <img src={snap.image} alt={snap.title} className="w-full object-cover max-h-[180px]" referrerPolicy="no-referrer" />
                      {snap.annotations?.map((anno: any, idx: number) => (
                        <div
                          key={idx}
                          className="absolute w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-emerald-300 shadow text-[8px] font-bold text-white flex items-center justify-center -translate-x-1/2 -translate-y-1/2"
                          style={{ left: `${anno.x}%`, top: `${anno.y}%` }}
                        >
                          {idx + 1}
                        </div>
                      ))}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white truncate">{snap.title}</h4>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1">
                        <span>{snap.timestamp}</span>
                        <span className="text-emerald-400 font-bold">{snap.annotations?.length || 0} Hotspots</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-700/60">
                      <button
                        onClick={() => {
                          const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(snap, null, 2));
                          const dlAnchorElem = document.createElement('a');
                          dlAnchorElem.setAttribute("href", dataStr);
                          dlAnchorElem.setAttribute("download", `snapshot_${snap.id}.json`);
                          dlAnchorElem.click();
                          showNotification?.("Exported diagram snapshot JSON", "success");
                        }}
                        className="flex-1 py-1 px-2 rounded-lg bg-slate-900 hover:bg-slate-700 text-[10px] font-bold text-slate-300 transition text-center cursor-pointer"
                      >
                        💾 Download
                      </button>
                      <button
                        onClick={() => {
                          const updated = studyGallery.filter(s => s.id !== snap.id);
                          setStudyGallery(updated);
                          localStorage.setItem('study_gallery_snaps', JSON.stringify(updated));
                          showNotification?.("Deleted snapshot from gallery", "info");
                        }}
                        className="py-1 px-2 rounded-lg bg-rose-950/80 hover:bg-rose-900 text-[10px] font-bold text-rose-300 transition text-center cursor-pointer"
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/50">
              <span className="text-xs text-slate-400">Total Saved: <strong>{studyGallery.length}</strong> snapshots</span>
              <button
                onClick={() => setIsGalleryOpen(false)}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
              >
                Close Gallery
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Color Palette & Category Highlights Modal */}
      {activePaletteMsgId && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className={cn(
            "w-full max-w-lg rounded-3xl p-6 border shadow-2xl space-y-5 animate-in zoom-in-95",
            theme === 'dark' ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-900"
          )}>
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/50 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🎨</span>
                <div>
                  <h3 
                    className="font-black tracking-tight text-purple-400"
                    style={{ fontSize: `${Math.max(16, popupFontSize + 3)}px` }}
                  >
                    Hotspot Color Palette & Category Themes
                  </h3>
                  <p className="text-xs text-slate-400">Choose specific highlight colors for different hotspot categories to update diagram borders instantly.</p>
                </div>
              </div>

              {/* Expandable Font Size Toolbar */}
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-xl p-1 text-xs gap-1 shadow-inner">
                  <span className="text-[10px] uppercase font-mono font-bold text-slate-400 px-1">Font</span>
                  <button
                    onClick={() => setPopupFontSize(prev => Math.max(12, prev - 2))}
                    disabled={popupFontSize <= 12}
                    className="px-2 py-1 rounded-lg hover:bg-slate-700 disabled:opacity-30 text-slate-200 font-extrabold transition cursor-pointer"
                    title="Decrease Pop-up Font Size (A-)"
                  >
                    A-
                  </button>
                  <span className="px-1.5 font-mono text-[11px] text-amber-400 font-bold min-w-[36px] text-center bg-slate-950/60 rounded py-0.5">
                    {popupFontSize}px
                  </span>
                  <button
                    onClick={() => setPopupFontSize(prev => Math.min(28, prev + 2))}
                    disabled={popupFontSize >= 28}
                    className="px-2 py-1 rounded-lg hover:bg-slate-700 disabled:opacity-30 text-slate-200 font-extrabold transition cursor-pointer"
                    title="Expand Pop-up Font Size (A+)"
                  >
                    A+
                  </button>
                  {popupFontSize !== 14 && (
                    <button
                      onClick={() => setPopupFontSize(14)}
                      className="px-1.5 py-1 rounded-lg hover:bg-slate-700 text-[10px] text-slate-400 font-bold hover:text-white transition cursor-pointer"
                      title="Reset Font Size"
                    >
                      Reset
                    </button>
                  )}
                </div>

                <button
                  onClick={() => setActivePaletteMsgId(null)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                  title="Close Pop-up"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              {/* Category Quick Presets */}
              <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700 space-y-2">
                <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider">Quick Category Presets</span>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { name: 'Theory / Definitions', color: 'Purple', bg: 'bg-purple-600' },
                    { name: 'Equations & Formulas', color: 'Amber', bg: 'bg-amber-600' },
                    { name: 'Visual Components', color: 'Emerald', bg: 'bg-emerald-600' },
                    { name: 'Critical Hotspots', color: 'Rose', bg: 'bg-rose-600' }
                  ].map((cat) => (
                    <button
                      key={cat.name}
                      onClick={() => {
                        const msgAnns = localMessages.find(m => m.id === activePaletteMsgId)?.metadata?.annotations || [];
                        const newColors = { ...annoColors };
                        msgAnns.forEach((_: any, idx: number) => {
                          newColors[`${activePaletteMsgId}-${idx}`] = cat.color;
                        });
                        setAnnoColors(newColors);
                        showNotification?.(`Applied category color "${cat.color}" to all hotspots!`, "success");
                      }}
                      className="p-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-purple-500 flex items-center justify-between font-bold text-slate-200 transition cursor-pointer"
                    >
                      <span>{cat.name}</span>
                      <span className={cn("w-3 h-3 rounded-full", cat.bg)} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Individual Hotspot Color Assignments */}
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Individual Hotspot Colors</span>
                {localMessages.find(m => m.id === activePaletteMsgId)?.metadata?.annotations?.map((anno: any, idx: number) => {
                  const key = `${activePaletteMsgId}-${idx}`;
                  const currentPreset = colorPresets.find(p => p.label === annoColors[key]) || colorPresets[0];

                  return (
                    <div key={idx} className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center font-bold text-[10px] text-white">
                          #{idx + 1}
                        </span>
                        <span className="font-bold text-white">{anno.label}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {colorPresets.map(preset => (
                          <button
                            key={preset.label}
                            onClick={() => {
                              setAnnoColors(prev => ({ ...prev, [key]: preset.label }));
                            }}
                            className={cn(
                              "w-4 h-4 rounded-full border transition cursor-pointer",
                              preset.bg,
                              currentPreset.label === preset.label ? "ring-2 ring-white scale-125 border-white" : "border-transparent opacity-60 hover:opacity-100"
                            )}
                            title={preset.label}
                          />
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-end pt-3 border-t border-slate-700/50">
              <button
                onClick={() => setActivePaletteMsgId(null)}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
              >
                Apply & Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Compare Original vs Adjusted Modal */}
      {compareModalMsgId && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className={cn(
            "w-full max-w-2xl rounded-3xl p-6 border shadow-2xl space-y-5 animate-in zoom-in-95 max-h-[85vh] overflow-y-auto",
            theme === 'dark' ? "bg-slate-900 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-900"
          )}>
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/50 flex-wrap gap-2">
              <div>
                <h3 
                  className="font-black tracking-tight text-indigo-400"
                  style={{ fontSize: `${Math.max(16, popupFontSize + 3)}px` }}
                >
                  Annotation Comparison: Original vs Adjusted
                </h3>
                <p className="text-xs text-slate-400">Review AI-generated original hotspot coordinates alongside your custom adjustments.</p>
              </div>

              {/* Expandable Font Size Toolbar */}
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-xl p-1 text-xs gap-1 shadow-inner">
                  <span className="text-[10px] uppercase font-mono font-bold text-slate-400 px-1">Font</span>
                  <button
                    onClick={() => setPopupFontSize(prev => Math.max(12, prev - 2))}
                    disabled={popupFontSize <= 12}
                    className="px-2 py-1 rounded-lg hover:bg-slate-700 disabled:opacity-30 text-slate-200 font-extrabold transition cursor-pointer"
                    title="Decrease Pop-up Font Size (A-)"
                  >
                    A-
                  </button>
                  <span className="px-1.5 font-mono text-[11px] text-amber-400 font-bold min-w-[36px] text-center bg-slate-950/60 rounded py-0.5">
                    {popupFontSize}px
                  </span>
                  <button
                    onClick={() => setPopupFontSize(prev => Math.min(28, prev + 2))}
                    disabled={popupFontSize >= 28}
                    className="px-2 py-1 rounded-lg hover:bg-slate-700 disabled:opacity-30 text-slate-200 font-extrabold transition cursor-pointer"
                    title="Expand Pop-up Font Size (A+)"
                  >
                    A+
                  </button>
                  {popupFontSize !== 14 && (
                    <button
                      onClick={() => setPopupFontSize(14)}
                      className="px-1.5 py-1 rounded-lg hover:bg-slate-700 text-[10px] text-slate-400 font-bold hover:text-white transition cursor-pointer"
                      title="Reset Font Size"
                    >
                      Reset
                    </button>
                  )}
                </div>

                <button
                  onClick={() => setCompareModalMsgId(null)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                  title="Close Pop-up"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Original AI Column */}
              <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700/60 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-amber-400 uppercase tracking-wider">Original AI Placement</span>
                  <span className="text-[10px] font-mono text-slate-400">Default Baseline</span>
                </div>
                <div className="space-y-2">
                  {originalAnnotationsMap[compareModalMsgId]?.map((orig: any, i: number) => (
                    <div key={i} className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-1">
                      <div className="font-bold text-white">#{i + 1} {orig.label}</div>
                      <div className="text-[10px] font-mono text-slate-400">X: {orig.x}%, Y: {orig.y}%</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Current Adjusted Column */}
              <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-indigo-400 uppercase tracking-wider">Current Adjusted</span>
                  <span className="text-[10px] font-mono text-emerald-400">Auto-Saved</span>
                </div>
                <div className="space-y-2">
                  {localMessages.find(m => m.id === compareModalMsgId)?.metadata?.annotations?.map((curr: any, i: number) => {
                    const orig = originalAnnotationsMap[compareModalMsgId]?.[i];
                    const isChanged = orig && (orig.x !== curr.x || orig.y !== curr.y);
                    return (
                      <div key={i} className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white">#{i + 1} {curr.label}</span>
                          {isChanged && <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold">Modified</span>}
                        </div>
                        <div className="text-[10px] font-mono text-slate-400">X: {curr.x}%, Y: {curr.y}%</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/50">
              <button
                onClick={() => {
                  if (confirm("Are you sure you want to reset all hotspots to original AI positions?")) {
                    const orig = originalAnnotationsMap[compareModalMsgId];
                    if (orig) {
                      setLocalMessages(prev => prev.map(m => {
                        if (m.id === compareModalMsgId && m.metadata) {
                          const updated = { ...m, metadata: { ...m.metadata, annotations: JSON.parse(JSON.stringify(orig)) } };
                          saveAnnotationsToLocalStorage(compareModalMsgId, orig);
                          return updated;
                        }
                        return m;
                      }));
                      showNotification?.("Reset annotations to original AI positions successfully", "success");
                    }
                  }
                }}
                className="px-4 py-2 rounded-xl bg-rose-600/80 hover:bg-rose-700 text-white font-bold text-xs transition cursor-pointer"
              >
                Reset to Original AI
              </button>
              <button
                onClick={() => setCompareModalMsgId(null)}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
              >
                Close Comparison
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Venn Diagram Builder Modal */}
      {isVennBuilderOpen && (
        <VennDiagramBuilder
          isOpen={isVennBuilderOpen}
          onClose={() => setIsVennBuilderOpen(false)}
          onSendToChat={(text) => {
            onSendMessage?.(text);
            setIsVennBuilderOpen(false);
            showNotification?.('Venn Diagram formula & analysis sent to AI tutor!', 'success');
          }}
          theme={theme}
        />
      )}

      {/* Digital Math Whiteboard Modal */}
      <MathDigitalWhiteboard
        isOpen={isWhiteboardOpen}
        onClose={() => setIsWhiteboardOpen(false)}
        onSendToChat={(promptText, imageBase64) => {
          onSendMessage(promptText, imageBase64);
          setIsWhiteboardOpen(false);
        }}
        onAttachToInput={(imageBase64) => {
          onSendMessage("I sketched this mathematical diagram/equation. Please analyze and explain it step-by-step:", imageBase64);
          setIsWhiteboardOpen(false);
        }}
        theme={theme}
        showNotification={showNotification}
      />

      <AudioDiagnostics 
        isOpen={isDiagnosticsOpen} 
        onClose={() => setIsDiagnosticsOpen(false)}
        analyser={analyserRef.current}
        audioContext={audioContextRef.current}
        isSpeaking={isSpeaking}
      />

      {/* Crash Doubt / Interruption Modal */}
      {isCrashDoubtModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={cn(
            "w-full max-w-lg rounded-3xl p-6 shadow-2xl border space-y-4 animate-in fade-in zoom-in-95 duration-200",
            theme === 'dark' ? "bg-slate-950 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
          )}>
            <div className="flex items-center justify-between border-b pb-3 border-slate-700/40">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-500">
                  <Zap size={22} className="fill-current animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-black tracking-tight">Raise Crash Doubt / Live Interruption</h3>
                  <p className="text-xs opacity-60">Pause running lecture to clarify a doubt with the professor</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCrashDoubtModalOpen(false)}
                className="p-2 rounded-xl hover:bg-slate-800/50 cursor-pointer transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-amber-500">Your Interruption Question / Doubt:</label>
              <textarea
                value={crashDoubtText}
                onChange={(e) => setCrashDoubtText(e.target.value)}
                placeholder="e.g., Professor, could you please clarify how this specific formula applies when x approaches zero?"
                className={cn(
                  "w-full p-3.5 rounded-2xl border text-sm min-h-[130px] focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none",
                  theme === 'dark' ? "bg-slate-900 border-slate-800 text-white placeholder-slate-500" : "bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400"
                )}
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                    handleAskCrashDoubt();
                  }
                }}
              />
              <p className="text-[11px] opacity-50">Press Ctrl+Enter or click the button below to instantly pause the lecture and ask the professor.</p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setIsCrashDoubtModalOpen(false)}
                className="px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-slate-800/50 cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAskCrashDoubt}
                className="px-5 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs uppercase tracking-wider hover:bg-amber-400 shadow-lg shadow-amber-500/25 cursor-pointer flex items-center gap-2 transition-all"
              >
                <Zap size={15} className="fill-current" />
                <span>Pause Lecture & Clear Doubt</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* IndexedDB Cache Management Modal */}
      {isCacheStatsModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={cn(
            "w-full max-w-lg rounded-3xl p-6 shadow-2xl border space-y-4 animate-in fade-in zoom-in-95 duration-200",
            theme === 'dark' ? "bg-slate-950 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
          )}>
            <div className="flex items-center justify-between border-b pb-3 border-slate-700/40">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400">
                  <HardDrive size={22} />
                </div>
                <div>
                  <h3 className="text-base font-black tracking-tight">IndexedDB Local Offline Cache</h3>
                  <p className="text-xs opacity-60">Network instability resilience & video fragment persistence</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCacheStatsModalOpen(false)}
                className="p-2 rounded-xl hover:bg-slate-800/50 cursor-pointer transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Video Fragments</p>
                  <p className="text-xl font-black text-cyan-400 mt-1">{cacheStats.cachedVideos}</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Metadata Items</p>
                  <p className="text-xl font-black text-indigo-400 mt-1">{cacheStats.metadataItems}</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Cache Volume</p>
                  <p className="text-xl font-black text-emerald-400 mt-1">{(cacheStats.totalBytes / (1024 * 1024)).toFixed(1)} MB</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-300 uppercase tracking-wider">
                  <ShieldAlert size={14} />
                  <span>Network Continuity Protection</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  IndexedDB automatically captures recent lecture metadata, verbal questions, transcripts, and video media blobs. During bandwidth drops or total offline disconnects, playback and lesson resumption transition seamlessly without losing your spot.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={async () => {
                  await clearLectureCache();
                  const freshStats = await getLectureCacheStats();
                  setCacheStats(freshStats);
                  showNotification?.("IndexedDB offline cache cleared successfully.", "info");
                }}
                className="px-3.5 py-2 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 hover:bg-rose-500/30 text-xs font-bold uppercase tracking-wider cursor-pointer flex items-center gap-1.5 transition-all"
              >
                <Trash2 size={14} />
                <span>Clear Cache</span>
              </button>
              <button
                type="button"
                onClick={() => setIsCacheStatsModalOpen(false)}
                className="px-5 py-2 rounded-xl bg-indigo-600 text-white font-black text-xs uppercase tracking-wider hover:bg-indigo-500 shadow-lg cursor-pointer transition-all"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Annotate Figure Hotspot Creation Overlay Modal */}
      {pendingAnnotationHotspot && (
        <div className="fixed inset-0 z-[999999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-5 md:p-6 max-w-lg w-full shadow-2xl space-y-4 relative text-white">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <StickyNote size={18} />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm md:text-base text-white flex items-center gap-2">
                    <span>📍 Add Figure Hotspot Note</span>
                  </h3>
                  <p className="text-xs text-slate-400 font-mono">
                    Coordinates: ({pendingAnnotationHotspot.x}%, {pendingAnnotationHotspot.y}%) on figure
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPendingAnnotationHotspot(null)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Category Selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>Hotspot Type & Style:</span>
                <span className="text-[10px] text-slate-400 font-normal">Choose color badge & icon</span>
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {(['question', 'note', 'concept', 'formula', 'exam'] as const).map((cat) => {
                  const cfg = HOTSPOT_CATEGORY_CONFIG[cat];
                  const isSelected = annotationCategoryInput === cat;
                  const Icon = cfg.icon;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setAnnotationCategoryInput(cat)}
                      className={cn(
                        "p-2 rounded-xl border text-xs font-bold transition flex items-center gap-2 cursor-pointer text-left",
                        isSelected
                          ? "bg-slate-800 border-amber-400 text-white ring-2 ring-amber-400/50 shadow-md"
                          : "bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
                      )}
                    >
                      <Icon size={14} className={cfg.colorClass} />
                      <span className="truncate">{cfg.label.replace(/^[^\s]+\s*/, '')}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Hotspot Title / Label */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Hotspot Title / Tag:</label>
              <input
                type="text"
                value={annotationTitleInput}
                onChange={(e) => setAnnotationTitleInput(e.target.value)}
                placeholder="e.g. Q1, Step 3, Nucleus, Formula V=IR..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
              />
            </div>

            {/* Hotspot Content / Question Text */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>Note or Question Content:</span>
                <span className="text-[10px] text-amber-400 font-medium">LaTeX math supported</span>
              </label>
              <textarea
                autoFocus
                rows={3}
                value={annotationNoteInput}
                onChange={(e) => setAnnotationNoteInput(e.target.value)}
                placeholder={
                  annotationCategoryInput === 'question'
                    ? "e.g., Why does the electric current peak at this node?"
                    : annotationCategoryInput === 'formula'
                    ? "e.g., Formula: F = m * a, unit: Newtons (N)"
                    : "Type your study note, observation, or question here..."
                }
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-medium text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 resize-none"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setPendingAnnotationHotspot(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleSavePendingAnnotation(false)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition cursor-pointer shadow-lg active:scale-95 flex items-center gap-1.5"
              >
                <StickyNote size={14} />
                <span>Attach Hotspot Note</span>
              </button>
              {annotationCategoryInput === 'question' && (
                <button
                  type="button"
                  onClick={() => handleSavePendingAnnotation(true)}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs transition cursor-pointer shadow-lg shadow-indigo-600/30 active:scale-95 flex items-center gap-1.5"
                >
                  <Sparkles size={14} />
                  <span>Attach & Ask AI Tutor 🤖</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification: Restore Session on Page Load */}
      <AnimatePresence>
        {showRestoreToast && activeLectureBookmark && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 400, damping: 25 }}
            className={cn(
              "fixed top-5 right-5 z-[2100] max-w-sm w-full p-4 rounded-2xl border shadow-2xl backdrop-blur-xl flex flex-col gap-3 transition-all",
              theme === 'dark' 
                ? "bg-slate-900/95 border-emerald-500/40 text-white shadow-emerald-950/40" 
                : "bg-white/95 border-emerald-500/40 text-slate-900 shadow-emerald-100"
            )}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="relative p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
                  <Bookmark size={18} className="fill-current" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-black uppercase tracking-wider text-emerald-400">Interrupted Lecture Detected</h4>
                    <span className="px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
                      {activeLectureBookmark.timeLabel}
                    </span>
                  </div>
                  <p className="text-xs font-medium opacity-80 mt-0.5">
                    {activeLectureBookmark.reason || 'Previous lecture bookmark ready to resume'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={async () => {
                  localStorage.removeItem('omni_lecture_bookmark');
                  await deleteLectureMetadata('omni_latest_lecture_bookmark');
                  await deleteLectureMetadata('omni_active_lecture_cache');
                  setActiveLectureBookmark(null);
                  setShowRestoreToast(false);
                }}
                className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-white/10 transition-colors"
                title="Dismiss toast"
              >
                <X size={14} />
              </button>
            </div>

            {activeLectureBookmark.snippet && (
              <p className="text-[11px] italic opacity-60 line-clamp-2 px-2.5 py-1.5 rounded-lg bg-black/20 border border-white/5">
                "{activeLectureBookmark.snippet}..."
              </p>
            )}

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={async () => {
                  localStorage.removeItem('omni_lecture_bookmark');
                  await deleteLectureMetadata('omni_latest_lecture_bookmark');
                  await deleteLectureMetadata('omni_active_lecture_cache');
                  setActiveLectureBookmark(null);
                  setShowRestoreToast(false);
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold opacity-60 hover:opacity-100 transition-opacity"
              >
                Dismiss
              </button>
              <button
                type="button"
                onClick={() => {
                  restoreLectureBookmark(activeLectureBookmark);
                  setShowRestoreToast(false);
                }}
                className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs uppercase tracking-wider hover:bg-emerald-400 shadow-md shadow-emerald-500/20 cursor-pointer flex items-center gap-2 transition-all"
              >
                <RotateCcw size={14} />
                <span>Restore Session</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Interactive Full-Screen Diagram Inspector Lightbox Modal */}
      {fullscreenDiagramMsgId && (() => {
        const fsMsg = localMessages.find(m => m.id === fullscreenDiagramMsgId);
        if (!fsMsg || !fsMsg.metadata?.image) return null;
        const topicName = fsMsg.metadata.topic || 'Visual Concept Diagram';
        const annotations = fsMsg.metadata.annotations || [];

        return (
          <div className="fixed inset-0 z-[999999] bg-slate-950/95 backdrop-blur-2xl flex flex-col justify-between p-4 md:p-6 shadow-2xl animate-in fade-in duration-200 select-none overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl px-5 py-3 shadow-xl flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                  <Maximize2 size={20} />
                </div>
                <div>
                  <h3 className="text-sm md:text-base font-black tracking-tight text-white flex items-center gap-2">
                    <span>🔬 Diagram Inspector:</span>
                    <span className="text-indigo-400">{topicName}</span>
                  </h3>
                  <p className="text-xs text-slate-400">Pinch, scroll wheel, or use controls below to zoom, rotate, and inspect details</p>
                </div>
              </div>

              {/* Status Badges & Close Button */}
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono font-bold text-slate-300">
                  <span className="text-indigo-400">🔍 {Math.round(fullscreenZoom * 100)}%</span>
                  <span className="text-slate-600">|</span>
                  <span className="text-amber-400">🔄 {((fullscreenRotation % 360) + 360) % 360}°</span>
                </div>
                <button
                  type="button"
                  onClick={() => setFullscreenDiagramMsgId(null)}
                  className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer active:scale-95 shadow-md flex items-center justify-center"
                  title="Exit Full-Screen (Esc)"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Main Stage Viewport */}
            <div 
              className="flex-1 relative overflow-auto flex items-center justify-center p-6 bg-slate-900/40 rounded-3xl border border-slate-800/80 my-4 shadow-inner custom-scrollbar"
              onWheel={(e) => {
                e.preventDefault();
                const delta = e.deltaY < 0 ? 0.2 : -0.2;
                const nextZoom = Math.max(0.5, Math.min(5, Number((fullscreenZoom + delta).toFixed(2))));
                setFullscreenZoom(nextZoom);
                setZoomLevels(prev => ({ ...prev, [fullscreenDiagramMsgId]: nextZoom }));
              }}
            >
              <div
                className="relative transition-transform duration-200 ease-out select-none"
                style={{
                  transform: `scale(${fullscreenZoom}) rotate(${fullscreenRotation}deg)`,
                  transformOrigin: 'center center'
                }}
              >
                <img
                  src={fsMsg.metadata.image}
                  alt={topicName}
                  className={cn(
                    "max-w-[85vw] max-h-[70vh] object-contain rounded-2xl border border-white/20 shadow-2xl transition-all duration-200",
                    autoContrastDiagramIds.has(fsMsg.id) && "contrast-125 brightness-110 saturate-125"
                  )}
                  style={{
                    filter: [
                      chalkInvertDiagramIds.has(fsMsg.id) ? 'invert(100%) hue-rotate(180deg) contrast(140%) brightness(95%)' : '',
                      autoContrastDiagramIds.has(fsMsg.id) ? 'contrast(135%) brightness(108%) saturate(125%)' : ''
                    ].filter(Boolean).join(' ') || undefined
                  }}
                  referrerPolicy="no-referrer"
                />

                {/* Interactive Hotspot Pins Overlay */}
                {showHotspots[fsMsg.id] !== false && annotations.map((anno: any, idx: number) => (
                  <div
                    key={idx}
                    className="absolute transform -translate-x-1/2 -translate-y-1/2 group/fshspot cursor-pointer z-20"
                    style={{ left: `${anno.x}%`, top: `${anno.y}%` }}
                  >
                    <div className="relative flex items-center justify-center">
                      <span className="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-amber-400 opacity-75"></span>
                      <div className="relative w-7 h-7 rounded-full bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center ring-2 ring-white shadow-xl">
                        {idx + 1}
                      </div>
                      {/* Detailed Hotspot Popover Tooltip */}
                      <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 hidden group-hover/fshspot:flex flex-col bg-slate-950/95 backdrop-blur-md text-white text-xs p-3 rounded-2xl border border-amber-500/40 shadow-2xl z-30 min-w-[180px] max-w-xs pointer-events-none">
                        <span className="font-extrabold text-amber-400 text-sm">#{idx + 1}: {anno.label}</span>
                        {anno.description && <span className="text-xs text-slate-300 mt-1 leading-relaxed">{anno.description}</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fullscreen Diagram Legend Block */}
            {showLegendMap[fullscreenDiagramMsgId] !== false && annotations && annotations.length > 0 && (
              <div className="w-full max-w-5xl mb-4">
                <DiagramLegendBlock
                  msgId={fullscreenDiagramMsgId}
                  annotations={annotations}
                  hoveredAnnoIndex={hoveredAnnoIndex}
                  onHoverAnno={(idx) => setHoveredAnnoIndex(idx !== null ? { msgId: fullscreenDiagramMsgId, index: idx } : null)}
                  onSelectAnno={(anno, idx) => {
                    setHoveredAnnoIndex({ msgId: fullscreenDiagramMsgId, index: idx });
                    setActiveAnnoModal({ msgId: fullscreenDiagramMsgId, anno, index: idx });
                  }}
                  annoColors={annoColors}
                  colorPresets={colorPresets}
                  showNotification={showNotification}
                  theme="dark"
                  topicTitle={topicName}
                />
              </div>
            )}

            {/* Bottom Control Dock */}
            <div className="flex items-center justify-center bg-slate-900/90 border border-slate-800 rounded-2xl px-5 py-3 shadow-2xl backdrop-blur-xl flex-wrap gap-4">
              {/* Refresh Diagram Button */}
              {fsMsg && (
                <>
                  <button
                    type="button"
                    onClick={() => handleRefreshDiagram(fsMsg)}
                    disabled={refreshingDiagramIds.has(fullscreenDiagramMsgId)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-950/90 border border-emerald-500/40 hover:bg-emerald-900 text-emerald-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    title="Re-generate and refresh current topic visual diagram"
                  >
                    {refreshingDiagramIds.has(fullscreenDiagramMsgId) ? (
                      <>
                        <Loader2 size={14} className="animate-spin text-emerald-400" />
                        <span>Refreshing...</span>
                      </>
                    ) : (
                      <>
                        <RotateCw size={14} className="text-emerald-400" />
                        <span>Refresh Diagram</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDownloadPNG(fsMsg)}
                    className="px-3 py-1.5 rounded-xl bg-blue-950/90 border border-blue-500/40 hover:bg-blue-900 text-blue-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    title="Download high-quality PNG image of study figure for offline review"
                  >
                    <Download size={14} className="text-blue-400" />
                    <span>Download PNG</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsQrScannerOpen(true)}
                    className="px-3 py-1.5 rounded-xl bg-amber-950/90 border border-amber-500/40 hover:bg-amber-900 text-amber-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    title="Scan physical QR code from camera or clipboard for related educational content"
                  >
                    <QrCode size={14} className="text-amber-400" />
                    <span>Scan QR</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsCachedFiguresModalOpen(true)}
                    className="px-3 py-1.5 rounded-xl bg-cyan-950/90 border border-cyan-500/40 hover:bg-cyan-900 text-cyan-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    title="Toggle between previously rendered figures from local storage cache without re-generating"
                  >
                    <Database size={14} className="text-cyan-400" />
                    <span>⚡ Cache ({cachedStudyFigures.length})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleGenerateElementQuiz(fsMsg)}
                    disabled={generatingElementQuizMsgId === fsMsg.id}
                    className="px-3 py-1.5 rounded-xl bg-indigo-950/90 border border-indigo-500/40 hover:bg-indigo-900 text-indigo-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    title="Automatically generate a specialized quiz question based on currently highlighted diagram elements"
                  >
                    {generatingElementQuizMsgId === fsMsg.id ? (
                      <>
                        <Loader2 size={14} className="animate-spin text-indigo-400" />
                        <span>Generating...</span>
                      </>
                    ) : (
                      <>
                        <Brain size={14} className="text-indigo-400" />
                        <span>Element Quiz</span>
                      </>
                    )}
                  </button>
                </>
              )}

              {/* Legend Toggle Button */}
              <button
                type="button"
                onClick={() => setShowLegendMap(prev => ({ ...prev, [fullscreenDiagramMsgId]: prev[fullscreenDiagramMsgId] === false ? true : false }))}
                className={cn(
                  "px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border cursor-pointer",
                  showLegendMap[fullscreenDiagramMsgId] !== false
                    ? "bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30"
                    : "bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-900"
                )}
                title="Show or hide the diagram legend block"
              >
                <Tag size={14} />
                <span>{showLegendMap[fullscreenDiagramMsgId] !== false ? 'Hide Legend' : 'Show Legend'}</span>
              </button>
              {/* Zoom Controls & Range Slider */}
              <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
                <span className="text-xs font-bold text-slate-400">Zoom:</span>
                <button
                  type="button"
                  onClick={() => {
                    const z = Math.max(0.5, Number((fullscreenZoom - 0.25).toFixed(2)));
                    setFullscreenZoom(z);
                    setZoomLevels(prev => ({ ...prev, [fullscreenDiagramMsgId]: z }));
                  }}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition active:scale-95"
                  title="Zoom Out"
                >
                  <Minus size={14} />
                </button>
                <input
                  type="range"
                  min="0.5"
                  max="5"
                  step="0.1"
                  value={fullscreenZoom}
                  onChange={(e) => {
                    const z = parseFloat(e.target.value);
                    setFullscreenZoom(z);
                    setZoomLevels(prev => ({ ...prev, [fullscreenDiagramMsgId]: z }));
                  }}
                  className="w-28 md:w-36 accent-indigo-500 cursor-pointer"
                />
                <button
                  type="button"
                  onClick={() => {
                    const z = Math.min(5, Number((fullscreenZoom + 0.25).toFixed(2)));
                    setFullscreenZoom(z);
                    setZoomLevels(prev => ({ ...prev, [fullscreenDiagramMsgId]: z }));
                  }}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition active:scale-95"
                  title="Zoom In"
                >
                  <Plus size={14} />
                </button>
                <span className="text-xs font-mono font-black text-amber-400 min-w-[42px] text-center">{Math.round(fullscreenZoom * 100)}%</span>
              </div>

              {/* Rotation Controls */}
              <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
                <span className="text-xs font-bold text-slate-400">Rotate:</span>
                <button
                  type="button"
                  onClick={() => {
                    const r = fullscreenRotation - 90;
                    setFullscreenRotation(r);
                    setDiagramRotations(prev => ({ ...prev, [fullscreenDiagramMsgId]: r }));
                  }}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition active:scale-95 flex items-center gap-1 text-xs font-bold"
                  title="Rotate Counter-Clockwise 90°"
                >
                  <RotateCcw size={14} />
                  <span>-90°</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const r = fullscreenRotation + 90;
                    setFullscreenRotation(r);
                    setDiagramRotations(prev => ({ ...prev, [fullscreenDiagramMsgId]: r }));
                  }}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition active:scale-95 flex items-center gap-1 text-xs font-bold"
                  title="Rotate Clockwise 90°"
                >
                  <RotateCw size={14} />
                  <span>+90°</span>
                </button>
              </div>

              {/* Reset View & Toggles */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setFullscreenZoom(1);
                    setFullscreenRotation(0);
                    setZoomLevels(prev => ({ ...prev, [fullscreenDiagramMsgId]: 1 }));
                    setDiagramRotations(prev => ({ ...prev, [fullscreenDiagramMsgId]: 0 }));
                    showNotification?.("Diagram view reset", "info");
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs transition cursor-pointer active:scale-95"
                  title="Reset Zoom to 100% and Rotation to 0°"
                >
                  🔄 Reset View
                </button>

                <button
                  type="button"
                  onClick={() => toggleAutoContrast(fullscreenDiagramMsgId)}
                  className={cn(
                    "px-3 py-1.5 rounded-xl border font-bold text-xs transition cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95",
                    autoContrastDiagramIds.has(fullscreenDiagramMsgId)
                      ? "bg-amber-400 text-slate-950 border-amber-300 font-extrabold"
                      : "bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700"
                  )}
                  title="Toggle High Contrast Filter"
                >
                  <Contrast size={14} />
                  <span>{autoContrastDiagramIds.has(fullscreenDiagramMsgId) ? 'Auto-Contrast ON' : 'Auto-Contrast'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => toggleChalkInvert(fullscreenDiagramMsgId)}
                  className={cn(
                    "px-3 py-1.5 rounded-xl border font-bold text-xs transition cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95",
                    chalkInvertDiagramIds.has(fullscreenDiagramMsgId)
                      ? "bg-purple-600 text-white border-purple-400 font-extrabold shadow-md"
                      : "bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700"
                  )}
                  title="Toggle Dark Blackboard Chalk Invert Mode"
                >
                  <span>{chalkInvertDiagramIds.has(fullscreenDiagramMsgId) ? '🖤 Chalk Invert ON' : '🖤 Chalk Invert'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSnapToGallery(fullscreenDiagramMsgId, fsMsg.metadata.image, annotations, topicName)}
                  className="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 hover:bg-emerald-900 text-emerald-300 font-bold text-xs transition cursor-pointer flex items-center gap-1.5"
                  title="Save snapshot to Study Gallery"
                >
                  📸 Snap to Gallery
                </button>

                <button
                  type="button"
                  onClick={() => setFullscreenDiagramMsgId(null)}
                  className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 shadow-md active:scale-95"
                  title="Close Inspector"
                >
                  <Minimize2 size={14} />
                  <span>Exit Fullscreen</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Cached Study Figures Modal */}
      {isCachedFiguresModalOpen && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-3xl rounded-3xl p-6 border shadow-2xl space-y-5 bg-slate-900 border-slate-700 text-white animate-in zoom-in-95 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-lg">
                  <Database size={22} />
                </div>
                <div>
                  <h3 className="font-black text-lg text-cyan-300 tracking-tight">LocalStorage Figure Cache</h3>
                  <p className="text-xs text-slate-400">Quickly toggle or load previously rendered study diagrams without re-generating</p>
                </div>
              </div>
              <button
                onClick={() => setIsCachedFiguresModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Close Cache Manager"
              >
                ✕
              </button>
            </div>

            {cachedStudyFigures.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="text-4xl opacity-40">⚡</div>
                <p className="text-slate-400 text-sm font-medium">No figures cached in localStorage yet.</p>
                <p className="text-xs text-slate-500">Generated study diagrams are automatically cached here so you can instantly switch between them during your study session.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="w-full sm:w-72 relative">
                    <input
                      type="text"
                      value={cachedFiguresSearchQuery}
                      onChange={(e) => setCachedFiguresSearchQuery(e.target.value)}
                      placeholder="Search cached figures by topic or tags..."
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 transition shadow-inner"
                    />
                    {cachedFiguresSearchQuery && (
                      <button
                        onClick={() => setCachedFiguresSearchQuery("")}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                  <div className="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-4 text-xs text-slate-400 px-1">
                    <span>Showing <strong className="text-cyan-300">{cachedStudyFigures.filter(item => {
                      if (!cachedFiguresSearchQuery.trim()) return true;
                      const q = cachedFiguresSearchQuery.toLowerCase();
                      const matchTopic = item.topic?.toLowerCase().includes(q);
                      const matchAnns = item.annotations?.some(a => a.label?.toLowerCase().includes(q) || a.desc?.toLowerCase().includes(q));
                      return matchTopic || matchAnns;
                    }).length}</strong> of {cachedStudyFigures.length}</span>
                    <button
                      onClick={() => {
                        if (confirm("Are you sure you want to clear all cached study figures?")) {
                          setCachedStudyFigures([]);
                          localStorage.removeItem('omni_cached_study_figures_v1');
                          showNotification?.("Figure cache cleared.", "info");
                        }
                      }}
                      className="text-rose-400 hover:text-rose-300 font-bold transition cursor-pointer"
                    >
                      Clear Cache
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[50vh] overflow-y-auto pr-1">
                  {cachedStudyFigures
                    .filter(item => {
                      if (!cachedFiguresSearchQuery.trim()) return true;
                      const q = cachedFiguresSearchQuery.toLowerCase();
                      const matchTopic = item.topic?.toLowerCase().includes(q);
                      const matchAnns = item.annotations?.some(a => a.label?.toLowerCase().includes(q) || a.desc?.toLowerCase().includes(q));
                      return matchTopic || matchAnns;
                    })
                    .map((item) => (
                    <div key={item.id} className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3 relative group">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-bold text-sm text-cyan-200 line-clamp-1">{item.topic}</div>
                          <div className="text-[10px] font-mono text-slate-400">{item.timestamp} • {item.annotations?.length || 0} Hotspots</div>
                        </div>
                        <button
                          onClick={() => {
                            setCachedStudyFigures(prev => {
                              const updated = prev.filter(p => p.id !== item.id);
                              localStorage.setItem('omni_cached_study_figures_v1', JSON.stringify(updated));
                              return updated;
                            });
                            showNotification?.("Removed figure from local cache.", "info");
                          }}
                          className="p-1.5 rounded-lg bg-slate-900 hover:bg-rose-950 text-slate-400 hover:text-rose-300 transition cursor-pointer opacity-0 group-hover:opacity-100"
                          title="Delete from Cache"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>

                      <div className="relative rounded-xl overflow-hidden border border-slate-700 bg-slate-950 max-h-[140px]">
                        <img src={item.image} alt={item.topic} className="w-full object-cover max-h-[140px]" referrerPolicy="no-referrer" />
                      </div>

                      <div className="pt-1 flex items-center justify-end gap-2">
                        {localMessages.filter(m => m.metadata?.image).map((msg) => (
                          <button
                            key={msg.id}
                            onClick={() => handleLoadCachedFigureToMessage(item, msg.id)}
                            className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black text-xs transition shadow-md cursor-pointer flex items-center gap-1.5"
                            title="Load into active diagram view instantly"
                          >
                            <span>⚡ Load Figure</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center justify-end pt-3 border-t border-slate-700/60">
              <button
                onClick={() => setIsCachedFiguresModalOpen(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Guided Onboarding Tour Modal - Disabled to ensure zero reader disturbance */}
      {false && isOnboardingOpen && (
        <div className="fixed inset-0 z-[999999] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl p-6 md:p-8 border shadow-2xl space-y-6 bg-slate-900 border-indigo-500/40 text-white animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shadow-lg">
                  <GraduationCap size={26} />
                </div>
                <div>
                  <div className="text-[10px] uppercase font-black tracking-wider text-indigo-400">Welcome Tour • Step {onboardingStep} of 3</div>
                  <h3 className="font-black text-xl text-white tracking-tight">Interactive Study Guide</h3>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsOnboardingOpen(false);
                  try {
                    localStorage.setItem('omni_onboarding_completed_v1', 'true');
                  } catch (e) {}
                }}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Skip Tour"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {onboardingStep === 1 && (
                <div className="space-y-4 animate-in fade-in">
                  <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center gap-3">
                    <div className="text-3xl">🎯</div>
                    <div>
                      <h4 className="font-bold text-sm text-indigo-200">Interactive Diagram Hotspots & Tooltips</h4>
                      <p className="text-xs text-slate-300">Click any numbered hotspot or node on anatomy and math diagrams to expand scientific descriptions instantly.</p>
                    </div>
                  </div>
                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-xs text-slate-400 space-y-2">
                    <div className="font-bold text-slate-200 flex items-center gap-1.5">
                      <span>💡 Pro Tip:</span>
                    </div>
                    <p>Use "Show Hotspots" and "Show Legend" toggles right underneath any figure to customize your view.</p>
                  </div>
                </div>
              )}

              {onboardingStep === 2 && (
                <div className="space-y-4 animate-in fade-in">
                  <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center gap-3">
                    <div className="text-3xl">🧠</div>
                    <div>
                      <h4 className="font-bold text-sm text-purple-200">Specialized Element Quizzes & QR Scanner</h4>
                      <p className="text-xs text-slate-300">Generate rigorous AI-powered quizzes tailored to your highlighted elements. Scan QR codes or export PDF study notes.</p>
                    </div>
                  </div>
                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-xs text-slate-400 space-y-2">
                    <div className="font-bold text-slate-200 flex items-center gap-1.5">
                      <span>✨ Active Recall:</span>
                    </div>
                    <p>Click the <strong className="text-indigo-300">"🧠 Element Quiz"</strong> button on any diagram to test your mastery of selected parts.</p>
                  </div>
                </div>
              )}

              {onboardingStep === 3 && (
                <div className="space-y-4 animate-in fade-in">
                  <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center gap-3">
                    <div className="text-3xl">⚡</div>
                    <div>
                      <h4 className="font-bold text-sm text-cyan-200">LocalStorage Figure Cache & Gallery</h4>
                      <p className="text-xs text-slate-300">Generated diagrams are automatically cached in local storage so you can instantly toggle between figures without re-generating!</p>
                    </div>
                  </div>
                  <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-xs text-slate-400 space-y-2">
                    <div className="font-bold text-slate-200 flex items-center gap-1.5">
                      <span>🚀 Lightning Fast:</span>
                    </div>
                    <p>Click <strong className="text-cyan-300">"⚡ Cache"</strong> at any time to view and load previously generated figures instantly.</p>
                  </div>
                </div>
              )}

              {/* Progress Dots */}
              <div className="flex items-center justify-center gap-2 pt-2">
                <span className={cn("w-2.5 h-2.5 rounded-full transition-all", onboardingStep === 1 ? "bg-indigo-500 w-6" : "bg-slate-700")} />
                <span className={cn("w-2.5 h-2.5 rounded-full transition-all", onboardingStep === 2 ? "bg-indigo-500 w-6" : "bg-slate-700")} />
                <span className={cn("w-2.5 h-2.5 rounded-full transition-all", onboardingStep === 3 ? "bg-indigo-500 w-6" : "bg-slate-700")} />
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/60">
              {onboardingStep > 1 ? (
                <button
                  onClick={() => setOnboardingStep(p => p - 1)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
                >
                  Back
                </button>
              ) : (
                <button
                  onClick={() => {
                    setIsOnboardingOpen(false);
                    try {
                      localStorage.setItem('omni_onboarding_completed_v1', 'true');
                    } catch (e) {}
                  }}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-medium text-xs transition cursor-pointer"
                >
                  Skip Tour
                </button>
              )}

              {onboardingStep < 3 ? (
                <button
                  onClick={() => setOnboardingStep(p => p + 1)}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs transition shadow-lg cursor-pointer"
                >
                  Next Step →
                </button>
              ) : (
                <button
                  onClick={() => {
                    setIsOnboardingOpen(false);
                    try {
                      localStorage.setItem('omni_onboarding_completed_v1', 'true');
                    } catch (e) {}
                    showNotification?.("🎉 You're all set! Enjoy exploring your interactive study diagrams.", "success");
                  }}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs transition shadow-lg cursor-pointer"
                >
                  Get Started 🚀
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Keyboard Shortcuts & Hotkeys Modal */}
      {isKeyboardShortcutsModalOpen && (
        <div className="fixed inset-0 z-[999999] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl p-6 md:p-8 border shadow-2xl space-y-6 bg-slate-900 border-slate-700 text-white animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-lg font-black text-lg">
                  ⌨️
                </div>
                <div>
                  <h3 className="font-black text-lg text-amber-300 tracking-tight">Keyboard Shortcuts & Hotkeys</h3>
                  <p className="text-xs text-slate-400">Power user navigation shortcuts for lightning-fast study sessions</p>
                </div>
              </div>
              <button
                onClick={() => setIsKeyboardShortcutsModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Close Hotkeys"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-1 gap-2.5">
                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm">⚡</span>
                    <span className="text-xs font-bold text-slate-200">Cached Figure Manager</span>
                  </div>
                  <kbd className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 font-mono text-xs font-bold text-cyan-300 shadow-sm">Ctrl + F</kbd>
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm">🖼️</span>
                    <span className="text-xs font-bold text-slate-200">Study Gallery Snapshots</span>
                  </div>
                  <kbd className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 font-mono text-xs font-bold text-emerald-300 shadow-sm">Ctrl + G</kbd>
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm">⌨️</span>
                    <span className="text-xs font-bold text-slate-200">Toggle Shortcuts Menu</span>
                  </div>
                  <kbd className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 font-mono text-xs font-bold text-amber-300 shadow-sm">Ctrl + K</kbd>
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm">🎯</span>
                    <span className="text-xs font-bold text-slate-200">Restart Onboarding Tour</span>
                  </div>
                  <kbd className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 font-mono text-xs font-bold text-indigo-300 shadow-sm">Ctrl + Shift + O</kbd>
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-800/80 border border-slate-700">
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm">❌</span>
                    <span className="text-xs font-bold text-slate-200">Close Any Modal / Dialog</span>
                  </div>
                  <kbd className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 font-mono text-xs font-bold text-rose-300 shadow-sm">Esc</kbd>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/60">
              <span className="text-[11px] text-slate-400">Mac users: use <code className="text-amber-300">Cmd</code> instead of <code className="text-amber-300">Ctrl</code>.</span>
              <button
                onClick={() => setIsKeyboardShortcutsModalOpen(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Speech-to-Text & Voice Command Prompts Modal */}
      {isVoiceCommandModalOpen && (
        <div className="fixed inset-0 z-[999999] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-xl rounded-3xl p-6 md:p-8 border shadow-2xl space-y-6 bg-slate-900 border-rose-500/40 text-white animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shadow-lg">
                  <Mic size={24} className={isVoiceSimulating ? "animate-pulse text-rose-300" : ""} />
                </div>
                <div>
                  <h3 className="font-black text-lg text-rose-300 tracking-tight">Speech-to-Text & Voice Command Hub</h3>
                  <p className="text-xs text-slate-400">Speak your study queries hands-free or use preset voice commands to generate diagrams</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsVoiceCommandModalOpen(false);
                  setIsVoiceSimulating(false);
                  setVoiceSpokenText("");
                }}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Close Voice Hub"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Live Voice Recorder Simulator Box */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col items-center justify-center text-center space-y-3 relative overflow-hidden">
                {isVoiceSimulating && (
                  <div className="absolute inset-0 bg-rose-950/20 backdrop-blur-xs flex items-center justify-center pointer-events-none">
                    <div className="flex items-center gap-1">
                      <span className="w-1.5 h-6 bg-rose-500 animate-bounce rounded-full" />
                      <span className="w-1.5 h-10 bg-rose-400 animate-bounce delay-75 rounded-full" />
                      <span className="w-1.5 h-8 bg-rose-500 animate-bounce delay-150 rounded-full" />
                      <span className="w-1.5 h-12 bg-rose-300 animate-bounce delay-200 rounded-full" />
                      <span className="w-1.5 h-5 bg-rose-500 animate-bounce delay-300 rounded-full" />
                    </div>
                  </div>
                )}

                <div className={cn(
                  "w-16 h-16 rounded-full flex items-center justify-center transition-all shadow-xl cursor-pointer",
                  isVoiceSimulating ? "bg-rose-600 text-white animate-pulse ring-4 ring-rose-500/40" : "bg-slate-800 text-rose-400 hover:bg-slate-700 border border-slate-700"
                )}
                  onClick={() => {
                    const next = !isVoiceSimulating;
                    setIsVoiceSimulating(next);
                    if (next) {
                      setVoiceSpokenText("Listening for your voice query... Speak now or pick a preset below!");
                      setTimeout(() => {
                        setVoiceSpokenText("Explain Newton's second law of motion and force vectors.");
                      }, 2500);
                    } else {
                      setVoiceSpokenText("");
                    }
                  }}
                  title="Click to toggle microphone listening simulation"
                >
                  <Mic size={28} />
                </div>

                <div>
                  <div className="font-bold text-sm text-slate-200">
                    {isVoiceSimulating ? "🎙️ Listening to Voice Input..." : "Click microphone to start voice recording"}
                  </div>
                  <div className="text-xs text-slate-400 max-w-md mt-1 font-mono min-h-[24px]">
                    {voiceSpokenText || "e.g. \"Generate an interactive anatomy diagram of the human brain\""}
                  </div>
                </div>

                {voiceSpokenText && voiceSpokenText.includes("Newton") && (
                  <button
                    onClick={() => {
                      setIsVoiceCommandModalOpen(false);
                      setIsVoiceSimulating(false);
                      onSendMessage?.("Explain Newton's second law of motion and force vectors with an interactive diagram.");
                      showNotification?.("🎙️ Voice command executed successfully!", "success");
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs transition shadow-lg cursor-pointer flex items-center gap-1.5 animate-bounce mt-2"
                  >
                    <span>🚀 Execute Spoken Study Query</span>
                  </button>
                )}
              </div>

              {/* Preset Voice Study Commands */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-300 block">Or Tap a Preset Voice Command:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {[
                    "Explain human heart anatomy and valves",
                    "Generate Maxwell's electromagnetic equations",
                    "Explain cellular respiration & mitochondria",
                    "Show quantum computing qubit superposition",
                    "Practice interactive element quiz on calculus",
                    "Explain plate tectonics and fault lines"
                  ].map((cmd, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        setIsVoiceCommandModalOpen(false);
                        setIsVoiceSimulating(false);
                        onSendMessage?.(`Generate a comprehensive interactive study guide and diagram for: ${cmd}`);
                        showNotification?.(`🎙️ Voice Prompt: "${cmd}"`, "success");
                      }}
                      className="p-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-rose-500/40 text-left text-xs font-medium text-slate-200 transition cursor-pointer flex items-center justify-between group shadow-sm"
                    >
                      <span className="line-clamp-1">🎙️ "{cmd}"</span>
                      <span className="text-[10px] text-rose-400 font-bold opacity-0 group-hover:opacity-100 transition">Run →</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/60">
              <span className="text-[11px] text-slate-400">Shortcut: Press <code className="text-rose-300">Ctrl + M</code> anytime to open voice commands.</span>
              <button
                onClick={() => {
                  setIsVoiceCommandModalOpen(false);
                  setIsVoiceSimulating(false);
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Accessibility & Readability Toolbar Modal */}
      {isAccessibilityModalOpen && (
        <div className="fixed inset-0 z-[999999] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl p-6 md:p-8 border shadow-2xl space-y-6 bg-slate-900 border-cyan-500/40 text-white animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b pb-4 border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-lg text-xl font-bold">
                  ♿
                </div>
                <div>
                  <h3 className="font-black text-lg text-cyan-300 tracking-tight">Accessibility & Readability Hub</h3>
                  <p className="text-xs text-slate-400">Customize font sizes and high-contrast modes across tooltips, cards, and math formulas</p>
                </div>
              </div>
              <button
                onClick={() => setIsAccessibilityModalOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Close Accessibility"
              >
                ✕
              </button>
            </div>

            <div className="space-y-5">
              {/* Font Size Scaling */}
              <div className="space-y-2.5">
                <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>🔠 Text Scaling & Font Size</span>
                  <span className="text-cyan-400 font-mono text-[11px] uppercase">{fontSizeScale}</span>
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: 'normal', label: 'Normal', desc: 'Standard 14px' },
                    { id: 'large', label: 'Large (A+)', desc: 'Enhanced 16px' },
                    { id: 'xl', label: 'Extra Large (A++)', desc: 'Maximum 18px+' }
                  ].map((mode) => (
                    <button
                      key={mode.id}
                      onClick={() => {
                        setFontSizeScale(mode.id as any);
                        localStorage.setItem('omni_font_size_scale_v1', mode.id);
                        showNotification?.(`Font size set to ${mode.label}`, 'success');
                      }}
                      className={cn(
                        "p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between",
                        fontSizeScale === mode.id
                          ? "bg-cyan-950/80 border-cyan-500 text-cyan-200 shadow-lg ring-2 ring-cyan-500/30"
                          : "bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800"
                      )}
                    >
                      <span className="font-black text-xs">{mode.label}</span>
                      <span className="text-[10px] text-slate-400 mt-1">{mode.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* High Contrast Mode */}
              <div className="space-y-2.5">
                <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>🎨 High-Contrast Readability Mode</span>
                  <span className={cn("text-[11px] font-bold px-2 py-0.5 rounded-full", isHighContrast ? "bg-amber-500/20 text-amber-300 border border-amber-500/40" : "bg-slate-800 text-slate-400")}>
                    {isHighContrast ? "ENABLED ⚡" : "DISABLED"}
                  </span>
                </label>
                <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-800/80 border border-slate-700">
                  <div className="space-y-1">
                    <div className="text-xs font-bold text-slate-200">Pure Black & Yellow High Contrast</div>
                    <div className="text-[11px] text-slate-400">Increases legibility for math formulas, diagrams, and explanation cards.</div>
                  </div>
                  <button
                    onClick={() => {
                      const next = !isHighContrast;
                      setIsHighContrast(next);
                      localStorage.setItem('omni_high_contrast_v1', String(next));
                      showNotification?.(next ? "High-contrast mode enabled" : "High-contrast mode disabled", "info");
                    }}
                    className={cn(
                      "px-4 py-2 rounded-xl font-black text-xs transition cursor-pointer shadow-md",
                      isHighContrast
                        ? "bg-amber-400 text-slate-950 hover:bg-amber-300"
                        : "bg-slate-700 text-slate-200 hover:bg-slate-600"
                    )}
                  >
                    {isHighContrast ? "Turn Off" : "Turn On"}
                  </button>
                </div>
              </div>

              {/* Preview Box */}
              <div className={cn(
                "p-4 rounded-2xl border space-y-2 transition-all",
                isHighContrast ? "bg-black border-amber-400 text-amber-300 font-bold" : "bg-slate-950 border-slate-800 text-slate-200",
                fontSizeScale === 'xl' ? "text-lg" : fontSizeScale === 'large' ? "text-base" : "text-xs"
              )}>
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs">
                  <span>👁️ Live Readability Preview</span>
                </div>
                <p className="leading-relaxed">
                  "Newton's Second Law defines net force as the rate of change of linear momentum." — Math formula: <code className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300 font-mono">F = m · a</code>
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/60">
              <span className="text-[11px] text-slate-400">Shortcut: Press <code className="text-cyan-300">Ctrl + A</code> anytime.</span>
              <button
                onClick={() => setIsAccessibilityModalOpen(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Custom Action Modal */}
      {isCustomActionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl text-slate-100 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-black">
                  ✨
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Create Custom Quick Action</h3>
                  <p className="text-xs text-slate-400">Define a custom prompt trigger pill for your study sessions</p>
                </div>
              </div>
              <button
                onClick={() => setIsCustomActionModalOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Pill Button Label (e.g. 🔍 Deep Dive)</label>
                <input
                  type="text"
                  value={customActionLabel}
                  onChange={(e) => setCustomActionLabel(e.target.value)}
                  placeholder="e.g. 🔍 Deep Dive"
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500 transition"
                  maxLength={25}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">AI Prompt Trigger</label>
                <textarea
                  value={customActionPrompt}
                  onChange={(e) => setCustomActionPrompt(e.target.value)}
                  placeholder="e.g. Please explain this concept with an interactive analogy, 3 bullet points, and practical examples..."
                  rows={4}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500 transition resize-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setIsCustomActionModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCustomAction}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition cursor-pointer shadow-lg shadow-indigo-600/30"
              >
                Save Action Pill
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pre-emptive Microphone Permission Request & Browser Settings Guide Modal */}
      <AnimatePresence>
        {showMicModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className={cn(
                "w-full max-w-md rounded-3xl p-6 border shadow-2xl space-y-5 text-left relative overflow-hidden",
                theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
              )}
            >
              {/* Background glow accent */}
              <div className="absolute -top-20 -right-20 w-40 h-40 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shadow-inner">
                    <Mic size={24} className="animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-base font-black tracking-tight">Microphone Access & Settings</h3>
                    <p className="text-xs text-slate-400 font-medium">Why microphone permission is needed</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowMicModal(false)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Purpose & Features List */}
              <div className="space-y-3 text-xs">
                <div className="p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/50 space-y-2">
                  <div className="font-extrabold text-indigo-400 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                    <span>Why Microphone Permission is Needed</span>
                  </div>
                  <ul className="space-y-2 text-slate-300">
                    <li className="flex items-start gap-2">
                      <span className="text-indigo-400 font-bold">•</span>
                      <span><strong>Hands-free Dictation:</strong> Speak to dictate text directly into chat or between message lines.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-indigo-400 font-bold">•</span>
                      <span><strong>Voice Doubts & Interruption:</strong> Speak questions directly to the AI tutor during running lectures.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-indigo-400 font-bold">•</span>
                      <span><strong>Speech & Audio Analysis:</strong> Active frequency visualizers and speech-to-text processing.</span>
                    </li>
                  </ul>
                </div>

                {/* Step-by-Step Browser Settings Guide for Permission Denied */}
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 space-y-2">
                  <div className="font-extrabold text-amber-300 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                    <AlertTriangle size={14} />
                    <span>Browser Permission Guide (If Blocked)</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-[11px] text-amber-100/90 leading-relaxed">
                    <li>Look at your browser's address bar at the top of the page.</li>
                    <li>Click the <strong>Lock (🔒)</strong> or <strong>Mic icon</strong> next to the web address.</li>
                    <li>Locate <strong>Microphone</strong> and toggle it to <strong>Allow</strong>.</li>
                    <li>Click <strong>Test & Enable Access</strong> below to verify.</li>
                  </ol>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={async () => {
                    try {
                      if (navigator.mediaDevices?.getUserMedia) {
                        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                        stream.getTracks().forEach(t => t.stop());
                        setMicError(null);
                        showNotification?.("Microphone permission granted successfully!", "success");
                        setShowMicModal(false);
                      } else {
                        showNotification?.("Microphone API not supported in this browser.", "error");
                      }
                    } catch (err: any) {
                      console.warn("Mic test error:", err);
                      setMicError("Microphone permission denied. Follow the browser permission guide above to grant access.");
                      showNotification?.("Microphone access denied. Please allow microphone in browser address bar.", "error");
                    }
                  }}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs shadow-lg shadow-indigo-600/30 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Mic size={16} />
                  <span>Test & Enable Access</span>
                </button>

                <button
                  onClick={() => setShowMicModal(false)}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700 transition-all cursor-pointer"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Screen Recording Playback Modal */}
      <AnimatePresence>
        {showScreenPlaybackModal && screenRecordingUrl && (
          <div className="fixed inset-0 z-[999999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={cn(
                "w-full max-w-2xl rounded-2xl border p-6 shadow-2xl flex flex-col space-y-4",
                theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
              )}
            >
              <div className="flex items-center justify-between border-b pb-3 border-slate-800/30">
                <div className="flex items-center gap-2.5">
                  <Monitor className="text-emerald-500" size={20} />
                  <h3 className="text-base font-black tracking-tight">
                    Captured Session Playback
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowScreenPlaybackModal(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-800/20 text-slate-400 hover:text-slate-100 transition-colors cursor-pointer"
                  title="Close Playback"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="relative aspect-video rounded-xl overflow-hidden bg-black border border-slate-800/40">
                <video
                  src={screenRecordingUrl}
                  controls
                  className="w-full h-full object-contain"
                  autoPlay
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800/30">
                <a
                  href={screenRecordingUrl}
                  download="captured-workspace-session.webm"
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md shadow-emerald-500/20"
                >
                  <Download size={14} />
                  <span>Download Recording</span>
                </a>
                <button
                  type="button"
                  onClick={() => setShowScreenPlaybackModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700/60 transition-all cursor-pointer"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
