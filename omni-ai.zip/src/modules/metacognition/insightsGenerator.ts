import { CalibrationSummary, CalibrationRecord } from './types';
import { generateAIResponse } from '../../lib/gemini';

export interface MetacognitionInsight {
  id: string;
  type: 'dangerous' | 'underconfident' | 'calibrated' | 'weekly_report';
  title: string;
  message: string;
  actionableTopicId?: string;
  priority: 'high' | 'medium' | 'low';
}

/**
 * Generates rule-based instantaneous insights (<10ms execution time)
 */
export function generateInstantInsights(
  overallSummary: CalibrationSummary,
  topicSummaries: CalibrationSummary[]
): MetacognitionInsight[] {
  const insights: MetacognitionInsight[] = [];

  // 1. Identify Overconfident / "Dangerous" Topics
  const dangerousTopics = topicSummaries.filter(t => t.dangerousCount >= 1);
  if (dangerousTopics.length > 0) {
    const primaryDangerous = dangerousTopics[0];
    insights.push({
      id: `insight_dang_${primaryDangerous.topicId}`,
      type: 'dangerous',
      title: `Overconfidence Trap in ${primaryDangerous.topicTitle}`,
      message: `You marked high confidence on ${primaryDangerous.dangerousCount} question(s) in "${primaryDangerous.topicTitle}" that were incorrect. Review these fundamental concepts to fix silent gaps before exams.`,
      actionableTopicId: primaryDangerous.topicId,
      priority: 'high'
    });
  }

  // 2. Identify Underconfident Topics
  const underconfidentTopics = topicSummaries.filter(t => t.underconfidentCount >= 1);
  if (underconfidentTopics.length > 0) {
    const primaryUnderconfident = underconfidentTopics[0];
    insights.push({
      id: `insight_under_${primaryUnderconfident.topicId}`,
      type: 'underconfident',
      title: `Trust Your Intuition in ${primaryUnderconfident.topicTitle}`,
      message: `You got ${primaryUnderconfident.underconfidentCount} question(s) correct in "${primaryUnderconfident.topicTitle}" despite rating low confidence. You understand this better than you think!`,
      actionableTopicId: primaryUnderconfident.topicId,
      priority: 'medium'
    });
  }

  // 3. Overall Calibration Status
  if (overallSummary.calibrationScore >= 0.85) {
    insights.push({
      id: 'insight_calibration_excellent',
      type: 'calibrated',
      title: 'Exceptional Metacognitive Calibration',
      message: `Your calibration score is ${(overallSummary.calibrationScore * 100).toFixed(0)}%! Your confidence levels accurately reflect your actual exam performance.`,
      priority: 'low'
    });
  } else if (overallSummary.avgConfidence > overallSummary.accuracy + 0.15) {
    insights.push({
      id: 'insight_calibration_overconfident',
      type: 'dangerous',
      title: 'General Overconfidence Tendency',
      message: `Your average confidence (${(overallSummary.avgConfidence * 100).toFixed(0)}%) is significantly higher than your accuracy (${(overallSummary.accuracy * 100).toFixed(0)}%). Slow down and double check step-by-step logic.`,
      priority: 'high'
    });
  }

  return insights;
}

/**
 * Generates an AI-powered Weekly Metacognition Report using Gemini
 */
export async function generateWeeklyMetacognitionReport(
  overallSummary: CalibrationSummary,
  topicSummaries: CalibrationSummary[]
): Promise<string> {
  const prompt = `You are a Senior Learning Analytics Engineer writing a brief 3-bullet Weekly Metacognition Report for a student.
  
Student Calibration Profile:
- Total Answered: ${overallSummary.totalAnswers}
- Overall Calibration Score: ${(overallSummary.calibrationScore * 100).toFixed(0)}%
- Accuracy: ${(overallSummary.accuracy * 100).toFixed(0)}%
- Avg Confidence: ${(overallSummary.avgConfidence * 100).toFixed(0)}%
- Mastered Count: ${overallSummary.masteredCount}
- Dangerous (Overconfident & Wrong) Count: ${overallSummary.dangerousCount}
- Underconfident (Surprise Success) Count: ${overallSummary.underconfidentCount}

Topic Breakdown:
${topicSummaries.map(t => `- ${t.topicTitle}: Calibration ${(t.calibrationScore * 100).toFixed(0)}%, Dangerous: ${t.dangerousCount}, Underconfident: ${t.underconfidentCount}`).join('\n')}

Provide 3 bullet points:
1. Executive Metacognition Assessment
2. Key Blind Spots / Dangerous Quadrant Action
3. Encouragement for Underconfident Mastery`;

  try {
    const response = await generateAIResponse(prompt, {
      model: 'gemini-3.8-flash'
    });
    return response;
  } catch {
    return `• Executive Assessment: Your overall metacognitive calibration score stands at ${(overallSummary.calibrationScore * 100).toFixed(0)}%.
• Blind Spot Action: Focus immediate study sessions on ${overallSummary.dangerousCount} high-confidence errors in the Dangerous quadrant.
• Confidence Boost: You achieved ${overallSummary.underconfidentCount} correct answers despite rating low confidence — trust your intuition more!`;
  }
}
