import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, RotateCcw, Volume2, Sparkles, BookOpen, Layers, 
  ArrowRight, Award, Zap, CheckCircle2 
} from 'lucide-react';
import { TranslationService } from '../../i18n/TranslationService';
import { useI18n } from '../../i18n/useI18n';

interface LiteClassroomCanvasProps {
  topic?: string;
  subject?: string;
  isDark?: boolean;
  onVoiceTrigger?: (text: string) => void;
}

export const LiteClassroomCanvas: React.FC<LiteClassroomCanvasProps> = ({
  topic = "Newton's Second Law of Motion",
  subject = "Physics",
  isDark = true,
  onVoiceTrigger
}) => {
  const { language, bilingualMode } = useI18n();
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [appliedForce, setAppliedForce] = useState<number>(50); // Newtons
  const [objectMass, setObjectMass] = useState<number>(10);    // kg

  const calculatedAcceleration = (appliedForce / Math.max(1, objectMass)).toFixed(1);

  const steps = [
    {
      title: "1. The Intuitive Concept",
      text: "Think of an object at rest. If you push it lightly, it moves slowly. If you push it hard with greater force, it accelerates rapidly!",
      subtext: "Force causes acceleration (F ∝ a).",
      formula: "a \\propto F"
    },
    {
      title: "2. The Mass Inertia Factor",
      text: "Now consider pushing a heavy loaded truck versus an empty bicycle with the exact same strength. The lighter object accelerates much faster!",
      subtext: "Acceleration is inversely proportional to mass (a ∝ 1/m).",
      formula: "a \\propto \\frac{1}{m}"
    },
    {
      title: "3. The Master Fundamental Law",
      text: "Combining both discoveries yields Newton's Second Law of Motion: Net Force equals Mass multiplied by Acceleration.",
      subtext: "Direct substitution: F = m · a",
      formula: "F = m \\cdot a \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
    }
  ];

  useEffect(() => {
    let timer: any;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentStep((prev) => (prev + 1) % steps.length);
      }, 4000);
    }
    return () => clearInterval(timer);
  }, [isPlaying, steps.length]);

  const handleSpeak = (text: string) => {
    if (onVoiceTrigger) {
      onVoiceTrigger(text);
    } else {
      TranslationService.speakText(text, language);
    }
  };

  return (
    <div className={`w-full rounded-2xl border flex flex-col overflow-hidden ${
      isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
    }`}>
      {/* 2D Flat Smartboard Header */}
      <div className={`px-4 py-3 border-b flex flex-wrap items-center justify-between gap-2 ${
        isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-slate-50 border-slate-200'
      }`}>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
            2D Lite Pedagogical Slate (Zero-GPU Lag)
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
            RAM: &lt; 90MB | 60 FPS
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            {isPlaying ? <Pause size={12} /> : <Play size={12} />}
            {isPlaying ? 'Pause Step Flow' : 'Auto Lecture'}
          </button>
          <button
            onClick={() => setCurrentStep(0)}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs transition cursor-pointer"
            title="Reset Lesson"
          >
            <RotateCcw size={13} />
          </button>
        </div>
      </div>

      {/* 2D Interactive Blackboard Canvas */}
      <div className="p-6 space-y-6">
        {/* Step Progress Indicators */}
        <div className="grid grid-cols-3 gap-2">
          {steps.map((s, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStep(idx)}
              className={`p-2.5 rounded-xl border text-left transition ${
                currentStep === idx
                  ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 ring-1 ring-indigo-500 font-bold'
                  : isDark ? 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700' : 'bg-slate-50 border-slate-200 text-slate-600'
              }`}
            >
              <div className="text-[11px] truncate">{s.title}</div>
            </button>
          ))}
        </div>

        {/* Current Active Step Presentation */}
        <div className={`p-5 rounded-2xl border space-y-3 ${
          isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-cyan-400 flex items-center gap-2">
              <Sparkles size={16} /> {steps[currentStep].title}
            </h3>
            <button
              onClick={() => handleSpeak(steps[currentStep].text)}
              className="p-1.5 rounded-lg bg-indigo-600/20 text-indigo-400 hover:bg-indigo-600 hover:text-white transition cursor-pointer"
              title="Professor Clarity Spoken Explanation"
            >
              <Volume2 size={14} />
            </button>
          </div>

          <p className="text-sm font-medium leading-relaxed">
            {steps[currentStep].text}
          </p>

          <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 font-mono text-xs text-amber-300 flex items-center justify-between">
            <span>Formula: {steps[currentStep].formula}</span>
            <span className="text-[10px] text-slate-400">{steps[currentStep].subtext}</span>
          </div>
        </div>

        {/* 2D Interactive Flat Physics Simulator */}
        <div className={`p-5 rounded-2xl border space-y-4 ${
          isDark ? 'bg-slate-900/50 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="flex items-center gap-1.5 text-indigo-400">
              <Zap size={14} /> Live 2D Kinematics Sandbox
            </span>
            <span className="text-emerald-400 font-mono">
              Acceleration a = F / m = {calculatedAcceleration} m/s²
            </span>
          </div>

          {/* 2D Vector Visualizer Canvas */}
          <div className="h-24 w-full rounded-xl bg-slate-950 border border-slate-800 relative flex items-center px-8 overflow-hidden">
            <div className="absolute inset-0 bg-grid-slate-900/50" />
            
            {/* Object Mass Block */}
            <div 
              className="h-14 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 border border-blue-400 flex flex-col items-center justify-center text-white shadow-lg transition-all"
              style={{ width: `${Math.max(45, objectMass * 4)}px` }}
            >
              <span className="text-[10px] font-bold">m = {objectMass}kg</span>
            </div>

            {/* Force Vector Arrow */}
            <div className="flex items-center ml-2">
              <div 
                className="h-1 bg-amber-400 transition-all"
                style={{ width: `${Math.min(180, appliedForce * 2)}px` }}
              />
              <div className="w-0 h-0 border-t-[5px] border-t-transparent border-b-[5px] border-b-transparent border-l-[8px] border-l-amber-400" />
              <span className="text-[10px] font-mono text-amber-300 ml-1.5 font-bold">
                F = {appliedForce}N
              </span>
            </div>
          </div>

          {/* Sliders */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <div className="flex justify-between text-slate-400">
                <span>Applied Force (F):</span>
                <span className="font-mono text-amber-300 font-bold">{appliedForce} N</span>
              </div>
              <input
                type="range"
                min="5"
                max="100"
                value={appliedForce}
                onChange={(e) => setAppliedForce(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-400">
                <span>Object Mass (m):</span>
                <span className="font-mono text-blue-300 font-bold">{objectMass} kg</span>
              </div>
              <input
                type="range"
                min="2"
                max="30"
                value={objectMass}
                onChange={(e) => setObjectMass(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
