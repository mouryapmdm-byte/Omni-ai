import React, { useState } from 'react';
import { cn } from '@/src/lib/utils';
import { FileText, Download, Printer, Sparkles, Calculator, BookOpen, ExternalLink, CheckCircle2, RefreshCw } from 'lucide-react';

interface DynamicLabReportProps {
  theme: 'light' | 'dark';
  onOpenChapter: (chapterNum: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const DynamicLabReport: React.FC<DynamicLabReportProps> = ({
  theme,
  onOpenChapter,
  showNotification
}) => {
  const [studentName, setStudentName] = useState('Alex Morgan');
  const [experimentTitle, setExperimentTitle] = useState('Synthesis of Tetraamminecopper(II) Sulfate Monohydrate');
  const [reactantName, setReactantName] = useState('Copper(II) Sulfate Pentahydrate (CuSO₄·5H₂O)');
  const [reactantMass, setReactantMass] = useState<number>(5.0); // grams
  const [molarMassReactant, setMolarMassReactant] = useState<number>(249.69); // g/mol
  const [actualYield, setActualYield] = useState<number>(4.2); // grams
  const [theoreticalMaxYield, setTheoreticalMaxYield] = useState<number>(4.85); // calculated or editable

  const calculatedMoles = Number((reactantMass / molarMassReactant).toFixed(4));
  const percentYield = Number(((actualYield / theoreticalMaxYield) * 100).toFixed(1));

  const handlePrint = () => {
    window.print();
    showNotification?.('Lab report sent to printer / PDF export.', 'success');
  };

  const handleCopyClipboard = () => {
    const reportText = `
FORMAL SCIENTIFIC LAB REPORT
==============================
Student: ${studentName}
Experiment: ${experimentTitle}
Date: ${new Date().toLocaleDateString()}

1. OBJECTIVE & INTRODUCTION
Synthesis and characterization of coordination complexes using stoichiometric principles.

2. CHEMICAL REACTION & STOICHIOMETRY
Reactant: ${reactantName}
Mass Used: ${reactantMass} g
Molar Mass: ${molarMassReactant} g/mol
Moles of Reactant: ${calculatedMoles} mol

3. QUANTITATIVE YIELD CALCULATIONS
Theoretical Maximum Yield: ${theoreticalMaxYield} g
Actual Experimental Yield: ${actualYield} g
Percentage Yield: ${percentYield}%

4. CONCLUSION
The synthesis was successfully conducted with a percentage yield of ${percentYield}%.
    `.trim();

    navigator.clipboard.writeText(reportText);
    showNotification?.('Formal lab report copied to clipboard!', 'success');
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-y-auto p-6 md:p-8 selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-slate-50/50 text-slate-900"
    )}>
      {/* Header Banner */}
      <div className={cn(
        "p-6 rounded-3xl border mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl",
        theme === 'dark' ? "bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/40 border-cyan-900/40" : "bg-gradient-to-r from-cyan-50 via-white to-indigo-50 border-cyan-100"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-cyan-600 to-blue-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-cyan-500/30">
            <FileText size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border border-cyan-500/20">
                Automated Scientific Document Generation
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Dynamic Lab Report Generator
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Input experimental reactants, masses, and yields to instantly format a publication-ready scientific lab report with stoichiometric calculations.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyClipboard}
            className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2.5 rounded-2xl font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
          >
            <Sparkles size={16} />
            <span>Copy Report</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white px-4 py-2.5 rounded-2xl font-bold text-xs transition-all cursor-pointer border border-slate-700"
          >
            <Printer size={16} />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Inputs vs Formatted Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Experimental Inputs */}
        <div className={cn(
          "p-6 md:p-8 rounded-3xl border shadow-xl space-y-5",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-700/60">
            <h3 className="text-lg font-black tracking-tight flex items-center gap-2">
              <Calculator size={18} className="text-cyan-500" />
              <span>Experimental Data Parameters</span>
            </h3>
            <span className="text-xs font-mono font-bold text-cyan-500">Auto-Calculate</span>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="font-black uppercase tracking-wider text-slate-400 block mb-1.5">Student Researcher Name</label>
              <input
                type="text"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                className={cn(
                  "w-full px-4 py-2.5 rounded-2xl border font-bold outline-none",
                  theme === 'dark' ? "bg-slate-900 border-slate-700 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-800 focus:border-cyan-400"
                )}
              />
            </div>

            <div>
              <label className="font-black uppercase tracking-wider text-slate-400 block mb-1.5">Experiment Title</label>
              <input
                type="text"
                value={experimentTitle}
                onChange={(e) => setExperimentTitle(e.target.value)}
                className={cn(
                  "w-full px-4 py-2.5 rounded-2xl border font-bold outline-none",
                  theme === 'dark' ? "bg-slate-900 border-slate-700 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-800 focus:border-cyan-400"
                )}
              />
            </div>

            <div>
              <label className="font-black uppercase tracking-wider text-slate-400 block mb-1.5">Primary Reactant / Starting Material</label>
              <input
                type="text"
                value={reactantName}
                onChange={(e) => setReactantName(e.target.value)}
                className={cn(
                  "w-full px-4 py-2.5 rounded-2xl border font-bold outline-none",
                  theme === 'dark' ? "bg-slate-900 border-slate-700 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-800 focus:border-cyan-400"
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="font-black uppercase tracking-wider text-slate-400 block mb-1.5">Reactant Mass (g)</label>
                <input
                  type="number"
                  step="0.1"
                  value={reactantMass}
                  onChange={(e) => setReactantMass(Number(e.target.value))}
                  className={cn(
                    "w-full px-4 py-2.5 rounded-2xl border font-bold outline-none",
                    theme === 'dark' ? "bg-slate-900 border-slate-700 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-800 focus:border-cyan-400"
                  )}
                />
              </div>
              <div>
                <label className="font-black uppercase tracking-wider text-slate-400 block mb-1.5">Molar Mass (g/mol)</label>
                <input
                  type="number"
                  step="0.01"
                  value={molarMassReactant}
                  onChange={(e) => setMolarMassReactant(Number(e.target.value))}
                  className={cn(
                    "w-full px-4 py-2.5 rounded-2xl border font-bold outline-none",
                    theme === 'dark' ? "bg-slate-900 border-slate-700 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-800 focus:border-cyan-400"
                  )}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="font-black uppercase tracking-wider text-slate-400 block mb-1.5">Theoretical Max Yield (g)</label>
                <input
                  type="number"
                  step="0.01"
                  value={theoreticalMaxYield}
                  onChange={(e) => setTheoreticalMaxYield(Number(e.target.value))}
                  className={cn(
                    "w-full px-4 py-2.5 rounded-2xl border font-bold outline-none",
                    theme === 'dark' ? "bg-slate-900 border-slate-700 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-800 focus:border-cyan-400"
                  )}
                />
              </div>
              <div>
                <label className="font-black uppercase tracking-wider text-slate-400 block mb-1.5">Actual Recovered Yield (g)</label>
                <input
                  type="number"
                  step="0.01"
                  value={actualYield}
                  onChange={(e) => setActualYield(Number(e.target.value))}
                  className={cn(
                    "w-full px-4 py-2.5 rounded-2xl border font-bold outline-none",
                    theme === 'dark' ? "bg-slate-900 border-slate-700 text-white focus:border-cyan-500" : "bg-slate-50 border-slate-200 text-slate-800 focus:border-cyan-400"
                  )}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Formatted Scientific Lab Report Preview */}
        <div className={cn(
          "p-6 md:p-8 rounded-3xl border shadow-xl flex flex-col justify-between font-serif",
          theme === 'dark' ? "bg-slate-800/80 border-slate-700 text-slate-200" : "bg-white border-slate-200 text-slate-900"
        )}>
          <div className="space-y-6">
            {/* Report Document Title Header */}
            <div className="text-center pb-6 border-b border-slate-200 dark:border-slate-700">
              <div className="text-xs font-sans font-bold uppercase tracking-widest text-cyan-600 dark:text-cyan-400 mb-1">
                Formal Scientific Laboratory Report
              </div>
              <h2 className="text-xl md:text-2xl font-black font-sans tracking-tight mb-2">
                {experimentTitle}
              </h2>
              <div className="text-xs font-sans text-slate-500 flex justify-center gap-4">
                <span>Researcher: <strong>{studentName}</strong></span>
                <span>Date: <strong>{new Date().toLocaleDateString()}</strong></span>
              </div>
            </div>

            {/* Section 1: Objective */}
            <div className="space-y-2 text-xs font-sans">
              <h4 className="font-black uppercase tracking-wider text-cyan-600 dark:text-cyan-400">1. Objective & Introduction</h4>
              <p className="leading-relaxed text-slate-600 dark:text-slate-300">
                To synthesize and quantify the percentage yield of coordination complexes through precise gravimetric and volumetric titration methods.
              </p>
            </div>

            {/* Section 2: Stoichiometric Calculations */}
            <div className="space-y-2 text-xs font-sans">
              <h4 className="font-black uppercase tracking-wider text-cyan-600 dark:text-cyan-400">2. Stoichiometric Calculations</h4>
              <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 space-y-1.5 font-mono">
                <div>Reactant Used: {reactantName}</div>
                <div>Mass: {reactantMass} g | Molar Mass: {molarMassReactant} g/mol</div>
                <div>Calculated Moles: <span className="text-cyan-500 font-bold">{calculatedMoles} mol</span></div>
              </div>
            </div>

            {/* Section 3: Results & Yield Analysis */}
            <div className="space-y-2 text-xs font-sans">
              <h4 className="font-black uppercase tracking-wider text-cyan-600 dark:text-cyan-400">3. Results & Percentage Yield</h4>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Theoretical Yield</div>
                  <div className="text-base font-black font-mono">{theoreticalMaxYield} g</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Actual Recovered Yield</div>
                  <div className="text-base font-black font-mono text-cyan-500">{actualYield} g</div>
                </div>
              </div>
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-center">
                <div className="text-xs text-cyan-600 dark:text-cyan-400 font-bold uppercase tracking-wider">Calculated Percentage Yield</div>
                <div className="text-3xl font-black font-mono text-cyan-600 dark:text-cyan-400 mt-1">{percentYield}%</div>
              </div>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-sans">
            <div className="flex items-center gap-1.5 font-bold text-cyan-600 dark:text-cyan-400">
              <BookOpen size={14} />
              <span>Publication-Ready Format</span>
            </div>
            <button
              onClick={() => onOpenChapter(9)}
              className="flex items-center gap-1 bg-cyan-50 hover:bg-cyan-600 text-cyan-600 hover:text-white dark:bg-cyan-950/60 dark:hover:bg-cyan-600 dark:text-cyan-300 font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              <span>Read Chapters</span>
              <ExternalLink size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
TargetFile: `/src/components/DynamicLabReport.tsx`
Overwrite: true
toolSummary: 'Create dynamic lab report component'
toolAction: 'Creating DynamicLabReport component'
