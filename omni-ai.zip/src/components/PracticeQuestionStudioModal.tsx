import React, { useState, useMemo } from 'react';
import {
  X,
  BookOpen,
  HelpCircle,
  Lightbulb,
  CheckCircle2,
  AlertCircle,
  Award,
  ChevronRight,
  ChevronDown,
  Sparkles,
  Volume2,
  Download,
  Copy,
  Check,
  BrainCircuit,
  Filter,
  Layers,
  ArrowRight,
  RefreshCw,
  Flame
} from 'lucide-react';
import { 
  PracticeQuestionPackage, 
  PracticeQuestionItem, 
  QuestionType, 
  generateComprehensiveQuestionPackage 
} from '../lib/practiceQuestionEngine';
import { playChalkSound } from '../lib/chalkAudio';

interface PracticeQuestionStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicTitle: string;
  subjectTitle?: string;
  subject?: string;
  initialMode?: 'academic' | 'competitive';
  theme?: 'light' | 'dark';
  onSpeak?: (text: string) => void;
  showNotification?: (message: string, type: 'info' | 'success' | 'warning' | 'error') => void;
  onSyncToSmartboard?: (markdownText: string, title?: string) => void;
}

export const PracticeQuestionStudioModal: React.FC<PracticeQuestionStudioModalProps> = ({
  isOpen,
  onClose,
  topicTitle,
  subjectTitle,
  subject = 'STEM',
  initialMode = 'academic',
  theme = 'dark',
  onSpeak,
  showNotification,
  onSyncToSmartboard
}) => {
  const [studyMode, setStudyMode] = useState<'academic' | 'competitive'>(initialMode);
  const [activeTab, setActiveTab] = useState<'taught' | 'suggested' | 'mcq_lab' | 'breakdown'>('taught');
  const [selectedType, setSelectedType] = useState<QuestionType | 'all'>('all');
  const [activeQuestionId, setActiveQuestionId] = useState<string | null>(null);
  
  // Hint reveal levels: questionId -> current revealed level (0 = none, 1 = gentle, 2 = partial, 3 = strong, 4 = final)
  const [revealedHints, setRevealedHints] = useState<Record<string, number>>({});
  const [studentAnswers, setStudentAnswers] = useState<Record<string, string>>({});
  const [solvedQuestions, setSolvedQuestions] = useState<Record<string, boolean>>({});
  
  // MCQ Lab state
  const [mcqAnswers, setMcqAnswers] = useState<Record<string, 'A' | 'B' | 'C' | 'D'>>({});
  const [eliminatedOptions, setEliminatedOptions] = useState<Record<string, string[]>>({});
  
  // Copy state
  const [copied, setCopied] = useState(false);

  // Generate question package
  const pkg: PracticeQuestionPackage = useMemo(() => {
    return generateComprehensiveQuestionPackage(topicTitle, subject, studyMode);
  }, [topicTitle, subject, studyMode]);

  if (!isOpen) return null;

  // Flattened questions based on active tab and filter
  const currentQuestions: PracticeQuestionItem[] = useMemo(() => {
    let list: PracticeQuestionItem[] = [];
    pkg.categories.forEach(cat => {
      if (selectedType !== 'all' && cat.type !== selectedType) return;
      if (activeTab === 'taught') {
        list.push(...cat.taughtQuestions);
      } else if (activeTab === 'suggested') {
        list.push(...cat.suggestedQuestions);
      } else if (activeTab === 'mcq_lab') {
        if (cat.type === 'mcq_4_options') {
          list.push(...cat.taughtQuestions);
        }
      }
    });
    return list;
  }, [pkg, activeTab, selectedType]);

  const activeQuestion = currentQuestions.find(q => q.id === activeQuestionId) || currentQuestions[0] || null;

  const handleNextHint = (qId: string) => {
    playChalkSound('scratch');
    setRevealedHints(prev => {
      const current = prev[qId] || 0;
      return { ...prev, [qId]: Math.min(4, current + 1) };
    });
  };

  const handleToggleEliminate = (qId: string, optKey: string) => {
    setEliminatedOptions(prev => {
      const current = prev[qId] || [];
      if (current.includes(optKey)) {
        return { ...prev, [qId]: current.filter(k => k !== optKey) };
      } else {
        return { ...prev, [qId]: [...current, optKey] };
      }
    });
  };

  const handleSelectMcq = (qId: string, optKey: 'A' | 'B' | 'C' | 'D') => {
    setMcqAnswers(prev => ({ ...prev, [qId]: optKey }));
  };

  const handleCopyMarkdown = () => {
    let md = `# 📝 Professor Clarity Practice Question Vault: ${pkg.topicTitle}\n`;
    md += `Mode: ${pkg.studyMode.toUpperCase()} | Total Questions: ${pkg.grandTotalCount}\n\n`;
    
    pkg.categories.forEach(cat => {
      md += `## 📌 ${cat.title} (${cat.marksPerQuestion})\n`;
      md += `### 🎓 Taught by Professor Clarity (${cat.taughtCount} Questions):\n`;
      cat.taughtQuestions.forEach((q, idx) => {
        md += `**Q${idx + 1}: ${q.question}**\n`;
        md += `✅ *Model Answer*: ${q.modelAnswer}\n\n`;
      });
      md += `### 💡 Suggested for Student Practice (${cat.suggestedCount} Questions):\n`;
      cat.suggestedQuestions.forEach((q, idx) => {
        md += `**Q${idx + 1}: ${q.question}**\n`;
        md += `💡 *Hint*: ${q.hints.level2}\n`;
        md += `📝 *Final Answer*: ${q.finalAnswer}\n\n`;
      });
    });

    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        id="practice-question-studio-modal"
        className="flex flex-col w-full max-w-6xl h-[92vh] bg-slate-950 border border-cyan-500/30 rounded-2xl shadow-2xl overflow-hidden text-slate-100"
      >
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between px-6 py-4 bg-slate-900/90 border-b border-slate-800 gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/40 rounded-xl text-cyan-400">
              <BrainCircuit className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg font-bold text-white tracking-wide">
                  Practice Question & Pedagogy Vault
                </h2>
                <span className="px-2.5 py-0.5 text-xs font-semibold rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  {pkg.studyMode === 'academic' ? '80–160 Academic Questions' : '420–580 Competitive Questions'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Topic: <span className="text-cyan-300 font-medium">{pkg.topicTitle}</span> • {pkg.subject}
              </p>
            </div>
          </div>

          {/* Mode Switcher & Actions */}
          <div className="flex items-center space-x-3">
            {/* Academic vs Competitive Toggle */}
            <div className="flex items-center p-1 bg-slate-950 border border-slate-700/80 rounded-xl">
              <button
                id="btn-switch-academic-mode"
                onClick={() => setStudyMode('academic')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                  studyMode === 'academic'
                    ? 'bg-cyan-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                📘 Academic ({pkg.studyMode === 'academic' ? pkg.grandTotalCount : '80–160'})
              </button>
              <button
                id="btn-switch-competitive-mode"
                onClick={() => setStudyMode('competitive')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center space-x-1.5 ${
                  studyMode === 'competitive'
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-amber-300" />
                <span>Competitive ({pkg.studyMode === 'competitive' ? pkg.grandTotalCount : '420–580'})</span>
              </button>
            </div>

            <button
              id="btn-copy-question-vault"
              onClick={handleCopyMarkdown}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium rounded-lg text-slate-200 transition-colors"
              title="Copy All Questions as Markdown"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
              <span>{copied ? 'Copied!' : 'Export'}</span>
            </button>

            <button
              id="btn-close-practice-studio"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center justify-between px-6 py-2 bg-slate-900/60 border-b border-slate-800/80">
          <div className="flex space-x-2">
            <button
              id="tab-taught-questions"
              onClick={() => { setActiveTab('taught'); setSelectedType('all'); }}
              className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'taught'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <BookOpen className="w-4 h-4 text-cyan-400" />
              <span>1. Taught Questions ({pkg.totalTaughtCount})</span>
            </button>

            <button
              id="tab-suggested-questions"
              onClick={() => { setActiveTab('suggested'); setSelectedType('all'); }}
              className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'suggested'
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Lightbulb className="w-4 h-4 text-amber-400" />
              <span>2. Suggested Practice & 4-Tier Hints ({pkg.totalSuggestedCount})</span>
            </button>

            {studyMode === 'competitive' && (
              <button
                id="tab-mcq-lab"
                onClick={() => { setActiveTab('mcq_lab'); setSelectedType('mcq_4_options'); }}
                className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'mcq_lab'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Award className="w-4 h-4 text-amber-400" />
                <span>3. 50 MCQs & Elimination Lab</span>
              </button>
            )}

            <button
              id="tab-breakdown-matrix"
              onClick={() => setActiveTab('breakdown')}
              className={`flex items-center space-x-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'breakdown'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Layers className="w-4 h-4 text-emerald-400" />
              <span>4. Master Quantity Breakdown</span>
            </button>
          </div>

          {/* Filter by Category */}
          {activeTab !== 'breakdown' && (
            <div className="flex items-center space-x-2">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                id="select-question-category-filter"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value as any)}
                className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-500"
              >
                <option value="all">All 8–9 Question Types</option>
                {pkg.categories.map(cat => (
                  <option key={cat.type} value={cat.type}>
                    {cat.title} ({activeTab === 'taught' ? cat.taughtCount : cat.suggestedCount})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
          {/* Main Question Explorer (Taught / Suggested / MCQ Lab) */}
          {activeTab !== 'breakdown' ? (
            <>
              {/* Question Sidebar List */}
              <div className="w-full md:w-80 lg:w-96 border-r border-slate-800 bg-slate-950/70 overflow-y-auto p-3 space-y-2">
                <div className="text-xs font-semibold text-slate-400 px-2 uppercase tracking-wider">
                  {activeTab === 'taught' ? 'Step-by-Step Taught Deck' : activeTab === 'suggested' ? 'Suggested Practice Deck' : '50 Competitive MCQs'} ({currentQuestions.length})
                </div>
                
                {currentQuestions.map((q, idx) => {
                  const isSelected = (activeQuestion?.id === q.id);
                  const isSolved = solvedQuestions[q.id];
                  const hintCount = revealedHints[q.id] || 0;

                  return (
                    <button
                      key={q.id}
                      id={`btn-question-item-${q.id}`}
                      onClick={() => {
                        setActiveQuestionId(q.id);
                        playChalkSound('scratch');
                      }}
                      className={`w-full text-left p-3 rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-cyan-950/50 border-cyan-500/60 shadow-md ring-1 ring-cyan-500/30'
                          : 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-800/60 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-slate-800 text-cyan-300">
                          Q{idx + 1} • {q.typeLabel.split(' ')[0]}
                        </span>
                        <div className="flex items-center space-x-1.5 text-[11px] text-slate-400">
                          {activeTab === 'suggested' && hintCount > 0 && (
                            <span className="flex items-center space-x-0.5 text-amber-400 font-semibold">
                              <Lightbulb className="w-3 h-3" />
                              <span>L{hintCount}</span>
                            </span>
                          )}
                          <span>{q.marks} {q.marks === 1 ? 'Mark' : 'Marks'}</span>
                        </div>
                      </div>
                      <p className="text-xs text-slate-200 line-clamp-2 font-medium">
                        {q.question}
                      </p>
                    </button>
                  );
                })}
              </div>

              {/* Active Question Display & Interactive Practice Area */}
              <div className="flex-1 overflow-y-auto p-6 bg-slate-950">
                {activeQuestion ? (
                  <div className="max-w-3xl mx-auto space-y-6">
                    {/* Question Card Header */}
                    <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-900/80 border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="px-3 py-1 bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-bold">
                            {activeQuestion.typeLabel}
                          </span>
                          <span className="text-xs text-slate-400">
                            Weightage: {activeQuestion.marks} {activeQuestion.marks === 1 ? 'Mark' : 'Marks'}
                          </span>
                        </div>
                        {onSpeak && activeQuestion.spokenTeachingScript && (
                          <button
                            id="btn-speak-question-solution"
                            onClick={() => onSpeak(activeQuestion.spokenTeachingScript!)}
                            className="flex items-center space-x-1 px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-semibold shadow transition-all"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>Teach Voice</span>
                          </button>
                        )}
                      </div>

                      <h3 className="text-base sm:text-lg font-bold text-white leading-relaxed">
                        {activeQuestion.question}
                      </h3>

                      {/* If diagram based, show diagram labels */}
                      {activeQuestion.diagramLabels && (
                        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
                          <div className="text-xs font-semibold text-cyan-400 mb-2">Diagram Structural Nodes:</div>
                          <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
                            {activeQuestion.diagramLabels.map(l => (
                              <div key={l.id} className="flex items-center space-x-1.5 p-1.5 bg-slate-900 rounded border border-slate-800">
                                <span className="w-5 h-5 rounded-full bg-cyan-600 text-white font-bold flex items-center justify-center text-[10px]">
                                  {l.id}
                                </span>
                                <span>{l.label}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* If Match the following, show column A & B */}
                      {activeQuestion.matchingPairs && (
                        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
                          <div className="text-xs font-semibold text-cyan-400 mb-2">Match Table:</div>
                          <div className="space-y-1.5 text-xs text-slate-300">
                            {activeQuestion.matchingPairs.map((p, pIdx) => (
                              <div key={pIdx} className="flex items-center justify-between p-2 bg-slate-900 rounded border border-slate-800">
                                <span className="font-semibold text-slate-200">{p.itemA}</span>
                                <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                                <span className="text-cyan-300">{p.itemB}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* =================================================== */}
                    {/* TAUGHT MODE: Professor Clarity Step-by-Step Model Answer */}
                    {/* =================================================== */}
                    {activeTab === 'taught' && (
                      <div className="space-y-4 animate-in fade-in duration-150">
                        {activeQuestion.spokenTeachingScript && (
                          <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/30 space-y-2">
                            <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
                              <Sparkles className="w-4 h-4" />
                              <span>Professor Clarity Spoken Teaching:</span>
                            </div>
                            <p className="text-sm text-cyan-100 italic leading-relaxed">
                              "{activeQuestion.spokenTeachingScript}"
                            </p>
                          </div>
                        )}

                        <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                          <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Step-by-Step Model Solution:</span>
                          </div>
                          <div className="text-sm text-slate-200 whitespace-pre-line leading-relaxed font-mono bg-slate-950 p-4 rounded-lg border border-slate-800">
                            {activeQuestion.modelAnswer}
                          </div>
                        </div>

                        {activeQuestion.markingScheme && activeQuestion.markingScheme.length > 0 && (
                          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                              📋 Examiner Marking Scheme:
                            </div>
                            <ul className="text-xs text-slate-300 space-y-1">
                              {activeQuestion.markingScheme.map((ms, mIdx) => (
                                <li key={mIdx} className="flex items-start space-x-2">
                                  <span className="text-cyan-400 font-bold">•</span>
                                  <span>{ms}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}

                    {/* =================================================== */}
                    {/* SUGGESTED MODE: 4-Tier Answer Hint Progressive Revealer */}
                    {/* =================================================== */}
                    {activeTab === 'suggested' && (
                      <div className="space-y-4 animate-in fade-in duration-150">
                        {/* Student Scratchpad Input */}
                        <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                            <span>Your Solution / Answer Notes:</span>
                            <span className="text-[11px] text-slate-400">Solve independently before checking hints</span>
                          </label>
                          <textarea
                            id={`textarea-student-scratchpad-${activeQuestion.id}`}
                            rows={3}
                            value={studentAnswers[activeQuestion.id] || ''}
                            onChange={(e) => setStudentAnswers({ ...studentAnswers, [activeQuestion.id]: e.target.value })}
                            placeholder="Type your formula derivation, keywords, or final answer here..."
                            className="w-full bg-slate-950 border border-slate-700/80 rounded-lg p-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                          />
                        </div>

                        {/* 4-Tier Progressive Hints Panel */}
                        <div className="p-5 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Lightbulb className="w-5 h-5 text-amber-400 animate-pulse" />
                              <span className="text-sm font-bold text-amber-300">
                                4-Level Progressive Answer Hints System
                              </span>
                            </div>
                            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                              Level {revealedHints[activeQuestion.id] || 0} / 4 Revealed
                            </span>
                          </div>

                          {/* Level 1 Hint */}
                          {(revealedHints[activeQuestion.id] || 0) >= 1 && (
                            <div className="p-3 bg-amber-950/30 border border-amber-500/40 rounded-xl space-y-1 animate-in fade-in duration-200">
                              <div className="text-xs font-bold text-amber-300 flex items-center space-x-1.5">
                                <span>💡 Level 1: Gentle Nudge</span>
                              </div>
                              <p className="text-xs text-amber-100">{activeQuestion.hints.level1}</p>
                            </div>
                          )}

                          {/* Level 2 Hint */}
                          {(revealedHints[activeQuestion.id] || 0) >= 2 && (
                            <div className="p-3 bg-amber-950/40 border border-amber-500/50 rounded-xl space-y-1 animate-in fade-in duration-200">
                              <div className="text-xs font-bold text-amber-300 flex items-center space-x-1.5">
                                <span>💡 Level 2: Partial Answer & Core Formula</span>
                              </div>
                              <p className="text-xs text-amber-100">{activeQuestion.hints.level2}</p>
                            </div>
                          )}

                          {/* Level 3 Hint */}
                          {(revealedHints[activeQuestion.id] || 0) >= 3 && (
                            <div className="p-3 bg-amber-950/50 border border-amber-500/60 rounded-xl space-y-1 animate-in fade-in duration-200">
                              <div className="text-xs font-bold text-amber-300 flex items-center space-x-1.5">
                                <span>💡 Level 3: Strong Hint & Elimination</span>
                              </div>
                              <p className="text-xs text-amber-100">{activeQuestion.hints.level3}</p>
                            </div>
                          )}

                          {/* Level 4 / Final Answer */}
                          {(revealedHints[activeQuestion.id] || 0) >= 4 && (
                            <div className="p-4 bg-emerald-950/40 border border-emerald-500/60 rounded-xl space-y-1 animate-in fade-in duration-200">
                              <div className="text-xs font-bold text-emerald-400 flex items-center space-x-1.5">
                                <CheckCircle2 className="w-4 h-4" />
                                <span>📝 Final Answer for Self-Verification:</span>
                              </div>
                              <div className="text-sm font-semibold text-emerald-100 whitespace-pre-line">
                                {activeQuestion.finalAnswer}
                              </div>
                            </div>
                          )}

                          {/* Reveal Next Hint Button */}
                          {(revealedHints[activeQuestion.id] || 0) < 4 && (
                            <button
                              id={`btn-reveal-next-hint-${activeQuestion.id}`}
                              onClick={() => handleNextHint(activeQuestion.id)}
                              className="w-full py-2.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg transition-all"
                            >
                              <Lightbulb className="w-4 h-4" />
                              <span>
                                Reveal Level {(revealedHints[activeQuestion.id] || 0) + 1} Hint
                              </span>
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {/* =================================================== */}
                    {/* COMPETITIVE MCQ & ELIMINATION LAB */}
                    {/* =================================================== */}
                    {activeTab === 'mcq_lab' && activeQuestion.options && (
                      <div className="space-y-4 animate-in fade-in duration-150">
                        <div className="text-xs font-semibold text-slate-400 flex items-center justify-between">
                          <span>Elimination Lab: Click option to select, or cross out distractors</span>
                          <span className="text-amber-400">+4 Correct / -1 Incorrect</span>
                        </div>

                        <div className="space-y-2.5">
                          {activeQuestion.options.map((opt) => {
                            const isSelected = mcqAnswers[activeQuestion.id] === opt.key;
                            const isEliminated = (eliminatedOptions[activeQuestion.id] || []).includes(opt.key);

                            return (
                              <div
                                key={opt.key}
                                className={`flex items-center justify-between p-3.5 rounded-xl border transition-all ${
                                  isEliminated
                                    ? 'bg-slate-950 border-rose-900/40 opacity-40 line-through'
                                    : isSelected
                                    ? 'bg-amber-950/40 border-amber-500 shadow-md'
                                    : 'bg-slate-900/80 border-slate-800 hover:bg-slate-800/80'
                                }`}
                              >
                                <button
                                  id={`btn-mcq-opt-${activeQuestion.id}-${opt.key}`}
                                  onClick={() => handleSelectMcq(activeQuestion.id, opt.key as any)}
                                  disabled={isEliminated}
                                  className="flex-1 flex items-center space-x-3 text-left"
                                >
                                  <span className={`w-7 h-7 rounded-lg font-bold flex items-center justify-center text-xs ${
                                    isSelected
                                      ? 'bg-amber-500 text-slate-950'
                                      : 'bg-slate-800 text-slate-300'
                                  }`}>
                                    {opt.key}
                                  </span>
                                  <span className="text-sm font-medium text-slate-100">
                                    {opt.text}
                                  </span>
                                </button>

                                <button
                                  id={`btn-eliminate-opt-${activeQuestion.id}-${opt.key}`}
                                  onClick={() => handleToggleEliminate(activeQuestion.id, opt.key)}
                                  className={`px-2.5 py-1 text-[11px] rounded-lg font-semibold border transition-all ${
                                    isEliminated
                                      ? 'bg-rose-900/40 text-rose-300 border-rose-700'
                                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-rose-300 hover:border-rose-500/50'
                                  }`}
                                >
                                  {isEliminated ? 'Restore' : 'Strike Out'}
                                </button>
                              </div>
                            );
                          })}
                        </div>

                        {/* Elimination Explanations if available */}
                        {activeQuestion.eliminationTechnique && (
                          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                            <div className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                              ⚡ Professor Clarity 5-Second Elimination Logic:
                            </div>
                            <ul className="text-xs text-slate-300 space-y-1.5">
                              {activeQuestion.eliminationTechnique.map((e, eIdx) => (
                                <li key={eIdx} className="flex items-start space-x-2">
                                  <span className="text-amber-400 font-bold">•</span>
                                  <span>{e}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-slate-500 space-y-2">
                    <HelpCircle className="w-8 h-8" />
                    <p className="text-sm">Select a question from the sidebar to start practicing</p>
                  </div>
                )}
              </div>
            </>
          ) : (
            /* =================================================== */
            /* MASTER QUANTITY BREAKDOWN TAB */
            /* =================================================== */
            <div className="flex-1 overflow-y-auto p-6 bg-slate-950 space-y-6">
              <div className="max-w-4xl mx-auto space-y-6">
                <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-blue-950/40 to-slate-900 border border-cyan-500/30">
                  <h3 className="text-base font-bold text-white mb-2">
                    📊 Comprehensive Question Quantity Matrix: {pkg.studyMode === 'academic' ? 'Academic Study (80–160 Questions)' : 'Competitive Entrance (420–580 Questions)'}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Professor Clarity ensures every topic has complete mastery through both step-by-step taught solutions and suggested practice with 4-tier progressive answer hints.
                  </p>
                </div>

                <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-900 border-b border-slate-800 text-slate-300">
                        <th className="p-3.5 font-bold">#</th>
                        <th className="p-3.5 font-bold">Question Category</th>
                        <th className="p-3.5 font-bold">Weightage</th>
                        <th className="p-3.5 font-bold text-cyan-400">Taught by Professor</th>
                        <th className="p-3.5 font-bold text-amber-400">Suggested with Hints</th>
                        <th className="p-3.5 font-bold text-emerald-400">Total per Type</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-200">
                      {pkg.categories.map((cat, idx) => (
                        <tr key={cat.type} className="hover:bg-slate-800/40 transition-colors">
                          <td className="p-3.5 font-bold text-slate-500">{idx + 1}</td>
                          <td className="p-3.5 font-semibold text-slate-100">{cat.title}</td>
                          <td className="p-3.5 text-slate-400">{cat.marksPerQuestion}</td>
                          <td className="p-3.5 font-bold text-cyan-300">{cat.taughtCount} Questions</td>
                          <td className="p-3.5 font-bold text-amber-300">{cat.suggestedCount} Questions</td>
                          <td className="p-3.5 font-bold text-emerald-300">{cat.taughtCount + cat.suggestedCount} Questions</td>
                        </tr>
                      ))}
                      <tr className="bg-slate-900/90 font-bold border-t-2 border-cyan-500/40 text-sm">
                        <td colSpan={3} className="p-3.5 text-white">Grand Total Question Bank</td>
                        <td className="p-3.5 text-cyan-300">{pkg.totalTaughtCount} Taught</td>
                        <td className="p-3.5 text-amber-300">{pkg.totalSuggestedCount} Suggested</td>
                        <td className="p-3.5 text-emerald-300">{pkg.grandTotalCount} Questions</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="flex items-center justify-between px-6 py-3 bg-slate-900/90 border-t border-slate-800 text-xs text-slate-400">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Professor Clarity Active Pedagogy Engine Active</span>
          </div>
          <div className="text-slate-400">
            Current Deck: <span className="text-cyan-300 font-semibold">{pkg.grandTotalCount} Total Questions Loaded</span>
          </div>
        </div>
      </div>
    </div>
  );
};
