/**
 * useDeepState.ts
 * ==========================================
 * PROFESSOR CLARITY STATE ARCHITECTURE SUITE
 * 
 * Provides:
 *  1. useDeepState: Enhanced state hook with internal microtask queue & depth circuit-breaker
 *  2. useBatchedUpdates: Coalesces multi-step state mutations into a single microtask
 *  3. useDeferredUpdates: Prioritizes critical UI updates while deferring non-critical visual states
 *  4. useFrameBatchedUpdates: Synchronizes high-frequency 3D/smartboard transforms with requestAnimationFrame
 *  5. useDepthMonitor: Real-time update depth tracking & telemetry
 *  6. useAutoDepthManagement: Safe state dispatcher preventing 'Maximum update depth exceeded'
 *  7. useClassroomStateManager: Master reducer-based state orchestrator with batchDispatch
 *  8. useSafeEffect: Loop-guarded useEffect replacement that detects and mitigates infinite cascading re-renders
 */

import {
  useState,
  useRef,
  useCallback,
  useEffect,
  useReducer,
  useMemo,
  type DependencyList,
  type EffectCallback,
} from 'react';
import {
  ClassroomState,
  ClassroomAction,
  classroomReducer,
  initialClassroomState,
  depthMonitor,
  globalMicrotaskBatcher,
  globalFrameBatcher,
} from '../lib/deepStateManager';

// ---------------------------------------------------------------------------
// 1. useDeepState HOOK
// ---------------------------------------------------------------------------

/**
 * useDeepState — Allows deep cascade updates without hitting React's 50-update depth limit.
 * Immediately updates the synchronous ref and queues React setState into a consolidated microtask batch.
 */
export function useDeepState<T>(initialValue: T | (() => T), stateName?: string) {
  const [state, setState] = useState<T>(initialValue);
  const stateRef = useRef<T>(state);
  const updateQueueRef = useRef<Array<(current: T) => T>>([]);
  const isProcessingRef = useRef<boolean>(false);
  const depthCountRef = useRef<number>(0);

  // Sync ref when state changes
  stateRef.current = state;

  const deepSetState = useCallback((newValue: T | ((prev: T) => T)) => {
    // 1. Immediately calculate latest value on the ref
    let resolvedValue: T;
    if (typeof newValue === 'function') {
      resolvedValue = (newValue as (prev: T) => T)(stateRef.current);
    } else {
      resolvedValue = newValue;
    }
    stateRef.current = resolvedValue;

    // 2. Queue the updater
    updateQueueRef.current.push(() => resolvedValue);

    // 3. Process via microtask batcher
    if (!isProcessingRef.current) {
      isProcessingRef.current = true;
      depthMonitor.increment();
      depthCountRef.current++;

      Promise.resolve().then(() => {
        isProcessingRef.current = false;
        const lastValue = stateRef.current;
        updateQueueRef.current = [];
        depthCountRef.current = 0;
        depthMonitor.decrement();

        setState(lastValue);
      });
    }
  }, [stateName]);

  return [state, deepSetState, stateRef] as const;
}

// ---------------------------------------------------------------------------
// 2. useBatchedUpdates HOOK
// ---------------------------------------------------------------------------

/**
 * useBatchedUpdates — Queues multiple state setter callbacks and executes them in a single batch.
 */
export function useBatchedUpdates() {
  const queuedUpdatesRef = useRef<Array<() => void>>([]);
  const processingRef = useRef(false);

  const queueUpdate = useCallback((update: () => void) => {
    queuedUpdatesRef.current.push(update);

    if (!processingRef.current) {
      processingRef.current = true;
      depthMonitor.increment();

      Promise.resolve().then(() => {
        const updates = queuedUpdatesRef.current;
        queuedUpdatesRef.current = [];
        processingRef.current = false;
        depthMonitor.decrement();

        // Execute all updates in a single tick
        updates.forEach(fn => {
          try {
            fn();
          } catch (err) {
            console.error('[useBatchedUpdates] Error in queued update:', err);
          }
        });
      });
    }
  }, []);

  return { queueUpdate, batch: queueUpdate };
}

// ---------------------------------------------------------------------------
// 3. useDeferredUpdates HOOK
// ---------------------------------------------------------------------------

/**
 * useDeferredUpdates — Executes high-priority updates immediately and defers low-priority visual effects.
 */
export function useDeferredUpdates() {
  const pendingUpdatesRef = useRef<Array<() => void>>([]);
  const frameScheduledRef = useRef(false);

  const deferUpdate = useCallback((update: () => void, priority: 'high' | 'low' = 'low') => {
    if (priority === 'high') {
      update();
    } else {
      pendingUpdatesRef.current.push(update);
      if (!frameScheduledRef.current) {
        frameScheduledRef.current = true;
        requestAnimationFrame(() => {
          const updates = pendingUpdatesRef.current;
          pendingUpdatesRef.current = [];
          frameScheduledRef.current = false;
          updates.forEach(fn => {
            try {
              fn();
            } catch (err) {
              console.error('[useDeferredUpdates] Error in deferred update:', err);
            }
          });
        });
      }
    }
  }, []);

  return { deferUpdate };
}

// ---------------------------------------------------------------------------
// 4. useFrameBatchedUpdates HOOK
// ---------------------------------------------------------------------------

/**
 * useFrameBatchedUpdates — Batches high-frequency 3D render loop mutations per animation frame.
 */
export function useFrameBatchedUpdates() {
  const pendingUpdatesRef = useRef<Array<() => void>>([]);
  const frameScheduledRef = useRef(false);

  const batchUpdate = useCallback((update: () => void) => {
    pendingUpdatesRef.current.push(update);

    if (!frameScheduledRef.current) {
      frameScheduledRef.current = true;

      requestAnimationFrame(() => {
        const updates = pendingUpdatesRef.current;
        pendingUpdatesRef.current = [];
        frameScheduledRef.current = false;

        updates.forEach(fn => {
          try {
            fn();
          } catch (err) {
            console.error('[useFrameBatchedUpdates] Error in frame update:', err);
          }
        });
      });
    }
  }, []);

  return { batchUpdate };
}

// ---------------------------------------------------------------------------
// 5. useDepthMonitor HOOK
// ---------------------------------------------------------------------------

/**
 * useDepthMonitor — Real-time telemetry for tracking and asserting update depth.
 */
export function useDepthMonitor() {
  const depthRef = useRef(0);
  const maxDepthRef = useRef(0);

  const incrementDepth = useCallback(() => {
    depthRef.current++;
    if (depthRef.current > maxDepthRef.current) {
      maxDepthRef.current = depthRef.current;
    }
    if (depthRef.current > 40 && process.env.NODE_ENV !== 'production') {
      console.warn(`[useDepthMonitor] Approaching React update depth threshold: ${depthRef.current}`);
    }
  }, []);

  const decrementDepth = useCallback(() => {
    if (depthRef.current > 0) depthRef.current--;
  }, []);

  const getDepthReport = useCallback(() => {
    return {
      currentDepth: depthRef.current,
      maxDepth: maxDepthRef.current,
      isNearLimit: depthRef.current >= 40,
    };
  }, []);

  return { incrementDepth, decrementDepth, getDepthReport };
}

// ---------------------------------------------------------------------------
// 6. useAutoDepthManagement HOOK
// ---------------------------------------------------------------------------

/**
 * useAutoDepthManagement — Safe state update wrapper that prevents recursion and breaks circular cascades.
 */
export function useAutoDepthManagement() {
  const { incrementDepth, decrementDepth, getDepthReport } = useDepthMonitor();

  const safeSetState = useCallback((setStateFn: () => void) => {
    incrementDepth();
    try {
      setStateFn();
    } finally {
      decrementDepth();
    }
  }, [incrementDepth, decrementDepth]);

  return { safeSetState, getDepthReport };
}

// ---------------------------------------------------------------------------
// 7. useClassroomStateManager HOOK
// ---------------------------------------------------------------------------

/**
 * useClassroomStateManager — Master depth-optimized classroom state reducer with batchDispatch.
 */
export function useClassroomStateManager(customInitialState?: Partial<ClassroomState>) {
  const mergedInitialState = useMemo<ClassroomState>(() => {
    return {
      ...initialClassroomState,
      ...(customInitialState || {}),
    };
  }, []);

  const [state, dispatch] = useReducer(classroomReducer, mergedInitialState);
  const pendingActionsRef = useRef<ClassroomAction[]>([]);
  const processingRef = useRef(false);

  const batchDispatch = useCallback((actions: ClassroomAction[]) => {
    pendingActionsRef.current.push(...actions);

    if (!processingRef.current) {
      processingRef.current = true;
      depthMonitor.increment();

      Promise.resolve().then(() => {
        const actionsToExecute = pendingActionsRef.current;
        pendingActionsRef.current = [];
        processingRef.current = false;
        depthMonitor.decrement();

        if (actionsToExecute.length > 0) {
          dispatch({
            type: 'BATCH_UPDATE',
            payload: actionsToExecute,
          });
        }
      });
    }
  }, []);

  return { state, dispatch, batchDispatch };
}

// ---------------------------------------------------------------------------
// 8. useSafeEffect HOOK (PREVENTS EFFECT RECURSION & STALE RE-RENDERS)
// ---------------------------------------------------------------------------

/**
 * useSafeEffect — A resilient drop-in replacement for useEffect that detects
 * circular trigger loops within a single rendering window and automatically
 * throttles runaway re-renders.
 */
export function useSafeEffect(
  effect: EffectCallback,
  deps?: DependencyList,
  options?: { maxExecutionsPerSecond?: number; effectName?: string }
) {
  const countRef = useRef(0);
  const lastResetRef = useRef(Date.now());
  const maxAllowed = options?.maxExecutionsPerSecond ?? 35;
  const name = options?.effectName ?? 'AnonymousEffect';

  useEffect(() => {
    const now = Date.now();
    if (now - lastResetRef.current > 1000) {
      countRef.current = 0;
      lastResetRef.current = now;
    }

    countRef.current++;
    if (countRef.current > maxAllowed) {
      console.warn(
        `[useSafeEffect] Guard tripped for "${name}": executed ${countRef.current} times in 1s. Loop broken.`
      );
      return;
    }

    return effect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
