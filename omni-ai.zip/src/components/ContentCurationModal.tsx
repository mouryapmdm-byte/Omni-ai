import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  BookOpen,
  Search,
  Filter,
  CheckCircle2,
  Sparkles,
  Layers,
  GraduationCap,
  Zap,
  Activity,
  Sliders,
  Send,
  RefreshCw,
  Award,
  TrendingUp,
  FileText,
  Calculator,
  Eye,
  Radio,
  Clock,
  ShieldCheck,
  Compass,
  AlertTriangle,
  Play,
  Copy,
  ChevronRight
} from 'lucide-react';
import { cn } from '../lib/utils';
import { 
  contentCollectionService 
} from '../services/contentCollectionService';
import { 
  CuratedContentItem, 
  ContentCategoryType, 
  DifficultyLevel, 
  PipelineStageLog,
  ContentGapReport,
  PersonalizationInterest,
  StudentCurationProfile,
  ExamTarget,
  LearningStyle
} from '../types/contentCuration';

interface ContentCurationModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTopic?: string;
  onDeliverToSmartboard?: (contentMarkdown: string, topicTitle: string) => void;
}

export const ContentCurationModal: React.FC<ContentCurationModalProps> = ({
  isOpen,
  onClose,
  activeTopic,
  onDeliverToSmartboard
}) => {
  const [activeTab, setActiveTab] = useState<'library' | 'pipeline' | 'quality' | 'adaptive' | 'gaps' | 'analytics'>('library');

  // Library Filter States
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [selectedExam, setSelectedExam] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedItem, setSelectedItem] = useState<CuratedContentItem | null>(null);

  // Analogy Selector
  const [activeAnalogyInterest, setActiveAnalogyInterest] = useState<PersonalizationInterest>('general');

  // Live Pipeline Execution State
  const [pipelineTopic, setPipelineTopic] = useState<string>(activeTopic || 'Electromagnetic Induction');
  const [pipelineSubject, setPipelineSubject] = useState<string>('Physics');
  const [isPipelineRunning, setIsPipelineRunning] = useState<boolean>(false);
  const [pipelineLogs, setPipelineLogs] = useState<PipelineStageLog[]>([]);

  // Student Profile for Recommendation
  const [studentProfile, setStudentProfile] = useState<StudentCurationProfile>({
    name: 'Student Scholar',
    gradeLevel: 'Class 12',
    targetExam: 'NEET',
    primaryLearningStyle: 'visual',
    interest: 'technology',
    currentMasteryLevel: 'standard',
    pacingPreference: 'normal',
    languagePreference: 'English',
    weakTopics: ['Chemical Kinetics', 'Definite Integrals'],
    strongTopics: ['Cellular Respiration', 'Faraday Induction']
  });

  // Gap Reports State
  const [gapReports, setGapReports] = useState<ContentGapReport[]>([]);

  // Quiz submission state inside card
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [showQuizSolution, setShowQuizSolution] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setGapReports(contentCollectionService.getGapReports());
      const items = contentCollectionService.getCuratedItems();
      if (items.length > 0 && !selectedItem) {
        setSelectedItem(items[0]);
      }
    }
  }, [isOpen]);

  const filteredItems = useMemo(() => {
    return contentCollectionService.getCuratedItems({
      subject: selectedSubject === 'All' ? undefined : selectedSubject,
      category: selectedCategory === 'All' ? undefined : (selectedCategory as ContentCategoryType),
      difficulty: selectedDifficulty === 'All' ? undefined : (selectedDifficulty as DifficultyLevel),
      examTarget: selectedExam === 'All' ? undefined : selectedExam,
      searchQuery: searchQuery.trim() || undefined
    });
  }, [selectedSubject, selectedCategory, selectedDifficulty, selectedExam, searchQuery, pipelineLogs]);

  // Handle Live Pipeline Trigger
  const handleRunPipeline = async () => {
    if (!pipelineTopic.trim()) return;
    setIsPipelineRunning(true);
    try {
      const logs = await contentCollectionService.runAutomaticCollectionPipeline(pipelineTopic, pipelineSubject);
      setPipelineLogs(logs);
      
      // Also synthesize live item
      const newItem = await contentCollectionService.liveSearchAndSynthesize(
        pipelineTopic,
        pipelineSubject,
        studentProfile.interest,
        studentProfile.currentMasteryLevel
      );
      setSelectedItem(newItem);
    } catch (e) {
      console.error(e);
    } finally {
      setIsPipelineRunning(false);
    }
  };

  // Deliver Item to Smartboard & Professor Clarity
  const handleDeliverToSmartboard = (item: CuratedContentItem) => {
    let payload = `## ${item.title}\n**Subject:** ${item.subject} | **Exam Level:** ${item.examTargets.join(', ')}\n\n`;
    
    if (item.content.markdownText) {
      payload += item.content.markdownText + '\n\n';
    }
    if (item.content.formulaLaTeX) {
      payload += `### Key Mathematical Formulation\n$$${item.content.formulaLaTeX}$$\n\n`;
    }
    if (item.content.diagramSvg) {
      payload += item.content.diagramSvg + '\n\n';
    }
    if (item.content.questionPrompt) {
      payload += `### Practice Exam Problem\n${item.content.questionPrompt}\n\n`;
      if (item.content.questionOptions) {
        payload += item.content.questionOptions.join('\n') + '\n\n';
      }
      if (item.content.stepByStepSolution) {
        payload += `**Solution:** ${item.content.stepByStepSolution}\n\n`;
      }
    }
    if (item.content.realWorldConnection) {
      payload += `> **Real-World Application:** ${item.content.realWorldConnection}\n\n`;
    }

    if (onDeliverToSmartboard) {
      onDeliverToSmartboard(payload, item.topic);
    }
    onClose();
  };

  const recommendationResult = useMemo(() => {
    return contentCollectionService.recommendContentForStudent(studentProfile, activeTopic);
  }, [studentProfile, activeTopic]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="flex flex-col w-full max-w-6xl h-[92vh] max-h-[880px] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* MODAL HEADER */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 shadow-lg shadow-sky-500/20 text-white">
              <BookOpen size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  Professor Clarity Content Collection & Curation Architecture
                </h2>
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-full">
                  Verified Multi-Source
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Automated 7-step gathering, 3+ source accuracy verification, and adaptive delivery
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 rounded-lg transition-colors"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* NAVIGATION TABS */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-slate-900/90 border-b border-slate-800 overflow-x-auto no-scrollbar">
          {[
            { id: 'library', label: 'Curated Knowledge Library', icon: <Layers size={16} /> },
            { id: 'pipeline', label: '7-Step Collection Pipeline', icon: <RefreshCw size={16} /> },
            { id: 'quality', label: 'Quality & Verification Matrix', icon: <ShieldCheck size={16} /> },
            { id: 'adaptive', label: 'Adaptive Difficulty & Profiles', icon: <Sliders size={16} /> },
            { id: 'gaps', label: 'Content Gap Detector', icon: <AlertTriangle size={16} /> },
            { id: 'analytics', label: 'Performance Analytics', icon: <TrendingUp size={16} /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all duration-150",
                activeTab === tab.id
                  ? "bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent"
              )}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* MODAL BODY */}
        <div className="flex-1 overflow-hidden p-6">
          {/* TAB 1: CURATED KNOWLEDGE LIBRARY */}
          {activeTab === 'library' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
              {/* Left Panel: Filters & List */}
              <div className="lg:col-span-5 flex flex-col h-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 overflow-hidden">
                {/* Search Bar */}
                <div className="relative mb-3">
                  <Search className="absolute left-3 top-2.5 text-slate-500" size={16} />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search curated topics, formulas, PYQs..."
                    className="w-full bg-slate-900 border border-slate-700/80 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-colors"
                  />
                </div>

                {/* Filter Pills */}
                <div className="flex flex-wrap gap-2 mb-3 text-[11px]">
                  {/* Subject */}
                  <select
                    value={selectedSubject}
                    onChange={(e) => setSelectedSubject(e.target.value)}
                    className="bg-slate-900 border border-slate-700/80 rounded-md px-2 py-1 text-slate-300 text-xs focus:outline-none focus:border-sky-500"
                  >
                    <option value="All">All Subjects</option>
                    <option value="Biology">Biology</option>
                    <option value="Physics">Physics</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Mathematics">Mathematics</option>
                  </select>

                  {/* Category */}
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="bg-slate-900 border border-slate-700/80 rounded-md px-2 py-1 text-slate-300 text-xs focus:outline-none focus:border-sky-500"
                  >
                    <option value="All">All Types (8)</option>
                    <option value="text">Text & Notes</option>
                    <option value="formula">Formulas</option>
                    <option value="visual">Visual Diagrams</option>
                    <option value="question">PYQs & Questions</option>
                  </select>

                  {/* Difficulty */}
                  <select
                    value={selectedDifficulty}
                    onChange={(e) => setSelectedDifficulty(e.target.value)}
                    className="bg-slate-900 border border-slate-700/80 rounded-md px-2 py-1 text-slate-300 text-xs focus:outline-none focus:border-sky-500"
                  >
                    <option value="All">All Difficulties</option>
                    <option value="foundation">Level 1: Foundation</option>
                    <option value="standard">Level 2: Standard</option>
                    <option value="advanced">Level 3: Advanced</option>
                    <option value="challenge">Level 4: Challenge</option>
                    <option value="mastery">Level 5: Mastery</option>
                  </select>
                </div>

                {/* Items List */}
                <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                  {filteredItems.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-slate-500 text-center">
                      <BookOpen size={32} className="mb-2 stroke-[1.5]" />
                      <p className="text-xs">No curated items found matching filter criteria.</p>
                      <button
                        onClick={() => {
                          setSelectedSubject('All');
                          setSelectedCategory('All');
                          setSelectedDifficulty('All');
                          setSearchQuery('');
                        }}
                        className="mt-2 text-xs text-sky-400 hover:underline"
                      >
                        Reset Filters
                      </button>
                    </div>
                  ) : (
                    filteredItems.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => {
                          setSelectedItem(item);
                          setSelectedQuizOption(null);
                          setShowQuizSolution(false);
                        }}
                        className={cn(
                          "p-3 rounded-lg border cursor-pointer transition-all duration-150",
                          selectedItem?.id === item.id
                            ? "bg-slate-800/90 border-sky-500 shadow-md ring-1 ring-sky-500/30"
                            : "bg-slate-900/60 border-slate-800 hover:bg-slate-850 hover:border-slate-700"
                        )}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className={cn(
                            "px-1.5 py-0.5 rounded text-[10px] font-bold uppercase",
                            item.subject === 'Biology' && "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
                            item.subject === 'Physics' && "bg-sky-500/10 text-sky-400 border border-sky-500/20",
                            item.subject === 'Chemistry' && "bg-amber-500/10 text-amber-400 border border-amber-500/20",
                            item.subject === 'Mathematics' && "bg-purple-500/10 text-purple-400 border border-purple-500/20"
                          )}>
                            {item.subject}
                          </span>
                          <span className="text-[10px] text-amber-400 font-semibold flex items-center gap-1">
                            ★ {item.qualityRating}.0
                          </span>
                        </div>
                        <h4 className="text-xs font-semibold text-white line-clamp-1">
                          {item.title}
                        </h4>
                        <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                          {item.topic}
                        </p>
                        <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/60 text-[10px] text-slate-500">
                          <span>{item.sources.length} Verified Sources</span>
                          <span className="text-emerald-400 font-medium capitalize">
                            L{item.difficultyRating} • {item.difficulty}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Right Panel: Rich Preview & Delivery to Smartboard */}
              <div className="lg:col-span-7 flex flex-col h-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-5 overflow-hidden">
                {selectedItem ? (
                  <div className="flex flex-col h-full">
                    {/* Item Header */}
                    <div className="flex items-start justify-between pb-3 border-b border-slate-800">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-bold text-sky-400 uppercase tracking-wide">
                            {selectedItem.subject} • {selectedItem.topic}
                          </span>
                          <span className="px-2 py-0.5 text-[10px] font-semibold bg-slate-800 text-slate-300 rounded border border-slate-700">
                            {selectedItem.category.toUpperCase()}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-white">
                          {selectedItem.title}
                        </h3>
                      </div>

                      <button
                        onClick={() => handleDeliverToSmartboard(selectedItem)}
                        className="flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-lg shadow-lg shadow-emerald-500/20 transition-all duration-150 transform hover:scale-[1.02]"
                      >
                        <Send size={14} />
                        <span>Deliver to Smartboard</span>
                      </button>
                    </div>

                    {/* Sources Badge Bar */}
                    <div className="flex flex-wrap items-center gap-2 py-2 border-b border-slate-800/60 text-[11px] text-slate-400">
                      <span className="font-semibold text-slate-300">Verified Sources:</span>
                      {selectedItem.sources.map((src, i) => (
                        <span key={i} className="px-2 py-0.5 bg-slate-900 border border-slate-700 rounded-full text-slate-300 text-[10px] flex items-center gap-1">
                          <ShieldCheck size={12} className="text-emerald-400" />
                          {src.name}
                        </span>
                      ))}
                    </div>

                    {/* Scrollable Content Card */}
                    <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1 text-slate-200 text-xs leading-relaxed">
                      {/* Text / Markdown */}
                      {selectedItem.content.markdownText && (
                        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 whitespace-pre-line font-sans">
                          {selectedItem.content.markdownText}
                        </div>
                      )}

                      {/* Formula & Derivation */}
                      {selectedItem.content.formulaLaTeX && (
                        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                          <h5 className="text-[11px] font-bold text-amber-400 mb-2 uppercase tracking-wide">
                            Mathematical Formulation & Derivation
                          </h5>
                          <div className="p-3 bg-black/50 border border-amber-500/20 rounded-lg text-emerald-400 font-mono text-sm overflow-x-auto">
                            $${selectedItem.content.formulaLaTeX}$$
                          </div>
                          {selectedItem.content.derivationSteps && (
                            <div className="mt-3 space-y-1.5 text-[11px] text-slate-300">
                              {selectedItem.content.derivationSteps.map((step, idx) => (
                                <div key={idx} className="flex items-start gap-2">
                                  <span className="text-sky-400 font-bold">•</span>
                                  <span>{step}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Vector SVG Diagram */}
                      {selectedItem.content.diagramSvg && (
                        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                          <h5 className="text-[11px] font-bold text-sky-400 mb-2 uppercase tracking-wide">
                            Interactive Vector Schematic
                          </h5>
                          <div 
                            className="w-full overflow-hidden rounded-lg border border-slate-700"
                            dangerouslySetInnerHTML={{ __html: selectedItem.content.diagramSvg }}
                          />
                        </div>
                      )}

                      {/* Practice Question Solver */}
                      {selectedItem.content.questionPrompt && (
                        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="text-[11px] font-bold text-purple-400 uppercase tracking-wide">
                              Exam Challenge ({selectedItem.content.examType || 'PYQ'})
                            </h5>
                            <span className="text-[10px] text-slate-400">{selectedItem.content.pyqYear}</span>
                          </div>
                          <p className="text-xs font-semibold text-white mb-3">
                            {selectedItem.content.questionPrompt}
                          </p>

                          {selectedItem.content.questionOptions && (
                            <div className="space-y-2 mb-3">
                              {selectedItem.content.questionOptions.map((opt, oIdx) => (
                                <button
                                  key={oIdx}
                                  onClick={() => setSelectedQuizOption(oIdx)}
                                  className={cn(
                                    "w-full text-left p-2.5 rounded-lg border text-xs transition-all",
                                    selectedQuizOption === oIdx
                                      ? oIdx === selectedItem.content.correctOptionIndex
                                        ? "bg-emerald-950/80 border-emerald-500 text-emerald-200"
                                        : "bg-rose-950/80 border-rose-500 text-rose-200"
                                      : "bg-slate-950/50 border-slate-800 hover:border-slate-700 text-slate-300"
                                  )}
                                >
                                  {opt}
                                </button>
                              ))}
                            </div>
                          )}

                          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                            <button
                              onClick={() => setShowQuizSolution(!showQuizSolution)}
                              className="text-[11px] text-sky-400 hover:underline font-medium"
                            >
                              {showQuizSolution ? 'Hide Step-by-Step Solution' : 'View Verified Solution'}
                            </button>
                            {selectedQuizOption !== null && (
                              <span className={cn(
                                "text-xs font-bold",
                                selectedQuizOption === selectedItem.content.correctOptionIndex
                                  ? "text-emerald-400"
                                  : "text-rose-400"
                              )}>
                                {selectedQuizOption === selectedItem.content.correctOptionIndex ? '✓ Correct Answer!' : '✗ Review Solution Below'}
                              </span>
                            )}
                          </div>

                          {showQuizSolution && selectedItem.content.stepByStepSolution && (
                            <div className="mt-3 p-3 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-300">
                              <span className="font-bold text-emerald-400">Step-by-Step Rationale: </span>
                              {selectedItem.content.stepByStepSolution}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Personalization Analogies Tab */}
                      {selectedItem.analogies && Object.keys(selectedItem.analogies).length > 0 && (
                        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="text-[11px] font-bold text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
                              <Sparkles size={14} />
                              Personalized Everyday Analogies
                            </h5>
                            <div className="flex gap-1">
                              {(['sports', 'cooking', 'technology'] as PersonalizationInterest[]).map((theme) => (
                                <button
                                  key={theme}
                                  onClick={() => setActiveAnalogyInterest(theme)}
                                  className={cn(
                                    "px-2 py-0.5 rounded text-[10px] font-medium capitalize",
                                    activeAnalogyInterest === theme
                                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                                      : "bg-slate-800 text-slate-400 hover:bg-slate-750"
                                  )}
                                >
                                  {theme}
                                </button>
                              ))}
                            </div>
                          </div>
                          <p className="text-xs text-slate-300 italic p-3 bg-black/40 border border-slate-800 rounded-lg">
                            "{selectedItem.analogies[activeAnalogyInterest] || selectedItem.analogies.sports || selectedItem.analogies.technology || 'Imagine a familiar system operating with exact mathematical balance.'}"
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-slate-500 text-xs">
                    Select a curated item on the left to preview verified materials.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: 7-STEP AUTOMATIC COLLECTION PIPELINE */}
          {activeTab === 'pipeline' && (
            <div className="flex flex-col h-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-6 overflow-y-auto">
              {/* Pipeline Trigger Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 p-4 bg-slate-900/90 border border-slate-800 rounded-xl mb-6 shadow-md">
                <div className="flex-1">
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Target Topic to Scrape & Curate
                  </label>
                  <input
                    type="text"
                    value={pipelineTopic}
                    onChange={(e) => setPipelineTopic(e.target.value)}
                    placeholder="e.g. Photoelectric Effect, CRISPR Cas-9, Matrix Transformations"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Subject Domain
                  </label>
                  <select
                    value={pipelineSubject}
                    onChange={(e) => setPipelineSubject(e.target.value)}
                    className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500"
                  >
                    <option value="Physics">Physics</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Biology">Biology</option>
                    <option value="Mathematics">Mathematics</option>
                  </select>
                </div>
                <div className="sm:self-end">
                  <button
                    onClick={handleRunPipeline}
                    disabled={isPipelineRunning}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-bold text-xs rounded-lg shadow-lg shadow-sky-500/20 transition-all disabled:opacity-50"
                  >
                    <RefreshCw size={14} className={cn(isPipelineRunning && "animate-spin")} />
                    <span>{isPipelineRunning ? 'Scraping & Verifying...' : 'Run 7-Step Pipeline'}</span>
                  </button>
                </div>
              </div>

              {/* 7 Stages Visualization Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {[
                  { step: 1, name: 'Identify Needs', desc: 'Scan syllabus, board patterns & student gaps', icon: <Search size={18} /> },
                  { step: 2, name: 'Multi-Source Search', desc: 'Query NCERT, HC Verma, Khan Academy & PYQs', icon: <Compass size={18} /> },
                  { step: 3, name: 'Multimodal Extraction', desc: 'Extract LaTeX, SVG diagrams & formulas', icon: <Layers size={18} /> },
                  { step: 4, name: '3+ Source Verification', desc: 'Cross-reference facts for 99.4% accuracy', icon: <ShieldCheck size={18} /> },
                  { step: 5, name: 'Categorise & Tag', desc: 'Index into 5 Difficulty levels & exam tags', icon: <Sliders size={18} /> },
                  { step: 6, name: 'Knowledge Graph Index', desc: 'Sub-second vector retrieval storage', icon: <Zap size={18} /> },
                  { step: 7, name: 'Deliver to Professor', desc: 'Inject into 3D Classroom Smartboard', icon: <Send size={18} /> },
                  { step: '★', name: 'Continuous Refresh', desc: 'Daily to annual auto-updates', icon: <Clock size={18} /> },
                ].map((s, idx) => (
                  <div 
                    key={idx}
                    className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-sky-500/40 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="flex items-center justify-center w-7 h-7 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20 text-xs font-bold">
                        {s.step}
                      </span>
                      <div className="text-slate-400">{s.icon}</div>
                    </div>
                    <h4 className="text-xs font-bold text-white mb-1">{s.name}</h4>
                    <p className="text-[11px] text-slate-400">{s.desc}</p>
                  </div>
                ))}
              </div>

              {/* Pipeline Live Activity Logs */}
              {pipelineLogs.length > 0 && (
                <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl">
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                    <CheckCircle2 size={16} />
                    Pipeline Execution Complete • {pipelineLogs.length} Stages Verified
                  </h4>
                  <div className="space-y-2">
                    {pipelineLogs.map((log) => (
                      <div key={log.stageNumber} className="flex items-start justify-between p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-bold text-[10px]">
                            Stage {log.stageNumber}
                          </span>
                          <span className="font-semibold text-white">{log.stageName}:</span>
                          <span className="text-slate-300">{log.details}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">{log.timestamp}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: QUALITY & VERIFICATION MATRIX */}
          {activeTab === 'quality' && (
            <div className="flex flex-col h-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-6 overflow-y-auto space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white mb-1">
                  Multi-Layer Verification & Quality Curation Framework
                </h3>
                <p className="text-xs text-slate-400">
                  Every concept delivered by Professor Clarity undergoes rigorous multi-source cross-referencing and curriculum drift checks.
                </p>
              </div>

              {/* 5 Verification Layers */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { layer: 'Layer 1: Automated Verification', desc: 'Fact-checking against textbook corpora, syntax checks, LaTeX equation validation, and duplicate elimination.', score: '100% Passed' },
                  { layer: 'Layer 2: 3+ Cross-Referencing', desc: 'Cross-references definitions across NCERT, HC Verma, Campbell Biology, and 15 years of competitive exam keys.', score: '99.4% Match' },
                  { layer: 'Layer 3: Expert Pedagogy Review', desc: 'Ensures tone follows Active Pedagogy, zero-jargon everyday intuition, and concrete step-by-step logic.', score: '5.0 / 5.0 Stars' },
                  { layer: 'Layer 4: Student Feedback Metrics', desc: 'Live student comprehension gain tracking, question difficulty calibration, and retention rate scoring.', score: '+82% Comprehension' },
                  { layer: 'Layer 5: Freshness & Syllabus Drift', desc: 'Ensures all questions adhere to the latest 2024-2026 reduced syllabus guidelines with zero obsolete topics.', score: 'Updated Monthly' },
                  { layer: 'Layer 6: Diversity Assurance', desc: 'Provides minimum 3 distinct analogy options (Sports, Tech, Cooking) and multi-modal sensory representations.', score: 'Multi-Perspective' },
                ].map((l, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xs font-bold text-white">{l.layer}</h4>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        {l.score}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">{l.desc}</p>
                  </div>
                ))}
              </div>

              {/* Source Reliability Index */}
              <div className="p-5 bg-slate-900/90 border border-slate-800 rounded-xl">
                <h4 className="text-xs font-bold text-sky-400 uppercase tracking-wider mb-3">
                  8 Primary Content Sources & Academic Reliability Scores
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  {[
                    { name: 'NCERT & State Boards', reliability: 99.8, type: 'Official Curriculum' },
                    { name: 'Reference Books (HCV/RDS)', reliability: 99.5, type: 'Rigorous Problem Sets' },
                    { name: 'NTA & PYQ Papers (15 Yrs)', reliability: 100, type: 'Exam Authentic' },
                    { name: 'Khan Academy & Platforms', reliability: 98.6, type: 'Visual Pedagogy' },
                    { name: 'Peer-Reviewed Journals', reliability: 99.9, type: 'Cutting Edge Science' },
                    { name: 'Digital Libraries (OER)', reliability: 98.9, type: 'Encyclopedic' },
                    { name: 'Govt. Education Updates', reliability: 100, type: 'Syllabus Changes' },
                    { name: 'Community Teacher Bank', reliability: 97.5, type: 'Real-World Tips' },
                  ].map((src, i) => (
                    <div key={i} className="p-3 bg-slate-950 border border-slate-800/80 rounded-lg">
                      <div className="font-bold text-white text-xs mb-0.5">{src.name}</div>
                      <div className="text-[10px] text-slate-400 mb-1">{src.type}</div>
                      <div className="text-[11px] font-mono text-emerald-400">{src.reliability}% Accuracy</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ADAPTIVE DIFFICULTY & PERSONALISATION */}
          {activeTab === 'adaptive' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
              {/* Student Profile Configuration */}
              <div className="lg:col-span-6 flex flex-col h-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-5 overflow-y-auto space-y-4">
                <h3 className="text-sm font-bold text-white">
                  Student Profile & Personalisation Preferences
                </h3>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Target Exam</label>
                  <select
                    value={studentProfile.targetExam}
                    onChange={(e) => setStudentProfile({ ...studentProfile, targetExam: e.target.value as ExamTarget })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="CBSE">CBSE Board Exam</option>
                    <option value="NEET">NEET Medical Entrance</option>
                    <option value="JEE_Main">JEE Main Engineering</option>
                    <option value="JEE_Adv">JEE Advanced</option>
                    <option value="ICSE">ICSE / ISC</option>
                    <option value="SAT">SAT / AP STEM</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Current Mastery Level</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['foundation', 'standard', 'advanced', 'challenge', 'mastery'] as DifficultyLevel[]).map((lvl) => (
                      <button
                        key={lvl}
                        onClick={() => setStudentProfile({ ...studentProfile, currentMasteryLevel: lvl })}
                        className={cn(
                          "p-2 rounded-lg border text-xs font-semibold capitalize transition-all",
                          studentProfile.currentMasteryLevel === lvl
                            ? "bg-sky-500/20 text-sky-300 border-sky-500"
                            : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700"
                        )}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Analogy & Interest Theme</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['general', 'sports', 'technology', 'cooking', 'nature', 'music'] as PersonalizationInterest[]).map((int) => (
                      <button
                        key={int}
                        onClick={() => setStudentProfile({ ...studentProfile, interest: int })}
                        className={cn(
                          "p-2 rounded-lg border text-xs font-semibold capitalize transition-all",
                          studentProfile.interest === int
                            ? "bg-amber-500/20 text-amber-300 border-amber-500"
                            : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700"
                        )}
                      >
                        {int}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">Primary Sensory Learning Style</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(['visual', 'auditory', 'reading', 'kinesthetic'] as LearningStyle[]).map((style) => (
                      <button
                        key={style}
                        onClick={() => setStudentProfile({ ...studentProfile, primaryLearningStyle: style })}
                        className={cn(
                          "p-2 rounded-lg border text-xs font-semibold capitalize transition-all",
                          studentProfile.primaryLearningStyle === style
                            ? "bg-purple-500/20 text-purple-300 border-purple-500"
                            : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700"
                        )}
                      >
                        {style}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Live Adaptive Recommendation Outcome */}
              <div className="lg:col-span-6 flex flex-col h-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-5 overflow-y-auto">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-white">
                      Smart Content Recommendation Engine
                    </h3>
                    <p className="text-xs text-slate-400">
                      Calculated using 5-factor weighted algorithm for {studentProfile.name}
                    </p>
                  </div>
                  {recommendationResult && (
                    <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-full text-xs font-bold">
                      {recommendationResult.matchScore}% Match
                    </span>
                  )}
                </div>

                {recommendationResult?.primaryRecommendation && (
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-sky-500/50 shadow-lg mb-4">
                    <div className="flex items-center justify-between text-[11px] mb-2">
                      <span className="font-bold text-sky-400">Top Recommended Module</span>
                      <span className="text-emerald-400 font-semibold capitalize">
                        Level: {recommendationResult.primaryRecommendation.difficulty}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-white mb-1">
                      {recommendationResult.primaryRecommendation.title}
                    </h4>
                    <p className="text-xs text-slate-300 mb-3">
                      {recommendationResult.primaryRecommendation.topic}
                    </p>
                    <button
                      onClick={() => handleDeliverToSmartboard(recommendationResult.primaryRecommendation)}
                      className="w-full py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2"
                    >
                      <Send size={14} />
                      <span>Deliver Personalized Module to Smartboard</span>
                    </button>
                  </div>
                )}

                {recommendationResult?.relatedItems && recommendationResult.relatedItems.length > 0 && (
                  <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                      Alternative Recommended Modules
                    </h4>
                    <div className="space-y-2">
                      {recommendationResult.relatedItems.map((item) => (
                        <div
                          key={item.id}
                          className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between"
                        >
                          <div>
                            <h5 className="text-xs font-bold text-white">{item.title}</h5>
                            <span className="text-[10px] text-slate-400">{item.subject} • {item.difficulty}</span>
                          </div>
                          <button
                            onClick={() => handleDeliverToSmartboard(item)}
                            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-sky-400 text-xs font-semibold rounded"
                          >
                            Deliver
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: CONTENT GAP DETECTOR */}
          {activeTab === 'gaps' && (
            <div className="flex flex-col h-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-6 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Automated Curriculum & Student Knowledge Gap Detector
                  </h3>
                  <p className="text-xs text-slate-400">
                    Proactively scans curriculum coverage, previous year question banks, and learning style deficiencies.
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  {gapReports.filter(g => !g.autoFilled).length} Active Gaps Detected
                </span>
              </div>

              <div className="space-y-3 mt-4">
                {gapReports.map((gap) => (
                  <div 
                    key={gap.id}
                    className={cn(
                      "p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all",
                      gap.autoFilled
                        ? "bg-emerald-950/20 border-emerald-500/30"
                        : gap.severity === 'high'
                          ? "bg-rose-950/20 border-rose-500/40"
                          : "bg-slate-900/80 border-slate-800"
                    )}
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={cn(
                          "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                          gap.severity === 'high' ? "bg-rose-500/20 text-rose-400" : "bg-amber-500/20 text-amber-400"
                        )}>
                          {gap.gapType.replace('_', ' ')}
                        </span>
                        <span className="text-xs font-bold text-white">{gap.subject} • {gap.topic}</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1">{gap.description}</p>
                      <p className="text-[11px] text-sky-400 mt-1">Recommended: {gap.recommendedAction}</p>
                    </div>

                    <div className="sm:self-center">
                      {gap.autoFilled ? (
                        <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                          <CheckCircle2 size={16} />
                          Auto-Filled & Indexed
                        </span>
                      ) : (
                        <button
                          onClick={() => {
                            contentCollectionService.autoFillGap(gap.id);
                            setGapReports(contentCollectionService.getGapReports());
                          }}
                          className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-lg shadow-md transition-colors"
                        >
                          Auto-Fill with AI
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: PERFORMANCE ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="flex flex-col h-full bg-slate-950/60 border border-slate-800/80 rounded-xl p-6 overflow-y-auto space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white mb-1">
                  Content Effectiveness & Pedagogical Impact Analytics
                </h3>
                <p className="text-xs text-slate-400">
                  Real-time learning outcome metrics, attention retention, and student comprehension gains.
                </p>
              </div>

              {/* KPI Stat Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { label: 'Total Curated Assets', val: '1,420+', change: '+12% this week', color: 'text-sky-400' },
                  { label: 'Source Verification Rate', val: '99.4%', change: '3+ Sources each', color: 'text-emerald-400' },
                  { label: 'Comprehension Gain', val: '+82%', change: 'Measured in post-quizzes', color: 'text-purple-400' },
                  { label: 'Avg Attention Retention', val: '94.2%', change: 'Active 3D Smartboard', color: 'text-amber-400' },
                ].map((kpi, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      {kpi.label}
                    </span>
                    <span className={cn("text-2xl font-bold font-mono", kpi.color)}>
                      {kpi.val}
                    </span>
                    <span className="text-[10px] text-slate-500 block mt-1">
                      {kpi.change}
                    </span>
                  </div>
                ))}
              </div>

              {/* Top Performing Modules Table */}
              <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                  Highest Yield Curated Content Modules
                </h4>
                <div className="space-y-2">
                  {contentCollectionService.getPerformanceMetrics().map((m, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800/80 text-xs">
                      <div>
                        <div className="font-bold text-white">{m.title}</div>
                        <div className="text-[10px] text-slate-400 capitalize">Type: {m.category} • {m.viewsCount} Views</div>
                      </div>
                      <div className="flex items-center gap-4 text-right font-mono">
                        <div>
                          <div className="text-emerald-400 font-bold">+{m.understandingGain}%</div>
                          <div className="text-[9px] text-slate-500">Knowledge Gain</div>
                        </div>
                        <div>
                          <div className="text-sky-400 font-bold">{m.completionRate}%</div>
                          <div className="text-[9px] text-slate-500">Completion</div>
                        </div>
                        <div>
                          <div className="text-amber-400 font-bold">★ {m.studentSatisfactionScore}</div>
                          <div className="text-[9px] text-slate-500">Rating</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
