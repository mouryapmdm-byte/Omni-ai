const fs = require('fs');
const file = 'src/lib/constants.ts';
let content = fs.readFileSync(file, 'utf8');

const targetStr = `export const INVERSE_TRIGONOMETRIC_FUNCTIONS_SUBTOPICS = [
  "Introduction",
  "1. Definition of Inverse Trigonometric Functions",
  "2. Domain and range",
  "3. Principal value branch",
  "4. Graphs of inverse trigonometric functions",
  "5. Elementary properties of inverse trigonometric functions",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];`;

const replacementStr = `export const INVERSE_TRIGONOMETRIC_FUNCTIONS_SUBTOPICS = [
  "Introduction",
  "1. Definition, domain, range, principal value branch",
  "2. Graphs of inverse trigonometric functions",
  "3. Elementary properties of inverse trigonometric functions",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];`;

if (content.includes(targetStr)) {
  content = content.replace(targetStr, replacementStr);
  fs.writeFileSync(file, content);
  console.log("Replaced subtopics successfully.");
} else {
  console.log("Target string not found.");
}
