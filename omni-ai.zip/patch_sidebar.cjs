const fs = require('fs');
const file = 'src/components/Sidebar.tsx';
let content = fs.readFileSync(file, 'utf8');

const targetStr = `<section className="mt-4">
          <div className="text-xs uppercase tracking-wider text-slate-500 mb-3 font-semibold flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Target size={14} className="text-indigo-500" /> Active Subject Lessons ({subjectLessons.length})
            </span>
          </div>
          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 select-none">
            {subjectLessons.map((title, i) => {
              const lessonNum = i + 1;
              const isSelected = lesson === String(lessonNum);
              const isBookmarked = (bookmarkedLessons || []).some(
                b => b.title === title && b.subject === subject
              );
              
              return (
                <div key={lessonNum} className="flex items-stretch gap-1.5 group/lesson">
                  <button
                    onClick={() => setLesson(String(lessonNum))}
                    className={cn(
                      "flex-1 px-3 py-2.5 rounded-xl text-xs font-bold text-left transition-all leading-snug cursor-pointer border flex items-center gap-2 min-h-[40px] truncate",
                      isSelected
                        ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10"
                        : theme === 'dark'
                          ? "bg-slate-900/40 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 hover:bg-slate-800/40"
                          : "bg-white border-slate-200/80 text-slate-700 hover:text-slate-900 hover:border-slate-300 hover:bg-slate-50"
                    )}
                    title={title}
                  >
                    <span className={cn(
                      "font-mono text-[10px] px-1.5 py-0.5 rounded flex-shrink-0 leading-none",
                      isSelected 
                        ? "bg-indigo-700 text-indigo-100" 
                        : theme === 'dark' 
                          ? "bg-slate-800 text-slate-400" 
                          : "bg-slate-100 text-slate-500"
                    )}>
                      {lessonNum}
                    </span>
                    <span className="truncate">{title}</span>
                  </button>
                  <button
                    onClick={() => onToggleBookmark?.(title, subject, lessonNum)}
                    className={cn(
                      "px-2.5 rounded-xl border transition-all cursor-pointer active:scale-95 flex items-center justify-center min-w-[38px] min-h-[38px] flex-shrink-0",
                      isBookmarked
                        ? "bg-amber-500/10 border-amber-500/40 text-amber-500"
                        : theme === 'dark'
                          ? "border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700 hover:bg-slate-800/30"
                          : "border-slate-200 text-slate-400 hover:text-slate-600 hover:border-slate-300 hover:bg-slate-50"
                    )}
                    title={isBookmarked ? "Remove Bookmark" : "Bookmark Lesson"}
                  >
                    <Bookmark size={13} className={isBookmarked ? "fill-current" : ""} />
                  </button>
                </div>
              );
            })}
          </div>
        </section>`;

const replacementStr = `<section className="mt-4">
          <div className="text-xs uppercase tracking-wider text-slate-500 mb-3 font-semibold flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Target size={14} className="text-indigo-500" /> Active Subject Lesson
            </span>
          </div>
          <div className="flex items-stretch gap-1.5">
            <select
              className={cn(
                "flex-1 w-full p-2.5 border rounded-lg text-sm cursor-pointer outline-none transition-colors",
                theme === 'dark' ? "bg-slate-800 border-slate-700 text-white hover:border-indigo-500" : "bg-white border-slate-200 text-slate-900 hover:border-indigo-300 focus:border-indigo-500"
              )}
              value={lesson}
              onChange={(e) => setLesson(e.target.value)}
            >
              {subjectLessons.map((title, i) => {
                const lessonNum = i + 1;
                return (
                  <option key={lessonNum} value={String(lessonNum)}>
                    {lessonNum}. {title}
                  </option>
                );
              })}
            </select>
            <button
              onClick={() => {
                const currentLessonNum = parseInt(lesson) || 1;
                const title = subjectLessons[currentLessonNum - 1] || subjectLessons[0];
                onToggleBookmark?.(title, subject, currentLessonNum);
              }}
              className={cn(
                "px-2.5 rounded-xl border transition-all cursor-pointer active:scale-95 flex items-center justify-center min-w-[38px] min-h-[38px] flex-shrink-0",
                (bookmarkedLessons || []).some(b => b.title === (subjectLessons[(parseInt(lesson) || 1) - 1] || subjectLessons[0]) && b.subject === subject)
                  ? "bg-amber-500/10 border-amber-500/40 text-amber-500"
                  : theme === 'dark'
                    ? "border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700 hover:bg-slate-800/30"
                    : "border-slate-200 text-slate-400 hover:text-slate-600 hover:border-slate-300 hover:bg-slate-50"
              )}
              title="Toggle Bookmark"
            >
              <Bookmark size={13} className={(bookmarkedLessons || []).some(b => b.title === (subjectLessons[(parseInt(lesson) || 1) - 1] || subjectLessons[0]) && b.subject === subject) ? "fill-current" : ""} />
            </button>
          </div>
        </section>`;

if (content.includes('Active Subject Lessons (')) {
  content = content.replace(targetStr, replacementStr);
  fs.writeFileSync(file, content);
  console.log("Replaced successfully");
} else {
  console.log("Could not find target string.");
}
