export * from '../../src/modules/virtual-labs/types';
