export interface Doubt {
  id: string;
  chapterId: string;
  chapterTitle?: string;
  topicId: string;
  topicTitle?: string;
  questionText: string;
  imageUrl?: string;
  upvotes: number;
  answerCount: number;
  hasVerifiedAnswer: boolean;
  createdAt: string;
  anonId: string; // rotating anonymous ID (e.g., "AnonStudent_83b")
  confusedCount: number; // "X students also found this confusing"
  userHasUpvoted?: boolean;
  userAlsoConfused?: boolean;
}

export interface Answer {
  id: string;
  doubtId: string;
  answerText: string;
  answerType: 'student' | 'ai' | 'professor-verified';
  upvotes: number;
  downvotes?: number;
  createdAt: string;
  isHelpful?: boolean;
  authorLabel?: string; // e.g. "Professor Clarity (AI)", "Verified Educator", "AnonPeer_94"
  verifiedBy?: string;
  referenceSource?: string; // e.g., "NCERT Physics Ch. 6, Page 211"
  userVote?: 'up' | 'down';
}

export interface DuplicateMatch {
  doubt: Doubt;
  similarityScore: number; // 0 - 100%
  topAnswer?: Answer;
}

export interface RateLimitStatus {
  allowed: boolean;
  remainingToday: number;
  maxPerDay: number;
  resetsAt: string;
}

export type DoubtSortOption = 'recent' | 'upvoted' | 'unanswered';
