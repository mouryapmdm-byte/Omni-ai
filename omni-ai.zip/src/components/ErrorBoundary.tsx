import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Trash2, ShieldCheck, Activity } from 'lucide-react';
import { logger } from '../logging/logger';
import { PLAYBOOKS, executeRecovery } from '../recovery/playbooks';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  isHealing: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    isHealing: false,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null, isHealing: true };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    logger.error('ErrorBoundary', 'Uncaught component exception caught by ErrorBoundary', {
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
    });
    this.setState({ errorInfo, isHealing: true });

    // Attempt autonomous recovery
    const playbook = PLAYBOOKS.find(p => p.trigger(error));
    if (playbook) {
      executeRecovery(playbook, error).then((success) => {
        if (success) {
          logger.info('ErrorBoundary', `Auto-recovered successfully from ${playbook.id}`);
          setTimeout(() => {
            this.setState({ hasError: false, error: null, errorInfo: null, isHealing: false });
          }, 200);
        } else {
          this.setState({ isHealing: false });
        }
      }).catch(() => {
        this.setState({ isHealing: false });
      });
    } else {
      this.setState({ isHealing: false });
    }
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null, isHealing: false });
  };

  private handleClearStorageAndReset = () => {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch (e) {
      console.error(e);
    }
    this.setState({ hasError: false, error: null, errorInfo: null, isHealing: false });
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6 font-sans">
          <div className="max-w-lg w-full bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl text-center">
            <div className="w-16 h-16 bg-red-500/10 text-red-400 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-red-500/20">
              <AlertTriangle className="w-8 h-8" />
            </div>
            
            <h1 className="text-2xl font-bold text-white mb-2">Something went wrong</h1>
            <p className="text-slate-400 text-sm mb-6 leading-relaxed">
              An unexpected error occurred during rendering. You can try refreshing the page or clearing the local cache.
            </p>

            {this.state.error && (
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 mb-6 text-left overflow-x-auto max-h-48 text-xs font-mono text-red-300">
                <p className="font-semibold text-red-400 mb-1">{this.state.error.name}: {this.state.error.message}</p>
                {this.state.error.stack && (
                  <pre className="text-slate-500 whitespace-pre-wrap text-[11px] leading-tight">{this.state.error.stack.split('\n').slice(1, 4).join('\n')}</pre>
                )}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={this.handleReset}
                className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium transition text-sm shadow-lg shadow-indigo-600/20"
              >
                <RefreshCw className="w-4 h-4" />
                Reload Page
              </button>
              <button
                onClick={this.handleClearStorageAndReset}
                className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-medium transition text-sm border border-slate-700"
              >
                <Trash2 className="w-4 h-4" />
                Clear Cache & Reload
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
