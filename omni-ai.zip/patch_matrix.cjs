const fs = require('fs');
const file = 'src/components/MatrixCalculatorModal.tsx';
let content = fs.readFileSync(file, 'utf8');

// 1. Update states
content = content.replace(
  "const [operation, setOperation] = useState<'add' | 'multiply' | 'detA' | 'detB' | 'invA' | 'invB' | null>(null);",
  "const [operation, setOperation] = useState<'add' | 'multiply' | 'detA' | 'detB' | 'invA' | 'invB' | 'scalarA' | 'scalarB' | 'refA' | 'refB' | 'rankA' | 'rankB' | null>(null);\n  const [scalarA, setScalarA] = useState<number>(2);\n  const [scalarB, setScalarB] = useState<number>(2);"
);

// 2. Insert getREF and getRank after getInverse
const getRefRankStr = `  const getREF = (M: Matrix3x3, rows: number, cols: number) => {
    const A = M.slice(0, rows).map(r => r.slice(0, cols).map(val => Number(val)));
    let lead = 0;
    for (let r = 0; r < rows; r++) {
      if (cols <= lead) return A;
      let i = r;
      while (Math.abs(A[i][lead]) < 1e-10) {
        i++;
        if (rows === i) {
          i = r;
          lead++;
          if (cols === lead) return A;
        }
      }
      
      let temp = A[i];
      A[i] = A[r];
      A[r] = temp;
      
      let val = A[r][lead];
      for (let j = 0; j < cols; j++) {
        A[r][j] = A[r][j] / val;
      }
      
      for (let i = r + 1; i < rows; i++) {
        let val2 = A[i][lead];
        for (let j = 0; j < cols; j++) {
          A[i][j] = A[i][j] - val2 * A[r][j];
        }
      }
      lead++;
    }
    return A;
  };

  const getRank = (M: Matrix3x3, rows: number, cols: number) => {
    const refMatrix = getREF(M, rows, cols);
    let rank = 0;
    for (let i = 0; i < rows; i++) {
      let isNonZero = false;
      for (let j = 0; j < cols; j++) {
        if (Math.abs(refMatrix[i][j]) > 1e-10) {
          isNonZero = true;
          break;
        }
      }
      if (isNonZero) rank++;
    }
    return rank;
  };
`;

content = content.replace(
  "const getDet3x3Steps = (M: Matrix3x3) => {",
  getRefRankStr + "\n  const getDet3x3Steps = (M: Matrix3x3) => {"
);

// 3. Insert render functions after renderInverse
const renderFuncsStr = `  const renderScalar = (matrix: 'A' | 'B') => {
    const M = matrix === 'A' ? matrixA : matrixB;
    const size = matrix === 'A' ? sizeA : sizeB;
    const scalar = matrix === 'A' ? scalarA : scalarB;
    
    const result = M.slice(0, size.rows).map(r => r.slice(0, size.cols).map(val => val * scalar));
    
    return (
      <div className="space-y-4 overflow-x-auto">
        <h3 className="font-bold">Scalar Multiplication (Matrix {matrix}):</h3>
        <div className="flex gap-4 items-center w-max">
           <span className="font-bold">{scalar} ×</span>
           <MatrixDisplay M={M} rows={size.rows} cols={size.cols} />
           <span className="font-bold">=</span>
           <MatrixDisplay M={result.map(r => r.map(v => parseFloat(v.toFixed(4))))} rows={size.rows} cols={size.cols} />
        </div>
      </div>
    );
  };

  const renderREF = (matrix: 'A' | 'B') => {
    const M = matrix === 'A' ? matrixA : matrixB;
    const size = matrix === 'A' ? sizeA : sizeB;
    
    const refMatrix = getREF(M, size.rows, size.cols);
    
    return (
      <div className="space-y-4 overflow-x-auto">
        <h3 className="font-bold">Row Echelon Form (REF) of Matrix {matrix}:</h3>
        <div className="flex gap-4 items-center w-max">
           <MatrixDisplay M={M} rows={size.rows} cols={size.cols} />
           <span className="font-bold">→</span>
           <MatrixDisplay M={refMatrix.map(r => r.map(v => parseFloat(v.toFixed(4)) === 0 ? 0 : parseFloat(v.toFixed(4))))} rows={size.rows} cols={size.cols} />
        </div>
      </div>
    );
  };

  const renderRank = (matrix: 'A' | 'B') => {
    const M = matrix === 'A' ? matrixA : matrixB;
    const size = matrix === 'A' ? sizeA : sizeB;
    
    const rank = getRank(M, size.rows, size.cols);
    const refMatrix = getREF(M, size.rows, size.cols);
    
    return (
      <div className="space-y-4 overflow-x-auto">
        <h3 className="font-bold">Rank of Matrix {matrix}:</h3>
        <div className="flex gap-4 items-center w-max">
           <MatrixDisplay M={M} rows={size.rows} cols={size.cols} />
           <span className="font-bold">→</span>
           <MatrixDisplay M={refMatrix.map(r => r.map(v => parseFloat(v.toFixed(4)) === 0 ? 0 : parseFloat(v.toFixed(4))))} rows={size.rows} cols={size.cols} />
        </div>
        <p className="text-lg mt-4 font-bold text-indigo-600">Rank = {rank}</p>
        <p className="text-sm">The rank is the number of non-zero rows in the Row Echelon Form.</p>
      </div>
    );
  };
`;

content = content.replace(
  "return (\n    <div className={cn(",
  renderFuncsStr + "\n  return (\n    <div className={cn("
);

// 4. Update the scalar inputs in Matrix A and Matrix B headers
const matrixAHeader = `<div className="flex gap-2 text-sm items-center">
                 <button 
                   onClick={() => handleTranspose('A')}
                   className={cn("px-2 py-1 rounded border text-xs font-medium transition-all", theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-300" : "bg-white border-slate-300 hover:bg-slate-100 text-slate-700")}
                 >
                   Transpose
                 </button>
                 <label>Size:</label>
                 <select 
                   className={cn("p-1 rounded border", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                   value={\`\${sizeA.rows}x\${sizeA.cols}\`}
                   onChange={(e) => {
                     const [r, c] = e.target.value.split('x').map(Number);
                     setSizeA({ rows: r, cols: c });
                   }}
                 >
                   {[1,2,3].map(r => [1,2,3].map(c => <option key={\`\${r}x\${c}\`} value={\`\${r}x\${c}\`}>{r}x{c}</option>))}
                 </select>
               </div>`;

const matrixAHeaderRepl = `<div className="flex gap-2 text-sm items-center flex-wrap">
                 <div className="flex items-center gap-1 border-r pr-2 mr-1 border-slate-300/50">
                    <label className="text-xs">k=</label>
                    <input 
                      type="number" 
                      value={scalarA} 
                      onChange={e => setScalarA(parseFloat(e.target.value) || 0)} 
                      className={cn("w-12 p-1 rounded border text-xs", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                    />
                 </div>
                 <button 
                   onClick={() => handleTranspose('A')}
                   className={cn("px-2 py-1 rounded border text-xs font-medium transition-all", theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-300" : "bg-white border-slate-300 hover:bg-slate-100 text-slate-700")}
                 >
                   Transpose
                 </button>
                 <label>Size:</label>
                 <select 
                   className={cn("p-1 rounded border", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                   value={\`\${sizeA.rows}x\${sizeA.cols}\`}
                   onChange={(e) => {
                     const [r, c] = e.target.value.split('x').map(Number);
                     setSizeA({ rows: r, cols: c });
                   }}
                 >
                   {[1,2,3].map(r => [1,2,3].map(c => <option key={\`\${r}x\${c}\`} value={\`\${r}x\${c}\`}>{r}x{c}</option>))}
                 </select>
               </div>`;

content = content.replace(matrixAHeader, matrixAHeaderRepl);

const matrixBHeader = `<div className="flex gap-2 text-sm items-center">
                 <button 
                   onClick={() => handleTranspose('B')}
                   className={cn("px-2 py-1 rounded border text-xs font-medium transition-all", theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-300" : "bg-white border-slate-300 hover:bg-slate-100 text-slate-700")}
                 >
                   Transpose
                 </button>
                 <label>Size:</label>
                 <select 
                   className={cn("p-1 rounded border", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                   value={\`\${sizeB.rows}x\${sizeB.cols}\`}
                   onChange={(e) => {
                     const [r, c] = e.target.value.split('x').map(Number);
                     setSizeB({ rows: r, cols: c });
                   }}
                 >
                   {[1,2,3].map(r => [1,2,3].map(c => <option key={\`\${r}x\${c}\`} value={\`\${r}x\${c}\`}>{r}x{c}</option>))}
                 </select>
               </div>`;

const matrixBHeaderRepl = `<div className="flex gap-2 text-sm items-center flex-wrap">
                 <div className="flex items-center gap-1 border-r pr-2 mr-1 border-slate-300/50">
                    <label className="text-xs">k=</label>
                    <input 
                      type="number" 
                      value={scalarB} 
                      onChange={e => setScalarB(parseFloat(e.target.value) || 0)} 
                      className={cn("w-12 p-1 rounded border text-xs", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                    />
                 </div>
                 <button 
                   onClick={() => handleTranspose('B')}
                   className={cn("px-2 py-1 rounded border text-xs font-medium transition-all", theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-300" : "bg-white border-slate-300 hover:bg-slate-100 text-slate-700")}
                 >
                   Transpose
                 </button>
                 <label>Size:</label>
                 <select 
                   className={cn("p-1 rounded border", theme === 'dark' ? "bg-slate-800 border-slate-700" : "bg-white border-slate-300")}
                   value={\`\${sizeB.rows}x\${sizeB.cols}\`}
                   onChange={(e) => {
                     const [r, c] = e.target.value.split('x').map(Number);
                     setSizeB({ rows: r, cols: c });
                   }}
                 >
                   {[1,2,3].map(r => [1,2,3].map(c => <option key={\`\${r}x\${c}\`} value={\`\${r}x\${c}\`}>{r}x{c}</option>))}
                 </select>
               </div>`;

content = content.replace(matrixBHeader, matrixBHeaderRepl);

// 5. Add new buttons
const btnStr = `<button 
            onClick={() => setOperation('invB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'invB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Inv(B)
          </button>
          <button 
            onClick={() => setOperation('scalarA')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'scalarA' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            k×A
          </button>
          <button 
            onClick={() => setOperation('scalarB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'scalarB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            k×B
          </button>
          <button 
            onClick={() => setOperation('refA')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'refA' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            REF(A)
          </button>
          <button 
            onClick={() => setOperation('refB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'refB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            REF(B)
          </button>
          <button 
            onClick={() => setOperation('rankA')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'rankA' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Rank(A)
          </button>
          <button 
            onClick={() => setOperation('rankB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'rankB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Rank(B)
          </button>`;

content = content.replace(
  `<button 
            onClick={() => setOperation('invB')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all", operation === 'invB' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            Inv(B)
          </button>`,
  btnStr
);

// 6. Add to render conditions
const conditionsStr = `{operation === 'invA' && renderInverse('A')}
            {operation === 'invB' && renderInverse('B')}
            {operation === 'scalarA' && renderScalar('A')}
            {operation === 'scalarB' && renderScalar('B')}
            {operation === 'refA' && renderREF('A')}
            {operation === 'refB' && renderREF('B')}
            {operation === 'rankA' && renderRank('A')}
            {operation === 'rankB' && renderRank('B')}`;

content = content.replace(
  `{operation === 'invA' && renderInverse('A')}
            {operation === 'invB' && renderInverse('B')}`,
  conditionsStr
);

fs.writeFileSync(file, content);
console.log('Patched MatrixCalculatorModal');
