import { convertLaTeXToSpokenText } from './utils';

export interface ActivitySummaryData {
  overview: {
    topic: string;
    subTopics: string[];
    duration: string;
    date: string;
    mode: string;
    professor: string;
    attendance: number;
    status: 'Completed' | 'Partial' | 'Interrupted';
  };
  topicsCovered: {
    mainTopic: string;
    items: { name: string; completed: boolean }[];
    total: number;
    completed: number;
    rate: number;
  };
  keyConcepts: { title: string; description: string; points: string[] }[];
  figuresUsed: { title: string; purpose: string; elements: string[]; animation: string; examRelevance: string }[];
  formulasPresented: { written: string; spoken: string; application: string }[];
  examplesWorked: { question: string; solution: string[]; answer: string; method: string }[];
  questionsAsked: { type: string; questions: string[] }[];
  studentQuestions: { student: string; question: string; answer: string }[];
  misconceptions: { issue: string; correction: string; explanation: string }[];
  mnemonics: { name: string; description: string; items: string[] }[];
  examPrep: { type: string; count: number; covered: boolean }[];
  compExam: { type: string; count: number; covered: boolean }[];
  engagementMoments: { title: string; response: string }[];
  animationsUsed: { name: string; type: string; duration: string; purpose: string }[];
  summaryLayers: { name: string; delivered: boolean; content: string }[];
  practiceQuestions: { level: 'Easy' | 'Medium' | 'Hard' | 'Competitive'; question: string }[];
  homework: { tasks: string[]; preview: string; prep: string[] };
  performanceMetrics: { category: string; rating: number; max: number }[];
  improvementAreas: { point: string; priority: 'High' | 'Medium' | 'Low'; implementation: string }[];
  nextPreview: { topic: string; connection: string; bridge: string; prerequisites: string[]; itemsToBring: string[] };
}

export function generateLectureActivitySummary(
  topicTitle: string,
  markdownContent: string
): ActivitySummaryData {
  const cleanTitle = topicTitle.replace(/###|##|#/g, '').trim();

  // Dynamic Generator for all topics
  const equations = [...markdownContent.matchAll(/(?:\$\$([\s\S]*?)\$\$|\$([^$\n]+)\$)/g)]
    .map(m => m[1] || m[2])
    .filter(f => f.trim().length > 1);

  const keyConceptsFromText = markdownContent.match(/##+\s*([^\n]+)/g)?.map(h => h.replace(/##+\s*/, '')) || [];
  
  return {
    overview: {
      topic: cleanTitle || "Advanced Science",
      subTopics: keyConceptsFromText.slice(0, 5).length > 0 ? keyConceptsFromText.slice(0, 5) : ["Core Definitions", "Mathematical Foundations", "Exam Practice"],
      duration: "45 minutes",
      date: new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
      mode: "Classroom Slate (3D Interactive)",
      professor: "Professor Clarity",
      attendance: 42,
      status: "Completed"
    },
    topicsCovered: {
      mainTopic: cleanTitle || "Advanced Science",
      items: [
        { name: "Historical Overview & Definition", completed: true },
        { name: "Mathematical & Physical Constants", completed: true },
        { name: "Key Experimental Evidence", completed: true },
        { name: "Worked Conceptual Calculations", completed: true },
        { name: "School Board Exam Syllabus Checklist", completed: true },
        { name: "National Entrance Exam Preparation", completed: true }
      ],
      total: 6,
      completed: 6,
      rate: 100
    },
    keyConcepts: keyConceptsFromText.slice(0, 4).map((concept, idx) => ({
      title: concept,
      description: `Critical core principle covering the academic foundations of ${cleanTitle}.`,
      points: [
        `Analysis of standard formulas and physical boundaries associated with ${concept}.`,
        `Thorough derivation and experimental observations presented on the 3D smartboard.`
      ]
    })).concat(keyConceptsFromText.length === 0 ? [
      {
        title: "Foundational Postulates",
        description: "Essential starting points of the topic",
        points: [
          "Understanding the primary laws and boundary parameters.",
          "Verifying experimental constants and units of measurement on the chalkboard."
        ]
      }
    ] : []),
    figuresUsed: [
      {
        title: "Figure 1: Conceptual Vector Model",
        purpose: `Visualize forces, variables, or system components relating to ${cleanTitle}`,
        elements: ["Reference coordinates", "Primary vectors", "System boundaries"],
        animation: "Responsive coordinates glow with automated pan-and-zoom focal tracking",
        examRelevance: "High (Often required schematic representation in board exams)"
      }
    ],
    formulasPresented: equations.slice(0, 3).map(eq => ({
      written: eq,
      spoken: convertLaTeXToSpokenText(eq),
      application: `Calculates key relational properties within ${cleanTitle}.`
    })).concat(equations.length === 0 ? [
      {
        written: "F = m \\cdot a",
        spoken: "Force equals mass times acceleration",
        application: "Newton's second law of motion, demonstrating the kinetic rate relation."
      }
    ] : []),
    examplesWorked: [
      {
        question: `Calculate the physical yield or constant boundary value under standard units for a typical ${cleanTitle} experiment.`,
        solution: [
          "Step 1: Identify all given parameters and convert to standard SI units.",
          "Step 2: State the primary balanced governing formula.",
          "Step 3: Substitute known constants and isolate the unknown variable.",
          "Step 4: Solve mathematically and attach the correct physical unit badge."
        ],
        answer: "Relational constant verified mathematically.",
        method: "Step-by-step mathematical board proof."
      }
    ],
    questionsAsked: [
      {
        type: "Professor's Classroom Prompts",
        questions: [
          "How does this value behave if we decrease our surface boundary distance?",
          "Can you spot the common unit trap in this formula?"
        ]
      }
    ],
    studentQuestions: [
      {
        student: "Aarav (Virtual Seat 5)",
        question: `How does this specific theory hold up under extreme physical parameters?`,
        answer: `Brilliant intuition, Aarav! Under extreme scales, we must apply relativistic or quantum corrections, but for our board exams and standard curriculum, the classical model works beautifully!`
      }
    ],
    misconceptions: [
      {
        issue: "Assuming scalar logic applies to vector equations directly.",
        correction: "Ensure vector direction is factored in using standard component splits.",
        explanation: "Combining magnitudes algebraically without angles is the most common exam point loss in numerical questions."
      }
    ],
    mnemonics: [
      {
        name: `The ${cleanTitle.slice(0, 5)} Master Guide`,
        description: "A fast memory aid for remembering steps",
        items: [
          "1. Read and list given variables.",
          "2. Choose the correct governing equation.",
          "3. Perform algebraic isolation of the term.",
          "4. Double check physical units of the final answer."
        ]
      }
    ],
    examPrep: [
      { type: "Very Short Answer Definition checks", count: 10, covered: true },
      { type: "Short Derivations & Explanations", count: 5, covered: true },
      { type: "Long Answer Comprehensive Essay", count: 3, covered: true }
    ],
    compExam: [
      { type: "JEE / NEET Single Choice MCQs", count: 10, covered: true },
      { type: "Assertion-Reason Relationship Checks", count: 5, covered: true }
    ],
    engagementMoments: [
      { title: "Socratic Inquiry Opening", response: "High student hand-raise rate on hook question." }
    ],
    animationsUsed: [
      { name: "Visual Grid Calibration", type: "Focal zoom animation", duration: "2 seconds", purpose: "Aligning camera perfectly with active chalkboard coordinate cells" }
    ],
    summaryLayers: [
      { name: "Layer 1: Lightning Recap", delivered: true, content: "Delivered immediately after equations were written on board." }
    ],
    practiceQuestions: [
      { level: "Easy", question: `Define the primary governing laws of ${cleanTitle}.` },
      { level: "Medium", question: "Derive the primary formula showing the relation between the key parameters." }
    ],
    homework: {
      tasks: [
        "Complete all exercises at the end of the chapter in your workbook.",
        "Derive the primary equations three times from memory in your revision notes."
      ],
      preview: "Advanced practical applications and upcoming experimental models.",
      prep: ["Review basic prerequisites", "Check standard formulas in the appendix"]
    },
    performanceMetrics: [
      { category: "Syllabus Compliance", rating: 5, max: 5 },
      { category: "Visual Figure Delivery", rating: 4.8, max: 5 },
      { category: "Practice Problems Worked", rating: 4.7, max: 5 }
    ],
    improvementAreas: [
      { point: "Spend more time outlining the historical context of the primary discovery.", priority: "Low", implementation: "Add a 2-minute introductory timeline story to the opening phase." }
    ],
    nextPreview: {
      topic: `Advanced Applications of ${cleanTitle}`,
      connection: "Now that we have mastered the core theoretical mechanics, we will look at how it drives modern physical technology.",
      bridge: "Today we cracked the theoretical code. Next time, we build the machines that use it. See you in the next lecture!",
      prerequisites: ["Mastery of today's core equations", "Basic calculus differentiation concepts"],
      itemsToBring: ["Calculators and geometric grid tools", "Your completed practice worksheet"]
    }
  };
}
