export interface BioValidationRule {
  key: string;
  label: string;
  unit: string;
  minAllowed: number;
  maxAllowed: number;
  warningMin: number;
  warningMax: number;
  warningMinMsg: string;
  warningMaxMsg: string;
}

export const BIO_RULES: Record<string, BioValidationRule> = {
  temperature: {
    key: 'temperature',
    label: 'Temperature',
    unit: '°C',
    minAllowed: -10,
    maxAllowed: 60,
    warningMin: 10,
    warningMax: 40,
    warningMinMsg: 'Warning: Low temperature (<10°C). Enzyme kinetic rate drops drastically & metabolic processes freeze.',
    warningMaxMsg: 'Warning: Thermal stress threshold exceeded (>40°C). High risk of enzyme denaturation & cell damage!'
  },
  ph: {
    key: 'ph',
    label: 'pH Level',
    unit: 'pH',
    minAllowed: 0,
    maxAllowed: 14,
    warningMin: 4.0,
    warningMax: 10.0,
    warningMinMsg: 'Warning: Acidic environment (<4.0 pH). Disruption of membrane potential & protein denaturation risk.',
    warningMaxMsg: 'Warning: Alkaline environment (>10.0 pH). Denaturation of essential structural enzymes & ion imbalance.'
  },
  grassGrowth: {
    key: 'grassGrowth',
    label: 'Grass Growth Rate',
    unit: 'x',
    minAllowed: 1.0,
    maxAllowed: 5.0,
    warningMin: 1.5,
    warningMax: 4.5,
    warningMinMsg: 'Warning: Low primary biomass growth (1.0x - 1.5x). Prey population faces severe starvation pressure.',
    warningMaxMsg: 'Warning: High biomass yield (>4.5x). Rapid prey population surge may strain ecosystem carrying capacity.'
  },
  oxygenLevel: {
    key: 'oxygenLevel',
    label: 'Oxygen (O2) Saturation',
    unit: '%',
    minAllowed: 0,
    maxAllowed: 100,
    warningMin: 5,
    warningMax: 80,
    warningMinMsg: 'Warning: Hypoxic condition (<5% O2). Severe limitation on aerobic mitochondrial ATP synthesis.',
    warningMaxMsg: 'Warning: Hyperoxic condition (>80% O2). Elevated risk of reactive oxygen species (ROS) toxicity.'
  },
  saltConc: {
    key: 'saltConc',
    label: 'Salinity / Salt Conc',
    unit: 'M',
    minAllowed: 0.01,
    maxAllowed: 2.0,
    warningMin: 0.05,
    warningMax: 0.8,
    warningMinMsg: 'Warning: Hypotonic condition (<0.05M). Risk of osmotic swelling & cell lysis in non-walled cells.',
    warningMaxMsg: 'Warning: Hypertonic condition (>0.8M). Severe osmotic dehydration & plasmolysis risk.'
  },
  n0: {
    key: 'n0',
    label: 'Initial Population (N0)',
    unit: '',
    minAllowed: 10,
    maxAllowed: 500,
    warningMin: 20,
    warningMax: 400,
    warningMinMsg: 'Warning: Small initial founder population (<20). Susceptible to genetic drift & stochastic extinction.',
    warningMaxMsg: 'Warning: Large initial population (>400). Immediate resource exhaustion & habitat overcrowding.'
  },
  carryingCapacityK: {
    key: 'carryingCapacityK',
    label: 'Carrying Capacity (K)',
    unit: '',
    minAllowed: 50,
    maxAllowed: 2000,
    warningMin: 100,
    warningMax: 1800,
    warningMinMsg: 'Warning: Low carrying capacity (<100). Micro-habitat bottleneck with tight ecological ceiling.',
    warningMaxMsg: 'Warning: High carrying capacity (>1800). Heavy environmental footprint pressure on habitat resources.'
  }
};

export interface ValidationResult {
  value: number;
  clamped: boolean;
  isWarning: boolean;
  warningMessage?: string;
  statusType: 'normal' | 'warning' | 'error';
}

export function validateBioVariable(
  ruleKey: keyof typeof BIO_RULES,
  requestedVal: number,
  notifyCallback?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void
): ValidationResult {
  const rule = BIO_RULES[ruleKey];
  if (!rule) {
    return { value: requestedVal, clamped: false, isWarning: false, statusType: 'normal' };
  }

  let finalVal = requestedVal;
  let clamped = false;

  // Enforce biological hard bounds (e.g. preventing negative temperature below -10°C or impossible pH levels)
  if (requestedVal < rule.minAllowed) {
    finalVal = rule.minAllowed;
    clamped = true;
  } else if (requestedVal > rule.maxAllowed) {
    finalVal = rule.maxAllowed;
    clamped = true;
  }

  let isWarning = false;
  let warningMessage = '';

  if (finalVal <= rule.warningMin) {
    isWarning = true;
    warningMessage = rule.warningMinMsg;
  } else if (finalVal >= rule.warningMax) {
    isWarning = true;
    warningMessage = rule.warningMaxMsg;
  }

  if (clamped) {
    const clampMsg = `Limit reached: ${rule.label} bounded to biologically plausible range [${rule.minAllowed}${rule.unit} - ${rule.maxAllowed}${rule.unit}].`;
    notifyCallback?.(clampMsg, 'warning');
  } else if (isWarning && warningMessage) {
    notifyCallback?.(warningMessage, 'warning');
  }

  return {
    value: finalVal,
    clamped,
    isWarning,
    warningMessage,
    statusType: clamped ? 'error' : isWarning ? 'warning' : 'normal'
  };
}
