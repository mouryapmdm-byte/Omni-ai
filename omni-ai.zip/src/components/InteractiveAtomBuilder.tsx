import React, { useState } from 'react';
import { cn } from '@/src/lib/utils';
import { Atom, Plus, Minus, RotateCcw, Sparkles, BookOpen, ExternalLink, ShieldCheck, ShieldAlert, Zap, Layers } from 'lucide-react';

interface ElementData {
  symbol: string;
  name: string;
  category: string;
}

const ELEMENT_MAP: Record<number, ElementData> = {
  1: { symbol: 'H', name: 'Hydrogen', category: 'Reactive Nonmetal' },
  2: { symbol: 'He', name: 'Helium', category: 'Noble Gas' },
  3: { symbol: 'Li', name: 'Lithium', category: 'Alkali Metal' },
  4: { symbol: 'Be', name: 'Beryllium', category: 'Alkaline Earth Metal' },
  5: { symbol: 'B', name: 'Boron', category: 'Metalloid' },
  6: { symbol: 'C', name: 'Carbon', category: 'Reactive Nonmetal' },
  7: { symbol: 'N', name: 'Nitrogen', category: 'Reactive Nonmetal' },
  8: { symbol: 'O', name: 'Oxygen', category: 'Reactive Nonmetal' },
  9: { symbol: 'F', name: 'Fluorine', category: 'Halogen' },
  10: { symbol: 'Ne', name: 'Neon', category: 'Noble Gas' },
  11: { symbol: 'Na', name: 'Sodium', category: 'Alkali Metal' },
  12: { symbol: 'Mg', name: 'Magnesium', category: 'Alkaline Earth Metal' },
  13: { symbol: 'Al', name: 'Aluminum', category: 'Post-Transition Metal' },
  14: { symbol: 'Si', name: 'Silicon', category: 'Metalloid' },
  15: { symbol: 'P', name: 'Phosphorus', category: 'Reactive Nonmetal' },
  16: { symbol: 'S', name: 'Sulfur', category: 'Reactive Nonmetal' },
  17: { symbol: 'Cl', name: 'Chlorine', category: 'Halogen' },
  18: { symbol: 'Ar', name: 'Argon', category: 'Noble Gas' }
};

interface InteractiveAtomBuilderProps {
  theme: 'light' | 'dark';
  onOpenChapter: (chapterNumber: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const InteractiveAtomBuilder: React.FC<InteractiveAtomBuilderProps> = ({
  theme,
  onOpenChapter,
  showNotification
}) => {
  const [protons, setProtons] = useState<number>(6); // Carbon by default
  const [neutrons, setNeutrons] = useState<number>(6);
  const [electrons, setElectrons] = useState<number>(6);

  const element = ELEMENT_MAP[protons] || {
    symbol: 'Uun',
    name: protons > 18 ? 'Superheavy Transuranic Element' : 'Unknown / Subatomic Void',
    category: 'Hypothetical / Synthetic'
  };

  const netCharge = protons - electrons;
  const massNumber = protons + neutrons;
  
  // Stability assessment
  const isStable = Math.abs(neutrons - protons) <= Math.ceil(protons * 0.3) && protons > 0 && protons <= 18;
  const isNeutral = netCharge === 0;

  const handleReset = () => {
    setProtons(6);
    setNeutrons(6);
    setElectrons(6);
    showNotification?.('Atom builder reset to Carbon-12 neutral state.', 'info');
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-y-auto p-6 md:p-8 selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-slate-50/50 text-slate-900"
    )}>
      {/* Header Banner */}
      <div className={cn(
        "p-6 rounded-3xl border mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl",
        theme === 'dark' ? "bg-gradient-to-r from-violet-950/60 via-slate-900 to-indigo-950/40 border-violet-900/40" : "bg-gradient-to-r from-violet-50 via-white to-indigo-50 border-violet-100"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-violet-600 to-indigo-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-violet-500/30">
            <Atom size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-violet-500/10 text-violet-600 dark:text-violet-400 border border-violet-500/20">
                Interactive Virtual Laboratory
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Interactive Atom Builder
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Construct atoms by adding subatomic particles (protons, neutrons, electrons) and observe real-time element identity, charge, and nuclear stability.
            </p>
          </div>
        </div>

        <button
          onClick={handleReset}
          className="flex items-center gap-2 bg-violet-500/10 hover:bg-violet-500/20 text-violet-600 dark:text-violet-400 px-4 py-2.5 rounded-2xl font-bold text-xs border border-violet-500/20 transition-all cursor-pointer active:scale-95"
        >
          <RotateCcw size={16} />
          <span>Reset Atom</span>
        </button>
      </div>

      {/* Main Builder Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Visual Bohr Model & Particle Controls */}
        <div className={cn(
          "lg:col-span-2 p-6 md:p-8 rounded-3xl border shadow-xl flex flex-col justify-between",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div>
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-700/60">
              <h3 className="text-lg font-black tracking-tight">Real-Time Bohr Model & Nucleus Visualizer</h3>
              <div className="flex items-center gap-2">
                <span className={cn(
                  "text-xs font-bold px-3 py-1 rounded-xl border flex items-center gap-1.5",
                  isStable ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20" : "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20"
                )}>
                  {isStable ? <ShieldCheck size={14} /> : <ShieldAlert size={14} />}
                  <span>{isStable ? 'Stable Isotope' : 'Unstable / Radioactive'}</span>
                </span>
              </div>
            </div>

            {/* Bohr Model Graphical Arena */}
            <div className="relative w-full h-72 flex items-center justify-center my-4 overflow-hidden rounded-2xl bg-slate-950/40 border border-slate-800/60">
              {/* Concentric Electron Shell orbits */}
              <div className="absolute w-36 h-36 rounded-full border border-violet-500/20 animate-[spin_20s_linear_infinite]" />
              <div className="absolute w-52 h-52 rounded-full border border-indigo-500/20 animate-[spin_30s_linear_infinite_reverse]" />
              <div className="absolute w-68 h-68 rounded-full border border-blue-500/20 animate-[spin_40s_linear_infinite]" />

              {/* Central Nucleus Cluster */}
              <div className="relative z-10 w-16 h-16 rounded-full bg-gradient-to-br from-violet-600 to-indigo-700 shadow-2xl shadow-violet-500/50 flex flex-col items-center justify-center text-white border-2 border-white/20">
                <span className="text-xs font-black">{protons}p⁺</span>
                <span className="text-[10px] font-mono opacity-80">{neutrons}n⁰</span>
              </div>

              {/* Floating Electrons Indicator Tag */}
              <div className="absolute bottom-4 left-4 text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-slate-900/80 text-violet-300 border border-slate-700">
                Electrons Orbiting: {electrons} {netCharge !== 0 ? `(Net ${netCharge > 0 ? `+${netCharge}` : netCharge})` : ''}
              </div>
            </div>

            {/* Particle Controller Buttons */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              {/* Protons Control */}
              <div className="p-4 rounded-2xl border bg-slate-900/40 border-slate-700/60 flex flex-col items-center justify-between">
                <div className="text-xs font-black uppercase tracking-wider text-violet-400 mb-2">Protons (Atomic No.)</div>
                <div className="text-2xl font-black mb-3">{protons}</div>
                <div className="flex items-center gap-2 w-full">
                  <button
                    onClick={() => { setProtons(Math.max(0, protons - 1)); showNotification?.('Removed proton', 'info'); }}
                    className="flex-1 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center transition-colors cursor-pointer active:scale-95"
                  >
                    <Minus size={16} />
                  </button>
                  <button
                    onClick={() => { setProtons(protons + 1); showNotification?.('Added proton', 'info'); }}
                    className="flex-1 p-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white flex items-center justify-center transition-colors cursor-pointer active:scale-95"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* Neutrons Control */}
              <div className="p-4 rounded-2xl border bg-slate-900/40 border-slate-700/60 flex flex-col items-center justify-between">
                <div className="text-xs font-black uppercase tracking-wider text-indigo-400 mb-2">Neutrons (Mass)</div>
                <div className="text-2xl font-black mb-3">{neutrons}</div>
                <div className="flex items-center gap-2 w-full">
                  <button
                    onClick={() => { setNeutrons(Math.max(0, neutrons - 1)); showNotification?.('Removed neutron', 'info'); }}
                    className="flex-1 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center transition-colors cursor-pointer active:scale-95"
                  >
                    <Minus size={16} />
                  </button>
                  <button
                    onClick={() => { setNeutrons(neutrons + 1); showNotification?.('Added neutron', 'info'); }}
                    className="flex-1 p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center transition-colors cursor-pointer active:scale-95"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* Electrons Control */}
              <div className="p-4 rounded-2xl border bg-slate-900/40 border-slate-700/60 flex flex-col items-center justify-between">
                <div className="text-xs font-black uppercase tracking-wider text-blue-400 mb-2">Electrons (Charge)</div>
                <div className="text-2xl font-black mb-3">{electrons}</div>
                <div className="flex items-center gap-2 w-full">
                  <button
                    onClick={() => { setElectrons(Math.max(0, electrons - 1)); showNotification?.('Removed electron', 'info'); }}
                    className="flex-1 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center transition-colors cursor-pointer active:scale-95"
                  >
                    <Minus size={16} />
                  </button>
                  <button
                    onClick={() => { setElectrons(electrons + 1); showNotification?.('Added electron', 'info'); }}
                    className="flex-1 p-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center transition-colors cursor-pointer active:scale-95"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Element Summary & Properties Card */}
        <div className={cn(
          "p-6 md:p-8 rounded-3xl border shadow-xl flex flex-col justify-between",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div>
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-700 text-white flex items-center justify-center text-2xl font-black shadow-lg">
                  {element.symbol}
                </div>
                <div>
                  <h3 className="text-xl font-black tracking-tight">{element.name}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{element.category}</p>
                </div>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/80 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Atomic Number (Z):</span>
                  <span className="font-mono font-bold">{protons}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Mass Number (A):</span>
                  <span className="font-mono font-bold">{massNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Net Electrical Charge:</span>
                  <span className={cn(
                    "font-mono font-bold",
                    netCharge === 0 ? "text-emerald-400" : "text-amber-400"
                  )}>
                    {netCharge === 0 ? '0 (Neutral Atom)' : netCharge > 0 ? `+${netCharge} (Cation)` : `${netCharge} (Anion)`}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/80">
                <span className="font-black uppercase tracking-wider text-slate-400 block mb-2">Isotope Nomenclature</span>
                <div className="font-mono text-sm font-bold text-violet-400">
                  ^{massNumber}_{protons}{element.symbol} ({element.name}-{massNumber})
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/80">
                <span className="font-black uppercase tracking-wider text-slate-400 block mb-2">Atomic Structure Rules</span>
                <p className="text-slate-400 leading-relaxed">
                  Protons define the fundamental element identity. Neutrons determine nuclear stability and isotopes. Electrons govern chemical bonding and ionic charge.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-violet-600 dark:text-violet-400">
              <BookOpen size={14} />
              <span>Fundamental Chemistry Structure</span>
            </div>
            <button
              onClick={() => onOpenChapter(1)}
              className="flex items-center gap-1 bg-violet-50 hover:bg-violet-600 text-violet-600 hover:text-white dark:bg-violet-950/60 dark:hover:bg-violet-600 dark:text-violet-300 text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              <span>Read Textbook</span>
              <ExternalLink size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
