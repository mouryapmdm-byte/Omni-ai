import { DiagnosticQuestion, UserResponse } from './types';

/**
 * 3-Parameter Logistic (3PL) Item Response Theory Engine
 * Computes probability of correct response given student ability theta.
 *
 * P(θ) = c + (1 - c) / (1 + e^(-1.7 * a * (θ - b)))
 *
 * where:
 * - θ: Student latent ability (-3.0 to +3.0)
 * - b: Item difficulty (-2.5 to +2.5)
 * - a: Item discrimination (0.5 to 2.0)
 * - c: Pseudo-guessing parameter (typically 0.25 for 4 options)
 */
export class IRTEngine {
  private static D = 1.702; // Scaling constant to approximate normal ogive

  /**
   * Probability of correct response
   */
  public static calculateProbability(
    theta: number,
    difficulty: number,
    discrimination: number = 1.0,
    pseudoGuessing: number = 0.25
  ): number {
    const exponent = -this.D * discrimination * (theta - difficulty);
    // Guard against numeric overflow
    if (exponent > 30) return pseudoGuessing;
    if (exponent < -30) return 1.0;
    const expTerm = Math.exp(exponent);
    return pseudoGuessing + (1 - pseudoGuessing) / (1 + expTerm);
  }

  /**
   * Item Information Function (Fisher Information)
   * Quantifies how much statistical information the item provides at ability level theta.
   */
  public static calculateInformation(
    theta: number,
    difficulty: number,
    discrimination: number = 1.0,
    pseudoGuessing: number = 0.25
  ): number {
    const P = this.calculateProbability(theta, difficulty, discrimination, pseudoGuessing);
    const Q = 1 - P;
    if (P <= pseudoGuessing || P >= 1.0) return 0.001;

    const numerator = Math.pow(this.D * discrimination, 2) * Math.pow(P - pseudoGuessing, 2) * Q;
    const denominator = Math.pow(1 - pseudoGuessing, 2) * P;
    return Math.max(0.001, numerator / denominator);
  }

  /**
   * Bayesian Expected A Posteriori (EAP) ability estimation
   * Uses numerical quadrature over standard normal prior N(0, 1).
   * Stable, bounded, and never diverges even with all-correct or all-wrong answers.
   */
  public static updateAbilityEstimate(
    responses: Array<{ isCorrect: boolean; question: DiagnosticQuestion }>,
    priorMean: number = 0.0,
    priorVariance: number = 1.0
  ): { theta: number; standardError: number; confidenceInterval: [number, number] } {
    if (responses.length === 0) {
      return {
        theta: priorMean,
        standardError: Math.sqrt(priorVariance),
        confidenceInterval: [-1.96 * Math.sqrt(priorVariance), 1.96 * Math.sqrt(priorVariance)]
      };
    }

    // Quadrature nodes from -4.0 to +4.0 with step 0.1
    const nodes: number[] = [];
    const minTheta = -4.0;
    const maxTheta = 4.0;
    const step = 0.1;
    for (let t = minTheta; t <= maxTheta; t += step) {
      nodes.push(parseFloat(t.toFixed(2)));
    }

    // Prior density: N(priorMean, priorVariance)
    const priorDensities = nodes.map(t => {
      const diff = t - priorMean;
      return (1 / Math.sqrt(2 * Math.PI * priorVariance)) * Math.exp(-(diff * diff) / (2 * priorVariance));
    });

    // Compute likelihood at each node
    const posterior = nodes.map((t, idx) => {
      let logLikelihood = 0;
      for (const r of responses) {
        const p = this.calculateProbability(
          t,
          r.question.difficulty,
          r.question.discrimination,
          r.question.pseudoGuessing
        );
        const term = r.isCorrect ? Math.max(1e-9, p) : Math.max(1e-9, 1 - p);
        logLikelihood += Math.log(term);
      }
      return Math.exp(logLikelihood) * priorDensities[idx];
    });

    // Normalize posterior
    const sumPosterior = posterior.reduce((a, b) => a + b, 0);
    if (sumPosterior === 0 || isNaN(sumPosterior)) {
      return {
        theta: priorMean,
        standardError: 0.8,
        confidenceInterval: [priorMean - 1.5, priorMean + 1.5]
      };
    }

    // Compute posterior mean (EAP estimate)
    let eapTheta = 0;
    for (let i = 0; i < nodes.length; i++) {
      const weight = posterior[i] / sumPosterior;
      eapTheta += nodes[i] * weight;
    }

    // Compute posterior standard deviation (Standard Error of Measurement)
    let variance = 0;
    for (let i = 0; i < nodes.length; i++) {
      const weight = posterior[i] / sumPosterior;
      const diff = nodes[i] - eapTheta;
      variance += diff * diff * weight;
    }

    const standardError = Math.max(0.18, Math.sqrt(variance));
    const lower = parseFloat((eapTheta - 1.96 * standardError).toFixed(2));
    const upper = parseFloat((eapTheta + 1.96 * standardError).toFixed(2));

    return {
      theta: parseFloat(eapTheta.toFixed(2)),
      standardError: parseFloat(standardError.toFixed(2)),
      confidenceInterval: [lower, upper]
    };
  }

  /**
   * Converts latent ability θ (-3 to +3) to standard intuitive percentage (0 - 100%)
   */
  public static thetaToPercentage(theta: number): number {
    // Sigmoid mapping: θ = 0 -> 50%, θ = +2 -> ~85%, θ = -2 -> ~15%
    const p = 1 / (1 + Math.exp(-1.1 * theta));
    return Math.round(p * 100);
  }

  /**
   * Decides if diagnostic stopping criterion is met:
   * 1. Minimum 12 questions answered AND Standard Error <= 0.30
   * 2. OR Maximum 20 questions reached
   */
  public static isStoppingConditionMet(
    questionsAnswered: number,
    standardError: number,
    maxQuestions: number = 20,
    minQuestions: number = 12
  ): boolean {
    if (questionsAnswered >= maxQuestions) return true;
    if (questionsAnswered >= minQuestions && standardError <= 0.30) return true;
    return false;
  }
}
