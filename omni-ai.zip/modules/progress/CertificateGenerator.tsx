export * from '../../src/modules/progress/CertificateGenerator';
