# Universal AI Tutor Chat Architecture — Omni AI

## 1. Executive Overview & Universal Philosophy
The **Universal AI Tutor** in Omni AI is a unified pedagogical intelligence engine serving students across:
- **Boards**: CBSE, ICSE / ISC, IB (PYP, MYP, DP), Cambridge (Primary, Lower Secondary, IGCSE, AS/A-Level), State Boards (Maharashtra, Tamil Nadu, Karnataka, UP, Kerala, Gujarat), NIOS, and Custom syllabi.
- **Classes**: Primary (Class 1–5), Middle (Class 6–8), Secondary (Class 9–10), Senior Secondary (Class 11–12), Competitive (JEE Main/Advanced, NEET, SAT, ACT, CUET, Olympiads), and Undergraduate (Class 13+).
- **Disciplines**: STEM (Mathematics, Physics, Chemistry, Biology, Computer Science, IT), Humanities (History, Geography, Civics, Economics, Psychology, Sociology, Political Science), Commerce (Accountancy, Business Studies), and Languages.
- **Languages**: 16+ languages (English, Hindi, Tamil, Telugu, Bengali, Marathi, Kannada, Malayalam, Gujarati, Punjabi, Urdu, Odia, Assamese, French, German, Spanish) with native typography and bilingual scientific terminology.

### The 10 Universal Principles
1. **One Engine, Infinite Adaptations**: Single code path dynamically calibrated via structured student profile metadata.
2. **Curriculum as Ground Truth**: Syllabi, learning objectives, and standard formulas are queried from structured databases; the AI never hallucinates outside the prescribed syllabus.
3. **Class-Aware Depth**: Vocabulary, sentence complexity, and cognitive load automatically scale across grades (Class 3 storytelling $\rightarrow$ Class 12 technical rigor).
4. **Board-Aware Patterns**: Automatically aligns response style with exam blueprints (CBSE step-marking, ICSE structured derivations, IB inquiry essays, Cambridge mark schemes).
5. **Language-Agnostic with Universal Math**: Spoken and vernacular explanations generated in the student's chosen language, while mathematical and chemical notation remains standardized in LaTeX.
6. **Exam-Aligned**: Prepares students specifically for their target milestones (Board Exams, JEE, NEET, SAT, School Terms).
7. **Age-Appropriate Guardrails**: Strict filters prevent cognitive mismatch and restrict out-of-scope advanced terminology for primary students.
8. **Culturally Grounded Analogies**: Contextualizes concepts with regional touchpoints (e.g. cricket, festivals, and trains in India; sports and road trips internationally).
9. **Text Generation Only**: Generates words and explanations exclusively; math evaluation, simulation logic, and diagram rendering remain in deterministic code.
10. **Multi-Stage Verification**: Validates every generated output across 7 safety and correctness vectors before student presentation.

---

## 2. Architecture & Pipeline

```
┌──────────────────────────────────────────────────────────────┐
│                   STUDENT CHAT UI                            │
│   (Select Board, Class, Subject, Language, Target Exam)      │
└───────────────────────┬──────────────────────────────────────┘
                        ↓
┌──────────────────────────────────────────────────────────────┐
│              INTENT CLASSIFIER (Microseconds)                │
│  Classify: explain | question | analogy | summarise |         │
│            clarify | example | check                         │
└───────────────────────┬──────────────────────────────────────┘
                        ↓
┌──────────────────────────────────────────────────────────────┐
│              CURRICULUM CONTEXT BUILDER                      │
│  - Syllabus database lookup                                  │
│  - Standard formulas & prerequisites                         │
│  - Board strategy & class strategy lookup                    │
│  - Vocabulary & depth calibration                            │
└───────────────────────┬──────────────────────────────────────┘
                        ↓
┌──────────────────────────────────────────────────────────────┐
│              UNIVERSAL CACHE LOOKUP                          │
│  Key: board::class::subject::chapter::topic::intent::lang    │
│  If hit → Return instantly (<10ms)                           │
└───────────────────────┬──────────────────────────────────────┘
                        ↓
┌──────────────────────────────────────────────────────────────┐
│              AI GENERATION (Gemini API)                      │
│  - Model: gemini-2.5-flash (calibrated temperature 0.3)      │
│  - Enforces strict JSON Schema                               │
│  - Retries up to 3 times on transient network blips          │
└───────────────────────┬──────────────────────────────────────┘
                        ↓
┌──────────────────────────────────────────────────────────────┐
│              UNIVERSAL VERIFIER                              │
│  1. Format Check (valid JSON)                                │
│  2. Schema Check (intent payload structure)                  │
│  3. Fact Check (syllabus keyword overlap)                    │
│  4. Math Syntax Check (LaTeX balanced delimiters)            │
│  5. Age-Appropriateness (filter cognitive mismatches)        │
│  6. Language Script Verification                             │
│  7. Safety & Guardrails (educational content enforcement)    │
└───────────────────────┬──────────────────────────────────────┘
                        ↓
┌──────────────────────────────────────────────────────────────┐
│              CACHE STORE & PRESENTATION                      │
│  - Store verified response in memory & browser storage       │
│  - Render Markdown & KaTeX equations                         │
│  - Present exam takeaways & analogy limits                   │
└──────────────────────────────────────────────────────────────┘
```

---

## 3. Module Inventory

| File Path | Description |
| :--- | :--- |
| `src/modules/ai-tutor/types.ts` | Complete TypeScript type definitions (BoardId, ClassLevel, TutorRequest, TutorResponse, CurriculumContext, etc.). |
| `src/modules/ai-tutor/strategies/BoardStrategies.ts` | Strategy definitions for CBSE, ICSE, IB DP/MYP, Cambridge, State Boards, and NIOS. |
| `src/modules/ai-tutor/strategies/ClassStrategies.ts` | Pedagogical depth, word counts, and question patterns for Class 1 through Undergraduate. |
| `src/modules/ai-tutor/strategies/LanguageStrategy.ts` | Prompts and bilingual clarity generators for 16+ languages. |
| `src/modules/ai-tutor/prompts/universal-templates.ts` | Calibrated prompt templates for explanations, practice questions, analogies, and summaries. |
| `src/modules/ai-tutor/IntentClassifier.ts` | Microsecond regex and heuristic intent classifier. |
| `src/modules/ai-tutor/CurriculumService.ts` | Ground-truth syllabus database, standard formulas, and offline fallback responses. |
| `src/modules/ai-tutor/UniversalContextBuilder.ts` | Student profile loader and curriculum context compiler. |
| `src/modules/ai-tutor/UniversalVerifier.ts` | Seven-point multi-stage validator enforcing JSON correctness, LaTeX balance, and age safety. |
| `src/modules/ai-tutor/UniversalTutorCache.ts` | Composite multi-tier caching engine with TTL and hit-rate analytics. |
| `src/modules/ai-tutor/AIService.ts` | Resilient generation client with retries and latency tracking. |
| `src/modules/ai-tutor/UniversalAITutorChat.ts` | Central orchestration engine. |
| `src/components/UniversalAITutorModal.tsx` | Full-screen interactive UI modal with live Board/Class/Language switching and KaTeX rendering. |

---

## 4. Cost & Performance Model
- **Token Efficiency**: Average explanation request runs ~400 tokens; cached responses consume 0 API tokens.
- **Cache Hit Rate**: Reaches $>80\%$ for shared syllabus topics within the same board and class.
- **Estimated Cost**: $<\$0.10$ per active student per month across all grade levels.
- **Latency**:
  - Cache Hit: $<15$ ms
  - AI Generation: $\sim 600 - 1200$ ms with Gemini 2.5 Flash
  - Offline Fallback: Instant (0 ms)
