const fs = require('fs');
let content = fs.readFileSync('src/components/MatrixCalculatorModal.tsx', 'utf8');
content = content.replace(/\\`/g, '`');
content = content.replace(/\\\$/g, '$');
fs.writeFileSync('src/components/MatrixCalculatorModal.tsx', content);
console.log("Fixed backticks and dollar signs");
