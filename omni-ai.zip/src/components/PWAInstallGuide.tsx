import React from 'react';
import { Smartphone, Check, X, Share, Tablet, Sparkles, Monitor } from 'lucide-react';
import { cn } from '../lib/utils';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallGuideProps {
  theme?: 'light' | 'dark';
  onClose?: () => void;
}

export const PWAInstallGuide: React.FC<PWAInstallGuideProps> = ({
  theme = 'dark',
  onClose,
}) => {
  const { isIOS, isAndroid, isDesktop } = usePWAInstall();

  return (
    <div className="space-y-5 py-2">
      {/* Device-Specific Instructions */}
      <div className="space-y-3">
        {isIOS ? (
          <div className={cn(
            "p-4 rounded-2xl border space-y-3 text-xs leading-relaxed",
            theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-indigo-50/50 border-indigo-100"
          )}>
            <div className={cn("font-bold flex items-center gap-2", theme === 'dark' ? "text-indigo-400" : "text-indigo-600")}>
              <Share size={14} />
              <span>How to Install on iPhone / iPad (Safari):</span>
            </div>
            <ol className={cn("list-decimal list-inside space-y-1.5 font-medium", theme === 'dark' ? "text-slate-300" : "text-slate-700")}>
              <li>Tap the <strong>Share</strong> button (the square icon with an arrow pointing up) at the bottom or top of Safari.</li>
              <li>Scroll down and tap <strong>Add to Home Screen</strong>.</li>
              <li>Tap <strong>Add</strong> in the top-right corner. The app will appear on your home screen!</li>
            </ol>
          </div>
        ) : isDesktop ? (
          <div className={cn(
            "p-4 rounded-2xl border space-y-3 text-xs leading-relaxed",
            theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-indigo-50/50 border-indigo-100"
          )}>
            <div className={cn("font-bold flex items-center gap-2", theme === 'dark' ? "text-amber-400" : "text-amber-600")}>
              <Monitor size={14} />
              <span>How to Install on Desktop (Chrome, Edge, Safari):</span>
            </div>
            <ol className={cn("list-decimal list-inside space-y-1.5 font-medium", theme === 'dark' ? "text-slate-300" : "text-slate-700")}>
              <li>Look at the <strong>address bar</strong> (URL bar) at the top of your browser.</li>
              <li>Click the <strong>Install icon</strong> (resembling a computer monitor or a circular <code>+</code> button) on the far right of the address bar.</li>
              <li>Or, click the browser menu <strong>(three dots ⋮ or File menu)</strong> and select <strong>Install Omni AI</strong> or **Add to Dock / Applications**.</li>
            </ol>
          </div>
        ) : (
          <div className={cn(
            "p-4 rounded-2xl border space-y-3 text-xs leading-relaxed",
            theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-indigo-50/50 border-indigo-100"
          )}>
            <div className={cn("font-bold flex items-center gap-2", theme === 'dark' ? "text-indigo-400" : "text-indigo-600")}>
              <Sparkles size={14} />
              <span>How to Install on Android Device:</span>
            </div>
            <ol className={cn("list-decimal list-inside space-y-1.5 font-medium", theme === 'dark' ? "text-slate-300" : "text-slate-700")}>
              <li>Tap the browser menu <strong>(three dots ⋮)</strong> in the top right.</li>
              <li>Select <strong>Install App</strong> or <strong>Add to Home screen</strong>.</li>
              <li>Confirm installation to launch with full native standalone experience!</li>
            </ol>
          </div>
        )}

        {/* Supported Platforms Grid */}
        <div className="grid grid-cols-3 gap-2.5 pt-2">
          <div className={cn(
            "p-3 rounded-xl border flex flex-col items-center justify-center text-center gap-1",
            theme === 'dark' ? "bg-slate-800/40 border-slate-700/60" : "bg-slate-50 border-slate-200"
          )}>
            <Smartphone size={18} className="text-emerald-400" />
            <span className={cn("text-[10px] font-black", theme === 'dark' ? "text-white" : "text-slate-800")}>Smartphones</span>
            <span className={cn("text-[9px] font-bold", theme === 'dark' ? "text-slate-400" : "text-slate-500")}>iOS & Android</span>
          </div>
          <div className={cn(
            "p-3 rounded-xl border flex flex-col items-center justify-center text-center gap-1",
            theme === 'dark' ? "bg-slate-800/40 border-slate-700/60" : "bg-slate-50 border-slate-200"
          )}>
            <Tablet size={18} className="text-indigo-400" />
            <span className={cn("text-[10px] font-black", theme === 'dark' ? "text-white" : "text-slate-800")}>Tablets</span>
            <span className={cn("text-[9px] font-bold", theme === 'dark' ? "text-slate-400" : "text-slate-500")}>iPad & Galaxy</span>
          </div>
          <div className={cn(
            "p-3 rounded-xl border flex flex-col items-center justify-center text-center gap-1",
            theme === 'dark' ? "bg-slate-800/40 border-slate-700/60" : "bg-slate-50 border-slate-200"
          )}>
            <Monitor size={18} className="text-amber-400" />
            <span className={cn("text-[10px] font-black", theme === 'dark' ? "text-white" : "text-slate-800")}>Desktops</span>
            <span className={cn("text-[9px] font-bold", theme === 'dark' ? "text-slate-400" : "text-slate-500")}>Mac & PC</span>
          </div>
        </div>

        {/* Device Perks */}
        <div className={cn("text-[11px] space-y-1.5 pt-1 font-semibold", theme === 'dark' ? "text-slate-400" : "text-slate-600")}>
          <div className="flex items-center gap-2">
            <Check size={12} className="text-emerald-500 shrink-0" />
            <span>Full-screen standalone layout without browser address bars</span>
          </div>
          <div className="flex items-center gap-2">
            <Check size={12} className="text-emerald-500 shrink-0" />
            <span>High-performance touch, stylus, and gesture tracking</span>
          </div>
          <div className="flex items-center gap-2">
            <Check size={12} className="text-emerald-500 shrink-0" />
            <span>Fast cached loading with offline service worker engine</span>
          </div>
        </div>
      </div>

      {onClose && (
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800/25 dark:border-slate-800/40">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition cursor-pointer shadow-md shadow-indigo-600/20"
          >
            Got It, Thanks!
          </button>
        </div>
      )}
    </div>
  );
};
