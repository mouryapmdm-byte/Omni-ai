import React, { useState, useMemo } from 'react';
import { 
  X, 
  Sparkles, 
  Check, 
  Flame, 
  Award, 
  BookOpen, 
  Lightbulb, 
  Compass, 
  Zap, 
  Volume2,
  ShieldCheck,
  BarChart2,
  Layers,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Grid,
  Radio,
  Sliders
} from 'lucide-react';
import { TEACHER_PEDAGOGY_STYLES, TeacherPedagogyStyle, getTeacherStyleById } from '../data/teacherStyles';
import { 
  calculateFidelityMetrics, 
  generateTechniquePreview, 
  compareTechniques,
  FidelityMetricsReport
} from '../services/teacherFidelityEngine';
import { cn } from '../lib/utils';

interface TeacherStyleDiscoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentStyleId: string;
  onSelectStyle: (style: TeacherPedagogyStyle) => void;
  onPlayGreeting?: (greeting: string) => void;
  showNotification?: (msg: string, type: 'info' | 'success' | 'warning' | 'error') => void;
  currentTopic?: string;
  boardContent?: string;
  spokenText?: string;
}

export const TeacherStyleDiscoveryModal: React.FC<TeacherStyleDiscoveryModalProps> = ({
  isOpen,
  onClose,
  currentStyleId,
  onSelectStyle,
  onPlayGreeting,
  showNotification,
  currentTopic = 'Newton\'s Laws of Motion',
  boardContent = '',
  spokenText = ''
}) => {
  const [activeTab, setActiveTab] = useState<'gallery' | 'fidelity_monitor' | 'comparison' | 'preview'>('gallery');
  const [previewStyleId, setPreviewStyleId] = useState<string>(currentStyleId);
  const [isImmersionModeActive, setIsImmersionModeActive] = useState<boolean>(true);

  const activeStyle = useMemo(() => getTeacherStyleById(currentStyleId), [currentStyleId]);

  // Compute live fidelity report
  const fidelityReport: FidelityMetricsReport = useMemo(() => {
    return calculateFidelityMetrics(currentStyleId, currentTopic, boardContent, spokenText);
  }, [currentStyleId, currentTopic, boardContent, spokenText]);

  // Generate comparison cards
  const comparisonCards = useMemo(() => compareTechniques(currentTopic), [currentTopic]);

  // Selected preview data
  const previewData = useMemo(() => generateTechniquePreview(previewStyleId, currentTopic), [previewStyleId, currentTopic]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-slate-900 border-2 border-indigo-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/90 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-amber-500 flex items-center justify-center text-xl shadow-lg shrink-0">
              {activeStyle.avatarIcon}
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                Teacher Technique Fidelity Architect
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold">
                  100% Pedagogy DNA
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Professor Clarity genuinely embodies your selected master teacher's vocabulary, tone, analogies & catchphrases
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-4 pt-3 bg-slate-950/60 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('gallery')}
            className={cn(
              "px-4 py-2.5 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 border-b-2 whitespace-nowrap cursor-pointer",
              activeTab === 'gallery'
                ? "bg-slate-900 text-indigo-400 border-indigo-500"
                : "text-slate-400 hover:text-slate-200 border-transparent"
            )}
          >
            <Grid size={15} />
            Teach Me Like... (Styles Gallery)
          </button>

          <button
            onClick={() => setActiveTab('fidelity_monitor')}
            className={cn(
              "px-4 py-2.5 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 border-b-2 whitespace-nowrap cursor-pointer",
              activeTab === 'fidelity_monitor'
                ? "bg-slate-900 text-emerald-400 border-emerald-500"
                : "text-slate-400 hover:text-slate-200 border-transparent"
            )}
          >
            <BarChart2 size={15} />
            Fidelity Monitor ({fidelityReport.overallScore}%)
          </button>

          <button
            onClick={() => setActiveTab('comparison')}
            className={cn(
              "px-4 py-2.5 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 border-b-2 whitespace-nowrap cursor-pointer",
              activeTab === 'comparison'
                ? "bg-slate-900 text-amber-400 border-amber-500"
                : "text-slate-400 hover:text-slate-200 border-transparent"
            )}
          >
            <Layers size={15} />
            Side-by-Side Comparison
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={cn(
              "px-4 py-2.5 text-xs font-bold rounded-t-xl transition-all flex items-center gap-2 border-b-2 whitespace-nowrap cursor-pointer",
              activeTab === 'preview'
                ? "bg-slate-900 text-cyan-400 border-cyan-500"
                : "text-slate-400 hover:text-slate-200 border-transparent"
            )}
          >
            <Play size={15} />
            30s Technique Preview
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: STYLES GALLERY */}
          {activeTab === 'gallery' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-indigo-950/60 to-purple-950/40 border border-indigo-500/30 rounded-2xl p-4 text-xs sm:text-sm text-indigo-200 flex items-start justify-between gap-3 shadow-lg">
                <div className="flex items-start gap-3">
                  <Sparkles className="text-amber-400 shrink-0 mt-0.5" size={20} />
                  <div>
                    <p className="font-bold text-white mb-0.5">Voice & Prompt Voice Commands</p>
                    <p className="text-slate-300 text-xs">
                      Say or type <span className="font-mono text-amber-300 bg-slate-950 px-2 py-0.5 rounded border border-amber-500/20">"Teach me like Physics Wallah"</span> or <span className="font-mono text-emerald-300 bg-slate-950 px-2 py-0.5 rounded border border-emerald-500/20">"Teach me like Khan Academy"</span> anytime during the 3D lecture!
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      setIsImmersionModeActive(!isImmersionModeActive);
                      showNotification?.(isImmersionModeActive ? 'Standard mode enabled' : '100% Full Technique Immersion Mode Active!', 'info');
                    }}
                    className={cn(
                      "px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border",
                      isImmersionModeActive
                        ? "bg-emerald-600 text-white border-emerald-400 shadow-md"
                        : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
                    )}
                  >
                    <ShieldCheck size={14} />
                    {isImmersionModeActive ? 'Immersion 100%' : 'Standard Mode'}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {TEACHER_PEDAGOGY_STYLES.map((style) => {
                  const isSelected = style.id === currentStyleId;
                  return (
                    <div
                      key={style.id}
                      onClick={() => {
                        onSelectStyle(style);
                        showNotification?.(`Switched teaching pedagogy to "${style.name}"!`, 'success');
                      }}
                      className={cn(
                        "p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between relative group",
                        isSelected
                          ? "bg-indigo-950/40 border-indigo-400 shadow-xl shadow-indigo-950/50 ring-2 ring-indigo-400/30"
                          : "bg-slate-800/40 border-slate-700/80 hover:border-slate-600 hover:bg-slate-800/70"
                      )}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">{style.avatarIcon}</span>
                            <div>
                              <h3 className="text-sm font-black text-white group-hover:text-indigo-300 transition-colors">
                                {style.name}
                              </h3>
                              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                                {style.badge}
                              </span>
                            </div>
                          </div>
                          {isSelected ? (
                            <div className="w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950 shadow-md">
                              <Check size={14} className="stroke-[3]" />
                            </div>
                          ) : (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setPreviewStyleId(style.id);
                                setActiveTab('preview');
                                onPlayGreeting?.(style.sampleGreeting);
                              }}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                              title="Preview 30s sample"
                            >
                              <Play size={14} />
                            </button>
                          )}
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed mb-3">
                          {style.tagline}
                        </p>

                        {/* Catchphrases badges */}
                        <div className="flex flex-wrap gap-1.5 mb-2">
                          {style.catchphrases?.slice(0, 2).map((phrase, idx) => (
                            <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-900/80 text-amber-300 border border-amber-500/20 italic truncate max-w-[180px]">
                              "{phrase}"
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                        <span className="text-slate-400 italic truncate max-w-[200px]">
                          "{style.speechPrefix}"
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectStyle(style);
                            showNotification?.(`Applied "${style.name}"!`, 'success');
                          }}
                          className={cn(
                            "px-3.5 py-1 rounded-xl font-bold transition-all text-[11px] cursor-pointer",
                            isSelected
                              ? "bg-emerald-600 text-white"
                              : "bg-slate-700 group-hover:bg-indigo-600 text-white"
                          )}
                        >
                          {isSelected ? 'Active Mode' : 'Select Technique'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: REAL-TIME FIDELITY MONITOR */}
          {activeTab === 'fidelity_monitor' && (
            <div className="space-y-4 animate-fadeIn">
              {/* Top Summary Banner */}
              <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="relative flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full border-4 border-indigo-500/30 flex items-center justify-center bg-slate-900">
                      <span className="text-xl font-black text-white">{fidelityReport.overallScore}%</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-base font-black text-white">{activeStyle.name}</h3>
                      <span className={cn("text-xs px-2.5 py-0.5 rounded-full font-bold border", fidelityReport.statusColor)}>
                        {fidelityReport.statusBadge}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Live Pedagogical Verification on Topic: <span className="text-amber-300 font-semibold">{fidelityReport.topicTitle}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right text-xs">
                    <p className="text-slate-400">Signature Anchors Active</p>
                    <p className="font-bold text-emerald-400">{fidelityReport.signatureAnchorsCount} Phrases Locked</p>
                  </div>

                  <button
                    onClick={() => {
                      showNotification?.(`Fidelity Audit Re-Calibrated! Current score: ${fidelityReport.overallScore}%`, 'success');
                    }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    title="Recalibrate metrics"
                  >
                    <RotateCcw size={16} />
                  </button>
                </div>
              </div>

              {/* 8-Dimension Breakdown Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {Object.entries(fidelityReport.dimensions).map(([key, dim]) => (
                  <div key={key} className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-xl flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{dim.label}</span>
                        <span className={cn(
                          "text-[10px] px-2 py-0.2 rounded font-mono font-bold",
                          dim.score >= 95 ? "bg-emerald-500/20 text-emerald-300" : "bg-amber-500/20 text-amber-300"
                        )}>
                          {dim.score}%
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-snug">{dim.details}</p>
                    </div>

                    <div className="shrink-0 pt-0.5">
                      {dim.status === 'perfect' ? (
                        <CheckCircle2 size={18} className="text-emerald-400" />
                      ) : (
                        <AlertTriangle size={18} className="text-amber-400" />
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Catchphrase & Drift Status */}
              <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                  <ShieldCheck size={16} className="text-indigo-400" />
                  Active Catchphrases & Real-Time Drift Guard
                </h4>

                <div className="flex flex-wrap gap-2">
                  {activeStyle.catchphrases?.map((phrase, idx) => (
                    <span key={idx} className="text-xs px-3 py-1 rounded-xl bg-indigo-950/60 text-indigo-200 border border-indigo-500/30 flex items-center gap-1.5">
                      <Sparkles size={12} className="text-amber-400" />
                      "{phrase}"
                    </span>
                  ))}
                </div>

                {fidelityReport.autoCorrectionPrompt && (
                  <div className="p-3 bg-rose-950/40 border border-rose-500/30 rounded-xl text-xs text-rose-300 font-mono">
                    {fidelityReport.autoCorrectionPrompt}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: SIDE-BY-SIDE COMPARISON */}
          {activeTab === 'comparison' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl text-xs text-slate-300 flex items-center justify-between">
                <span>Side-by-side pedagogical breakdown for topic: <strong className="text-amber-300">{currentTopic}</strong></span>
                <span className="text-[10px] text-slate-400">6 Master Styles Compared</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {comparisonCards.map((card) => {
                  const isCurrent = card.styleId === currentStyleId;
                  return (
                    <div 
                      key={card.styleId} 
                      className={cn(
                        "p-4 rounded-2xl border-2 transition-all space-y-2.5",
                        isCurrent
                          ? "bg-indigo-950/40 border-indigo-400 shadow-xl"
                          : "bg-slate-950/60 border-slate-800"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{card.avatarIcon}</span>
                          <div>
                            <h4 className="text-sm font-bold text-white">{card.styleName}</h4>
                            <span className="text-[10px] text-amber-400 font-semibold">{card.badge}</span>
                          </div>
                        </div>

                        {isCurrent ? (
                          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                            Active
                          </span>
                        ) : (
                          <button
                            onClick={() => {
                              const sel = getTeacherStyleById(card.styleId);
                              onSelectStyle(sel);
                              showNotification?.(`Selected "${sel.name}"!`, 'success');
                            }}
                            className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold cursor-pointer"
                          >
                            Switch Style
                          </button>
                        )}
                      </div>

                      <div className="p-2.5 bg-slate-900 rounded-xl text-xs text-slate-300 italic">
                        "{card.sampleOpening}"
                      </div>

                      <div className="text-[11px] text-slate-400 flex items-center gap-2">
                        <span className="font-semibold text-slate-300">Signature:</span>
                        <span className="text-amber-300 font-mono">"{card.signaturePhrase}"</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: 30s TECHNIQUE PREVIEW */}
          {activeTab === 'preview' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 bg-gradient-to-r from-slate-950 to-indigo-950/80 border border-slate-800 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{previewData.avatarIcon}</span>
                    <div>
                      <h3 className="text-base font-black text-white">{previewData.styleName}</h3>
                      <p className="text-xs text-slate-400">30-Second Live Demonstration Sampler</p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onPlayGreeting?.(previewData.opening);
                      showNotification?.(`Playing audio sample for ${previewData.styleName}...`, 'info');
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-lg"
                  >
                    <Volume2 size={16} />
                    Listen Sample
                  </button>
                </div>

                <div className="space-y-3 pt-2 border-t border-slate-800">
                  <div className="p-3 bg-slate-900/90 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">Opening Hook</span>
                    <p className="text-xs text-white italic">"{previewData.opening}"</p>
                  </div>

                  <div className="p-3 bg-slate-900/90 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Step-by-Step Explanation</span>
                    <p className="text-xs text-slate-200">{previewData.explanationSnippet}</p>
                  </div>

                  <div className="p-3 bg-slate-900/90 rounded-xl space-y-1">
                    <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">Interactive Practice Check</span>
                    <p className="text-xs text-slate-300">{previewData.practicePrompt}</p>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <div className="flex flex-wrap gap-1.5">
                    {previewData.keyCharacteristics.map((char, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        ✓ {char}
                      </span>
                    ))}
                  </div>

                  <button
                    onClick={() => {
                      const sel = getTeacherStyleById(previewStyleId);
                      onSelectStyle(sel);
                      showNotification?.(`Activated "${sel.name}" style for live lecture!`, 'success');
                      onClose();
                    }}
                    className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors cursor-pointer"
                  >
                    Activate {previewData.styleName}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/90 flex items-center justify-between text-xs text-slate-400">
          <span>Selected Style: <strong className="text-white">{activeStyle.name}</strong> ({fidelityReport.overallScore}% Fidelity)</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition-colors cursor-pointer"
          >
            Apply & Return to Slate
          </button>
        </div>
      </div>
    </div>
  );
};
