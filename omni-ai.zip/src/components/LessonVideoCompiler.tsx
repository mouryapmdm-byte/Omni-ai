import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, Loader2, Download, Play, Pause, CheckCircle2, AlertCircle, 
  Tv, Info, RefreshCw, X, ChevronRight, ChevronLeft, FileText, 
  Volume2, VolumeX, Eye, BookOpen, Layers, Award, ChevronDown, Globe,
  Share2, Copy, Check
} from 'lucide-react';
import { generateAIResponse, generateSpeech, convertPcmToWav } from '../lib/gemini';
import { LANGUAGES } from '../lib/constants';
import { downloadFileFromUrl } from '../lib/utils';
import { stripAllRawMarkdown, formatLaTeXToUnicode } from '../lib/streaming/cleanStreamingMarkdown';

interface LessonVideoCompilerProps {
  lessonTitle: string;
  chapterTitle: string;
  subject: string;
  difficulty: string;
  languageCode?: string;
  onGenerateVideo: (prompt: string) => Promise<string | undefined | null>;
  onClose: () => void;
  onPublishToEduTube?: (video: any) => void;
}

interface Slide {
  slideTitle: string;
  narrationText: string;
  equations: string[];
  points: string[];
  visualDiagram: string;
  diagramType: 'graph' | 'vectors' | 'bonds' | 'steps' | 'logic';
}

export const LessonVideoCompiler: React.FC<LessonVideoCompilerProps> = ({
  lessonTitle,
  chapterTitle,
  subject,
  difficulty,
  languageCode,
  onGenerateVideo,
  onClose,
  onPublishToEduTube
}) => {
  // Language Selection
  const [selectedLang, setSelectedLang] = useState<string>(languageCode || 'en');
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);

  // EduTube Publisher state
  const [publishTitle, setPublishTitle] = useState(`Lecture: ${lessonTitle}`);
  const [publishChannel, setPublishChannel] = useState('Professor Clarity');
  const [publishDesc, setPublishDesc] = useState(`An interactive conceptual voice-narrated micro-lesson about ${lessonTitle} under "${chapterTitle}". Explains definitions, equations, and solutions with extreme standard academic rigor.`);
  const [isPublished, setIsPublished] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  const handlePublishToEduTube = () => {
    if (!onPublishToEduTube) return;
    setIsPublishing(true);
    
    // Simulate slight network latency for a high-fidelity publishing feel
    setTimeout(() => {
      const compiledVideo = {
        id: 'v_' + Math.random().toString(36).substring(2, 15),
        title: publishTitle,
        source: 'AI Studio (Omni AI)',
        duration: `${slides.length > 0 ? Math.floor(slides.length * 15 / 60) : 0}:${String((slides.length * 15) % 60).padStart(2, '0')}`,
        thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=640&h=360&q=80',
        url: stockVideoUrl || 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
        channelTitle: publishChannel,
        viewCount: Math.floor(Math.random() * 10) + 1,
        publishedAt: new Date(),
        isAIGenerated: true,
        topic: lessonTitle,
        subject: subject,
        prompt: `Professional educational lecture video about "${lessonTitle}".`,
        likes: 0,
        description: publishDesc,
        events: slides.map((s, idx) => ({
          timestamp: idx * 15,
          event: s.slideTitle
        }))
      };

      onPublishToEduTube(compiledVideo);
      setIsPublishing(false);
      setIsPublished(true);
    }, 1200);
  };

  // Modes & Statuses
  const [activeTab, setActiveTab] = useState<'interactive' | 'stock'>('interactive');
  const [isCompiling, setIsCompiling] = useState(true);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('Initializing custom video engine...');
  const [logs, setLogs] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Video output (if any)
  const [stockVideoUrl, setStockVideoUrl] = useState<string>('https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4');

  // Interactive Slides Data
  const [slides, setSlides] = useState<Slide[]>([]);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<'169' | '916'>('169');
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [copiedTextType, setCopiedTextType] = useState<'twitter' | 'linkedin' | 'storyboard' | null>(null);
  
  // Speech Voice Audio state
  const [audioUrls, setAudioUrls] = useState<Record<number, string>>({});
  const [isSynthesizingVoice, setIsSynthesizingVoice] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Canvas context for interactive mathematical illustrations
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Compile process
  useEffect(() => {
    let active = true;

    // Pause audio when starting new compile
    if (audioRef.current) {
      audioRef.current.pause();
    }
    setIsPlaying(false);
    setAudioUrls({});
    setIsCompiling(true);
    setProgress(0);
    setCurrentSlideIndex(0);

    const compileCustomLesson = async () => {
      try {
        const langObj = LANGUAGES.find(l => l.code === selectedLang) || LANGUAGES[0];
        setLogs([`[System] Booting interactive video compiler engine in ${langObj.name} (${langObj.native})...`]);
        setProgress(10);
        await new Promise(resolve => setTimeout(resolve, 800));
        if (!active) return;

        // Step 1: Query Gemini-3-Flash for educational slides and visual script
        setStatusText(`Designing board drawings and translating lecture to ${langObj.name}...`);
        setLogs(prev => [...prev, `[LLM] Drafting interactive storyboard in ${langObj.name} with Gemini 3...`]);
        setProgress(30);

        const prompt = `You are a high-fidelity visual blackboard storyboard generator.
Generate a structured learning storyboard for the lesson "${lessonTitle}" inside the chapter "${chapterTitle}".
The level is "${difficulty}" and the subject is "${subject}".
The presentation text, visual descriptions, and narrator voice-over MUST be generated in the language: ${langObj.name} (${langObj.native}).

You must output a strictly structured JSON block with a "slides" array containing exactly 3 detailed slides.
Each slide must contain:
1. "slideTitle" (string, short and concise, translated in ${langObj.name})
2. "narrationText" (string, 2-3 clear professional sentences explaining the concept in ${langObj.name}. Keep it highly educational)
3. "equations" (array of strings representing LaTeX-style or text-style mathematical formulas/chemical bounds/logic rules. Keep variables and numbers in standard notation)
4. "points" (array of 2-3 short bullet points expanding on definitions, translated in ${langObj.name})
5. "visualDiagram" (string, brief instructions in English on how to draw a matching visual diagram on a chalkboard, e.g. "Draw an exponential growth curve from left to right")
6. "diagramType" (one of: 'graph', 'vectors', 'bonds', 'steps', 'logic')

Output ONLY the raw JSON block without markdown formatting or code blocks.`;

        const responseText = await generateAIResponse(prompt, {
          model: 'gemini-3.6-flash',
          responseMimeType: 'application/json'
        });

        if (!active) return;
        
        let compiledSlides: Slide[] = [];
        try {
          const parsed = JSON.parse(responseText.trim());
          if (parsed && Array.isArray(parsed.slides)) {
            compiledSlides = parsed.slides;
          }
        } catch (e) {
          console.error("Failed to parse JSON response:", responseText, e);
        }

        // Fallback slides in case of parsing errors
        if (compiledSlides.length === 0 || lessonTitle.toLowerCase().includes('electric charge') || lessonTitle.toLowerCase().includes('gauss') || lessonTitle.toLowerCase().includes('potential') || lessonTitle.toLowerCase().includes('capacitor') || lessonTitle.toLowerCase().includes('dielectric') || lessonTitle.toLowerCase().includes('resistance') || lessonTitle.toLowerCase().includes('ohm') || lessonTitle.toLowerCase().includes('dc circuit') || lessonTitle.toLowerCase().includes('kirchhoff') || lessonTitle.toLowerCase().includes('potentiometer') || lessonTitle.toLowerCase().includes('moving charge') || lessonTitle.toLowerCase().includes('magnetic field') || lessonTitle.toLowerCase().includes('biot') || lessonTitle.toLowerCase().includes('torque') || lessonTitle.toLowerCase().includes('galvanometer') || lessonTitle.toLowerCase().includes('earth') || lessonTitle.toLowerCase().includes('terrestrial magnetism') || lessonTitle.toLowerCase().includes('substance') || lessonTitle.toLowerCase().includes('diamagnetic') || lessonTitle.toLowerCase().includes('ferromagnetic') || lessonTitle.toLowerCase().includes('induction') || lessonTitle.toLowerCase().includes('faraday') || lessonTitle.toLowerCase().includes('alternating current') || lessonTitle.toLowerCase().includes('ac circuit') || lessonTitle.toLowerCase().includes('transformer') || lessonTitle.toLowerCase().includes('electromagnetic wave') || lessonTitle.toLowerCase().includes('em wave') || lessonTitle.toLowerCase().includes('spectrum') || lessonTitle.toLowerCase().includes('ray optics') || lessonTitle.toLowerCase().includes('optical instrument') || lessonTitle.toLowerCase().includes('telescope') || lessonTitle.toLowerCase().includes('microscope') || lessonTitle.toLowerCase().includes('prism') || lessonTitle.toLowerCase().includes('wave optics') || lessonTitle.toLowerCase().includes('huygen') || lessonTitle.toLowerCase().includes('wavefront') || lessonTitle.toLowerCase().includes('wave nature') || lessonTitle.toLowerCase().includes('interference') || lessonTitle.toLowerCase().includes('diffraction') || lessonTitle.toLowerCase().includes('polarization') || lessonTitle.toLowerCase().includes('dual nature') || lessonTitle.toLowerCase().includes('radiation') || lessonTitle.toLowerCase().includes('photoelectric') || lessonTitle.toLowerCase().includes('matter wave') || lessonTitle.toLowerCase().includes('atoms') || lessonTitle.toLowerCase().includes('rutherford') || lessonTitle.toLowerCase().includes('bohr') || lessonTitle.toLowerCase().includes('hydrogen spectrum') || lessonTitle.toLowerCase().includes('nuclei') || lessonTitle.toLowerCase().includes('radioactivity') || lessonTitle.toLowerCase().includes('mass defect') || lessonTitle.toLowerCase().includes('binding energy') || lessonTitle.toLowerCase().includes('semiconductor') || lessonTitle.toLowerCase().includes('logic gate') || lessonTitle.toLowerCase().includes('transistor') || lessonTitle.toLowerCase().includes('diode') || lessonTitle.toLowerCase().includes('communication') || lessonTitle.toLowerCase().includes('modulation') || lessonTitle.toLowerCase().includes('amplitude') || lessonTitle.toLowerCase().includes('bandwidth') || lessonTitle.toLowerCase().includes('reflection') || lessonTitle.toLowerCase().includes('spherical mirror') || lessonTitle.toLowerCase().includes('concave mirror') || lessonTitle.toLowerCase().includes('convex mirror') || lessonTitle.toLowerCase().includes('refraction') || lessonTitle.toLowerCase().includes('total internal reflection') || lessonTitle.toLowerCase().includes('optical fiber') || lessonTitle.toLowerCase().includes('snell') || lessonTitle.toLowerCase().includes('spherical surface') || lessonTitle.toLowerCase().includes('lenses') || lessonTitle.toLowerCase().includes('lens maker') || lessonTitle.toLowerCase().includes('dispersion') || lessonTitle.toLowerCase().includes('minimum deviation')) {
          if (lessonTitle.toLowerCase().includes('communication') || lessonTitle.toLowerCase().includes('modulation') || lessonTitle.toLowerCase().includes('bandwidth')) {
            compiledSlides = [
              {
                slideTitle: "1. ELEMENTS OF COMMUNICATION & SIGNAL PROPAGATION MODES",
                narrationText: "Welcome to Chapter 42: Communication Systems. We explore communication components, signal bandwidths, and Ground, Sky, and Space Wave propagation.",
                equations: [`d_{\\text{max}} = \\sqrt{2 R h_T} + \\sqrt{2 R h_R} \\quad (\\text{LOS Range})`, `f_c = 9 \\sqrt{N_{\\text{max}}} \\quad (\\text{Ionospheric Critical Frequency})`],
                points: [
                  "1. Core Elements: Information Source → Transmitter → Channel (Medium + Noise) → Receiver → User.",
                  "2. Signal Bandwidth: Audio speech (300 Hz – 3.1 kHz), Music (20 kHz), Television video signals (4.2 MHz).",
                  "3. Ground Wave Propagation: Surface waves follow Earth's curvature (< 2 MHz); attenuated by ground energy absorption.",
                  "4. Sky Wave Propagation: Ionospheric reflection of sky waves (3–30 MHz); critical frequency f_c depends on electron density N_max.",
                  "5. Space Wave Propagation: Line-of-sight (LOS) propagation (> 30 MHz); maximum LOS range determined by antenna heights h_T and h_R."
                ],
                visualDiagram: "Draw Earth curvature showing Ground Wave along surface, Sky Wave reflecting off Ionosphere, and Space Wave Line-Of-Sight antenna transmission.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. NEED FOR MODULATION & AMPLITUDE MODULATION (AM)",
                narrationText: "We analyze why carrier modulation is essential for long-distance transmission and derive Amplitude Modulation bandwidth and sidebands.",
                equations: [`e_{\\text{AM}}(t) = A_c (1 + \\mu \\sin \\omega_m t) \\sin \\omega_c t`, `\\mu = \\frac{A_m}{A_c}, \\quad \\text{Bandwidth} = 2 f_m`],
                points: [
                  "6. Need for Modulation: Reduces required antenna size (h ≥ λ/4), prevents signal overlapping, and increases effective radiated power P ∝ (1/λ)².",
                  "7. Amplitude Modulation (AM): Carrier amplitude varies in direct proportion to modulating audio signal voltage.",
                  "8. Modulation Index (μ): Ratio of modulating amplitude to carrier amplitude μ = A_m / A_c; μ ≤ 1 prevents distortion.",
                  "9. AM Spectrum & Sidebands: Contains carrier f_c, Upper Sideband USB (f_c + f_m), and Lower Sideband LSB (f_c - f_m); Total Bandwidth = 2 f_m."
                ],
                visualDiagram: "Draw AM wave synthesis: carrier wave, modulating audio wave, resulting AM modulated waveform, and frequency spectrum sidebands.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. AM DEMODULATION & MODERN OPTICAL/SATELLITE NETWORKS",
                narrationText: "We examine diode envelope detection for AM demodulation alongside optical fiber and geostationary satellite communication.",
                equations: [`\\frac{1}{f_c} \\ll R C \\ll \\frac{1}{f_m} \\quad (\\text{Envelope Detector Condition})`, `v_{\\text{satellite}} = \\sqrt{\\frac{G M}{R + h}}`],
                points: [
                  "10. Diode Envelope Detector: Recovers original modulating audio signal from high-frequency AM carrier wave.",
                  "11. RC Time Constant Condition: Must satisfy 1/f_c ≪ RC ≪ 1/f_m for accurate envelope tracking without clipping.",
                  "12. Optical Fiber Communication: Uses Total Internal Reflection (TIR) inside glass fiber core for ultra-high bandwidth data transfer.",
                  "13. Satellite Communication: Geostationary satellites at orbit height ~35,786 km act as transponders relaying global microwave signals."
                ],
                visualDiagram: "Draw Diode Envelope Detector circuit (Diode, Resistor R, Capacitor C) with AM input and smoothed output audio waveform.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('logic gate') || lessonTitle.toLowerCase().includes('de morgan') || lessonTitle.toLowerCase().includes('boolean')) {
            compiledSlides = [
              {
                slideTitle: "1. BINARY LOGIC & BASIC GATES (OR, AND, NOT)",
                narrationText: "Welcome to Chapter 41: Logic Gates. We introduce binary digital signals, Boolean algebra, and basic OR, AND, and NOT logic gates.",
                equations: [`Y = A + B \\quad (\\text{OR Gate})`, `Y = A \\cdot B \\quad (\\text{AND Gate}), \\quad Y = \\bar{A} \\quad (\\text{NOT Gate})`],
                points: [
                  "1. Digital Logic Signal: Operates with two discrete voltage states representing binary logic 0 (Low / 0V) and logic 1 (High / +5V).",
                  "2. OR Gate: Output Y is HIGH (1) if at least one input is HIGH (1); Boolean expression Y = A + B.",
                  "3. AND Gate: Output Y is HIGH (1) only if all inputs are HIGH (1); Boolean expression Y = A · B.",
                  "4. NOT Gate (Inverter): Output Y is the inverse of input A; Boolean expression Y = Ā."
                ],
                visualDiagram: "Draw symbols and complete Truth Tables for basic logic gates: OR, AND, and NOT.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. UNIVERSAL GATES (NAND, NOR) & DE MORGAN'S LAWS",
                narrationText: "We explore universal logic gates NAND and NOR, proving their ability to build all basic gates, and apply De Morgan's laws.",
                equations: [`\\overline{A + B} = \\bar{A} \\cdot \\bar{B} \\quad (\\text{De Morgan Law 1})`, `\\overline{A \\cdot B} = \\bar{A} + \\bar{B} \\quad (\\text{De Morgan Law 2})`],
                points: [
                  "5. NAND Gate: Combination of AND gate followed by NOT gate; Y = (A · B)̄. Outputs LOW only when both inputs are HIGH.",
                  "6. NOR Gate: Combination of OR gate followed by NOT gate; Y = (A + B)̄. Outputs HIGH only when both inputs are LOW.",
                  "7. Universal Property: NAND and NOR gates can be combined to implement any basic logic gate without additional components.",
                  "8. De Morgan's Theorems: Essential rules for Boolean algebra simplification converting NOR to AND with inverted inputs and vice versa."
                ],
                visualDiagram: "Draw NAND and NOR gate logic symbols alongside circuit implementations constructing NOT, AND, and OR gates using NAND only.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. EXCLUSIVE GATES (XOR, XNOR) & DIGITAL LOGIC ICs",
                narrationText: "We examine Exclusive-OR (XOR) and Exclusive-NOR (XNOR) logic gates and digital integrated circuit (IC) packaging scales.",
                equations: [`Y = A \\oplus B = A \\bar{B} + \\bar{A} B \\quad (\\text{XOR Gate})`, `Y = \\overline{A \\oplus B} = A B + \\bar{A} \\bar{B} \\quad (\\text{XNOR Gate})`],
                points: [
                  "9. XOR Gate (Exclusive-OR): Output Y is HIGH (1) if inputs A and B are different; Y = A ⊕ B = A B̄ + Ā B.",
                  "10. XNOR Gate (Exclusive-NOR): Output Y is HIGH (1) if inputs A and B are identical; Y = A B + Ā B̄.",
                  "11. Digital Logic Applications: Parity checkers, binary half-adders/full-adders, digital comparators, and arithmetic logic units (ALU).",
                  "12. Integrated Circuit Packaging: Small Scale Integration (SSI < 10 gates) up to Very Large Scale Integration (VLSI > 10,000 gates)."
                ],
                visualDiagram: "Draw XOR and XNOR gate symbols, Truth Tables, and binary half-adder circuit using XOR and AND gates.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('transistor') || lessonTitle.toLowerCase().includes('amplifier') || lessonTitle.toLowerCase().includes('bjt')) {
            compiledSlides = [
              {
                slideTitle: "1. BJT STRUCTURE, WORKING & CARRIER CURRENTS",
                narrationText: "Welcome to Chapter 40: Junction Transistors. We analyze Bipolar Junction Transistor (BJT) construction, carrier currents, and gain ratios.",
                equations: [`I_E = I_B + I_C`, `\\alpha = \\frac{\\Delta I_C}{\\Delta I_E}, \\quad \\beta = \\frac{\\Delta I_C}{\\Delta I_B} = \\frac{\\alpha}{1 - \\alpha}`],
                points: [
                  "1. BJT Structure: Three-layer semiconductor device (NPN or PNP) consisting of thin, lightly doped Base sandwiched between heavily doped Emitter and moderately doped Collector.",
                  "2. Forward-Reverse Biasing: Emitter-Base junction is forward-biased to inject majority carriers; Collector-Base junction is reverse-biased to collect carriers.",
                  "3. Emitter Current Formula: Total emitter current equals sum of base and collector currents: I_E = I_B + I_C (where I_B ≈ 1-5% of I_E).",
                  "4. Current Gains α & β: Alpha (CB current gain α < 1) and Beta (CE current gain β ≈ 20–500) are related by β = α / (1 - α)."
                ],
                visualDiagram: "Draw NPN and PNP transistor structure, biasing battery connections, and charge carrier flow across Emitter, Base, and Collector.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. COMMON EMITTER (CE) AMPLIFIER & PHASE REVERSAL",
                narrationText: "We examine Common Emitter (CE) input and output characteristics, voltage gain derivation, and 180° output phase reversal.",
                equations: [`A_v = \\frac{\\Delta V_o}{\\Delta V_i} = - \\beta \\frac{R_L}{R_{in}}`, `A_p = A_v \\times \\beta = \\beta^2 \\frac{R_L}{R_{in}}`],
                points: [
                  "5. CE Input Characteristics: Curve of base current I_B vs V_BE at constant V_CE (resembles forward diode V-I curve).",
                  "6. CE Output Characteristics: Curve of collector current I_C vs V_CE at constant I_B (shows Cut-off, Active, and Saturation regions).",
                  "7. Voltage Gain (A_v): Ratio of output signal voltage to input signal voltage; A_v = - β (R_L / R_in).",
                  "8. 180° Phase Reversal: Negative sign indicates output voltage signal is 180° out of phase with input voltage signal in CE mode."
                ],
                visualDiagram: "Draw CE Transistor Amplifier circuit with AC signal generator, load resistor R_L, and 180° inverted output voltage waveform.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. TRANSISTOR AS A SWITCH & LC OSCILLATOR",
                narrationText: "We explore transistor switching between Cut-off and Saturation, and positive feedback LC oscillator circuits.",
                equations: [`f = \\frac{1}{2 \\pi \\sqrt{L C}} \\quad (\\text{Oscillator Frequency})`, `A \\beta = 1 \\quad (\\text{Barkhausen Criterion})`],
                points: [
                  "9. Transistor Switch: Operates in Cut-off region (I_C = 0, OFF state) and Saturation region (V_CE ≈ 0, ON state).",
                  "10. LC Tank Circuit: Inductor L and capacitor C exchange energy periodically to produce high-frequency electrical oscillations.",
                  "11. Positive Feedback Loop: Portion of collector output voltage fed back to base input in phase (0° or 360°) to sustain continuous oscillations.",
                  "12. Barkhausen Criterion: Loop gain A β must equal 1 with zero net phase shift around loop for self-sustained oscillation."
                ],
                visualDiagram: "Draw Transistor LC Oscillator circuit with tank circuit (L, C), inductive feedback coil, and sustained sinusoidal output waveform.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('diode') || lessonTitle.toLowerCase().includes('zener') || lessonTitle.toLowerCase().includes('led') || lessonTitle.toLowerCase().includes('photodiode')) {
            compiledSlides = [
              {
                slideTitle: "1. P-N JUNCTION V-I CHARACTERISTICS & DIODE RESISTANCE",
                narrationText: "Welcome to Chapter 39: Semiconductor Diodes. We explore P-N junction V-I characteristics, Knee voltage, and static vs dynamic diode resistance.",
                equations: [`R_{\\text{dc}} = \\frac{V}{I}, \\quad r_{\\text{ac}} = \\frac{\\Delta V}{\\Delta I}`, `I = I_s \\left( e^{\\frac{e V}{\\eta k T}} - 1 \\right)`],
                points: [
                  "1. V-I Curve: Forward bias curve shows exponential current growth above Knee Voltage (~0.7V for Si, ~0.3V for Ge).",
                  "2. Reverse Bias Curve: Minimal reverse saturation current (I_s ~ μA or nA) flows until breakdown voltage is reached.",
                  "3. Static Resistance (R_dc): Ratio of total DC voltage V to total DC current I at a given operating point.",
                  "4. Dynamic Resistance (r_ac): Reciprocal of slope of V-I curve: r_ac = ΔV / ΔI."
                ],
                visualDiagram: "Draw full P-N junction V-I characteristic curve showing Knee Voltage, Forward Current, Reverse Saturation Current, and Breakdown Voltage.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. ZENER DIODE VOLTAGE REGULATOR & BREAKDOWN MECHANISMS",
                narrationText: "We examine Zener vs Avalanche breakdown mechanisms and Zener diode voltage regulation under fluctuating load and line conditions.",
                equations: [`V_{\\text{out}} = V_Z \\quad (\\text{Constant Regulator Voltage})`, `I_S = I_Z + I_L = \\frac{V_{\\text{in}} - V_Z}{R_S}`],
                points: [
                  "5. Avalanche vs Zener Breakdown: Zener breakdown occurs in heavily doped junctions under strong electric field (~10⁶ V/m); Avalanche occurs in lightly doped junctions via impact ionization.",
                  "6. Zener Diode Regulation: Operates in reverse breakdown; maintains constant terminal voltage V_Z regardless of fluctuations in load current I_L or input voltage V_in.",
                  "7. Series Resistance Calculation: Series resistor R_S limits total current to protect Zener diode from over-heating.",
                  "8. Ripple Factor Suppression: Provides smooth DC voltage output from pulsating DC supply."
                ],
                visualDiagram: "Draw Zener Diode Voltage Regulator circuit diagram: unregulated DC source, series resistor R_S, Zener diode, load resistor R_L, and regulated DC output.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. OPTOELECTRONIC DIODES: LED, PHOTODIODE & SOLAR CELL",
                narrationText: "We study special optoelectronic devices: Light Emitting Diodes (LED), Photodiodes, and Solar Cells.",
                equations: [`E_g = h \\nu = \\frac{h c}{\\lambda} \\quad (\\text{LED Emission})`, `I = I_L - I_s \\left( e^{\\frac{e V}{k T}} - 1 \\right) \\quad (\\text{Solar Cell})`],
                points: [
                  "9. Light Emitting Diode (LED): Forward-biased junction releasing energy as photons via electron-hole recombination; emission wavelength determined by bandgap E_g.",
                  "10. Photodiode: Reverse-biased junction detecting light; absorbed photons (hν > E_g) generate electron-hole pairs increasing reverse photocurrent.",
                  "11. Solar Cell: Unbiased P-N junction converting solar radiation into electrical power via photovoltaic effect.",
                  "12. Photovoltaic Characteristics: Open Circuit Voltage V_oc and Short Circuit Current I_sc determine Solar Cell fill factor."
                ],
                visualDiagram: "Draw structure and V-I characteristics of LED (1st quadrant), Photodiode (3rd quadrant), and Solar Cell (4th quadrant).",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('semiconductor electronics') || lessonTitle.toLowerCase().includes('zener') || lessonTitle.toLowerCase().includes('rectifier')) {
            compiledSlides = [
              {
                slideTitle: "1. ENERGY BANDS IN SOLIDS & INTRINSIC VS EXTRINSIC SEMICONDUCTORS",
                narrationText: "Welcome to Chapter 38: Semiconductor Electronics. We explore energy band gaps in conductors, insulators, and semiconductors, alongside doping mechanisms.",
                equations: [`E_g(\\text{Si}) \\approx 1.1 \\text{ eV}, \\quad E_g(\\text{Ge}) \\approx 0.72 \\text{ eV}`, `n_e \\cdot n_h = n_i^2 \\quad (\\text{Law of Mass Action})`],
                points: [
                  "1. Energy Band Formation: Overlapping atomic orbits in crystals split into Valence Band (VB) and Conduction Band (CB) separated by Forbidden Energy Gap E_g.",
                  "2. Band Gap Classification: Conductors (E_g = 0), Insulators (E_g > 3 eV), and Semiconductors (E_g ≈ 1 eV).",
                  "3. Intrinsic Semiconductors: Pure Si/Ge where thermal agitation creates electron-hole pairs with equal concentrations n_e = n_h = n_i.",
                  "4. Extrinsic Doping: N-Type (doped with pentavalent P/As donors; n_e ≫ n_h) and P-Type (doped with trivalent B/Al acceptors; n_h ≫ n_e)."
                ],
                visualDiagram: "Draw energy band diagrams for Conductor (overlapping), Insulator (large gap E_g > 3 eV), and Semiconductor (small E_g ~ 1 eV with donor/acceptor energy levels).",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. P-N JUNCTION FORMATION, DEPLETION LAYER & V-I CHARACTERISTICS",
                narrationText: "We analyze diffusion and drift currents during P-N junction formation, the resulting potential barrier, and biasing characteristics.",
                equations: [`I = I_e + I_h = e A (n_e v_e + n_h v_h)`, `V_0 \\approx 0.7 \\text{ V (Si)}, \\quad 0.3 \\text{ V (Ge)}`],
                points: [
                  "5. P-N Junction Depletion Region: Carrier diffusion across junction leaves uncompensated donor ions (+ in N) and acceptor ions (- in P), creating internal electric field.",
                  "6. Built-in Potential Barrier (V_0): Halts further net diffusion; V_0 ≈ 0.7 V for Silicon and 0.3 V for Germanium.",
                  "7. Forward Bias Behavior: External potential reduces barrier width and height, causing exponential forward current flow above knee voltage.",
                  "8. Reverse Bias Behavior: External voltage widens potential barrier, suppressing majority current and leaving tiny micro-ampere reverse saturation current."
                ],
                visualDiagram: "Draw P-N junction under Forward Bias and Reverse Bias alongside complete forward and reverse V-I characteristic curves.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. DIODE RECTIFIERS & ZENER DIODE VOLTAGE REGULATION",
                narrationText: "We examine practical applications of P-N junction diodes as half-wave and full-wave AC rectifiers and Zener diode voltage regulators.",
                equations: [`\\eta_{\\text{half}} = 40.6\\%, \\quad \\eta_{\\text{full}} = 81.2\\%`, `V_{\\text{out}} = V_Z \\quad (\\text{Zener Regulation})`],
                points: [
                  "9. Half-Wave Rectifier: Single diode conducts during positive half-cycles only; maximum efficiency η = 40.6%.",
                  "10. Full-Wave Rectifier: Center-tapped transformer or 4-diode bridge conducts during both half-cycles; efficiency η = 81.2%.",
                  "11. Zener Diode Regulation: Operates safely in reverse breakdown region maintaining constant voltage V_Z despite varying input voltage or load current.",
                  "12. Optoelectronic Devices: Photodiode (reverse bias light detector), Light Emitting Diode LED (forward bias photon generator), and Solar Cell (unbiased photovoltage)."
                ],
                visualDiagram: "Draw Full-Wave Rectifier circuit with transformer, diodes, load resistor, and input AC versus smooth DC output waveforms.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('fission') || lessonTitle.toLowerCase().includes('fusion') || lessonTitle.toLowerCase().includes('sources of energy')) {
            compiledSlides = [
              {
                slideTitle: "1. NUCLEAR FISSION REACTION & ENERGY RELEASE",
                narrationText: "Welcome to Chapter 37: Nuclear Fission and Fusion : Sources of Energy. We explore nuclear fission, neutron multiplication, and liquid drop model physics.",
                equations: [`{}^{235}_{92}\\text{U} + {}^1_0\\text{n} \\to {}^{236}_{92}\\text{U}^* \\to {}^{141}_{56}\\text{Ba} + {}^{92}_{36}\\text{Kr} + 3 {}^1_0\\text{n} + 200 \\text{ MeV}`, `Q = (M_{\\text{reactants}} - M_{\\text{products}}) c^2`],
                points: [
                  "1. Nuclear Fission Discovery: Absorption of thermal neutron by U-235 causes target nucleus to split into intermediate daughter fragments.",
                  "2. Liquid Drop Model: Captured neutron induces nuclear surface oscillations, elongating nucleus into dumbbell shape until Coulomb repulsion splits it.",
                  "3. Massive Energy Yield: ~200 MeV energy released per fission event due to mass deficit converted via E = Δm c².",
                  "4. Secondary Neutrons: Average of 2.5 fast neutrons released per fission, providing the foundation for chain reactions."
                ],
                visualDiagram: "Draw U-235 fission event: neutron absorption, dumbbell deformation, splitting into Ba-141 and Kr-92 fragments, and 3 secondary neutrons.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. CONTROLLED CHAIN REACTION & NUCLEAR REACTOR ARCHITECTURE",
                narrationText: "We study multiplication factor k, critical mass conditions, and the engineering safety components of nuclear power reactors.",
                equations: [`k = \\frac{\\text{Neutrons produced in one generation}}{\\text{Neutrons produced in preceding generation}}`, `k = 1 \\quad (\\text{Critical Steady State})`],
                points: [
                  "5. Multiplication Factor (k): k < 1 (subcritical), k = 1 (critical steady state), k > 1 (supercritical explosion).",
                  "6. Critical Mass: Minimum mass of fissionable material required to prevent excessive neutron leakage through surface.",
                  "7. Reactor Moderator & Control: Heavy water (D₂O) or Graphite slows fast neutrons to thermal energies; Cadmium / Boron rods absorb excess neutrons.",
                  "8. Energy Conversion Loop: Coolant transfers thermal heat from reactor core to steam generator driving electric turbines."
                ],
                visualDiagram: "Draw schematic diagram of Nuclear Reactor core: fuel rods, control rods, moderator, coolant circulation loop, heat exchanger, and turbine generator.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. THERMONUCLEAR FUSION & STELLAR PROTON-PROTON CYCLE",
                narrationText: "We examine thermonuclear fusion, high thermal kinetic energy barriers, and the solar Proton-Proton energy cycle.",
                equations: [`4 {}^1_1\\text{H} \\to {}^4_2\\text{He} + 2 e^+ + 2 \\nu_e + 26.7 \\text{ MeV}`, `E_{\\text{fusion/nucleon}} > E_{\\text{fission/nucleon}}`],
                points: [
                  "9. Thermonuclear Fusion: Light nuclei fuse into heavier stable nucleus, releasing far greater energy per unit mass than fission.",
                  "10. Coulomb Barrier: Extreme temperatures (~10⁷ K) and pressures required for thermal kinetic energy to overcome electrostatic repulsion.",
                  "11. Solar Proton-Proton Cycle: Multi-step thermonuclear reaction in Sun's core fusing 4 hydrogen protons into a Helium-4 nucleus emitting 26.7 MeV.",
                  "12. Controlled Tokamak Confinement: Magnetic confinement fusion utilizing toroidal magnetic fields to isolate high-temperature plasma."
                ],
                visualDiagram: "Draw stellar Proton-Proton cycle stages fusing 4 hydrogen protons into a Helium-4 nucleus with positron emission and 26.7 MeV energy release.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('mass-energy') || lessonTitle.toLowerCase().includes('binding energy')) {
            compiledSlides = [
              {
                slideTitle: "1. EINSTEIN'S MASS-ENERGY EQUIVALENCE & ATOMIC MASS UNIT",
                narrationText: "Welcome to Chapter 36: Mass-Energy Equivalence : Nuclear Binding Energy. We study Einstein's mass-energy law, atomic mass units, and energy balance.",
                equations: [`E = m c^2`, `1 \\text{ u} = 1.6605 \\times 10^{-27} \\text{ kg} \\equiv 931.5 \\text{ MeV}`],
                points: [
                  "1. Mass-Energy Equivalence: Mass is a condensed form of energy; mass m can convert into energy E = m c² and vice versa.",
                  "2. Unified Atomic Mass Unit (1 u): Exactly 1/12th the mass of neutral Carbon-12 atom = 1.6605 × 10⁻²⁷ kg.",
                  "3. Energy Equivalent of 1 u: E = (1.6605 × 10⁻²⁷ kg) × (3 × 10⁸ m/s)² = 1.492 × 10⁻¹⁰ J = 931.5 MeV.",
                  "4. Conservation Law: In nuclear transformations, total mass-energy (rest mass energy plus kinetic energy) is strictly conserved."
                ],
                visualDiagram: "Draw diagram illustrating conversion of mass deficit Δm into released energy Q = Δm c².",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. MASS DEFECT, BINDING ENERGY & N/Z STABILITY BELT",
                narrationText: "We derive mass defect Δm, binding energy per nucleon E_bn, and analyze the neutron-to-proton N/Z stability belt.",
                equations: [`\\Delta m = [Z m_p + (A-Z) m_n] - M_{\\text{nucleus}}`, `E_{bn} = \\frac{\\Delta m \\times 931.5}{A} \\text{ MeV}`],
                points: [
                  "5. Nuclear Mass Defect (Δm): Difference between sum of individual constituent nucleon masses and actual rest mass of assembled nucleus.",
                  "6. Nuclear Binding Energy (E_b): Energy released during nuclear assembly or required to separate nucleus into constituent nucleons: E_b = Δm × 931.5 MeV.",
                  "7. Binding Energy Per Nucleon (E_bn): Measures nuclear stability; reaches maximum ~8.8 MeV for Fe-56.",
                  "8. N/Z Stability Belt: Light stable nuclei have N/Z ≈ 1; heavy stable nuclei require N/Z up to 1.56 to overcome proton Coulomb repulsion."
                ],
                visualDiagram: "Draw plot of Neutron Number N versus Proton Number Z showing stable band (N/Z = 1 for light, up to 1.56 for heavy) and decay regions.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. PAIR PRODUCTION, ANNIHILATION & Q-VALUE CALCULATIONS",
                narrationText: "We explore gamma ray pair production, electron-positron pair annihilation, and nuclear reaction Q-value energy balance.",
                equations: [`h \\nu \\to e^- + e^+ \\quad (h \\nu \\ge 1.02 \\text{ MeV})`, `e^- + e^+ \\to 2 \\gamma \\quad (E_\\gamma = 0.511 \\text{ MeV})`],
                points: [
                  "9. Pair Production: High-energy gamma ray photon (hν ≥ 1.02 MeV) near heavy nucleus materializes into electron (e⁻) and positron (e⁺).",
                  "10. Threshold Energy: Rest mass energy of e⁻ or e⁺ is 0.511 MeV, making minimum photon energy requirement 2 × 0.511 = 1.02 MeV.",
                  "11. Pair Annihilation: Slow electron and positron collide and annihilate, releasing two gamma photons emitted in opposite directions for momentum conservation.",
                  "12. Reaction Q-Value: Q = (M_initial - M_final) × 931.5 MeV; positive Q indicates exoergic reaction, negative Q indicates endoergic reaction."
                ],
                visualDiagram: "Draw photon conversion into electron-positron pair in Coulomb field of nucleus and mutual annihilation into twin gamma photons.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('radioactivity') || lessonTitle.toLowerCase().includes('half-life') || lessonTitle.toLowerCase().includes('soddy')) {
            compiledSlides = [
              {
                slideTitle: "1. RADIOACTIVE DISINTEGRATION & ALPHA, BETA, GAMMA RADIATIONS",
                narrationText: "Welcome to Chapter 35: Radioactivity. We study natural radioactive decay, radiation properties, and Soddy-Russell group displacement laws.",
                equations: [`N(t) = N_0 e^{-\\lambda t}`, `A = -\\frac{dN}{dt} = \\lambda N`],
                points: [
                  "1. Natural Radioactivity: Spontaneous nuclear disintegration of heavy unstable nuclei emitting alpha, beta, and gamma rays.",
                  "2. Alpha Particles (α): Helium nuclei (₂He⁴), high ionizing power, low penetrating power, deflected by magnetic/electric fields.",
                  "3. Beta Particles (β): High-speed electrons (₋₁e⁰) or positrons (₊₁e⁰), moderate ionizing power, penetrating power ~100x alpha particles.",
                  "4. Gamma Rays (γ): High-energy electromagnetic photons, zero charge and rest mass, extremely high penetrating power (passes through lead).",
                  "5. Soddy-Russell Group Displacement Laws: Alpha decay reduces Z by 2 and A by 4; Beta decay increases Z by 1 with A unchanged."
                ],
                visualDiagram: "Draw radioactive shielding block with α, β, γ rays deflecting in transverse electric/magnetic field.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. RADIOACTIVE DECAY LAW, HALF-LIFE & MEAN LIFE",
                narrationText: "We analyze the exponential Rutherford-Soddy decay law, half-life period, mean life, and activity units.",
                equations: [`T_{1/2} = \\frac{\\ln 2}{\\lambda} = \\frac{0.693}{\\lambda}`, `\\tau = \\frac{1}{\\lambda} = \\frac{T_{1/2}}{0.693} \\approx 1.44 T_{1/2}`],
                points: [
                  "6. Radioactive Decay Law: Rate of disintegration -dN/dt is directly proportional to number of active undecayed nuclei N present at that instant: -dN/dt = λ N.",
                  "7. Exponential Decay Formula: N(t) = N_0 e^(-λt), where λ is radioactive decay constant (s⁻¹).",
                  "8. Half-Life Period (T_1/2): Time required for half of original active nuclei to decay: T_1/2 = ln 2 / λ = 0.693 / λ.",
                  "9. Mean / Average Life (τ): Sum of life times of all nuclei divided by total number: τ = 1 / λ = 1.44 T_1/2.",
                  "10. Activity Units: Curie (1 Ci = 3.7 × 10¹⁰ Bq) and Becquerel (1 Bq = 1 decay/second)."
                ],
                visualDiagram: "Draw exponential decay curve N(t) vs time t showing halving intervals at T_1/2, 2T_1/2, 3T_1/2.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. BETA DECAY NEUTRINO HYPOTHESIS & CARBON DATING",
                narrationText: "We explore the continuous beta energy spectrum, Pauli's neutrino hypothesis, nuclear gamma transitions, and radiocarbon dating.",
                equations: [`n \\to p + e^- + \\bar{\\nu}_e \\quad (\\beta^- \\text{ decay})`, `p \\to n + e^+ + \\nu_e \\quad (\\beta^+ \\text{ decay})`],
                points: [
                  "11. Continuous Beta Energy Spectrum: Emitted beta particles exhibit continuous kinetic energy distribution up to maximum end-point energy E_max.",
                  "12. Pauli's Neutrino Hypothesis: Neutrinos / antineutrinos (zero mass, spin 1/2, neutral) carry away missing energy and angular momentum.",
                  "13. Gamma Ray Emission: Excitation of daughter nucleus following α or β emission releases discrete gamma photon transitions.",
                  "14. Carbon-14 Radiocarbon Dating: Measures decay ratio of radioactive Carbon-14 (T_1/2 = 5730 years) to determine age of organic artifacts."
                ],
                visualDiagram: "Draw continuous beta spectrum graph (number of beta particles vs energy) showing maximum end-point energy E_max.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('nuclear structure') || lessonTitle.toLowerCase().includes('binding energy per nucleon')) {
            compiledSlides = [
              {
                slideTitle: "1. COMPOSITION OF NUCLEUS, SIZE & DENSITY",
                narrationText: "Welcome to Chapter 34: Nuclear Structure. We study the constituents of the atomic nucleus, nuclear radius scaling, and the extraordinary constant density of nuclear matter.",
                equations: [`R = R_0 A^{1/3} \\quad (R_0 \\approx 1.2 \\text{ fm})`, `\\rho \\approx 2.3 \\times 10^{17} \\text{ kg/m}^3`],
                points: [
                  "1. Nucleon Composition: Nucleus consists of positively charged protons and uncharged neutrons (collectively called nucleons). Mass Number A = Z + N.",
                  "2. Nuclear Radius Formula: R = R_0 A^(1/3), where R_0 = 1.2 × 10⁻¹⁵ m (1.2 fm). Nuclear volume V is directly proportional to mass number A.",
                  "3. Constant Nuclear Density: Nuclear density ρ ≈ 2.3 × 10¹⁷ kg/m³, completely independent of mass number A across all elements.",
                  "4. Nuclide Classifications: Isotopes (same Z, diff A), Isobars (same A, diff Z), Isotones (same N = A - Z), Isomers (same Z and A, diff energy states)."
                ],
                visualDiagram: "Draw spherical nucleus of radius R showing packed protons and neutrons with radius scaling proportional to cube root of mass number A.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. MASS DEFECT & BINDING ENERGY PER NUCLEON CURVE",
                narrationText: "We analyze mass defect, mass-energy equivalence, and the fundamental Binding Energy per Nucleon curve governing nuclear stability, fission, and fusion.",
                equations: [`\\Delta m = [Z m_p + (A - Z) m_n] - M_{\\text{nucleus}}`, `E_b = \\Delta m \\times 931.5 \\text{ MeV}`, `E_{bn} = \\frac{E_b}{A}`],
                points: [
                  "5. Mass Defect (Δm): Total mass of individual free nucleons is always greater than rest mass of assembled nucleus.",
                  "6. Nuclear Binding Energy (E_b): Energy required to completely separate nucleons: E_b = Δm · c² (where 1 atomic mass unit 1 u = 931.5 MeV).",
                  "7. Binding Energy Per Nucleon Curve (E_bn vs A): Peaks at iron Fe-56 (E_bn ≈ 8.8 MeV/nucleon) and remains high (~8.5 MeV) for intermediate nuclei.",
                  "8. Fission & Fusion Insights: Heavy nuclei (A > 200) undergo Nuclear Fission and light nuclei (A < 20) undergo Nuclear Fusion to increase E_bn towards 8.8 MeV."
                ],
                visualDiagram: "Draw E_bn versus Mass Number A graph showing initial steep rise, peak at Fe-56 (8.8 MeV), flat plateau, and gradual drop for heavy elements.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. PROPERTIES OF NUCLEAR FORCES & MESON THEORY",
                narrationText: "We examine the strong nuclear force binding nucleons together inside the nucleus and Hideki Yukawa's meson exchange mechanism.",
                equations: [`F_{\\text{nuclear}} \\gg F_{\\text{electrostatic}} \\quad (r \\approx 1 \\text{ fm})`, `V(r) \\quad \\text{Short-range Potential Well}`],
                points: [
                  "9. Strongest Interaction: Strong nuclear force is ~100 times stronger than electrostatic repulsion between protons at short distances.",
                  "10. Short Range & Saturation: Operates strictly within ~1 to 2 fm; rapidly drops to zero at larger distances. Each nucleon interacts only with nearest neighbors.",
                  "11. Charge Independence: p-p, p-n, and n-n nuclear forces are virtually equal in magnitude.",
                  "12. Yukawa Meson Exchange Theory: Nuclear forces arise from continuous exchange of virtual pi-mesons (π⁺, π⁻, π⁰) between nucleons."
                ],
                visualDiagram: "Draw potential energy V(r) vs inter-nucleon distance r curve showing attractive well at 1 fm and strong repulsive core below 0.5 fm.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('bohr') || lessonTitle.toLowerCase().includes('hydrogen spectrum') || lessonTitle.toLowerCase().includes('origin of spectra')) {
            compiledSlides = [
              {
                slideTitle: "1. RUTHERFORD MODEL & BOHR'S QUANTIZATION POSTULATES",
                narrationText: "Welcome to Chapter 33: Atom & Bohr's Theory of Hydrogen Atom. We explore Rutherford's scattering model, its radiation breakdown, and Niels Bohr's quantum postulates.",
                equations: [`L = m v r = \\frac{n h}{2\\pi}`, `\\frac{m v^2}{r} = \\frac{1}{4\\pi\\varepsilon_0} \\frac{e^2}{r^2}`],
                points: [
                  "1. Rutherford Model Limitations: Accelerating orbiting electrons should continuously radiate electromagnetic energy and spiral into nucleus.",
                  "2. Stationary Orbits Postulate: Electrons revolve around nucleus in specific non-radiating permitted circular orbits.",
                  "3. Angular Momentum Quantization: Orbital angular momentum L = m v r is an integral multiple of h / (2π), so L = n h / (2π).",
                  "4. Quantum Jump & Photon Emission: Photon emitted or absorbed only when electron jumps between orbits: h ν = E_n2 - E_n1."
                ],
                visualDiagram: "Draw Bohr atom model showing positive nucleus, quantized circular electron orbits n=1,2,3, and photon emission during inward electron transition.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. ORBIT RADIUS, VELOCITY & ENERGY FORMULAS",
                narrationText: "We derive exact formulas for orbital radii, electron speeds, and total energy levels for hydrogen-like atoms.",
                equations: [`r_n = \\frac{\\varepsilon_0 h^2 n^2}{\\pi m e^2} = 0.53 \\, n^2 \\text{ \\AA}`, `E_n = -\\frac{m e^4}{8 \\varepsilon_0^2 h^2 n^2} = -\\frac{13.6}{n^2} \\text{ eV}`],
                points: [
                  "5. Radius Derivation: Permitted orbit radius r_n ∝ n² / Z. Ground state radius for hydrogen (n = 1) is Bohr radius r₁ = 0.53 Å.",
                  "6. Electron Velocity: Orbital speed v_n ∝ Z / n. In ground state, v₁ ≈ c / 137.",
                  "7. Energy Expression: Kinetic energy K = +13.6 / n² eV, Potential energy U = -27.2 / n² eV, giving Total Energy E_n = -13.6 / n² eV.",
                  "8. Ground State & Ionization Energy: Ground state energy E₁ = -13.6 eV; Ionization energy required to remove electron to infinity is +13.6 eV."
                ],
                visualDiagram: "Draw hydrogen energy level diagram with ground state E₁ = -13.6 eV, E₂ = -3.4 eV, E₃ = -1.51 eV up to continuum level E_∞ = 0 eV.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. HYDROGEN SPECTRAL SERIES & RYDBERG FORMULA",
                narrationText: "We analyze emission spectra transitions, Rydberg's wave-number equation, and de Broglie's standing wave explanation of quantization.",
                equations: [`\\frac{1}{\\lambda} = R \\left(\\frac{1}{n_1^2} - \\frac{1}{n_2^2}\\right) \\quad (R \\approx 1.097 \\times 10^7 \\text{ m}^{-1})`, `2 \\pi r_n = n \\lambda`],
                points: [
                  "9. Lyman Series (n₁ = 1, n₂ = 2,3,4...): Transitions to ground state emit ultraviolet spectral lines.",
                  "10. Balmer Series (n₁ = 2, n₂ = 3,4,5...): Transitions to n=2 emit visible spectral lines (H_α, H_β, H_γ, H_δ).",
                  "11. Paschen, Brackett, Pfund Series: Transitions to n₁ = 3, 4, 5 yield infrared spectral emissions.",
                  "12. de Broglie Wave Explanation: Permitted Bohr orbits correspond to stationary standing matter waves where orbit circumference 2πr_n = n λ."
                ],
                visualDiagram: "Draw complete line spectrum transition diagram illustrating Lyman (UV), Balmer (Visible), Paschen, Brackett, and Pfund series.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('x-ray') || lessonTitle.toLowerCase().includes('coolidge') || lessonTitle.toLowerCase().includes('moseley')) {
            compiledSlides = [
              {
                slideTitle: "1. PRODUCTION OF X-RAYS & COOLIDGE TUBE",
                narrationText: "Welcome to Chapter 32: X-Rays. We examine the generation of high-frequency electromagnetic radiation using Coolidge vacuum tubes.",
                equations: [`K = e V = \\frac{1}{2} m v^2`, `\\lambda_{\\min} = \\frac{h c}{e V} = \\frac{12400}{V} \\text{ \\AA}`],
                points: [
                  "1. Discovery & Nature: Discovered by W.C. Roentgen (1895); high-frequency electromagnetic waves (wavelength range 0.1 Å to 100 Å).",
                  "2. Coolidge Tube Construction: Evacuated glass bulb with heated tungsten filament cathode and heavy metal molybdenum/copper target anode.",
                  "3. Working Mechanism: Electrons emitted thermionically are accelerated across high potential V (10 kV to 100 kV) and abruptly decelerated upon striking target.",
                  "4. Energy Conversion Efficiency: Less than 1% electron kinetic energy converts to X-ray radiation; >99% turns into thermal heat requiring target cooling fins."
                ],
                visualDiagram: "Draw Coolidge X-ray tube: heated filament, electron beam, slanted heavy target, water cooling channel, and emerging shielded X-ray beam.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. CONTINUOUS & CHARACTERISTIC X-RAY SPECTRA",
                narrationText: "We differentiate between continuous Bremsstrahlung spectrum and characteristic discrete inner-shell spectral lines.",
                equations: [`h \\nu_{\\max} = e V \\implies \\lambda_{\\min} = \\frac{h c}{e V}`, `E_{K\\alpha} = E_L - E_K = h \\nu`],
                points: [
                  "5. Continuous Spectrum (Bremsstrahlung): Produced by random deceleration of fast electrons in nuclear electric fields of target atoms.",
                  "6. Duane-Hunt Law: Minimum wavelength cutoff λ_min depends exclusively on accelerating potential V: λ_min = 12400 / V Å.",
                  "7. Characteristic X-Rays: High-energy incident electron ejects inner-shell electron (K or L); outer electron drops down emitting discrete photon hν = E_L - E_K.",
                  "8. Spectral Peaks: Sharp intensity peaks K_α, K_β, L_α superimposed on continuous background, unique to target material element."
                ],
                visualDiagram: "Draw X-ray intensity versus wavelength λ spectrum graph displaying continuous curve with sharp cutoff λ_min and distinct K_α, K_β characteristic peaks.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. MOSELEY'S LAW & BRAGG CRYSTAL DIFFRACTION",
                narrationText: "We study Moseley's Law establishing atomic numbers and Bragg's Law of X-ray diffraction in crystals.",
                equations: [`\\sqrt{\\nu} = a (Z - b) \\quad \\text{(Moseley's Law)}`, `2 d \\sin \\theta = n \\lambda \\quad \\text{(Bragg's Law)}`],
                points: [
                  "9. Moseley's Law: Square root of characteristic line frequency √ν is directly proportional to atomic number Z: √ν = a(Z - b).",
                  "10. Importance of Moseley's Law: Proved that atomic number Z (not atomic weight) determines element placement in Periodic Table.",
                  "11. Bragg's Diffraction Law: Constructive interference of X-rays reflected from crystal lattice planes occurs when 2 d sin θ = n λ.",
                  "12. Practical Applications: Medical radiography (bone fracture diagnosis), radiotherapy, airport security scanners, and X-ray crystallography."
                ],
                visualDiagram: "Draw Bragg crystal reflection diagram showing parallel atomic lattice planes with spacing d, grazing angle θ, and constructive interference condition.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('matter wave') || lessonTitle.toLowerCase().includes('de broglie') || lessonTitle.toLowerCase().includes('davisson')) {
            compiledSlides = [
              {
                slideTitle: "1. DUAL NATURE OF RADIATION & DE BROGLIE HYPOTHESIS",
                narrationText: "Welcome to Chapter 31: Matter Waves. We investigate wave-particle duality, photon momentum, and de Broglie's revolutionary hypothesis that moving material particles exhibit wave characteristics.",
                equations: [`p = \\frac{h}{\\lambda}`, `\\lambda = \\frac{h}{p} = \\frac{h}{m v} = \\frac{h}{\\sqrt{2 m K}}`],
                points: [
                  "1. Dual Nature of Radiation: Light exhibits wave phenomena (interference, diffraction) and particle phenomena (photoelectric effect, Compton effect).",
                  "2. de Broglie Hypothesis (1924): A moving material particle is associated with a wave called a matter wave or de Broglie wave.",
                  "3. de Broglie Wavelength Formula: λ = h / p = h / (m v) = h / √(2 m K) where K is kinetic energy.",
                  "4. Wavelength vs Mass: Matter wavelength is inversely proportional to mass and velocity; noticeable only for subatomic particles (electrons, protons)."
                ],
                visualDiagram: "Draw a particle of mass m moving with velocity v associated with a pilot wave packet of wavelength λ = h/mv.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. DE BROGLIE WAVELENGTH OF ELECTRONS & DAVISSON-GERMER EXPERIMENT",
                narrationText: "We derive the formula for de Broglie wavelength of an accelerated electron and examine the historic Davisson-Germer experiment confirming electron diffraction.",
                equations: [`\\lambda_e = \\frac{h}{\\sqrt{2 m e V}} = \\frac{12.27}{\\sqrt{V}} \\text{ \\AA}`, `2 d \\sin \\theta = n \\lambda \\quad \\text{(Bragg's Law)}`],
                points: [
                  "5. Electron Wavelength in Accelerating Voltage V: K = e V, leading to λ_e = 12.27 / √V Å. For V = 54 V, λ_e = 1.67 Å.",
                  "6. Davisson-Germer Experiment (1927): Electron beam scattered by Nickel crystal target showed strong diffraction peak at scattering angle ϕ = 50° with accelerating voltage V = 54 V.",
                  "7. Bragg's Diffraction Agreement: Crystal lattice spacing d = 0.91 Å gave Bragg wavelength λ = 1.65 Å, matching de Broglie's theoretical value (1.67 Å) precisely.",
                  "8. Significance: Experimental proof that electrons behave as waves, laying foundation for quantum mechanics and electron microscopes."
                ],
                visualDiagram: "Draw Davisson-Germer experimental setup: electron gun, nickel crystal target, and movable ionization collector with angular intensity peak at 50°.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. WAVE PACKETS & HEISENBERG UNCERTAINTY PRINCIPLE",
                narrationText: "We study wave packets, group vs phase velocity, and Heisenberg's Uncertainty Principle governing quantum measurements.",
                equations: [`\\Delta x \\cdot \\Delta p_x \\ge \\frac{\\hbar}{2} = \\frac{h}{4\\pi}`, `\\Delta E \\cdot \\Delta t \\ge \\frac{h}{4\\pi}`],
                points: [
                  "9. Wave Packet Representation: A moving particle is represented by a localized superposed wave packet traveling at group velocity v_g = v_particle.",
                  "10. Heisenberg Uncertainty Principle: It is impossible to simultaneously measure both exact position and exact momentum of a quantum particle.",
                  "11. Uncertainty Relation: Δx · Δp_x ≥ h / (4π). Decreasing spatial localization Δx increases momentum uncertainty Δp.",
                  "12. Energy-Time Uncertainty: ΔE · Δt ≥ h / (4π), governing energy state lifetimes and spectroscopic spectral line broadening."
                ],
                visualDiagram: "Draw a wave packet with envelope width Δx and Fourier wavevector spread Δk illustrating position-momentum uncertainty balance.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('photoelectric') || lessonTitle.toLowerCase().includes('work function') || lessonTitle.toLowerCase().includes('stopping potential')) {
            compiledSlides = [
              {
                slideTitle: "1. ELECTRON EMISSION & HERTZ/LENARD EXPERIMENTS",
                narrationText: "Welcome to Chapter 30: Photoelectric Effect. We examine free electron emission from metal surfaces, work function, and experimental discoveries of Hertz and Lenard.",
                equations: [`W_0 = h \\nu_0 = \\frac{h c}{\\lambda_0}`, `e V_0 = K_{\\max} = \\frac{1}{2} m v_{\\max}^2`],
                points: [
                  "1. Work Function (W₀): Minimum energy required to eject an electron from metal surface (expressed in electron-volts, 1 eV = 1.602×10⁻¹⁹ J).",
                  "2. Photoelectric Effect Definition: Phenomenon of emission of electrons (photoelectrons) from a metal surface when light of suitable high frequency strikes it.",
                  "3. Hertz & Lenard Observations: UV light on zinc plate causes electron emission. Current flows immediately without observable time lag (< 10⁻⁹ s).",
                  "4. Stopping Potential (V₀): Retarding potential applied to collector plate that reduces photoelectric current to zero (e V₀ = K_max)."
                ],
                visualDiagram: "Draw photoelectric glass tube setup: quartz window, photosensitive emitter cathode C, collector anode A, microammeter, and variable voltage source.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. LAWS OF PHOTOELECTRIC EMISSION & EINSTEIN'S EQUATION",
                narrationText: "We analyze experimental dependencies on intensity, frequency, and potential, highlighting the breakdown of classical wave theory and Einstein's photon hypothesis.",
                equations: [`h \\nu = W_0 + K_{\\max}`, `h \\nu = h \\nu_0 + \\frac{1}{2} m v_{\\max}^2`, `V_0 = \\left(\\frac{h}{e}\\right) \\nu - \\frac{W_0}{e}`],
                points: [
                  "5. Effect of Intensity: Photoelectric current is directly proportional to incident light intensity (photon flux).",
                  "6. Effect of Frequency: Kinetic energy K_max and stopping potential V₀ increase linearly with frequency ν above threshold frequency ν₀.",
                  "7. Classical Wave Theory Failure: Wave theory incorrectly predicts energy accumulation time lag and intensity dependence of electron kinetic energy.",
                  "8. Einstein's Photoelectric Equation: Energy photon hν = Work function W₀ + Max kinetic energy K_max."
                ],
                visualDiagram: "Draw stopping potential V₀ versus frequency ν straight-line graph with slope h/e and negative intercept -W₀/e on potential axis.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. PHOTON PROPERTIES & PHOTOCELL APPLICATIONS",
                narrationText: "We summarize fundamental quantum properties of photons and explore practical technological applications of photocells.",
                equations: [`E = h \\nu`, `p = \\frac{h \\nu}{c}`, `K_{\\max} = e V_0`],
                points: [
                  "9. Quantum Properties of Photons: Travel at speed c, zero rest mass, energy E = hν, momentum p = hν/c, electrically neutral.",
                  "10. Determination of Planck's Constant: Slope of V₀ vs ν graph gives Millikan's accurate value h = e × (slope) = 6.626×10⁻³⁴ J·s.",
                  "11. Photocells: Devices converting light energy into electric current utilizing photoelectric emission (vacuum tube, gas-filled, photovoltaic).",
                  "12. Real-World Applications: Automatic street lights, burglar alarms, solar power cells, exposure meters in cameras, and sound reproduction in motion pictures."
                ],
                visualDiagram: "Draw photoemissive cell circuit with cathode coated with alkali metal (Caesium/Rubidium) illuminating light meter relay.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('polarization') || lessonTitle.toLowerCase().includes('brewster') || lessonTitle.toLowerCase().includes('malus') || lessonTitle.toLowerCase().includes('polaroid')) {
            compiledSlides = [
              {
                slideTitle: "1. UNPOLARIZED VS PLANE POLARIZED LIGHT & BREWSTER'S LAW",
                narrationText: "Welcome to Chapter 29: Polarization of Light. We prove the transverse nature of light waves, define planes of polarization, and examine Brewster's Law of reflection.",
                equations: [`\\tan i_p = \\mu \\quad \\text{(Brewster's Law)}`, `i_p + r = 90^\\circ`],
                points: [
                  "1. Transverse Nature Proof: Polarization proves light waves are transverse electromagnetic waves with electric field vectors E vibrating perpendicular to direction of propagation.",
                  "2. Unpolarized vs Polarized Light: Unpolarized light has E vectors symmetrically oriented in all planes; Plane Polarized Light has E vectors restricted to a single plane.",
                  "3. Planes of Vibration & Polarization: Plane of Vibration contains E vectors and direction of propagation; Plane of Polarization is perpendicular to plane of vibration.",
                  "4. Brewster's Law: When light is incident at polarizing angle i_p, reflected light is completely plane polarized, and tan i_p = μ (reflected and refracted rays are perpendicular: i_p + r = 90°)."
                ],
                visualDiagram: "Draw incident unpolarized ray hitting glass surface at polarizing angle i_p, showing completely polarized reflected ray perpendicular to refracted ray.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. POLARIZATION BY DOUBLE REFRACTION & NICOL PRISM",
                narrationText: "We study birefringence in calcite crystals, ordinary versus extraordinary rays, and the construction of the Nicol prism.",
                equations: [`\\mu_O = \\frac{c}{v_O}`, `\\mu_E = \\frac{c}{v_E}`],
                points: [
                  "5. Double Refraction (Birefringence): Unpolarized ray entering calcite or quartz crystal splits into two refracted rays: Ordinary (O-ray) and Extraordinary (E-ray).",
                  "6. O-ray vs E-ray: O-ray obeys Snell's law with spherical wave surface; E-ray disobeys Snell's law with ellipsoidal wave surface.",
                  "7. Nicol Prism Construction: Optical device made from calcite crystal cut at 68° angle, sliced diagonally and cemented with Canada Balsam (μ = 1.55).",
                  "8. Elimination of O-ray: Canada balsam layer has refractive index lower than O-ray (μ_O = 1.658), causing Total Internal Reflection of O-ray while transmitting E-ray."
                ],
                visualDiagram: "Draw Nicol prism diagram showing Canada balsam layer reflecting O-ray to black absorbed side while transmitting 100% plane polarized E-ray.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. MALUS' LAW, POLAROIDS & OPTICAL ACTIVITY",
                narrationText: "We analyze Malus' Law for transmitted light intensity through crossed polarizers, polaroid applications, and optical rotation.",
                equations: [`I = I_0 \\cos^2 \\theta`, `S = \\frac{\\theta}{L \\cdot c} \\quad \\text{(Specific Rotation)}`],
                points: [
                  "9. Malus' Law: When completely plane polarized light of intensity I₀ passes through an analyzer at angle θ to polarizer, transmitted intensity I = I₀ cos² θ.",
                  "10. Parallel vs Crossed Polarizers: For θ = 0°, maximum intensity I₀ is transmitted; for θ = 90° (crossed polarizers), transmitted intensity is zero.",
                  "11. Polaroids: Synthetic sheets containing aligned herapathite micro-crystals that produce polarized light by dichroism (selective absorption). Used in sunglasses, car headlights, 3D cinema.",
                  "12. Optical Activity & Polarimeter: Ability of optically active substances (sugar solutions, quartz) to rotate plane of polarization through angle θ = S L c."
                ],
                visualDiagram: "Draw Polarizer P₁ and Analyzer P₂ set at angle θ, illustrating intensity variation from I₀ to I₀ cos² θ and zero transmission at 90°.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('diffraction') || lessonTitle.toLowerCase().includes('single slit')) {
            compiledSlides = [
              {
                slideTitle: "1. CONCEPT OF DIFFRACTION & FRAUNHOFER SINGLE SLIT",
                narrationText: "Welcome to Chapter 28: Diffraction of Light. We investigate bending of light around obstacles, Fresnel vs Fraunhofer diffraction, and single slit secondary wavelets.",
                equations: [`a \\sin \\theta = n \\lambda \\quad \\text{(Minima)}`, `a \\sin \\theta = \\left(n + \\frac{1}{2}\\right) \\lambda \\quad \\text{(Secondary Maxima)}`],
                points: [
                  "1. Definition of Diffraction: Bending of light waves around corners of obstacles or narrow apertures into the geometrical shadow region.",
                  "2. Classifications: Fresnel Diffraction (source and screen at finite distances) vs Fraunhofer Diffraction (source and screen at infinite distances using convex lenses).",
                  "3. Single Slit Setup: Parallel light beam incident on slit of width 'a'. Secondary wavelets from different parts of slit interfere on screen.",
                  "4. Condition for Minima: Path difference between extreme wavelets a sin θ = nλ (n = 1, 2, 3...)."
                ],
                visualDiagram: "Draw Fraunhofer single slit setup with slit width 'a', focusing convex lens, and diffraction pattern on screen.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. CENTRAL MAXIMUM WIDTH & INTENSITY DISTRIBUTION",
                narrationText: "We derive angular and linear widths of the central diffraction maximum and analyze relative intensity peaks.",
                equations: [`2 \\theta_0 = \\frac{2 \\lambda}{a}`, `\\beta_0 = \\frac{2 \\lambda D}{a}`, `I = I_0 \\left( \\frac{\\sin \\alpha}{\\alpha} \\right)^2 \\quad \\text{where } \\alpha = \\frac{\\pi a \\sin \\theta}{\\lambda}`],
                points: [
                  "5. Central Maximum: Lies between first minima on either side (a sin θ = ±λ). Brightest and twice as wide as secondary maxima.",
                  "6. Angular Width of Central Maximum: 2θ₀ = 2λ / a. Decreases as slit width 'a' increases.",
                  "7. Linear Width of Central Maximum: β₀ = 2 λ D / a.",
                  "8. Relative Intensity Ratio: Peak intensities drop rapidly: I₀ : I₁ : I₂ ... = 1 : 1/22 : 1/61 : 1/121..."
                ],
                visualDiagram: "Draw central diffraction peak of intensity I₀ flanked by rapidly decaying secondary maxima at (3λ/2a, 5λ/2a) and zero minima at (λ/a, 2λ/a).",
                diagramType: "graph"
              },
              {
                slideTitle: "3. FRESNEL DISTANCE & INTERFERENCE VS DIFFRACTION",
                narrationText: "We study Rayleigh's criterion, Fresnel distance establishing ray optics limits, and contrast interference with diffraction.",
                equations: [`Z_f = \\frac{a^2}{\\lambda}`, `\\theta = \\frac{1.22 \\lambda}{D_0} \\quad \\text{(Rayleigh Criterion)}`],
                points: [
                  "9. Fresnel Distance (Z_f): Distance over which a light beam spreads due to diffraction by an amount equal to slit size 'a' (Z_f = a² / λ). Ray optics valid for z << Z_f.",
                  "10. Rayleigh's Criterion for Resolution: Two point objects are just resolved when central maximum of one falls on first minimum of the other.",
                  "11. Interference vs Diffraction: Interference is superposition of waves from two distinct coherent sources; Diffraction is superposition of wavelets from same wavefront.",
                  "12. Fringe Uniformity Difference: Interference fringes are equally spaced and equally bright; Diffraction fringes are unequally spaced with decreasing brightness."
                ],
                visualDiagram: "Draw beam spreading graph illustrating Fresnel distance Z_f = a²/λ beyond which diffraction spreading exceeds geometric slit width 'a'.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('interference') || lessonTitle.toLowerCase().includes('double slit') || lessonTitle.toLowerCase().includes('ydse') || lessonTitle.toLowerCase().includes('fringe')) {
            compiledSlides = [
              {
                slideTitle: "1. PRINCIPLE OF SUPERPOSITION & COHERENCE",
                narrationText: "Welcome to Chapter 27: Interference of Light. We analyze wave superposition, phase difference, coherent sources, and resultant intensity distribution.",
                equations: [`y = y_1 + y_2`, `\\Delta \\phi = \\frac{2\\pi}{\\lambda} \\Delta x`, `I = I_1 + I_2 + 2 \\sqrt{I_1 I_2} \\cos \\phi`],
                points: [
                  "1. Superposition Principle: Net displacement vector at any point is vector sum of individual displacements produced by overlapping waves.",
                  "2. Phase & Path Difference: Phase difference Δϕ = (2π/λ) Δx.",
                  "3. Coherent Sources: Sources emitting light waves of identical frequency, wavelength, and constant phase difference Δϕ.",
                  "4. Resultant Intensity Formula: I = I1 + I2 + 2√(I1 I2) cos ϕ. For equal amplitudes (a1 = a2 = a), I = 4 I₀ cos²(ϕ/2)."
                ],
                visualDiagram: "Draw two overlapping circular wave ripples from coherent slits S1 and S2 showing constructive and destructive interference nodes.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. YOUNG'S DOUBLE SLIT EXPERIMENT (YDSE) & FRINGE WIDTH",
                narrationText: "We examine Young's Double Slit Experiment, calculating bright and dark fringe positions and deriving the fringe width formula.",
                equations: [`y_n = n \\frac{\\lambda D}{d} \\quad \\text{(Bright)}`, `y_n = \\left(n - \\frac{1}{2}\\right) \\frac{\\lambda D}{d} \\quad \\text{(Dark)}`, `\\beta = \\frac{\\lambda D}{d}`],
                points: [
                  "5. YDSE Experimental Setup: Monochromatic light hits double slits S1 and S2 separated by distance d, forming interference fringes on screen at distance D.",
                  "6. Position of Bright Fringes (Maxima): Path difference Δx = nλ (n = 0, 1, 2...), giving position yn = n λ D / d.",
                  "7. Position of Dark Fringes (Minima): Path difference Δx = (2n-1) λ / 2, giving position yn = (n - 1/2) λ D / d.",
                  "8. Fringe Width Formula: Distance between consecutive bright or dark fringes β = λ D / d. All fringes in YDSE are of equal width."
                ],
                visualDiagram: "Draw YDSE ray diagram showing double slits S1 and S2 at separation d, screen at distance D, and path difference S2P - S1P = d sin θ.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. FRINGE SHIFT & THIN FILM INTERFERENCE",
                narrationText: "We explore intensity conservation, fringe displacement due to thin transparent sheets, and thin film colors in soap bubbles.",
                equations: [`\\Delta y = \\frac{(\\mu - 1) t D}{d}`, `2 \\mu t \\cos r = n \\lambda \\quad \\text{(Reflected Dark)}`, `I_{\\text{avg}} = \\frac{I_{\\max} + I_{\\min}}{2} = I_1 + I_2`],
                points: [
                  "9. Conservation of Energy: Interference redistributes light energy from dark regions to bright regions without violating energy conservation.",
                  "10. Fringe Shift due to Thin Sheet: Inserting a transparent film of thickness t and refractive index μ shifts the fringe pattern by Δy = (μ - 1) t D / d.",
                  "11. Thin Film Interference: Interference between light reflected from top and bottom surfaces of a thin film (e.g. soap bubble, oil film).",
                  "12. Phase Change on Reflection: Reflection at a denser medium introduces an extra path difference of λ/2 (stokes shift)."
                ],
                visualDiagram: "Draw a thin transparent dielectric slab of thickness t placed in path of ray S1P, shifting central fringe upward by Δy.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('huygen') || lessonTitle.toLowerCase().includes('wavefront') || (lessonTitle.toLowerCase().includes('wave nature') && !lessonTitle.toLowerCase().includes('dual nature'))) {
            compiledSlides = [
              {
                slideTitle: "1. WAVEFRONTS & HUYGENS' PRINCIPLE",
                narrationText: "Welcome to Chapter 26: Wave Nature of Light and Huygens' Principle. We analyze wave surfaces, wavefront geometry, and secondary wavelets.",
                equations: [`v = \\nu \\lambda`, `c = \\frac{1}{\\sqrt{\\mu_0 \\varepsilon_0}}`],
                points: [
                  "1. Newton's Corpuscular vs Huygens' Wave Theory: Huygens proposed light propagates as mechanical waves through luminiferous ether.",
                  "2. Wavefront Definition: Locus of all points in a medium vibrating in the same phase. Light rays are always perpendicular to wavefronts.",
                  "3. Types of Wavefronts: Spherical (point source), Cylindrical (line source), and Plane wavefront (source at infinite distance).",
                  "4. Huygens' Principle: Every point on a primary wavefront acts as a secondary source of spherical wavelets spreading in all directions with speed of light."
                ],
                visualDiagram: "Draw a spherical wavefront expanding from a point source and plane wavefronts propagating with perpendicular light rays.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. PROOF OF LAWS OF REFLECTION & REFRACTION",
                narrationText: "Huygens' wave theory successfully proves Snell's Law of Refraction and the Law of Reflection using secondary wavelets.",
                equations: [`\\sin i = \\sin r \\implies i = r`, `\\frac{\\sin i}{\\sin r} = \\frac{v_1}{v_2} = \\frac{n_2}{n_1} = n_{12}`],
                points: [
                  "5. Proof of Law of Reflection: Incident plane wavefront AB hits reflecting surface at angle i; secondary wavelet from A travels distance BC = v t.",
                  "6. Reflection Proof: Triangles ABC and ADC are congruent, yielding angle of incidence i equal to angle of reflection r (i = r).",
                  "7. Proof of Snell's Law of Refraction: Incident wavefront AB enters medium 2 with speed v2; sin i / sin r = (v1 t / AC) / (v2 t / AC) = v1 / v2.",
                  "8. Speed in Denser Medium: According to wave theory, light travels SLOWER in optically denser medium (v2 < v1), contradicting Newton's corpuscular theory."
                ],
                visualDiagram: "Draw Huygens' construction for refraction of a plane wavefront at a plane boundary showing incident wavefront AB and refracted wavefront CD.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. WAVEFRONT BEHAVIOR & DOPPLER EFFECT IN LIGHT",
                narrationText: "We examine wavefront transformation through optical devices and frequency shifts due to relative motion between source and observer.",
                equations: [`\\Delta \\nu = - \\nu \\frac{v}{c}`, `\\frac{\\Delta \\lambda}{\\lambda} = \\frac{v}{c}`],
                points: [
                  "9. Wavefront through Prism: Incident plane wavefront emerges tilted towards base due to greater delay at thicker section of prism.",
                  "10. Wavefront through Convex Lens & Concave Mirror: Incident plane wavefront converts to converging spherical wavefronts.",
                  "11. Doppler Effect in Light: Apparent change in frequency/wavelength when light source and observer move relative to each other.",
                  "12. Red Shift & Blue Shift: Red Shift (wavelength increases, λ' > λ) when source recedes; Blue Shift (wavelength decreases) when source approaches."
                ],
                visualDiagram: "Draw plane wavefront incident on a convex lens transforming into a converging spherical wavefront focused at focal point F.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('microscope') || lessonTitle.toLowerCase().includes('telescope') || (lessonTitle.toLowerCase().includes('optical instrument') && !lessonTitle.toLowerCase().includes('ray optics'))) {
            compiledSlides = [
              {
                slideTitle: "1. HUMAN EYE & MICROSCOPES (SIMPLE & COMPOUND)",
                narrationText: "Welcome to Chapter 25: Optical Instruments. We explore the human eye, defects of vision, and image formation in simple and compound microscopes.",
                equations: [`m_{\\text{simple}} = 1 + \\frac{D}{f}`, `m_{\\text{compound}} = -\\frac{v_o}{u_o}\\left(1 + \\frac{D}{f_e}\\right) \\approx -\\frac{L}{f_o}\\frac{D}{f_e}`],
                points: [
                  "1. Human Eye & Accommodation: Least distance of distinct vision D = 25 cm. Defects include Myopia (concave lens), Hypermetropia (convex lens), and Astigmatism.",
                  "2. Simple Microscope: Single convex lens produces erect, magnified virtual image. Magnifying power m = 1 + D/f (near point) or m = D/f (infinity).",
                  "3. Compound Microscope: Two convex lenses (Objective & Eyepiece). Objective forms real, inverted intermediate image; Eyepiece magnifies it.",
                  "4. Magnification & Length: Total magnifying power m = - (vo/uo)(1 + D/fe) or m = - (L/fo)(D/fe), with tube length L = vo + ue."
                ],
                visualDiagram: "Draw ray diagram of a compound microscope showing objective lens forming real image A'B' and eyepiece forming final magnified virtual image A''B''.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. ASTRONOMICAL & REFLECTING TELESCOPES",
                narrationText: "Telescopes magnify distant celestial and terrestrial objects using refracting lens systems or paraboloidal reflecting mirrors.",
                equations: [`m_{\\text{astro}} = -\\frac{f_o}{f_e}`, `L = f_o + f_e`],
                points: [
                  "5. Astronomical Telescope: Uses large aperture, long focal length objective (fo) and small eyepiece (fe). Magnifying power m = - fo/fe in normal adjustment.",
                  "6. Normal Adjustment: Final image formed at infinity; distance between objective and eyepiece (tube length) L = fo + fe.",
                  "7. Reflecting Telescopes (Cassegrain / Newtonian): Uses concave parabolic objective mirror to eliminate chromatic aberration and spherical aberration.",
                  "8. Advantages of Reflecting Telescopes: Higher light-gathering power, light weight, no absorption losses, and large mechanical support stability."
                ],
                visualDiagram: "Draw ray diagram of a Cassegrain reflecting telescope showing primary concave mirror, secondary convex mirror, and eyepiece focusing light rays.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. RESOLVING POWER OF OPTICAL INSTRUMENTS",
                narrationText: "Resolving power defines the ability of microscopes and telescopes to produce distinctly separate images of two closely spaced objects.",
                equations: [`\\text{Limit of Resolution } d\\theta = \\frac{1.22 \\lambda}{D}`, `\\text{Resolving Power (Microscope)} = \\frac{2 n \\sin \\theta}{1.22 \\lambda}`],
                points: [
                  "9. Rayleigh's Criterion: Two point objects are just resolved when central diffraction maximum of one falls on first minimum of the other.",
                  "10. Telescope Resolving Power: Limit of resolution dθ = 1.22 λ / D. Resolving power RP = D / (1.22 λ), proportional to aperture D.",
                  "11. Microscope Resolving Power: RP = (2 n sin θ) / (1.22 λ), where n sin θ is the Numerical Aperture (NA) of the objective.",
                  "12. Optimization: Resolving power improves by using shorter wavelength (UV light / oil immersion objective for higher n)."
                ],
                visualDiagram: "Draw diffraction patterns of two point sources illustrating Rayleigh's criterion for just resolved, well resolved, and unresolved images.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('prism') || lessonTitle.toLowerCase().includes('dispersion') || lessonTitle.toLowerCase().includes('minimum deviation')) {
            compiledSlides = [
              {
                slideTitle: "1. REFRACTION THROUGH PRISM & MINIMUM DEVIATION",
                narrationText: "Welcome to Chapter 24: Refraction and Dispersion of Light through a Prism. We study light bending through triangular prisms and derive the Prism Formula.",
                equations: [`\\delta = i + e - A`, `n = \\frac{\\sin\\left(\\frac{A + \\delta_m}{2}\\right)}{\\sin\\left(\\frac{A}{2}\\right)}`],
                points: [
                  "1. Refraction through Prism: Ray undergoes two refractions at non-parallel surfaces, resulting in total angle of deviation δ = i + e - A.",
                  "2. Minimum Deviation (δm): At minimum deviation, angle of incidence equals angle of emergence (i = e) and ray passes symmetrically through prism.",
                  "3. Prism Formula: n = sin((A + δm)/2) / sin(A/2). Used to accurately measure refractive index of glass prism.",
                  "4. Thin Prism Deviation: For small refracting angles A, deviation δ = (n - 1)A."
                ],
                visualDiagram: "Draw a triangular glass prism ABC showing incident ray at angle i, refracted ray inside prism, emergent ray at angle e, and deviation angle δ.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. DISPERSION OF LIGHT & DISPERSIVE POWER",
                narrationText: "White light splits into its constituent spectrum colors when passing through a prism due to wavelength dependence of refractive index.",
                equations: [`n = A + \\frac{B}{\\lambda^2}`, `\\theta = (n_v - n_r)A`, `\\omega = \\frac{n_v - n_r}{n - 1}`],
                points: [
                  "5. Dispersion: Splitting of composite white light into VIBGYOR colors due to different speeds for different wavelengths.",
                  "6. Cauchy's Relation: Refractive index decreases with increasing wavelength (n_violet > n_red, so violet deviates most).",
                  "7. Angular Dispersion (θ): Difference in deviation between violet and red rays (θ = (nv - nr)A).",
                  "8. Dispersive Power (ω): Ratio of angular dispersion to mean deviation (ω = (nv - nr)/(n - 1)). Independent of prism angle A."
                ],
                visualDiagram: "Draw a beam of white light entering a glass prism and dispersing into a spectrum band of VIBGYOR colors (Red on top, Violet at bottom).",
                diagramType: "graph"
              },
              {
                slideTitle: "3. SCATTERING OF LIGHT & RAINBOW FORMATION",
                narrationText: "Natural optical phenomena like rainbows and the blue sky result from dispersion, total internal reflection, and atmospheric scattering.",
                equations: [`I \\propto \\frac{1}{\\lambda^4} \\text{ (Rayleigh Scattering Law)}`],
                points: [
                  "9. Primary Rainbow: Formed by two refractions and one total internal reflection in spherical raindrops (Angular radius ~ 42°).",
                  "10. Secondary Rainbow: Formed by two refractions and two total internal reflections in raindrops (Angular radius ~ 50°, inverted colors).",
                  "11. Rayleigh Scattering (I ∝ 1/λ⁴): Shorter wavelengths (blue) are scattered far more strongly than longer wavelengths (red).",
                  "12. Natural Effects: Blue color of sky, reddish appearance of sun at sunrise/sunset, and white color of clouds."
                ],
                visualDiagram: "Draw a spherical raindrop showing white light entering, refracting and dispersing, undergoing TIR, and emerging as a rainbow beam.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('spherical surface') || lessonTitle.toLowerCase().includes('lenses') || lessonTitle.toLowerCase().includes('lens maker')) {
            compiledSlides = [
              {
                slideTitle: "1. REFRACTION AT SPHERICAL SURFACES & LENS MAKER'S FORMULA",
                narrationText: "Welcome to Chapter 23: Refraction of Light at Spherical Surfaces and Lenses. We study refraction across single spherical surfaces and derive the famous Lens Maker's Formula.",
                equations: [`\\frac{n_2}{v} - \\frac{n_1}{u} = \\frac{n_2 - n_1}{R}`, `\\frac{1}{f} = (n - 1)\\left(\\frac{1}{R_1} - \\frac{1}{R_2}\\right)`],
                points: [
                  "1. Single Spherical Refracting Surface: Relates object distance u, image distance v, and surface radius R by (n2/v - n1/u = (n2 - n1)/R).",
                  "2. Thin Lenses: Spherical lenses bounded by two spherical surfaces or one spherical and one plane surface.",
                  "3. Lens Maker's Formula: 1/f = (n - 1)(1/R1 - 1/R2). Used by opticians to manufacture lenses of desired focal length.",
                  "4. Convex Lens (Converging) & Concave Lens (Diverging): Behavior depends on relative refractive index of lens and surrounding medium."
                ],
                visualDiagram: "Draw a convex spherical refracting surface separating medium 1 (n1) and medium 2 (n2), showing object O on principal axis, image I, center of curvature C, and radius R.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. THIN LENS FORMULA, POWER & MAGNIFICATION",
                narrationText: "The thin lens formula connects object distance, image distance, and focal length, while lens power measures the degree of convergence or divergence.",
                equations: [`\\frac{1}{f} = \\frac{1}{v} - \\frac{1}{u}`, `P = \\frac{1}{f \\text{ (in meters)}} \\text{ (Dioptres, D)}`, `m = \\frac{v}{u} = \\frac{f}{f + u}`],
                points: [
                  "5. Thin Lens Formula: 1/f = 1/v - 1/u. Applies to both convex and concave lenses using Cartesian sign convention.",
                  "6. Power of a Lens (P = 1/f): Expressed in Dioptres (D). Positive for convex lenses (converging), negative for concave lenses (diverging).",
                  "7. Linear Magnification (m): Ratio of image height to object height (h'/h = v/u). Positive for virtual and erect, negative for real and inverted.",
                  "8. Focal Length in Medium: Focal length increases when lens is immersed in a liquid of higher refractive index than air."
                ],
                visualDiagram: "Draw a double convex thin lens showing principal focus F1, F2, object beyond 2F, and real inverted magnified/diminished image formation.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. COMBINATION OF LENSES & ABERRATIONS",
                narrationText: "Lenses are combined to increase magnification, sharpen images, or reduce chromatic aberration.",
                equations: [`\\frac{1}{F} = \\frac{1}{f_1} + \\frac{1}{f_2}`, `P_{\\text{total}} = P_1 + P_2`, `m_{\\text{total}} = m_1 \\times m_2`],
                points: [
                  "9. Lenses in Contact: Equivalent focal length 1/F = 1/f1 + 1/f2 and total power P = P1 + P2.",
                  "10. Lenses Separated by Distance d: Equivalent focal length 1/F = 1/f1 + 1/f2 - d/(f1 f2).",
                  "11. Chromatic Aberration: Inability of a lens to focus all colors at the same point due to dispersion.",
                  "12. Achromatic Combination: Combination of a convex crown glass lens and a concave flint glass lens (Achromatic doublet) to eliminate chromatic aberration."
                ],
                visualDiagram: "Draw an Achromatic Doublet showing a convex crown glass lens cemented to a concave flint glass lens bringing red and violet rays to a single focus.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('refraction') || lessonTitle.toLowerCase().includes('total internal reflection') || lessonTitle.toLowerCase().includes('optical fiber') || lessonTitle.toLowerCase().includes('snell')) {
            compiledSlides = [
              {
                slideTitle: "1. LAWS OF REFRACTION & SNELL'S LAW",
                narrationText: "Welcome to Chapter 22: Refraction of Light at a Plane Interface, Total Internal Reflection, and Optical Fibers. We explore how light bends across medium boundaries.",
                equations: [`n_1 \\sin i = n_2 \\sin r`, `n = \\frac{c}{v}`],
                points: [
                  "1. Refraction: Change in direction of light when passing obliquely from one medium to another due to velocity change.",
                  "2. Snell's Law: Ratio of sine of angle of incidence to sine of angle of refraction is constant (n1 sin i = n2 sin r).",
                  "3. Absolute Refractive Index (n = c/v): Ratio of speed of light in vacuum to speed in medium.",
                  "4. Refraction through Glass Slab: Produces lateral shift without changing direction of emergent ray."
                ],
                visualDiagram: "Draw a ray of light passing from air (n1) to glass (n2), bending towards the normal, showing angle i, angle r, and normal line.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. REAL & APPARENT DEPTH & TOTAL INTERNAL REFLECTION",
                narrationText: "When light travels from an optically denser to a rarer medium, refraction causes objects to appear shallower, leading to Total Internal Reflection beyond the critical angle.",
                equations: [`\\sin i_c = \\frac{1}{n}`, `\\Delta x = t \\left(1 - \\frac{1}{n}\\right)`],
                points: [
                  "5. Real and Apparent Depth: An object submerged in a denser medium appears raised by normal shift Δx = t(1 - 1/n).",
                  "6. Critical Angle (ic): Angle of incidence in denser medium for which angle of refraction in rarer medium is 90° (sin ic = 1/n).",
                  "7. Total Internal Reflection (TIR): When i > ic in denser medium, light is 100% reflected back into denser medium with zero transmission loss.",
                  "8. Conditions for TIR: Light must travel from denser to rarer medium, and angle of incidence must exceed critical angle."
                ],
                visualDiagram: "Draw rays from an underwater source hitting surface at normal incidence, critical angle ic (grazing refraction along surface), and i > ic (total internal reflection back into water).",
                diagramType: "graph"
              },
              {
                slideTitle: "3. OPTICAL FIBERS & APPLICATIONS OF TIR",
                narrationText: "Total Internal Reflection enables revolutionary applications including optical fiber communications, decorative illuminations, and medical endoscopes.",
                equations: [`\\text{Numerical Aperture (NA)} = \\sqrt{n_1^2 - n_2^2}`],
                points: [
                  "9. Optical Fiber Structure: Consists of a high refractive index Core (n1) surrounded by a lower refractive index Cladding (n2).",
                  "10. Light Propagation: Light entering core at small acceptance angle undergoes continuous TIR at core-cladding interface.",
                  "11. Advantages: High bandwidth, immune to electromagnetic interference, minimal signal attenuation over long distances.",
                  "12. Other TIR Phenomena: Mirage in hot deserts, brilliance of cut diamonds, and Porro prisms in optical instruments."
                ],
                visualDiagram: "Draw a cylindrical optical fiber showing Core (n1) and Cladding (n2), with a ray entering at the end face and undergoing repeated TIR along the core.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('reflection') || lessonTitle.toLowerCase().includes('spherical mirror') || lessonTitle.toLowerCase().includes('concave mirror') || lessonTitle.toLowerCase().includes('convex mirror')) {
            compiledSlides = [
              {
                slideTitle: "1. LAWS OF REFLECTION & SPHERICAL MIRRORS",
                narrationText: "Welcome to Chapter 21: Reflection of Light and Spherical Mirrors. We study the laws of reflection and the geometry of concave and convex spherical mirrors.",
                equations: [`i = r`, `f = \\frac{R}{2}`],
                points: [
                  "1. Laws of Reflection: Angle of incidence equals angle of reflection (i = r). Incident ray, reflected ray, and normal lie in the same plane.",
                  "2. Spherical Mirrors: Concave mirror (converging, reflective inside) and Convex mirror (diverging, reflective outside).",
                  "3. Center of Curvature (C) & Radius (R): Distance from pole (P) to center of curvature (C).",
                  "4. Focal Length Relation: For small apertures (paraxial rays), focal length is half the radius of curvature (f = R/2)."
                ],
                visualDiagram: "Draw a concave spherical mirror showing Pole (P), Focus (F), Center of Curvature (C), Principal Axis, and a paraxial ray reflecting through the Focus F.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. MIRROR FORMULA & MAGNIFICATION",
                narrationText: "The mirror formula relates object distance u, image distance v, and focal length f according to the Cartesian Sign Convention.",
                equations: [`\\frac{1}{f} = \\frac{1}{v} + \\frac{1}{u}`, `m = -\\frac{v}{u} = \\frac{f - v}{f} = \\frac{f}{f - u}`],
                points: [
                  "5. Sign Convention: All distances measured from Pole P. Distances in direction of incident light are positive; opposite are negative.",
                  "6. Mirror Formula: 1/f = 1/v + 1/u. Holds for both concave and convex mirrors for real and virtual images.",
                  "7. Linear Magnification (m): Ratio of height of image to height of object (h'/h = -v/u). Positive m indicates virtual and erect image; negative m indicates real and inverted.",
                  "8. Longitudinal Magnification: m_L = -dv/du = m² for small axial object lengths."
                ],
                visualDiagram: "Draw an object in front of a concave mirror beyond C, showing two key rays (parallel to axis and through C) intersecting to form a real, inverted, diminished image between C and F.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. APPLICATIONS & ABERRATIONS",
                narrationText: "Spherical mirrors find wide practical applications, though spherical aberration must be mitigated for precise imaging.",
                equations: [`\\Delta f = f_{marginal} - f_{paraxial}`],
                points: [
                  "9. Uses of Concave Mirrors: Shaving mirrors, dentist mirrors, searchlights, and solar furnaces (producing intense heat at focal point).",
                  "10. Uses of Convex Mirrors: Rear-view mirrors in vehicles (provides wide field of view and erect image), street lamp reflectors.",
                  "11. Spherical Aberration: Inability of spherical mirror to focus marginal and paraxial rays at the same point, causing image blur.",
                  "12. Mitigation: Using parabolic mirrors eliminates spherical aberration completely (used in astronomical telescopes)."
                ],
                visualDiagram: "Draw a comparison of a Spherical Mirror showing marginal rays focusing closer than paraxial rays (spherical aberration) versus a Parabolic Mirror focusing all parallel rays to a sharp focal point.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('communication') || lessonTitle.toLowerCase().includes('modulation') || lessonTitle.toLowerCase().includes('amplitude') || lessonTitle.toLowerCase().includes('bandwidth')) {
            compiledSlides = [
              {
                slideTitle: "1. ELEMENTS OF A COMMUNICATION SYSTEM",
                narrationText: "Welcome to Chapter 20: Communication Systems. Every communication system consists of three basic elements: a transmitter, a communication channel, and a receiver.",
                equations: [`\\text{System} = \\text{Tx} + \\text{Channel} + \\text{Rx}`],
                points: [
                  "1. Transmitter (Tx): Converts the message signal into a form suitable for transmission over the channel.",
                  "2. Channel: The physical medium (wires, cables, or free space) that connects the transmitter and receiver.",
                  "3. Receiver (Rx): Extracts the original message signal from the received, often degraded, signal.",
                  "4. Noise: Unwanted signals that tend to disturb the transmission and processing of message signals in a communication system."
                ],
                visualDiagram: "Draw a block diagram of a basic communication system: Information Source -> Transmitter -> Channel (with Noise entering) -> Receiver -> User of Information.",
                diagramType: "steps"
              },
              {
                slideTitle: "2. BANDWIDTH & ELECTROMAGNETIC WAVE PROPAGATION",
                narrationText: "Different signals require different bandwidths. These signals propagate through space in three main ways: ground wave, sky wave, and space wave.",
                equations: [`f_c = \\sqrt{9 N_{max}}`, `d = \\sqrt{2 h_T R} + \\sqrt{2 h_R R}`],
                points: [
                  "5. Bandwidth: The frequency range over which an equipment operates or the portion of the spectrum occupied by the signal (e.g., Speech: 3 kHz, Video: 4.2 MHz).",
                  "6. Ground Wave: Propagation along the surface of the earth (f < 2 MHz), highly attenuated.",
                  "7. Sky Wave: Reflected by the ionosphere (3 MHz to 30 MHz). Used for short-wave broadcast.",
                  "8. Space Wave: Line-of-sight propagation (f > 40 MHz) using TV antennas or satellite relays."
                ],
                visualDiagram: "Draw an Earth cross-section showing Ground Wave hugging the surface, Sky Wave reflecting off the ionosphere, and Space Wave traveling in a straight line-of-sight between two tall antennas.",
                diagramType: "logic"
              },
              {
                slideTitle: "3. MODULATION (AMPLITUDE MODULATION)",
                narrationText: "Low-frequency message signals cannot be transmitted over long distances. They are superimposed on a high-frequency carrier wave, a process called modulation.",
                equations: [`c(t) = A_c \\sin(\\omega_c t)`, `m(t) = A_m \\sin(\\omega_m t)`, `\\mu = \\frac{A_m}{A_c}`],
                points: [
                  "9. Need for Modulation: Practical antenna length (λ/4), reducing power loss, and avoiding mixing of signals.",
                  "10. Amplitude Modulation (AM): The amplitude of the high-frequency carrier wave is varied in accordance with the message signal.",
                  "11. Modulation Index (μ): Ratio of modulating signal amplitude to carrier amplitude. Should be ≤ 1 to avoid distortion.",
                  "12. Bandwidth of AM: 2 × f_m, containing the carrier frequency f_c and sidebands (f_c - f_m and f_c + f_m)."
                ],
                visualDiagram: "Plot three waveforms vertically: a low-frequency message signal, a high-frequency carrier signal, and the resulting amplitude-modulated (AM) wave showing the envelope matching the message signal.",
                diagramType: "graph"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('semiconductor') || lessonTitle.toLowerCase().includes('logic gate') || lessonTitle.toLowerCase().includes('transistor') || lessonTitle.toLowerCase().includes('diode')) {
            compiledSlides = [
              {
                slideTitle: "1. ENERGY BANDS & SEMICONDUCTORS",
                narrationText: "Welcome to Chapter 19: Semiconductor Electronics. We classify solids based on energy bands and explore the properties of intrinsic and extrinsic semiconductors.",
                equations: [`E_g = E_c - E_v`, `n_e = n_h = n_i \\text{ (Intrinsic)}`, `n_e n_h = n_i^2 \\text{ (Mass Action)}`],
                points: [
                  "1. Energy Bands: Valence band (VB) contains bonding electrons; Conduction band (CB) contains free electrons.",
                  "2. Band Gap (E_g): Energy difference between CB and VB. Conductors (E_g ≈ 0), Insulators (E_g > 3eV), Semiconductors (E_g < 3eV).",
                  "3. Intrinsic Semiconductors: Pure semiconductors (e.g., Si, Ge). Equal number of electrons and holes (n_e = n_h).",
                  "4. Extrinsic Semiconductors: Doped with impurities. n-type (Pentavalent dopant, electrons are majority charge carriers), p-type (Trivalent dopant, holes are majority carriers)."
                ],
                visualDiagram: "Draw energy band diagrams comparing a metal (overlapping bands), an insulator (large band gap), and a semiconductor (small band gap), illustrating the valence and conduction bands.",
                diagramType: "logic"
              },
              {
                slideTitle: "2. p-n JUNCTION & DIODES",
                narrationText: "When p-type and n-type materials are joined, a p-n junction forms with a depletion region. This forms the basis of the semiconductor diode.",
                equations: [`I = I_0(e^{\\frac{qV}{kT}} - 1)`],
                points: [
                  "5. Depletion Region: A thin region at the junction devoid of mobile charge carriers, creating a potential barrier.",
                  "6. Forward Bias: p-side to positive, n-side to negative. Barrier decreases, current flows easily.",
                  "7. Reverse Bias: p-side to negative, n-side to positive. Barrier increases, only small leakage current flows.",
                  "8. Applications: Diodes are used as half-wave and full-wave rectifiers to convert AC to DC. Special diodes include Zener (voltage regulation), LEDs, and Photodiodes."
                ],
                visualDiagram: "Draw a circuit diagram of a p-n junction diode in forward bias and reverse bias, alongside its I-V characteristic curve showing the exponential rise in forward bias and the breakdown in reverse bias.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. LOGIC GATES",
                narrationText: "Digital electronics uses logic gates to perform logical operations. The fundamental building blocks are AND, OR, and NOT gates.",
                equations: [`Y = A \\cdot B \\text{ (AND)}`, `Y = A + B \\text{ (OR)}`, `Y = \\overline{A} \\text{ (NOT)}`],
                points: [
                  "9. Analog vs Digital: Digital signals have discrete values (0 and 1), unlike continuous analog signals.",
                  "10. Basic Logic Gates: OR (addition), AND (multiplication), NOT (inversion).",
                  "11. Universal Gates: NAND and NOR gates are universal because any logic gate can be constructed using only them.",
                  "12. Truth Tables: Used to define the output for all possible combinations of inputs for a given logic gate."
                ],
                visualDiagram: "Draw the standard symbols for AND, OR, and NOT logic gates, and next to each, provide a simple truth table demonstrating their operation for inputs A and B.",
                diagramType: "logic"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('nuclei') || lessonTitle.toLowerCase().includes('radioactivity') || lessonTitle.toLowerCase().includes('mass defect') || lessonTitle.toLowerCase().includes('binding energy')) {
            compiledSlides = [
              {
                slideTitle: "1. COMPOSITION OF NUCLEUS & MASS DEFECT",
                narrationText: "Welcome to Chapter 18: Nuclei (Pages 751-800). We explore the nucleus consisting of protons and neutrons, its size relation to mass number, and Einstein's mass-energy equivalence which explains the mass defect in stable nuclei.",
                equations: [`R = R_0 A^{1/3}`, `E = mc^2`, `\\Delta m = [Z m_p + (A-Z) m_n] - M`],
                points: [
                  "1. Atomic Nucleus: Contains protons (Z) and neutrons (A-Z), collectively called nucleons.",
                  "2. Nuclear Size: Radius R = R₀A^(1/3), where R₀ ≈ 1.2 fm (Fermi). Nuclear density is extremely high and independent of mass number A.",
                  "3. Mass-Energy Equivalence: Energy E = mc², converting mass directly into energy (1 amu = 931.5 MeV).",
                  "4. Mass Defect (Δm): Difference between the sum of masses of constituent nucleons and the actual mass of the nucleus."
                ],
                visualDiagram: "Draw a diagram representing a nucleus with protons and neutrons packed together, and an illustration of a weighing scale showing the individual nucleons weighing more than the assembled nucleus to visually represent mass defect.",
                diagramType: "logic"
              },
              {
                slideTitle: "2. BINDING ENERGY & NUCLEAR FORCES",
                narrationText: "The mass defect is converted into Binding Energy, which holds the nucleus together. We study the Binding Energy curve and the characteristics of the strong nuclear force.",
                equations: [`BE = \\Delta m \\cdot c^2`, `\\text{BE per nucleon} = \\frac{BE}{A}`],
                points: [
                  "5. Binding Energy (BE): Energy required to break a nucleus into its constituent nucleons.",
                  "6. BE per Nucleon Curve: Shows a peak near Iron (Fe-56), indicating maximum stability.",
                  "7. Fission and Fusion: Heavy nuclei undergo fission, and light nuclei undergo fusion to reach states of higher BE per nucleon (greater stability).",
                  "8. Strong Nuclear Force: Extremely strong, attractive, short-range (fermi level), charge-independent, and spin-dependent force between nucleons."
                ],
                visualDiagram: "Plot a graph of Binding Energy per nucleon (MeV) versus Mass Number (A), showing a steep rise for light nuclei, a broad maximum around A=50-80 (Iron), and a gradual decrease for heavy nuclei.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. RADIOACTIVITY & DECAY LAW",
                narrationText: "Unstable nuclei spontaneously decay by emitting alpha, beta, or gamma radiation. We mathematically model this decay process using the Radioactive Decay Law.",
                equations: [`\\frac{dN}{dt} = -\\lambda N`, `N(t) = N_0 e^{-\\lambda t}`, `T_{1/2} = \\frac{\\ln(2)}{\\lambda} = \\frac{0.693}{\\lambda}`],
                points: [
                  "9. Radioactivity: Spontaneous emission of radiation (α, β, γ) from unstable nuclei to achieve stability.",
                  "10. Radioactive Decay Law: Rate of disintegration is directly proportional to the number of undecayed nuclei present.",
                  "11. Half-Life (T_1/2): Time taken for half of the radioactive sample to decay.",
                  "12. Mean Life (τ): Average lifespan of all nuclei in a sample, τ = 1/λ. (T_1/2 = 0.693 τ)."
                ],
                visualDiagram: "Draw an exponential decay curve showing the number of undecayed nuclei N(t) versus time t, marking the half-lives (T_1/2, 2T_1/2, 3T_1/2) and the corresponding reduction in nuclei (N₀/2, N₀/4, N₀/8).",
                diagramType: "graph"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('atoms') || lessonTitle.toLowerCase().includes('rutherford') || lessonTitle.toLowerCase().includes('bohr') || lessonTitle.toLowerCase().includes('hydrogen spectrum')) {
            compiledSlides = [
              {
                slideTitle: "1. RUTHERFORD'S ALPHA-PARTICLE SCATTERING",
                narrationText: "Welcome to Chapter 17: Atoms (Pages 701-750). We begin with Rutherford's Alpha-particle scattering experiment which led to the discovery of the atomic nucleus, establishing that most of the atom's mass is concentrated in a tiny central core.",
                equations: [`r_0 = \\frac{1}{4\\pi\\epsilon_0} \\frac{2Ze^2}{K}`, `b = \\frac{Ze^2 \\cot(\\theta/2)}{4\\pi\\epsilon_0 K}`],
                points: [
                  "1. Rutherford's Nuclear Model: Atom has a dense, positively charged nucleus surrounded by orbiting electrons.",
                  "2. Alpha-particle Scattering Experiment: Directed α-particles at a thin gold foil.",
                  "3. Distance of Closest Approach (r₀): Determines upper limit on nucleus size.",
                  "4. Impact Parameter (b): Perpendicular distance of velocity vector from nucleus center."
                ],
                visualDiagram: "Draw Rutherford's alpha-particle scattering experiment showing a lead collimator, gold foil, and scintillating screen detecting scattered alpha particles at various angles.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. BOHR MODEL OF THE HYDROGEN ATOM",
                narrationText: "Bohr proposed a quantized model for the hydrogen atom, where electrons orbit the nucleus in specific stationary states without radiating energy.",
                equations: [`mvr = \\frac{nh}{2\\pi}`, `r_n = \\frac{\\epsilon_0 h^2 n^2}{\\pi m e^2} \\approx 0.529 n^2 \\text{ \\AA}`, `E_n = -\\frac{me^4}{8\\epsilon_0^2 h^2} \\frac{1}{n^2} = -\\frac{13.6}{n^2} \\text{ eV}`],
                points: [
                  "5. Bohr's Postulates: Stationary orbits, quantization of angular momentum (L = nh/2π), and energy radiation during transitions (hν = E_i - E_f).",
                  "6. Radius of nth orbit (r_n): Proportional to n², where r₁ = 0.53 Å (Bohr radius).",
                  "7. Energy Levels (E_n): Total energy is negative, indicating a bound state. E_n = -13.6/n² eV.",
                  "8. Electron Orbits: Kinetic energy (K = |E|) and Potential energy (U = -2K)."
                ],
                visualDiagram: "Draw the Bohr model of a hydrogen atom showing a central positive nucleus and circular electron orbits (n=1, 2, 3), illustrating a photon emission during an electron transition.",
                diagramType: "logic"
              },
              {
                slideTitle: "3. HYDROGEN SPECTRAL SERIES",
                narrationText: "When an electron transitions between quantized energy levels, it emits or absorbs a photon, giving rise to the characteristic line spectrum of hydrogen.",
                equations: [`\\frac{1}{\\lambda} = R \\left( \\frac{1}{n_f^2} - \\frac{1}{n_i^2} \\right)`, `\\lambda = \\frac{hc}{\\Delta E}`, `2\\pi r_n = n\\lambda`],
                points: [
                  "9. Atomic Spectra: Emission and absorption spectra form discrete lines.",
                  "10. Spectral Series: Lyman (UV, n_f=1), Balmer (Visible, n_f=2), Paschen (IR, n_f=3), Brackett (IR, n_f=4), Pfund (IR, n_f=5).",
                  "11. Rydberg Formula: 1/λ = R (1/n_f² - 1/n_i²) where R = 1.097×10⁷ m⁻¹.",
                  "12. de Broglie's Explanation: Justifies Bohr's quantization condition by setting orbit circumference equal to an integer number of wavelengths."
                ],
                visualDiagram: "Draw the energy level diagram of a hydrogen atom showing horizontal lines for n=1 to infinity, with vertical arrows indicating transitions for Lyman, Balmer, and Paschen series.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('dual nature') || lessonTitle.toLowerCase().includes('radiation') || lessonTitle.toLowerCase().includes('photoelectric') || lessonTitle.toLowerCase().includes('matter wave')) {
            compiledSlides = [
              {
                slideTitle: "1. ELECTRON EMISSION & PHOTOELECTRIC EFFECT",
                narrationText: "Welcome to Chapter 16: Dual Nature of Radiation and Matter (Pages 651-700). We study electron emission, Hertz and Lenard's observations, and the effect of intensity and potential on photoelectric current.",
                equations: [`E = h\\nu = \\frac{hc}{\\lambda}`, `p = \\frac{E}{c} = \\frac{h}{\\lambda}`, `K_{\\text{max}} = eV_0`],
                points: [
                  "1. Types of Electron Emission: Thermionic, Field, and Photoelectric Emission",
                  "2. Work Function (Φ₀): Minimum energy required to eject an electron from a metal surface",
                  "3. Experimental Study: Effect of Intensity (increases current) & Potential on Photoelectric Current",
                  "4. Stopping Potential (V₀): Negative potential at which photoelectric current becomes zero"
                ],
                visualDiagram: "Draw an experimental setup for studying photoelectric effect showing an evacuated glass tube, photosensitive plate, collector, and external circuit with ammeter and voltmeter.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. EINSTEIN'S PHOTOELECTRIC EQUATION",
                narrationText: "We explore the particle nature of light, photons, and Einstein's Photoelectric Equation explaining the laws of photoelectric emission.",
                equations: [`K_{\\text{max}} = h\\nu - \\Phi_0`, `eV_0 = h(\\nu - \\nu_0)`, `K_{\\text{max}} = \\frac{hc}{\\lambda} - \\Phi_0`],
                points: [
                  "5. Particle Nature of Light: Light consists of discrete energy packets called Photons",
                  "6. Einstein's Photoelectric Equation: K_max = hν - Φ₀",
                  "7. Threshold Frequency (ν₀): Minimum frequency for emission (Φ₀ = hν₀)",
                  "8. Laws of Photoelectric Emission: Instantaneous process, intensity determines number of photoelectrons, frequency determines max kinetic energy"
                ],
                visualDiagram: "Draw a graph of stopping potential (V₀) versus frequency (ν) of incident light for two different metals, showing parallel straight lines intersecting the x-axis at threshold frequencies.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. WAVE NATURE OF MATTER (DE BROGLIE WAVES)",
                narrationText: "We detail the wave nature of matter, de Broglie relation, and the Davisson-Germer experiment verifying electron diffraction.",
                equations: [`\\lambda = \\frac{h}{p} = \\frac{h}{mv}`, `\\lambda = \\frac{h}{\\sqrt{2mK}}`, `\\lambda_{\\text{electron}} = \\frac{12.27}{\\sqrt{V}} \\text{ \\AA}`],
                points: [
                  "9. Wave Nature of Matter: Moving particles exhibit wave-like properties",
                  "10. de Broglie Wavelength: λ = h/p = h/√(2mK) = h/√(2mqV)",
                  "11. Wavelength of an Electron accelerated through potential V: λ = 12.27/√V Å",
                  "12. Davisson and Germer Experiment: Verified wave nature of electrons via diffraction from a nickel crystal"
                ],
                visualDiagram: "Draw Davisson-Germer experiment setup showing electron gun, nickel crystal target, and movable electron detector measuring scattering intensity.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('wave optics') || lessonTitle.toLowerCase().includes('huygen') || lessonTitle.toLowerCase().includes('interference') || lessonTitle.toLowerCase().includes('diffraction') || lessonTitle.toLowerCase().includes('polarization')) {
            compiledSlides = [
              {
                slideTitle: "1. HUYGENS' PRINCIPLE & INTERFERENCE (YDSE)",
                narrationText: "Welcome to Chapter 15: Wave Optics (Pages 596-650). We study wave nature of light, Huygens' Principle, coherent sources, and Young's Double Slit Experiment.",
                equations: [`y_n = \\frac{n \\lambda D}{d}`, `\\beta = \\frac{\\lambda D}{d}`, `I = I_1 + I_2 + 2\\sqrt{I_1 I_2}\\cos\\phi`],
                points: [
                  "1. Wavefronts (Spherical, Cylindrical, Plane) & Huygens' Principle of Secondary Wavelets",
                  "2. Refraction and Reflection of Plane Waves Explaining Snell's Law",
                  "3. Coherent vs Incoherent Sources & Principle of Superposition",
                  "4. Young's Double Slit Experiment (YDSE) & Fringe Width Formula β = λD/d"
                ],
                visualDiagram: "Draw Young's Double Slit Experiment setup showing coherent wavefronts interfering and producing alternating bright and dark fringes on a screen.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. DIFFRACTION OF LIGHT & RESOLVING POWER",
                narrationText: "We explore the bending of light around obstacles in Single Slit Diffraction and the Resolving Power of optical instruments.",
                equations: [`a \\sin \\theta = n \\lambda`, `\\theta_1 = \\frac{\\lambda}{a}`, `\\text{R.P.}_{\\text{microscope}} = \\frac{2 n \\sin \\theta}{\\lambda}`],
                points: [
                  "5. Single Slit Diffraction: Central Maximum Width & Secondary Minima Condition (a sin θ = nλ)",
                  "6. Intensity Distribution Curve in Diffraction (Central Maximum is brightest)",
                  "7. Resolving Power of a Microscope (Limit of Resolution d = λ / (2n sin θ))",
                  "8. Resolving Power of an Astronomical Telescope (Limit of Resolution dθ = 1.22λ / D)"
                ],
                visualDiagram: "Draw intensity distribution graph of single slit diffraction showing a wide, tall central maximum and smaller secondary maxima.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. POLARIZATION OF LIGHT & MALUS'S LAW",
                narrationText: "We detail unpolarized and polarized light, Polarization by scattering, reflection (Brewster's Law), and transmission (Malus's Law).",
                equations: [`I = I_0 \\cos^2 \\theta`, `\\mu = \\tan i_p`, `i_p + r = 90^\\circ`],
                points: [
                  "9. Transverse Nature of Light Waves & Concept of Unpolarized vs Linearly Polarized Light",
                  "10. Polarization by Transmission (Polaroids) & Malus's Law (I = I₀ cos²θ)",
                  "11. Polarization by Scattering (Blue Sky is Partially Polarized)",
                  "12. Polarization by Reflection & Brewster's Angle (Reflected and Refracted rays are perpendicular)"
                ],
                visualDiagram: "Draw unpolarized light passing through a polarizer to become linearly polarized, then passing through an analyzer at angle θ.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('ray optics') || lessonTitle.toLowerCase().includes('optical instrument') || lessonTitle.toLowerCase().includes('telescope') || lessonTitle.toLowerCase().includes('prism')) {
            compiledSlides = [
              {
                slideTitle: "1. REFLECTION, REFRACTION & TOTAL INTERNAL REFLECTION",
                narrationText: "Welcome to Chapter 14: Ray Optics and Optical Instruments (Pages 546-595). We study spherical mirrors, Snell's Law, refractive index, and Total Internal Reflection (TIR).",
                equations: [`n = \\frac{c}{v} = \\frac{\\sin i}{\\sin r}`, `\\sin i_c = \\frac{n_2}{n_1}`, `\\frac{1}{v} + \\frac{1}{u} = \\frac{1}{f} = \\frac{2}{R}`],
                points: [
                  "1. Laws of Reflection and Refraction at Plane & Curved Interfaces",
                  "2. Mirror Formula & Magnification for Concave and Convex Mirrors",
                  "3. Refraction at Spherical Surfaces & Lens Maker's Formula: 1/f = (n-1)(1/R₁ - 1/R₂)",
                  "4. Total Internal Reflection (TIR), Critical Angle i_c & Optical Fibers / Mirages"
                ],
                visualDiagram: "Draw ray diagram showing total internal reflection inside optical fiber core and cladding with critical angle.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. PRISM DEVIATION, DISPERSION & SCATTERING",
                narrationText: "We explore refraction through a prism, angle of deviation δ, minimum deviation δ_m, angular dispersion, and atmospheric scattering of light.",
                equations: [`A + \\delta = i_1 + i_2`, `r_1 + r_2 = A`, `\\mu = \\frac{\\sin((A+\\delta_m)/2)}{\\sin(A/2)}`],
                points: [
                  "5. Refraction and Deviation through a Prism: δ = (μ - 1)A for Small Angle Prism",
                  "6. Condition for Minimum Deviation δ_m & Determination of Refractive Index μ",
                  "7. Dispersion of Light: Angular Dispersion & Dispersive Power",
                  "8. Rayleigh Scattering of Light (I ∝ 1/λ⁴): Blue Sky and Red Sunset Explanation"
                ],
                visualDiagram: "Draw glass triangular prism splitting white light beam into VIBGYOR spectrum with angle of deviation.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. OPTICAL INSTRUMENTS: MICROSCOPES & TELESCOPES",
                narrationText: "We detail optical instruments: Simple Magnifying Glass, Compound Microscope, Astronomical Refracting Telescope, and Reflecting Telescopes.",
                equations: [`m = 1 + \\frac{D}{f} \\text{ (Simple)}`, `M = - \\frac{L}{f_o} \\left( 1 + \\frac{D}{f_e} \\right)`, `M = - \\frac{f_o}{f_e} \\text{ (Telescope)}`],
                points: [
                  "9. Simple Microscope (Magnifying Glass): Angular Magnification m = 1 + D/f",
                  "10. Compound Microscope: Objective & Eyepiece Lenses, High Magnification Formula",
                  "11. Astronomical Telescope in Normal Adjustment: Angular Magnification M = -f_o/f_e",
                  "12. Reflecting Telescopes (Cassegrain & Newtonian): Advantages over Chromatic Aberration"
                ],
                visualDiagram: "Draw compound microscope optical layout showing objective lens forming real image magnified by eyepiece.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('electromagnetic wave') || lessonTitle.toLowerCase().includes('em wave') || lessonTitle.toLowerCase().includes('spectrum')) {
            compiledSlides = [
              {
                slideTitle: "1. DISPLACEMENT CURRENT & AMPERE-MAXWELL LAW",
                narrationText: "Welcome to Chapter 13: Electromagnetic Waves (Pages 516-545). We study Inconsistency of Ampere's Law, Displacement Current I_d = ε₀(dΦ_E/dt), and Ampere-Maxwell Law.",
                equations: [`I_d = \\epsilon_0 \\frac{d\\Phi_E}{dt}`, `\\oint \\mathbf{B} \\cdot d\\mathbf{l} = \\mu_0 \\left( I_c + I_d \\right)`, `\\mathbf{J}_d = \\epsilon_0 \\frac{\\partial \\mathbf{E}}{\\partial t}`],
                points: [
                  "1. Maxwell's Discovery of Ampere's Circuital Law Inconsistency in Charging Capacitor",
                  "2. Displacement Current I_d = ε₀ (dΦ_E / dt) & Current Continuity in Circuits",
                  "3. Ampere-Maxwell General Law: ∮ B · dl = μ₀ (I_c + I_d)",
                  "4. Maxwell's 4 Fundamental Electromagnetic Equations in Vacuum"
                ],
                visualDiagram: "Draw charging parallel plate capacitor showing conduction current I_c in wires and electric flux change creating displacement current I_d between plates.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. PROPERTIES & SPEED OF ELECTROMAGNETIC WAVES",
                narrationText: "We explore EM Wave Transverse Nature (E ⊥ B ⊥ Propagation), Speed in Vacuum c = 1/√(μ₀ε₀) = 3 × 10⁸ m/s, Ratio E₀/B₀ = c, Energy Density and Poynting Vector.",
                equations: [`c = \\frac{1}{\\sqrt{\\mu_0 \\epsilon_0}} = \\frac{E_0}{B_0}`, `u = u_E + u_B = \\frac{1}{2}\\epsilon_0 E^2 + \\frac{B^2}{2\\mu_0}`, `\\mathbf{S} = \\frac{1}{\\mu_0} (\\mathbf{E} \\times \\mathbf{B})`],
                points: [
                  "5. Production of EM Waves by Oscillating / Accelerated Electric Charges",
                  "6. Transverse Nature: Electric Vector E and Magnetic Vector B Oscillate Mutually Perpendicular",
                  "7. Speed in Vacuum c = 3 × 10⁸ m/s, Medium Speed v = 1/√(με) = c / n",
                  "8. Energy Density u = ε₀ E_rms² & Poynting Vector S = (1/μ₀)(E × B) Radiation Intensity"
                ],
                visualDiagram: "Draw 3D coordinate axis showing transverse sinusoidal electric field E along y-axis, magnetic field B along z-axis propagating along x-axis.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. THE ELECTROMAGNETIC SPECTRUM & APPLICATIONS",
                narrationText: "We detail the complete EM Spectrum: Radio Waves, Microwaves, Infrared, Visible, UV, X-Rays, Gamma Rays, their production, wavelength ranges & uses.",
                equations: [`c = f \\lambda`, `E_{photon} = h f = \\frac{h c}{\\lambda}`, `\\lambda_{radio} > \\lambda_{micro} > \\lambda_{IR} > \\lambda_{vis} > \\lambda_{UV} > \\lambda_{X} > \\lambda_{\\gamma}`],
                points: [
                  "9. Radio Waves & Microwaves: Production, Radar Systems, Cellular Networks & Ovens",
                  "10. Infrared & Visible Spectrum: Heat Radiation, Night Vision, Spectroscopy & Optics",
                  "11. Ultraviolet, X-Rays & Gamma Rays: Sterilization, Radiography, Cancer Therapy & Hazards",
                  "12. Solved Board & Competitive Practice Numericals (JEE/NEET/CUET)"
                ],
                visualDiagram: "Draw continuous Electromagnetic Spectrum bar ordered by frequency/wavelength showing labeled bands from Radio to Gamma Rays.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('alternating current') || lessonTitle.toLowerCase().includes('ac circuit') || lessonTitle.toLowerCase().includes('transformer')) {
            compiledSlides = [
              {
                slideTitle: "1. AC FUNDAMENTALS & REACTANCE (R, L, C CIRCUITS)",
                narrationText: "Welcome to Chapter 12: Alternating Current (Pages 466-515). We study Peak and RMS values I_rms = I₀/√2, and Reactance X_L = ωL, X_C = 1/ωC.",
                equations: [`I_{rms} = \\frac{I_0}{\\sqrt{2}}`, `X_L = \\omega L = 2\\pi f L`, `X_C = \\frac{1}{\\omega C} = \\frac{1}{2\\pi f C}`],
                points: [
                  "1. Alternating Current & Peak vs RMS / Effective Value (I_rms = 0.707 I₀)",
                  "2. Pure Resistors (In Phase), Pure Inductors (Voltage Leads by π/2), Pure Capacitors (Current Leads by π/2)",
                  "3. Inductive Reactance X_L = ωL & Capacitive Reactance X_C = 1/(ωC)",
                  "4. Phasor Representation & Vector Diagrams for Phase Relationships"
                ],
                visualDiagram: "Draw sinusoidal AC voltage wave with peak V₀ and RMS level marked alongside current phasor diagram.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. L-C-R SERIES CIRCUIT & ELECTRICAL RESONANCE",
                narrationText: "We analyze L-C-R Series AC Circuits, Impedance Z = √(R² + (X_L - X_C)²), Resonant Frequency f_r = 1/(2π√LC), and Q-Factor.",
                equations: [`Z = \\sqrt{R^2 + (X_L - X_C)^2}`, `f_r = \\frac{1}{2\\pi \\sqrt{LC}}`, `Q = \\frac{\\omega_0 L}{R}`],
                points: [
                  "5. L-C-R Series Circuit Impedance Z & Phase Angle tan φ = (X_L - X_C)/R",
                  "6. Electrical Resonance Condition X_L = X_C & Minimum Impedance Z = R",
                  "7. Resonant Frequency f_r = 1/(2π√LC) & Resonance Sharpness Quality Factor Q",
                  "8. LC Oscillations & Exchange of Electric and Magnetic Energy"
                ],
                visualDiagram: "Draw L-C-R Series circuit diagram alongside Resonance Curve plotting current vs frequency with peak at f_r.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. POWER FACTOR, WATTLESS CURRENT & TRANSFORMERS",
                narrationText: "We explore True Power P = V_rms I_rms cos φ, Power Factor, Wattless Current, and Transformer Principle, Efficiency & Energy Losses.",
                equations: [`P_{true} = V_{rms} I_{rms} \\cos\\phi`, `k = \\frac{N_s}{N_p} = \\frac{V_s}{V_p}`, `\\eta = \\frac{P_{out}}{P_{in}} \\times 100\\%`],
                points: [
                  "9. True Power, Apparent Power & Power Factor cos φ = R/Z",
                  "10. Wattless Current in Pure L or C Circuits (cos φ = 0)",
                  "11. Transformer Step-Up & Step-Down Working (k = N_s / N_p = V_s / V_p)",
                  "12. Transformer Losses (Copper, Iron Hysteresis, Eddy Currents) & Solved Numericals"
                ],
                visualDiagram: "Draw Transformer core with primary coil N_p and secondary coil N_s linked by magnetic flux lines.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('induction') || lessonTitle.toLowerCase().includes('faraday')) {
            compiledSlides = [
              {
                slideTitle: "1. FARADAY'S LAWS & LENZ'S LAW OF EMI",
                narrationText: "Welcome to Chapter 11: Electromagnetic Induction (Pages 416-465). We study Magnetic Flux Φ, Faraday's Laws, Induced EMF e = -dΦ/dt, and Lenz's Law.",
                equations: [`\\Phi = B A \\cos\\theta`, `e = -\\frac{d\\Phi}{dt}`, `q = \\frac{\\Delta\\Phi}{R}`],
                points: [
                  "1. Magnetic Flux Φ = B · A cos θ & Faraday's EMI Experiments",
                  "2. Faraday's First and Second Laws of Electromagnetic Induction",
                  "3. Lenz's Law (Direction of Induced EMF & Energy Conservation)",
                  "4. Induced Current I = e/R & Total Induced Charge q = ΔΦ/R"
                ],
                visualDiagram: "Draw bar magnet moving towards a closed wire coil inducing current indicated by a galvanometer needle deflection.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. MOTIONAL EMF, EDDY CURRENTS & SELF-INDUCTION",
                narrationText: "We analyze Motional EMF (e = Blv), Rotating Rod EMF (e = ½ B ω l²), Eddy Currents, and Self-Inductance L of solenoids.",
                equations: [`e = B l v`, `e = \\frac{1}{2} B \\omega l^2`, `e = -L \\frac{dI}{dt}`],
                points: [
                  "5. Motional EMF in Straight Conductors & Rotating Rod in Uniform Field",
                  "6. Eddy Currents (Foucault Currents): Applications, Induction Furnaces & Minimization",
                  "7. Self-Induction Phenomenon & Self-Inductance L of Solenoid (L = μ₀ N² A / l)",
                  "8. Energy Stored in Magnetic Field of Inductor (U = ½ L I²)"
                ],
                visualDiagram: "Draw conducting rod moving at velocity v along parallel rails in uniform perpendicular magnetic field.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. MUTUAL INDUCTION & AC GENERATOR DYNAMO",
                narrationText: "We explore Mutual Inductance M between coaxial solenoids, Inductor Combinations, and AC Generator principle producing sinusoidal EMF e = e₀ sin ωt.",
                equations: [`e_2 = -M \\frac{dI_1}{dt}`, `e = e_0 \\sin\\omega t`, `e_0 = N B A \\omega`],
                points: [
                  "9. Mutual Induction & Mutual Inductance M of Coaxial Solenoids (M = μ₀ N₁ N₂ A / l)",
                  "10. Series & Parallel Combination of Inductors (L_eq = L₁ + L₂ ± 2M)",
                  "11. AC Generator / Dynamo Working (e = N B A ω sin ωt)",
                  "12. Solved Board & Competitive Practice Numericals (JEE/NEET/CUET)"
                ],
                visualDiagram: "Draw AC Generator rectangular coil rotating between N and S magnetic poles with slip rings and carbon brushes.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('substance') || lessonTitle.toLowerCase().includes('diamagnetic') || lessonTitle.toLowerCase().includes('ferromagnetic')) {
            compiledSlides = [
              {
                slideTitle: "1. INTENSITY OF MAGNETIZATION, PERMEABILITY & SUSCEPTIBILITY",
                narrationText: "Welcome to Chapter 10: Magnetic Classification of Substances (Pages 381-415). We study Intensity of Magnetization M, Field Intensity H, Permeability μ, and Susceptibility χ.",
                equations: [`M = \\frac{m}{V}`, `\\chi = \\frac{M}{H}`, `\\mu_r = 1 + \\chi`],
                points: [
                  "1. Intensity of Magnetization (M = m/V) & Magnetic Intensity H",
                  "2. Magnetic Susceptibility χ = M/H & Relation with Permeability (μ_r = 1 + χ)",
                  "3. Relation B = μ₀ (H + M) & Vector Formulations",
                  "4. Classification Criteria based on Susceptibility χ and Permeability μ_r"
                ],
                visualDiagram: "Draw bar material placed in magnetic field lines demonstrating alignment of atomic magnetic dipoles.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. DIAMAGNETIC, PARAMAGNETIC & FERROMAGNETIC MATERIALS",
                narrationText: "We compare Diamagnetic (χ < 0, temperature independent), Paramagnetic (χ > 0, Curie's Law χ = C/T), and Ferromagnetic materials (Domain theory & Weiss molecular field).",
                equations: [`\\chi_{para} = \\frac{C}{T}`, `\\chi_{ferro} = \\frac{C}{T - T_c}`],
                points: [
                  "5. Diamagnetic Substances (Origin in Orbital Electron Motion & Repulsion by Poles)",
                  "6. Paramagnetic Substances (Permanent Dipoles & Curie's Law χ = C/T)",
                  "7. Ferromagnetic Substances (Domain Theory & Weiss Molecular Field)",
                  "8. Curie Temperature T_c & Transition from Ferromagnetic to Paramagnetic State"
                ],
                visualDiagram: "Draw domain structure inside ferromagnetic crystal before and after external magnetic field alignment.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. HYSTERESIS LOOP & MAGNETIC MATERIAL SELECTION",
                narrationText: "We analyze the Hysteresis Loop (Retentivity and Coercivity), energy loss per cycle, and selection of materials for Permanent Magnets, Electromagnets, and Transformer Cores.",
                equations: [`W_{hysteresis} = \\oint B \\cdot dH`, `\\text{Loss per cycle} = \\text{Area of B-H Loop}`],
                points: [
                  "9. Hysteresis Loop (B-H / I-H Curve, Residual Magnetism / Retentivity & Coercivity)",
                  "10. Hysteresis Loss Energy Dissipation & Loop Area Calculation",
                  "11. Material Selection: Soft Iron for Electromagnets vs Steel/Alnico for Permanent Magnets",
                  "12. Solved Board & Competitive Practice Numericals (JEE/NEET/CUET)"
                ],
                visualDiagram: "Draw B-H Hysteresis Loop showing retentivity intercept on vertical axis and coercivity intercept on horizontal axis.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('earth') || lessonTitle.toLowerCase().includes('terrestrial magnetism')) {
            compiledSlides = [
              {
                slideTitle: "1. BAR MAGNET AS MAGNETIC DIPOLE & GAUSS'S LAW",
                narrationText: "Welcome to Chapter 9: Magnetic Field and Earth's Magnetism (Pages 346-380). We study Bar Magnets, Axial & Equatorial magnetic fields, and Gauss's Law in Magnetism.",
                equations: [`\\tau = M B \\sin\\theta`, `B_{axial} = \\frac{\\mu_0}{4\\pi} \\frac{2 M}{r^3}`, `\\oint \\vec{B} \\cdot d\\vec{A} = 0`],
                points: [
                  "1. Bar Magnet Dipole Moment & Torque τ = M B sin θ",
                  "2. Magnetic Field Intensity on Axial (End-on) & Equatorial (Broadside) Lines",
                  "3. Gauss's Law in Magnetism: Absence of Magnetic Monopoles",
                  "4. Magnetic Field Lines Properties & Comparison with Electrostatic Lines"
                ],
                visualDiagram: "Draw bar magnet with magnetic field lines looping from N pole to S pole externally and S to N internally.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. TERRESTRIAL MAGNETISM & EARTH'S MAGNETIC ELEMENTS",
                narrationText: "We analyze Terrestrial Magnetism and Earth's three magnetic elements: Magnetic Declination θ, Angle of Dip or Inclination δ, and Horizontal Component H_e.",
                equations: [`B_e = \\sqrt{H_e^2 + V_e^2}`, `\\tan\\delta = \\frac{V_e}{H_e}`, `H_e = B_e \\cos\\delta`],
                points: [
                  "5. Earth's Magnetic Field Origin & Magnetic Meridian vs Geographic Meridian",
                  "6. Declination (θ), Angle of Dip / Inclination (δ), Horizontal Component (H_e)",
                  "7. Mathematical Relations between B_e, H_e, V_e and Angle of Dip δ",
                  "8. Neutral Points (Field Cancellation) & Determination of Earth's Field"
                ],
                visualDiagram: "Draw Earth globe with magnetic dipole axis tilted relative to geographic axis, showing magnetic meridian and angle of dip.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. TANGENT GALVANOMETER & TANGENT LAW PRACTICE",
                narrationText: "We study Tangent Galvanometer principle I = K tan θ, Tangent Law formulation, Solved Numericals, and competitive examination practice.",
                equations: [`B = H_e \\tan\\theta`, `I = \\left(\\frac{2 r H_e}{\\mu_0 N}\\right) \\tan\\theta = K \\tan\\theta`],
                points: [
                  "9. Tangent Law Principle (B = H_e tan θ) in Perpendicular Magnetic Fields",
                  "10. Tangent Galvanometer Construction, Working & Reduction Factor K",
                  "11. Solved Board & Competitive Examination Numericals",
                  "12. Objective MCQs & Practice Questions for JEE/NEET/CUET"
                ],
                visualDiagram: "Draw Tangent Galvanometer circular coil with central compass needle deflected by angle θ.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('torque') || lessonTitle.toLowerCase().includes('galvanometer')) {
            compiledSlides = [
              {
                slideTitle: "1. TORQUE ON RECTANGULAR LOOP & MAGNETIC DIPOLE MOMENT",
                narrationText: "Welcome to Chapter 8: Torque on a Current-Loop : Moving-Coil Galvanometer (Pages 311-345). We study Torque on a Rectangular Loop, Magnetic Dipole Moment, and Bohr Magneton.",
                equations: [`\\tau = N I A B \\sin\\theta`, `\\vec{M} = N I \\vec{A}`, `\\mu_b = \\frac{e h}{4\\pi m_e}`],
                points: [
                  "1. Torque on Rectangular Loop in Uniform Field τ = NIAB sin θ",
                  "2. Magnetic Dipole Moment of Current Loop M = N I A",
                  "3. Magnetic Moment of Revolving Electron & Bohr Magneton μ_b",
                  "4. Potential Energy of Magnetic Dipole U = -M B cos θ"
                ],
                visualDiagram: "Draw rectangular coil suspended in uniform magnetic field between N and S pole pieces showing deflecting torque.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. MOVING-COIL GALVANOMETER: Radial Field & Sensitivity",
                narrationText: "We analyze the Moving-Coil Galvanometer principle C θ = N I A B, soft iron core purpose, radial magnetic field, and current and voltage sensitivity formulas.",
                equations: [`I = \\left(\\frac{C}{N A B}\\right) \\theta = K \\theta`, `S_I = \\frac{\\theta}{I} = \\frac{N A B}{C}`, `S_V = \\frac{\\theta}{V} = \\frac{N A B}{C R}`],
                points: [
                  "5. Moving-Coil Galvanometer Principle & Working",
                  "6. Radial Field & Cylindrical Soft Iron Core Function",
                  "7. Deflecting Torque Balance with Restoring Torsional Couple C θ",
                  "8. Current Sensitivity (S_I) & Voltage Sensitivity (S_V)"
                ],
                visualDiagram: "Draw Moving-Coil Galvanometer with concave magnetic poles, cylindrical soft iron core, coil, phosphor bronze strip, and mirror indicator.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. CONVERSION TO AMMETER & VOLTMETER & EXAM PRACTICE",
                narrationText: "We learn how to convert a Galvanometer into an Ammeter using parallel Shunt resistance S and into a Voltmeter using high series resistance R, followed by numerical practice.",
                equations: [`S = \\left(\\frac{I_g}{I - I_g}\\right) G`, `R = \\frac{V}{I_g} - G`],
                points: [
                  "9. Conversion into Ammeter (Parallel Low Shunt Resistance S)",
                  "10. Conversion into Voltmeter (Series High Resistance R)",
                  "11. Ideal Ammeter (Zero Resistance) & Ideal Voltmeter (Infinite Resistance)",
                  "12. Solved Numerical Problems & Competitive Examination Practice"
                ],
                visualDiagram: "Draw galvanometer circuit conversion diagrams: ammeter with parallel shunt S and voltmeter with series resistance R.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('moving charge') || lessonTitle.toLowerCase().includes('magnetic field') || lessonTitle.toLowerCase().includes('biot')) {
            compiledSlides = [
              {
                slideTitle: "1. BIOT-SAVART LAW & AMPERE'S CIRCUITAL LAW",
                narrationText: "Welcome to Chapter 7: Moving Charges and Magnetic Field (Pages 261-310). We study Oersted's experiment, Biot-Savart Law, circular loop fields, Ampere's Circuital Law, Solenoids, and Toroids.",
                equations: [`d\\vec{B} = \\frac{\\mu_0}{4\\pi} \\frac{I (d\\vec{l} \\times \\hat{r})}{r^2}`, `B = \\frac{\\mu_0 I}{2\\pi r}`, `\\oint \\vec{B} \\cdot d\\vec{l} = \\mu_0 I_{enclosed}`],
                points: [
                  "1. Oersted's Discovery & Concept of Magnetic Field B",
                  "2. Biot-Savart Law Vector Formulation & Applications",
                  "3. Field at the Centre & Axis of Circular Current Loop",
                  "4. Ampere's Circuital Law & Fields of Straight Conductor, Solenoid & Toroid"
                ],
                visualDiagram: "Draw circular current loop with magnetic field lines threading through center axis.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. LORENTZ MAGNETIC FORCE & CYCLOTRON",
                narrationText: "We analyze Lorentz magnetic force F = q(v x B), helical trajectory of charged particles in uniform magnetic field, and the Cyclotron resonance principle.",
                equations: [`\\vec{F} = q(\\vec{v} \\times \\vec{B})`, `r = \\frac{m v}{q B}`, `f = \\frac{q B}{2\\pi m}`],
                points: [
                  "5. Lorentz Magnetic Force F = q v B sin θ",
                  "6. Motion of Charge in Magnetic Field (Circular & Helical Paths)",
                  "7. Cyclotron Construction, Frequency & Resonance Condition",
                  "8. Maximum Kinetic Energy of Accelerated Particles in Cyclotron"
                ],
                visualDiagram: "Draw Cyclotron D-shaped metal chambers with spiral particle trajectory in magnetic field.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. FORCE BETWEEN PARALLEL CONDUCTORS & PRACTICE",
                narrationText: "We examine magnetic force on current-carrying conductors F = I L B sin θ, mutual attraction/repulsion between parallel conductors, definition of 1 Ampere, and competitive exam practice.",
                equations: [`F = I L B \\sin\\theta`, `\\frac{F}{L} = \\frac{\\mu_0 I_1 I_2}{2\\pi d}`],
                points: [
                  "9. Force on Current-Carrying Conductor in Magnetic Field",
                  "10. Force Between Two Parallel Current Conductors & Definition of 1 Ampere",
                  "11. Solved Numerical Problems (Board & Competitive Standard)",
                  "12. Objective MCQs for JEE/NEET/CUET Examinations"
                ],
                visualDiagram: "Draw two parallel wires carrying currents I1 and I2 showing magnetic attraction forces.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('dc circuit') || lessonTitle.toLowerCase().includes('kirchhoff') || lessonTitle.toLowerCase().includes('potentiometer')) {
            compiledSlides = [
              {
                slideTitle: "1. DC CIRCUITS & KIRCHHOFF'S LAWS: Energy, EMF & Loop Rules",
                narrationText: "Welcome to Chapter 6: DC Circuits and Measurements (Pages 211-260). We study Electric Energy, Power, EMF, Cell Combinations, and Kirchhoff's Laws.",
                equations: [`P = V I = I^2 R = \\frac{V^2}{R}`, `\\sum I = 0`, `\\sum I R = \\sum E`],
                points: [
                  "1. Electric Energy & Electric Power Formulas & Applications",
                  "2. Electromotive Force (EMF), Terminal Voltage & Internal Resistance",
                  "3. Series, Parallel & Mixed Grouping of Cells",
                  "4. Kirchhoff's First Law (Junction Rule) & Second Law (Loop Rule)"
                ],
                visualDiagram: "Draw closed electrical circuit loop showing voltage sources, resistors, and current directions with Kirchhoff loop arrows.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. Wheatstone Bridge & Meter Bridge Measurements",
                narrationText: "We analyze Wheatstone Bridge balance condition P/Q = R/S, its mathematical derivation, sensitivity, and Meter Bridge determination of unknown resistance.",
                equations: [`\\frac{P}{Q} = \\frac{R}{S}`, `R = X \\left(\\frac{l}{100 - l}\\right)`],
                points: [
                  "5. Wheatstone Bridge Principle, Balance Condition & Sensitivity",
                  "6. Meter Bridge (Slide Wire Bridge) Circuit & Unknown Resistance",
                  "7. End Corrections & Error Minimization in Bridge Circuits"
                ],
                visualDiagram: "Draw diamond Wheatstone bridge circuit with four resistor arms P, Q, R, S and central galvanometer.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. Potentiometer Principles, Calibration & Practice",
                narrationText: "We study the Potentiometer principle V ∝ l, comparison of EMFs of two cells, determination of cell internal resistance, solved numericals, and competitive exam MCQs.",
                equations: [`V = K l`, `\\frac{E_1}{E_2} = \\frac{l_1}{l_2}`, `r = R \\left( \\frac{l_1}{l_2} - 1 \\right)`],
                points: [
                  "8. Potentiometer Principle, Potential Gradient K & Sensitivity",
                  "9. Comparison of EMFs of Two Cells (E₁/E₂ = l₁/l₂)",
                  "10. Determination of Cell Internal Resistance (r = R(l₁/l₂ - 1))",
                  "11. Solved Numerical Problems & Competitive Examination Practice"
                ],
                visualDiagram: "Draw potentiometer wire setup with driver cell, jockey, secondary circuit, and galvanometer.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('resistance') || lessonTitle.toLowerCase().includes('ohm')) {
            compiledSlides = [
              {
                slideTitle: "1. ELECTRIC CURRENT & OHM'S LAW: Drift Velocity & Mechanism",
                narrationText: "Welcome to Chapter 5: Electric Resistance and Ohm's Law (Pages 166-210). We study Electric Current, Free Electron Model, Drift Velocity, Relaxation Time, and Ohm's Law proof.",
                equations: [`I = \\frac{dQ}{dt}`, `I = n e A v_d`, `v_d = \\frac{e E \\tau}{m}`],
                points: [
                  "1. Electric Current & Direction of Current Flow (Ampere)",
                  "2. Free Electron Model & Drift Velocity v_d",
                  "3. Relation between Current & Drift Velocity (I = n e A v_d)",
                  "4. Deduction and Mathematical Proof of Ohm's Law (V = I R)"
                ],
                visualDiagram: "Draw a conductor segment with electric field E, electron drift velocity v_d, and cross-sectional area A.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. Resistance, Resistivity & Temperature Coefficient",
                narrationText: "We analyze Electrical Resistance, Specific Resistance (Resistivity), Current Density j = σE vector form, and Temperature Dependence of Resistance.",
                equations: [`R = \\rho \\frac{l}{A}`, `\\vec{j} = \\sigma \\vec{E}`, `R_t = R_0 (1 + \\alpha \\Delta T)`],
                points: [
                  "5. Factors Affecting Resistance & Specific Resistance (Resistivity ρ)",
                  "6. Electrical Conductivity σ & Current Density Vector Form (j = σE)",
                  "7. Temperature Coefficient of Resistance α",
                  "8. Ohmic vs Non-Ohmic Conductors & V-I Characteristics"
                ],
                visualDiagram: "Draw V-I graph comparing Ohmic linear conductor vs Non-Ohmic diode/vacuum tube curve.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. Resistors, Superconductors & Solved Practice",
                narrationText: "We examine Carbon Color Codes, Thermistors, Superconductors, Cell Internal Resistance, Solved Numerical Problems, and Competitive Examination MCQs.",
                equations: [`E = V + I r`, `r = R \\left( \\frac{E}{V} - 1 \\right)`],
                points: [
                  "9. Carbon Resistor Color Codes & Thermistors",
                  "10. Superconductivity & Transition Temperature",
                  "11. Cell Internal Resistance & Terminal Voltage",
                  "12. Solved Numerical Problems & Competitive Examination Practice"
                ],
                visualDiagram: "Draw circuit diagram with internal resistance r, EMF E, external resistor R, and voltmeter.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('potential')) {
            compiledSlides = [
              {
                slideTitle: "1. ELECTRIC POTENTIAL: Concept & Potential Difference",
                narrationText: "Welcome to Chapter 3: Electric Potential (Pages 86-119). We explore Electric Potential, Potential Difference, SI unit Volt, and potential due to point charges and group of charges.",
                equations: [`V = \\frac{W}{q_0}`, `V = \\frac{1}{4\\pi\\varepsilon_0} \\frac{q}{r}`],
                points: [
                  "1. Concept of Electric Potential & Potential Difference (SI Unit Volt)",
                  "2. Electric Potential due to a Point Charge & Group of Point Charges",
                  "3. Electric Potential due to an Electric Dipole (Axial & Equatorial Lines)",
                  "4. Electron-Volt (eV) Unit of Energy"
                ],
                visualDiagram: "Draw equipotential concentric circles around a positive point charge with potential values.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. Relation with Field, Equipotential Surfaces & Dipole Work",
                narrationText: "We analyze the differential relation E = -dV/dr, equipotential surfaces, potential energy of charge systems, and torque/work done in rotating a dipole in a uniform field.",
                equations: [`E = -\\frac{dV}{dr}`, `W = p E (\\cos\\theta_1 - \\cos\\theta_2)`],
                points: [
                  "5. Relation between Electric Field and Electric Potential (E = -dV/dr)",
                  "6. Equipotential Surfaces & Their Essential Properties",
                  "7. Electric Potential Energy of a System of Point Charges",
                  "8. Work Done in Rotating an Electric Dipole in Uniform Field"
                ],
                visualDiagram: "Draw parallel equipotential planes perpendicular to uniform electric field lines.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. Charged Conductors, Corona Discharge & Practice",
                narrationText: "We evaluate potential distribution on charged conductors, action of points (Corona Discharge), solved numerical problems, and competitive exam questions.",
                equations: [`U = \\frac{1}{4\\pi\\varepsilon_0} \\frac{q_1 q_2}{r}`, `\\sigma \\propto \\frac{1}{r}`],
                points: [
                  "9. Potential of Charged Conductors & Action of Points (Corona Discharge)",
                  "10. Solved Numerical Problems (Board & Entrance Level)",
                  "11. Multiple Choice Questions for Competitive Exams (JEE/NEET/CUET)"
                ],
                visualDiagram: "Draw a charged irregular conductor showing high charge accumulation at sharp points.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('capacitor') || lessonTitle.toLowerCase().includes('dielectric')) {
            compiledSlides = [
              {
                slideTitle: "1. CAPACITANCE: Principles & Parallel Plate Capacitors",
                narrationText: "Welcome to Chapter 4: Capacitors and Dielectrics (Pages 120-165). We study Electrical Capacitance, Farad, Parallel Plate Capacitors, and dielectric medium effects.",
                equations: [`C = \\frac{Q}{V}`, `C = \\frac{K \\varepsilon_0 A}{d}`],
                points: [
                  "1. Electrical Capacitance of a Conductor (Definition & SI Unit Farad)",
                  "2. Capacitance of an Isolated Spherical Conductor (C = 4πε₀r)",
                  "3. Principle & Construction of a Parallel Plate Capacitor",
                  "4. Effect of Dielectric Medium & Dielectric Constant (K)"
                ],
                visualDiagram: "Draw parallel metal plates with opposite charges Q and -Q separated by dielectric slab.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. Combinations, Energy Stored & Sharing of Charges",
                narrationText: "We analyze series and parallel combinations of capacitors, energy stored in capacitors, energy density, and redistribution of charges upon sharing.",
                equations: [`\\frac{1}{C_s} = \\frac{1}{C_1} + \\frac{1}{C_2}`, `U = \\frac{1}{2} C V^2`, `u = \\frac{1}{2} \\varepsilon_0 E^2`],
                points: [
                  "5. Combination of Capacitors in Series and Parallel",
                  "6. Energy Stored in Charged Capacitor & Energy Density",
                  "7. Redistribution of Charge & Loss of Energy on Sharing Charges",
                  "8. Dielectric Polarization & Dielectric Strength"
                ],
                visualDiagram: "Draw schematic diagrams for series and parallel capacitor networks.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. Van de Graaff Generator & Competitive Practice",
                narrationText: "We study the Van de Graaff Generator principle, construction, working, solved numericals, and competitive entrance examination questions.",
                equations: [`V_{common} = \\frac{C_1 V_1 + C_2 V_2}{C_1 + C_2}`, `\\Delta U = \\frac{C_1 C_2 (V_1 - V_2)^2}{2(C_1 + C_2)}`],
                points: [
                  "9. Van de Graaff Generator (Principle, High Voltage & Working)",
                  "10. Solved Numerical Problems",
                  "11. Multiple Choice Questions for Competitive Exams"
                ],
                visualDiagram: "Draw a Van de Graaff Generator showing endless belt, spray comb, and high voltage sphere.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('gauss')) {
            compiledSlides = [
              {
                slideTitle: "1. GAUSS' THEOREM: Electric Flux & Solid Angle",
                narrationText: "Welcome to Chapter 2: Gauss' Theorem (Pages 50-85). We study Area Vector, Solid Angle, Electric Flux, and the core mathematical formulation of Gauss' Theorem.",
                equations: [`\\Phi_E = \\oint \\vec{E} \\cdot d\\vec{A} = \\frac{Q_{enclosed}}{\\varepsilon_0}`, `d\\Omega = \\frac{dA \\cos\\theta}{r^2}`],
                points: [
                  "1. Area Vector & Solid Angle Definition",
                  "2. Electric Flux (Definition, Formula & SI Unit N·m²/C)",
                  "3. Gauss' Law Statement & Mathematical Proof",
                  "4. Deduction of Coulomb's Law from Gauss' Theorem"
                ],
                visualDiagram: "Draw a closed Gaussian surface enclosing charge Q with outward electric flux vector dA.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. Applications: Long Wire, Plane Sheet & Plate",
                narrationText: "We apply Gauss' Law to find electric field intensity due to an infinitely long straight charged wire, infinite thin plane sheet of charge, and near a charged conducting plate.",
                equations: [`E_{wire} = \\frac{\\lambda}{2\\pi\\varepsilon_0 r}`, `E_{sheet} = \\frac{\\sigma}{2\\varepsilon_0}`],
                points: [
                  "5. Field due to Infinitely Long Charged Wire (E ∝ 1/r)",
                  "6. Field due to Infinite Thin Plane Sheet of Charge",
                  "7. Field near a Charged Conducting Plate (E = σ/ε₀)",
                  "8. Field due to Two Parallel Plane Sheets of Charge"
                ],
                visualDiagram: "Draw a cylindrical Gaussian surface around an infinitely long charged wire.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. Spherical Shells, Mechanical Force & Energy Density",
                narrationText: "We evaluate field intensities for thin spherical shells, solid spheres, mechanical force on conductors, energy density of electric fields, solved numericals, and competitive questions.",
                equations: [`E_{shell, outside} = \\frac{1}{4\\pi\\varepsilon_0} \\frac{q}{r^2}`, `u = \\frac{1}{2} \\varepsilon_0 E^2`],
                points: [
                  "9. Field inside, on surface, & outside a Charged Thin Spherical Shell",
                  "10. Field of Uniformly Charged Solid Non-Conducting Sphere",
                  "11. Mechanical Force on a Conductor & Energy Density (u = 1/2 ε₀E²)",
                  "12. Solved Numericals & Competitive Exam Multichoice Questions"
                ],
                visualDiagram: "Draw a thin spherical shell showing radial field vectors outside and zero field inside.",
                diagramType: "steps"
              }
            ];
          } else if (lessonTitle.toLowerCase().includes('electric charge')) {
            compiledSlides = [
              {
                slideTitle: "1. ELECTROSTATICS: Electric Charges & Fundamental Properties",
                narrationText: "Welcome to Chapter 1: Electric Charges and Fields (Pages 1-49). We study Electric Charge, Positive/Negative charges, Electron Theory of Electrification, Conductors, Insulators, Electrostatic Induction, and Coulomb's Law.",
                equations: [`F = \\frac{1}{4\\pi\\varepsilon_0} \\frac{q_1 q_2}{r^2}`, `q = \\pm n e`],
                points: [
                  "1. Electric Charge & Positive/Negative Charges",
                  "2. Electron Theory of Electrification & Conductors vs Insulators",
                  "3. Electrostatic Induction & SI Unit (Coulomb)",
                  "4. Three Important Properties & Coulomb's Law in Vector Form"
                ],
                visualDiagram: "Draw two point charges q1 and q2 separated by distance r with electrostatic force vectors.",
                diagramType: "vectors"
              },
              {
                slideTitle: "2. Superposition Principle & Electric Field Intensity",
                narrationText: "We examine forces between multiple charges using the Superposition Principle, equilibrium of charge systems, concept of electric field, point-charge intensity, and continuous charge distributions.",
                equations: [`\\vec{E} = \\frac{\\vec{F}}{q_0}`, `\\vec{F}_{total} = \\sum \\vec{F}_{1i}`],
                points: [
                  "5. Forces between Multiple Charges & Superposition Principle",
                  "6. Equilibrium of Charge and System of Charges",
                  "7. Concept of Electric Field & Intensity of Electric Field",
                  "8. Field Intensity due to Continuous Charge Distribution"
                ],
                visualDiagram: "Draw electric field lines radiating from positive and negative point charges.",
                diagramType: "graph"
              },
              {
                slideTitle: "3. Electric Lines of Force, Dipoles & Torque",
                narrationText: "We explore Electric Lines of Force, Electric Dipole and Dipole Moment, Electric Field due to an Electric Dipole, Torque on a Dipole in a Uniform Electric Field, along with Solved Numericals and Competitive Exam Practice.",
                equations: [`\\vec{p} = q \\cdot \\vec{2a}`, `\\tau = \\vec{p} \\times \\vec{E}`],
                points: [
                  "9. Electric Lines of Force & Electric Dipole Moment",
                  "10. Electric Field due to an Electric Dipole (Axial & Equatorial)",
                  "11. Torque on a Dipole in a Uniform Electric Field",
                  "12. Solved Numericals & Competitive Exam Multichoice Questions"
                ],
                visualDiagram: "Draw an electric dipole in a uniform electric field showing torque forces.",
                diagramType: "steps"
              }
            ];
          } else {
            compiledSlides = [
              {
                slideTitle: "1. Foundational Core Principles",
                narrationText: `Let us explore the core definition of ${lessonTitle}. In standard terms, it represents the foundational relationship underlying these elements within ${subject}.`,
                equations: [`y = f(x)`, `E = mc^2`],
                points: [
                  "Primary variable scaling and coordinates setup.",
                  "Symmetric behavior across Cartesian grids."
                ],
                visualDiagram: "Draw a standard cartesian grid with a linear functional line.",
                diagramType: "graph"
              },
              {
                slideTitle: "2. Advanced Analysis & Vectors",
                narrationText: `Now, moving on to practical mechanics. We observe how force vectors direct the dynamic velocity trajectories of our target object.`,
                equations: [`F_{net} = \\sum F_i = m \\cdot a`],
                points: [
                  "Vector summation across spatial dimensions.",
                  "Magnitude scaling under continuous gravity acceleration."
                ],
                visualDiagram: "Draw forces vectors pointing at an object.",
                diagramType: "vectors"
              },
              {
                slideTitle: "3. Formula Resolution",
                narrationText: `Finally, by substituting these properties into our differential equations, we obtain the absolute system solution.`,
                equations: [`\\int v(t)\\,dt = s(t) + C`],
                points: [
                  "Continuous integration boundaries mapped.",
                  "System static state solution computed successfully."
                ],
                visualDiagram: "Draw a step-by-step resolution diagram.",
                diagramType: "steps"
              }
            ];
          }
        }

        const cleanSlides: Slide[] = compiledSlides.map(slide => ({
          ...slide,
          slideTitle: stripAllRawMarkdown(slide.slideTitle),
          narrationText: stripAllRawMarkdown(slide.narrationText),
          equations: (slide.equations || []).map(eq => formatLaTeXToUnicode(stripAllRawMarkdown(eq))),
          points: (slide.points || []).map(pt => stripAllRawMarkdown(pt)),
          visualDiagram: stripAllRawMarkdown(slide.visualDiagram)
        }));

        setSlides(cleanSlides);
        setLogs(prev => [...prev, `[Syllabus] Successfully compiled ${cleanSlides.length} interactive chalkboard slides.`]);
        setProgress(60);
        setStatusText(`Synthesizing professional audio voice track in ${langObj.name}...`);

        // Step 2: Lazy synthesize voice for the FIRST slide to speed up load time
        try {
          const firstSlideText = compiledSlides[0].narrationText;
          const pcmData = await generateSpeech(firstSlideText, 'Kore');
          if (pcmData && active) {
            const wavBase64 = convertPcmToWav(pcmData);
            const audioUrl = `data:audio/wav;base64,${wavBase64}`;
            setAudioUrls({ 0: audioUrl });
            setLogs(prev => [...prev, `[TTS] Generated voice narrative track for Slide 1 in ${langObj.name}.`]);
          }
        } catch (ttsErr) {
          console.error("TTS pre-synthesis failed:", ttsErr);
        }

        setProgress(80);
        setStatusText('Rendering custom conceptual 3D graphics...');

        // Step 3: Trigger real video generation (Veo) as background fallback/stock option
        try {
          const slideSummary = slides.map(s => s.slideTitle).join(", ");
          const realUrl = await onGenerateVideo(
            `Professional educational lecture video about "${lessonTitle}". Style: High-quality modern 2D/3D scientific animation or lab demonstration. Subject: ${subject}. Visuals should reflect: ${slideSummary}. Academic rigor: ${difficulty}.`
          );
          if (realUrl && active) {
            setStockVideoUrl(realUrl);
            setLogs(prev => [...prev, '[Veo 3.1] Custom generated stock video compiled successfully.']);
          } else {
            setLogs(prev => [...prev, '[System] Google Veo is restricted or busy. Loaded default high-quality educational background.']);
          }
        } catch (videoErr) {
          console.error("Video synthesis failed:", videoErr);
        }

        setProgress(100);
        setIsCompiling(false);
        setLogs(prev => [...prev, `[Encoder] Interactive lecture compiled in ${langObj.name} successfully. Press PLAY to watch!`]);
      } catch (err) {
        console.error("Compilation error:", err);
        if (active) {
          setError("Failed to compile custom video lesson. Please try again.");
          setIsCompiling(false);
        }
      }
    };

    compileCustomLesson();

    return () => {
      active = false;
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, [lessonTitle, chapterTitle, subject, difficulty, selectedLang]);

  // Audio voice-track execution
  const playCurrentSlideVoice = async (index: number) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }

    const slide = slides[index];
    if (!slide) return;

    let targetUrl = audioUrls[index];

    if (!targetUrl) {
      setIsSynthesizingVoice(true);
      try {
        const pcmData = await generateSpeech(slide.narrationText, 'Kore');
        if (pcmData) {
          const wavBase64 = convertPcmToWav(pcmData);
          const url = `data:audio/wav;base64,${wavBase64}`;
          setAudioUrls(prev => ({ ...prev, [index]: url }));
          targetUrl = url;
        }
      } catch (err) {
        console.error("Speech synthesis error:", err);
      } finally {
        setIsSynthesizingVoice(false);
      }
    }

    if (targetUrl) {
      const audio = new Audio(targetUrl);
      audioRef.current = audio;
      audio.muted = isMuted;
      audio.onended = () => {
        setIsPlaying(false);
        // Autoplay next slide if exists
        if (index < slides.length - 1) {
          setTimeout(() => {
            handleNextSlide();
            setIsPlaying(true);
          }, 1200);
        }
      };
      
      if (isPlaying) {
        audio.play().catch(e => console.error("Audio play failed:", e));
      }
    }
  };

  // Sync state & narration audio when isPlaying or slide index changes
  useEffect(() => {
    if (!isCompiling && slides.length > 0) {
      if (isPlaying) {
        playCurrentSlideVoice(currentSlideIndex);
      } else {
        if (audioRef.current) {
          audioRef.current.pause();
        }
      }
    }
  }, [isPlaying, currentSlideIndex, isCompiling]);

  // Blackboard animation renderer based on diagram instruction
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || isCompiling || slides.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas based on selected aspect ratio
    if (aspectRatio === '916') {
      canvas.width = 360;
      canvas.height = 640;
    } else {
      canvas.width = 640;
      canvas.height = 360;
    }

    const slide = slides[currentSlideIndex];
    if (!slide) return;

    // Draw chalkboard surface texture
    ctx.fillStyle = '#0f172a'; // Deep slate
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Chalk grid lines
    ctx.strokeStyle = 'rgba(255,255,255,0.04)';
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let x = 0; x < canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Dynamic chalkboard drawings
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.85)'; // Red chalk
    ctx.fillStyle = 'rgba(239, 68, 68, 0.85)';
    ctx.lineWidth = 2.5;

    if (slide.diagramType === 'graph') {
      if (aspectRatio === '916') {
        // Draw axes for vertical aspect ratio
        ctx.strokeStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath();
        ctx.moveTo(40, 480);
        ctx.lineTo(320, 480); // X Axis
        ctx.moveTo(60, 100);
        ctx.lineTo(60, 500); // Y Axis
        ctx.stroke();

        // Plot exponential or sine curve
        ctx.strokeStyle = '#f43f5e'; // Rose color
        ctx.beginPath();
        for (let x = 60; x <= 310; x++) {
          const normalizedX = (x - 60) / 250;
          let yVal = 0;
          if (lessonTitle.toLowerCase().includes('trig') || lessonTitle.toLowerCase().includes('wave')) {
            yVal = Math.sin(normalizedX * Math.PI * 4) * 80 + 290;
          } else {
            yVal = 480 - Math.pow(normalizedX, 2.5) * 300;
          }
          if (x === 60) ctx.moveTo(x, yVal);
          else ctx.lineTo(x, yVal);
        }
        ctx.stroke();

        // Label
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.font = 'bold 20px monospace';
        ctx.fillText("X: Scaling Boundary", 140, 520);
        ctx.fillText("Y: Amplitude Function", 75, 90);
      } else {
        // Draw axes for landscape 16:9
        ctx.strokeStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath();
        ctx.moveTo(80, 280);
        ctx.lineTo(560, 280); // X Axis
        ctx.moveTo(100, 40);
        ctx.lineTo(100, 300); // Y Axis
        ctx.stroke();

        // Plot exponential or sine curve
        ctx.strokeStyle = '#f43f5e'; // Rose color
        ctx.beginPath();
        for (let x = 100; x <= 500; x++) {
          const normalizedX = (x - 100) / 400;
          let yVal = 0;
          if (lessonTitle.toLowerCase().includes('trig') || lessonTitle.toLowerCase().includes('wave')) {
            yVal = Math.sin(normalizedX * Math.PI * 4) * 80 + 160;
          } else {
            yVal = 280 - Math.pow(normalizedX, 2.5) * 200;
          }
          if (x === 100) ctx.moveTo(x, yVal);
          else ctx.lineTo(x, yVal);
        }
        ctx.stroke();

        // Label
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.font = 'bold 20px monospace';
        ctx.fillText("X: Scaling Boundary", 420, 300);
        ctx.fillText("Y: Amplitude Function", 115, 60);
      }

    } else if (slide.diagramType === 'vectors') {
      // Draw Clean Blackboard Coordinate Grid
      const ox = aspectRatio === '916' ? 180 : 320;
      const oy = aspectRatio === '916' ? 320 : 180;
      const scale = aspectRatio === '916' ? 0.85 : 1.0;
      
      // X & Y Axes
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(ox - 150 * scale, oy);
      ctx.lineTo(ox + 150 * scale, oy);
      ctx.moveTo(ox, oy + 120 * scale);
      ctx.lineTo(ox, oy - 120 * scale);
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 20px monospace';
      ctx.fillText("X-Axis", ox + 155 * scale, oy + 4);
      ctx.fillText("Y-Axis", ox - 18, oy - 125 * scale);
      ctx.fillText("O(0,0)", ox - 35, oy + 18);

    } else if (slide.diagramType === 'bonds' || subject.toLowerCase().includes('chemistry')) {
      // Draw Molecular bounds / bonds
      const cx = aspectRatio === '916' ? 180 : 320;
      const cy = aspectRatio === '916' ? 320 : 180;
      const scale = aspectRatio === '916' ? 0.8 : 1.0;

      // Central atom
      ctx.fillStyle = '#ef4444'; // Red Oxygen
      ctx.beginPath();
      ctx.arc(cx, cy, 28 * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.round(24 * scale)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText("O", cx, cy + 8 * scale);

      // Hydrogen 1
      ctx.fillStyle = '#3b82f6';
      ctx.beginPath();
      ctx.arc(cx - 100 * scale, cy + 80 * scale, 18 * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillText("H", cx - 100 * scale, cy + 85 * scale);

      // Hydrogen 2
      ctx.fillStyle = '#3b82f6';
      ctx.beginPath();
      ctx.arc(cx + 100 * scale, cy + 80 * scale, 18 * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillText("H", cx + 100 * scale, cy + 85 * scale);

      // Covalent bonds lines
      ctx.strokeStyle = 'rgba(255,255,255,0.6)';
      ctx.lineWidth = 4 * scale;
      ctx.beginPath();
      ctx.moveTo(cx - 20 * scale, cy + 15 * scale);
      ctx.lineTo(cx - 80 * scale, cy + 65 * scale);
      ctx.moveTo(cx + 20 * scale, cy + 15 * scale);
      ctx.lineTo(cx + 80 * scale, cy + 65 * scale);
      ctx.stroke();

      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.font = 'bold 18px monospace';
      ctx.fillText("Covalent Electron Sharing", cx, cy - 50 * scale);

    } else {
      // Flow steps or standard boxes
      if (aspectRatio === '916') {
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        const boxWidth = 180;
        const boxHeight = 55;
        const bx = 180; // center x
        
        // Block 1
        ctx.strokeRect(bx - boxWidth / 2, 120, boxWidth, boxHeight);
        ctx.fillStyle = 'rgba(239, 68, 68, 0.1)';
        ctx.fillRect(bx - boxWidth / 2, 120, boxWidth, boxHeight);

        // Arrow 1 down
        ctx.strokeStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath();
        ctx.moveTo(bx, 180);
        ctx.lineTo(bx, 220);
        ctx.stroke();

        // Block 2
        ctx.strokeStyle = '#10b981';
        ctx.strokeRect(bx - boxWidth / 2, 230, boxWidth, boxHeight);
        ctx.fillStyle = 'rgba(16, 185, 129, 0.1)';
        ctx.fillRect(bx - boxWidth / 2, 230, boxWidth, boxHeight);

        // Arrow 2 down
        ctx.strokeStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath();
        ctx.moveTo(bx, 290);
        ctx.lineTo(bx, 330);
        ctx.stroke();

        // Block 3
        ctx.strokeStyle = '#f59e0b';
        ctx.strokeRect(bx - boxWidth / 2, 340, boxWidth, boxHeight);
        ctx.fillStyle = 'rgba(245, 158, 11, 0.1)';
        ctx.fillRect(bx - boxWidth / 2, 340, boxWidth, boxHeight);

        // Labels
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 18px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText("INPUT STATE", bx, 155);
        ctx.fillText("PROCESSOR", bx, 265);
        ctx.fillText("OUTPUT STATE", bx, 375);
      } else {
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        const stepsY = 180;
        
        // Block 1
        ctx.strokeRect(80, stepsY - 40, 120, 60);
        ctx.fillStyle = 'rgba(239, 68, 68, 0.1)';
        ctx.fillRect(80, stepsY - 40, 120, 60);

        // Arrow 1
        ctx.strokeStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath();
        ctx.moveTo(210, stepsY - 10);
        ctx.lineTo(250, stepsY - 10);
        ctx.stroke();

        // Block 2
        ctx.strokeStyle = '#10b981';
        ctx.strokeRect(260, stepsY - 40, 120, 60);
        ctx.fillStyle = 'rgba(16, 185, 129, 0.1)';
        ctx.fillRect(260, stepsY - 40, 120, 60);

        // Arrow 2
        ctx.strokeStyle = 'rgba(255,255,255,0.5)';
        ctx.beginPath();
        ctx.moveTo(390, stepsY - 10);
        ctx.lineTo(430, stepsY - 10);
        ctx.stroke();

        // Block 3
        ctx.strokeStyle = '#f59e0b';
        ctx.strokeRect(440, stepsY - 40, 120, 60);
        ctx.fillStyle = 'rgba(245, 158, 11, 0.1)';
        ctx.fillRect(440, stepsY - 40, 120, 60);

        // Labels
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 18px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText("INPUT STATE", 140, stepsY - 2);
        ctx.fillText("PROCESSOR", 320, stepsY - 2);
        ctx.fillText("OUTPUT STATE", 500, stepsY - 2);
      }
    }

    // Subtle Branding Watermark
    ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 1;
    ctx.textAlign = 'center';
    
    // Tiny divider line above watermark
    ctx.beginPath();
    ctx.moveTo(30, canvas.height - 35);
    ctx.lineTo(canvas.width - 30, canvas.height - 35);
    ctx.stroke();

    ctx.font = 'bold 13px monospace';
    ctx.fillText(`⚡ GENERATED BY OMNI AI • OMNI-AI.STUDIO`, canvas.width / 2, canvas.height - 21);
    ctx.font = 'bold 10px monospace';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.fillText(`SCAN OR VISIT TO SOLVE PRACTICE PROBLEMS`, canvas.width / 2, canvas.height - 9);
  }, [currentSlideIndex, slides, isCompiling, aspectRatio]);

  const handleNextSlide = () => {
    if (currentSlideIndex < slides.length - 1) {
      setCurrentSlideIndex(prev => prev + 1);
    }
  };

  const handlePrevSlide = () => {
    if (currentSlideIndex > 0) {
      setCurrentSlideIndex(prev => prev - 1);
    }
  };

  const handleTogglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const handleToggleMute = () => {
    setIsMuted(!isMuted);
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
    }
  };

  // Generate complete study cheat-sheet file
  const handleDownloadCheatSheet = () => {
    if (slides.length === 0) return;

    let markdown = `# Dynamic Lecture Cheat-Sheet: ${lessonTitle}\n`;
    markdown += `**Subject**: ${subject} | **Difficulty**: ${difficulty} | **Chapter**: ${chapterTitle}\n\n`;
    markdown += `---\n\n`;

    slides.forEach((slide, idx) => {
      markdown += `### Slide ${idx + 1}: ${slide.slideTitle}\n\n`;
      markdown += `> *Vocal Narration Script*: "${slide.narrationText}"\n\n`;
      
      if (slide.equations.length > 0) {
        markdown += `**Core Equations & Rules**:\n`;
        slide.equations.forEach(eq => {
          markdown += `- \` ${eq} \` \n`;
        });
        markdown += `\n`;
      }

      if (slide.points.length > 0) {
        markdown += `**Key Learning Breakdowns**:\n`;
        slide.points.forEach(pt => {
          markdown += `- ${pt}\n`;
        });
        markdown += `\n`;
      }
      markdown += `*Board Illustration Map*: ${slide.visualDiagram}\n\n`;
      markdown += `---\n\n`;
    });

    const blob = new Blob([markdown], { type: 'text/markdown' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${lessonTitle.replace(/\s+/g, '_')}_study_guide.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col bg-slate-950 text-slate-100 rounded-3xl overflow-hidden shadow-2xl border border-slate-800 max-w-4xl w-full mx-auto animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold shadow-lg shadow-red-900/20 animate-pulse">
            <Tv size={15} />
          </div>
          <div className="text-left">
            <h3 className="font-black text-sm tracking-tight text-white uppercase leading-none">
              EduTube Lecture Simulator
            </h3>
            <span className="text-[9px] text-slate-400 font-bold tracking-wider uppercase">
              Interactive Audio & Board Synthesis
            </span>
          </div>
        </div>
        
        {/* Tab Selector */}
        {!isCompiling && (
          <div className="flex items-center gap-3">
            <div className="flex bg-slate-950 p-1.5 rounded-xl border border-slate-800 scale-90 sm:scale-100">
              <button
                onClick={() => {
                  setActiveTab('interactive');
                  setIsPlaying(false);
                }}
                className={`px-3 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  activeTab === 'interactive' 
                    ? 'bg-red-600 text-white shadow-md' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Eye size={11} />
                Chalkboard
              </button>
              <button
                onClick={() => {
                  setActiveTab('stock');
                  setIsPlaying(false);
                }}
                className={`px-3 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  activeTab === 'stock' 
                    ? 'bg-red-600 text-white shadow-md' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Tv size={11} />
                Stock Video
              </button>
            </div>

            {activeTab === 'interactive' && (
              <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 gap-1 scale-90 sm:scale-100">
                <button
                  onClick={() => setAspectRatio('169')}
                  className={`px-2.5 py-1 text-[9px] font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                    aspectRatio === '169' 
                      ? 'bg-indigo-600 text-white shadow-sm' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Landscape format (16:9)"
                >
                  16:9
                </button>
                <button
                  onClick={() => setAspectRatio('916')}
                  className={`px-2.5 py-1 text-[9px] font-black uppercase tracking-wider rounded-lg transition-all cursor-pointer ${
                    aspectRatio === '916' 
                      ? 'bg-indigo-600 text-white shadow-sm' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Vertical format (9:16 Shorts/TikTok)"
                >
                  9:16 Shorts
                </button>
              </div>
            )}
          </div>
        )}

        <button 
          onClick={onClose}
          className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X size={18} />
        </button>
      </div>

      {/* Main Body */}
      <div className="p-6 space-y-5">
        
        {/* Meta Header */}
        <div className="bg-slate-900/60 border border-slate-850 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-left">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[9px] bg-red-500/15 text-red-400 border border-red-500/10 font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                {subject}
              </span>
              <span className="text-[9px] bg-indigo-500/15 text-indigo-400 border border-indigo-500/10 font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                {difficulty}
              </span>
            </div>
            <h2 className="text-base font-black text-white leading-tight">
              {lessonTitle}
            </h2>
            <p className="text-xs text-slate-400 font-medium">
              Curriculum Core: <span className="text-slate-200 font-semibold">{chapterTitle}</span>
            </p>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <Globe size={11} className="text-red-500" /> Translate:
              </span>
              <div className="relative">
                <button
                  onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                  className="flex items-center gap-1.5 bg-slate-950 hover:bg-slate-900 text-slate-200 font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-lg border border-slate-800 transition active:scale-95 cursor-pointer"
                >
                  <span>{LANGUAGES.find(l => l.code === selectedLang)?.flag}</span>
                  <span>{LANGUAGES.find(l => l.code === selectedLang)?.name}</span>
                  <ChevronDown size={10} className="text-slate-500" />
                </button>
                <AnimatePresence>
                  {isLangDropdownOpen && (
                    <>
                      {/* Backdrop to close click */}
                      <div 
                        className="fixed inset-0 z-40" 
                        onClick={() => setIsLangDropdownOpen(false)}
                      />
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 5 }}
                        className="absolute left-0 mt-1.5 w-52 max-h-60 overflow-y-auto bg-slate-900 border border-slate-800 rounded-xl shadow-2xl z-50 p-1.5 scrollbar-thin"
                      >
                        {LANGUAGES.map((lang) => (
                          <button
                            key={lang.code}
                            onClick={() => {
                              setSelectedLang(lang.code);
                              setIsLangDropdownOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition ${
                              selectedLang === lang.code
                                ? 'bg-red-600/15 text-red-400 border border-red-500/10'
                                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                            }`}
                          >
                            <span className="flex items-center gap-1.5">
                              <span>{lang.flag}</span>
                              <span>{lang.name}</span>
                            </span>
                            <span className="text-[9px] text-slate-500 font-mono normal-case">{lang.native}</span>
                          </button>
                        ))}
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
              {/* Start Lesson button after translation drop-down list button */}
              <button
                onClick={() => {
                  onGenerateVideo(`Interactive Video Lesson: ${lessonTitle}`);
                }}
                className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-lg border border-emerald-500 transition active:scale-95 cursor-pointer shadow-md ml-1"
                title="Start Video Lesson"
              >
                <Play size={10} className="fill-white" />
                <span>Start Lesson</span>
              </button>
            </div>
          </div>

          <div className="flex gap-2 flex-wrap justify-end">
            {activeTab === 'interactive' && !isCompiling && (
              <button
                onClick={() => setExportModalOpen(true)}
                className="flex items-center justify-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[10px] uppercase tracking-wider px-3.5 py-2 rounded-xl cursor-pointer shadow-lg shadow-indigo-950/30 transition active:scale-95"
              >
                <Sparkles size={13} className="text-white animate-pulse" />
                <span>Social Shorts Exporter</span>
              </button>
            )}

            {!isCompiling && onPublishToEduTube && (
              <button
                onClick={() => setExportModalOpen(true)}
                className="flex items-center justify-center gap-1.5 bg-gradient-to-r from-red-600 to-indigo-600 hover:from-red-500 hover:to-indigo-500 text-white font-black text-[10px] uppercase tracking-wider px-3.5 py-2 rounded-xl cursor-pointer shadow-lg shadow-indigo-950/30 transition active:scale-95"
              >
                <Tv size={13} />
                <span>Publish to EduTube</span>
              </button>
            )}

            <button
              onClick={handleDownloadCheatSheet}
              disabled={isCompiling}
              className="flex items-center justify-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white font-black text-[10px] uppercase tracking-wider px-3.5 py-2 rounded-xl cursor-pointer shadow-lg transition active:scale-95 disabled:opacity-50"
            >
              <FileText size={13} />
              <span>Syllabus Notes</span>
            </button>

            {activeTab === 'stock' && !isCompiling && stockVideoUrl && (
              <button
                onClick={() => downloadFileFromUrl(stockVideoUrl, `${lessonTitle.replace(/\s+/g, '_')}_stock_lecture.mp4`)}
                className="flex items-center justify-center gap-1.5 bg-red-600 hover:bg-red-500 text-white font-black text-[10px] uppercase tracking-wider px-3.5 py-2 rounded-xl cursor-pointer shadow-lg shadow-red-900/20 transition active:scale-95"
              >
                <Download size={13} />
                <span>Download MP4</span>
              </button>
            )}
          </div>
        </div>

        {/* Compile Progress Overlay */}
        {isCompiling ? (
          <div className="space-y-5 py-8 text-center max-w-md mx-auto">
            <div className="flex flex-col items-center justify-center space-y-3">
              <Loader2 className="animate-spin text-red-500" size={40} />
              <div>
                <p className="font-black text-sm text-white">{statusText}</p>
                <p className="text-[10px] text-slate-500 font-mono mt-1 uppercase tracking-wider">
                  Compiling High-Definition Video Lesson ({progress}%)
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <motion.div 
                className="h-full bg-red-600 rounded-full shadow-[0_0_12px_rgba(239,68,68,0.6)]" 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>

            {/* Logs Terminal */}
            <div className="bg-slate-950 border border-slate-900 rounded-2xl p-4 text-left h-[120px] overflow-y-auto scrollbar-thin">
              {logs.map((log, idx) => (
                <div key={idx} className="flex items-start gap-2 text-[10px] font-mono text-slate-400 mb-1 last:mb-0">
                  <span className="text-red-500 font-black">❯</span>
                  <span>{log}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* Left: View Panel */}
            <div className="lg:col-span-8 space-y-4">
              
              {activeTab === 'interactive' ? (
                /* Interactive Canvas Chalkboard with Audio Voice */
                <div className="bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 relative shadow-2xl flex flex-col">
                  
                  {/* Canvas Slate */}
                  <div className={`relative bg-slate-950 flex items-center justify-center overflow-hidden transition-all duration-300 ${
                    aspectRatio === '916' 
                      ? 'aspect-[9/16] max-h-[580px] w-full max-w-[326px] mx-auto rounded-t-2xl border-x border-slate-800' 
                      : 'aspect-video w-full'
                  }`}>
                    <canvas 
                      ref={canvasRef} 
                      className="absolute inset-0 w-full h-full object-cover"
                    />

                    {/* Subtitle / Overlay voice block */}
                    {isPlaying && slides[currentSlideIndex] && (
                      <div className="absolute bottom-4 left-4 right-4 bg-slate-950/80 backdrop-blur-md border border-slate-800 rounded-xl p-3 text-center animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <p className="text-xs text-red-400 font-mono font-black uppercase tracking-widest mb-1 flex items-center justify-center gap-1">
                          <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping" />
                          Narrator Voice-over
                        </p>
                        <p className="text-xs text-slate-200 font-medium italic">
                          "{slides[currentSlideIndex].narrationText}"
                        </p>
                      </div>
                    )}

                    {/* Synthesizing loading overlay */}
                    {isSynthesizingVoice && (
                      <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm flex flex-col items-center justify-center gap-2">
                        <Loader2 className="animate-spin text-red-500" size={24} />
                        <span className="text-[10px] font-bold uppercase text-slate-400">
                          Synthesizing voice track...
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Chalkboard controls */}
                  <div className="bg-slate-950 px-4 py-3 border-t border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={handleTogglePlay}
                        className="w-10 h-10 rounded-xl bg-red-600 hover:bg-red-500 text-white flex items-center justify-center cursor-pointer transition active:scale-95"
                      >
                        {isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" />}
                      </button>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={handlePrevSlide}
                          disabled={currentSlideIndex === 0}
                          className="p-1.5 text-slate-400 hover:text-white disabled:opacity-35 cursor-pointer"
                        >
                          <ChevronLeft size={18} />
                        </button>
                        <span className="text-[10px] font-mono text-slate-400">
                          Slide {currentSlideIndex + 1} / {slides.length}
                        </span>
                        <button
                          onClick={handleNextSlide}
                          disabled={currentSlideIndex === slides.length - 1}
                          className="p-1.5 text-slate-400 hover:text-white disabled:opacity-35 cursor-pointer"
                        >
                          <ChevronRight size={18} />
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5">
                      {/* Audio visualizer peaks */}
                      {isPlaying && !isSynthesizingVoice && (
                        <div className="flex gap-0.5 h-3 items-end">
                          <span className="w-0.5 bg-red-500 animate-pulse h-full" />
                          <span className="w-0.5 bg-red-500 animate-pulse h-2" />
                          <span className="w-0.5 bg-red-500 animate-pulse h-4" />
                          <span className="w-0.5 bg-red-500 animate-pulse h-1" />
                        </div>
                      )}

                      <button
                        onClick={() => {
                          if (stockVideoUrl) {
                            downloadFileFromUrl(stockVideoUrl, `${lessonTitle.replace(/\s+/g, '_')}_ai_recorded_video.mp4`);
                          }
                        }}
                        className="flex items-center gap-1 bg-red-600 hover:bg-red-500 text-white font-black text-[10px] uppercase tracking-wider px-2.5 py-1.5 rounded-xl transition active:scale-95 shadow-lg cursor-pointer"
                        title="Download AI Generated Recorded Video"
                      >
                        <Download size={12} />
                        <span>Download MP4</span>
                      </button>

                      <button
                        onClick={handleToggleMute}
                        className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
                      >
                        {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                      </button>
                    </div>
                  </div>

                </div>
              ) : (
                /* Standard pre-compiled video option */
                <div className="bg-black rounded-2xl overflow-hidden border border-slate-800 aspect-video relative shadow-2xl">
                  <video
                    src={stockVideoUrl}
                    controls
                    autoPlay
                    loop
                    className="absolute inset-0 w-full h-full object-contain"
                  />
                  
                  {/* AI Content Overlay to match interactive content */}
                  <div className="absolute inset-0 pointer-events-none flex flex-col items-start p-6 bg-gradient-to-t from-black/60 via-transparent to-black/30">
                    <motion.div 
                      initial={{ opacity: 0, y: -20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-900/80 backdrop-blur-md border border-white/10 px-4 py-2 rounded-xl shadow-xl mb-4"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Sparkles size={12} className="text-red-500" />
                        <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">AI Concept Layer</span>
                      </div>
                      <h3 className="text-white text-sm font-bold">{slides[currentSlideIndex]?.slideTitle || lessonTitle}</h3>
                    </motion.div>

                    <div className="mt-auto space-y-2">
                      {slides[currentSlideIndex]?.equations.slice(0, 2).map((eq, i) => (
                        <motion.div 
                          key={i}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 * i }}
                          className="bg-red-600/20 backdrop-blur-md border border-red-500/30 px-3 py-1.5 rounded-lg text-xs text-white font-mono shadow-lg"
                        >
                          {eq}
                        </motion.div>
                      ))}
                      {slides[currentSlideIndex]?.points.slice(0, 3).map((p, i) => (
                        <motion.div 
                          key={i}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.3 + (0.1 * i) }}
                          className="bg-slate-900/40 backdrop-blur-sm px-2 py-1 rounded text-[10px] text-slate-200 border border-white/5"
                        >
                          • {p}
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Dynamic Information Block */}
              {activeTab === 'interactive' && slides[currentSlideIndex] && (
                <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 space-y-3 text-left">
                  <div className="flex items-center gap-2 text-red-400">
                    <BookOpen size={14} />
                    <span className="text-[10px] font-black uppercase tracking-wider">
                      Slide Topic: {slides[currentSlideIndex].slideTitle}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed font-medium">
                    {slides[currentSlideIndex].narrationText}
                  </p>
                </div>
              )}

            </div>

            {/* Right: Board Breakdown and Syllabus Index */}
            <div className="lg:col-span-4 space-y-4 text-left">
              
              {/* Lecture Timeline / Slide Index */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                  <Layers size={13} className="text-red-500" />
                  Lecture Chapters
                </h3>
                
                <div className="space-y-2">
                  {slides.map((slide, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setCurrentSlideIndex(idx);
                        setIsPlaying(true);
                      }}
                      className={`w-full text-left p-3 rounded-xl border text-xs transition-all flex items-center justify-between cursor-pointer ${
                        currentSlideIndex === idx 
                          ? 'bg-red-600/10 border-red-500/50 text-white' 
                          : 'bg-slate-950/40 border-slate-850 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <span className="text-[9px] font-bold text-red-400 block uppercase tracking-wide">
                          Part {idx + 1}
                        </span>
                        <span className="font-bold block leading-snug">
                          {slide.slideTitle}
                        </span>
                      </div>
                      <ChevronRight size={14} className={currentSlideIndex === idx ? 'text-red-400' : 'text-slate-600'} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Key Equations Board Drawing Panel */}
              {activeTab === 'interactive' && slides[currentSlideIndex] && (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                    <Award size={13} className="text-red-500" />
                    Chalk Formulas
                  </h3>

                  <div className="space-y-2">
                    {slides[currentSlideIndex].equations.map((eq, i) => (
                      <div 
                        key={i} 
                        className="bg-slate-950 p-3 rounded-xl border border-slate-850 font-mono text-center text-xs text-yellow-400 select-all"
                      >
                        {eq}
                      </div>
                    ))}
                  </div>

                  <div className="space-y-1.5 pt-2 border-t border-slate-800/60">
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block">
                      Learning Outcomes:
                    </span>
                    {slides[currentSlideIndex].points.map((pt, i) => (
                      <div key={i} className="flex gap-2 items-start text-xs text-slate-300">
                        <span className="text-red-500 mt-1 font-black">✓</span>
                        <span>{pt}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>

          </div>
        )}

      </div>

      {/* Footer */}
      <div className="px-6 py-3.5 bg-slate-950 border-t border-slate-900 flex justify-between items-center text-[10px] text-slate-500 font-mono uppercase tracking-wider">
        <span>Curriculum Target: {lessonTitle.slice(0, 30)}...</span>
        <span>Omni AI & TTS Studio</span>
      </div>

      {/* Viral Shorts Exporter Modal Overlay */}
      <AnimatePresence>
        {exportModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-auto">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 bg-slate-950/85 backdrop-blur-md"
              onClick={() => setExportModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className="relative bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl text-left flex flex-col max-h-[90vh]"
            >
              {/* Modal Header */}
              <div className="px-6 py-4 bg-slate-950 border-b border-slate-850 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-900/20">
                    <Sparkles size={15} className="animate-pulse" />
                  </div>
                  <div>
                    <h3 className="font-black text-sm tracking-tight text-white uppercase leading-none">
                      Viral Lecture Shorts Exporter
                    </h3>
                    <span className="text-[9px] text-slate-400 font-bold tracking-wider uppercase">
                      One-Click Social Exporter & growth loop
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setExportModalOpen(false)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto space-y-6 scrollbar-thin">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-start">
                  
                  {/* Left Column: Visual export */}
                  <div className="space-y-4">
                    <div className="bg-slate-950 p-3 rounded-2xl border border-slate-850 flex flex-col items-center">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-2 block">
                        Vertical Board Preview (Slide {currentSlideIndex + 1})
                      </span>
                      
                      {/* Interactive ratio preview indicator */}
                      <div className="relative aspect-[9/16] w-36 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-center overflow-hidden shadow-inner">
                        {/* Fake mini board drawings */}
                        <div className="absolute inset-0 flex flex-col justify-between p-2 opacity-80 pointer-events-none">
                          <span className="text-[5px] font-mono text-yellow-500 font-bold self-start">{slides[currentSlideIndex]?.slideTitle}</span>
                          <div className="w-full flex-1 flex items-center justify-center">
                            <span className="text-[4px] font-mono text-indigo-400 text-center uppercase tracking-wide leading-none">
                              {slides[currentSlideIndex]?.diagramType} layout<br/>
                              watermark active
                            </span>
                          </div>
                          <span className="text-[4px] font-mono text-slate-500 text-center">OMNI-AI.STUDIO • ⚡</span>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          // Make sure aspect ratio is vertical before download
                          setAspectRatio('916');
                          // Brief timeout to let canvas render update before downloading
                          setTimeout(() => {
                            const canvas = canvasRef.current;
                            if (canvas) {
                              const dataUrl = canvas.toDataURL("image/png");
                              const link = document.createElement('a');
                              link.href = dataUrl;
                              link.download = `${lessonTitle.replace(/\s+/g, '_')}_slide_${currentSlideIndex + 1}_short.png`;
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                            }
                          }, 100);
                        }}
                        className="w-full mt-3 flex items-center justify-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[10px] uppercase tracking-wider py-2.5 rounded-xl cursor-pointer shadow-lg transition active:scale-95"
                      >
                        <Download size={13} />
                        <span>Export Frame PNG (9:16)</span>
                      </button>
                    </div>

                    <div className="bg-slate-950/40 p-4 border border-slate-850 rounded-2xl space-y-2">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                        <CheckCircle2 size={13} className="text-emerald-500" />
                        Watermark Applied
                      </h4>
                      <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                        The downloaded high-fidelity chalkboard drawing will contain a clean, subtle vector watermark <code className="text-yellow-400 font-mono">OMNI-AI.STUDIO • ⚡</code> to direct organic student viewers to your learning platform.
                      </p>
                    </div>
                  </div>

                  {/* Right Column: Pre-written micro-lessons */}
                  <div className="space-y-4">
                    {/* Twitter/X template */}
                    <div className="bg-slate-950 p-4 border border-slate-850 rounded-2xl space-y-2 relative">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-200 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                          Twitter / X Micro-Lesson
                        </span>
                        <button
                          onClick={() => {
                            const slide = slides[currentSlideIndex];
                            if (!slide) return;
                            const eqs = slide.equations.join(' & ');
                            const bulletPoints = slide.points.map(p => `• ${p}`).join('\n');
                            const txt = `🧠 LESSON BREAKDOWN: ${lessonTitle} (${subject})\n\n` +
                              `Check out this synthesized vertical blackboard short! \n` +
                              (eqs ? `📝 Core formulas: ${eqs}\n` : '') +
                              `${bulletPoints}\n\n` +
                              `👉 Solve interactive practice tests and earn rewards at Omni AI Studio! #STEM #AI #EdTech #StudyTips`;
                            navigator.clipboard.writeText(txt);
                            setCopiedTextType('twitter');
                            setTimeout(() => setCopiedTextType(null), 2000);
                          }}
                          className="flex items-center gap-1 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white text-[9px] font-bold uppercase px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                        >
                          {copiedTextType === 'twitter' ? (
                            <>
                              <Check size={10} className="text-emerald-500" />
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy size={10} />
                              <span>Copy Post</span>
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-[10px] text-slate-300 font-mono whitespace-pre-wrap max-h-28 overflow-y-auto bg-slate-900/60 p-2.5 rounded-lg border border-slate-850 select-all">
                        {(() => {
                          const slide = slides[currentSlideIndex];
                          if (!slide) return '';
                          const eqs = slide.equations.join(' & ');
                          const bulletPoints = slide.points.map(p => `• ${p}`).join('\n');
                          return `🧠 LESSON BREAKDOWN: ${lessonTitle} (${subject})\n\n` +
                            `Check out this synthesized vertical blackboard short! \n` +
                            (eqs ? `📝 Core formulas: ${eqs}\n` : '') +
                            `${bulletPoints}\n\n` +
                            `👉 Solve interactive practice tests and earn rewards at Omni AI Studio! #STEM #AI #EdTech #StudyTips`;
                        })()}
                      </p>
                    </div>

                    {/* LinkedIn template */}
                    <div className="bg-slate-950 p-4 border border-slate-850 rounded-2xl space-y-2 relative">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-200 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                          LinkedIn Professional
                        </span>
                        <button
                          onClick={() => {
                            const slide = slides[currentSlideIndex];
                            if (!slide) return;
                            const eqs = slide.equations.join('\n• ');
                            const bulletPoints = slide.points.map(p => `• ${p}`).join('\n');
                            const txt = `🎓 Digital Tutoring & Visual Learning: ${lessonTitle}\n\n` +
                              `I just synthesized an interactive, voice-narrated micro-lesson on "${chapterTitle}" using Omni AI Studio. Complex science and engineering concepts are instantly converted into stylized blackboard vector animations.\n\n` +
                              `📌 Key Takeaways:\n` +
                              `${bulletPoints}\n\n` +
                              (eqs ? `📐 Essential Formulas:\n• ${eqs}\n\n` : '') +
                              `Omni AI leverages full-spectrum LLMs & speech technology to make learning accessible and engaging for competitive exams. \n\n` +
                              `Try it out: #AIinEducation #LearningCompanion #EdTech #OmniAI`;
                            navigator.clipboard.writeText(txt);
                            setCopiedTextType('linkedin');
                            setTimeout(() => setCopiedTextType(null), 2000);
                          }}
                          className="flex items-center gap-1 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white text-[9px] font-bold uppercase px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                        >
                          {copiedTextType === 'linkedin' ? (
                            <>
                              <Check size={10} className="text-emerald-500" />
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy size={10} />
                              <span>Copy Post</span>
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-[10px] text-slate-300 font-mono whitespace-pre-wrap max-h-32 overflow-y-auto bg-slate-900/60 p-2.5 rounded-lg border border-slate-850 select-all">
                        {(() => {
                          const slide = slides[currentSlideIndex];
                          if (!slide) return '';
                          const eqs = slide.equations.join('\n• ');
                          const bulletPoints = slide.points.map(p => `• ${p}`).join('\n');
                          return `🎓 Digital Tutoring & Visual Learning: ${lessonTitle}\n\n` +
                            `I just synthesized an interactive, voice-narrated micro-lesson on "${chapterTitle}" using Omni AI Studio. Complex science and engineering concepts are instantly converted into stylized blackboard vector animations.\n\n` +
                            `📌 Key Takeaways:\n` +
                            `${bulletPoints}\n\n` +
                            (eqs ? `📐 Essential Formulas:\n• ${eqs}\n\n` : '') +
                            `Omni AI leverages full-spectrum LLMs & speech technology to make learning accessible and engaging for competitive exams. \n\n` +
                            `Try it out: #AIinEducation #LearningCompanion #EdTech #OmniAI`;
                        })()}
                      </p>
                    </div>

                    {/* Storyboard script copy */}
                    <div className="bg-slate-950 p-4 border border-slate-850 rounded-2xl space-y-2 relative">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-200 font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                          Shorts Storyboard Cue Sheet
                        </span>
                        <button
                          onClick={() => {
                            const slide = slides[currentSlideIndex];
                            if (!slide) return;
                            const txt = `[SCENE ${currentSlideIndex + 1}: ${slide.slideTitle}]\n` +
                              `[VISUAL CUE]: Vertical 9:16 Chalkboard displaying ${slide.visualDiagram}\n` +
                              `[AUDIO NARRATION]: "${slide.narrationText}"\n` +
                              `[WATERMARK DISPLAY]: "⚡ GENERATED BY OMNI AI • OMNI-AI.STUDIO"`;
                            navigator.clipboard.writeText(txt);
                            setCopiedTextType('storyboard');
                            setTimeout(() => setCopiedTextType(null), 2000);
                          }}
                          className="flex items-center gap-1 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white text-[9px] font-bold uppercase px-2 py-1 rounded border border-slate-800 transition cursor-pointer"
                        >
                          {copiedTextType === 'storyboard' ? (
                            <>
                              <Check size={10} className="text-emerald-500" />
                              <span>Copied!</span>
                            </>
                          ) : (
                            <>
                              <Copy size={10} />
                              <span>Copy Script</span>
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-[10px] text-slate-300 font-mono whitespace-pre-wrap max-h-24 overflow-y-auto bg-slate-900/60 p-2.5 rounded-lg border border-slate-850 select-all">
                        {(() => {
                          const slide = slides[currentSlideIndex];
                          if (!slide) return '';
                          return `[SCENE ${currentSlideIndex + 1}: ${slide.slideTitle}]\n` +
                            `[VISUAL CUE]: Vertical 9:16 Chalkboard displaying ${slide.visualDiagram}\n` +
                            `[AUDIO NARRATION]: "${slide.narrationText}"\n` +
                            `[WATERMARK DISPLAY]: "⚡ GENERATED BY OMNI AI • OMNI-AI.STUDIO"`;
                        })()}
                      </p>
                    </div>

                    {/* EduTube Publisher Card */}
                    {onPublishToEduTube && (
                      <div className="bg-gradient-to-r from-slate-950 to-indigo-950/80 p-5 border border-indigo-500/20 rounded-2xl space-y-3.5 shadow-xl">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Tv size={16} className="text-red-500 animate-pulse" />
                            <span className="text-[10px] bg-red-950/40 border border-red-500/30 text-red-400 font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                              EduTube Publisher
                            </span>
                          </div>
                          {isPublished && (
                            <span className="text-[9px] text-emerald-400 font-bold bg-emerald-950/50 border border-emerald-500/30 px-2 py-0.5 rounded-md uppercase tracking-wider flex items-center gap-1">
                              <CheckCircle2 size={10} /> Published
                            </span>
                          )}
                        </div>
                        
                        <p className="text-[10px] text-slate-300 leading-relaxed font-medium">
                          Publish this compiled video lesson to the EduTube library! It will be accessible immediately to all students with real-time analytics.
                        </p>

                        <div className="space-y-2.5 pt-1">
                          <div>
                            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">Video Title</label>
                            <input 
                              type="text" 
                              value={publishTitle} 
                              onChange={(e) => setPublishTitle(e.target.value)} 
                              className="w-full bg-slate-900/80 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500" 
                              placeholder="Enter educational video title..."
                              disabled={isPublished || isPublishing}
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">Creator / channel name</label>
                            <input 
                              type="text" 
                              value={publishChannel} 
                              onChange={(e) => setPublishChannel(e.target.value)} 
                              className="w-full bg-slate-900/80 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500" 
                              placeholder="Enter channel name..."
                              disabled={isPublished || isPublishing}
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">Description</label>
                            <textarea 
                              value={publishDesc} 
                              onChange={(e) => setPublishDesc(e.target.value)} 
                              rows={2}
                              className="w-full bg-slate-900/80 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500 resize-none scrollbar-thin" 
                              placeholder="Enter video description..."
                              disabled={isPublished || isPublishing}
                            />
                          </div>
                        </div>

                        <button
                          onClick={handlePublishToEduTube}
                          disabled={isPublished || isPublishing}
                          className={`w-full flex items-center justify-center gap-1.5 font-black text-[10px] uppercase tracking-wider py-2.5 rounded-xl transition shadow-lg cursor-pointer ${
                            isPublished 
                              ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 cursor-default' 
                              : isPublishing
                              ? 'bg-indigo-600/50 text-white cursor-wait'
                              : 'bg-red-600 hover:bg-red-500 text-white active:scale-95'
                          }`}
                        >
                          {isPublished ? (
                            <>
                              <CheckCircle2 size={13} />
                              <span>Successfully Uploaded to EduTube!</span>
                            </>
                          ) : isPublishing ? (
                            <>
                              <Loader2 size={13} className="animate-spin" />
                              <span>Publishing to EduTube Network...</span>
                            </>
                          ) : (
                            <>
                              <Tv size={13} />
                              <span>Publish to EduTube Network</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}

                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 bg-slate-950 border-t border-slate-850 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-500 uppercase">Aspect ratio matches vertical 9:16 guidelines</span>
                <button
                  onClick={() => setExportModalOpen(false)}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs uppercase px-4 py-2 rounded-xl transition cursor-pointer"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
