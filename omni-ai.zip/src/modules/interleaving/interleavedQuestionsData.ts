export interface InterleavedQuestion {
  id: string;
  questionText: string;
  options: string[];
  correctAnswer: string;
  solution: string;
  chapterId: string;
  chapterTitle: string;
  conceptTested: string;
  difficultyLevel: number; // 1 to 5
  discriminationTarget?: string; // topic to differentiate from (e.g. 'Combination')
  isDiscriminationQuestion?: boolean;
}

export const INTERLEAVED_QUESTIONS: Record<string, InterleavedQuestion[]> = {
  Mathematics: [
    {
      id: 'm_q1',
      chapterId: 'relations_functions',
      chapterTitle: '1. Relations and Functions',
      conceptTested: 'Equivalence Relation',
      difficultyLevel: 2,
      questionText: 'Let R be a relation on the set of integers Z defined by x R y if and only if (x - y) is divisible by 5. What type of relation is R?',
      options: [
        'Reflexive and symmetric but not transitive',
        'Reflexive and transitive but not symmetric',
        'Equivalence Relation',
        'Symmetric and transitive but not reflexive'
      ],
      correctAnswer: 'Equivalence Relation',
      solution: 'R is reflexive since x - x = 0 is divisible by 5. It is symmetric because if x - y is divisible by 5, then y - x = -(x - y) is also divisible by 5. It is transitive because if x - y and y - z are divisible by 5, then their sum x - z is divisible by 5. Thus, it is an equivalence relation.',
      discriminationTarget: 'Partial Order Relation'
    },
    {
      id: 'm_q2',
      chapterId: 'relations_functions',
      chapterTitle: '1. Relations and Functions',
      conceptTested: 'One-to-One (Injective) Functions',
      difficultyLevel: 3,
      questionText: 'Let f: R → R be defined as f(x) = 3x³ + 7. Which of the following is true about f?',
      options: [
        'f is injective but not surjective',
        'f is surjective but not injective',
        'f is bijective (both injective and surjective)',
        'f is neither injective nor surjective'
      ],
      correctAnswer: 'f is bijective (both injective and surjective)',
      solution: 'For injectivity: f(a) = f(b) ⇒ 3a³ + 7 = 3b³ + 7 ⇒ a³ = b³ ⇒ a = b (since we are in R). For surjectivity: for any y ∈ R, we can solve y = 3x³ + 7 for x = ((y - 7)/3)^(1/3), which is a real number. Thus f is bijective.',
      discriminationTarget: 'Many-to-One Functions'
    },
    {
      id: 'm_q3',
      chapterId: 'inverse_trig',
      chapterTitle: '2. Inverse Trigonometric Functions',
      conceptTested: 'Principal Value Branch',
      difficultyLevel: 2,
      questionText: 'Find the principal value of cos⁻¹(-1/2).',
      options: [
        '-π/3',
        'π/3',
        '2π/3',
        '5π/6'
      ],
      correctAnswer: '2π/3',
      solution: 'The principal value branch of cos⁻¹(x) is [0, π]. Since cos(2π/3) = cos(π - π/3) = -cos(π/3) = -1/2, the principal value is 2π/3.',
      discriminationTarget: 'General values outside [0, π]'
    },
    {
      id: 'm_q4',
      chapterId: 'inverse_trig',
      chapterTitle: '2. Inverse Trigonometric Functions',
      conceptTested: 'Domain of Inverse Trig Functions',
      difficultyLevel: 3,
      questionText: 'What is the domain of the function f(x) = sin⁻¹(2x - 3)?',
      options: [
        '[-1, 1]',
        '[1, 2]',
        '[0, 3]',
        '[-2, 2]'
      ],
      correctAnswer: '[1, 2]',
      solution: 'The domain of sin⁻¹(u) is -1 ≤ u ≤ 1. So, -1 ≤ 2x - 3 ≤ 1 ⇒ 2 ≤ 2x ≤ 4 ⇒ 1 ≤ x ≤ 2. The domain is [1, 2].',
      discriminationTarget: 'Range of Inverse Trig Functions'
    },
    {
      id: 'm_q5',
      chapterId: 'matrices',
      chapterTitle: '3. Matrices',
      conceptTested: 'Symmetric Matrices',
      difficultyLevel: 2,
      questionText: 'If A is a square matrix, then A + Aᵀ is always:',
      options: [
        'Skew-symmetric matrix',
        'Symmetric matrix',
        'Diagonal matrix',
        'Identity matrix'
      ],
      correctAnswer: 'Symmetric matrix',
      solution: 'Let B = A + Aᵀ. Then Bᵀ = (A + Aᵀ)ᵀ = Aᵀ + (Aᵀ)ᵀ = Aᵀ + A = A + Aᵀ = B. Since Bᵀ = B, it is a symmetric matrix.',
      discriminationTarget: 'Skew-Symmetric Matrices'
    },
    {
      id: 'm_q6',
      chapterId: 'matrices',
      chapterTitle: '3. Matrices',
      conceptTested: 'Skew-Symmetric Matrices',
      difficultyLevel: 3,
      questionText: 'If A is a skew-symmetric matrix of order 3, what is the value of its determinant det(A)?',
      options: [
        '1',
        '-1',
        '0',
        'Cannot be determined'
      ],
      correctAnswer: '0',
      solution: 'For any skew-symmetric matrix A of odd order n, det(A) = det(-Aᵀ) = (-1)ⁿ det(Aᵀ) = -det(A). Therefore, 2*det(A) = 0 ⇒ det(A) = 0.',
      discriminationTarget: 'Symmetric Matrices Determinants'
    },
    {
      id: 'm_q7',
      chapterId: 'determinants',
      chapterTitle: '4. Determinants',
      conceptTested: 'Properties of Determinants',
      difficultyLevel: 3,
      questionText: 'If A is a square matrix of order 3 and |A| = 5, then find the value of |3A|.',
      options: [
        '15',
        '45',
        '135',
        '27'
      ],
      correctAnswer: '135',
      solution: 'For any square matrix A of order n, |k A| = kⁿ |A|. Here, order n = 3 and k = 3, so |3A| = 3³ * |A| = 27 * 5 = 135.',
      discriminationTarget: 'Matrix multiplication scalar rule'
    },
    {
      id: 'm_q8',
      chapterId: 'continuity_differentiability',
      chapterTitle: '5. Continuity and Differentiability',
      conceptTested: 'Chain Rule Differentiation',
      difficultyLevel: 2,
      questionText: 'Find the derivative of f(x) = log(sin(x)) with respect to x.',
      options: [
        'tan(x)',
        'cot(x)',
        '1/sin(x)',
        '-cot(x)'
      ],
      correctAnswer: 'cot(x)',
      solution: 'Using Chain Rule: d/dx [log(sin(x))] = (1 / sin(x)) * d/dx[sin(x)] = (1 / sin(x)) * cos(x) = cot(x).',
      discriminationTarget: 'Quotient Rule Differentiation'
    },
    {
      id: 'm_q9',
      chapterId: 'continuity_differentiability',
      chapterTitle: '5. Continuity and Differentiability',
      conceptTested: 'Logarithmic Differentiation',
      difficultyLevel: 4,
      questionText: 'Find the derivative of y = x^x with respect to x.',
      options: [
        'x * x^(x-1)',
        'x^x * log(x)',
        'x^x * (1 + log(x))',
        'x^x * (1 - log(x))'
      ],
      correctAnswer: 'x^x * (1 + log(x))',
      solution: 'Take natural log on both sides: log(y) = x * log(x). Differentiating with respect to x: (1/y)(dy/dx) = log(x) + x * (1/x) = log(x) + 1. Thus, dy/dx = y * (1 + log(x)) = x^x * (1 + log(x)).',
      discriminationTarget: 'Power Rule Differentiation'
    },
    {
      id: 'm_q10',
      chapterId: 'applications_derivatives',
      chapterTitle: '6. Applications of Derivatives',
      conceptTested: 'Increasing and Decreasing Functions',
      difficultyLevel: 3,
      questionText: 'The interval in which the function f(x) = 2x² - 3x is strictly increasing is:',
      options: [
        '(-∞, 3/4)',
        '(3/4, ∞)',
        '(-∞, -3/4)',
        '(-3/4, ∞)'
      ],
      correctAnswer: '(3/4, ∞)',
      solution: "f'(x) = 4x - 3. For strictly increasing, f'(x) > 0 ⇒ 4x - 3 > 0 ⇒ x > 3/4. So the interval is (3/4, ∞).",
      discriminationTarget: 'Strictly Decreasing Intervals'
    },
    {
      id: 'm_q11',
      chapterId: 'integrals',
      chapterTitle: '7. Integrals',
      conceptTested: 'Integration by Substitution',
      difficultyLevel: 3,
      questionText: 'Evaluate the indefinite integral: ∫ (x * e^(x²)) dx.',
      options: [
        'e^(x²) + C',
        '(1/2) * e^(x²) + C',
        '2 * e^(x²) + C',
        'x² * e^(x²) + C'
      ],
      correctAnswer: '(1/2) * e^(x²) + C',
      solution: 'Put t = x², then dt = 2x dx ⇒ x dx = dt/2. The integral becomes ∫ e^t * (dt/2) = (1/2) * e^t + C = (1/2) * e^(x²) + C.',
      discriminationTarget: 'Integration by Parts'
    },
    {
      id: 'm_q12',
      chapterId: 'integrals',
      chapterTitle: '7. Integrals',
      conceptTested: 'Integration by Parts',
      difficultyLevel: 4,
      questionText: 'Evaluate the indefinite integral: ∫ x * log(x) dx.',
      options: [
        '(x²/2) * log(x) - x²/4 + C',
        '(x²/2) * log(x) + x²/4 + C',
        'x² * log(x) - x² + C',
        '(x/2) * log(x) - x/2 + C'
      ],
      correctAnswer: '(x²/2) * log(x) - x²/4 + C',
      solution: 'Using ILATE rule, let u = log(x) (first function) and v = x (second function). ∫ u v dx = u ∫ v dx - ∫ [u\' ∫ v dx] dx = log(x) * (x²/2) - ∫ (1/x) * (x²/2) dx = (x²/2) * log(x) - (1/2) ∫ x dx = (x²/2) * log(x) - x²/4 + C.',
      discriminationTarget: 'Integration by Substitution'
    },
    {
      id: 'm_q13',
      chapterId: 'applications_integrals',
      chapterTitle: '8. Applications of Integrals',
      conceptTested: 'Area Under Curve',
      difficultyLevel: 3,
      questionText: 'Find the area of the region bounded by the curve y = x², the x-axis, and the ordinates x = 1 and x = 2.',
      options: [
        '7/3 sq units',
        '3 sq units',
        '8/3 sq units',
        '5/3 sq units'
      ],
      correctAnswer: '7/3 sq units',
      solution: 'Area = ∫₁² y dx = ∫₁² x² dx = [x³/3]₁² = 2³/3 - 1³/3 = 8/3 - 1/3 = 7/3 sq units.',
      discriminationTarget: 'Volume of Solid of Revolution'
    },
    {
      id: 'm_q14',
      chapterId: 'differential_equations',
      chapterTitle: '9. Differential Equations',
      conceptTested: 'Integrating Factor',
      difficultyLevel: 4,
      questionText: 'Find the Integrating Factor (I.F.) of the linear differential equation: dy/dx + y * sec(x) = tan(x).',
      options: [
        'sec(x) + tan(x)',
        'sec(x) - tan(x)',
        'log(sec(x) + tan(x))',
        'sec(x) * tan(x)'
      ],
      correctAnswer: 'sec(x) + tan(x)',
      solution: 'Here, P(x) = sec(x). The Integrating Factor is I.F. = e^(∫ P(x) dx) = e^(∫ sec(x) dx) = e^(log(sec(x) + tan(x))) = sec(x) + tan(x).',
      discriminationTarget: 'Separable Differential Equations'
    },
    {
      id: 'm_q15',
      chapterId: 'probability',
      chapterTitle: '13. Probability',
      conceptTested: 'Conditional Probability',
      difficultyLevel: 3,
      questionText: 'If P(A) = 0.6, P(B) = 0.3, and P(A ∩ B) = 0.2, find P(A|B).',
      options: [
        '2/3',
        '1/3',
        '1/2',
        '3/4'
      ],
      correctAnswer: '2/3',
      solution: 'Using the formula: P(A|B) = P(A ∩ B) / P(B) = 0.2 / 0.3 = 2/3.',
      discriminationTarget: 'Independent Events Probability'
    },

    // --- Discrimination Training Questions ---
    {
      id: 'm_disc_1',
      chapterId: 'probability',
      chapterTitle: '13. Probability / Permutations',
      conceptTested: 'Permutation vs Combination',
      difficultyLevel: 2,
      isDiscriminationQuestion: true,
      questionText: 'Suppose you are choosing 3 students from a class of 10 to form a leadership committee containing a President, Vice President, and Secretary. To solve the number of possible committees, which combinatorial concept should be used?',
      options: [
        'Combination (order of choice does NOT matter)',
        'Permutation (order of choice matters)',
        'Binomial Distribution',
        'Bayes\' Theorem'
      ],
      correctAnswer: 'Permutation (order of choice matters)',
      solution: 'Since the committee has specific roles (President, VP, Secretary), selecting (Alice, Bob, Charlie) is different from selecting (Bob, Alice, Charlie) because who gets which role changes. Thus, order matters, requiring Permutations (10P3). If it were just a generic 3-person team, order would not matter, requiring Combinations (10C3).',
      discriminationTarget: 'Combination (order of choice does NOT matter)'
    },
    {
      id: 'm_disc_2',
      chapterId: 'probability',
      chapterTitle: '13. Probability / Combinations',
      conceptTested: 'Permutation vs Combination',
      difficultyLevel: 2,
      isDiscriminationQuestion: true,
      questionText: 'A baker wants to pick 4 distinct toppings out of 9 available ingredients to make a custom pizza. To calculate how many different pizzas can be made, which concept applies?',
      options: [
        'Permutation (order of choice matters)',
        'Combination (order of choice does NOT matter)',
        'Multiplication Principle of Independent Trials',
        'Venn Diagram Union Rule'
      ],
      correctAnswer: 'Combination (order of choice does NOT matter)',
      solution: 'Putting pepperoni, olives, mushrooms, and onions on a pizza results in the exact same pizza regardless of the order they are sprinkled. Thus, order of selection does not matter, and we use Combinations (9C4).',
      discriminationTarget: 'Permutation (order of choice matters)'
    },
    {
      id: 'm_disc_3',
      chapterId: 'integrals',
      chapterTitle: '7. Integrals',
      conceptTested: 'Definite vs Indefinite Integrals',
      difficultyLevel: 1,
      isDiscriminationQuestion: true,
      questionText: 'A mathematics problem asks you to calculate the area under the curve y = sin(x) from x = 0 to x = π. Will the mathematical result of this operation be a function or a single real number?',
      options: [
        'A family of functions containing an arbitrary constant C (Indefinite)',
        'A single real number representing the accumulated area (Definite)',
        'A differential equation representing a slope field',
        'An imaginary vector value'
      ],
      correctAnswer: 'A single real number representing the accumulated area (Definite)',
      solution: 'A definite integral with real bounds [a, b] always evaluates to a single numeric value (e.g. 2 for ∫₀^π sin(x) dx). An indefinite integral computes the general antiderivative, which is a family of functions with "+ C".',
      discriminationTarget: 'A family of functions containing an arbitrary constant C (Indefinite)'
    }
  ],

  Physics: [
    {
      id: 'p_q1',
      chapterId: 'electric_charges_fields',
      chapterTitle: '1. Electric Charges and Fields',
      conceptTested: "Coulomb's Law",
      difficultyLevel: 2,
      questionText: 'Two point charges q₁ and q₂ are separated by a distance r in a vacuum. If the distance between them is doubled, what happens to the electrostatic force F between them?',
      options: [
        'F is doubled (2F)',
        'F is halved (F/2)',
        'F becomes one-fourth (F/4)',
        'F becomes four times (4F)'
      ],
      correctAnswer: 'F becomes one-fourth (F/4)',
      solution: "According to Coulomb's Law, the electrostatic force F is inversely proportional to the square of the distance: F ∝ 1/r². If distance r is doubled to 2r, the force becomes F' ∝ 1/(2r)² = 1/(4r²), which is F/4."
    },
    {
      id: 'p_q2',
      chapterId: 'electrostatic_potential_capacitance',
      chapterTitle: '2. Electrostatic Potential and Capacitance',
      conceptTested: 'Parallel Plate Capacitor',
      difficultyLevel: 3,
      questionText: 'The distance between the plates of a charged parallel plate capacitor connected to a battery is doubled. What happens to the energy stored in the capacitor?',
      options: [
        'It is doubled',
        'It is halved',
        'It becomes four times',
        'It remains unchanged'
      ],
      correctAnswer: 'It is halved',
      solution: 'When the capacitor remains connected to a battery, its potential V remains constant. The capacitance is C = ε₀A/d. If distance d is doubled, C becomes C/2. The stored energy is U = (1/2) * C * V². Since V is constant and C is halved, the energy U is halved.',
      discriminationTarget: 'Capacitor disconnected from battery'
    },
    {
      id: 'p_q3',
      chapterId: 'electrostatic_potential_capacitance',
      chapterTitle: '2. Electrostatic Potential and Capacitance',
      conceptTested: 'Equipotential Surfaces',
      difficultyLevel: 2,
      questionText: 'What is the amount of work done in moving a test charge q over an equipotential surface of potential V between two points separated by distance r?',
      options: [
        'q * V',
        'q / V',
        'Zero',
        'V * r'
      ],
      correctAnswer: 'Zero',
      solution: 'Work done W = q * ΔV. On an equipotential surface, the potential is the same at all points, so ΔV = 0. Therefore, the work done is zero.',
      discriminationTarget: 'Non-equipotential surface work'
    },
    {
      id: 'p_q4',
      chapterId: 'current_electricity',
      chapterTitle: '3. Current Electricity',
      conceptTested: "Ohm's Law Temperature Dependency",
      difficultyLevel: 3,
      questionText: 'For a metallic conductor, how does the resistance change as the temperature increases?',
      options: [
        'Resistance decreases',
        'Resistance increases',
        'Resistance remains constant',
        'Resistance first increases then decreases'
      ],
      correctAnswer: 'Resistance increases',
      solution: 'In a metal, as temperature increases, the thermal vibration of lattice ions increases, causing more frequent collisions of free electrons. This decreases the relaxation time τ. Since resistance R ∝ 1/τ, resistance increases.',
      discriminationTarget: 'Semiconductor temperature dependency'
    },
    {
      id: 'p_q5',
      chapterId: 'moving_charges_magnetism',
      chapterTitle: '4. Moving Charges and Magnetism',
      conceptTested: 'Lorentz Force Direction',
      difficultyLevel: 3,
      questionText: 'An electron is moving along the positive x-axis in a region with a magnetic field directed along the positive y-axis. What is the direction of the magnetic force on the electron?',
      options: [
        'Positive z-axis',
        'Negative z-axis',
        'Positive y-axis',
        'Negative y-axis'
      ],
      correctAnswer: 'Negative z-axis',
      solution: 'The magnetic force is F = q(v × B). Here, v is along +i, B is along +j, and q = -e (negative charge of electron). v × B = i × j = k. Since q is negative, F = -e * k = -k. The force is along the negative z-axis.',
      discriminationTarget: 'Proton moving in magnetic field'
    },

    // --- Discrimination Training Questions ---
    {
      id: 'p_disc_1',
      chapterId: 'wave_optics',
      chapterTitle: '10. Wave Optics',
      conceptTested: 'Interference vs Diffraction',
      difficultyLevel: 3,
      isDiscriminationQuestion: true,
      questionText: 'An optical experiment displays a fringe pattern on a screen. All the bright fringes are found to have the exact same intensity and equal width. What physical phenomenon produced this pattern?',
      options: [
        'Diffraction of light',
        'Interference of light',
        'Polarization of light',
        'Refraction of light'
      ],
      correctAnswer: 'Interference of light',
      solution: 'In Interference (like Young\'s Double Slit), all bright fringes have equal intensity and equal width. In contrast, in Diffraction (Single Slit), there is a broad, highly intense central maximum, and the secondary maxima decrease rapidly in intensity and width as you move outward.',
      discriminationTarget: 'Diffraction of light'
    },
    {
      id: 'p_disc_2',
      chapterId: 'electrostatic_potential_capacitance',
      chapterTitle: '2. Electrostatic Potential and Capacitance',
      conceptTested: 'Battery Connected vs Disconnected',
      difficultyLevel: 4,
      isDiscriminationQuestion: true,
      questionText: 'A parallel-plate capacitor is charged, and then the charging battery is disconnected. If we now double the plate separation, what happens to the electric field between the plates?',
      options: [
        'The electric field is halved',
        'The electric field is doubled',
        'The electric field remains unchanged',
        'The electric field becomes four times'
      ],
      correctAnswer: 'The electric field remains unchanged',
      solution: 'Since the battery is disconnected, the charge Q on the plates remains constant. The electric field E = Q / (ε₀A). Because neither Q, ε₀, nor A depends on the plate separation d, the electric field remains unchanged. (If the battery remained connected, V would be constant, so E = V/d would be halved). This is a critical distinction in learning physics!',
      discriminationTarget: 'Battery remains connected when plate separation changes'
    }
  ]
};
