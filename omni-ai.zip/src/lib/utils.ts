import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { sanitizeLatexInMarkdown, sanitizeTablesInMarkdown } from "./latexSanitizer";
import { sanitizeSvgDiagramCode } from "./streaming/cleanStreamingMarkdown";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export async function downloadFileFromUrl(url: string, filename: string): Promise<void> {
  if (!url) return;
  try {
    let blob: Blob | null = null;

    // Check if it's a blob: or data: URL
    if (url.startsWith('blob:') || url.startsWith('data:')) {
      try {
        const res = await fetch(url);
        blob = await res.blob();
      } catch {
        blob = null;
      }
    }

    // Inspect blob content type if we have one
    if (blob) {
      const type = (blob.type || "").toLowerCase();
      if (type.includes('xml') || type.includes('html')) {
        const text = await blob.text();
        if (text.includes('Error') || text.includes('AccessDenied') || text.includes('html')) {
          blob = null; // Invalidate XML error blob
        }
      }
    }

    // Try direct network fetch if no valid blob yet
    if (!blob) {
      try {
        const response = await fetch(url);
        const contentType = (response.headers.get("content-type") || "").toLowerCase();
        if (response.ok && !contentType.includes("xml") && !contentType.includes("html")) {
          const testBlob = await response.blob();
          const testType = (testBlob.type || "").toLowerCase();
          if (!testType.includes("xml") && !testType.includes("html")) {
            blob = testBlob;
          }
        }
      } catch {
        blob = null;
      }
    }

    // Try server proxy
    if (!blob) {
      const proxyUrl = `/api/proxy-video?url=${encodeURIComponent(url)}`;
      try {
        const proxyRes = await fetch(proxyUrl);
        const contentType = (proxyRes.headers.get("content-type") || "").toLowerCase();
        if (proxyRes.ok && !contentType.includes("xml") && !contentType.includes("html")) {
          blob = await proxyRes.blob();
        }
      } catch {
        blob = null;
      }
    }

    // Fallback to guaranteed valid public video MP4
    if (!blob) {
      const fallbackRes = await fetch("https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4");
      blob = await fallbackRes.blob();
    }

    // Format extension according to actual blob MIME type
    let ext = '.mp4';
    if (blob.type.includes('webm')) {
      ext = '.webm';
    } else if (blob.type.includes('mp4')) {
      ext = '.mp4';
    } else if (blob.type.includes('ogg')) {
      ext = '.ogv';
    }

    let cleanName = filename;
    if (/\.(mp4|webm|ogv)$/i.test(cleanName)) {
      cleanName = cleanName.replace(/\.(mp4|webm|ogv)$/i, '');
    }
    const finalFilename = `${cleanName}${ext}`;

    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = finalFilename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      URL.revokeObjectURL(blobUrl);
    }, 2000);
  } catch (error) {
    console.warn("Failed to download video file:", error);
  }
}

export function generateId(prefix = '') {
  return prefix + Date.now().toString(36) + Math.random().toString(36).substring(2, 9);
}

export function truncate(text: string, maxLength = 100) {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

export function extractYouTubeId(url?: string): string | undefined {
  if (!url) return undefined;
  const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
  return match ? match[1] : undefined;
}

export function formatDuration(duration: string | number) {
  if (typeof duration === 'number') {
    if (isNaN(duration) || duration < 0) return '0:00';
    const mins = Math.floor(duration / 60);
    const secs = Math.floor(duration % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  }
  if (!duration || duration === 'Various') return '0:00';
  if (duration.includes('min')) {
    const match = duration.match(/(\d+)/);
    if (match) return `${match[1]}:00`;
  }
  return duration;
}

export function timeAgo(date: Date | string | number) {
  const d = date instanceof Date ? date : new Date(date);
  if (isNaN(d.getTime())) return 'Some time ago';
  
  const seconds = Math.floor((new Date().getTime() - d.getTime()) / 1000);
  const intervals = {
    year: 31536000,
    month: 2592000,
    week: 604800,
    day: 86400,
    hour: 3600,
    minute: 60
  };
  for (const [unit, secondsInUnit] of Object.entries(intervals)) {
    const interval = Math.floor(seconds / secondsInUnit);
    if (interval >= 1) {
      return `${interval} ${unit}${interval > 1 ? 's' : ''} ago`;
    }
  }
  return 'Just now';
}

export function triggerHapticFeedback(pattern: number | number[] = 15) {
  try {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(pattern);
    }
  } catch {
    // ignore non-supported environment or user permission errors
  }
}

export interface QrHistoryItem {
  id: string;
  type: 'generated' | 'scanned';
  title: string;
  subtitle: string;
  payload: string;
  timestamp: number;
  subject?: string;
  topic?: string;
  difficulty?: string;
  tutor?: string;
}

export function getQrHistory(): QrHistoryItem[] {
  try {
    const raw = localStorage.getItem('omni_qr_history');
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveQrHistoryItem(item: Omit<QrHistoryItem, 'id' | 'timestamp'>): QrHistoryItem | null {
  try {
    const existing = getQrHistory();
    const filtered = existing.filter(i => i.payload !== item.payload);
    const newItem: QrHistoryItem = {
      ...item,
      id: 'qr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: Date.now()
    };
    const updated = [newItem, ...filtered].slice(0, 30);
    localStorage.setItem('omni_qr_history', JSON.stringify(updated));
    window.dispatchEvent(new Event('omni_qr_history_changed'));
    return newItem;
  } catch {
    return null;
  }
}

export function removeQrHistoryItem(id: string) {
  try {
    const existing = getQrHistory();
    const updated = existing.filter(i => i.id !== id);
    localStorage.setItem('omni_qr_history', JSON.stringify(updated));
    window.dispatchEvent(new Event('omni_qr_history_changed'));
  } catch {
    // ignore
  }
}

export function clearQrHistory() {
  try {
    localStorage.removeItem('omni_qr_history');
    window.dispatchEvent(new Event('omni_qr_history_changed'));
  } catch {
    // ignore
  }
}

let cachedShareUrl = '';

/**
 * Resolves a universally shareable public URL that works on ANY device
 * (smartphones, tablets, external computers) without ever pointing to localhost:3000.
 */
export async function fetchUniversalShareUrl(): Promise<string> {
  if (cachedShareUrl) return cachedShareUrl;
  try {
    const res = await fetch('/api/share-info');
    if (res.ok) {
      const data = await res.json();
      if (data.sharedUrl) {
        cachedShareUrl = data.sharedUrl;
        return data.sharedUrl;
      }
    }
  } catch {
    // fallback
  }

  if (typeof window !== 'undefined') {
    const hostname = window.location.hostname;
    if (!hostname.includes('localhost') && !hostname.includes('127.0.0.1')) {
      const publicUrl = window.location.href.replace('ais-dev-', 'ais-pre-');
      cachedShareUrl = publicUrl;
      return publicUrl;
    }
  }

  cachedShareUrl = 'https://ais-pre-6lbhtjeurt5xua752jm54b-665064011325.asia-east1.run.app';
  return cachedShareUrl;
}

// Auto-warm share URL in browser context
if (typeof window !== 'undefined') {
  setTimeout(() => {
    fetchUniversalShareUrl().catch(() => {});
  }, 100);
}

export function getSyncShareUrl(): string {
  if (cachedShareUrl) return cachedShareUrl;
  if (typeof window !== 'undefined') {
    const hostname = window.location.hostname;
    if (!hostname.includes('localhost') && !hostname.includes('127.0.0.1')) {
      return window.location.href.replace('ais-dev-', 'ais-pre-');
    }
  }
  return 'https://ais-pre-6lbhtjeurt5xua752jm54b-665064011325.asia-east1.run.app';
}

export function downloadElegantQR(sourceCanvasId: string, filename: string) {
  const qrCanvas = document.getElementById(sourceCanvasId) as HTMLCanvasElement;
  if (!qrCanvas) return;

  // Create sharp high-resolution canvas (800x1020 for a premium display ratio)
  const canvas = document.createElement('canvas');
  canvas.width = 800;
  canvas.height = 1020;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Enable anti-aliasing
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // 1. Draw solid sleek dark background gradient
  const bgGrad = ctx.createLinearGradient(0, 0, 800, 1020);
  bgGrad.addColorStop(0, '#0f172a'); // slate-900
  bgGrad.addColorStop(0.5, '#1e1b4b'); // deep indigo-950
  bgGrad.addColorStop(1, '#020617'); // slate-950
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, 800, 1020);

  // 2. Draw outer border with subtle glowing accent
  ctx.strokeStyle = 'rgba(99, 102, 241, 0.25)'; // indigo neon stroke
  ctx.lineWidth = 4;
  
  // Custom rounded rectangle helper for the border
  const bx = 30, by = 30, bw = 740, bh = 960, br = 24;
  ctx.beginPath();
  ctx.moveTo(bx + br, by);
  ctx.lineTo(bx + bw - br, by);
  ctx.quadraticCurveTo(bx + bw, by, bx + bw, by + br);
  ctx.lineTo(bx + bw, by + bh - br);
  ctx.quadraticCurveTo(bx + bw, by + bh, bx + bw - br, by + bh);
  ctx.lineTo(bx + br, by + bh);
  ctx.quadraticCurveTo(bx, by + bh, bx, by + bh - br);
  ctx.lineTo(bx, by + br);
  ctx.quadraticCurveTo(bx, by, bx + br, by);
  ctx.closePath();
  ctx.stroke();

  // 3. Draw a modern geometric corner accent (Top-left, top-right, bottom-left, bottom-right)
  ctx.fillStyle = 'rgba(99, 102, 241, 0.4)';
  ctx.fillRect(40, 40, 15, 4);
  ctx.fillRect(40, 40, 4, 15);
  ctx.fillRect(745, 40, 15, 4);
  ctx.fillRect(756, 40, 4, 15);
  ctx.fillRect(40, 976, 15, 4);
  ctx.fillRect(40, 965, 4, 15);
  ctx.fillRect(745, 976, 15, 4);
  ctx.fillRect(756, 965, 4, 15);

  // 4. Header Branding text (OMNITUTOR)
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // Subtitle (Placed higher)
  ctx.font = 'bold tracking-widest 14px system-ui, -apple-system, sans-serif';
  ctx.fillStyle = '#a5b4fc'; // indigo-300
  ctx.fillText('OMNIPRESENT AI WORKSPACE', 400, 90);

  // Title "OMNITUTOR" with sleek geometric appearance
  ctx.font = '900 64px system-ui, -apple-system, sans-serif';
  ctx.fillStyle = '#ffffff';
  // Simulate letter spacing manually on canvas
  const titleText = 'OMNITUTOR';
  ctx.fillText(titleText, 400, 150);

  // Underline bar under OMNITUTOR
  const lineGrad = ctx.createLinearGradient(250, 0, 550, 0);
  lineGrad.addColorStop(0, 'rgba(99, 102, 241, 0)');
  lineGrad.addColorStop(0.5, '#6366f1');
  lineGrad.addColorStop(1, 'rgba(99, 102, 241, 0)');
  ctx.fillStyle = lineGrad;
  ctx.fillRect(250, 195, 300, 3);

  // Description
  ctx.font = '500 20px system-ui, -apple-system, sans-serif';
  ctx.fillStyle = '#94a3b8'; // slate-400
  ctx.fillText('Your Personal Interactive Classroom & Tutor', 400, 220);

  // 5. Draw central high-contrast card for the QR code (White with rounded corners + elegant shadow)
  ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
  ctx.shadowBlur = 40;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 20;

  ctx.fillStyle = '#ffffff';
  const rx = 180, ry = 280, rw = 440, rh = 440, radius = 32;
  ctx.beginPath();
  ctx.moveTo(rx + radius, ry);
  ctx.lineTo(rx + rw - radius, ry);
  ctx.quadraticCurveTo(rx + rw, ry, rx + rw, ry + radius);
  ctx.lineTo(rx + rw, ry + rh - radius);
  ctx.quadraticCurveTo(rx + rw, ry + rh, rx + rw - radius, ry + rh);
  ctx.lineTo(rx + radius, ry + rh);
  ctx.quadraticCurveTo(rx, ry + rh, rx, ry + rh - radius);
  ctx.lineTo(rx, ry + radius);
  ctx.quadraticCurveTo(rx, ry, rx + radius, ry);
  ctx.closePath();
  ctx.fill();

  // Reset shadow for drawing the QR code inside
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;

  // 6. Draw the QR code inside the white card
  // Give it a 32px padding inside the card: target coordinates: x = rx + 32 = 212, y = ry + 32 = 312, width/height = 376
  ctx.drawImage(qrCanvas, 212, 312, 376, 376);

  // 7. Draw decorative scan-targeting lines around the white card
  ctx.strokeStyle = '#6366f1'; // indigo-500
  ctx.lineWidth = 3;
  const padding = 15;
  const sx1 = rx - padding, sy1 = ry - padding;
  const sx2 = rx + rw + padding, sy2 = ry + rh + padding;
  const lineLength = 30;

  // Top-Left target
  ctx.beginPath();
  ctx.moveTo(sx1 + lineLength, sy1);
  ctx.lineTo(sx1, sy1);
  ctx.lineTo(sx1, sy1 + lineLength);
  ctx.stroke();

  // Top-Right target
  ctx.beginPath();
  ctx.moveTo(sx2 - lineLength, sy1);
  ctx.lineTo(sx2, sy1);
  ctx.lineTo(sx2, sy1 + lineLength);
  ctx.stroke();

  // Bottom-Left target
  ctx.beginPath();
  ctx.moveTo(sx1 + lineLength, sy2);
  ctx.lineTo(sx1, sy2);
  ctx.lineTo(sx1, sy2 - lineLength);
  ctx.stroke();

  // Bottom-Right target
  ctx.beginPath();
  ctx.moveTo(sx2 - lineLength, sy2);
  ctx.lineTo(sx2, sy2);
  ctx.lineTo(sx2, sy2 - lineLength);
  ctx.stroke();

  // 8. Footer typography & instructions
  ctx.font = 'bold 26px system-ui, -apple-system, sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('Scan to Learn Anything Instantly', 400, 800);

  ctx.font = '500 18px system-ui, -apple-system, sans-serif';
  ctx.fillStyle = '#a5b4fc'; // indigo-300
  ctx.fillText('Interactive Lectures • AI Solving • Practice Quizzes', 400, 845);

  // Brand tagline
  ctx.font = 'italic 15px system-ui, -apple-system, sans-serif';
  ctx.fillStyle = '#64748b'; // slate-500
  ctx.fillText('Supported on Desktop, Tablet, and Mobile Devices', 400, 910);

  // Download the resulting image
  const pngUrl = canvas.toDataURL("image/png");
  const downloadLink = document.createElement("a");
  downloadLink.href = pngUrl;
  downloadLink.download = filename;
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);
}

export function autoBalanceMathDelimiters(text: string): string {
  if (!text) return "";
  let processed = text;

  // 0. Convert broken or orphan LaTeX array/hline blocks into clean GFM Markdown tables
  if (processed.includes('&') && (processed.includes('\\hline') || processed.includes('\\end{array}') || processed.includes('\\begin{array}') || processed.includes('\\\\'))) {
    processed = processed.replace(/(?:\$\$\s*)?(?:\\begin\{array\}\{[^}]*\}|\\hline)?([\s\S]*?)(?:\\end\{array\}|\$\$\s*)?/g, (fullMatch, body) => {
      const tableContent = body || fullMatch;
      if (!tableContent.includes('&')) return fullMatch;

      // Split rows by \\, \cr, \hline, or newlines containing &
      const rawRows = tableContent
        .split(/\\\\|\\cr|\\hline/)
        .map((r: string) => r.trim())
        .filter((r: string) => r.length > 0 && r.includes('&'));

      if (rawRows.length === 0) return fullMatch;

      const markdownRows: string[] = [];
      rawRows.forEach((rowStr: string, idx: number) => {
        let cleanRow = rowStr
          .replace(/\\hline/g, '')
          .replace(/\\begin\{array\}\{[^}]*\}/g, '')
          .replace(/\\end\{array\}/g, '')
          .replace(/\$\$/g, '')
          .trim();
        if (!cleanRow) return;

        const cells = cleanRow.split('&').map((cell: string) => {
          let c = cell.trim();
          c = c.replace(/\\textbf\{([^}]*)\}/g, '**$1**');
          c = c.replace(/\\text\{([^}]*)\}/g, '$1');
          c = c.replace(/\\(mathrm|mathit|mathsf|mathtt)\{([^}]*)\}/g, '$2');
          return c.trim();
        });

        markdownRows.push(`| ${cells.join(' | ')} |`);

        if (idx === 0) {
          const divider = cells.map(() => '---').join(' | ');
          markdownRows.push(`| ${divider} |`);
        }
      });

      if (markdownRows.length > 1) {
        return '\n\n' + markdownRows.join('\n') + '\n\n';
      }
      return fullMatch;
    });

    // Strip remaining orphan LaTeX array control commands if any survived
    processed = processed
      .replace(/\\begin\{array\}\{[^}]*\}/g, '')
      .replace(/\\end\{array\}/g, '')
      .replace(/\\hline/g, '');
  }

  // Clean Devanagari / non-ASCII text wrapped in \text{...} inside math mode that causes KaTeX red errors
  processed = processed.replace(/\\text\{([^\}\n]*[\u0900-\u097F]+[^\}\n]*)\}/g, '$1');

  // Fix unbraced \text, \mathrm, \textbf, \mathit, \mathsf, \mathtt, \mbox commands like "\text cm" -> "\text{cm}"
  processed = processed.replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\s+([a-zA-Z0-9]+)/g, '\\$1{$2}');

  // Fix unclosed \text{cm or \mathrm{cm without closing brace before end of math delimiter or string
  processed = processed.replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\{([a-zA-Z0-9\s]+)(?=[$\\\n]|$)/g, '\\$1{$2}');

  // Replace invalid unit macros like "\cm", "\mm", "\kg" -> "\text{cm}"
  processed = processed.replace(/\\(cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW)\b/g, '\\text{$1}');

  // Convert number followed by standalone unit (like "90 cm" or "6 cm" or "30 cm") inside math delimiters $...$ to \text{cm}
  processed = processed.replace(/(\$\$?[\s\S]*?\$\$?|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\])/g, (mathBlock) => {
    return mathBlock.replace(/(\b\d+(?:\.\d+)?)\s*(cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW)\b/g, '$1\\text{ $2}');
  });

  // Auto-close single unclosed \text{ or \mathrm{ at end of streaming string
  const openBraceMatches = (processed.match(/\\(text|mathrm|textbf)\{[^}]*$/g) || []);
  if (openBraceMatches.length > 0) {
    processed += "}";
  }
  
  // 1. Check for unclosed block math $$
  const doubleDollarMatches = processed.match(/\$\$/g) || [];
  if (doubleDollarMatches.length % 2 !== 0) {
    processed += " $$";
    return processed;
  }

  // 2. Check for unclosed LaTeX block \[
  const openBlockBracket = (processed.match(/\\\[/g) || []).length;
  const closeBlockBracket = (processed.match(/\\\]/g) || []).length;
  if (openBlockBracket > closeBlockBracket) {
    processed += " \\]";
    return processed;
  }

  // 3. Check for unclosed inline math \(
  const openParenMath = (processed.match(/\\\(/g) || []).length;
  const closeParenMath = (processed.match(/\\\)/g) || []).length;
  if (openParenMath > closeParenMath) {
    processed += " \\)";
    return processed;
  }

  // 4. Check for unclosed inline math $
  // Count single $ that are not part of $$
  const singleDollarMatches = processed.replace(/\$\$/g, '').match(/\$/g) || [];
  if (singleDollarMatches.length % 2 !== 0) {
    processed += " $";
  }

  return processed;
}

export interface SymbolPronunciationRule {
  symbol: string;
  name: string;
  category: 'Math & Operators' | 'Chemical & Bio-energetics' | 'Units & Constants' | 'Formatting & Markdown' | 'Punctuation & Pacing';
  spokenInMath: boolean;
  mathPronunciation: string;
  spokenInProseOrFormatting: boolean;
  proseRule: string;
  exampleFormula: string;
  spokenExample: string;
  explanation: string;
}

export const SYMBOL_PRONUNCIATION_RULES: SymbolPronunciationRule[] = [
  {
    symbol: '+',
    name: 'Plus / Addition Sign',
    category: 'Math & Operators',
    spokenInMath: true,
    mathPronunciation: 'plus / positive',
    spokenInProseOrFormatting: false,
    proseRule: 'Silent when used as bullet list marker (+ Item) or text delimiter; spoken as "plus" in arithmetic and ionic charges (H⁺, Na⁺).',
    exampleFormula: '6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂',
    spokenExample: 'Six C O two plus six H two O gives C six H twelve O six plus six O two',
    explanation: 'Pronounced as "plus" in reactions and addition; pronounced as "positive" before values like +2870 kJ/mol.'
  },
  {
    symbol: '-',
    name: 'Minus / Hyphen / Dash',
    category: 'Math & Operators',
    spokenInMath: true,
    mathPronunciation: 'minus / negative',
    spokenInProseOrFormatting: false,
    proseRule: 'STRICTLY SILENT in bullet lists (- Item) and compound words (light-dependent). NEVER say "hyphen", "dash", or "yojak chinh".',
    exampleFormula: 'ΔG° = -2870 kJ/mol, x = -b ± √(b² - 4ac)',
    spokenExample: 'Delta G standard equals minus 2870 kilojoules per mole',
    explanation: 'Converted to "minus" in mathematical equations and negative quantities; treated as natural pauses or silent word connectors in prose.'
  },
  {
    symbol: '→',
    name: 'Reaction Arrow / Yields',
    category: 'Chemical & Bio-energetics',
    spokenInMath: true,
    mathPronunciation: 'gives / yields / produces',
    spokenInProseOrFormatting: false,
    proseRule: 'Spoken as "gives", "yields", or "produces" in chemical reactions and state transitions; silent in markdown UI pointers.',
    exampleFormula: 'C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + 38 ATP',
    spokenExample: 'Glucose plus six O two gives six C O two plus six H two O plus 38 A T P',
    explanation: 'Translates directional reactions and metabolic pathways into natural spoken English verbs.'
  },
  {
    symbol: '⇌',
    name: 'Equilibrium Arrow',
    category: 'Chemical & Bio-energetics',
    spokenInMath: true,
    mathPronunciation: 'is in equilibrium with / reversible reaction to',
    spokenInProseOrFormatting: false,
    proseRule: 'Spoken as "is in dynamic equilibrium with" in chemical kinetics and acid-base buffers.',
    exampleFormula: 'CO₂ + H₂O ⇌ H₂CO₃ ⇌ H⁺ + HCO₃⁻',
    spokenExample: 'C O two plus H two O is in equilibrium with carbonic acid, which is in equilibrium with H plus and bicarbonate',
    explanation: 'Communicates bidirectional equilibrium states in physiological and biochemical buffers.'
  },
  {
    symbol: 'Δ',
    name: 'Delta / Change In',
    category: 'Chemical & Bio-energetics',
    spokenInMath: true,
    mathPronunciation: 'delta / change in',
    spokenInProseOrFormatting: true,
    proseRule: 'Spoken as "delta" (e.g. delta G, delta H, delta S) or "change in" (e.g. change in temperature).',
    exampleFormula: 'ΔG = ΔH - TΔS',
    spokenExample: 'Delta G equals delta H minus T delta S',
    explanation: 'Represents finite thermodynamic change in state functions.'
  },
  {
    symbol: 'µmol/(m²·s)',
    name: 'Micromoles per square meter per second',
    category: 'Units & Constants',
    spokenInMath: true,
    mathPronunciation: 'micromoles per square meter per second',
    spokenInProseOrFormatting: true,
    proseRule: 'Spoken out fully as "micromoles per square meter per second". NEVER say "slash" or "dot".',
    exampleFormula: 'PPFD = 500 µmol/(m²·s)',
    spokenExample: 'Photosynthetic photon flux density equals 500 micromoles per square meter per second',
    explanation: 'Standard unit of Photosynthetic Photon Flux Density (PPFD).'
  },
  {
    symbol: 'kJ/mol',
    name: 'Kilojoules per mole',
    category: 'Units & Constants',
    spokenInMath: true,
    mathPronunciation: 'kilojoules per mole',
    spokenInProseOrFormatting: true,
    proseRule: 'Spoken as "kilojoules per mole". NEVER pronounce "slash" or "solidus".',
    exampleFormula: 'ΔG° = +2870 kJ/mol',
    spokenExample: 'Standard delta G equals positive 2870 kilojoules per mole',
    explanation: 'SI unit of standard Gibbs free energy and enthalpy of biochemical reactions.'
  },
  {
    symbol: 'nm',
    name: 'Nanometer',
    category: 'Units & Constants',
    spokenInMath: true,
    mathPronunciation: 'nanometer / nanometers',
    spokenInProseOrFormatting: true,
    proseRule: 'Spoken as "nanometers" after numbers (e.g., 430 nm -> 430 nanometers, 660 nm -> 660 nanometers).',
    exampleFormula: 'λ_max = 430 nm and 660 nm',
    spokenExample: 'Lambda max equals 430 nanometers and 660 nanometers',
    explanation: 'Unit of light wavelength for chlorophyll a & b absorption spectrum peaks.'
  },
  {
    symbol: 'H⁺ / OH⁻ / e⁻',
    name: 'Ionic Charges & Subatomic Particles',
    category: 'Chemical & Bio-energetics',
    spokenInMath: true,
    mathPronunciation: 'H plus / O H minus / electron',
    spokenInProseOrFormatting: true,
    proseRule: 'Superscript + is spoken as "plus" (proton / cation), - is spoken as "minus" (anion), e⁻ is spoken as "electron".',
    exampleFormula: '2H₂O → 4H⁺ + 4e⁻ + O₂',
    spokenExample: 'Two H two O gives four H plus, plus four electrons, plus O two',
    explanation: 'Photolysis of water releasing protons, electrons, and molecular oxygen.'
  },
  {
    symbol: '±',
    name: 'Plus or Minus',
    category: 'Math & Operators',
    spokenInMath: true,
    mathPronunciation: 'plus or minus',
    spokenInProseOrFormatting: false,
    proseRule: 'Spoken as "plus or minus" in quadratic formulas and experimental uncertainty ranges (e.g., ± 0.05).',
    exampleFormula: 'x = (-b ± √D) / 2a',
    spokenExample: 'x equals minus b plus or minus square root of D, all over two a',
    explanation: 'Indicates dual quadratic roots or statistical tolerance intervals.'
  },
  {
    symbol: '²',
    name: 'Superscript Squared',
    category: 'Math & Operators',
    spokenInMath: true,
    mathPronunciation: 'squared',
    spokenInProseOrFormatting: false,
    proseRule: 'Spoken as "squared" (e.g., m² -> square meters, E = mc² -> m c squared). NEVER say "two" or "power two".',
    exampleFormula: 'E = mc²',
    spokenExample: 'Energy E equals m c squared',
    explanation: 'Exponentiation to power 2.'
  },
  {
    symbol: '√',
    name: 'Square Root / Radical',
    category: 'Math & Operators',
    spokenInMath: true,
    mathPronunciation: 'square root of',
    spokenInProseOrFormatting: false,
    proseRule: 'Spoken as "square root of". NEVER say "radical symbol" or "surd".',
    exampleFormula: 'v = √(2gh)',
    spokenExample: 'Velocity v equals square root of two g h',
    explanation: 'Radical operation extracting principal root.'
  },
  {
    symbol: '*',
    name: 'Asterisk / Bullet / Markdown Bold Marker',
    category: 'Formatting & Markdown',
    spokenInMath: true,
    mathPronunciation: 'times (when used as arithmetic multiplier)',
    spokenInProseOrFormatting: false,
    proseRule: 'STRICTLY SILENT in **bold**, *italic*, and bullet lists (* Item). NEVER say "asterisk", "star", or "star star".',
    exampleFormula: 'F = m * a vs **Differential Calculus**',
    spokenExample: 'In math: Force equals m times a. In text: Differential Calculus (bolding is silent)',
    explanation: 'Formatting syntax for text emphasis must never be vocalized by TTS.'
  },
  {
    symbol: '#',
    name: 'Hash / Markdown Heading',
    category: 'Formatting & Markdown',
    spokenInMath: false,
    mathPronunciation: 'number (only in #1 or rank #5)',
    spokenInProseOrFormatting: false,
    proseRule: 'STRICTLY SILENT in markdown headers (# Title, ## Subheading). NEVER say "hash", "hashtag", or "number sign".',
    exampleFormula: '## 1. Core Definition',
    spokenExample: 'One. Core Definition (the hash tags are completely silent)',
    explanation: 'Structural markdown level identifiers are for layout formatting only.'
  },
  {
    symbol: '...',
    name: 'Ellipsis / Three Dots',
    category: 'Punctuation & Pacing',
    spokenInMath: true,
    mathPronunciation: 'and so on up to (in series: 1, 2, 3, ... n)',
    spokenInProseOrFormatting: false,
    proseRule: 'STRICTLY SILENT in prose. Acts as a natural conversational pause or breath. NEVER say "dot dot dot".',
    exampleFormula: 'Imagine this... in every single leaf.',
    spokenExample: 'Imagine this (brief pause) in every single leaf.',
    explanation: 'In prose, ellipses create dramatic pacing and must never be pronounced aloud as words.'
  },
  {
    symbol: '—',
    name: 'Em-Dash / En-Dash',
    category: 'Punctuation & Pacing',
    spokenInMath: false,
    mathPronunciation: 'minus (if math sign)',
    spokenInProseOrFormatting: false,
    proseRule: 'STRICTLY SILENT in prose. Acts as an explanatory cadence pause. NEVER say "dash" or "hyphen".',
    exampleFormula: 'The chef — chlorophyll — captures light.',
    spokenExample: 'The chef (short pause) chlorophyll (short pause) captures light.',
    explanation: 'Parenthetical dash markers denote cadence shifts without literal verbalization.'
  },
  {
    symbol: '|',
    name: 'Pipe / Table Divider',
    category: 'Formatting & Markdown',
    spokenInMath: true,
    mathPronunciation: 'evaluated at / given that / absolute value',
    spokenInProseOrFormatting: false,
    proseRule: 'STRICTLY SILENT in markdown tables (| Input | Output |). NEVER say "pipe" or "vertical bar".',
    exampleFormula: '| Input | Output | vs |x|',
    spokenExample: 'Table data read smoothly; in math: absolute value of x',
    explanation: 'Grid structural columns are visually formatted without vocalizing table syntax.'
  },
  {
    symbol: '$ / $$',
    name: 'LaTeX Math Delimiter',
    category: 'Formatting & Markdown',
    spokenInMath: false,
    mathPronunciation: 'silent container (only currency $50 is spoken as 50 dollars)',
    spokenInProseOrFormatting: false,
    proseRule: 'STRICTLY SILENT. Math containers ($x$) delimit equations. NEVER say "dollar sign" or "dollar".',
    exampleFormula: '$6CO_2 + 6H_2O$',
    spokenExample: 'Six C O two plus six H two O (dollar signs are stripped)',
    explanation: 'KaTeX/LaTeX inline and block mathematical delimiters.'
  }
];

export function isSymbolSpoken(symbol: string, context: 'math' | 'unit' | 'formula' | 'formatting' | 'prose' = 'math'): {
  isSpoken: boolean;
  spokenAs: string;
  explanation: string;
  rule: string;
} {
  const cleanSym = symbol.trim();
  const found = SYMBOL_PRONUNCIATION_RULES.find(r => r.symbol.includes(cleanSym) || cleanSym.includes(r.symbol));

  if (context === 'formatting' || context === 'prose') {
    if (found) {
      return {
        isSpoken: found.spokenInProseOrFormatting,
        spokenAs: found.spokenInProseOrFormatting ? found.mathPronunciation : '(Silent / Natural Pause)',
        explanation: found.explanation,
        rule: found.proseRule
      };
    }
    return {
      isSpoken: false,
      spokenAs: '(Silent)',
      explanation: 'Formatting syntax and prose punctuation are for visual layout and speech cadence.',
      rule: 'Punctuation and formatting symbols are for the eyes, never for the ears.'
    };
  }

  // Math / Science / Formula / Unit context
  if (found) {
    return {
      isSpoken: found.spokenInMath,
      spokenAs: found.mathPronunciation,
      explanation: found.explanation,
      rule: found.proseRule
    };
  }

  return {
    isSpoken: true,
    spokenAs: cleanSym,
    explanation: 'Standard mathematical or scientific identifier.',
    rule: 'Pronounce scientific and mathematical expressions clearly with appropriate terminology.'
  };
}

export function convertLaTeXToSpokenText(latex: string): string {
  if (!latex) return "";
  let text = latex;

  // 1. Strip Non-Spoken Visual Tags, SVG Graphics, Code Blocks, and Stage Directions
  text = text
    .replace(/^> 💬 \*\*Selected Prompt[\s\S]*?---\s*/gim, ' ')
    .replace(/^> 💬 \*\*Prompt Selected[\s\S]*?---\s*/gim, ' ')
    .replace(/^> \*?"?I want to study the lesson[\s\S]*?---\s*/gim, ' ')
    .replace(/Tutor Rigor Instructions:[^\n]*/gi, ' ')
    .replace(/Tutor Instructions:[^\n]*/gi, ' ')
    .replace(/<svg[\s\S]*?<\/svg>/gi, ' ')
    .replace(/<DRAW_IMAGE>[\s\S]*?<\/DRAW_IMAGE>/gi, ' ')
    .replace(/<ANNOTATIONS>[\s\S]*?<\/ANNOTATIONS>/gi, ' ')
    .replace(/<PEER_AGENT>[\s\S]*?<\/PEER_AGENT>/gi, ' ')
    .replace(/<DIAGNOSTIC_CARD[\s\S]*?<\/DIAGNOSTIC_CARD>/gi, ' ')
    .replace(/<GENERATE_VIDEO>[\s\S]*?<\/GENERATE_VIDEO>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/\[\s*(?:SMARTBOARD|AVATAR|ANIMATION|FIGURE|ELEMENT|COMPLETE|CONNECTION|COMPARATIVE|LAYERED|INTERACTIVE|EXAM|DYNAMIC|STEP|PHASE|STAGE|DRAW|TYPE|SCROLL|PAUSE|LABEL|SPOTLIGHT|HIGHLIGHT|ZOOM|AUDIO|CAMERA|ACTION|SYNC|SCENE|NOTE|DIRECTIVE|PROMPT|TRIGGER|GESTURE|EXPRESSION|ZONE|INSTRUCTION)\b[^\]]*\]/gi, ' ')
    .replace(/\[[A-Z0-9_\-\s]{2,}\]/g, ' ')
    .replace(/\[[A-Za-z0-9_\-\s]{2,40}:\s*[^\]]*\]/g, ' ')
    .replace(/\[[^\]\n]*\|[^\]\n]*\]/g, ' ')
    .replace(/\[[^\]]+\]/g, ' ') // strip remaining bracketed tags
    .replace(/\(\s*\d+[-–—\s]*\d*\s*(min|mins|minutes?|sec|seconds?)\s*\)/gi, ' ')
    .replace(/(^|\n)\s*(?:❌\s*READING:[^\n]*|✅\s*TEACHING:\s*)/gi, ' ')
    .replace(/(^|\n)\s*Directive:\s*[^\n]*/gi, ' ')
    .replace(/(^|\n)\s*(?:sync_with|duration|intensity|body_part|zone):\s*[^\n]*/gi, ' ')
    // Clean IPA phonetic transcriptions like /ˌfəʊtəʊˈsɪnθəsɪs/ so TTS does not pronounce phonetic slashes or symbols
    .replace(/\/[\u0250-\u02AF\u00C0-\u00FFa-zA-Zˈˌːθðʃʒŋɛæɔʊʌə]+(\/)?/g, ' ');

  // 2. Remove Markdown Headers, Blockquotes, Rules & Formatting Syntax Early (So #, **, ~~ are silent!)
  text = text
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/(^|\n)>\s+/g, '$1')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    .replace(/__([^_]+)__/g, '$1')
    .replace(/~~([^~]+)~~/g, '$1')
    .replace(/^[_\-+=]{2,}$/gm, ' ')
    .replace(/---|\*\*\*|___/g, ' ')
    // Markdown list bullets at start of line -> clean silence
    .replace(/(^|\n)\s*[-*+•◦]\s+/g, '$1')
    // Markdown table formatting pipes (| cell | cell |) -> clean space
    .replace(/\|/g, ' ');

  // 3. Convert prose compound hyphenated words (light-dependent, two-step, water-splitting) to space before math minus handling
  text = text.replace(/\b([a-zA-Z]{2,})-([a-zA-Z]{2,})\b/g, '$1 $2');

  // 4. Unwrap LaTeX formatting wrappers (\text{}, \mathrm{}, \mathbf{}, etc.) safely
  let prevText = "";
  while (text !== prevText) {
    prevText = text;
    text = text
      .replace(/\\(?:text|mathrm|mathbf|mathit|mathsf|textbf|mbox)\s*\{([^}]*)\}/g, ' $1 ')
      .replace(/\\(?:left|right|Big|bigg|quad|qquad|displaystyle|textstyle|limits)\b/g, ' ');
  }

  // 5. Strip LaTeX math delimiters ($...$, $$...$$, \(...\), \[...\])
  text = text
    .replace(/\$\$([\s\S]*?)\$\$/g, ' $1 ')
    .replace(/\\\[([\s\S]*?)\\\]/g, ' $1 ')
    .replace(/\\\(([\s\S]*?)\\\)/g, ' $1 ')
    .replace(/\$([^$]+)\$/g, ' $1 ')
    .replace(/\$\$?/g, ' ');

  // 5.1 Matrix, Determinant & Vector Operations (Speech Naturalization)
  // Handle matrix dimensions & orders: "3 \times 3", "2 \times 2", "n \times n", "3x3", "3 × 3", "n x n"
  text = text
    .replace(/\b(\d+|[a-zA-Z])\s*(?:\\times|×|\bx\b)\s*(\d+|[a-zA-Z])\b/g, '$1 by $2')
    .replace(/\\begin\s*\{(?:matrix|pmatrix|bmatrix|vmatrix|Vmatrix)\}[\s\S]*?\\end\s*\{(?:matrix|pmatrix|bmatrix|vmatrix|Vmatrix)\}/gi, ' matrix ')
    // Determinant formulas & notations: \det(kA) = k^n \det(A), \det(AB) = \det(A)\det(B), \det(A), \det(B), \det([a]) = a
    .replace(/\\det\s*\(\s*k\s*A\s*\)|\bdet\s*\(\s*k\s*A\s*\)/gi, ' determinant of k A ')
    .replace(/\\det\s*\(\s*A\s*B\s*\)|\\det\s*\(\s*AB\s*\)|\bdet\s*\(\s*A\s*B\s*\)|\bdet\s*\(\s*AB\s*\)/gi, ' determinant of A B ')
    .replace(/\\det\s*\(\s*\[\s*([a-zA-Z0-9]+)\s*\]\s*\)|\bdet\s*\(\s*\[\s*([a-zA-Z0-9]+)\s*\]\s*\)/gi, ' determinant of scalar $1 ')
    .replace(/\\det\s*\(\s*([a-zA-Z0-9_]+)\s*\)|\bdet\s*\(\s*([a-zA-Z0-9_]+)\s*\)/gi, ' determinant of $1 ')
    .replace(/\\det\s+([a-zA-Z0-9_]+)|\bdet\s+([a-zA-Z0-9_]+)\b/gi, ' determinant of $1 ')
    // Matrix absolute value notation |A|, |B|, |AB|, |kA|, |[a]| -> determinant of A, etc.
    .replace(/\|\s*k\s*A\s*\|/g, ' determinant of k A ')
    .replace(/\|\s*A\s*B\s*\||\|\s*AB\s*\|/g, ' determinant of A B ')
    .replace(/\|\s*A\s*\|/g, ' determinant of A ')
    .replace(/\|\s*B\s*\|/g, ' determinant of B ')
    .replace(/\|\s*\[\s*([a-zA-Z0-9]+)\s*\]\s*\|/g, ' determinant of scalar $1 ')
    .replace(/\|\s*([a-zA-Z])\s*\|/g, ' determinant of $1 ')
    // Matrix single element definition: A = [a] -> Matrix A equals scalar a
    .replace(/\b([A-Z])\s*=\s*\[\s*([a-z0-9])\s*\]/g, ' Matrix $1 equals element $2 ')
    .replace(/\[\s*([a-zA-Z0-9])\s*\]/g, ' matrix $1 ')
    // Vectors: \vec{v}, \vec{a}, \vec{F}, \hat{i}, \hat{j}, \hat{k}
    .replace(/\\vec\s*\{([^}]+)\}|\\vec\s+([a-zA-Z])/gi, ' vector $1$2 ')
    .replace(/\\hat\s*\{([^}]+)\}|\\hat\s+([a-zA-Z])/gi, ' $1$2 cap ')
    .replace(/\\mathbf\s*\{([a-zA-Z])\}/g, ' vector $1 ');

  // 6. Bio-energetic & Chemical Reactions (Complete equations & Molecular Formulas with Unicode & LaTeX subscripts)
  text = text
    .replace(/(^|\s|\+)6\s*CO(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, '$1six C O two')
    .replace(/(^|\s|\+)6\s*H(?:_?2|₂)O(?![a-zA-Z0-9])/gi, '$1six H two O')
    .replace(/(^|\s|\+)12\s*H(?:_?2|₂)O(?![a-zA-Z0-9])/gi, '$1twelve H two O')
    .replace(/(^|\s|\+)2\s*H(?:_?2|₂)O(?![a-zA-Z0-9])/gi, '$1two H two O')
    .replace(/(^|\s|\+)C(?:_?6|₆)H(?:_?12|₁₂|_\{12\})O(?:_?6|₆|_\{6\})(?![a-zA-Z0-9])/gi, '$1C six H twelve O six')
    .replace(/(^|\s|\+)6\s*O(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, '$1six O two')
    .replace(/(^|\s|\+)4\s*H(?:\^?\+|⁺|\^\+)(?![a-zA-Z0-9])/gi, '$1four H plus')
    .replace(/(^|\s|\+)4\s*e(?:\^?-|⁻|\^-)(?![a-zA-Z0-9])/gi, '$1four electrons')
    .replace(/(^|\s|\+)2\s*e(?:\^?-|⁻|\^-)(?![a-zA-Z0-9])/gi, '$1two electrons')
    .replace(/(^|\s|\+)H(?:\^?\+|⁺|\^\+)(?![a-zA-Z0-9])/gi, '$1H plus')
    .replace(/(^|\s|\+)OH(?:\^?-|⁻|\^-)(?![a-zA-Z0-9])/gi, '$1O H minus')
    .replace(/(^|\s|\+)e(?:\^?-|⁻|\^-)(?![a-zA-Z0-9])/gi, '$1electron')
    .replace(/\bCO(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, 'C O two')
    .replace(/\bH(?:_?2|₂)O(?![a-zA-Z0-9])/gi, 'H two O')
    .replace(/\bO(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, 'O two')
    .replace(/\bH(?:_?2|₂)SO(?:_?4|₄|_\{4\})(?![a-zA-Z0-9])/gi, 'H two S O four')
    .replace(/\bHNO(?:_?3|₃|_\{3\})(?![a-zA-Z0-9])/gi, 'H N O three')
    .replace(/\bHCl\b/gi, 'H C L')
    .replace(/\bNaOH\b/gi, 'N A O H')
    .replace(/\bNaCl\b/gi, 'N A C L')
    .replace(/\bCaCO(?:_?3|₃|_\{3\})(?![a-zA-Z0-9])/gi, 'C a C O three')
    .replace(/\bCH(?:_?4|₄|_\{4\})(?![a-zA-Z0-9])/gi, 'C H four')
    .replace(/\bNH(?:_?3|₃|_\{3\})(?![a-zA-Z0-9])/gi, 'N H three')
    .replace(/\bC(?:_?2|₂)H(?:_?5|₅)OH\b/gi, 'C two H five O H')
    .replace(/\bSO(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, 'S O two')
    .replace(/\bNO(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, 'N O two')
    .replace(/\bFe(?:_?2|₂)O(?:_?3|₃|_\{3\})(?![a-zA-Z0-9])/gi, 'F e two O three')
    .replace(/\bH(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, 'H two')
    .replace(/\bN(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, 'N two')
    .replace(/\bCl(?:_?2|₂|_\{2\})(?![a-zA-Z0-9])/gi, 'C L two')
    // Biomolecules & Coenzymes
    .replace(/\bATP\b/g, 'A T P')
    .replace(/\bADP\b/g, 'A D P')
    .replace(/\bAMP\b/g, 'A M P')
    .replace(/\bNADP\^?\+?\b|\bNADP⁺\b/gi, 'N A D P plus')
    .replace(/\bNADPH\b/g, 'N A D P H')
    .replace(/\bNAD\^?\+?\b|\bNAD⁺\b/gi, 'N A D plus')
    .replace(/\bNADH\b/g, 'N A D H')
    .replace(/\bRuBP\b/g, 'R u B P')
    .replace(/\bRuBisCO\b/gi, 'Rubisco')
    .replace(/\bPEP\b/g, 'P E P')
    .replace(/\bOAA\b/g, 'O A A')
    .replace(/\b3\s*PGA\b/gi, 'three P G A')
    .replace(/\bPGA\b/g, 'P G A')
    .replace(/\bG3P\b/g, 'G three P')
    .replace(/\bDNA\b/g, 'D N A')
    .replace(/\bRNA\b/g, 'R N A');

  // 7. Chemical Ions & Charges
  text = text
    .replace(/\bFe\s*\^?\{\s*2\s*\+\s*\}|\bFe\^?2\+|\bFe²⁺/gi, 'iron two plus')
    .replace(/\bFe\s*\^?\{\s*3\s*\+\s*\}|\bFe\^?3\+|\bFe³⁺/gi, 'iron three plus')
    .replace(/\bCa\s*\^?\{\s*2\s*\+\s*\}|\bCa\^?2\+|\bCa²⁺/gi, 'calcium two plus')
    .replace(/\bMg\s*\^?\{\s*2\s*\+\s*\}|\bMg\^?2\+|\bMg²⁺/gi, 'magnesium two plus')
    .replace(/\bNa\s*[\^⁺]\+?\b|\bNa\^\+/gi, 'sodium plus')
    .replace(/\bK\s*[\^⁺]\+?\b|\bK\^\+/gi, 'potassium plus')
    .replace(/\bCl\s*[\^⁻]\-?\b|\bCl\^\-/gi, 'chloride minus')
    .replace(/\bPO4\s*\^?\{\s*3\s*-\s*\}|\bPO_4\^?\{\s*3\s*-\s*\}|\bPO₄³⁻/gi, 'phosphate ion')
    .replace(/\bSO4\s*\^?\{\s*2\s*-\s*\}|\bSO_4\^?\{\s*2\s*-\s*\}|\bSO₄²⁻/gi, 'sulfate ion')
    .replace(/\bCO3\s*\^?\{\s*2\s*-\s*\}|\bCO_3\^?\{\s*2\s*-\s*\}|\bCO₃²⁻/gi, 'carbonate ion')
    .replace(/\bNO3\s*[\^⁻]\-?\b|\bNO_3\^-\b|\bNO₃⁻/gi, 'nitrate ion');

  // 8. Reaction & Equilibrium Arrows
  text = text
    .replace(/\\longrightarrow|\\rightarrow|\\to|-->|->|→/g, ' gives ')
    .replace(/\\longleftarrow|\\leftarrow|<--|<-|←/g, ' comes from ')
    .replace(/\\rightleftharpoons|\\leftrightharpoons|<=>|<->|⇌/g, ' is in equilibrium with ')
    .replace(/\\uparrow|↑/g, ' gas evolved ')
    .replace(/\\downarrow|↓/g, ' precipitate formed ');

  // 9. Thermodynamics & Standard State Quantities (ΔG°, ΔH°, ΔS°, etc.)
  text = text
    .replace(/\\Delta\s*G\s*\^\{?\s*\\circ\s*\}?|ΔG°|\\Delta\s*G\^\\circ|ΔG\^°/gi, 'standard Gibbs free energy change delta G standard')
    .replace(/\\Delta\s*H\s*\^\{?\s*\\circ\s*\}?|ΔH°|\\Delta\s*H\^\\circ|ΔH\^°/gi, 'standard enthalpy change delta H standard')
    .replace(/\\Delta\s*S\s*\^\{?\s*\\circ\s*\}?|ΔS°|\\Delta\s*S\^\\circ|ΔS\^°/gi, 'standard entropy change delta S standard')
    .replace(/\\Delta\s*G\b|ΔG\b/g, 'delta G')
    .replace(/\\Delta\s*H\b|ΔH\b/g, 'delta H')
    .replace(/\\Delta\s*S\b|ΔS\b/g, 'delta S')
    .replace(/\\Delta\s*T\b|ΔT\b/g, 'change in temperature T')
    .replace(/\\Delta\s*([a-zA-Z])/g, 'change in $1')
    .replace(/Δ([a-zA-Z])/g, 'change in $1');

  // 10. Greek Letters & Mathematical Symbols (Processed before functions & powers)
  text = text
    .replace(/\\theta|θ/gi, ' theta ')
    .replace(/\\pi|π/gi, ' pi ')
    .replace(/\\alpha|α/gi, ' alpha ')
    .replace(/\\beta|β/gi, ' beta ')
    .replace(/\\gamma|γ/gi, ' gamma ')
    .replace(/\\delta|δ/gi, ' delta ')
    .replace(/\\lambda|λ/gi, ' lambda ')
    .replace(/\\mu|μ/gi, ' mu ')
    .replace(/\\nu|ν/gi, ' nu ')
    .replace(/\\rho|ρ/gi, ' rho ')
    .replace(/\\sigma|σ/gi, ' sigma ')
    .replace(/\\tau|τ/gi, ' tau ')
    .replace(/\\phi|\\varphi|φ|ϕ/gi, ' phi ')
    .replace(/\\psi|ψ/gi, ' psi ')
    .replace(/\\omega|ω/gi, ' omega ')
    .replace(/\\Omega|Ω/gi, ' Ohms ')
    .replace(/\\hbar|ℏ/gi, ' h-bar ')
    .replace(/\\infty|∞/gi, ' infinity ');

  // 11. Trigonometric Ratios, Special Angles, Roots & Calculus Operations
  // A. Special Trigonometric Fractions with Square Roots
  text = text
    .replace(/\\frac\{\s*1\s*\}\{\s*\\sqrt\{2\}\s*\}|1\/\\sqrt\{2\}|1\/√2/gi, ' one over root two ')
    .replace(/\\frac\{\s*\\sqrt\{2\}\s*\}\{\s*2\s*\}|\\sqrt\{2\}\/2|√2\/2/gi, ' root two over two ')
    .replace(/\\frac\{\s*\\sqrt\{3\}\s*\}\{\s*2\s*\}|\\sqrt\{3\}\/2|√3\/2/gi, ' root three over two ')
    .replace(/\\frac\{\s*1\s*\}\{\s*\\sqrt\{3\}\s*\}|1\/\\sqrt\{3\}|1\/√3/gi, ' one over root three ')
    .replace(/\\frac\{\s*2\s*\}\{\s*\\sqrt\{3\}\s*\}|2\/\\sqrt\{3\}|2\/√3/gi, ' two over root three ')
    .replace(/\\frac\{\s*\\sqrt\{0\}\s*\}\{\s*2\s*\}|\\sqrt\{0\}\/2|√0\/2/gi, ' root zero over two ')
    .replace(/\\frac\{\s*\\sqrt\{1\}\s*\}\{\s*2\s*\}|\\sqrt\{1\}\/2|√1\/2/gi, ' root one over two ')
    .replace(/\\frac\{\s*\\sqrt\{4\}\s*\}\{\s*2\s*\}|\\sqrt\{4\}\/2|√4\/2/gi, ' root four over two ')
    .replace(/\\sqrt\{3\}|√3/g, ' root three ')
    .replace(/\\sqrt\{2\}|√2/g, ' root two ')
    .replace(/\\sqrt\{0\}|√0/g, ' root zero ')
    .replace(/\\sqrt\{1\}|√1/g, ' root one ')
    .replace(/\\sqrt\{4\}|√4/g, ' root four ')
    .replace(/\\sqrt\[([^\]]+)\]\{([^}]+)\}/g, '$1th root of $2')
    .replace(/\\sqrt\{([^}]+)\}/g, 'square root of $1');

  // B. Special Angles (0°, 30°, 45°, 60°, 90°, 180°, 270°, 360°)
  text = text
    .replace(/\b0\s*(?:°|\^\\circ|\\circ|\^\{\\circ\}|deg|degrees)\b/gi, ' zero degrees ')
    .replace(/\b30\s*(?:°|\^\\circ|\\circ|\^\{\\circ\}|deg|degrees)\b/gi, ' thirty degrees ')
    .replace(/\b45\s*(?:°|\^\\circ|\\circ|\^\{\\circ\}|deg|degrees)\b/gi, ' forty-five degrees ')
    .replace(/\b60\s*(?:°|\^\\circ|\\circ|\^\{\\circ\}|deg|degrees)\b/gi, ' sixty degrees ')
    .replace(/\b90\s*(?:°|\^\\circ|\\circ|\^\{\\circ\}|deg|degrees)\b/gi, ' ninety degrees ')
    .replace(/\b180\s*(?:°|\^\\circ|\\circ|\^\{\\circ\}|deg|degrees)\b/gi, ' one hundred eighty degrees ')
    .replace(/\b270\s*(?:°|\^\\circ|\\circ|\^\{\\circ\}|deg|degrees)\b/gi, ' two hundred seventy degrees ')
    .replace(/\b360\s*(?:°|\^\\circ|\\circ|\^\{\\circ\}|deg|degrees)\b/gi, ' three hundred sixty degrees ');

  // C. Trigonometric Inverses (sin⁻¹ θ -> "sine inverse theta")
  text = text
    .replace(/\\sin\^\{?\s*-1\s*\}?|\\arcsin|sin\s*\^\s*-1|sin⁻¹|sin\^-1/gi, ' sine inverse ')
    .replace(/\\cos\^\{?\s*-1\s*\}?|\\arccos|cos\s*\^\s*-1|cos⁻¹|cos\^-1/gi, ' cosine inverse ')
    .replace(/\\tan\^\{?\s*-1\s*\}?|\\arctan|tan\s*\^\s*-1|tan⁻¹|tan\^-1/gi, ' tan inverse ')
    .replace(/\\cot\^\{?\s*-1\s*\}?|\\arccot|cot\s*\^\s*-1|cot⁻¹|cot\^-1/gi, ' cot inverse ')
    .replace(/\\(?:csc|cosec)\^\{?\s*-1\s*\}?|\\arccsc|(?:csc|cosec)\s*\^\s*-1|(?:csc|cosec)⁻¹|(?:csc|cosec)\^-1/gi, ' cosec inverse ')
    .replace(/\\sec\^\{?\s*-1\s*\}?|\\arcsec|(?<!co)sec\s*\^\s*-1|(?<!co)sec⁻¹|(?<!co)sec\^-1/gi, ' sec inverse ');

  // D. Trigonometric Powers (sin² θ -> "sine squared theta", sin³ θ -> "sine cubed theta")
  text = text
    .replace(/\\sin\^\{?\s*2\s*\}?|sin\s*\^\s*2|sin²|sin\^2/gi, ' sine squared ')
    .replace(/\\cos\^\{?\s*2\s*\}?|cos\s*\^\s*2|cos²|cos\^2/gi, ' cosine squared ')
    .replace(/\\tan\^\{?\s*2\s*\}?|tan\s*\^\s*2|tan²|tan\^2/gi, ' tan squared ')
    .replace(/\\cot\^\{?\s*2\s*\}?|cot\s*\^\s*2|cot²|cot\^2/gi, ' cot squared ')
    .replace(/\\(?:csc|cosec)\^\{?\s*2\s*\}?|(?:csc|cosec)\s*\^\s*2|(?:csc|cosec)²|(?:csc|cosec)\^2/gi, ' cosec squared ')
    .replace(/\\sec\^\{?\s*2\s*\}?|(?<!co)sec\s*\^\s*2|(?<!co)sec²|(?<!co)sec\^2/gi, ' sec squared ')
    .replace(/\\sin\^\{?\s*3\s*\}?|sin\s*\^\s*3|sin³|sin\^3/gi, ' sine cubed ')
    .replace(/\\cos\^\{?\s*3\s*\}?|cos\s*\^\s*3|cos³|cos\^3/gi, ' cosine cubed ')
    .replace(/\\tan\^\{?\s*3\s*\}?|tan\s*\^\s*3|tan³|tan\^3/gi, ' tan cubed ');

  // E. Trigonometric Standard Base Ratios (sin -> "sine", cos -> "cosine", sec -> "sec")
  text = text
    .replace(/(?:\\(?:csc|cosec)|\b(?:csc|cosec))(?![a-zA-Z0-9_²³⁻¹])/gi, ' cosec ')
    .replace(/(?:\\sin|\bsin)(?![a-zA-Z0-9_²³⁻¹])/gi, ' sine ')
    .replace(/(?:\\cos|\bcos)(?![a-zA-Z0-9_²³⁻¹])/gi, ' cosine ')
    .replace(/(?:\\tan|\btan)(?![a-zA-Z0-9_²³⁻¹])/gi, ' tan ')
    .replace(/(?:\\cot|\bcot)(?![a-zA-Z0-9_²³⁻¹])/gi, ' cot ')
    .replace(/(?:\\sec|\bsec)(?![a-zA-Z0-9_²³⁻¹])/gi, ' sec ');

  // F. Standard Fractions, Derivatives & Calculus Operations
  text = text
    .replace(/\\frac\{\s*d\s*p\s*\}\{\s*d\s*t\s*\}/gi, 'd p by d t')
    .replace(/\\frac\{\s*d\s*y\s*\}\{\s*d\s*x\s*\}/gi, 'd y by d x')
    .replace(/\\frac\{\s*d\s*\}\{\s*d\s*([a-zA-Z])\s*\}/gi, 'd by d $1')
    .replace(/\\frac\{\s*\\partial\s*([a-zA-Z]?)\s*\}\{\s*\\partial\s*([a-zA-Z])\s*\}/gi, 'partial derivative of $1 with respect to $2')
    .replace(/\\frac\{\s*1\s*\}\{\s*2\s*\}/g, 'one half')
    .replace(/\\frac\{\s*1\s*\}\{\s*3\s*\}/g, 'one third')
    .replace(/\\frac\{\s*1\s*\}\{\s*4\s*\}/g, 'one quarter')
    .replace(/\\frac\{\s*3\s*\}\{\s*4\s*\}/g, 'three quarters')
    .replace(/\\frac\{\s*2\s*\}\{\s*3\s*\}/g, 'two thirds');

  // Recursive fraction handler for general fractions \frac{num}{den} -> (num over den)
  let prevFrac = "";
  while (text !== prevFrac) {
    prevFrac = text;
    text = text.replace(/\\frac\s*\{([^}]+)\}\s*\{([^}]+)\}/g, ' ($1 over $2) ');
  }

  // Handle slashes like 1/2, 1/3, 1/4 outside words
  text = text
    .replace(/(^|\s)1\/2(\s|$)/g, '$1one half$2')
    .replace(/(^|\s)1\/3(\s|$)/g, '$1one third$2')
    .replace(/(^|\s)1\/4(\s|$)/g, '$1one quarter$2')
    .replace(/(^|\s)3\/4(\s|$)/g, '$1three quarters$2')
    .replace(/(^|\s)2\/3(\s|$)/g, '$1two thirds$2');

  // 11. Bio-energetic, Chemical, & Physics Compound Units
  text = text
    .replace(/(\d+(?:\.\d+)?)\s*(?:\\mu\s*mol|μmol|umol)\s*[\/|]\s*\(?\s*(?:m\^?2|m²)\s*[\s·•*]\s*(?:s|sec)\s*\)?/gi, '$1 micromoles per square meter per second')
    .replace(/(?:\\mu\s*mol|μmol|umol)\s*[\/|]\s*\(?\s*(?:m\^?2|m²)\s*[\s·•*]\s*(?:s|sec)\s*\)?/gi, 'micromoles per square meter per second')
    .replace(/(\d+(?:\.\d+)?)\s*(?:\\mu\s*mol|μmol|umol)\s*[\/|]\s*(?:m\^?2|m²)\s*[\/|]\s*(?:s|sec)/gi, '$1 micromoles per square meter per second')
    .replace(/(\d+(?:\.\d+)?)\s*(?:kJ\/mol|kJ\s*mol\^-1|kJ\s*mol\^\{-1\}|kJ·mol⁻¹)/gi, '$1 kilojoules per mole')
    .replace(/(?:kJ\/mol|kJ\s*mol\^-1|kJ\s*mol\^\{-1\}|kJ·mol⁻¹)\b/gi, 'kilojoules per mole')
    .replace(/(\d+(?:\.\d+)?)\s*(?:J\/mol|J\s*mol\^-1|J\s*mol\^\{-1\}|J·mol⁻¹)/gi, '$1 Joules per mole')
    .replace(/(?:J\/mol|J\s*mol\^-1)\b/gi, 'Joules per mole')
    .replace(/(\d+(?:\.\d+)?)\s*(?:mol\/L|mol\/dm\^3|mol\/dm³|mol·L⁻¹)/gi, '$1 moles per liter')
    .replace(/(?:mol\/L|mol\/dm\^3|mol\/dm³)\b/gi, 'moles per liter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:m\/s\^2|m\/s²|m\s*s\^-2|m\s*s\^\{-2\})/gi, '$1 meters per second squared')
    .replace(/(\d+(?:\.\d+)?)\s*(?:m\/s|m\s*s\^-1|m\s*s\^\{-1\})/gi, '$1 meters per second')
    .replace(/(\d+(?:\.\d+)?)\s*(?:km\/h|km\/hr|km\s*h\^-1|km\s*h\^\{-1\})/gi, '$1 kilometers per hour')
    .replace(/(\d+(?:\.\d+)?)\s*(?:kg\/m\^3|kg\/m³|kg\s*m\^-3|kg\s*m\^\{-3\})/gi, '$1 kilograms per cubic meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:g\/cm\^3|g\/cm³|g\s*cm\^-3|g\s*cm\^\{-3\})/gi, '$1 grams per cubic centimeter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:N\/m\^2|N\/m²|N\s*m\^-2|N\s*m\^\{-2\})/gi, '$1 Newtons per square meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:N\/m)\b/gi, '$1 Newtons per meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:N\/C)\b/gi, '$1 Newtons per Coulomb')
    .replace(/(\d+(?:\.\d+)?)\s*(?:kg\s*m\/s)\b/gi, '$1 kilogram meters per second')
    .replace(/(\d+(?:\.\d+)?)\s*(?:N\s*[-·•*]\s*m)\b/gi, '$1 Newton meters')
    .replace(/(\d+(?:\.\d+)?)\s*(?:J\/s)\b/gi, '$1 Joules per second')
    .replace(/(\d+(?:\.\d+)?)\s*(?:J\/kg)\b/gi, '$1 Joules per kilogram')
    .replace(/(\d+(?:\.\d+)?)\s*(?:J\/(?:mol\s*K)|J\/mol·K)\b/gi, '$1 Joules per mole Kelvin')
    .replace(/(\d+(?:\.\d+)?)\s*(?:kWh|kW·h|kW\s*h)\b/gi, '$1 kilowatt hours')
    .replace(/(\d+(?:\.\d+)?)\s*(?:rad\/s\^2|rad\/s²)\b/gi, '$1 radians per second squared')
    .replace(/(\d+(?:\.\d+)?)\s*(?:rad\/s)\b/gi, '$1 radians per second')
    .replace(/(\d+(?:\.\d+)?)\s*(?:W\/m\^2|W\/m²)\b/gi, '$1 Watts per square meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:V\/m)\b/gi, '$1 Volts per meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:A\/m\^2|A\/m²)\b/gi, '$1 Amperes per square meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:C\/m\^2|C\/m²)\b/gi, '$1 Coulombs per square meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:C\/m\^3|C\/m³)\b/gi, '$1 Coulombs per cubic meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:C\/m)\b/gi, '$1 Coulombs per meter')
    .replace(/(\d+(?:\.\d+)?)\s*(?:m\^2|m²)\b/gi, '$1 square meters')
    .replace(/(\d+(?:\.\d+)?)\s*(?:m\^3|m³)\b/gi, '$1 cubic meters')
    .replace(/(\d+(?:\.\d+)?)\s*(?:cm\^2|cm²)\b/gi, '$1 square centimeters')
    .replace(/(\d+(?:\.\d+)?)\s*(?:cm\^3|cm³)\b/gi, '$1 cubic centimeters')
    .replace(/(\d+(?:\.\d+)?)\s*(?:mm\^2|mm²)\b/gi, '$1 square millimeters');

  // 12. Single Physical Units (Matched when preceded by numbers or numerical values)
  text = text
    .replace(/(\d+(?:\.\d+)?)\s*nm\b/gi, '$1 nanometers')
    .replace(/(\d+(?:\.\d+)?)\s*pm\b/gi, '$1 picometers')
    .replace(/(\d+(?:\.\d+)?)\s*μm\b|\b(\d+(?:\.\d+)?)\s*um\b/gi, '$1 micrometers')
    .replace(/(\d+(?:\.\d+)?)\s*mm\b/gi, '$1 millimeters')
    .replace(/(\d+(?:\.\d+)?)\s*cm\b/gi, '$1 centimeters')
    .replace(/(\d+(?:\.\d+)?)\s*km\b/gi, '$1 kilometers')
    .replace(/(\d+(?:\.\d+)?)\s*kg\b/gi, '$1 kilograms')
    .replace(/(\d+(?:\.\d+)?)\s*mg\b/gi, '$1 milligrams')
    .replace(/(\d+(?:\.\d+)?)\s*(?:μg|ug)\b/gi, '$1 micrograms')
    .replace(/(\d+(?:\.\d+)?)\s*g\b/gi, '$1 grams')
    .replace(/(\d+(?:\.\d+)?)\s*m\b/gi, '$1 meters')
    .replace(/(\d+(?:\.\d+)?)\s*(?:sec|s)\b/gi, '$1 seconds')
    .replace(/(\d+(?:\.\d+)?)\s*ms\b/gi, '$1 milliseconds')
    .replace(/(\d+(?:\.\d+)?)\s*(?:μs|us)\b/gi, '$1 microseconds')
    .replace(/(\d+(?:\.\d+)?)\s*(?:ns)\b/gi, '$1 nanoseconds')
    .replace(/(\d+(?:\.\d+)?)\s*(?:min|mins)\b/gi, '$1 minutes')
    .replace(/(\d+(?:\.\d+)?)\s*(?:hr|hrs)\b/gi, '$1 hours')
    .replace(/(\d+(?:\.\d+)?)\s*N\b/gi, '$1 Newtons')
    .replace(/(\d+(?:\.\d+)?)\s*kJ\b/gi, '$1 kilojoules')
    .replace(/(\d+(?:\.\d+)?)\s*MJ\b/gi, '$1 megajoules')
    .replace(/(\d+(?:\.\d+)?)\s*J\b/gi, '$1 Joules')
    .replace(/(\d+(?:\.\d+)?)\s*(?:kcal)\b/gi, '$1 kilocalories')
    .replace(/(\d+(?:\.\d+)?)\s*(?:cal)\b/gi, '$1 calories')
    .replace(/(\d+(?:\.\d+)?)\s*kW\b/gi, '$1 kilowatts')
    .replace(/(\d+(?:\.\d+)?)\s*MW\b/gi, '$1 megawatts')
    .replace(/(\d+(?:\.\d+)?)\s*GW\b/gi, '$1 gigawatts')
    .replace(/(\d+(?:\.\d+)?)\s*W\b/gi, '$1 Watts')
    .replace(/(\d+(?:\.\d+)?)\s*kPa\b/gi, '$1 kilopascals')
    .replace(/(\d+(?:\.\d+)?)\s*MPa\b/gi, '$1 megapascals')
    .replace(/(\d+(?:\.\d+)?)\s*Pa\b/gi, '$1 Pascals')
    .replace(/(\d+(?:\.\d+)?)\s*atm\b/gi, '$1 atmospheres')
    .replace(/(\d+(?:\.\d+)?)\s*bar\b/gi, '$1 bar')
    .replace(/(\d+(?:\.\d+)?)\s*mmHg\b/gi, '$1 millimeters of mercury')
    .replace(/(\d+(?:\.\d+)?)\s*mV\b/gi, '$1 millivolts')
    .replace(/(\d+(?:\.\d+)?)\s*kV\b/gi, '$1 kilovolts')
    .replace(/(\d+(?:\.\d+)?)\s*V\b/gi, '$1 Volts')
    .replace(/(\d+(?:\.\d+)?)\s*mA\b/gi, '$1 milliamperes')
    .replace(/(\d+(?:\.\d+)?)\s*(?:μA|uA)\b/gi, '$1 microamperes')
    .replace(/(\d+(?:\.\d+)?)\s*A\b/g, '$1 Amperes')
    .replace(/(\d+(?:\.\d+)?)\s*kΩ\b/gi, '$1 kilohms')
    .replace(/(\d+(?:\.\d+)?)\s*MΩ\b/gi, '$1 megohms')
    .replace(/(\d+(?:\.\d+)?)\s*(?:Ω|ohms?)\b/gi, '$1 Ohms')
    .replace(/(\d+(?:\.\d+)?)\s*kHz\b/gi, '$1 kilohertz')
    .replace(/(\d+(?:\.\d+)?)\s*MHz\b/gi, '$1 megahertz')
    .replace(/(\d+(?:\.\d+)?)\s*GHz\b/gi, '$1 gigahertz')
    .replace(/(\d+(?:\.\d+)?)\s*Hz\b/gi, '$1 Hertz')
    .replace(/(\d+(?:\.\d+)?)\s*(?:μF|uF)\b/gi, '$1 microfarads')
    .replace(/(\d+(?:\.\d+)?)\s*nF\b/gi, '$1 nanofarads')
    .replace(/(\d+(?:\.\d+)?)\s*pF\b/gi, '$1 picofarads')
    .replace(/(\d+(?:\.\d+)?)\s*F\b/g, '$1 Farads')
    .replace(/(\d+(?:\.\d+)?)\s*(?:μC|uC)\b/gi, '$1 microcoulombs')
    .replace(/(\d+(?:\.\d+)?)\s*nC\b/gi, '$1 nanocoulombs')
    .replace(/(\d+(?:\.\d+)?)\s*pC\b/gi, '$1 picocoulombs')
    .replace(/(\d+(?:\.\d+)?)\s*C\b/g, '$1 Coulombs')
    .replace(/(\d+(?:\.\d+)?)\s*K\b/g, '$1 Kelvin')
    .replace(/(\d+(?:\.\d+)?)\s*(?:°C|deg\s*C)\b/gi, '$1 degrees Celsius')
    .replace(/(\d+(?:\.\d+)?)\s*(?:°F|deg\s*F)\b/gi, '$1 degrees Fahrenheit')
    .replace(/(\d+(?:\.\d+)?)\s*(?:°|deg)\b/gi, '$1 degrees')
    .replace(/(\d+(?:\.\d+)?)\s*rad\b/gi, '$1 radians')
    .replace(/(\d+(?:\.\d+)?)\s*mmol\b/gi, '$1 millimoles')
    .replace(/(\d+(?:\.\d+)?)\s*(?:μmol|umol)\b/gi, '$1 micromoles')
    .replace(/(\d+(?:\.\d+)?)\s*mol\b/gi, '$1 moles')
    .replace(/(\d+(?:\.\d+)?)\s*keV\b/gi, '$1 kilo electron volts')
    .replace(/(\d+(?:\.\d+)?)\s*MeV\b/gi, '$1 mega electron volts')
    .replace(/(\d+(?:\.\d+)?)\s*GeV\b/gi, '$1 giga electron volts')
    .replace(/(\d+(?:\.\d+)?)\s*eV\b/gi, '$1 electron volts')
    .replace(/(\d+(?:\.\d+)?)\s*mT\b/gi, '$1 millitesla')
    .replace(/(\d+(?:\.\d+)?)\s*T\b/g, '$1 Tesla')
    .replace(/(\d+(?:\.\d+)?)\s*Wb\b/gi, '$1 Webers')
    .replace(/(\d+(?:\.\d+)?)\s*mH\b/gi, '$1 millihenries')
    .replace(/(\d+(?:\.\d+)?)\s*(?:μH|uH)\b/gi, '$1 microhenries')
    .replace(/(\d+(?:\.\d+)?)\s*H\b/g, '$1 Henries')
    .replace(/(\d+(?:\.\d+)?)\s*dB\b/gi, '$1 decibels')
    .replace(/(\d+(?:\.\d+)?)\s*rpm\b/gi, '$1 revolutions per minute')
    .replace(/(\d+(?:\.\d+)?)\s*lux\b/gi, '$1 lux');

  // 13. Scientific Exponents & Powers
  text = text
    .replace(/10\^\{-?19\}|10\^-19/g, '10 to the minus 19')
    .replace(/10\^\{-?9\}|10\^-9/g, '10 to the minus 9')
    .replace(/10\^\{23\}|10\^23/g, '10 to the 23rd')
    .replace(/10\^\{8\}|10\^8/g, '10 to the 8th')
    .replace(/\\sqrt\[([^\]]+)\]\{([^}]+)\}/g, '$1th root of $2')
    .replace(/\\sqrt\{([^}]+)\}/g, 'square root of $1')
    .replace(/([a-zA-Z0-9_\)\}]|\\[a-zA-Z]+)\^2/g, '$1 squared')
    .replace(/([a-zA-Z0-9_\)\}]|\\[a-zA-Z]+)\^3/g, '$1 cubed')
    .replace(/([a-zA-Z0-9_\)\}]|\\[a-zA-Z]+)\^\{([^}]+)\}/g, '$1 to the power of $2')
    .replace(/([a-zA-Z0-9_\)\}]|\\[a-zA-Z]+)\^(-?\d+)/g, '$1 to the power of $2');

  // 14. Subscripts & Physical Constants
  text = text
    .replace(/\\(?:epsilon|varepsilon)_0|\\(?:epsilon|varepsilon)_o/gi, 'epsilon naught')
    .replace(/\\mu_0/gi, 'mu naught')
    .replace(/\bk_B\b/g, 'k B')
    .replace(/\bN_A\b/g, 'N A')
    .replace(/\bv_0\b|\bv_\{0\}\b/g, 'v zero')
    .replace(/\bv_i\b|\bv_\{i\}\b/g, 'v initial')
    .replace(/\bv_f\b|\bv_\{f\}\b/g, 'v final')
    .replace(/\bP_1\b|\bP_\{1\}\b/g, 'P one')
    .replace(/\bP_2\b|\bP_\{2\}\b/g, 'P two')
    .replace(/\bV_1\b|\bV_\{1\}\b/g, 'V one')
    .replace(/\bV_2\b|\bV_\{2\}\b/g, 'V two')
    .replace(/\bx_1\b|\bx_\{1\}\b/g, 'x one')
    .replace(/\bx_2\b|\bx_\{2\}\b/g, 'x two')
    .replace(/_\{([^}]+)\}/g, ' sub $1 ')
    .replace(/_([a-zA-Z0-9]+)/g, ' sub $1 ');

  // 15. Greek Symbols & Math Notation
  text = text
    .replace(/\\int_\{([^}]+)\}\^\{([^}]+)\}/g, 'integral from $1 to $2')
    .replace(/\\int\^\{([^}]+)\}_\{([^}]+)\}/g, 'integral from $2 to $1')
    .replace(/\\int/g, 'integral of ')
    .replace(/\\sum_\{([^}]+)\}\^\{([^}]+)\}/g, 'summation from $1 to $2')
    .replace(/\\sum/g, 'summation of ')
    .replace(/\\times|×|\\cdot/g, ' times ')
    .replace(/\\div|÷/g, ' divided by ')
    .replace(/\\pm|±/g, ' plus or minus ')
    .replace(/\\mp|∓/g, ' minus or plus ')
    .replace(/\\leq|\\le|≤/g, ' is less than or equal to ')
    .replace(/\\geq|\\ge|≥/g, ' is greater than or equal to ')
    .replace(/\\neq|\\ne|≠/g, ' is not equal to ')
    .replace(/\\approx|≈/g, ' is approximately equal to ')
    .replace(/\\propto|∝/g, ' is proportional to ')
    .replace(/\\equiv|≡/g, ' is identically equal to ')
    .replace(/\\infty|∞/g, ' infinity ')
    .replace(/\\pi|π/g, ' pi ')
    .replace(/\\theta|θ/g, ' theta ')
    .replace(/\\alpha|α/g, ' alpha ')
    .replace(/\\beta|β/g, ' beta ')
    .replace(/\\gamma|γ/g, ' gamma ')
    .replace(/\\delta|δ/g, ' delta ')
    .replace(/\\lambda|λ/g, ' lambda ')
    .replace(/\\mu|μ/g, ' mu ')
    .replace(/\\nu|ν/g, ' nu ')
    .replace(/\\rho|ρ/g, ' rho ')
    .replace(/\\sigma|σ/g, ' sigma ')
    .replace(/\\tau|τ/g, ' tau ')
    .replace(/\\phi|\\varphi|φ/g, ' phi ')
    .replace(/\\psi|ψ/g, ' psi ')
    .replace(/\\omega|ω/g, ' omega ')
    .replace(/\\Omega|Ω/g, ' Ohms ')
    .replace(/\\hbar|ℏ/g, ' h-bar ')
    .replace(/\\partial|∂/g, ' partial derivative ')
    .replace(/\\nabla|∇/g, ' nabla ')
    .replace(/=/g, ' equals ')
    .replace(/%/g, ' percent ');

  // 16. Contextual Signs: Mathematical Plus (+) and Minus (-) handling
  // Unary positive sign before a number: "+2870" -> "positive 2870"
  text = text.replace(/(^|[\s(=])\+(\d+(?:\.\d+)?)/g, '$1positive $2');
  // Binary plus between numbers, variables or terms: "a + b" -> "a plus b"
  text = text.replace(/\+/g, ' plus ');

  // Unary negative sign before a number or variable: "-2870" -> "minus 2870", "-b" -> "minus b"
  text = text.replace(/(^|[\s(=])[-−](\d+(?:\.\d+)?|[a-zA-Z]\b)/g, '$1minus $2');
  // Binary minus between math tokens: "a - b" -> "a minus b"
  text = text.replace(/(\b[a-zA-Z0-9\)]+)\s*[-−]\s*([a-zA-Z0-9\(]+)/g, '$1 minus $2');

  // 17. Abbreviations & Spoken Punctuation Cleanup
  text = text
    .replace(/\be\.g\.,?\b/gi, 'for example')
    .replace(/\bi\.e\.,?\b/gi, 'that is')
    .replace(/\betc\.\b/gi, 'and so on')
    .replace(/\bFig\.\s*(\d+)/gi, 'Figure $1')
    .replace(/\(([A-Z])\)\s*/g, 'part $1, ')
    .replace(/\\/g, '')
    // Strip leftover formatting characters ($ # * _ •)
    .replace(/[$#*_•]/g, ' ')
    // Convert em-dashes and ellipses to natural pauses (commas for TTS pitch & pause)
    .replace(/[—–]/g, ', ')
    .replace(/…/g, ', ')
    .replace(/\.{2,}/g, ', ')
    // Ban literal utterance of formatting or filler symbol words
    .replace(/\b(dot\s+dot\s+dot|dot\s+dot|yojak\s+chinh|star\s+star\s+star|bullet\s+point|new\s+line|backslash|asterisk|hyphen|underscore|caret|curly\s+bracket|square\s+bracket|round\s+bracket|dollar\s+sign|hash\s+tag|hash\s+symbol)\b/gi, '')
    .replace(/\n+/g, '. ')
    .replace(/\s+/g, ' ')
    .trim();

  return expandAbbreviationsForSpeech(text);
}

export function expandAbbreviationsForSpeech(text: string, style: 'standard' | 'formal' = 'standard'): string {
  if (!text) return "";
  let processed = text;

  // Check if text contains Devanagari (Hindi) characters to provide localized phonetic pronunciations
  const hasDevanagari = /[\u0900-\u097F]/.test(processed);

  // Expand Hindi abbreviations (e.g. उदा. / उदा० / उदा: -> उदाहरण)
  processed = processed.replace(/(^|[\s(])उदा(?:[.\u0970:]|\s*[:-]?\s*)(?![अ-ह\u0900-\u097F])/g, "$1उदाहरण: ");
  processed = processed.replace(/(^|[\s(])प्र(?:[.\u0970:]|\s*[:-]?\s*)(?![अ-ह\u0900-\u097F])/g, "$1प्रश्न: ");
  processed = processed.replace(/(^|[\s(])समी(?:[.\u0970:]|\s*[:-]?\s*)(?![अ-ह\u0900-\u097F])/g, "$1समीकरण ");

  // Fix 'dr' / 'dr\'' so it is not spoken as "doctor"
  if (hasDevanagari) {
    processed = processed.replace(/\bdr'(?!\w)/gi, " डी आर प्राइम ");
    processed = processed.replace(/\bdr\b/gi, " डी आर ");
    processed = processed.replace(/\bd\s+r'(?!\w)/gi, " डी आर प्राइम ");
    processed = processed.replace(/\bd\s+r\b/gi, " डी आर ");
  } else {
    processed = processed.replace(/\bdr'(?!\w)/gi, " d r prime ");
    processed = processed.replace(/\bdr\b/gi, " d r ");
    processed = processed.replace(/\bd\s+r'(?!\w)/gi, " d r prime ");
    processed = processed.replace(/\bd\s+r\b/gi, " d r ");
  }

  const isFormal = style === 'formal';

  if (hasDevanagari) {
    if (isFormal) {
      // Formal scientific Hindi (pure Hindi definitions where applicable, e.g. "वर्ग मीटर" instead of "मीटर स्क्वायर")
      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "कूलम्ब प्रति वर्ग मीटर");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "कूलम्ब प्रति वर्ग मीटर");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s+(?:to\s+the\s+power\s+of\s+2|squared|square)\b/gi, "कूलम्ब प्रति वर्ग मीटर");

      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "कूलम्ब प्रति घन मीटर");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "कूलम्ब प्रति घन मीटर");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s+(?:to\s+the\s+power\s+of\s+3|cubed|cube)\b/gi, "कूलम्ब प्रति घन मीटर");

      processed = processed.replace(/\bkg\s*[\/|]\s*m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "किलोग्राम प्रति घन मीटर");
      processed = processed.replace(/\bkg\s*[\/|]\s*m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "किलोग्राम प्रति वर्ग मीटर");
    } else {
      // 1. Coulomb per square meter (c/m square, C/m², C/m^2, etc.) -> कूलम्ब प्रति मीटर स्क्वायर
      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "कूलम्ब प्रति मीटर स्क्वायर");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "कूलम्ब प्रति मीटर स्क्वायर");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s+(?:to\s+the\s+power\s+of\s+2|squared|square)\b/gi, "कूलम्ब प्रति मीटर स्क्वायर");

      // 2. Coulomb per cubic meter (C/m³, C/m^3) -> कूलम्ब प्रति मीटर क्यूब
      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "कूलम्ब प्रति मीटर क्यूब");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "कूलम्ब प्रति मीटर क्यूब");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s+(?:to\s+the\s+power\s+of\s+3|cubed|cube)\b/gi, "कूलम्ब प्रति मीटर क्यूब");

      processed = processed.replace(/\bkg\s*[\/|]\s*m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "किलोग्राम प्रति मीटर क्यूब");
      processed = processed.replace(/\bkg\s*[\/|]\s*m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "किलोग्राम प्रति मीटर स्क्वायर");
    }

    // 3. Coulomb per meter (C/m) -> कूलम्ब प्रति मीटर
    processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\b/gi, "कूलम्ब प्रति मीटर");
    processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\b/gi, "कूलम्ब प्रति मीटर");

    // 4. Other physics units
    processed = processed.replace(/\bN\s*[\/|]\s*C\b/g, "न्यूटन प्रति कूलम्ब");
    processed = processed.replace(/\bV\s*[\/|]\s*m\b/g, "वोल्ट प्रति मीटर");
    processed = processed.replace(/\bF\s*[\/|]\s*m\b/g, "फैराड प्रति मीटर");
    processed = processed.replace(/\bJ\s*[\/|]\s*C\b/g, "जूल प्रति कूलम्ब");
    processed = processed.replace(/\bN\s*[-·•*]\s*m\b/g, "न्यूटन मीटर");

    // 5. Celsius / degrees
    processed = processed.replace(/°C\b/g, "डिग्री सेल्सियस");
    processed = processed.replace(/\bdeg\s+C\b/gi, "डिग्री सेल्सियस");

    // 6. Units after numbers: e.g. 5 C -> 5 कूलम्ब
    processed = processed.replace(/(\d+(?:\.\d+)?)\s*\bC\b/g, "$1 कूलम्ब");

    // 7. Linear Algebra & Matrix / Determinant enunciation in Hindi
    processed = processed
      .replace(/\b(\d+)\s*(?:by|बाई|x|×)\s*(\d+)\b/gi, "$1 बाई $2")
      .replace(/\\?det\s*\(\s*k\s*A\s*\)|\bdet\s*\(\s*k\s*A\s*\)/gi, "डिटरमिनेंट k A")
      .replace(/\\?det\s*\(\s*A\s*B\s*\)|\bdet\s*\(\s*A\s*B\s*\)/gi, "डिटरमिनेंट A B")
      .replace(/\\?det\s*\(\s*([A-Za-z0-9_]+)\s*\)|\bdet\s*\(\s*([A-Za-z0-9_]+)\s*\)/gi, "डिटरमिनेंट $1")
      .replace(/\bdeterminant\s+of\s+([A-Za-z0-9_]+)/gi, "डिटरमिनेंट $1")
      .replace(/\bk\s*(?:\^|to the power of)\s*n\b/gi, "k की घात n")
      .replace(/\bk\s*(?:\^|to the power of)\s*3\b|\bk\s+cubed\b/gi, "k की घात 3")
      .replace(/\bk\s*(?:\^|to the power of)\s*2\b|\bk\s+squared\b/gi, "k की घात 2")
      .replace(/\b([a-zA-Z])\s*(?:\^|to the power of)\s*([a-zA-Z0-9]+)\b/gi, "$1 की घात $2");
  } else {
    // English equivalents
    if (isFormal) {
      // Explicit formal scientific enunciation: "Coulomb per meter squared", "Coulomb per meter cubed"
      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "coulomb per meter squared");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "coulomb per meter squared");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s+(?:to\s+the\s+power\s+of\s+2|squared|square)\b/gi, "coulomb per meter squared");

      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "coulomb per meter cubed");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "coulomb per meter cubed");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s+(?:to\s+the\s+power\s+of\s+3|cubed|cube)\b/gi, "coulomb per meter cubed");

      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\b/gi, "coulomb per meter");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\b/gi, "coulomb per meter");

      processed = processed.replace(/\bkg\s*[\/|]\s*m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "kilograms per meter cubed");
      processed = processed.replace(/\bkg\s*[\/|]\s*m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "kilograms per meter squared");

      processed = processed.replace(/\bN\s*[\/|]\s*C\b/g, "Newton per Coulomb");
      processed = processed.replace(/\bV\s*[\/|]\s*m\b/g, "volt per meter");
      processed = processed.replace(/\bF\s*[\/|]\s*m\b/g, "farad per meter");
      processed = processed.replace(/\bJ\s*[\/|]\s*C\b/g, "joule per Coulomb");
      processed = processed.replace(/\bN\s*[-·•*]\s*m\b/g, "Newton meter");
    } else {
      // 1. Coulomb per square meter (c/m square, C/m², C/m^2, etc.)
      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "coulomb prati miter square");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "coulomb prati miter square");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s+(?:to\s+the\s+power\s+of\s+2|squared|square)\b/gi, "coulomb prati miter square");

      // 2. Coulomb per cubic meter (C/m³, C/m^3)
      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "coulomb prati miter cube");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "coulomb prati miter cube");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\s+(?:to\s+the\s+power\s+of\s+3|cubed|cube)\b/gi, "coulomb prati miter cube");

      // 3. Coulomb per meter (C/m)
      processed = processed.replace(/\b(C|coulomb)\s*[\/|]\s*m\b/gi, "coulomb prati miter");
      processed = processed.replace(/\b(C|coulomb)\s+(?:over|per|prati)\s+m\b/gi, "coulomb prati miter");

      processed = processed.replace(/\bkg\s*[\/|]\s*m\s*(?:\^?3|³|\bcubed\b|\bcube\b)\b/gi, "kilogram prati miter cube");
      processed = processed.replace(/\bkg\s*[\/|]\s*m\s*(?:\^?2|²|\bsquared\b|\bsquare\b)\b/gi, "kilogram prati miter square");

      // 4. Other physics units
      processed = processed.replace(/\bN\s*[\/|]\s*C\b/g, "Newton per Coulomb");
      processed = processed.replace(/\bV\s*[\/|]\s*m\b/g, "volt per meter");
      processed = processed.replace(/\bF\s*[\/|]\s*m\b/g, "farad per meter");
      processed = processed.replace(/\bJ\s*[\/|]\s*C\b/g, "joule per Coulomb");
      processed = processed.replace(/\bN\s*[-·•*]\s*m\b/g, "Newton meter");
    }

    // 5. Celsius / degrees
    processed = processed.replace(/°C\b/g, "degrees Celsius");
    processed = processed.replace(/\bdeg\s+C\b/gi, "degrees Celsius");

    // 6. Units after numbers: e.g. 5 C -> 5 Coulombs
    processed = processed.replace(/(\d+(?:\.\d+)?)\s*\bC\b/g, "$1 Coulombs");
  }

  // 1. Specific phrase replacements for SI (International System of Units)
  processed = processed.replace(/\bSI\s+unit(s?)\b/gi, "International System unit$1");
  processed = processed.replace(/\bSI\b/g, "International System of Units");

  // 2. Unit combinations with forward slash
  processed = processed.replace(/\bm\/s\^2\b/g, "meters per second squared");
  processed = processed.replace(/\bm\/s\b/g, "meters per second");
  processed = processed.replace(/\bkm\/h\b/g, "kilometers per hour");
  processed = processed.replace(/\bkg\/m\^3\b/g, "kilograms per cubic meter");

  // 3. Units with numbers preceding them (e.g., "5 kg" -> "5 kilograms", "10 m" -> "10 meters")
  // Note: single letter units like A, N, C, J, W, V, F, K are strictly uppercase to avoid clashing with algebra variables
  const unitsAfterNumber: { [key: string]: string } = {
    'kg': 'kilograms',
    'g': 'grams',
    'mg': 'milligrams',
    'm': 'meters',
    'cm': 'centimeters',
    'mm': 'millimeters',
    'km': 'kilometers',
    's': 'seconds',
    'ms': 'milliseconds',
    'Hz': 'Hertz',
    'MHz': 'Megahertz',
    'GHz': 'Gigahertz',
    'Pa': 'Pascals',
    'kPa': 'kilopascals',
    'rad': 'radians',
    'deg': 'degrees'
  };

  Object.entries(unitsAfterNumber).forEach(([unit, replacement]) => {
    // Matches a digit (optionally with decimal), followed by optional spaces, then the unit bounded.
    const regex = new RegExp(`(\\d+(?:\\.\\d+)?)\\s*\\b${unit}\\b`, 'gi');
    processed = processed.replace(regex, `$1 ${replacement}`);
  });

  // Capitalized single-letter units after numbers (case-sensitive)
  const capitalUnitsAfterNumber: { [key: string]: string } = {
    'N': 'Newtons',
    'J': 'Joules',
    'W': 'Watts',
    'V': 'Volts',
    'A': 'Amperes',
    'K': 'Kelvins'
  };
  Object.entries(capitalUnitsAfterNumber).forEach(([unit, replacement]) => {
    const regex = new RegExp(`(\\d+(?:\\.\\d+)?)\\s+${unit}\\b`, 'g');
    processed = processed.replace(regex, `$1 ${replacement}`);
  });

  // 4. Standalone abbreviations (unconditional with word boundary)
  const standaloneAbbreviations: { [key: string]: string } = {
    'kg': 'kilograms',
    'cm': 'centimeters',
    'mm': 'millimeters',
    'km': 'kilometers',
    'Hz': 'Hertz',
    'MHz': 'Megahertz',
    'kPa': 'kilopascals',
    'm/s': 'meters per second',
    'm/s^2': 'meters per second squared'
  };

  Object.entries(standaloneAbbreviations).forEach(([abbr, replacement]) => {
    // Escapes special characters like ^ and / in the abbreviation keys
    const escapedAbbr = abbr.replace(/[/\^]/g, '\\$&');
    const regex = new RegExp(`\\b${escapedAbbr}\\b`, 'g');
    processed = processed.replace(regex, replacement);
  });

  // 5. Roman numerals in structural headings (Step I -> Step one, चरण I -> चरण एक)
  const hindiRomanSteps: { [key: string]: string } = {
    'I': 'एक', 'II': 'दो', 'III': 'तीन', 'IV': 'चार', 'V': 'पाँच',
    'VI': 'छह', 'VII': 'सात', 'VIII': 'आठ', 'IX': 'नौ', 'X': 'दस'
  };
  Object.entries(hindiRomanSteps).forEach(([roman, hindiWord]) => {
    // Matches "चरण" or "charan" followed by space and Roman numeral (case-insensitive)
    const regex = new RegExp(`\\b(चरण|charan)\\s*\\b${roman}\\b`, 'gi');
    processed = processed.replace(regex, `$1 ${hindiWord}`);
  });

  const englishRomanSteps: { [key: string]: string } = {
    'I': 'one', 'II': 'two', 'III': 'three', 'IV': 'four', 'V': 'five',
    'VI': 'six', 'VII': 'seven', 'VIII': 'eight', 'IX': 'nine', 'X': 'ten'
  };
  Object.entries(englishRomanSteps).forEach(([roman, englishWord]) => {
    // Matches structural words followed by space and Roman numeral (case-insensitive)
    const regex = new RegExp(`\\b(step|part|section|phase|question|problem)\\s*\\b${roman}\\b`, 'gi');
    processed = processed.replace(regex, `$1 ${englishWord}`);
  });

  // Standalone list indicators: I., II., III., etc. at start of line or bounded by space
  Object.entries(englishRomanSteps).forEach(([roman, englishWord]) => {
    const regex = new RegExp(`\\b${roman}\\.\\s`, 'g'); // Case-sensitive to avoid matching lowercase single 'i.' too aggressively
    processed = processed.replace(regex, `${englishWord}. `);
  });

  // Final sanitizer to prevent TTS engines from literally pronouncing punctuation marks out loud as words
  // 1. Replace Hindi purna viram danda (।) with a regular English period (.) so the TTS engine pauses naturally instead of saying "purna viram" or "purna biram"
  processed = processed.replace(/।/g, '. ');
  processed = processed.replace(/॥/g, '. ');

  // 2. Replace semicolons and colons with a comma or space so the TTS engine pauses naturally instead of pronouncing the word "semicolon" or "colon"
  processed = processed.replace(/;/g, ', ');
  processed = processed.replace(/:/g, ', ');

  // 3. Prevent multiple consecutive dots (e.g. "..", "...", "....") from being pronounced as "dot dot dot" by replacing them with a single comma/period
  processed = processed.replace(/\.{2,}/g, ', ');

  // 4. Clean up any literal occurrences of punctuation words that might have been generated or left in translation
  processed = processed.replace(/\b(purna\s+viram|purna\s+biram|semicolon|colon|dot\s+dot)\b/gi, ' ');

  // 5. Clean up any extra spaces
  processed = processed.replace(/\s+/g, ' ').trim();

  return processed;
}

export function normalizeMathematicalInput(input: string): string {
  if (!input) return "";

  let processed = input;

  // 1. Fix unbraced \text, \mathrm, \textbf, \mathit, \mathsf, \mathtt, \mbox commands followed by unit/word: "\text cm" -> "\text{cm}"
  processed = processed.replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\s+([a-zA-Z0-9]+)/g, '\\$1{$2}');

  // 2. Convert slash unit macros like "\cm", "\mm", "\kg" -> "\text{cm}"
  processed = processed.replace(/\\(cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW|deg|rad)\b/gi, '\\text{$1}');

  // 3. Fix unclosed \text{cm or \mathrm{cm without closing brace before delimiter, newline, or end of string
  processed = processed.replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\{([a-zA-Z0-9\s]+)(?=[$\\\n]|$)/g, '\\$1{$2}');

  // 4. Wrap numbers followed by unit abbreviations (e.g., "90 cm", "90cm", "6.5 mm", "10 kg", "50 Hz")
  // inside \text{...} blocks so KaTeX and math evaluators treat them as non-math text identifiers.
  const unitsPattern = '\\b(cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW|deg|rad)\\b';
  const numberUnitRegex = new RegExp(`(\\b\\d+(?:\\.\\d+)?)\\s*${unitsPattern}`, 'gi');

  if (/(\$\$?[\s\S]*?\$\$?|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\])/.test(processed)) {
    processed = processed.replace(/(\$\$?[\s\S]*?\$\$?|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\])/g, (mathBlock) => {
      return mathBlock.replace(numberUnitRegex, (match, num, unit) => {
        return `${num}\\text{ ${unit}}`;
      });
    });
  } else if (/[=+\/*\\^-]/.test(processed)) {
    // If input is a raw mathematical equation like "f_o = 90 cm"
    processed = processed.replace(numberUnitRegex, '$1\\text{ $2}');
  }

  // 5. Pre-process lines: trim and remove empty elements but preserve structure
  const lines = processed.split('\n').map(line => line.trim());
  
  // 2. Resolve obvious divider-based fractions first:
  // e.g., 
  // numerator
  // --- or ___ or ===
  // denominator
  for (let i = 1; i < lines.length - 1; i++) {
    const line = lines[i];
    if (/^[_\-+=]{2,}$/.test(line)) { // Looks like a divider line
      const num = lines[i - 1];
      const den = lines[i + 1];
      if (num && den && !/^[_\-+=]{2,}$/.test(num) && !/^[_\-+=]{2,}$/.test(den)) {
        lines[i - 1] = `\\frac{${num}}{${den}}`;
        lines[i] = "";
        lines[i + 1] = "";
      }
    }
  }

  // Filter out any blank lines we just created or that were already empty
  let cleanLines = lines.filter(line => line.length > 0);

  // 3. Resolve vertically stacked derivatives and fractions without divider lines
  // e.g., "F=" followed by "dt" and "dp" (or "dp" and "dt")
  // Or "F=" followed by "dp" then "dt"
  for (let i = 0; i < cleanLines.length - 1; i++) {
    const current = cleanLines[i];
    const next = cleanLines[i + 1];
    
    // Check if we have an equation start like "F =" or "F="
    if (i < cleanLines.length - 2 && /^[a-zA-Z\s]*=$/.test(current)) {
      const firstTerm = cleanLines[i + 1];
      const secondTerm = cleanLines[i + 2];
      
      // If we see differential terms like dp and dt in a vertical stack (regardless of order, force dp/dt)
      if (
        (firstTerm === 'dp' && secondTerm === 'dt') || 
        (firstTerm === 'dt' && secondTerm === 'dp') ||
        (firstTerm === 'dx' && secondTerm === 'dy') ||
        (firstTerm === 'dy' && secondTerm === 'dx')
      ) {
        const num = (firstTerm.startsWith('d') && firstTerm !== 'dt') || secondTerm === 'dt' ? firstTerm : secondTerm;
        const den = num === firstTerm ? secondTerm : firstTerm;
        cleanLines[i] = `${current} \\frac{${num}}{${den}}`;
        cleanLines[i + 1] = "";
        cleanLines[i + 2] = "";
        i += 2; // skip processed items
        continue;
      }
    }

    // General case of two consecutive single/short mathematical variables/differentials that might be a fraction
    if (/^[a-zA-Z]{1,3}$/.test(current) && /^[a-zA-Z]{1,3}$/.test(next)) {
      // If one of them is dt/dx/dy/dz and they are stacked
      if (current.startsWith('d') || next.startsWith('d')) {
        cleanLines[i] = `\\frac{${current}}{${next}}`;
        cleanLines[i + 1] = "";
        i++;
      }
    }
  }

  // Refilter
  cleanLines = cleanLines.filter(line => line.length > 0);

  // 4. Handle vertically-spaced simple equality equations:
  // e.g., 
  // p
  // =
  // m
  // v
  // or similar single character segments
  for (let i = 0; i < cleanLines.length - 1; i++) {
    if (cleanLines[i] === "=") {
      // Look back for a single letter and look forward for letters
      let leftIndex = i - 1;
      while (leftIndex >= 0 && cleanLines[leftIndex].length === 1 && /^[a-zA-Z]$/.test(cleanLines[leftIndex])) {
        leftIndex--;
      }
      leftIndex++; // first valid single letterDocumentAnalyzer

      let rightIndex = i + 1;
      while (rightIndex < cleanLines.length && cleanLines[rightIndex].length === 1 && /^[a-zA-Z]$/.test(cleanLines[rightIndex])) {
        rightIndex++;
      }
      rightIndex--; // last valid single letter
      if (leftIndex < i && rightIndex > i) {
        const leftSide = cleanLines.slice(leftIndex, i).join("");
        const rightSide = cleanLines.slice(i + 1, rightIndex + 1).join("");
        cleanLines[leftIndex] = `${leftSide} = ${rightSide}`;
        
        // Blank out the merged lines
        for (let j = leftIndex + 1; j <= rightIndex; j++) {
          cleanLines[j] = "";
        }
        i = rightIndex;
      }
    }
  }

  // Refilter
  cleanLines = cleanLines.filter(line => line.length > 0);

  // 5. Wrap Hindi transition words correctly, e.g. "जहाँ" -> "where" or "जहाँ" with proper text spacing,
  // and join consecutive fragments.
  for (let i = 0; i < cleanLines.length; i++) {
    let line = cleanLines[i];
    // Normalize Hindi 'जहाँ' or 'जहॉं' or 'जहा' meaning 'where'
    if (/^[जज]ह[ाँॉा]\s*$/u.test(line) || line.toLowerCase() === 'where') {
      cleanLines[i] = " , जहाँ ";
    }
  }

  // Final assembly: join lines with appropriate spacing. If there is already an inline equation or block,
  // normalize double equals or duplicates like "p=mv p=mv"
  let result = cleanLines.join(" ");

  // Deduplicate identical equations side by side (e.g. "p=mv p=mv" -> "p=mv")
  result = result.replace(/\b([a-zA-Z]\s*=\s*[a-zA-Z0-9]+)\s+\1\b/g, "$1");

  // Final safety pass for unbraced \text commands or unclosed braces
  result = result.replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\s+([a-zA-Z0-9]+)/g, '\\$1{$2}');
  result = result.replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\{([a-zA-Z0-9\s]+)(?=[$\\\n]|$)/g, '\\$1{$2}');
  
  return result.trim();
}

/**
 * Serializes an object to JSON while safely handling circular structures and DOM elements.
 * Circular references are replaced with "[Circular]" and DOM elements are replaced with "[DOM Element]".
 */
export function safeJsonStringify(obj: any, indent = 0): string {
  const cache = new Set();
  
  const stringified = JSON.stringify(
    obj,
    (key, value) => {
      // Handle DOM elements
      if (value instanceof HTMLElement || value instanceof Node || (value && typeof value === 'object' && value.nodeType)) {
        return `[DOM Element: ${value.nodeName || 'unknown'}]`;
      }
      
      // Handle circular references
      if (typeof value === 'object' && value !== null) {
        if (cache.has(value)) {
          return "[Circular]";
        }
        cache.add(value);
      }
      return value;
    },
    indent
  );
  
  cache.clear();
  return stringified;
}

/**
 * Ensures screen display text contains ONLY natural language (and LaTeX / SVG graphics),
 * completely stripping out internal system tags, bracketed commands, timing parameters, and pseudo-code markup.
 */
export function cleanNaturalLanguageForScreen(rawText: string): string {
  if (!rawText) return '';
  let text = rawText;

  // 0a. Strip injected prompt headers, prompt echoes, or rigor directives from display
  text = text.replace(/^> 💬[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
  text = text.replace(/^> \*{0,2}Selected Prompt[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
  text = text.replace(/^> \*{0,2}Prompt Selected[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
  text = text.replace(/^> \*?"?I want to study[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
  text = text.replace(/^> \*?"?I want to solve[\s\S]*?(?=\n\n[^>]|\n\n#|$)/gim, '');
  text = text.replace(/(?:^|\n)[ \t]*>?[ \t]*\*{0,2}(?:Tutor Rigor Instructions|Tutor Instructions|Please proceed to teach|STANDARD depth\/rigor)[^\n]*/gi, '');
  text = text.replace(/(?:^|\n)[ \t]*>?[ \t]*\*{0,2}(?:MASTER CURRICULUM|CRITICAL PEDAGOGICAL|MANDATORY NATURAL|STRICT TOPIC|CRITICAL SMARTBOARD|CRITICAL SELECTION|STRICT ZERO)[^\n]*/gi, '');
  text = text.replace(/^[ \t]*[=\-_*]{3,}[ \t]*$/gm, '');

  // 0. Unwrap outer ```markdown ... ``` or ```md ... ``` wrappers so headings/math render directly
  text = text.replace(/^\s*```(?:markdown|md|text|txt|latex)?\s*\n([\s\S]*?)(?:\n\s*```\s*)?$/i, '$1');

  // 0b. Unwrap ```svg ... ``` code blocks containing <svg> elements into clean raw SVG
  text = text.replace(/```(?:svg|xml|html)?\s*\n\s*(<svg[\s\S]*?<\/svg>)\s*\n?```/gi, '\n\n$1\n\n');
  text = text.replace(/```(?:svg|xml|html)?\s*\n\s*(<svg[\s\S]*?>)/gi, '\n\n$1');

  // 0c. Strip standalone ```markdown, ```md, ```text, ```latex delimiter lines
  text = text.replace(/^[ \t]*```(?:markdown|md|text|txt|latex)[ \t]*$/gim, '');

  // 1. Remove pseudo-code blocks that only contain machine language / bracketed stage directives
  text = text.replace(/```[a-z]*\s*(\[(?:AVATAR|SMARTBOARD|ANIMATION|DRAW|TYPE|SCROLL|PAUSE|TEACHING|ANALOGY|STORY|BREAKDOWN|RULE)[^`]*?)```/gi, '');

  // 2. Remove arrow-prefixed action commands e.g. "→ [SMARTBOARD: ...] " or "  → [AVATAR: ...]"
  text = text.replace(/(^|\n)\s*→\s*\[[^\]\n]*\][^\n]*/g, '$1');

  // 3. Remove all bracketed commands with keyword + colon or parameter
  text = text.replace(/\[\s*(?:SMARTBOARD|AVATAR|ANIMATION|FIGURE|ELEMENT|COMPLETE|CONNECTION|COMPARATIVE|LAYERED|INTERACTIVE|EXAM|DYNAMIC|STEP|PHASE|STAGE|DRAW|TYPE|SCROLL|PAUSE|LABEL|SPOTLIGHT|HIGHLIGHT|ZOOM|AUDIO|CAMERA|ACTION|SYNC|SCENE|NOTE|DIRECTIVE|PROMPT|TRIGGER|GESTURE|EXPRESSION|ZONE|INSTRUCTION)\b[^\]]*\]/gi, '');

  // 4. Remove ALL CAPS bracketed header tags like [FIGURE_CONSTRUCTION_SEQUENCE], [TEACHING_GOLDEN_RULE], [ANALOGY_METHOD]
  text = text.replace(/\[[A-Z0-9_\-\s]{2,}\]/g, '');

  // 5. Remove any generic bracketed directive e.g. [Action: ...], [sync_with: ...]
  text = text.replace(/\[[A-Za-z0-9_\-\s]{2,40}:\s*[^\]]*\]/g, '');

  // 6. Remove any remaining pipe-separated timing or sync directives e.g. [1s | smooth | sync_with: "..."]
  text = text.replace(/\[[^\]\n]{1,120}\|[^\]\n]{1,120}\]/g, '');

  // 7. Remove time duration strings e.g. (2-3 min), (10-15 min), (2 sec, silent), (1s)
  text = text.replace(/\(\s*\d+[-–—\s]*\d*\s*(min|mins|minutes?|sec|seconds?)\s*\)/gi, '');

  // 8. Remove bracketed action tags with simple content or timing
  text = text.replace(/\[Type:\s*([^\]]*?)--?\s*\d+\s*sec[^\]]*?silent[^\]]*\]/gi, '');
  text = text.replace(/\[Type:\s*"([^"]+)"[^\]]*\]/gi, '$1');
  text = text.replace(/\[Type:\s*([^\]]+)\]/gi, '$1');
  text = text.replace(/\[Scroll:\s*([^\]]+)\]/gi, '');
  text = text.replace(/\[Draw:\s*"([^"]+)"[^\]]*\]/gi, '');
  text = text.replace(/\[Draw:\s*([^\]]+)\]/gi, '');
  text = text.replace(/\[Pause:\s*([^\]]+)\]/gi, '');
  text = text.replace(/\[Label:\s*"([^"]+)"[^\]]*\]/gi, '$1');
  text = text.replace(/\[Label:\s*([^\]]+)\]/gi, '$1');
  text = text.replace(/\[→\s*Animation:\s*([^\]]*)\]/gi, '');
  text = text.replace(/\[\s*Animation:\s*([^\]]*)\]/gi, '');
  text = text.replace(/\*\((Illustration|Animation):\s*([^)]*)\)\*/gi, '');

  // 9. Remove explicit pseudo-code markers like ❌ READING: or ✅ TEACHING: or Directive:
  text = text.replace(/(^|\n)\s*(?:❌\s*READING:[^\n]*|✅\s*TEACHING:\s*)/gi, '$1');
  text = text.replace(/(^|\n)\s*Directive:\s*[^\n]*/gi, '$1');

  // 10. Remove lines that are purely machine metadata (e.g., sync_with: ..., duration: ...)
  text = text.replace(/(^|\n)\s*(?:sync_with|duration|intensity|body_part|zone):\s*[^\n]*/gi, '$1');

  // 11. Remove trailing dangling code fences (```)
  text = text.replace(/(?:\r?\n)[ \t]*```[ \t]*$/g, '');

  // 12. Clean up empty double spaces and excessive newlines
  text = text.replace(/[ \t]{2,}/g, ' ');
  text = text.replace(/\n\s*\n\s*\n+/g, '\n\n');
  return text.trim();
}

/**
 * Ensures any raw inline <svg>...</svg> blocks inside markdown content
 * (outside of code fences) are automatically formatted as code blocks so that
 * ReactMarkdown components render them seamlessly in-place using SvgDiagramViewer.
 */
export function formatMarkdownWithInlineSvgs(content: string): string {
  if (!content) return '';
  let cleanedContent = cleanNaturalLanguageForScreen(content);
  // Unwrap any outer markdown code fence wrappers
  cleanedContent = cleanedContent.replace(/^\s*```(?:markdown|md|text|txt|latex)?\s*\n([\s\S]*?)(?:\n\s*```\s*)?$/i, '$1');

  const codeBlockRegex = /(```[\s\S]*?```)/g;
  const parts = cleanedContent.split(codeBlockRegex);

  const processed = parts.map((part) => {
    if (part.startsWith('```')) {
      // If code block is just wrapping an SVG, sanitize it thoroughly
      if (part.includes('<svg') && part.includes('</svg>')) {
        const sanitized = sanitizeSvgDiagramCode(part);
        if (sanitized) {
          return `\n\n\`\`\`svg\n${sanitized}\n\`\`\`\n\n`;
        }
        return part;
      }
      return part;
    }
    const svgRegex = /<svg[\s\S]*?<\/svg>/gi;
    return part.replace(svgRegex, (svgMatch) => {
      const sanitized = sanitizeSvgDiagramCode(svgMatch);
      return `\n\n\`\`\`svg\n${sanitized || svgMatch}\n\`\`\`\n\n`;
    });
  });

  let merged = processed.join('');
  // Normalize indented headings so they are parsed as headings, not indented code blocks
  merged = merged.replace(/^[ \t]+(#{1,6})\s+/gm, '$1 ');
  // Strip hashes after bullet markers: "- #### Title" -> "- Title"
  merged = merged.replace(/^([ \t]*[-*+•]\s*)#{1,6}\s*/gm, '$1');
  // Strip trailing dangling hashes on in-flight lines
  merged = merged.replace(/(?:^|\n)[ \t]*#{1,6}\s*(?:\([a-zA-Z0-9\u0900-\u097F]*\)?\s*)?$/g, '');
  const tableSanitized = sanitizeTablesInMarkdown(merged);
  return sanitizeLatexInMarkdown(tableSanitized);
}

export { sanitizeLatex, sanitizeLatexInMarkdown, safeKatexOptions, formatHumanReadableInterval, sanitizeTablesInMarkdown } from './latexSanitizer';



