import { SupportedLanguageCode, LanguageMetadata, TranslationDictionary } from './types';
import en from './translations/en.json';
import hi from './translations/hi.json';
import ta from './translations/ta.json';
import te from './translations/te.json';
import bn from './translations/bn.json';
import mr from './translations/mr.json';
import kn from './translations/kn.json';
import ml from './translations/ml.json';
import gu from './translations/gu.json';
import pa from './translations/pa.json';
import ur from './translations/ur.json';

export const SUPPORTED_LANGUAGES: Record<SupportedLanguageCode, LanguageMetadata> = {
  en: {
    code: 'en',
    name: 'English',
    nativeName: 'English',
    script: 'Latin',
    dir: 'ltr',
    voiceCode: 'en-IN',
    flagEmoji: '🌐',
    sampleGreeting: 'Welcome back to Omni AI Ultimate'
  },
  hi: {
    code: 'hi',
    name: 'Hindi',
    nativeName: 'हिन्दी',
    script: 'Devanagari',
    dir: 'ltr',
    voiceCode: 'hi-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'ओमनी एआई में आपका स्वागत है'
  },
  ta: {
    code: 'ta',
    name: 'Tamil',
    nativeName: 'தமிழ்',
    script: 'Tamil',
    dir: 'ltr',
    voiceCode: 'ta-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'ஓம்னி ஏஐ-க்கு நல்வரவு'
  },
  te: {
    code: 'te',
    name: 'Telugu',
    nativeName: 'తెలుగు',
    script: 'Telugu',
    dir: 'ltr',
    voiceCode: 'te-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'ఓమ్ని AI కి స్వాగతం'
  },
  bn: {
    code: 'bn',
    name: 'Bengali',
    nativeName: 'বাংলা',
    script: 'Bengali',
    dir: 'ltr',
    voiceCode: 'bn-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'অমনি এআই-তে স্বাগতম'
  },
  mr: {
    code: 'mr',
    name: 'Marathi',
    nativeName: 'मराठी',
    script: 'Devanagari',
    dir: 'ltr',
    voiceCode: 'mr-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'ओम्नी एआय मध्ये आपले स्वागत आहे'
  },
  kn: {
    code: 'kn',
    name: 'Kannada',
    nativeName: 'ಕನ್ನಡ',
    script: 'Kannada',
    dir: 'ltr',
    voiceCode: 'kn-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'ಓಮ್ನಿ ಎಐ ಗೆ ಸುಸ್ವಾಗತ'
  },
  ml: {
    code: 'ml',
    name: 'Malayalam',
    nativeName: 'മലയാളം',
    script: 'Malayalam',
    dir: 'ltr',
    voiceCode: 'ml-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'ഓംനി എഐയിലേക്ക് സ്വാഗതം'
  },
  gu: {
    code: 'gu',
    name: 'Gujarati',
    nativeName: 'ગુજરાતી',
    script: 'Gujarati',
    dir: 'ltr',
    voiceCode: 'gu-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'ઓમ્ની એઆઈ માં આપનું સ્વાગત છે'
  },
  pa: {
    code: 'pa',
    name: 'Punjabi',
    nativeName: 'ਪੰਜਾਬੀ',
    script: 'Gurmukhi',
    dir: 'ltr',
    voiceCode: 'pa-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'ਓਮਨੀ ਏਆਈ ਵਿੱਚ ਤੁਹਾਡਾ ਸੁਆਗਤ ਹੈ'
  },
  ur: {
    code: 'ur',
    name: 'Urdu',
    nativeName: 'اردو',
    script: 'Arabic (Nastaliq)',
    dir: 'rtl',
    voiceCode: 'ur-IN',
    flagEmoji: '🇮🇳',
    sampleGreeting: 'اومنی اے آئی میں خوش آمدید'
  }
};

const TRANSLATION_CATALOG: Record<SupportedLanguageCode, any> = {
  en,
  hi,
  ta,
  te,
  bn,
  mr,
  kn,
  ml,
  gu,
  pa,
  ur
};

/**
 * Resolves dot-notated translation string key (e.g. 'common.welcome') with instant fallback to English
 */
export const getTranslation = (key: string, lang: SupportedLanguageCode = 'en'): string => {
  const parts = key.split('.');
  
  // Try targeted language
  let current = TRANSLATION_CATALOG[lang];
  for (const part of parts) {
    if (current && typeof current === 'object' && part in current) {
      current = current[part];
    } else {
      current = undefined;
      break;
    }
  }

  if (typeof current === 'string') {
    return current;
  }

  // Fallback to English
  let fallback = TRANSLATION_CATALOG['en'];
  for (const part of parts) {
    if (fallback && typeof fallback === 'object' && part in fallback) {
      fallback = fallback[part];
    } else {
      fallback = undefined;
      break;
    }
  }

  return typeof fallback === 'string' ? fallback : key;
};

/**
 * Formats numbers in Indian Lakh/Crore system (1,00,000) or International system
 */
export const formatLocalizedNumber = (
  num: number, 
  system: 'indian' | 'international' = 'indian'
): string => {
  if (system === 'indian') {
    return new Intl.NumberFormat('en-IN').format(num);
  }
  return new Intl.NumberFormat('en-US').format(num);
};

/**
 * Formats currency in INR (₹) or USD ($)
 */
export const formatLocalizedCurrency = (
  amount: number,
  currency: 'INR' | 'USD' = 'INR'
): string => {
  if (currency === 'INR') {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
  }
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(amount);
};

/**
 * Formats date to DD/MM/YYYY or MM/DD/YYYY
 */
export const formatLocalizedDate = (
  date: Date | string | number,
  format: 'DD/MM/YYYY' | 'MM/DD/YYYY' = 'DD/MM/YYYY'
): string => {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();

  if (format === 'DD/MM/YYYY') {
    return `${day}/${month}/${year}`;
  }
  return `${month}/${day}/${year}`;
};
