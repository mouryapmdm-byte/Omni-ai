import React, { useState, useRef } from 'react';
import { cn } from '@/src/lib/utils';
import { Image, Upload, Search, Camera, CheckCircle2, AlertCircle, Loader2, Trash2, Maximize2, MessageSquare } from 'lucide-react';
import { generateAIResponse } from '@/src/lib/gemini';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

interface DiagramAnalyzerProps {
  theme: 'light' | 'dark';
  onClose: () => void;
}

export const DiagramAnalyzer: React.FC<DiagramAnalyzerProps> = ({ theme, onClose }) => {
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setImage(event.target?.result as string);
          setAnalysis(null);
          setError(null);
        };
        reader.readAsDataURL(selectedFile);
      } else {
        setError('Please upload an image file (PNG, JPG, WEBP).');
      }
    }
  };

  const startCamera = async () => {
    setCameraActive(true);
    setAnalysis(null);
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera error:', err);
      setError('Could not access camera. Please check permissions.');
      setCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setImage(dataUrl);
        stopCamera();
      }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const handleAnalyze = async (customQuery?: string) => {
    if (!image) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const base64 = image.split(',')[1];
      const mimeType = image.split(';')[0].split(':')[1];

      const prompt = customQuery 
        ? `Based on this diagram, please answer: ${customQuery}`
        : "Analyze this diagram comprehensively. Explain the components, labels, relationships between elements, and any underlying scientific, mathematical, or technical principles illustrated. Be precise and academic.";

      const fileData = {
        inlineData: {
          data: base64,
          mimeType: mimeType
        }
      };

      const response = await generateAIResponse(prompt, { 
        model: 'gemini-3.6-flash',
        systemInstruction: "You are an expert academic diagram analyst and scientific visual researcher. You excel at identifying labels, flowcharts, circuit diagrams, biological structures, and mathematical plots. Provide structured, accurate insights.",
        contents: { parts: [fileData, { text: prompt }] }
      });
      
      setAnalysis(response);
    } catch (err: any) {
      console.error('Analysis error:', err);
      setError(err.message || 'Failed to analyze the diagram. Please ensure the image is clear.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const reset = () => {
    setImage(null);
    setAnalysis(null);
    setError(null);
    setQuery('');
    stopCamera();
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className={cn(
      "flex flex-col h-full overflow-hidden transition-all duration-300",
      theme === 'dark' ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-800"
    )}>
      {/* Header */}
      <div className={cn(
        "px-6 py-4 border-b flex items-center justify-between shrink-0",
        theme === 'dark' ? "bg-slate-900 border-slate-800 shadow-xl" : "bg-white border-slate-200 shadow-sm"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Maximize2 size={20} className="text-white" />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight uppercase">Diagram Vision AI</h2>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-0.5">
              Intelligent Visual Problem Solver
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
           {image && (
             <button 
               onClick={reset}
               className="p-2 text-slate-400 hover:text-red-500 transition-colors"
               title="Clear current view"
             >
               <Trash2 size={20} />
             </button>
           )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
        {!image && !cameraActive ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full max-h-[500px]">
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={cn(
                "border-2 border-dashed rounded-3xl p-12 flex flex-col items-center justify-center gap-4 cursor-pointer transition-all group",
                theme === 'dark' 
                  ? "border-slate-800 bg-slate-900/50 hover:border-indigo-500 hover:bg-indigo-900/10" 
                  : "border-slate-200 bg-white hover:border-indigo-500 hover:bg-indigo-50/50"
              )}
            >
              <div className="p-5 bg-indigo-500/10 text-indigo-500 rounded-2xl group-hover:scale-110 transition-transform">
                <Upload size={40} />
              </div>
              <div className="text-center">
                <p className="text-lg font-black tracking-tight">Upload Image</p>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Diagram, Plot, or Sketch</p>
              </div>
              <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />
            </div>

            <div 
              onClick={startCamera}
              className={cn(
                "border-2 border-dashed rounded-3xl p-12 flex flex-col items-center justify-center gap-4 cursor-pointer transition-all group",
                theme === 'dark' 
                  ? "border-slate-800 bg-slate-900/50 hover:border-emerald-500 hover:bg-emerald-900/10" 
                  : "border-slate-200 bg-white hover:border-emerald-500 hover:bg-emerald-50/50"
              )}
            >
              <div className="p-5 bg-emerald-500/10 text-emerald-500 rounded-2xl group-hover:scale-110 transition-transform">
                <Camera size={40} />
              </div>
              <div className="text-center">
                <p className="text-lg font-black tracking-tight">Use Camera</p>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Capture Live Paper Work</p>
              </div>
            </div>
          </div>
        ) : cameraActive ? (
          <div className="relative rounded-3xl overflow-hidden bg-black aspect-video max-w-2xl mx-auto shadow-2xl">
            <video 
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4">
              <button 
                onClick={stopCamera}
                className="px-6 py-3 bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-white/20 transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={capturePhoto}
                className="px-8 py-3 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-500 transition-all active:scale-95"
              >
                Capture Diagram
              </button>
            </div>
            <canvas ref={canvasRef} className="hidden" />
          </div>
        ) : (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="relative group rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-2xl">
              <img 
                src={image!} 
                alt="Diagram" 
                className="w-full h-auto max-h-[400px] object-contain bg-slate-100 dark:bg-slate-800"
              />
              {!analysis && !isAnalyzing && (
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                   <button 
                     onClick={() => handleAnalyze()}
                     className="px-10 py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl hover:bg-indigo-500 transition-all active:scale-95 flex items-center gap-2"
                   >
                     <Search size={16} /> Start Full Analysis
                   </button>
                </div>
              )}
            </div>

            {isAnalyzing && (
              <div className={cn(
                "p-12 rounded-3xl border flex flex-col items-center justify-center gap-6 animate-pulse",
                theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
              )}>
                <div className="relative">
                  <div className="absolute inset-0 bg-indigo-500/20 blur-xl rounded-full scale-150 animate-pulse"></div>
                  <Loader2 size={48} className="text-indigo-600 animate-spin relative" />
                </div>
                <div className="text-center space-y-2">
                  <p className="text-lg font-black tracking-tight">Omni Vision Decoding...</p>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.3em]">Extracting components and principles</p>
                </div>
              </div>
            )}

            {error && (
              <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-4 text-red-500">
                <AlertCircle size={24} />
                <p className="text-sm font-bold uppercase tracking-tight">{error}</p>
              </div>
            )}

            {analysis && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-700">
                <div className={cn(
                  "p-8 rounded-3xl border shadow-xl relative overflow-hidden",
                  theme === 'dark' ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
                )}>
                  {/* Decorative background mark */}
                  <div className="absolute top-0 right-0 p-4 opacity-5 rotate-12 scale-150 text-indigo-500 pointer-events-none">
                    <Maximize2 size={120} />
                  </div>

                  <div className="flex items-center gap-3 mb-8 relative">
                    <div className="w-8 h-8 bg-indigo-500/10 text-indigo-500 rounded-lg flex items-center justify-center font-black text-sm">
                      AI
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-widest text-slate-400">Analysis Output</h3>
                  </div>

                  <div className="prose prose-slate dark:prose-invert max-w-none markdown-body relative">
                    <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                      {analysis}
                    </Markdown>
                  </div>
                </div>

                <div className={cn(
                  "p-8 rounded-3xl border shadow-2xl space-y-4",
                  theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-indigo-50 border-indigo-100"
                )}>
                  <p className="text-[10px] font-black uppercase tracking-widest text-indigo-600 flex items-center gap-2">
                    <MessageSquare size={12} /> Interactive Query
                  </p>
                  <div className="flex gap-3">
                    <input 
                      type="text"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Ask a specific question about an element in this diagram..."
                      className={cn(
                        "flex-1 px-6 py-4 rounded-2xl text-sm font-bold transition-all focus:outline-none focus:ring-4 focus:ring-indigo-500/10",
                        theme === 'dark' 
                          ? "bg-slate-900 border border-slate-800 text-slate-100 placeholder:text-slate-700" 
                          : "bg-white border border-indigo-200 text-slate-800 placeholder:text-slate-400"
                      )}
                      onKeyDown={(e) => e.key === 'Enter' && query.trim() && handleAnalyze(query)}
                    />
                    <button 
                      onClick={() => handleAnalyze(query)}
                      disabled={isAnalyzing || !query.trim()}
                      className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-500 disabled:opacity-50 transition-all active:scale-95 shadow-xl shadow-indigo-600/20"
                    >
                      Analyze Query
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer Instructions */}
      {!image && !cameraActive && (
        <div className={cn(
          "p-6 border-t flex items-center justify-center gap-8",
          theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-100"
        )}>
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
            <CheckCircle2 size={14} className="text-indigo-500" />
            Flowcharts & Graphs
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
            <CheckCircle2 size={14} className="text-emerald-500" />
            Scientific Schematics
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
            <CheckCircle2 size={14} className="text-amber-500" />
            Biological Diagrams
          </div>
        </div>
      )}
    </div>
  );
};
