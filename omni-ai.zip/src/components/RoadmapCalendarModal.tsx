import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Calendar, Check, Play, Clock, Sparkles, AlertCircle, Trophy, 
  HelpCircle, Coffee, RotateCcw, ChevronLeft, ChevronRight, Wand2, 
  BookOpen, Compass, Flame, Smile, Hourglass, HelpCircle as HelpIcon, ArrowRight,
  Bell, BellRing
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { generateAIResponse } from '../lib/gemini';

interface Lesson {
  id: string;
  title: string;
  description: string;
  duration: string;
  level: string;
}

interface RoadmapWeek {
  weekNumber: number;
  title: string;
  chapters: string[];
  lessons: Lesson[];
  progressPercent: number;
  completedCount: number;
  totalCount: number;
  status: 'completed' | 'in_progress' | 'not_started';
}

interface RoadmapCalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  weeks: RoadmapWeek[];
  completedLessons: Record<string, boolean>;
  onToggleLesson: (chapterTitle: string, lessonId: string) => void;
  onStudyLesson: (lessonTitle: string, chapterTitle: string, depth?: 'quick' | 'standard' | 'deep' | 'academic') => void;
  subject: string;
  difficulty: string;
  boardName: string;
  theme: 'light' | 'dark';
  reminders: {
    id: string;
    weekNumber: number;
    weekTitle: string;
    subject: string;
    triggerTime: number;
    isActive: boolean;
  }[];
  onOpenReminderModal: (weekNumber: number, title: string) => void;
}

export const RoadmapCalendarModal: React.FC<RoadmapCalendarModalProps> = ({
  isOpen,
  onClose,
  weeks,
  completedLessons,
  onToggleLesson,
  onStudyLesson,
  subject,
  difficulty,
  boardName,
  theme,
  reminders,
  onOpenReminderModal
}) => {
  const [selectedWeekIdx, setSelectedWeekIdx] = useState<number>(0);
  const [showExplanation, setShowExplanation] = useState<string | null>(null);
  const [isGeneratingSchedule, setIsGeneratingSchedule] = useState(false);
  const [customSchedule, setCustomSchedule] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(`daily_schedule_${subject}`);
      return saved || '';
    } catch {
      return '';
    }
  });

  if (weeks.length === 0) return null;

  // Distribute lessons of the selected week into Mon-Sun calendar days
  const getWeeklyCalendarDays = (week: RoadmapWeek) => {
    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const distribution: Record<string, Lesson[]> = {
      'Monday': [], 'Tuesday': [], 'Wednesday': [], 'Thursday': [], 'Friday': [], 'Saturday': [], 'Sunday': []
    };

    const lessons = week.lessons;
    if (lessons.length === 0) return { distribution, daysOfWeek };

    if (lessons.length <= 3) {
      // 3 lessons: Monday, Wednesday, Friday
      const targetDays = ['Monday', 'Wednesday', 'Friday'];
      lessons.forEach((lesson, index) => {
        const day = targetDays[index % targetDays.length];
        distribution[day].push(lesson);
      });
    } else if (lessons.length <= 5) {
      // 5 lessons: Monday to Friday
      const targetDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
      lessons.forEach((lesson, index) => {
        const day = targetDays[index % targetDays.length];
        distribution[day].push(lesson);
      });
    } else {
      // 6 or more: Spread evenly Mon-Sun
      lessons.forEach((lesson, index) => {
        const day = daysOfWeek[index % daysOfWeek.length];
        distribution[day].push(lesson);
      });
    }

    return { distribution, daysOfWeek };
  };

  const currentWeek = weeks[selectedWeekIdx] || weeks[0];
  const { distribution, daysOfWeek } = getWeeklyCalendarDays(currentWeek);

  // Calculate stats
  const totalLessonsCount = weeks.reduce((acc, w) => acc + w.totalCount, 0);
  const completedLessonsCount = weeks.reduce((acc, w) => acc + w.completedCount, 0);
  const overallProgress = totalLessonsCount > 0 ? Math.round((completedLessonsCount / totalLessonsCount) * 100) : 0;
  
  // Calculate total study time
  const getDurationInMinutes = (durationStr: string): number => {
    const match = durationStr.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : 25;
  };

  const totalStudyMinutes = weeks.reduce((sum, w) => {
    let weekSum = 0;
    w.lessons.forEach(l => {
      const isCompleted = !!completedLessons[`${w.chapters[0]}_${l.id}`];
      if (isCompleted) {
        weekSum += getDurationInMinutes(l.duration);
      }
    });
    return sum + weekSum;
  }, 0);

  // Streak logic simulation using localStorage
  const studyStreak = (() => {
    try {
      const saved = localStorage.getItem(`study_streak_${subject}`);
      return saved ? parseInt(saved, 10) : Math.max(1, completedLessonsCount > 0 ? Math.min(7, Math.ceil(completedLessonsCount / 2)) : 0);
    } catch {
      return 1;
    }
  })();

  const handleGenerateAISchedule = async () => {
    setIsGeneratingSchedule(true);
    const prompt = `You are an expert AI Study Planner. Create a highly optimized day-by-day hourly schedule for Week ${currentWeek.weekNumber} of studying "${subject}" under the "${boardName}" curriculum.
Study Depth Level: ${difficulty}

Here are the lessons to plan for this week:
${currentWeek.lessons.map((l, i) => `Lesson ${i+1}: "${l.title}" - ${l.description} (Duration: ${l.duration})`).join('\n')}

Please generate a professional, practical time-boxed hourly planner for the study days (Monday to Sunday) that balances high cognitive load subjects with strategic breaks (using Pomodoro 25/5 or ultradian rhythm protocols). 
Include:
1. Hourly slots for active studying, revision, and active recall checks.
2. Formats for study blocks (e.g., 9:00 AM - 9:50 AM: Study, 9:50 AM - 10:00 AM: Rest).
3. Weekly integration checklist.

Format your output in a sleek, highly legible, clean layout with bullet points. Do not write raw Markdown block syntaxes like \`\`\`. Keep it compact and structured.`;

    try {
      const result = await generateAIResponse(prompt, {
        model: 'gemini-3.6-flash',
        systemInstruction: 'You are an elite academic productivity and time-management coach.'
      });
      if (result) {
        setCustomSchedule(result);
        try {
          localStorage.setItem(`daily_schedule_${subject}`, result);
        } catch (e) {
          console.error(e);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingSchedule(false);
    }
  };

  const handleClearSchedule = () => {
    setCustomSchedule('');
    try {
      localStorage.removeItem(`daily_schedule_${subject}`);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 overflow-y-auto">
          {/* Backdrop overlay */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-md cursor-pointer"
          />

          {/* Modal Container */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.92, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ type: "spring", damping: 25, stiffness: 350 }}
            className={cn(
              "relative w-full max-w-6xl h-full sm:h-auto sm:max-h-[92vh] flex flex-col rounded-none sm:rounded-3xl border shadow-2xl overflow-hidden z-10",
              theme === 'dark' 
                ? "bg-slate-900 border-slate-800 text-slate-100" 
                : "bg-slate-50 border-slate-200 text-slate-900"
            )}
          >
          {/* Header Bar */}
          <div className={cn(
            "p-5 flex items-center justify-between border-b shrink-0",
            theme === 'dark' ? "border-slate-800 bg-slate-900/90" : "border-slate-200 bg-white"
          )}>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-500/10 rounded-xl">
                <Calendar className="text-indigo-500" size={24} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-black tracking-tight">Academic Visual Calendar</h3>
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-2 py-0.5 rounded-full font-black uppercase">
                    Interactive Grid
                  </span>
                </div>
                <p className="text-xs opacity-60 font-medium">
                  {subject} &bull; {boardName} &bull; {difficulty}
                </p>
              </div>
            </div>
            
            <button 
              onClick={onClose}
              className="p-2 hover:bg-slate-250 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              <X size={20} className="opacity-60 hover:opacity-100" />
            </button>
          </div>

          {/* Quick Metrics Header Row */}
          <div className={cn(
            "px-6 py-4 grid grid-cols-2 md:grid-cols-4 gap-4 border-b shrink-0",
            theme === 'dark' ? "border-slate-800/80 bg-slate-900/40" : "border-slate-200 bg-slate-100/30"
          )}>
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-500 rounded-xl">
                <Compass size={18} />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Course Progress</span>
                <span className="text-base font-black">{overallProgress}%</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-500/10 text-emerald-500 rounded-xl">
                <Check size={18} />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Lessons Mastered</span>
                <span className="text-base font-black">{completedLessonsCount} / {totalLessonsCount}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-500/10 text-amber-500 rounded-xl">
                <Flame className="animate-pulse" size={18} />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Active Streak</span>
                <span className="text-base font-black">{studyStreak} Days</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-pink-500/10 text-pink-500 rounded-xl">
                <Clock size={18} />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Total Study Time</span>
                <span className="text-base font-black">
                  {Math.round(totalStudyMinutes / 60)}h {totalStudyMinutes % 60}m
                </span>
              </div>
            </div>
          </div>

          {/* Main Content Pane */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 min-h-0">
            {/* Week Selector Bar */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  disabled={selectedWeekIdx === 0}
                  onClick={() => setSelectedWeekIdx(p => p - 1)}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 disabled:opacity-30 cursor-pointer hover:bg-slate-150 dark:hover:bg-slate-850"
                >
                  <ChevronLeft size={16} />
                </button>
                <div className="text-center">
                  <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider block">Currently Viewing</span>
                  <span className="text-sm font-extrabold px-1">Week {currentWeek.weekNumber} of {weeks.length}</span>
                </div>
                <button
                  disabled={selectedWeekIdx === weeks.length - 1}
                  onClick={() => setSelectedWeekIdx(p => p + 1)}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 disabled:opacity-30 cursor-pointer hover:bg-slate-150 dark:hover:bg-slate-850"
                >
                  <ChevronRight size={16} />
                </button>
              </div>

              {/* Weekly Milestone Completion status */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => onOpenReminderModal(currentWeek.weekNumber, currentWeek.title)}
                  className={cn(
                    "py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border",
                    reminders.some(r => r.weekNumber === currentWeek.weekNumber && r.isActive)
                      ? "bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-400 hover:bg-amber-500/20"
                      : "bg-slate-100 dark:bg-slate-800 border-slate-250 dark:border-slate-700/80 hover:bg-indigo-600 hover:text-white"
                  )}
                >
                  {reminders.some(r => r.weekNumber === currentWeek.weekNumber && r.isActive) ? (
                    <>
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                      </span>
                      Reminder Active
                    </>
                  ) : (
                    <>
                      <Bell size={13} className="text-indigo-500 dark:text-indigo-400 group-hover:text-white" />
                      Set Week Reminder
                    </>
                  )}
                </button>

                {currentWeek.status === 'completed' ? (
                  <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/35 px-3 py-1.5 rounded-xl text-emerald-500 text-xs font-black">
                    <Trophy size={14} className="text-amber-500" />
                    Milestone Completed! 🏆
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 px-3 py-1.5 rounded-xl text-slate-400 dark:text-slate-500 text-xs font-bold">
                    <Hourglass size={14} className="animate-spin-slow" />
                    Milestone In Progress ({currentWeek.completedCount}/{currentWeek.totalCount})
                  </div>
                )}
              </div>
            </div>

            {/* Calendar Visual Grid / Matrix */}
            <div className="space-y-2">
              <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                <Calendar size={13} className="text-indigo-500" /> 7-Day Week Schedule View
              </h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-7 gap-3">
                {daysOfWeek.map((day) => {
                  const dayLessons = distribution[day] || [];
                  const hasLessons = dayLessons.length > 0;
                  
                  // Calculate daily completeness
                  const totalInDay = dayLessons.length;
                  const completedInDay = dayLessons.filter(l => !!completedLessons[`${currentWeek.chapters[0]}_${l.id}`]).length;
                  const isDayCompleted = totalInDay > 0 && completedInDay === totalInDay;
                  const isDayInProgress = totalInDay > 0 && completedInDay > 0 && completedInDay < totalInDay;

                  return (
                    <div 
                      key={day}
                      className={cn(
                        "rounded-xl border p-4.5 flex flex-col min-h-[140px] transition-all duration-300",
                        !hasLessons 
                          ? "bg-slate-100/50 dark:bg-slate-900/30 border-slate-200/50 dark:border-slate-800/40 opacity-70"
                          : isDayCompleted
                          ? "bg-emerald-500/[0.04] border-emerald-500/40 shadow-emerald-500/[0.02] shadow-md"
                          : isDayInProgress
                          ? "bg-amber-500/[0.03] border-amber-500/35 shadow-amber-500/[0.02]"
                          : theme === 'dark' ? "bg-slate-850/40 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                      )}
                    >
                      {/* Day Header */}
                      <div className="flex items-center justify-between border-b pb-2 mb-2 border-slate-150 dark:border-slate-800/80">
                        <span className="text-xs font-black tracking-tight">{day}</span>
                        {hasLessons ? (
                          isDayCompleted ? (
                            <span className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20">
                              <Check size={11} strokeWidth={4} />
                            </span>
                          ) : isDayInProgress ? (
                            <span className="text-[9px] bg-amber-500/10 text-amber-600 border border-amber-500/20 px-1.5 py-0.2 rounded-full font-bold">
                              {completedInDay}/{totalInDay}
                            </span>
                          ) : (
                            <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                          )
                        ) : (
                          <Coffee size={13} className="text-slate-400 opacity-60" />
                        )}
                      </div>

                      {/* Day Contents */}
                      <div className="flex-1 flex flex-col justify-between gap-3">
                        {hasLessons ? (
                          <div className="space-y-2">
                            {dayLessons.map((lesson) => {
                              const isCompleted = !!completedLessons[`${currentWeek.chapters[0]}_${lesson.id}`];
                              return (
                                <div 
                                  key={lesson.id} 
                                  className={cn(
                                    "p-2 rounded-lg border text-[11px] font-medium leading-relaxed group transition-all relative",
                                    isCompleted 
                                      ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300" 
                                      : "bg-slate-100/50 dark:bg-slate-900/40 border-slate-200/80 dark:border-slate-800 hover:border-indigo-500"
                                  )}
                                >
                                  <div className="flex items-start justify-between gap-1">
                                    <div className="space-y-0.5">
                                      <p className="font-extrabold line-clamp-2 leading-tight">{lesson.title}</p>
                                      <div className="flex items-center gap-1.5 opacity-60 text-[9px] font-semibold">
                                        <Clock size={9} /> {lesson.duration}
                                      </div>
                                    </div>
                                    <button
                                      onClick={() => onToggleLesson(currentWeek.chapters[0], lesson.id)}
                                      className={cn(
                                        "w-4.5 h-4.5 rounded border flex items-center justify-center cursor-pointer transition-colors shrink-0 mt-0.5",
                                        isCompleted 
                                          ? "bg-emerald-500 border-emerald-500 text-white" 
                                          : "border-slate-350 dark:border-slate-600 hover:border-indigo-500"
                                      )}
                                    >
                                      {isCompleted && <Check size={9} strokeWidth={4} />}
                                    </button>
                                  </div>
                                  
                                  {/* Explanation Hover Toggle */}
                                  <div className="mt-2 flex items-center justify-between gap-2 border-t pt-1.5 border-slate-200/50 dark:border-slate-800/50 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button 
                                      onClick={() => setShowExplanation(showExplanation === lesson.id ? null : lesson.id)}
                                      className="text-[9px] hover:text-indigo-500 flex items-center gap-0.5 cursor-pointer font-bold uppercase"
                                    >
                                      <HelpIcon size={9} /> Info
                                    </button>
                                    <button
                                      onClick={() => onStudyLesson(lesson.title, currentWeek.chapters[0])}
                                      className="text-[9px] text-indigo-500 hover:text-indigo-600 flex items-center gap-0.5 cursor-pointer font-extrabold uppercase"
                                    >
                                      Study <Play size={8} fill="currentColor" />
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <div className="flex-1 flex flex-col items-center justify-center py-4 text-center">
                            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Spacing Rest</span>
                            <span className="text-[9px] opacity-50 block mt-0.5 leading-snug">Review, revise, or self-study past milestones</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Interactive Lesson Explanation Dialog (Inline Animate) */}
            <AnimatePresence>
              {showExplanation && (() => {
                const explLesson = currentWeek.lessons.find(l => l.id === showExplanation);
                if (!explLesson) return null;
                return (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className={cn(
                      "p-4 rounded-xl border flex flex-col md:flex-row justify-between items-start md:items-center gap-4 animate-fadeIn",
                      theme === 'dark' ? "bg-indigo-950/20 border-indigo-900/55" : "bg-indigo-50/30 border-indigo-150"
                    )}
                  >
                    <div className="space-y-1 max-w-3xl">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] uppercase font-black bg-indigo-500/10 text-indigo-500 px-1.5 py-0.5 rounded">
                          Lesson Abstract
                        </span>
                        <h5 className="font-extrabold text-xs">{explLesson.title}</h5>
                      </div>
                      <p className="text-xs opacity-80 leading-relaxed">
                        {explLesson.description}
                      </p>
                    </div>
                    <div className="flex items-center gap-2.5 shrink-0 self-end md:self-auto">
                      <button 
                        onClick={() => onStudyLesson(explLesson.title, currentWeek.chapters[0])}
                        className="py-1 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-black cursor-pointer transition-colors"
                      >
                        Study Lesson Now
                      </button>
                      <button 
                        onClick={() => setShowExplanation(null)}
                        className="py-1 px-2.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
                      >
                        Dismiss
                      </button>
                    </div>
                  </motion.div>
                );
              })()}
            </AnimatePresence>

            {/* AI Daily Planner section */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start pt-2">
              <div className="lg:col-span-12 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                    <Sparkles size={13} className="text-amber-500" /> Hourly Study Block Planner
                  </h4>
                  {customSchedule && (
                    <button
                      onClick={handleClearSchedule}
                      className="text-[10px] text-pink-500 hover:text-pink-600 font-bold flex items-center gap-1 cursor-pointer uppercase"
                    >
                      <RotateCcw size={10} /> Reset Schedule
                    </button>
                  )}
                </div>

                <div className={cn(
                  "p-5 rounded-2xl border space-y-4",
                  theme === 'dark' ? "bg-slate-850/40 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                )}>
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="space-y-1">
                      <h5 className="font-extrabold text-sm flex items-center gap-1.5 text-indigo-500">
                        <Wand2 size={15} className="text-amber-500 animate-pulse" />
                        Optimize Daily Hourly Blocks with Omni AI
                      </h5>
                      <p className="text-xs opacity-70 max-w-2xl">
                        Based on the distributed 7-day visual calendar, let Omni AI structure specific, optimal study times, revision buffers, and memory checkpoints.
                      </p>
                    </div>

                    <button
                      onClick={handleGenerateAISchedule}
                      disabled={isGeneratingSchedule}
                      className="w-full sm:w-auto py-2 px-4.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md hover:shadow-lg self-end sm:self-auto shrink-0"
                    >
                      {isGeneratingSchedule ? (
                        <>
                          <RotateCcw size={12} className="animate-spin" />
                          Structuring Schedule...
                        </>
                      ) : (
                        <>
                          <Wand2 size={12} />
                          Generate Hourly Schedule
                        </>
                      )}
                    </button>
                  </div>

                  {customSchedule ? (
                    <div className={cn(
                      "p-4 rounded-xl border max-h-[320px] overflow-y-auto text-xs leading-relaxed font-medium whitespace-pre-line shadow-inner",
                      theme === 'dark' ? "bg-slate-900/90 border-slate-850 text-slate-300" : "bg-slate-100/60 border-slate-200 text-slate-700"
                    )}>
                      <div className="prose prose-xs dark:prose-invert space-y-2">
                        {customSchedule}
                      </div>
                    </div>
                  ) : (
                    <div className={cn(
                      "p-6 rounded-xl border text-center space-y-2",
                      theme === 'dark' ? "bg-slate-900/35 border-slate-800" : "bg-slate-50 border-slate-150"
                    )}>
                      <Smile size={24} className="text-indigo-400 mx-auto opacity-70" />
                      <p className="text-xs font-bold opacity-80">No AI-optimized daily hourly block generated yet.</p>
                      <p className="text-[10px] opacity-60 max-w-md mx-auto leading-relaxed">
                        Click the button above to have Omni AI construct a highly practical, stress-tested time management study schedule for your Week {currentWeek.weekNumber} content!
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Footer controls */}
          <div className={cn(
            "p-4 flex items-center justify-between border-t shrink-0 bg-slate-100/10",
            theme === 'dark' ? "border-slate-800 bg-slate-900/90" : "border-slate-200 bg-white"
          )}>
            <div className="text-[10px] opacity-50 font-bold flex items-center gap-1.5">
              <AlertCircle size={12} /> Click checkmarks on the study calendar to toggle progress.
            </div>
            <button
              onClick={onClose}
              className="py-1.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-extrabold cursor-pointer transition-all shadow-md hover:shadow-lg"
            >
              Close Calendar View
            </button>
          </div>
        </motion.div>
      </div>
      )}
    </AnimatePresence>
  );
};
