import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, Sparkles, X, Plus, Trash2, Sliders, ChevronLeft, ChevronRight, 
  BookOpen, HelpCircle, AlertCircle, RefreshCw, Award, Compass, GraduationCap, Activity,
  Check
} from 'lucide-react';
import { collection, addDoc, getDocs, query, where, orderBy, writeBatch, doc, limit } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../../lib/firebase';
import { ContextManager, LearningContext } from './ContextManager';
import { Guardrails } from './Guardrails';
import { MessageInput } from './MessageInput';
import { AIResponse } from './AIResponse';
import { generateAIResponse } from '../../lib/gemini';
import { cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

interface ChatMessage {
  id: string;
  studentId: string;
  role: 'student' | 'ai' | 'system';
  content: string;
  contentType: 'text' | 'image' | 'latex' | 'voice';
  context?: {
    chapterId?: string;
    topicId?: string;
    currentTimestamp?: number;
  };
  createdAt: string;
}

interface ChatSession {
  id: string;
  studentId: string;
  title: string;
  subject?: string;
  topic?: string;
  messageCount: number;
  createdAt: string;
  updatedAt: string;
}

interface ChatSidebarProps {
  currentSubject?: string;
  currentChapterId?: string;
  currentChapterTitle?: string;
  currentTopicId?: string;
  currentTopicTitle?: string;
  language?: string;
}

export const ChatSidebar: React.FC<ChatSidebarProps> = ({
  currentSubject = 'General Science',
  currentChapterId = '',
  currentChapterTitle = '',
  currentTopicId = '',
  currentTopicTitle = '',
  language = 'en'
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSession, setActiveSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [sendingSeconds, setSendingSeconds] = useState(0);

  useEffect(() => {
    let interval: any = null;
    if (isSending) {
      setSendingSeconds(0);
      interval = setInterval(() => {
        setSendingSeconds(prev => prev + 1);
      }, 1000);
    } else {
      setSendingSeconds(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isSending]);

  const [learningStyle, setLearningStyle] = useState<'conceptual' | 'socratic' | 'practical' | 'visual'>('conceptual');
  const [showSettings, setShowSettings] = useState(false);
  const [isCreatingSession, setIsCreatingSession] = useState(false);
  const [newSessionTitle, setNewSessionTitle] = useState('');

  // Floating trigger position and collision-free drag management
  const [position, setPosition] = useState<{ x: number | null; y: number | null }>(() => {
    try {
      const saved = localStorage.getItem('omni_assistant_pos');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.x === 'number' && typeof parsed.y === 'number') {
          return parsed;
        }
      }
    } catch {}
    return { x: null, y: null };
  });

  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number; hasMoved: boolean }>({
    startX: 0,
    startY: 0,
    initialX: 0,
    initialY: 0,
    hasMoved: false
  });

  const handlePointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0) return;
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();

    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: rect.left,
      initialY: rect.top,
      hasMoved: false
    };

    const handlePointerMove = (moveEvent: PointerEvent) => {
      const deltaX = moveEvent.clientX - dragStartRef.current.startX;
      const deltaY = moveEvent.clientY - dragStartRef.current.startY;

      if (!dragStartRef.current.hasMoved && (Math.abs(deltaX) > 4 || Math.abs(deltaY) > 4)) {
        dragStartRef.current.hasMoved = true;
        setIsDragging(true);
      }

      if (dragStartRef.current.hasMoved) {
        const newX = Math.min(Math.max(12, dragStartRef.current.initialX + deltaX), window.innerWidth - 64);
        const newY = Math.min(Math.max(70, dragStartRef.current.initialY + deltaY), window.innerHeight - 90);
        setPosition({ x: newX, y: newY });
      }
    };

    const handlePointerUp = () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);

      if (dragStartRef.current.hasMoved) {
        setTimeout(() => setIsDragging(false), 50);
        setPosition(prev => {
          if (prev.x !== null && prev.y !== null) {
            try {
              localStorage.setItem('omni_assistant_pos', JSON.stringify(prev));
            } catch {}
          }
          return prev;
        });
      }
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
  };

  const messageEndRef = useRef<HTMLDivElement>(null);

  // Load context on startup
  useEffect(() => {
    const ctx = ContextManager.getContext();
    if (ctx.learningStyle) {
      setLearningStyle(ctx.learningStyle);
    }
  }, []);

  // Listen to global open chat events
  useEffect(() => {
    const handleOpenEvent = () => setIsOpen(true);
    const handleToggleEvent = () => setIsOpen(prev => !prev);

    window.addEventListener('open_ai_tutor_chat', handleOpenEvent);
    window.addEventListener('open_chat_sidebar', handleOpenEvent);
    window.addEventListener('toggle_ai_tutor_chat', handleToggleEvent);

    return () => {
      window.removeEventListener('open_ai_tutor_chat', handleOpenEvent);
      window.removeEventListener('open_chat_sidebar', handleOpenEvent);
      window.removeEventListener('toggle_ai_tutor_chat', handleToggleEvent);
    };
  }, []);

  // Update ContextManager whenever active lesson changes in the parent app
  useEffect(() => {
    if (currentSubject && currentChapterId) {
      ContextManager.updateActiveLesson(
        currentSubject,
        currentChapterId,
        currentChapterTitle,
        currentTopicId,
        currentTopicTitle,
        language
      );
    } else if (language) {
      ContextManager.saveContext({ language });
    }
  }, [currentSubject, currentChapterId, currentChapterTitle, currentTopicId, currentTopicTitle, language]);

  const defaultWelcomeSession: ChatSession = {
    id: 'active_welcome',
    studentId: 'omni_student',
    title: '🎓 Live AI Tutor Session',
    subject: 'Syllabus Help',
    topic: 'Get Started',
    messageCount: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const defaultWelcomeMessage: ChatMessage = {
    id: 'msg_welcome',
    studentId: 'omni_student',
    role: 'ai',
    content: `Hello! I am your **Omni AI Tutor**. I'm connected online to Gemini AI models and ready 24/7 to help you master any subject, formula, or exam problem! 

Tell me what you are studying or upload a photo of a question, and I'll explain it using simple analogies, step-by-step mathematical formulas, and real-world examples. How can I help you excel today?`,
    contentType: 'text',
    createdAt: new Date().toISOString()
  };

  // Helper to read local messages cache
  const getStoredMessages = (sessionId: string): ChatMessage[] | null => {
    try {
      const stored = localStorage.getItem(`omni_offline_messages_${sessionId}`) || 
                     (sessionId === 'active_welcome' ? localStorage.getItem('omni_offline_messages_offline_welcome') : null);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return null;
  };

  // Load Sessions on mount/auth change (merges online Firestore and persistent sessions)
  useEffect(() => {
    const fetchSessions = async () => {
      // 1. Get or create local sessions cache
      let localSessionsList: ChatSession[] = [];
      try {
        const local = localStorage.getItem('omni_offline_chat_sessions');
        if (local) {
          localSessionsList = JSON.parse(local);
          // Migrate old session titles if present
          localSessionsList = localSessionsList.map(s => {
            if (s.id === 'offline_welcome' || s.title === 'Offline Welcome Tutorial') {
              return { ...s, id: 'active_welcome', title: '🎓 Live AI Tutor Session' };
            }
            return s;
          });
        }
      } catch (e) {
        console.warn("Failed reading local chat sessions", e);
      }

      if (!localSessionsList || localSessionsList.length === 0) {
        localSessionsList = [defaultWelcomeSession];
        try {
          localStorage.setItem('omni_offline_chat_sessions', JSON.stringify(localSessionsList));
          if (!getStoredMessages('active_welcome')) {
            localStorage.setItem('omni_offline_messages_active_welcome', JSON.stringify([defaultWelcomeMessage]));
          }
        } catch (e) {}
      }

      const user = auth.currentUser;
      if (!user) {
        // Unauthenticated / offline: load local sessions
        setSessions(localSessionsList);
        if (localSessionsList.length > 0) {
          handleSelectSession(localSessionsList[0]);
        }
        setIsLoading(false);
        return;
      }

      // 2. Authenticated Online Mode: Load Firestore sessions and merge with local sessions
      setIsLoading(true);
      const path = 'chat_sessions';
      try {
        const q = query(
          collection(db, path),
          where('userId', '==', user.uid),
          orderBy('updatedAt', 'desc'),
          limit(20)
        );
        const snap = await getDocs(q);
        const loaded: ChatSession[] = [];
        snap.forEach(doc => {
          const data = doc.data();
          loaded.push({
            id: doc.id,
            studentId: data.userId,
            title: data.title,
            subject: data.subject,
            topic: data.topic,
            messageCount: data.messageCount || 0,
            createdAt: data.createdAt ? new Date(data.createdAt).toISOString() : new Date().toISOString(),
            updatedAt: data.updatedAt ? new Date(data.updatedAt).toISOString() : new Date().toISOString()
          });
        });

        // Merge Firestore sessions with default live session
        const mergedMap = new Map<string, ChatSession>();
        localSessionsList.forEach(s => mergedMap.set(s.id, s));
        loaded.forEach(s => mergedMap.set(s.id, s));
        const combined = Array.from(mergedMap.values());

        setSessions(combined);
        if (combined.length > 0) {
          handleSelectSession(combined[0]);
        }
      } catch (err) {
        console.warn("Firestore error loading sessions, using local fallback:", err);
        setSessions(localSessionsList);
        if (localSessionsList.length > 0) {
          handleSelectSession(localSessionsList[0]);
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchSessions();
  }, [auth.currentUser]);

  // Handle local offline backup
  const loadLocalSessions = () => {
    try {
      const local = localStorage.getItem('omni_offline_chat_sessions');
      if (local) {
        const parsed = JSON.parse(local);
        setSessions(parsed);
        if (parsed.length > 0) {
          handleSelectSession(parsed[0]);
        }
      } else {
        setSessions([defaultWelcomeSession]);
        setActiveSession(defaultWelcomeSession);
        setMessages([defaultWelcomeMessage]);
        localStorage.setItem('omni_offline_chat_sessions', JSON.stringify([defaultWelcomeSession]));
        localStorage.setItem('omni_offline_messages_active_welcome', JSON.stringify([defaultWelcomeMessage]));
      }
    } catch (e) {
      console.error("Local storage read failed", e);
    }
  };

  const handleSelectSession = async (session: ChatSession) => {
    setActiveSession(session);
    
    // Check local storage for messages cache first
    const cached = getStoredMessages(session.id);
    if (cached) {
      setMessages(cached);
    } else if (session.id === 'active_welcome' || session.id === 'offline_welcome') {
      setMessages([defaultWelcomeMessage]);
      try {
        localStorage.setItem(`omni_offline_messages_${session.id}`, JSON.stringify([defaultWelcomeMessage]));
      } catch (e) {}
    }

    const user = auth.currentUser;
    if (!user || session.id === 'active_welcome' || session.id === 'offline_welcome' || session.id.startsWith('offline_') || session.id.startsWith('session_') || session.id.startsWith('temp_')) {
      return;
    }

    // Load from Firestore nested path
    setIsLoading(true);
    const path = `chat_sessions/${session.id}/messages`;
    try {
      const q = query(collection(db, path), orderBy('createdAt', 'asc'));
      const snap = await getDocs(q);
      const loaded: ChatMessage[] = [];
      snap.forEach(doc => {
        const data = doc.data();
        loaded.push({
          id: doc.id,
          studentId: data.studentId,
          role: data.role,
          content: data.content,
          contentType: data.contentType,
          context: data.context,
          createdAt: data.createdAt
        });
      });

      if (loaded.length > 0) {
        setMessages(loaded);
        localStorage.setItem(`omni_offline_messages_${session.id}`, JSON.stringify(loaded));
      }
    } catch (err: any) {
      if (err?.code !== 'permission-denied' && err?.code !== 'unauthenticated') {
        console.warn("Firestore error loading messages, using local cache:", err);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleInlineCreateSubmit = async () => {
    const title = newSessionTitle.trim();
    if (title) {
      await handleCreateSession(title);
    }
    setIsCreatingSession(false);
    setNewSessionTitle('');
  };

  const handleCreateSession = async (title: string, selectImmediately = true) => {
    const user = auth.currentUser;
    const cleanTitle = title.trim() || `Study Session (${currentSubject})`;
    
    const newSessionData = {
      title: cleanTitle,
      subject: currentSubject || 'General Science',
      topic: currentTopicTitle || 'Introductory Concept',
      messageCount: 0,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    if (!user) {
      // Local session creation
      const localSession: ChatSession = {
        id: `offline_${Date.now()}`,
        studentId: 'offline_student',
        ...newSessionData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      const updated = [localSession, ...sessions];
      setSessions(updated);
      localStorage.setItem('omni_offline_chat_sessions', JSON.stringify(updated));
      
      if (selectImmediately) {
        setActiveSession(localSession);
        const welcomeMsg: ChatMessage = {
          id: `msg_welcome_${Date.now()}`,
          studentId: 'offline_student',
          role: 'ai',
          content: `Started study session for **${cleanTitle}** (${newSessionData.subject}). How can I help you learn this topic?`,
          contentType: 'text',
          createdAt: new Date().toISOString()
        };
        setMessages([welcomeMsg]);
        localStorage.setItem(`omni_offline_messages_${localSession.id}`, JSON.stringify([welcomeMsg]));
      }
      return;
    }

    // Server-side Firestore session creation
    const path = 'chat_sessions';
    try {
      const docRef = await addDoc(collection(db, path), {
        userId: user.uid,
        ...newSessionData,
        id: `temp_${Date.now()}` // temporary fallback placeholder
      });

      const session: ChatSession = {
        id: docRef.id,
        studentId: user.uid,
        ...newSessionData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      setSessions(prev => [session, ...prev]);

      if (selectImmediately) {
        setActiveSession(session);
        setMessages([]);
        // Add default tutor welcome message
        const welcomeText = `Let's work together on **${cleanTitle}** in ${session.subject}! 
What formula, problem, or concept should we review first?`;
        
        await handleSaveMessage(session.id, 'ai', welcomeText, 'text');
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  };

  const handleSaveMessage = async (
    sessionId: string, 
    role: 'student' | 'ai' | 'system', 
    content: string, 
    contentType: 'text' | 'image' | 'latex' | 'voice',
    contextData?: any
  ): Promise<ChatMessage> => {
    const user = auth.currentUser;
    const msgData: Omit<ChatMessage, 'id'> = {
      studentId: user ? user.uid : 'omni_student',
      role,
      content,
      contentType,
      context: contextData || {
        chapterId: currentChapterId || undefined,
        topicId: currentTopicId || undefined
      },
      createdAt: new Date().toISOString()
    };

    const tempId = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    const msg: ChatMessage = {
      id: tempId,
      ...msgData
    };

    // Instant UI update and local cache persistence
    setMessages(prev => {
      const updated = [...prev, msg];
      try {
        localStorage.setItem(`omni_offline_messages_${sessionId}`, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    // Asynchronously save to Firestore when user is signed in and session is a cloud session
    if (user && !sessionId.startsWith('offline_') && !sessionId.startsWith('active_')) {
      const path = `chat_sessions/${sessionId}/messages`;
      try {
        const docRef = await addDoc(collection(db, path), msgData);
        msg.id = docRef.id;
      } catch (err) {
        console.warn("Firestore message save skipped/fallback to local cache:", err);
      }
    }

    return msg;
  };

  const handleDeleteSession = async (sessionToDelete: ChatSession, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }

    const targetId = sessionToDelete.id;
    const user = auth.currentUser;

    // 1. Immediately wipe active messages state if this is the active session
    if (activeSession?.id === targetId) {
      setMessages([]);
    }

    // 2. Remove all cached messages for this session from localStorage
    try {
      localStorage.removeItem(`omni_offline_messages_${targetId}`);
      if (targetId === 'active_welcome' || targetId === 'offline_welcome') {
        localStorage.removeItem('omni_offline_messages_active_welcome');
        localStorage.removeItem('omni_offline_messages_offline_welcome');
      }
    } catch (err) {}

    // 3. Filter session from state and local storage
    const filtered = sessions.filter(s => s.id !== targetId);

    if (filtered.length === 0) {
      // Create a fresh clean session if all sessions were deleted
      const freshSession: ChatSession = {
        id: `session_${Date.now()}`,
        studentId: user?.uid || 'omni_student',
        title: currentChapterTitle ? `🎓 ${currentChapterTitle}` : '🎓 New Study Session',
        subject: currentSubject || 'Syllabus Help',
        topic: currentChapterTitle || 'Get Started',
        messageCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      setSessions([freshSession]);
      setActiveSession(freshSession);
      setMessages([]);
      try {
        localStorage.setItem('omni_offline_chat_sessions', JSON.stringify([freshSession]));
        localStorage.removeItem(`omni_offline_messages_${freshSession.id}`);
      } catch (err) {}
    } else {
      setSessions(filtered);
      try {
        localStorage.setItem('omni_offline_chat_sessions', JSON.stringify(filtered));
      } catch (err) {}

      if (activeSession?.id === targetId) {
        handleSelectSession(filtered[0]);
      }
    }

    // 4. Cleanly delete from cloud Firestore if user is signed in and it's a cloud session
    if (user && !targetId.startsWith('offline_') && !targetId.startsWith('active_')) {
      try {
        // Fetch subcollection message documents to delete atomically
        const messagesPath = `chat_sessions/${targetId}/messages`;
        const msgsSnap = await getDocs(collection(db, messagesPath));
        
        const batch = writeBatch(db);
        msgsSnap.forEach((mDoc) => {
          batch.delete(doc(db, messagesPath, mDoc.id));
        });
        batch.delete(doc(db, 'chat_sessions', targetId));
        
        await batch.commit();
      } catch (err) {
        console.warn("Firestore session and messages delete error:", err);
      }
    }
  };

  // Core Send query logic to Gemini Server API
  const handleSendMessage = async (text: string, contentType: 'text' | 'image' | 'latex' | 'voice', imageBase64?: string) => {
    if (!activeSession) {
      await handleCreateSession(`Study Session (${currentSubject || 'General'})`, true);
    }

    const targetSession = activeSession || sessions[0];
    if (!targetSession) return;

    // Check Guardrails first
    const guardrail = Guardrails.checkQuery(text);
    if (!guardrail.passed) {
      // Add system/AI warning message directly inside chat without calling backend API
      const warnMsg: ChatMessage = {
        id: `warn_${Date.now()}`,
        studentId: targetSession.studentId,
        role: 'system',
        content: guardrail.suggestedResponse || 'Please stay on topic.',
        contentType: 'text',
        createdAt: new Date().toISOString()
      };
      setMessages(prev => [...prev, warnMsg]);
      return;
    }

    // Apply Socratic pedagogical constraints if helpful
    const processedQueryText = Guardrails.enforcePedagogicalSocrates(text);

    // Save user's question locally/cloud
    let displayContent = text;
    if (contentType === 'image') {
      displayContent = text ? `[Uploaded Problem Image] ${text}` : '[Uploaded Problem Image]';
    }
    await handleSaveMessage(targetSession.id, 'student', displayContent, contentType);
    
    setIsSending(true);
    scrollToBottom();

    try {
      // Get System Instructions based on current context
      const ctx = ContextManager.getContext();
      ctx.learningStyle = learningStyle;
      if (currentSubject) ctx.currentSubject = currentSubject;
      if (currentChapterTitle) ctx.currentChapterTitle = currentChapterTitle;
      if (currentTopicTitle) ctx.currentTopicTitle = currentTopicTitle;
      if (language) ctx.language = language;

      const systemInstruction = ContextManager.getSystemInstructions(ctx);

      // Build alternating multi-turn history for Gemini API starting with user turn
      const validHistory = messages.filter(m => m.content && m.content.trim().length > 0);
      const firstStudentIdx = validHistory.findIndex(m => m.role === 'student');
      const filteredHistory = firstStudentIdx !== -1 ? validHistory.slice(firstStudentIdx).slice(-6) : [];

      const contentsPayload: any[] = [];
      let lastRole: string | null = null;

      for (const m of filteredHistory) {
        const role = m.role === 'student' ? 'user' : 'model';
        if (role === lastRole && contentsPayload.length > 0) {
          // Merge consecutive same-role text
          const lastTurn = contentsPayload[contentsPayload.length - 1];
          lastTurn.parts[0].text += `\n\n${m.content}`;
        } else {
          contentsPayload.push({
            role,
            parts: [{ text: m.content }]
          });
          lastRole = role;
        }
      }

      // Prepare final current query parts
      const userParts: any[] = [];
      if (contentType === 'image' && imageBase64) {
        userParts.push({
          inlineData: {
            mimeType: 'image/jpeg',
            data: imageBase64
          }
        });
      }
      userParts.push({ text: processedQueryText });

      if (lastRole === 'user' && contentsPayload.length > 0) {
        contentsPayload[contentsPayload.length - 1].parts.push(...userParts);
      } else {
        contentsPayload.push({
          role: 'user',
          parts: userParts
        });
      }

      // Call online Gemini API via centralized generateAIResponse
      const aiReplyText = await generateAIResponse(processedQueryText, {
        model: 'gemini-3.8-flash',
        systemInstruction: systemInstruction,
        contents: contentsPayload
      });

      // Save AI Response
      await handleSaveMessage(targetSession.id, 'ai', aiReplyText || "Let's break this down step-by-step. What is the fundamental concept or formula you'd like to explore?", 'text');
    } catch (err: any) {
      console.error("AI tutor response error:", err);
      // Helpful pedagogical fallback if offline or network failure
      const fallbackReplies = [
        "Let's break this problem down systematically: 1) Identify the known variables and units, 2) State the fundamental governing formula, and 3) Rearrange the equation to isolate the target unknown before calculating.",
        "Here is a key conceptual tip: Always draw a free-body diagram or molecular schematic first. What is the primary relationship between the variables in this topic?",
        "To master this topic: Review the standard SI unit conversions first, then apply the formula step-by-step to avoid common calculation traps."
      ];
      const selectedFallback = fallbackReplies[Math.floor(Math.random() * fallbackReplies.length)];
      await handleSaveMessage(targetSession.id, 'ai', selectedFallback, 'text');
    } finally {
      setIsSending(false);
      scrollToBottom();
    }
  };

  // Server-side Text-To-Speech Synthesis helper
  const handleSynthesizeSpeech = async (text: string, voice: string): Promise<string> => {
    try {
      const response = await fetch('/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'speech',
          prompt: text,
          voiceName: voice
        })
      });

      if (!response.ok) {
        throw new Error("Speech synthesis failed");
      }

      const data = await response.json();
      return data.audio; // Return base64 representation
    } catch (e) {
      // Fallback to Google TTS action if standard flash speech model errors
      try {
        const response = await fetch('/api/gemini', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'googleSpeech',
            prompt: text,
            voiceName: 'en'
          })
        });
        const data = await response.json();
        return data.audio;
      } catch (innerErr) {
        throw new Error("All TTS engines failed");
      }
    }
  };

  const handleStyleChange = (style: 'conceptual' | 'socratic' | 'practical' | 'visual') => {
    setLearningStyle(style);
    ContextManager.saveContext({ learningStyle: style });
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 80);
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  return (
    <>
      {/* Floating Trigger Badge - Drag-to-position, elevated clearance & hidden when drawer is open */}
      {!isOpen && (
        <div
          style={
            position.x !== null && position.y !== null
              ? { left: `${position.x}px`, top: `${position.y}px`, right: 'auto', bottom: 'auto' }
              : undefined
          }
          onPointerDown={handlePointerDown}
          className={cn(
            "fixed z-[2500] select-none touch-none",
            position.x === null && "bottom-24 md:bottom-20 right-4 sm:right-6",
            isDragging ? "cursor-grabbing scale-105" : "cursor-grab"
          )}
        >
          <button
            type="button"
            onClick={(e) => {
              if (dragStartRef.current.hasMoved) {
                e.preventDefault();
                e.stopPropagation();
                return;
              }
              setIsOpen(true);
            }}
            className="bg-indigo-600/95 hover:bg-indigo-500 text-white p-3 sm:p-3.5 rounded-full shadow-2xl shadow-indigo-600/40 active:scale-95 transition-transform flex items-center justify-center gap-2 group border border-indigo-400/30 cursor-pointer backdrop-blur-md"
            title="Open Omni Assistant (Drag to reposition anywhere)"
            aria-label="Open Omni Assistant"
          >
            <Sparkles className="w-5 h-5 animate-pulse text-amber-300 shrink-0" />
            <span className="font-extrabold text-xs max-w-0 overflow-hidden group-hover:max-w-[140px] transition-all duration-300 ease-out uppercase tracking-widest whitespace-nowrap">
              Omni assistant
            </span>
          </button>
        </div>
      )}

      {/* Backdrop overlay when open on mobile/tablet */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-[2490] md:hidden animate-in fade-in duration-200"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Persistent / Collapsible Sidebar Container */}
      <div className={`fixed top-0 right-0 h-screen w-full md:w-[420px] bg-slate-950 text-white border-l border-slate-800 z-[2500] shadow-2xl transition-all duration-300 ease-in-out flex flex-col transform ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
        
        {/* Header bar */}
        <div className="bg-slate-900 border-b border-slate-800 p-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <GraduationCap className="w-6 h-6 text-indigo-400" />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xs font-black tracking-widest uppercase text-slate-400">Omni AI Ultimate</h2>
                <span className="flex items-center gap-1 text-[9px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Online AI 24/7
                </span>
              </div>
              <h3 className="text-xs font-black text-indigo-300">Syllabus Private Tutor</h3>
            </div>
          </div>
          
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${
                showSettings 
                  ? 'bg-indigo-600 text-white' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
              title="Pedagogical Settings"
            >
              <Sliders className="w-4 h-4" />
            </button>
            
            <button
              onClick={() => setIsOpen(false)}
              className="p-2 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Learning Settings overlay inside sidebar */}
        {showSettings ? (
          <div className="bg-slate-900/95 border-b border-slate-800 p-4 space-y-4 shrink-0 transition-all animate-fadeIn relative z-20">
            <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
              <Compass className="w-4 h-4" /> Customize AI Teaching Scaffolding
            </h4>
            
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'conceptual', title: 'Conceptual Explanation', desc: 'Focus on variables and formulas' },
                { id: 'socratic', title: 'Socratic Dialogue', desc: 'Guiding hints, no direct answers' },
                { id: 'practical', title: 'Practical Careers', desc: 'Link to aerospace/protein builds' },
                { id: 'visual', title: 'Visual Diagrams', desc: 'Prioritize SVG diagrams & graphs' }
              ].map((style) => (
                <button
                  key={style.id}
                  onClick={() => handleStyleChange(style.id as any)}
                  className={`p-2.5 rounded-xl border text-left transition-all space-y-0.5 ${
                    learningStyle === style.id
                      ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  <span className="text-xs font-bold block">{style.title}</span>
                  <span className="text-[9px] block leading-normal opacity-80">{style.desc}</span>
                </button>
              ))}
            </div>

            <div className="border-t border-slate-800 pt-3 flex items-center justify-between">
              <span className="text-[10px] text-slate-500 font-extrabold uppercase">Tutor Active State</span>
              <button
                onClick={() => setShowSettings(false)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-[10px] px-3 py-1.5 rounded-lg transition-all"
              >
                Apply Customizations
              </button>
            </div>
          </div>
        ) : null}

        {/* Current contextual syllabus target indicator */}
        {currentChapterTitle && (
          <div className="bg-indigo-950/50 px-4 py-2 border-b border-slate-800 shrink-0 text-xs flex items-center justify-between text-indigo-300">
            <span className="flex items-center gap-1.5 font-bold truncate">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <span>Context: {currentSubject} &rarr; {currentChapterTitle}</span>
            </span>
            <span className="text-[9px] bg-indigo-500/20 px-2 py-0.5 rounded-full font-black text-indigo-300 uppercase shrink-0">In Sync</span>
          </div>
        )}

        {/* Core Chat Scrollable Pane */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950">
          
          {/* Active Session switching control */}
          <div className="flex items-center justify-between bg-slate-900/60 p-2 rounded-xl border border-slate-800/80 mb-2 gap-2 min-h-[46px]">
            {isCreatingSession ? (
              <div className="flex-1 flex items-center gap-1.5 animate-in slide-in-from-right duration-200">
                <input
                  type="text"
                  autoFocus
                  placeholder="Enter session topic..."
                  value={newSessionTitle}
                  onChange={(e) => setNewSessionTitle(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleInlineCreateSubmit();
                    } else if (e.key === 'Escape') {
                      setIsCreatingSession(false);
                      setNewSessionTitle('');
                    }
                  }}
                  className="flex-1 bg-slate-950 border border-indigo-500/50 rounded-lg px-2 py-1 text-xs font-bold text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                />
                <button
                  onClick={handleInlineCreateSubmit}
                  className="p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-all cursor-pointer flex items-center justify-center shrink-0"
                  title="Create Session"
                >
                  <Check className="w-3 h-3" />
                </button>
                <button
                  onClick={() => {
                    setIsCreatingSession(false);
                    setNewSessionTitle('');
                  }}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg transition-all cursor-pointer flex items-center justify-center shrink-0"
                  title="Cancel"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <>
                <select
                  value={activeSession?.id || ''}
                  onChange={(e) => {
                    const target = sessions.find(s => s.id === e.target.value);
                    if (target) handleSelectSession(target);
                  }}
                  className="flex-1 bg-transparent border-none text-xs font-bold text-slate-300 outline-none cursor-pointer pr-4 truncate"
                >
                  {sessions.map((s) => (
                    <option key={s.id} value={s.id} className="bg-slate-900 text-slate-300">
                      📂 {s.title}
                    </option>
                  ))}
                </select>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => {
                      setIsCreatingSession(true);
                      setNewSessionTitle('');
                    }}
                    className="p-1.5 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white rounded-lg transition-all cursor-pointer flex items-center justify-center"
                    title="Create a new study session"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>

                  {activeSession && (
                    <button
                      onClick={(e) => handleDeleteSession(activeSession, e)}
                      className="p-1.5 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white rounded-lg transition-all cursor-pointer flex items-center justify-center"
                      title="Delete active study session"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </>
            )}
          </div>

          {isLoading && messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 gap-3 text-slate-500 animate-pulse">
              <RefreshCw className="w-8 h-8 animate-spin text-indigo-500" />
              <p className="text-xs font-bold uppercase tracking-widest">Loading Syllabus Chat Files...</p>
            </div>
          ) : (
            messages.map((msg, idx) => {
              const isAI = msg.role === 'ai';
              const isSystem = msg.role === 'system';

              if (isSystem) {
                return (
                  <div key={idx} className="bg-amber-950/40 border border-amber-900/30 text-amber-300 p-3 rounded-2xl text-xs font-semibold leading-relaxed flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <span>{msg.content}</span>
                  </div>
                );
              }

              return (
                <div key={idx} className={`flex flex-col gap-1.5 ${isAI ? 'items-start' : 'items-end'}`}>
                  {/* Sender title */}
                  <span className="text-[9px] font-black uppercase text-slate-500 tracking-wider px-1">
                    {isAI ? '📖 Professor Tutor' : '🎓 You'}
                  </span>
                  
                  {isAI ? (
                    <AIResponse
                      content={msg.content}
                      onSynthesizeSpeech={handleSynthesizeSpeech}
                    />
                  ) : (
                    <div className="bg-indigo-600 text-white rounded-2xl px-3.5 py-2.5 max-w-[85%] text-xs font-bold leading-relaxed shadow-sm">
                      {msg.content}
                    </div>
                  )}
                </div>
              );
            })
          )}

          {isSending && (() => {
            const stages = [
              'Analyzing question...',
              'Formulating pedagogical logic...',
              'Drafting step-by-step response...',
              'Polishing explanation & formulas...'
            ];
            const currentStageIndex = Math.min(
              Math.floor(sendingSeconds / 2.2),
              stages.length - 1
            );
            const currentStage = stages[currentStageIndex];

            return (
              <div className="flex flex-col gap-1.5 items-start my-1 w-full max-w-sm">
                <span className="text-[9px] font-black uppercase text-indigo-400 tracking-wider px-1">📖 Professor Tutor</span>
                <div className="ai-thinking-bubble-pulse w-full bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-3 flex flex-col gap-2 text-xs font-bold text-indigo-300 shadow-lg shadow-indigo-500/10 backdrop-blur-md relative overflow-hidden">
                  <div className="flex items-center gap-2.5">
                    <div className="relative flex items-center justify-center shrink-0">
                      <span className="absolute -inset-1 rounded-full bg-indigo-500/25 animate-ping" />
                      <Activity className="w-4 h-4 animate-spin text-indigo-400 relative z-10" />
                    </div>
                    <div className="flex items-center gap-1.5 min-w-0 flex-1">
                      <AnimatePresence mode="wait">
                        <motion.span
                          key={currentStage}
                          initial={{ opacity: 0, y: 3 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -3 }}
                          transition={{ duration: 0.2 }}
                          className="truncate text-xs font-semibold text-indigo-200"
                        >
                          {currentStage}
                        </motion.span>
                      </AnimatePresence>
                      <span className="inline-flex items-center gap-0.5 text-indigo-400 shrink-0">
                        <span className="w-1 h-1 rounded-full bg-current ai-thinking-dot-1" />
                        <span className="w-1 h-1 rounded-full bg-current ai-thinking-dot-2" />
                        <span className="w-1 h-1 rounded-full bg-current ai-thinking-dot-3" />
                      </span>
                    </div>
                    <span className="text-[10px] font-normal px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700/60 shrink-0">
                      {sendingSeconds}s
                    </span>
                  </div>

                  {/* Stage Progress Dots */}
                  <div className="flex items-center justify-between gap-1 pt-0.5">
                    <div className="flex items-center gap-1">
                      {stages.map((_, idx) => (
                        <span
                          key={idx}
                          className={cn(
                            "h-1 rounded-full transition-all duration-300",
                            idx === currentStageIndex
                              ? "w-3 bg-indigo-500 shadow-sm shadow-indigo-500/50"
                              : idx < currentStageIndex
                                ? "w-1.5 bg-indigo-400/50"
                                : "w-1 bg-slate-700"
                          )}
                        />
                      ))}
                    </div>
                    <span className="text-[9px] font-normal text-slate-400">
                      Step {currentStageIndex + 1} of {stages.length}
                    </span>
                  </div>

                  {/* Shimmer progress bar */}
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-slate-800 overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-indigo-500 to-violet-500"
                      initial={{ width: "20%" }}
                      animate={{ width: `${Math.min(96, 25 + currentStageIndex * 24)}%` }}
                      transition={{ duration: 0.4, ease: "easeOut" }}
                    />
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Quick Starter Suggestions */}
          {messages.length <= 2 && !isSending && (
            <div className="pt-2 space-y-2">
              <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider block">
                ⚡ Quick Study Starters:
              </span>
              <div className="grid grid-cols-1 gap-1.5">
                {[
                  `Explain ${currentChapterTitle || currentSubject || 'this topic'} with a real-world analogy`,
                  `Derive and break down key formulas for ${currentChapterTitle || currentSubject || 'this lesson'}`,
                  `Give me a 3-step practice problem with solution hints`,
                  `What are the most common exam traps for this topic?`
                ].map((promptText, pIdx) => (
                  <button
                    key={pIdx}
                    onClick={() => handleSendMessage(promptText, 'text')}
                    className="text-left text-xs text-indigo-300 hover:text-white bg-slate-900/80 hover:bg-indigo-950/70 border border-slate-800 hover:border-indigo-500/50 p-2.5 rounded-xl transition-all shadow-sm font-medium"
                  >
                    💡 {promptText}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div ref={messageEndRef} />
        </div>

        {/* Bottom Message Input Panel */}
        <MessageInput
          onSend={handleSendMessage}
          disabled={isSending}
          currentSubject={currentSubject}
          language={language}
        />
      </div>
    </>
  );
};
