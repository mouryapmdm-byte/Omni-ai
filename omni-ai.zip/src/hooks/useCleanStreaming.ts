import { useState, useRef, useEffect, useCallback } from 'react';
import { StreamingBuffer } from '../lib/streaming/StreamingBuffer';
import { cleanStreamingMarkdown } from '../lib/streaming/cleanStreamingMarkdown';

interface CleanStreamingOptions {
  /**
   * Render delay in milliseconds for smooth animation batching
   */
  renderDelay?: number;
  /**
   * Callback fired when stream finishes
   */
  onComplete?: (finalContent: string) => void;
}

interface CleanStreamingResult {
  /**
   * Safe-to-render sanitized content (no raw markdown/LaTeX flashing)
   */
  safeContent: string;
  /**
   * Incomplete pending content held in buffer
   */
  pendingContent: string;
  /**
   * Whether streaming is currently active
   */
  isStreaming: boolean;
  /**
   * Push a new token or character chunk
   */
  push: (chunk: string) => void;
  /**
   * Conclude the active stream and flush all buffers
   */
  finish: () => void;
  /**
   * Reset buffer state for next lecture segment
   */
  reset: () => void;
}

export function useCleanStreaming(options: CleanStreamingOptions = {}): CleanStreamingResult {
  const { onComplete } = options;

  const bufferRef = useRef<StreamingBuffer>(new StreamingBuffer());
  const [safeContent, setSafeContent] = useState<string>('');
  const [pendingContent, setPendingContent] = useState<string>('');
  const [isStreaming, setIsStreaming] = useState<boolean>(false);

  const rafRef = useRef<number | null>(null);

  const processBuffer = useCallback(() => {
    const safe = bufferRef.current.getSafeContent();
    const pending = bufferRef.current.getPending();

    const sanitized = cleanStreamingMarkdown(safe, true);
    setSafeContent(sanitized);
    setPendingContent(pending);
  }, []);

  const push = useCallback(
    (chunk: string) => {
      setIsStreaming(true);
      bufferRef.current.append(chunk);

      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
      }

      rafRef.current = requestAnimationFrame(() => {
        processBuffer();
        rafRef.current = null;
      });
    },
    [processBuffer]
  );

  const finish = useCallback(() => {
    const final = bufferRef.current.flush();
    const cleanFinal = cleanStreamingMarkdown(final, false);
    setSafeContent(cleanFinal);
    setPendingContent('');
    setIsStreaming(false);
    onComplete?.(cleanFinal);
  }, [onComplete]);

  const reset = useCallback(() => {
    bufferRef.current.reset();
    setSafeContent('');
    setPendingContent('');
    setIsStreaming(false);
  }, []);

  useEffect(() => {
    return () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  return {
    safeContent,
    pendingContent,
    isStreaming,
    push,
    finish,
    reset,
  };
}
