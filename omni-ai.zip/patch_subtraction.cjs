const fs = require('fs');
const file = 'src/components/MatrixCalculatorModal.tsx';
let content = fs.readFileSync(file, 'utf8');

// Update state definition
content = content.replace(
  "const [operation, setOperation] = useState<'add' | 'multiply' | 'detA' | 'detB' | 'invA' | 'invB' | 'scalarA' | 'scalarB' | 'refA' | 'refB' | 'rankA' | 'rankB' | null>(null);",
  "const [operation, setOperation] = useState<'add' | 'subtract' | 'multiply' | 'detA' | 'detB' | 'invA' | 'invB' | 'scalarA' | 'scalarB' | 'refA' | 'refB' | 'rankA' | 'rankB' | null>(null);"
);

// Add renderSubtraction
const renderSub = `
  const renderSubtraction = () => {
    if (sizeA.rows !== sizeB.rows || sizeA.cols !== sizeB.cols) {
      return <p className="text-red-500 font-bold p-4">Error: Matrices must have the same dimensions for subtraction.</p>;
    }
    
    const result = matrixA.slice(0, sizeA.rows).map((row, i) => 
      row.slice(0, sizeA.cols).map((val, j) => val - matrixB[i][j])
    );
    
    return (
      <div className="space-y-4 overflow-x-auto">
        <h3 className="font-bold">Step-by-step Subtraction:</h3>
        <div className="flex gap-4 items-center w-max">
           <MatrixDisplay M={matrixA} rows={sizeA.rows} cols={sizeA.cols} />
           <span className="font-bold">-</span>
           <MatrixDisplay M={matrixB} rows={sizeB.rows} cols={sizeB.cols} />
           <span className="font-bold">=</span>
           <div className="grid gap-1 border-l-2 border-r-2 border-slate-400 p-1" style={{ gridTemplateColumns: \`repeat(\${sizeA.cols}, minmax(0, 1fr))\` }}>
              {Array(sizeA.rows).fill(0).map((_, i) => (
                Array(sizeA.cols).fill(0).map((_, j) => (
                  <div key={\`\${i}-\${j}\`} className="px-2 py-1 text-center whitespace-nowrap bg-indigo-500/10 rounded">
                    {matrixA[i][j]} - {matrixB[i][j]}
                  </div>
                ))
              ))}
           </div>
           <span className="font-bold">=</span>
           <MatrixDisplay M={result} rows={sizeA.rows} cols={sizeA.cols} />
        </div>
      </div>
    );
  };
`;

content = content.replace(
  "const renderMultiplication = () => {",
  renderSub + "\n  const renderMultiplication = () => {"
);

// Add Subtraction button
const button = `          <button 
            onClick={() => setOperation('subtract')}
            className={cn("px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-2", operation === 'subtract' ? "bg-indigo-600 text-white" : (theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-200" : "bg-slate-200 hover:bg-slate-300 text-slate-800"))}
          >
            <Minus size={16} /> Subtract (A - B)
          </button>`;

content = content.replace(
  "          <button \n            onClick={() => setOperation('multiply')}",
  button + "\n          <button \n            onClick={() => setOperation('multiply')}"
);

// Add to render logic
content = content.replace(
  "{operation === 'add' && renderAddition()}",
  "{operation === 'add' && renderAddition()}\n            {operation === 'subtract' && renderSubtraction()}"
);

fs.writeFileSync(file, content);
console.log("Patched MatrixCalculatorModal for subtraction");
