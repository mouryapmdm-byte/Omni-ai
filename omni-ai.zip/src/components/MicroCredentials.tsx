import React, { useState } from 'react';
import { 
  Award, 
  ShieldCheck, 
  Download, 
  Share2, 
  FileText, 
  Copy, 
  Check, 
  Key, 
  ExternalLink, 
  RefreshCw, 
  User, 
  Briefcase, 
  GraduationCap, 
  Mail, 
  Cpu, 
  TrendingUp, 
  Sparkles,
  Lock,
  Globe
} from 'lucide-react';

interface Credential {
  id: string;
  title: string;
  subject: string;
  issueDate: string;
  grade: string;
  issuer: string;
  hash: string;
  openBadgesStandard: string;
  recipientDID: string;
  verified: boolean;
}

const INITIAL_CREDENTIALS: Credential[] = [
  {
    id: 'OMNI-CRED-908122',
    title: 'Advanced Quantum Mechanics Specialist',
    subject: 'Physics',
    issueDate: '2026-06-28',
    grade: 'A+ (98th Percentile)',
    issuer: 'Omni AI Global Academic Council',
    hash: '8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e',
    openBadgesStandard: 'Open Badges v3.0 (JSON-LD)',
    recipientDID: 'did:key:z6MkpTHR8VNsBxq2X7K6GZ12mJq7gS8b3p',
    verified: true
  },
  {
    id: 'OMNI-CRED-712399',
    title: 'Differential Calculus & Real Analysis',
    subject: 'Mathematics',
    issueDate: '2026-06-15',
    grade: 'A (94th Percentile)',
    issuer: 'Omni AI Global Academic Council',
    hash: 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2',
    openBadgesStandard: 'Open Badges v3.0 (JSON-LD)',
    recipientDID: 'did:key:z6MkpTHR8VNsBxq2X7K6GZ12mJq7gS8b3p',
    verified: true
  },
  {
    id: 'OMNI-CRED-412803',
    title: 'Organic Chemical Reaction Synthesis',
    subject: 'Chemistry',
    issueDate: '2026-05-30',
    grade: 'A+ (99th Percentile)',
    issuer: 'Omni AI Global Academic Council',
    hash: 'f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8',
    openBadgesStandard: 'Open Badges v3.0 (JSON-LD)',
    recipientDID: 'did:key:z6MkpTHR8VNsBxq2X7K6GZ12mJq7gS8b3p',
    verified: true
  }
];

export const MicroCredentials: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [credentials, setCredentials] = useState<Credential[]>(INITIAL_CREDENTIALS);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [verifyStatus, setVerifyStatus] = useState<Record<string, 'idle' | 'verifying' | 'success'>>({});
  
  // Self-Sovereign Identity Key pair generator
  const [didKey, setDidKey] = useState<string>('did:key:z6MkpTHR8VNsBxq2X7K6GZ12mJq7gS8b3p');
  const [privateKey, setPrivateKey] = useState<string>('ed25519_sk_8f731ad88e0b4a4cf909ee82cdb817b1248a3e79124be370129ffb1297e68202');
  const [generatingKeys, setGeneratingKeys] = useState<boolean>(false);

  // Resume Export view / details state
  const [studentName, setStudentName] = useState<string>('Alex Thorne');
  const [studentTitle, setStudentTitle] = useState<string>('Aspiring Quantum Computing Engineer');
  const [studentEmail, setStudentEmail] = useState<string>('alex.thorne@quantummail.org');
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [exportFormat, setExportFormat] = useState<'markdown' | 'jsonld'>('markdown');

  const generateNewKeyPair = () => {
    setGeneratingKeys(true);
    setTimeout(() => {
      const chars = '0123456789abcdef';
      let randomHex = '';
      for (let i = 0; i < 64; i++) {
        randomHex += chars[Math.floor(Math.random() * chars.length)];
      }
      const randomDID = 'did:key:z6M' + randomHex.slice(0, 32);
      
      setDidKey(randomDID);
      setPrivateKey('ed25519_sk_' + randomHex);
      setGeneratingKeys(false);

      // Automatically update recipient DID on certificates
      setCredentials(prev => prev.map(cred => ({
        ...cred,
        recipientDID: randomDID
      })));
    }, 800);
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleVerifyCredential = (credId: string) => {
    setVerifyStatus(prev => ({ ...prev, [credId]: 'verifying' }));
    
    // Simulate real cryptographic verification (SHA-256 Merkle root verification)
    setTimeout(() => {
      setVerifyStatus(prev => ({ ...prev, [credId]: 'success' }));
    }, 1200);
  };

  // Render verifiable JSON-LD format
  const generateJSONLD = () => {
    return JSON.stringify({
      "@context": [
        "https://www.w3.org/2018/credentials/v1",
        "https://purl.imsglobal.org/spec/ob/v3p0/context.json"
      ],
      "id": "urn:uuid:8b31a281-b922-488b-ad7c-cd3bb222810a",
      "type": ["VerifiableCredential", "OpenBadgeCredential"],
      "issuer": {
        "id": "did:web:omni.ai:issuer",
        "type": ["Profile"],
        "name": "Omni AI Global Academic Council",
        "url": "https://omni.ai/academic"
      },
      "issuanceDate": "2026-06-28T12:00:00Z",
      "credentialSubject": {
        "id": didKey,
        "type": ["AchievementSubject"],
        "name": studentName,
        "achievement": {
          "id": "https://omni.ai/achievements/quantum-specialist",
          "type": ["Achievement"],
          "name": "Advanced Quantum Mechanics Specialist",
          "description": "Student achieved master-level command of quantum state vector superposition, entanglements, and Hilbert operators.",
          "criteria": {
            "narrative": "Requires scoring above 95% on the comprehensive Omni AI diagnostic proctored mock simulation."
          }
        }
      },
      "proof": {
        "type": "Ed25519Signature2020",
        "created": "2026-06-28T12:05:22Z",
        "verificationMethod": "did:web:omni.ai:issuer#key-1",
        "proofPurpose": "assertionMethod",
        "proofValue": "z3h8aMxp9Y... cryptographic signature block"
      }
    }, null, 2);
  };

  // Render markdown resume formatting
  const generateMarkdownResume = () => {
    return `# Academic Portfolio - ${studentName}
## ${studentTitle}
**Email:** ${studentEmail}
**Decentralized Identifier (DID):** \`${didKey}\`

---

### Verifiable Micro-Credentials
${credentials.map(cred => `- **${cred.title}**
  * Subject: ${cred.subject} | Grade: ${cred.grade}
  * Date Issued: ${cred.issueDate}
  * Cryptographic Signature Check: Certified Verification Pass (\`${cred.hash.slice(0, 16)}...\`)
`).join('\n')}`;
  };

  return (
    <div id="micro-credentials-root" className="flex flex-col h-full overflow-y-auto pr-1">
      {/* Upper Vault Banner / Self-Sovereign Identity Setup */}
      <div id="did-vault-card" className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 mb-4 grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
        <div className="lg:col-span-8">
          <h3 className="text-xs font-black uppercase tracking-wider text-indigo-500 mb-1 flex items-center gap-1.5">
            <Key size={14} />
            Self-Sovereign Identity (SSI) Cryptographic Vault
          </h3>
          <p className="text-[10px] text-slate-500 leading-relaxed mb-3">
            To combat credential fraud, the Omni AI system signs certificates using ed25519 private keys, mapping outcomes directly to your Decentralized Identifier (DID).
          </p>

          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 bg-white dark:bg-slate-850 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-mono">
              <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">DID KEY:</span>
              <span className="text-slate-600 dark:text-slate-300 select-all truncate flex-1">{didKey}</span>
              <button
                id="btn-copy-did"
                onClick={() => handleCopy(didKey, 'did')}
                className="text-slate-400 hover:text-indigo-500 cursor-pointer"
              >
                {copiedId === 'did' ? <Check size={13} className="text-emerald-500" /> : <Copy size={13} />}
              </button>
            </div>

            <div className="flex items-center gap-2 bg-white dark:bg-slate-850 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-mono">
              <span className="text-[9px] font-black uppercase tracking-widest text-red-400 flex items-center gap-0.5">
                <Lock size={10} /> SECRET:
              </span>
              <span className="text-slate-400 select-all truncate flex-1">••••••••••••••••••••••••••••••••••••••••••••••••</span>
              <button
                id="btn-copy-sk"
                onClick={() => handleCopy(privateKey, 'sk')}
                className="text-slate-400 hover:text-indigo-500 cursor-pointer"
              >
                {copiedId === 'sk' ? <Check size={13} className="text-emerald-500" /> : <Copy size={13} />}
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-800 pt-3 lg:pt-0 lg:pl-4 flex flex-col items-center justify-center text-center">
          <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-950/40 text-indigo-500 rounded-full flex items-center justify-center mb-2 animate-pulse">
            <Cpu size={20} />
          </div>
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Key Management</span>
          <button
            id="btn-generate-keys"
            disabled={generatingKeys}
            onClick={generateNewKeyPair}
            className="py-1.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-black text-[10px] uppercase tracking-wider flex items-center gap-1 cursor-pointer shadow-sm"
          >
            <RefreshCw size={11} className={generatingKeys ? 'animate-spin' : ''} />
            {generatingKeys ? 'Generating...' : 'Cycle Keypair'}
          </button>
        </div>
      </div>

      <div id="credentials-main-split" className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Left Column: Verifiable Badges Certificates List (Col 7) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="mb-4">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Award size={15} className="text-indigo-500" />
                Signed Verifiable Academic Credentials
              </h3>
              <p className="text-[10px] text-slate-500 mt-0.5">Cryptographically verified achievements meeting modern W3C Open Badges 3.0 specs</p>
            </div>

            <div id="credentials-list" className="flex flex-col gap-3.5">
              {credentials.map((cred) => {
                const currentStatus = verifyStatus[cred.id] || 'idle';

                return (
                  <div
                    id={`credential-card-${cred.id}`}
                    key={cred.id}
                    className="p-4 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col gap-3 relative overflow-hidden group hover:border-indigo-500/40 transition-colors"
                  >
                    {/* Ribbon check corner */}
                    <div className="absolute top-0 right-0 w-12 h-12 bg-indigo-500/5 flex items-center justify-center rounded-bl-2xl">
                      <ShieldCheck size={18} className="text-indigo-500 animate-pulse" />
                    </div>

                    <div className="pr-10">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-xs font-black text-slate-800 dark:text-slate-100">{cred.title}</h4>
                      </div>
                      <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">{cred.subject} • {cred.issuer}</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-100 dark:border-slate-800/80 text-[10px] font-bold text-slate-500">
                      <div>
                        <span className="text-[8px] font-black text-slate-400 block uppercase">ISSUE DATE</span>
                        <span className="text-slate-700 dark:text-slate-300 font-mono">{cred.issueDate}</span>
                      </div>
                      <div>
                        <span className="text-[8px] font-black text-slate-400 block uppercase">ACADEMIC GRADE</span>
                        <span className="text-indigo-500 font-black">{cred.grade}</span>
                      </div>
                      <div>
                        <span className="text-[8px] font-black text-slate-400 block uppercase">CREDENTIAL ID</span>
                        <span className="text-slate-700 dark:text-slate-300 font-mono select-all">{cred.id}</span>
                      </div>
                    </div>

                    {/* Cryptographic signature output */}
                    <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-150 dark:border-slate-800 text-[9px] font-mono flex items-center gap-2 text-slate-500">
                      <span className="text-[8px] font-black uppercase text-slate-400">SIG_HASH:</span>
                      <span className="truncate select-all flex-1">{cred.hash}</span>
                      <button
                        id={`btn-copy-hash-${cred.id}`}
                        onClick={() => handleCopy(cred.hash, cred.id)}
                        className="text-slate-400 hover:text-indigo-500 cursor-pointer flex-shrink-0"
                      >
                        {copiedId === cred.id ? <Check size={10} className="text-emerald-500" /> : <Copy size={10} />}
                      </button>
                    </div>

                    {/* Interactive Verify Trigger */}
                    <div className="flex items-center justify-between mt-1 pt-1">
                      <span className="text-[9px] text-slate-400 font-bold italic flex items-center gap-1">
                        <Globe size={11} /> Format: {cred.openBadgesStandard}
                      </span>

                      <button
                        id={`btn-verify-cred-${cred.id}`}
                        disabled={currentStatus === 'verifying'}
                        onClick={() => handleVerifyCredential(cred.id)}
                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all ${
                          currentStatus === 'verifying'
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                            : currentStatus === 'success'
                              ? 'bg-emerald-500/15 text-emerald-500 border border-emerald-500/20'
                              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm'
                        }`}
                      >
                        {currentStatus === 'verifying' ? (
                          <>
                            <RefreshCw size={11} className="animate-spin" /> Verifying...
                          </>
                        ) : currentStatus === 'success' ? (
                          <>
                            <ShieldCheck size={11} /> Cryptographically Secured
                          </>
                        ) : (
                          <>
                            <ShieldCheck size={11} /> Validate On-Chain Integrity
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Portfolio Resume Exporter (Col 5) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="mb-4">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <FileText size={15} className="text-indigo-500" />
                E-Portfolio & Resume Exporter
              </h3>
              <p className="text-[10px] text-slate-500 mt-0.5">Customize and pack verifiable achievements into university resumes</p>
            </div>

            {/* Editing settings inputs */}
            <div id="exporter-inputs" className="flex flex-col gap-3 text-xs mb-4">
              <div>
                <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Full Student Name</label>
                <input
                  id="input-student-name"
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 text-xs font-bold dark:text-white outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Professional Target Heading</label>
                <input
                  id="input-student-title"
                  type="text"
                  value={studentTitle}
                  onChange={(e) => setStudentTitle(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 text-xs font-bold dark:text-white outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Contact Email Address</label>
                <input
                  id="input-student-email"
                  type="email"
                  value={studentEmail}
                  onChange={(e) => setStudentEmail(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 text-xs font-bold dark:text-white outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Quick Live Preview of the Resume page */}
            <div id="resume-preview-card" className="p-4 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl relative overflow-hidden text-slate-800 dark:text-slate-200 text-xs shadow-inner">
              <div className="absolute top-2 right-2 text-[8px] font-black uppercase text-slate-400 border border-slate-200 dark:border-slate-800 px-1.5 py-0.5 rounded">
                RESUME PREVIEW
              </div>

              <div className="border-b border-slate-150 dark:border-slate-800 pb-3 mb-3">
                <h4 className="text-sm font-black text-slate-950 dark:text-white">{studentName}</h4>
                <div className="text-[10px] text-slate-500 font-bold flex items-center gap-1.5 mt-0.5">
                  <Briefcase size={10} /> {studentTitle}
                </div>
                <div className="text-[9px] text-slate-400 font-semibold flex items-center gap-1.5 mt-0.5">
                  <Mail size={10} /> {studentEmail}
                </div>
              </div>

              <div className="flex flex-col gap-2.5">
                <div>
                  <span className="text-[9px] font-black text-indigo-500 uppercase tracking-widest block mb-1">VERIFIED MICRO-CREDENTIALS</span>
                  <div className="flex flex-col gap-1.5 text-[10px]">
                    {credentials.map(c => (
                      <div key={c.id} className="flex justify-between items-center bg-slate-50 dark:bg-slate-900 p-1.5 rounded border border-slate-150 dark:border-slate-800/60">
                        <span className="font-bold text-slate-700 dark:text-slate-300">{c.title}</span>
                        <span className="font-mono text-emerald-500 text-[8px] font-black">✔ CRYPTO_PASS</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t border-slate-100 dark:border-slate-800 pt-2.5">
                  <span className="text-[9px] font-black text-indigo-500 uppercase tracking-widest block mb-1">GLOBAL DID PORTFOLIO</span>
                  <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded font-mono text-[8px] text-slate-400 select-all truncate">
                    {didKey}
                  </div>
                </div>
              </div>
            </div>

            {/* Large trigger buttons to activate file download export modal */}
            <div className="grid grid-cols-2 gap-2 mt-4">
              <button
                id="btn-export-markdown"
                onClick={() => { setExportFormat('markdown'); setShowExportModal(true); }}
                className="py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer shadow-sm transition-all"
              >
                <FileText size={12} /> Export Markdown
              </button>
              <button
                id="btn-export-jsonld"
                onClick={() => { setExportFormat('jsonld'); setShowExportModal(true); }}
                className="py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer shadow-sm transition-all"
              >
                <Share2 size={12} /> Export JSON-LD
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Export view raw Modal overlay panel overlay */}
      {showExportModal && (
        <div id="export-overlay-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 w-full max-w-xl flex flex-col max-h-[85vh]">
            <div className="flex justify-between items-center mb-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Sparkles size={14} className="text-indigo-500" />
                Raw Export: {exportFormat === 'markdown' ? 'Academic Resume Markdown' : 'Decentralized JSON-LD Schema'}
              </h4>
              <button
                id="btn-close-export"
                onClick={() => setShowExportModal(false)}
                className="text-slate-400 hover:text-red-500 font-extrabold text-xs cursor-pointer"
              >
                Close
              </button>
            </div>

            {/* Code output blocks */}
            <div className="flex-1 overflow-y-auto mb-4">
              <pre className="p-4 bg-slate-950 text-indigo-300 rounded-xl font-mono text-[10px] leading-relaxed whitespace-pre-wrap select-all">
                {exportFormat === 'markdown' ? generateMarkdownResume() : generateJSONLD()}
              </pre>
            </div>

            {/* Bottom tools action bar */}
            <div className="flex justify-between items-center border-t border-slate-200 dark:border-slate-800 pt-3">
              <span className="text-[9px] text-slate-400 font-bold">Verified on-chain via did:key cryptographic validation standard.</span>
              <button
                id="btn-copy-export-payload"
                onClick={() => handleCopy(exportFormat === 'markdown' ? generateMarkdownResume() : generateJSONLD(), 'export')}
                className="py-2 px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-black text-[10px] uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                {copiedId === 'export' ? <Check size={12} /> : <Copy size={12} />}
                {copiedId === 'export' ? 'Payload Copied!' : 'Copy Payload'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
