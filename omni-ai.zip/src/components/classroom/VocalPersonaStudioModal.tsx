import React, { useState } from 'react';
import { X, Mic, MicOff, Volume2, Sparkles, Sliders, Check, Play, RefreshCw, Zap } from 'lucide-react';
import { TEACHER_PEDAGOGY_STYLES, TeacherPedagogyStyle } from '../../data/teacherStyles';
import { TutorPersonaConfig, PersonaArchetype } from '../../types';

export interface VocalPersonaStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentStyle?: TeacherPedagogyStyle;
  currentPersona?: any;
  onSelectStyle?: (styleId: string) => void;
  onSelectTeacherStyle?: (styleId: string) => void;
  personaConfig?: TutorPersonaConfig;
  onUpdatePersonaConfig?: (config: TutorPersonaConfig) => void;
  onUpdatePersona?: (config: TutorPersonaConfig) => void;
  acousticProfile?: any;
  onUpdateAcoustic?: (partial: any) => void;
  speechRate?: number;
  onChangeSpeechRate?: (rate: number) => void;
  speechPitch?: number;
  onChangeSpeechPitch?: (pitch: number) => void;
  onTestVoice?: (sampleText: string) => void;
  isSpeaking?: boolean;
  onStopSpeech?: () => void;
  onStopSpeaking?: () => void;
  isListening?: boolean;
  onToggleSpeechRecognition?: () => void;
  onToggleMic?: () => void;
  onSendVoicePrompt?: (prompt: string) => void;
  availableVoices?: SpeechSynthesisVoice[] | any[];
}

export const VocalPersonaStudioModal: React.FC<VocalPersonaStudioModalProps> = ({
  isOpen,
  onClose,
  currentStyle: providedCurrentStyle,
  currentPersona,
  onSelectStyle,
  onSelectTeacherStyle,
  personaConfig,
  onUpdatePersonaConfig,
  onUpdatePersona,
  acousticProfile,
  onUpdateAcoustic,
  speechRate = 1.0,
  onChangeSpeechRate,
  speechPitch = 1.0,
  onChangeSpeechPitch,
  onTestVoice,
  isSpeaking = false,
  onStopSpeech,
  onStopSpeaking,
  isListening = false,
  onToggleSpeechRecognition,
  onToggleMic,
  onSendVoicePrompt,
  availableVoices = []
}) => {
  const currentStyle = providedCurrentStyle || currentPersona || TEACHER_PEDAGOGY_STYLES[0];
  const handleSelect = (id: string) => {
    if (onSelectStyle) onSelectStyle(id);
    if (onSelectTeacherStyle) onSelectTeacherStyle(id);
  };
  const handleStopAudio = onStopSpeaking || onStopSpeech;
  const handleToggleListening = onToggleMic || onToggleSpeechRecognition;

  const [activeTab, setActiveTab] = useState<'persona' | 'voice_settings' | 'live_agent'>('persona');
  const [localRate, setLocalRate] = useState<number>(speechRate);
  const [localPitch, setLocalPitch] = useState<number>(speechPitch);
  const [socraticIntensity, setSocraticIntensity] = useState<number>(personaConfig?.socraticIntensity || 3);
  const [energyLevel, setEnergyLevel] = useState<number>(personaConfig?.energyLevel || 85);
  const [analogyDensity, setAnalogyDensity] = useState<number>(personaConfig?.analogyDensity || 90);
  const [rigorLevel, setRigorLevel] = useState<number>(personaConfig?.rigorLevel || 75);
  const [audioEngine, setAudioEngine] = useState<'neural' | 'native'>('neural');

  if (!isOpen) return null;

  const handleApplyPersona = (style: TeacherPedagogyStyle) => {
    handleSelect(style.id);
    const updateFn = onUpdatePersona || onUpdatePersonaConfig;
    if (updateFn) {
      let archetype: PersonaArchetype = 'professor_clarity';
      if (style.id.includes('socratic')) archetype = 'socratic_specialist';
      else if (style.id.includes('story')) archetype = 'conceptual_storyteller';
      else if (style.id.includes('exam')) archetype = 'strict_academic';
      else if (style.id.includes('mistake')) archetype = 'high_energy';

      updateFn({
        archetype,
        name: style.name,
        avatarIcon: style.avatarIcon,
        socraticIntensity,
        feedbackTone: 'balanced_encouragement',
        inquiryRatio: 50,
        rigorLevel,
        energyLevel,
        analogyDensity,
        customInstructions: style.pedagogicalDirective || style.promptDirective
      });
    }
  };

  const handleTestSample = () => {
    const text = `Greetings! I am ${currentStyle.name}. In today's session, every complex equation will become intuitive, concrete, and deeply memorable. Are you ready to begin?`;
    if (onTestVoice) {
      onTestVoice(text);
    } else {
      try {
        window.speechSynthesis?.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.rate = localRate;
        u.pitch = localPitch;
        window.speechSynthesis?.speak(u);
      } catch (e) {}
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-amber-500/20 to-indigo-500/20 text-amber-300 border border-amber-500/30">
              <Mic size={22} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>Vocal Persona & Voice Agent Studio</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  {currentStyle.name} Active
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Calibrate vocal cadence, socratic inquiry level, and live voice interaction in 3D
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-800 bg-slate-950/50 px-4 text-xs font-bold">
          <button
            onClick={() => setActiveTab('persona')}
            className={`py-3 px-4 border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'persona'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>👨‍🏫</span>
            <span>Vocal Archetypes</span>
          </button>
          <button
            onClick={() => setActiveTab('voice_settings')}
            className={`py-3 px-4 border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'voice_settings'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders size={14} />
            <span>Cadence & Acoustics</span>
          </button>
          <button
            onClick={() => setActiveTab('live_agent')}
            className={`py-3 px-4 border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'live_agent'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Mic size={14} />
            <span>Voice Agent Live Mic</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar touch-pan-y overscroll-contain p-4 sm:p-6 space-y-4">
          {activeTab === 'persona' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {TEACHER_PEDAGOGY_STYLES.map(style => {
                  const isSelected = currentStyle.id === style.id;
                  return (
                    <div
                      key={style.id}
                      onClick={() => handleApplyPersona(style)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between group ${
                        isSelected
                          ? 'bg-indigo-950/70 border-indigo-500 ring-2 ring-indigo-500/40'
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{style.avatarIcon}</span>
                            <span className="text-sm font-black text-white group-hover:text-indigo-300">
                              {style.name}
                            </span>
                          </div>
                          {isSelected && (
                            <span className="p-1 rounded-full bg-emerald-500 text-slate-950">
                              <Check size={12} strokeWidth={3} />
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                          {style.description || style.tagline}
                        </p>
                      </div>

                      <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500">
                        <span className="font-mono text-indigo-300 font-bold">{style.tone || style.dimensions?.toneEnergy || style.badge}</span>
                        <span>{style.shortName}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'voice_settings' && (
            <div className="space-y-5">
              {/* Speed / Rate */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Zap size={14} className="text-amber-400" />
                    <span>Speech Pace (Rate)</span>
                  </span>
                  <span className="font-mono font-bold text-indigo-400">{localRate.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.75"
                  max="1.75"
                  step="0.05"
                  value={localRate}
                  onChange={e => {
                    const r = parseFloat(e.target.value);
                    setLocalRate(r);
                    onChangeSpeechRate?.(r);
                  }}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>0.75x (Meditative)</span>
                  <span>1.0x (Standard)</span>
                  <span>1.75x (Brisk Drill)</span>
                </div>
              </div>

              {/* Pitch */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Volume2 size={14} className="text-cyan-400" />
                    <span>Vocal Pitch & Warmth</span>
                  </span>
                  <span className="font-mono font-bold text-cyan-400">{localPitch.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.7"
                  max="1.3"
                  step="0.05"
                  value={localPitch}
                  onChange={e => {
                    const p = parseFloat(e.target.value);
                    setLocalPitch(p);
                    onChangeSpeechPitch?.(p);
                  }}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>Deeper Baritone</span>
                  <span>Natural Default</span>
                  <span>Higher Resonance</span>
                </div>
              </div>

              {/* Socratic Inquiry Intensity */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Sparkles size={14} className="text-emerald-400" />
                    <span>Socratic Inquiry Intensity</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-400">Level {socraticIntensity} / 5</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  step="1"
                  value={socraticIntensity}
                  onChange={e => setSocraticIntensity(parseInt(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>1: Direct Delivery</span>
                  <span>3: Balanced Questions</span>
                  <span>5: Deep Socratic Probing</span>
                </div>
              </div>

              {/* Audio Synthesis Engine */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white">Speech Synthesis Engine</h4>
                  <p className="text-[11px] text-slate-400">Select between neural stream and client web speech</p>
                </div>
                <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
                  <button
                    onClick={() => setAudioEngine('neural')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      audioEngine === 'neural' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Neural AI Voice
                  </button>
                  <button
                    onClick={() => setAudioEngine('native')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      audioEngine === 'native' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    System TTS
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'live_agent' && (
            <div className="p-6 rounded-2xl bg-slate-950/60 border border-slate-800 text-center space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
                {isListening ? (
                  <Mic size={32} className="text-emerald-400 animate-pulse" />
                ) : (
                  <MicOff size={32} className="text-slate-400" />
                )}
              </div>

              <div>
                <h3 className="text-sm font-black text-white">
                  {isListening ? 'Voice Agent Listening...' : 'Two-Way Voice Interaction'}
                </h3>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  Click the microphone button to talk directly with {currentStyle.name} during the lecture. Your question will be answered verbally in character!
                </p>
              </div>

              <div className="pt-2 flex justify-center gap-3">
                <button
                  onClick={handleToggleListening}
                  className={`px-5 py-2.5 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer shadow-lg ${
                    isListening
                      ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-600/30 animate-pulse'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                  }`}
                >
                  {isListening ? <MicOff size={16} /> : <Mic size={16} />}
                  <span>{isListening ? 'Stop Listening' : 'Start Voice Input'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer with Test Audio button */}
        <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={handleTestSample}
              disabled={isSpeaking}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Volume2 size={15} />
              <span>{isSpeaking ? 'Speaking...' : 'Test Voice Sample'}</span>
            </button>
            {isSpeaking && (
              <button
                onClick={handleStopAudio}
                className="px-3 py-2 rounded-xl bg-red-950/80 hover:bg-red-900 text-red-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                Stop
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer shadow-md shadow-indigo-600/30"
          >
            Apply & Done
          </button>
        </div>
      </div>
    </div>
  );
};
