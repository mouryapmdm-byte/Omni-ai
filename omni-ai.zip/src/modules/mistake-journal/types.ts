export type MistakeCategory = 
  | 'calculation_error'
  | 'concept_misunderstanding'
  | 'unit_error'
  | 'sign_error'
  | 'formula_misuse'
  | 'reading_comprehension'
  | 'silly_mistake';

export interface Mistake {
  id: string;
  studentId: string;
  questionId: string;
  questionText: string;
  subject: string;
  chapterId: string;
  chapterName: string;
  topicId: string;
  topicName: string;
  studentAnswer: string;
  correctAnswer: string;
  mistakeType: MistakeCategory;
  timeSpent: number; // in seconds
  createdAt: string;
  reviewed: boolean;
  improved: boolean;
  context?: string; // e.g. 'speed_run', 'mock_exam', 'practice'
  confidenceLevel?: 'guess' | 'unsure' | 'confident';
  detailedDiagnosis?: string;
  remediationAttemptCount?: number;
}

export interface MistakePattern {
  id: string;
  type: 'recurring_mistake_type' | 'concept_confusion' | 'fatigue_spike' | 'speed_rush';
  title: string;
  description: string;
  count: number;
  subject: string;
  chapterName?: string;
  severity: 'high' | 'medium' | 'low';
  remediationSuggestion: string;
}

export interface WeeklyMistakeReview {
  weekStartDate: string;
  totalMistakes: number;
  resolvedMistakes: number;
  top3MistakeTypes: {
    type: MistakeCategory;
    displayName: string;
    count: number;
    percentage: number;
    trend: 'improved' | 'worsened' | 'stable';
  }[];
  accuracyDeltaVsLastWeek: number;
  recommendedFocusHours: number;
}

export interface RemediationQuestion {
  id: string;
  mistakeRefId: string;
  questionText: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  targetMistakeType: MistakeCategory;
  trapWarning: string;
  subject: string;
  topic: string;
}
