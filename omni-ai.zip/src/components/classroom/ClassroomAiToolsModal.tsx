import React from 'react';
import { X, Sparkles, Beaker, Atom, Table, BookOpen, FileText, CheckCircle2, Zap, Layers, FileCode2, Volume2, ShieldCheck, Microscope } from 'lucide-react';

export interface ClassroomAiToolItem {
  id: string;
  name?: string;
  title?: string;
  category: string;
  icon: string;
  description: string;
  action: () => void;
  badge?: string;
}

export interface ClassroomAiToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tools: ClassroomAiToolItem[];
  theme?: 'light' | 'dark';
  topic?: string;
}

export const ClassroomAiToolsModal: React.FC<ClassroomAiToolsModalProps> = ({
  isOpen,
  onClose,
  tools,
  theme = 'dark',
  topic
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-indigo-500/20 text-cyan-300 border border-cyan-500/30">
              <Sparkles size={22} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>AI Tools & STEM Pedagogical Suite</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                  {tools.length} Tools Ready
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Seamlessly launch interactive simulations, dynamic figures, formulas, and recaps in 3D
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tools Grid */}
        <div className="flex-1 overflow-y-auto custom-scrollbar touch-pan-y overscroll-contain p-4 sm:p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
          {tools.map(tool => (
            <div
              key={tool.id}
              onClick={() => {
                tool.action();
                onClose();
              }}
              className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-indigo-500/60 hover:bg-slate-800/60 transition-all cursor-pointer flex flex-col justify-between group shadow-lg text-left"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <span className="text-2xl p-2 rounded-xl bg-slate-900 border border-slate-800 group-hover:scale-110 transition-transform">
                    {tool.icon}
                  </span>
                  {tool.badge && (
                    <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {tool.badge}
                    </span>
                  )}
                </div>
                <h3 className="text-xs sm:text-sm font-black text-white mt-3 group-hover:text-indigo-300 transition-colors">
                  {tool.title || tool.name}
                </h3>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {tool.description}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-indigo-400 font-bold group-hover:text-indigo-300">
                <span>Launch in 3D</span>
                <span>➔</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-400">
          <span>All AI tools operate seamlessly in real-time with the 3D Classroom Smartboard</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
