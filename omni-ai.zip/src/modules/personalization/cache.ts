import { GeneratedExample, ExampleTrio } from './types';

const CACHE_STORAGE_KEY = 'omni_example_cache_v1';

/**
 * Curated high-fidelity offline seed examples across common concepts and interest categories
 */
const SEED_EXAMPLES: GeneratedExample[] = [
  // --- CONCEPT: Newton's Second Law (F = ma) ---
  {
    id: 'seed_fma_sports',
    conceptId: 'newtons_second_law',
    conceptTitle: "Newton's Second Law of Motion",
    interestCategory: 'sports',
    subInterest: 'Cricket',
    exampleText: "When an elite cricket bowler delivers a 150-gram ball accelerating at 400 m/s² during the arm whip, their shoulder and fingers exert a forward force of exactly 60 N on the seam. If they bowl a heavier 160-gram wet ball with identical shoulder muscle force, the acceleration immediately drops to 375 m/s².",
    exampleFormula: "F = m \\cdot a \\implies 60\\text{ N} = (0.150\\text{ kg}) \\times (400\\text{ m/s}^2)",
    modelFormula: "F = m \\cdot a",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 12
  },
  {
    id: 'seed_fma_gaming',
    conceptId: 'newtons_second_law',
    conceptTitle: "Newton's Second Law of Motion",
    interestCategory: 'gaming',
    subInterest: 'Physics Engines',
    exampleText: "In a gaming physics engine like Unreal Engine 5, a simulated 2000-kg battle mech being hit by a plasma pulse of 50,000 N will accelerate backwards at 25 m/s². If a modder equips the mech with heavy 4000-kg depleted uranium plating, that same 50,000 N plasma blast only knocks it back at 12.5 m/s².",
    exampleFormula: "a = \\frac{F}{m} = \\frac{50{,}000\\text{ N}}{2000\\text{ kg}} = 25\\text{ m/s}^2",
    modelFormula: "F = m \\cdot a",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 18
  },
  {
    id: 'seed_fma_space',
    conceptId: 'newtons_second_law',
    conceptTitle: "Newton's Second Law of Motion",
    interestCategory: 'space',
    subInterest: 'Rockets',
    exampleText: "During second-stage ignition, a SpaceX Falcon 9 upper stage engine delivers 934,000 N of vacuum thrust. With 100,000 kg of propellants remaining, acceleration is 9.34 m/s²; as fuel burns down to just 15,000 kg of dry mass, the constant thrust hurls the vehicle forward at a blistering 62.3 m/s².",
    exampleFormula: "a = \\frac{F}{m} \\implies \\frac{934{,}000\\text{ N}}{15{,}000\\text{ kg}} = 62.3\\text{ m/s}^2",
    modelFormula: "F = m \\cdot a",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 24
  },
  {
    id: 'seed_fma_generic',
    conceptId: 'newtons_second_law',
    conceptTitle: "Newton's Second Law of Motion",
    interestCategory: 'generic',
    exampleText: "Pushing a 50 kg supermarket cart with a steady horizontal force of 100 N produces an acceleration of 2 m/s² across the smooth floor. If 50 kg of heavy groceries are loaded inside doubling the mass to 100 kg, the same 100 N push produces only 1 m/s² acceleration.",
    exampleFormula: "F = m \\cdot a \\implies a = \\frac{100\\text{ N}}{50\\text{ kg}} = 2\\text{ m/s}^2",
    modelFormula: "F = m \\cdot a",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 5
  },

  // --- CONCEPT: Ohm's Law (V = IR) ---
  {
    id: 'seed_ohm_tech',
    conceptId: 'ohms_law',
    conceptTitle: "Ohm's Law",
    interestCategory: 'tech',
    subInterest: 'Robotics',
    exampleText: "In an autonomous drone's avionics motherboard, a 3.3V logic line powers a telemetry sensor with an internal resistance of 330 Ω, drawing exactly 10 mA of current. When an accidental short reduces resistance to 33 Ω, current surges tenfold to 100 mA, triggering the automatic overcurrent cutoff switch.",
    exampleFormula: "I = \\frac{V}{R} = \\frac{3.3\\text{ V}}{330\\ \\Omega} = 0.010\\text{ A} = 10\\text{ mA}",
    modelFormula: "V = I \\cdot R",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 15
  },
  {
    id: 'seed_ohm_music',
    conceptId: 'ohms_law',
    conceptTitle: "Ohm's Law",
    interestCategory: 'music',
    subInterest: 'Guitar Acoustics',
    exampleText: "A 100-watt tube guitar amplifier outputs a peak signal of 28.3 V into an 8 Ω stage speaker cabinet, pushing 3.54 A of driving current through the copper voice coils. If you rewire the speakers in parallel down to 4 Ω at the same voltage, current demand doubles to 7.08 A.",
    exampleFormula: "I = \\frac{V}{R} = \\frac{28.3\\text{ V}}{8\\ \\Omega} \\approx 3.54\\text{ A}",
    modelFormula: "V = I \\cdot R",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 19
  },
  {
    id: 'seed_ohm_generic',
    conceptId: 'ohms_law',
    conceptTitle: "Ohm's Law",
    interestCategory: 'generic',
    exampleText: "A standard 9V battery connected across an incandescent indicator lamp of 18 Ω resistance drives a steady current of 0.5 A through the filament. If the resistance is doubled to 36 Ω, the current is halved to 0.25 A.",
    exampleFormula: "I = \\frac{V}{R} = \\frac{9\\text{ V}}{18\\ \\Omega} = 0.5\\text{ A}",
    modelFormula: "V = I \\cdot R",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 8
  },

  // --- CONCEPT: Conservation of Energy (E_k + E_p = Const) ---
  {
    id: 'seed_energy_sports',
    conceptId: 'conservation_of_energy',
    conceptTitle: "Conservation of Mechanical Energy",
    interestCategory: 'sports',
    subInterest: 'Formula 1',
    exampleText: "At the top of the steep Eau Rouge crest in Spa, a 798-kg Formula 1 car holds 156,000 J of gravitational potential energy. As it plunges 20 meters downhill into the Kemmel straight, that entire potential energy transforms into kinetic energy, boosting its speed by 71 km/h without burning a drop of fuel.",
    exampleFormula: "\\Delta E_k = m g h = (798\\text{ kg})(9.8\\text{ m/s}^2)(20\\text{ m}) = 156{,}408\\text{ J}",
    modelFormula: "E_k + E_p = \\text{Constant}",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 21
  },
  {
    id: 'seed_energy_space',
    conceptId: 'conservation_of_energy',
    conceptTitle: "Conservation of Mechanical Energy",
    interestCategory: 'space',
    subInterest: 'Planetary Orbits',
    exampleText: "When the James Webb Space Telescope travels through its elliptical path near Lagrange Point 2, orbital energy is perfectly conserved. Moving further from the Sun increases its gravitational potential energy while shedding kinetic velocity from 1.0 km/s down to 0.2 km/s.",
    exampleFormula: "E_{\\text{total}} = \\frac{1}{2}mv^2 - \\frac{G M m}{r} = \\text{Constant}",
    modelFormula: "E_k + E_p = \\text{Constant}",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 25
  },
  {
    id: 'seed_energy_generic',
    conceptId: 'conservation_of_energy',
    conceptTitle: "Conservation of Mechanical Energy",
    interestCategory: 'generic',
    exampleText: "A 2 kg pendulum released from a height of 1.5 meters holds 29.4 J of potential energy. At the bottom of its swing where height is zero, all 29.4 J has converted to kinetic energy, giving it a maximum velocity of 5.42 m/s.",
    exampleFormula: "v = \\sqrt{2 g h} = \\sqrt{2 \\times 9.8 \\times 1.5} \\approx 5.42\\text{ m/s}",
    modelFormula: "E_k + E_p = \\text{Constant}",
    generatedAt: '2026-09-23T00:00:00.000Z',
    engagementScore: 7
  }
];

export class ExampleCache {
  private static memoryCache: Map<string, GeneratedExample> = new Map();

  private static getCacheKey(conceptId: string, category: string): string {
    return `${conceptId.toLowerCase().trim()}:${category.toLowerCase().trim()}`;
  }

  public static initialize(): void {
    // Populate with seeds
    SEED_EXAMPLES.forEach(ex => {
      this.memoryCache.set(this.getCacheKey(ex.conceptId, ex.interestCategory), ex);
    });

    // Merge from localStorage
    try {
      const raw = localStorage.getItem(CACHE_STORAGE_KEY);
      if (raw) {
        const stored: GeneratedExample[] = JSON.parse(raw);
        if (Array.isArray(stored)) {
          stored.forEach(ex => {
            this.memoryCache.set(this.getCacheKey(ex.conceptId, ex.interestCategory), ex);
          });
        }
      }
    } catch (e) {
      console.error('Error loading example cache from storage:', e);
    }
  }

  public static get(conceptId: string, category: string): GeneratedExample | null {
    if (this.memoryCache.size === 0) {
      this.initialize();
    }
    return this.memoryCache.get(this.getCacheKey(conceptId, category)) || null;
  }

  public static put(example: GeneratedExample): void {
    if (this.memoryCache.size === 0) {
      this.initialize();
    }
    this.memoryCache.set(this.getCacheKey(example.conceptId, example.interestCategory), example);

    try {
      const all = Array.from(this.memoryCache.values());
      localStorage.setItem(CACHE_STORAGE_KEY, JSON.stringify(all.slice(-100))); // keep last 100
    } catch (e) {
      console.error('Error persisting example to storage:', e);
    }
  }

  public static getTrio(
    conceptId: string,
    primaryCategory: string,
    secondaryCategory: string
  ): { primary: GeneratedExample | null; secondary: GeneratedExample | null; generic: GeneratedExample | null } {
    return {
      primary: this.get(conceptId, primaryCategory),
      secondary: this.get(conceptId, secondaryCategory),
      generic: this.get(conceptId, 'generic')
    };
  }
}
