import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Grid3X3, Info, BarChart2, RefreshCw, Save, HelpCircle, ChevronRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { cn } from '@/src/lib/utils';

interface GenotypeInfo {
  allele1: string;
  allele2: string;
}

interface ResultStats {
  genotype: string;
  count: number;
  percentage: number;
  phenotype: string;
}

export const PunnettSquareSimulator: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  const [crossType, setCrossType] = useState<'monohybrid' | 'dihybrid'>('monohybrid');
  
  // Monohybrid State
  const [parent1, setParent1] = useState<GenotypeInfo>({ allele1: 'T', allele2: 't' });
  const [parent2, setParent2] = useState<GenotypeInfo>({ allele1: 'T', allele2: 't' });
  
  // Dihybrid State
  const [dihybridP1, setDihybridP1] = useState({ a1: 'T', a2: 't', b1: 'R', b2: 'r' });
  const [dihybridP2, setDihybridP2] = useState({ a1: 'T', a2: 't', b1: 'R', b2: 'r' });

  const [trait1, setTrait1] = useState({ name: 'Plant Height', dom: 'Tall', rec: 'Dwarf' });
  const [trait2, setTrait2] = useState({ name: 'Seed Shape', dom: 'Round', rec: 'Wrinkled' });

  // Logic to calculate Punnett Square
  const results = useMemo(() => {
    if (crossType === 'monohybrid') {
      const p1 = [parent1.allele1, parent1.allele2];
      const p2 = [parent2.allele1, parent2.allele2];
      
      const square = [];
      for (let i = 0; i < p2.length; i++) {
        for (let j = 0; j < p1.length; j++) {
          const alleles = [p2[i], p1[j]].sort((a, b) => {
            if (a === a.toUpperCase() && b === b.toLowerCase()) return -1;
            if (a === a.toLowerCase() && b === b.toUpperCase()) return 1;
            return a.localeCompare(b);
          });
          square.push(alleles.join(''));
        }
      }

      const counts: Record<string, number> = {};
      square.forEach(g => { counts[g] = (counts[g] || 0) + 1; });

      const stats: ResultStats[] = Object.keys(counts).map(g => {
        const isDominant = g.includes(parent1.allele1.toUpperCase()) || g.includes(parent2.allele1.toUpperCase());
        return {
          genotype: g,
          count: counts[g],
          percentage: (counts[g] / 4) * 100,
          phenotype: isDominant ? trait1.dom : trait1.rec
        };
      }).sort((a, b) => b.count - a.count);

      return { square, stats, size: 2 };
    } else {
      // Dihybrid: 4x4 grid
      const getGametes = (a1: string, a2: string, b1: string, b2: string) => [
        a1 + b1, a1 + b2, a2 + b1, a2 + b2
      ];
      
      const gametes1 = getGametes(dihybridP1.a1, dihybridP1.a2, dihybridP1.b1, dihybridP1.b2);
      const gametes2 = getGametes(dihybridP2.a1, dihybridP2.a2, dihybridP2.b1, dihybridP2.b2);

      const square = [];
      for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
          const g1 = gametes1[j];
          const g2 = gametes2[i];
          
          // Combine and sort: TtRr
          const resA = [g1[0], g2[0]].sort((a, b) => (a === a.toUpperCase() ? -1 : 1)).join('');
          const resB = [g1[1], g2[1]].sort((a, b) => (a === a.toUpperCase() ? -1 : 1)).join('');
          square.push(resA + resB);
        }
      }

      const counts: Record<string, number> = {};
      square.forEach(g => { counts[g] = (counts[g] || 0) + 1; });

      const stats: ResultStats[] = Object.keys(counts).map(g => {
        const hasDomA = g.includes(dihybridP1.a1.toUpperCase());
        const hasDomB = g.includes(dihybridP1.b1.toUpperCase());
        let phenotype = '';
        if (hasDomA && hasDomB) phenotype = `${trait1.dom} & ${trait2.dom}`;
        else if (hasDomA) phenotype = `${trait1.dom} & ${trait2.rec}`;
        else if (hasDomB) phenotype = `${trait1.rec} & ${trait2.dom}`;
        else phenotype = `${trait1.rec} & ${trait2.rec}`;

        return {
          genotype: g,
          count: counts[g],
          percentage: (counts[g] / 16) * 100,
          phenotype
        };
      }).sort((a, b) => b.count - a.count);

      return { square, stats, size: 4, gametes1, gametes2 };
    }
  }, [crossType, parent1, parent2, dihybridP1, dihybridP2, trait1, trait2]);

  const handleReset = () => {
    setParent1({ allele1: 'T', allele2: 't' });
    setParent2({ allele1: 'T', allele2: 't' });
  };

  const saveToNotes = () => {
    const traitInfo = crossType === 'monohybrid' 
      ? `${trait1.name} (${trait1.dom} vs ${trait1.rec})`
      : `${trait1.name} & ${trait2.name}`;
      
    const note = {
      title: `Genetics Analysis: ${traitInfo}`,
      summary: `${crossType === 'monohybrid' ? 'Monohybrid' : 'Dihybrid'} inheritance simulation. Results show a ${results.stats.map(s => `${s.genotype} (${s.percentage}%)`).join(', ')} distribution.`,
      keyConcepts: ["Mendelian Genetics", "Punnett Square", "Inheritance Patterns", "Genotype vs Phenotype"],
      subject: "Science (Biology)",
      topic: "Principles of Inheritance and Variation"
    };
    window.dispatchEvent(new CustomEvent('save_omni_note', { detail: note }));
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800">
      {/* Header */}
      <div className="p-4 bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <Grid3X3 className="w-5 h-5 text-emerald-500" />
            Mendelian Inheritance Simulator
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">Punnett Square mapping and probability analysis</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleReset}
            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition"
            title="Reset to Monohybrid Cross"
          >
            <RefreshCw size={18} />
          </button>
          <button
            onClick={saveToNotes}
            className="flex items-center gap-2 px-3 py-2 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold rounded-lg transition"
          >
            <Save size={16} /> Save Analysis
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Controls Sidebar */}
        <div className="w-full lg:w-[320px] bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 p-6 overflow-y-auto">
          <div className="space-y-6">
            {/* Cross Type Selector */}
            <div className="space-y-3">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cross Complexity</label>
              <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-lg">
                <button
                  onClick={() => setCrossType('monohybrid')}
                  className={cn(
                    "flex-1 py-1.5 text-[10px] font-bold rounded-md transition-all",
                    crossType === 'monohybrid' ? "bg-white dark:bg-slate-800 shadow-sm text-emerald-600" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  Monohybrid (2x2)
                </button>
                <button
                  onClick={() => setCrossType('dihybrid')}
                  className={cn(
                    "flex-1 py-1.5 text-[10px] font-bold rounded-md transition-all",
                    crossType === 'dihybrid' ? "bg-white dark:bg-slate-800 shadow-sm text-emerald-600" : "text-slate-500 hover:text-slate-700"
                  )}
                >
                  Dihybrid (4x4)
                </button>
              </div>
            </div>

            {/* Trait Config */}
            <div className="space-y-3">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Trait Configuration</label>
              <div className="space-y-2">
                <div className="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-800">
                  <input
                    type="text"
                    value={trait1.name}
                    onChange={(e) => setTrait1({...trait1, name: e.target.value})}
                    className="w-full mb-2 bg-transparent text-xs font-bold outline-none border-b border-transparent focus:border-emerald-500"
                    placeholder="Trait 1 (e.g. Height)"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={trait1.dom}
                      onChange={(e) => setTrait1({...trait1, dom: e.target.value})}
                      className="px-2 py-1 text-[10px] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
                      placeholder="Dominant"
                    />
                    <input
                      type="text"
                      value={trait1.rec}
                      onChange={(e) => setTrait1({...trait1, rec: e.target.value})}
                      className="px-2 py-1 text-[10px] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
                      placeholder="Recessive"
                    />
                  </div>
                </div>

                {crossType === 'dihybrid' && (
                  <div className="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-800">
                    <input
                      type="text"
                      value={trait2.name}
                      onChange={(e) => setTrait2({...trait2, name: e.target.value})}
                      className="w-full mb-2 bg-transparent text-xs font-bold outline-none border-b border-transparent focus:border-emerald-500"
                      placeholder="Trait 2 (e.g. Shape)"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={trait2.dom}
                        onChange={(e) => setTrait2({...trait2, dom: e.target.value})}
                        className="px-2 py-1 text-[10px] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
                        placeholder="Dominant"
                      />
                      <input
                        type="text"
                        value={trait2.rec}
                        onChange={(e) => setTrait2({...trait2, rec: e.target.value})}
                        className="px-2 py-1 text-[10px] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
                        placeholder="Recessive"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Parent Genotypes */}
            <div className="space-y-4">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Parent Genotypes</label>
              
              {crossType === 'monohybrid' ? (
                <>
                  <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-3">Parent 1 (Top)</span>
                    <div className="flex gap-2">
                      <select value={parent1.allele1} onChange={(e) => setParent1({...parent1, allele1: e.target.value})} className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-2 py-1 text-sm outline-none">
                        <option value="T">T (Dom)</option><option value="t">t (Rec)</option>
                      </select>
                      <select value={parent1.allele2} onChange={(e) => setParent1({...parent1, allele2: e.target.value})} className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-2 py-1 text-sm outline-none">
                        <option value="T">T (Dom)</option><option value="t">t (Rec)</option>
                      </select>
                    </div>
                  </div>
                  <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-3">Parent 2 (Left)</span>
                    <div className="flex gap-2">
                      <select value={parent2.allele1} onChange={(e) => setParent2({...parent2, allele1: e.target.value})} className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-2 py-1 text-sm outline-none">
                        <option value="T">T (Dom)</option><option value="t">t (Rec)</option>
                      </select>
                      <select value={parent2.allele2} onChange={(e) => setParent2({...parent2, allele2: e.target.value})} className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-2 py-1 text-sm outline-none">
                        <option value="T">T (Dom)</option><option value="t">t (Rec)</option>
                      </select>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-3">Parent 1 (Top)</span>
                    <div className="grid grid-cols-2 gap-2">
                      <select value={dihybridP1.a1} onChange={(e) => setDihybridP1({...dihybridP1, a1: e.target.value})} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-1 text-xs outline-none">
                        <option value="T">T</option><option value="t">t</option>
                      </select>
                      <select value={dihybridP1.a2} onChange={(e) => setDihybridP1({...dihybridP1, a2: e.target.value})} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-1 text-xs outline-none">
                        <option value="T">T</option><option value="t">t</option>
                      </select>
                      <select value={dihybridP1.b1} onChange={(e) => setDihybridP1({...dihybridP1, b1: e.target.value})} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-1 text-xs outline-none">
                        <option value="R">R</option><option value="r">r</option>
                      </select>
                      <select value={dihybridP1.b2} onChange={(e) => setDihybridP1({...dihybridP1, b2: e.target.value})} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-1 text-xs outline-none">
                        <option value="R">R</option><option value="r">r</option>
                      </select>
                    </div>
                  </div>
                  <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-3">Parent 2 (Left)</span>
                    <div className="grid grid-cols-2 gap-2">
                      <select value={dihybridP2.a1} onChange={(e) => setDihybridP2({...dihybridP2, a1: e.target.value})} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-1 text-xs outline-none">
                        <option value="T">T</option><option value="t">t</option>
                      </select>
                      <select value={dihybridP2.a2} onChange={(e) => setDihybridP2({...dihybridP2, a2: e.target.value})} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-1 text-xs outline-none">
                        <option value="T">T</option><option value="t">t</option>
                      </select>
                      <select value={dihybridP2.b1} onChange={(e) => setDihybridP2({...dihybridP2, b1: e.target.value})} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-1 text-xs outline-none">
                        <option value="R">R</option><option value="r">r</option>
                      </select>
                      <select value={dihybridP2.b2} onChange={(e) => setDihybridP2({...dihybridP2, b2: e.target.value})} className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-1 py-1 text-xs outline-none">
                        <option value="R">R</option><option value="r">r</option>
                      </select>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Main Simulator View */}
        <div className="flex-1 flex flex-col p-6 overflow-y-auto">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            {/* The Punnett Grid */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <Grid3X3 className="w-4 h-4 text-emerald-500" /> Interaction Grid
              </h3>
              
              <div className="relative p-12 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm inline-block mx-auto min-w-[340px]">
                {/* Top Parent Label */}
                <div className="absolute top-0 left-[80px] right-0 h-12 flex justify-around items-center">
                  {(crossType === 'monohybrid' ? [parent1.allele1, parent1.allele2] : (results.gametes1 || [])).map((g, idx) => (
                    <div key={idx} className="flex-1 text-center text-lg font-black text-emerald-500 font-mono">{g}</div>
                  ))}
                </div>
                
                {/* Left Parent Label */}
                <div className="absolute left-0 top-[80px] bottom-0 w-12 flex flex-col justify-around items-center">
                  {(crossType === 'monohybrid' ? [parent2.allele1, parent2.allele2] : (results.gametes2 || [])).map((g, idx) => (
                    <div key={idx} className="flex-1 flex items-center text-lg font-black text-emerald-500 font-mono">{g}</div>
                  ))}
                </div>

                {/* The Grid Square */}
                <div 
                  className={cn(
                    "grid gap-2 mt-2 ml-4",
                    results.size === 2 ? "grid-cols-2" : "grid-cols-4"
                  )}
                >
                  {results.square.map((genotype, idx) => {
                    const isAllDominant = results.size === 4 
                      ? (genotype.includes(dihybridP1.a1.toUpperCase()) && genotype.includes(dihybridP1.b1.toUpperCase())) 
                      : genotype.includes(parent1.allele1.toUpperCase());
                    
                    return (
                      <motion.div
                        key={idx}
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ delay: idx * 0.02 }}
                        className={cn(
                          "flex flex-col items-center justify-center rounded-lg border-2 transition-all",
                          results.size === 2 ? "w-24 h-24" : "w-16 h-16",
                          isAllDominant
                            ? "bg-emerald-100 border-emerald-300 dark:bg-emerald-950 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400"
                            : "bg-slate-100 border-slate-300 dark:bg-slate-900 dark:border-slate-800 text-slate-700 dark:text-slate-400"
                        )}
                      >
                        <span className={cn("font-black font-mono", results.size === 4 ? "text-xs" : "text-2xl")}>{genotype}</span>
                        {results.size === 2 && (
                          <span className="text-[10px] font-bold uppercase opacity-60 text-center px-1">
                            {genotype.includes(parent1.allele1.toUpperCase()) ? trait1.dom : trait1.rec}
                          </span>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/20 rounded-xl border border-emerald-100 dark:border-emerald-800/50">
                <h4 className="text-xs font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-1.5 mb-2">
                  <HelpCircle size={14} /> Mendelian Insights
                </h4>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-500 leading-relaxed">
                  {crossType === 'monohybrid' 
                    ? "Mendel's Law of Segregation states that during gamete formation, the alleles for each gene segregate so that each gamete carries only one allele."
                    : "Mendel's Law of Independent Assortment states that the alleles of two (or more) different genes get sorted into gametes independently of one another."}
                </p>
              </div>
            </div>

            {/* Statistics & Chart */}
            <div className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-indigo-500" /> Probability Analysis
                </h3>
                
                <div className="h-[250px] w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
                  <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                    <BarChart data={results.stats}>
                      <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#1e293b' : '#f1f5f9'} vertical={false} />
                      <XAxis 
                        dataKey="genotype" 
                        fontSize={10} 
                        fontWeight="bold" 
                        axisLine={false} 
                        tickLine={false}
                        tick={{ fill: theme === 'dark' ? '#94a3b8' : '#64748b' }}
                      />
                      <YAxis 
                        fontSize={10} 
                        fontWeight="bold" 
                        axisLine={false} 
                        tickLine={false} 
                        unit="%"
                        tick={{ fill: theme === 'dark' ? '#94a3b8' : '#64748b' }}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                          border: 'none',
                          borderRadius: '12px',
                          boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                        }}
                      />
                      <Bar dataKey="percentage" radius={[8, 8, 0, 0]}>
                        {results.stats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#10b981' : '#6366f1'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Genotype List */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Offspring Phenotypes</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {results.stats.map((stat, idx) => (
                    <div 
                      key={idx}
                      className="p-3 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between group hover:border-emerald-500/50 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-900 flex items-center justify-center text-xs font-black font-mono">
                          {stat.genotype}
                        </div>
                        <div className="max-w-[100px] truncate">
                          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Phenotype</p>
                          <p className="text-[10px] font-bold text-slate-700 dark:text-slate-200 truncate">{stat.phenotype}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-black text-emerald-500">{stat.percentage}%</p>
                        <p className="text-[9px] font-bold text-slate-400">{stat.count}/{results.size * results.size} Ratio</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
