import React, { useState } from 'react';
import {
  X,
  Sparkles,
  RefreshCw,
  Send,
  BookOpen,
  Layers,
  Brain,
  Sliders,
  Maximize2,
  Minimize2,
  FileText
} from 'lucide-react';
import { cn } from '../lib/utils';
import { VisualTransformationPresenter } from './VisualTransformationPresenter';
import {
  SEED_AND_FRUIT_FORMATION_PACKAGE,
  transformationPresentationService
} from '../services/transformationPresentationService';
import { TransformationPresentationPackage } from '../types/transformationPresentation';

interface VisualTransformationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeliverToSmartboard?: (contentMarkdown: string, topicTitle: string) => void;
  onSpeak?: (text: string) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  initialRawInput?: string;
  theme?: 'light' | 'dark' | string;
}

export const VisualTransformationModal: React.FC<VisualTransformationModalProps> = ({
  isOpen,
  onClose,
  onDeliverToSmartboard,
  onSpeak,
  showNotification,
  initialRawInput,
  theme = 'dark'
}) => {
  const [currentPackage, setCurrentPackage] = useState<TransformationPresentationPackage>(SEED_AND_FRUIT_FORMATION_PACKAGE);
  const [customTextInput, setCustomTextInput] = useState<string>(initialRawInput || '');
  const [showCustomInputDrawer, setShowCustomInputDrawer] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleGenerateCustom = async () => {
    if (!customTextInput.trim()) {
      showNotification?.('Please enter raw table data or a topic prompt.', 'warning');
      return;
    }
    setIsGenerating(true);
    try {
      const pkg = await transformationPresentationService.generateDynamicTransformation(customTextInput);
      setCurrentPackage(pkg);
      setShowCustomInputDrawer(false);
      showNotification?.(`Generated presentation: "${pkg.titleHindi}"!`, 'success');
    } catch (err) {
      showNotification?.('Failed to generate presentation. Using default.', 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className={cn(
        "w-full rounded-3xl border flex flex-col overflow-hidden transition-all shadow-2xl",
        isFullscreen ? "h-[98vh] max-w-[98vw]" : "h-[92vh] max-w-6xl",
        theme === 'dark' ? "bg-slate-950 border-cyan-500/40 text-white" : "bg-slate-900 border-slate-700 text-white"
      )}>
        
        {/* Modal Top Control Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950/90 border-b border-cyan-500/30 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-pink-600 text-white shadow-md">
              <Sparkles size={20} />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                Visual Transformation Architect Studio
                <span className="text-xs font-semibold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded-full border border-cyan-500/30">
                  Professor Clarity Engine
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Transforms raw tabular data into 5 interactive pedagogical modes with ploidy badges, memory mnemonics, & 3D smartboard delivery.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCustomInputDrawer(prev => !prev)}
              className={cn(
                "px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 cursor-pointer",
                showCustomInputDrawer
                  ? "bg-cyan-600 border-cyan-500 text-white"
                  : "bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800"
              )}
            >
              <FileText size={14} />
              <span>{showCustomInputDrawer ? "Hide Raw Data Input" : "Paste Raw Table Data"}</span>
            </button>

            <button
              onClick={() => setIsFullscreen(prev => !prev)}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors border border-slate-800 cursor-pointer"
              title={isFullscreen ? "Exit Fullscreen" : "Fullscreen View"}
            >
              {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 hover:bg-red-950/80 text-slate-300 hover:text-red-400 transition-colors border border-slate-800 hover:border-red-800 cursor-pointer"
              title="Close Modal"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Custom Input Drawer (Optional when user wants to paste raw markdown table) */}
        {showCustomInputDrawer && (
          <div className="p-4 bg-slate-900/95 border-b border-cyan-500/30 space-y-3 shrink-0 animate-fadeIn">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-cyan-400 uppercase tracking-wider">
                Paste Any Raw Tabular Data (Biology, Chemistry, Physics, etc.)
              </span>
              <button
                onClick={() => {
                  setCustomTextInput(`| निषेचन से पूर्व (Pre-Fertilization) | निषेचन के बाद की संरचना (Post-Fertilization Structure) | गुणसूत्रता (Ploidy Level) |
| :- | :- | :- |
| अंडाशय (Ovary) | फल (Fruit) | 2N |
| अंडाशय भित्ति (Ovary Wall) | फलभित्ति (Pericarp) | 2N |
| बीजांड (Ovule) | बीज (Seed) | 2N |
| युग्मनज (Zygote) | भ्रूण (Embryo) | 2N |
| PEN (Primary Endosperm Nucleus) | भ्रूणपोष (Endosperm) | 3N |
| अध्यावरण (Integuments) | बीजावरण (Seed Coat - Testa & Tegmen) | 2N |
| बीजांडकाय (Nucellus) | परिभ्रूणपोष (Perisperm) - (उदा. काली मिर्च, चुकंदर) | 2N |`);
                }}
                className="text-[11px] font-bold text-slate-400 hover:text-cyan-300 underline cursor-pointer"
              >
                Insert Seed & Fruit Formation Table
              </button>
            </div>

            <textarea
              value={customTextInput}
              onChange={(e) => setCustomTextInput(e.target.value)}
              placeholder="Paste raw markdown table or describe transformation stages..."
              rows={4}
              className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-cyan-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
            />

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={handleGenerateCustom}
                disabled={isGenerating}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-black text-xs transition-all shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isGenerating ? <RefreshCw size={14} className="animate-spin" /> : <Sparkles size={14} />}
                <span>{isGenerating ? "Transforming with AI..." : "Architect Visual Presentation"}</span>
              </button>
            </div>
          </div>
        )}

        {/* Modal Body Container with Visual Transformation Presenter */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 sm:p-4">
          <VisualTransformationPresenter
            packageData={currentPackage}
            theme={theme}
            onDeliverToSmartboard={onDeliverToSmartboard}
            onSpeak={onSpeak}
            showNotification={showNotification}
            isInsideModal={true}
          />
        </div>

      </div>
    </div>
  );
};
