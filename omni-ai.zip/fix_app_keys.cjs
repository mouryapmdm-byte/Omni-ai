const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

code = code.replace(
  /\} else if \(e\.code === 'ArrowLeft' \|\| e\.key === 'ArrowLeft'\) \{[^}]+mediaElements\.forEach\(media => \{[^}]+media\.currentTime = Math\.max\(0, media\.currentTime - 5\);[^}]+\}\);/s,
  `} else if (e.code === 'ArrowLeft' || e.key === 'ArrowLeft') {
        e.preventDefault();
        mediaElements.forEach(media => {
          try {
            if (media.readyState >= 1) {
              media.currentTime = Math.max(0, media.currentTime - 5);
            }
          } catch(err) {}
        });`
);

code = code.replace(
  /\} else if \(e\.code === 'ArrowRight' \|\| e\.key === 'ArrowRight'\) \{[^}]+mediaElements\.forEach\(media => \{[^}]+media\.currentTime = Math\.min\(media\.duration \|\| Infinity, media\.currentTime \+ 5\);[^}]+\}\);/s,
  `} else if (e.code === 'ArrowRight' || e.key === 'ArrowRight') {
        e.preventDefault();
        mediaElements.forEach(media => {
          try {
            if (media.readyState >= 1) {
              media.currentTime = Math.min(media.duration || Infinity, media.currentTime + 5);
            }
          } catch(err) {}
        });`
);

fs.writeFileSync('src/App.tsx', code);
