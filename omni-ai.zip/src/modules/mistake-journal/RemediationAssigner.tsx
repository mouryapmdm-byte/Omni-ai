import React, { useState } from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  Zap, 
  HelpCircle, 
  ShieldAlert, 
  RefreshCw, 
  Award, 
  BookOpen 
} from 'lucide-react';
import { Mistake, RemediationQuestion, MistakeCategory } from './types';
import { MistakeClassifier, MISTAKE_CATEGORY_INFO } from './mistakeClassifier';

interface RemediationAssignerProps {
  isDark?: boolean;
  mistakes: Mistake[];
  onRemediationComplete?: (mistakeId: string, success: boolean) => void;
  showNotification?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
}

export const RemediationAssigner: React.FC<RemediationAssignerProps> = ({
  isDark = true,
  mistakes,
  onRemediationComplete,
  showNotification
}) => {
  const unresolvedMistakes = mistakes.filter(m => !m.improved);
  const activeMistake = unresolvedMistakes[0] || mistakes[0];

  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);

  // Dynamic Remediation Question Generator based on active mistake category
  const remediationData: RemediationQuestion = React.useMemo(() => {
    if (!activeMistake) {
      return {
        id: 'rem_default',
        mistakeRefId: 'none',
        questionText: 'Which of the following represents the correct Cartesian sign convention for focal length of a concave mirror?',
        options: ['f is always positive (+)', 'f is always negative (-)', 'f depends on object distance', 'f is zero at pole'],
        correctAnswer: 'f is always negative (-)',
        explanation: 'Concave mirror focal point lies in front of mirror surface (against incident rays), hence f < 0.',
        targetMistakeType: 'sign_error',
        trapWarning: 'Common trap: Don’t confuse concave mirror (f < 0) with convex mirror (f > 0).',
        subject: 'Physics',
        topic: 'Optics'
      };
    }

    if (activeMistake.mistakeType === 'sign_error') {
      return {
        id: 'rem_sign_1',
        mistakeRefId: activeMistake.id,
        questionText: 'An object is placed 15 cm in front of a concave mirror of focal length 10 cm. Using the mirror formula (1/f = 1/v + 1/u), what is the image distance v?',
        options: ['-30 cm', '+30 cm', '-6 cm', '+6 cm'],
        correctAnswer: '-30 cm',
        explanation: 'u = -15 cm, f = -10 cm. 1/v = 1/f - 1/u = -1/10 - (-1/15) = -1/30 ⇒ v = -30 cm (Real, inverted image).',
        targetMistakeType: 'sign_error',
        trapWarning: 'Trap Alert: Forgetting that u is always negative (-15 cm) causes a sign cancellation error.',
        subject: activeMistake.subject,
        topic: activeMistake.topicName
      };
    } else if (activeMistake.mistakeType === 'unit_error') {
      return {
        id: 'rem_unit_1',
        mistakeRefId: activeMistake.id,
        questionText: 'A heat engine absorbs 5 kJ of heat from a hot reservoir and performs 2000 J of work. How much heat is rejected to the cold sink in kJ?',
        options: ['3 kJ', '3000 kJ', '4.8 kJ', '2.5 kJ'],
        correctAnswer: '3 kJ',
        explanation: 'Q_in = 5 kJ = 5000 J. W = 2000 J = 2 kJ. Q_out = Q_in - W = 5 kJ - 2 kJ = 3 kJ.',
        targetMistakeType: 'unit_error',
        trapWarning: 'Trap Alert: Ensure both quantities are in the same SI scale (kJ vs J) before subtracting.',
        subject: activeMistake.subject,
        topic: activeMistake.topicName
      };
    } else if (activeMistake.mistakeType === 'reading_comprehension') {
      return {
        id: 'rem_reading_1',
        mistakeRefId: activeMistake.id,
        questionText: 'Which of the following statements regarding ideal gases is INCORRECT?',
        options: [
          'Collisions between molecules are perfectly elastic',
          'Intermolecular attractive forces are significant at low pressure',
          'Volume of gas molecules is negligible compared to vessel volume',
          'Average kinetic energy depends solely on absolute temperature'
        ],
        correctAnswer: 'Intermolecular attractive forces are significant at low pressure',
        explanation: 'In ideal gas theory, intermolecular attractive forces are assumed to be ZERO. At low pressure, real gases behave ideally.',
        targetMistakeType: 'reading_comprehension',
        trapWarning: 'Trap Alert: The question explicitly asks for the INCORRECT option.',
        subject: activeMistake.subject,
        topic: activeMistake.topicName
      };
    } else {
      return {
        id: 'rem_concept_1',
        mistakeRefId: activeMistake.id,
        questionText: `Targeted Concept Validation: In ${activeMistake.chapterName}, which of the following represents the foundational theorem?`,
        options: [
          'Conservation of Total Energy & Momentum',
          'Linear scaling with squared time',
          'Independent coordinate superposition',
          'Direct proportionality to temperature'
        ],
        correctAnswer: 'Conservation of Total Energy & Momentum',
        explanation: 'Conservation laws govern the closed system boundaries across both mechanics and thermal transitions.',
        targetMistakeType: activeMistake.mistakeType,
        trapWarning: 'Review the boundary conditions of this law.',
        subject: activeMistake.subject,
        topic: activeMistake.topicName
      };
    }
  }, [activeMistake]);

  const handleSubmit = () => {
    if (!selectedOption) return;
    const correct = selectedOption === remediationData.correctAnswer;
    setIsCorrect(correct);
    setHasSubmitted(true);

    if (correct && activeMistake) {
      MistakeClassifier.markReviewed(activeMistake.id, true);
      onRemediationComplete?.(activeMistake.id, true);
      showNotification?.('🎉 Concept Mastered! Mistake marked as resolved.', 'success');
    } else {
      showNotification?.('⚠️ Incorrect on drill. Review the trap warning carefully.', 'warning');
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setHasSubmitted(false);
    setIsCorrect(false);
  };

  return (
    <div className={`p-6 rounded-2xl border space-y-6 ${
      isDark ? 'bg-slate-900/90 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
    }`}>
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/60 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold">Targeted Concept Remediation Engine</h2>
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                {unresolvedMistakes.length} Active Gaps
              </span>
            </div>
            <p className="text-xs opacity-60">Re-testing your vulnerable concepts in fresh contexts to rewire cognitive traps</p>
          </div>
        </div>

        {activeMistake && (
          <span className={`text-xs px-3 py-1 rounded-full border font-bold ${MISTAKE_CATEGORY_INFO[activeMistake.mistakeType]?.badgeColor}`}>
            Target: {MISTAKE_CATEGORY_INFO[activeMistake.mistakeType]?.name}
          </span>
        )}
      </div>

      {/* Target Question Card */}
      <div className={`p-5 rounded-2xl border space-y-4 ${
        isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
      }`}>
        <div className="flex items-center justify-between text-xs opacity-70">
          <span className="font-bold text-indigo-400">
            {remediationData.subject} • {remediationData.topic}
          </span>
          <span className="text-[11px] font-mono">Remediation Question</span>
        </div>

        <p className="text-sm font-semibold leading-relaxed">
          {remediationData.questionText}
        </p>

        {/* Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {remediationData.options?.map((opt, idx) => {
            const isSelected = selectedOption === opt;
            const isAnswer = opt === remediationData.correctAnswer;

            let optionClass = isDark ? 'bg-slate-900 border-slate-700 hover:border-slate-500' : 'bg-white border-slate-200 hover:border-slate-400';
            if (hasSubmitted) {
              if (isAnswer) {
                optionClass = 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold';
              } else if (isSelected && !isCorrect) {
                optionClass = 'bg-rose-500/20 border-rose-500 text-rose-300 font-bold';
              }
            } else if (isSelected) {
              optionClass = 'bg-indigo-600/30 border-indigo-500 text-indigo-200 ring-2 ring-indigo-500';
            }

            return (
              <button
                key={idx}
                disabled={hasSubmitted}
                onClick={() => setSelectedOption(opt)}
                className={`p-3.5 rounded-xl border text-xs text-left font-medium transition-all ${optionClass}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center font-mono text-[10px] shrink-0">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span>{opt}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Trap Warning Box */}
        <div className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
          isDark ? 'bg-amber-950/20 border-amber-800/40 text-amber-200' : 'bg-amber-50 border-amber-200 text-amber-900'
        }`}>
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-[11px] font-bold uppercase tracking-wider">Trap Prevention Warning</strong>
            <p className="text-[11px] opacity-90">{remediationData.trapWarning}</p>
          </div>
        </div>

        {/* Feedback on submit */}
        {hasSubmitted && (
          <div className={`p-4 rounded-xl border text-xs leading-relaxed animate-fadeIn ${
            isCorrect 
              ? isDark ? 'bg-emerald-950/20 border-emerald-800/50 text-emerald-200' : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : isDark ? 'bg-rose-950/20 border-rose-800/50 text-rose-200' : 'bg-rose-50 border-rose-200 text-rose-900'
          }`}>
            <div className="font-bold mb-1 flex items-center gap-1.5">
              {isCorrect ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-rose-400" />}
              {isCorrect ? 'Excellent! Cognitive Trap Avoided.' : 'Incorrect Approach:'}
            </div>
            <p className="text-[11px]">{remediationData.explanation}</p>
          </div>
        )}

        {/* Action Button */}
        <div className="flex items-center justify-end gap-3 pt-2">
          {!hasSubmitted ? (
            <button
              onClick={handleSubmit}
              disabled={!selectedOption}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all ${
                selectedOption
                  ? 'bg-purple-600 hover:bg-purple-700 text-white cursor-pointer'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              Verify Answer
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md flex items-center gap-2"
            >
              Next Remediation Drill <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
