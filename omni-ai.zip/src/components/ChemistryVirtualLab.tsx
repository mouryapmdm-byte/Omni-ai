import React, { useState, useEffect } from 'react';
import { cn } from '@/src/lib/utils';
import { Beaker, FlaskConical, Droplet, Flame, RotateCcw, Play, CheckCircle2, BookOpen, ExternalLink, Sparkles, Sliders, Activity, HelpCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

interface ChemistryVirtualLabProps {
  theme: 'light' | 'dark';
  onOpenChapter: (chapterNumber: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

type ExperimentType = 'coordination_titration' | 'organic_acid_base' | 'halide_solubility' | 'aldehyde_test';

export const ChemistryVirtualLab: React.FC<ChemistryVirtualLabProps> = ({
  theme,
  onOpenChapter,
  showNotification
}) => {
  const [activeExp, setActiveExp] = useState<ExperimentType>('coordination_titration');
  const [titrantVolume, setTitrantVolume] = useState<number>(0); // mL added
  const [isAdding, setIsAdding] = useState(false);
  const [temperature, setTemperature] = useState<number>(25); // °C
  const [hasStarted, setHasStarted] = useState(false);

  // Reset values on experiment switch
  useEffect(() => {
    setTitrantVolume(0);
    setIsAdding(false);
    setHasStarted(false);
  }, [activeExp]);

  // Auto titration drip simulation
  useEffect(() => {
    let timer: any;
    if (isAdding) {
      timer = setInterval(() => {
        setTitrantVolume(prev => {
          const maxVol = activeExp === 'coordination_titration' ? 50 : activeExp === 'organic_acid_base' ? 40 : 20;
          if (prev >= maxVol) {
            setIsAdding(false);
            showNotification?.('Titration / test completed to endpoint!', 'success');
            return maxVol;
          }
          return Number((prev + 0.5).toFixed(1));
        });
      }, 150);
    }
    return () => clearInterval(timer);
  }, [isAdding, activeExp, showNotification]);

  // Derived state for Coordination Titration (Cu2+ + NH3 -> [Cu(NH3)4]2+)
  const coordColor = () => {
    if (titrantVolume === 0) return 'rgba(59, 130, 246, 0.4)'; // pale blue Cu(H2O)6 2+
    if (titrantVolume < 10) return 'rgba(99, 102, 241, 0.6)';
    if (titrantVolume < 25) return 'rgba(129, 140, 248, 0.8)';
    return 'rgba(79, 70, 229, 0.95)'; // deep royal blue [Cu(NH3)4]2+
  };

  // Derived state for Organic Acid-Base Titration (CH3COOH + NaOH with Phenolphthalein)
  const calcPH = () => {
    if (activeExp !== 'organic_acid_base') return 7;
    // Initial pH ~2.9, equivalence at 25mL (pH ~8.7), past eq up to 13
    if (titrantVolume === 0) return 2.9;
    if (titrantVolume < 24) return Number((2.9 + (titrantVolume / 24) * 5.5).toFixed(2));
    if (titrantVolume <= 26) return Number((8.7 + ((titrantVolume - 24) / 2) * 3.5).toFixed(2));
    return Number((12.2 + Math.min(1.5, (titrantVolume - 26) / 10)).toFixed(2));
  };

  const acidBaseColor = () => {
    const ph = calcPH();
    if (ph < 8.2) return 'rgba(255, 255, 255, 0.85)'; // Colorless
    if (ph < 9.5) return 'rgba(244, 114, 182, 0.5)'; // Light pale pink
    return 'rgba(236, 72, 153, 0.9)'; // Vibrant magenta / pink endpoint
  };

  // Derived state for Halide Solubility (R-X + AgNO3 -> AgX ppt)
  const halidePrecipitate = () => {
    if (titrantVolume === 0) return 'Clear Solution (No ppt)';
    if (titrantVolume < 10) return 'Opalescent cloudy white suspension (AgCl ppt)';
    return 'Heavy curdy white / pale yellow precipitate (Soluble in conc. NH3)';
  };

  // Derived state for Aldehyde Test (Tollens Test: RCHO + [Ag(NH3)2]+ -> Ag mirror)
  const aldehydeAppearance = () => {
    if (titrantVolume === 0) return 'Clear Ammoniacal Silver Nitrate solution';
    if (titrantVolume < 15) return 'Darkening colloidal suspension with initial silver deposition';
    return 'Brilliant lustrous Silver Mirror (Ag⁰ coating on inner flask walls)';
  };

  // Chart data points generator
  const getChartData = () => {
    const data = [];
    const max = activeExp === 'coordination_titration' ? 50 : activeExp === 'organic_acid_base' ? 40 : 20;
    for (let v = 0; v <= max; v += 2) {
      let val = 0;
      if (activeExp === 'coordination_titration') {
        val = Number((100 * (1 - Math.exp(-v / 10))).toFixed(1)); // % complex formed
      } else if (activeExp === 'organic_acid_base') {
        // pH curve
        val = v === 0 ? 2.9 : v < 25 ? Number((2.9 + (v / 25) * 5.8).toFixed(1)) : Number((8.7 + Math.min(4.5, (v - 25) * 0.9)).toFixed(1));
      } else if (activeExp === 'halide_solubility') {
        val = Number((v * 5).toFixed(1)); // mg precipitate formed
      } else {
        val = Number((v * 5).toFixed(1)); // % silver mirror intensity
      }
      data.push({ volume: v, metric: val });
    }
    return data;
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-y-auto p-6 md:p-8 selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-slate-50/50 text-slate-900"
    )}>
      {/* Header */}
      <div className={cn(
        "p-6 rounded-3xl border mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl",
        theme === 'dark' ? "bg-gradient-to-r from-teal-950/60 via-slate-900 to-indigo-950/40 border-teal-900/40" : "bg-gradient-to-r from-teal-50 via-white to-indigo-50 border-teal-100"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-teal-600 to-emerald-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-teal-500/30">
            <FlaskConical size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">
                Interactive Virtual Chemistry Laboratory
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Titration & Solubility Workbench
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Conduct precision titrations with Coordination Compounds and Organic Reagents with real-time color transitions and titration curves.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-teal-500/10 text-teal-600 dark:text-teal-400 px-4 py-2 rounded-2xl font-bold text-xs border border-teal-500/20">
          <Sparkles size={16} />
          <span>Real-time Stoichiometry Engine</span>
        </div>
      </div>

      {/* Experiment Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {[
          { id: 'coordination_titration', label: 'Coordination Complex Titration', desc: 'Cu²⁺ + 4NH₃ ⇌ [Cu(NH₃)₄]²⁺', chapter: '9. Coordination', chapNum: 9 },
          { id: 'organic_acid_base', label: 'Organic Acid-Base Titration', desc: 'CH₃COOH vs NaOH + Phenolphthalein', chapter: '12. Carboxylic Acids', chapNum: 12 },
          { id: 'halide_solubility', label: 'Haloalkane Solubility & AgNO₃', desc: 'R-X Precipitation Test', chapter: '10. Haloalkanes', chapNum: 10 },
          { id: 'aldehyde_test', label: "Tollens' Aldehyde Test", desc: 'Silver Mirror Test for RCHO', chapter: '12. Aldehydes & Ketones', chapNum: 12 }
        ].map(exp => (
          <button
            key={exp.id}
            onClick={() => setActiveExp(exp.id as ExperimentType)}
            className={cn(
              "p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between group",
              activeExp === exp.id
                ? "bg-teal-600 text-white border-teal-500 shadow-lg shadow-teal-500/20"
                : theme === 'dark'
                ? "bg-slate-800/80 border-slate-700 hover:border-teal-500/50 text-slate-300"
                : "bg-white border-slate-200 hover:border-teal-300 text-slate-700"
            )}
          >
            <div>
              <div className="text-xs font-black uppercase tracking-wider mb-1 opacity-80">{exp.chapter}</div>
              <div className="text-sm font-extrabold tracking-tight mb-1">{exp.label}</div>
              <div className="text-xs font-mono opacity-80">{exp.desc}</div>
            </div>
            <div className="mt-4 flex items-center justify-between text-[11px] font-bold opacity-90">
              <span>{activeExp === exp.id ? 'Active Experiment' : 'Click to Load'}</span>
              <span className="group-hover:translate-x-1 transition-transform">&rarr;</span>
            </div>
          </button>
        ))}
      </div>

      {/* Main Lab Arena */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left / Center: Visual Beaker & Controls (2 cols) */}
        <div className={cn(
          "lg:col-span-2 p-6 md:p-8 rounded-3xl border shadow-xl flex flex-col justify-between",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div>
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-700/60">
              <div>
                <h3 className="text-lg font-black tracking-tight">
                  {activeExp === 'coordination_titration' && 'Spectrophotometric Coordination Titration'}
                  {activeExp === 'organic_acid_base' && 'Acid-Base Neutralization Titration Curve'}
                  {activeExp === 'halide_solubility' && 'Haloalkane Nucleophilic Substitution & Precipitation'}
                  {activeExp === 'aldehyde_test' && "Tollens' Ammoniacal Silver Mirror Test"}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Controlled dropwise addition from burette into conical flask reaction vessel.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setTitrantVolume(0)}
                  className="p-2 rounded-xl border hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
                  title="Reset Experiment"
                >
                  <RotateCcw size={16} />
                </button>
                <button
                  onClick={() => setIsAdding(!isAdding)}
                  className={cn(
                    "px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md",
                    isAdding
                      ? "bg-amber-600 hover:bg-amber-500 text-white"
                      : "bg-teal-600 hover:bg-teal-500 text-white shadow-teal-500/20"
                  )}
                >
                  <Play size={14} />
                  <span>{isAdding ? 'Pause Drip' : 'Start Titration Drip'}</span>
                </button>
              </div>
            </div>

            {/* Visual Glassware Graphic Area */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center py-6">
              {/* Burette / Dropper visualization */}
              <div className="flex flex-col items-center justify-center">
                <div className="w-6 h-36 bg-slate-200 dark:bg-slate-700 rounded-t-lg border border-slate-300 dark:border-slate-600 relative overflow-hidden flex flex-col justify-end">
                  <div 
                    className="w-full bg-teal-500/80 transition-all duration-200"
                    style={{ height: `${Math.max(10, 100 - (titrantVolume * 2))}%` }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center font-mono text-[10px] font-bold text-slate-800 dark:text-white">
                    Burette
                  </div>
                </div>
                <div className="w-2 h-6 bg-slate-400 dark:bg-slate-600" />
                <div className="text-xs font-mono font-bold mt-2 text-teal-600 dark:text-teal-400">
                  Titrant Added: {titrantVolume.toFixed(1)} mL
                </div>
                {isAdding && (
                  <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-500 animate-pulse mt-1">
                    <Droplet size={12} />
                    <span>Dripping into flask...</span>
                  </div>
                )}
              </div>

              {/* Conical Flask Visualizer */}
              <div className="flex flex-col items-center justify-center">
                <div className="relative w-48 h-48 flex items-center justify-center">
                  {/* Flask SVG outline */}
                  <svg viewBox="0 0 200 200" className="w-full h-full drop-shadow-lg">
                    <polygon points="90,20 110,20 110,60 160,160 40,160" fill="none" stroke="currentColor" strokeWidth="4" className="text-slate-400 dark:text-slate-500" />
                    {/* Liquid Level inside flask */}
                    <path 
                      d="M 52,130 Q 100,120 148,130 L 156,155 Q 100,160 44,155 Z" 
                      fill={
                        activeExp === 'coordination_titration' ? coordColor() :
                        activeExp === 'organic_acid_base' ? acidBaseColor() :
                        activeExp === 'halide_solubility' ? (titrantVolume > 0 ? 'rgba(241, 245, 249, 0.9)' : 'rgba(255, 255, 255, 0.4)') :
                        (titrantVolume > 10 ? 'rgba(203, 213, 225, 0.95)' : 'rgba(254, 243, 199, 0.6)')
                      }
                      className="transition-colors duration-300"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-center">
                    <span className="text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-900/80 text-white backdrop-blur shadow">
                      Reaction Flask
                    </span>
                  </div>
                </div>

                <div className="mt-3 text-center">
                  <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    {activeExp === 'coordination_titration' && `Complex State: ${titrantVolume < 10 ? 'Pale Blue Aqua Ion' : 'Deep Blue Tetraamminecopper(II)'}`}
                    {activeExp === 'organic_acid_base' && `Indicator State: pH ${calcPH()} (${calcPH() < 8.2 ? 'Colorless (Acid)' : 'Pink (Endpoint)'})`}
                    {activeExp === 'halide_solubility' && halidePrecipitate()}
                    {activeExp === 'aldehyde_test' && aldehydeAppearance()}
                  </div>
                </div>
              </div>
            </div>

            {/* Manual Controls */}
            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700/60">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase tracking-wider text-slate-400">Manual Titrant Volume Slider</span>
                <span className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400">{titrantVolume} mL</span>
              </div>
              <input
                type="range"
                min="0"
                max={activeExp === 'coordination_titration' ? 50 : activeExp === 'organic_acid_base' ? 40 : 20}
                step="0.5"
                value={titrantVolume}
                onChange={(e) => setTitrantVolume(Number(e.target.value))}
                className="w-full accent-teal-600 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Live Titration Analytics Chart & Stoichiometry (1 col) */}
        <div className="space-y-6 flex flex-col justify-between">
          {/* Chart Card */}
          <div className={cn(
            "p-6 rounded-3xl border shadow-xl flex flex-col",
            theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
          )}>
            <div className="flex items-center justify-between mb-4">
              <div className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <Activity size={16} className="text-teal-500" />
                <span>
                  {activeExp === 'organic_acid_base' ? 'Titration Curve (pH vs Volume)' : 'Response & Yield Curve'}
                </span>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-teal-500/10 text-teal-600 dark:text-teal-400">
                Live Data
              </span>
            </div>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <LineChart data={getChartData()}>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#334155' : '#e2e8f0'} />
                  <XAxis dataKey="volume" stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} fontSize={10} unit=" mL" />
                  <YAxis stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} fontSize={10} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: theme === 'dark' ? '#1e293b' : '#ffffff',
                      borderColor: theme === 'dark' ? '#334155' : '#e2e8f0',
                      borderRadius: '12px',
                      fontSize: '12px'
                    }}
                  />
                  <Line type="monotone" dataKey="metric" stroke="#0d9488" strokeWidth={3} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Stoichiometry & Textbook Link Card */}
          <div className={cn(
            "p-6 rounded-3xl border shadow-xl",
            theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
          )}>
            <div className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
              Stoichiometric & Textbook Reference
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
              {activeExp === 'coordination_titration' && 'Coordination complex formation involves stepwise ligand substitution where ammonia replaces coordinated water molecules in [Cu(H₂O)₆]²⁺.'}
              {activeExp === 'organic_acid_base' && 'Neutralization of weak acetic acid with strong base NaOH exhibits a sharp inflection point near pH 8.7 at equivalence point.'}
              {activeExp === 'halide_solubility' && 'Haloalkanes react with alcoholic silver nitrate to precipitate insoluble silver halides (AgCl, AgBr, AgI) based on C-X bond cleavage.'}
              {activeExp === 'aldehyde_test' && "Tollens' test oxidizes aldehydes to carboxylate anions while reducing diamminesilver(I) complex to elemental silver (silver mirror)."}
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-700/60">
              <div className="flex items-center gap-1.5 text-xs font-bold text-teal-600 dark:text-teal-400">
                <BookOpen size={14} />
                <span>
                  {activeExp === 'coordination_titration' ? 'Chapter 9: Coordination Compounds' :
                   activeExp === 'organic_acid_base' ? 'Chapter 12: Carboxylic Acids' :
                   activeExp === 'halide_solubility' ? 'Chapter 10: Haloalkanes' : 'Chapter 12: Aldehydes & Ketones'}
                </span>
              </div>
              <button
                onClick={() => onOpenChapter(
                  activeExp === 'coordination_titration' ? 9 :
                  activeExp === 'organic_acid_base' ? 12 :
                  activeExp === 'halide_solubility' ? 10 : 12
                )}
                className="flex items-center gap-1 bg-teal-50 hover:bg-teal-600 text-teal-600 hover:text-white dark:bg-teal-950/60 dark:hover:bg-teal-600 dark:text-teal-300 text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-sm"
              >
                <span>Read Chapter</span>
                <ExternalLink size={12} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
