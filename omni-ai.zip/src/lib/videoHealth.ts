/**
 * Video Playback Health Checker & Preprocessor Utility
 */

export interface PlaybackDiagnostic {
  code: number;
  codeName: string;
  summary: string;
  troubleshooting: string[];
}

/**
 * Maps MediaError codes to human-readable diagnostic reports with browser troubleshooting guidance.
 */
export function getPlaybackDiagnostics(error: MediaError | null, videoUrl: string): PlaybackDiagnostic {
  const code = error?.code || 4;
  
  switch (code) {
    case 1: // MEDIA_ERR_ABORTED
      return {
        code: 1,
        codeName: 'MEDIA_ERR_ABORTED',
        summary: 'Video fetch process was aborted by the user or browser session context.',
        troubleshooting: [
          'Ensure network connection is stable.',
          'Reload the page or restart the video session.',
          'Check if browser extension or ad-blocker interrupted media stream.'
        ]
      };
    case 2: // MEDIA_ERR_NETWORK
      return {
        code: 2,
        codeName: 'MEDIA_ERR_NETWORK',
        summary: 'Network protocol error occurred while downloading video stream.',
        troubleshooting: [
          'Verify internet connectivity and CORS headers.',
          'Try clearing browser cache and cookies.',
          'Attempt proxy re-encoding via server fallback stream.'
        ]
      };
    case 3: // MEDIA_ERR_DECODE
      return {
        code: 3,
        codeName: 'MEDIA_ERR_DECODE',
        summary: 'Codec decoding failed or media file bitstream is corrupted.',
        troubleshooting: [
          'Disable hardware acceleration in browser settings.',
          'Try opening in external platform-native player (VLC / QuickTime).',
          'Convert file stream to H.264 MP4 container.'
        ]
      };
    case 4: // MEDIA_ERR_SRC_NOT_SUPPORTED
    default:
      return {
        code: 4,
        codeName: 'MEDIA_ERR_SRC_NOT_SUPPORTED',
        summary: 'Video format or MIME type is not natively supported by your browser.',
        troubleshooting: [
          'Attempting automated server-side blob stream proxy conversion.',
          'Disable hardware acceleration or try Chrome/Firefox media pipeline.',
          'Open video directly in external native media player window.'
        ]
      };
  }
}

/**
 * Pre-processes video URL to verify browser codec compatibility
 */
export async function preProcessVideoSource(rawUrl: string): Promise<{ playableUrl: string; isConverted: boolean }> {
  if (!rawUrl) {
    return { playableUrl: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4', isConverted: false };
  }

  // If already blob: or data: or youtube, return directly
  if (rawUrl.startsWith('blob:') || rawUrl.startsWith('data:') || rawUrl.includes('youtube.com') || rawUrl.includes('youtu.be')) {
    return { playableUrl: rawUrl, isConverted: false };
  }

  // Test browser HTMLVideoElement canPlayType
  const videoElem = document.createElement('video');
  const extension = rawUrl.split('.').pop()?.split('?')[0]?.toLowerCase();
  
  let mimeCheck = 'video/mp4';
  if (extension === 'webm') mimeCheck = 'video/webm';
  if (extension === 'ogv' || extension === 'ogg') mimeCheck = 'video/ogg';

  const canPlay = videoElem.canPlayType(mimeCheck);

  if (canPlay === '' && extension && !['mp4', 'webm', 'mov'].includes(extension)) {
    // Incompatible extension, re-encode via proxy
    try {
      const proxyUrl = `/api/proxy-video?url=${encodeURIComponent(rawUrl)}`;
      const res = await fetch(proxyUrl);
      if (res.ok) {
        const blob = await res.blob();
        const safeBlob = new Blob([blob], { type: 'video/mp4; codecs="avc1.42E01E, mp4a.40.2"' });
        return { playableUrl: URL.createObjectURL(safeBlob), isConverted: true };
      }
    } catch (e) {
      console.warn("Pre-process proxy conversion failed:", e);
    }
  }

  return { playableUrl: rawUrl, isConverted: false };
}
