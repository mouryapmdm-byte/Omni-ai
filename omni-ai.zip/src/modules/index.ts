/**
 * Core Application Modular Registry
 * Centralized public exports for domain modules across Classroom, STEM Labs, Mathematics, Assessment, Media/AI, and Collaboration.
 */

export * as ClassroomModule from './classroom';
export * as LabsModule from './labs';
export * as MathematicsModule from './mathematics';
export * as AssessmentModule from './assessment';
export * as MediaAiModule from './media-ai';
export * as CollaborationModule from './collaboration';
export * as AiTutorModule from './ai-tutor';
