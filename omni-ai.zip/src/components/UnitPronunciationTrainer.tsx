import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Mic, MicOff, Volume2, Trophy, ArrowRight, CheckCircle2, 
  HelpCircle, AlertCircle, Sparkles, RefreshCw, Search, GraduationCap,
  Play, Pause, Award, Info, BookOpen, Languages, Star, Flame
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export interface UnitItem {
  id: string;
  symbol: string;
  name: string;
  category: 'Electrostatics' | 'Mechanics' | 'Thermodynamics' | 'Electromagnetism' | 'General Physics' | 'Chemistry & Physical Sciences';
  meaning: string;
  spokenEnglish: string;
  spokenHinglish: string;
  spokenHindi: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export const SCIENTIFIC_UNITS: UnitItem[] = [
  {
    id: 'umol_m2_s',
    symbol: 'µmol/(m²·s)',
    name: 'Micromoles per square meter per second',
    category: 'Chemistry & Physical Sciences',
    meaning: 'Photon flux density measuring incident radiant photon flux per unit surface area per second.',
    spokenEnglish: 'micromoles per square meter per second',
    spokenHinglish: 'micro mole prati meter square second',
    spokenHindi: 'माइक्रो मोल प्रति वर्ग मीटर प्रति सेकंड',
    difficulty: 'hard'
  },
  {
    id: 'kj_mol',
    symbol: 'kJ/mol',
    name: 'Kilojoules per mole',
    category: 'Chemistry & Physical Sciences',
    meaning: 'SI unit of standard Gibbs free energy (ΔG°) and enthalpy of chemical reactions.',
    spokenEnglish: 'kilojoules per mole',
    spokenHinglish: 'kilo joule prati mole',
    spokenHindi: 'किलोजूल प्रति मोल',
    difficulty: 'medium'
  },
  {
    id: 'mol_l',
    symbol: 'mol/L',
    name: 'Moles per liter (Molarity)',
    category: 'Chemistry & Physical Sciences',
    meaning: 'SI unit of molar concentration for dissolved solutes and reaction kinetic assays.',
    spokenEnglish: 'moles per liter',
    spokenHinglish: 'mole prati liter',
    spokenHindi: 'मोल प्रति लीटर',
    difficulty: 'easy'
  },
  {
    id: 'nm_wavelength',
    symbol: 'nm',
    name: 'Nanometer',
    category: 'Chemistry & Physical Sciences',
    meaning: 'SI unit of wavelength measuring light absorption spectra and optical frequencies (e.g. 430 nm and 660 nm).',
    spokenEnglish: 'nanometer',
    spokenHinglish: 'nano meter',
    spokenHindi: 'नैनोमीटर',
    difficulty: 'easy'
  },
  {
    id: 'c_m2',
    symbol: 'C/m²',
    name: 'Coulomb per square meter',
    category: 'Electrostatics',
    meaning: 'SI unit of electric charge density (surface charge density).',
    spokenEnglish: 'coulomb prati miter square',
    spokenHinglish: 'coulomb prati miter square',
    spokenHindi: 'कूलम्ब प्रति मीटर स्क्वायर',
    difficulty: 'hard'
  },
  {
    id: 'c_m3',
    symbol: 'C/m³',
    name: 'Coulomb per cubic meter',
    category: 'Electrostatics',
    meaning: 'SI unit of electric charge density (volume charge density).',
    spokenEnglish: 'coulomb prati miter cube',
    spokenHinglish: 'coulomb prati miter cube',
    spokenHindi: 'कूलम्ब प्रति मीटर क्यूब',
    difficulty: 'hard'
  },
  {
    id: 'c_m',
    symbol: 'C/m',
    name: 'Coulomb per meter',
    category: 'Electrostatics',
    meaning: 'SI unit of electric charge density (linear charge density).',
    spokenEnglish: 'coulomb prati miter',
    spokenHinglish: 'coulomb prati miter',
    spokenHindi: 'कूलम्ब प्रति मीटर',
    difficulty: 'medium'
  },
  {
    id: 'kg_m3',
    symbol: 'kg/m³',
    name: 'Kilogram per cubic meter',
    category: 'Mechanics',
    meaning: 'SI unit of mass density (volumetric mass density).',
    spokenEnglish: 'kilogram prati miter cube',
    spokenHinglish: 'kilogram prati miter cube',
    spokenHindi: 'किलोग्राम प्रति मीटर क्यूब',
    difficulty: 'hard'
  },
  {
    id: 'n_c',
    symbol: 'N/C',
    name: 'Newton per Coulomb',
    category: 'Electrostatics',
    meaning: 'SI unit of electric field strength.',
    spokenEnglish: 'Newton per Coulomb',
    spokenHinglish: 'newton prati coulomb',
    spokenHindi: 'न्यूटन प्रति कूलम्ब',
    difficulty: 'medium'
  },
  {
    id: 'v_m',
    symbol: 'V/m',
    name: 'Volt per meter',
    category: 'Electrostatics',
    meaning: 'Alternative SI unit of electric field strength.',
    spokenEnglish: 'volt per meter',
    spokenHinglish: 'volt prati miter',
    spokenHindi: 'वोल्ट प्रति मीटर',
    difficulty: 'easy'
  },
  {
    id: 'f_m',
    symbol: 'F/m',
    name: 'Farad per meter',
    category: 'Electromagnetism',
    meaning: 'SI unit of permittivity.',
    spokenEnglish: 'farad per meter',
    spokenHinglish: 'farad prati miter',
    spokenHindi: 'फैराड प्रति मीटर',
    difficulty: 'medium'
  },
  {
    id: 'j_c',
    symbol: 'J/C',
    name: 'Joule per Coulomb',
    category: 'Electrostatics',
    meaning: 'Equivalent to one Volt; SI unit of electric potential.',
    spokenEnglish: 'joule per Coulomb',
    spokenHinglish: 'joule prati coulomb',
    spokenHindi: 'जूल प्रति कूलम्ब',
    difficulty: 'easy'
  },
  {
    id: 'n_m',
    symbol: 'N·m',
    name: 'Newton meter',
    category: 'Mechanics',
    meaning: 'SI unit of torque (moment of force) and work/energy.',
    spokenEnglish: 'Newton meter',
    spokenHinglish: 'newton miter',
    spokenHindi: 'न्यूटन मीटर',
    difficulty: 'easy'
  },
  {
    id: 'm_s2',
    symbol: 'm/s²',
    name: 'Meter per second squared',
    category: 'Mechanics',
    meaning: 'SI unit of acceleration.',
    spokenEnglish: 'meter per second squared',
    spokenHinglish: 'meter prati second square',
    spokenHindi: 'मीटर प्रति सेकंड स्क्वायर',
    difficulty: 'medium'
  },
  {
    id: 'pa_s',
    symbol: 'Pa·s',
    name: 'Pascal second',
    category: 'Mechanics',
    meaning: 'SI unit of dynamic viscosity.',
    spokenEnglish: 'Pascal second',
    spokenHinglish: 'pascal second',
    spokenHindi: 'पास्कल सेकंड',
    difficulty: 'medium'
  },
  {
    id: 'w_mk',
    symbol: 'W/(m·K)',
    name: 'Watt per meter-kelvin',
    category: 'Thermodynamics',
    meaning: 'SI unit of thermal conductivity.',
    spokenEnglish: 'watt per meter kelvin',
    spokenHinglish: 'watt prati miter kelvin',
    spokenHindi: 'वाट प्रति मीटर केल्विन',
    difficulty: 'hard'
  }
];

interface UnitPronunciationTrainerProps {
  onAwardXp?: (xp: number) => void;
  onClose?: () => void;
  theme?: 'light' | 'dark';
}

export const UnitPronunciationTrainer: React.FC<UnitPronunciationTrainerProps> = ({
  onAwardXp,
  onClose,
  theme = 'dark'
}) => {
  const [selectedDifficulty, setSelectedDifficulty] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUnit, setSelectedUnit] = useState<UnitItem>(SCIENTIFIC_UNITS[0]);
  const [pronunciationMode, setPronunciationMode] = useState<'hinglish' | 'english' | 'hindi'>('hinglish');
  
  // Recording/Practice states
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [practiceResult, setPracticeResult] = useState<{
    score: number;
    feedback: string;
    matchedWords: { word: string; isCorrect: boolean }[];
  } | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [streakCount, setStreakCount] = useState(0);

  const recognitionRef = useRef<any>(null);
  const speechUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Stop any active speech on unmount
  useEffect(() => {
    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, []);

  // Filtered list
  const filteredUnits = SCIENTIFIC_UNITS.filter(unit => {
    const matchesDifficulty = selectedDifficulty === 'all' || unit.difficulty === selectedDifficulty;
    const matchesSearch = unit.symbol.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          unit.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          unit.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDifficulty && matchesSearch;
  });

  // Handle TTS demo
  const handleListenDemo = () => {
    if (!window.speechSynthesis) {
      alert("Text-to-speech is not supported in this browser.");
      return;
    }

    window.speechSynthesis.cancel();
    setIsSpeaking(true);

    let textToSpeak = '';
    let lang = 'en-US';

    if (pronunciationMode === 'english') {
      textToSpeak = selectedUnit.spokenEnglish;
      lang = 'en-US';
    } else if (pronunciationMode === 'hinglish') {
      textToSpeak = selectedUnit.spokenHinglish;
      lang = 'en-IN'; // Elegant Indian English accent
    } else {
      textToSpeak = selectedUnit.spokenHindi;
      lang = 'hi-IN'; // Pure Hindi accent
    }

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = lang;
    utterance.rate = 0.85; // Speak slightly slower for training clarity!

    utterance.onend = () => {
      setIsSpeaking(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
    };

    speechUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  // Start speech recording practice
  const handleTogglePractice = () => {
    if (isRecording) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsRecording(false);
      return;
    }

    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.");
      return;
    }

    setTranscript('');
    setPracticeResult(null);
    setIsRecording(true);

    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = false;
    
    // Choose voice language base
    if (pronunciationMode === 'hindi') {
      rec.lang = 'hi-IN';
    } else if (pronunciationMode === 'hinglish') {
      rec.lang = 'en-IN';
    } else {
      rec.lang = 'en-US';
    }

    rec.onresult = (event: any) => {
      const finalResult = event.results[0][0].transcript;
      setTranscript(finalResult);
      evaluatePronunciation(finalResult);
    };

    rec.onerror = (e: any) => {
      const errorType = e?.error || '';
      if (errorType === 'no-speech' || errorType === 'aborted') {
        setIsRecording(false);
        return;
      }
      setIsRecording(false);
    };

    rec.onend = () => {
      setIsRecording(false);
    };

    recognitionRef.current = rec;
    rec.start();
  };

  // Evaluate accuracy score
  const evaluatePronunciation = (userSpoken: string) => {
    const cleanUser = userSpoken.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "").trim();
    
    let targetPhrase = '';
    if (pronunciationMode === 'english') {
      targetPhrase = selectedUnit.spokenEnglish;
    } else if (pronunciationMode === 'hinglish') {
      targetPhrase = selectedUnit.spokenHinglish;
    } else {
      targetPhrase = selectedUnit.spokenHindi;
    }

    const cleanTarget = targetPhrase.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "").trim();
    
    const targetWords = cleanTarget.split(/\s+/);
    const userWords = cleanUser.split(/\s+/);

    // Calculate word matches
    const matchedWords = targetWords.map(tWord => {
      // Find matching word
      const isCorrect = userWords.some(uWord => {
        // Simple direct match or sound-alike heuristics
        if (uWord === tWord) return true;
        // Basic phonetic helper for units (e.g. meter vs miter, coulomb vs coolamb)
        const normalize = (w: string) => w
          .replace(/ee/g, 'i')
          .replace(/y/g, 'i')
          .replace(/u/g, 'oo')
          .replace(/k/g, 'c')
          .replace(/s/g, 'c')
          .replace(/ph/g, 'f')
          .replace(/h/g, '')
          .replace(/v/g, 'w');
        return normalize(uWord) === normalize(tWord);
      });
      return { word: tWord, isCorrect };
    });

    const correctCount = matchedWords.filter(m => m.isCorrect).length;
    let score = Math.round((correctCount / targetWords.length) * 100);

    // Give high score if target matches perfectly or closely
    if (cleanUser === cleanTarget) {
      score = 100;
    }

    let feedback = '';
    if (score >= 90) {
      feedback = "Perfect! Your pronunciation of the scientific unit is absolutely spot-on!";
      setStreakCount(prev => prev + 1);
      if (onAwardXp) {
        onAwardXp(15);
      }
    } else if (score >= 70) {
      feedback = "Excellent effort! You got most of the parts right. Listen to the AI tutor and try again to hit 100%.";
    } else if (score >= 40) {
      feedback = "Good try. Emphasize multi-part breaks like 'prati' or 'square' more clearly.";
    } else {
      feedback = "Pronunciation was a bit unclear. Try listening to the tutor, matching the rate, and repeating.";
    }

    setPracticeResult({
      score,
      feedback,
      matchedWords
    });
  };

  const difficultyColors = {
    easy: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    medium: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    hard: 'bg-rose-500/10 text-rose-400 border-rose-500/20'
  };

  return (
    <div className={cn(
      "flex flex-col md:flex-row h-[550px] w-full rounded-2xl overflow-hidden border",
      theme === 'dark' ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
    )}>
      {/* Sidebar list */}
      <div className={cn(
        "w-full md:w-80 border-r flex flex-col h-1/2 md:h-full",
        theme === 'dark' ? 'border-slate-800 bg-slate-900/50' : 'border-slate-200 bg-slate-50'
      )}>
        {/* Search & Difficulty Filter */}
        <div className="p-4 border-b border-slate-800 flex flex-col gap-2.5">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="Search scientific units..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={cn(
                "w-full pl-9 pr-3 py-1.5 rounded-lg text-xs outline-none border transition-all duration-200",
                theme === 'dark' ? 'bg-slate-950 border-slate-800 focus:border-indigo-500 text-slate-100' : 'bg-white border-slate-200 focus:border-indigo-500 text-slate-800'
              )}
            />
          </div>
          
          <div className="flex gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            {(['all', 'easy', 'medium', 'hard'] as const).map(diff => (
              <button
                key={diff}
                onClick={() => setSelectedDifficulty(diff)}
                className={cn(
                  "flex-1 text-[10px] py-1 font-bold rounded-md transition-all duration-150 capitalize",
                  selectedDifficulty === diff 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' 
                    : 'text-slate-400 hover:text-slate-200'
                )}
              >
                {diff}
              </button>
            ))}
          </div>
        </div>

        {/* List scrollarea */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin">
          {filteredUnits.length > 0 ? (
            filteredUnits.map(unit => (
              <button
                key={unit.id}
                onClick={() => {
                  setSelectedUnit(unit);
                  setTranscript('');
                  setPracticeResult(null);
                }}
                className={cn(
                  "w-full text-left px-3 py-2.5 rounded-lg flex items-center justify-between transition-all duration-200 border group",
                  selectedUnit.id === unit.id
                    ? 'bg-indigo-600/10 border-indigo-500/30 text-white shadow-lg'
                    : 'border-transparent hover:bg-slate-800/40 hover:border-slate-800 text-slate-400 hover:text-slate-200'
                )}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className={cn(
                      "font-mono font-bold text-xs select-none",
                      selectedUnit.id === unit.id ? 'text-indigo-400' : 'text-slate-200'
                    )}>
                      {unit.symbol}
                    </span>
                    <span className={cn(
                      "text-[9px] px-1.5 py-0.25 rounded-full border uppercase tracking-wider font-bold",
                      difficultyColors[unit.difficulty]
                    )}>
                      {unit.difficulty}
                    </span>
                  </div>
                  <p className="text-[10px] mt-0.5 truncate max-w-[170px] text-slate-400 group-hover:text-slate-300">
                    {unit.name}
                  </p>
                </div>
                <ArrowRight size={12} className={cn(
                  "transition-all duration-200 opacity-0 group-hover:opacity-100",
                  selectedUnit.id === unit.id ? 'opacity-100 text-indigo-400 translate-x-0.5' : 'text-slate-400'
                )} />
              </button>
            ))
          ) : (
            <div className="text-center py-8 text-slate-500 text-xs">
              <Info size={16} className="mx-auto mb-2 opacity-50" />
              No scientific units match your search.
            </div>
          )}
        </div>
      </div>

      {/* Main Sandbox */}
      <div className="flex-1 flex flex-col h-1/2 md:h-full p-6 relative overflow-y-auto">
        {/* Title */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-600/10 text-indigo-400 border border-indigo-500/20">
              <GraduationCap size={16} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Unit Pronunciation Trainer</h3>
              <p className="text-[10px] text-slate-400">Master physics and math spoken terms with your AI Tutor</p>
            </div>
          </div>
          {streakCount > 0 && (
            <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full text-xs font-bold animate-bounce">
              <Flame size={12} className="fill-amber-400 text-amber-500" />
              <span>{streakCount} Win Streak!</span>
            </div>
          )}
        </div>

        {/* Selected Unit Details */}
        <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 mb-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <span className="text-[9px] font-mono uppercase tracking-widest text-indigo-400 font-bold bg-indigo-500/10 px-2 py-0.5 rounded-md border border-indigo-500/20">
              {selectedUnit.category}
            </span>
            <div className="flex items-baseline gap-2">
              <h4 className="text-2xl font-mono font-black text-white select-all">{selectedUnit.symbol}</h4>
              <p className="text-xs text-slate-300 font-medium">{selectedUnit.name}</p>
            </div>
            <p className="text-[11px] text-slate-400 max-w-md">{selectedUnit.meaning}</p>
          </div>

          {/* Pronunciation Target Pronunciation Choice */}
          <div className="flex flex-col gap-1.5 min-w-[140px]">
            <span className="text-[9px] uppercase tracking-wider font-bold text-slate-400 flex items-center gap-1">
              <Languages size={10} /> Pronunciation Accent
            </span>
            <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800">
              {(['hinglish', 'english', 'hindi'] as const).map(mode => (
                <button
                  key={mode}
                  onClick={() => {
                    setPronunciationMode(mode);
                    setTranscript('');
                    setPracticeResult(null);
                  }}
                  className={cn(
                    "flex-1 text-[9px] py-1 font-bold rounded transition-all duration-150 capitalize",
                    pronunciationMode === mode 
                      ? 'bg-indigo-600 text-white' 
                      : 'text-slate-400 hover:text-slate-200'
                  )}
                >
                  {mode === 'hindi' ? 'हिन्दी' : mode}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Learn Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Target Pronunciation display */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <div>
              <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">How to pronounce:</span>
              <div className="text-lg font-bold text-indigo-400 font-mono mt-1 select-all">
                {pronunciationMode === 'english' && selectedUnit.spokenEnglish}
                {pronunciationMode === 'hinglish' && selectedUnit.spokenHinglish}
                {pronunciationMode === 'hindi' && selectedUnit.spokenHindi}
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                {pronunciationMode === 'hinglish' && "Scientific standard using traditional 'prati' and 'square' notations."}
                {pronunciationMode === 'english' && "Standard global English scientific phonetic translation."}
                {pronunciationMode === 'hindi' && "शुद्ध हिंदी भौतिकी उच्चारण।"}
              </p>
            </div>

            <button
              onClick={handleListenDemo}
              disabled={isSpeaking}
              className={cn(
                "mt-4 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer w-full shadow-lg border",
                isSpeaking 
                  ? 'bg-indigo-600/10 border-indigo-500/30 text-indigo-400' 
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-700/50 hover:shadow-indigo-900/20 active:scale-95'
              )}
            >
              {isSpeaking ? (
                <>
                  <div className="flex gap-0.5 items-center">
                    <span className="h-2 w-1 rounded-full bg-indigo-400 animate-pulse" />
                    <span className="h-3 w-1 rounded-full bg-indigo-400 animate-pulse delay-75" />
                    <span className="h-1 w-1 rounded-full bg-indigo-400 animate-pulse delay-150" />
                  </div>
                  <span>Tutor Speaking...</span>
                </>
              ) : (
                <>
                  <Volume2 size={14} />
                  <span>Listen to AI Tutor</span>
                </>
              )}
            </button>
          </div>

          {/* User Practice Area */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center">
                <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Practice Out Loud:</span>
                {isRecording && (
                  <span className="flex h-2 w-2 rounded-full bg-rose-500 animate-ping" />
                )}
              </div>
              <div className={cn(
                "mt-2 min-h-[40px] text-xs font-mono rounded-lg p-2 flex items-center justify-center border",
                isRecording 
                  ? 'bg-rose-500/5 border-rose-500/20 text-rose-300 animate-pulse' 
                  : 'bg-slate-950 border-slate-800/80 text-slate-400'
              )}>
                {isRecording ? (
                  <div className="flex flex-col items-center gap-1 text-center">
                    <span className="text-[10px] uppercase font-bold text-rose-400 animate-bounce">Listening to your pronunciation...</span>
                    <p className="text-[9px] text-slate-500">Speak clearly into your microphone now</p>
                  </div>
                ) : transcript ? (
                  <p className="text-slate-100 select-all font-bold">"{transcript}"</p>
                ) : (
                  <p className="text-[10px] text-slate-500 text-center">Click the Mic to practice saying this scientific unit out loud</p>
                )}
              </div>
            </div>

            <button
              onClick={handleTogglePractice}
              className={cn(
                "mt-4 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer w-full border shadow-lg",
                isRecording
                  ? 'bg-rose-600 hover:bg-rose-700 text-white border-rose-800/80 hover:shadow-rose-950/20'
                  : 'bg-slate-850 hover:bg-slate-800 text-slate-200 border-slate-700/80 active:scale-95'
              )}
            >
              {isRecording ? <MicOff size={14} /> : <Mic size={14} />}
              <span>{isRecording ? "Stop & Transcribe" : "Listen & Repeat"}</span>
            </button>
          </div>
        </div>

        {/* Evaluation Results */}
        <AnimatePresence mode="wait">
          {practiceResult && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className={cn(
                "border rounded-xl p-5 space-y-3.5",
                practiceResult.score >= 85 
                  ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-100' 
                  : practiceResult.score >= 60 
                    ? 'bg-amber-500/5 border-amber-500/20 text-amber-100' 
                    : 'bg-slate-900 border-slate-800 text-slate-300'
              )}
            >
              <div className="flex items-center justify-between border-b border-slate-800/40 pb-2.5">
                <div className="flex items-center gap-2">
                  {practiceResult.score >= 85 ? (
                    <Trophy className="text-amber-400" size={18} />
                  ) : (
                    <Award className="text-slate-400" size={18} />
                  )}
                  <span className="text-xs font-bold text-white">Pronunciation Scorecard</span>
                </div>
                <div className="flex items-baseline gap-0.5">
                  <span className={cn(
                    "text-xl font-black font-mono",
                    practiceResult.score >= 85 ? 'text-emerald-400' : 'text-slate-200'
                  )}>{practiceResult.score}</span>
                  <span className="text-[10px] text-slate-400">/ 100</span>
                </div>
              </div>

              {/* Highlighting target syllables matched */}
              <div className="space-y-1">
                <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Word-by-word Analysis:</span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {practiceResult.matchedWords.map((item, idx) => (
                    <span
                      key={idx}
                      className={cn(
                        "text-[10px] px-2 py-0.5 rounded font-mono font-bold border transition-all duration-150",
                        item.isCorrect 
                          ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 shadow-sm shadow-emerald-950/20' 
                          : 'bg-rose-500/10 border-rose-500/20 text-rose-400 line-through decoration-rose-500/30'
                      )}
                    >
                      {item.word}
                    </span>
                  ))}
                </div>
              </div>

              {/* Textual Feedback */}
              <div className="flex items-start gap-2 text-xs">
                <div className={cn(
                  "p-1 rounded-full mt-0.5 border",
                  practiceResult.score >= 85 ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-400'
                )}>
                  <Sparkles size={12} />
                </div>
                <div className="space-y-1">
                  <p className="font-bold text-slate-200">AI Tutor Feedback:</p>
                  <p className="text-[11px] text-slate-300 leading-relaxed">{practiceResult.feedback}</p>
                </div>
              </div>

              {/* Reward toast */}
              {practiceResult.score >= 85 && (
                <div className="bg-emerald-600/10 border border-emerald-500/20 p-2 rounded-lg flex items-center justify-between text-xs text-emerald-400">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Star size={12} className="fill-emerald-400" />
                    <span>Accuracy Target Met!</span>
                  </div>
                  <span className="font-mono font-bold bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">+15 XP Awarded</span>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
