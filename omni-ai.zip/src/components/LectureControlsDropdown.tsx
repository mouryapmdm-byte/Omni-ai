import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronDown,
  FastForward,
  Volume2,
  Sparkles,
  User,
  Calculator,
  Minimize2,
  BookOpen,
  X,
  Layers,
  Zap,
  Scale,
  GraduationCap,
  MessageSquare,
  Sliders
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

export interface LectureControlsDropdownProps {
  onShowAll: () => void;
  onNarrate: () => void;
  isSpeaking: boolean;
  onTeachLike: () => void;
  currentTeacherStyleName?: string;
  currentTeacherAvatarIcon?: string;
  onAvatarPhoto: () => void;
  graphicsQualityMode: 'performance' | 'balanced' | 'ultra';
  onSelectGraphicsQuality: (mode: 'performance' | 'balanced' | 'ultra') => void;
  onFormulaArchitect: () => void;
  teachingPresentationMode: 'text_teaching' | 'figure_teaching' | 'hybrid';
  onSelectTeachingMode: (mode: 'text_teaching' | 'figure_teaching' | 'hybrid') => void;
  lectureDeliveryFormat?: 'socratic' | 'quick' | 'standard';
  onSelectDeliveryFormat?: (format: 'socratic' | 'quick' | 'standard') => void;
  onMinimizeNote: () => void;
  isNotesMinimized?: boolean;
  align?: 'left' | 'right';
  className?: string;
  buttonLabel?: string;
  onSelectBoard?: () => void;
  selectedBoardName?: string;
  onSelectDifficulty?: () => void;
  currentDifficultyName?: string;
  onSelectSubject?: () => void;
  currentSubjectName?: string;
  onSelectTopic?: () => void;
  onOpenSyllabus?: () => void;
  onOpenAiTools?: () => void;
  onOpenVocalPersona?: () => void;
  onOpenQuadSpeedSync?: () => void;
  currentQuadSpeedSummary?: string;
}

export const LectureControlsDropdown: React.FC<LectureControlsDropdownProps> = ({
  onShowAll,
  onNarrate,
  isSpeaking,
  onTeachLike,
  currentTeacherStyleName = 'Khan Academy',
  currentTeacherAvatarIcon = '👨‍🏫',
  onAvatarPhoto,
  graphicsQualityMode,
  onSelectGraphicsQuality,
  onFormulaArchitect,
  teachingPresentationMode,
  onSelectTeachingMode,
  lectureDeliveryFormat = 'socratic',
  onSelectDeliveryFormat,
  onMinimizeNote,
  isNotesMinimized = false,
  align = 'right',
  className = '',
  buttonLabel = 'Lecture Controls',
  onSelectBoard,
  selectedBoardName,
  onSelectDifficulty,
  currentDifficultyName,
  onSelectSubject,
  currentSubjectName,
  onOpenSyllabus,
  onOpenAiTools,
  onOpenVocalPersona,
  onOpenQuadSpeedSync,
  currentQuadSpeedSummary = '1.0x / 1.0x'
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  const cleanLabel = buttonLabel.replace(' ▾', '');

  return (
    <div ref={dropdownRef} className={cn("relative inline-block text-left shrink-0", className)}>
      {/* Trigger Button */}
      <button
        id="lecture-controls-dropdown-trigger"
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(prev => !prev);
        }}
        className={cn(
          "px-2 py-1 sm:px-2.5 sm:py-1 rounded-xl text-[10px] sm:text-xs font-bold flex items-center gap-1 sm:gap-1.5 transition-all cursor-pointer border shadow-sm select-none shrink-0",
          isOpen
            ? "bg-indigo-600 text-white border-indigo-400 ring-2 ring-indigo-400/40"
            : "bg-slate-900/95 hover:bg-slate-800 text-indigo-200 hover:text-white border-indigo-500/40 hover:border-indigo-400"
        )}
        title="Quick Actions Dropdown List: Show all, Voice Narration, Teach like, Avatar photo, Perf/Bal/Ultra, Formula architect, Text/Figure/Hybrid, Minimize note"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <Layers size={12} className="text-indigo-400 shrink-0" />
        <span className="font-extrabold tracking-tight hidden sm:inline">{cleanLabel}</span>
        <span className="font-extrabold tracking-tight inline sm:hidden">
          {cleanLabel.replace('Lecture ', '')}
        </span>
        {isSpeaking && (
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" title="Voice Narration Active" />
        )}
        <ChevronDown
          size={11}
          className={cn("transition-transform duration-200 shrink-0", isOpen ? "rotate-180 text-white" : "text-indigo-400")}
        />
      </button>

      {/* Dropdown Menu List */}
      {isOpen && (
        <div
          id="lecture-controls-dropdown-menu"
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
          className={cn(
            "absolute z-[100] mt-1.5 w-72 sm:w-80 max-w-[calc(100vw-1.5rem)] rounded-2xl bg-slate-950/98 border border-indigo-500/40 shadow-2xl backdrop-blur-2xl p-2.5 text-slate-100 animate-in fade-in zoom-in-95 duration-150 overflow-hidden ring-1 ring-white/10",
            align === 'right' ? "right-0" : "left-0"
          )}
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800/80 px-1">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
              <span className="text-[11px] font-black uppercase tracking-wider text-indigo-300">
                Lecture Quick Menu
              </span>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsOpen(false);
              }}
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Close Menu"
            >
              <X size={12} />
            </button>
          </div>

          <div className="flex flex-col gap-1 max-h-[70vh] sm:max-h-[75vh] overflow-y-auto custom-scrollbar touch-pan-y overscroll-contain pr-0.5">
            {/* 1. Show All Button */}
            <button
              id="dropdown-btn-show-all"
              onClick={(e) => {
                e.stopPropagation();
                onShowAll();
                setIsOpen(false);
              }}
              className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 group-hover:scale-105 transition-transform">
                  <FastForward size={13} />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
                    Show All
                  </div>
                  <div className="text-[10px] text-slate-400">Instantly reveal all content & formulas</div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-emerald-400/80 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
                Reveal
              </span>
            </button>

            {/* 2. Voice Narration Button */}
            <button
              id="dropdown-btn-narating"
              onClick={(e) => {
                e.stopPropagation();
                onNarrate();
                setIsOpen(false);
              }}
              className={cn(
                "w-full text-left p-2 rounded-xl border transition-all flex items-center justify-between group cursor-pointer",
                isSpeaking
                  ? "bg-indigo-950/60 border-indigo-500/50 text-indigo-100 shadow-sm"
                  : "hover:bg-slate-900/90 border-transparent hover:border-slate-800"
              )}
            >
              <div className="flex items-center gap-2.5">
                <div className={cn(
                  "p-1.5 rounded-lg border transition-transform group-hover:scale-105",
                  isSpeaking
                    ? "bg-indigo-600 text-white border-indigo-400 animate-pulse"
                    : "bg-indigo-500/20 text-indigo-400 border-indigo-500/30"
                )}>
                  <Volume2 size={13} className={isSpeaking ? "animate-bounce" : ""} />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 group-hover:text-indigo-300 transition-colors flex items-center gap-1.5">
                    <span>Voice Narration</span>
                    {isSpeaking && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {isSpeaking ? "Audio speaking synchronously..." : "Start voice narration on smartboard"}
                  </div>
                </div>
              </div>
              <span className={cn(
                "text-[10px] font-mono px-1.5 py-0.5 rounded border",
                isSpeaking
                  ? "bg-indigo-600 text-white border-indigo-400 font-bold"
                  : "bg-slate-900 text-slate-400 border-slate-800"
              )}>
                {isSpeaking ? "Active" : "Voice"}
              </span>
            </button>

            {/* 3. Teach Like Button */}
            <button
              id="dropdown-btn-teach-like"
              onClick={(e) => {
                e.stopPropagation();
                onTeachLike();
                setIsOpen(false);
              }}
              className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-teal-500/20 text-teal-300 border border-teal-500/30 group-hover:scale-105 transition-transform flex items-center justify-center text-xs">
                  <span>{currentTeacherAvatarIcon}</span>
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 group-hover:text-teal-300 transition-colors">
                    Teach Like
                  </div>
                  <div className="text-[10px] text-slate-400 truncate max-w-[170px]">
                    Current: {currentTeacherStyleName}
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-teal-400/80 bg-teal-950/60 px-1.5 py-0.5 rounded border border-teal-500/30">
                Style
              </span>
            </button>

            {/* 3B. Quad-Speed Synchronization Hub */}
            {onOpenQuadSpeedSync && (
              <button
                id="dropdown-btn-quad-speed-sync"
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenQuadSpeedSync();
                  setIsOpen(false);
                }}
                className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-indigo-500/30 bg-indigo-950/30 transition-all flex items-center justify-between group cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 group-hover:scale-105 transition-transform">
                    <Sliders size={13} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-indigo-200 group-hover:text-indigo-100 transition-colors">
                      Quad-Speed Sync Hub
                    </div>
                    <div className="text-[10px] text-indigo-300/70 truncate max-w-[170px]">
                      Typing · Voice · Visuals · Scroll
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-indigo-300 bg-indigo-950/80 px-1.5 py-0.5 rounded border border-indigo-400/30">
                  {currentQuadSpeedSummary}
                </span>
              </button>
            )}

            {/* 4. Avatar Photo Button */}
            <button
              id="dropdown-btn-avatar-photo"
              onClick={(e) => {
                e.stopPropagation();
                onAvatarPhoto();
                setIsOpen(false);
              }}
              className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 group-hover:scale-105 transition-transform">
                  <User size={13} />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 group-hover:text-amber-300 transition-colors">
                    Avatar Photo
                  </div>
                  <div className="text-[10px] text-slate-400">Upload educator picture with auto-fit</div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-amber-400/80 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-500/30">
                Photo
              </span>
            </button>

            {/* 5. Perf, Bal, Ultra (Graphics Optimization Selector) */}
            <div className="p-2 rounded-xl bg-slate-900/70 border border-slate-800/80 my-0.5">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-300">
                  Perf, Bal, Ultra
                </span>
                <span className="text-[9px] font-mono text-slate-400">3D Fidelity</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                <button
                  id="dropdown-btn-quality-perf"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectGraphicsQuality('performance');
                  }}
                  className={cn(
                    "py-1 px-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 border",
                    graphicsQualityMode === 'performance'
                      ? "bg-amber-600 text-white border-amber-400 shadow-sm shadow-amber-500/30"
                      : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                  )}
                  title="Performance Mode: High FPS, 1.0x Resolution"
                >
                  <Zap size={10} />
                  <span>Perf</span>
                </button>
                <button
                  id="dropdown-btn-quality-bal"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectGraphicsQuality('balanced');
                  }}
                  className={cn(
                    "py-1 px-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 border",
                    graphicsQualityMode === 'balanced'
                      ? "bg-indigo-600 text-white border-indigo-400 shadow-sm shadow-indigo-500/30"
                      : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                  )}
                  title="Balanced Mode: 60 FPS, Anti-Aliased"
                >
                  <Scale size={10} />
                  <span>Bal</span>
                </button>
                <button
                  id="dropdown-btn-quality-ultra"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectGraphicsQuality('ultra');
                  }}
                  className={cn(
                    "py-1 px-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 border",
                    graphicsQualityMode === 'ultra'
                      ? "bg-purple-600 text-white border-purple-400 shadow-sm shadow-purple-500/30"
                      : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                  )}
                  title="Ultra Mode: Full Soft Shadows, 2.0x Retina"
                >
                  <Sparkles size={10} />
                  <span>Ultra</span>
                </button>
              </div>
            </div>

            {/* 6. Formula Architect and Practice Button */}
            <button
              id="dropdown-btn-formula-architect"
              onClick={(e) => {
                e.stopPropagation();
                onFormulaArchitect();
                setIsOpen(false);
              }}
              className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-500/30 group-hover:scale-105 transition-transform">
                  <Calculator size={13} />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 group-hover:text-blue-300 transition-colors">
                    Formula Architect & Practice
                  </div>
                  <div className="text-[10px] text-slate-400">Formula derivations & adaptive practice questions</div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-blue-400/80 bg-blue-950/60 px-1.5 py-0.5 rounded border border-blue-500/30">
                Practice
              </span>
            </button>

            {/* 7. Text 70/30, Figure 80/30, Hybrid 50/50 */}
            <div className="p-2 rounded-xl bg-slate-900/70 border border-slate-800/80 my-0.5">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-300">
                  Text 70/30, Figure 80/30, Hybrid 50/50
                </span>
                <span className="text-[9px] font-mono text-slate-400">Smartboard Split</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                <button
                  id="dropdown-btn-mode-text"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectTeachingMode('text_teaching');
                  }}
                  className={cn(
                    "py-1 px-1 rounded-lg text-[9.5px] font-bold transition-all cursor-pointer text-center border truncate",
                    teachingPresentationMode === 'text_teaching'
                      ? "bg-cyan-600 text-white border-cyan-400 shadow-sm shadow-cyan-500/30"
                      : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                  )}
                  title="Text Teaching: 70% Text + 30% Key Points"
                >
                  Text 70/30
                </button>
                <button
                  id="dropdown-btn-mode-figure"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectTeachingMode('figure_teaching');
                  }}
                  className={cn(
                    "py-1 px-1 rounded-lg text-[9.5px] font-bold transition-all cursor-pointer text-center border truncate",
                    teachingPresentationMode === 'figure_teaching'
                      ? "bg-amber-600 text-white border-amber-400 shadow-sm shadow-amber-500/30"
                      : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                  )}
                  title="Figure Teaching: 80% Diagram + 20% Interactive Labels"
                >
                  Figure 80/30
                </button>
                <button
                  id="dropdown-btn-mode-hybrid"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectTeachingMode('hybrid');
                  }}
                  className={cn(
                    "py-1 px-1 rounded-lg text-[9.5px] font-bold transition-all cursor-pointer text-center border truncate",
                    teachingPresentationMode === 'hybrid'
                      ? "bg-indigo-600 text-white border-indigo-400 shadow-sm shadow-indigo-500/30"
                      : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                  )}
                  title="Hybrid Mode: 50% Live Figure + 50% Text & Equations"
                >
                  Hybrid 50/50
                </button>
              </div>
            </div>

            {/* 8. Lecture Delivery Format Mode Switch (Non-Destructive) */}
            {onSelectDeliveryFormat && (
              <div className="p-2 rounded-xl bg-slate-900/80 border border-cyan-500/30 my-0.5">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-cyan-300 flex items-center gap-1">
                    <MessageSquare size={11} className="text-cyan-400" />
                    Lecture Delivery Mode
                  </span>
                  <span className="text-[9px] font-mono text-slate-400">Format Switch</span>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <button
                    id="dropdown-btn-format-socratic"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectDeliveryFormat('socratic');
                      setIsOpen(false);
                    }}
                    className={cn(
                      "py-1.5 px-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer text-center border flex flex-col items-center justify-center gap-0.5",
                      lectureDeliveryFormat === 'socratic'
                        ? "bg-cyan-600 text-white border-cyan-400 shadow-sm shadow-cyan-500/30"
                        : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                    )}
                    title="Socratic Mode: Direct 1-on-1 teaching, concise intuition & equations"
                  >
                    <span>💬</span>
                    <span className="truncate text-[9.5px]">Socratic</span>
                  </button>
                  <button
                    id="dropdown-btn-format-quick"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectDeliveryFormat('quick');
                      setIsOpen(false);
                    }}
                    className={cn(
                      "py-1.5 px-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer text-center border flex flex-col items-center justify-center gap-0.5",
                      lectureDeliveryFormat === 'quick'
                        ? "bg-amber-600 text-white border-amber-400 shadow-sm shadow-amber-500/30"
                        : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                    )}
                    title="Quick Review: Fast 2-minute overview with core equations & 1-question check"
                  >
                    <span>⚡</span>
                    <span className="truncate text-[9.5px]">Quick</span>
                  </button>
                  <button
                    id="dropdown-btn-format-standard"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectDeliveryFormat('standard');
                      setIsOpen(false);
                    }}
                    className={cn(
                      "py-1.5 px-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer text-center border flex flex-col items-center justify-center gap-0.5",
                      lectureDeliveryFormat === 'standard'
                        ? "bg-indigo-600 text-white border-indigo-400 shadow-sm shadow-indigo-500/30"
                        : "bg-slate-950/80 text-slate-400 border-slate-800 hover:text-slate-200"
                    )}
                    title="Standard Study: Clean conceptual foundation + LaTeX derivations + worked examples"
                  >
                    <span>📘</span>
                    <span className="truncate text-[9.5px]">Standard</span>
                  </button>
                </div>
              </div>
            )}

            {/* 9. Minimize Note Button */}
            <button
              id="dropdown-btn-minimize-note"
              onClick={(e) => {
                e.stopPropagation();
                onMinimizeNote();
                setIsOpen(false);
              }}
              className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer mt-0.5"
            >
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30 group-hover:scale-105 transition-transform">
                  <Minimize2 size={13} />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-100 group-hover:text-rose-300 transition-colors">
                    Minimize Note
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {isNotesMinimized ? "Restore smartboard presentation view" : "Collapse notes to see full 3D lecture hall"}
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-mono text-rose-400/80 bg-rose-950/60 px-1.5 py-0.5 rounded border border-rose-500/30">
                {isNotesMinimized ? "Expand" : "Collapse"}
              </span>
            </button>

            {/* Quick Curriculum & 3D Tools Section */}
            {(onSelectBoard || onSelectDifficulty || onSelectSubject || onOpenSyllabus || onOpenAiTools || onOpenVocalPersona) && (
              <div className="pt-2 mt-2 border-t border-slate-800/80 space-y-1">
                <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                  <span>3D Curriculum & AI Suite</span>
                  <span className="text-[9px] text-indigo-400 font-mono">3D Mode</span>
                </div>

                {onSelectBoard && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectBoard();
                      setIsOpen(false);
                    }}
                    className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        <GraduationCap size={13} />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-100 group-hover:text-indigo-300">
                          1. Board & University
                        </div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[170px]">
                          {selectedBoardName || 'Select from 80+ Boards & Universities'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-indigo-400 bg-indigo-950/60 px-1.5 py-0.5 rounded border border-indigo-500/30">
                      Board
                    </span>
                  </button>
                )}

                {onSelectDifficulty && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectDifficulty();
                      setIsOpen(false);
                    }}
                    className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        <Scale size={13} />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-100 group-hover:text-emerald-300">
                          2. Learning Level
                        </div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[170px]">
                          {currentDifficultyName || 'Class 9-12 / College / Competitive'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
                      Level
                    </span>
                  </button>
                )}

                {onSelectSubject && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectSubject();
                      setIsOpen(false);
                    }}
                    className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        <BookOpen size={13} />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-100 group-hover:text-cyan-300">
                          3. Subjects
                        </div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[170px]">
                          {currentSubjectName || 'Physics, Chem, Math, Bio, CS'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-500/30">
                      Subject
                    </span>
                  </button>
                )}

                {onOpenSyllabus && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenSyllabus();
                      setIsOpen(false);
                    }}
                    className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-violet-500/20 text-violet-300 border border-violet-500/30">
                        <Layers size={13} />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-100 group-hover:text-violet-300">
                          6. Syllabus & Chapters
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Complete curriculum roadmap & weightage
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-violet-400 bg-violet-950/60 px-1.5 py-0.5 rounded border border-violet-500/30">
                      Syllabus
                    </span>
                  </button>
                )}

                {onOpenAiTools && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenAiTools();
                      setIsOpen(false);
                    }}
                    className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        <Sparkles size={13} />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-100 group-hover:text-amber-300">
                          7. AI Tools Suite
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Science Lab, Reactions, Atom Builder, Glossary
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-500/30">
                      Tools
                    </span>
                  </button>
                )}

                {onOpenVocalPersona && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenVocalPersona();
                      setIsOpen(false);
                    }}
                    className="w-full text-left p-2 rounded-xl hover:bg-slate-900/90 border border-transparent hover:border-slate-800 transition-all flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-pink-500/20 text-pink-300 border border-pink-500/30">
                        <Volume2 size={13} />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-100 group-hover:text-pink-300">
                          8. Vocal Persona & Voice Agent
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Live cadence, socratic ratio & mic interaction
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-pink-400 bg-pink-950/60 px-1.5 py-0.5 rounded border border-pink-500/30">
                      Vocal
                    </span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
