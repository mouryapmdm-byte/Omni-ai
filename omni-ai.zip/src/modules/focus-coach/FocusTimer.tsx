import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Settings, Check, Flame, ShieldAlert, Award, Clock } from 'lucide-react';
import { DistractionDetector } from './distractionDetector';
import { StudySession } from './types';

interface FocusTimerProps {
  isDark?: boolean;
  onSessionComplete?: (session: StudySession) => void;
}

export const FocusTimer: React.FC<FocusTimerProps> = ({
  isDark = true,
  onSessionComplete
}) => {
  const [mode, setMode] = useState<'pomodoro' | 'shortBreak' | 'longBreak' | 'customFocus'>('pomodoro');
  const [studyMinutesSetting, setStudyMinutesSetting] = useState<number>(25);
  const [breakMinutesSetting, setBreakMinutesSetting] = useState<number>(5);
  const [autoStartNext, setAutoStartNext] = useState<boolean>(false);

  const [timeLeftSeconds, setTimeLeftSeconds] = useState<number>(25 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [completedPomodoros, setCompletedPomodoros] = useState<number>(0);
  const [totalFocusMinutes, setTotalFocusMinutes] = useState<number>(0);

  // Live metrics from DistractionDetector
  const [currentFocusScore, setCurrentFocusScore] = useState<number>(100);
  const [tabSwitches, setTabSwitches] = useState<number>(0);
  const [idleMinutes, setIdleMinutes] = useState<number>(0);
  const [alertBanner, setAlertBanner] = useState<string | null>(null);

  const detectorRef = useRef(DistractionDetector.getInstance());

  // Listen to distraction detector events
  useEffect(() => {
    const detector = detectorRef.current;
    const unsubscribe = detector.subscribe(event => {
      setTabSwitches(event.tabSwitchCount);
      setCurrentFocusScore(event.currentFocusScore);
      setAlertBanner(event.message);
    });

    return () => unsubscribe();
  }, []);

  // Update timer target on mode change
  useEffect(() => {
    let targetMin = 25;
    if (mode === 'pomodoro') targetMin = studyMinutesSetting;
    else if (mode === 'shortBreak') targetMin = breakMinutesSetting;
    else if (mode === 'longBreak') targetMin = 15;
    else if (mode === 'customFocus') targetMin = studyMinutesSetting;

    setTimeLeftSeconds(targetMin * 60);
    setIsRunning(false);
    detectorRef.current.resetSession();
  }, [mode, studyMinutesSetting, breakMinutesSetting]);

  // Main Interval Hook
  useEffect(() => {
    let timer: number | null = null;

    if (isRunning && timeLeftSeconds > 0) {
      timer = window.setInterval(() => {
        setTimeLeftSeconds(prev => prev - 1);

        // Update distraction detector metrics periodically
        const metrics = detectorRef.current.getMetrics();
        setTabSwitches(metrics.tabSwitches);
        setIdleMinutes(metrics.idleMinutes);
        setCurrentFocusScore(metrics.focusScore);
      }, 1000);
    } else if (timeLeftSeconds === 0 && isRunning) {
      handleTimerCompletion();
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isRunning, timeLeftSeconds]);

  const toggleStartPause = () => {
    if (!isRunning) {
      detectorRef.current.startSession();
      setIsRunning(true);
    } else {
      detectorRef.current.pauseSession();
      setIsRunning(false);
    }
  };

  const resetTimer = () => {
    detectorRef.current.resetSession();
    setIsRunning(false);
    setAlertBanner(null);
    let targetMin = 25;
    if (mode === 'pomodoro') targetMin = studyMinutesSetting;
    else if (mode === 'shortBreak') targetMin = breakMinutesSetting;
    else if (mode === 'longBreak') targetMin = 15;
    else if (mode === 'customFocus') targetMin = studyMinutesSetting;
    setTimeLeftSeconds(targetMin * 60);
  };

  const handleTimerCompletion = () => {
    detectorRef.current.pauseSession();
    setIsRunning(false);

    if (mode === 'pomodoro' || mode === 'customFocus') {
      const newPomodoros = completedPomodoros + 1;
      setCompletedPomodoros(newPomodoros);
      setTotalFocusMinutes(prev => prev + studyMinutesSetting);

      const metrics = detectorRef.current.getMetrics();
      const sessionData: StudySession = {
        id: `session_${Date.now()}`,
        studentId: 'student_101',
        startedAt: new Date(Date.now() - studyMinutesSetting * 60000).toISOString(),
        endedAt: new Date().toISOString(),
        durationMinutes: studyMinutesSetting,
        focusScore: metrics.focusScore,
        tabSwitches: metrics.tabSwitches,
        idleMinutes: metrics.idleMinutes,
        pomodoroCount: 1,
        breakCount: 0,
        subjects: ['STEM Focus'],
        mode
      };

      DistractionDetector.saveCompletedSession(sessionData);
      if (onSessionComplete) onSessionComplete(sessionData);

      // Auto-switch to break
      if (newPomodoros % 4 === 0) {
        setMode('longBreak');
      } else {
        setMode('shortBreak');
      }
    } else {
      setMode('pomodoro');
    }

    if (autoStartNext) {
      setTimeout(() => {
        detectorRef.current.startSession();
        setIsRunning(true);
      }, 1000);
    }
  };

  const totalSeconds = (
    mode === 'pomodoro' ? studyMinutesSetting :
    mode === 'shortBreak' ? breakMinutesSetting :
    mode === 'longBreak' ? 15 : studyMinutesSetting
  ) * 60;

  const progressPercent = Math.min(100, Math.max(0, ((totalSeconds - timeLeftSeconds) / totalSeconds) * 100));
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`rounded-2xl p-6 border ${isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'}`}>
      {/* Mode Navigation Bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMode('pomodoro')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
              mode === 'pomodoro'
                ? 'bg-indigo-500 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            25m Focus
          </button>
          <button
            onClick={() => setMode('shortBreak')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
              mode === 'shortBreak'
                ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            5m Short Break
          </button>
          <button
            onClick={() => setMode('longBreak')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
              mode === 'longBreak'
                ? 'bg-teal-500 text-slate-950 shadow-md font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            15m Reset
          </button>
        </div>

        {/* Custom interval setting toggle */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Target:</span>
          <select
            value={studyMinutesSetting}
            onChange={e => setStudyMinutesSetting(Number(e.target.value))}
            disabled={isRunning}
            className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-1.5 outline-none"
          >
            <option value={15}>15 Min</option>
            <option value={25}>25 Min (Standard)</option>
            <option value={45}>45 Min (Deep Dive)</option>
            <option value={60}>60 Min (Power)</option>
          </select>
        </div>
      </div>

      {/* Alert Banner for Tab Switches */}
      {alertBanner && (
        <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>{alertBanner}</span>
          </div>
          <button
            onClick={() => setAlertBanner(null)}
            className="text-amber-400 font-bold hover:underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Circular Timer & Stats Layout */}
      <div className="flex flex-col md:flex-row items-center justify-around gap-8 py-4">
        {/* Progress Ring Timer */}
        <div className="relative w-64 h-64 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="128"
              cy="128"
              r="110"
              className="stroke-slate-800"
              strokeWidth="12"
              fill="transparent"
            />
            <circle
              cx="128"
              cy="128"
              r="110"
              className={`transition-all duration-1000 ${
                mode === 'pomodoro' ? 'stroke-indigo-500' : 'stroke-emerald-400'
              }`}
              strokeWidth="12"
              strokeDasharray={2 * Math.PI * 110}
              strokeDashoffset={(2 * Math.PI * 110) * (1 - progressPercent / 100)}
              strokeLinecap="round"
              fill="transparent"
            />
          </svg>

          {/* Time & Action Button inside Circle */}
          <div className="absolute inset-0 flex flex-col items-center justify-center space-y-2">
            <span className="text-4xl font-extrabold font-mono tracking-tight text-white">
              {formatTime(timeLeftSeconds)}
            </span>
            <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
              {mode === 'pomodoro' ? 'Deep Study Session' : 'Rest & Recharge'}
            </span>

            {/* Start / Pause Control */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={toggleStartPause}
                className={`p-3.5 rounded-full text-slate-950 font-bold transition-transform active:scale-95 shadow-lg ${
                  isRunning
                    ? 'bg-amber-400 hover:bg-amber-300'
                    : mode === 'pomodoro'
                    ? 'bg-indigo-400 hover:bg-indigo-300'
                    : 'bg-emerald-400 hover:bg-emerald-300'
                }`}
              >
                {isRunning ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-0.5" />}
              </button>
              <button
                onClick={resetTimer}
                className="p-3.5 rounded-full bg-slate-800 border border-slate-700 text-slate-400 hover:text-slate-200 hover:bg-slate-700 transition-colors"
                title="Reset Timer"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Live Metrics Card */}
        <div className="space-y-4 w-full max-w-xs">
          <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60 space-y-3">
            <span className="text-xs font-semibold text-slate-400 block uppercase tracking-wider">
              Real-Time Focus Score
            </span>
            <div className="flex items-center justify-between">
              <span className={`text-3xl font-black font-mono ${
                currentFocusScore >= 80 ? 'text-emerald-400' : currentFocusScore >= 60 ? 'text-amber-400' : 'text-rose-400'
              }`}>
                {currentFocusScore}/100
              </span>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-slate-800 border border-slate-700 text-slate-300">
                {currentFocusScore >= 80 ? 'Flow State' : currentFocusScore >= 60 ? 'Moderate' : 'Distracted'}
              </span>
            </div>

            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  currentFocusScore >= 80 ? 'bg-emerald-400' : currentFocusScore >= 60 ? 'bg-amber-400' : 'bg-rose-400'
                }`}
                style={{ width: `${currentFocusScore}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Tab Switches</span>
              <span className="font-bold text-amber-300 text-base">{tabSwitches}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Completed</span>
              <span className="font-bold text-indigo-300 text-base">{completedPomodoros} Sessions</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
            <span>Auto-start breaks</span>
            <input
              type="checkbox"
              checked={autoStartNext}
              onChange={e => setAutoStartNext(e.target.checked)}
              className="w-4 h-4 rounded text-indigo-500 bg-slate-800 border-slate-700 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
