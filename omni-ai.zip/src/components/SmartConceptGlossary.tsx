import React, { useState } from 'react';
import { cn } from '@/src/lib/utils';
import { Sparkles, BookOpen, ExternalLink, Atom, Search, CheckCircle2, Bookmark, Layers, FlaskConical } from 'lucide-react';

export interface ChemistryTerm {
  term: string;
  category: string;
  formula?: string;
  definition: string;
  properties: string[];
  chapter: string;
}

export const CHEMISTRY_DICTIONARY: Record<string, ChemistryTerm> = {
  'ligand': {
    term: 'Ligand',
    category: 'Coordination Chemistry',
    formula: 'NH₃, H₂O, CN⁻',
    definition: 'An ion or molecule attached to a central metal atom by coordinate covalent bonds.',
    properties: ['Acts as Lewis base (electron pair donor)', 'Can be monodentate or polydentate', 'Determines crystal field splitting'],
    chapter: 'Chapter 9: Coordination Compounds'
  },
  'coordination number': {
    term: 'Coordination Number',
    category: 'Coordination Chemistry',
    formula: 'CN (4, 6)',
    definition: 'Total number of ligand donor atoms directly bonded to the central metal ion.',
    properties: ['Determines spatial geometry (tetrahedral, octahedral)', 'Depends on charge and steric factors'],
    chapter: 'Chapter 9: Coordination Compounds'
  },
  'crystal field theory': {
    term: 'Crystal Field Theory (CFT)',
    category: 'Coordination Chemistry',
    definition: 'Electrostatic model describing d-orbital degeneracy breaking in transition metal complexes.',
    properties: ['Splits t₂g and e_g orbitals', 'Explains color and magnetic properties'],
    chapter: 'Chapter 9: Coordination Compounds'
  },
  'chelation': {
    term: 'Chelation',
    category: 'Coordination Chemistry',
    definition: 'Formation of two or more coordinate bonds between a polydentate ligand and a metal ion.',
    properties: ['Produces exceptionally stable chelate rings', 'Crucial in biochemistry and titration'],
    chapter: 'Chapter 9: Coordination Compounds'
  },
  'sn1': {
    term: 'S_N1 Reaction',
    category: 'Organic Mechanism',
    definition: 'Unimolecular nucleophilic substitution proceeding via a planar carbocation intermediate.',
    properties: ['Two-step mechanism', 'Rate depends only on substrate concentration', 'Leads to racemization'],
    chapter: 'Chapter 10: Haloalkanes and Haloarenes'
  },
  'sn2': {
    term: 'S_N2 Reaction',
    category: 'Organic Mechanism',
    definition: 'Bimolecular nucleophilic substitution with simultaneous bond breaking and making via inversion of configuration.',
    properties: ['One-step concerted mechanism', 'Walden inversion occurs', 'Favored by primary substrates'],
    chapter: 'Chapter 10: Haloalkanes and Haloarenes'
  },
  'zwitterion': {
    term: 'Zwitterion',
    category: 'Biomolecules',
    formula: '⁺H₃N-R-COO⁻',
    definition: 'A dipolar ion with both positive and negative electrical charges on different atoms in the same molecule.',
    properties: ['High melting point', 'High water solubility', 'Exhibits amphoteric behavior at isoelectric point'],
    chapter: 'Chapter 14: Biomolecules'
  },
  'peptide bond': {
    term: 'Peptide Bond',
    category: 'Biomolecules',
    formula: '-CO-NH-',
    definition: 'Amide linkage formed between the carboxyl group of one amino acid and the amino group of another.',
    properties: ['Partial double bond character', 'Rigid and planar structure', 'Resistant to hydrolysis without catalysts'],
    chapter: 'Chapter 14: Biomolecules'
  },
  'activation energy': {
    term: 'Activation Energy (E_a)',
    category: 'Chemical Kinetics',
    formula: 'E_a',
    definition: 'Minimum threshold energy required by reactants to undergo a chemical reaction.',
    properties: ['Determined via Arrhenius equation', 'Lowered by catalysts to accelerate reaction rates'],
    chapter: 'Chapter 4: Chemical Kinetics'
  },
  'molarity': {
    term: 'Molarity (M)',
    category: 'Solution Chemistry',
    formula: 'mol/L',
    definition: 'Number of moles of solute dissolved in one liter of solution.',
    properties: ['Temperature dependent due to volume expansion/contraction', 'Fundamental concentration unit'],
    chapter: 'Chapter 1: Solutions'
  },
  'buffer solution': {
    term: 'Buffer Solution',
    category: 'Physical Chemistry',
    definition: 'An aqueous solution resistant to pH changes upon addition of small amounts of acid or base.',
    properties: ['Composed of weak acid and its conjugate base (or vice versa)', 'Governed by Henderson-Hasselbalch equation'],
    chapter: 'Chapter 7: Equilibrium'
  }
};

interface SmartConceptGlossaryProps {
  theme: 'light' | 'dark';
  onOpenChapter: (chapterNum: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const SmartConceptGlossary: React.FC<SmartConceptGlossaryProps> = ({
  theme,
  onOpenChapter,
  showNotification
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTermKey, setSelectedTermKey] = useState<string>('ligand');

  const filteredEntries = Object.entries(CHEMISTRY_DICTIONARY).filter(([key, val]) =>
    val.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
    val.definition.toLowerCase().includes(searchQuery.toLowerCase()) ||
    val.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeTerm = CHEMISTRY_DICTIONARY[selectedTermKey] || CHEMISTRY_DICTIONARY['ligand'];

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-y-auto p-6 md:p-8 selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-slate-50/50 text-slate-900"
    )}>
      {/* Header Banner */}
      <div className={cn(
        "p-6 rounded-3xl border mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl",
        theme === 'dark' ? "bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/40 border-emerald-900/40" : "bg-gradient-to-r from-emerald-50 via-white to-teal-50 border-emerald-100"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-500/30">
            <BookOpen size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                Smart Chat Integration & Glossary
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Smart Concept Glossary
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Automatically detects and highlights chemistry terms across chat messages with instant tooltip definitions and deep insights.
            </p>
          </div>
        </div>

        <div className="relative w-full md:w-72">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search chemistry terms..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={cn(
              "w-full pl-10 pr-4 py-2.5 rounded-2xl border text-xs font-bold outline-none transition-all",
              theme === 'dark' ? "bg-slate-800/80 border-slate-700 text-white focus:border-emerald-500" : "bg-white border-slate-200 text-slate-800 focus:border-emerald-400 shadow-sm"
            )}
          />
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left List of Terms */}
        <div className={cn(
          "p-6 rounded-3xl border shadow-xl flex flex-col h-[520px] overflow-y-auto",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div className="text-xs font-black uppercase tracking-wider text-slate-400 mb-4">
            Available Chemistry Terms ({filteredEntries.length})
          </div>
          <div className="space-y-2">
            {filteredEntries.map(([key, item]) => {
              const isSelected = selectedTermKey === key;
              return (
                <button
                  key={key}
                  onClick={() => {
                    setSelectedTermKey(key);
                    showNotification?.(`Inspecting ${item.term}`, 'info');
                  }}
                  className={cn(
                    "w-full p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between group",
                    isSelected
                      ? "bg-emerald-600 text-white border-emerald-500 shadow-lg shadow-emerald-500/30 scale-[1.02]"
                      : theme === 'dark'
                      ? "bg-slate-900/60 border-slate-700 hover:border-emerald-500/50 text-slate-300"
                      : "bg-slate-50 border-slate-200 hover:border-emerald-300 text-slate-700"
                  )}
                >
                  <div>
                    <div className="text-sm font-black tracking-tight">{item.term}</div>
                    <div className={cn("text-[10px] font-bold mt-0.5", isSelected ? "text-emerald-100" : "text-slate-400")}>
                      {item.category}
                    </div>
                  </div>
                  {item.formula && (
                    <span className={cn(
                      "text-[10px] font-mono px-2 py-1 rounded-xl font-bold border",
                      isSelected ? "bg-emerald-700/60 border-emerald-400 text-white" : "bg-slate-200/50 dark:bg-slate-900/80 border-slate-300 dark:border-slate-700 text-emerald-500"
                    )}>
                      {item.formula}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Detailed Term Inspection Card */}
        <div className={cn(
          "lg:col-span-2 p-6 md:p-8 rounded-3xl border shadow-xl flex flex-col justify-between h-[520px]",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div>
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-700/60">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 flex items-center justify-center font-black text-xl">
                  <Atom size={22} />
                </div>
                <div>
                  <h3 className="text-xl font-black tracking-tight">{activeTerm.term}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{activeTerm.category}</p>
                </div>
              </div>
              {activeTerm.formula && (
                <div className="px-3.5 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-mono font-bold text-xs border border-emerald-500/20">
                  {activeTerm.formula}
                </div>
              )}
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="font-black uppercase tracking-wider text-slate-400 block mb-1">Definition</span>
                <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-900/80 text-slate-800 dark:text-slate-200 leading-relaxed border border-slate-200 dark:border-slate-700 font-medium">
                  {activeTerm.definition}
                </div>
              </div>

              <div>
                <span className="font-black uppercase tracking-wider text-slate-400 block mb-2">Key Properties & Behaviors</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeTerm.properties.map((prop, i) => (
                    <div key={i} className="p-3 rounded-xl bg-slate-100 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 flex items-start gap-2">
                      <CheckCircle2 size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                      <span className="text-slate-700 dark:text-slate-300">{prop}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400">
              <BookOpen size={14} />
              <span>{activeTerm.chapter}</span>
            </div>
            <button
              onClick={() => {
                const num = parseInt(activeTerm.chapter.replace(/[^0-9]/g, '')) || 9;
                onOpenChapter(num);
              }}
              className="flex items-center gap-1 bg-emerald-50 hover:bg-emerald-600 text-emerald-600 hover:text-white dark:bg-emerald-950/60 dark:hover:bg-emerald-600 dark:text-emerald-300 text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              <span>Read Textbook Chapter</span>
              <ExternalLink size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper function to parse chat message text and render clickable chemistry glossary terms with tooltips
export function renderSmartGlossaryText(text: string, onSelectTerm?: (termKey: string) => void): React.ReactNode[] {
  // Find all keys in CHEMISTRY_DICTIONARY that appear in text (case-insensitive)
  const keys = Object.keys(CHEMISTRY_DICTIONARY);
  
  // Sort keys by length descending so longer phrases match first (e.g. "crystal field theory" before "field")
  const sortedKeys = keys.sort((a, b) => b.length - a.length);

  // We can build a regex pattern matching any of these keys case-insensitively
  const escapedKeys = sortedKeys.map(k => k.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
  if (escapedKeys.length === 0) return [text];

  const regex = new RegExp(`\\b(${escapedKeys.join('|')})\\b`, 'gi');

  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    const matchIndex = match.index;
    if (matchIndex > lastIndex) {
      parts.push(text.substring(lastIndex, matchIndex));
    }

    const matchedStr = match[0];
    const lowerKey = matchedStr.toLowerCase();
    const entry = CHEMISTRY_DICTIONARY[lowerKey];

    if (entry) {
      parts.push(
        <span
          key={`${matchIndex}-${matchedStr}`}
          title={`${entry.term}: ${entry.definition}`}
          onClick={(e) => {
            e.stopPropagation();
            onSelectTerm?.(lowerKey);
          }}
          className="inline-flex items-center gap-1 px-1.5 py-0.5 mx-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-400/30 hover:bg-emerald-500/30 hover:border-emerald-400 cursor-pointer transition-all font-semibold group relative"
        >
          <span>{matchedStr}</span>
          <span className="text-[9px] opacity-70 group-hover:opacity-100">💡</span>
        </span>
      );
    } else {
      parts.push(matchedStr);
    }

    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    parts.push(text.substring(lastIndex));
  }

  return parts;
}
