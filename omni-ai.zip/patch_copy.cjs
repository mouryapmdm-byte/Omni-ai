const fs = require('fs');
const file = 'src/components/MatrixCalculatorModal.tsx';
let content = fs.readFileSync(file, 'utf8');

// Insert copy functions
const copyStr = `
  const copyToInput = (target: 'A' | 'B', result: number[][], rows: number, cols: number) => {
    const padded = Array(3).fill(0).map(() => Array(3).fill(0));
    for(let i=0; i<Math.min(rows, 3); i++) {
      for(let j=0; j<Math.min(cols, 3); j++) {
        padded[i][j] = result[i][j];
      }
    }
    if (target === 'A') {
      setMatrixA(padded);
      setSizeA({ rows: Math.min(rows, 3), cols: Math.min(cols, 3) });
    } else {
      setMatrixB(padded);
      setSizeB({ rows: Math.min(rows, 3), cols: Math.min(cols, 3) });
    }
  };

  const renderCopyButtons = (result: number[][], rows: number, cols: number) => (
    <div className="flex flex-col gap-2 ml-4 border-l pl-4 border-slate-300 dark:border-slate-700">
      <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Copy Result To</p>
      <div className="flex gap-2">
        <button 
          onClick={() => copyToInput('A', result, rows, cols)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5", theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-300" : "bg-slate-100 hover:bg-slate-200 text-slate-700")}
        >
          <Copy size={14} /> Matrix A
        </button>
        <button 
          onClick={() => copyToInput('B', result, rows, cols)}
          className={cn("px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5", theme === 'dark' ? "bg-slate-800 hover:bg-slate-700 text-slate-300" : "bg-slate-100 hover:bg-slate-200 text-slate-700")}
        >
          <Copy size={14} /> Matrix B
        </button>
      </div>
    </div>
  );
`;

content = content.replace(
  "const getDeterminant = (M: Matrix3x3, size: {rows: number, cols: number}) => {",
  copyStr + "\n  const getDeterminant = (M: Matrix3x3, size: {rows: number, cols: number}) => {"
);

fs.writeFileSync(file, content);
console.log("Patched MatrixCalculatorModal with copy logic");
