import React, { useState } from 'react';
import { cn } from '@/src/lib/utils';
import { Search, BookOpen, ExternalLink, Sparkles, Bookmark, CheckCircle2, Atom, Layers, FlaskConical, ArrowRight, Share2, Copy } from 'lucide-react';

interface GlossaryItem {
  id: string;
  term: string;
  category: 'coordination' | 'organic' | 'biomolecules';
  formula?: string;
  definition: string;
  properties: string[];
  textbookChapter: string;
  chapterNumber: number;
}

const GLOSSARY_DATA: GlossaryItem[] = [
  // Coordination Compounds
  {
    id: 'coord-1',
    term: 'Ligand',
    category: 'coordination',
    formula: 'NH₃, H₂O, CN⁻, CO',
    definition: 'An ion or molecule (neutral or negative) attached to a central metal atom or ion by coordinate covalent bonds in a coordination complex.',
    properties: [
      'Acts as a Lewis base (electron pair donor)',
      'Can be monodentate (one donor site) or polydentate/chelating (multiple donor sites)',
      'Influences crystal field splitting energy (Δ₀) and color of complexes'
    ],
    textbookChapter: '9. Coordination Compounds',
    chapterNumber: 9
  },
  {
    id: 'coord-2',
    term: 'Coordination Number',
    category: 'coordination',
    formula: 'CN (e.g. 4, 6)',
    definition: 'The total number of ligand donor atoms directly bonded to the central metal ion in a coordination complex.',
    properties: [
      'Determines the spatial geometry of the complex (e.g., tetrahedral/square planar for CN=4, octahedral for CN=6)',
      'Depends on metal ion charge, radius, and steric factors of ligands'
    ],
    textbookChapter: '9. Coordination Compounds',
    chapterNumber: 9
  },
  {
    id: 'coord-3',
    term: 'Crystal Field Theory (CFT)',
    category: 'coordination',
    definition: 'An electrostatic model that describes the breaking of orbital degeneracy in transition metal complexes due to the electric field of surrounding ligands.',
    properties: [
      'Splits d-orbitals into t₂g and e_g sets in octahedral fields',
      'Explains color, magnetic properties, and spectral absorption of complexes',
      'Uses spectrochemical series to order ligand field strengths'
    ],
    textbookChapter: '9. Coordination Compounds',
    chapterNumber: 9
  },
  {
    id: 'coord-4',
    term: 'Chelation',
    category: 'coordination',
    definition: 'The formation of two or more coordinate bonds between a polydentate ligand and a single central metal ion, forming a stable ring structure.',
    properties: [
      'Chelate complexes are significantly more stable than non-chelated complexes (chelate effect)',
      'Important in analytical chemistry and biological systems (e.g., EDTA, hemoglobin)'
    ],
    textbookChapter: '9. Coordination Compounds',
    chapterNumber: 9
  },
  {
    id: 'coord-5',
    term: 'IUPAC Nomenclature in Coordination',
    category: 'coordination',
    definition: 'Standard systematic naming convention where cations are named before anions, ligands are listed alphabetically before the metal, and metal oxidation state is denoted in Roman numerals.',
    properties: [
      'Anionic ligands end in "-o" (e.g., chloro, cyano)',
      'Neutral ligands have special names (e.g., ammine, aqua, carbonyl)',
      'Anionic complexes end in the suffix "-ate"'
    ],
    textbookChapter: '9. Coordination Compounds',
    chapterNumber: 9
  },

  // Organic Functional Groups
  {
    id: 'org-1',
    term: 'Haloalkane (Alkyl Halide)',
    category: 'organic',
    formula: 'R-X (X = F, Cl, Br, I)',
    definition: 'Compounds derived from alkanes by replacing one or more hydrogen atoms with halogen atoms.',
    properties: [
      'Undergoes nucleophilic substitution (S_N1 and S_N2) and elimination (E1 and E2) reactions',
      'Polar carbon-halogen bond allows dipole-dipole interactions',
      'Widely used as solvents and synthetic intermediates'
    ],
    textbookChapter: '10. Haloalkanes and Haloarenes',
    chapterNumber: 10
  },
  {
    id: 'org-2',
    term: 'Alcohol',
    category: 'organic',
    formula: 'R-OH',
    definition: 'Organic compounds containing one or more hydroxyl (-OH) groups attached directly to saturated carbon atoms.',
    properties: [
      'Exhibits strong intermolecular hydrogen bonding, resulting in higher boiling points',
      'Can act as weak acids or weak bases (amphoteric nature)',
      'Classified as primary (1°), secondary (2°), or tertiary (3°) based on carbon attachment'
    ],
    textbookChapter: '11. Alcohols, Phenols and Ethers',
    chapterNumber: 11
  },
  {
    id: 'org-3',
    term: 'Phenol',
    category: 'organic',
    formula: 'Ar-OH',
    definition: 'Aromatic organic compounds containing a hydroxyl group directly attached to a benzene ring.',
    properties: [
      'More acidic than aliphatic alcohols due to resonance stabilization of the phenoxide ion',
      'Undergoes electrophilic aromatic substitution easily (e.g., nitration, bromination)',
      'Gives characteristic violet coloration with neutral FeCl₃ solution'
    ],
    textbookChapter: '11. Alcohols, Phenols and Ethers',
    chapterNumber: 11
  },
  {
    id: 'org-4',
    term: 'Aldehyde and Ketone (Carbonyl Group)',
    category: 'organic',
    formula: 'R-CHO / R-CO-R\'',
    definition: 'Compounds containing a carbonyl group (C=O). In aldehydes, carbonyl is bonded to at least one hydrogen; in ketones, to two carbon groups.',
    properties: [
      'Undergoes characteristic nucleophilic addition reactions',
      'Aldehydes are easily oxidized to carboxylic acids (positive Tollens\' and Fehling\'s tests)',
      'Exhibits keto-enol tautomerism when alpha-hydrogens are present'
    ],
    textbookChapter: '12. Aldehydes, Ketones and Carboxylic Acids',
    chapterNumber: 12
  },
  {
    id: 'org-5',
    term: 'Carboxylic Acid',
    category: 'organic',
    formula: 'R-COOH',
    definition: 'Organic compounds containing a carboxyl functional group (-COOH), consisting of a carbonyl group attached to a hydroxyl group.',
    properties: [
      'Exhibits strong acidity due to resonance stabilization of the carboxylate anion (R-COO⁻)',
      'Forms stable dimers via intermolecular hydrogen bonding',
      'Reacts with alcohols to form esters (esterification)'
    ],
    textbookChapter: '12. Aldehydes, Ketones and Carboxylic Acids',
    chapterNumber: 12
  },
  {
    id: 'org-6',
    term: 'Amine',
    category: 'organic',
    formula: 'R-NH₂, R₂NH, R₃N',
    definition: 'Derivatives of ammonia where one or more hydrogen atoms are replaced by alkyl or aryl groups.',
    properties: [
      'Acts as organic bases due to the lone pair of electrons on nitrogen',
      'Primary amines react with nitrous acid to form diazonium salts',
      'Gives carbylamine test (foul odor isonitrile) for primary aliphatic/aromatic amines'
    ],
    textbookChapter: '13. Organic Compounds Containing Nitrogen',
    chapterNumber: 13
  },

  // Biomolecules
  {
    id: 'bio-1',
    term: 'Carbohydrate',
    category: 'biomolecules',
    formula: 'Cₓ(H₂O)ᵧ',
    definition: 'Polyhydroxy aldehydes or polyhydroxy ketones, or substances that yield these on hydrolysis (sugars and starches).',
    properties: [
      'Classified as monosaccharides, oligosaccharides, and polysaccharides',
      'Serves as primary energy source and structural components (cellulose in plants, glycogen in animals)',
      'Exhibits optical isomerism and mutarotation in aqueous solutions'
    ],
    textbookChapter: '14. Biomolecules',
    chapterNumber: 14
  },
  {
    id: 'bio-2',
    term: 'Protein & Amino Acid',
    category: 'biomolecules',
    formula: 'H₂N-CHR-COOH',
    definition: 'Macromolecules composed of amino acids linked together by peptide bonds (-CONH-).',
    properties: [
      'Amino acids contain both basic amino (-NH₂) and acidic carboxyl (-COOH) groups (zwitterion form)',
      'Proteins have primary, secondary (α-helix, β-sheet), tertiary, and quaternary structures',
      'Denaturation disrupts 3D structure via heat, pH change, or chemicals without breaking primary peptide bonds'
    ],
    textbookChapter: '14. Biomolecules',
    chapterNumber: 14
  },
  {
    id: 'bio-3',
    term: 'Enzyme',
    category: 'biomolecules',
    definition: 'Biological catalysts (mostly globular proteins) that dramatically accelerate biochemical reaction rates without being consumed.',
    properties: [
      'Highly specific for substrates (lock-and-key or induced-fit models)',
      'Sensitive to temperature and pH variations with optimal operating ranges',
      'Lower activation energy of biochemical transformations'
    ],
    textbookChapter: '14. Biomolecules',
    chapterNumber: 14
  },
  {
    id: 'bio-4',
    term: 'Nucleic Acid (DNA & RNA)',
    category: 'biomolecules',
    definition: 'Biopolymers composed of nucleotide monomers (nitrogenous base + pentose sugar + phosphate group) responsible for genetic information storage and protein synthesis.',
    properties: [
      'DNA stores hereditary information in double-helix antiparallel strands (A-T, G-C pairing)',
      'RNA translates genetic code into proteins (mRNA, tRNA, rRNA)',
      'Phosphodiester bonds link nucleotides together'
    ],
    textbookChapter: '14. Biomolecules',
    chapterNumber: 14
  },
  {
    id: 'bio-5',
    term: 'Vitamin',
    category: 'biomolecules',
    definition: 'Organic compounds required in small quantities for normal metabolic functions that cannot be synthesized adequately by the organism.',
    properties: [
      'Classified as water-soluble (Vitamins B and C) or fat-soluble (Vitamins A, D, E, and K)',
      'Deficiency leads to specific metabolic disorders (e.g., scurvy for Vit C, night blindness for Vit A)'
    ],
    textbookChapter: '14. Biomolecules',
    chapterNumber: 14
  }
];

interface ChemistryGlossaryProps {
  theme: 'light' | 'dark';
  onOpenChapter: (chapterNumber: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const ChemistryGlossary: React.FC<ChemistryGlossaryProps> = ({
  theme,
  onOpenChapter,
  showNotification
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'coordination' | 'organic' | 'biomolecules'>('all');
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('omni_chemistry_glossary_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = bookmarkedIds.includes(id)
      ? bookmarkedIds.filter(bId => bId !== id)
      : [...bookmarkedIds, id];
    setBookmarkedIds(updated);
    localStorage.setItem('omni_chemistry_glossary_bookmarks', JSON.stringify(updated));
    showNotification?.(bookmarkedIds.includes(id) ? 'Removed from saved definitions' : 'Saved to quick glossary bookmarks!', 'info');
  };

  const filteredItems = GLOSSARY_DATA.filter(item => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.definition.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.formula && item.formula.toLowerCase().includes(searchQuery.toLowerCase())) ||
      item.textbookChapter.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-y-auto p-6 md:p-8 selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-slate-50/50 text-slate-900"
    )}>
      {/* Header Banner */}
      <div className={cn(
        "p-6 rounded-3xl border mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl",
        theme === 'dark' ? "bg-gradient-to-r from-indigo-950/60 via-slate-900 to-violet-950/40 border-indigo-900/40" : "bg-gradient-to-r from-indigo-50 via-white to-violet-50 border-indigo-100"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-violet-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
            <FlaskConical size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                Interactive Chemistry Reference
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Chemistry Glossary & Concept Explorer
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Master coordination compounds, organic functional groups, and biomolecules with verified definitions and direct textbook links.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-4 py-2 rounded-2xl font-bold text-xs border border-indigo-500/20">
          <Sparkles size={16} />
          <span>{GLOSSARY_DATA.length} Curated Concepts</span>
        </div>
      </div>

      {/* Search & Category Filter Toolbar */}
      <div className="flex flex-col md:flex-row items-center gap-4 mb-6">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="Search terms, formulas, functional groups, or textbook chapters..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={cn(
              "w-full pl-12 pr-4 py-3 rounded-2xl text-sm border outline-none transition-all shadow-sm",
              theme === 'dark' 
                ? "bg-slate-800/80 border-slate-700 text-white placeholder-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20" 
                : "bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
            )}
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
          {[
            { id: 'all', label: 'All Concepts' },
            { id: 'coordination', label: 'Coordination Compounds' },
            { id: 'organic', label: 'Organic Groups' },
            { id: 'biomolecules', label: 'Biomolecules' }
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={cn(
                "px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap active:scale-95",
                activeCategory === cat.id
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/30"
                  : theme === 'dark'
                  ? "bg-slate-800 text-slate-300 hover:bg-slate-700"
                  : "bg-white text-slate-700 hover:bg-slate-100 border border-slate-200"
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Glossary Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.length === 0 ? (
          <div className="col-span-full py-16 text-center">
            <Atom className="mx-auto text-slate-400 mb-3 animate-spin" size={36} />
            <h3 className="text-lg font-bold">No chemistry terms found</h3>
            <p className="text-sm text-slate-500 mt-1">Try adjusting your search query or category filters.</p>
          </div>
        ) : (
          filteredItems.map(item => {
            const isBookmarked = bookmarkedIds.includes(item.id);
            return (
              <div
                key={item.id}
                className={cn(
                  "p-6 rounded-2xl border transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1 shadow-md",
                  theme === 'dark'
                    ? "bg-slate-800/60 border-slate-700/80 hover:border-indigo-500/50 hover:shadow-indigo-500/10"
                    : "bg-white border-slate-200/80 hover:border-indigo-300 hover:shadow-xl"
                )}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className={cn(
                      "text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-lg",
                      item.category === 'coordination' ? "bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20" :
                      item.category === 'organic' ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20" :
                      "bg-violet-500/10 text-violet-600 dark:text-violet-400 border border-violet-500/20"
                    )}>
                      {item.category === 'coordination' ? 'Coordination Chemistry' : item.category === 'organic' ? 'Organic Chemistry' : 'Biomolecules'}
                    </span>
                    <button
                      onClick={(e) => toggleBookmark(item.id, e)}
                      className={cn(
                        "p-2 rounded-xl transition-colors cursor-pointer",
                        isBookmarked ? "text-amber-500 bg-amber-500/10" : "text-slate-400 hover:text-indigo-500 hover:bg-indigo-500/10"
                      )}
                      title={isBookmarked ? "Remove Bookmark" : "Save Bookmark"}
                    >
                      <Bookmark size={16} fill={isBookmarked ? "currentColor" : "none"} />
                    </button>
                  </div>

                  <h3 className="text-lg font-black tracking-tight group-hover:text-indigo-500 transition-colors mb-1 flex items-center justify-between">
                    <span>{item.term}</span>
                    {item.formula && (
                      <span className="text-xs font-mono font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 rounded">
                        {item.formula}
                      </span>
                    )}
                  </h3>

                  <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                    {item.definition}
                  </p>

                  <div className="space-y-1.5 mb-6">
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">
                      Key Properties & Behavior
                    </div>
                    {item.properties.map((prop, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <CheckCircle2 size={13} className="text-indigo-500 shrink-0 mt-0.5" />
                        <span>{prop}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between mt-auto">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    <BookOpen size={14} />
                    <span>{item.textbookChapter}</span>
                  </div>
                  <button
                    onClick={() => onOpenChapter(item.chapterNumber)}
                    className="flex items-center gap-1 bg-indigo-50 hover:bg-indigo-600 text-indigo-600 hover:text-white dark:bg-indigo-950/60 dark:hover:bg-indigo-600 dark:text-indigo-300 text-xs font-bold px-3 py-1.5 rounded-xl transition-all active:scale-95 cursor-pointer shadow-sm"
                  >
                    <span>Jump to Chapter</span>
                    <ExternalLink size={12} />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
