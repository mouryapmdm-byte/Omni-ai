// src/components/ProfessorClarityDebuggerModal.tsx
/**
 * Master Debugging Dashboard & System Health Console
 * Part 5: Real-Time Observability, Auto-Recovery Logs, Automated Testing, and Health Matrix
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Activity,
  ShieldCheck,
  Zap,
  RefreshCw,
  Terminal,
  Cpu,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  X,
  Play,
  Layers,
  Sparkles,
  Search,
  Filter,
  Volume2,
  Video,
  Eye,
  Sliders,
  Flame,
  Info
} from 'lucide-react';
import { metrics, SystemHealthBreakdown } from '../metrics/metrics';
import { logger, LogEntry, LogLevel } from '../logging/logger';
import { PLAYBOOKS, getRecoveryLogs, RecoveryExecutionLog } from '../recovery/playbooks';
import { safeMode } from '../recovery/safe-mode';
import { autoTest, TestResult, TestCase } from '../testing/auto-test-suite';
import { cn } from '../lib/utils';

interface ProfessorClarityDebuggerModalProps {
  isOpen: boolean;
  onClose: () => void;
  showNotification?: (message: string, type: 'info' | 'success' | 'warning' | 'error') => void;
}

export const ProfessorClarityDebuggerModal: React.FC<ProfessorClarityDebuggerModalProps> = ({
  isOpen,
  onClose,
  showNotification,
}) => {
  const [activeTab, setActiveTab] = useState<'health' | 'playbooks' | 'tests' | 'logs' | 'categories'>('health');
  const [healthData, setHealthData] = useState<SystemHealthBreakdown>(metrics.calculateHealthScore());
  const [recoveryLogs, setRecoveryLogs] = useState<RecoveryExecutionLog[]>(getRecoveryLogs());
  const [recentLogs, setRecentLogs] = useState<LogEntry[]>(logger.getLogs({ limit: 100 }));
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedLogLevel, setSelectedLogLevel] = useState<number>(-1);
  const [logSearchQuery, setLogSearchQuery] = useState('');
  const [isSafeModeActive, setIsSafeModeActive] = useState(safeMode.isActive());

  // Test suite state
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [testResults, setTestResults] = useState<Array<{ test: TestCase; result: TestResult }>>(autoTest.getLastRunResults());

  // Refresh live metrics every 2 seconds when open
  useEffect(() => {
    if (!isOpen) return;

    const interval = setInterval(() => {
      setHealthData(metrics.calculateHealthScore());
      setRecoveryLogs(getRecoveryLogs());
      setIsSafeModeActive(safeMode.isActive());
    }, 2000);

    return () => clearInterval(interval);
  }, [isOpen]);

  // Subscribe to live log emission
  useEffect(() => {
    if (!isOpen) return;
    const unsubscribe = logger.subscribe((entry) => {
      setRecentLogs((prev) => [entry, ...prev.slice(0, 150)]);
    });
    return () => unsubscribe();
  }, [isOpen]);

  const handleManualRefresh = useCallback(() => {
    setIsRefreshing(true);
    setHealthData(metrics.calculateHealthScore());
    setRecoveryLogs(getRecoveryLogs());
    setRecentLogs(logger.getLogs({ limit: 100 }));
    setTimeout(() => setIsRefreshing(false), 400);
  }, []);

  const handleRunAllTests = async () => {
    setIsRunningTests(true);
    try {
      const outcome = await autoTest.runAll();
      setTestResults(outcome.results);
      showNotification?.(
        `Automated Diagnostic Suite: ${outcome.passedCount}/${outcome.totalCount} tests passed!`,
        outcome.passedCount === outcome.totalCount ? 'success' : 'warning'
      );
    } catch (err) {
      showNotification?.('Test suite run interrupted.', 'error');
    } finally {
      setIsRunningTests(false);
    }
  };

  const handleToggleSafeMode = () => {
    if (safeMode.isActive()) {
      safeMode.deactivate();
      setIsSafeModeActive(false);
      showNotification?.('Safe Mode deactivated. Full classroom capabilities active.', 'success');
    } else {
      safeMode.activate('Manual inspection toggle');
      setIsSafeModeActive(true);
      showNotification?.('Safe Mode manually activated for inspection.', 'info');
    }
  };

  const filteredLogs = useMemo(() => {
    return recentLogs.filter((log) => {
      if (selectedLogLevel !== -1 && log.level !== selectedLogLevel) return false;
      if (logSearchQuery.trim()) {
        const q = logSearchQuery.toLowerCase();
        return (
          log.message.toLowerCase().includes(q) ||
          log.component.toLowerCase().includes(q) ||
          (log.data && JSON.stringify(log.data).toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [recentLogs, selectedLogLevel, logSearchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in text-slate-100 font-sans">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-6xl w-full h-[92vh] flex flex-col shadow-2xl overflow-hidden relative">
        
        {/* Header Bar */}
        <div className="p-4 sm:p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
              <ShieldCheck size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2">
                  <span>Professor Clarity Self-Healing Architecture</span>
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>AUTONOMOUS BACKEND ACTIVE</span>
                </span>
                {isSafeModeActive && (
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                    SAFE MODE ACTIVE
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Observability, automated root-cause diagnosis, resilient recovery playbooks & live health scoring.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Refresh Health & Metrics"
            >
              <RefreshCw size={16} className={isRefreshing ? 'animate-spin text-indigo-400' : ''} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-4 sm:px-6 py-2 bg-slate-950/90 border-b border-slate-800/80 overflow-x-auto shrink-0">
          {[
            { id: 'health', label: 'System Health Dashboard', icon: <Activity size={14} /> },
            { id: 'playbooks', label: 'Recovery Playbooks & History', icon: <Zap size={14} /> },
            { id: 'tests', label: 'Automated Diagnostic Suite', icon: <Play size={14} /> },
            { id: 'logs', label: 'Live Observability Logs', icon: <Terminal size={14} /> },
            { id: 'categories', label: '12 Debugging Categories', icon: <Layers size={14} /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                'px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap',
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              )}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 custom-scrollbar">

          {/* TAB 1: SYSTEM HEALTH DASHBOARD */}
          {activeTab === 'health' && (
            <div className="space-y-6">
              {/* Top Hero Health Card */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950/40 border border-indigo-500/30 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400 block mb-1">
                      MASTER SYSTEM HEALTH SCORE
                    </span>
                    <div className="flex items-baseline gap-3">
                      <span className="text-3xl sm:text-4xl font-black font-mono text-emerald-400">
                        {healthData.overallHealth}
                      </span>
                      <span className="text-xs font-bold text-slate-400">/ 100</span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-xs font-bold">
                        OPTIMAL STABILITY
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">Uptime</span>
                      <span className="text-sm font-mono font-bold text-white">{healthData.uptimePercent}%</span>
                    </div>
                    <div className="h-8 w-px bg-slate-800" />
                    <button
                      onClick={handleToggleSafeMode}
                      className={cn(
                        'px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-md',
                        isSafeModeActive
                          ? 'bg-amber-600 hover:bg-amber-500 text-white'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      )}
                    >
                      <ShieldCheck size={14} />
                      <span>{isSafeModeActive ? 'Exit Safe Mode' : 'Toggle Safe Mode'}</span>
                    </button>
                  </div>
                </div>

                {/* 8-Component Weighted Breakdown Matrix */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                  {[
                    { name: 'React State', weight: '20%', data: healthData.components.reactState, icon: <Cpu size={14} /> },
                    { name: '3D Rendering', weight: '15%', data: healthData.components.rendering3d, icon: <Eye size={14} /> },
                    { name: 'Audio / Speech', weight: '10%', data: healthData.components.audioSpeech, icon: <Volume2 size={14} /> },
                    { name: 'HD Recording', weight: '10%', data: healthData.components.recording, icon: <Video size={14} /> },
                    { name: 'Teaching Quality', weight: '15%', data: healthData.components.teachingQuality, icon: <Sparkles size={14} /> },
                    { name: 'UI / UX Frame', weight: '10%', data: healthData.components.uiUx, icon: <Sliders size={14} /> },
                    { name: 'Performance', weight: '10%', data: healthData.components.performance, icon: <Zap size={14} /> },
                    { name: 'Curriculum Content', weight: '10%', data: healthData.components.content, icon: <CheckCircle2 size={14} /> },
                  ].map((comp, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-slate-400 text-[11px]">
                        <span className="font-bold flex items-center gap-1.5 text-slate-300">
                          {comp.icon}
                          <span>{comp.name}</span>
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">({comp.weight})</span>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-lg font-black font-mono text-white">
                          {comp.data.score}<span className="text-xs text-slate-500">/100</span>
                        </span>
                        <span className={cn(
                          'text-[10px] px-1.5 py-0.5 rounded font-bold uppercase',
                          comp.data.status === 'healthy' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                        )}>
                          {comp.data.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Real-time Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">FPS (Avg / Min)</span>
                  <div className="text-xl font-mono font-black text-cyan-400">
                    {healthData.metrics.fpsAvg} <span className="text-xs text-slate-500">/ {healthData.metrics.fpsMin}</span>
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Client Heap Memory</span>
                  <div className="text-xl font-mono font-black text-amber-400">
                    {healthData.metrics.memoryMb} <span className="text-xs text-slate-500">MB</span>
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Estimated CPU</span>
                  <div className="text-xl font-mono font-black text-indigo-400">
                    {healthData.metrics.cpuEstPercent}%
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Errors / Minute</span>
                  <div className="text-xl font-mono font-black text-emerald-400">
                    {healthData.metrics.errorsPerMinute}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Auto-Recoveries Today</span>
                  <div className="text-xl font-mono font-black text-purple-400">
                    {healthData.metrics.autoRecoveriesToday}
                  </div>
                </div>
              </div>

              {/* Predictive Alerts Panel */}
              {healthData.predictiveAlerts.length > 0 && (
                <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-2">
                  <h4 className="text-xs font-black uppercase text-amber-400 tracking-wider flex items-center gap-1.5">
                    <AlertTriangle size={14} />
                    <span>Predictive System Alerts (Automated Proactive Defense)</span>
                  </h4>
                  <div className="space-y-1.5">
                    {healthData.predictiveAlerts.map((alert) => (
                      <div key={alert.id} className="text-xs text-slate-300 flex items-center justify-between p-2 rounded-xl bg-slate-900/80 border border-slate-800">
                        <span>{alert.message}</span>
                        <span className="text-[10px] text-amber-400 font-mono">Action horizon: ~{alert.actionInHours}h</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: PLAYBOOKS & RECOVERIES */}
          {activeTab === 'playbooks' && (
            <div className="space-y-6">
              {/* Active Playbooks List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Zap size={16} className="text-indigo-400" />
                    <span>Registered Automated Recovery Playbooks</span>
                  </h3>
                  <span className="text-xs text-slate-400">
                    {PLAYBOOKS.length} Autonomous self-healing routines active
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {PLAYBOOKS.map((pb) => (
                    <div key={pb.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-bold">
                            {pb.category}
                          </span>
                          <h4 className="text-xs font-bold text-white">{pb.name}</h4>
                        </div>
                        <span className="text-[10px] font-mono text-slate-500">max {pb.maxAttempts} attempts</span>
                      </div>

                      <div className="space-y-1 pt-1">
                        {pb.steps.map((s, i) => (
                          <div key={i} className="text-[11px] text-slate-400 flex items-center gap-2">
                            <span className="text-emerald-400 text-xs">✓</span>
                            <span>{s.name}</span>
                            <span className="text-[10px] text-slate-600 font-mono">({s.timeout}ms)</span>
                          </div>
                        ))}
                      </div>

                      {pb.fallbackTo && (
                        <div className="text-[10px] text-amber-400/90 pt-1 flex items-center gap-1">
                          <Info size={11} />
                          <span>Fallback mode: {pb.fallbackTo}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Execution History */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">
                  Recent Autonomous Recovery Executions
                </h4>
                {recoveryLogs.length === 0 ? (
                  <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 text-center text-slate-400 text-xs">
                    No runtime crashes or exceptions intercepted. System is running cleanly with 0 interruptions.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {recoveryLogs.map((log) => (
                      <div key={log.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            'p-1.5 rounded-lg',
                            log.success ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                          )}>
                            {log.success ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />}
                          </div>
                          <div>
                            <div className="font-bold text-white">{log.playbookName}</div>
                            <div className="text-[11px] text-slate-400">
                              Trigger: <code className="text-indigo-300 font-mono">{log.errorTrigger}</code>
                            </div>
                          </div>
                        </div>

                        <div className="text-right text-[11px] font-mono text-slate-400">
                          <div>{log.durationMs}ms ({log.attempts} attempts)</div>
                          <div className="text-[10px] text-slate-500">{new Date(log.timestamp).toLocaleTimeString()}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: AUTOMATED TESTS */}
          {activeTab === 'tests' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Play size={16} className="text-cyan-400" />
                    <span>Automated Self-Testing & Diagnostic Suite</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Runs simulated render cycles, audio cancellation, recording streams, and KaTeX sanity checks.
                  </p>
                </div>
                <button
                  onClick={handleRunAllTests}
                  disabled={isRunningTests}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-black text-xs transition shadow-md shadow-indigo-600/20 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw size={13} className={isRunningTests ? 'animate-spin' : ''} />
                  <span>{isRunningTests ? 'Running Diagnostics...' : 'Run All Tests'}</span>
                </button>
              </div>

              {testResults.length === 0 ? (
                <div className="p-8 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-3">
                  <Sparkles size={28} className="mx-auto text-indigo-400" />
                  <p className="text-xs text-slate-400">
                    Diagnostic suite ready. Click "Run All Tests" to evaluate all system subsystems.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {testResults.map((item, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        'p-3.5 rounded-xl border flex items-start justify-between text-xs transition-all',
                        item.result.passed
                          ? 'bg-slate-950 border-slate-800'
                          : 'bg-red-950/20 border-red-500/30 text-red-200'
                      )}
                    >
                      <div className="flex items-start gap-3">
                        <div className={cn(
                          'p-1.5 rounded-lg mt-0.5',
                          item.result.passed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        )}>
                          {item.result.passed ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white">{item.test.name}</span>
                            <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] font-mono">
                              {item.test.component}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 mt-1">
                            {item.result.details || item.result.error}
                          </div>
                        </div>
                      </div>

                      <div className="text-right text-[11px] font-mono text-slate-400 shrink-0">
                        <span className={item.result.passed ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                          {item.result.passed ? 'PASSED' : 'FAILED'}
                        </span>
                        <div className="text-[10px] text-slate-500">{item.result.duration}ms</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: LIVE OBSERVABILITY LOGS */}
          {activeTab === 'logs' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2 flex-1 max-w-md">
                  <div className="relative w-full">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Search log messages or components..."
                      value={logSearchQuery}
                      onChange={(e) => setLogSearchQuery(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                {/* Log Level Filter */}
                <div className="flex items-center gap-1.5 overflow-x-auto">
                  {[
                    { label: 'ALL', level: -1 },
                    { label: 'INFO', level: LogLevel.INFO },
                    { label: 'WARN', level: LogLevel.WARN },
                    { label: 'ERROR', level: LogLevel.ERROR },
                  ].map((lvl) => (
                    <button
                      key={lvl.label}
                      onClick={() => setSelectedLogLevel(lvl.level)}
                      className={cn(
                        'px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer',
                        selectedLogLevel === lvl.level
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      )}
                    >
                      {lvl.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Terminal Logs Output */}
              <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 font-mono text-xs max-h-[50vh] overflow-y-auto space-y-1.5 custom-scrollbar">
                {filteredLogs.length === 0 ? (
                  <div className="p-4 text-center text-slate-500">No logs matching current filter.</div>
                ) : (
                  filteredLogs.map((log) => {
                    const levelColor =
                      log.level >= LogLevel.ERROR
                        ? 'text-red-400'
                        : log.level === LogLevel.WARN
                        ? 'text-amber-400'
                        : 'text-indigo-400';
                    return (
                      <div key={log.id} className="flex items-start gap-2 hover:bg-slate-900/50 p-1 rounded transition">
                        <span className="text-[10px] text-slate-600 shrink-0">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                        <span className={cn('text-[10px] font-black shrink-0 w-12', levelColor)}>
                          [{LogLevel[log.level]}]
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold shrink-0">
                          [{log.component}]
                        </span>
                        <span className="text-slate-200 break-all">{log.message}</span>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 5: 12 DEBUGGING CATEGORIES */}
          {activeTab === 'categories' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers size={16} className="text-indigo-400" />
                <span>The 12 Comprehensive Debugging Categories & Decision Trees</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {[
                  {
                    cat: '1. React State Errors',
                    signals: 'Maximum update depth, undefined access, render loops',
                    autofix: 'Wrap dependencies in useMemo/useCallback, functional updates, circuit breaker at 100 runs.',
                  },
                  {
                    cat: '2. 3D Rendering Errors',
                    signals: 'WebGL context lost, black screen > 2s, FPS < 30',
                    autofix: 'Automatic scene state restore, context reinit, LOD downscaling, resource disposal.',
                  },
                  {
                    cat: '3. Audio/Speech Errors',
                    signals: 'No audio, overlapping speech queues, sync drift > 200ms',
                    autofix: 'Previous speech cancelled before utterance, mutex serialization, AudioContext resume.',
                  },
                  {
                    cat: '4. Recording Errors',
                    signals: 'MediaRecorder throws, bitrate drops, captureStream null',
                    autofix: 'In-memory canvas frame stream, automatic partial saving, 1080p50 preset validation.',
                  },
                  {
                    cat: '5. Teaching Quality',
                    signals: 'Student confusion signals, pacing disengagement, monotone audio',
                    autofix: 'Active pedagogy shifts: analogy method, question-first, natural formula-to-practice flow.',
                  },
                  {
                    cat: '6. Question System',
                    signals: 'Wrong question count, missing hint tiers, lack of mastery tracking',
                    autofix: 'Enforce 5-level adaptive questions (Substitution -> Board Exam challenge), auto-hints.',
                  },
                  {
                    cat: '7. Figure Teaching',
                    signals: 'SVG not rendering, labels desynchronized from speech, figure clipping',
                    autofix: 'Progressive element revelation, speech-sync highlights, auto-close triggers.',
                  },
                  {
                    cat: '8. Smartboard Layout',
                    signals: 'Overlap between text & equations, raw LaTeX markup showing',
                    autofix: 'KaTeX delimiter auto-repair, safe zones padding, multi-mode responsive presentation.',
                  },
                  {
                    cat: '9. Avatar Issues',
                    signals: 'Avatar offscreen, gesture desync, photo autofit distortion',
                    autofix: 'Safe bounds repositioning, 1s gesture re-sync interval, default avatar fallback.',
                  },
                  {
                    cat: '10. Emotional Intelligence',
                    signals: 'Tone mismatch, lack of empathy, repetitive praise',
                    autofix: 'Adaptive Socratic tone matching, frustration detection, personalized encouragement.',
                  },
                  {
                    cat: '11. Teacher Discovery',
                    signals: 'Teacher persona mismatch, style drift',
                    autofix: 'Fuzzy teacher matcher, authenticity alignment with signature phrases & pedagogical style.',
                  },
                  {
                    cat: '12. Performance Issues',
                    signals: 'Memory > 400MB, CPU sustained high, battery drain',
                    autofix: 'Garbage disposal triggers, dynamic shadow map downscaling, deferred lazy loading.',
                  },
                ].map((item, idx) => (
                  <div key={idx} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="font-bold text-indigo-300 text-xs">{item.cat}</div>
                    <div className="text-slate-400 text-[11px]">
                      <strong className="text-slate-300">Signals: </strong>{item.signals}
                    </div>
                    <div className="text-slate-300 text-[11px]">
                      <strong className="text-emerald-400">Auto-Fix: </strong>{item.autofix}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <ShieldCheck size={14} className="text-emerald-400" />
            <span>Autonomous Self-Healing: Active & Monitoring Classroom Slate</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition cursor-pointer"
          >
            Close Debugger
          </button>
        </div>

      </div>
    </div>
  );
};
