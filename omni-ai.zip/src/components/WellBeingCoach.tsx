import React, { useState, useEffect } from 'react';
import { 
  Heart, Smile, Sparkles, Wind, Eye, Clock, Volume2, 
  VolumeX, Play, Pause, RefreshCw, CheckCircle2, Shield
} from 'lucide-react';
import { cn } from '../lib/utils';

interface Props {
  theme?: 'light' | 'dark';
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const WellBeingCoach: React.FC<Props> = ({
  theme = 'light',
  showNotification
}) => {
  const [stressLevel, setStressLevel] = useState<number>(3); // 1 to 5
  const [activeTab, setActiveTab] = useState<'breathing' | 'affirmations' | 'eye_strain'>('breathing');
  
  // Breathing animation states
  const [isBreathingActive, setIsBreathingActive] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [breathCountdown, setBreathCountdown] = useState(4);
  const [completedBreathCycles, setCompletedBreathCycles] = useState(0);

  // 4-7-8 Breathing Loop
  useEffect(() => {
    if (!isBreathingActive) return;

    const timer = setInterval(() => {
      setBreathCountdown(prev => {
        if (prev <= 1) {
          if (breathPhase === 'Inhale') {
            setBreathPhase('Hold');
            return 7;
          } else if (breathPhase === 'Hold') {
            setBreathPhase('Exhale');
            return 8;
          } else {
            setBreathPhase('Inhale');
            setCompletedBreathCycles(c => c + 1);
            return 4;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isBreathingActive, breathPhase]);

  const affirmations = [
    "You are capable of understanding even the most complex mathematical formulas. Take it one line of algebra at a time.",
    "Making mistakes during practice is not a sign of failure—it is the exact neurological mechanism of learning.",
    "Your worth is not defined by a single exam score. Steady, consistent curiosity always triumphs in the long run.",
    "Remember to drink a glass of water and relax your shoulders. Clarity begins with a calm mind."
  ];

  const [currentAffirmationIndex, setCurrentAffirmationIndex] = useState(0);

  const isDark = theme === 'dark';

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Top Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-pink-600 flex items-center justify-center text-white shadow-md">
            <Heart size={22} className="animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Emotional & Well-Being Support</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-rose-500/10 text-rose-400 border border-rose-500/20">
                Mindful Study
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Guided 4-7-8 breathing &bull; Stress alleviation &bull; 20-20-20 eye strain pauses
            </p>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('breathing')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
              activeTab === 'breathing' ? "bg-rose-600 text-white shadow-sm" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            )}
          >
            <Wind size={13} /> 4-7-8 Breathing
          </button>
          <button
            onClick={() => setActiveTab('eye_strain')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
              activeTab === 'eye_strain' ? "bg-rose-600 text-white shadow-sm" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            )}
          >
            <Eye size={13} /> 20-20-20 Rule
          </button>
          <button
            onClick={() => setActiveTab('affirmations')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
              activeTab === 'affirmations' ? "bg-rose-600 text-white shadow-sm" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            )}
          >
            <Smile size={13} /> Encouragement
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Stress Meter Check-in Bar */}
        <div className={cn(
          "p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
          isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200"
        )}>
          <div className="space-y-0.5">
            <span className="text-xs font-bold text-slate-300">How is your mental focus & stress right now?</span>
            <p className="text-[11px] text-slate-400">Professor Clarity tunes explanation pacing to your state.</p>
          </div>

          <div className="flex items-center gap-2">
            {[1, 2, 3, 4, 5].map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  setStressLevel(lvl);
                  showNotification?.(
                    lvl >= 4 ? "Take a 3-minute breather! Mental clarity is key." : "Focus calibrated.",
                    lvl >= 4 ? "warning" : "success"
                  );
                }}
                className={cn(
                  "w-8 h-8 rounded-lg font-bold text-xs transition cursor-pointer flex items-center justify-center",
                  stressLevel === lvl
                    ? "bg-rose-600 text-white ring-2 ring-rose-400 shadow-md"
                    : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                )}
              >
                {lvl === 1 ? '🌿' : lvl === 2 ? '😌' : lvl === 3 ? '😐' : lvl === 4 ? '😰' : '🔥'}
              </button>
            ))}
          </div>
        </div>

        {/* Tab 1: Guided Breathing Circle */}
        {activeTab === 'breathing' && (
          <div className="flex flex-col items-center justify-center py-6 space-y-6">
            <div className="relative flex items-center justify-center">
              {/* Outer Pulsing Aura */}
              <div
                className={cn(
                  "w-64 h-64 rounded-full border-4 transition-all duration-1000 flex items-center justify-center",
                  breathPhase === 'Inhale' 
                    ? "scale-110 border-cyan-400 bg-cyan-500/10 shadow-2xl shadow-cyan-500/20" 
                    : breathPhase === 'Hold'
                      ? "scale-105 border-amber-400 bg-amber-500/10"
                      : "scale-90 border-rose-400 bg-rose-500/10"
                )}
              >
                <div className="text-center space-y-1">
                  <span className="text-xs font-black uppercase tracking-widest text-slate-400">
                    {breathPhase}
                  </span>
                  <div className="text-4xl font-black font-mono">
                    {breathCountdown}s
                  </div>
                  <span className="text-[11px] text-slate-400 block">
                    Cycle #{completedBreathCycles + 1}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setIsBreathingActive(!isBreathingActive);
                  if (!isBreathingActive) {
                    setBreathPhase('Inhale');
                    setBreathCountdown(4);
                  }
                }}
                className={cn(
                  "px-6 py-2.5 rounded-xl font-bold text-xs shadow-lg transition flex items-center gap-2 cursor-pointer",
                  isBreathingActive
                    ? "bg-slate-800 hover:bg-slate-700 text-slate-200"
                    : "bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30"
                )}
              >
                {isBreathingActive ? <Pause size={14} /> : <Play size={14} />}
                {isBreathingActive ? "Pause Exercise" : "Start 4-7-8 Breathing Loop"}
              </button>
            </div>

            <p className="text-xs text-slate-400 text-center max-w-sm">
              Scientifically proven to activate the parasympathetic nervous system and reduce pre-exam cognitive anxiety within 90 seconds.
            </p>
          </div>
        )}

        {/* Tab 2: 20-20-20 Eye Strain Rule */}
        {activeTab === 'eye_strain' && (
          <div className="space-y-4 max-w-xl mx-auto">
            <div className={cn(
              "p-6 rounded-2xl border space-y-3",
              isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <div className="flex items-center gap-3 text-cyan-400">
                <Eye size={24} />
                <h3 className="text-sm font-bold text-slate-100">The 20-20-20 Digital Screen Rule</h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Every <strong>20 minutes</strong> spent looking at a screen, take a break to gaze at an object <strong>20 feet away</strong> for at least <strong>20 seconds</strong>.
              </p>
              <div className="p-3.5 rounded-xl bg-cyan-500/10 text-xs text-cyan-300 border border-cyan-500/20 font-semibold">
                Tip: Look out a window at a tree, cloud, or distant wall to relax ciliary eye muscles.
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Professor Clarity Affirmations */}
        {activeTab === 'affirmations' && (
          <div className="space-y-4 max-w-xl mx-auto">
            <div className={cn(
              "p-6 rounded-2xl border space-y-4 text-center",
              isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <Sparkles size={24} className="text-amber-400 mx-auto" />
              <p className="text-sm sm:text-base font-medium text-slate-200 leading-relaxed italic">
                "{affirmations[currentAffirmationIndex]}"
              </p>
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => setCurrentAffirmationIndex((currentAffirmationIndex + 1) % affirmations.length)}
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw size={12} /> Next Affirmation
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
