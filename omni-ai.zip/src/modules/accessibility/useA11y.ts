import { createContext, useContext } from 'react';
import { AccessibilityPreferences, LiveAnnouncement } from './types';

export interface A11yContextValue {
  preferences: AccessibilityPreferences;
  updatePreferences: (partial: Partial<AccessibilityPreferences>) => void;
  resetPreferences: () => void;
  announce: (message: string, priority?: 'polite' | 'assertive') => void;
  liveAnnouncement: LiveAnnouncement | null;
  toggleHighContrast: () => void;
  toggleDyslexiaFont: () => void;
  setFontScale: (scale: number) => void;
  toggleReducedMotion: () => void;
}

export const A11yContext = createContext<A11yContextValue | null>(null);

export const useA11y = (): A11yContextValue => {
  const context = useContext(A11yContext);
  if (!context) {
    throw new Error('useA11y must be used within an A11yProvider');
  }
  return context;
};
