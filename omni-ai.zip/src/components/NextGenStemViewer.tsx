import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { 
  Box, Eye, RotateCw, Play, Pause, RefreshCw, ZoomIn, ZoomOut,
  Layers, Sparkles, Compass, Atom, Cpu, Check, Info, Shield, 
  ChevronRight, Sliders, Maximize2, Share2, Download
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface Spatial3DStemViewerProps {
  theme: 'light' | 'dark';
  onSendToChat?: (text: string) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

type ModelCategory = 'math_surfaces' | 'vector_fields' | 'crystal_lattices' | 'molecules';

interface PresetItem {
  id: string;
  name: string;
  category: ModelCategory;
  formula: string;
  description: string;
  properties: { label: string; value: string }[];
}

const PRESETS: PresetItem[] = [
  // Math Surfaces
  {
    id: 'hyperbolic_paraboloid',
    name: 'Hyperbolic Paraboloid (Saddle)',
    category: 'math_surfaces',
    formula: 'z = \\frac{x^2}{a^2} - \\frac{y^2}{b^2}',
    description: 'A doubly ruled quadric surface having a saddle point at the origin where principal curvatures have opposite signs.',
    properties: [
      { label: 'Gaussian Curvature', value: 'K < 0 everywhere' },
      { label: 'Saddle Point', value: '(0, 0, 0)' },
      { label: 'Type', value: 'Doubly Ruled Quadric' }
    ]
  },
  {
    id: 'elliptic_paraboloid',
    name: 'Elliptic Paraboloid',
    category: 'math_surfaces',
    formula: 'z = \\frac{x^2}{a^2} + \\frac{y^2}{b^2}',
    description: 'A bowl-shaped quadric surface with elliptic horizontal cross-sections and parabolic vertical cross-sections.',
    properties: [
      { label: 'Gaussian Curvature', value: 'K > 0 everywhere' },
      { label: 'Extremum', value: 'Global Minimum at (0,0,0)' },
      { label: 'Type', value: 'Convex Quadric' }
    ]
  },
  {
    id: 'mobius_strip',
    name: 'Möbius Strip',
    category: 'math_surfaces',
    formula: 'x = (1 + \\frac{v}{2}\\cos\\frac{u}{2})\\cos u, \\; y = (1 + \\frac{v}{2}\\cos\\frac{u}{2})\\sin u, \\; z = \\frac{v}{2}\\sin\\frac{u}{2}',
    description: 'A non-orientable surface with only one boundary component and one continuous side.',
    properties: [
      { label: 'Euler Characteristic', value: 'χ = 0' },
      { label: 'Orientability', value: 'Non-orientable' },
      { label: 'Boundaries', value: 'Single unknotted loop' }
    ]
  },
  {
    id: 'torus_knot',
    name: 'Trefoil Torus Knot (2,3)',
    category: 'math_surfaces',
    formula: 'x = \\sin t + 2\\sin 2t, \\; y = \\cos t - 2\\cos 2t, \\; z = -\\sin 3t',
    description: 'The simplest non-trivial knot, formed by wrapping around a torus 2 times longitudinally and 3 times meridionally.',
    properties: [
      { label: 'Crossing Number', value: '3' },
      { label: 'Chirality', value: 'Chiral (Non-amphichiral)' },
      { label: 'Alexander Polynomial', value: 't - 1 + t^{-1}' }
    ]
  },
  // Vector Fields & Attractors
  {
    id: 'lorenz_attractor',
    name: 'Lorenz Strange Attractor (Chaos)',
    category: 'vector_fields',
    formula: '\\dot{x} = \\sigma(y - x), \\; \\dot{y} = x(\\rho - z) - y, \\; \\dot{z} = xy - \\beta z',
    description: 'Non-linear dynamical system exhibiting deterministic chaos, fractal dimension ~2.06, and butterfly-wing attractor lobes.',
    properties: [
      { label: 'Parameters', value: 'σ=10, ρ=28, β=8/3' },
      { label: 'Fractal Dimension', value: 'd_H ≈ 2.06' },
      { label: 'Lyapunov Exponent', value: 'λ_1 ≈ 0.905 > 0' }
    ]
  },
  {
    id: 'vortex_field',
    name: '3D Rotational Vector Field (Curl)',
    category: 'vector_fields',
    formula: '\\vec{F}(x,y,z) = \\langle -y, x, \\frac{z}{2} \\rangle, \\; \\nabla \\times \\vec{F} = 2\\hat{k}',
    description: '3D vector field demonstrating non-zero curl along the z-axis and vertical divergence.',
    properties: [
      { label: 'Curl (∇ × F)', value: '⟨0, 0, 2⟩' },
      { label: 'Divergence (∇ · F)', value: '0.5' },
      { label: 'Circulation', value: 'Counter-clockwise in XY' }
    ]
  },
  // Crystal Lattices
  {
    id: 'fcc_lattice',
    name: 'Face-Centered Cubic (FCC) Lattice',
    category: 'crystal_lattices',
    formula: 'a = 2\\sqrt{2} R, \\; APF = \\frac{\\pi}{3\\sqrt{2}} \\approx 0.74',
    description: 'Close-packed cubic crystal structure (e.g. Cu, Al, Au, Ag) with atoms at each corner and at center of all 6 cube faces.',
    properties: [
      { label: 'Coordination Number', value: '12' },
      { label: 'Atoms per Unit Cell', value: '4' },
      { label: 'Atomic Packing Factor', value: '74.05% (Max close-packed)' }
    ]
  },
  {
    id: 'bcc_lattice',
    name: 'Body-Centered Cubic (BCC) Lattice',
    category: 'crystal_lattices',
    formula: 'a = \\frac{4}{\\sqrt{3}} R, \\; APF = \\frac{\\sqrt{3}\\pi}{8} \\approx 0.68',
    description: 'Cubic crystal structure (e.g. α-Fe, Cr, W, Na) with an atom at each of the 8 corners and one central atom in the body.',
    properties: [
      { label: 'Coordination Number', value: '8' },
      { label: 'Atoms per Unit Cell', value: '2' },
      { label: 'Atomic Packing Factor', value: '68.02%' }
    ]
  },
  {
    id: 'diamond_cubic',
    name: 'Diamond Cubic Crystal Lattice',
    category: 'crystal_lattices',
    formula: 'APF = \\frac{\\sqrt{3}\\pi}{16} \\approx 0.34, \\; sp^3 \\text{ tetrahedral}',
    description: 'Tetrahedrally bonded crystal lattice formed by two interpenetrating FCC sublattices displaced by (1/4, 1/4, 1/4) of unit cube.',
    properties: [
      { label: 'Bond Angle', value: '109.47° (Tetrahedral)' },
      { label: 'Coordination Number', value: '4 (sp³ hybridization)' },
      { label: 'Atoms per Unit Cell', value: '8' }
    ]
  },
  // Molecules
  {
    id: 'dna_helix',
    name: 'B-DNA Double Helix',
    category: 'molecules',
    formula: '10.5 \\text{ bp/turn}, \\; 3.4 \\text{ nm pitch}, \\; 2.0 \\text{ nm diameter}',
    description: 'Right-handed antiparallel double helix with complementary purine-pyrimidine base pairs (A-T with 2 H-bonds, G-C with 3 H-bonds).',
    properties: [
      { label: 'Helical Sense', value: 'Right-handed B-form' },
      { label: 'Rise per Base Pair', value: '0.34 nm' },
      { label: 'Major / Minor Groove', value: '2.2 nm / 1.2 nm' }
    ]
  },
  {
    id: 'benzene_ring',
    name: 'Benzene Molecule (C₆H₆) & π-Orbital',
    category: 'molecules',
    formula: 'C_6H_6, \\; \\text{Aromatic Stabilization Energy } \\approx 150 \\text{ kJ/mol}',
    description: 'Planar hexagonal ring with sp² hybridized carbons and delocalized 6-electron aromatic π-cloud above and below the ring plane.',
    properties: [
      { label: 'Bond Length (C-C)', value: '139.9 pm (between single & double)' },
      { label: 'Bond Angles', value: '120° in-plane' },
      { label: 'Hückel Rule', value: '4n + 2 (n=1) = 6 π electrons' }
    ]
  },
  {
    id: 'cyclohexane_chair',
    name: 'Cyclohexane Chair Conformation',
    category: 'molecules',
    formula: 'C_6H_{12}, \\; \\text{Strain Energy } \\approx 0 \\text{ kcal/mol}',
    description: 'Most stable conformer of cyclohexane, free of all angle strain and eclipsing torsional strain, with alternating axial/equatorial hydrogens.',
    properties: [
      { label: 'C-C-C Angles', value: '109.5° (Ideal tetrahedral)' },
      { label: 'Torsional Strain', value: '0 (All bonds staggered)' },
      { label: 'Ring Flip Energy', value: '10.8 kcal/mol barrier' }
    ]
  }
];

export const NextGenStemViewer: React.FC<Spatial3DStemViewerProps> = ({
  theme,
  onSendToChat,
  showNotification
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedId, setSelectedId] = useState<string>('hyperbolic_paraboloid');
  const [activeCategory, setActiveCategory] = useState<ModelCategory>('math_surfaces');
  const [isRotating, setIsRotating] = useState(true);
  const [rotationSpeed, setRotationSpeed] = useState(0.008);
  const [wireframeMode, setWireframeMode] = useState(false);
  const [colorMap, setColorMap] = useState<'cyan_indigo' | 'thermal' | 'emerald' | 'sunset'>('cyan_indigo');
  const [slicePlane, setSlicePlane] = useState<'none' | 'xy' | 'xz' | 'yz'>('none');
  const [slicePos, setSlicePos] = useState(0);
  const [hoveredInfo, setHoveredInfo] = useState<string | null>(null);

  // Scene references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rootGroupRef = useRef<THREE.Group | null>(null);
  const sliceMeshRef = useRef<THREE.Mesh | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Interaction tracking (orbit drag)
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });

  const activePreset = PRESETS.find(p => p.id === selectedId) || PRESETS[0];

  // Initialize Three.js Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 450;

    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(theme === 'dark' ? 0x090d16 : 0xf8fafc);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 3.5, 7.5);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(5, 10, 7);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x6366f1, 0.8);
    dirLight2.position.set(-5, -5, -5);
    scene.add(dirLight2);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(10, 20, theme === 'dark' ? 0x334155 : 0xcbd5e1, theme === 'dark' ? 0x1e293b : 0xe2e8f0);
    gridHelper.position.y = -2;
    scene.add(gridHelper);

    // Root model group
    const rootGroup = new THREE.Group();
    rootGroupRef.current = rootGroup;
    scene.add(rootGroup);

    // Resize Observer
    const resizeObserver = new ResizeObserver(entries => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0 && cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = w / h;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    // Animation Loop
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);
      if (rootGroupRef.current && isRotating && !isDraggingRef.current) {
        rootGroupRef.current.rotation.y += rotationSpeed;
      }
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    animate();

    return () => {
      resizeObserver.disconnect();
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      renderer.dispose();
    };
  }, [theme]);

  // Build the 3D geometry whenever selectedId, wireframeMode, or colorMap changes
  useEffect(() => {
    const rootGroup = rootGroupRef.current;
    if (!rootGroup) return;

    // Clear previous models
    while (rootGroup.children.length > 0) {
      const obj = rootGroup.children[0];
      rootGroup.remove(obj);
      if ((obj as THREE.Mesh).geometry) (obj as THREE.Mesh).geometry.dispose();
    }

    const getColor = (u: number, v: number): THREE.Color => {
      if (colorMap === 'thermal') {
        const r = Math.sin(u * Math.PI);
        const g = Math.sin(v * Math.PI * 2);
        const b = Math.cos(u * Math.PI);
        return new THREE.Color(r, g, b);
      } else if (colorMap === 'emerald') {
        return new THREE.Color(0.1 + 0.3 * u, 0.6 + 0.3 * v, 0.4 + 0.3 * u);
      } else if (colorMap === 'sunset') {
        return new THREE.Color(0.9 - 0.3 * v, 0.3 + 0.4 * u, 0.6 + 0.2 * v);
      }
      // cyan_indigo
      return new THREE.Color(0.2 + 0.6 * u, 0.4 + 0.4 * (1 - v), 0.95);
    };

    switch (selectedId) {
      case 'hyperbolic_paraboloid': {
        const segments = 40;
        const geom = new THREE.BufferGeometry();
        const positions: number[] = [];
        const colors: number[] = [];
        const indices: number[] = [];

        for (let i = 0; i <= segments; i++) {
          const u = (i / segments) * 4 - 2; // x: -2 to 2
          for (let j = 0; j <= segments; j++) {
            const v = (j / segments) * 4 - 2; // y: -2 to 2
            const z = (u * u - v * v) * 0.35; // z = (x^2 - y^2)/k
            positions.push(u, z, v);

            const col = getColor((u + 2) / 4, (v + 2) / 4);
            colors.push(col.r, col.g, col.b);
          }
        }

        for (let i = 0; i < segments; i++) {
          for (let j = 0; j < segments; j++) {
            const a = i * (segments + 1) + j;
            const b = (i + 1) * (segments + 1) + j;
            const c = (i + 1) * (segments + 1) + (j + 1);
            const d = i * (segments + 1) + (j + 1);
            indices.push(a, b, d);
            indices.push(b, c, d);
          }
        }

        geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
        geom.setIndex(indices);
        geom.computeVertexNormals();

        const mat = new THREE.MeshStandardMaterial({
          vertexColors: true,
          side: THREE.DoubleSide,
          wireframe: wireframeMode,
          roughness: 0.3,
          metalness: 0.2
        });
        const mesh = new THREE.Mesh(geom, mat);
        rootGroup.add(mesh);

        // Add coordinate axes & saddle tangent arrows
        const axes = new THREE.AxesHelper(2.5);
        rootGroup.add(axes);
        break;
      }

      case 'elliptic_paraboloid': {
        const segments = 40;
        const geom = new THREE.BufferGeometry();
        const positions: number[] = [];
        const colors: number[] = [];
        const indices: number[] = [];

        for (let i = 0; i <= segments; i++) {
          const r = (i / segments) * 2;
          for (let j = 0; j <= segments; j++) {
            const theta = (j / segments) * Math.PI * 2;
            const x = r * Math.cos(theta);
            const y = (r * r) * 0.45 - 1.2;
            const z = r * Math.sin(theta);
            positions.push(x, y, z);

            const col = getColor(r / 2, j / segments);
            colors.push(col.r, col.g, col.b);
          }
        }

        for (let i = 0; i < segments; i++) {
          for (let j = 0; j < segments; j++) {
            const a = i * (segments + 1) + j;
            const b = (i + 1) * (segments + 1) + j;
            const c = (i + 1) * (segments + 1) + (j + 1);
            const d = i * (segments + 1) + (j + 1);
            indices.push(a, b, d);
            indices.push(b, c, d);
          }
        }

        geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
        geom.setIndex(indices);
        geom.computeVertexNormals();

        const mat = new THREE.MeshStandardMaterial({
          vertexColors: true,
          side: THREE.DoubleSide,
          wireframe: wireframeMode,
          roughness: 0.3,
          metalness: 0.2
        });
        rootGroup.add(new THREE.Mesh(geom, mat));
        rootGroup.add(new THREE.AxesHelper(2.5));
        break;
      }

      case 'mobius_strip': {
        const uSteps = 80;
        const vSteps = 20;
        const geom = new THREE.BufferGeometry();
        const positions: number[] = [];
        const colors: number[] = [];
        const indices: number[] = [];

        for (let i = 0; i <= uSteps; i++) {
          const u = (i / uSteps) * Math.PI * 2;
          for (let j = 0; j <= vSteps; j++) {
            const v = (j / vSteps) * 0.8 - 0.4;
            const x = (1.5 + v * Math.cos(u / 2)) * Math.cos(u);
            const y = (1.5 + v * Math.cos(u / 2)) * Math.sin(u);
            const z = v * Math.sin(u / 2);
            positions.push(x, z, y);

            const col = getColor(i / uSteps, j / vSteps);
            colors.push(col.r, col.g, col.b);
          }
        }

        for (let i = 0; i < uSteps; i++) {
          for (let j = 0; j < vSteps; j++) {
            const a = i * (vSteps + 1) + j;
            const b = (i + 1) * (vSteps + 1) + j;
            const c = (i + 1) * (vSteps + 1) + (j + 1);
            const d = i * (vSteps + 1) + (j + 1);
            indices.push(a, b, d);
            indices.push(b, c, d);
          }
        }

        geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
        geom.setIndex(indices);
        geom.computeVertexNormals();

        const mat = new THREE.MeshStandardMaterial({
          vertexColors: true,
          side: THREE.DoubleSide,
          wireframe: wireframeMode,
          roughness: 0.3
        });
        rootGroup.add(new THREE.Mesh(geom, mat));
        break;
      }

      case 'torus_knot': {
        const geom = new THREE.TorusKnotGeometry(1.4, 0.4, 140, 24, 2, 3);
        const count = geom.attributes.position.count;
        const colors: number[] = [];
        for (let i = 0; i < count; i++) {
          const col = getColor((i % 70) / 70, i / count);
          colors.push(col.r, col.g, col.b);
        }
        geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

        const mat = new THREE.MeshStandardMaterial({
          vertexColors: true,
          wireframe: wireframeMode,
          roughness: 0.2,
          metalness: 0.4
        });
        rootGroup.add(new THREE.Mesh(geom, mat));
        break;
      }

      case 'lorenz_attractor': {
        // Integrate Lorenz Equations (RK4-like step)
        let x = 0.1, y = 0, z = 0;
        const dt = 0.008;
        const sigma = 10, rho = 28, beta = 8 / 3;
        const points: THREE.Vector3[] = [];
        const colors: number[] = [];

        for (let i = 0; i < 4000; i++) {
          const dx = sigma * (y - x) * dt;
          const dy = (x * (rho - z) - y) * dt;
          const dz = (x * y - beta * z) * dt;
          x += dx;
          y += dy;
          z += dz;
          // Scale & center
          points.push(new THREE.Vector3(x * 0.08, (z - 25) * 0.08, y * 0.08));

          const t = i / 4000;
          const col = getColor(t, (z / 50));
          colors.push(col.r, col.g, col.b);
        }

        const curve = new THREE.CatmullRomCurve3(points);
        const tubeGeom = new THREE.TubeGeometry(curve, 1000, 0.035, 6, false);
        tubeGeom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

        const mat = new THREE.MeshStandardMaterial({
          vertexColors: true,
          roughness: 0.2,
          metalness: 0.5
        });
        rootGroup.add(new THREE.Mesh(tubeGeom, mat));
        break;
      }

      case 'vortex_field': {
        // Grid of 3D Vector arrows
        const arrowGroup = new THREE.Group();
        const range = 1.8;
        const step = 0.9;

        for (let x = -range; x <= range; x += step) {
          for (let y = -range; y <= range; y += step) {
            for (let z = -range; z <= range; z += step) {
              const vx = -y * 0.4;
              const vy = 0.2 * z;
              const vz = x * 0.4;
              const dir = new THREE.Vector3(vx, vy, vz);
              const len = dir.length();
              if (len > 0.05) {
                dir.normalize();
                const col = getColor((x + range) / (2 * range), Math.min(len, 1));
                const arrow = new THREE.ArrowHelper(dir, new THREE.Vector3(x, y, z), Math.min(len * 0.8, 0.7), col.getHex(), 0.15, 0.08);
                arrowGroup.add(arrow);
              }
            }
          }
        }
        rootGroup.add(arrowGroup);
        rootGroup.add(new THREE.AxesHelper(2.5));
        break;
      }

      case 'fcc_lattice': {
        // FCC Unit Cell with 8 corner atoms + 6 face atoms + wireframe cube
        const fccGroup = new THREE.Group();
        const size = 2.2;
        const r = 0.32;
        const atomGeom = new THREE.SphereGeometry(r, 24, 24);
        const cornerMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, metalness: 0.3, roughness: 0.2 });
        const faceMat = new THREE.MeshStandardMaterial({ color: 0x10b981, metalness: 0.3, roughness: 0.2 });

        // 8 Corners
        const corners = [
          [-size/2, -size/2, -size/2], [size/2, -size/2, -size/2],
          [-size/2, size/2, -size/2], [size/2, size/2, -size/2],
          [-size/2, -size/2, size/2], [size/2, -size/2, size/2],
          [-size/2, size/2, size/2], [size/2, size/2, size/2],
        ];
        corners.forEach(([cx, cy, cz]) => {
          const sphere = new THREE.Mesh(atomGeom, cornerMat);
          sphere.position.set(cx, cy, cz);
          fccGroup.add(sphere);
        });

        // 6 Face Centers
        const faces = [
          [0, 0, -size/2], [0, 0, size/2],
          [0, -size/2, 0], [0, size/2, 0],
          [-size/2, 0, 0], [size/2, 0, 0]
        ];
        faces.forEach(([fx, fy, fz]) => {
          const sphere = new THREE.Mesh(atomGeom, faceMat);
          sphere.position.set(fx, fy, fz);
          fccGroup.add(sphere);
        });

        // Wireframe box
        const boxGeom = new THREE.BoxGeometry(size, size, size);
        const wireMat = new THREE.LineBasicMaterial({ color: 0x94a3b8, linewidth: 2 });
        const wireMesh = new THREE.LineSegments(new THREE.EdgesGeometry(boxGeom), wireMat);
        fccGroup.add(wireMesh);

        rootGroup.add(fccGroup);
        break;
      }

      case 'bcc_lattice': {
        // BCC Unit Cell: 8 Corners + 1 Center
        const bccGroup = new THREE.Group();
        const size = 2.2;
        const r = 0.35;
        const cornerMat = new THREE.MeshStandardMaterial({ color: 0x6366f1, metalness: 0.3, roughness: 0.2 });
        const centerMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.4, roughness: 0.2 });

        const atomGeom = new THREE.SphereGeometry(r, 24, 24);
        const corners = [
          [-size/2, -size/2, -size/2], [size/2, -size/2, -size/2],
          [-size/2, size/2, -size/2], [size/2, size/2, -size/2],
          [-size/2, -size/2, size/2], [size/2, -size/2, size/2],
          [-size/2, size/2, size/2], [size/2, size/2, size/2],
        ];
        corners.forEach(([cx, cy, cz]) => {
          const sphere = new THREE.Mesh(atomGeom, cornerMat);
          sphere.position.set(cx, cy, cz);
          bccGroup.add(sphere);
        });

        const centerSphere = new THREE.Mesh(atomGeom, centerMat);
        centerSphere.position.set(0, 0, 0);
        bccGroup.add(centerSphere);

        // Body diagonals connecting center to corners
        corners.forEach(([cx, cy, cz]) => {
          const cylGeom = new THREE.CylinderGeometry(0.04, 0.04, Math.sqrt(3)*size/2, 8);
          const cylMat = new THREE.MeshBasicMaterial({ color: 0xe2e8f0 });
          const cyl = new THREE.Mesh(cylGeom, cylMat);
          cyl.position.set(cx/2, cy/2, cz/2);
          cyl.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(cx, cy, cz).normalize());
          bccGroup.add(cyl);
        });

        const boxGeom = new THREE.BoxGeometry(size, size, size);
        const wireMat = new THREE.LineBasicMaterial({ color: 0x94a3b8 });
        bccGroup.add(new THREE.LineSegments(new THREE.EdgesGeometry(boxGeom), wireMat));

        rootGroup.add(bccGroup);
        break;
      }

      case 'diamond_cubic': {
        const diaGroup = new THREE.Group();
        const size = 2.4;
        const atomGeom = new THREE.SphereGeometry(0.24, 20, 20);
        const mat = new THREE.MeshStandardMaterial({ color: 0x06b6d4, metalness: 0.7, roughness: 0.1 });

        // Generate tetrahedral diamond lattice nodes
        const latticeNodes: [number, number, number][] = [
          [-size/2, -size/2, -size/2], [size/2, -size/2, -size/2], [-size/2, size/2, -size/2], [size/2, size/2, -size/2],
          [-size/2, -size/2, size/2], [size/2, -size/2, size/2], [-size/2, size/2, size/2], [size/2, size/2, size/2],
          [0, 0, -size/2], [0, 0, size/2], [0, -size/2, 0], [0, size/2, 0], [-size/2, 0, 0], [size/2, 0, 0],
          [-size/4, -size/4, -size/4], [size/4, size/4, -size/4], [size/4, -size/4, size/4], [-size/4, size/4, size/4]
        ];

        latticeNodes.forEach(([x, y, z]) => {
          const atom = new THREE.Mesh(atomGeom, mat);
          atom.position.set(x, y, z);
          diaGroup.add(atom);
        });

        const boxGeom = new THREE.BoxGeometry(size, size, size);
        diaGroup.add(new THREE.LineSegments(new THREE.EdgesGeometry(boxGeom), new THREE.LineBasicMaterial({ color: 0x64748b })));
        rootGroup.add(diaGroup);
        break;
      }

      case 'dna_helix': {
        const dnaGroup = new THREE.Group();
        const numPairs = 18;
        const radius = 1.2;
        const heightPerStep = 0.28;
        const angleStep = Math.PI / 5; // ~10 pairs per turn

        const strandMat1 = new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.3 });
        const strandMat2 = new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.3 });
        const aMat = new THREE.MeshStandardMaterial({ color: 0xef4444 });
        const tMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b });
        const gMat = new THREE.MeshStandardMaterial({ color: 0x10b981 });
        const cMat = new THREE.MeshStandardMaterial({ color: 0x8b5cf6 });

        const atomGeom = new THREE.SphereGeometry(0.16, 16, 16);

        for (let i = 0; i < numPairs; i++) {
          const y = (i - numPairs / 2) * heightPerStep;
          const angle1 = i * angleStep;
          const angle2 = angle1 + Math.PI;

          const x1 = Math.cos(angle1) * radius;
          const z1 = Math.sin(angle1) * radius;
          const x2 = Math.cos(angle2) * radius;
          const z2 = Math.sin(angle2) * radius;

          // Sugar-phosphate backbone nodes
          const b1 = new THREE.Mesh(atomGeom, strandMat1);
          b1.position.set(x1, y, z1);
          dnaGroup.add(b1);

          const b2 = new THREE.Mesh(atomGeom, strandMat2);
          b2.position.set(x2, y, z2);
          dnaGroup.add(b2);

          // Base pair rungs (half pair 1 + half pair 2)
          const basePairType = i % 2 === 0; // A-T vs G-C
          const p1 = new THREE.Vector3(x1, y, z1);
          const p2 = new THREE.Vector3(x2, y, z2);
          const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);

          // Half 1
          const cyl1Geom = new THREE.CylinderGeometry(0.06, 0.06, radius, 8);
          const cyl1 = new THREE.Mesh(cyl1Geom, basePairType ? aMat : gMat);
          cyl1.position.set((x1 + mid.x) / 2, y, (z1 + mid.z) / 2);
          cyl1.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(mid.x - x1, 0, mid.z - z1).normalize());
          dnaGroup.add(cyl1);

          // Half 2
          const cyl2Geom = new THREE.CylinderGeometry(0.06, 0.06, radius, 8);
          const cyl2 = new THREE.Mesh(cyl2Geom, basePairType ? tMat : cMat);
          cyl2.position.set((x2 + mid.x) / 2, y, (z2 + mid.z) / 2);
          cyl2.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(mid.x - x2, 0, mid.z - z2).normalize());
          dnaGroup.add(cyl2);
        }

        rootGroup.add(dnaGroup);
        break;
      }

      case 'benzene_ring': {
        const benzGroup = new THREE.Group();
        const r = 1.4;
        const carbonMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.3, metalness: 0.4 });
        const hydroMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.2 });
        const bondMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.4 });

        const carbonGeom = new THREE.SphereGeometry(0.24, 20, 20);
        const hydroGeom = new THREE.SphereGeometry(0.14, 16, 16);

        for (let i = 0; i < 6; i++) {
          const theta = (i / 6) * Math.PI * 2;
          const cx = Math.cos(theta) * r;
          const cz = Math.sin(theta) * r;

          const c = new THREE.Mesh(carbonGeom, carbonMat);
          c.position.set(cx, 0, cz);
          benzGroup.add(c);

          // Hydrogen
          const hx = Math.cos(theta) * (r + 0.9);
          const hz = Math.sin(theta) * (r + 0.9);
          const h = new THREE.Mesh(hydroGeom, hydroMat);
          h.position.set(hx, 0, hz);
          benzGroup.add(h);

          // C-H bond
          const chGeom = new THREE.CylinderGeometry(0.04, 0.04, 0.9, 8);
          const ch = new THREE.Mesh(chGeom, bondMat);
          ch.position.set((cx + hx) / 2, 0, (cz + hz) / 2);
          ch.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(hx - cx, 0, hz - cz).normalize());
          benzGroup.add(ch);

          // C-C bond
          const nextTheta = ((i + 1) / 6) * Math.PI * 2;
          const ncx = Math.cos(nextTheta) * r;
          const ncz = Math.sin(nextTheta) * r;
          const ccGeom = new THREE.CylinderGeometry(0.06, 0.06, r, 8);
          const cc = new THREE.Mesh(ccGeom, bondMat);
          cc.position.set((cx + ncx) / 2, 0, (cz + ncz) / 2);
          cc.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(ncx - cx, 0, ncz - cz).normalize());
          benzGroup.add(cc);
        }

        // Delocalized pi-electron cloud ring (torus above and below plane)
        const piCloudGeom = new THREE.TorusGeometry(r * 0.9, 0.18, 16, 40);
        const piMat = new THREE.MeshStandardMaterial({
          color: 0x6366f1,
          transparent: true,
          opacity: 0.45,
          roughness: 0.1
        });
        const topCloud = new THREE.Mesh(piCloudGeom, piMat);
        topCloud.rotation.x = Math.PI / 2;
        topCloud.position.y = 0.4;
        benzGroup.add(topCloud);

        const botCloud = new THREE.Mesh(piCloudGeom, piMat);
        botCloud.rotation.x = Math.PI / 2;
        botCloud.position.y = -0.4;
        benzGroup.add(botCloud);

        rootGroup.add(benzGroup);
        break;
      }

      case 'cyclohexane_chair': {
        const chairGroup = new THREE.Group();
        // 6 Carbons in chair conformation
        const carbons: [number, number, number][] = [
          [1.2, 0.35, 0],
          [0.6, -0.35, 1.04],
          [-0.6, 0.35, 1.04],
          [-1.2, -0.35, 0],
          [-0.6, 0.35, -1.04],
          [0.6, -0.35, -1.04]
        ];

        const cMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.3 });
        const hAxMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.2 }); // Red for Axial
        const hEqMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.2 }); // Blue for Equatorial
        const bondMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8 });

        const cGeom = new THREE.SphereGeometry(0.22, 20, 20);
        const hGeom = new THREE.SphereGeometry(0.12, 16, 16);

        carbons.forEach(([x, y, z], idx) => {
          const c = new THREE.Mesh(cGeom, cMat);
          c.position.set(x, y, z);
          chairGroup.add(c);

          // C-C bond to next carbon
          const next = carbons[(idx + 1) % 6];
          const dist = Math.sqrt((next[0] - x)**2 + (next[1] - y)**2 + (next[2] - z)**2);
          const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, dist, 8), bondMat);
          cyl.position.set((x + next[0]) / 2, (y + next[1]) / 2, (z + next[2]) / 2);
          cyl.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(next[0] - x, next[1] - y, next[2] - z).normalize());
          chairGroup.add(cyl);

          // Axial Hydrogen (strictly up or down)
          const isUp = idx % 2 === 0;
          const axY = y + (isUp ? 0.75 : -0.75);
          const hAx = new THREE.Mesh(hGeom, hAxMat);
          hAx.position.set(x, axY, z);
          chairGroup.add(hAx);

          const axBond = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.75, 8), bondMat);
          axBond.position.set(x, (y + axY) / 2, z);
          chairGroup.add(axBond);

          // Equatorial Hydrogen
          const eqVec = new THREE.Vector3(x, isUp ? -0.25 : 0.25, z).normalize().multiplyScalar(0.75);
          const hEq = new THREE.Mesh(hGeom, hEqMat);
          hEq.position.set(x + eqVec.x, y + eqVec.y, z + eqVec.z);
          chairGroup.add(hEq);

          const eqBond = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.75, 8), bondMat);
          eqBond.position.set(x + eqVec.x / 2, y + eqVec.y / 2, z + eqVec.z / 2);
          eqBond.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), eqVec.clone().normalize());
          chairGroup.add(eqBond);
        });

        rootGroup.add(chairGroup);
        break;
      }
    }
  }, [selectedId, wireframeMode, colorMap]);

  // Handle Slicing Plane
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (sliceMeshRef.current) {
      scene.remove(sliceMeshRef.current);
      sliceMeshRef.current.geometry.dispose();
      sliceMeshRef.current = null;
    }

    if (slicePlane !== 'none') {
      const planeGeom = new THREE.PlaneGeometry(6, 6);
      const planeMat = new THREE.MeshStandardMaterial({
        color: 0xec4899,
        transparent: true,
        opacity: 0.3,
        side: THREE.DoubleSide
      });
      const planeMesh = new THREE.Mesh(planeGeom, planeMat);

      if (slicePlane === 'xy') {
        planeMesh.position.z = slicePos;
      } else if (slicePlane === 'xz') {
        planeMesh.rotation.x = Math.PI / 2;
        planeMesh.position.y = slicePos;
      } else if (slicePlane === 'yz') {
        planeMesh.rotation.y = Math.PI / 2;
        planeMesh.position.x = slicePos;
      }

      sliceMeshRef.current = planeMesh;
      scene.add(planeMesh);
    }
  }, [slicePlane, slicePos]);

  // Mouse Orbit Drag Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !rootGroupRef.current) return;
    const deltaX = e.clientX - prevMousePos.current.x;
    const deltaY = e.clientY - prevMousePos.current.y;

    rootGroupRef.current.rotation.y += deltaX * 0.01;
    rootGroupRef.current.rotation.x += deltaY * 0.01;

    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleZoom = (direction: 'in' | 'out') => {
    if (!cameraRef.current) return;
    const factor = direction === 'in' ? 0.85 : 1.15;
    cameraRef.current.position.multiplyScalar(factor);
    cameraRef.current.updateProjectionMatrix();
  };

  const handleResetCamera = () => {
    if (!cameraRef.current || !rootGroupRef.current) return;
    cameraRef.current.position.set(0, 3.5, 7.5);
    cameraRef.current.lookAt(0, 0, 0);
    rootGroupRef.current.rotation.set(0, 0, 0);
    setSlicePlane('none');
    setSlicePos(0);
    showNotification?.("3D Viewport camera reset to default", "info");
  };

  const handleSendToTutor = () => {
    const prompt = `Can you explain the mathematical and physical significance of the 3D model: "${activePreset.name}" with formula $${activePreset.formula}$? Specifically cover:
1. Geometric properties and coordinate transformations
2. Physical or chemical applications
3. How to calculate its key invariants or properties (${activePreset.properties.map(p => `${p.label}: ${p.value}`).join(', ')})`;
    if (onSendToChat) {
      onSendToChat(prompt);
      showNotification?.(`Sent ${activePreset.name} to AI Tutor!`, "success");
    }
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col lg:flex-row rounded-2xl overflow-hidden border shadow-xl",
      theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
    )}>
      {/* Left / Control Panel */}
      <div className={cn(
        "w-full lg:w-80 flex-shrink-0 flex flex-col border-b lg:border-b-0 lg:border-r overflow-y-auto p-4 space-y-4",
        theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50/80 border-slate-200"
      )}>
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-md">
              <Box size={18} />
            </div>
            <div>
              <h2 className="text-sm font-bold leading-tight">3D STEM Visualizer</h2>
              <span className="text-[10px] text-indigo-500 font-semibold uppercase tracking-wider">Spatial Geometry & Atoms</span>
            </div>
          </div>
        </div>

        {/* Category Selector Tabs */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-slate-200/60 dark:bg-slate-850">
          <button
            onClick={() => setActiveCategory('math_surfaces')}
            className={cn(
              "py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1",
              activeCategory === 'math_surfaces'
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Compass size={13} />
            <span>Surfaces</span>
          </button>
          <button
            onClick={() => setActiveCategory('vector_fields')}
            className={cn(
              "py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1",
              activeCategory === 'vector_fields'
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Sliders size={13} />
            <span>Vectors</span>
          </button>
          <button
            onClick={() => setActiveCategory('crystal_lattices')}
            className={cn(
              "py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1",
              activeCategory === 'crystal_lattices'
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Cpu size={13} />
            <span>Lattices</span>
          </button>
          <button
            onClick={() => setActiveCategory('molecules')}
            className={cn(
              "py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1",
              activeCategory === 'molecules'
                ? "bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Atom size={13} />
            <span>Molecules</span>
          </button>
        </div>

        {/* Model Presets List */}
        <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
          {PRESETS.filter(p => p.category === activeCategory).map(preset => (
            <button
              key={preset.id}
              onClick={() => setSelectedId(preset.id)}
              className={cn(
                "w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between cursor-pointer",
                selectedId === preset.id
                  ? "bg-indigo-50 dark:bg-indigo-950/50 border-indigo-500 text-indigo-900 dark:text-indigo-200 font-bold shadow-sm"
                  : "border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300"
              )}
            >
              <div className="truncate pr-2">
                <div className="text-xs truncate">{preset.name}</div>
                <div className="text-[10px] opacity-60 font-mono truncate">{preset.formula}</div>
              </div>
              {selectedId === preset.id && (
                <Check size={14} className="text-indigo-600 dark:text-indigo-400 flex-shrink-0" />
              )}
            </button>
          ))}
        </div>

        {/* Selected Preset Details */}
        <div className={cn(
          "p-3 rounded-xl border text-xs space-y-2",
          theme === 'dark' ? "bg-slate-900/90 border-slate-800" : "bg-white border-slate-200"
        )}>
          <div className="font-bold text-slate-900 dark:text-white">{activePreset.name}</div>
          <div className="text-[11px] font-mono text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 p-1.5 rounded-lg border border-indigo-200/50 dark:border-indigo-900/50 overflow-x-auto">
            {activePreset.formula}
          </div>
          <p className="text-[11px] opacity-75 leading-relaxed">{activePreset.description}</p>

          <div className="space-y-1 pt-1 border-t border-slate-200 dark:border-slate-800">
            {activePreset.properties.map((prop, idx) => (
              <div key={idx} className="flex justify-between items-center text-[10px]">
                <span className="opacity-60">{prop.label}:</span>
                <span className="font-semibold text-right">{prop.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Shading & Viewport Controls */}
        <div className="space-y-2">
          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Render Styles & Slicing</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setWireframeMode(!wireframeMode)}
              className={cn(
                "p-2 rounded-lg text-xs font-semibold border flex items-center justify-center gap-1.5 cursor-pointer transition-all",
                wireframeMode
                  ? "bg-indigo-600 text-white border-indigo-600"
                  : "border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
              )}
            >
              <Layers size={13} />
              <span>Wireframe</span>
            </button>

            <select
              value={colorMap}
              onChange={e => setColorMap(e.target.value as any)}
              className={cn(
                "p-2 rounded-lg text-xs font-semibold border outline-none cursor-pointer",
                theme === 'dark' ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-800"
              )}
            >
              <option value="cyan_indigo">Theme: Indigo Cyan</option>
              <option value="thermal">Theme: Thermal Spectrum</option>
              <option value="emerald">Theme: Emerald Matrix</option>
              <option value="sunset">Theme: Sunset Coral</option>
            </select>
          </div>

          {/* Slicing plane selector */}
          <div className="flex items-center gap-2 pt-1">
            <span className="text-[10px] opacity-60">Slice Plane:</span>
            {(['none', 'xy', 'xz', 'yz'] as const).map(plane => (
              <button
                key={plane}
                onClick={() => setSlicePlane(plane)}
                className={cn(
                  "px-2 py-1 rounded text-[10px] uppercase font-bold border transition-all cursor-pointer",
                  slicePlane === plane
                    ? "bg-pink-600 text-white border-pink-600"
                    : "border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                )}
              >
                {plane}
              </button>
            ))}
          </div>

          {slicePlane !== 'none' && (
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] opacity-75">
                <span>Plane Offset:</span>
                <span>{slicePos.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="-2"
                max="2"
                step="0.05"
                value={slicePos}
                onChange={e => setSlicePos(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-pink-500"
              />
            </div>
          )}
        </div>

        {/* Action Button: Ask Tutor */}
        <button
          onClick={handleSendToTutor}
          className="w-full mt-auto py-2.5 px-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/25 active:scale-95 transition-all cursor-pointer"
        >
          <Sparkles size={14} />
          <span>Explain in AI Tutor Chat</span>
        </button>
      </div>

      {/* Right / 3D Canvas Viewport */}
      <div className="flex-1 relative flex flex-col min-h-[400px]">
        {/* Top Viewport Overlay Controls */}
        <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
          <div className="pointer-events-auto flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700 text-white text-xs shadow-lg">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-semibold">{activePreset.name}</span>
          </div>

          <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-900/80 backdrop-blur-md p-1 rounded-xl border border-slate-700 text-white shadow-lg">
            <button
              onClick={() => setIsRotating(!isRotating)}
              title={isRotating ? "Pause Auto-Rotation" : "Start Auto-Rotation"}
              className={cn(
                "p-2 rounded-lg transition-all cursor-pointer",
                isRotating ? "bg-indigo-600 text-white" : "hover:bg-slate-800 text-slate-300"
              )}
            >
              {isRotating ? <Pause size={14} /> : <Play size={14} />}
            </button>
            <button
              onClick={() => handleZoom('in')}
              title="Zoom In"
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-300 transition-all cursor-pointer"
            >
              <ZoomIn size={14} />
            </button>
            <button
              onClick={() => handleZoom('out')}
              title="Zoom Out"
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-300 transition-all cursor-pointer"
            >
              <ZoomOut size={14} />
            </button>
            <button
              onClick={handleResetCamera}
              title="Reset Camera Orientation"
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-300 transition-all cursor-pointer"
            >
              <RefreshCw size={14} />
            </button>
          </div>
        </div>

        {/* 3D WebGL Canvas Container */}
        <div
          ref={mountRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className="flex-1 w-full h-full cursor-grab active:cursor-grabbing select-none"
        />

        {/* Bottom Viewport Status Helper */}
        <div className="absolute bottom-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none text-[11px]">
          <div className="bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300">
            🖱️ <span className="font-semibold">Click & drag</span> to rotate | Scroll to zoom
          </div>

          <div className="bg-indigo-950/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-indigo-800 text-indigo-300 font-mono">
            {activePreset.category.toUpperCase()}
          </div>
        </div>
      </div>
    </div>
  );
};
