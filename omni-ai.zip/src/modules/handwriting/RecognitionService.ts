import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });

export async function recognizeMath(imageData: string): Promise<string> {
  const prompt = "Convert this handwritten mathematical expression into a clean LaTeX string. Return ONLY the LaTeX string, no other text.";
  
  const result = await ai.models.generateContent({
    model: 'gemini-2.0-flash',
    contents: [
      prompt,
      {
        inlineData: {
          data: imageData.split(',')[1],
          mimeType: 'image/png'
        }
      }
    ]
  });
  
  return (result.text || '').trim();
}
