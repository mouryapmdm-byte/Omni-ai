const fs = require('fs');
const file = 'src/lib/constants.ts';
let content = fs.readFileSync(file, 'utf8');

const targetStr = `export const MATHEMATICS_ICSE_LESSONS = [
  "1. Relations and Functions",
  "2. Inverse Trigonometric Functions",
  "3. Matrices",`;

const replacementStr = `export const MATHEMATICS_ICSE_LESSONS = [
  "1. Relations and Functions",
  "2. Inverse Trigonometric Functions - Definition, domain, range, principal value branch, Graphs, Elementary properties",
  "3. Matrices",`;

if (content.includes(targetStr)) {
  content = content.replace(targetStr, replacementStr);
  fs.writeFileSync(file, content);
  console.log("Replaced math lessons successfully.");
} else {
  console.log("Target string not found.");
}
