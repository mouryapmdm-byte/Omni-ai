export const CONFIG = {
  VERSION: "14.0-OmniAI-Ultimate-Complete",
  APP_NAME: "Omni AI Ultimate",
  DIFFICULTY_LEVELS: ['high', 'college', 'graduate', 'phd', 'ai_research'] as const,
  MATH_TOPICS: [
    'arithmetic', 'algebra', 'geometry', 'calculus', 'linear_algebra',
    'number_theory', 'probability_statistics', 'discrete_mathematics',
    'trigonometry', 'differential_equations', 'real_analysis', 'complex_analysis',
    'topology', 'abstract_algebra', 'numerical_methods', 'optimization',
    'combinatorics', 'graph_theory', 'set_theory', 'logic'
  ] as const,
  SUBJECTS: [
    'mathematics', 'physics', 'chemistry', 'biology', 'computer_science',
    'history', 'geography', 'literature', 'languages', 'economics',
    'psychology', 'philosophy', 'art', 'music', 'sociology', 'political_science',
    'medicine', 'law', 'business', 'ai_research', 
    'mechanical_engineering', 'civil_engineering', 'electrical_engineering', 
    'chemical_engineering', 'aerospace_engineering', 'biomedical_engineering',
    'english', 'social_science', 'history_geography', 'environmental_science',
    'astronomy', 'geology', 'accounting', 'business_studies', 'civics',
    'biotechnology', 'cybersecurity', 'journalism_media', 'statistics',
    'home_science', 'physical_education', 'other'
  ] as const,
  TOPICS: {
    mathematics: [
      'arithmetic', 'algebra', 'geometry', 'calculus', 'linear_algebra',
      'number_theory', 'probability_statistics', 'discrete_mathematics',
      'trigonometry', 'differential_equations', 'real_analysis', 'complex_analysis',
      'topology', 'abstract_algebra', 'numerical_methods', 'optimization',
      'combinatorics', 'graph_theory', 'set_theory', 'logic', 'category_theory',
      'fractal_geometry', 'chaos_theory', 'cryptography', 'game_theory_math'
    ],
    physics: [
      '1. Electric Charges and Field',
      "2. Gauss' Theorem",
      "3. Electric Potential",
      "4. Capacitors and Dielectrics",
      "5. Electric Resistance and Ohm's Law",
      "6. DC Circuits and Measurements",
      "7. Moving Charges and Magnetic Field",
      "8. Torque on a Current-Loop : Moving-Coil Galvanometer",
      "9. Magnetic Field and Earth's Magnetism",
      "10. Magnetic Classification of Substances",
      "11. Electromagnetic Induction",
      "12. Alternating Current",
      "13. Electromagnetic Waves",
      "14. Ray Optics and Optical Instruments",
      "15. Wave Optics",
      "16. Dual Nature of Radiation and Matter",
      "17. Atoms",
      "18. Nuclei",
      "19. Semiconductor Electronics",
      "20. Communication Systems",
      "21. Reflection of Light : Spherical Mirrors",
      "22. Refraction of Light at a Plane Interface : Total Internal Reflection : Optical Fiber",
      "23. Refraction of Light at Spherical Surfaces : Lenses",
      "24. Refraction and Dispersion of Light through a Prism",
      "25. Optical Instruments",
      "26. Wave Nature of Light : Huygens' Principle",
      "27. Interference of Light",
      "28. Diffraction of Light",
      "29. Polarization of Light",
      "30. Photoelectric Effect",
      "31. Matter Waves",
      "32. X-Rays",
      "33. Atom, Origin of Spectra : Bohr's Theory of Hydrogen Atom",
      "34. Nuclear Structure",
      "35. Radioactivity",
      "36. Mass-Energy Equivalence : Nuclear Binding Energy",
      "37. Nuclear Fission and Fusion : Sources of Energy",
      "38. Semiconductor Electronics",
      "39. Semiconductor Diodes",
      "40. Junction Transistors",
      "41. Logic Gates",
      "42. Communication Systems",
      'mechanics', 'thermodynamics', 'electromagnetism', 'optics', 'quantum_mechanics',
      'relativity', 'particle_physics', 'astrophysics', 'condensed_matter', 'nuclear_physics',
      'fluid_dynamics', 'plasma_physics', 'acoustics', 'biophysics', 'geophysics',
      'string_theory', 'quantum_field_theory', 'cosmology', 'statistical_mechanics'
    ],
    chemistry: [
      'organic_chemistry', 'inorganic_chemistry', 'physical_chemistry', 'analytical_chemistry',
      'biochemistry', 'theoretical_chemistry', 'environmental_chemistry', 'materials_science',
      'polymer_chemistry', 'medicinal_chemistry', 'thermochemistry', 'electrochemistry',
      'spectroscopy', 'quantum_chemistry', 'nanochemistry', 'Appendix: Chemistry Appendices'
    ],
    biology: [
      'genetics', 'evolution', 'ecology', 'cell_biology', 'molecular_biology',
      'physiology', 'anatomy', 'microbiology', 'botany', 'zoology',
      'marine_biology', 'neurobiology', 'immunology', 'biotechnology', 'paleontology',
      'virology', 'mycology', 'entomology', 'bioinformatics'
    ],
    computer_science: [
      'algorithms', 'data_structures', 'operating_systems', 'networks', 'databases',
      'software_engineering', 'artificial_intelligence', 'machine_learning', 'cybersecurity', 'graphics',
      'cloud_computing', 'distributed_systems', 'human_computer_interaction', 'compilers',
      'computer_architecture', 'blockchain', 'quantum_computing', 'internet_of_things'
    ],
    history: [
      'ancient_history', 'medieval_history', 'modern_history', 'world_war_i', 'world_war_ii',
      'cold_war', 'renaissance', 'industrial_revolution', 'colonialism', 'civil_rights',
      'american_history', 'european_history', 'asian_history', 'african_history',
      'latin_american_history', 'history_of_science', 'economic_history', 'art_history_context'
    ],
    geography: [
      'physical_geography', 'human_geography', 'cartography', 'climatology', 'geomorphology',
      'economic_geography', 'political_geography', 'environmental_geography',
      'urban_geography', 'population_geography', 'gis_remote_sensing', 'hydrology',
      'biogeography', 'oceanography'
    ],
    literature: [
      'poetry', 'drama', 'fiction', 'non_fiction', 'literary_criticism',
      'comparative_literature', 'creative_writing', 'classics',
      'renaissance_literature', 'romanticism', 'modernism', 'post_modernism',
      'world_literature', 'shakespearian_studies', 'mythology'
    ],
    languages: [
      'linguistics', 'phonetics', 'syntax', 'semantics', 'pragmatics',
      'english', 'spanish', 'french', 'german', 'chinese', 'japanese',
      'italian', 'russian', 'arabic', 'portuguese', 'language_acquisition',
      'sociolinguistics', 'historical_linguistics'
    ],
    economics: [
      'microeconomics', 'macroeconomics', 'econometrics', 'game_theory',
      'behavioral_economics', 'development_economics', 'international_trade',
      'labor_economics', 'public_finance', 'monetary_economics', 'financial_economics',
      'environmental_economics', 'economic_growth'
    ],
    psychology: [
      'cognitive_psychology', 'developmental_psychology', 'social_psychology',
      'clinical_psychology', 'neuropsychology', 'behavioral_psychology',
      'educational_psychology', 'forensic_psychology', 'industrial_organizational',
      'personality_psychology', 'abnormal_psychology', 'positive_psychology'
    ],
    philosophy: [
      'ethics', 'metaphysics', 'epistemology', 'logic', 'political_philosophy',
      'aesthetics', 'existentialism', 'phenomenology',
      'philosophy_of_mind', 'philosophy_of_science', 'ancient_philosophy',
      'modern_philosophy', 'eastern_philosophy', 'stoicism'
    ],
    art: [
      'art_history', 'painting', 'sculpture', 'photography', 'digital_art',
      'architecture', 'design', 'fine_arts',
      'graphic_design', 'fashion_design', 'interior_design', 'animation',
      'cinematography', 'printmaking', 'ceramics'
    ],
    music: [
      'music_theory', 'composition', 'music_history', 'ethnomusicology',
      'performance', 'jazz', 'classical', 'electronic_music',
      'music_production', 'orchestration', 'conducting', 'music_therapy',
      'acoustics_music', 'film_scoring'
    ],
    sociology: [
      'origin_dev_sociology_anthropology', 'research_methodology_sociology',
      'basic_concepts_society_culture', 'social_structure_groups_processes',
      'social_problems_deviance', 'indian_sociologists_thinkers', 'practical_sociological_research',
      'social_theory', 'social_stratification', 'urban_sociology', 'rural_sociology',
      'sociology_of_education', 'sociology_of_religion', 'gender_studies',
      'race_and_ethnicity', 'criminology', 'demography', 'social_movements'
    ],
    political_science: [
      'international_relations', 'comparative_politics', 'political_theory',
      'public_policy', 'public_administration', 'political_economy',
      'geopolitics', 'human_rights', 'diplomacy', 'electoral_systems'
    ],
    medicine: [
      'internal_medicine', 'surgery', 'pediatrics', 'obstetrics_gynecology',
      'psychiatry', 'neurology', 'cardiology', 'oncology', 'radiology',
      'pathology', 'pharmacology', 'epidemiology', 'public_health', 'genetics_medicine'
    ],
    mechanical_engineering: [
      'thermodynamics', 'fluid_mechanics', 'solid_mechanics', 'kinematics',
      'robotics', 'manufacturing', 'heat_transfer', 'machine_design'
    ],
    civil_engineering: [
      'structural_engineering', 'geotechnical_engineering', 'transportation_engineering',
      'environmental_engineering', 'water_resources', 'construction_management', 'surveying'
    ],
    electrical_engineering: [
      'circuit_theory', 'electromagnetics', 'control_systems', 'power_systems',
      'microelectronics', 'signal_processing', 'telecommunications', 'digital_logic'
    ],
    chemical_engineering: [
      'process_design', 'transport_phenomena', 'chemical_kinetics', 'thermodynamics_chem',
      'materials_science', 'polymer_engineering', 'biochemical_engineering', 'process_control'
    ],
    aerospace_engineering: [
      'aerodynamics', 'propulsion', 'orbital_mechanics', 'flight_dynamics',
      'avionics', 'spacecraft_design', 'aircraft_structures', 'materials_aerospace'
    ],
    biomedical_engineering: [
      'biomechanics', 'biomaterials', 'medical_imaging', 'bioinformatics',
      'tissue_engineering', 'neural_engineering', 'clinical_engineering', 'biosensors'
    ],
    law: [
      'constitutional_law', 'criminal_law', 'civil_law', 'international_law',
      'corporate_law', 'intellectual_property', 'environmental_law',
      'human_rights_law', 'family_law', 'administrative_law', 'tort_law'
    ],
    business: [
      'marketing', 'finance', 'accounting', 'management', 'entrepreneurship',
      'human_resources', 'operations_management', 'supply_chain',
      'business_analytics', 'international_business', 'organizational_behavior'
    ],
    ai_research: [
      'neural_networks', 'transformers', 'reinforcement_learning', 'computer_vision',
      'natural_language_processing', 'generative_models', 'robotics', 'ethics_in_ai',
      'explainable_ai', 'ai_safety', 'large_language_models', 'automated_reasoning',
      'multi_agent_systems', 'knowledge_representation'
    ],
    other: [
      'general_knowledge', 'current_affairs', 'hobbies', 'travel', 'food',
      'lifestyle', 'technology_news', 'entertainment', 'sports', 'miscellaneous'
    ],
    english: [
      'reading_comprehension', 'creative_writing', 'grammar_and_mechanics', 'vocabulary_building', 'rhetorical_analysis', 'literary_devices', 'speaking_and_listening'
    ],
    social_science: [
      'civic_responsibilities', 'democratic_politics', 'economic_systems_impact', 'social_structures', 'cultural_heritage', 'globalization_effects'
    ],
    history_geography: [
      'climatology_patterns', 'physical_landforms', 'world_historical_epochs', 'cartography_skills', 'human_migration_geography', 'geopolitical_structures'
    ],
    environmental_science: [
      'ecosystems_dynamics', 'climate_change_science', 'biodiversity_conservation', 'sustainable_resource_management', 'pollution_toxicology_remediations'
    ],
    astronomy: [
      'stellar_evolution_cycles', 'cosmology_and_origins', 'planetary_geology', 'space_exploration_technologies', 'observational_astrophysics_methods'
    ],
    geology: [
      'plate_tectonics_faults', 'mineralogy_and_petrology', 'stratigraphy_sedimentations', 'geomorphology_processes', 'natural_hazards_mitigation'
    ],
    accounting: [
      'double_entry_bookkeeping', 'financial_statement_analysis', 'management_accounting_controls', 'auditing_standards', 'corporate_taxation_structures'
    ],
    business_studies: [
      'organizational_structures', 'strategic_operations_management', 'human_resource_dynamics', 'business_ethics_compliance', 'international_market_entry'
    ],
    civics: [
      'constitutional_frameworks_design', 'electoral_systems_behavior', 'public_policy_creation_cycles', 'citizenship_rights_obligations', 'municipal_governance_systems'
    ],
    biotechnology: [
      'recombinant_dna_technologies', 'immunotechnology_advancements', 'bioprocess_engineering_scaleup', 'agricultural_genetic_modifications', 'bioethics_regulations'
    ],
    cybersecurity: [
      'cryptographic_systems', 'network_security_protocols', 'threat_vectors_mitigations', 'digital_forensics_incident_response', 'security_compliance_auditing'
    ],
    journalism_media: [
      'investigative_reporting', 'ethical_media_standards', 'digital_media_seo_writing', 'broadcasting_production_operations', 'pr_campaign_strategies'
    ],
    statistics: [
      'probability_distribution_models', 'hypothesis_testing_inferences', 'multivariate_regression_analyses', 'data_visualization_theory', 'survey_sampling_designs'
    ],
    home_science: [
      'dietetics_clinical_nutrition', 'human_development_lifespan', 'family_resource_budgetings', 'textile_science_care_fabrics', 'community_outreach_extension'
    ],
    physical_education: [
      'kinesiology_and_applied_anatomy', 'exercise_physiology_dynamics', 'sports_nutrition_metabolism', 'athletic_training_methodology', 'sports_psychology_coaching'
    ]
  } as Record<string, string[]>,
  ENTRANCE_EXAMS_DATA: {
    'NTSE': { name: 'National Talent Search Examination (NTSE)', subjects: ['mathematics', 'science', 'social_science'], topics: { mathematics: ['arithmetic', 'algebra'], science: ['physics', 'chemistry', 'biology'], social_science: ['history', 'geography', 'civics'] }, eligibility: 'Conducted by NCERT for 10th-grade students to award scholarships for higher studies in sciences and social sciences.' },
    'KVPY': { name: 'Kishore Vaigyanik Protsahan Yojana (KVPY)', subjects: ['mathematics', 'physics', 'chemistry', 'biology'], topics: { mathematics: ['arithmetic', 'algebra'], physics: ['mechanics', 'optics'], chemistry: ['organic', 'physical'], biology: ['genetics', 'physiology'] }, eligibility: 'National fellowship/scholarship program funded by the Department of Science and Technology for 11th/12th graders pursuing basic science courses.' },
    'NSE': { name: 'National Standard Examination (NSE)', subjects: ['physics', 'chemistry', 'biology', 'astronomy'], topics: { physics: ['mechanics', 'optics'], chemistry: ['organic', 'physical'], biology: ['genetics', 'physiology'], astronomy: ['celestial_mechanics'] }, eligibility: 'Conducted by IAPT in Physics, Chemistry, Biology, Astronomy, and Junior Science, acting as the first step toward the International Olympiads.' },
    'JEE_MAIN': { name: 'Joint Entrance Examination (JEE) Main / Advanced', subjects: ['mathematics', 'physics', 'chemistry'], topics: { mathematics: ['algebra', 'calculus', 'coordinate_geometry'], physics: ['mechanics', 'thermodynamics', 'electromagnetism'], chemistry: ['physical', 'organic', 'inorganic'] }, eligibility: 'The primary national-level test for admission into undergraduate engineering and architecture courses at IITs, NITs, and IIITs.' },
    'CUET_UG': { name: 'Common University Entrance Test (CUET UG)', subjects: ['mathematics', 'physics', 'chemistry', 'biology', 'history', 'geography', 'english'], topics: { mathematics: ['algebra', 'calculus'], physics: ['mechanics', 'optics'], chemistry: ['organic', 'physical'], biology: ['botany', 'zoology'], history: ['modern_history'], geography: ['physical_geography'], english: ['grammar'] }, eligibility: 'Standardized exam administered by the National Testing Agency (NTA) for admissions into undergraduate courses across participating Central and State universities.' },
    'NDA': { name: 'National Defence Academy (NDA) Exam', subjects: ['mathematics', 'general_ability'], topics: { mathematics: ['algebra', 'trigonometry'], general_ability: ['english', 'current_affairs'] }, eligibility: 'Conducted by UPSC for admission to the Army, Navy, and Air Force wings of the NDA.' },
    'NEET_UG': { name: 'NEET (UG)', subjects: ['physics', 'chemistry', 'biology'], topics: { physics: ['mechanics', 'optics', 'modern_physics'], chemistry: ['organic', 'inorganic', 'physical'], biology: ['botany', 'zoology'] }, eligibility: 'The qualifying test for admission to undergraduate medical (MBBS/BDS) and allied courses in India.' },
    'CAT': { name: 'Common Admission Test (CAT)', subjects: ['quantitative_ability', 'data_interpretation', 'verbal_ability'], topics: { quantitative_ability: ['arithmetic', 'algebra'], data_interpretation: ['charts', 'graphs'], verbal_ability: ['reading_comprehension'] }, eligibility: 'The premier national-level management aptitude test for admission to IIMs and other top B-schools.' },
    'GATE': { name: 'Graduate Aptitude Test in Engineering (GATE)', subjects: ['engineering_math', 'computer_science', 'electronics', 'mechanical'], topics: { engineering_math: ['linear_algebra', 'calculus'], computer_science: ['algorithms', 'networks'], electronics: ['circuits', 'signals'], mechanical: ['thermodynamics', 'mechanics'] }, eligibility: 'National examination for comprehensive understanding of various undergraduate subjects in engineering and science, often required for M.Tech/Ph.D. admissions.' },
    'CLAT': { name: 'Common Law Admission Test (CLAT)', subjects: ['english', 'legal_aptitude', 'logical_reasoning', 'general_knowledge'], topics: { english: ['comprehension'], legal_aptitude: ['contracts', 'torts'], logical_reasoning: ['analytical'], general_knowledge: ['current_affairs'] }, eligibility: 'National level entrance exam for admissions to undergraduate (LLB) and postgraduate (LLM) degree programs at 24 National Law Universities (NLUs) in India.' },
    'CUET_PG': { name: 'Common University Entrance Test (CUET PG)', subjects: ['general_knowledge', 'subject_specific'], topics: { general_knowledge: ['current_affairs'], subject_specific: ['domain_knowledge'] }, eligibility: 'Conducted by NTA for admission into postgraduate programs across participating Central and State universities.' },
    'CEED_UCEED': { name: 'CEED / UCEED', subjects: ['design_aptitude', 'drawing'], topics: { design_aptitude: ['visual_spatial'], drawing: ['sketching'] }, eligibility: 'Joint entrance examinations conducted by IIT Bombay for Common Entrance Examination for Design (Postgraduate) and Undergraduate programs, respectively.' },
    'UNI_SPECIFIC': { name: 'University-Specific Exams', subjects: ['general_knowledge', 'subject_specific'], topics: { general_knowledge: ['current_affairs'], subject_specific: ['domain_knowledge'] }, eligibility: 'Many universities conduct their own specialized entrance exams for master\'s programs, such as the Jawaharlal Nehru University Entrance Examination (JNUEE) and Delhi University Entrance Test (DUET).' },
    'UGC_CSIR_NET': { name: 'UGC-NET / CSIR-NET', subjects: ['general_aptitude', 'subject_specific'], topics: { general_aptitude: ['reasoning'], subject_specific: ['domain_knowledge'] }, eligibility: 'Conducted by NTA to determine eligibility for the Junior Research Fellowship (JRF) and/or Lectureship in humanities and sciences.' },
    'JEST': { name: 'Joint Entrance Screening Test (JEST)', subjects: ['physics', 'theoretical_cs', 'neuroscience'], topics: { physics: ['mechanics', 'electromagnetism'], theoretical_cs: ['algorithms'], neuroscience: ['neurobiology'] }, eligibility: 'National level exam for admission to Ph.D. and Integrated Ph.D. programs in Physics, Theoretical Computer Science, Neuroscience, or Computational Biology at premier institutes.' },
    'TIFR_GS': { name: 'TIFR GS', subjects: ['physics', 'chemistry', 'biology', 'mathematics'], topics: { physics: ['mechanics'], chemistry: ['organic'], biology: ['genetics'], mathematics: ['algebra'] }, eligibility: 'The Graduate School Admission test conducted by the Tata Institute of Fundamental Research (TIFR) for Ph.D. in science domains.' },
    'DBT_ICMR_JRF': { name: 'DBT-JRF / ICMR-JRF', subjects: ['biotechnology', 'medical_research'], topics: { biotechnology: ['recombinant_dna'], medical_research: ['epidemiology'] }, eligibility: 'Specific fellowship exams conducted for Junior Research Fellowship in Biotechnology and Medical Research.' },
    'INDIAN_ARMY_TES': { name: 'Indian Army TES', subjects: ['physics', 'chemistry', 'mathematics'], topics: { physics: ['mechanics'], chemistry: ['organic'], mathematics: ['algebra'] }, eligibility: 'Technical Entry Scheme. Shortlisted based on 12th PCM percentages followed by rigorous SSB interviews for a direct permanent commission in the Army alongside a B.Tech degree.' },
    'INDIAN_NAVY_10_2': { name: 'Indian Navy 10+2 B.Tech Entry Scheme', subjects: ['physics', 'chemistry', 'mathematics'], topics: { physics: ['mechanics'], chemistry: ['organic'], mathematics: ['algebra'] }, eligibility: 'Uses JEE Main ranks to shortlist candidates for direct Service Selection Board (SSB) interviews for Navy engineering careers.' },
    'SITEEE': { name: 'SITEEE', subjects: ['physics', 'chemistry', 'mathematics'], topics: { physics: ['mechanics'], chemistry: ['organic'], mathematics: ['algebra'] }, eligibility: 'Symbiosis International University’s standalone engineering test for its technical institutes.' },
    'JNU_FL_PG': { name: 'JNU Foreign Language PG Test', subjects: ['linguistics', 'geopolitics'], topics: { linguistics: ['syntax'], geopolitics: ['international_relations'] }, eligibility: 'Dedicated entrance framework for pursuing Master of Arts in specialized international linguistics, geopolitics, and translation.' },
    'NIMCJ_ENTRANCE': { name: 'NIMCJ Entrance Exam', subjects: ['journalism_media', 'general_knowledge'], topics: { journalism_media: ['reporting'], general_knowledge: ['current_affairs'] }, eligibility: 'National Institute of Mass Communication and Journalism test for postgraduate diplomas in electronic, print, and digital journalism.' },
    'EFLUPG': { name: 'EFLUPG', subjects: ['english', 'linguistics'], topics: { english: ['comprehension'], linguistics: ['syntax'] }, eligibility: 'English and Foreign Languages University exam for MA English, Linguistics, and foreign languages.' },
    'ISRO_JRF': { name: 'ISRO JRF Screening Test', subjects: ['physics', 'remote_sensing', 'satellite_engineering'], topics: { physics: ['mechanics'], remote_sensing: ['gis'], satellite_engineering: ['avionics'] }, eligibility: 'Organized periodically by the Indian Space Research Organisation for choosing junior research fellows for space sciences, remote sensing, and satellite payload engineering.' },
    'MH_SET': { name: 'MH-SET', subjects: ['general_knowledge', 'subject_specific'], topics: { general_knowledge: ['current_affairs'], subject_specific: ['domain_knowledge'] }, eligibility: 'State Eligibility Test for Lectureship.' },
    'KSET': { name: 'KSET', subjects: ['general_knowledge', 'subject_specific'], topics: { general_knowledge: ['current_affairs'], subject_specific: ['domain_knowledge'] }, eligibility: 'State Eligibility Test for Lectureship.' },
    'WB_SET': { name: 'WB-SET', subjects: ['general_knowledge', 'subject_specific'], topics: { general_knowledge: ['current_affairs'], subject_specific: ['domain_knowledge'] }, eligibility: 'State Eligibility Test for Lectureship.' },
    'TNSET': { name: 'TNSET', subjects: ['general_knowledge', 'subject_specific'], topics: { general_knowledge: ['current_affairs'], subject_specific: ['domain_knowledge'] }, eligibility: 'State Eligibility Test for Lectureship.' },
    'GSET': { name: 'GSET', subjects: ['general_knowledge', 'subject_specific'], topics: { general_knowledge: ['current_affairs'], subject_specific: ['domain_knowledge'] }, eligibility: 'State Eligibility Test for Lectureship.' },
    'AMU_ENTRANCE': { name: 'AMU Entrance Exam', subjects: ['physics', 'chemistry', 'mathematics'], topics: { physics: ['mechanics'], chemistry: ['organic'], mathematics: ['algebra'] }, eligibility: 'Aligarh Muslim University\'s institutional test for engineering (B.Tech) and architecture.' },
    'IMU_CET': { name: 'IMU CET', subjects: ['physics', 'chemistry', 'mathematics', 'english'], topics: { physics: ['mechanics'], chemistry: ['organic'], mathematics: ['algebra'], english: ['comprehension'] }, eligibility: 'Indian Maritime University Common Entrance Test for pursuing B.Sc. Nautical Science, B.Tech Marine Engineering, or DNS.' }
  },
  COMPETITIONS: {
    'IMO': { level: 'phd', topics: ['geometry', 'number_theory', 'algebra', 'combinatorics'] },
    'AMC': { level: 'high', topics: ['algebra', 'geometry', 'counting', 'probability'] },
    'MATHCOUNTS': { level: 'high', topics: ['arithmetic', 'algebra', 'geometry', 'number_theory'] },
    'INMO': { level: 'high', topics: ['number_theory', 'geometry', 'combinatorics', 'algebra'] }
  },
  STREAK_MILESTONES: {
    7: { icon: '🔥', reward: 'Week Warrior', xp: 200 },
    14: { icon: '📚', reward: 'Fortnight Scholar', xp: 500 },
    30: { icon: '🏆', reward: 'Monthly Master', xp: 1000 },
    100: { icon: '👑', reward: 'Century Sage', xp: 5000 },
    365: { icon: '⭐', reward: 'Yearly Legend', xp: 10000 }
  },
  TUTORS: {
    socratic: {
      name: 'Socratic Guide',
      icon: '🤔',
      style: 'questions',
      prompt: 'Guide through questions only. Never give direct answers.',
      color: '#8b5cf6'
    },
    professor: {
      name: 'The Professor',
      icon: '👨‍🏫',
      style: 'academic',
      prompt: 'Provide detailed, academic, and structured lectures with formal definitions.',
      color: '#ef4444'
    },
    professor_clarity: {
      name: 'Professor Clarity',
      icon: '🎓',
      style: 'master_educator',
      prompt: 'TEACH, do not just read. Transform every fact into a living explanation with analogies, stories, and question-first triggers. Deliver with perfectly synchronised typing/speaking/scrolling markers ([Type: ...], [Scroll: ...], [Draw: ...], [Pause: ...]), clean natural speech without symbol names or filler words, silent board writing transitions, and 10-phase structured lecture delivery with all 6 Core Features.',
      color: '#6366f1'
    },
    peer: {
      name: 'The Peer',
      icon: '👋',
      style: 'casual',
      prompt: 'Explain things like a friend using casual language and simple analogies.',
      color: '#22c55e'
    },
    direct: {
      name: 'Direct Instructor',
      icon: '📝',
      style: 'explanation',
      prompt: 'Provide clear, step-by-step explanations.',
      color: '#3b82f6'
    },
    visual: {
      name: 'Visual Learner Helper',
      icon: '🎨',
      style: 'diagrams',
      prompt: 'Use visual analogies and real-world examples.',
      color: '#10b981'
    },
    rigorous: {
      name: 'Mathematical Rigorist',
      icon: '🔬',
      style: 'proofs',
      prompt: 'Emphasize formal definitions and proofs.',
      color: '#f59e0b'
    },
    encouraging: {
      name: 'Encouraging Coach',
      icon: '🏆',
      style: 'encouraging',
      prompt: 'Be highly positive, encouraging, motivating, and provide energetic, celebratory feedback to empower the learner.',
      color: '#ec4899'
    }
  },
  CURRICULA: {
    'CBSE-10': {
      name: 'CBSE Class 10',
      country: 'India',
      topics: [
        { id: 'real_numbers', name: 'Real Numbers', prerequisites: [] },
        { id: 'polynomials', name: 'Polynomials', prerequisites: ['real_numbers'] },
        { id: 'linear_equations', name: 'Linear Equations', prerequisites: ['polynomials'] },
        { id: 'quadratic_equations', name: 'Quadratic Equations', prerequisites: ['polynomials'] },
        { id: 'triangles', name: 'Triangles', prerequisites: [] },
        { id: 'trigonometry_intro', name: 'Trigonometry', prerequisites: ['triangles'] }
      ],
      sequence: ['real_numbers', 'polynomials', 'linear_equations', 'quadratic_equations', 'triangles', 'trigonometry_intro']
    },
    'CBSE-12': {
      name: 'CBSE Class 12',
      country: 'India',
      topics: [
        { id: 'relations_functions', name: 'Relations and Functions', prerequisites: [] },
        { id: 'inverse_trig', name: 'Inverse Trigonometric Functions', prerequisites: ['relations_functions'] },
        { id: 'matrices', name: 'Matrices', prerequisites: [] },
        { id: 'determinants', name: 'Determinants', prerequisites: ['matrices'] },
        { id: 'calculus_continuity', name: 'Continuity and Differentiability', prerequisites: ['relations_functions'] },
        { id: 'applications_derivatives', name: 'Applications of Derivatives', prerequisites: ['calculus_continuity'] },
        { id: 'integrals', name: 'Integrals', prerequisites: ['calculus_continuity'] },
        { id: 'applications_integrals', name: 'Applications of Integrals', prerequisites: ['integrals'] },
        { id: 'differential_equations', name: 'Differential Equations', prerequisites: ['integrals'] },
        { id: 'vectors', name: 'Vectors', prerequisites: [] },
        { id: 'three_dimensional_geometry', name: 'Three Dimensional Geometry', prerequisites: ['vectors'] },
        { id: 'linear_programming', name: 'Linear Programming', prerequisites: [] },
        { id: 'probability', name: 'Probability', prerequisites: [] }
      ],
      sequence: ['relations_functions', 'inverse_trig', 'matrices', 'determinants', 'calculus_continuity', 'applications_derivatives', 'integrals', 'applications_integrals', 'differential_equations', 'vectors', 'three_dimensional_geometry', 'linear_programming', 'probability']
    },
    'IB-SL': {
      name: 'IB Mathematics SL',
      country: 'International',
      topics: [
        { id: 'algebra_basics', name: 'Algebra', prerequisites: [] },
        { id: 'functions', name: 'Functions', prerequisites: ['algebra_basics'] },
        { id: 'trig', name: 'Trigonometry', prerequisites: ['algebra_basics'] },
        { id: 'vectors', name: 'Vectors', prerequisites: ['algebra_basics'] },
        { id: 'stats_probability', name: 'Statistics & Probability', prerequisites: [] },
        { id: 'calculus_intro', name: 'Calculus', prerequisites: ['functions', 'trig'] }
      ],
      sequence: ['algebra_basics', 'functions', 'trig', 'vectors', 'stats_probability', 'calculus_intro']
    },
    'AP-Calculus': {
      name: 'AP Calculus AB/BC',
      country: 'USA',
      topics: [
        { id: 'limits', name: 'Limits and Continuity', prerequisites: [] },
        { id: 'derivatives', name: 'Differentiation', prerequisites: ['limits'] },
        { id: 'applications_derivatives', name: 'Applications of Differentiation', prerequisites: ['derivatives'] },
        { id: 'integrals', name: 'Integration', prerequisites: ['derivatives'] },
        { id: 'applications_integrals', name: 'Applications of Integration', prerequisites: ['integrals'] },
        { id: 'series_bc', name: 'Infinite Series (BC only)', prerequisites: ['integrals'] }
      ],
      sequence: ['limits', 'derivatives', 'applications_derivatives', 'integrals', 'applications_integrals', 'series_bc']
    },
    'GCSE': {
      name: 'GCSE Mathematics',
      country: 'UK',
      topics: [
        { id: 'number', name: 'Number', prerequisites: [] },
        { id: 'algebra_gcse', name: 'Algebra', prerequisites: ['number'] },
        { id: 'ratio_proportion', name: 'Ratio & Proportion', prerequisites: ['number'] },
        { id: 'geometry_measures', name: 'Geometry & Measures', prerequisites: [] },
        { id: 'probability_stats', name: 'Probability & Statistics', prerequisites: ['number'] }
      ],
      sequence: ['number', 'algebra_gcse', 'ratio_proportion', 'geometry_measures', 'probability_stats']
    },
    'A-Level': {
      name: 'A-Level Mathematics',
      country: 'UK',
      topics: [
        { id: 'proof', name: 'Proof', prerequisites: [] },
        { id: 'algebra_functions', name: 'Algebra & Functions', prerequisites: [] },
        { id: 'coordinate_geometry', name: 'Coordinate Geometry', prerequisites: ['algebra_functions'] },
        { id: 'sequences_series', name: 'Sequences & Series', prerequisites: ['algebra_functions'] },
        { id: 'trig_a_level', name: 'Trigonometry', prerequisites: [] },
        { id: 'exponentials_logs', name: 'Exponentials & Logarithms', prerequisites: ['algebra_functions'] },
        { id: 'differentiation', name: 'Differentiation', prerequisites: ['algebra_functions'] },
        { id: 'integration', name: 'Integration', prerequisites: ['differentiation'] }
      ],
      sequence: ['proof', 'algebra_functions', 'coordinate_geometry', 'sequences_series', 'trig_a_level', 'exponentials_logs', 'differentiation', 'integration']
    }
  },
  VIDEO_PLATFORMS: {
    khanAcademy: { name: 'Khan Academy', url: 'https://www.khanacademy.org', icon: '🎓', region: 'Global', hasApi: false },
    youtube: { name: 'YouTube EDU', url: 'https://www.youtube.com/education', icon: '📺', region: 'Global', hasApi: true, apiUrl: 'https://www.googleapis.com/youtube/v3/search' },
    coursera: { name: 'Coursera', url: 'https://www.coursera.org', icon: '🎓', region: 'Global', hasApi: true, apiUrl: 'https://api.coursera.org/api/courses.v1' },
    edx: { name: 'edX', url: 'https://www.edx.org', icon: '🎓', region: 'Global', hasApi: true, apiUrl: 'https://courses.edx.org/api/v1/courses/' },
    mitOcw: { name: 'MIT OCW', url: 'https://ocw.mit.edu', icon: '🏛️', region: 'USA', hasApi: false },
    nptel: { name: 'NPTEL', url: 'https://nptel.ac.in', icon: '🇮🇳', region: 'India', hasApi: true, apiUrl: 'https://api.nptelprep.in/courses' },
    swayam: { name: 'SWAYAM', url: 'https://swayam.gov.in', icon: '🇮🇳', region: 'India', hasApi: false },
    bilibili: { name: 'Bilibili Learning', url: 'https://www.bilibili.com', icon: '📺', region: 'China', hasApi: true, apiUrl: 'https://api.bilibili.com/x/web-interface/' },
    freecodecamp: { name: 'freeCodeCamp', url: 'https://www.freecodecamp.org', icon: '💻', region: 'Global', hasApi: true, apiUrl: 'https://api.freecodecamp.org/graphql' },
    tedEd: { name: 'TED-Ed', url: 'https://ed.ted.com', icon: '💡', region: 'Global', hasApi: false },
    alison: { name: 'Alison', url: 'https://alison.com', icon: '📚', region: 'Ireland', hasApi: false },
    futureLearn: { name: 'FutureLearn', url: 'https://www.futurelearn.com', icon: '🎓', region: 'UK', hasApi: false },
    openClassrooms: { name: 'OpenClassrooms', url: 'https://openclassrooms.com', icon: '🎓', region: 'France', hasApi: false },
    diksha: { name: 'DIKSHA', url: 'https://diksha.gov.in', icon: '🇮🇳', region: 'India', hasApi: false },
    xuetangX: { name: 'XuetangX', url: 'https://www.xuetangx.com', icon: '🇨🇳', region: 'China', hasApi: false },
    icourses: { name: 'iCourse', url: 'https://www.icourses.cn', icon: '🇨🇳', region: 'China', hasApi: false },
    ebs: { name: 'EBS', url: 'https://www.ebs.co.kr', icon: '🇰🇷', region: 'South Korea', hasApi: false },
    kmooc: { name: 'K-MOOC', url: 'https://www.kmooc.kr', icon: '🇰🇷', region: 'South Korea', hasApi: false },
    fun: { name: 'FUN MOOC', url: 'https://www.fun-mooc.fr', icon: '🇫🇷', region: 'France', hasApi: false },
    eduopen: { name: 'EduOpen', url: 'https://www.eduopen.org', icon: '🇮🇹', region: 'Italy', hasApi: false },
    federica: { name: 'Federica', url: 'https://www.federica.eu', icon: '🇮🇹', region: 'Italy', hasApi: false },
    miriadax: { name: 'Miríadax', url: 'https://miriadax.net', icon: '🇪🇸', region: 'Spain', hasApi: false },
    nau: { name: 'NAU', url: 'https://nau.edu.pt', icon: '🇵🇹', region: 'Portugal', hasApi: false },
    openHPI: { name: 'openHPI', url: 'https://open.hpi.de', icon: '🇩🇪', region: 'Germany', hasApi: false },
    moocFi: { name: 'MOOC.fi', url: 'https://mooc.fi', icon: '🇫🇮', region: 'Finland', hasApi: false },
    openEducation: { name: 'Open Education', url: 'https://openedu.ru', icon: '🇷🇺', region: 'Russia', hasApi: false },
    prometheus: { name: 'Prometheus', url: 'https://prometheus.org.ua', icon: '🇺🇦', region: 'Ukraine', hasApi: false },
    mexicoX: { name: 'MéxicoX', url: 'https://mexicox.gob.mx', icon: '🇲🇽', region: 'Mexico', hasApi: false },
    crea: { name: 'CREA', url: 'https://crea.siemens-stiftung.org', icon: '🌎', region: 'Latin America', hasApi: false },
    eneza: { name: 'Eneza Education', url: 'https://enezaeducation.com', icon: '🇰🇪', region: 'Kenya', hasApi: false },
    telkomLearn: { name: 'TelkomLearn', url: 'https://telkomlearn.co.za', icon: '🇿🇦', region: 'South Africa', hasApi: false },
    ujMoocs: { name: 'UJ MOOCs', url: 'https://moocs.uj.ac.za', icon: '🇿🇦', region: 'South Africa', hasApi: false },
    edraak: { name: 'Edraak', url: 'https://www.edraak.org', icon: '🇯🇴', region: 'Jordan', hasApi: false },
    madrasa: { name: 'Madrasa', url: 'https://madrasa.ae', icon: '🇦🇪', region: 'UAE', hasApi: false },
    jmooc: { name: 'JMOOC', url: 'https://www.jmooc.jp', icon: '🇯🇵', region: 'Japan', hasApi: false },
    gacco: { name: 'gacco', url: 'https://gacco.org', icon: '🇯🇵', region: 'Japan', hasApi: false },
    thaimooc: { name: 'ThaiMOOC', url: 'https://www.thaimooc.org', icon: '🇹🇭', region: 'Thailand', hasApi: false },
    openLearning: { name: 'OpenLearning', url: 'https://www.openlearning.com', icon: '🇦🇺', region: 'Australia', hasApi: false },
    utas: { name: 'UTas MOOCs', url: 'https://moocs.utas.edu.au', icon: '🇦🇺', region: 'Australia', hasApi: false },
    odinProject: { name: 'The Odin Project', url: 'https://www.theodinproject.com', icon: '💻', region: 'Global', hasApi: false },
    duolingo: { name: 'Duolingo', url: 'https://www.duolingo.com', icon: '🦉', region: 'Global', hasApi: false },
    saylor: { name: 'Saylor Academy', url: 'https://www.saylor.org', icon: '📚', region: 'USA', hasApi: false },
    universarium: { name: 'Universarium', url: 'https://universarium.org', icon: '🇷🇺', region: 'Russia', hasApi: false },
    campusIl: { name: 'Campus-IL', url: 'https://campus.gov.il', icon: '🇮🇱', region: 'Israel', hasApi: false },
    yaklass: { name: 'Yaklass', url: 'https://www.yaklass.ru', icon: '🇷🇺', region: 'Russia', hasApi: false },
    stepik: { name: 'Stepik', url: 'https://stepik.org', icon: '🇷🇺', region: 'Russia', hasApi: false },
    academicEarth: { name: 'Academic Earth', url: 'https://academicearth.org', icon: '🎓', region: 'USA', hasApi: false }
  }
};

export const DIFFICULTY_NAMES: Record<string, string> = {
  kinder: '🎈 Kindergarten',
  elementary: '📚 Elementary',
  middle: '🏫 Middle School',
  high: '🎓 High School',
  college: '🏛️ College',
  graduate: '📖 Graduate',
  phd: '🔬 PhD',
  ai_research: '🤖 AI Research'
};

export const TOPIC_ICONS: Record<string, string> = {
  arithmetic: '🔢', algebra: 'x²', geometry: '📐', calculus: '∫',
  linear_algebra: '🧮', number_theory: '🔢', probability_statistics: '📊',
  discrete_mathematics: '🕸️', trigonometry: '📐', differential_equations: '📈',
  real_analysis: 'ℝ', complex_analysis: 'ℂ', topology: '🌀',
  abstract_algebra: '🧩', numerical_methods: '💻', optimization: '📉',
  combinatorics: '🔀', graph_theory: '🕸️', set_theory: '📦', logic: '🧠',
  category_theory: '🏹', fractal_geometry: '❄️', chaos_theory: '🌪️',
  cryptography: '🔐', game_theory_math: '♟️',
  '1. Relations and Functions': '🔗',
  '2. Inverse Trigonometric Functions - Definition, domain, range, principal value branch, Graphs, Elementary properties': '📐',
  '3. Matrices': '🧮',
  '4. Determinants': '🔢',
  '1. Electric Charges and Field': '⚡',
  "2. Gauss' Theorem": '📐',
  "3. Electric Potential": '🔋',
  "4. Capacitors and Dielectrics": '⚡',
  "5. Electric Resistance and Ohm's Law": '🔌',
  "6. DC Circuits and Measurements": '🎛️',
  "7. Moving Charges and Magnetic Field": '🧲',
  "8. Torque on a Current-Loop : Moving-Coil Galvanometer": '🔄',
  "9. Magnetic Field and Earth's Magnetism": '🌍',
  "10. Magnetic Classification of Substances": '🔬',
  "11. Electromagnetic Induction": '⚡',
  "12. Alternating Current": '〰️',
  "13. Electromagnetic Waves": '📡',
  "14. Ray Optics and Optical Instruments": '👓',
  "15. Wave Optics": '🌊',
  "16. Dual Nature of Radiation and Matter": '☀️',
  "17. Atoms": '⚛️',
  "18. Nuclei": '☢️',
  "19. Semiconductor Electronics": '💻',
  "20. Communication Systems": '📡',
  "21. Reflection of Light : Spherical Mirrors": '🪞',
  "22. Refraction of Light at a Plane Interface : Total Internal Reflection : Optical Fiber": '🔍',
  "23. Refraction of Light at Spherical Surfaces : Lenses": '🔎',
  "24. Refraction and Dispersion of Light through a Prism": '🌈',
  "25. Optical Instruments": '🔭',
  "26. Wave Nature of Light : Huygens' Principle": '🌊',
  "27. Interference of Light": '✨',
  "28. Diffraction of Light": '🌀',
  "29. Polarization of Light": '🕶️',
  "30. Photoelectric Effect": '☀️',
  "31. Matter Waves": '⚛️',
  "32. X-Rays": '🩻',
  "33. Atom, Origin of Spectra : Bohr's Theory of Hydrogen Atom": '🔬',
  "34. Nuclear Structure": '☢️',
  "35. Radioactivity": '☣️',
  "36. Mass-Energy Equivalence : Nuclear Binding Energy": '⚡',
  "37. Nuclear Fission and Fusion : Sources of Energy": '💥',
  "38. Semiconductor Electronics": '🔌',
  "39. Semiconductor Diodes": '⚡',
  "40. Junction Transistors": '🎛️',
  "41. Logic Gates": '🧠',
  "42. Communication Systems": '📡',
  "1. Sexual Reproduction in Flowering Plants": '🌸',
  "2. Human Reproduction": '👪',
  "3. Reproductive Health": '🏥',
  "4. Principles of Inheritance and Variation": '🧬',
  "5. Molecular Basis of Inheritance": '🔬',
  "6. Evolution": '🐒',
  "7. Human Health and Disease": '💊',
  "8. Microbes in Human Welfare": '🦠',
  "9. Biotechnology: Principles and Processes": '🧬',
  "10. Biotechnology and its Applications": '🧪',
  "11. Organisms and Populations": '🌳',
  "12. Ecosystem": '🌍',
  "13. Biodiversity and Conservation": '🦁',
  "1. Computational Thinking and Programming - 2": '🐍',
  "2. Computer Networks": '🌐',
  "3. Database Management": '🗄️',
  "4. Data Structures": '📚',
  "5. Societal Impacts": '⚖️',
  "1. Bricks, Beads and Bones": '🏺',
  "2. Kings, Farmers and Towns": '👑',
  "3. Kinship, Caste and Class": '👥',
  "4. Thinkers, Beliefs and Buildings": '☸️',
  "5. Through the Eyes of Travellers": '🎒',
  "6. Bhakti-Sufi Traditions": '🕍',
  "7. An Imperial Capital: Vijayanagara": '🏰',
  "8. Peasants, Zamindars and the State": '🌾',
  "10. Colonialism and the Countryside": '📜',
  "11. Rebels and the Raj": '⚔️',
  "12. Mahatma Gandhi and the Nationalist Movement": '🇮🇳',
  "13. Framing the Constitution": '📖',
  "1. Human Geography: Nature and Scope": '🧠',
  "2. The World Population": '👥',
  "3. Human Development": '📈',
  "4. Primary Activities": '🚜',
  "5. Secondary Activities": '🏭',
  "6. Tertiary and Quaternary Activities": '📡',
  "7. Transport and Communication": '🚆',
  "8. International Trade": '🚢',
  "9. Human Settlements": '🏘️',
  "1. The End of Bipolarity": '🧱',
  "2. Contemporary Centres of Power": '🏢',
  "3. Contemporary South Asia": '🌏',
  "4. International Organizations": '🇺🇳',
  "5. Security in the Contemporary World": '🛡️',
  "6. Environment and Natural Resources": '🌿',
  "7. Globalization": '🌍',
  "8. Challenges of Nation-Building": '🏗️',
  "9. Era of One-Party Dominance": '🐘',
  "10. Politics of Planned Development": '📊',
  "11. India's External Relations": '🤝',
  "12. The Crisis of Democratic Order": '⚖️',
  "13. Recent Developments in Indian Politics": '🗳️',
  "1. Demographic Structure of Indian Society": '👥',
  "2. Social Institutions: Continuity and Change": '🏠',
  "3. Patterns of Social Inequality and Exclusion": '🧱',
  "4. The Challenges of Cultural Diversity": '🌈',
  "5. Structural Change": '🏗️',
  "6. Cultural Change": '🎭',
  "7. Change and Development in Rural Society": '🌾',
  "8. Change and Development in Industrial Society": '🏭',
  "9. Social Movements": '📢',
  "1. Variations in Psychological Attributes": '🧠',
  "2. Self and Personality": '👤',
  "3. Meeting Life Challenges": '💪',
  "4. Psychological Disorders": '🩺',
  "5. Therapeutic Approaches": '🛋️',
  "6. Attitude and Social Cognition": '💭',
  "7. Social Influence and Group Processes": '👥',
  "1. Introduction to Macroeconomics": '📊',
  "2. National Income Accounting": '💰',
  "3. Money and Banking": '🏦',
  "4. Determination of Income and Employment": '📈',
  "5. Government Budget and the Economy": '📜',
  "6. Balance of Payments": '⚖️',
  "7. Indian Economy on the Eve of Independence": '🕰️',
  "8. Indian Economy 1950-1990": '🏗️',
  "9. Liberalisation, Privatisation and Globalisation": '🔓',
  "10. Human Capital Formation in India": '🎓',
  "11. Rural Development": '🌾',
  "12. Employment: Growth, Informalisation and Other Issues": '👷',
  "13. Sustainable Economic Development": '🌱',
  "14. Development Experience of India: A Comparison with Neighbours": '🤝',
  "1. Intelligence and Ability": '🧠',
  "2. Personality": '👤',
  "3. Lifespan Development": '📈',
  "4. Stress and Health": '💪',
  "5. Psychological Disorders and Psychotherapy": '🩺',
  "6. Social Thought and Social Behaviour": '👥',
  "7. Attitude and Social Influence": '💭',
  "1. Solid State": '🧊',
  "2. Solutions": '🧪',
  "3. Electrochemistry": '⚡',
  "4. Chemical Kinetics": '⏱️',
  "5. Surface Chemistry": '🧼',
  "6. General Principles and Processes of Isolation of Elements": '⚗️',
  "7. p-Block Elements (Groups 15 to 18)": '🔬',
  "8. d- and f-Block Elements": '🧲',
  "9. Coordination Compounds": '⚛️',
  "10. Haloalkanes and Haloarenes": '🧬',
  "11. Alcohols, Phenols and Ethers": '🍾',
  "12. Aldehydes, Ketones and Carboxylic Acids": '🧪',
  "13. Organic Compounds Containing Nitrogen (Amines)": '🧫',
  "14. Biomolecules": '🧬',
  "15. Polymers": '🧵',
  "16. Chemistry in Everyday Life": '💊',
  "Appendix: Chemistry Appendices": '📑',
  mechanics: '⚙️', thermodynamics: '🔥', electromagnetism: '⚡', optics: '👓',
  quantum_mechanics: '⚛️', relativity: '🌌', particle_physics: '🔬',
  astrophysics: '🔭', condensed_matter: '💎', nuclear_physics: '☢️',
  fluid_dynamics: '🌊', plasma_physics: '✨', acoustics: '🔊',
  biophysics: '🧬', geophysics: '🌍', string_theory: '🎻',
  quantum_field_theory: '🌫️', cosmology: '🎆', statistical_mechanics: '🎲',
  organic_chemistry: '🧪', inorganic_chemistry: '⚗️', physical_chemistry: '🌡️',
  analytical_chemistry: '🔍', biochemistry: '🧬', theoretical_chemistry: '💻',
  environmental_chemistry: '🌱', materials_science: '🏗️', polymer_chemistry: '🔗',
  medicinal_chemistry: '💊', thermochemistry: '🔥', electrochemistry: '🔋',
  spectroscopy: '🌈', quantum_chemistry: '⚛️', nanochemistry: '🔬',
  genetics: '🧬', evolution: '🐒', ecology: '🌳', cell_biology: '🧫',
  molecular_biology: '🔬', physiology: '💪', anatomy: '🦴',
  microbiology: '🦠', botany: '🌿', zoology: '🦁',
  marine_biology: '🐬', neurobiology: '🧠', immunology: '🛡️',
  biotechnology: '🧬', paleontology: '🦖', virology: '🦠',
  mycology: '🍄', entomology: '🐞', bioinformatics: '💻',
  algorithms: '💻', data_structures: '🏗️', operating_systems: '🖥️',
  networks: '🌐', databases: '🗄️', software_engineering: '🛠️',
  artificial_intelligence: '🤖', machine_learning: '📈', cybersecurity: '🛡️',
  graphics: '🖼️', cloud_computing: '☁️', distributed_systems: '🔗',
  human_computer_interaction: '🖱️', compilers: '⚙️', computer_architecture: '💾',
  blockchain: '⛓️', quantum_computing: '⚛️', internet_of_things: '🏠',
  ancient_history: '🏛️', medieval_history: '🏰', modern_history: '🏙️',
  world_war_i: '🎖️', world_war_ii: '🎖️', cold_war: '❄️',
  renaissance: '🎨', industrial_revolution: '🏭', colonialism: '🚢',
  civil_rights: '✊', american_history: '🇺🇸', european_history: '🇪🇺',
  asian_history: '🌏', african_history: '🌍', latin_american_history: '🌎',
  history_of_science: '🔬', economic_history: '💰', art_history_context: '🖼️',
  physical_geography: '🏔️', human_geography: '🏘️', cartography: '🗺️',
  climatology: '🌦️', geomorphology: '⛰️', economic_geography: '💰',
  political_geography: '🗳️', environmental_geography: '🌍', urban_geography: '🏙️',
  population_geography: '👥', gis_remote_sensing: '🛰️', hydrology: '💧',
  biogeography: '🐾', oceanography: '🌊',
  poetry: '📜', drama: '🎭', fiction: '📖', non_fiction: '📰',
  literary_criticism: '🔍', comparative_literature: '📚', creative_writing: '✍️',
  classics: '🏛️', renaissance_literature: '🖋️', romanticism: '🌹',
  modernism: '🏙️', post_modernism: '🧩', world_literature: '🌍',
  shakespearian_studies: '🎭', mythology: '⚡',
  linguistics: '🗣️', phonetics: '👄', syntax: '🏗️', semantics: '📖',
  pragmatics: '💬', english: '🇬🇧', spanish: '🇪🇸', french: '🇫🇷',
  german: '🇩🇪', chinese: '🇨🇳', japanese: '🇯🇵', italian: '🇮🇹',
  russian: '🇷🇺', arabic: '🇸🇦', portuguese: '🇵🇹', language_acquisition: '👶',
  sociolinguistics: '👥', historical_linguistics: '📜',
  microeconomics: '📉', macroeconomics: '📈', econometrics: '📊',
  game_theory: '♟️', behavioral_economics: '🧠', development_economics: '🌱',
  international_trade: '🚢', labor_economics: '👷', public_finance: '🏦',
  monetary_economics: '💵', financial_economics: '💰', environmental_economics: '🌍',
  economic_growth: '🚀',
  cognitive_psychology: '🧠', developmental_psychology: '👶', social_psychology: '👥',
  clinical_psychology: '🛋️', neuropsychology: '🧠', behavioral_psychology: '🐕',
  educational_psychology: '🏫', forensic_psychology: '⚖️', industrial_organizational: '🏢',
  personality_psychology: '👤', abnormal_psychology: '🌀', positive_psychology: '☀️',
  ethics: '⚖️', metaphysics: '✨', epistemology: '🔍', logic_phil: '🧠',
  political_philosophy: '🗳️', aesthetics: '🎨', existentialism: '👤',
  phenomenology: '👁️', philosophy_of_mind: '🧠', philosophy_of_science: '🔬',
  ancient_philosophy: '🏛️', modern_philosophy: '💡', eastern_philosophy: '☯️',
  stoicism: '🗿',
  art_history: '🖼️', painting: '🎨', sculpture: '🗿', photography: '📷',
  digital_art: '💻', architecture: '🏛️', design: '📐', fine_arts: '🎭',
  graphic_design: '🖋️', fashion_design: '👗', interior_design: '🛋️',
  animation: '🎞️', cinematography: '🎥', printmaking: '🖼️', ceramics: '🏺',
  music_theory: '🎼', composition: '🎹', music_history: '📜',
  ethnomusicology: '🌍', performance: '🎻', jazz: '🎷', classical: '🎻',
  electronic_music: '🎛️', music_production: '🎧', orchestration: '🎺',
  conducting: '🪄', music_therapy: '🧘', acoustics_music: '🔊', film_scoring: '🎬',
  origin_dev_sociology_anthropology: '📘', research_methodology_sociology: '🗽',
  basic_concepts_society_culture: '🌐', social_structure_groups_processes: '🏗️',
  social_problems_deviance: '⚠️', indian_sociologists_thinkers: '🇮🇳', practical_sociological_research: '📝',
  social_theory: '📖', social_stratification: '🪜', urban_sociology: '🏙️',
  rural_sociology: '🚜', sociology_of_education: '🏫', sociology_of_religion: '⛪',
  gender_studies: '⚧️', race_and_ethnicity: '🌍', criminology: '🔍',
  demography: '📊', social_movements: '📢',
  international_relations: '🌐', comparative_politics: '🗳️', political_theory: '📖',
  public_policy: '📜', public_administration: '🏢', political_economy: '💰',
  geopolitics: '🌍', human_rights: '⚖️', diplomacy: '🤝', electoral_systems: '🗳️',
  internal_medicine: '🩺', surgery: '🔪', pediatrics: '👶',
  obstetrics_gynecology: '🤰', psychiatry: '🧠', neurology: '🧠',
  cardiology: '❤️', oncology: '🎗️', radiology: '🩻', pathology: '🔬',
  pharmacology: '💊', epidemiology: '📊', public_health: '🌍',
  genetics_medicine: '🧬',
  mechanical_engineering: '⚙️', civil_engineering: '🏗️', electrical_engineering: '⚡',
  chemical_engineering: '🧪', aerospace_engineering: '🚀', biomedical_engineering: '🧬',
  environmental_engineering: '🌱', software_engineering_tech: '💻',
  robotics_engineering: '🤖', materials_engineering: '🏗️', structural_engineering: '🏢',
  constitutional_law: '📜', criminal_law: '⚖️', civil_law: '⚖️',
  international_law: '🌐', corporate_law: '💼', intellectual_property: '💡',
  environmental_law: '🌳', human_rights_law: '⚖️', family_law: '🏠',
  administrative_law: '🏢', tort_law: '⚖️',
  marketing: '📢', finance: '💰', accounting: '📊', management: '💼',
  entrepreneurship: '🚀', human_resources: '👥', operations_management: '⚙️',
  supply_chain: '🚚', business_analytics: '📈', international_business: '🌐',
  organizational_behavior: '👥',
  neural_networks: '🧠', transformers: '🤖', reinforcement_learning: '🎮',
  computer_vision: '👁️', natural_language_processing: '🗣️', generative_models: '🎨',
  robotics: '🤖', ethics_in_ai: '⚖️', explainable_ai: '🔍', ai_safety: '🛡️',
  large_language_models: '📚', automated_reasoning: '🧠', multi_agent_systems: '👥',
  knowledge_representation: '🕸️',
  fluid_mechanics: '🌊', solid_mechanics: '🧱', kinematics: '⚙️', manufacturing: '🏭',
  heat_transfer: '🌡️', machine_design: '📐',
  geotechnical_engineering: '🌍', transportation_engineering: '🚗',
  water_resources: '💧', construction_management: '🏢', surveying: '🔭',
  circuit_theory: '🔌', electromagnetics: '⚡', control_systems: '🎛️', power_systems: '🔋',
  microelectronics: '💻', signal_processing: '📡', telecommunications: '📞', digital_logic: '0️⃣',
  process_design: '📐', transport_phenomena: '🌊', chemical_kinetics: '⏱️', thermodynamics_chem: '🔥',
  polymer_engineering: '🔗', biochemical_engineering: '🧫', process_control: '🎛️',
  aerodynamics: '💨', propulsion: '🚀', orbital_mechanics: '🪐', flight_dynamics: '✈️',
  avionics: '🎛️', spacecraft_design: '🛰️', aircraft_structures: '✈️', materials_aerospace: '🛡️',
  biomechanics: '🏃', biomaterials: '🦴', medical_imaging: '🩻',
  tissue_engineering: '🧫', neural_engineering: '🧠', clinical_engineering: '🏥', biosensors: '🧬',
  general_knowledge: '🌍', current_affairs: '📰', hobbies: '🎨', travel: '✈️', food: '🍕',
  lifestyle: '🏠', technology_news: '📱', entertainment: '🎬', sports: '⚽', miscellaneous: '🧩'
};

export const SUBJECT_ICONS: Record<string, string> = {
  mathematics: '🔢', physics: '⚛️', chemistry: '🧪',
  biology: '🧬', computer_science: '💻', history: '📜',
  geography: '🌍', literature: '📚', languages: '🗣️',
  economics: '📈', psychology: '🧠', philosophy: '⚖️',
  art: '🎨', music: '🎵', sociology: '👥',
  political_science: '🗳️', medicine: '🏥',
  mechanical_engineering: '⚙️', civil_engineering: '🏗️', electrical_engineering: '⚡',
  chemical_engineering: '⚗️', aerospace_engineering: '🚀', biomedical_engineering: '🧬',
  law: '⚖️', business: '💼', ai_research: '🤖',
  english: '🇬🇧', social_science: '👥', history_geography: '🗺️', environmental_science: '🌱',
  astronomy: '🌌', geology: '🪨', accounting: '🏦', business_studies: '👔', civics: '🏛️',
  biotechnology: '🧬', cybersecurity: '🔒', journalism_media: '📻', statistics: '📊',
  home_science: '🍳', physical_education: '🏃', other: '✨'
};

export const LANGUAGES = [
  { code: 'en', name: 'English', native: 'English', flag: '🇺🇸' },
  { code: 'hi', name: 'Hindi', native: 'हिन्दी', flag: '🇮🇳' },
  { code: 'hinglish', name: 'Hinglish', native: 'हिंग्लिश', flag: '🇮🇳' },
  { code: 'ur', name: 'Urdu', native: 'اردو', flag: '🇵🇰' },
  { code: 'bn', name: 'Bengali', native: 'বাংলা', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', native: 'मराठी', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', native: 'తెలుగు', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்', flag: '🇮🇳' },
  { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી', flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ', flag: '🇮🇳' },
  { code: 'ml', name: 'Malayalam', native: 'മലയാളം', flag: '🇮🇳' },
  { code: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
  { code: 'or', name: 'Odia', native: 'ଓଡ଼ିଆ', flag: '🇮🇳' },
  { code: 'as', name: 'Assamese', native: 'অসমীয়া', flag: '🇮🇳' },
  { code: 'ma', name: 'Maithili', native: 'मैथिली', flag: '🇮🇳' },
  { code: 'bho', name: 'Bhojpuri', native: 'भोजपुरी', flag: '🇮🇳' },
  { code: 'sa', name: 'Sanskrit', native: 'संस्कृतम्', flag: '🇮🇳' },
  { code: 'ne', name: 'Nepali', native: 'नेपाली', flag: '🇳🇵' },
  { code: 'es', name: 'Spanish', native: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'French', native: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'German', native: 'Deutsch', flag: '🇩🇪' },
  { code: 'zh', name: 'Chinese', native: '中文', flag: '🇨🇳' },
  { code: 'ar', name: 'Arabic', native: 'العربية', flag: '🇸🇦' },
  { code: 'ru', name: 'Russian', native: 'Русский', flag: '🇷🇺' },
  { code: 'pt', name: 'Portuguese', native: 'Português', flag: '🇵🇹' },
  { code: 'ja', name: 'Japanese', native: '日本語', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', native: '한국어', flag: '🇰🇷' },
  { code: 'it', name: 'Italian', native: 'Italiano', flag: '🇮🇹' },
  { code: 'nl', name: 'Dutch', native: 'Nederlands', flag: '🇳🇱' },
  { code: 'tr', name: 'Turkish', native: 'Türkçe', flag: '🇹🇷' },
  { code: 'vi', name: 'Vietnamese', native: 'Tiếng Việt', flag: '🇻🇳' },
  { code: 'th', name: 'Thai', native: 'ไทย', flag: '🇹🇭' },
  { code: 'jv', name: 'Javanese', native: 'Basa Jawa', flag: '🇮🇩' }
];

export interface Persona {
  id: string;
  name: string;
  voiceName: string;
  accent: string;
  icon: string;
  description: string;
  textToneAdjustment: string;
}

export const PERSONAS: Persona[] = [
  {
    id: 'formal_professor',
    name: 'Formal Professor',
    voiceName: 'Puck',
    accent: 'British',
    icon: '👨‍🏫',
    description: 'Disciplined, academically dense, authoritative and objective lectures.',
    textToneAdjustment: 'You are an elite, highly precise university professor. Your explanations are formal, deeply academic, and avoid slang or conversational fillers.'
  },
  {
    id: 'encouraging_coach',
    name: 'Encouraging Coach',
    voiceName: 'Kore',
    accent: 'American',
    icon: '🏆',
    description: 'High energy, motivating, conversational, and championing tone.',
    textToneAdjustment: 'You are a lively, positive, and deeply encouraging sports/academic coach. Push the student with high energy, celebratory feedback, and bright enthusiasm.'
  },
  {
    id: 'minimalist_mentor',
    name: 'Minimalist Mentor',
    voiceName: 'Zephyr',
    accent: 'Australian',
    icon: '🧘',
    description: 'Calm, sparse, deeply precise, and focused entirely on the absolute essence.',
    textToneAdjustment: 'You are a minimalist zen scholar. Omit all decorative adjectives. Deliver only raw, highly concentrated wisdom and direct paths to the solution.'
  },
  {
    id: 'epic_storyteller',
    name: 'Epic Storyteller',
    voiceName: 'Fenrir',
    accent: 'Indian',
    icon: '⚔️',
    description: 'Epic narrative arcs, high-contrast allegories, and legendary framing.',
    textToneAdjustment: 'You are an epic bard or historical storyteller. Turn concepts into grand legends, dramatic quests, and cinematic cosmic transformations.'
  },
  {
    id: 'axiomatic_mind',
    name: 'Axiomatic Mind',
    voiceName: 'Charon',
    accent: 'Chinese',
    icon: '🏛️',
    description: 'Uncompromising logical definitions, complete mathematical rigor, and systematic axioms.',
    textToneAdjustment: 'You are an absolute mathematician and rigorous logician. Frame every learning point with strict axiomatic boundaries, formal proofs, and absolute deduction.'
  }
];

export const ELECTRIC_CHARGES_SUBTOPICS = [
  "Introduction",
  "1. Electric Charge",
  "2. Positive and Negative Charges",
  "3. Electron Theory of Electrification",
  "4. Conductors and Insulators",
  "5. Electrostatic Induction",
  "6. SI Unit of Electric Charge : Coulomb",
  "7. Three Important Properties of Electric Charge",
  "8. Coulomb's Law : Force between Two Point-Charges",
  "9. Coulomb's Law in Vector Form",
  "10. Forces between Multiple Charges : Superposition Principle",
  "11. Equilibrium of Charge and System of Charges",
  "12. Concept of Electric Field",
  "13. Intensity of Electric Field",
  "14. Electric Field Intensity due to a Point-charge",
  "15. Intensity of Electric Field due to a Continuous Charge Distribution",
  "16. Electric Lines of Force",
  "17. Electric Dipole : Electric Dipole Moment",
  "18. Electric Field due to an Electric Dipole",
  "19. Torque on a Dipole in a Uniform Electric Field",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const GAUSS_THEOREM_SUBTOPICS = [
  "Introduction & Area Vector",
  "1. Solid Angle",
  "2. Electric Flux (Definition & SI Unit)",
  "3. Gauss' Theorem (Statement & Mathematical Form)",
  "4. Proof of Gauss' Theorem for a Spherical Surface",
  "5. Deduction of Coulomb's Law from Gauss' Theorem",
  "6. Electric Field Intensity due to an Infinitely Long Straight Charged Wire",
  "7. Electric Field Intensity due to an Infinite Thin Plane Sheet of Charge",
  "8. Electric Field Intensity near a Charged Conducting Plate",
  "9. Electric Field Intensity due to Two Parallel Infinite Thin Plane Sheets of Charge",
  "10. Electric Field Intensity due to a Uniformly Charged Thin Spherical Shell (Inside, Surface, Outside)",
  "11. Electric Field Intensity due to a Uniformly Charged Solid Non-Conducting Sphere",
  "12. Mechanical Force on a Charged Conductor",
  "13. Energy Density of an Electric Field",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const ELECTRIC_POTENTIAL_SUBTOPICS = [
  "Introduction & Concept of Electric Potential",
  "1. Electric Potential & Potential Difference (Definition, Formula & SI Unit Volt)",
  "2. Electric Potential due to a Point Charge",
  "3. Electric Potential due to a Group of Point Charges",
  "4. Electric Potential due to an Electric Dipole (Axial & Equatorial Lines)",
  "5. Relation between Electric Field and Electric Potential (E = -dV/dr)",
  "6. Equipotential Surfaces & Their Properties",
  "7. Electric Potential Energy of a System of Point Charges",
  "8. Potential Energy of an Electric Dipole in a Uniform External Field",
  "9. Work Done in Rotating an Electric Dipole in an External Field",
  "10. Potential of a Charged Conductor & Corona Discharge",
  "11. Electron-Volt (eV) Unit of Energy",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const CAPACITORS_DIELECTRICS_SUBTOPICS = [
  "Introduction & Concept of Capacitance",
  "1. Electrical Capacitance of a Conductor (Definition & SI Unit Farad)",
  "2. Capacitance of an Isolated Spherical Conductor",
  "3. Principle of a Capacitor & Types of Capacitors",
  "4. Parallel Plate Capacitor & Its Capacitance Formula",
  "5. Effect of Dielectric Medium on Capacitance & Dielectric Constant (K)",
  "6. Capacitance of Parallel Plate Capacitor with Dielectric Slab",
  "7. Capacitance of Parallel Plate Capacitor with Conducting Slab",
  "8. Combination of Capacitors in Series and Parallel",
  "9. Energy Stored in a Charged Capacitor (U = 1/2 CV²)",
  "10. Energy Density of an Electric Field in a Capacitor",
  "11. Redistribution of Charge & Loss of Energy on Sharing Charges",
  "12. Polarization of Dielectrics & Dielectric Strength",
  "13. Van de Graaff Generator (Principle, Construction & Working)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const ELECTRIC_RESISTANCE_SUBTOPICS = [
  "Introduction & Concept of Electric Current",
  "1. Electric Current (Definition, Direction, Formula & SI Unit Ampere)",
  "2. Mechanism of Current Flow in Metallic Conductors & Free Electron Model",
  "3. Drift Velocity, Relaxation Time & Mean Free Path",
  "4. Relation between Electric Current and Drift Velocity (I = n e A v_d)",
  "5. Ohm's Law (Statement, Deduction & Mathematical Proof)",
  "6. Electrical Resistance (Definition, SI Unit Ohm & Dimensions)",
  "7. Factors Affecting Resistance & Specific Resistance (Resistivity ρ)",
  "8. Electrical Conductivity & Current Density (Vector Form j = σ E)",
  "9. Temperature Dependence of Resistance & Temperature Coefficient (α)",
  "10. Ohmic and Non-Ohmic Conductors & V-I Characteristics",
  "11. Carbon Resistors & Color Code System",
  "12. Thermistors & Superconductors (Transition Temperature)",
  "13. Internal Resistance of a Cell & Terminal Potential Difference",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const DC_CIRCUITS_SUBTOPICS = [
  "Introduction & Concept of DC Circuits",
  "1. Electric Energy and Electric Power (Formula, Units & Applications)",
  "2. Electromotive Force (EMF), Terminal Voltage and Internal Resistance of a Cell",
  "3. Combination of Cells in Series, Parallel and Mixed Grouping",
  "4. Kirchhoff's Laws (Kirchhoff's First Law/Junction Rule & Second Law/Loop Rule)",
  "5. Wheatstone Bridge Principle, Derivation & Sensitivity",
  "6. Meter Bridge (Slide Wire Bridge) & Determination of Unknown Resistance",
  "7. Potentiometer Principle, Construction, Calibration & Sensitivity",
  "8. Comparison of EMFs of Two Cells using Potentiometer",
  "9. Determination of Internal Resistance of a Cell using Potentiometer",
  "10. Post Office Box & Measurement of Resistance",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const MOVING_CHARGES_SUBTOPICS = [
  "Introduction & Concept of Magnetic Field",
  "1. Oersted's Experiment & Magnetic Field due to Electric Current",
  "2. Biot-Savart Law & Vector Form",
  "3. Magnetic Field at the Centre of a Circular Loop carrying Current",
  "4. Magnetic Field along the Axis of a Circular Current Loop",
  "5. Ampere's Circuital Law & Derivation",
  "6. Magnetic Field due to an Infinitely Long Straight Current-Carrying Conductor",
  "7. Magnetic Field inside a Straight Solenoid & Toroid",
  "8. Force on a Moving Charge in a Magnetic Field (Lorentz Magnetic Force F = q v B sin θ)",
  "9. Motion of a Charged Particle in a Uniform Magnetic Field (Helical Path & Cyclotron Frequency)",
  "10. Cyclotron (Principle, Construction, Working & Resonance Condition)",
  "11. Force on a Current-Carrying Conductor in a Uniform Magnetic Field (F = I L B sin θ)",
  "12. Force Between Two Parallel Current-Carrying Conductors & Definition of Ampere",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const TORQUE_CURRENT_LOOP_SUBTOPICS = [
  "Introduction & Concept of Torque on Current Loop",
  "1. Torque on a Rectangular Current-Carrying Loop in a Uniform Magnetic Field (τ = M B sin θ = N I A B sin θ)",
  "2. Magnetic Dipole Moment of a Current Loop (M = N I A)",
  "3. Magnetic Dipole Moment of a Revolving Electron (Bohr Magneton μ_b)",
  "4. Moving-Coil Galvanometer (Principle, Construction & Working)",
  "5. Radial Magnetic Field & Purpose of Soft Iron Core",
  "6. Current Sensitivity & Voltage Sensitivity of a Galvanometer",
  "7. Conversion of Galvanometer into an Ammeter (Shunt Resistance S)",
  "8. Conversion of Galvanometer into a Voltmeter (High Resistance R in Series)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const EARTH_MAGNETISM_SUBTOPICS = [
  "Introduction & Concept of Magnetic Field & Dipole",
  "1. Bar Magnet as a Magnetic Dipole & Magnetic Field Lines Properties",
  "2. Magnetic Dipole Moment of a Bar Magnet & Torque in Uniform Field (τ = M B sin θ)",
  "3. Magnetic Field of a Bar Magnet on Axial Line (End-on Position) & Equatorial Line (Broadside-on Position)",
  "4. Gauss's Law in Magnetism (∮ B · dA = 0)",
  "5. Terrestrial Magnetism & Earth's Magnetic Field Elements (Declination θ, Dip/Inclination δ, Horizontal Component H_e)",
  "6. Mathematical Relation between Elements of Earth's Magnetic Field (B_e = √(H_e² + V_e²), tan δ = V_e / H_e)",
  "7. Neutral Points & Determination of Earth's Magnetic Field Component",
  "8. Tangent Galvanometer & Tangent Law (I = K tan θ)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const MAGNETIC_SUBSTANCES_SUBTOPICS = [
  "Introduction & Magnetic Intensity H, Magnetization M & Magnetic Permeability μ",
  "1. Intensity of Magnetization (M = m/V) & Magnetic Field Intensity (H = B/μ₀ - M)",
  "2. Magnetic Susceptibility (χ = M/H) & Relation with Relative Permeability (μ_r = 1 + χ)",
  "3. Diamagnetic Substances (Definition, Electron Origin, Properties & Temperature Independence)",
  "4. Paramagnetic Substances (Definition, Atomic Dipole Origin, Properties & Curie's Law χ = C/T)",
  "5. Ferromagnetic Substances (Definition, Domain Theory, Weiss Molecular Field & Soft/Hard Iron)",
  "6. Effect of Temperature on Magnetism & Curie Temperature T_c (Curie-Weiss Law)",
  "7. Hysteresis Loop (B-H / I-H Curve, Residual Magnetism / Retentivity & Coercivity)",
  "8. Hysteresis Loss (Energy Dissipation per Cycle & Area of Hysteresis Loop)",
  "9. Choice of Magnetic Materials for Permanent Magnets, Electromagnets, Transformer Cores & Telephone Diaphragms",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const ELECTROMAGNETIC_INDUCTION_SUBTOPICS = [
  "Introduction & Magnetic Flux Φ = B · A cos θ",
  "1. Faraday's Experiments on Electromagnetic Induction",
  "2. Faraday's Laws of Electromagnetic Induction & Induced EMF (e = -dΦ/dt)",
  "3. Lenz's Law & Conservation of Energy",
  "4. Induced Current & Induced Charge (q = ΔΦ/R)",
  "5. Motional EMF in a Straight Conductor (e = B v l) & Rotating Rod (e = ½ B ω l²)",
  "6. Eddy Currents (Foucault Currents), Applications & Minimization",
  "7. Self-Induction, Self-Inductance L (e = -L dI/dt) & Inductance of Solenoid",
  "8. Mutual Induction, Mutual Inductance M (e₂ = -M dI₁/dt) & Inductance of Coaxial Solenoids",
  "9. Energy Stored in an Inductor (U = ½ L I²)",
  "10. Combination of Inductors (Series L = L₁ + L₂ ± 2M & Parallel)",
  "11. AC Generator / Dynamo (Principle, Working & Peak/Instantaneous EMF e = e₀ sin ωt)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const ALTERNATING_CURRENT_SUBTOPICS = [
  "Introduction & Alternating Voltage and Current Definitions",
  "1. Mean / Average Value of AC over Half & Full Cycle (I_avg = 2 I₀ / π = 0.637 I₀)",
  "2. Root Mean Square (RMS) or Effective / Virtual Value of AC (I_rms = I₀ / √2 = 0.707 I₀)",
  "3. AC Circuit Containing Resistance Only (V and I in Same Phase)",
  "4. AC Circuit Containing Inductance Only (Voltage Leads Current by π/2, Inductive Reactance X_L = ω L)",
  "5. AC Circuit Containing Capacitance Only (Current Leads Voltage by π/2, Capacitive Reactance X_C = 1 / ω C)",
  "6. L-R Series AC Circuit (Impedance Z = √(R² + X_L²), Phase Angle tan φ = X_L / R)",
  "7. C-R Series AC Circuit (Impedance Z = √(R² + X_C²), Phase Angle tan φ = X_C / R)",
  "8. L-C-R Series AC Circuit & Phasor Diagram (Impedance Z = √(R² + (X_L - X_C)²))",
  "9. Series Electrical Resonance in L-C-R Circuit (Resonant Frequency f_r = 1 / (2π √(LC)), Resonance Curve)",
  "10. Quality Factor (Q-Factor = ω₀ L / R) & Sharpness of Resonance",
  "11. Power in AC Circuit (True Power P = V_rms I_rms cos φ, Apparent Power = V_rms I_rms)",
  "12. Power Factor (cos φ = R / Z) & Wattless Current / Idle Current",
  "13. LC Oscillations & Conservation of Energy (Frequency f = 1 / (2π √(LC)))",
  "14. Transformer (Principle, Step-Up & Step-Down, Transformation Ratio k = N_s / N_p = V_s / V_p, Efficiency η)",
  "15. Energy Losses in Transformer (Copper Loss, Iron/Hysteresis Loss, Eddy Current Loss, Flux Leakage)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const ELECTROMAGNETIC_WAVES_SUBTOPICS = [
  "Introduction & Inconsistency of Ampere's Circuital Law",
  "1. Displacement Current Concept I_d = ε₀ (dΦ_E / dt) & Ampere-Maxwell Law (∮ B · dl = μ₀ (I_c + I_d))",
  "2. Electromagnetic Waves Definition, Production by Oscillating/Accelerated Charges",
  "3. Transverse Nature of EM Waves (Electric E and Magnetic B Fields Perpendicular to Each Other & Direction of Propagation)",
  "4. Velocity of EM Waves in Vacuum (c = 1 / √(μ₀ ε₀) = 3 × 10⁸ m/s) & Medium Speed (v = 1 / √(μ ε))",
  "5. Ratio of Amplitudes of Electric and Magnetic Fields (E₀ / B₀ = c)",
  "6. Energy Density of EM Waves (u = u_E + u_B = ½ ε₀ E² + ½ (B² / μ₀) = ε₀ E_rms²)",
  "7. Intensity, Momentum & Radiation Pressure of EM Waves (Poynting Vector S = (1/μ₀) (E × B))",
  "8. Electromagnetic Spectrum Overview & Frequency/Wavelength Classification",
  "9. Radio Waves, Microwaves & Infrared Waves (Production, Frequency/Wavelength Ranges, Properties & Practical Applications)",
  "10. Visible Light, Ultraviolet Rays, X-Rays & Gamma Rays (Production, Frequency/Wavelength Ranges, Properties & Practical Applications)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const RAY_OPTICS_SUBTOPICS = [
  "Introduction & Laws of Reflection and Refraction (Snell's Law)",
  "1. Reflection of Light by Spherical Mirrors (Mirror Formula & Magnification)",
  "2. Refraction of Light at Plane Interfaces & Real/Apparent Depth",
  "3. Total Internal Reflection (TIR), Critical Angle & Optical Fibers / Total Reflection Prisms",
  "4. Refraction at Spherical Surfaces (Convex and Concave Refraction Formula)",
  "5. Lens Maker's Formula & Thin Lens Formula (Combination of Thin Lenses in Contact)",
  "6. Refraction and Dispersion of Light through a Prism (Angle of Deviation δ, Minimum Deviation δ_m)",
  "7. Scattering of Light in Atmosphere (Blue Color of Sky, Red Sunset)",
  "8. Optical Instruments: Simple Microscope / Magnifying Glass (Magnifying Power for Near & Far Point)",
  "9. Compound Microscope (Working, Ray Diagram & Magnifying Power M = -(L/f_o)(1 + D/f_e))",
  "10. Astronomical Telescope (Refracting Telescope: Normal Adjustment & Minimum Separation)",
  "11. Reflecting Telescopes (Cassegrain & Newtonian Types, Advantages over Refracting Telescopes)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const WAVE_OPTICS_SUBTOPICS = [
  "Introduction & Wave Nature of Light",
  "1. Huygens' Principle & Wavefronts (Spherical, Cylindrical, Plane)",
  "2. Refraction & Reflection of Plane Waves using Huygens' Principle",
  "3. Coherent and Incoherent Sources of Light (Phase Difference & Path Difference)",
  "4. Interference of Light & Young's Double Slit Experiment (YDSE)",
  "5. Condition for Constructive & Destructive Interference (Fringe Width β = λD/d)",
  "6. Intensity Distribution in Interference Pattern (I = I₁ + I₂ + 2√(I₁I₂)cosφ)",
  "7. Diffraction of Light & Single Slit Experiment",
  "8. Width of Central Maximum & Intensity Distribution of Diffraction Pattern",
  "9. Resolving Power of Optical Instruments (Microscope & Telescope)",
  "10. Polarization of Light (Unpolarized vs Polarized Light)",
  "11. Malus's Law (I = I₀ cos²θ) & Polarization by Scattering",
  "12. Polarization by Reflection (Brewster's Law: n = tan i_p)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const DUAL_NATURE_SUBTOPICS = [
  "Introduction & Electron Emission (Thermionic, Field, Photoelectric)",
  "1. Photoelectric Effect (Hertz, Hallwachs and Lenard's Observations)",
  "2. Experimental Study of Photoelectric Effect (Effect of Intensity & Potential)",
  "3. Effect of Frequency of Incident Light on Stopping Potential",
  "4. Laws of Photoelectric Emission",
  "5. Particle Nature of Light: The Photon (Energy E = hν, Momentum p = h/λ)",
  "6. Einstein's Photoelectric Equation: Energy Quantum of Radiation (K_max = hν - Φ)",
  "7. Wave Nature of Matter: de Broglie Relation (λ = h/p = h/√(2mE))",
  "8. de Broglie Wavelength of an Electron (λ = 12.27/√V Å)",
  "9. Davisson and Germer Experiment (Experimental Verification of Wave Nature)",
  "10. X-Rays (Production and Properties - Optional/Additional)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const ATOMS_SUBTOPICS = [
  "Introduction & Alpha-particle Scattering Experiment",
  "1. Rutherford's Nuclear Model of Atom",
  "2. Distance of Closest Approach & Impact Parameter",
  "3. Electron Orbits (Kinetic and Potential Energy of Electron)",
  "4. Atomic Spectra (Spectral Series of Hydrogen Atom)",
  "5. Bohr Model of the Hydrogen Atom (Postulates)",
  "6. Energy Levels of Hydrogen Atom (E_n = -13.6/n² eV)",
  "7. The Line Spectra of the Hydrogen Atom (Lyman, Balmer, Paschen, Brackett, Pfund series)",
  "8. De Broglie's Explanation of Bohr's Second Postulate of Quantisation",
  "9. Limitations of Bohr's Model",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const NUCLEI_SUBTOPICS = [
  "Introduction & Atomic Masses and Composition of Nucleus",
  "1. Size of the Nucleus (R = R₀ A^(1/3))",
  "2. Mass-Energy (Einstein's Mass-Energy Equivalence: E = mc²)",
  "3. Nuclear Binding Energy & Mass Defect (Δm)",
  "4. Binding Energy per Nucleon Curve and Nuclear Stability",
  "5. Nuclear Force (Properties: Strong, Short-range, Spin-dependent)",
  "6. Radioactivity: Alpha, Beta, and Gamma Decay",
  "7. Radioactive Decay Law (N = N₀ e^(-λt))",
  "8. Half-Life (T_1/2 = 0.693/λ) and Mean Life (τ = 1/λ)",
  "9. Nuclear Energy: Fission and Fusion",
  "10. Nuclear Reactor (Principles of Controlled Chain Reaction)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const SEMICONDUCTOR_ELECTRONICS_SUBTOPICS = [
  "Introduction & Energy Bands in Solids",
  "1. Classification of Metals, Conductors and Semiconductors on the basis of Energy Bands",
  "2. Intrinsic Semiconductors",
  "3. Extrinsic Semiconductors (n-type and p-type)",
  "4. p-n Junction Formation & Depletion Region",
  "5. Semiconductor Diode and its I-V Characteristics (Forward & Reverse Bias)",
  "6. Application of Junction Diode as a Rectifier (Half-wave & Full-wave)",
  "7. Special Purpose p-n Junction Diodes (Zener Diode, Photodiode, LED, Solar Cell)",
  "8. Zener Diode as a Voltage Regulator",
  "9. Junction Transistor and its action (Basics)",
  "10. Digital Electronics and Logic Gates (OR, AND, NOT, NAND, NOR)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const COMMUNICATION_SYSTEMS_SUBTOPICS = [
  "Introduction & Elements of a Communication System",
  "1. Basic Terminology Used in Electronic Communication Systems",
  "2. Bandwidth of Signals (Speech, TV, Digital Data)",
  "3. Bandwidth of Transmission Medium",
  "4. Propagation of Electromagnetic Waves (Ground, Sky, and Space Wave)",
  "5. Modulation and its Necessity",
  "6. Amplitude Modulation (AM)",
  "7. Production of Amplitude Modulated Wave",
  "8. Detection of Amplitude Modulated Wave",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const REFLECTION_OF_LIGHT_SUBTOPICS = [
  "Introduction & Laws of Reflection of Light",
  "1. Reflection at Plane Surfaces & Characteristics of Image",
  "2. Spherical Mirrors: Concave and Convex Mirrors",
  "3. Sign Convention (New Cartesian Sign Convention) & Focal Length (f = R/2)",
  "4. Mirror Formula (1/f = 1/v + 1/u)",
  "5. Linear Magnification (m = -v/u = f/(f-u))",
  "6. Ray Diagrams for Concave and Convex Mirrors for Different Object Positions",
  "7. Aberrations in Spherical Mirrors (Spherical Aberration & Paraxial Rays)",
  "8. Applications & Uses of Spherical Mirrors (Searchlights, Shaving Mirrors, Rear-view Mirrors)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const REFRACTION_PLANE_INTERFACE_SUBTOPICS = [
  "Introduction & Cause of Refraction of Light",
  "1. Laws of Refraction & Snell's Law (n1 sin i = n2 sin r)",
  "2. Absolute and Relative Refractive Index & Speed of Light in Medium",
  "3. Refraction Through a Glass Slab & Lateral Shift/Displacement",
  "4. Real and Apparent Depth & Normal Shift (Δx = t(1 - 1/n))",
  "5. Total Internal Reflection (TIR) & Critical Angle (sin ic = 1/n)",
  "6. Applications of Total Internal Reflection (Mirage, Sparkling of Diamond, Porro Prisms)",
  "7. Optical Fiber: Principle, Structure (Core, Cladding), Propagation & Applications",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const REFRACTION_SPHERICAL_SURFACES_LENSES_SUBTOPICS = [
  "1. Refraction at Single Spherical Surface (n2/v - n1/u = (n2 - n1)/R)",
  "2. Refraction through Thin Spherical Lenses: Convex and Concave Lenses",
  "3. Lens Maker's Formula (1/f = (n - 1)(1/R1 - 1/R2))",
  "4. Lens Formula (1/f = 1/v - 1/u) & Power of a Lens (P = 1/f in meters, Dioptres)",
  "5. Linear Magnification of Lens (m = v/u = f/(f+u))",
  "6. Combination of Thin Lenses in Contact (1/F = 1/f1 + 1/f2, P = P1 + P2)",
  "7. Combination of Lenses Separated by Distance d",
  "8. Ray Diagrams for Convex and Concave Lenses for Various Object Positions",
  "9. Chromatic & Spherical Aberration in Lenses & Achromatism",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const REFRACTION_DISPERSION_PRISM_SUBTOPICS = [
  "1. Refraction of Light through a Triangular Glass Prism",
  "2. Angle of Deviation (δ = i + e - A) & Factors Affecting Deviation",
  "3. Angle of Minimum Deviation (δm) & Prism Formula (n = sin((A+δm)/2) / sin(A/2))",
  "4. Dispersion of White Light by Prism & Spectrum (VIBGYOR)",
  "5. Cauchy's Formula (n = A + B/λ²) & Angular Dispersion (θ = (nv - nr)A)",
  "6. Dispersive Power of Prism Material (ω = (nv - nr)/(n - 1))",
  "7. Rainbow Formation: Primary Rainbow (Two Refractions, One TIR) & Secondary Rainbow (Two Refractions, Two TIRs)",
  "8. Scattering of Light: Rayleigh's Law (I ∝ 1/λ⁴), Blue Color of Sky, Redness of Sunset/Sunrise",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const OPTICAL_INSTRUMENTS_SUBTOPICS = [
  "1. Human Eye & Visual Angle, Power of Accommodation, Defects of Vision (Myopia, Hypermetropia, Presbyopia, Astigmatism) & Corrections",
  "2. Simple Microscope (Magnifying Glass): Rays, Magnifying Power (m = 1 + D/f at Near Point, m = D/f at Infinity)",
  "3. Compound Microscope: Ray Diagram, Construction, Working & Magnifying Power (m = - (vo/uo)(1 + D/fe) or m = - (L/fo)(D/fe))",
  "4. Astronomical Telescope (Refracting): Ray Diagrams, Normal Adjustment & Magnifying Power (m = - fo/fe, Tube Length L = fo + fe)",
  "5. Terrestrial Telescope & Galilean Telescope: Construction, Ray Diagrams & Magnifying Power",
  "6. Reflecting Telescopes: Newtonian & Cassegrain Telescopes (Advantages over Refracting Telescopes - No Chromatic/Spherical Aberration)",
  "7. Resolving Power of Optical Instruments: Rayleigh's Criterion for Resolution, Resolving Power of Microscope & Telescope",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const WAVE_NATURE_HUYGENS_SUBTOPICS = [
  "1. Corpuscular vs Wave Theory of Light (Newton vs Huygens)",
  "2. Concept of Wavefront: Definition, Types (Spherical, Cylindrical, Plane Wavefronts) & Rays",
  "3. Huygens' Principle of Secondary Wavelets & Propagation of Wavefronts",
  "4. Proof of Law of Reflection using Huygens' Principle (sin i = sin r, ∠i = ∠r)",
  "5. Proof of Snell's Law of Refraction using Huygens' Wave Theory (sin i / sin r = v1/v2 = n2/n1)",
  "6. Behavior of Wavefront passing through Prism, Convex Lens, and Concave Mirror",
  "7. Speed of Light in Denser vs Rarer Medium according to Huygens' Wave Theory",
  "8. Doppler Effect in Light: Red Shift (receding source) & Blue Shift (approaching source), Fractional Frequency Shift (Δν/ν = - v/c)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const INTERFERENCE_OF_LIGHT_SUBTOPICS = [
  "1. Principle of Superposition of Light Waves & Phase Difference (Δϕ = 2π/λ · Δx)",
  "2. Coherent & Incoherent Sources of Light (Conditions for Sustained Interference)",
  "3. Interference of Light & Mathematical Analysis of Fringe Intensity (I = I1 + I2 + 2√(I1 I2) cos ϕ)",
  "4. Constructive Interference (Maxima: Δx = nλ, I_max = (a1 + a2)²) & Destructive Interference (Minima: Δx = (2n-1)λ/2, I_min = (a1 - a2)²)",
  "5. Young's Double Slit Experiment (YDSE) Setup & Wavefront Splitting",
  "6. Fringe Width Formula Derivation (β = λ D / d) & Position of Bright/Dark Fringes (y_n = n λ D / d)",
  "7. Intensity Distribution Curve in YDSE & Conservation of Energy in Interference",
  "8. Shift of Fringe Pattern on Introducing Thin Transparent Sheet (Δy = (μ - 1)t D / d)",
  "9. Interference in Thin Films & Colors in Soap Bubbles / Oil Films",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const DIFFRACTION_OF_LIGHT_SUBTOPICS = [
  "1. Concept of Diffraction of Light & Comparison with Interference",
  "2. Fresnel vs Fraunhofer Diffraction Classifications",
  "3. Fraunhofer Diffraction at a Single Slit: Experimental Arrangement & Secondary Wavelets",
  "4. Positions of Secondary Minima (a sin θ = nλ) & Secondary Maxima (a sin θ = (2n+1)λ/2)",
  "5. Width of Central Diffraction Maximum (β_0 = 2 λ D / a) & Angular Width (2θ_0 = 2 λ / a)",
  "6. Intensity Distribution Curve in Single Slit Diffraction & Ratio of Peak Intensities (1 : 1/22 : 1/61...)",
  "7. Fresnel Distance (Z_f = a² / λ) & Limit of Ray Optics Validity",
  "8. Difference between Interference and Diffraction Patterns",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const POLARIZATION_OF_LIGHT_SUBTOPICS = [
  "1. Unpolarized vs Plane Polarized Light & Transverse Nature of Light Waves",
  "2. Plane of Vibration & Plane of Polarization Definitions",
  "3. Polarization by Reflection & Brewster's Law (tan i_p = μ, i_p + r = 90°)",
  "4. Polarization by Refraction & Pile of Plates Setup",
  "5. Polarization by Double Refraction (Birefringence): Ordinary (O) & Extraordinary (E) Rays",
  "6. Nicol Prism: Construction, Action & Total Internal Reflection of O-ray",
  "7. Malus' Law of Transmitted Intensity (I = I_0 cos² θ)",
  "8. Polaroids: Dichroism, Construction, Uses in Sun Glasses & 3D Movies",
  "9. Optical Activity & Specific Rotation of Cane Sugar Solution",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const PHOTOELECTRIC_EFFECT_SUBTOPICS = [
  "1. Free Electrons in Metals & Work Function (W_0 = h ν_0)",
  "2. Electron Emission Types: Thermionic, Field, Secondary, and Photoelectric Emission",
  "3. Hertz & Lenard's Photoelectric Observations & Experimental Setup",
  "4. Effect of Light Intensity on Photoelectric Current",
  "5. Effect of Potential & Concept of Stopping Potential (V_0, e V_0 = K_max)",
  "6. Effect of Frequency on Stopping Potential & Threshold Frequency (ν_0)",
  "7. Laws of Photoelectric Emission & Failure of Classical Wave Theory",
  "8. Einstein's Photoelectric Equation (h ν = W_0 + K_max = h ν_0 + 1/2 m v_max²)",
  "9. Determination of Planck's Constant (h) & Work Function from V_0 vs ν Graph",
  "10. Photocells: Construction, Working & Applications in Automatic Doors / Light Meters",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const MATTER_WAVES_SUBTOPICS = [
  "1. Dual Nature of Radiation: Wave-Particle Duality & Photon Momentum (p = h / λ)",
  "2. de Broglie Hypothesis of Matter Waves (λ = h / p = h / (m v))",
  "3. de Broglie Wavelength of Relativistic & Non-relativistic Charged Particles",
  "4. de Broglie Wavelength of Electron Accelerated through Potential V (λ = 12.27 / √V Å)",
  "5. Davisson and Germer Experiment: Experimental Setup, Nickel Crystal Diffraction & Verification of Matter Waves",
  "6. Wave Packet Concept & Group Velocity vs Phase Velocity",
  "7. Heisenberg's Uncertainty Principle (Δx · Δp ≥ h / 4π)",
  "8. Applications & Significance of Matter Waves in Electron Microscopes",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const X_RAYS_SUBTOPICS = [
  "1. Production of X-Rays & Coolidge Tube Construction and Working",
  "2. Mechanism of X-Ray Generation: Fast Moving Electrons Striking Heavy Metal Target",
  "3. Continuous X-Ray Spectrum & Duane-Hunt Law (λ_min = h c / (e V) = 12400 / V Å)",
  "4. Characteristic X-Ray Spectrum & Emission of K_α, K_β, L_α X-Ray Lines",
  "5. Moseley's Law (√ν = a(Z - b)) & Significance in Periodic Table & Atomic Numbers",
  "6. Properties of X-Rays: High Penetration Power, Ionization, Photographic & Fluorescent Effects",
  "7. Bragg's Law of X-Ray Diffraction in Crystals (2 d sin θ = n λ)",
  "8. Applications of X-Rays in Radiography, Radiotherapy, Crystallography & Security Inspections",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const ATOMS_BOHR_SPECTRUM_SUBTOPICS = [
  "1. Rutherford's Alpha-Particle Scattering Experiment & Nuclear Atom Model",
  "2. Distance of Closest Approach & Impact Parameter Concepts",
  "3. Limitations of Rutherford Model: Electromagnetic Instability & Continuous Spectrum Paradox",
  "4. Bohr's Postulates of Hydrogen Atom Model: Quantized Circular Orbits & Stationary States",
  "5. Bohr's Quantization Condition of Angular Momentum (L = m v r = n h / 2π)",
  "6. Derivation of Orbit Radius (r_n ∝ n²), Orbital Velocity (v_n ∝ 1/n), & Total Energy (E_n = -13.6 / n² eV)",
  "7. Spectral Transitions & Emission / Absorption Line Spectra",
  "8. Hydrogen Spectral Series: Lyman, Balmer, Paschen, Brackett, and Pfund Series",
  "9. Rydberg Formula & Rydberg Constant (1/λ = R (1/n_1² - 1/n_2²))",
  "10. De Broglie Explanation of Bohr's Quantization Condition (2 π r = n λ)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const NUCLEAR_STRUCTURE_SUBTOPICS = [
  "1. Composition of Atomic Nucleus: Protons, Neutrons, Nucleons & Atomic Number (Z), Mass Number (A)",
  "2. Nuclear Size Formula (R = R_0 A^(1/3)) & Constant Nuclear Density (~2.3 × 10¹⁷ kg/m³)",
  "3. Isotopes, Isobars, Isotones, & Isomers with Examples",
  "4. Atomic Mass Unit (amu or u) & Mass-Energy Equivalence (1 u = 931.5 MeV)",
  "5. Mass Defect (Δm = Z m_p + (A - Z) m_n - M) & Nuclear Binding Energy (E_b = Δm × 931.5 MeV)",
  "6. Binding Energy Per Nucleon Curve (E_bn vs A) & Nuclear Stability Thresholds",
  "7. Fundamental Properties of Nuclear Forces: Short Range, Charge Independent, Spin Dependent, Non-Central & Saturation Property",
  "8. Yukawa's Meson Exchange Theory of Nuclear Forces",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const RADIOACTIVITY_SUBTOPICS = [
  "1. Discovery of Radioactivity (Becquerel, Curies) & Natural Radioactive Disintegration",
  "2. Characteristics of Alpha (α), Beta (β), and Gamma (γ) Radiations & Deflection in Electric / Magnetic Fields",
  "3. Soddy-Russell Group Displacement Laws for Alpha and Beta Decay",
  "4. Radioactive Decay Law (N = N_0 e^(-λt)) & Activity (A = -dN/dt = λ N, Becquerel & Curie units)",
  "5. Half-Life Period (T_1/2 = 0.693 / λ) & Mean / Average Life (τ = 1 / λ = 1.44 T_1/2)",
  "6. Radioactive Decay Series (Uranium, Thorium, Actinium) & Radioactive Equilibrium",
  "7. Alpha Decay Energy (Q-value) & Alpha Particle Spectrum",
  "8. Beta Decay Spectrum & Pauli's Neutrino / Antineutrino Hypothesis",
  "9. Gamma Ray Emission & Internal Conversion Nuclear Transitions",
  "10. Radiation Hazards, Safety Measures & Carbon Dating (C-14) Applications",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const MASS_ENERGY_BINDING_ENERGY_SUBTOPICS = [
  "1. Einstein's Mass-Energy Equivalence Principle (E = m c²) & Relativistic Mass",
  "2. Conversion Units: Electron-Volt (eV), MeV, and Atomic Mass Unit Energy Equivalent (1 u = 931.5 MeV)",
  "3. Nuclear Mass Defect (Δm = Z m_p + (A - Z) m_n - M)",
  "4. Total Nuclear Binding Energy Formula & Binding Energy Per Nucleon (E_bn)",
  "5. Comprehensive Analysis of Binding Energy Per Nucleon Curve",
  "6. Nuclear Stability Belt & Neutron-to-Proton Ratio (N/Z) Thresholds",
  "7. Mass Defect and Q-Value Calculations in Nuclear Reactions",
  "8. Pair Production (γ → e⁻ + e⁺, E_min = 1.02 MeV) & Pair Annihilation (e⁻ + e⁺ → 2γ)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const NUCLEAR_FISSION_FUSION_SUBTOPICS = [
  "1. Discovery of Nuclear Fission (Hahn, Strassmann, Meitner) & U-235 Fission Reactions",
  "2. Energy Released in Fission (~200 MeV per U-235 nucleus) & Liquid Drop Model Explanation",
  "3. Chain Reaction Mechanism: Uncontrolled (Atom Bomb) vs Controlled Chain Reactions",
  "4. Multiplication Factor / Reproduction Factor (k) & Critical Size / Mass",
  "5. Nuclear Reactor Construction: Fuel Rods, Moderator, Control Rods, Coolant & Shielding",
  "6. Nuclear Fusion Mechanism & High Temperature / Pressure Requirements (Thermonuclear Reactions)",
  "7. Proton-Proton Cycle & Carbon-Nitrogen Cycle in Stellar / Solar Energy Production",
  "8. Hydrogen Bomb & Controlled Thermonuclear Fusion (Tokamak, Magnetic Confinement)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const SEMICONDUCTOR_ELECTRONICS_LESSON_SUBTOPICS = [
  "1. Energy Band Theory in Solids: Valence Band, Conduction Band & Forbidden Energy Gap (E_g)",
  "2. Classification of Solids: Conductors (E_g = 0), Insulators (E_g > 3 eV), and Semiconductors (E_g ~ 1 eV)",
  "3. Intrinsic Semiconductors (Pure Si, Ge): Thermal Generation of Electron-Hole Pairs & Electrical Conductivity",
  "4. Extrinsic Semiconductors: Doping Process, N-type (Pentavalent: P, As, Sb) & P-type (Trivalent: B, Al, In) Semiconductors",
  "5. Charge Carrier Concentrations & Law of Mass Action (n_e · n_h = n_i²)",
  "6. Electrical Conduction in Semiconductors (I = I_e + I_h) & Drift Velocity / Mobility",
  "7. P-N Junction Formation: Diffusion Current, Drift Current, Depletion Region & Potential Barrier (V_0)",
  "8. Biasing of P-N Junction: Forward Bias & Reverse Bias V-I Characteristics",
  "9. P-N Junction Diode as Rectifier: Half-Wave Rectifier & Full-Wave Rectifier (Center-Tap & Bridge)",
  "10. Special Purpose Diodes: Zener Diode (Voltage Regulator), LED, Photodiode & Solar Cell",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const SEMICONDUCTOR_DIODES_SUBTOPICS = [
  "1. P-N Junction Diode V-I Characteristics in Forward and Reverse Bias",
  "2. Resistance of a Diode: Static (DC) Resistance (R_dc = V/I) and Dynamic (AC) Resistance (r_ac = ΔV / ΔI)",
  "3. Breakdown Mechanisms in Diodes: Avalanche Breakdown vs Zener Breakdown",
  "4. Zener Diode as a Voltage Regulator & Load / Line Regulation Circuits",
  "5. Light Emitting Diode (LED): Spontaneous Emission, Bandgap Energy (E_g = h ν) & Color Spectra",
  "6. Photodiode: Reverse Bias Light Detector, Photo-Current Generation & Fast Optical Switch",
  "7. Solar Cell: Photovoltaic Effect, Open Circuit Voltage (V_oc), Short Circuit Current (I_sc) & Fill Factor",
  "8. Point Contact Diode & Schottky Barrier Diode High-Frequency Applications",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const JUNCTION_TRANSISTORS_SUBTOPICS = [
  "1. Structure of Bipolar Junction Transistor (BJT): NPN and PNP Types (Emitter, Base, Collector & Doping)",
  "2. Transistor Action and Charge Carrier Flow: Emitter Current Formula (I_E = I_B + I_C)",
  "3. Transistor Configurations: Common Base (CB), Common Emitter (CE), and Common Collector (CC)",
  "4. Common Emitter (CE) Characteristics: Input Characteristics (I_B vs V_BE) & Output Characteristics (I_C vs V_CE)",
  "5. Current Amplification Factors: Alpha (α = ΔI_C / ΔI_E) and Beta (β = ΔI_C / ΔI_B) & Relation β = α / (1 - α)",
  "6. Transistor as an Amplifier in CE Configuration: Voltage Gain (A_v = - β R_L / R_in), Power Gain & 180° Phase Reversal",
  "7. Transistor as a Switch: Cut-off Region (OFF State) and Saturation Region (ON State)",
  "8. Transistor LC Oscillator: Positive Feedback, Barkhausen Criterion (A β = 1) & Resonance Frequency",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const LOGIC_GATES_SUBTOPICS = [
  "1. Analog vs Digital Signals & Binary Number System Fundamentals (Bits, Bytes, Logic 0 & Logic 1)",
  "2. Basic Logic Gates: OR Gate, AND Gate, and NOT Gate (Symbols, Truth Tables & Boolean Expressions)",
  "3. Universal Logic Gates: NAND Gate and NOR Gate (Universal Property & Construction of Basic Gates)",
  "4. Exclusive Logic Gates: XOR (Exclusive-OR) and XNOR (Exclusive-NOR) Gates & Comparator Applications",
  "5. De Morgan's Laws: (A + B)' = A' · B' and (A · B)' = A' + B' Boolean Simplification",
  "6. Realization of Logic Gates using Diode-Resistor Logic (DRL) and Transistor-Transistor Logic (TTL)",
  "7. Truth Table Construction and Boolean Logic Circuit Synthesis from Expression",
  "8. Integrated Circuits (ICs): SSI, MSI, LSI, VLSI & Microprocessor Digital Logic Applications",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const COMMUNICATION_SYSTEMS_LESSON_SUBTOPICS = [
  "1. Elements of a Communication System: Transmitter, Channel / Medium, Noise Source & Receiver",
  "2. Basic Terminology: Signal, Transducer, Bandwidth, Attenuation, Amplification, Range & Repeater",
  "3. Bandwidth of Signals (Speech 300-3100 Hz, Music 20 kHz, Video 4.2 MHz) & Transmission Media (Coaxial, Fiber)",
  "4. Wave Propagation Modes: Ground Wave, Sky Wave (Ionospheric Reflection, Skip Distance) & Space Wave (LOS)",
  "5. Need for Modulation: Antenna Height (h ≥ λ/4), Radiated Power (P ∝ (l/λ)²), and Overlapping Prevention",
  "6. Amplitude Modulation (AM): Derivation, Modulation Index (μ = A_m / A_c), Sidebands (USB, LSB) & Bandwidth = 2 f_m",
  "7. Frequency Modulation (FM) vs Phase Modulation (PM) Principles & Noise Immunity Advantages",
  "8. Detection / Demodulation of AM Wave: Diode Detector Circuit & Envelope Detection",
  "9. Satellite Communication, Optical Fiber Networks & Cellular / Mobile Networks Basics",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions, [B] Multichoice Question, Hints/Solutions"
];

export const PHYSICS_ICSE_LESSONS = [
  "1. ELECTRIC CHARGES AND FIELDS: 23 Learning Modules, Introduction (1), Electric Charge (3), Positive and Negative Charges (5), Electron Theory of Electrification (8), Conductors and Insulators (10), Electrostatic Induction (12)",
  "2. Gauss' Theorem",
  "3. Electric Potential",
  "4. Capacitors and Dielectrics",
  "5. Electric Resistance and Ohm's Law",
  "6. DC Circuits and Measurements",
  "7. Moving Charges and Magnetic Field",
  "8. Torque on a Current-Loop : Moving-Coil Galvanometer",
  "9. Magnetic Field and Earth's Magnetism",
  "10. Magnetic Classification of Substances",
  "11. Electromagnetic Induction",
  "12. Alternating Current",
  "13. Electromagnetic Waves",
  "14. Ray Optics and Optical Instruments",
  "15. Wave Optics",
  "16. Dual Nature of Radiation and Matter",
  "17. Atoms",
  "18. Nuclei",
  "19. Semiconductor Electronics",
  "20. Communication Systems",
  "21. Reflection of Light : Spherical Mirrors",
  "22. Refraction of Light at a Plane Interface : Total Internal Reflection : Optical Fiber",
  "23. Refraction of Light at Spherical Surfaces : Lenses",
  "24. Refraction and Dispersion of Light through a Prism",
  "25. Optical Instruments",
  "26. Wave Nature of Light : Huygens' Principle",
  "27. Interference of Light",
  "28. Diffraction of Light",
  "29. Polarization of Light",
  "30. Photoelectric Effect",
  "31. Matter Waves",
  "32. X-Rays",
  "33. Atom, Origin of Spectra : Bohr's Theory of Hydrogen Atom",
  "34. Nuclear Structure",
  "35. Radioactivity",
  "36. Mass-Energy Equivalence : Nuclear Binding Energy",
  "37. Nuclear Fission and Fusion : Sources of Energy",
  "38. Semiconductor Electronics",
  "39. Semiconductor Diodes",
  "40. Junction Transistors",
  "41. Logic Gates",
  "42. Communication Systems"
];

export const PSYCHOLOGY_ISC_LESSONS = [
  "1. Intelligence and Ability",
  "2. Personality",
  "3. Lifespan Development",
  "4. Stress and Health",
  "5. Psychological Disorders and Psychotherapy",
  "6. Social Thought and Social Behaviour",
  "7. Attitude and Social Influence"
];

export const CONTINUITY_DIFFERENTIABILITY_SUBTOPICS = [
  "Introduction",
  "1. Step continuity, point continuity, and jump anomalies over piecewise functions",
  "2. Left-hand derivative (LHD) and right-hand derivative (RHD) correlations",
  "3. Derivatives of composite functions via Chain Rule",
  "4. Implicit function differentiation",
  "5. Inverse trigonometric function differentiation",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const EXPONENTIAL_LOGARITHMIC_MEAN_VALUE_SUBTOPICS = [
  "Introduction",
  "1. Exponential and logarithmic functions (e^x, a^x, log x)",
  "2. Logarithmic differentiation for variable-base exponents (u^v)",
  "3. Parametric functions",
  "4. Second-order derivatives",
  "5. Rolle’s Theorem",
  "6. Lagrange's Mean Value Theorem (geometrical interpretations and algebraic verifications)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const APPLICATION_DERIVATIVES_SUBTOPICS = [
  "Introduction",
  "1. Rate of change of quantities with respect to time or variables",
  "2. Equations of tangents and normals to a curve at a designated point",
  "3. Rigorous identification of strictly increasing and decreasing intervals",
  "4. Local/absolute maxima and minima, first derivative test, second derivative test, and word-problem optimizations for real-world geometry",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const INTEGRATION_SUBTOPICS = [
  "Introduction",
  "1. Integration as the inverse process of differentiation",
  "2. Integration by substitution, integration by parts, and integration via partial fractions",
  "3. Integration of expressions involving quadratic denominators: ∫ dx/(x² ± a²), ∫ dx/√(a² ± x²), ∫ dx/(ax²+bx+c), ∫ (px+q)dx/(ax²+bx+c)",
  "4. Fundamental Theorem of Calculus, evaluation of definite integrals, definite integration as the limit of a Riemann sum",
  "5. P0 to P7 properties (dummy variables, interval splitting, odd/even function simplification, and reflection bounds) used for evaluation",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const DIFFERENTIAL_EQUATIONS_SUBTOPICS = [
  "Introduction",
  "1. Order and degree of a differential equation",
  "2. Constructing differential equations by eliminating arbitrary constants",
  "3. Homogeneous equations, variable separable method, equations reducible to variable separable type, and first-order linear differential equations (dy/dx + Py = Q)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const PROBABILITY_SUBTOPICS = [
  "Introduction",
  "1. Definition, sample space scaling, and multiplication theorem on probability",
  "2. Definition, verification criteria, and mutually exclusive vs. independent comparisons",
  "3. Partition of sample spaces, theorem of total probability, calculation of posterior probabilities",
  "4. Discrete random variables, constructing probability mass distributions",
  "5. Evaluation of the Expectation/Mean (μ) and Variance (σ²) of a discrete random variable",
  "6. Bernoulli trials, conditions for success/failure, and evaluation using the binomial probability formula",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const VECTORS_SUBTOPICS = [
  "Introduction",
  "1. Vectors and scalars, magnitude, direction, position vector of a point, direction cosines, and direction ratios",
  "2. Null (zero), unit, co-initial, collinear, and equal vectors",
  "3. Vector addition, scalar multiplication, and the internal/external section formula",
  "4. Scalar (dot) product of two vectors, projection of a vector on a line, vector (cross) product of two vectors, and area calculations for triangles and parallelograms",
  "5. Scalar triple product [ a, b, c ], geometric volume of a parallelepiped, and coplanarity proofs",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const THREE_DIMENSIONAL_GEOMETRY_SUBTOPICS = [
  "Introduction",
  "1. Direction cosines and direction ratios of lines passing through two distinct points",
  "2. Vector and Cartesian equations of a line, coplanar and skew lines, and finding the shortest distance between two lines",
  "3. Vector and Cartesian equations of a plane, intersecting planes, angle between two lines, angle between two planes, and angle between a line and a plane",
  "4. Calculating the perpendicular distance of a point from a target plane",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const APPLICATIONS_OF_INTEGRALS_SUBTOPICS = [
  "Introduction",
  "1. Evaluating bounded regions enclosed by simple algebraic curves, specifically lines, circles, standard parabolas (y² = 4ax), and ellipses (x²/a² + y²/b² = 1)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const APPLICATION_DERIVATIVES_ECONOMICS_SUBTOPICS = [
  "Introduction",
  "1. Total Cost (TC), Average Cost (AC), Marginal Cost (MC), Total Revenue (TR), Average Revenue (AR), and Marginal Revenue (MR)",
  "2. Maximizing total revenue, maximizing profit functions (Π = TR - TC), and minimizing total average costs using first and second derivatives",
  "3. Price elasticity of demand (η = -(p/x) · (dx/dp)), demand functions, and determination of break-even points",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const REGRESSION_SUBTOPICS = [
  "Introduction",
  "1. Deriving the regression line of y on x and the regression line of x on y",
  "2. Calculation of coefficients (byx and bxy), properties of regression lines, identifying the intersection point (x̄, ȳ), and calculating the correlation coefficient (r = ±√(byx · bxy))",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const LINEAR_PROGRAMMING_SUBTOPICS = [
  "Introduction",
  "1. Translating verbal commerce/manufacturing scenarios into mathematical constraints and objective functions (Z = ax + by)",
  "2. Plotting linear constraints, identifying bounded and unbounded feasible regions, identifying corner points, and finding the optimal maximum or minimum values",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const RELATIONS_FUNCTIONS_SUBTOPICS = [
  "Introduction",
  "1. Types of relations: Reflexive, symmetric, transitive and equivalence relations",
  "2. One to one and onto functions",
  "3. Composite functions",
  "4. Inverse of a function",
  "5. Binary operations: all axioms and properties",
  "6. Relation on a set A",
  "7. Identity relation, empty relation, universal relation",
  "8. Functions: as special relations, writing 'y is a function of x' as y=f(x)",
  "9. Types of functions: one to one, many to one, into, onto",
  "10. Real Valued function",
  "11. Domain and range of a function",
  "12. Conditions of invertibility",
  "13. Composite functions and invertible functions (algebraic functions only)",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const INVERSE_TRIGONOMETRIC_FUNCTIONS_SUBTOPICS = [
  "Introduction",
  "1. Definition, domain, range, principal value branch",
  "2. Graphs of inverse trigonometric functions",
  "3. Elementary properties of inverse trigonometric functions",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const MATRICES_SUBTOPICS = [
  "Introduction",
  "1. Concept, notation, order and equality of matrices",
  "2. Types of matrices (zero, identity, diagonal, etc.)",
  "3. Transpose of a matrix",
  "4. Symmetric and skew symmetric matrices",
  "5. Operation on matrices: Addition and subtraction",
  "6. Multiplication of a matrix with a scalar",
  "7. Multiplication of two matrices (compatibility)",
  "8. Simple properties of addition and scalar multiplication",
  "9. Non-commutativity of multiplication of matrices",
  "10. Concept of elementary row and column operations",
  "11. Invertible matrices and uniqueness of inverse",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const DETERMINANTS_SUBTOPICS = [
  "Introduction",
  "1. Determinant of a square matrix (up to 3x3)",
  "2. Properties of determinants",
  "3. Minors and co-factors",
  "4. Applications of determinants in finding area of a triangle",
  "5. Adjoint and inverse of a square matrix",
  "6. Consistency, inconsistency and number of solutions of system of linear equations",
  "7. Solving system of linear equations in two or three variables using inverse of a matrix",
  "Solved Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Numericals",
  "For Different Competitive Examinations : [A] Multichoice Questions (Having Only One Correct Option), [B] Multichoice Question (Having One or More than One Correct Option), Hints/Solutions"
];

export const MATHEMATICS_CBSE_LESSONS = [
  "1. Relations and Functions",
  "2. Inverse Trigonometric Functions - Definition, domain, range, principal value branch, Graphs, Elementary properties",
  "3. Matrices",
  "4. Determinants",
  "5. Continuity and Differentiability",
  "6. Applications of Derivatives",
  "7. Integrals",
  "8. Applications of Integrals",
  "9. Differential Equations",
  "10. Vectors",
  "11. Three Dimensional Geometry",
  "12. Linear Programming",
  "13. Probability",
  "14. Linear Regression and Correlation"
];

export const PHYSICS_CBSE_LESSONS = [
  "1. ELECTRIC CHARGES AND FIELDS: 23 Learning Modules, Introduction (1), Electric Charge (3), Positive and Negative Charges (5), Electron Theory of Electrification (8), Conductors and Insulators (10), Electrostatic Induction (12)",
  "2. Electrostatic Potential and Capacitance",
  "3. Current Electricity",
  "4. Moving Charges and Magnetism",
  "5. Magnetism and Matter",
  "6. Electromagnetic Induction",
  "7. Alternating Current",
  "8. Electromagnetic Waves",
  "9. Ray Optics and Optical Instruments",
  "10. Wave Optics",
  "11. Dual Nature of Radiation and Matter",
  "12. Atoms",
  "13. Nuclei",
  "14. Semiconductor Electronics"
];

export const MATHEMATICS_ICSE_LESSONS = [
  "1. Relations and Functions",
  "2. Inverse Trigonometric Functions - Definition, domain, range, principal value branch, Graphs, Elementary properties",
  "3. Matrices",
  "4. Determinants",
  "5. Continuity and Differentiability",
  "6. Exponential, Logarithmic Functions & Mean Value Theorems",
  "7. Applications of Derivatives",
  "8. Integrals",
  "9. Differential Equations",
  "10. Probability",
  "11. Vectors",
  "12. Three Dimensional Geometry",
  "13. Applications of Integrals",
  "14. Application of Calculus in Commerce and Economics",
  "15. Linear Regression",
  "16. Linear Programming"
];

export const CHEMISTRY_ICSE_LESSONS = [
  "1. Solid State",
  "2. Solutions",
  "3. Electrochemistry",
  "4. Chemical Kinetics",
  "5. Surface Chemistry",
  "6. General Principles and Processes of Isolation of Elements",
  "7. p-Block Elements (Groups 15 to 18)",
  "8. d- and f-Block Elements",
  "9. Coordination Compounds",
  "10. Haloalkanes and Haloarenes",
  "11. Alcohols, Phenols and Ethers",
  "12. Aldehydes, Ketones and Carboxylic Acids",
  "13. Organic Compounds Containing Nitrogen (Amines)",
  "14. Biomolecules",
  "15. Polymers",
  "16. Chemistry in Everyday Life",
  "Appendix: Chemistry Appendices"
];

export const CHEMISTRY_CBSE_LESSONS = [
  "Chapter 1: Solutions (7 Marks) - Types & Concentrations, Vapour Pressure (Raoult's Law), Colligative Properties, and Molar Mass Determinations (Van't Hoff factor)",
  "Chapter 2: Electrochemistry (9 Marks) - Redox & Galvanic Systems, Thermodynamics & Kinetics (Nernst equation), Conductance & Electrolysis (Kohlrausch's Law), and Applied Electrochemistry",
  "Chapter 3: Chemical Kinetics (7 Marks) - Reaction Rates, Rate Laws & Order/Molecularity, Integrated Rate Expressions & Half-life, and Collision Dynamic Models (Arrhenius equation)",
  "Chapter 4: d- and f-Block Elements (7 Marks) - Transition Metals (d-block) Properties, Heavy Inorganic Compounds (K2Cr2O7 & KMnO4), and Inner Transition Metals (Lanthanoids & Actinoids)",
  "Chapter 5: Coordination Compounds (7 Marks) - Structural Nomenclature, Isomerism Configurations, Bonding Theories (Werner's, VBT, CFT), and Applications",
  "Chapter 6: Haloalkanes and Haloarenes (6 Marks) - Nomenclature & Nature of C-X Bond, Substitution Reaction Mechanisms (SN1, SN2), Elimination & Metal Reactions, and Environmental Impacts",
  "Chapter 7: Alcohols, Phenols and Ethers (6 Marks) - Preparation & Properties, Distinct Tests (Lucas test), Named Reactions (Kolbe's, Reimer-Tiemann), and Williamson Synthesis",
  "Chapter 8: Aldehydes, Ketones and Carboxylic Acids (8 Marks) - Carbonyl Group Reactions, Nucleophilic Additions, Named Condensations (Aldol, Cannizzaro), and Carboxylic Acid Strength",
  "Chapter 9: Amines (6 Marks) - Classifications & Nomenclature, Basicity Comparisons, Hinsberg's Test, and Diazonium Salt Reactions",
  "Chapter 10: Biomolecules (7 Marks) - Carbohydrates (Mono/Oligo/Polysaccharides), Protein Structures & Denaturation, Vitamins & Hormones, and Nucleic Acids (DNA vs. RNA)"
];

export const SOLUTIONS_CBSE_SUBTOPICS = [
  "Types & Concentrations: Binary liquid mixtures, expressions of concentration of solutions of solids in liquids, solubility of gases in liquids (Henry's Law)",
  "Vapour Pressure: Liquid-liquid solutions, Raoult's law for volatile and non-volatile solutes, ideal and non-ideal solutions, deviations (positive and negative) from Raoult's law",
  "Colligative Properties: Relative lowering of vapour pressure, elevation of boiling point, depression of freezing point, osmotic pressure",
  "Molar Mass Determinations: Calculation of molecular mass using colligative properties, abnormal molecular mass, Van't Hoff factor (i) and its relation to degree of association and dissociation"
];

export const ELECTROCHEMISTRY_CBSE_SUBTOPICS = [
  "Redox & Galvanic Systems: Redox reactions, EMF of a cell, standard electrode potential, galvanic cells, electrolytic cells",
  "Thermodynamics & Kinetics: Nernst equation and its applications to chemical cells, relation between Gibbs energy change (Δ G) and EMF of a cell (E_cell)",
  "Conductance & Electrolysis: Conductance in electrolytic solutions, specific and molar conductivity, variations of conductivity with concentration, Kohlrausch's Law and its applications",
  "Applied Electrochemistry: Electrolysis and laws of electrolysis (elementary idea), dry cell- electrolytic cells and Galvanic cells, lead accumulator, fuel cells, corrosion"
];

export const CHEMICAL_KINETICS_CBSE_SUBTOPICS = [
  "Reaction Rates: Rate of a reaction (average and instantaneous), factors affecting rates of reaction: concentration, temperature, catalyst",
  "Rate Laws: Order and molecularity of a reaction, rate law and specific rate constant",
  "Integrated Rate Expressions: Integrated rate equations and half-life calculations (restricted strictly to zero and first-order reactions)",
  "Collision Dynamic Models: Mathematical introduction to activation energy, Arrhenius equation, concept of collision theory (elementary qualitative idea, no mathematical treatment)"
];

export const D_AND_F_BLOCK_CBSE_SUBTOPICS = [
  "Transition Metals (d-Block) Properties: Transition metals (d-block) properties, periodic trends, electronic configurations, oxidation states, and metallic properties",
  "Heavy Inorganic Compounds: Heavy inorganic compounds like Potassium Dichromate (K2Cr2O7) and Potassium Permanganate (KMnO4) preparation, properties, and oxidizing actions",
  "Inner Transition Metals (f-Block) - Lanthanoids: Electronic configuration, oxidation states, chemical reactivity, and lanthanoid contraction consequences",
  "Inner Transition Metals (f-Block) - Actinoids: Electronic configuration, oxidation states, and comparative study with lanthanoids"
];

export const COORDINATION_COMPOUNDS_CBSE_SUBTOPICS = [
  "Structural Nomenclature: Structural nomenclature, ligands, coordination number, coordination sphere, and IUPAC nomenclature rules",
  "Isomerism Configurations: Structural isomerism (linkage, ionization, coordination, hydrate) and stereoisomerism (geometrical and optical)",
  "Bonding Theories: Werner's theory, Valence Bond Theory (VBT - hybridization, geometry, magnetic nature), and Crystal Field Theory (CFT - d-orbital splitting, CFSE)",
  "Applications: Stability of complexes, applications in qualitative analysis, extraction of metals, and biological systems (chlorophyll, hemoglobin, vitamin B12)"
];

export const HALOALKANES_HALOARENES_CBSE_SUBTOPICS = [
  "Nomenclature & Properties: Examines nomenclature, nature of C-X bond, dipole moments, physical and chemical properties",
  "Substitution Reaction Mechanisms: Nucleophilic substitution mechanisms (SN1, SN2) with stereochemical aspects (retention, inversion, racemization)",
  "Elimination & Metal Reactions: Elimination reactions (Saytzeff's rule) and organometallic reactions (Grignard reagent, Wurtz, Fittig, Wurtz-Fittig)",
  "Environmental Impacts: Uses and environmental impacts of polyhalogen compounds (dichloromethane, chloroform, iodoform, CCl4, freons, DDT)"
];

export const ALCOHOLS_PHENOLS_ETHERS_CBSE_SUBTOPICS = [
  "Preparation and Properties: Focuses on preparation and properties of alcohols, phenols, and ethers, physical properties and hydrogen bonding",
  "Distinct Tests: Distinct tests like the Lucas test (distinction between primary, secondary, and tertiary alcohols) and neutral FeCl3 test for phenols",
  "Named Reactions: Kolbe's reaction, Reimer-Tiemann reaction, acid-catalyzed dehydration of alcohols, and esterification",
  "Williamson Synthesis: Williamson synthesis of symmetrical and unsymmetrical ethers, physical properties, and cleavage of C-O bond by HI"
];

export const ALDEHYDES_KETONES_CARBOXYLIC_CBSE_SUBTOPICS = [
  "Carbonyl Group Reactions: Details carbonyl group reactions, nomenclature, dipolar structure, and methods of preparation",
  "Nucleophilic Additions: Nucleophilic additions across carbonyl bonds (HCN, NaHSO3, Grignard, alcohols) and addition-elimination with ammonia derivatives",
  "Named Condensations & Reductions: Aldol condensations, Cross-Aldol condensations, Cannizzaro reactions, Clemmensen and Wolff-Kishner reductions, Tollens' and Fehling's tests",
  "Carboxylic Acid Strength: Acidity of carboxylic acids and substituent effects (inductive/resonance), Hell-Volhard-Zelinsky reaction, and decarboxylation"
];

export const AMINES_CBSE_SUBTOPICS = [
  "Classifications & Nomenclature: Reviews classifications (1°, 2°, 3° amines), IUPAC nomenclature, Gabriel phthalimide synthesis, and Hoffmann bromamide reaction",
  "Basicity Comparisons: Basicity comparisons of aliphatic and aromatic amines in gaseous and aqueous phases, inductive, steric, and solvation factors",
  "Hinsberg's Test: Distinction between primary, secondary, and tertiary amines using Hinsberg's reagent (benzenesulphonyl chloride) and carbylamine test",
  "Diazonium Salt Reactions: Preparation of diazonium salts, physical properties, Sandmeyer, Gattermann, azo coupling reactions, and synthetic applications"
];

export const BIOMOLECULES_CBSE_SUBTOPICS = [
  "Carbohydrates: Summarizes carbohydrates, aldoses/ketoses, monosaccharides (cyclic structures of D-glucose and D-fructose), oligosaccharides, and polysaccharides",
  "Protein Structures & Denaturation: Amino acids, peptide bonds, levels of protein structure (primary, secondary alpha-helix/beta-sheet, tertiary, quaternary), and denaturation",
  "Vitamins & Hormones: Classification of vitamins (fat vs water soluble), deficiency diseases, and physiological functions of hormones",
  "Nucleic Acids: Chemical composition, nucleotides, Watson-Crick double-helix structure of DNA, RNA types (mRNA, tRNA, rRNA), biological roles, and DNA vs. RNA"
];

export const SOLID_STATE_SUBTOPICS = [
  "1.1 Classification of Solids",
  "1.2 Space Lattice and Unit Cell",
  "1.3 Cubic Systems and Related Calculations",
  "1.4 Close-Packed Structures",
  "1.5 Characteristics and Structures of Different Types of Crystalline Solids",
  "1.6 Imperfections (Defects) in Solids",
  "1.7 Properties of Solids",
  "1.8 Amorphous Solids",
  "• Self Assessment and Competition File"
];

export const SOLUTIONS_SUBTOPICS = [
  "2.1 Types of Solutions and the Composition of a Solution",
  "2.2 Intensive, Extensive and Colligative Properties",
  "2.3 Non-Volatile Non-Electrolytic Solute, Electrolytic Solute, Dissociation and Association",
  "2.4 Solutions of Gases in Liquids",
  "2.5 Solid Solutions",
  "2.6 Solutions of Solids in Liquids",
  "2.7 Vapour Pressure of Solutions and Raoult's Law",
  "2.8 Ideal and Non-Ideal Solutions",
  "2.9 Colligative Properties and Relative Molecular Masses of Non-Volatile Substances",
  "2.10 Abnormal Molecular Masses and Van't Hoff Factor",
  "• Self Assessment and Competition File"
];

export const ELECTROCHEMISTRY_SUBTOPICS = [
  "3.1 Electrochemical Cells (Galvanic and Electrolytic Cells)",
  "3.2 Galvanic Cell (Voltaic Cell)",
  "3.3 Electrode Potential",
  "3.4 EMF of a Galvanic Cell (Cell Potential)",
  "3.5 Metallic and Electrolytic Conduction",
  "3.6 Electrolytic Conductance",
  "3.7 Variation of Molar Conductivity with Concentration",
  "3.8 Kohlrausch's Law",
  "3.9 Electrolysis and Criteria for Product Formation",
  "3.10 Quantitative Aspect of Electrolysis",
  "3.11 Some Commercial Cells (Batteries)",
  "3.12 Corrosion",
  "• Self Assessment and Competition File"
];

export const CHEMICAL_KINETICS_SUBTOPICS = [
  "4.1 Reaction Rate, its Measurement and its Dependence on Various Factors",
  "4.2 Dependence of Reaction Rate on Concentration of Reactants",
  "4.3 Zero Order Reactions",
  "4.4 First Order Reactions",
  "4.5 Experimental Determination of Rate Law, Rate Constant and Order of Reaction",
  "4.6 Dependence of Reaction Rate on Temperature",
  "4.7 Molecularity of a Reaction",
  "4.8 Mechanism of a Reaction",
  "• Self Assessment and Competition File"
];

export const SURFACE_CHEMISTRY_SUBTOPICS = [
  "5.1 Adsorption",
  "5.2 Catalysis",
  "5.3 The Colloidal State",
  "5.4 Emulsions",
  "• Self Assessment and Competition File"
];

export const ISOLATION_OF_ELEMENTS_SUBTOPICS = [
  "6.1 Mode of Occurrence of Elements in Nature",
  "6.2 Extraction of Metals",
  "6.3 Concentration of Ores",
  "6.4 Extraction of Crude Metal from the Concentrated Ore",
  "6.5 Thermodynamic Principles of Metallurgy",
  "6.6 Electrochemical Principles of Metallurgy",
  "6.7 Extraction of Non-Metals and Metals by Oxidation",
  "6.8 Refining of the Crude Metal",
  "6.9 Uses of Aluminium, Copper, Zinc, Iron and Silver",
  "• Self Assessment and Competition File"
];

export const P_BLOCK_ELEMENTS_SUBTOPICS = [
  "7.1 Group 15 (Group V A) Elements : The Nitrogen Family",
  "7.2 Group 16 Elements : Oxygen Family",
  "7.3 Group 17 Elements : The Halogen Family",
  "7.4 Group 18 Elements : The Noble Gases",
  "• Self Assessment and Competition File"
];

export const D_AND_F_BLOCK_SUBTOPICS = [
  "8.1 The Transition Elements or d-Block Elements",
  "8.2 The Inner Transition Elements or f-Block (4f And 5f) Elements",
  "• Self Assessment and Competition File"
];

export const COORDINATION_COMPOUNDS_SUBTOPICS = [
  "9.1 Coordination Compounds and Some Important Terms Used in Coordination Chemistry",
  "9.2 Nomenclature of Coordination Compounds",
  "9.3 Isomerism in Coordination Compounds",
  "9.4 Bonding in Coordination Compounds",
  "9.5 Stability of Coordination Compounds in Solution (Stability Constant)",
  "9.6 Importance and Applications (Uses) of Coordination Compounds",
  "• Self Assessment and Competition File"
];

export const HALOALKANES_HALOARENES_SUBTOPICS = [
  "10.1 Classification of Halogen Derivatives of Hydrocarbons",
  "10.2 Haloalkanes or Alkyl Halides",
  "10.3 Polyhalogen Compounds",
  "10.4 Haloarenes",
  "• Self Assessment and Competition File"
];

export const ALCOHOLS_PHENOLS_ETHERS_SUBTOPICS = [
  "11.1 Classification of Hydroxy Derivatives",
  "11.2 Alcohols",
  "11.3 Phenols",
  "11.4 Some Commercially Important Monohydric Alcohols and Phenols",
  "11.5 Ethers",
  "• Self Assessment and Competition File"
];

export const ALDEHYDES_KETONES_CARBOXYLIC_SUBTOPICS = [
  "12.1 Aldehydes and Ketones",
  "12.2 Commercially Important Aldehydes and Ketones",
  "12.3 Distinction between Aldehydes and Ketones",
  "12.4 Carboxylic Acids",
  "12.5 Some Commercially Important Carboxylic Acids",
  "• Self Assessment and Competition File"
];

export const AMINES_NITROGEN_COMPOUNDS_SUBTOPICS = [
  "13.1 Cyanides and Isocyanides",
  "13.2 Amines",
  "13.3 Diazonium Salts",
  "• Self Assessment and Competition File"
];

export const BIOMOLECULES_CHEMISTRY_SUBTOPICS = [
  "14.1 Carbohydrates",
  "14.2 Proteins",
  "14.3 Enzymes",
  "14.4 Hormones",
  "14.5 Nucleic Acids",
  "14.6 Vitamins",
  "• Self Assessment and Competition File"
];

export const POLYMERS_SUBTOPICS = [
  "15.1 Polymers : Definition and Some Related Terms",
  "15.2 Classification of Polymers",
  "15.3 General Methods and Mechanism (Principle) of Polymerisation",
  "15.4 Some Commercially Important Polymers",
  "15.5 Biodegradable Polymers",
  "• Self Assessment and Competition File"
];

export const CHEMISTRY_EVERYDAY_LIFE_SUBTOPICS = [
  "16.1 Therapeutic Action of Different Classes of Drugs",
  "16.2 Chemicals in Food",
  "16.3 Cleansing Agents (Soaps and Synthetic Detergents)",
  "• Self Assessment and Competition File"
];

export const CHEMISTRY_APPENDICES_SUBTOPICS = [
  "Appendix A: Name Reactions (Mechanism, Reagents, Solved Transformation Rules)",
  "Appendix B: Interconversion of Organic Compounds (Aliphatic & Aromatic Roadmaps)",
  "Appendix C: Physical Constants (Fundamental Atomic, Thermodynamic & Equilibrium Tables)",
  "• Quick Revision & Synthesis Cheat Sheets"
];

export const BIOLOGY_CBSE_LESSONS = [
  "1. Sexual Reproduction in Flowering Plants",
  "2. Human Reproduction",
  "3. Reproductive Health",
  "4. Principles of Inheritance and Variation",
  "5. Molecular Basis of Inheritance",
  "6. Evolution",
  "7. Human Health and Disease",
  "8. Microbes in Human Welfare",
  "9. Biotechnology: Principles and Processes",
  "10. Biotechnology and its Applications",
  "11. Organisms and Populations",
  "12. Ecosystem",
  "13. Biodiversity and Conservation"
];

export const END_OF_BIPOLARITY_SUBTOPICS = [
  "What was the Soviet System?",
  "Gorbachev and the Disintegration",
  "Reasons for Soviet Disintegration",
  "Consequences of Disintegration",
  "Shock Therapy in Post-Communist Regimes",
  "Tensions and Conflicts in Former Soviet Republics"
];

export const CONTEMPORARY_CENTRES_POWER_SUBTOPICS = [
  "European Union (EU)",
  "Association of South East Asian Nations (ASEAN)",
  "Rise of Chinese Economy",
  "India-China Relations",
  "Japan and South Korea as New Centres"
];

export const CONTEMPORARY_SOUTH_ASIA_SUBTOPICS = [
  "The Military and Democracy in Pakistan",
  "Democracy in Bangladesh",
  "Monarchy and Democracy in Nepal",
  "Ethnic Conflict and Democracy in Sri Lanka",
  "India-Pakistan Conflicts",
  "India and its Neighbours"
];

export const INTERNATIONAL_ORGANIZATIONS_SUBTOPICS = [
  "Why International Organizations?",
  "Evolution of the UN",
  "Reform of the UN after the Cold War",
  "Jurisdiction of the UN",
  "India and the UN Reforms",
  "UN in a Unipolar World"
];

export const SECURITY_CONTEMPORARY_WORLD_SUBTOPICS = [
  "What is Security?",
  "Traditional Notions: External and Internal",
  "Non-Traditional Notions: Human Security and Global Security",
  "New Sources of Threats (Terrorism, Health, Poverty)",
  "India's Security Strategy"
];

export const ENVIRONMENT_NATURAL_RESOURCES_SUBTOPICS = [
  "Environmental Concerns in Global Politics",
  "Global Commons",
  "Common but Differentiated Responsibilities",
  "India's Stand on Environmental Issues",
  "Environmental Movements",
  "Resource Geopolitics"
];

export const GLOBALIZATION_POL_SUBTOPICS = [
  "Concept of Globalization",
  "Causes of Globalization",
  "Political, Economic and Cultural Consequences",
  "India and Globalization",
  "Resistance to Globalization"
];

export const CHALLENGES_NATION_BUILDING_SUBTOPICS = [
  "Challenges for the New Nation",
  "Three Challenges",
  "Partition: Process and Consequences",
  "Integration of Princely States",
  "Sardar Vallabhbhai Patel's Role",
  "Reorganization of States"
];

export const ERA_ONE_PARTY_DOMINANCE_SUBTOPICS = [
  "Challenge of Building Democracy",
  "Congress Dominance in First Three Elections",
  "Nature of Congress Dominance",
  "Emergence of Opposition Parties"
];

export const POLITICS_PLANNED_DEVELOPMENT_SUBTOPICS = [
  "Political Contestation over Development",
  "Idea of Planning and Planning Commission",
  "The First and Second Five Year Plans",
  "Key Controversies (Agriculture vs Industry)",
  "NITI Aayog"
];

export const INDIA_EXTERNAL_RELATIONS_SUBTOPICS = [
  "International Context of India's Foreign Policy",
  "Policy of Non-Alignment",
  "Nehru's Role",
  "Afro-Asian Unity",
  "Peace and Conflict with China (1962)",
  "Wars and Peace with Pakistan (1965, 1971)",
  "India's Nuclear Policy"
];

export const CRISIS_DEMOCRATIC_ORDER_SUBTOPICS = [
  "Background to Emergency",
  "Economic Context",
  "Gujarat and Bihar Movements",
  "Conflict with Judiciary",
  "Declaration of Emergency (1975)",
  "Consequences and Lessons of Emergency"
];

export const DEMOGRAPHIC_STRUCTURE_SUBTOPICS = [
  "Theories and Concepts in Demography",
  "Malthusian Theory of Population Growth",
  "Theory of Demographic Transition",
  "Common Concepts and Indicators",
  "Size and Growth of India's Population",
  "Age Structure of the Indian Population",
  "The Declining Sex Ratio",
  "Literacy and Rural-Urban Variations"
];

export const SOCIAL_INSTITUTIONS_SUBTOPICS = [
  "Caste and the Caste System",
  "Caste in the Past and Present",
  "Tribal Communities",
  "Classifications of Tribal Societies",
  "Family and Kinship",
  "Forms of Family",
  "The Household as a Unit"
];

export const SOCIAL_INEQUALITY_SUBTOPICS = [
  "Social Inequality and Social Stratification",
  "Caste as a System of Hierarchy",
  "Tribals and their Struggles",
  "The Struggle for Women's Equality",
  "The Protection of Minority Rights",
  "The Differently Abled and their Challenges"
];

export const CULTURAL_DIVERSITY_SUBTOPICS = [
  "Cultural Diversity and the Indian Nation-State",
  "Regionalism in the Indian Context",
  "The Nation-State and Religion",
  "Secularism and Communalism",
  "State and Civil Society"
];

export const STRUCTURAL_CHANGE_SUBTOPICS = [
  "Understanding Colonialism",
  "Urbanization and Industrialization",
  "The Impact of British Rule",
  "The Emergence of a National Economy"
];

export const CULTURAL_CHANGE_SUBTOPICS = [
  "Sanskritization",
  "Westernization",
  "Modernization",
  "Secularization",
  "Social Reform Movements"
];

export const RURAL_SOCIETY_CHANGE_SUBTOPICS = [
  "Agrarian Structure and Social Relations",
  "Land Reforms in Post-Independence India",
  "The Green Revolution and its Social Consequences",
  "Transformation in Rural Society",
  "Circulation of Labour and Globalization"
];

export const INDUSTRIAL_SOCIETY_CHANGE_SUBTOPICS = [
  "Images of Industrial Society",
  "Industrialization in India",
  "The Organization of Work",
  "Working Conditions in Industries",
  "Home-Based Work and Outsourcing"
];

export const SOCIAL_MOVEMENTS_SUBTOPICS = [
  "Features of Social Movements",
  "Types of Social Movements",
  "Ecological Movements",
  "Class-Based Movements (Peasants, Workers)",
  "Caste-Based Movements (Dalit, Backward Class)",
  "The Women's Movement",
  "Tribal Movements"
];

export const PSYCH_VARIATIONS_SUBTOPICS = [
  "Individual Differences in Human Functioning",
  "Assessment of Psychological Attributes",
  "Intelligence: Theories and Types",
  "Culture and Intelligence",
  "Emotional Intelligence",
  "Special Abilities: Aptitude and Creativity"
];

export const SELF_PERSONALITY_SUBTOPICS = [
  "Concept of Self",
  "Cognitive and Behavioural Aspects of Self",
  "Culture and Self",
  "Concept of Personality",
  "Major Approaches to Personality",
  "Assessment of Personality"
];

export const LIFE_CHALLENGES_SUBTOPICS = [
  "Nature and Types of Stress",
  "Effects of Stress on Health",
  "Coping with Stress",
  "Promoting Positive Health and Well-being"
];

export const PSYCH_DISORDERS_SUBTOPICS = [
  "Concepts of Abnormality and Psychological Disorders",
  "Classification of Psychological Disorders",
  "Factors Underlying Abnormal Behaviour",
  "Major Psychological Disorders"
];

export const THERAPEUTIC_APPROACHES_SUBTOPICS = [
  "Nature and Process of Psychotherapy",
  "Types of Therapies",
  "Rehabilitation of the Mentally Ill"
];

export const ATTITUDE_SOCIAL_COGNITION_SUBTOPICS = [
  "Explaining Social Behaviour",
  "Nature and Components of Attitudes",
  "Attitude Change",
  "Prejudice and Discrimination",
  "Strategies for Handling Prejudice"
];

export const SOCIAL_INFLUENCE_GROUPS_SUBTOPICS = [
  "Nature and Formation of Groups",
  "Types of Groups",
  "Influence of Group on Individual Behaviour",
  "Conformity, Compliance, and Obedience",
  "Cooperation and Competition"
];

export const MACRO_INTRO_SUBTOPICS = [
  "Emergence of Macroeconomics",
  "Context of the Great Depression",
  "Keynesian vs Classical Economics",
  "Structure of Macroeconomics"
];

export const NATIONAL_INCOME_SUBTOPICS = [
  "Some Basic Concepts of Macroeconomics",
  "Circular Flow of Income (Two-Sector Model)",
  "Aggregates Related to National Income",
  "GDP, GNP, NDP, NNP at Market Price & Factor Cost",
  "Methods of Calculating National Income",
  "Value Added Method",
  "Income Method",
  "Expenditure Method",
  "Real vs Nominal GDP",
  "GDP and Welfare"
];

export const MONEY_BANKING_SUBTOPICS = [
  "Money: Meaning and Functions",
  "Demand and Supply of Money",
  "Money Creation by Commercial Banks",
  "Central Bank and its Functions",
  "Monetary Policy Instruments (Repo, Reverse Repo, CRR, SLR)"
];

export const INCOME_EMPLOYMENT_SUBTOPICS = [
  "Aggregate Demand and its Components",
  "Propensity to Consume and Save",
  "Short-Run Fixed Price Analysis",
  "Equilibrium Output",
  "Investment Multiplier and its Working",
  "Excess and Deficient Demand",
  "Measures to Correct Excess/Deficient Demand"
];

export const GOVT_BUDGET_SUBTOPICS = [
  "Meaning and Objectives of Government Budget",
  "Components of Budget: Revenue and Capital",
  "Revenue and Capital Receipts",
  "Revenue and Capital Expenditure",
  "Measures of Government Deficit",
  "Fiscal, Revenue and Primary Deficit"
];

export const BALANCE_PAYMENTS_SUBTOPICS = [
  "Meaning and Components of BOP",
  "Current and Capital Account",
  "Foreign Exchange Market",
  "Fixed vs Flexible Exchange Rates",
  "Determination of Exchange Rate",
  "Merits and Demerits of Different Systems"
];

export const INDIAN_ECON_EVE_SUBTOPICS = [
  "Low Level of Economic Development",
  "Agricultural Sector during Colonialism",
  "Industrial Sector and De-industrialization",
  "Foreign Trade and Drain of Wealth",
  "Demographic Profile and Infrastructure"
];

export const INDIAN_ECON_1950_1990_SUBTOPICS = [
  "The Goals of Five Year Plans",
  "Agriculture: Land Reforms and Green Revolution",
  "Industry: IPR 1956 and SSI",
  "Trade Policy: Import Substitution"
];

export const LPG_APPRAISAL_SUBTOPICS = [
  "Background of Reforms (1991)",
  "Liberalisation, Privatisation, Globalisation",
  "Indian Economy during Reforms",
  "An Appraisal of LPG Policies"
];

export const HUMAN_CAPITAL_SUBTOPICS = [
  "What is Human Capital?",
  "Sources of Human Capital",
  "Human Capital and Economic Growth",
  "Human Capital vs Human Development",
  "State of Education Sector in India"
];

export const RURAL_DEV_ECON_SUBTOPICS = [
  "What is Rural Development?",
  "Credit and Marketing in Rural Areas",
  "Diversification into Productive Activities",
  "Sustainable Development and Organic Farming"
];

export const EMPLOYMENT_ISSUES_SUBTOPICS = [
  "Workers and Employment",
  "Participation of People in Employment",
  "Self-Employed and Hired Workers",
  "Growth and Changing Structure of Employment",
  "Informalisation of Indian Workforce",
  "Unemployment and Government Policy"
];

export const SUSTAINABLE_DEV_SUBTOPICS = [
  "Environment and Sustainable Development",
  "Functions and Role of Environment",
  "State of India's Environment",
  "Sustainable Development Strategies"
];

export const COMPARATIVE_DEV_SUBTOPICS = [
  "Development Strategies of India, Pakistan and China",
  "Successive Five Year Plans",
  "Demographic Indicators",
  "GDP and Sectoral Growth",
  "Human Development Indicators"
];

export const ISC_PSYCH_INTELLIGENCE_SUBTOPICS = [
  "Definition of Intelligence",
  "Theories of Intelligence: Spearman, Thurstone, Sternberg, Gardner",
  "Individual Differences in Intelligence",
  "Psychological Testing and Assessment",
  "Emotional Intelligence",
  "Aptitude and Creativity"
];

export const ISC_PSYCH_PERSONALITY_SUBTOPICS = [
  "Meaning and Definition of Personality",
  "Theories of Personality: Type and Trait Approaches",
  "Psychoanalytic Theory (Freud)",
  "Post-Freudian Approaches",
  "Humanistic Approach (Maslow, Rogers)",
  "Assessment of Personality: Projective and Non-Projective"
];

export const ISC_PSYCH_LIFESPAN_SUBTOPICS = [
  "Meaning of Development",
  "Stages of Development: Prenatal, Infancy, Childhood",
  "Adolescence: Physical, Cognitive and Social Development",
  "Adulthood and Old Age",
  "Influence of Environment and Heredity"
];

export const ISC_PSYCH_STRESS_HEALTH_SUBTOPICS = [
  "Concept of Stress",
  "Types of Stress and Stressors",
  "Effects of Stress on Health",
  "Coping Strategies for Stress",
  "Promoting Positive Health and Well-being"
];

export const ISC_PSYCH_DISORDERS_THERAPY_SUBTOPICS = [
  "Concept of Abnormality",
  "Classification of Psychological Disorders (DSM/ICD)",
  "Major Disorders: Anxiety, Mood, Schizophrenia",
  "Behavioural and Developmental Disorders",
  "Types of Psychotherapy: CBT, Client-Centred, Biomedical"
];

export const ISC_PSYCH_SOCIAL_THOUGHT_SUBTOPICS = [
  "Social Cognition and Schema",
  "Attribution Process",
  "Nature and Formation of Attitudes",
  "Attitude Change",
  "Prejudice and Discrimination"
];

export const ISC_PSYCH_SOCIAL_INFLUENCE_SUBTOPICS = [
  "Conformity, Compliance and Obedience",
  "Group Dynamics and Formation",
  "Leadership Styles",
  "Conflict and Cooperation",
  "Social Facilitation and Social Loafing"
];

export const ISC_BIO_REPRODUCTION_SUBTOPICS = [
  "Reproduction in Organisms",
  "Sexual Reproduction in Flowering Plants",
  "Human Reproduction",
  "Reproductive Health"
];

export const ISC_BIO_GENETICS_SUBTOPICS = [
  "Principles of Inheritance and Variation",
  "Molecular Basis of Inheritance",
  "Evolution"
];

export const ISC_BIO_WELFARE_SUBTOPICS = [
  "Human Health and Disease",
  "Microbes in Human Welfare"
];

export const ISC_BIO_BIOTECH_SUBTOPICS = [
  "Biotechnology: Principles and Processes",
  "Biotechnology and its Applications"
];

export const ISC_BIO_ECOLOGY_SUBTOPICS = [
  "Organisms and Populations",
  "Ecosystem",
  "Biodiversity and Conservation",
  "Environmental Issues"
];

export const BIOLOGY_ISC_LESSONS = [
  "1. REPRODUCTION: 16 Learning Modules, Plant Reproduction (5), Human Reproduction (6), Reproductive Health (5)",
  "2. GENETICS AND EVOLUTION: 15 Learning Modules, Mendelian Deviations (4), Chromosomes & Disorders (4), Molecular Basis (4), Evolution (3)",
  "3. BIOLOGY AND HUMAN WELFARE: 14 Learning Modules, Health & Disease (7), Microbes (7)",
  "4. BIOTECHNOLOGY AND ITS APPLICATIONS: 10 Learning Modules, Principles & Processes (5), Applications (5)",
  "5. ECOLOGY AND ENVIRONMENT: 15 Learning Modules, Populations (5), Ecosystems (5), Biodiversity (5)",
  "6. PRACTICAL EVALUATION WORK: 30 Learning Modules, Core Experiments (15), Spotting Exam (10), Project & File (5)"
];
export const ISC_ECON_MICRO_SUBTOPICS = [
  "Introduction to Microeconomics",
  "Theory of Consumer Behaviour",
  "Production and Costs",
  "Theory of the Firm under Perfect Competition",
  "Theory of the Firm under Imperfect Competition"
];

export const ISC_ECON_MACRO_SUBTOPICS = [
  "National Income and Related Aggregates",
  "Determination of Income and Employment",
  "Money and Banking",
  "Government Budget",
  "Balance of Payments"
];

export const ECONOMICS_ISC_LESSONS = [
  "1. Microeconomics",
  "2. Macroeconomics"
];

export const RECENT_DEVELOPMENTS_POL_SUBTOPICS = [
  "Context of the 1990s",
  "Era of Coalitions",
  "Alliance Politics (NDA and UPA)",
  "Mandal Issues and Implementation",
  "Communalism, Secularism, Democracy",
  "Emergence of a New Consensus"
];

export const HUMAN_GEOGRAPHY_NATURE_SUBTOPICS = [
  "Nature of Human Geography",
  "Scope of Human Geography",
  "Naturalisation of Humans",
  "Humanisation of Nature",
  "Determinism vs Possibilism"
];

export const WORLD_POPULATION_SUBTOPICS = [
  "Distribution and Density",
  "Factors influencing Distribution",
  "Population Growth and Components",
  "Demographic Transition Theory",
  "Population Control Measures"
];

export const HUMAN_DEVELOPMENT_GEOG_SUBTOPICS = [
  "Growth vs Development",
  "Four Pillars of Human Development",
  "Approaches to Human Development",
  "Human Development Index (HDI)",
  "International Comparisons"
];

export const PRIMARY_ACTIVITIES_SUBTOPICS = [
  "Hunting and Gathering",
  "Pastoralism (Nomadic & Commercial)",
  "Agriculture (Subsistence & Commercial)",
  "Plantation Agriculture",
  "Extensive Commercial Grain Cultivation",
  "Mixed Farming",
  "Mining"
];

export const SECONDARY_ACTIVITIES_SUBTOPICS = [
  "Manufacturing and Industries",
  "Classification of Industries",
  "Large Scale Manufacturing",
  "Footloose Industries",
  "High-Tech Industries"
];

export const TERTIARY_QUATERNARY_SUBTOPICS = [
  "Trade and Commerce",
  "Transport and Communication Services",
  "Tourism as a Service",
  "Quaternary and Quinary Activities",
  "Outsourcing and Digital Divide"
];

export const TRANSPORT_COMMUNICATION_SUBTOPICS = [
  "Land Transport (Roads & Railways)",
  "Water Transport (Inland & Oceanic)",
  "Air Transport",
  "Pipelines",
  "Satellite Communication",
  "Cyber Space"
];

export const INTERNATIONAL_TRADE_GEOG_SUBTOPICS = [
  "Basis of International Trade",
  "Types and Balance of Trade",
  "World Trade Organization (WTO)",
  "Regional Trade Blocs",
  "Gateways of International Trade (Ports)"
];

export const HUMAN_SETTLEMENTS_GEOG_SUBTOPICS = [
  "Rural and Urban Settlements",
  "Classification of Urban Settlements",
  "Functional Classification of Towns",
  "Problems of Human Settlements",
  "Urbanization Trends"
];

export const INDIA_POPULATION_GEOG_SUBTOPICS = [
  "Distribution and Density in India",
  "Population Growth and Composition",
  "Linguistic and Religious Composition",
  "Rural-Urban Composition",
  "Occupational Structure"
];

export const BRICKS_BEADS_BONES_SUBTOPICS = [
  "The Harappan Civilisation",
  "Archaeological Finds and Interpretations",
  "Subsistence Strategies",
  "Social Differences and Craft Production",
  "Finding out about Trade and Communication"
];

export const KINGS_FARMERS_TOWNS_SUBTOPICS = [
  "Early States and Economies (c.600 BCE-600 CE)",
  "The Mauryan Empire",
  "New Notions of Kingship",
  "Towns and Trade",
  "Deciphering Brahmi and Kharosthi"
];

export const KINSHIP_CASTE_CLASS_SUBTOPICS = [
  "Early Societies (c.600 BCE-600 CE)",
  "Social Histories and the Mahabharata",
  "Rules of Marriage and Patriliny",
  "The Caste System and Beyond",
  "Social Mobility and Gender Relations"
];

export const THINKERS_BELIEFS_BUILDINGS_SUBTOPICS = [
  "Cultural Developments (c.600 BCE-600 CE)",
  "Sanchi Stupa and Early Buddhism",
  "The Life and Teachings of the Buddha",
  "Mahayana Buddhism and Puranic Hinduism",
  "Temple Architecture and Sculptures"
];

export const THROUGH_EYES_TRAVELLERS_SUBTOPICS = [
  "Perceptions of Society (c.10th to 17th Century)",
  "Al-Biruni and the Kitab-ul-Hind",
  "Ibn Battuta and the Rihla",
  "Francois Bernier and the Mughal Court",
  "Making Sense of an Alien World"
];

export const BHAKTI_SUFI_TRADITIONS_SUBTOPICS = [
  "Religious Beliefs and Devotional Texts (c.8th to 18th Century)",
  "New Strands in the Fabric of Religion",
  "The Alvars and Nayanars of Tamil Nadu",
  "The Growth of Sufism",
  "Kabir, Guru Nanak, and Mirabai"
];

export const VIJAYANAGARA_EMPIRE_SUBTOPICS = [
  "An Imperial Capital: Vijayanagara (c.14th to 16th Century)",
  "The Discovery of Hampi",
  "Kings and Traders",
  "The Royal Centre and Sacred Centre",
  "The Mahanavami Dibba"
];

export const PEASANTS_ZAMINDARS_STATE_SUBTOPICS = [
  "Agrarian Society and the Mughal Empire",
  "The Village Community",
  "Women in Agrarian Society",
  "Forests and Tribes",
  "The Zamindars and Land Revenue"
];

export const COLONIALISM_COUNTRYSIDE_SUBTOPICS = [
  "Exploring Official Archives",
  "Bengal and the Zamindars",
  "The Hoe and the Plough (Santhals)",
  "A Revolt in the Countryside (Deccan Riots)",
  "The Permanent Settlement"
];

export const REBELS_AND_RAJ_SUBTOPICS = [
  "The Revolt of 1857 and Its Representations",
  "Pattern of the Rebellion",
  "Awadh in Revolt",
  "What the Rebels Wanted",
  "Images of the Revolt"
];

export const MAHATMA_GANDHI_MOVEMENT_SUBTOPICS = [
  "Civil Disobedience and Beyond",
  "The Making and Unmaking of Non-Cooperation",
  "The Salt March",
  "The Last Heroic Days",
  "Knowing Gandhi"
];

export const FRAMING_CONSTITUTION_SUBTOPICS = [
  "The Beginning of a New Era",
  "A Tumultuous Time",
  "Defining Rights",
  "The Powers of the State",
  "The Language of the Nation"
];

export const PYTHON_REVISION_TOUR_SUBTOPICS = [
  "Review of Python Basics",
  "Conditional Statements",
  "Loops and Iterations",
  "Strings, Lists, Tuples",
  "Dictionaries and Sets"
];

export const FUNCTIONS_SUBTOPICS = [
  "Function Definition and Call",
  "Arguments and Parameters",
  "Scope of Variables",
  "Return Values",
  "Recursion"
];

export const FILE_HANDLING_SUBTOPICS = [
  "Types of Files",
  "Text Files: Open, Read, Write",
  "Binary Files: Pickle Module",
  "CSV Files: CSV Module",
  "Exception Handling"
];

export const DATA_STRUCTURES_CS_SUBTOPICS = [
  "Linear Data Structures",
  "Stack Operations (Push/Pop)",
  "Queue Implementation",
  "List as Stack and Queue"
];

export const COMPUTER_NETWORKS_CS_SUBTOPICS = [
  "Evolution of Networking",
  "Network Types (LAN, WAN, MAN)",
  "Network Topologies",
  "Transmission Media",
  "Network Protocols (TCP/IP, HTTP, FTP)",
  "Network Security"
];

export const DATABASE_MANAGEMENT_CS_SUBTOPICS = [
  "Database Concepts",
  "Relational Data Model",
  "Structured Query Language (SQL)",
  "Data Definition Language (DDL)",
  "Data Manipulation Language (DML)"
];

export const INTERFACE_PYTHON_SQL_SUBTOPICS = [
  "Database Connectivity",
  "MySQL Connector",
  "Executing SQL Queries",
  "Fetch Results"
];

export const SOCIETAL_IMPACTS_SUBTOPICS = [
  "Digital Footprint",
  "Net and Communication Etiquettes",
  "Data Protection and Privacy",
  "Cyber Crime and IT Act",
  "E-waste Management"
];

export const SEXUAL_REPRODUCTION_PLANTS_SUBTOPICS = [
  "Introduction",
  "1. Anatomy of Flower and Reproductive Whorls (Androecium and Gynoecium)",
  "2. Microsporangium Structure and Microsporogenesis",
  "3. Pollen Grain Architecture, Viability, and Cryopreservation",
  "4. Megasporogenesis, Ovule Structure, and Female Gametophyte (7-Celled, 8-Nucleate Embryo Sac)",
  "5. Pollination Types: Autogamy, Geitonogamy, and Xenogamy",
  "6. Pollinating Agents: Abiotic (Wind, Water) and Biotic (Insects, Birds, Bats)",
  "7. Outbreeding Devices and Self-Incompatibility Mechanisms",
  "8. Pollen-Pistil Interaction, Pollen Tube Growth, and Artificial Hybridization (Emasculation & Bagging)",
  "9. Double Fertilization: Syngamy and Triple Fusion (PEN Formation)",
  "10. Post-Fertilization: Free-Nuclear & Cellular Endosperm Development",
  "11. Embryogeny: Dicot (Heart-shaped, Torpedo) and Monocot (Scutellum, Coleoptile, Coleorhiza) Embryos",
  "12. Seed Morphology, Albuminous vs Non-Albuminous Seeds, and Seed Dormancy",
  "13. Pericarp & Fruit Types: True Fruits, False Fruits (Apple, Cashew), and Parthenocarpy",
  "14. Apomixis and Polyembryony: Agricultural Significance in Hybrid Seed Production",
  "Solved Conceptual & Numerical Problems (Microspore/Megaspore Division Counts)",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Diagrammatic & Numerical Exercises",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Assertion-Reason & Case-Based Questions, Hints & Detailed Solutions"
];

export const HUMAN_REPRODUCTION_SUBTOPICS = [
  "Introduction",
  "1. Male Reproductive System: Testes, Seminiferous Tubules, Sertoli & Leydig Cells",
  "2. Accessory Ducts and Glands (Seminal Vesicles, Prostate, Bulbourethral Glands)",
  "3. Female Reproductive System: Ovaries, Oviducts (Fallopian Tubes), Uterus, Cervix, Vagina",
  "4. Histology of Mammary Glands and Hormonal Regulation of Milk Synthesis",
  "5. Spermatogenesis: Spermatogonia, Spermatocytes, Spermatids, and Spermiogenesis",
  "6. Sperm Microscopic Structure: Head, Acrosome, Neck, Middle Piece (Mitochondrial Spiral), Tail",
  "7. Oogenesis: Oogonia, Meiotic Arrest at Prophase-I, Secondary Oocyte & Polar Body Formation",
  "8. Folliculogenesis: Primordial, Primary, Secondary, Tertiary (Antrum), and Graafian Follicle",
  "9. Menstrual Cycle Phases: Menstrual, Follicular/Proliferative, Ovulatory Surge, Luteal/Secretory",
  "10. Hormonal Interplay: GnRH, LH, FSH, Estrogen, Progesterone, and Corpus Luteum Regression",
  "11. Capacitation, Acrosome Reaction, Cortical Reaction, and Prevention of Polyspermy",
  "12. Cleavage, Morula, Blastocyst Inner Cell Mass, Trophoblast, and Implantation",
  "13. Placenta Formation, Chorionic Villi, and Endocrine Function (hCG, hPL, Estrogen, Progesterone, Relaxin)",
  "14. Embryonic Germ Layers (Ectoderm, Mesoderm, Endoderm) and Organogenesis Timeline",
  "15. Parturition Reflex (Foetal Ejection Reflex, Oxytocin Cascade) and Lactation (Colostrum)",
  "Solved Conceptual & Quantitative Problems (Ploidy & Chromosome Count per Gametogenic Stage)",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Hormonal Graph & Flowchart Analysis",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Assertion-Reason & Match the Columns, Hints & Solutions"
];

export const REPRODUCTIVE_HEALTH_SUBTOPICS = [
  "Introduction",
  "1. Reproductive and Child Health Care (RCH) Programmes and Community Awareness",
  "2. Amniocentesis Procedure, Karyotyping, Ethical Concerns, and Legal Bans",
  "3. Demographic Growth Trends and Population Explosion Factors in India",
  "4. Ideal Contraceptive Attributes and Natural Birth Control Methods (Periodic Abstinence, Coitus Interruptus, Lactational Amenorrhea)",
  "5. Barrier Methods: Male/Female Condoms, Diaphragms, Cervical Caps, Spermicidal Agents",
  "6. Intrauterine Devices (IUDs): Non-medicated (Lippes Loop), Copper-releasing (CuT, Cu7, Multiload 375), Hormone-releasing (Progestasert, LNG-20)",
  "7. Oral Contraceptive Pills: Combined Pills, Progestogens, and Saheli (Centchroman)",
  "8. Emergency Contraceptives, Subdermal Implants, and Surgical Sterilization (Vasectomy & Tubectomy)",
  "9. Medical Termination of Pregnancy (MTP) Act, Medical vs Surgical Abortion Safety",
  "10. Sexually Transmitted Infections (STIs): Transmission, Symptoms, Complications, and Prevention (Gonorrhea, Syphilis, Chlamydiasis, Genital Herpes, Hepatitis-B, HIV/AIDS)",
  "11. Infertility Causes in Males and Females (Anovulation, Oligospermia, Azoospermia, Tubal Blockage)",
  "12. Assisted Reproductive Technologies (ART): In Vitro Fertilization (IVF) and Test-Tube Baby Program",
  "13. Embryo Transfer Techniques: Zygote Intra-Fallopian Transfer (ZIFT) vs Intra-Uterine Transfer (IUT)",
  "14. Gamete Intra-Fallopian Transfer (GIFT), Intra-Cytoplasmic Sperm Injection (ICSI), and Intra-Uterine Insemination (IUI)",
  "Solved Conceptual & Case-Based Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Case Studies & ART Selection Matrix",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Statement-Based & Matching Questions, Hints & Solutions"
];

export const PRINCIPLES_OF_INHERITANCE_SUBTOPICS = [
  "Introduction",
  "1. Gregor Mendel's Experimental Design on Pisum sativum and 7 Pairs of Contrasting Traits",
  "2. Monohybrid Cross: Law of Dominance and Law of Segregation (Purity of Gametes)",
  "3. Punnett Square Analysis, Genotypic (1:2:1) and Phenotypic (3:1) Ratios, Test Cross vs Back Cross",
  "4. Dihybrid Cross: Law of Independent Assortment and Phenotypic Ratio (9:3:3:1)",
  "5. Incomplete Dominance in Antirrhinum majus (Snapdragon) and Mirabilis jalapa (1:2:1 Ratios)",
  "6. Codominance in Human ABO Blood Groups (IA, IB, i Alleles) and Sickle-Cell Trait",
  "7. Multiple Allelism and Starch Grain Size Expression in Pea Seeds (Pleiotropic Dominance)",
  "8. Polygenic Inheritance: Human Skin Color (Quantitative Traits, Gaussian Distribution)",
  "9. Pleiotropy: Single Gene Influencing Multiple Phenotypic Traits (Phenylketonuria)",
  "10. Chromosomal Theory of Inheritance (Sutton and Boveri Parallelism between Genes and Chromosomes)",
  "11. T.H. Morgan's Drosophila melanogaster Experiments: Sex-Linked Traits, Linkage, and Recombination",
  "12. Chromosome Mapping: Alfred Sturtevant's Recombination Frequency (1 Map Unit = 1% Recombination)",
  "13. Sex Determination Systems: XX-XY (Humans/Drosophila), XX-XO (Grasshopper), ZZ-ZW (Birds), Haplodiploidy (Honeybees)",
  "14. Mutations: Point Mutation (Sickle-cell anemia), Frame-shift, Chromosomal Aberrations, and Mutagens",
  "15. Pedigree Analysis Symbols and Standard Inheritance Patterns (Autosomal Dominant/Recessive, X-Linked)",
  "16. Mendelian Disorders: Haemophilia, Sickle-Cell Anemia, Thalassemia, Phenylketonuria, Cystic Fibrosis, Color Blindness",
  "17. Chromosomal Disorders: Aneuploidy, Polyploidy, Down's Syndrome (Trisomy 21), Klinefelter's Syndrome (47, XXY), Turner's Syndrome (45, XO)",
  "Solved Numerical & Genetic Cross Problems (Punnett Squares, Probability, Recombination Frequencies, Pedigree Trees)",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Genetics Crosses & Pedigree Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Pedigree & Probability Numericals, Hints & Solutions"
];

export const MOLECULAR_BASIS_INHERITANCE_SUBTOPICS = [
  "Introduction",
  "1. Chemical Structure of Polynucleotide Chain: Nitrogenous Bases, Pentose Sugars, Phosphate Group, Phosphodiester and Glycosidic Bonds",
  "2. Double Helix Model of B-DNA (Watson & Crick), Complementary Base Pairing, Anti-parallel Strands, Pitch & Dimensions",
  "3. Erwin Chargaff's Equimolar Rules ([A]+[G] = [T]+[C]) and DNA Quantitation",
  "4. Packaging of DNA: Histone Octamer, Nucleosome Model, 10 nm and 30 nm Chromatin Fibers, Euchromatin vs Heterochromatin",
  "5. Search for Genetic Material: Frederick Griffith's Transformation Experiment (Streptococcus pneumoniae S-strain vs R-strain)",
  "6. Avery, MacLeod, and McCarty Biochemical Proof of DNA as the Transforming Principle",
  "7. Alfred Hershey and Martha Chase Bacteriophage Experiment using 35S and 32P Radioactive Isotope Tracers",
  "8. RNA World Hypothesis, Catalytic RNA (Ribozymes), RNA vs DNA Stability and Mutation Rates",
  "9. Semiconservative DNA Replication: Matthew Meselson and Franklin Stahl 15N/14N Heavy Isotope CsCl Density Gradient Experiment",
  "10. Replication Machinery: Origin of Replication (ori), Helicase, Single-Stranded Binding Proteins, Topoisomerase/Gyrase",
  "11. DNA Polymerase III Mechanics: Leading Strand Continuous Synthesis vs Lagging Strand Okazaki Fragments and DNA Ligase",
  "12. Transcription Unit: Promoter, Structural Gene, Terminator, Template Strand (3'->5') vs Coding Strand (5'->3')",
  "13. Transcription in Prokaryotes vs Eukaryotes: RNA Polymerase I, II, III, Cistrons (Monocistronic vs Polycistronic)",
  "14. Post-Transcriptional Processing in Eukaryotes: hnRNA Precursor, 7-Methylguanosine Capping, Poly-A Tailing, Intron Splicing (Spliceosome)",
  "15. Genetic Code Characteristics: Triplet Nature, Degeneracy, Unambiguousness, Non-overlapping, Universal, AUG Dual Role",
  "16. Transfer RNA (tRNA) Adaptor Molecule: Secondary Clover-leaf Structure, Anticodon Loop, Amino Acid Acceptor Stem, Tertiary L-shape",
  "17. Translation Mechanism: Aminoacylation (Charging) of tRNA, Ribosomal Subunits (A, P, E Sites), Initiation, Elongation, Peptide Bond Formation, Termination",
  "18. Regulation of Gene Expression: Operon Concept, Francois Jacob and Jacques Monod Lac Operon Model (i-gene, Promoter, Operator, z, y, a Genes, Inducer Allolactose)",
  "19. Human Genome Project (HGP): Goals, Methodologies (ESTs vs Sequence Annotation), Vectors (BAC, YAC), Automated Sanger Sequencing, Key Findings",
  "20. DNA Fingerprinting: Variable Number Tandem Repeats (VNTRs), Satellite DNA (Micro/Minisatellites), Restriction Digestion, Southern Blotting, Probing, and PCR Amplification",
  "Solved Molecular & Sequence Analysis Problems (Nucleotide percentage calculations, mRNA sequence translation, Lac Operon state deduction)",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Sequence & Molecular Diagram Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Molecular Sequence & Operon Problem Sets, Hints & Solutions"
];

export const EVOLUTION_SUBTOPICS = [
  "Introduction",
  "1. Big Bang Theory, Stellar Evolution, and Primitive Earth Reducing Atmosphere (Lack of Free O2)",
  "2. Origin of Life Theories: Special Creation, Spontaneous Generation (Abiogenesis), Panspermia, Oparin-Haldane Biochemical Evolution",
  "3. Stanley Miller and Harold Urey Experiment: Electric Discharge Apparatus Synthesizing Amino Acids and Organic Compounds",
  "4. Morphological and Anatomical Evidence: Homologous Organs and Divergent Evolution (Forelimbs of Mammals, Thorns of Bougainvillea vs Tendrils of Cucurbita)",
  "5. Analogous Organs and Convergent Evolution (Wings of Birds vs Insects, Eye of Octopus vs Mammals, Sweet Potato vs Potato)",
  "6. Palaeontological Evidence: Fossil Formation, Stratigraphic Dating, Connecting Links (Archaeopteryx)",
  "7. Embryological Evidence: Ernst Haeckel's Biogenetic Law ('Ontogeny Recapitulates Phylogeny') and Karl Ernst von Baer's Rebuttal",
  "8. Biochemical and Molecular Evidence: Protein and Gene Homology Across Taxa",
  "9. Adaptive Radiation: Darwin's Finches in Galapagos Islands and Australian Marsupial Radiation",
  "10. Biological Evolution by Natural Selection: Industrial Melanism in Peppered Moth (Biston betularia) and Antibiotic/Pesticide Resistance",
  "11. Theories of Evolution: Jean-Baptiste Lamarck (Use and Disuse of Organs) vs Charles Darwin (Branching Descent and Natural Selection)",
  "12. Mechanism of Evolution: Hugo de Vries Mutation Theory on Oenothera lamarckiana (Saltation vs Darwinian Gradual Variations)",
  "13. Hardy-Weinberg Principle of Genetic Equilibrium: Algebraic Equation (p^2 + 2pq + q^2 = 1)",
  "14. Factors Disrupting Hardy-Weinberg Equilibrium: Gene Migration/Flow, Genetic Drift, Mutation, Genetic Recombination, Natural Selection",
  "15. Modes of Natural Selection: Stabilizing Selection (Peak Narrows), Directional Selection (Peak Shifts), Disruptive Selection (Two Peaks Form)",
  "16. Genetic Drift Mechanisms: Founder Effect and Bottleneck Effect",
  "17. Geological Time Scale: Eras (Precambrian, Palaeozoic, Mesozoic, Cenozoic), Periods, Epochs, and Evolutionary Progression of Plants and Animals",
  "18. Origin and Evolution of Man: Chronological Lineage (Dryopithecus, Ramapithecus, Australopithecus, Homo habilis, Homo erectus, Neanderthal Man, Homo sapiens)",
  "Solved Population Genetics & Hardy-Weinberg Numerical Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Evolutionary Tree & Population Genetics Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Hardy-Weinberg & Human Evolution Problem Sets, Hints & Solutions"
];

export const HUMAN_HEALTH_DISEASE_SUBTOPICS = [
  "Introduction",
  "1. Concept of Health, Disease Etiology, Infectious vs Non-Infectious Diseases",
  "2. Bacterial Diseases in Humans: Typhoid (Salmonella typhi, Widal Test) and Pneumonia (Streptococcus pneumoniae, Haemophilus influenzae)",
  "3. Viral Diseases: Common Cold (Rhinovirus), Dengue Fever, Chikungunya",
  "4. Protozoan Diseases: Malaria (Plasmodium vivax/falciparum/malariae Life Cycle in Human Host and Female Anopheles Vector) and Amoebic Dysentery (Entamoeba histolytica)",
  "5. Helminthic Diseases: Ascariasis (Ascaris lumbricoides) and Elephantiasis/Filariasis (Wuchereria bancrofti and W. malayi)",
  "6. Fungal Diseases: Ringworm (Microsporum, Trichophyton, Epidermophyton) Symptoms and Transmission",
  "7. Innate Immunity Barriers: Physical (Skin, Mucosa), Physiological (Acid, Tears, Saliva), Cellular (PMNL, Monocytes, Macrophages), Cytokine (Interferons)",
  "8. Acquired Immunity Features: Memory, Specificity, Discrimination of Self vs Non-self, B-Lymphocytes (Antibody Factory) and T-Lymphocytes (Cellular Response)",
  "9. Antibody Structure: Immunoglobulin Chains (H2L2), Antigen-Binding Site (Fab), Fc Region, Classes (IgG, IgA, IgM, IgE, IgD)",
  "10. Humoral Immune Response vs Cell-Mediated Immunity (CMI) and Role of T-Cells in Organ Transplant Rejection",
  "11. Active vs Passive Immunity, Natural vs Artificial Immunity, Colostrum (IgA) Protection, Tetanus Toxoid, Snake Antivenom",
  "12. Vaccination and Immunization Principles: Primary vs Secondary Immune Response, Recombinant DNA Vaccines (Hepatitis B)",
  "13. Allergies: IgE Antibodies, Mast Cell Histamine/Serotonin Release, Anaphylaxis, Anti-histamines, Steroids",
  "14. Autoimmunity and Autoimmune Diseases: Rheumatoid Arthritis, Myasthenia Gravis, Self-Tolerance Breakdown",
  "15. Immune System Organs: Primary Lymphoid Organs (Bone Marrow, Thymus) and Secondary Lymphoid Organs (Spleen, Lymph Nodes, Tonsils, MALT - Mucosal Associated Lymphoid Tissue)",
  "16. Acquired Immuno-Deficiency Syndrome (AIDS): Causative Agent (HIV Retrovirus Structure), Reverse Transcriptase Enzyme, Infection of Macrophages and Helper T-Lymphocytes (CD4+), ELISA Test, Treatment with Anti-Retroviral Drugs",
  "17. Cancer Biology: Normal Cell Contact Inhibition Loss, Benign vs Malignant Tumors, Metastasis Mechanics, Proto-oncogenes to Oncogenes Conversion, Tumor Suppressor Genes",
  "18. Carcinogens (Physical, Chemical, Biological/Oncogenic Viruses), Diagnosis (Biopsy, MRI, CT, Radiography, Monoclonal Antibodies), Treatment Modalities (Surgery, Radiotherapy, Chemotherapy, Alpha-Interferon Immunotherapy)",
  "19. Drug Abuse: Opioids (Morphine, Heroin/Smack, Receptors in CNS/GI tract), Cannabinoids (Marijuana, Hashish, Charas, Ganja, Receptors in Brain, Cardiovascular Effects), Coca Alkaloids/Cocaine (Erythroxylum coca, Dopamine Transport Inhibition, Hallucinations)",
  "20. Hallucinogens (LSD, Atropa belladonna, Datura), Tobacco Addiction (Nicotine, CO Toxicity), Alcohol Addiction, Adolescent Misuse, Dependence, Withdrawal Syndrome, Prevention Strategies",
  "Solved Clinical, Diagnostic & Epidemiological Case Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Clinical & Pathogen Life Cycle Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Immunology & Oncology Problem Sets, Hints & Solutions"
];

export const MICROBES_HUMAN_WELFARE_SUBTOPICS = [
  "Introduction",
  "1. Microbes in Household Products: Lactic Acid Bacteria (LAB) in Milk Curdling, Coagulation, Vitamin B12 Enrichment, and Gut Pathogen Control",
  "2. Fermentation Applications: Dough Leavening by Baker's Yeast (Saccharomyces cerevisiae), Toddy Production from Palm Sap",
  "3. Cheese Microbes: Swiss Cheese Large Holes by Propionibacterium shermanii (CO2 Production), Roquefort Cheese Ripening by Penicillium roqueforti",
  "4. Microbes in Industrial Fermentation: Fermentors, Alcoholic Beverages (Distilled: Whisky, Brandy, Rum vs Non-distilled: Wine, Beer)",
  "5. Antibiotics: Alexander Fleming Discovery of Penicillin from Penicillium notatum, Ernest Chain and Howard Florey Commercialization during WWII",
  "6. Industrial Organic Acids: Aspergillus niger (Citric Acid), Acetobacter aceti (Acetic Acid), Clostridium butylicum (Butyric Acid), Lactobacillus (Lactic Acid)",
  "7. Commercial Enzymes: Lipases (Detergent Formulations, Stain Removal), Pectinases & Proteases (Juice Clarification), Streptokinase (Clot Buster from Streptococcus for Myocardial Infarction)",
  "8. Bioactive Molecules: Cyclosporin A (Trichoderma polysporum, Immunosuppressive Agent in Organ Transplants) and Statins (Monascus purpureus Yeast, Blood Cholesterol Lowering Agent by Competitive Enzyme Inhibition)",
  "9. Microbes in Sewage Treatment: Primary Treatment (Physical Sequential Filtration and Sedimentation, Primary Sludge and Effluent)",
  "10. Secondary/Biological Treatment: Aeration Tanks, Aerobic Microbes and Flocs (Fungal Filaments + Bacteria), Biological Oxygen Demand (BOD)",
  "11. BOD Concept as a Direct Index of Water Pollution and Organic Matter Content",
  "12. Anaerobic Sludge Digesters: Methanogenic Bacteria producing Biogas (Methane, Hydrogen Sulphide, CO2) and Treated Effluent Discharge into Natural Water Bodies",
  "13. Ganga Action Plan and Yamuna Action Plan Initiatives",
  "14. Biogas Production: Biogas Plant Architecture (10-15 ft Concrete Tank, Floating Cover, Slurry Inlet, Gas Outlet), Role of Methanobacterium in Cattle Dung (Gobar Gas)",
  "15. Microbes as Biocontrol Agents: Organic Farming, Natural Predators (Ladybird Beetle for Aphids, Dragonfly for Mosquitoes)",
  "16. Microbial Biocontrol: Bacillus thuringiensis (Bt) Spores for Caterpillar Control, Trichoderma Fungus for Root Ecosystem Diseases, Baculoviruses (Nucleopolyhedrovirus) for Species-Specific Narrow Spectrum Insecticidal Control",
  "17. Microbes as Biofertilizers: Symbiotic Nitrogen Fixers (Rhizobium in Legume Root Nodules), Free-Living Nitrogen Fixers (Azospirillum, Azotobacter)",
  "18. Mycorrhizae: Symbiotic Fungal Association (Glomus genus) Enhancing Soil Phosphorus Absorption, Drought Resistance, and Root Health",
  "19. Cyanobacteria as Biofertilizers: Anabaena, Nostoc, Oscillatoria in Paddy Fields and Organic Matter Enrichment",
  "Solved Applied & BOD Calculation Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Industrial & STP Process Flowchart Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Industrial Products & Biofertilizer Matching Problems, Hints & Solutions"
];

export const BIOTECHNOLOGY_PRINCIPLES_SUBTOPICS = [
  "Introduction",
  "1. European Federation of Biotechnology (EFB) Definition of Biotechnology",
  "2. Core Principles of Biotechnology: Genetic Engineering (Gene Manipulation) and Chemical Engineering (Sterile Bioprocess Maintenance)",
  "3. Conceptual Development of Recombinant DNA Technology: Construction of First rDNA Molecule by Stanley Cohen and Herbert Boyer (1972) using Salmonella typhimurium Plasmid",
  "4. Tools of Recombinant DNA Technology: Restriction Enzymes (Exonucleases vs Endonucleases), Hind II Discovery",
  "5. Restriction Endonuclease Nomenclature (EcoRI: E. coli RY13), Palindromic Nucleotide Recognition Sequences (5'-GAATTC-3'), Cleavage Mechanism and Sticky Ends",
  "6. DNA Ligase Enzyme, Phosphodiester Bond Synthesis, and Recombinant DNA Formation",
  "7. Separation and Isolation of DNA Fragments: Agarose Gel Electrophoresis, Charge Density, Ethidium Bromide Staining, UV Transillumination, and Elution",
  "8. Cloning Vectors: Essential Features - Origin of Replication (ori) and Copy Number Control",
  "9. Selectable Markers: Antibiotic Resistance Genes (ampR, tetR) for Identifying Recombinants vs Non-recombinants",
  "10. Vector pBR322 Plasmid Map: Restriction Sites (BamHI, SalI, PstI, PvuI, EcoRI, ClaI, HindIII, PvuII) and rop Gene",
  "11. Insertional Inactivation Principle: Blue-White Screening using β-galactosidase Gene (lacZ) and Chromogenic Substrate",
  "12. Vectors for Gene Cloning in Plants: Agrobacterium tumefaciens Ti Plasmid (T-DNA Transformation into Crown Gall) and Disarmed Retroviruses in Animal Cells",
  "13. Competent Host Cell Transformation: Divalent Cation (CaCl2) Treatment, Ice-Heat Shock (42°C)-Ice Method",
  "14. Alternative Transformation Techniques: Microinjection (Direct Injection into Animal Nucleus) and Biolistics / Gene Gun (Gold/Tungsten Microparticles for Plant Cells)",
  "15. Step-by-Step Recombinant DNA Process: Isolation of Genetic Material (Cell Lysis using Lysozyme/Cellulase/Chitinase, RNAse/Protease Digestion, Chilled Ethanol Precipitation)",
  "16. Cutting DNA at Specific Sites, Joining Foreign DNA into Vector using Ligase",
  "17. Polymerase Chain Reaction (PCR) In Vitro Gene Amplification: 3 Steps - Denaturation (94°C), Annealing of Primers (54°C), Extension by Thermostable Taq DNA Polymerase (72°C from Thermus aquaticus), Billion-fold Amplification Calculation",
  "18. Insertion of Recombinant DNA into Host Cell/Organism and Selection of Transformed Cells",
  "19. Expressing Foreign Gene Products: Recombinant Proteins, Continuous Culture System, Exponential Growth Phase Maintenance",
  "20. Bioreactors Architecture: Simple Stirred-Tank Bioreactor vs Sparged Stirred-Tank Bioreactor (Impeller System, Oxygen Delivery, Foam Control, Temperature/pH Sensors, Sampling Ports)",
  "21. Downstream Processing (DSP): Product Separation, Purification, Formulation with Preservatives, Clinical Quality Control Tests and Registration",
  "Solved Recombinant DNA & PCR Numerical/Sequence Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Plasmid Vector & PCR Flowchart Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Plasmid Maps & Restriction Digest Numerical Problems, Hints & Solutions"
];

export const BIOTECHNOLOGY_APPLICATIONS_SUBTOPICS = [
  "Introduction",
  "1. Genetically Modified Organisms (GMOs) Definition and Agricultural Advantages (Enhanced Stress Tolerance, Reduced Chemical Pesticides, Post-Harvest Loss Reduction, Golden Rice enriched with Vitamin A)",
  "2. Pest-Resistant Crops: Bt Cotton and Bacillus thuringiensis Endotoxin",
  "3. Insecticidal Proteins (Cry Proteins: cryIAc & cryIIAb against Cotton Bollworms, cryIAb against Corn Borer)",
  "4. Bt Protoxin Mechanism: Inactive Crystal Protein Solubilization in Alkaline Insect Midgut, Proteolytic Cleavage, Epithelial Binding, Pore Formation, Lysis and Death",
  "5. Nematode Pest Resistance: RNA Interference (RNAi) Cellular Defense Mechanism in Tobacco Plants against Meloidogyne incognita",
  "6. RNAi Process: Double-Stranded RNA (dsRNA) Generation using Agrobacterium Vectors, Dicer Cleavage into siRNA, RISC Complex Assembly, Specific mRNA Complementary Binding and Silencing",
  "7. Medical Biotechnology Applications: Recombinant Therapeutics (30 Approved Worldwide, 12 in India)",
  "8. Genetically Engineered Human Insulin (Humulin): Eli Lilly (1983) Achievement, Recombinant Synthesis of Separate A and B Polypeptide Chains in E. coli, Extraction and Disulfide Bond Linkage",
  "9. Gene Therapy: Concept and First Clinical Trial (1990) on 4-year-old Patient with Adenosine Deaminase (ADA) Deficiency",
  "10. ADA Deficiency Treatments: Enzyme Replacement Therapy (ERT), Bone Marrow Transplantation, and Recombinant Functional ADA cDNA Retroviral Transfection into Patient Lymphocytes",
  "11. Molecular Diagnostics vs Conventional Serology: Early Disease Detection",
  "12. Recombinant DNA Probes and Autoradiography: Single-Stranded DNA/RNA Labeled with Radioactive Isotope Hybridizing to Mutated Genes",
  "13. Polymerase Chain Reaction (PCR) Diagnostics: Detection of Low-Abundance Pathogens (HIV in Asymptomatic Patients, Cancer Mutations)",
  "14. Enzyme-Linked Immunosorbent Assay (ELISA): Antigen-Antibody Binding Principle and Enzymatic Colorimetric Detection",
  "15. Transgenic Animals: Definition, Production Methods (Microinjection, Retroviral Vectors, Embryonic Stem Cells)",
  "16. Purposes of Transgenic Animals: Normal Physiology, Human Disease Models, Biological Products Production (Human alpha-1-antitrypsin for Emphysema, First Transgenic Cow 'Rosie' (1997) Producing 2.4 g/L Human alpha-lactalbumin Enriched Milk)",
  "17. Transgenic Animals for Vaccine Safety Testing (Polio Vaccine Safety in Transgenic Mice) and Chemical Toxicity/Safety Testing",
  "18. Ethical Concerns in Biotechnology: Genetic Engineering Approval Committee (GEAC) Role in Regulating GMO Releases and Public Safety",
  "19. Biopiracy Definition: Unapproved Commercial Exploitation of Bio-resources and Indigenous Knowledge by Multinational Corporations",
  "20. Cases of Biopiracy: US Patent on Indian Basmati Rice (1997), Neem and Turmeric Patent Revocations, Indian Patent Bill Amendments",
  "Solved Bio-Applications & Diagnostic Case Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Clinical & Agricultural Case Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Bio-Therapeutic & Transgenic Model Problem Sets, Hints & Solutions"
];

export const ORGANISMS_POPULATIONS_SUBTOPICS = [
  "Introduction",
  "1. Organism and Environment: Major Biomes of the World (Tropical Rain Forest, Temperate Forest, Coniferous Forest, Desert, Tundra, Sea Coast)",
  "2. Major Abiotic Factors: Temperature (Thermal Tolerance: Eurythermal vs Stenothermal Organisms), Geographical Distribution Limits",
  "3. Water Abiotic Factor: Osmotic Tolerance (Euryhaline vs Stenohaline Species), Marine vs Freshwater Osmoregulation Challenges",
  "4. Light Abiotic Factor: Photoperiodism, Photosynthetic Active Radiation, Stratification in Forests",
  "5. Soil Abiotic Factor: Soil Composition, Grain Size, Aggregation, Water Holding Capacity, pH, Mineral Composition",
  "6. Responses to Abiotic Factors: Regulate (Homeostasis Maintenance through Physiological/Behavioral Means in Mammals)",
  "7. Conformers: Energy Cost of Homeostasis, Thermal Conformation in Small Animals (High Surface-to-Volume Ratio)",
  "8. Migrate: Long-distance Seasonal Migration (Siberian Cranes to Keoladeo National Park, Bharatpur)",
  "9. Suspend: Spores, Seeds, Dormancy, Hibernation (Bears), Aestivation (Snails/Fish), Diapause (Zooplankton)",
  "10. Adaptations: Morphological (Kangaroo Rat Water Conservation, Desert Plant Thick Cuticle & CAM Photosynthetic Pathway), Physiological (Altitude Sickness Compensation), Allen's Rule (Shorter Ears/Limbs in Cold Climate Mammals)",
  "11. Behavioral Adaptations: Desert Lizards Sun Basking and Burrowing Habits",
  "12. Population Attributes: Population Density (N), Birth Rate (Natality), Death Rate (Mortality), Sex Ratio",
  "13. Age Pyramids: Percent Individuals in Pre-reproductive, Reproductive, Post-reproductive Age Groups (Expanding Triangles, Stable Bells, Declining Urns)",
  "14. Population Growth Factors: Natality (B), Mortality (D), Immigration (I), Emigration (E), Equation: N_{t+1} = N_t + [(B + I) - (D + E)]",
  "15. Exponential Population Growth: Unlimited Resource Model, Differential Form (dN/dt = rN), Intrinsic Rate of Natural Increase (r), Integral Form (N_t = N_0 e^{rt}), J-shaped Growth Curve",
  "16. Logistic Population Growth: Limited Resource Model, Carrying Capacity (K), Differential Form (dN/dt = rN[(K-N)/K]), S-shaped / Sigmoid Verhulst-Pearl Logistic Curve",
  "17. Life History Variation Strategies: r-selected Species vs K-selected Species",
  "18. Population Interactions Classification: Mutualism (+/+), Competition (-/-), Predation (+/-), Parasitism (+/-), Commensalism (+/0), Amensalism (-/0)",
  "19. Predation Dynamics: Predators as Energy Conduit, Population Regulation, Prey Defenses (Camouflage, Monarch Butterfly, Calotropis)",
  "20. Competition: Gause's Competitive Exclusion Principle, Interference Competition, MacArther's Resource Partitioning (5 Warbler Species)",
  "21. Parasitism Adaptations: Loss of Sense Organs, Suckers, High Reproductive Capacity, Complex Life Cycles, Brood Parasitism (Cuckoo laying eggs in Crow nest)",
  "22. Commensalism Examples: Orchid Epiphyte on Mango Branch, Barnacles on Whale Back, Cattle Egret and Grazing Cattle, Sea Anemone and Clown Fish",
  "23. Mutualism Examples: Lichens, Mycorrhizae, Fig Tree and Wasp Pollination Co-evolution, Ophrys Orchid Pseudocopulation with Male Bee",
  "Solved Population Growth & Differential Equations Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Population Growth & Age Pyramid Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Exponential & Logistic Growth Numerical Sets, Hints & Solutions"
];

export const ECOSYSTEM_SUBTOPICS = [
  "Introduction",
  "1. Ecosystem Definition, Structural Components (Abiotic & Biotic), Functional Aspects (Productivity, Decomposition, Energy Flow, Nutrient Cycling)",
  "2. Pond Ecosystem as a Self-Sustaining Unit: Autotrophic Components, Consumers, Decomposers, Light & Soil Dynamics",
  "3. Primary Productivity: Definition (Biomass Rate g m^{-2} yr^{-1} or kcal m^{-2} yr^{-1})",
  "4. Gross Primary Productivity (GPP) vs Net Primary Productivity (NPP = GPP - Respiration Loss R), Factors Affecting Primary Productivity",
  "5. Secondary Productivity Definition (Rate of Formation of New Organic Matter by Consumers)",
  "6. Process of Decomposition: Detritus Input, 5 Steps - Fragmentation, Leaching, Catabolism, Humification, Mineralization",
  "7. Rate of Decomposition Controls: Chemical Quality of Detritus (Lignin & Chitin slow, Nitrogen & Sugars fast) and Climatic Factors",
  "8. Energy Flow in Ecosystems: Unidirectional Flow, First and Second Laws of Thermodynamics",
  "9. Incident Solar Radiation, Photosynthetically Active Radiation (PAR, ~50%), Plant Capture Efficiency (2-10% of PAR = 1-5% of Total Solar)",
  "10. Food Chains: Grazing Food Chain (GFC) vs Detritus Food Chain (DFC)",
  "11. Food Webs and Ecosystem Stability",
  "12. Trophic Levels: Positioning of Organisms, Standing Crop (Biomass or Number of Living Organisms at a Specific Time), Dry Weight vs Fresh Weight",
  "13. Ecological Energetics: Raymond Lindeman's 10 Percent Law of Energy Transfer Between Consecutive Trophic Levels",
  "14. Ecological Pyramids: Pyramid of Numbers (Upright in Grassland, Inverted/Spindle in Tree Ecosystem)",
  "15. Pyramid of Biomass: Upright in Terrestrial, Inverted in Marine Ecosystems (Small Phytoplankton Standing Crop Supporting Large Zooplankton/Fish)",
  "16. Pyramid of Energy: Always Upright (Cannot Be Inverted Due to Heat Loss at Each Transfer)",
  "17. Limitations of Ecological Pyramids: Excludes Saprophytes/Decomposers, Assumes Simple Unbranched Food Chains, Organisms Occupying Multiple Trophic Levels",
  "18. Ecological Succession: Concept of Sere, Seral Stages, Pioneer Species, Climax Community Balance",
  "19. Primary Succession (Bare Rock, Newly Formed Pond) vs Secondary Succession (Burned Forest, Abandoned Farmland)",
  "20. Succession of Plants: Hydrarch Succession (Water to Mesic: Phytoplankton -> Submerged -> Free Floating -> Reed Swamp -> Marsh Meadow -> Scrub -> Forest Climax)",
  "21. Xerarch Succession (Bare Rock to Mesic: Crustose Lichens -> Mosses -> Annual Grasses -> Perennial Herbs -> Shrubs -> Trees Climax)",
  "22. Biogeochemical Cycles: Gaseous Cycles (Carbon, Nitrogen) vs Sedimentary Cycles (Phosphorus, Sulphur)",
  "23. Carbon Cycle: Atmospheric Reservoir (1%), Oceanic Dissolved Reservoir (71%), Photosynthetic Fixation (4x10^13 kg/year), Human Alterations",
  "24. Phosphorus Cycle: Rock Reservoir, Weathering, Soil Solution Absorption by Plant Roots, Herbivores, Decomposers, Differences from Carbon Cycle",
  "25. Ecosystem Services: Definition, Robert Costanza Valuation of Nature's Services ($33 Trillion/Year), Soil Formation (50%), Recreation (10%), Nutrient Cycling (10%), Climate Regulation (6%)",
  "Solved Ecological Energetics & Biomass Calculation Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Pyramid & Succession Flowchart Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Energy Flow & Trophic Level Numerical Sets, Hints & Solutions"
];

export const BIODIVERSITY_CONSERVATION_SUBTOPICS = [
  "Introduction",
  "1. Edward Wilson Definition of Biodiversity and 3 Levels of Biological Organization",
  "2. Genetic Diversity: Intra-species Genetic Variation (*Rauwolfia vomitoria* Reserpine Potency, 50,000 Rice Strains, 1,000 Mango Varieties)",
  "3. Species Diversity: Inter-species Richness (Western Ghats Amphibian Diversity vs Eastern Ghats)",
  "4. Ecological Diversity: Ecosystem Variety (India's Deserts, Rain Forests, Mangroves, Coral Reefs, Estuaries vs Scandinavian Nations)",
  "5. Global Species Census: IUCN Census Data (>1.5 Million Named Species), Robert May Statistical Global Estimation (7 Million Species)",
  "6. Global Taxonomic Proportions: >70% Animals, <22% Plants, 70% of Animals are Insects",
  "7. India's Biodiversity Profile: 2.4% World Land Area Supporting 8.1% Global Species Diversity (12 Mega Biodiversity Countries)",
  "8. Patterns of Biodiversity: Latitudinal Gradients (Highest Diversity in Tropics, Decreasing Towards Poles, Amazon Rain Forest Record Diversity)",
  "9. Reasons for High Tropical Biodiversity: Constant Non-Seasonal Climate, Evolutionary Stability Time, Higher Solar Energy",
  "10. Species-Area Relationship: Alexander von Humboldt Observation in South American Jungles, Rectangular Hyperbola Curve, Logarithmic Equation (log S = log C + Z log A)",
  "11. Z-Value Slope Interpretation: Standard Regions (Z = 0.1 to 0.2) vs Large Continents / Frugivorous Birds (Z = 0.6 to 1.2)",
  "12. Importance of Species Diversity to Ecosystem Stability: David Tilman Long-Term Field Experiments",
  "13. Rivet Popper Hypothesis: Paul Ehrlich Analogy (Key Species = Critical Rivets Holding Ecosystem Airplane Together)",
  "14. Loss of Biodiversity: Mass Extinction Episodes (Sixth Extinction Wave 100-1000 Times Faster Due to Human Activities), IUCN Red List Statistics (784 Extinctions)",
  "15. Recent Extinction Examples: Dodo (Mauritius), Quagga (Africa), Thylacine (Australia), Steller's Sea Cow (Russia), 3 Tiger Subspecies (Bali, Javan, Caspian)",
  "16. 'The Evil Quartet' Causes of Biodiversity Loss: 1. Habitat Loss & Fragmentation (Amazon Rain Forest Deforestation), 2. Over-Exploitation (Steller's Sea Cow, Passenger Pigeon), 3. Alien Invasive Species (*Nile Perch*, *Lantana*, *Eichhornia*, *Parthenium*), 4. Co-Extinctions (Co-evolved Plant-Pollinator)",
  "17. Reasons for Biodiversity Conservation: Narrowly Utilitarian (Direct Economic Benefits: Food, Fiber, Timber, Medicines - 25% Modern Drugs from Plants)",
  "18. Broadly Utilitarian Reasons (Ecosystem Services: Amazon Forest 20% Oxygen Release, Pollination, Aesthetic Value)",
  "19. Ethical Reasons (Philosophical, Moral & Stewardship Responsibilities for Co-inhabitants)",
  "20. Conservation Strategies: In-situ (On-site) Conservation of Entire Ecosystems",
  "21. Biodiversity Hotspots: High Endemism & High Threat Criteria (34 Global Hotspots; 3 Covering India: Western Ghats-Sri Lanka, Indo-Burma, Himalayas)",
  "22. Protected Area Networks in India: Biosphere Reserves (14), National Parks (90+), Wildlife Sanctuaries (448+), Sacred Groves (Khasi & Jaintia Hills in Meghalaya, Aravalli Hills)",
  "23. Ex-situ (Off-site) Conservation: Zoological Parks, Botanical Gardens, Wildlife Safari Parks",
  "24. Advanced Ex-situ Methods: Cryopreservation (-196°C Liquid Nitrogen) of Gametes, In Vitro Tissue Culture Micropropagation, Seed Banks",
  "25. Global Conventions: The Earth Summit (Rio de Janeiro, 1992) and World Summit on Sustainable Development (Johannesburg, 2002)",
  "Solved Species-Area & Conservation Calculation Problems",
  "Questions : Objective Type, Very Short-Answer Type, Short-Answer Type, Long-Answer Type [A], Long-Answer Type [B], Species-Area Graph & Conservation Strategy Practice",
  "For Different Competitive Examinations (NEET / Exemplar) : [A] Multichoice Questions, [B] Species-Area Slope & Extinction Factor Matching Sets, Hints & Solutions"
];

export const BIOLOGY_ICSE_LESSONS = [
  "1. REPRODUCTION: 16 Learning Modules, Plant Reproduction (5), Human Reproduction (6), Reproductive Health (5)",
  "2. GENETICS AND EVOLUTION: 15 Learning Modules, Mendelian Deviations (4), Chromosomes & Disorders (4), Molecular Basis (4), Evolution (3)",
  "3. BIOLOGY AND HUMAN WELFARE: 14 Learning Modules, Health & Disease (7), Microbes (7)",
  "4. BIOTECHNOLOGY AND ITS APPLICATIONS: 10 Learning Modules, Principles & Processes (5), Applications (5)",
  "5. ECOLOGY AND ENVIRONMENT: 15 Learning Modules, Populations (5), Ecosystems (5), Biodiversity (5)",
  "6. PRACTICAL EVALUATION WORK: 30 Learning Modules, Core Experiments (15), Spotting Exam (10), Project & File (5)"
];

export const COMPUTER_SCIENCE_ICSE_LESSONS = [
  "Computer System Overview & Architecture",
  "Programming Fundamentals in Python / C++",
  "Conditional and Looping Constructs",
  "Functions and Scope",
  "Strings and Lists",
  "Tuples and Dictionaries",
  "Object-Oriented Programming Concepts",
  "Classes and Objects in Python/C++",
  "Inheritance and Polymorphism",
  "File Handling in Python/C++",
  "Data Structures: Stacks and Queues",
  "Sorting and Searching Algorithms",
  "Introduction to Databases and SQL",
  "SQL Queries and Joins",
  "Boolean Algebra and Logic Gates",
  "Networking Fundamentals and Topologies",
  "Transmission Media and Devices",
  "Protocol Suites and IP Addressing",
  "Web Technologies: HTML, CSS, JavaScript",
  "Cyber Security and Threat Mitigation",
  "Advanced Data Structures: Trees and Graphs",
  "Dynamic Programming",
  "Operating Systems & Process Scheduling",
  "Cloud Computing Architecture",
  "Artificial Intelligence Foundations",
  "Machine Learning Supervised Models",
  "Neural Networks & Deep Learning",
  "Natural Language Processing",
  "Computer Vision & Image Processing",
  "Software Engineering Methodologies",
  "Distributed Systems & Microservices",
  "Blockchain Technology & Smart Contracts",
  "Quantum Computing Principles",
  "Internet of Things (IoT) Embedded Systems",
  "Ethics in AI & Technology Governance"
];

// ==========================================
// ICSE CLASS 9 MATHEMATICS CURRICULUM DATA
// ==========================================

export const RATIONAL_IRRATIONAL_NUMBERS_ICSE9_SUBTOPICS = [
  "Rational Numbers: Definition and representation as terminating or non-terminating repeating (recurring) decimals",
  "Irrational Numbers: Non-terminating, non-repeating decimals; Distinction between rational and irrational numbers",
  "Proofs of Irrationality: Proving irrationality of √2, √3, √5 using method of contradiction",
  "Simplifying Radical Expressions: Operations on radicals (addition, subtraction, multiplication, and division of surds)",
  "Rationalising the Denominator: Rationalising single and binomial surds using conjugate expressions",
  "Real Number Properties: Density property, ordering of real numbers on the number line, and completeness property",
  "Exam-Focused Problem Solving: Converting recurring decimals to fractions, simplifying complex radical fractions, and ICSE question patterns"
];

export const COMPOUND_INTEREST_ICSE9_SUBTOPICS = [
  "Concept of Compound Interest: Difference between Simple Interest (SI) and Compound Interest (CI) over successive conversion periods",
  "Step-by-step CI Computation: Calculating compound interest year-by-year without formula using simple interest steps",
  "Compound Interest Formula: Derivation and direct application of Amount A = P(1 + r/100)ⁿ and CI = A - P",
  "Interest Compounded Semi-Annually and Quarterly: Adjusting interest rate (r/2, r/4) and number of conversion periods (2n, 4n)",
  "Varying Rates of Interest: Successive annual rates r₁, r₂, r₃: A = P(1 + r₁/100)(1 + r₂/100)(1 + r₃/100)",
  "Inverse Problems: Finding rate of interest (r), time duration (n), or initial principal (P) dynamically given CI or Amount",
  "Applications to Real-World Growth and Decay: Population increase/decrease and depreciation of machinery/assets",
  "ICSE Board Exam Scoring Rubrics: Multi-stage financial arithmetic problems and step-by-step calculation proofs"
];

export const EXPANSIONS_ICSE9_SUBTOPICS = [
  "Square Expansions of Binomials: Algebraic identities (x + y)² = x² + 2xy + y² and (x - y)² = x² - 2xy + y²",
  "Reciprocal Binomial Square Expansions: (x ± 1/x)² = x² + 1/x² ± 2 and finding values of x² + 1/x² given x ± 1/x",
  "Trinomial Square Expansions: Full expansion of (a + b + c)² = a² + b² + c² + 2(ab + bc + ca) and sign variations",
  "Cube Expansions of Binomials: Identities (x + y)³ = x³ + y³ + 3xy(x + y) and (x - y)³ = x³ - y³ - 3xy(x - y)",
  "Reciprocal Cube Expansions: (x ± 1/x)³ = x³ ± 1/x³ ± 3(x ± 1/x) and evaluating higher powers without finding x",
  "Conditional Algebraic Identities: If a + b + c = 0, then a³ + b³ + c³ = 3abc; Application to rapid numerical evaluations",
  "Simplification & Value Evaluation: Evaluating symmetric polynomial expressions using algebraic identity transformations",
  "ICSE Challenge Practice: Factoring and expansion shortcuts, double brackets, and exam-level algebraic manipulations"
];

export const FACTORISATION_ICSE9_SUBTOPICS = [
  "Factorisation by Taking Out Common Factors: Identifying greatest common monomial and binomial factors across terms",
  "Factorisation by Grouping Terms: Strategic re-ordering and pairing of algebraic terms to extract common factors",
  "Difference of Two Squares: Applications of identity a² - b² = (a + b)(a - b) to numerical and algebraic expressions",
  "Trinomial Factoring (Splitting the Middle Term): Factoring quadratic polynomials of standard form ax² + bx + c",
  "Sum and Difference of Two Cubes: Identities a³ + b³ = (a + b)(a² - ab + b²) and a³ - b³ = (a - b)(a² + ab + b²)",
  "Multi-Stage Factorisation: Complete factorisation combining grouping, middle term splitting, and difference of squares/cubes",
  "ICSE Exam Patterns: Tricky algebraic patterns, symmetric expressions, fractional coefficients, and rubric requirements"
];

export const SIMULTANEOUS_LINEAR_EQUATIONS_ICSE9_SUBTOPICS = [
  "Linear Equations in Two Variables: Standard algebraic form ax + by + c = 0 and condition for unique solutions",
  "Method of Elimination: Solving simultaneous linear systems by equating coefficients through multiplication and addition/subtraction",
  "Method of Substitution: Isolating one variable in terms of the other and substituting to solve the system",
  "Method of Cross-Multiplication: Determinant / cross-multiplication formula for simultaneous linear systems",
  "Equations Reducible to Linear Form: Substituting u = 1/x, v = 1/y to solve systems with fractional variables",
  "Word Problems on Numbers & Two-Digit Numbers: Formulating equations involving digit reversal and sum of digits",
  "Word Problems on Fractions, Age & Geometry: Solving real-world scenarios relating to ages, perimeter/area, and fractions",
  "Word Problems on Speed, Distance, Time & Commercial Applications: Upstream/downstream boat problems, work rate, and cost/profit",
  "ICSE Board Exam Marking Standards: Complete step-by-step verification, variable definitions, and unit conclusions"
];

export const INDICES_EXPONENTS_ICSE9_SUBTOPICS = [
  "Fundamental Laws of Indices: Product rule aᵐ · aⁿ = aᵐ⁺ⁿ, quotient rule aᵐ / aⁿ = aᵐ⁻ⁿ, and power rule (aᵐ)ⁿ = aᵐⁿ",
  "Zero and Negative Integral Exponents: Mathematical meaning and proofs of a⁰ = 1 (for a ≠ 0) and a⁻ⁿ = 1/aⁿ",
  "Fractional Exponents & Radicals: Definition of aᵐ/ⁿ = ⁿ√(aᵐ) = (ⁿ√a)ᵐ and conversion between radical and exponential forms",
  "Simplification of Exponential Expressions: Prime factorisation of bases and algebraic reduction of nested exponents",
  "Elementary Exponential Equations: Solving equations of the form aˣ = b and aᶠ⁽ˣ⁾ = aᵍ⁽ˣ⁾ ⇒ f(x) = g(x)",
  "Simultaneous Exponential Equations: Solving systems where multiple unknown variables appear in exponents",
  "ICSE Exam Pitfalls: Handling negative signs in bases vs exponents, common student calculation traps, and rapid checks"
];

export const LOGARITHMS_ICSE9_SUBTOPICS = [
  "Fundamental Definition of Logarithm: Equivalence aˣ = b ⇔ logₐ b = x (with constraints a > 0, a ≠ 1, b > 0)",
  "Interchange Between Exponential and Logarithmic Forms: Converting between index notation and logarithmic notation",
  "Product Rule of Logarithms: Proof and application of logₐ(m · n) = logₐ m + logₐ n",
  "Quotient Rule of Logarithms: Proof and application of logₐ(m / n) = logₐ m - logₐ n",
  "Power Rule of Logarithms: Proof and application of logₐ(mⁿ) = n · logₐ m",
  "Special Logarithmic Values: Proof that logₐ 1 = 0 and logₐ a = 1 for any valid base a",
  "Change of Base Rule: Derivation of logₐ b = (log_c b) / (log_c a) and the reciprocal rule logₐ b · log_b a = 1",
  "Common Logarithms: Base-10 logarithms, concept of characteristic and mantissa, and evaluating multi-term expressions",
  "Solving Logarithmic Equations: Combining logarithmic terms using laws to solve for unknown variables",
  "ICSE Examination Rubrics: Rigorous algebraic justification of log steps and avoiding extraneous solutions"
];

export const TRIANGLES_GEOMETRY_ICSE9_SUBTOPICS = [
  "Congruence of Triangles: Concept of geometric congruence, correspondence of vertices, and CPCTC principle",
  "Congruency Conditions: Side-Side-Side (SSS), Side-Angle-Side (SAS), Angle-Side-Angle (ASA), Angle-Angle-Side (AAS)",
  "Right-Angle-Hypotenuse-Side (RHS) Criterion: Distinct conditions and proof applications for right-angled triangles",
  "Isosceles Triangle Theorems: Angles opposite to equal sides of a triangle are equal; Converse theorem and formal proofs",
  "Equilateral Triangle Properties: Equal sides, all interior angles equal to 60°, concurrence of altitudes, medians, and angle bisectors",
  "Inequalities in a Triangle: If two sides of a triangle are unequal, the greater angle lies opposite the longer side (and converse)",
  "Triangle Inequality Theorem: The sum of any two sides of a triangle is strictly greater than the third side",
  "Formal Deductive Proofs in Geometry: Writing standard ICSE two-column geometric proofs (Given, To Prove, Construction, Proof with Reasons)"
];

export const MIDPOINT_INTERCEPT_THEOREMS_ICSE9_SUBTOPICS = [
  "The Mid-point Theorem: Line segment joining the mid-points of two sides of a triangle is parallel to the third side and half of it",
  "Proof of the Mid-point Theorem: Euclidean construction and formal deductive proof using quadrilateral congruency",
  "Converse of the Mid-point Theorem: The line drawn through the mid-point of one side of a triangle parallel to another side bisects the third side",
  "The Equal Intercept Theorem: If three or more parallel lines make equal intercepts on one transversal, they make equal intercepts on any other transversal",
  "Proof of the Intercept Theorem: Complete geometric proof using transversal triangles and parallelogram properties",
  "Applications to Quadrilaterals: Proving that joining the mid-points of consecutive sides of any quadrilateral forms a parallelogram",
  "Geometric Riders: Multi-step riders involving medians, parallel segments, and midpoint configurations",
  "ICSE Exam Scoring Standards: Essential construction lines, geometric reasons, and step-by-step theorem rubrics"
];

export const RECTILINEAR_FIGURES_ICSE9_SUBTOPICS = [
  "Angle Sum Property of Polygons: Sum of interior angles of an n-sided polygon = (2n - 4) · 90°; Sum of interior angles of a quadrilateral is 360°",
  "Parallelograms: Definition and properties (opposite sides equal, opposite angles equal, diagonals bisect each other; Converse conditions)",
  "Special Parallelograms — Rectangle: Properties, diagonals are equal, each interior angle is 90°",
  "Special Parallelograms — Rhombus: All sides equal, diagonals bisect each other at right angles (perpendicular bisectors)",
  "Special Parallelograms — Square: All sides equal, all angles 90°, diagonals equal and bisect each other at right angles",
  "Trapezium & Isosceles Trapezium: Properties, non-parallel sides equal in isosceles trapezium, base angles equal, diagonals equal",
  "Constructions & Deductive Proofs: Proving a given quadrilateral is a parallelogram, rectangle, rhombus, or square based on minimal conditions",
  "ICSE Geometric Riders: Figure analysis, deductive geometric reasoning, and step-by-step proof structure"
];

export const CIRCLES_GEOMETRY_ICSE9_SUBTOPICS = [
  "Circle Fundamentals: Center, radius, diameter, chord, secant, tangent, arc, sector, segment, and concentric circles",
  "Perpendicular from Center to Chord: A straight line drawn from the center of a circle to bisect a chord is perpendicular to the chord (and converse proof)",
  "Equal Chords Theorem: Equal chords of a circle are equidistant from the center; Chords equidistant from the center are equal in length",
  "Chords and Arc Subtended Angles: Equal chords subtend equal angles at the center of the circle (and converse)",
  "Angle at the Center Theorem: The angle subtended by an arc at the center is double the angle subtended by it at any point on the remaining circumference",
  "Angles in the Same Segment: Angles in the same segment of a circle are equal; Angle in a semicircle is a right angle (90°)",
  "Cyclic Quadrilaterals Introduction: Opposite angles of a cyclic quadrilateral are supplementary; Exterior angle equals interior opposite angle",
  "ICSE Board Exam Riders: Numerical calculation of chord lengths, radial distances, and formal deductive circle proofs"
];

export const AREA_PLANE_FIGURES_ICSE9_SUBTOPICS = [
  "Perimeter and Area of Triangles: Standard formula Area = 1/2 · base · height; Equilateral triangle Area = (√3/4)a² and altitude h = (√3/2)a",
  "Heron's Formula: Semi-perimeter s = (a + b + c)/2; Area = √[s(s - a)(s - b)(s - c)]; Application to scalene triangles and quadrilaterals",
  "Area of Quadrilaterals: Rectangles (l · b), squares (a²), parallelograms (base · height), rhombuses (1/2 · d₁ · d₂), trapeziums [1/2 · (a + b) · h]",
  "Perimeter and Area of Circles: Circumference C = 2πr, Area A = πr²; Area of circular ring / shaded border path A = π(R² - r²)",
  "Area of Sectors and Segments: Arc length l = (θ/360°) · 2πr; Sector Area = (θ/360°) · πr² = 1/2 · l · r; Area of minor/major segments",
  "Combined Plane Figures: Shaded area calculations combining polygons, semicircles, and concentric circular regions",
  "Regular Polygons: Perimeter and area calculation by dividing into congruent isosceles triangles",
  "Real-World Practical Problems: Turfing a field, fencing costs, paving paths, and unit conversions (cm², m², hectares, ares)"
];

export const SURFACE_AREA_VOLUME_ICSE9_SUBTOPICS = [
  "Three-Dimensional Solids: Identification of faces, vertices, edges, and net patterns of prisms and cylinders",
  "Cubes: Lateral surface area (4a²), total surface area (6a²), volume (a³), length of diagonal (a√3)",
  "Cuboids: Lateral surface area [2(l + b)h], total surface area [2(lb + bh + hl)], volume (l · b · h), length of diagonal [√(l² + b² + h²)]",
  "Right Circular Cylinders: Curved/lateral surface area (2πrh), total surface area [2πr(h + r)], volume (πr²h)",
  "Hollow Cylinders (Pipes): Internal radius r, external radius R, thickness (R - r); CSA [2πh(R + r)], TSA [2π(R + r)(h + R - r)], Volume of material [πh(R² - r²)]",
  "Melting, Casting and Reshaping: Conservation of volume principle when 3D solids are recast into another shape",
  "Applied Flow Problems: Water flowing through cylindrical pipes at uniform speed (rate of flow · cross-sectional area · time = volume)",
  "ICSE Mensuration Exam Problem Solving: Step-by-step substitution, fractional π approximations (22/7 or 3.142), and units consistency"
];

export const COORDINATE_GEOMETRY_ICSE9_SUBTOPICS = [
  "Cartesian Coordinate System: Origin O(0,0), perpendicular coordinate axes (x-axis, y-axis), coordinate planes, and 4 quadrants sign rules",
  "Plotting Points on the Coordinate Plane: Locating and plotting ordered pairs (x, y); Identifying coordinates from graph grids",
  "Equations of Lines Parallel to Axes: Equation of x-axis (y = 0), equation of y-axis (x = 0), lines parallel to x-axis (y = ±k), lines parallel to y-axis (x = ±c)",
  "Distance Formula: Derivation using Pythagoras theorem: d = √[(x₂ - x₁)² + (y₂ - y₁)²]",
  "Geometric Applications of Distance Formula: Proving points are collinear; Proving vertices form equilateral, isosceles, or right-angled triangles",
  "Verifying Quadrilateral Types: Using distances to prove a figure is a parallelogram, rectangle, rhombus, or square",
  "Mid-point Formula: Coordinates of midpoint M of line segment joining (x₁, y₁) and (x₂, y₂): M = ((x₁ + x₂)/2, (y₁ + y₂)/2)",
  "Center of Circles & Diagonals: Finding circle center given diameter endpoints, verifying diagonal intersection in parallelograms",
  "ICSE Graphing & Proof Rubrics: Coordinate axes labelling, scale notation, and algebraic proof documentation"
];

export const TRIGONOMETRICAL_RATIOS_ICSE9_SUBTOPICS = [
  "Concept of Trigonometric Ratios: Defining hypotenuse, perpendicular (opposite side), and base (adjacent side) with respect to acute angle θ",
  "Definitions of the Six T-Ratios: sin θ = P/H, cos θ = B/H, tan θ = P/B, cot θ = B/P, sec θ = H/B, csc θ = H/P",
  "Reciprocal and Quotient Relations: csc θ = 1/sin θ, sec θ = 1/cos θ, cot θ = 1/tan θ, tan θ = sin θ/cos θ, cot θ = cos θ/sin θ",
  "Values of T-Ratios for Standard Angles: Complete derivation and exact values for 0°, 30°, 45°, 60°, and 90°",
  "Fundamental Trigonometric Identities: Proofs of sin²θ + cos²θ = 1, 1 + tan²θ = sec²θ, and 1 + cot²θ = csc²θ",
  "Proving Trigonometric Identities: Structured LHS-to-RHS proofs, algebraic substitutions, and trigonometric conjugate rationalisation",
  "Numerical Evaluation of Trigonometric Expressions: Computing exact values of trigonometric expressions without mathematical tables",
  "Complementary Angles Overview: sin(90° - θ) = cos θ, cos(90° - θ) = sin θ, tan(90° - θ) = cot θ",
  "ICSE Exam Marking Rubrics: Complete identity justification, avoiding undefined values (tan 90°, csc 0°), and neat step execution"
];

export const STATISTICS_ICSE9_SUBTOPICS = [
  "Statistical Data Fundamentals: Primary data, secondary data, raw (ungrouped) data, arrayed data, and grouped frequency data",
  "Frequency Distributions: Class intervals, class limits (lower limit, upper limit), true class boundaries, class mark (mid-value), class width/size",
  "Tally Marks & Frequency Tables: Constructing discrete and continuous frequency distribution tables from raw datasets",
  "Cumulative Frequency: Less-than type and more-than type cumulative frequency tables and their statistical significance",
  "Histograms: Drawing histograms with equal class intervals on continuous scales; Handling inclusive to exclusive boundary conversions",
  "Frequency Polygons: Constructing frequency polygons using mid-points of histogram rectangles or directly using class marks",
  "Measures of Central Tendency — Mean: Arithmetic mean of raw data (x̄ = Σx/n) and mean of ungrouped frequency distribution (x̄ = Σfx / Σf)",
  "Measures of Central Tendency — Median & Mode: Finding median for odd and even number of observations; Mode as the most frequently occurring observation",
  "ICSE Data Interpretation: Graphical analysis, reading cumulative data, and solving exam questions on frequency distributions"
];

export const INTERNAL_ASSESSMENT_MATH_ICSE9_SUBTOPICS = [
  "Overview of Paper II: 20 Marks school-supervised internal assessment framework and coursework guidelines",
  "Mathematical Project 1 — Commercial & Financial Mathematics: Planning a family budget, comparative survey of bank savings and recurring deposits",
  "Mathematical Project 2 — Geometric Tessellations & Theorem Verification: Verification of midpoint theorem or area formulas using origami/cut-out paper models",
  "Mathematical Project 3 — Statistical Field Survey: Collecting real-world empirical data (e.g., student heights/weights), drawing histograms, and computing mean/median",
  "Class Record Work & Assignment Submission (10 Marks): Structured portfolio maintenance, neatness, objective, methodology, data tables, and conclusion",
  "Viva-Voce & Project Presentation (10 Marks): Oral defense, conceptual clarity, answering examiner questions on mathematical methods and findings",
  "ICSE Internal Assessment Rubric: Evaluation criteria, timely submission guidelines, and presentation excellence standards"
];

export const MEASUREMENTS_EXPERIMENTATION_ICSE9_SUBTOPICS = [
  "International System of Units: Fundamental & derived units, standard SI symbols, submultiples & multiples (micro, milli, centi, kilo, mega)",
  "Measurement of Length & Least Count: Principle of least count, Vernier Callipers (least count/Vernier constant, positive & negative zero error, zero correction)",
  "Micrometer Screw Gauge: Pitch, least count formula (Pitch / Total circular divisions), positive/negative zero error, backlash error and remedies",
  "Measurement of Time & Simple Pendulum: Oscillations, amplitude, frequency, time period definition (T = 2π√(l/g))",
  "Factors Affecting Simple Pendulum Time Period: Independence of mass and amplitude, direct variation with √l, inverse variation with √g",
  "Graphical & Experimental Determination of 'g': l vs T² linear graph, slope calculation (4π²/g), and finding acceleration due to gravity",
  "ICSE Practical Measurement Standards: Significant figures, instrument handling, and avoiding parallax error in measurements"
];

export const MOTION_ONE_DIMENSION_ICSE9_SUBTOPICS = [
  "Scalar and Vector Quantities: Definitions, physical distinctions, scalar vs vector representation, and 1D vector signs (+ and -)",
  "Distance and Displacement: Definitions, comparative distinctions, path dependence vs position change, zero displacement scenarios",
  "Speed and Velocity: Uniform and non-uniform speed/velocity, instantaneous speed, average speed (s_total/t_total), average velocity",
  "Acceleration and Retardation: Definitions, SI units (m/s²), uniform vs non-uniform acceleration, negative acceleration (deceleration/retardation)",
  "Acceleration Due to Gravity (g): Value of g (9.8 m/s² or 10 m/s²), vertical projection under gravity, sign conventions",
  "Graphical Representation of 1D Motion: s-t graphs (stationary, uniform, accelerated; slope = velocity); v-t graphs (slope = acceleration, area = distance/displacement)",
  "Kinematic Equations of Motion: Derivations (v = u + at, s = ut + ½at², v² = u² + 2as) by algebraic and graphical methods",
  "ICSE Numerical Problem Solving: Multi-step motion calculations, stopping distance, overtakes, reaction time, and motion under gravity"
];

export const LAWS_OF_MOTION_ICSE9_SUBTOPICS = [
  "Contact and Non-Contact Forces: Normal reaction, tension, friction, restoring force; Gravitational, electrostatic, and magnetic forces",
  "Newton's First Law of Motion: Qualitative concept of force, Galileo's thought experiment, concept of inertia",
  "Types of Inertia: Inertia of rest, inertia of motion, and inertia of direction with comprehensive everyday physical examples",
  "Linear Momentum & Newton's Second Law: Momentum (p = mv), rate of change of momentum, mathematical derivation of F = ma",
  "Units of Force: Absolute units (Newton N, Dyne), gravitational units (kgf, gf), and unit conversions (1 N = 10⁵ dynes, 1 kgf = 9.8 N)",
  "Newton's Third Law of Motion: Action-reaction pairs, simultaneous action on different bodies, recoil of gun, rocket propulsion, swimming, walking",
  "Universal Law of Gravitation: Statement, mathematical formulation (F = G m₁m₂/r²), universal gravitational constant G = 6.67×10⁻¹¹ N m²/kg²",
  "Gravity, Free Fall, Mass vs Weight: Relation between g and G (g = GM/R²), variation of g with height and depth, mass vs weight comparison"
];

export const FLUIDS_PRESSURE_ARCHIMEDES_ICSE9_SUBTOPICS = [
  "Thrust and Pressure in Fluids: Definitions, SI units (N/m², Pascal, bar, atm, torr), factors affecting liquid pressure (P = hρg)",
  "Laws of Liquid Pressure: Equal pressure at equal depth in all directions, independent of container shape, liquid seeks its own level",
  "Pascal's Principle & Hydraulic Machines: Transmission of pressure, hydraulic press, hydraulic lift, hydraulic brakes (F₁/A₁ = F₂/A₂, mechanical advantage)",
  "Atmospheric Pressure & Barometers: Concept, Torricelli's experiment, simple mercury barometer, advantages of mercury, vacuum above mercury column",
  "Modern Barometers & Weather Forecasting: Fortin's barometer, Aneroid barometer (altimeter), altitude pressure variation, predicting storms and fair weather",
  "Buoyancy & Archimedes' Principle: Upthrust / buoyant force (F_B = Vρg), Archimedes' principle statement, experimental proof, apparent loss of weight",
  "Principle of Floatation: Floating equilibrium condition (W = F_B or ρ_s ≤ ρ_l), fraction of volume submerged (V_sub/V_total = ρ_s/ρ_l)",
  "Relative Density & Applications: Definition of Relative Density (RD = ρ_sub/ρ_water), finding RD of solids and liquids using Archimedes' principle, hydrometers, submarines, icebergs, iron ships, balloons"
];

export const HEAT_AND_ENERGY_ICSE9_SUBTOPICS = [
  "Concepts of Heat and Temperature: Thermal energy, difference between heat and temperature, units (Joule, calorie, kilocalorie, °C, K, °F), kinetic molecular theory",
  "Thermal Expansion: Expansion in solids (linear, superficial, cubical), liquids, and gases; Practical everyday consequences and compensations",
  "Anomalous Expansion of Water: Volume and density behavior of water from 0°C to 4°C, maximum density at 4°C (1 g/cm³ or 1000 kg/m³)",
  "Hope's Experiment & Biological Significance: Experimental demonstration of anomalous expansion, survival of marine and aquatic life in frozen water bodies during winter",
  "Energy Sources & Classifications: Renewable sources (solar, wind, hydroelectric, biomass, geothermal, tidal) vs Non-renewable sources (coal, petroleum, natural gas, nuclear)",
  "Energy Transformations & Conservation Principle: Law of Conservation of Energy, energy degradation / dissipation into non-useful thermal forms",
  "Greenhouse Effect and Global Warming: Mechanism of greenhouse gases (CO₂, CH₄, water vapour), global warming impacts, ozone depletion, and carbon footprint reduction"
];

export const LIGHT_REFLECTION_SPHERICAL_MIRRORS_ICSE9_SUBTOPICS = [
  "Reflection of Light at Plane Surfaces: Incident ray, reflected ray, normal, angle of incidence i and reflection r, laws of reflection, regular vs diffuse reflection",
  "Image Formation by Plane Mirror: Virtual, erect, laterally inverted, same size, equidistant object-image properties, ray tracing diagrams",
  "Images Formed by Inclined Plane Mirrors: Number of images formula (n = 360/θ - 1 or 360/θ depending on symmetry and odd/even condition), parallel mirrors (n = ∞)",
  "Optical Devices Using Plane Mirrors: Periscope, kaleidoscope, construction, beam ray paths, and applications",
  "Spherical Mirrors — Terminology: Concave and convex mirrors, pole (P), centre of curvature (C), radius of curvature (R), principal axis, principal focus (F), focal length (f = R/2)",
  "Ray Diagrams for Concave Mirror: Real and virtual image formation for all 6 object positions (infinity, beyond C, at C, between C and F, at F, between F and P)",
  "Ray Diagrams for Convex Mirror: Always virtual, erect, and diminished images for all object positions, wide field of view",
  "Mirror Formula & Linear Magnification: Sign convention (New Cartesian), Mirror Formula (1/f = 1/v + 1/u), Magnification formula (m = -v/u = h_i/h_o), practical uses (headlights, shaving mirror, rear-view mirror, dental mirror)"
];

export const SOUND_PROPAGATION_ULTRASONIC_ICSE9_SUBTOPICS = [
  "Nature and Propagation of Sound: Mechanical longitudinal waves, compressions and rarefactions, requirement of elastic material medium (Bell jar experiment)",
  "Speed of Sound in Different Media: Speed in solids (v_solid > v_liquid > v_gas), speed of sound in air (≈ 330-340 m/s), comparison with speed of light (3×10⁸ m/s)",
  "Factors Affecting Speed of Sound: Temperature (v ∝ √T), humidity (moist air vs dry air), density, wind direction; Independence of pressure and amplitude",
  "Audible, Infrasonic and Ultrasonic Sound: Human audible range (20 Hz - 20,000 Hz), infrasound (<20 Hz), ultrasound (>20 kHz)",
  "Applications of Ultrasound: SONAR (Sound Navigation and Ranging) echo ranging (d = vt/2), medical ultrasonography/echocardiography, bat echolocation, ultrasonic cleaning, flaw detection in metal castings",
  "Distinction between Sound Waves and Light Waves: Mechanical vs Electromagnetic, longitudinal vs transverse, speed comparisons, medium requirements"
];

export const ELECTRICITY_MAGNETISM_ICSE9_SUBTOPICS = [
  "Static Electricity & Electric Charges: Positive and negative charges, atomic structure basis, electrostatic induction, charging by friction and conduction",
  "Gold-Leaf Electroscope: Construction, working, detecting presence and nature of electric charge, charging by induction",
  "Atmospheric Electricity & Lightning: Cloud charging mechanisms, lightning discharge, lightning conductor (Franklin's rod) principle and safety precautions",
  "Current Electricity Fundamentals: Electric current (I = Q/t, Ampere), Potential and Potential Difference (V = W/Q, Volt), electromotive force (EMF)",
  "Electric Circuits & Components: Closed vs open circuits, standard circuit symbols, switches, safety fuse (lead-tin alloy, low melting point, series connection), connecting wires",
  "Electric Cells: Primary cells (Simple Voltameter, Leclanché, Daniel, Dry cell) vs Secondary cells (Lead-acid accumulator, rechargeable lithium cells)",
  "Magnetism & Magnetic Fields: Magnetic and non-magnetic substances, properties of magnets, magnetic field lines around bar magnet (properties: continuous closed loops, never intersect)",
  "Plotting Magnetic Field Lines & Neutral Points: Using compass needle, Earth's magnetic field interaction, neutral points (B_magnet = B_Earth), plotting with North pointing North vs North pointing South",
  "Electromagnetism: Magnetic effect of electric current (Oersted's discovery), electromagnets vs permanent magnets, making electromagnets, electric bell working"
];

export const INTERNAL_ASSESSMENT_PHYSICS_ICSE9_SUBTOPICS = [
  "Overview of Paper II (20 Marks): School-assessed practical coursework, laboratory experiments, project work, and viva-voce examination framework",
  "Experiment 1 — Vernier Callipers: Determining Vernier constant, measuring length and diameter of a cylinder/sphere, calculating volume",
  "Experiment 2 — Screw Gauge: Determining pitch and least count, measuring diameter of a thin wire and thickness of a glass strip",
  "Experiment 3 — Simple Pendulum: Determining time period for 5 different lengths, plotting l vs T² graph, calculating slope and g",
  "Experiment 4 — Laws of Reflection: Verifying angle of incidence equals angle of reflection using plane mirror and optical pins on drawing board",
  "Experiment 5 — Focal Length of Concave Mirror: Finding approximate focal length by distant object method and measuring focal length using one-pin parallax method",
  "Experiment 6 — Density by Archimedes' Principle: Measuring mass using spring balance / beam balance and measuring volume/loss of weight in water with measuring cylinder",
  "Experiment 7 — Plotting Magnetic Field Lines: Tracing magnetic field lines of bar magnet on paper with magnetic compass, identifying neutral points",
  "Lab Journal, Portfolio Maintenance & Viva-Voce (20 Marks): ICSE marking rubrics for practical observation tables, error estimation, graph neatness, and oral examination"
];

export const LANGUAGE_OF_CHEMISTRY_ICSE9_SUBTOPICS = [
  "Symbols and Valency: Definition of a symbol; Valency as combining capacity; Variable valency of elements (Iron Fe²⁺/Fe³⁺, Copper Cu⁺/Cu²⁺, Sulfur, Lead); Radicals (monovalent, divalent, trivalent, and tetravalent electropositive & electronegative ions)",
  "Chemical Formulae & Criss-Cross Method: Writing chemical formulas of binary and polyatomic compounds using the criss-cross valency method",
  "Chemical Equations & Balancing: Balancing chemical equations by the hit-and-trial method; Information conveyed by a chemical equation (reactants, products, states) and its essential limitations (speed, heat, concentration)",
  "Relative Atomic Mass (A_r) and Relative Molecular Mass (M_r): Standard Carbon-12 scale definitions; Calculating relative molecular mass (molecular weight) of simple and hydrated compounds",
  "Percentage Composition Calculations: Determining the percentage composition of constituent elements in a compound from its chemical formula and relative atomic masses",
  "ICSE Chemical Nomenclature & Practice: Naming binary compounds, oxy-acids, bases, acidic/basic salts, and translating word equations into balanced symbolic equations"
];

export const CHEMICAL_CHANGES_REACTIONS_ICSE9_SUBTOPICS = [
  "Types of Chemical Reactions — Direct Combination: Synthesis reactions (metal + non-metal, non-metal + non-metal, compound + element) with key conditions and balanced equations",
  "Decomposition Reactions: Thermal decomposition of metal carbonates, nitrates, and hydroxides; Electrolytic decomposition (electrolysis of acidified water)",
  "Displacement Reactions: Single displacement based on the metal and non-metal reactivity series, visual observation indicators (color change, precipitate, gas release)",
  "Double Decomposition Reactions: Precipitation reactions (formation of insoluble salts) and Neutralization reactions (acid + base → salt + water) with typical examples",
  "Reversible and Irreversible Reactions: Definitions, reversible equilibrium arrows (⇌), physical and chemical examples (thermal dissociation of NH₄Cl vs irreversible decomposition)",
  "Energy Changes in Reactions: Exothermic reactions (heat release, ΔH < 0, burning of carbon/respiration) vs Endothermic reactions (heat absorption, ΔH > 0, photosynthesis/formation of NO)",
  "Catalysis & Industrial Examples: Definition of a catalyst, positive catalyst, negative catalyst (inhibitor), promoters, and catalytic reactions (Haber's ammonia synthesis with Fe/Mo, Contact process SO₃ with V₂O₅)"
];

export const WATER_SOLUTIONS_HYDRATION_ICSE9_SUBTOPICS = [
  "Water as Universal Solvent: High dielectric constant, dissolution of polar solutes; Distinguishing dilute, concentrated, saturated, and supersaturated solutions",
  "Solubility & Solubility Curves: Definition of solubility (g solute per 100g water at given T), temperature and pressure effects, interpreting solubility curves of KNO₃, NaCl, CaSO₄",
  "Crystallization & Water of Crystallization: Meaning of crystals, hydrated salts vs anhydrous substances, calculating water of crystallization percentage",
  "Efflorescence, Deliquescence, and Hygroscopy: Definitions, atmospheric vapor pressure comparison, typical examples (washing soda Na₂CO₃·10H₂O, anhydrous CaCl₂, silica gel, conc. H₂SO₄)",
  "Hard and Soft Water: Distinguishing characteristics, behavior with soap; Causes of hardness (dissolved hydrogencarbonates, chlorides, and sulphates of Ca²⁺ and Mg²⁺)",
  "Hardness Removal & Water Softening: Temporary hardness removal (boiling, Clark's process with slaked lime) vs Permanent hardness removal (washing soda method, ion-exchange / Permutit process)"
];

export const ATOMIC_STRUCTURE_BONDING_ICSE9_SUBTOPICS = [
  "Subatomic Particles: Discovery, relative mass, and charge properties of electrons, protons, and neutrons; Thomson's plum pudding model and Rutherford's α-scattering nuclear model",
  "Bohr's Atomic Model & Energy Shells: Postulates, stationary orbits (K, L, M, N), and electronic distribution following the 2n² rule up to Calcium (Z = 1 to 20)",
  "Atomic Parameters: Atomic number (Z), Mass number (A), number of neutrons (n = A - Z); Isotopes and Isobars (definitions, examples: ¹H/²H/³H, ¹²C/¹⁴C, ⁴⁰Ar/⁴⁰Ca, and fractional atomic masses of Cl)",
  "Electrovalent (Ionic) Bonding: Electron transfer from electropositive metals to electronegative non-metals, ionic crystal lattice, properties of ionic compounds (high MP/BP, electrolytic conduction in molten/aqueous state)",
  "Ionic Electron-Dot Structures: Lewis dot diagrams and formation mechanisms for Sodium Chloride (NaCl), Magnesium Chloride (MgCl₂), and Calcium Oxide (CaO)",
  "Covalent (Molecular) Bonding: Sharing of electron pairs between non-metals, single (H-H, Cl-Cl), double (O=O), and triple (N≡N) covalent bonds; Polar vs non-polar covalent bonds",
  "Covalent Electron-Dot Structures: Lewis electron-dot diagrams for H₂, O₂, N₂, H₂O, NH₃, and CH₄ with shared pairs and lone pairs"
];

export const PERIODIC_TABLE_PROPERTIES_ICSE9_SUBTOPICS = [
  "Historical Classification of Elements: Dobereiner's Triads (law of triads, atomic mass arithmetic mean), Newlands' Law of Octaves, and their foundational limitations",
  "Mendeleev's Periodic Table: Periodic law based on atomic mass, structural achievements (predicting eka-elements, correcting atomic masses), and anomalies (position of hydrogen, isotopes, anomalous mass pairs)",
  "Modern Periodic Law & Table Structure: Moseley's atomic number basis, 18 vertical columns (groups: alkali metals, alkaline earths, halogens, noble gases) and 7 horizontal rows (periods)",
  "Periodic Trends up to Calcium (Z = 1 to 20): Electronic configuration patterns across Periods 1-3 and Groups 1, 2, 13-18",
  "Valency Variations Across Periods & Groups: Trends in valency across a period (increasing 1 to 4, then decreasing 4 to 0) and constancy of valency down a group",
  "Atomic Radius & Metallic Character: Periodicity in atomic size (decreasing across period, increasing down group), metallic to non-metallic transitions, and chemical reactivity trends"
];

export const HYDROGEN_STUDY_ICSE9_SUBTOPICS = [
  "Dual Position of Hydrogen in Periodic Table: Resemblance with Group 1 Alkali Metals (electropositive valency +1, reducing agent) and Group 17 Halogens (diatomic gas, electronegative valency -1, non-metallic hydride formation)",
  "Laboratory Preparation of Hydrogen: Reaction of granulated zinc with dilute hydrochloric or dilute sulfuric acid; Downward displacement of water / air collection; Precautions and apparatus setup",
  "Purification & Impurities in Hydrogen: Removal of arsine, phosphine, hydrogen sulfide, sulfur dioxide, and moisture using specific washing solutions (AgNO₃, Pb(CH₃COO)₂, KOH, fused CaCl₂)",
  "Industrial Manufacture — Bosch Process: Production of water gas (C + H₂O → CO + H₂), catalytic conversion of CO to CO₂ with excess steam (Fe₂O₃/Cr₂O₃ at 450°C), separation and liquefaction of gases",
  "Physical and Chemical Properties of Hydrogen: Colorless, odorless, neutral, lightest gas; Combustibility, reaction with non-metals (O₂, Cl₂, N₂), reducing action with heated metal oxides (CuO + H₂ → Cu + H₂O)",
  "Oxidation and Reduction in Terms of Oxygen & Hydrogen: Classical definitions of oxidation (addition of O / removal of H) and reduction (removal of O / addition of H), identifying oxidizing and reducing agents",
  "Uses of Hydrogen & Confirmatory Tests: Hydrogen fuel, oxy-hydrogen torch, hydrogenation of vegetable oils, manufacture of ammonia (Haber process), and characteristic 'pop sound' test"
];

export const GAS_LAWS_BOYLE_CHARLES_ICSE9_SUBTOPICS = [
  "Measurable Gas Variables: Volume (V in dm³, cm³, L, mL), Pressure (P in atm, mm Hg, torr, Pa), and Temperature (T in Kelvin and Celsius; T = t + 273)",
  "Boyle's Law: Statement (Volume is inversely proportional to pressure at constant temperature: V ∝ 1/P), mathematical formula (P₁V₁ = P₂V₂ = k), molecular interpretation using kinetic theory",
  "Graphical Representations of Boyle's Law: P vs V hyperbolic isotherms, P vs 1/V straight lines passing through origin, and PV vs P horizontal isobaric lines",
  "Charles' Law: Statement (Volume is directly proportional to absolute temperature at constant pressure: V ∝ T), concept of Absolute Zero (-273°C / 0 K), mathematical formula (V₁/T₁ = V₂/T₂)",
  "Graphical Representations of Charles' Law: Volume vs Temperature (°C) with linear extrapolation to -273°C, and Volume vs Temperature (K) straight lines through origin",
  "Combined Gas Equation & STP: Derivation of (P₁V₁)/T₁ = (P₂V₂)/T₂, Standard Temperature and Pressure conditions (STP: 0°C / 273 K, 1 atm / 760 mm Hg / 1.013×10⁵ Pa)",
  "ICSE Gas Law Numerical Calculations: Step-by-step solving of numerical problems involving Boyle's law, Charles' law, combined gas equation, and STP volume conversions"
];

export const ATMOSPHERIC_POLLUTION_ICSE9_SUBTOPICS = [
  "Atmospheric Pollutants & Sources: Primary vs secondary air pollutants, oxides of sulfur (SO₂, SO₃), oxides of nitrogen (NO, NO₂), carbon monoxide (CO), and suspended particulate matter",
  "Acid Rain — Chemistry & Mechanism: Atmospheric oxidation and conversion of SO₂ and NO₂ into sulfurous, sulfuric, nitrous, and nitric acids (H₂SO₃, H₂SO₄, HNO₂, HNO₃); pH threshold (< 5.6)",
  "Environmental Impacts of Acid Rain: Acidification of soil and water bodies, leaching of essential plant nutrients and toxic heavy metals (Al³⁺), damage to forests, and marble cancer of monuments (CaCO₃ + H₂SO₄ → CaSO₄ + H₂O + CO₂)",
  "Global Warming & The Greenhouse Effect: Mechanism of natural vs enhanced greenhouse effect, major greenhouse gases (CO₂, CH₄, N₂O, tropospheric ozone, water vapor, CFCs)",
  "Climatic Consequences of Global Warming: Global average temperature rise, melting of polar ice sheets and Himalayan glaciers, sea level rise, shifting weather patterns, and ocean acidification",
  "Ozone Layer Depletion: Stratospheric ozone formation & dynamic equilibrium (Chapman cycle), role of chlorofluorocarbons (CFCs / Freons), catalytic destruction of O₃ by chlorine free radicals (Cl•)",
  "Effects of UV Radiation & Abatement Strategies: Harmful impacts of UV-B radiation (skin cancer, cataracts, phytoplankton decline); Montreal Protocol, phasing out CFCs, and global carbon mitigation strategies"
];

export const INTERNAL_ASSESSMENT_CHEMISTRY_ICSE9_SUBTOPICS = [
  "Overview of Paper II (20 Marks): School-assessed practical laboratory coursework, experimental record maintenance, qualitative chemical identification, and viva-voce examination framework",
  "Experiment 1 — Action of Heat on Substances: Heating copper carbonate (green to black CuO), zinc carbonate (white to yellow hot/white cold ZnO), lead nitrate (crackling sound, brown NO₂ gas, yellow PbO residue), and ammonium chloride (sublimation)",
  "Experiment 2 — Flame Tests for Metal Cations: Performing flame tests with platinum / nichrome wire and conc. HCl for Sodium (golden yellow), Potassium (lilac), and Calcium (brick red)",
  "Experiment 3 — Identification of Gases: Confirmatory chemical and sensory tests for H₂ (pop sound), O₂ (relights glowing splint), CO₂ (lime water milky), Cl₂ (bleaches litmus), HCl (dense white fumes with NH₃), SO₂ (acidified K₂Cr₂O₇ turns green), H₂S (rotten egg smell, lead acetate paper black), NO₂ (brown gas, turns KI-starch paper blue), and NH₃ (turns Nessler's reagent brown)",
  "Experiment 4 — Solubility & Saturated Solutions: Preparing a saturated solution of potassium nitrate / copper sulphate at room temperature, determining solubility, and observing crystal formation upon cooling",
  "Experiment 5 — Chemical Reactions & Precipitate Observation: Differentiating precipitation (AgNO₃ + NaCl → AgCl↓ white precipitate), neutralization, displacement, and gas evolution reactions in test tubes",
  "Practical Record Book (10 Marks) & Viva-Voce (10 Marks): ICSE evaluation rubrics for systematic experimental observations, balanced chemical equations, apparatus diagrams, and oral defense of laboratory chemistry principles"
];

export const BASIC_BIOLOGY_ICSE9_SUBTOPICS = [
  "The Cell — Fundamental Unit of Life: Cell theory, protoplasm, detailed structural components of plant and animal cells, key differences between plant and animal cells, prokaryotic vs eukaryotic cells",
  "Cell Organelles & Functions: Structure and functions of Cell Wall, Cell Membrane (fluid mosaic model), Nucleus (nuclear membrane, chromatin, nucleolus), Mitochondria (cellular respiration, ATP synthesis), Chloroplast (thylakoids, stroma, photosynthesis), Ribosomes (protein synthesis), Golgi Complex (secretion, packaging), Endoplasmic Reticulum (RER, SER), Vacuoles, Centrosome & Centrioles (spindle formation in animal cells), and Lysosomes (suicide bags, intracellular digestion)",
  "Plant Tissues — Meristematic & Permanent: Meristematic tissues (apical and lateral cambium characteristics and active cell division); Simple permanent tissues (Parenchyma, Collenchyma, Sclerenchyma structures and mechanical/storage functions); Complex permanent tissues (Xylem vessels/tracheids for water transport, Phloem sieve tubes/companion cells for food translocation)",
  "Animal Tissues — Classification & Characteristics: Epithelial tissues (squamous, cuboidal, columnar, ciliated, stratified); Connective tissues (Areolar, Adipose fat storage, Skeletal: bone & cartilage, Fluid: blood components & lymph); Muscular tissues (Striated skeletal voluntary, Unstriated visceral involuntary, Cardiac heart muscle); Nervous tissue (Neuron structure: cyton, dendrites, axon, myelin sheath, synapse)"
];

export const FLOWERING_PLANTS_ICSE9_SUBTOPICS = [
  "Vegetative Plant Morphology: Structural adaptations and functions of root systems (taproot vs fibrous roots), stems (nodes, internodes, support), leaves (petiole, lamina, venation patterns: reticulate vs parallel), and fruits (pericarp: epicarp, mesocarp, endocarp; true vs false fruits)",
  "Structure of a Bisexual Flower: Detailed anatomy of floral whorls — Calyx (sepals, epicalyx), Corolla (petals, polypetalous vs gamopetalous), Androecium (stamens: filament, bilobed anther, pollen grains), and Gynoecium/Pistil (carpels: receptive stigma, style, ovary containing ovules with embryo sac)",
  "Floral Types, Inflorescence & Placentation: Complete vs incomplete flowers, bisexual (hermaphrodite) vs unisexual (staminate, pistillate, monoecious, dioecious), actinomorphic vs zygomorphic symmetry; Elementary concepts of inflorescence and ovary placentation (marginal, axile, parietal, free-central, basal)",
  "Pollination — Mechanisms & Agents: Definition and comparison of Self-pollination (Autogamy, Geitonogamy) vs Cross-pollination (Allogamy / Xenogamy); Contrivances favoring self and cross-pollination (dichogamy, protandry, protogyny, herkogamy, self-sterility); Agents of pollination (Anemophily wind, Entomophily insects, Hydrophily water, Ornithophily birds) and flower adaptations; Advantages and disadvantages of pollination types",
  "Fertilization Process in Angiosperms: Pollen grain germination on stigma, pollen tube growth through style guided by chemotropism, entry into ovule through micropyle, discharge of two male gametes, Syngamy (male gamete + egg cell → diploid zygote) and Triple Fusion (second male gamete + definitive secondary nucleus → triploid primary endosperm nucleus), Double Fertilization significance, and post-fertilization transformations (ovule → seed, ovary → fruit)",
  "Structure and Germination of Seeds: Morphology and anatomy of Monocotyledonous albuminous seed (Maize grain: pericarp + testa fused, endosperm, aleurone layer, scutellum, coleoptile, coleorhiza) and Dicotyledonous exalbuminous seed (Bean seed: testa, tegmen, hilum, micropyle, cotyledons, embryo axis: plumule and radicle)",
  "Types of Germination & Environmental Factors: Epigeal germination (hypocotyl elongates, cotyledons pushed above soil, e.g., bean, castor) vs Hypogeal germination (epicotyl elongates, cotyledons remain below soil, e.g., pea, maize, gram); Essential conditions for germination (water/moisture for enzyme activation, oxygen for respiration, suitable temperature 25°C-35°C); Experimental verification using the Three-Bean experiment and pyrogallic acid oxygen absorption setup"
];

export const HUMAN_ANATOMY_PHYSIOLOGY_ICSE9_SUBTOPICS = [
  "Nutrition, Balanced Diet & Food Components: Meaning of nutrition, balanced diet requirements, macronutrients (carbohydrates, proteins, fats) and micronutrients (vitamins A, B-complex, C, D, E, K; minerals: calcium, iron, iodine, phosphorus, sodium, potassium), dietary fiber / roughage, and water; Protein-Energy Malnutrition (PEM) deficiency syndromes: Kwashiorkor (protein deficiency in toddlers, oedema, protruding belly) and Marasmus (caloric & protein deficiency in infants, severe emaciation)",
  "Anatomy of the Human Digestive System: Alimentary canal structure — Mouth cavity, dentition (types of teeth: incisors, canines, premolars, molars, dental formula 2123/2123, structure of a tooth: enamel, dentine, pulp cavity), Pharynx, Oesophagus (peristalsis), Stomach (cardiac, fundus, pylorus, gastric glands), Small intestine (duodenum, jejunum, ileum, villi adaptations for absorption), Large intestine (caecum, appendix, colon, rectum, anus); Digestive glands: Salivary glands (parotid, submandibular, sublingual), Liver (bile production, gall bladder storage, emulsification of fats), Pancreas (exocrine pancreatic juice with amylase, trypsin, lipase, and endocrine islets)",
  "Mechanism of Digestion, Absorption & Assimilation: Step-by-step chemical digestion across organs: Salivary digestion (salivary amylase / ptyalin: starch → maltose), Gastric digestion (HCl acid activation, pepsin: proteins → peptones/proteoses, rennin in infants), Pancreatic & Intestinal digestion (pancreatic amylase, trypsinogen activation by enterokinase, steapsin/lipase: fats → fatty acids + glycerol, intestinal peptidases, maltase, sucrase, lactase); Absorption of nutrients into blood capillaries (glucose, amino acids) and lacteals (fatty acids, glycerol via lymph), assimilation in tissues, and egestion of undigested waste",
  "The Human Skeletal System & Framework: Functions of the skeleton (support, organ protection, locomotion, hemopoiesis in bone marrow, mineral reservoir); Axial Skeleton (Skull: cranium & facial bones, Vertebral Column: 33 vertebrae - cervical, thoracic, lumbar, sacral, coccygeal, Rib cage: 12 pairs - true ribs 1-7, false ribs 8-10, floating ribs 11-12, Sternum); Appendicular Skeleton (Pectoral Girdle & Upper Limbs: humerus, radius, ulna, carpals, metacarpals, phalanges; Pelvic Girdle & Lower Limbs: femur, patella, tibia, fibula, tarsals, metatarsals, phalanges)",
  "Joints, Ligaments, Tendons & Movement: Classification of joints: Immovable / Synarthrosis (sutures of skull), Partially movable / Amphiarthrosis (intervertebral discs, pubic symphysis), Freely movable / Synovial / Diarthrosis joints: Hinge joint (elbow, knee), Ball-and-Socket joint (shoulder, hip), Pivot joint (atlas-axis joint, radius-ulna), Gliding joint (wrist carpals, ankle tarsals); Synovial membrane, synovial fluid, ligaments (bone to bone), and tendons (muscle to bone)",
  "Skin — Structure, Functions & Thermoregulation: Structure of human skin — Epidermis (Stratum corneum cornified layer, Stratum lucidum/granulosum, Stratum malpighii / germinativum with melanin pigment) and Dermis (connective tissue, blood vessels, nerve endings, hair follicles, sebaceous glands producing sebum, sweat / sudoriferous glands); Skin functions: mechanical protection, microbial barrier, tactile/thermal sensation, excretion of urea/salts in sweat, Vitamin D synthesis; Thermoregulatory homeostatic mechanism: responses to heat (cutaneous vasodilation, profuse sweating & evaporative cooling) vs responses to cold (cutaneous vasoconstriction, reduction of sweat, arrector pili hair erection, shivering thermogenesis)",
  "The Respiratory System & Gas Exchange: Distinction between external respiration (breathing / ventilation), internal tissue respiration, and cellular biochemical respiration; Respiratory tract anatomy (External nares, nasal cavity with ciliated mucus lining, pharynx, epiglottis, larynx / voice box with vocal cords, trachea with C-shaped cartilaginous rings, bronchi, bronchioles, terminal alveoli with capillary meshwork); Mechanism of breathing: Inspiration (diaphragm contracts & flattens, external intercostal muscles contract, rib cage moves upwards and outwards, thoracic volume increases, intrapulmonary pressure drops) and Expiration (diaphragm and intercostals relax, rib cage moves downwards and inwards, thoracic volume decreases, air expelled); Aerobic respiration (C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + 38 ATP) vs Anaerobic respiration (lactic acid fermentation in muscles, alcoholic fermentation in yeast yielding 2 ATP); Transport of respiratory gases (O₂ as oxyhaemoglobin, CO₂ as carbaminohaemoglobin, dissolved in plasma, and bicarbonate ions HCO₃⁻); Respiratory capacities (Tidal volume, Vital capacity, Residual volume) and common disorders (Asthma, Bronchitis, Pneumonia, Hypoxia)"
];

export const HEALTH_HYGIENE_ICSE9_SUBTOPICS = [
  "Concepts of Health, Hygiene & Disease Classification: World Health Organization (WHO) definition of health (state of complete physical, mental, and social well-being); Personal and community hygiene; Disease classification: Communicable / Infectious diseases vs Non-communicable diseases (deficiency, degenerative, metabolic, allergic, cancerous, genetic)",
  "Infectious Diseases — Pathogens, Vectors & Symptoms: Detailed study of communicable diseases by causal agents: Bacterial diseases — Tuberculosis (Mycobacterium tuberculosis, BCG vaccine), Typhoid (Salmonella typhi, Widal test, TAB vaccine), Cholera (Vibrio cholerae, dehydration, ORS treatment); Viral diseases — Common Cold (Rhinovirus), Influenza, AIDS (Human Immunodeficiency Virus HIV targeting T-helper lymphocytes, ELISA test, preventive measures), Chickenpox (Varicella-zoster virus), Hepatitis (Hepatitis viruses A, B, C; jaundice symptoms); Protozoan diseases — Malaria (Plasmodium vivax/falciparum transmitted by female Anopheles mosquito, lifecycle, quinine/artemisinin treatment), Amoebic Dysentery (Entamoeba histolytica, cyst contamination); Fungal diseases — Ringworm / Tinea (Trichophyton, Microsporum, itchy circular skin lesions)",
  "Immunity & Body Defense Mechanisms: First line of defense (skin, mucous membranes, saliva lysozyme, stomach HCl, tears); Second line of defense (phagocytic white blood cells, macrophages, inflammatory response); Third line of defense — Specific immune response: Innate / Inborn natural immunity vs Acquired / Adaptive immunity; Active immunity (naturally acquired through infection, artificially acquired through vaccination) vs Passive immunity (maternal antibodies via placenta/colostrum, administration of readymade antisera / antivenom / antitoxins)",
  "Vaccination & Immunization Schedules: Meaning of vaccine (killed, attenuated, toxoids, or recombinant antigens), principle of immunological memory, active immunization; National immunization schedule for infants: BCG (tuberculosis), DPT / Pentavalent (Diphtheria, Pertussis whooping cough, Tetanus), OPV/IPV (Polio), MMR (Measles, Mumps, Rubella), Hepatitis B, and booster doses",
  "First Aid Principles & Emergency Handling: Aims of first aid (preserve life, prevent deterioration, promote recovery); Management protocols: Fractures (immobilization, splints, slings), Burns and scalds (cooling with cold water, sterile non-stick dressings, avoiding bursting blisters), External bleeding and haemorrhage (direct pressure, elevation, pressure points, sterile tourniquets), and Snake bites (calming victim, immobilizing bitten limb, applying broad bandage below heart level, avoiding cutting/sucking wound, immediate hospital antivenom administration)"
];

export const WASTE_MANAGEMENT_ICSE9_SUBTOPICS = [
  "Waste Accumulation & Categories: Definition of waste; Classification based on degradability — Biodegradable waste (organic food scraps, sewage, paper, agricultural biomass decomposed by microbial action) vs Non-biodegradable waste (plastics, polythene, glass, synthetic chemicals, heavy metals, e-waste persisting in environment); Sources of waste: Domestic (kitchen waste, packaging, wastewater), Industrial (fly ash, chemical effluents, toxic sludge, slag), Agricultural (pesticide residues, fertilizer runoff, crop stubble, animal manure), and Commercial / Biomedical (hospital syringes, anatomical waste, contaminated cotton)",
  "Environmental & Health Impacts of Improper Waste: Ecological degradation, bioaccumulation and biomagnification of persistent organic pollutants (DDT, heavy metals like Mercury Minamata disease and Cadmium Itai-itai disease); Air pollution from open burning (dioxins, furans, toxic smog); Water pollution & eutrophication of lakes; Soil contamination, disruption of soil microbial flora; Vector proliferation (breeding of flies, mosquitoes, rodents causing epidemics of cholera, dengue, plague)",
  "Methods of Safe Waste Disposal: Source segregation of waste (color-coded bins: green for biodegradable, blue for dry recyclables, red/yellow for hazardous/biomedical waste); Open dumping vs Sanitary Landfills (site selection, impermeable clay/geomembrane liners, leachate collection and treatment systems, methane gas monitoring); Composting (aerobic microbial decomposition into nutrient-rich humus) and Vermicomposting (using earthworms like Eisenia fetida for rapid bio-fertilizer production); Incineration (high-temperature thermal destruction of hazardous hospital/chemical waste, pollution control scrubbers, bottom ash management)",
  "The 3 R's Strategy & Waste Minimization: Reduce (minimizing consumption, reducing single-use plastics, packaging optimization), Reuse (repurposing containers, glass bottles, repair and refill models), Recycle (mechanical and chemical reprocessing of paper, plastic polymers, scrap aluminum/steel, glass into new manufactured goods); Upcycling, circular economy principles, Extended Producer Responsibility (EPR), and community civic participation in waste stewardship"
];

export const INTERNAL_ASSESSMENT_BIOLOGY_ICSE9_SUBTOPICS = [
  "Overview of Paper II (20 Marks): Framework for school-level continuous internal assessment in ICSE Class 9 Biology: Practical laboratory exercises, record maintenance, specimen spot identification, and viva-voce examination",
  "Experiment 1 — Microscopic Examination of Cells: Preparation and staining of temporary mounts of onion peel (plant cell wall, nucleus, vacuole) and human cheek epithelial cells (plasma membrane, cytoplasm, prominent nucleus) under compound microscope",
  "Experiment 2 — Food Tests for Biochemical Components: Testing food samples for Starch (Iodine test giving blue-black coloration), Reducing Sugars / Glucose (Benedict's / Fehling's reagent giving green to brick-red precipitate on heating), Proteins (Biuret test giving violet/purple color, Xanthoproteic test), and Fats/Lipids (translucent grease-spot test on filter paper, Sudan III staining)",
  "Experiment 3 — Physiological Seed Germination Setups: Setting up and recording observations for the Three-Bean experiment to verify the necessity of water, air (oxygen), and warmth; Demonstration of oxygen consumption during germination using germinating seeds and alkaline pyrogallol setup",
  "Experiment 4 — Flower Dissection & Floral Parts Identification: Dissecting and mounting floral parts of a bisexual flower (e.g., Hibiscus / Petunia / Brassica) to identify sepals, petals, stamen structure (anther, filament, pollen), and pistil structure (stigma, style, ovary transverse section showing ovules and placentation)",
  "Experiment 5 — Specimen Spotting & Model Identification: Spot identification and functional labeling of permanent slides (plant tissues: parenchyma, collenchyma, sclerenchyma, xylem, phloem; animal tissues: squamous epithelium, striated muscle, blood smear, nerve cell), human skeletal bones (skull, ribs, vertebrae, pelvic girdle, femur, humerus), and lung bell-jar breathing model",
  "Practical Record Book (10 Marks) & Viva-Voce (10 Marks): ICSE evaluation rubrics for systematically recorded neat pencil biological diagrams, labelled parts, accurate observations, and viva-voce questioning on experimental physiology and cell biology"
];

export const BIOLOGY_ICSE_CLASS9_LESSONS = [
  "1. Basic Biology: The Cell & Tissues",
  "2. Flowering Plants: Morphology, Flowers, Pollination, Fertilization & Seeds",
  "3. Human Anatomy and Physiology: Digestion, Skeleton, Skin & Respiration",
  "4. Health and Hygiene: Diseases, Immunity & First Aid",
  "5. Waste Generation and Management: Sources, Impact & The 3 Rs",
  "6. Paper II: Internal Assessment & Practical Biology (20 Marks)"
];

export const CHEMISTRY_ICSE_CLASS9_LESSONS = [
  "1. The Language of Chemistry",
  "2. Chemical Changes and Reactions",
  "3. Water: Solutions, Hydration & Hardness",
  "4. Atomic Structure and Chemical Bonding",
  "5. The Periodic Table & Periodic Properties",
  "6. Study of the First Element — Hydrogen",
  "7. Study of Gas Laws: Boyle's & Charles' Law",
  "8. Atmospheric Pollution: Acid Rain, Global Warming & Ozone Depletion",
  "9. Paper II: Internal Assessment & Practical Chemistry (20 Marks)"
];

export const PHYSICS_ICSE_CLASS9_LESSONS = [
  "1. Measurements and Experimentation",
  "2. Motion in One Dimension",
  "3. Laws of Motion",
  "4. Fluids: Pressure in Fluids and Archimedes' Principle",
  "5. Heat and Energy",
  "6. Light: Reflection of Light & Spherical Mirrors",
  "7. Sound: Propagation & Ultrasonic Waves",
  "8. Electricity and Magnetism",
  "9. Paper II: Internal Assessment & Practical Physics (20 Marks)"
];

export const PHYSICS_ICSE_CLASS11_LESSONS = [
  "Unit 1: Physical World and Measurement",
  "Unit 2: Kinematics",
  "Unit 3: Laws of Motion",
  "Unit 4: Work, Energy, and Power",
  "Unit 5: Motion of System of Particles and Rigid Body",
  "Unit 6: Gravitation",
  "Unit 7: Properties of Bulk Matter",
  "Unit 8: Heat and Thermodynamics",
  "Unit 9: Behaviour of Perfect Gases and Kinetic Theory of Gases",
  "Unit 10: Oscillations and Waves",
  "Paper II: Practical Work & Project (30 Marks)"
];

export const BIOLOGY_ICSE_CLASS11_LESSONS = [
  "Unit 1: Diversity of Living Organisms",
  "Unit 2: Structural Organisation in Animals and Plants",
  "Unit 3: Cell: Structure and Function",
  "Unit 4: Plant Physiology",
  "Unit 5: Human Physiology",
  "Paper II: Practical Work & Project (30 Marks)"
];

export const CHEMISTRY_ICSE_CLASS11_LESSONS = [
  "Unit 1: Some Basic Concepts of Chemistry",
  "Unit 2: Structure of Atom",
  "Unit 3: Classification of Elements and Periodicity in Properties",
  "Unit 4: Chemical Bonding and Molecular Structure",
  "Unit 5: Chemical Thermodynamics",
  "Unit 6: Equilibrium",
  "Unit 7: Redox Reactions",
  "Unit 8: Organic Chemistry – Some Basic Principles and Techniques",
  "Unit 9: Hydrocarbons",
  "Paper II: Practical Work, Project Work & Viva-Voce (20 Marks)"
];

export const MATHEMATICS_ICSE_CLASS9_LESSONS = [
  "1. Pure Arithmetic: Rational and Irrational Numbers",
  "2. Commercial Mathematics: Compound Interest",
  "3. Algebra: Expansions",
  "4. Algebra: Factorisation",
  "5. Algebra: Simultaneous Linear Equations",
  "6. Algebra: Indices / Exponents",
  "7. Algebra: Logarithms",
  "8. Geometry: Triangles (Congruency & Inequalities)",
  "9. Geometry: Mid-point and Intercept Theorems",
  "10. Geometry: Rectilinear Figures (Quadrilaterals)",
  "11. Geometry: Circles (Chord & Angle Properties)",
  "12. Mensuration: Area of Plane Figures",
  "13. Mensuration: Surface Area and Volume of 3D Solids",
  "14. Coordinate Geometry: Cartesian System & Distance Formula",
  "15. Trigonometry: Trigonometrical Ratios & Simple Identities",
  "16. Statistics: Data Representation & Measures of Central Tendency",
  "17. Paper II: Internal Assessment & Mathematical Projects (20 Marks)"
];

export const MATHEMATICS_ICSE_CLASS10_LESSONS = [
  "1. Commercial Math: Goods and Services Tax (GST)",
  "2. Commercial Math: Banking (Recurring Deposit Accounts)",
  "3. Algebra: Linear Inequations in One Variable",
  "4. Algebra: Quadratic Equations in One Variable",
  "5. Algebra: Ratio and Proportion",
  "6. Algebra: Factorization of Polynomials (Remainder & Factor Theorems)",
  "7. Algebra: Matrices",
  "8. Algebra: Arithmetic & Geometric Progressions (A.P. & G.P.)",
  "9. Coordinate Geometry: Reflection & Symmetry",
  "10. Coordinate Geometry: Section & Midpoint Formulae",
  "11. Coordinate Geometry: Equation of a Straight Line",
  "12. Geometry: Similarity of Triangles & Scale Maps",
  "13. Geometry: Loci (Locus & Constructions)",
  "14. Geometry: Circles (Angle, Cyclic & Tangent Properties)",
  "15. Mensuration: Surface Area & Volume of 3D Solids",
  "16. Trigonometry: Trigonometrical Identities & Angles",
  "17. Trigonometry: Heights and Distances",
  "18. Statistics: Measures of Central Tendency (Mean, Median, Mode & Ogives)",
  "19. Probability: Single Event Theoretical Probability",
  "20. Paper II: Internal Assessment & Practical Work (20 Marks)"
];

export const GST_ICSE10_SUBTOPICS = [
  "GST Computation: CGST, SGST for intra-state and IGST for inter-state transactions",
  "Multi-Stage Supply Chain: Tax computation across manufacturer, wholesaler, retailer, and consumer",
  "Bill Calculations: Finding list price, discount, Input Tax Credit (ITC), net tax paid, and total bill amount"
];

export const BANKING_ICSE10_SUBTOPICS = [
  "Recurring Deposit (RD) Account: Concept of monthly deposits (P) over n months at rate r% p.a.",
  "Interest Computation: Application of monthly equivalent principal formula I = P × n(n+1)/24 × r/100",
  "Maturity Value & Variables: Calculating Maturity Value MV = P × n + I, solving for P, n (in months), or r"
];

export const LINEAR_INEQUALITIES_ICSE10_SUBTOPICS = [
  "Algebraic Solution: Solving linear inequalities in one variable over Natural (N), Whole (W), Integer (Z), and Real (R) number domains",
  "Number Line Representation: Graphing solution sets on real number lines with filled/open endpoint circles",
  "Set Notation: Expressing solution sets in set-builder and interval forms"
];

export const QUADRATIC_EQUATIONS_ICSE10_SUBTOPICS = [
  "Methods of Solution: Solving ax² + bx + c = 0 by factorization and quadratic formula x = (-b ± √(b² - 4ac)) / (2a)",
  "Discriminant & Nature of Roots: Real & distinct (D > 0), real & equal (D = 0), and non-real roots (D < 0)",
  "Word Problems: Applied problems on numbers, speed-distance-time, geometry, work-rate, and commercial problems"
];

export const RATIO_PROPORTION_ICSE10_SUBTOPICS = [
  "Ratio & Proportion Fundamentals: Duplicate, triplicate, sub-duplicate ratios; continued and mean proportionals",
  "Properties of Proportion: Application of Componendo, Dividendo, Alternando, Invertendo, and Addendo rules",
  "Direct Algebraic Applications: Solving complex rational equations using proportion properties"
];

export const FACTORIZATION_POLYNOMIALS_ICSE10_SUBTOPICS = [
  "Remainder Theorem: Evaluating remainder R = f(a) when polynomial f(x) is divided by (x - a)",
  "Factor Theorem: Proving (x - a) is a factor of f(x) if f(a) = 0",
  "Complete Factorization: Factorizing cubic polynomials into linear factors using Factor Theorem"
];

export const MATRICES_ICSE10_SUBTOPICS = [
  "Matrix Fundamentals & Types: Order of matrix (m × n), row, column, square, zero, and identity (I) matrices",
  "Matrix Operations: Addition, subtraction, scalar multiplication, and matrix multiplication (A × B)",
  "Matrix Equations: Solving 2 × 2 matrix equations for unknown elements and variables"
];

export const PROGRESSIONS_ICSE10_SUBTOPICS = [
  "Arithmetic Progression (A.P.): General term a_n = a + (n - 1)d, sum of n terms S_n = n/2 [2a + (n - 1)d] or n/2 (a + l)",
  "Geometric Progression (G.P.): General term a_n = a · r^(n-1), sum S_n = a(r^n - 1)/(r - 1)",
  "Word Problems: Applications of A.P. and G.P. in real-world scenarios and sequences"
];

export const REFLECTION_ICSE10_SUBTOPICS = [
  "Coordinate Reflection: Reflection of points P(x, y) in x-axis, y-axis, and origin (0, 0)",
  "Invariant Points: Identifying points remaining unchanged under specific reflections",
  "Geometric Figures by Reflection: Plotting transformed points to form symmetrical polygons and calculating perimeter/area"
];

export const SECTION_MIDPOINT_ICSE10_SUBTOPICS = [
  "Section Formula: Internal division of line segment joining (x1, y1) and (x2, y2) in ratio m:n -> ((mx2 + nx1)/(m+n), (my2 + ny1)/(m+n))",
  "Midpoint Formula: Finding midpoint coordinates ((x1 + x2)/2, (y1 + y2)/2)",
  "Centroid of Triangle: Coordinates of centroid ((x1 + x2 + x3)/3, (y1 + y2 + y3)/3)"
];

export const EQUATION_LINE_ICSE10_SUBTOPICS = [
  "Slope of a Line: Gradient m = tan θ = (y2 - y1) / (x2 - x1); Parallel lines (m1 = m2) and Perpendicular lines (m1 · m2 = -1)",
  "Forms of Line Equation: Slope-intercept form (y = mx + c), Point-slope form (y - y1 = m(x - x1)), Two-point form",
  "X and Y Intercepts: Finding x-intercept, y-intercept, and distance from origin"
];

export const SIMILARITY_ICSE10_SUBTOPICS = [
  "Axioms of Similarity: Angle-Angle (AA), Side-Angle-Side (SAS), Side-Side-Side (SSS) similarity criteria",
  "Basic Proportionality Theorem (Thales Theorem): Ratio of sides and parallel line segments in similar triangles",
  "Area Ratio & Scale Maps: Ratio of areas of similar triangles equals square of ratio of corresponding sides; Scale factor (k), map distances, actual areas and volumes"
];

export const LOCI_ICSE10_SUBTOPICS = [
  "Locus Concepts: Definition of locus as a set of points satisfying given geometric conditions",
  "Standard Loci Theorems: Locus equidistant from two fixed points (perpendicular bisector) and two intersecting lines (angle bisector)",
  "Constructing Loci: Geometric constructions combining ruler-compass loci and circle/line intersections"
];

export const CIRCLES_PROPERTIES_ICSE10_SUBTOPICS = [
  "Angle Properties: Angle subtended at center is twice angle at circumference; Angles in same segment are equal; Angle in semicircle is 90°",
  "Cyclic Quadrilaterals: Opposite angles sum to 180°; Exterior angle equals interior opposite angle",
  "Tangent & Secant Properties: Tangent is perpendicular to radius at point of contact; Tangents from external point are equal; Alternate Segment Theorem; Intersecting Chords Theorem PA × PB = PC × PD"
];

export const MENSURATION_3D_ICSE10_SUBTOPICS = [
  "Right Circular Cylinder & Cone: Curved surface area, total surface area, and volume of cylinder and cone",
  "Sphere & Hemisphere: Surface area and volume of spheres and hemispheres",
  "Combination of Solids & Melting: Recasting solids (melting and reshaping), hollow solids, and composite shapes"
];

export const TRIGONOMETRY_IDENTITIES_ICSE10_SUBTOPICS = [
  "Fundamental Identities: Proving sin²θ + cos²θ = 1, 1 + tan²θ = sec²θ, 1 + cot²θ = cosec²θ",
  "Complementary Angles: Evaluating trig ratios for (90° - θ)",
  "Trigonometric Tables: Reading values for standard and non-standard angles"
];

export const HEIGHTS_DISTANCES_ICSE10_SUBTOPICS = [
  "Angles of Elevation & Depression: Visualizing line of sight, horizontal level, elevation and depression angles",
  "2D Trigonometric Problems: Solving right-angled triangles using 30°, 45°, 60° angles",
  "Multi-Observer Problems: Calculating heights of towers/buildings and distances between moving objects"
];

export const STATISTICS_ICSE10_SUBTOPICS = [
  "Measures of Central Tendency: Mean (Direct, Assumed Mean, Step-deviation methods for grouped data)",
  "Median & Quartiles Graphically: Constructing Cumulative Frequency curves (Ogives) to determine Median, Lower Quartile (Q1), Upper Quartile (Q3), Interquartile Range",
  "Mode Graphically: Determining mode from frequency histograms"
];

export const PROBABILITY_ICSE10_SUBTOPICS = [
  "Single Event Probability: Definition P(E) = (Number of favorable outcomes) / (Total number of possible outcomes)",
  "Sample Spaces: Dice rolls, coin tosses, playing cards, colored balls, and number selection problems",
  "Complementary Events: Probability of occurrence and non-occurrence P(E) + P(not E) = 1"
];

export const MATHEMATICS_ICSE_CLASS11_LESSONS = [
  "1. Section A: Sets",
  "2. Section A: Relations and Functions",
  "3. Section A: Trigonometry",
  "4. Section A: Principle of Mathematical Induction",
  "5. Section A: Complex Numbers and Quadratic Equations",
  "6. Section A: Linear Inequalities",
  "7. Section A: Permutations and Combinations",
  "8. Section A: Binomial Theorem",
  "9. Section A: Sequence and Series",
  "10. Section A: Straight Lines",
  "11. Section A: Circles",
  "12. Section A: Calculus - Limits and Derivatives",
  "13. Section A: Statistics",
  "14. Section A: Probability",
  "15. Section B (Optional Track A): Conic Sections",
  "16. Section B (Optional Track A): Introduction to Three-Dimensional Geometry",
  "17. Section B (Optional Track A): Mathematical Reasoning",
  "18. Section C (Optional Track B): Statistics (Commercial Track - Combined Mean & Expectation)",
  "19. Section C (Optional Track B): Correlation and Regression Analysis",
  "20. Section C (Optional Track B): Index Numbers and Moving Averages",
  "21. Paper II: Project Work & Viva-Voce (20 Marks)"
];

export const OOP_CONCEPTS_ICSE9_SUBTOPICS = [
  "Principles of OOP: Introduction to Object-Oriented Programming, Difference between OOP and Procedure-Oriented Programming (POP)",
  "Core OOP Pillars: Real-world definitions and significance of Abstraction, Encapsulation, Inheritance, and Polymorphism",
  "Software Design Paradigms: Real-world modeling, modularity, reusability, maintainability, and data security advantages of OOP over POP"
];

export const OBJECTS_CLASSES_ICSE9_SUBTOPICS = [
  "Objects as Real-World Entities: State (attributes/characteristics) and Behavior (methods/actions) of objects",
  "Classes as Blueprints: Definition of a class as an object factory, user-defined data type, and template",
  "Object Realization & Lifecycle: Instantiation using 'new' operator, memory allocation, declaring reference variables, and invoking member methods"
];

export const VALUES_DATA_TYPES_ICSE9_SUBTOPICS = [
  "Character Set & Encoding: Unicode character encoding system, ASCII vs Unicode standards",
  "Java Tokens & Identifiers: Keywords, Identifiers, Literals (integer, floating-point, character, boolean, string, null), Punctuators/Separators, and Operators; Rules for naming identifiers",
  "Primitive Data Types: byte, short, int, long, float, double, char, boolean — sizes in bits/bytes, default values, and range of values",
  "Non-Primitive Data Types: Reference types (Classes, Arrays, Interfaces) vs Primitive types",
  "Variables & Constants: Declaration, initialization, scope (local vs instance), and using the 'final' keyword for constants",
  "Type Conversion: Implicit type conversion (widening) vs Explicit type casting (narrowing), truncation, and precision loss rules"
];

export const OPERATORS_JAVA_ICSE9_SUBTOPICS = [
  "Arithmetic & Relational Operators: Basic arithmetic (+, -, *, /, %), modulus behavior with negative operands, and relational comparison operators (<, <=, >, >=, ==, !=)",
  "Logical & Assignment Operators: Logical operators (&&, ||, !), short-circuit evaluation, simple assignment (=), and shorthand compound assignment (+=, -=, *=, /=, %=)",
  "Unary & Increment/Decrement Operators: Unary plus/minus, Prefix vs Postfix increment (++) and decrement (--), step-by-step evaluation of complex nested expressions",
  "Ternary Operator: Conditional operator (condition ? expr1 : expr2) as a compact alternative to simple if-else",
  "Operator Precedence & Associativity: Operational hierarchy, order of evaluation, associativity rules, and parenthetical override"
];

export const INPUT_JAVA_ICSE9_SUBTOPICS = [
  "Initialization vs Dynamic Input: Literal assignment at compilation vs dynamic keyboard input during runtime",
  "Scanner Class & Keyboard Input: Importing java.util.Scanner, creating Scanner object with System.in, methods: next(), nextLine(), nextInt(), nextDouble(), nextFloat(), nextLong(), nextShort(), nextByte(), nextBoolean(), and next().charAt(0)",
  "Data Input Exceptions: Understanding common runtime input errors, InputMismatchException, buffer flushing issues between nextInt() and nextLine()",
  "Types of Program Errors: Syntax errors (compilation errors), Runtime errors (exceptions like division by zero, null pointer), and Logical errors (incorrect formula/output)"
];

export const MATH_LIBRARY_JAVA_ICSE9_SUBTOPICS = [
  "Standard Math Library Methods: Using java.lang.Math functions: Math.sin(), Math.cos(), Math.tan(), Math.asin(), Math.acos(), Math.atan(), Math.pow(), Math.sqrt(), Math.cbrt(), Math.log(), Math.abs(), Math.ceil(), Math.floor(), Math.round(), Math.min(), Math.max(), Math.random()",
  "Math Class Constants: Mathematical constants Math.PI (π ≈ 3.14159...) and Math.E (Euler's number e ≈ 2.71828...)",
  "Writing Java Mathematical Expressions: Converting standard algebraic formulas and quadratic/trigonometric expressions into syntactically valid Java code"
];

export const CONDITIONAL_CONSTRUCTS_ICSE9_SUBTOPICS = [
  "Decision-Making Statements: Simple if, if-else, nested if-else constructs, and multi-way branching using if-else-if ladder",
  "Switch Statement: Syntax of switch-case, role of break statement to prevent fall-through, default label, allowed switch expression types (byte, short, char, int, String, enum)",
  "Comparing Switch vs If-Else-If: Performance, readability, limitations of switch (relational expressions vs constant values)",
  "Dangling Else Problem & System Exit: Ambiguous else association, curly braces block resolution, and terminating execution using System.exit(0)"
];

export const ITERATIVE_CONSTRUCTS_ICSE9_SUBTOPICS = [
  "Iteration & Loop Mechanics: Need for loops, 4 essential components: initialization, test condition, body of loop, update expression (step value)",
  "Entry-Controlled vs Exit-Controlled Loops: for loop and while loop (entry-controlled) vs do-while loop (exit-controlled, guaranteed at least one execution)",
  "Jump Statements in Loops: Using break to exit loop immediately, and continue to skip the current iteration",
  "Nested Loops & Pattern Printing: Double loop execution cycle, row-column coordinate logic, printing number grids, character triangles, inverted pyramids, and Floyd's triangle",
  "Infinite Loops & Off-by-One Errors: Common looping pitfalls, loop termination conditions, and tracing loop variables",
  "Standard Number Algorithms: Digit extraction (n % 10, n / 10), sum & product of digits, reversing numbers, Prime check, Armstrong number, Palindrome number, Perfect number, Automorphic number, Neon number, and Special number checks"
];

export const INTERNAL_ASSESSMENT_CS_ICSE9_SUBTOPICS = [
  "Practical Lab Work Overview (80 Marks): Designing, coding, compiling, and debugging a minimum of 15-20 robust Java programs in an IDE (BlueJ / Eclipse)",
  "Core Practical Problem Domains: Formula evaluation, menu-driven programs using switch-case and loops, number property checks, pattern printing, and basic character/string manipulation",
  "Viva-Voce & Oral Defense (10 Marks): Oral examination defending program logic, variable role tracking, Dry Run / Variable Description Table, and algorithmic time considerations",
  "Logbook & Record Documentation (10 Marks): Systematic maintenance of problem statements, algorithm/flowchart design, commented Java source code, variable descriptions, and multi-case test run outputs"
];

export const COMPUTER_SCIENCE_ICSE_CLASS9_LESSONS = [
  "1. Introduction to Object-Oriented Programming Concepts",
  "2. Elementary Concept of Objects and Classes",
  "3. Values and Data Types",
  "4. Operators in Java",
  "5. Input in Java",
  "6. Mathematical Library Methods",
  "7. Conditional Constructs in Java",
  "8. Iterative Constructs in Java",
  "9. Paper II: Internal Assessment & Practical Lab Work (100 Marks)"
];

export const DATA_REP_BOOLEAN_ALG_ICSE11_SUBTOPICS = [
  "Number Systems: Conversion between base systems (Binary, Octal, Decimal, Hexadecimal); Representation of signed integers using Sign-Magnitude, 1's Complement, and 2's Complement notation; Floating-point representation (binary fractions)",
  "Binary Arithmetic: Binary addition, subtraction (including subtraction using 2's complement), multiplication, and division",
  "Character Codes: ASCII, ISCII, and Unicode representation frameworks",
  "Boolean Algebra Foundations: Boolean constants, variables, and functions; Basic logic operations (AND, OR, NOT); Truth tables and logic gate symbols (including NAND, NOR, XOR, XNOR)",
  "Algebraic Laws & Theorems: Commutative, Associative, Distributive, and Identity laws; De Morgan's Laws and their algebraic and truth-table verifications; Duality principle",
  "Minterms and Maxterms: Canonical forms: Sum of Products (SOP) and Product of Sums (POS) expressions; Reducing Boolean expressions using algebraic manipulation and Karnaugh Maps (K-Maps) up to 3 variables (including don't care conditions)"
];

export const HARDWARE_ARCHITECTURE_ICSE11_SUBTOPICS = [
  "Logic Circuits: Designing combinational circuits from Boolean expressions; Half Adder and Full Adder circuits; Decoder, Encoder, Multiplexer (MUX), and Demultiplexer (DEMUX) architecture",
  "Memory Units: Implementation of Sequential circuits; Basic Flip-Flops (SR, JK, and D flip-flops) configurations; Registers and counters (elementary qualitative understanding)"
];

export const JAVA_OOP_CONCEPTS_ICSE11_SUBTOPICS = [
  "OOP Review: Principles of Object-Oriented Programming (Abstraction, Encapsulation, Inheritance, Polymorphism); Contrast with structured/procedural programming",
  "Java Virtual Machine: Compilation and execution model; Bytecode concept, JVM, and Just-In-Time (JIT) compilers",
  "Language Basics: Keywords, tokens, identifiers, literals, operators (arithmetic, relational, logical, bitwise, assignment, ternary, increment/decrement)",
  "Data Types & Typecasting: Primitive (int, float, char, boolean, etc.) vs. Reference types; Scope and lifetime of variables; Automatic type conversion and explicit typecasting"
];

export const CONTROL_STRUCTURES_FUNCTIONS_ICSE11_SUBTOPICS = [
  "Decision Making: Flow control using if, if-else, nested if, and switch-case constructs",
  "Iteration: Loops (for, while, do-while); Nested loop matrices; Jump statements (break and continue)",
  "Methods / Functions: Method declaration, signatures, and return types; Call by Value vs. Call by Reference execution parameters; Pure and impure functions; Variable-scope resolution inside code blocks"
];

export const ARRAYS_STRINGS_ICSE11_SUBTOPICS = [
  "Single-Dimensional Arrays: Declaring, initializing, and indexing 1D arrays; Searching Algorithms: Linear Search and Binary Search; Sorting Algorithms: Bubble Sort and Selection Sort",
  "Two-Dimensional Arrays: Declaration and memory layouts (Row-Major and Column-Major address calculations); Manipulating matrix elements, boundary elements, and processing row/column arrays",
  "String and Character Manipulation: Storage mechanics of strings; Standard functions of the String and StringBuffer classes (e.g., length(), indexOf(), charAt(), substring(), equals(), compareTo(), append())"
];

export const ADVANCED_OOP_FEATURES_ICSE11_SUBTOPICS = [
  "Classes & Objects: Class definitions, data members (instance variables, static variables), and member methods; Concept of this keyword",
  "Constructors: Default, parameterized, and copy constructors; Constructor overloading",
  "Encapsulation & Access Specifiers: Visibility modifiers (private, protected, public, and default package access); Data hiding principles",
  "Scope & Memory Management: Static fields and static methods; Garbage collection mechanics and the finalize() method"
];

export const PRACTICAL_WORK_CS_ICSE11_SUBTOPICS = [
  "Programming Assessment (15 Marks): On-system algorithmic problem execution encompassing number manipulation, 1D/2D array operations, or string parsing in Java",
  "Documentation & Algorithm Design (5 Marks): Formal step-by-step algorithm, unique variable descriptions (Variable Table), and multi-case test runs",
  "Practical Laboratory File (5 Marks): Year-long lab journal containing a minimum of 20 to 25 complex Java programs spanning all theoretical units",
  "Viva-Voce (5 Marks): System-side oral examination testing syntax comprehension, data structures, and logic manipulation"
];

export const COMPUTER_SCIENCE_ICSE_CLASS11_LESSONS = [
  "1. Data Representation and Boolean Algebra",
  "2. Computer Hardware and Basic Architecture",
  "3. Introduction to Java and OOP Concepts",
  "4. Control Structures and Function Design",
  "5. Primitive Data Structures: Arrays and Strings",
  "6. Advanced Object-Oriented Programming Features",
  "7. Paper II: Practical Work & Laboratory Assessment (30 Marks)"
];

export const GROWTH_OF_NATIONALISM_ICSE11_SUBTOPICS = [
  "Factors Specializing Rise: Impact of Western education, vernacular press, British economic policies, and racial discrimination",
  "Precursors to INC: Political associations in Bengal, Madras, and Bombay (e.g., East India Association, Indian Association)",
  "Foundation of the Indian National Congress (1885): Role of A.O. Hume; The first two sessions; Early aims, objectives, and constitutional methods of the Early Nationalists (Moderates)"
];

export const EMERGENCE_OF_RADICALS_ICSE11_SUBTOPICS = [
  "The Assertive Nationalists: Causes for the rise of radical nationalism; Perspectives and contributions of Lal-Bal-Pal and Aurobindo Ghosh",
  "Partition of Bengal (1905): Curzon’s real vs. stated motives; Anti-partition movement mechanisms",
  "Swadeshi and Boycott: Methods of agitation, national education schemes, economic impacts, and the Surat Split (1907)"
];

export const WWI_NATIONALIST_POLITICS_ICSE11_SUBTOPICS = [
  "The Ghadar Movement: Outbreak in North America, Komagata Maru incident, and its impact on the home front",
  "Home Rule League: Dual movements led by Bal Gangadhar Tilak and Annie Besant; Objectives and widespread socio-political mobilization",
  "The Lucknow Pact (1916): Factors leading to Congress-League unity and reunion of Moderates and Radicals; Historical significance"
];

export const GANDHIAN_ERA_MASS_NATIONALISM_ICSE11_SUBTOPICS = [
  "Rise of Mahatma Gandhi: Satyagraha philosophy; Early localized campaigns (Champaran, Kheda, Ahmedabad)",
  "Turning Points (1919): Rowlatt Act, Jallianwala Bagh Massacre, and the Khilafat Movement",
  "Non-Cooperation Movement (1920–22) & Civil Disobedience: Launch, methods, suspension (Chauri Chaura), and evaluation; The Simon Commission, Nehru Report, and Purna Swaraj declaration; Dandi March and Round Table Conferences",
  "Alternative Strands: Simon Commission boycott; Rise of the Swaraj Party; Revolutionary nationalism (HSRA, Bhagat Singh, Surya Sen); Emergence of Socialist ideas (Jawaharlal Nehru, Subhas Chandra Bose)"
];

export const IMPACT_WWI_PEACE_SETTLEMENTS_ICSE11_SUBTOPICS = [
  "Paris Peace Conference (1919): The Big Three (Wilson, Lloyd George, Clemenceau) and their conflicting aims; Woodrow Wilson’s Fourteen Points",
  "The Treaty of Versailles: Detailed terms, territorial redraws, military restrictions, and war guilt clauses; Critical evaluation of its fairness",
  "Other Treaties: Brief overview of St. Germain, Trianon, Neuilly, and Sèvres/Lausanne"
];

export const GREAT_DEPRESSION_TOTALITARIANISM_ICSE11_SUBTOPICS = [
  "The Great Depression (1929): Causes (Wall Street Crash, overproduction) and widespread global economic and political impacts",
  "Fascism in Italy: Post-war crisis in Italy; Rise of Benito Mussolini; Fascist ideology, March on Rome, and domestic/foreign policies",
  "Nazism in Germany: Weaknesses of the Weimar Republic; Rise of Adolf Hitler; Nazi ideology, consolidation of totalitarian power (Third Reich), and aggressive expansionist foreign policy"
];

export const WWII_COLLAPSE_COLLECTIVE_SECURITY_ICSE11_SUBTOPICS = [
  "The League of Nations: Structural weaknesses, failure to maintain collective security (Manchuria crisis, Abyssinia crisis)",
  "Road to War: Hitler’s foreign policy successes (Rhineland, Anschluss, Munich Pact, Sudetenland crisis); Policy of Appeasement by Britain and France; Nazi-Soviet Non-Aggression Pact",
  "Outbreak of WWII: Invasion of Poland (1939) and structural catalyst for global conflict"
];

export const RISE_OF_COMMUNISM_CHINA_ICSE11_SUBTOPICS = [
  "The Chinese Revolution (1911): Collapse of the Manchu/Qing Dynasty; Sun Yat-sen and the three principles of the Kuomintang (KMT)",
  "KMT vs. CCP Civil War: Sun Yat-sen's alliance with the Chinese Communist Party (CCP); Chiang Kai-shek's purge of communists (Shanghai Massacre)",
  "Rise of Mao Zedong: The Long March (1934–35) and its strategic importance; Communist mobilization of the peasantry; Impact of the Second Sino-Japanese War; The Communist victory of 1949"
];

export const PROJECT_WORK_HISTORY_ICSE11_SUBTOPICS = [
  "Research Essay Submission: Comprehensive research project (approx. 2000 words) on approved historical themes (e.g., Swadeshi Movement, Fascism in Italy, Treaty of Versailles)",
  "Assessment Criteria - Project File & Historical Research Quality: 10 Marks (Internal Evaluation)",
  "Assessment Criteria - Project File & Viva-Voce Examination: 10 Marks (External Evaluation)"
];

export const HISTORY_ICSE_CLASS11_LESSONS = [
  "1. Section A: Growth of Nationalism (Late 19th Century)",
  "2. Section A: Emergence of the Radicals & Swadeshi Movement",
  "3. Section A: First World War and Nationalist Politics (1914–1918)",
  "4. Section A: The Gandhian Era (Mass Nationalism 1919–1935)",
  "5. Section B: Impact of the First World War and the Peace Settlements",
  "6. Section B: The Great Depression and the Rise of Totalitarianism",
  "7. Section B: World War II and the Collapse of Collective Security",
  "8. Section B: Rise of Communism in China (1911–1949)",
  "9. Paper II: Project Work & Historical Research Essay (20 Marks)"
];

export const EARTH_STRUCTURE_ENDOGENETIC_ICSE11_SUBTOPICS = [
  "Internal Structure of the Earth: Core, mantle, and crust; Temperature, pressure, and density zones; Sources of information (seismic waves properties, volcanic activity)",
  "Continental Drift and Plate Tectonics: Wegener’s Continental Drift theory (evidences and criticisms); Modern Plate Tectonics theory; Types of plate boundaries (convergent, divergent, transform); Major and minor tectonic plates of the world",
  "Endogenetic Forces & Landforms: Folding and Faulting (types, mechanisms, fold mountains, rift valleys, block mountains); Volcanism (intrusive and extrusive landforms, global distribution); Earthquakes (causes, Richter/Mercalli scales, seismic zones, tsunami hazards)"
];

export const EXOGENETIC_LANDFORMS_ICSE11_SUBTOPICS = [
  "Weathering and Mass Wasting: Mechanical, chemical, and biological weathering; Factors affecting weathering; Mass wasting types (landslides, mudflow, soil creep)",
  "Fluvial, Eolian, and Glacial Landforms: Work of running water, wind, and glaciers; Erosional and depositional features (valleys, waterfalls, meanders, floodplains, sand dunes, loess, moraines, U-shaped valleys, hanging valleys)"
];

export const ATMOSPHERE_HYDROSPHERE_ICSE11_SUBTOPICS = [
  "Atmospheric Composition and Structure: Layers of the atmosphere (troposphere, stratosphere, mesosphere, thermosphere, exosphere); Insolation, heat budget of the Earth, and factors controlling temperature distribution",
  "Pressure Belts and Wind Systems: Global planetary winds (Trade winds, Westerlies, Polar easterlies); Monsoon winds; Local winds (Loo, Mistral, Fohn, Chinook); Tropical vs temperate cyclones and anticyclones",
  "Submarine Topography and Movements: Relief configuration of ocean basins (continental shelf, slope, deep sea plains, ocean trenches); Temperature and salinity variations; Ocean Currents (Atlantic, Pacific, Indian Ocean circuits); Spring and neap tides"
];

export const POPULATION_SETTLEMENTS_ICSE11_SUBTOPICS = [
  "World Population Dynamics: Growth, distribution, and density patterns; Factors influencing population distribution; Overpopulation, underpopulation, optimum population; Demographic Transition Model phases",
  "Human Settlements & Urbanization: Rural vs Urban settlements; Rural settlement patterns (linear, radial, nucleated, dispersed); Urbanization trends, functional classification of towns, urban challenges (slums, congestion, waste management)"
];

export const PHYSICAL_FRAMEWORK_INDIA_ICSE11_SUBTOPICS = [
  "Physiographic Divisions of India: Detailed study of the Northern Mountains, Great Plains, Peninsular Plateau, Coastal Plains, and Islands",
  "Drainage Systems: Comparison between Himalayan rivers (Indus, Ganga, Brahmaputra) and Peninsular rivers (Mahanadi, Godavari, Krishna, Cauvery, Narmada, Tapi)",
  "The Indian Monsoon: Mechanism of the monsoon (Classical vs Jet Stream theories); Seasons of India; Spatial distribution of rainfall and drought/flood management"
];

export const RESOURCES_ENVIRONMENT_INDIA_ICSE11_SUBTOPICS = [
  "Natural Vegetation and Soils: Classification and distribution of Indian forests; Soil types of India (Alluvial, Black, Red, Laterite); Soil erosion causes and conservation strategies",
  "Hazards and Disaster Management: Cloudbursts, landslides, earthquakes, and cyclones in the Indian subcontinent; Mitigation and disaster management policies"
];

export const PRACTICAL_GEOGRAPHY_ICSE11_SUBTOPICS = [
  "Section A - Cartography & Toposheets (15 Marks): Construction of line graphs, bar diagrams, pie charts, age-sex pyramids; Graphical construction of Map Projections (Cylindrical Equal-Area, Conical with one standard parallel, Zenithal Equidistant); Topographical sheet grid reading, scale, gradient, contour intervals, drainage patterns, and land use",
  "Section B - Field Study Project Report (10 Marks): Compilation of an independent local field survey report (approx. 20-25 pages) on land-use patterns, socio-economic village/slum survey, or environmental impact analysis",
  "Section C - Practical Log and Viva-Voce (5 Marks): Year-long regular practical workbook submissions evaluated alongside a brief oral board examination"
];

export const GEOGRAPHY_ICSE_CLASS11_LESSONS = [
  "1. Section A: Structure of the Earth and Endogenetic Processes",
  "2. Section A: Exogenetic Processes and Landform Development",
  "3. Section A: Atmosphere and Hydrosphere",
  "4. Section B: Population Dynamics and Human Settlements",
  "5. Section C: Physical Framework and Climate of India",
  "6. Section C: Resource Base and Environmental Issues",
  "7. Paper II: Practical Work, Cartographic Skills & Field Project (30 Marks)"
];

export const OUR_CONSTITUTION_ICSE9_SUBTOPICS = [
  "The Foundation: Definition of a Constitution, dates of its adoption (26th November 1949) and enforcement (26th January 1950), and historical significance of the Constituent Assembly",
  "Salient Features: Preamble ideals, Single citizenship, Universal Adult Franchise, and the fundamental concept of a Welfare State",
  "Core Rights & Duties: Fundamental Rights (6 core rights, judicial enforceability, and constitutional writs: Habeas Corpus, Mandamus, Prohibition, Quo-Warranto, Certiorari) and Fundamental Duties (Article 51A)",
  "Directive Principles of State Policy: Meaning, classification (Socialistic, Gandhian, Liberal-Intellectual, International), welfare state goals, and comparison with Fundamental Rights"
];

export const ELECTIONS_ICSE9_SUBTOPICS = [
  "Electoral Mechanisms: Meaning and essential purpose of the electoral process in a representative democracy, principle of secret ballot",
  "The Commission: Composition, appointment, independence, and primary administrative, advisory, and regulatory functions of the Election Commission of India",
  "Election Formats: Structural differences between Direct and Indirect elections; definitions and distinctions between General Elections, Mid-term Elections, and By-elections"
];

export const LOCAL_SELF_GOVERNMENT_ICSE9_SUBTOPICS = [
  "Democratic Decentralization: Need, purpose, and significance of grassroots self-governance via 73rd and 74th Constitutional Amendment Acts",
  "Rural Local Governance (Panchayati Raj): Three-tier structural hierarchy: Gram Panchayat (Gram Sabha, Pradhan/Sarpanch, Nyaya Panchayat), Panchayat Samiti (Block level composition and functions), and Zila Parishad (District level composition and supervisory role)",
  "Urban Local Governance (Municipalities): Municipal Corporations (Mayor, Municipal Commissioner, functions in metropolitan cities) vs Municipal Committees / Municipalities (Chairperson, ward members, functions in smaller towns); sources of municipal revenue and public utility services"
];

export const ANCIENT_INDIA_CIVILISATIONS_ICSE9_SUBTOPICS = [
  "The Harappan Civilisation: Archaeological sources (Great Bath, Citadel, Seals, Bronze Dancing Girl, Granary), urban town planning, drainage system, trade, crafts, religious beliefs, and decline theories",
  "The Vedic Period: Early Vedic vs Later Vedic society; Epics (Ramayana & Mahabharata) and Vedic literature as historical sources, socio-economic structure, caste/varna system evolution, and religious practices",
  "Rise of Jainism and Buddhism: 6th Century BCE socio-religious causes, Vardhamana Mahavira's life & core doctrines (Triratnas, Ahimsa), Gautama Buddha's life, Four Noble Truths, Eightfold Path (Ashtangika Marga), and societal impact",
  "The Mauryan Empire: Sources (Arthashastra, Indica, Ashokan Edicts), Chandragupta Maurya's administration, Kalinga War and Ashoka's Dhamma principles and propagation",
  "The Sangam Age & The Gupta Empire: Sangam literature (Tirukkural) as source for South Indian society; Gupta Age golden era: sources (Allahabad Pillar Inscription, Fa-Hien, Kalidasa), political achievements (Samudragupta, Chandragupta II), science, art, and architecture"
];

export const MEDIEVAL_INDIA_CULTURE_ICSE9_SUBTOPICS = [
  "The Chola Kingdom: Inscriptional sources (Brihadeeswara Temple, Thanjavur), local self-government in Chola villages (Ur and Sabha / Uttaramerur inscription), maritime trade, and Chola bronzes",
  "The Delhi Sultanate: Architectural sources (Qutub Minar, literary accounts), prominent dynasties: Slave Dynasty (Iltutmish, Balban), Khalji Dynasty (Alauddin Khalji's market and military reforms), and Tughlaq Dynasty (Muhammad bin Tughlaq's projects)",
  "The Mughal Empire: Sources (Ain-i-Akbari, Taj Mahal, Jama Masjid), Akbar's administrative system (Mansabdari, Todar Mal's Land Revenue Zabt system), and Akbar's religious policies (Sulh-i-Kul, Din-i-Ilahi)",
  "Composite Culture & Religious Movements: Bhakti Movement (Kabir, Guru Nanak, Mirabai), Sufism (Chisti order, Nizamuddin Auliya, Khwaja Moinuddin Chishti), and introduction & cultural impact of Christianity"
];

export const MODERN_AGE_EUROPE_ICSE9_SUBTOPICS = [
  "The Renaissance: Meaning, root causes (fall of Constantinople 1453, printing press, humanism), impact on Art (Da Vinci, Michelangelo), Literature (Shakespeare, Dante), and Science (Copernicus, Galileo), transition to modern world",
  "The Reformation: Root causes (corruption in Church, sale of indulgences), Martin Luther and 95 Theses in Germany, Protestant movement, and Catholic Counter-Reformation (Council of Trent, Jesuits under Ignatius of Loyola)",
  "The Industrial Revolution: Meaning, origin in Great Britain (coal/iron deposits, capital, colonial markets, transport), key inventions (Steam Engine, Spinning Jenny, Power Loom), and socio-economic consequences (factory system, urbanization, capitalism, labor conditions)"
];

export const GEOGRAPHICAL_SKILLS_MAPWORK_ICSE9_SUBTOPICS = [
  "World Map Localization (10 Marks Compulsory): Identifying, marking, and labeling major global geographical features on an outline map of the World",
  "Major World Water Bodies: Oceans (Pacific, Atlantic, Indian, Arctic, Southern), major Seas (Caribbean, Mediterranean, Red, Black, Baltic, Arabian, South China Sea), Gulfs, Bays, and Straits (Strait of Gibraltar, Malacca Strait, Persian Gulf)",
  "Global Relief & River Systems: Major Mountain Ranges (Himalayas, Rockies, Andes, Alps, Urals, Great Dividing Range, Atlas), Major Plateaus (Tibetan, Colorado, Deccan, Brazilian), and River Systems (Amazon, Nile, Mississippi, Yangtze, Ganges, Danube, Congo, Rhine, Indus)"
];

export const PHYSICAL_GEOGRAPHY_EARTH_ICSE9_SUBTOPICS = [
  "Earth as a Planet & Geoid: Shape of the Earth (Oblate Spheroid / Geoid), proofs of Earth's spherical shape, unique habitat for life",
  "Geographic Grid & Time: Latitudes (Equator, Tropics, Arctic/Antarctic circles) and Longitudes (Prime Meridian, GMT); Calculation of Local Time, Standard Time, Time Zones, and International Date Line (IDL)",
  "Movements of the Earth: Rotation (day & night, Coriolis effect) and Revolution (inclination of axis at 66.5°, equinoxes, solstices, unequal days/nights, cycle of seasons)",
  "Internal Structure of the Earth: Crust (Sial and Sima, Mohorovicic discontinuity), Mantle (Asthenosphere, Upper/Lower Mantle), and Core (Barysphere / Nife, Gutenberg discontinuity)",
  "Dynamic Landforms & Earth Movements: Endogenic forces (Plate tectonics, folding, faulting), Volcanism (volcano types, intrusive/extrusive landforms), Earthquakes (causes, focus, epicenter, seismic waves, Richter scale), and Exogenic processes (Mechanical, Chemical, Biological Weathering, Denudation)"
];

export const ATMOSPHERE_HYDROSPHERE_ICSE9_SUBTOPICS = [
  "Atmospheric Composition & Structure: Gaseous layers, ozone layer, and vertical stratification (Troposphere, Stratosphere, Mesosphere, Thermosphere, Exosphere) with temperature lapse rate",
  "Insolation & Heat Balance: Incoming solar radiation, heat budget of Earth, factors controlling global temperature distribution",
  "Atmospheric Pressure & Planetary Winds: Pressure belts (Equatorial Low, Subtropical Highs, Subpolar Lows, Polar Highs); Wind systems: Planetary winds (Trade Winds, Westerlies, Polar Easterlies), Periodic winds (Monsoons, Land/Sea breezes), Local winds (Loo, Foehn, Chinook), Cyclones and Anticyclones",
  "Humidity & Precipitation: Absolute & Relative humidity, condensation forms (dew, fog, clouds), and Rainfall classification (Convectional, Orographic / Relief, Cyclonic / Frontal rainfall)",
  "Hydrosphere — Ocean Currents & Tides: Ocean currents: causes, major currents of Atlantic, Pacific, and Indian Oceans (Gulf Stream, Kuroshio, Labrador, Canary, Benguela), climate and navigation effects; Ocean Tides: gravitational pull of Moon & Sun, Spring vs Neap Tides, tidal energy and navigation utility"
];

export const ENVIRONMENT_NATURAL_REGIONS_ICSE9_SUBTOPICS = [
  "World Natural Regions: Climatic characteristics, natural vegetation, wildlife, and human adaptation in major biomes: Equatorial Region, Tropical Grasslands (Savanna), Tropical Deserts, Tropical Monsoon, Mediterranean, Temperate Grasslands (Steppes/Prairies), Taiga, and Tundra",
  "Environmental Degradation & Pollution: Sources, causes, and impacts of Air pollution (smog, acid rain), Water pollution (industrial effluents, eutrophication), Soil pollution, and Radiation / Noise pollution",
  "Global Environmental Crises: Greenhouse Effect, Global Warming, Ozone Layer Depletion (CFCs, Montreal Protocol), Loss of Biodiversity, and Desertification",
  "Conservation & Sustainable Management: Waste management (The 3 Rs: Reduce, Reuse, Recycle), afforestation, rainwater harvesting, renewable energy, and sustainable development goals"
];

export const INTERNAL_ASSESSMENT_SOCIAL_SCIENCE_ICSE9_SUBTOPICS = [
  "Paper I: History & Civics Internal Assessment (20 Marks): Continuous project evaluation on historical monuments, local self-governing bodies survey, mock elections simulation, or global reform movements; Project file (10 marks) and Viva-voce oral defense (10 marks)",
  "Paper II: Geography Internal Assessment (20 Marks): Practical field survey, meteorological recording logbook (weather instruments: thermometer, barometer, rain gauge, wind vane), local environmental issue study, Project file (10 marks) and Viva-voce examination (10 marks)"
];

export const SOCIAL_SCIENCE_ICSE_CLASS9_LESSONS = [
  "1. Civics: Our Constitution (Foundation, Salient Features, Rights, Duties & Directive Principles)",
  "2. Civics: Elections (Electoral Process, Election Commission & Election Formats)",
  "3. Civics: Local Self-Government (Rural Panchayati Raj & Urban Municipal Governance)",
  "4. History: Ancient India (Harappan, Vedic Period, Jainism & Buddhism, Mauryas, Sangam & Guptas)",
  "5. History: Medieval India & Cultural Shifts (Cholas, Delhi Sultanate, Mughals, Bhakti & Sufism)",
  "6. History: Modern Age in Europe (Renaissance, Reformation & Industrial Revolution)",
  "7. Geography: Geographical Skills & World Map Work (Oceans, Seas, Mountain Ranges, Plateaus & Rivers)",
  "8. Geography: Physical Earth & Landforms (Earth as Geoid, Latitudes-Longitudes, Movements & Internal Structure)",
  "9. Geography: Atmosphere & Hydrosphere (Composition, Pressure Belts, Winds, Humidity, Tides & Ocean Currents)",
  "10. Geography: Environment & Natural Regions (Global Climatic Zones, Pollution & Conservation)",
  "11. Paper I & II: Internal Assessment & Practical Project Work (20 Marks Each)"
];

export const HISTORY_CIVICS_ICSE_CLASS9_LESSONS = [
  "1. Civics: Our Constitution (Foundation, Salient Features, Rights, Duties & Directive Principles)",
  "2. Civics: Elections (Electoral Process, Election Commission & Election Formats)",
  "3. Civics: Local Self-Government (Rural Panchayati Raj & Urban Municipal Governance)",
  "4. History: Ancient India (Harappan, Vedic Period, Jainism & Buddhism, Mauryas, Sangam & Guptas)",
  "5. History: Medieval India & Cultural Shifts (Cholas, Delhi Sultanate, Mughals, Bhakti & Sufism)",
  "6. History: Modern Age in Europe (Renaissance, Reformation & Industrial Revolution)",
  "7. Paper I: Internal Assessment & Field Projects (20 Marks)"
];

export const GEOGRAPHY_ICSE_CLASS9_LESSONS = [
  "1. Geographical Skills & World Map Work (Oceans, Seas, Mountain Ranges, Plateaus & Rivers)",
  "2. Physical Earth & Landforms (Earth as Geoid, Latitudes-Longitudes, Movements & Internal Structure)",
  "3. Atmosphere & Hydrosphere (Composition, Pressure Belts, Winds, Humidity, Tides & Ocean Currents)",
  "4. Environment & Natural Regions (Global Climatic Zones, Pollution & Conservation)",
  "5. Paper II: Internal Assessment & Practical Work (20 Marks)"
];

export const SETS_ICSE11_SUBTOPICS = [
  "Sets & Representations: Roster form, Set-builder form, Empty set, Finite and Infinite sets, Equal sets",
  "Subsets, Power Set & Universal Set: Subsets of real numbers, Power set P(A), Universal set U",
  "Venn Diagrams & Operations: Union (A ∪ B), Intersection (A ∩ B), Difference (A - B), Complement (A')",
  "Algebraic Properties of Sets: Commutative, Associative, Distributive, De Morgan's laws, and cardinality applications n(A ∪ B) = n(A) + n(B) - n(A ∩ B)"
];

export const RELATIONS_FUNCTIONS_ICSE11_SUBTOPICS = [
  "Cartesian Product of Sets: Ordered pairs, Cartesian product A × B, number of elements n(A × B) = n(A) · n(B)",
  "Relations: Definition, domain, co-domain, range of a relation, pictorial arrow diagrams",
  "Functions as Special Relations: Definition of function, vertical line test, domain, co-domain, and range",
  "Real-Valued Functions & Graphs: Identity, Constant, Polynomial, Rational, Modulus |x|, Signum sgn(x), and Greatest Integer function [x] graphs and properties"
];

export const TRIGONOMETRY_ICSE11_SUBTOPICS = [
  "Angle Measurement & Unit Circle: Positive and negative angles, Radians vs Degrees conversion (180° = π rad), Unit circle definition of trig functions",
  "Signs & Graphs of Trigonometric Functions: Quadrant signs (ASTC rule), Domain, range, periodicity, and graphs of sin, cos, tan, cosec, sec, cot",
  "Compound Angle Formulas: Proofs and applications of sin(x ± y), cos(x ± y), tan(x ± y)",
  "Multiple & Sub-multiple Angle Identities: Formulas for sin 2x, cos 2x, tan 2x, sin 3x, cos 3x, half-angle formulas",
  "Trigonometric Equations: Principal solutions and general solutions for sin x = sin α, cos x = cos α, tan x = tan α"
];

export const MATHEMATICAL_INDUCTION_ICSE11_SUBTOPICS = [
  "Processes of Demonstration & Principle: Intuitive motivation, Base step P(1), Inductive hypothesis P(k), Inductive step P(k+1)",
  "Formal Applications: Proving sum formulas (e.g., ∑n, ∑n², ∑2ⁿ), algebraic divisibility proofs, and inequality relations using PMI"
];

export const COMPLEX_NUMBERS_QUADRATIC_ICSE11_SUBTOPICS = [
  "Need for Complex Numbers & Imaginary Unit: Definition of i = √-1, powers of i, algebraic properties (addition, subtraction, multiplication, division, modulus, conjugate)",
  "Argand Plane & Polar Representation: Complex plane representation, modulus |z|, argument arg(z), polar form z = r(cos θ + i sin θ)",
  "Quadratic Equations in C: Fundamental Theorem of Algebra, solving ax² + bx + c = 0 with negative discriminant (complex roots)"
];

export const LINEAR_INEQUALITIES_ICSE11_SUBTOPICS = [
  "Linear Inequalities in One Variable: Algebraic solutions, interval notation, representation on the real number line",
  "Graphical Solution in Two Variables: Half-planes, graphing linear inequalities ax + by ≤ c or ax + by ≥ c",
  "Systems of Linear Inequalities: Graphing feasible regions for systems of linear inequalities in two variables"
];

export const PERMUTATIONS_COMBINATIONS_ICSE11_SUBTOPICS = [
  "Fundamental Principle of Counting: Multiplication principle and addition principle of counting",
  "Factorial Notation & Permutations: Factorial n!, Derivation and application of nPr = n! / (n - r)!, permutations with repetition and circular permutations",
  "Combinations & Algebraic Properties: Derivation of nCr = n! / [r!(n - r)!], properties nCr = nC(n-r), nCr + nC(r-1) = (n+1)Cr, real-world selection problems"
];

export const BINOMIAL_THEOREM_ICSE11_SUBTOPICS = [
  "Statement & Proof of Binomial Theorem: Historical context, Pascal's triangle, expansion (a + b)ⁿ for positive integral indices",
  "General Term & Middle Term: Finding (r+1)-th general term Tr+1 = nCr aⁿ⁻ʳ bʳ, middle term(s) determination in expansions",
  "Simple Applications & Expansions: Numerically greatest term, term independent of x, binomial coefficients properties"
];

export const SEQUENCE_SERIES_ICSE11_SUBTOPICS = [
  "Arithmetic Progression (A.P.): General term an = a + (n - 1)d, sum Sn = n/2 [2a + (n - 1)d], Arithmetic Mean (A.M.) between two numbers",
  "Geometric Progression (G.P.): General term an = a · rⁿ⁻¹, sum Sn = a(1 - rⁿ)/(1 - r), sum of infinite G.P., Geometric Mean (G.M.)",
  "Relation between A.M. and G.M.: Proof and applications of A.M. ≥ G.M. for positive real numbers",
  "Special Series Summation: Sum of first n natural numbers ∑n, sum of squares ∑n², sum of cubes ∑n³"
];

export const STRAIGHT_LINES_ICSE11_SUBTOPICS = [
  "Slope & Angle Between Lines: Shifting of origin, slope m = tan θ, parallel and perpendicular line conditions, angle tan θ = |(m2 - m1)/(1 + m1 m2)|",
  "Forms of Line Equations: Slope-intercept (y = mx + c), point-slope, two-point, intercept (x/a + y/b = 1), and normal form (x cos α + y sin α = p)",
  "General Equation & Intersection: General form Ax + By + C = 0, family of lines passing through point of intersection L1 + λL2 = 0",
  "Distance Formulas: Perpendicular distance of a point (x1, y1) from line Ax + By + C = 0, distance between parallel lines"
];

export const CIRCLES_ICSE11_SUBTOPICS = [
  "Equations of Circle: Standard form (x - h)² + (y - k)² = r² with center (h, k) and radius r; General equation x² + y² + 2gx + 2fy + c = 0 with center (-g, -f) and radius √(g² + f² - c)",
  "Tangents & Conditions of Tangency: Condition for line y = mx + c to be tangent to circle, equation of tangent at point (x1, y1)"
];

export const CALCULUS_LIMITS_DERIVATIVES_ICSE11_SUBTOPICS = [
  "Intuitive Idea & Evaluation of Limits: Left-hand and right-hand limits, limits of polynomials, rational functions, trigonometric limits lim(x→0) sin x / x = 1, exponential lim(x→0) (eˣ - 1)/x = 1, logarithmic limits",
  "Definition of Derivative: Derivative as rate of change, first principles method f'(x) = lim(h→0) [f(x+h) - f(x)]/h, geometrical interpretation as slope of tangent",
  "Derivative Rules & Formulas: Sum/difference rule, product rule (uv)', quotient rule (u/v)', derivatives of polynomial and trigonometric functions"
];

export const STATISTICS_ICSE11_SUBTOPICS = [
  "Measures of Dispersion: Range, Mean Deviation about mean and median for ungrouped and grouped data",
  "Variance & Standard Deviation: Calculation of variance σ² and standard deviation σ for raw data, discrete frequency distributions, and continuous grouped data",
  "Frequency Distribution Analysis: Coefficient of variation (C.V. = σ / x̄ × 100%), comparing stability/variability of distributions with equal means but different variances"
];

export const PROBABILITY_ICSE11_SUBTOPICS = [
  "Random Experiments & Events: Sample space S, outcomes, events (simple, compound, exhaustive, mutually exclusive, complementary 'not E', 'and', 'or')",
  "Axiomatic Approach to Probability: Axioms of probability P(E) ≥ 0, P(S) = 1, addition theorem P(A ∪ B) = P(A) + P(B) - P(A ∩ B)",
  "Event Probabilities: Probability of 'at least one' event, complementary probability P(E') = 1 - P(E)"
];

export const CONIC_SECTIONS_ICSE11_SUBTOPICS = [
  "Sections of a Cone: Degenerate and non-degenerate conics (circle, ellipse, parabola, hyperbola) formed by intersecting a double-napped cone with a plane",
  "Parabola: Standard equations y² = 4ax, y² = -4ax, x² = 4ay, x² = -4ay; Focus, directrix, axis, vertex, latus rectum length",
  "Ellipse: Standard equation x²/a² + y²/b² = 1 (a > b and b > a); Vertices, major/minor axes, foci, eccentricity e = √(1 - b²/a²), directrices, latus rectum",
  "Hyperbola: Standard equation x²/a² - y²/b² = 1; Vertices, transverse/conjugate axes, foci, eccentricity e = √(1 + b²/a²), directrices, latus rectum"
];

export const THREE_DIMENSIONAL_GEOMETRY_ICSE11_SUBTOPICS = [
  "Coordinate Axes & Planes: 3D rectangular coordinate system, 8 octants, coordinates of a point (x, y, z)",
  "Distance & Section Formulas: Distance between two points P(x1, y1, z1) and Q(x2, y2, z2), section formula for internal and external division of line segment"
];

export const MATHEMATICAL_REASONING_ICSE11_SUBTOPICS = [
  "Mathematically Acceptable Statements: Definition of statement, truth value (true or false), open sentences vs statements",
  "Logic Operators & Connectives: 'And' (conjunction), 'Or' (inclusive vs exclusive disjunction), 'Implies' (conditional), 'If and only if' (biconditional), quantifiers ('There exists', 'For all')",
  "Validation & Proof Methods: Direct proof, proof by contradiction, counterexamples, converse and contrapositive statements"
];

export const COMMERCIAL_STATISTICS_EXPECTATION_ICSE11_SUBTOPICS = [
  "Combined Mean & Variance: Weighted arithmetic mean, combined standard deviation and variance formulas for multiple combined data batches",
  "Mathematical Expectation: Discrete random variables, probability distribution P(X = x_i), expected value E(X) = ∑ x_i P(x_i), variance Var(X) = E(X²) - [E(X)]²"
];

export const CORRELATION_REGRESSION_ICSE11_SUBTOPICS = [
  "Scatter Diagrams & Bivariate Distributions: Graphical rendering of paired variables (x, y), visual estimation of positive, negative, or zero correlation",
  "Karl Pearson's Coefficient of Correlation: Derivation and calculation of r = Cov(x, y) / (σx σy), interpretation of values (-1 ≤ r ≤ 1)",
  "Regression Lines & Coefficients: Lines of regression of y on x and x on y, regression coefficients b_yx and b_xy, relation r = ±√(b_yx · b_xy), predicting unknown values"
];

export const INDEX_NUMBERS_MOVING_AVERAGES_ICSE11_SUBTOPICS = [
  "Index Numbers: Price index and quantity index, simple aggregate method, weighted aggregate index methods: Laspeyres' Index, Paasche's Index, and Fisher's Ideal Index",
  "Moving Averages & Time-Series: Time-series components, smoothing variations using 3-year, 4-year (centered), and 5-year moving averages"
];

export const PROJECT_WORK_ICSE11_SUBTOPICS = [
  "Paper II — Project File & Academic Content (10 Marks): Submission of two independent mathematical synthesis projects on real-world applications, statistical data analysis, or geometric/algebraic proofs",
  "Paper II — Viva-Voce & Individual Presentation (10 Marks): Oral defense, conceptual inquiry, and presentation of submitted project work supervised by faculty"
];

export const PHYSICAL_WORLD_MEASUREMENT_ICSE11_SUBTOPICS = [
  "Units and Measurements: Need for measurement; SI units, fundamental and derived units; Dimensions of physical quantities, dimensional analysis, and its application to checking equations and deriving formulas",
  "Errors in Measurement: Significant figures; Least count of instruments; Types of errors (systematic and random); Absolute, relative, and percentage errors; Combination and propagation of errors in algebraic operations"
];

export const KINEMATICS_ICSE11_SUBTOPICS = [
  "Motion in a Straight Line: Frame of reference; Position-time graphs, speed, and velocity; Uniform and non-uniform motion, average speed, and instantaneous velocity; Calculus-based derivation of equations of motion; Relative velocity",
  "Motion in a Plane: Scalar and vector quantities; Position and displacement vectors, equality of vectors, multiplication of vectors by a real number; Addition and subtraction of vectors (graphical and analytical methods); Resolution of a vector in a plane; Unit vectors, Scalar (dot) product and Vector (cross) product of two vectors",
  "Projectiles and Uniform Circular Motion: Projectile motion (time of flight, maximum height, horizontal range, and trajectory equation); Uniform circular motion: angular velocity, angular acceleration, centripetal acceleration, and centripetal force dynamics"
];

export const LAWS_OF_MOTION_ICSE11_SUBTOPICS = [
  "Newton's Laws of Motion: Intuitive concept of force; Inertia; Newton's First Law, Second Law (F = ma and linear momentum conservation), and Third Law (action-reaction pairs); Impulse and Impulse-Momentum theorem",
  "Friction & Dynamics of Circular Motion: Law of conservation of linear momentum and its applications (recoil of a gun, concurrent forces equilibrium); Static and kinetic friction, laws of friction, rolling friction, lubrication; Dynamics of uniform circular motion: banking of roads and bending of a cyclist"
];

export const WORK_ENERGY_POWER_ICSE11_SUBTOPICS = [
  "Work and Kinetic Energy: Work done by a constant force and a variable force; Kinetic energy, work-energy theorem, and power expressions",
  "Potential Energy and Collisions: Potential energy, potential energy of a spring, conservative and non-conservative forces; Conservation of mechanical energy; Elastic and inelastic collisions in one and two dimensions"
];

export const SYSTEM_PARTICLES_RIGID_BODY_ICSE11_SUBTOPICS = [
  "Centre of Mass: Centre of mass of a two-particle system, momentum conservation, and centre of mass motion; Centre of mass of a rigid body; Torque, angular momentum, and conservation of angular momentum with real-world applications",
  "Moment of Inertia: Equilibrium of rigid bodies; Moment of inertia, radius of gyration; Values of moments of inertia for simple geometrical objects (no derivation); Statement and application of parallel and perpendicular axes theorems"
];

export const GRAVITATION_ICSE11_SUBTOPICS = [
  "Kepler's Laws and Gravitation: Kepler's laws of planetary motion; Universal law of gravitation; Acceleration due to gravity (g) and its variation with altitude, depth, and latitude",
  "Satellites and Escapes: Gravitational potential energy and gravitational potential; Escape velocity; Orbital velocity of a satellite, geostationary satellites, total energy of a satellite"
];

export const PROPERTIES_BULK_MATTER_ICSE11_SUBTOPICS = [
  "Mechanical Properties of Solids: Elastic behaviour, Stress-strain relationship, Hooke's law, Young's modulus, bulk modulus, and shear modulus of rigidity; Poisson's ratio; Elastic potential energy",
  "Mechanical Properties of Fluids: Pressure due to a fluid column; Pascal's law and its applications; Viscosity, Stokes' law, terminal velocity, streamline and turbulent flow, critical velocity; Bernoulli's theorem and its structural applications",
  "Surface Tension: Surface energy and surface tension, angle of contact, excess of pressure across a curved liquid surface, capillary rise phenomenon"
];

export const THERMODYNAMICS_PHYSICS_ICSE11_SUBTOPICS = [
  "Thermal Properties of Matter: Heat, temperature, thermal expansion (solids, liquids, gases); Anomalous expansion of water; Specific heat capacity, calorimetry; Change of state, latent heat capacity; Heat transfer (conduction, convection, and radiation), thermal conductivity, Stefan's law, and Wien's displacement law",
  "Thermodynamics: Thermal equilibrium and definition of temperature (Zeroth law of thermodynamics); First law of thermodynamics, isothermal and adiabatic processes; Reversible and irreversible processes; Second law of thermodynamics, heat engine, and refrigerator efficiency parameters"
];

export const KINETIC_THEORY_GASES_ICSE11_SUBTOPICS = [
  "Kinetic Theory of Gases: Equation of state of a perfect gas, work done in compressing a gas; Kinetic theory of gases—assumptions, concept of pressure; Kinetic interpretation of temperature; RMS speed of gas molecules; Degrees of freedom, law of equi-partition of energy, and specific heat capacities (Cp, Cv) of gases; Avogadro's number"
];

export const OSCILLATIONS_WAVES_ICSE11_SUBTOPICS = [
  "Oscillations: Periodic and oscillatory motions, period, frequency, displacement as a function of time; Simple Harmonic Motion (SHM) and its equations; Phase; Energy in SHM (kinetic and potential energies); Simple pendulum derivation; Free, forced, and damped oscillations, resonance",
  "Waves: Wave motion, longitudinal and transverse waves, speed of travelling wave; Displacement relation for a progressive wave; Principle of superposition of waves, reflection of waves, standing waves in strings and organ pipes, fundamental mode and harmonics; Beats phenomenon"
];

export const PRACTICAL_PHYSICS_ICSE11_SUBTOPICS = [
  "Section A: Laboratory Experiments (15 Marks): Minimum 10 to 12 experiments to verify physical parameters (Vernier Callipers/Screw Gauge dimensions, 'g' via simple pendulum, force constant of a spring, Boyle's Law verification, surface tension via capillary tube)",
  "Section B: Project Work (10 Marks): Independent research project or functional prototype applying core principles of mechanics, fluid dynamics, or thermodynamics",
  "Section C: Practical File & Viva-Voce (5 Marks): Assessment of regular observation data logged into the laboratory manual alongside an oral examination based on experimental techniques"
];

// Biology Class 11 (ICSE Board / ISC) Subtopics
export const DIVERSITY_LIVING_ORGANISMS_ICSE11_SUBTOPICS = [
  "The Living World: What is living? Biodiversity; Need for classification; Three domains of life; Taxonomy and systematics; Concept of species and taxonomic hierarchy; Binomial nomenclature",
  "Biological Classification: Five-kingdom classification; Salient features and classification of Monera, Protista, and Fungi into major groups; Lichens, Viruses, Viroids, and Prions",
  "Plant Kingdom: Salient features and classification of plants into major groups—Algae, Bryophytes, Pteridophytes, Gymnosperms, and Angiosperms (3 to 5 distinguishing features and at least 2 examples of each category)",
  "Animal Kingdom: Salient features and classification of animals, non-chordates up to phyla level and chordates up to class level (salient features and distinguishing characters with examples)"
];

export const STRUCTURAL_ORGANISATION_ICSE11_SUBTOPICS = [
  "Plant Anatomy: Anatomy and functions of different tissues and tissue systems in dicot and monocot roots, stems, and leaves; Secondary growth mechanisms in dicot stems and roots",
  "Animal Tissues & Cockroach Anatomy: Morphology, anatomy, and functions of different systems (digestive, circulatory, respiratory, nervous, and reproductive) of an insect (Cockroach) as a structural type representation"
];

export const CELL_STRUCTURE_FUNCTION_ICSE11_SUBTOPICS = [
  "Cell Biology: Cell theory and cell as basic unit of life; Structure of prokaryotic and eukaryotic cells; Plant cell vs animal cell; Cell envelope, membrane, wall; Endomembrane system (ER, Golgi, Lysosomes, Vacuoles), Mitochondria, Ribosomes, Plastids, Microbodies, Cytoskeleton, Cilia, Flagella, Centrioles, Nucleus, Chromatin, Nucleolus",
  "Biomolecules: Chemical constituents of living cells; Structure and function of proteins, carbohydrates, lipids, nucleic acids; Enzymes: Properties, mechanism of action, factors affecting activity, classification, nomenclature, co-factors",
  "Cell Cycle and Cell Division: Cell cycle mechanics; Mitosis and Meiosis (Stages and significance of Meiosis I and Meiosis II)"
];

export const PLANT_PHYSIOLOGY_ICSE11_SUBTOPICS = [
  "Photosynthesis in Higher Plants: Autotrophic nutrition; Chloroplast pigments site; Light reaction (photochemical phase) & Dark reaction (biosynthetic phase); Cyclic & non-cyclic photophosphorylation; Chemiosmotic hypothesis; C3 and C4 pathways; Photorespiration; Factors affecting photosynthesis",
  "Respiration in Plants: Cellular respiration—glycolysis, fermentation (anaerobic), TCA cycle (Krebs cycle), Electron Transport System (ETS) via oxidative phosphorylation; Energy relations—ATP generated; Amphibolic pathways; Respiratory quotient (RQ)",
  "Plant Growth and Development: Phases of plant growth and growth rate; Conditions of growth; Differentiation, dedifferentiation, and redifferentiation; Plant growth regulators (Auxin, Gibberellin, Cytokinin, Ethylene, Abscisic acid); Seed dormancy; Vernalisation; Photoperiodism"
];

export const HUMAN_PHYSIOLOGY_ICSE11_SUBTOPICS = [
  "Breathing and Respiration: Respiratory organs in animals; Human respiratory system; Mechanism of breathing and regulation—volumes and capacities; Gas exchange and transport (O2 and CO2); Oxyhaemoglobin dissociation curve; Disorders (Asthma, Emphysema, Occupational disorders)",
  "Body Fluids and Circulation: Composition of blood, blood groups, coagulation; Lymph and function; Human circulatory system—heart structure, blood vessels, cardiac cycle, cardiac output, ECG, double circulation, regulation; Disorders (Hypertension, CAD, Angina, Heart failure)",
  "Excretory Products and Their Elimination: Ammonotelism, ureotelism, uricotelism; Human excretory system—kidney and nephron structure; Urine formation (Ultrafiltration, selective reabsorption, secretion); Counter-current mechanism; Regulation (ADH, ANF, RAAS); Disorders (Uremia, Renal failure, Calculi, Nephritis); Dialysis and artificial kidney",
  "Locomotion and Movement: Types of movement (ciliary, flagellar, muscular); Skeletal muscle ultrastructure, contractile proteins, Sliding Filament Theory; Human skeleton & joints (fibrous, cartilaginous, synovial); Disorders (Myasthenia gravis, Tetany, Muscular dystrophy, Arthritis, Osteoporosis, Gout)",
  "Neural Control and Coordination: Neuron structure & unit; Nerve impulse generation and conduction; Synaptic transmission; Central nervous system (Brain and Spinal cord anatomy); Peripheral & Autonomic nervous systems",
  "Chemical Coordination and Integration: Endocrine glands and hormones (Hypothalamus, Pituitary, Pineal, Thyroid, Parathyroid, Adrenal, Pancreas, Gonads); Mechanisms of hormone action (protein vs steroid); Messengers and regulators; Disorders (Dwarfism, Acromegaly, Goitre, Diabetes Mellitus, Addison's disease)"
];

export const PRACTICAL_BIOLOGY_ICSE11_SUBTOPICS = [
  "Section A: Laboratory Experiments & Spottings (15 Marks): Plant anatomy temporary slides (T.S. dicot/monocot stem & root); Physiological experiments (temperature/pH effect on salivary amylase, paper chromatography plant pigments, Ganong's potometer transpiration); Specimen, tissue, and bone spotting identification",
  "Section B: Project Work (10 Marks): Independent research project or biological field study (local ecosystem biodiversity, blood pressure variations across age groups, plant growth under altered light spectra)",
  "Section C: Practical File & Viva-Voce (5 Marks): Continuous assessment of structured laboratory observation records alongside oral examination on diagnostic biological techniques"
];

export const SOME_BASIC_CONCEPTS_CHEM_ICSE11_SUBTOPICS = [
  "General Foundations: Matter and its nature; Laws of chemical combination (Definite proportions, Multiple proportions, Reciprocal proportions, Gay Lussac's Law)",
  "Stoichiometry Math: Atomic, molecular, and equivalent masses; Mole concept, Avogadro's number, molar mass; Percentage composition, empirical formula, molecular formula; Stoichiometric calculations involving limiting reagents, mass-mass, mass-volume, volume-volume relationships",
  "Solution Concentrations: Concentrations expressed as mass percentage, volume percentage, ppm, mole fraction, molarity (M), and molality (m)"
];

export const STRUCTURE_OF_ATOM_ICSE11_SUBTOPICS = [
  "Subatomic Evolution: Discovery of subatomic particles (electron, proton, neutron); Thomson's and Rutherford's atomic models and limitations; Bohr's atomic model, hydrogen spectrum, spectral series, Bohr radius and energy calculations",
  "Quantum Mechanical Model: Dual nature of matter and light, de Broglie relation, Heisenberg uncertainty principle; Quantum mechanical model of atom, wave function ψ, atomic orbitals, quantum numbers (n, l, m, s), orbital shapes (s, p, d, f); Aufbau principle, Pauli exclusion principle, Hund's rule, electronic configuration of atoms"
];

export const CLASSIFICATION_ELEMENTS_PERIODICITY_ICSE11_SUBTOPICS = [
  "Periodic Table Structure: Modern periodic law and modern periodic table; s, p, d, f blocks; periodic trends in properties (atomic radius, ionic radius, ionization enthalpy, electron gain enthalpy, electronegativity, valency, oxidation states)"
];

export const CHEMICAL_BONDING_MOLECULAR_ICSE11_SUBTOPICS = [
  "Chemical Bonding Theories: Ionic bond, covalent bond, coordinate bond, metallic bond; Valence Shell Electron Pair Repulsion (VSEPR) theory, geometry of molecules; Valence Bond Theory (VBT), orbital overlap, hybridization (sp, sp2, sp3, sp3d, sp3d2); Molecular Orbital Theory (MOT), LCAO, bonding and antibonding orbitals, bond order, magnetic properties of homonuclear diatomic molecules (H2, He2, Li2, B2, C2, N2, O2, F2); Hydrogen bonding"
];

export const CHEMICAL_THERMODYNAMICS_ICSE11_SUBTOPICS = [
  "Thermodynamic Fundamentals: System, surroundings, state functions, extensive and intensive properties; First law of thermodynamics, internal energy (U), enthalpy (H), heat capacity (C), specific heat capacity, molar heat capacity; Hess's law of constant heat summation, enthalpy of reaction, formation, combustion, neutralization, atomization, phase transitions; Second law of thermodynamics, entropy (S), Gibbs free energy (G), spontaneity criterion (ΔG = ΔH - TΔS), equilibrium constant connection"
];

export const EQUILIBRIUM_ICSE11_SUBTOPICS = [
  "Chemical Equilibrium: Dynamic nature of equilibrium, Law of mass action, equilibrium constants (Kc, Kp), relation between Kc and Kp; Le Chatelier's principle and applications (effect of concentration, temperature, pressure, catalyst)",
  "Ionic Equilibrium: Electrolytes and non-electrolytes, Arrhenius, Bronsted-Lowry, and Lewis concepts of acids and bases; Ionization of water, pH scale, acid/base dissociation constants (Ka, Kb), buffer solutions, Henderson-Hasselbalch equation; Solubility product (Ksp), common ion effect"
];

export const REDOX_REACTIONS_ICSE11_SUBTOPICS = [
  "Redox Concepts: Oxidation and reduction in terms of electron transfer and oxidation number; Balancing redox reactions (Ion-electron method, Oxidation number method); Applications of redox reactions, electrochemical cells"
];

export const ORGANIC_CHEMISTRY_BASIC_ICSE11_SUBTOPICS = [
  "Nomenclature & Isomerism: IUPAC nomenclature of organic compounds (mono and polyfunctional); Structural isomerism (chain, position, functional group, metamerism, tautomerism) and Stereoisomerism (geometrical and optical)",
  "Reaction Mechanisms: Inductive effect, electromeric effect, resonance/mesomeric effect, hyperconjugation; Homolytic and heterolytic bond cleavage, carbocations, carbanions, free radicals, electrophiles, nucleophiles; Types of organic reactions (substitution, addition, elimination, rearrangement)"
];

export const HYDROCARBONS_ICSE11_SUBTOPICS = [
  "Alkanes, Alkenes, Alkynes & Aromatic Hydrocarbons: Alkanes (conformations of ethane, free radical halogenation); Alkenes (geometrical isomerism, Markovnikov's and anti-Markovnikov's addition, ozonolysis); Alkynes (acidity of terminal alkynes, addition reactions); Aromatic hydrocarbons (structure of benzene, aromaticity, Huckel's rule, electrophilic substitution reactions: nitration, halogenation, sulphonation, Friedel-Crafts alkylation and acylation)"
];

export const INORGANIC_CHEMISTRY_S_P_BLOCK_ICSE11_SUBTOPICS = [
  "s-Block Group Trends: Group 1 (Alkali Metals) and Group 2 (Alkaline Earth Metals) trends in electronic configuration, atomic/ionic radii, ionization enthalpy, hydration enthalpy, and chemical reactivity with oxygen, water, hydrogen, and halogens; Anomalous behaviour of Lithium and Beryllium; Diagonal relationships",
  "p-Block Group Trends: General introduction, configurations, and oxidation states of Group 13 (Boron family) and Group 14 (Carbon family); Inert pair effect; Anomalous properties of Boron and Carbon; Allotropes of Carbon (diamond, graphite, fullerenes)"
];

export const ORGANIC_CHEMISTRY_HYDROCARBONS_ICSE11_SUBTOPICS = [
  ...ORGANIC_CHEMISTRY_BASIC_ICSE11_SUBTOPICS,
  ...HYDROCARBONS_ICSE11_SUBTOPICS
];

export const PRACTICAL_CHEMISTRY_ICSE11_SUBTOPICS = [
  "Qualitative & Quantitative Analysis: Detection of extra elements (N, S, Halogens in organic compounds); Volumetric analysis (titrations: acid-base, redox KMnO4); Qualitative salt analysis (cations and anions identification)",
  "Practical Record File, Project Work & Viva-Voce: Experimental logbook maintenance, chemistry project report, viva-voce examination framework"
];

// Physics Class 11 Compatibility Exports
export const FORCE_WORK_POWER_ENERGY_ICSE11_SUBTOPICS = WORK_ENERGY_POWER_ICSE11_SUBTOPICS;
export const LIGHT_OPTICS_ICSE11_SUBTOPICS = [
  "Reflection & Refraction at Spherical Surfaces: Lens maker's formula, magnification, power of a lens, combinations of thin lenses in contact",
  "Optical Instruments: Microscope, astronomical telescope (reflecting and refracting) and their magnifying powers",
  "Wave Optics: Wavefront and Huygens' principle, reflection and refraction of plane wave at a plane surface using wave fronts; Interference, Young's double slit experiment, diffraction due to a single slit"
];
export const SOUND_ACOUSTICS_ICSE11_SUBTOPICS = OSCILLATIONS_WAVES_ICSE11_SUBTOPICS;
export const ELECTRICITY_MAGNETISM_ICSE11_SUBTOPICS = [
  "Electric Charges and Fields: Coulomb's law, electric field, electric dipole, torque on a dipole, Gauss's law and its applications",
  "Current Electricity: Electric current, Ohm's law, drift velocity, resistivity, temperature dependence, Kirchhoff's laws and Wheatstone bridge",
  "Magnetic Effects: Biot-Savart law, Ampere's law, force on a moving charge in magnetic field, magnetic dipole moment"
];
export const HEAT_CALORIMETRY_ICSE11_SUBTOPICS = THERMODYNAMICS_PHYSICS_ICSE11_SUBTOPICS;
export const MODERN_PHYSICS_NUCLEAR_ICSE11_SUBTOPICS = [
  "Dual Nature of Radiation & Matter: Photoelectric effect, Einstein's photoelectric equation; de Broglie wavelength of matter waves",
  "Atoms and Nuclei: Alpha-particle scattering experiment; Rutherford's model; Bohr model, energy levels, hydrogen spectrum; Composition and size of nucleus, radioactivity, mass defect, binding energy"
];

export const getLessonsForSubject = (subject: string, boardAcronym?: string, level?: string): string[] => {
  const norm = (subject || '').toLowerCase();
  const lvl = (level || '').toLowerCase();
  const isClass9 = lvl.includes('9') || lvl.includes('ix') || lvl.includes('class 9');
  const isClass10 = lvl.includes('10') || lvl.includes('class 10') || (lvl.includes('x') && !lvl.includes('xi') && !lvl.includes('ix'));
  const isClass11 = lvl.includes('11') || lvl.includes('xi') || lvl.includes('class 11');
  if (norm === 'physics') {
    const ac = (boardAcronym || '').toLowerCase();
    if (ac.includes('cbse')) {
      return [
        'Chapter 1: Electric Charges and Fields',
        'Chapter 2: Electrostatic Potential and Capacitance',
        'Chapter 3: Current Electricity',
        'Chapter 4: Moving Charges and Magnetism',
        'Chapter 5: Magnetism and Matter',
        'Chapter 6: Electromagnetic Induction',
        'Chapter 7: Alternating Current',
        'Chapter 8: Electromagnetic Waves',
        'Chapter 9: Ray Optics and Optical Instruments',
        'Chapter 10: Wave Optics',
        'Chapter 11: Dual Nature of Radiation and Matter',
        'Chapter 12: Atoms',
        'Chapter 13: Nuclei',
        'Chapter 14: Semiconductor Electronics'
      ];
    }
    if (ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) {
      if (isClass9) {
        return PHYSICS_ICSE_CLASS9_LESSONS;
      }
      if (isClass11) {
        return PHYSICS_ICSE_CLASS11_LESSONS;
      }
      return PHYSICS_ICSE_LESSONS;
    }
    return [
      'Mechanics & Kinematics',
      'Thermal Physics & Thermodynamics',
      'Optics & Wave Motion',
      'Current Electricity & Electromagnetism',
      'Modern Physics & Electronics'
    ];
  }
  if (norm === 'mathematics') {
    const ac = (boardAcronym || '').toLowerCase();
    if (ac.includes('cbse')) {
      return MATHEMATICS_CBSE_LESSONS;
    }
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass9) {
      return MATHEMATICS_ICSE_CLASS9_LESSONS;
    }
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass10) {
      return MATHEMATICS_ICSE_CLASS10_LESSONS;
    }
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return MATHEMATICS_ICSE_CLASS11_LESSONS;
    }
    return MATHEMATICS_ICSE_CLASS10_LESSONS;
  }
  if (norm === 'chemistry') {
    const ac = (boardAcronym || '').toLowerCase();
    if (ac.includes('cbse')) {
      return CHEMISTRY_CBSE_LESSONS;
    }
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass9) {
      return CHEMISTRY_ICSE_CLASS9_LESSONS;
    }
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return CHEMISTRY_ICSE_CLASS11_LESSONS;
    }
    return CHEMISTRY_ICSE_LESSONS;
  }
  if (norm === 'biology') {
    const ac = (boardAcronym || '').toLowerCase();
    if (ac.includes('cbse')) {
      return BIOLOGY_CBSE_LESSONS;
    }
    if ((ac.includes('isc') || ac.includes('icse') || ac.includes('cisce')) && isClass9) {
      return BIOLOGY_ICSE_CLASS9_LESSONS;
    }
    if ((ac.includes('isc') || ac.includes('icse') || ac.includes('cisce')) && isClass11) {
      return BIOLOGY_ICSE_CLASS11_LESSONS;
    }
    if (ac.includes('isc') || ac.includes('icse') || ac.includes('cisce')) {
      return BIOLOGY_ISC_LESSONS;
    }
    return BIOLOGY_ICSE_LESSONS;
  }
  if (norm === 'computer_science' || norm === 'computers' || norm === 'computer_applications') {
    const ac = (boardAcronym || '').toLowerCase();
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass9) {
      return COMPUTER_SCIENCE_ICSE_CLASS9_LESSONS;
    }
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return COMPUTER_SCIENCE_ICSE_CLASS11_LESSONS;
    }
    return COMPUTER_SCIENCE_ICSE_LESSONS;
  }
  if (norm === 'social_science' || norm === 'social_studies' || norm === 'sst') {
    const ac = (boardAcronym || '').toLowerCase();
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass9) {
      return SOCIAL_SCIENCE_ICSE_CLASS9_LESSONS;
    }
    return [
      'Indian History & World Civics',
      'Geography of India',
      'Indian Democratic Principles & Institutions'
    ];
  }
  if (norm === 'history' || norm === 'history_civics' || norm === 'civics') {
    const ac = (boardAcronym || '').toLowerCase();
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass9) {
      return HISTORY_CIVICS_ICSE_CLASS9_LESSONS;
    }
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return HISTORY_ICSE_CLASS11_LESSONS;
    }
    return [
      'Indian Freedom Movement & Nationalism',
      'World War Eras & Colonialism',
      'Civics & Organs of Indian Government'
    ];
  }
  if (norm === 'geography') {
    const ac = (boardAcronym || '').toLowerCase();
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass9) {
      return GEOGRAPHY_ICSE_CLASS9_LESSONS;
    }
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return GEOGRAPHY_ICSE_CLASS11_LESSONS;
    }
    return [
      'Detailed Geography of India',
      'Physical & Resource Geography',
      'Climatic Zones & Soils of India'
    ];
  }
  if (norm === 'political_science' || norm === 'political science' || norm === 'pol_science' || norm === 'political_science_civics') {
    const ac = (boardAcronym || '').toLowerCase();
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return POLITICAL_SCIENCE_ICSE_CLASS11_LESSONS;
    }
    return POLITICAL_SCIENCE_ICSE_CLASS11_LESSONS;
  }
  if (norm === 'sociology') {
    const ac = (boardAcronym || '').toLowerCase();
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return SOCIOLOGY_ICSE_CLASS11_LESSONS;
    }
    return SOCIOLOGY_ICSE_CLASS11_LESSONS;
  }
  if (norm === 'psychology' || norm === 'psych') {
    const ac = (boardAcronym || '').toLowerCase();
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return PSYCHOLOGY_ICSE_CLASS11_LESSONS;
    }
    return PSYCHOLOGY_ISC_LESSONS;
  }
  if (norm === 'economics' || norm === 'economy' || norm === 'econ') {
    const ac = (boardAcronym || '').toLowerCase();
    if ((ac.includes('icse') || ac.includes('cisce') || ac.includes('isc')) && isClass11) {
      return ECONOMICS_ICSE_CLASS11_LESSONS;
    }
    return ECONOMICS_ISC_LESSONS;
  }
  
  const readable = subject.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  return Array.from({ length: 35 }, (_, i) => `${readable} Module ${i + 1}`);
};

export const POLITICAL_SCIENCE_ICSE_CLASS11_LESSONS = [
  'Introduction to Political Science & Theory of State',
  'Fundamental Political Concepts: Sovereignty, Law, Liberty, Equality & Justice',
  'Forms of Government: Unitary, Federal, Parliamentary & Presidential',
  'Constitutions and Organic Structures: Legislature, Executive & Judiciary',
  'Franchise, Representation, Political Parties & Pressure Groups',
  'Paper II: Project Work & Comparative Political Analysis (20 Marks)'
];

export const INTRO_POLITICAL_SCIENCE_ICSE11_SUBTOPICS = [
  "Scope & Nature of Political Science: Definition of Political Science; Evolution from traditional philosophical study to modern behavioral and empirical discipline; Scope of study and interdisciplinary relationships with History, Economics, and Sociology",
  "The State: Definition and essential elements of the State (Population, Territory, Government, Sovereignty); Distinctions between State and Government, State and Nation, and State and Society",
  "Origin of the State: Critical analysis of theories of origin, focusing on the Social Contract Theory (Hobbes, Locke, and Rousseau) and the Evolutionary/Historical Theory"
];

export const FUNDAMENTAL_POLITICAL_CONCEPTS_ICSE11_SUBTOPICS = [
  "Sovereignty: Meaning, essential characteristics, and types (titular, real, legal, political, and popular sovereignty); Monistic theory (John Austin's legal sovereignty) vs. Pluralistic theory of sovereignty",
  "Law: Definition, sources of law (custom, religion, judicial decisions, equity, scientific commentaries, legislation), and classifications of law; Interrelationship between Law and Liberty",
  "Liberty, Equality, and Justice: Liberty (meaning, negative vs. positive dimensions, safeguards); Equality (meaning, legal, political, social, and economic dimensions, relationship with Liberty); Justice (meaning, legal, political, social, economic, and distributive justice concepts)"
];

export const FORMS_OF_GOVERNMENT_ICSE11_SUBTOPICS = [
  "Unitary and Federal Systems: Unitary State (meaning, features, merits, demerits - Example: United Kingdom); Federal State (meaning, essential features, merits, demerits - Example: United States)",
  "Parliamentary and Presidential Systems: Parliamentary System (executive-legislative coordination, collective responsibility, leadership role of Prime Minister - Examples: United Kingdom and India); Presidential System (strict separation of powers, fixed tenure, role of President - Example: United States)"
];

export const CONSTITUTIONS_ORGANIC_STRUCTURES_ICSE11_SUBTOPICS = [
  "Classification of Constitutions: Written vs. Unwritten constitutions; Rigid vs. Flexible constitutions; Comparative merits and demerits with global case studies",
  "The Legislature: Primary and secondary functions of a modern legislature; Unicameralism vs. Bicameralism (arguments for and against a second chamber)",
  "The Executive: Functions of the executive branch; Types of executives (nominal vs. real, single vs. plural, political vs. permanent/civil service)",
  "The Judiciary: Importance of an independent judiciary; Core functions of the judiciary; Judicial Review (meaning, origin, and global significance); Essential safeguards for ensuring judicial independence"
];

export const FRANCHISE_REPRESENTATION_PARTIES_ICSE11_SUBTOPICS = [
  "Suffrage and Minority Representation: Universal Adult Franchise (arguments for and against); Minority representation systems (Proportional Representation: Single Transferable Vote & List system, Cumulative voting, Plural voting)",
  "Political Parties and Pressure Groups: Political Parties (meaning, functions, types: one-party, two-party, multi-party systems); Pressure Groups (definition, techniques and methods of operation, structural distinction from political parties)"
];

export const PROJECT_WORK_POLITICAL_SCIENCE_ICSE11_SUBTOPICS = [
  "Paper II: Project Work & Research Essay (20 Marks): Independent 2000-word analytical project report on approved political or constitutional themes (e.g., Comparative study of US President vs UK Prime Minister, Working of Multi-Party vs Two-Party Systems, Role of Pressure Groups in Public Policy)",
  "Assessment Framework: Evaluation split into Project File & Academic Research Content (10 Marks Internal Evaluation) and Viva-Voce / Individual Presentation (10 Marks External Board Evaluation)"
];

export const SOCIOLOGY_ICSE_CLASS11_LESSONS = [
  '1. Origin and Development of Sociology and Anthropology',
  '2. Research Methodology',
  '3. Basic Concepts',
  '4. Social Structure',
  '5. Social Problems',
  '6. Indian Sociologists',
  'Paper II: Practical Work (30 Marks)'
];

export const ORIGIN_DEV_SOCIOLOGY_ICSE11_SUBTOPICS = [
  "Emergence & Scope: Historical contexts leading to the growth of both disciplines and the dynamic scope of sociology.",
  "Classical Thinkers: Foundational theories by Auguste Comte (Positivism), Herbert Spencer (Social Darwinism), Émile Durkheim (Structural Functionalism), Max Weber (Interpretive Sociology), and Karl Marx (Conflict Theory).",
  "Interrelationships: Comparisons between sociology and other social sciences like political science, economics, and anthropology."
];

export const RESEARCH_METHODOLOGY_SOCIOLOGY_ICSE11_SUBTOPICS = [
  "Foundations & Scientific Methods: Importance of scientific methodology, step-by-step procedures from observation to hypothesis building, and comparative or historical approaches.",
  "Tools of Data Collection: Exploration of primary and secondary tools including questionnaires, interviews, and observations."
];

export const BASIC_CONCEPTS_SOCIOLOGY_ICSE11_SUBTOPICS = [
  "Individual, Society & Socialization: Characteristics of society, rural vs. urban differences, and the socialization process involving primary/secondary agencies and theories like Cooley's Looking-Glass Self.",
  "Culture: Material vs. non-material culture, cultural lag, and ethnocentrism."
];

export const SOCIAL_STRUCTURE_SOCIOLOGY_ICSE11_SUBTOPICS = [
  "Social Groups & Processes: Primary, secondary, in-out, and reference groups alongside status, role conflict, and basic social processes like co-operation and conflict.",
  "Status and Role: Ascribed vs. achieved status and role stereotyping."
];

export const SOCIAL_PROBLEMS_SOCIOLOGY_ICSE11_SUBTOPICS = [
  "Issues & Deviance: Demographic challenges like overpopulation, poverty, child labour, juvenile delinquency, and hurdles faced by vulnerable groups."
];

export const INDIAN_SOCIOLOGISTS_ICSE11_SUBTOPICS = [
  "Pioneering Perspectives: Contributions and field-work profiles of thinkers such as G.S. Ghurye, M.N. Srinivas, and others."
];

export const PRACTICAL_SOCIOLOGY_ICSE11_SUBTOPICS = [
  "Sociological Projects: Completion of two independent empirical or ethnographic research projects utilizing interviews or surveys (15 marks each).",
  "Assessment Framework: Evaluated via a project file/report (10 marks) and a viva-voce/presentation (5 marks)."
];

export const PSYCHOLOGY_ICSE_CLASS11_LESSONS = [
  "1. Introduction to Psychology",
  "2. Methods of Psychology",
  "3. Biological Bases of Behaviour",
  "4. Human Development",
  "5. Sensory, Attentional, and Perceptual Processes",
  "6. Learning",
  "7. Human Memory",
  "Paper II: Practical Work (30 Marks)"
];

export const ECONOMICS_ICSE_CLASS11_LESSONS = [
  "1. Understanding Economics & Basic Concepts",
  "2. Consumer Behaviour and Demand",
  "3. Producer Behaviour, Supply, and Cost",
  "4. Market Forms and Price Determination",
  "5. Structural Features of the Indian Economy",
  "6. Basic Statistics for Economics",
  "Paper II: Project Work (20 Marks)"
];

export const INTRO_PSYCHOLOGY_ICSE11_SUBTOPICS = [
  "Foundations & Nature: Definition of psychology; Evolution from a philosophical branch to an empirical science; Scope and branches of psychology (cognitive, developmental, social, clinical, industrial, and educational).",
  "Historical Schools: Structuralism (Wilhelm Wundt), Functionalism (William James), Behaviorism (John B. Watson, B.F. Skinner), Gestalt Psychology, Psychoanalysis (Sigmund Freud), and Humanistic Perspective (Carl Rogers, Abraham Maslow).",
  "The Indian Perspective: Ancient Indian roots of psychological thought (Yoga, Vedanta, and Sufi influences); The development of modern scientific psychology in India."
];

export const METHODS_PSYCHOLOGY_ICSE11_SUBTOPICS = [
  "Scientific Research: Goals of psychological inquiry (description, prediction, explanation, and control); Objectivity, reliability, and validity parameters.",
  "Observational Method: Naturalistic vs. participant observation; Strengths and biases.",
  "Experimental Method: Independent, dependent, and extraneous variables; Experimental vs. control groups.",
  "Correlational Method: Positive, negative, and zero correlation; Understanding that correlation does not imply causation.",
  "Case Study & Survey Method: Qualitative profiling, interviews, rating scales, and standardized questionnaires.",
  "Ethical Issues: Informed consent, confidentiality, debriefing, and minimizing harm to human and animal subjects."
];

export const BIOLOGICAL_BASES_PSYCHOLOGY_ICSE11_SUBTOPICS = [
  "The Neuron: Structure of a neuron (dendrites, cell body, axon, myelin sheath, terminal buttons); Nerve impulse transmission (action potential and synaptic transmission); Major neurotransmitters (Acetylcholine, Dopamine, Serotonin) and their behavioral impacts.",
  "Central Nervous System (CNS): Structure and functions of the Brain (hindbrain, midbrain, forebrain including the cerebral cortex and limbic system) and Spinal Cord; Lateralization and hemispheric specialization.",
  "Peripheral Nervous System (PNS): Somatic and Autonomic systems (Sympathetic and Parasympathetic nervous systems activation profiles during stress).",
  "The Endocrine System: Major endocrine glands (Pituitary, Thyroid, Adrenals, Gonads) and the physiological/behavioral effects of hormone secretions."
];

export const HUMAN_DEVELOPMENT_PSYCHOLOGY_ICSE11_SUBTOPICS = [
  "Growth and Development: Meaning of development; Principles of growth and development; Interaction of heredity (nature) and environment (nurture).",
  "Stages of Development: Physical, cognitive, and socio-emotional changes across major milestones: Prenatal development, Infancy, and Early/Late Childhood.",
  "Adolescence: Identity crisis, peer pressure, physiological changes, and challenges.",
  "Adulthood and Old Age: Aging processes and coping mechanisms.",
  "Theories of Development: Piaget's Theory of Cognitive Development (four stages); Erikson's Theory of Psychosocial Development (eight stages)."
];

export const SENSORY_PERCEPTUAL_PSYCHOLOGY_ICSE11_SUBTOPICS = [
  "Sensory Modalities: Structure and working of the human eye (visual sensation) and ear (auditory sensation); Concepts of absolute threshold and differential threshold (Just Noticeable Difference).",
  "Attentional Processes: Selective attention and sustained attention; Factors influencing attention (internal/subjective vs. external/objective factors).",
  "Perceptual Organisation: Principles of Gestalt organization (Proximity, Similarity, Continuity, Closure); Perception of depth (monocular and binocular cues); Perceptual constancies (size, shape); Illusions (Müller-Lyer, Ponzo illusions)."
];

export const LEARNING_PSYCHOLOGY_ICSE11_SUBTOPICS = [
  "Classical Conditioning: Ivan Pavlov’s experiments; Concepts of Unconditioned Stimulus (US), Unconditioned Response (UR), Conditioned Stimulus (CS), and Conditioned Response (CR); Phenomena of acquisition, extinction, spontaneous recovery, generalization, and discrimination.",
  "Operant Conditioning: B.F. Skinner’s box experiments; Types of reinforcement (positive vs. negative); Punishment vs. negative reinforcement; Schedules of reinforcement (fixed, variable, interval, ratio).",
  "Cognitive & Observational Learning: Insight learning (Wolfgang Köhler's chimpanzee experiments); Latent learning (Edward Tolman); Observational/Social learning (Albert Bandura’s Bobo doll experiments)."
];

export const MEMORY_PSYCHOLOGY_ICSE11_SUBTOPICS = [
  "Stage Model of Memory: Atkinson and Shiffrin model; Sensory memory (iconic, echoic), Short-Term Memory (STM / Working Memory), and Long-Term Memory (LTM).",
  "LTM Classifications: Declarative (Semantic and Episodic) vs. Non-declarative/Procedural memory.",
  "Forgetting: Ebbinghaus’ forgetting curve; Theories of forgetting: Trace decay (disuse), Interference (proactive and retroactive), and Motivated forgetting (repression).",
  "Memory Enhancement: Mnemonics, method of loci, chunking, organization, and deep-level processing."
];

export const PRACTICAL_PSYCHOLOGY_ICSE11_SUBTOPICS = [
  "Section A: Laboratory Experiments / Testing (15 Marks): Core assignments: Measuring the span of immediate memory, testing the effect of chunking on recall, analyzing bilateral transfer of learning (mirror-drawing apparatus), demonstrating part vs. whole learning, or evaluating the division of attention.",
  "Section B: Case Profile / Field Project (10 Marks): Conduction of a basic field profile, observing a developmental milestone in children or interviewing adolescents regarding academic stress and identity choices, documented in an empirical format.",
  "Section C: Practical Log and Viva-Voce (5 Marks): Structural review of the regular laboratory notebook and an oral board examination conducted by an external examiner."
];

export const UNDERSTANDING_ECONOMICS_ICSE11_SUBTOPICS = [
  "Definitions of Economics: Wealth definition (Adam Smith), Welfare definition (Alfred Marshall), Scarcity definition (Lionel Robbins), and Growth definition (Paul Samuelson).",
  "Core Concepts: Micro vs. Macroeconomics; Positive vs. Normative economics; Concept of scarcity, choice, and central problems of an economy (What, How, and For Whom to produce).",
  "Basic Terminology: Definition and classification of Goods (economic, free, consumer, capital, intermediate); Utility, Value, Price, Wealth, Welfare, Production, and Consumption."
];

export const CONSUMER_BEHAVIOUR_DEMAND_ICSE11_SUBTOPICS = [
  "Utility Analysis: Cardinal utility approach; Law of Diminishing Marginal Utility; Consumer’s equilibrium (Single commodity case); Ordinal utility approach: Indifference curves, properties, and consumer's budget line.",
  "Theory of Demand: Meaning and determinants of demand; Demand function; Law of Demand (statement, assumptions, and reasons for its operation); Exceptions to the Law of Demand.",
  "Movements vs. Shifts: Distinction between expansion/contraction of demand (movements along the curve) and increase/decrease in demand (shifts of the curve).",
  "Elasticity of Demand: Price elasticity of demand (meaning and degrees: perfectly elastic, perfectly inelastic, unitary, elastic, inelastic); Methods of measurement: Percentage method, Point method, and Total Outlay method; Factors affecting price elasticity of demand."
];

export const PRODUCER_BEHAVIOUR_SUPPLY_COST_ICSE11_SUBTOPICS = [
  "Production Function: Short-run vs. Long-run production function; Law of Variable Proportions (three stages, assumptions, and reasons for operation); Returns to scale (brief qualitative overview).",
  "Cost and Revenue Concepts: Meaning of Total Cost (TC), Total Fixed Cost (TFC), Total Variable Cost (TVC), Average Cost (AC), and Marginal Cost (MC) along with their mathematical interrelations and U-shaped curves; Total Revenue (TR), Average Revenue (AR), and Marginal Revenue (MR) under perfect and imperfect competition.",
  "Theory of Supply: Meaning and determinants of supply; Law of Supply; Movements vs. shifts of the supply curve; Price elasticity of supply (meaning and measurement via percentage method)."
];

export const MARKET_FORMS_PRICE_DET_ICSE11_SUBTOPICS = [
  "Main Market Forms: Meaning and unique characteristics of Perfect Competition, Monopoly, Monopolistic Competition, and Oligopoly.",
  "Equilibrium Price: Price determination under Perfect Competition; Effects of shifts in demand and supply on the equilibrium price and quantity; Concept of price ceiling and price floor."
];

export const STRUCTURAL_FEATURES_INDIAN_ECON_ICSE11_SUBTOPICS = [
  "Post-Independence Overview: Indian economy at the time of Independence; Nature and features of the Indian economy as a developing economy.",
  "Economic Sectors: Role and problems of Agriculture, Industry, and the Services sector in Indian economic development.",
  "Economic Reforms: Economic policies up to 1991; The New Economic Policy of 1991 (Liberalisation, Privatisation, and Globalisation - LPG).",
  "Current Challenges: Absolute vs. relative poverty, unemployment trends, human capital formation, and sustainable economic growth."
];

export const BASIC_STATISTICS_ECONOMICS_ICSE11_SUBTOPICS = [
  "Data Collection & Organisation: Meaning, scope, and importance of statistics in economics; Primary vs. secondary data; Methods of data collection; Sampling vs. Census methods; Classification and tabular presentation of data.",
  "Measures of Central Tendency: Calculation of Mean, Median, and Mode for ungrouped and grouped continuous data.",
  "Measures of Dispersion: Absolute and relative dispersion measures; Range, Quartile Deviation, Mean Deviation, Standard Deviation, and Coefficient of Variation.",
  "Correlation & Index Numbers: Karl Pearson’s Coefficient of Correlation (scatter diagrams and numerical calculation); Meaning, types, and construction of Index Numbers (Wholesale Price Index, Consumer Price Index, Laspeyres’, Paasche’s, and Fisher’s methods)."
];

export const PROJECT_WORK_ECONOMICS_ICSE11_SUBTOPICS = [
  "Research Essay Submission: Select and draft two detailed project reports (approx. 1000-1500 words each) based on the curriculum parameters.",
  "Sample Project Directions: Comparative price study of consumer goods; analytical study of 1991 reforms; or community unemployment survey.",
  "Assessment Framework: Project File & Academic Content (10 Marks Internal Evaluation) and Viva-Voce / Individual Presentation (10 Marks External Board Evaluation)."
];


