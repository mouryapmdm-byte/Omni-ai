import React, { useState, useRef, useEffect, useId, useCallback, useMemo } from 'react';
import { cn } from '../lib/utils';
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Maximize2, 
  Download, 
  Copy, 
  Check, 
  Edit3, 
  Sparkles, 
  X,
  Grid,
  Tag,
  ArrowUpRight,
  Play,
  Pause,
  Eye,
  EyeOff,
  Layers,
  Sparkle,
  Pencil,
  Eraser,
  Trash2,
  Undo2,
  Redo2,
  MoveUpRight,
  Minus,
  Palette,
  Volume2,
  VolumeX,
  Compass,
  Move,
  Info,
  Sliders,
  Contrast,
  Zap,
  SunMedium,
  Crosshair,
  Target
} from 'lucide-react';
import { playChalkSound, playDiagramThud, isChalkSoundEnabled, setChalkSoundEnabled } from '@/src/lib/chalkAudio';
import { sanitizeSvgDiagramCode } from '../lib/streaming/cleanStreamingMarkdown';

// Helper function to parse CSS color string to RGB components [r, g, b, alpha]
function parseCssColorToRgb(colorStr: string): { r: number; g: number; b: number; a: number } {
  if (!colorStr || colorStr === 'transparent' || colorStr === 'inherit') {
    return { r: 15, g: 23, b: 42, a: 1 };
  }
  
  const rgbMatch = colorStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
  if (rgbMatch) {
    return {
      r: parseInt(rgbMatch[1], 10),
      g: parseInt(rgbMatch[2], 10),
      b: parseInt(rgbMatch[3], 10),
      a: rgbMatch[4] !== undefined ? parseFloat(rgbMatch[4]) : 1,
    };
  }

  if (colorStr.startsWith('#')) {
    const hex = colorStr.replace('#', '');
    if (hex.length === 3) {
      return {
        r: parseInt(hex[0] + hex[0], 16),
        g: parseInt(hex[1] + hex[1], 16),
        b: parseInt(hex[2] + hex[2], 16),
        a: 1,
      };
    }
    if (hex.length >= 6) {
      return {
        r: parseInt(hex.substring(0, 2), 16),
        g: parseInt(hex.substring(2, 4), 16),
        b: parseInt(hex.substring(4, 6), 16),
        a: hex.length === 8 ? parseInt(hex.substring(6, 8), 16) / 255 : 1,
      };
    }
  }

  return { r: 15, g: 23, b: 42, a: 1 };
}

// Helper to calculate relative luminance according to WCAG 2.1 specifications
function getRelativeLuminance(r: number, g: number, b: number): number {
  const rs = r / 255;
  const gs = g / 255;
  const bs = b / 255;

  const R = rs <= 0.03928 ? rs / 12.92 : Math.pow((rs + 0.055) / 1.055, 2.4);
  const G = gs <= 0.03928 ? gs / 12.92 : Math.pow((gs + 0.055) / 1.055, 2.4);
  const B = bs <= 0.03928 ? bs / 12.92 : Math.pow((bs + 0.055) / 1.055, 2.4);

  return 0.2126 * R + 0.7152 * G + 0.0722 * B;
}

// Helper to compute contrast ratio between two relative luminances
function getContrastRatio(l1: number, l2: number): number {
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

interface SvgDiagramViewerProps {
  svgCode: string;
  theme?: 'light' | 'dark';
  title?: string;
  onOpenWhiteboard?: (svgDataUrl: string) => void;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  onRenderComplete?: () => void;
  onExplainFigure?: (svgCodeOrImage: string, title?: string, isNanoBanana?: boolean) => void;
  // Unified canvas UI state bindings
  isHighContrast?: boolean;
  isVectorDragMode?: boolean;
  showVectorTelemetry?: boolean;
  isMagnifierActive?: boolean;
  isChalkMode?: boolean;
  showGrid?: boolean;
  onToggleHighContrast?: (val?: boolean) => void;
  onToggleVectorDragMode?: (val?: boolean) => void;
  onToggleVectorTelemetry?: (val?: boolean) => void;
  onToggleMagnifier?: (val?: boolean) => void;
  onToggleChalkMode?: (val?: boolean) => void;
  onToggleGrid?: (val?: boolean) => void;
}

type ChalkTool = 'pen' | 'arrow' | 'line' | 'eraser';

interface ChalkColor {
  name: string;
  color: string;
  bgClass: string;
}

const CHALK_COLORS: ChalkColor[] = [
  { name: 'Yellow Chalk', color: '#fde047', bgClass: 'bg-yellow-300' },
  { name: 'White Chalk', color: '#ffffff', bgClass: 'bg-white' },
  { name: 'Mint Green', color: '#4ade80', bgClass: 'bg-emerald-400' },
  { name: 'Coral Pink', color: '#f43f5e', bgClass: 'bg-rose-500' },
  { name: 'Sky Cyan', color: '#38bdf8', bgClass: 'bg-sky-400' },
  { name: 'Amber Glow', color: '#fb923c', bgClass: 'bg-amber-500' }
];

const NEON_CHALK_COLORS: ChalkColor[] = [
  { name: 'Neon Laser Cyan', color: '#00f5ff', bgClass: 'bg-[#00f5ff]' },
  { name: 'Neon Electric Yellow', color: '#ffff00', bgClass: 'bg-[#ffff00]' },
  { name: 'Neon Laser Magenta', color: '#ff007f', bgClass: 'bg-[#ff007f]' },
  { name: 'Neon Toxic Lime', color: '#39ff14', bgClass: 'bg-[#39ff14]' },
  { name: 'High-Contrast Pure White', color: '#ffffff', bgClass: 'bg-white' },
  { name: 'Neon Plasma Orange', color: '#ff5500', bgClass: 'bg-[#ff5500]' }
];

export interface DraggableVector {
  id: string;
  name: string;
  label: string;
  originX: number;
  originY: number;
  tipX: number;
  tipY: number;
  color: string;
  secondaryColor: string;
  isResultant?: boolean;
}

export const SvgDiagramViewer: React.FC<SvgDiagramViewerProps> = ({
  svgCode,
  theme = 'dark',
  title = '2D Vector Teaching Schematic',
  onOpenWhiteboard,
  showNotification,
  onRenderComplete,
  onExplainFigure,
  isHighContrast: propHighContrast,
  isVectorDragMode: propVectorDragMode,
  showVectorTelemetry: propVectorTelemetry,
  isMagnifierActive: propMagnifierActive,
  isChalkMode: propChalkMode,
  showGrid: propShowGrid,
  onToggleHighContrast,
  onToggleVectorDragMode,
  onToggleVectorTelemetry,
  onToggleMagnifier,
  onToggleChalkMode,
  onToggleGrid
}) => {
  const [zoom, setZoom] = useState(1);
  const [copied, setCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const svgWrapperRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const vectorSvgOverlayRef = useRef<SVGSVGElement>(null);
  const instanceId = useId().replace(/:/g, '');

  // Panacea Feature: Live-Interactive Sandbox & Active-Recall Playground States
  const [parsedLabels, setParsedLabels] = useState<Array<{ text: string; x: number; y: number; width: number; height: number; element: HTMLElement }>>([]);
  const [isQuizActive, setIsQuizActive] = useState(false);
  const [quizTarget, setQuizTarget] = useState<string | null>(null);
  const [quizCompleted, setQuizCompleted] = useState<string[]>([]);
  const [quizAttempts, setQuizAttempts] = useState({ correct: 0, total: 0 });
  const [flowSpeed, setFlowSpeed] = useState(2); // Flow controller slider state (Default 2x)

  // Parse labels and coordinates from DOM after render
  useEffect(() => {
    if (!containerRef.current) return;
    
    const timer = setTimeout(() => {
      const elements = containerRef.current?.querySelectorAll('text, tspan');
      if (!elements) return;
      
      const labelsList: any[] = [];
      const seenTexts = new Set<string>();

      elements.forEach((el: any) => {
        const textContent = el.textContent?.trim();
        // Ignore empty, short, or purely numeric labels to prevent clutter
        if (!textContent || textContent.length < 1 || /^\d+$/.test(textContent) || seenTexts.has(textContent)) {
          return;
        }
        
        const containerRect = containerRef.current?.getBoundingClientRect();
        const elRect = el.getBoundingClientRect();
        
        if (containerRect && elRect) {
          labelsList.push({
            text: textContent,
            x: elRect.left - containerRect.left + elRect.width / 2,
            y: elRect.top - containerRect.top + elRect.height / 2,
            width: elRect.width,
            height: elRect.height,
            element: el,
          });
          seenTexts.add(textContent);
        }
      });
      
      setParsedLabels(labelsList);
    }, 600);

    return () => clearTimeout(timer);
  }, [svgCode, isFullscreen]);

  // Handle click listener binding on actual SVG text/tspan nodes
  useEffect(() => {
    if (parsedLabels.length === 0) return;

    const handleElementClick = (e: MouseEvent, labelText: string) => {
      if (!isQuizActive) {
        // In standard explore mode, clicking a hotspot triggers descriptions
        playChalkSound?.();
        if (onExplainFigure) {
          onExplainFigure(svgCode, `Detailed Spotlight explanation of "${labelText}"`);
        } else if (showNotification) {
          showNotification(`Spotlight on: "${labelText}" • Click the Explain button above for a full breakdown.`, 'info');
        }
        return;
      }

      e.stopPropagation();
      e.preventDefault();

      if (labelText === quizTarget) {
        // Correct click
        playDiagramThud?.();
        const nextCompleted = [...quizCompleted, labelText];
        setQuizCompleted(nextCompleted);
        
        const elements = containerRef.current?.querySelectorAll('text, tspan');
        elements?.forEach((el: any) => {
          if (el.textContent?.trim() === labelText) {
            el.classList.add('quiz-revealed');
          }
        });

        // Trigger confetti burst on success!
        import('canvas-confetti').then((confettiModule) => {
          confettiModule.default({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.8 }
          });
        });

        const remaining = parsedLabels
          .map(l => l.text)
          .filter(t => !nextCompleted.includes(t));

        if (remaining.length > 0) {
          const nextTarget = remaining[Math.floor(Math.random() * remaining.length)];
          setQuizTarget(nextTarget);
          setQuizAttempts(prev => ({ correct: prev.correct + 1, total: prev.total + 1 }));
          if (showNotification) {
            showNotification(`Correct! Now find and click on: "${nextTarget}"`, 'success');
          }
        } else {
          setQuizTarget(null);
          setQuizAttempts(prev => ({ correct: prev.correct + 1, total: prev.total + 1 }));
          if (showNotification) {
            showNotification(`🏆 Incredible! You successfully labeled all components of the diagram!`, 'success');
          }
          // Massive confetti celebration!
          import('canvas-confetti').then((confettiModule) => {
            confettiModule.default({
              particleCount: 150,
              spread: 100,
              origin: { y: 0.6 }
            });
          });
        }
      } else {
        // Incorrect click
        playChalkSound?.();
        setQuizAttempts(prev => ({ ...prev, total: prev.total + 1 }));
        if (showNotification) {
          showNotification(`Not quite! That was "${labelText}". Try to find: "${quizTarget}"`, 'warning');
        }
      }
    };

    parsedLabels.forEach((label) => {
      const handler = (e: MouseEvent) => handleElementClick(e, label.text);
      label.element.addEventListener('click', handler);
      (label.element as any)._quizHandler = handler;
    });

    return () => {
      parsedLabels.forEach((label) => {
        if ((label.element as any)._quizHandler) {
          label.element.removeEventListener('click', (label.element as any)._quizHandler);
        }
      });
    };
  }, [parsedLabels, isQuizActive, quizTarget, quizCompleted]);

  // Context-Aware Anchor Tagging Metadata
  const anchorParagraph = useMemo(() => {
    const match = svgCode.match(/data-anchor-paragraph=["']?(\d+)["']?/i);
    if (match) return match[1];
    const commentMatch = svgCode.match(/ANCHOR_POINT:\s*Paragraph\s*(\d+)/i);
    return commentMatch ? commentMatch[1] : null;
  }, [svgCode]);

  const anchorTopic = useMemo(() => {
    const match = svgCode.match(/data-anchor-topic=["']?([^"'>]+)["']?/i);
    if (match) return match[1];
    const commentMatch = svgCode.match(/ANCHOR_POINT:\s*Paragraph\s*\d+\s*-\s*([^\n-->]+)/i);
    return commentMatch ? commentMatch[1].trim() : null;
  }, [svgCode]);

  // Floating Interactive Toolbar States
  const [showGrid, setShowGrid] = useState(propShowGrid ?? true);
  const [showLabels, setShowLabels] = useState(true);
  const [showResultant, setShowResultant] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);
  const [animKey, setAnimKey] = useState(0);

  // Vector Drag Mode States (Default: false per user request to delete default vectors)
  const [isVectorDragMode, setIsVectorDragMode] = useState(propVectorDragMode ?? false);
  const [activeDragTarget, setActiveDragTarget] = useState<{ id: string; type: 'tip' | 'origin' } | null>(null);

  // Layered Transparency & Advanced Scientific Fill Patterns
  const [layerOpacity, setLayerOpacity] = useState<number>(0.95);
  const [fillPatternStyle, setFillPatternStyle] = useState<'none' | 'hatch' | 'crosshatch' | 'stipple' | 'cellular' | 'xray'>('none');
  const [showPatternMenu, setShowPatternMenu] = useState<boolean>(false);
  const [showOpacityMenu, setShowOpacityMenu] = useState<boolean>(false);

  // High-Contrast Neon Accessibility Mode (Optimized for diverse lighting & projection)
  const [isHighContrast, setIsHighContrast] = useState<boolean>(() => {
    if (propHighContrast !== undefined) return propHighContrast;
    return typeof document !== 'undefined' && (document.documentElement.classList.contains('high-contrast') || document.documentElement.classList.contains('high-contrast-neon'));
  });

  // Dynamic Theme Manager: Auto-detects current theme state and exports responsive color values
  const colors = useMemo(() => {
    const isHCGreen = (theme as string) === 'high-contrast-green' || 
                      (typeof document !== 'undefined' && document.documentElement.classList.contains('high-contrast-green')) ||
                      (typeof localStorage !== 'undefined' && localStorage.getItem('omni_theme_mode') === 'high-contrast-green');
                      
    const isHC = isHighContrast || 
                 (typeof document !== 'undefined' && (document.documentElement.classList.contains('high-contrast') || document.documentElement.classList.contains('high-contrast-neon'))) ||
                 (typeof localStorage !== 'undefined' && localStorage.getItem('omni_theme_mode') === 'high-contrast');

    const isDarkMode = theme === 'dark' || 
                       (typeof document !== 'undefined' && document.documentElement.classList.contains('dark')) ||
                       (typeof localStorage !== 'undefined' && localStorage.getItem('omni_theme') === 'dark');

    if (isHCGreen) {
      return {
        bg: '#022c22', // emerald-950
        primary: '#34d399', // emerald-400
        secondary: '#a7f3d0', // emerald-200
        text: '#e6f4ea',
        highlight: '#fbbf24', // amber-400
        accent: '#059669', // emerald-600
        grid: 'rgba(52, 211, 153, 0.15)',
        modeName: 'High Contrast Green'
      };
    }
    
    if (isHC) {
      return {
        bg: '#000000',
        primary: '#ffffff',
        secondary: '#00f5ff', // neon cyan
        text: '#ffffff',
        highlight: '#ff007f', // neon pink
        accent: '#00f5ff',
        grid: 'rgba(0, 245, 255, 0.2)',
        modeName: 'High Contrast Neon'
      };
    }
    
    if (isDarkMode) {
      return {
        bg: '#0f172a', // slate-900
        primary: '#f1f5f9', // slate-100
        secondary: '#818cf8', // indigo-400
        text: '#cbd5e1', // slate-300
        highlight: '#fb7185', // rose-400
        accent: '#4f46e5',
        grid: 'rgba(255, 255, 255, 0.08)',
        modeName: 'Dark Mode'
      };
    }
    
    // Light Mode (Default)
    return {
      bg: '#ffffff',
      primary: '#0f172a', // slate-900
      secondary: '#4f46e5', // indigo-600
      text: '#1e293b', // slate-800
      highlight: '#e11d48', // rose-600
      accent: '#6366f1',
      grid: 'rgba(0, 0, 0, 0.06)',
      modeName: 'Light Mode'
    };
  }, [theme, isHighContrast]);

  // Sync external props if provided
  useEffect(() => {
    if (propHighContrast !== undefined) {
      setIsHighContrast(prev => prev !== propHighContrast ? propHighContrast : prev);
    }
  }, [propHighContrast]);

  useEffect(() => {
    if (propVectorDragMode !== undefined) {
      setIsVectorDragMode(prev => prev !== propVectorDragMode ? propVectorDragMode : prev);
    }
  }, [propVectorDragMode]);

  useEffect(() => {
    if (propVectorTelemetry !== undefined) {
      setShowVectorTelemetry(prev => prev !== propVectorTelemetry ? propVectorTelemetry : prev);
    }
  }, [propVectorTelemetry]);

  useEffect(() => {
    if (propMagnifierActive !== undefined) {
      setIsMagnifierActive(prev => prev !== propMagnifierActive ? propMagnifierActive : prev);
    }
  }, [propMagnifierActive]);

  useEffect(() => {
    if (propChalkMode !== undefined) {
      setIsChalkMode(prev => prev !== propChalkMode ? propChalkMode : prev);
    }
  }, [propChalkMode]);

  useEffect(() => {
    if (propShowGrid !== undefined) {
      setShowGrid(prev => prev !== propShowGrid ? propShowGrid : prev);
    }
  }, [propShowGrid]);

  // Nano Banana 2 Visual Asset Generation Engine State (gemini-3.1-flash-image-preview)
  const [nanoBananaImageUrl, setNanoBananaImageUrl] = useState<string | null>(null);
  const [isGeneratingNanoBanana, setIsGeneratingNanoBanana] = useState<boolean>(false);
  const [activeVisualMode, setActiveVisualMode] = useState<'nanobanana' | 'vector'>('nanobanana');

  const handleGenerateNanoBanana = async () => {
    try {
      setIsGeneratingNanoBanana(true);
      showNotification?.("Rendering 2K Visual Diagram with Nano Banana 2 (gemini-3.1-flash-image-preview)...", "info");
      const cleanPrompt = title ? `Clean academic scientific textbook diagram explaining ${title}, high contrast vector line art, labeled parts, 2K resolution` : 'Scientific educational 2K textbook diagram, clean vector labels';
      const res = await fetch("/api/gemini", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "generateImage",
          prompt: cleanPrompt,
          model: "gemini-3.1-flash-image-preview",
          imageSize: "2K",
          aspectRatio: "16:9"
        })
      });
      const data = await res.json();
      if (data?.imageUrl) {
        setNanoBananaImageUrl(data.imageUrl);
        setActiveVisualMode('nanobanana');
        showNotification?.("Nano Banana 2 (2K) visual diagram rendered successfully!", "success");
      }
    } catch (e) {
      console.warn("Nano Banana 2 generation error:", e);
      showNotification?.("Could not connect to Nano Banana 2 engine. Reverting to interactive vector view.", "warning");
    } finally {
      setIsGeneratingNanoBanana(false);
    }
  };

  // SVG Container Background Color & Luminance Observer State
  const [containerBgInfo, setContainerBgInfo] = useState<{
    rgb: { r: number; g: number; b: number; a: number };
    luminance: number;
    bgColorStr: string;
  }>({
    rgb: { r: 15, g: 23, b: 42, a: 1 },
    luminance: 0.02,
    bgColorStr: 'rgb(15, 23, 42)',
  });

  // Automated High-Contrast Class Observer Sync Effect
  useEffect(() => {
    if (typeof document === 'undefined') return;

    const updateContrastState = () => {
      const isHC = document.documentElement.classList.contains('high-contrast') || document.documentElement.classList.contains('high-contrast-neon');
      setIsHighContrast(prev => prev !== isHC ? isHC : prev);
    };

    updateContrastState();

    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.attributeName === 'class') {
          updateContrastState();
        }
      }
    });

    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  const onRenderCompleteRef = useRef(onRenderComplete);
  useEffect(() => {
    onRenderCompleteRef.current = onRenderComplete;
  }, [onRenderComplete]);

  // Notify parent component that visual rendering of the SVG diagram is complete (triggered strictly on svgCode change)
  useEffect(() => {
    if (onRenderCompleteRef.current) {
      const renderTimer = setTimeout(() => {
        onRenderCompleteRef.current?.();
      }, 150);
      return () => clearTimeout(renderTimer);
    }
  }, [svgCode]);

  // Automated Sync Function: Monitors the background color of the SVG container dynamically & updates contrast during theme transitions
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const updateContainerBg = () => {
      if (!containerRef.current) return;

      let el: HTMLElement | null = containerRef.current;
      let computedBg = 'transparent';

      while (el) {
        const style = window.getComputedStyle(el);
        const bg = style.backgroundColor;
        if (bg && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)') {
          computedBg = bg;
          break;
        }
        el = el.parentElement;
      }

      if (computedBg === 'transparent') {
        computedBg = isHighContrast ? 'rgb(0, 0, 0)' : (theme === 'dark' ? 'rgb(15, 23, 42)' : 'rgb(248, 250, 252)');
      }

      const rgb = parseCssColorToRgb(computedBg);
      const luminance = getRelativeLuminance(rgb.r, rgb.g, rgb.b);

      setContainerBgInfo(prev => {
        if (prev.bgColorStr === computedBg && prev.luminance === luminance) {
          return prev;
        }
        return {
          rgb,
          luminance,
          bgColorStr: computedBg,
        };
      });
    };

    updateContainerBg();

    // Trigger soft diagram slate placement thud sound on chalkboard mount
    const thudTimer = setTimeout(() => {
      playDiagramThud(0.28);
    }, 120);

    const observer = new MutationObserver(() => {
      updateContainerBg();
    });

    if (containerRef.current) {
      observer.observe(containerRef.current, { attributes: true, attributeFilter: ['style', 'class'] });
    }
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'style'] });

    let animFrameId: number;
    let transitionTimeout: NodeJS.Timeout;

    const handleTransitionRun = () => {
      const loop = () => {
        updateContainerBg();
        animFrameId = requestAnimationFrame(loop);
      };
      loop();
      clearTimeout(transitionTimeout);
      transitionTimeout = setTimeout(() => {
        cancelAnimationFrame(animFrameId);
        updateContainerBg();
      }, 500);
    };

    window.addEventListener('transitionrun', handleTransitionRun);
    window.addEventListener('resize', updateContainerBg);

    return () => {
      observer.disconnect();
      window.removeEventListener('transitionrun', handleTransitionRun);
      window.removeEventListener('resize', updateContainerBg);
      cancelAnimationFrame(animFrameId);
      clearTimeout(transitionTimeout);
    };
  }, [isHighContrast, theme]);

  // Automated Sync Engine: Dynamically updates legend font weight, text contrast & colors based on container luminance & high-contrast mode
  const legendSyncTheme = React.useMemo(() => {
    const isDarkBg = containerBgInfo.luminance < 0.45;

    // Calculate dynamic contrast ratio against legend fill
    let textLuminance = 1.0;
    if (!isDarkBg && !isHighContrast) {
      textLuminance = 0.05;
    }
    const computedRatio = getContrastRatio(textLuminance, containerBgInfo.luminance);
    const contrastRatioStr = `${computedRatio.toFixed(1)}:1`;

    if (isHighContrast) {
      return {
        isHighContrast: true,
        isLightBg: false,
        contrastLevelLabel: `${contrastRatioStr} ULTRA HIGH CONTRAST (SYNCED)`,
        bgFill: '#000000',
        bgOpacity: '0.96',
        borderColor: '#00f5ff',
        glowShadow: '0 0 16px rgba(0, 245, 255, 0.5)',
        headerBg: '#00f5ff',
        headerTextColor: '#000000',
        textColorA: '#00f5ff',
        textColorB: '#ffff00',
        textColorR: '#ff007f',
        textColorAngle: '#39ff14',
        textComponent: '#ffffff',
        dividerColor: '#00f5ff',
        fontWeightHeader: '900',
        fontWeightBody: '800',
        fontWeightValue: '900',
        letterSpacing: '0.6',
        telemetryPanelBg: 'bg-black/95 border-b border-[#00f5ff]/60 text-white shadow-[0_0_20px_rgba(0,245,255,0.25)]',
        badgeAClass: 'bg-black border-[#00f5ff] text-white shadow-[0_0_10px_rgba(0,245,255,0.4)]',
        badgeBClass: 'bg-black border-[#ffff00] text-white shadow-[0_0_10px_rgba(255,255,0,0.4)]',
        badgeRClass: 'bg-black border-[#ff007f] text-white shadow-[0_0_12px_rgba(255,0,127,0.5)]',
        badgeAngleClass: 'bg-black border-[#39ff14] text-white shadow-[0_0_10px_rgba(57,255,20,0.4)]',
        badgeContrastClass: 'bg-black border border-[#00f5ff] text-[#00f5ff] font-black shadow-[0_0_8px_rgba(0,245,255,0.4)]',
      };
    }

    if (!isDarkBg) {
      // Light background detected in container
      return {
        isHighContrast: false,
        isLightBg: true,
        contrastLevelLabel: `${contrastRatioStr} AAA LEGIBILITY (SYNCED)`,
        bgFill: '#ffffff',
        bgOpacity: '0.96',
        borderColor: '#0284c7',
        glowShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
        headerBg: '#e0f2fe',
        headerTextColor: '#0369a1',
        textColorA: '#0284c7',
        textColorB: '#b45309',
        textColorR: '#be123c',
        textColorAngle: '#15803d',
        textComponent: '#334155',
        dividerColor: '#cbd5e1',
        fontWeightHeader: '800',
        fontWeightBody: '700',
        fontWeightValue: '800',
        letterSpacing: '0.3',
        telemetryPanelBg: 'bg-white/95 border-b border-sky-200 text-slate-800 shadow-sm',
        badgeAClass: 'bg-sky-50 border-sky-300 text-sky-900',
        badgeBClass: 'bg-amber-50 border-amber-300 text-amber-900',
        badgeRClass: 'bg-rose-50 border-rose-300 text-rose-900',
        badgeAngleClass: 'bg-emerald-50 border-emerald-300 text-emerald-900',
        badgeContrastClass: 'bg-sky-100 border border-sky-400 text-sky-900 font-bold',
      };
    }

    // Standard dark theme background
    return {
      isHighContrast: false,
      isLightBg: false,
      contrastLevelLabel: `${contrastRatioStr} AAA STANDARD (SYNCED)`,
      bgFill: '#0f172a',
      bgOpacity: '0.88',
      borderColor: '#3b82f6',
      glowShadow: '0 4px 12px rgba(0, 0, 0, 0.5)',
      headerBg: '#1e293b',
      headerTextColor: '#38bdf8',
      textColorA: '#38bdf8',
      textColorB: '#fbbf24',
      textColorR: '#f43f5e',
      textColorAngle: '#4ade80',
      textComponent: '#e2e8f0',
      dividerColor: '#334155',
      fontWeightHeader: '900',
      fontWeightBody: '700',
      fontWeightValue: '800',
      letterSpacing: '0.4',
      telemetryPanelBg: 'bg-slate-950/90 border-b border-slate-800/80 text-slate-100',
      badgeAClass: 'bg-sky-950/40 border-sky-500/30 text-slate-300',
      badgeBClass: 'bg-amber-950/40 border-amber-500/30 text-slate-300',
      badgeRClass: 'bg-rose-950/40 border-rose-500/40 text-slate-300',
      badgeAngleClass: 'bg-emerald-950/40 border-emerald-500/30 text-slate-300',
      badgeContrastClass: 'bg-slate-900/80 border border-slate-700 text-slate-400 font-bold',
    };
  }, [isHighContrast, containerBgInfo]);

  // Magnifying Glass Loupe Tool States
  const [isMagnifierActive, setIsMagnifierActive] = useState<boolean>(false);
  const [magnifierPos, setMagnifierPos] = useState<{ clientX: number; clientY: number; svgX: number; svgY: number } | null>(null);
  const [isHoveringCluttered, setIsHoveringCluttered] = useState<boolean>(false);

  // Vector Telemetry Stats Visibility State (Default: hidden per user request)
  const [showVectorTelemetry, setShowVectorTelemetry] = useState<boolean>(false);

  // Interactive Professor Laser Pointer / Cursor State (Default: hidden per user request)
  const [isProfPointerActive, setIsProfPointerActive] = useState<boolean>(false);
  const [profCursor, setProfCursor] = useState<{ x: number; y: number; activeNode: string }>({
    x: 420,
    y: 260,
    activeNode: 'Vector A⃗ Tip'
  });

  // Dynamic Neon Color Definitions for Standard vs High-Contrast Modes
  const colorA = isHighContrast ? '#00f5ff' : '#38bdf8'; // Electric Neon Cyan
  const colorB = isHighContrast ? '#ffff00' : '#fbbf24'; // Laser Neon Yellow / Lime
  const colorR = isHighContrast ? '#ff007f' : '#f43f5e'; // Ultra Vivid Laser Magenta / Hot Pink
  const colorOrigin = isHighContrast ? '#d946ef' : '#6366f1'; // Bright Neon Violet
  const axisColor = isHighContrast ? '#ffffff' : '#94a3b8'; // High-Luminance Pure White
  const axisGridColor = isHighContrast ? '#38bdf8' : '#64748b';

  // Dynamic Vectors State (Initialized for interactive physics & trigonometry)
  const [vectors, setVectors] = useState<DraggableVector[]>([
    {
      id: 'vecA',
      name: 'Vector A (A⃗)',
      label: 'A⃗',
      originX: 250,
      originY: 260,
      tipX: 420,
      tipY: 260,
      color: '#38bdf8', // Sky 400
      secondaryColor: '#0284c7'
    },
    {
      id: 'vecB',
      name: 'Vector B (B⃗)',
      label: 'B⃗',
      originX: 250,
      originY: 260,
      tipX: 370,
      tipY: 130,
      color: '#fbbf24', // Amber 400
      secondaryColor: '#d97706'
    }
  ]);

  // Chalk Drawing Overlay States
  const [isChalkMode, setIsChalkMode] = useState(false);
  const [activeChalkTool, setActiveChalkTool] = useState<ChalkTool>('pen');
  const [selectedColor, setSelectedColor] = useState<string>('#fde047');
  const [chalkWidth, setChalkWidth] = useState<number>(3);
  const [chalkUndoStack, setChalkUndoStack] = useState<ImageData[]>([]);
  const [chalkRedoStack, setChalkRedoStack] = useState<ImageData[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [soundEnabled, setSoundEnabledState] = useState<boolean>(() => isChalkSoundEnabled());
  const startPosRef = useRef<{ x: number; y: number } | null>(null);
  const previewSnapshotRef = useRef<ImageData | null>(null);

  // Clean raw SVG string if wrapped in markdown backticks or tags, and strip any moving ball animations
  const cleanSvg = React.useMemo(() => {
    let result = sanitizeSvgDiagramCode(svgCode);
    if (!result) {
      let clean = svgCode.trim();
      if (clean.startsWith('```')) {
        clean = clean.replace(/^```[a-zA-Z]*\n?/, '').replace(/\n?```$/, '');
      }
      const svgMatch = clean.match(/<svg[\s\S]*<\/svg>/i);
      result = svgMatch ? svgMatch[0] : clean;
    }

    // Strip moving balls and animations from 2D teaching schematics
    result = result.replace(/<animate[\s\S]*?\/>/gi, '');
    result = result.replace(/<animate[\s\S]*?<\/animate>/gi, '');
    result = result.replace(/<animateMotion[\s\S]*?\/>/gi, '');
    result = result.replace(/<animateMotion[\s\S]*?<\/animateMotion>/gi, '');
    result = result.replace(/<animateTransform[\s\S]*?\/>/gi, '');
    result = result.replace(/<animateTransform[\s\S]*?<\/animateTransform>/gi, '');
    result = result.replace(/<animateColor[\s\S]*?\/>/gi, '');
    result = result.replace(/<animateColor[\s\S]*?<\/animateColor>/gi, '');
    
    // Remove any inline CSS keyframes or animation properties that cause moving balls or particles
    result = result.replace(/@keyframes[\s\S]*?\}\s*\}/gi, '');
    result = result.replace(/animation:\s*[^;"]+;?/gi, '');

    // Master Scientific Defs Library (Layered Transparency & Advanced Fill Patterns)
    const masterScientificDefs = `
      <defs id="sci-master-defs-${instanceId}">
        <!-- 1. Diagonal Scientific Hatching Patterns -->
        <pattern id="sci-hatch-cyan" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="8" stroke="#00f5ff" stroke-width="1.5" stroke-opacity="0.85" />
        </pattern>
        <pattern id="sci-hatch-amber" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="8" stroke="#f59e0b" stroke-width="1.5" stroke-opacity="0.85" />
        </pattern>
        <pattern id="sci-hatch-emerald" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="8" stroke="#10b981" stroke-width="1.5" stroke-opacity="0.85" />
        </pattern>
        <pattern id="sci-hatch-rose" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="8" stroke="#f43f5e" stroke-width="1.5" stroke-opacity="0.85" />
        </pattern>
        <pattern id="sci-hatch-purple" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="8" stroke="#a855f7" stroke-width="1.5" stroke-opacity="0.85" />
        </pattern>
        <pattern id="sci-hatch-white" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="8" stroke="#ffffff" stroke-width="1.2" stroke-opacity="0.75" />
        </pattern>

        <!-- 2. Scientific Cross-Hatching Matrix Patterns -->
        <pattern id="sci-crosshatch-cyan" width="10" height="10" patternUnits="userSpaceOnUse">
          <path d="M 0 0 L 10 10 M 10 0 L 0 10" stroke="#00f5ff" stroke-width="1" stroke-opacity="0.7" />
        </pattern>
        <pattern id="sci-crosshatch-amber" width="10" height="10" patternUnits="userSpaceOnUse">
          <path d="M 0 0 L 10 10 M 10 0 L 0 10" stroke="#f59e0b" stroke-width="1" stroke-opacity="0.7" />
        </pattern>
        <pattern id="sci-crosshatch-dense" width="6" height="6" patternUnits="userSpaceOnUse">
          <path d="M 0 3 L 6 3 M 3 0 L 3 6" stroke="#38bdf8" stroke-width="0.8" stroke-opacity="0.6" />
        </pattern>

        <!-- 3. Stippling / Cellular Cytoplasm / Dot Density Patterns -->
        <pattern id="sci-dots-stipple" width="10" height="10" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="1" fill="#38bdf8" fill-opacity="0.85" />
          <circle cx="7" cy="7" r="1.2" fill="#00f5ff" fill-opacity="0.9" />
          <circle cx="7" cy="2" r="0.6" fill="#818cf8" fill-opacity="0.6" />
          <circle cx="2" cy="7" r="0.6" fill="#818cf8" fill-opacity="0.6" />
        </pattern>
        <pattern id="sci-dots-amber" width="8" height="8" patternUnits="userSpaceOnUse">
          <circle cx="4" cy="4" r="1.2" fill="#fbbf24" fill-opacity="0.8" />
        </pattern>
        <pattern id="sci-dots-rose" width="8" height="8" patternUnits="userSpaceOnUse">
          <circle cx="4" cy="4" r="1.2" fill="#fb7185" fill-opacity="0.8" />
        </pattern>

        <!-- 4. Cellular Mesh / Hexagonal Lattice / Carbon / Membrane -->
        <pattern id="sci-hex-mesh" width="14" height="24" patternUnits="userSpaceOnUse">
          <path d="M 7 0 L 14 4 L 14 12 L 7 16 L 0 12 L 0 4 Z M 7 16 L 14 20 L 14 28 L 7 32 L 0 28 L 0 20 Z" fill="none" stroke="#10b981" stroke-width="0.9" stroke-opacity="0.65" />
        </pattern>
        <pattern id="sci-cellular-lipid" width="12" height="12" patternUnits="userSpaceOnUse">
          <circle cx="6" cy="3" r="2" fill="#f43f5e" fill-opacity="0.75" />
          <line x1="6" y1="5" x2="6" y2="10" stroke="#fbbf24" stroke-width="1.2" stroke-opacity="0.8" />
        </pattern>
        <pattern id="sci-wave-refraction" width="16" height="16" patternUnits="userSpaceOnUse">
          <path d="M 0 8 Q 4 4, 8 8 T 16 8" fill="none" stroke="#60a5fa" stroke-width="1.2" stroke-opacity="0.75" />
        </pattern>

        <!-- 5. Layered Translucent Gradients & Refractive Shaders -->
        <linearGradient id="sci-gradient-lens" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.45" />
          <stop offset="50%" stop-color="#818cf8" stop-opacity="0.2" />
          <stop offset="100%" stop-color="#00f5ff" stop-opacity="0.5" />
        </linearGradient>
        <radialGradient id="sci-gradient-plasma" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#ffff00" stop-opacity="0.9" />
          <stop offset="45%" stop-color="#f59e0b" stop-opacity="0.45" />
          <stop offset="85%" stop-color="#ef4444" stop-opacity="0.2" />
          <stop offset="100%" stop-color="#ef4444" stop-opacity="0" />
        </radialGradient>
        <radialGradient id="sci-gradient-orbital" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#00f5ff" stop-opacity="0.7" />
          <stop offset="40%" stop-color="#38bdf8" stop-opacity="0.3" />
          <stop offset="80%" stop-color="#818cf8" stop-opacity="0.1" />
          <stop offset="100%" stop-color="#6366f1" stop-opacity="0" />
        </radialGradient>
        <linearGradient id="sci-gradient-membrane" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#10b981" stop-opacity="0.5" />
          <stop offset="50%" stop-color="#065f46" stop-opacity="0.2" />
          <stop offset="100%" stop-color="#10b981" stop-opacity="0.5" />
        </linearGradient>
        
        <!-- 6. Component Layer Depth Separation Filter -->
        <filter id="sci-filter-depth" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="2" stdDeviation="2" flood-color="#000000" flood-opacity="0.45" />
        </filter>
      </defs>
    `;

    // Inject master scientific defs right after opening <svg> tag
    if (result.includes('<svg') && !result.includes(`sci-master-defs-${instanceId}`)) {
      result = result.replace(/<svg([^>]*)>/i, `<svg$1>${masterScientificDefs}`);
    }

    return result;
  }, [svgCode, instanceId]);

  // Derived Vector Physics / Math Computations
  const fallbackVectorA: DraggableVector = {
    id: 'vecA',
    name: 'Vector A (A⃗)',
    label: 'A⃗',
    originX: 250,
    originY: 260,
    tipX: 420,
    tipY: 260,
    color: '#38bdf8',
    secondaryColor: '#0284c7'
  };
  const fallbackVectorB: DraggableVector = {
    id: 'vecB',
    name: 'Vector B (B⃗)',
    label: 'B⃗',
    originX: 250,
    originY: 260,
    tipX: 370,
    tipY: 130,
    color: '#fbbf24',
    secondaryColor: '#d97706'
  };

  const vecA = vectors.find(v => v.id === 'vecA') || vectors[0] || fallbackVectorA;
  const vecB = vectors.find(v => v.id === 'vecB') || vectors[1] || fallbackVectorB;

  const dxA = vecA.tipX - vecA.originX;
  const dyA = -(vecA.tipY - vecA.originY); // standard cartesian inversion
  const magA = Math.round(Math.sqrt(dxA * dxA + dyA * dyA));
  const angleA = Math.round((Math.atan2(dyA, dxA) * 180 / Math.PI + 360) % 360);

  const dxB = vecB.tipX - vecB.originX;
  const dyB = -(vecB.tipY - vecB.originY);
  const magB = Math.round(Math.sqrt(dxB * dxB + dyB * dyB));
  const angleB = Math.round((Math.atan2(dyB, dxB) * 180 / Math.PI + 360) % 360);

  // Resultant R = A + B (from origin of A)
  const rx = dxA + dxB;
  const ry = dyA + dyB;
  const magR = Math.round(Math.sqrt(rx * rx + ry * ry));
  const angleR = Math.round((Math.atan2(ry, rx) * 180 / Math.PI + 360) % 360);

  // Inter-vector angle & dot/cross product variables for dynamic Legend labeling
  const angleBetween = Math.abs(angleB - angleA);
  const acuteAngleBetween = Math.round(Math.min(angleBetween, 360 - angleBetween));
  const dotProduct = Math.round(dxA * dxB + dyA * dyB);
  const crossProductZ = Math.round(dxA * dyB - dyA * dxB);

  const resultantTipX = vecA.originX + rx;
  const resultantTipY = vecA.originY - ry;

  // Parallelogram completion tip (for tip-to-tail / parallelogram projection)
  const tipTailX = vecA.tipX + dxB;
  const tipTailY = vecA.tipY - dyB;

  // Cluttered Region & Overlapping Vectors Distance Calculations
  const tipDistance = Math.round(Math.sqrt(Math.pow(vecA.tipX - vecB.tipX, 2) + Math.pow(vecA.tipY - vecB.tipY, 2)));
  const isClutteredRegion = tipDistance < 60 || acuteAngleBetween < 15;

  // Automated Professor Laser Pointer Lecture Tour
  useEffect(() => {
    if (!isProfPointerActive) return;

    const targets = [
      { x: vecA.tipX, y: vecA.tipY, activeNode: `Vector A⃗ Tip (|A|=${magA})` },
      { x: vecB.tipX, y: vecB.tipY, activeNode: `Vector B⃗ Tip (|B|=${magB})` },
      { x: resultantTipX, y: resultantTipY, activeNode: `Resultant R⃗ Tip (|R|=${magR}, θ=${angleR}°)` },
      { x: vecA.originX, y: vecA.originY, activeNode: 'Origin O (0,0)' },
      { x: vecA.originX + 45, y: vecA.originY - 20, activeNode: `Angle Between Vectors ∠(A,B) = ${acuteAngleBetween}°` },
      { x: 115, y: 95, activeNode: 'Schematic Legend & Formula Matrix' }
    ];

    let targetIdx = 0;
    const tourInterval = setInterval(() => {
      targetIdx = (targetIdx + 1) % targets.length;
      setProfCursor(targets[targetIdx]);
    }, 3800);

    return () => clearInterval(tourInterval);
  }, [isProfPointerActive, vecA.tipX, vecA.tipY, vecB.tipX, vecB.tipY, vecA.originX, vecA.originY, resultantTipX, resultantTipY, magA, magB, magR, angleR, acuteAngleBetween]);

  // Container Pointer Tracking for Magnifying Glass & Overlap Detection
  const handleContainerPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    // Convert client pixels to SVG ViewBox space (600 x 400)
    const svgX = Math.max(10, Math.min(590, (clientX / rect.width) * 600));
    const svgY = Math.max(10, Math.min(390, (clientY / rect.height) * 400));

    setMagnifierPos({ clientX, clientY, svgX, svgY });

    // Check if pointer is hovering directly over a cluttered area (near tip A, tip B, or origin)
    const distToTipA = Math.sqrt((svgX - vecA.tipX) ** 2 + (svgY - vecA.tipY) ** 2);
    const distToTipB = Math.sqrt((svgX - vecB.tipX) ** 2 + (svgY - vecB.tipY) ** 2);
    const distToOrigin = Math.sqrt((svgX - vecA.originX) ** 2 + (svgY - vecA.originY) ** 2);

    const nearClutteredPoint = isClutteredRegion && (distToTipA < 75 || distToTipB < 75 || distToOrigin < 75);
    setIsHoveringCluttered(nearClutteredPoint);

    if (isProfPointerActive && (distToTipA < 40 || distToTipB < 40 || distToOrigin < 40)) {
      setProfCursor({
        x: Math.round(svgX),
        y: Math.round(svgY),
        activeNode: distToTipA < 40 ? `Vector A⃗ Tip (|A|=${magA})` : distToTipB < 40 ? `Vector B⃗ Tip (|B|=${magB})` : 'Origin O (0,0)'
      });
    }
  };

  const handleContainerPointerLeave = () => {
    setMagnifierPos(null);
    setIsHoveringCluttered(false);
  };

  // Adjust canvas resolution to container size
  const syncCanvasSize = useCallback((targetCanvas: HTMLCanvasElement | null) => {
    if (!targetCanvas || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    
    if (targetCanvas.width !== Math.floor(rect.width * dpr) || targetCanvas.height !== Math.floor(rect.height * dpr)) {
      const ctx = targetCanvas.getContext('2d');
      let tempImage: ImageData | null = null;
      if (ctx && targetCanvas.width > 0 && targetCanvas.height > 0) {
        try {
          tempImage = ctx.getImageData(0, 0, targetCanvas.width, targetCanvas.height);
        } catch {}
      }

      targetCanvas.width = Math.floor(rect.width * dpr);
      targetCanvas.height = Math.floor(rect.height * dpr);
      targetCanvas.style.width = `${rect.width}px`;
      targetCanvas.style.height = `${rect.height}px`;

      if (ctx) {
        ctx.scale(dpr, dpr);
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
      }
    }
  }, []);

  useEffect(() => {
    syncCanvasSize(canvasRef.current);
    const handleResize = () => syncCanvasSize(canvasRef.current);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [syncCanvasSize]);

  // Sync canvas size when chalk mode becomes active
  useEffect(() => {
    if (isChalkMode && canvasRef.current) {
      syncCanvasSize(canvasRef.current);
    }
  }, [isChalkMode, syncCanvasSize]);

  // Dedicated Handlers for Toolbar Toggle Buttons to guarantee reliable state changes & notifications
  const toggleHighContrast = useCallback(() => {
    setIsHighContrast(prev => {
      const next = !prev;
      if (typeof document !== 'undefined') {
        if (next) {
          document.documentElement.classList.add('high-contrast', 'high-contrast-neon');
        } else {
          document.documentElement.classList.remove('high-contrast', 'high-contrast-neon');
        }
      }
      if (onToggleHighContrast) onToggleHighContrast(next);
      if (soundEnabled) playChalkSound('tap', 0.3);
      showNotification?.(
        next ? 'Neon High-Contrast Mode Activated for Classroom Projection' : 'Standard Color Theme Restored', 
        'info'
      );
      return next;
    });
  }, [soundEnabled, showNotification, onToggleHighContrast]);

  const toggleVectorDragMode = useCallback(() => {
    setIsVectorDragMode(prev => {
      const next = !prev;
      if (onToggleVectorDragMode) onToggleVectorDragMode(next);
      if (soundEnabled) playChalkSound('tap', 0.3);
      showNotification?.(next ? 'Interactive Draggable Vector Handles Enabled' : 'Interactive Vector Handles Hidden', 'info');
      return next;
    });
  }, [soundEnabled, showNotification, onToggleVectorDragMode]);

  const toggleVectorTelemetry = useCallback(() => {
    setShowVectorTelemetry(prev => {
      const next = !prev;
      if (onToggleVectorTelemetry) onToggleVectorTelemetry(next);
      if (soundEnabled) playChalkSound('tap', 0.3);
      showNotification?.(next ? 'Vector Telemetry Stats Panel Shown' : 'Vector Telemetry Stats Panel Hidden', 'info');
      return next;
    });
  }, [soundEnabled, showNotification, onToggleVectorTelemetry]);

  const toggleMagnifier = useCallback(() => {
    setIsMagnifierActive(prev => {
      const next = !prev;
      if (next) {
        setMagnifierPos(current => current || { clientX: 250, clientY: 180, svgX: 300, svgY: 200 });
      } else {
        setMagnifierPos(null);
      }
      if (onToggleMagnifier) onToggleMagnifier(next);
      if (soundEnabled) playChalkSound('tap', 0.3);
      showNotification?.(
        next ? '2.8x Magnifying Glass Active! Hover over vector regions for zoomed view.' : 'Magnifying Glass Off', 
        'info'
      );
      return next;
    });
  }, [soundEnabled, showNotification, onToggleMagnifier]);

  const toggleChalkMode = useCallback(() => {
    setIsChalkMode(prev => {
      const next = !prev;
      if (onToggleChalkMode) onToggleChalkMode(next);
      if (next) {
        showNotification?.('Chalk Draw Overlay Active! Click & drag to annotate.', 'success');
        if (canvasRef.current) {
          syncCanvasSize(canvasRef.current);
        }
      } else {
        showNotification?.('Chalk Draw Overlay Closed', 'info');
      }
      if (soundEnabled) playChalkSound('tap', 0.3);
      return next;
    });
  }, [soundEnabled, showNotification, syncCanvasSize, onToggleChalkMode]);

  const toggleGrid = useCallback(() => {
    setShowGrid(prev => {
      const next = !prev;
      if (onToggleGrid) onToggleGrid(next);
      if (soundEnabled) playChalkSound('tap', 0.3);
      showNotification?.(next ? 'Coordinate Grid Shown' : 'Coordinate Grid Hidden', 'info');
      return next;
    });
  }, [soundEnabled, showNotification, onToggleGrid]);

  const toggleLabels = useCallback(() => {
    setShowLabels(prev => {
      const next = !prev;
      if (soundEnabled) playChalkSound('tap', 0.3);
      showNotification?.(next ? 'Vector Labels Shown' : 'Vector Labels Hidden (Quiz Mode)', 'info');
      return next;
    });
  }, [soundEnabled, showNotification]);

  const toggleResultant = useCallback(() => {
    setShowResultant(prev => {
      const next = !prev;
      if (soundEnabled) playChalkSound('tap', 0.3);
      showNotification?.(next ? 'Resultant Vector Highlighted' : 'Resultant Vector Dimmed', 'info');
      return next;
    });
  }, [soundEnabled, showNotification]);

  // Vector Drag Handle Logic
  const handleVectorPointerDown = (
    e: React.PointerEvent<SVGCircleElement | SVGGElement>,
    vectorId: string,
    type: 'tip' | 'origin'
  ) => {
    e.stopPropagation();
    e.preventDefault();
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
    setActiveDragTarget({ id: vectorId, type });
    if (soundEnabled) playChalkSound('tap', 0.3);
  };

  const handleVectorPointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!activeDragTarget || !vectorSvgOverlayRef.current) return;
    const svg = vectorSvgOverlayRef.current;
    const rect = svg.getBoundingClientRect();

    // Calculate mouse position inside SVG viewBox (0 0 600 400)
    const svgX = ((e.clientX - rect.left) / rect.width) * 600;
    const svgY = ((e.clientY - rect.top) / rect.height) * 400;

    // Constrain within bounds
    const clampedX = Math.max(30, Math.min(570, Math.round(svgX)));
    const clampedY = Math.max(30, Math.min(370, Math.round(svgY)));

    setVectors(prev => prev.map(v => {
      if (activeDragTarget.type === 'origin') {
        // Move common origin for all vectors so they stay rooted together
        const shiftX = clampedX - v.originX;
        const shiftY = clampedY - v.originY;
        return {
          ...v,
          originX: clampedX,
          originY: clampedY,
          tipX: Math.max(30, Math.min(570, v.tipX + shiftX)),
          tipY: Math.max(30, Math.min(370, v.tipY + shiftY))
        };
      } else if (v.id === activeDragTarget.id) {
        return { ...v, tipX: clampedX, tipY: clampedY };
      }
      return v;
    }));

    if (soundEnabled && Math.random() < 0.15) {
      playChalkSound('scratch', 0.1);
    }
  };

  const handleVectorPointerUp = (e: React.PointerEvent<SVGSVGElement>) => {
    if (activeDragTarget) {
      try {
        (e.target as Element).releasePointerCapture?.(e.pointerId);
      } catch {}
      setActiveDragTarget(null);
      if (soundEnabled) playChalkSound('tap', 0.2);
    }
  };

  // Reset vectors to standard textbook configuration
  const handleResetVectors = () => {
    setVectors([
      {
        id: 'vecA',
        name: 'Vector A (A⃗)',
        label: 'A⃗',
        originX: 250,
        originY: 260,
        tipX: 420,
        tipY: 260,
        color: '#38bdf8',
        secondaryColor: '#0284c7'
      },
      {
        id: 'vecB',
        name: 'Vector B (B⃗)',
        label: 'B⃗',
        originX: 250,
        originY: 260,
        tipX: 370,
        tipY: 130,
        color: '#fbbf24',
        secondaryColor: '#d97706'
      }
    ]);
    if (soundEnabled) playChalkSound('dust', 0.3);
    showNotification?.('Vectors reset to default angles & magnitudes', 'info');
  };

  // Preset Angle Snapping
  const snapVector = (vectorId: string, angleDeg: number, magnitude: number = 160) => {
    const rad = (angleDeg * Math.PI) / 180;
    setVectors(prev => prev.map(v => {
      if (v.id === vectorId) {
        return {
          ...v,
          tipX: Math.round(v.originX + magnitude * Math.cos(rad)),
          tipY: Math.round(v.originY - magnitude * Math.sin(rad))
        };
      }
      return v;
    }));
    if (soundEnabled) playChalkSound('tap', 0.25);
    showNotification?.(`Snapped ${vectorId === 'vecA' ? 'A⃗' : 'B⃗'} to ${angleDeg}°`, 'info');
  };

  // Drawing Helper: Get position relative to canvas
  const getCoordinates = (e: React.PointerEvent<HTMLCanvasElement>, canvas: HTMLCanvasElement) => {
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  // Helper to draw Arrow on Canvas
  const drawArrow = (
    ctx: CanvasRenderingContext2D,
    fromX: number,
    fromY: number,
    toX: number,
    toY: number,
    color: string,
    width: number
  ) => {
    const headLength = Math.max(12, width * 3.5);
    const angle = Math.atan2(toY - fromY, toX - fromX);

    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.shadowColor = color;
    ctx.shadowBlur = 4;

    ctx.beginPath();
    ctx.moveTo(fromX, fromY);
    ctx.lineTo(toX, toY);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(toX, toY);
    ctx.lineTo(
      toX - headLength * Math.cos(angle - Math.PI / 6),
      toY - headLength * Math.sin(angle - Math.PI / 6)
    );
    ctx.lineTo(
      toX - headLength * Math.cos(angle + Math.PI / 6),
      toY - headLength * Math.sin(angle + Math.PI / 6)
    );
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  };

  // Chalk Drawing Event Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isChalkMode) return;
    const canvas = e.currentTarget;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.setPointerCapture(e.pointerId);
    setIsDrawing(true);
    const pos = getCoordinates(e, canvas);
    startPosRef.current = pos;

    try {
      const snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setChalkUndoStack(prev => [...prev.slice(-25), snapshot]);
      setChalkRedoStack([]); // Clear redo on new stroke
      previewSnapshotRef.current = snapshot;
    } catch {}

    if (soundEnabled) {
      playChalkSound('tap', 0.25);
    }

    if (activeChalkTool === 'pen' || activeChalkTool === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
      if (activeChalkTool === 'eraser') {
        ctx.globalCompositeOperation = 'destination-out';
        ctx.lineWidth = chalkWidth * 6;
        ctx.shadowBlur = 0;
      } else {
        ctx.globalCompositeOperation = 'source-over';
        ctx.strokeStyle = selectedColor;
        ctx.lineWidth = chalkWidth;
        ctx.shadowColor = selectedColor;
        ctx.shadowBlur = 4;
      }
      ctx.lineTo(pos.x + 0.1, pos.y + 0.1);
      ctx.stroke();
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !isChalkMode) return;
    const canvas = e.currentTarget;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pos = getCoordinates(e, canvas);

    if (activeChalkTool === 'pen' || activeChalkTool === 'eraser') {
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
      if (soundEnabled && Math.random() < 0.2) {
        playChalkSound('scratch', 0.15);
      }
    } else if (previewSnapshotRef.current && startPosRef.current) {
      ctx.putImageData(previewSnapshotRef.current, 0, 0);
      if (activeChalkTool === 'arrow') {
        drawArrow(ctx, startPosRef.current.x, startPosRef.current.y, pos.x, pos.y, selectedColor, chalkWidth);
      } else if (activeChalkTool === 'line') {
        ctx.save();
        ctx.strokeStyle = selectedColor;
        ctx.lineWidth = chalkWidth;
        ctx.shadowColor = selectedColor;
        ctx.shadowBlur = 4;
        ctx.beginPath();
        ctx.moveTo(startPosRef.current.x, startPosRef.current.y);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
        ctx.restore();
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !isChalkMode) return;
    const canvas = e.currentTarget;
    try {
      canvas.releasePointerCapture(e.pointerId);
    } catch {}
    setIsDrawing(false);
    startPosRef.current = null;
    previewSnapshotRef.current = null;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.beginPath();
      ctx.globalCompositeOperation = 'source-over';
    }
    if (soundEnabled) {
      playChalkSound('tap', 0.2);
    }
  };

  // Undo Last Chalk Stroke
  const handleUndoChalk = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || chalkUndoStack.length === 0) {
      showNotification?.('Nothing to undo', 'info');
      return;
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    try {
      const currentSnapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setChalkRedoStack(prev => [...prev.slice(-25), currentSnapshot]);
    } catch {}

    const previousSnapshot = chalkUndoStack[chalkUndoStack.length - 1];
    setChalkUndoStack(prev => prev.slice(0, -1));
    ctx.putImageData(previousSnapshot, 0, 0);
    if (soundEnabled) playChalkSound('dust', 0.2);
    showNotification?.('Undid last chalk annotation', 'info');
  }, [chalkUndoStack, soundEnabled, showNotification]);

  // Redo Chalk Stroke
  const handleRedoChalk = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || chalkRedoStack.length === 0) {
      showNotification?.('Nothing to redo', 'info');
      return;
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    try {
      const currentSnapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setChalkUndoStack(prev => [...prev.slice(-25), currentSnapshot]);
    } catch {}

    const nextSnapshot = chalkRedoStack[chalkRedoStack.length - 1];
    setChalkRedoStack(prev => prev.slice(0, -1));
    ctx.putImageData(nextSnapshot, 0, 0);
    if (soundEnabled) playChalkSound('tap', 0.25);
    showNotification?.('Redid chalk annotation', 'info');
  }, [chalkRedoStack, soundEnabled, showNotification]);

  // Keyboard shortcut listener (Ctrl+Z for Undo, Ctrl+Y / Ctrl+Shift+Z for Redo)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isChalkMode) return;
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        handleUndoChalk();
      } else if (
        ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') ||
        ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'z')
      ) {
        e.preventDefault();
        handleRedoChalk();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isChalkMode, handleUndoChalk, handleRedoChalk]);

  const handleClearChalk = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    try {
      const snapshot = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setChalkUndoStack(prev => [...prev.slice(-25), snapshot]);
      setChalkRedoStack([]);
    } catch {}

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (soundEnabled) playChalkSound('dust', 0.4);
    showNotification?.('Chalkboard wiped clean!', 'info');
  };

  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabledState(next);
    setChalkSoundEnabled(next);
    if (next) playChalkSound('tap', 0.3);
    showNotification?.(next ? 'Chalk audio effects enabled' : 'Chalk audio muted', 'info');
  };

  const handleToggleAnimate = () => {
    if (!isAnimating) {
      setIsAnimating(true);
      setAnimKey(prev => prev + 1);
      showNotification?.('Vector Path Animation Started!', 'info');
    } else {
      setIsAnimating(false);
      showNotification?.('Animation Paused', 'info');
    }
  };

  const handleCopySvg = () => {
    navigator.clipboard.writeText(cleanSvg);
    setCopied(true);
    showNotification?.('SVG Diagram code copied to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadPng = () => {
    try {
      const blob = new Blob([cleanSvg], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width || 800;
        canvas.height = img.height || 400;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = theme === 'dark' ? '#0f172a' : '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0);

          if (canvasRef.current) {
            ctx.drawImage(canvasRef.current, 0, 0, canvas.width, canvas.height);
          }

          const pngUrl = canvas.toDataURL('image/png');
          const downloadLink = document.createElement('a');
          downloadLink.href = pngUrl;
          downloadLink.download = `teaching_diagram_with_chalk_${Date.now()}.png`;
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);
          URL.revokeObjectURL(url);
          showNotification?.('2D Diagram & Chalk Annotations exported as PNG!', 'success');
        }
      };
      img.src = url;
    } catch {
      showNotification?.('Failed to convert SVG to PNG', 'error');
    }
  };

  const handleAnnotateOnWhiteboard = () => {
    if (!onOpenWhiteboard) {
      showNotification?.('Opening Digital Math Whiteboard...', 'info');
      return;
    }
    const blob = new Blob([cleanSvg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width || 1000;
      canvas.height = img.height || 500;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = theme === 'dark' ? '#0f172a' : '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0);
        if (canvasRef.current) {
          ctx.drawImage(canvasRef.current, 0, 0, canvas.width, canvas.height);
        }
        const dataUrl = canvas.toDataURL('image/png');
        onOpenWhiteboard(dataUrl);
      }
    };
    img.src = url;
  };

  return (
    <div className={cn(
      "my-4 rounded-2xl border shadow-xl overflow-hidden transition-all duration-200 relative group/viewer",
      theme === 'dark' 
        ? "bg-slate-900/90 border-slate-700/80 text-slate-100" 
        : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Dynamic Interactive CSS Rules for SVG Manipulation */}
      <style>{`
        #viewer-${instanceId} .svg-content {
          width: 100%;
          height: auto;
          display: block;
        }

        /* Dynamic SVG Theme Color Mapping & Legibility Overrides */
        #viewer-${instanceId} {
          background-color: var(--svg-bg) !important;
          transition: background-color 0.3s ease;
        }
        #viewer-${instanceId} svg {
          background: transparent !important;
        }
        /* Automatically adjust lines/paths that might clash with light/dark backgrounds */
        #viewer-${instanceId} svg path[stroke="#ffffff"],
        #viewer-${instanceId} svg path[stroke="white"],
        #viewer-${instanceId} svg path[stroke="#fff"],
        #viewer-${instanceId} svg line[stroke="#ffffff"],
        #viewer-${instanceId} svg line[stroke="white"],
        #viewer-${instanceId} svg line[stroke="#fff"],
        #viewer-${instanceId} svg circle[stroke="#ffffff"],
        #viewer-${instanceId} svg circle[stroke="white"],
        #viewer-${instanceId} svg circle[stroke="#fff"] {
          stroke: var(--svg-primary) !important;
        }

        #viewer-${instanceId} svg path[stroke="#000000"],
        #viewer-${instanceId} svg path[stroke="black"],
        #viewer-${instanceId} svg path[stroke="#000"],
        #viewer-${instanceId} svg line[stroke="#000000"],
        #viewer-${instanceId} svg line[stroke="black"],
        #viewer-${instanceId} svg line[stroke="#000"],
        #viewer-${instanceId} svg circle[stroke="#000000"],
        #viewer-${instanceId} svg circle[stroke="black"],
        #viewer-${instanceId} svg circle[stroke="#000"] {
          stroke: var(--svg-primary) !important; /* Adapt black lines to white in dark/green modes */
        }

        #viewer-${instanceId} svg text,
        #viewer-${instanceId} svg tspan {
          fill: var(--svg-primary) !important;
          font-family: inherit;
        }
        
        #viewer-${instanceId} svg rect[fill="#ffffff"],
        #viewer-${instanceId} svg rect[fill="white"],
        #viewer-${instanceId} svg rect[fill="#fff"] {
          fill: var(--svg-bg) !important;
          stroke: var(--svg-primary) !important;
        }

        #viewer-${instanceId} svg rect[fill="#000000"],
        #viewer-${instanceId} svg rect[fill="black"],
        #viewer-${instanceId} svg rect[fill="#000"] {
          fill: var(--svg-bg) !important;
          stroke: var(--svg-primary) !important;
        }

        /* Dynamic flow speed control injected based on slider */
        #viewer-${instanceId} path {
          stroke-dasharray: ${flowSpeed > 0 ? "8, 4" : "none"} !important;
          animation: ${flowSpeed > 0 ? `flow-path ${15 / flowSpeed}s linear infinite` : "none"} !important;
        }
        @keyframes flow-path {
          to {
            stroke-dashoffset: -100;
          }
        }

        /* Active-Recall Quiz Mode Style Overrides */
        #viewer-${instanceId}.quiz-active text,
        #viewer-${instanceId}.quiz-active tspan {
          fill: #475569 !important;
          opacity: 0.25 !important;
          cursor: pointer !important;
          pointer-events: auto !important;
          transition: all 0.2s ease !important;
        }
        #viewer-${instanceId}.quiz-active text:hover,
        #viewer-${instanceId}.quiz-active tspan:hover {
          fill: #f59e0b !important;
          opacity: 0.75 !important;
          font-weight: bold !important;
        }
        #viewer-${instanceId}.quiz-active .quiz-revealed {
          fill: #10b981 !important;
          opacity: 1 !important;
          font-weight: 900 !important;
          text-shadow: 0 0 10px rgba(16, 185, 129, 0.8) !important;
        }

        /* High-Contrast Neon Accessibility Boost for Base AI SVG */
        #viewer-${instanceId}.high-contrast-neon .svg-canvas-wrapper svg {
          filter: invert(0.88) hue-rotate(180deg) brightness(1.6) contrast(2) drop-shadow(0 0 6px rgba(0, 245, 255, 0.8)) !important;
        }

        #viewer-${instanceId}.high-contrast-neon text,
        #viewer-${instanceId}.high-contrast-neon tspan {
          fill: #00f5ff !important;
          font-weight: 900 !important;
          text-shadow: 0 0 8px rgba(0,0,0,0.9), 0 0 4px rgba(0,245,255,0.9) !important;
        }

        #viewer-${instanceId}.high-contrast-neon path,
        #viewer-${instanceId}.high-contrast-neon line,
        #viewer-${instanceId}.high-contrast-neon polyline,
        #viewer-${instanceId}.high-contrast-neon polygon,
        #viewer-${instanceId}.high-contrast-neon circle {
          stroke-width: 1.8px;
        }

        /* Toggle Grid */
        #viewer-${instanceId}.hide-grid .grid,
        #viewer-${instanceId}.hide-grid [id*="grid"],
        #viewer-${instanceId}.hide-grid [class*="grid"],
        #viewer-${instanceId}.hide-grid pattern,
        #viewer-${instanceId}.hide-grid line[stroke*="#33"],
        #viewer-${instanceId}.hide-grid line[stroke*="#22"],
        #viewer-${instanceId}.hide-grid line[stroke*="#44"],
        #viewer-${instanceId}.hide-grid line[stroke-dasharray] {
          opacity: 0 !important;
          transition: opacity 0.25s ease;
        }

        /* Toggle Labels */
        #viewer-${instanceId}.hide-labels text,
        #viewer-${instanceId}.hide-labels tspan,
        #viewer-${instanceId}.hide-labels [id*="label"],
        #viewer-${instanceId}.hide-labels [class*="label"],
        #viewer-${instanceId}.hide-labels [id*="text"],
        #viewer-${instanceId}.hide-labels [class*="text"] {
          opacity: 0 !important;
          transition: opacity 0.25s ease;
        }

        /* Show / Hide Resultant Vector */
        #viewer-${instanceId}.hide-resultant [id*="resultant"],
        #viewer-${instanceId}.hide-resultant [class*="resultant"],
        #viewer-${instanceId}.hide-resultant [id*="net"],
        #viewer-${instanceId}.hide-resultant [class*="net"],
        #viewer-${instanceId}.hide-resultant [id*="vector-r"],
        #viewer-${instanceId}.hide-resultant [id*="sum"],
        #viewer-${instanceId}.hide-resultant path[stroke*="#ec4899"],
        #viewer-${instanceId}.hide-resultant path[stroke*="#f43f5e"],
        #viewer-${instanceId}.hide-resultant path[stroke*="#e11d48"],
        #viewer-${instanceId}.hide-resultant path[stroke*="#10b981"],
        #viewer-${instanceId}.hide-resultant line[stroke*="#ec4899"],
        #viewer-${instanceId}.hide-resultant line[stroke*="#f43f5e"] {
          opacity: 0.05 !important;
          stroke-dasharray: 4,4 !important;
          transition: all 0.3s ease;
        }

        /* Vector Path Rendering - Instant Static Display */
        #viewer-${instanceId}.is-animating path,
        #viewer-${instanceId}.is-animating line,
        #viewer-${instanceId}.is-animating polyline {
          stroke-dasharray: none !important;
          stroke-dashoffset: 0 !important;
          animation: none !important;
        }

        /* Layered Transparency & Depth Control */
        #viewer-${instanceId} .svg-canvas-wrapper {
          opacity: ${layerOpacity};
          transition: opacity 0.2s ease, filter 0.3s ease;
        }

        /* Advanced Scientific Fill Pattern Overlays */
        #viewer-${instanceId}.pattern-hatch path:not([fill="none"]):not([stroke]):not([fill="transparent"]),
        #viewer-${instanceId}.pattern-hatch polygon:not([fill="none"]),
        #viewer-${instanceId}.pattern-hatch circle:not([fill="none"]),
        #viewer-${instanceId}.pattern-hatch rect:not([fill="none"]) {
          fill: url(#sci-hatch-cyan) !important;
          fill-opacity: 0.75 !important;
          stroke: #00f5ff !important;
          stroke-width: 1.2px !important;
        }

        #viewer-${instanceId}.pattern-crosshatch path:not([fill="none"]):not([stroke]):not([fill="transparent"]),
        #viewer-${instanceId}.pattern-crosshatch polygon:not([fill="none"]),
        #viewer-${instanceId}.pattern-crosshatch circle:not([fill="none"]),
        #viewer-${instanceId}.pattern-crosshatch rect:not([fill="none"]) {
          fill: url(#sci-crosshatch-amber) !important;
          fill-opacity: 0.8 !important;
          stroke: #f59e0b !important;
          stroke-width: 1.2px !important;
        }

        #viewer-${instanceId}.pattern-stipple path:not([fill="none"]):not([stroke]):not([fill="transparent"]),
        #viewer-${instanceId}.pattern-stipple polygon:not([fill="none"]),
        #viewer-${instanceId}.pattern-stipple circle:not([fill="none"]),
        #viewer-${instanceId}.pattern-stipple rect:not([fill="none"]) {
          fill: url(#sci-dots-stipple) !important;
          fill-opacity: 0.85 !important;
          stroke: #38bdf8 !important;
          stroke-width: 1.2px !important;
        }

        #viewer-${instanceId}.pattern-cellular path:not([fill="none"]):not([stroke]):not([fill="transparent"]),
        #viewer-${instanceId}.pattern-cellular polygon:not([fill="none"]),
        #viewer-${instanceId}.pattern-cellular circle:not([fill="none"]),
        #viewer-${instanceId}.pattern-cellular rect:not([fill="none"]) {
          fill: url(#sci-hex-mesh) !important;
          fill-opacity: 0.8 !important;
          stroke: #10b981 !important;
          stroke-width: 1.2px !important;
        }

        /* Layered X-Ray Mode: Translucent Layer Slicing for Overlapping Components */
        #viewer-${instanceId}.mode-xray path,
        #viewer-${instanceId}.mode-xray polygon,
        #viewer-${instanceId}.mode-xray circle,
        #viewer-${instanceId}.mode-xray ellipse,
        #viewer-${instanceId}.mode-xray rect {
          fill-opacity: 0.38 !important;
          stroke-width: 1.8px !important;
          mix-blend-mode: screen !important;
          filter: drop-shadow(0 0 2px rgba(0, 245, 255, 0.4)) !important;
        }
      `}</style>

      {/* Top Header Bar */}
      <div className={cn(
        "px-4 py-2.5 border-b flex items-center justify-between gap-3 flex-wrap relative z-10",
        isHighContrast
          ? "bg-black border-cyan-500/40 text-white shadow-lg"
          : theme === 'dark' 
            ? "bg-slate-950/80 border-slate-800" 
            : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-center gap-2">
          <span className={cn(
            "p-1.5 rounded-lg",
            isHighContrast ? "bg-cyan-500/30 text-cyan-300 shadow-[0_0_8px_rgba(0,245,255,0.5)]" : "bg-indigo-500/20 text-indigo-400"
          )}>
            <Sparkles size={14} />
          </span>
          <span className={cn(
            "text-xs font-black uppercase tracking-wide",
            isHighContrast ? "text-cyan-300 drop-shadow-[0_0_6px_rgba(0,245,255,0.6)]" : "text-indigo-400"
          )}>
            {title}
          </span>
          <span className={cn(
            "text-[10px] px-2 py-0.5 rounded-full font-mono flex items-center gap-1 border",
            isHighContrast 
              ? "bg-black text-[#00f5ff] border-[#00f5ff] font-bold shadow-[0_0_8px_rgba(0,245,255,0.4)]" 
              : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
          )}>
            <Compass size={11} />
            <span>Theme: {colors.modeName}</span>
          </span>
          {anchorParagraph && (
            <span className="text-[10px] px-2 py-0.5 rounded-full font-mono font-bold bg-violet-500/20 text-violet-300 border border-violet-500/40 flex items-center gap-1 shadow-sm">
              <span>📍 Anchor: Para #{anchorParagraph} {anchorTopic ? `• ${anchorTopic}` : ''}</span>
            </span>
          )}
          {isHighContrast && (
            <span className="text-[10px] px-2 py-0.5 rounded-full font-mono font-bold bg-black text-[#ffff00] border border-[#ffff00] shadow-[0_0_8px_rgba(255,255,0,0.5)] flex items-center gap-1">
              <Zap size={10} className="text-[#ffff00]" />
              <span>Neon High-Contrast</span>
            </span>
          )}
          {isChalkMode && (
            <span className="text-[10px] px-2 py-0.5 rounded-full font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse flex items-center gap-1">
              <Pencil size={10} />
              <span>Chalk Active</span>
            </span>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5">
          {/* Nano Banana 2 2K Generation & Switch Button */}
          <button
            type="button"
            onClick={() => {
              if (nanoBananaImageUrl) {
                setActiveVisualMode(prev => prev === 'nanobanana' ? 'vector' : 'nanobanana');
                showNotification?.(activeVisualMode === 'nanobanana' ? 'Switched to Interactive Vector mode' : 'Switched to Nano Banana 2 (2K) mode', 'info');
              } else {
                handleGenerateNanoBanana();
              }
            }}
            disabled={isGeneratingNanoBanana}
            title={nanoBananaImageUrl ? (activeVisualMode === 'nanobanana' ? "Switch to Vector Mode" : "Switch to Nano Banana 2 (2K) Visual Mode") : "Render 2K Visual Diagram with Nano Banana 2 (gemini-3.1-flash-image-preview)"}
            className={cn(
              "p-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 text-xs font-mono font-bold border shrink-0",
              isGeneratingNanoBanana
                ? "bg-purple-900/60 text-purple-300 border-purple-500/50 animate-pulse"
                : nanoBananaImageUrl && activeVisualMode === 'nanobanana'
                ? "bg-gradient-to-r from-purple-600/30 to-indigo-600/30 text-amber-300 border-amber-400/60 shadow-[0_0_12px_rgba(234,179,8,0.4)]"
                : "text-slate-400 hover:text-amber-300 hover:bg-slate-800 border-slate-700/60"
            )}
          >
            <Sparkles size={14} className={isGeneratingNanoBanana ? "animate-spin text-amber-400" : "text-amber-400"} />
            <span className="text-[10px]">
              {isGeneratingNanoBanana ? "Rendering 2K..." : nanoBananaImageUrl && activeVisualMode === 'nanobanana' ? "🍌 Nano Banana 2 (2K)" : "🍌 Nano Banana 2 (2K)"}
            </span>
          </button>

          {/* Professor Pointer Toggle Button */}
          <button
            type="button"
            onClick={() => {
              const next = !isProfPointerActive;
              setIsProfPointerActive(next);
              if (soundEnabled) playChalkSound('tap', 0.3);
              showNotification?.(
                next ? 'Professor Laser Pointer Enabled (Teaching Cursor Active)' : 'Professor Pointer Hidden', 
                'info'
              );
            }}
            title={isProfPointerActive ? "Disable Professor Laser Pointer" : "Enable Professor Laser Pointer (Interactive Teaching Cursor)"}
            className={cn(
              "p-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 text-xs font-mono font-bold border",
              isProfPointerActive 
                ? "bg-rose-950/80 text-rose-300 border-rose-500/60 shadow-[0_0_10px_rgba(239,68,68,0.4)]" 
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800 border-transparent"
            )}
          >
            <Crosshair size={14} className={isProfPointerActive ? "text-rose-400" : "text-slate-400"} />
            <span className="hidden sm:inline text-[10px]">{isProfPointerActive ? "Prof. Pointer ON" : "Prof. Pointer"}</span>
          </button>

          {/* High-Contrast Neon Toggle (Top Quick Action) */}
          <button
            type="button"
            onClick={toggleHighContrast}
            title={isHighContrast ? "Disable Neon High-Contrast (Standard View)" : "Enable Neon High-Contrast Scheme for Lighting Accessibility"}
            className={cn(
              "p-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 text-xs font-mono font-bold border",
              isHighContrast 
                ? "bg-black text-[#00f5ff] border-[#00f5ff] shadow-[0_0_10px_rgba(0,245,255,0.5)]" 
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800 border-transparent"
            )}
          >
            <Contrast size={14} className={isHighContrast ? "text-[#00f5ff]" : "text-slate-400"} />
            <span className="hidden sm:inline text-[10px]">{isHighContrast ? "Neon ON" : "High Contrast"}</span>
          </button>

          {/* Layered Transparency & Opacity Dropdown Popover */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowOpacityMenu(prev => !prev);
                setShowPatternMenu(false);
              }}
              title="Adjust Layer Transparency & Component Depth"
              className={cn(
                "p-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 text-xs font-mono font-bold border",
                showOpacityMenu || layerOpacity < 0.9
                  ? "bg-indigo-950/80 text-indigo-300 border-indigo-500/60 shadow-[0_0_10px_rgba(99,102,241,0.4)]"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800 border-transparent"
              )}
            >
              <Layers size={14} className={layerOpacity < 0.9 ? "text-indigo-400" : "text-slate-400"} />
              <span className="hidden md:inline text-[10px]">{Math.round(layerOpacity * 100)}% Opacity</span>
            </button>

            {showOpacityMenu && (
              <div className="absolute right-0 top-full mt-2 w-56 p-3 bg-slate-950/95 border border-slate-700/80 rounded-2xl shadow-2xl backdrop-blur-xl z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Layers size={12} />
                    Layer Transparency
                  </span>
                  <span className="text-xs font-mono font-bold text-white bg-indigo-500/20 px-1.5 py-0.5 rounded-md">
                    {Math.round(layerOpacity * 100)}%
                  </span>
                </div>
                
                {/* Opacity Slider */}
                <input
                  type="range"
                  min="0.2"
                  max="1.0"
                  step="0.05"
                  value={layerOpacity}
                  onChange={(e) => setLayerOpacity(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 mb-3"
                />

                {/* Preset Chips */}
                <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono">
                  <button
                    type="button"
                    onClick={() => { setLayerOpacity(1.0); setShowOpacityMenu(false); }}
                    className={cn(
                      "p-1.5 rounded-lg border text-center font-bold transition",
                      layerOpacity === 1.0 ? "bg-indigo-600 text-white border-indigo-400" : "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800"
                    )}
                  >
                    100% Solid
                  </button>
                  <button
                    type="button"
                    onClick={() => { setLayerOpacity(0.75); setShowOpacityMenu(false); }}
                    className={cn(
                      "p-1.5 rounded-lg border text-center font-bold transition",
                      layerOpacity === 0.75 ? "bg-indigo-600 text-white border-indigo-400" : "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800"
                    )}
                  >
                    75% Translucent
                  </button>
                  <button
                    type="button"
                    onClick={() => { setLayerOpacity(0.5); setShowOpacityMenu(false); }}
                    className={cn(
                      "p-1.5 rounded-lg border text-center font-bold transition",
                      layerOpacity === 0.5 ? "bg-indigo-600 text-white border-indigo-400" : "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800"
                    )}
                  >
                    50% Depth Slicer
                  </button>
                  <button
                    type="button"
                    onClick={() => { setLayerOpacity(0.3); setShowOpacityMenu(false); }}
                    className={cn(
                      "p-1.5 rounded-lg border text-center font-bold transition",
                      layerOpacity === 0.3 ? "bg-indigo-600 text-white border-indigo-400" : "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800"
                    )}
                  >
                    30% X-Ray Sheer
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Advanced Scientific Fill Patterns Dropdown Popover */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setShowPatternMenu(prev => !prev);
                setShowOpacityMenu(false);
              }}
              title="Apply Scientific Fill Patterns & Hatching for Component Distinction"
              className={cn(
                "p-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 text-xs font-mono font-bold border",
                showPatternMenu || fillPatternStyle !== 'none'
                  ? "bg-amber-950/80 text-amber-300 border-amber-500/60 shadow-[0_0_10px_rgba(245,158,11,0.4)]"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800 border-transparent"
              )}
            >
              <Palette size={14} className={fillPatternStyle !== 'none' ? "text-amber-400" : "text-slate-400"} />
              <span className="hidden md:inline text-[10px]">
                {fillPatternStyle === 'none' ? 'Fill Pattern' : fillPatternStyle.toUpperCase()}
              </span>
            </button>

            {showPatternMenu && (
              <div className="absolute right-0 top-full mt-2 w-64 p-3 bg-slate-950/95 border border-slate-700/80 rounded-2xl shadow-2xl backdrop-blur-xl z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Palette size={12} />
                    Fill Patterns & Textures
                  </span>
                </div>
                
                <div className="space-y-1 text-xs">
                  <button
                    type="button"
                    onClick={() => { setFillPatternStyle('none'); setShowPatternMenu(false); }}
                    className={cn(
                      "w-full text-left px-2.5 py-1.5 rounded-lg font-mono flex items-center justify-between transition",
                      fillPatternStyle === 'none' ? "bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40" : "hover:bg-slate-900 text-slate-300"
                    )}
                  >
                    <span>Standard Solid Fills</span>
                    {fillPatternStyle === 'none' && <Check size={13} className="text-amber-400" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => { setFillPatternStyle('hatch'); setShowPatternMenu(false); }}
                    className={cn(
                      "w-full text-left px-2.5 py-1.5 rounded-lg font-mono flex items-center justify-between transition",
                      fillPatternStyle === 'hatch' ? "bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40" : "hover:bg-slate-900 text-slate-300"
                    )}
                  >
                    <span>📐 Diagonal Hatching (Cyan/Amber)</span>
                    {fillPatternStyle === 'hatch' && <Check size={13} className="text-amber-400" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => { setFillPatternStyle('crosshatch'); setShowPatternMenu(false); }}
                    className={cn(
                      "w-full text-left px-2.5 py-1.5 rounded-lg font-mono flex items-center justify-between transition",
                      fillPatternStyle === 'crosshatch' ? "bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40" : "hover:bg-slate-900 text-slate-300"
                    )}
                  >
                    <span>🔲 Crosshatch Matrix Grid</span>
                    {fillPatternStyle === 'crosshatch' && <Check size={13} className="text-amber-400" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => { setFillPatternStyle('stipple'); setShowPatternMenu(false); }}
                    className={cn(
                      "w-full text-left px-2.5 py-1.5 rounded-lg font-mono flex items-center justify-between transition",
                      fillPatternStyle === 'stipple' ? "bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40" : "hover:bg-slate-900 text-slate-300"
                    )}
                  >
                    <span>🔬 Stippling Dots Density</span>
                    {fillPatternStyle === 'stipple' && <Check size={13} className="text-amber-400" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => { setFillPatternStyle('cellular'); setShowPatternMenu(false); }}
                    className={cn(
                      "w-full text-left px-2.5 py-1.5 rounded-lg font-mono flex items-center justify-between transition",
                      fillPatternStyle === 'cellular' ? "bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40" : "hover:bg-slate-900 text-slate-300"
                    )}
                  >
                    <span>🧬 Cellular Hex / Lipid Mesh</span>
                    {fillPatternStyle === 'cellular' && <Check size={13} className="text-amber-400" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => { setFillPatternStyle('xray'); setShowPatternMenu(false); }}
                    className={cn(
                      "w-full text-left px-2.5 py-1.5 rounded-lg font-mono flex items-center justify-between transition",
                      fillPatternStyle === 'xray' ? "bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40 shadow-[0_0_8px_rgba(0,245,255,0.3)]" : "hover:bg-slate-900 text-slate-300"
                    )}
                  >
                    <span>🩻 Layered Translucent X-Ray</span>
                    {fillPatternStyle === 'xray' && <Check size={13} className="text-cyan-400" />}
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="w-px h-4 bg-slate-700/60 mx-1 hidden sm:block" />

          {/* Quick Preset Buttons for Common Vector Angles */}
          <div className="hidden lg:flex items-center gap-1 bg-black/30 px-2 py-1 rounded-xl border border-white/5 text-[10px] font-mono">
            <span className="text-slate-500 font-bold uppercase mr-1">Presets:</span>
            <button
              type="button"
              onClick={() => { snapVector('vecA', 0, 160); snapVector('vecB', 90, 140); }}
              className={cn("px-1.5 py-0.5 rounded transition", isHighContrast ? "hover:bg-cyan-950 text-cyan-300 font-bold" : "hover:bg-slate-800 text-sky-300")}
              title="Perpendicular 90° (Pythagorean Theorem)"
            >
              90° Orthogonal
            </button>
            <button
              type="button"
              onClick={() => { snapVector('vecA', 0, 160); snapVector('vecB', 60, 160); }}
              className={cn("px-1.5 py-0.5 rounded transition", isHighContrast ? "hover:bg-yellow-950 text-yellow-300 font-bold" : "hover:bg-slate-800 text-amber-300")}
              title="Equilateral Triangle Law (60°)"
            >
              60° Parallelogram
            </button>
            <button
              type="button"
              onClick={() => { snapVector('vecA', 0, 160); snapVector('vecB', 180, 120); }}
              className={cn("px-1.5 py-0.5 rounded transition", isHighContrast ? "hover:bg-pink-950 text-pink-300 font-bold" : "hover:bg-slate-800 text-rose-300")}
              title="Collinear / Antiparallel (180°)"
            >
              180° Opposite
            </button>
          </div>

          <div className="w-px h-4 bg-slate-700/60 mx-1 hidden lg:block" />

          <button
            type="button"
            onClick={() => setZoom(z => Math.max(0.6, z - 0.2))}
            title="Zoom Out"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <ZoomOut size={14} />
          </button>

          <span className="text-[10px] font-mono font-bold text-slate-400 px-1">
            {Math.round(zoom * 100)}%
          </span>

          <button
            type="button"
            onClick={() => setZoom(z => Math.min(2.5, z + 0.2))}
            title="Zoom In"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <ZoomIn size={14} />
          </button>

          <button
            type="button"
            onClick={handleResetVectors}
            title="Reset Vector Positions & Zoom"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <RotateCcw size={14} />
          </button>

          <div className="w-px h-4 bg-slate-700/60 mx-1" />

          {/* Chalk Sound Toggle */}
          <button
            type="button"
            onClick={handleToggleSound}
            title={soundEnabled ? "Chalk Sounds Enabled" : "Chalk Sounds Muted"}
            className={cn(
              "p-1.5 rounded-lg transition cursor-pointer",
              soundEnabled ? "text-amber-400 hover:bg-slate-800" : "text-slate-500 hover:bg-slate-800"
            )}
          >
            {soundEnabled ? <Volume2 size={14} /> : <VolumeX size={14} />}
          </button>

          {onOpenWhiteboard && (
            <button
              type="button"
              onClick={handleAnnotateOnWhiteboard}
              title="Annotate on Digital Whiteboard"
              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1.5 transition cursor-pointer shadow-sm active:scale-95"
            >
              <Edit3 size={13} />
              <span>Full Board</span>
            </button>
          )}

          {onExplainFigure && (
            <button
              type="button"
              onClick={() => onExplainFigure(svgCode, title)}
              title="Ask the AI Tutor for a deep, step-by-step breakdown of this diagram"
              className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold flex items-center gap-1.5 transition cursor-pointer shadow-sm active:scale-95 shadow-indigo-600/20"
            >
              <Sparkles size={13} className="text-amber-300 animate-pulse" />
              <span>Explain</span>
            </button>
          )}

          {/* Real-time Vector Flow Speed Controller */}
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-slate-800/40 border border-slate-700/50 text-[10px] font-bold text-slate-300">
            <span>Flow:</span>
            <input
              type="range"
              min="0"
              max="5"
              step="1"
              value={flowSpeed}
              onChange={(e) => {
                setFlowSpeed(Number(e.target.value));
                playChalkSound?.();
                if (showNotification) {
                  showNotification(`Flow velocity adjusted to ${e.target.value}x`, 'info');
                }
              }}
              title="Drag to simulate vector flow velocity and current speed"
              className="w-12 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
            <span className="font-mono text-[9px] text-amber-300">{flowSpeed}x</span>
          </div>

          {/* Active Recall Quiz Trigger */}
          <button
            type="button"
            onClick={() => {
              setIsQuizActive(!isQuizActive);
              if (!isQuizActive) {
                setQuizCompleted([]);
                setQuizAttempts({ correct: 0, total: 0 });
                const labels = parsedLabels.map(l => l.text);
                if (labels.length > 0) {
                  const target = labels[Math.floor(Math.random() * labels.length)];
                  setQuizTarget(target);
                  showNotification?.(`🎯 Recall Challenge Started! Find and click on: "${target}"`, 'info');
                } else {
                  showNotification?.("No clear labels found on this diagram to quiz.", 'warning');
                }
              } else {
                setQuizTarget(null);
                const elements = containerRef.current?.querySelectorAll('text, tspan');
                elements?.forEach((el: any) => el.classList.remove('quiz-revealed'));
              }
              playChalkSound?.();
            }}
            title={isQuizActive ? "End Recall Challenge" : "Start Active-Recall Quiz Mode"}
            className={cn(
              "px-2.5 py-1 rounded-lg text-[11px] font-extrabold flex items-center gap-1 transition cursor-pointer active:scale-95 shadow-sm",
              isQuizActive 
                ? "bg-amber-500 hover:bg-amber-400 text-slate-950" 
                : "bg-emerald-600 hover:bg-emerald-500 text-white"
            )}
          >
            <Compass size={13} className={isQuizActive ? "animate-spin" : ""} />
            <span>{isQuizActive ? "Recall Active" : "Recall Quiz"}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPng}
            title="Download Diagram & Chalk PNG"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <Download size={14} />
          </button>

          <button
            type="button"
            onClick={handleCopySvg}
            title="Copy SVG Code"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
          </button>

          <button
            type="button"
            onClick={() => setIsFullscreen(true)}
            title="Fullscreen Expand"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <Maximize2 size={14} />
          </button>
        </div>
      </div>

      {/* Real-Time Mathematical & Physical Vector Telemetry Matrix */}
      {showVectorTelemetry && (
        <div className={cn(
          "px-4 py-2 border-b flex items-center justify-between gap-4 flex-wrap text-xs font-mono transition-all duration-300",
          legendSyncTheme.telemetryPanelBg
        )}>
          <div className="flex items-center gap-4 flex-wrap">
            {/* Vector A Specs */}
            <div className={cn("flex items-center gap-1.5 px-2.5 py-1 rounded-xl border transition-all", legendSyncTheme.badgeAClass)}>
              <span className={cn(
                "w-2.5 h-2.5 rounded-full",
                isHighContrast 
                  ? "bg-[#00f5ff] shadow-[0_0_10px_#00f5ff]" 
                  : "bg-sky-400 shadow-[0_0_8px_rgba(56,189,248,0.6)]"
              )} />
              <span style={{ color: legendSyncTheme.textColorA }} className="font-extrabold">A⃗:</span>
              <span>|A| = <b className="text-white font-bold">{magA}</b></span>
              <span className="text-slate-500">|</span>
              <span>θ = <b style={{ color: legendSyncTheme.textColorA }} className="font-bold">{angleA}°</b></span>
              <span className="text-[10px] opacity-90">({dxA}î + {dyA}ĵ)</span>
            </div>

            {/* Vector B Specs */}
            <div className={cn("flex items-center gap-1.5 px-2.5 py-1 rounded-xl border transition-all", legendSyncTheme.badgeBClass)}>
              <span className={cn(
                "w-2.5 h-2.5 rounded-full",
                isHighContrast 
                  ? "bg-[#ffff00] shadow-[0_0_10px_#ffff00]" 
                  : "bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]"
              )} />
              <span style={{ color: legendSyncTheme.textColorB }} className="font-extrabold">B⃗:</span>
              <span>|B| = <b className="text-white font-bold">{magB}</b></span>
              <span className="text-slate-500">|</span>
              <span>θ = <b style={{ color: legendSyncTheme.textColorB }} className="font-bold">{angleB}°</b></span>
              <span className="text-[10px] opacity-90">({dxB}î + {dyB}ĵ)</span>
            </div>

            {/* Resultant R = A + B Specs */}
            {showResultant && (
              <div className={cn("flex items-center gap-1.5 px-2.5 py-1 rounded-xl border transition-all animate-in fade-in duration-200", legendSyncTheme.badgeRClass)}>
                <span className={cn(
                  "w-2.5 h-2.5 rounded-full animate-pulse",
                  isHighContrast ? "bg-[#ff007f] shadow-[0_0_12px_#ff007f]" : "bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.8)]"
                )} />
                <span style={{ color: legendSyncTheme.textColorR }} className="font-black">R⃗ (Net):</span>
                <span>|R| = <b style={{ color: legendSyncTheme.textColorR }} className="font-black">{magR}</b></span>
                <span className="text-slate-500">|</span>
                <span>θ_R = <b style={{ color: legendSyncTheme.textColorR }} className="font-bold">{angleR}°</b></span>
                <span className="text-[10px] opacity-90">({rx}î + {ry}ĵ)</span>
              </div>
            )}

            {/* Inter-Vector Angle & Dot Product Legend Specs */}
            <div className={cn("flex items-center gap-1.5 px-2.5 py-1 rounded-xl border transition-all", legendSyncTheme.badgeAngleClass)}>
              <span style={{ color: legendSyncTheme.textColorAngle }} className="font-black">∠(A,B):</span>
              <b style={{ color: legendSyncTheme.textColorAngle }}>{acuteAngleBetween}°</b>
              <span className="text-slate-500">|</span>
              <span style={{ color: legendSyncTheme.textColorAngle }} className="font-bold">A⃗·B⃗ = <b>{dotProduct}</b></span>
            </div>

            {/* Cluttered / Overlapping Region Warning Badge */}
            {isClutteredRegion && (
              <div className={cn(
                "flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-[11px] font-mono font-bold animate-pulse",
                isHighContrast 
                  ? "bg-black border-[#ff5500] text-[#ff5500] shadow-[0_0_10px_rgba(255,85,0,0.4)]" 
                  : "bg-amber-950/60 border-amber-500/50 text-amber-300"
              )}>
                <ZoomIn size={12} className={isHighContrast ? "text-[#ff5500]" : "text-amber-400"} />
                <span>Overlapping Vectors (Δ={tipDistance}u) — Hover to Magnify</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className={cn("px-2 py-0.5 rounded-md text-[10px] font-mono flex items-center gap-1.5", legendSyncTheme.badgeContrastClass)}>
              <Contrast size={11} />
              <span>{legendSyncTheme.contrastLevelLabel}</span>
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-1">
              <Info size={12} className={isHighContrast ? "text-[#00f5ff]" : "text-indigo-400"} />
              <span>Drag vector arrow tips or origin points to manipulate angles in real-time</span>
            </div>
          </div>
        </div>
      )}

      {/* Main Diagram Viewport with Draggable Vectors & Chalk Overlay */}
      <div 
        id={`viewer-${instanceId}`}
        ref={containerRef}
        onPointerMove={handleContainerPointerMove}
        onPointerLeave={handleContainerPointerLeave}
        className={cn(
          "relative overflow-hidden p-4 flex items-center justify-center min-h-[340px] max-h-[580px] select-none transition-colors",
          isQuizActive && "quiz-active",
          isHighContrast && "high-contrast-neon bg-black",
          fillPatternStyle !== 'none' && `pattern-${fillPatternStyle}`,
          fillPatternStyle === 'xray' && "mode-xray",
          !showGrid && "hide-grid",
          !showLabels && "hide-labels",
          !showResultant && "hide-resultant",
          isAnimating && "is-animating",
          isChalkMode ? "cursor-crosshair" : "cursor-default"
        )}
        style={{
          backgroundColor: colors.bg,
          '--svg-bg': colors.bg,
          '--svg-primary': colors.primary,
          '--svg-secondary': colors.secondary,
          '--svg-text': colors.text,
          '--svg-highlight': colors.highlight,
          '--svg-accent': colors.accent,
          backgroundImage: showGrid 
            ? (isHighContrast
                ? 'radial-gradient(circle, rgba(0,245,255,0.6) 1.5px, transparent 1.5px), linear-gradient(to right, rgba(0,245,255,0.2) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,245,255,0.2) 1px, transparent 1px)'
                : theme === 'dark' 
                  ? 'radial-gradient(circle, rgba(56,189,248,0.5) 1.5px, transparent 1.5px), linear-gradient(to right, rgba(255,255,255,0.12) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.12) 1px, transparent 1px)' 
                  : 'radial-gradient(circle, rgba(2,132,199,0.4) 1.5px, transparent 1.5px), linear-gradient(to right, rgba(0,0,0,0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,0,0,0.1) 1px, transparent 1px)')
            : 'none',
          backgroundSize: '20px 20px'
        } as React.CSSProperties}
      >
        {/* Active-Recall Quiz Banner Overlay */}
        {isQuizActive && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-4 px-5 py-3 rounded-2xl bg-slate-950/95 text-slate-100 border border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.25)] backdrop-blur-xl animate-in fade-in slide-in-from-top-2 duration-200 min-w-[320px] max-w-[95%]">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400">Recall Challenge</span>
            </div>
            <div className="h-4 w-[1px] bg-slate-800" />
            <div className="text-xs font-extrabold flex-1 text-center">
              {quizTarget ? (
                <span>Find & click on: <strong className="text-amber-300 underline underline-offset-4 decoration-amber-400 font-black">{quizTarget}</strong></span>
              ) : (
                <span className="text-emerald-400 font-black">🎉 Challenge Cleared!</span>
              )}
            </div>
            <div className="h-4 w-[1px] bg-slate-800" />
            <div className="text-[10px] font-mono font-bold text-slate-400">
              Score: <strong className="text-slate-200">{quizAttempts.correct}/{quizAttempts.total}</strong>
            </div>
          </div>
        )}

        {/* Underlying SVG Diagram Container */}
        <div 
          key={animKey}
          ref={svgWrapperRef}
          className="transition-transform duration-200 ease-out flex items-center justify-center w-full svg-canvas-wrapper max-w-4xl relative"
          style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}
        >
          {/* Base AI SVG Code or Nano Banana 2 (2K) Image */}
          {nanoBananaImageUrl && activeVisualMode === 'nanobanana' ? (
            <div className="w-full h-full flex flex-col items-center justify-center relative overflow-hidden rounded-xl bg-slate-950 p-1">
              <img
                src={nanoBananaImageUrl}
                alt={title || "Nano Banana 2 2K Scientific Diagram"}
                className={cn(
                  "w-full h-auto max-h-[500px] object-contain rounded-xl shadow-2xl transition-all duration-300",
                  isHighContrast && "contrast-125 saturate-150"
                )}
                style={{ opacity: layerOpacity }}
              />
              <div className="absolute top-2 right-2 px-2.5 py-0.5 rounded-full bg-slate-950/90 border border-amber-400/50 text-[10px] font-black text-amber-300 backdrop-blur-md flex items-center gap-1.5 shadow-xl">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                </span>
                <span>🍌 Nano Banana 2 • 2K Ultra-HD</span>
              </div>
            </div>
          ) : (
            <div 
              className={cn(
                "w-full pointer-events-none transition-all duration-200",
                isHighContrast && "contrast-125 saturate-150"
              )}
              style={{ opacity: layerOpacity }}
              dangerouslySetInnerHTML={{ __html: cleanSvg }}
            />
          )}

          {/* Interactive Dynamic Draggable Vector SVG Overlay Layer */}
          {(isVectorDragMode || showGrid || showVectorTelemetry || isProfPointerActive) && (
            <svg
              ref={vectorSvgOverlayRef}
              viewBox="0 0 600 400"
              onPointerMove={handleVectorPointerMove}
              onPointerUp={handleVectorPointerUp}
              onPointerLeave={handleVectorPointerUp}
              className={cn(
                "absolute inset-0 w-full h-full z-10 select-none",
                isChalkMode ? "pointer-events-none opacity-40" : "pointer-events-auto opacity-100"
              )}
            >
              <defs>
                {/* Arrowhead Markers */}
                <marker id={`arrow-vecA-${instanceId}`} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1 L 10 5 L 0 9 z" fill={colorA} />
                </marker>
                <marker id={`arrow-vecB-${instanceId}`} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1 L 10 5 L 0 9 z" fill={colorB} />
                </marker>
                <marker id={`arrow-resultant-${instanceId}`} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M 0 0.5 L 10 5 L 0 9.5 z" fill={colorR} />
                </marker>

                {/* Glow Filter */}
                <filter id={`glow-${instanceId}`} x="-30%" y="-30%" width="160%" height="160%">
                  <feGaussianBlur stdDeviation={isHighContrast ? "4" : "3"} result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Cartesian Coordinate Axes with High-Contrast Tick Marks & Badges */}
              {showGrid && (
                <g className={cn("transition-opacity", isHighContrast ? "opacity-90" : "opacity-35")}>
                  {/* Primary X-Axis */}
                  <line 
                    x1="20" 
                    y1={vecA.originY} 
                    x2="580" 
                    y2={vecA.originY} 
                    stroke={axisColor} 
                    strokeWidth={isHighContrast ? "2" : "1"} 
                    strokeDasharray={isHighContrast ? "6 3" : "4 4"} 
                  />
                  {/* Primary Y-Axis */}
                  <line 
                    x1={vecA.originX} 
                    y1="20" 
                    x2={vecA.originX} 
                    y2="380" 
                    stroke={axisColor} 
                    strokeWidth={isHighContrast ? "2" : "1"} 
                    strokeDasharray={isHighContrast ? "6 3" : "4 4"} 
                  />

                  {/* High-Contrast Ticks on X and Y Axes */}
                  {isHighContrast && (
                    <g stroke="#ffffff" strokeWidth="1.5" opacity="0.8">
                      {[-200, -100, 100, 200].map(offset => {
                        const tx = vecA.originX + offset;
                        const ty = vecA.originY - offset;
                        return (
                          <React.Fragment key={offset}>
                            {tx >= 30 && tx <= 570 && (
                              <line x1={tx} y1={vecA.originY - 5} x2={tx} y2={vecA.originY + 5} />
                            )}
                            {ty >= 30 && ty <= 370 && (
                              <line x1={vecA.originX - 5} y1={ty} x2={vecA.originX + 5} y2={ty} />
                            )}
                          </React.Fragment>
                        );
                      })}
                    </g>
                  )}

                  {/* High-Contrast Axis Badges */}
                  {/* +X Label */}
                  <g transform={`translate(555, ${vecA.originY - 18})`}>
                    <rect x="0" y="0" width="28" height="18" rx="4" fill="#000000" stroke={isHighContrast ? "#00f5ff" : "#94a3b8"} strokeWidth="1.5" />
                    <text x="14" y="13" fill={isHighContrast ? "#00f5ff" : "#94a3b8"} fontSize="11" fontWeight="bold" fontFamily="monospace" textAnchor="middle">+X</text>
                  </g>
                  {/* -X Label */}
                  {isHighContrast && (
                    <g transform={`translate(15, ${vecA.originY - 18})`}>
                      <rect x="0" y="0" width="28" height="18" rx="4" fill="#000000" stroke="#00f5ff" strokeWidth="1.5" />
                      <text x="14" y="13" fill="#00f5ff" fontSize="11" fontWeight="bold" fontFamily="monospace" textAnchor="middle">-X</text>
                    </g>
                  )}
                  {/* +Y Label */}
                  <g transform={`translate(${vecA.originX + 8}, 22)`}>
                    <rect x="0" y="0" width="28" height="18" rx="4" fill="#000000" stroke={isHighContrast ? "#ffff00" : "#94a3b8"} strokeWidth="1.5" />
                    <text x="14" y="13" fill={isHighContrast ? "#ffff00" : "#94a3b8"} fontSize="11" fontWeight="bold" fontFamily="monospace" textAnchor="middle">+Y</text>
                  </g>
                  {/* Origin Badge */}
                  {isHighContrast && (
                    <g transform={`translate(${vecA.originX - 38}, ${vecA.originY + 10})`}>
                      <rect x="0" y="0" width="34" height="16" rx="4" fill="#000000" stroke="#d946ef" strokeWidth="1.5" />
                      <text x="17" y="12" fill="#d946ef" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">(0,0)</text>
                    </g>
                  )}
                </g>
              )}

              {/* Parallelogram Construction Guidelines & 3 Vectors (Only when isVectorDragMode is enabled) */}
              {isVectorDragMode && (
                <>
                  {showResultant && (
                    <g className="transition-all duration-150">
                      {/* Line from Tip A to Resultant Tip */}
                      <line
                        x1={vecA.tipX}
                        y1={vecA.tipY}
                        x2={resultantTipX}
                        y2={resultantTipY}
                        stroke={colorB}
                        strokeWidth={isHighContrast ? "2.5" : "1.5"}
                        strokeDasharray={isHighContrast ? "5 3" : "4 4"}
                        opacity={isHighContrast ? "0.9" : "0.6"}
                        filter={isHighContrast ? `url(#glow-${instanceId})` : undefined}
                      />
                      {/* Line from Tip B to Resultant Tip */}
                      <line
                        x1={vecB.tipX}
                        y1={vecB.tipY}
                        x2={resultantTipX}
                        y2={resultantTipY}
                        stroke={colorA}
                        strokeWidth={isHighContrast ? "2.5" : "1.5"}
                        strokeDasharray={isHighContrast ? "5 3" : "4 4"}
                        opacity={isHighContrast ? "0.9" : "0.6"}
                        filter={isHighContrast ? `url(#glow-${instanceId})` : undefined}
                      />
                    </g>
                  )}

                  {/* Resultant Vector R⃗ */}
                  {showResultant && (
                    <g filter={`url(#glow-${instanceId})`}>
                      <line
                        x1={vecA.originX}
                        y1={vecA.originY}
                        x2={resultantTipX}
                        y2={resultantTipY}
                        stroke={colorR}
                        strokeWidth={isHighContrast ? "5.5" : "4"}
                        strokeLinecap="round"
                        markerEnd={`url(#arrow-resultant-${instanceId})`}
                      />
                      {showLabels && (
                        <g transform={`translate(${(vecA.originX + resultantTipX) / 2 + 10}, ${(vecA.originY + resultantTipY) / 2 - 10})`}>
                          <rect 
                            x="-4" 
                            y="-14" 
                            width={isHighContrast ? "76" : "70"} 
                            height="22" 
                            rx="6" 
                            fill={isHighContrast ? "#000000" : "#881337"} 
                            opacity={isHighContrast ? "0.95" : "0.85"} 
                            stroke={colorR} 
                            strokeWidth={isHighContrast ? "2" : "1"} 
                          />
                          <text 
                            x={isHighContrast ? "34" : "31"} 
                            y="1" 
                            fill={isHighContrast ? "#ff007f" : "#ffffff"} 
                            fontSize="11" 
                            fontWeight="bold" 
                            textAnchor="middle" 
                            fontFamily="monospace"
                          >
                            R⃗ = {magR}
                          </text>
                        </g>
                      )}
                    </g>
                  )}

                  {/* Vector A⃗ */}
                  <g filter={isHighContrast ? `url(#glow-${instanceId})` : undefined}>
                    <line
                      x1={vecA.originX}
                      y1={vecA.originY}
                      x2={vecA.tipX}
                      y2={vecA.tipY}
                      stroke={colorA}
                      strokeWidth={isHighContrast ? "4.5" : "3.5"}
                      strokeLinecap="round"
                      markerEnd={`url(#arrow-vecA-${instanceId})`}
                    />
                    {showLabels && (
                      <g transform={`translate(${(vecA.originX + vecA.tipX) / 2}, ${(vecA.originY + vecA.tipY) / 2 - 14})`}>
                        {isHighContrast ? (
                          <>
                            <rect x="-35" y="-12" width="70" height="20" rx="5" fill="#000000" stroke="#00f5ff" strokeWidth="1.5" />
                            <text x="0" y="2" fill="#00f5ff" fontSize="12" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                              A⃗ ({magA})
                            </text>
                          </>
                        ) : (
                          <text 
                            x="0" 
                            y="0"
                            fill="#38bdf8" 
                            fontSize="12" 
                            fontWeight="bold"
                            textAnchor="middle"
                            fontFamily="monospace"
                          >
                            A⃗ ({magA})
                          </text>
                        )}
                      </g>
                    )}
                  </g>

                  {/* Vector B⃗ */}
                  <g filter={isHighContrast ? `url(#glow-${instanceId})` : undefined}>
                    <line
                      x1={vecB.originX}
                      y1={vecB.originY}
                      x2={vecB.tipX}
                      y2={vecB.tipY}
                      stroke={colorB}
                      strokeWidth={isHighContrast ? "4.5" : "3.5"}
                      strokeLinecap="round"
                      markerEnd={`url(#arrow-vecB-${instanceId})`}
                    />
                    {showLabels && (
                      <g transform={`translate(${(vecB.originX + vecB.tipX) / 2}, ${(vecB.originY + vecB.tipY) / 2 - 14})`}>
                        {isHighContrast ? (
                          <>
                            <rect x="-35" y="-12" width="70" height="20" rx="5" fill="#000000" stroke="#ffff00" strokeWidth="1.5" />
                            <text x="0" y="2" fill="#ffff00" fontSize="12" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                              B⃗ ({magB})
                            </text>
                          </>
                        ) : (
                          <text 
                            x="0" 
                            y="0"
                            fill="#fbbf24" 
                            fontSize="12" 
                            fontWeight="bold"
                            textAnchor="middle"
                            fontFamily="monospace"
                          >
                            B⃗ ({magB})
                          </text>
                        )}
                      </g>
                    )}
                  </g>

                  {/* Common Origin Anchor Point (Draggable) */}
                  <g 
                    onPointerDown={(e) => handleVectorPointerDown(e, 'vecA', 'origin')}
                    className="cursor-move group/origin"
                  >
                    <circle
                      cx={vecA.originX}
                      cy={vecA.originY}
                      r={isHighContrast ? "11" : "9"}
                      fill={colorOrigin}
                      stroke="#ffffff"
                      strokeWidth={isHighContrast ? "3" : "2.5"}
                      className="transition-transform group-hover/origin:scale-125"
                    />
                    <circle
                      cx={vecA.originX}
                      cy={vecA.originY}
                      r={isHighContrast ? "15" : "13"}
                      fill="none"
                      stroke={isHighContrast ? "#ffffff" : "#6366f1"}
                      strokeWidth={isHighContrast ? "2" : "1.5"}
                      strokeDasharray="3 3"
                    />
                  </g>

                  {/* Draggable Tip Handle for Vector A⃗ */}
                  <g 
                    onPointerDown={(e) => handleVectorPointerDown(e, 'vecA', 'tip')}
                    className="cursor-grab active:cursor-grabbing group/tipA"
                  >
                    <circle
                      cx={vecA.tipX}
                      cy={vecA.tipY}
                      r={isHighContrast ? "12" : "10"}
                      fill={colorA}
                      stroke="#ffffff"
                      strokeWidth={isHighContrast ? "3" : "2.5"}
                      className="transition-transform group-hover/tipA:scale-130 shadow-lg"
                    />
                    <circle
                      cx={vecA.tipX}
                      cy={vecA.tipY}
                      r="16"
                      fill="none"
                      stroke={isHighContrast ? "rgba(0,245,255,0.4)" : "rgba(56,189,248,0.3)"}
                      strokeWidth="1.5"
                      className="pointer-events-none"
                    />
                  </g>

                  {/* Draggable Tip Handle for Vector B⃗ */}
                  <g 
                    onPointerDown={(e) => handleVectorPointerDown(e, 'vecB', 'tip')}
                    className="cursor-grab active:cursor-grabbing group/tipB"
                  >
                    <circle
                      cx={vecB.tipX}
                      cy={vecB.tipY}
                      r={isHighContrast ? "12" : "10"}
                      fill={colorB}
                      stroke="#ffffff"
                      strokeWidth={isHighContrast ? "3" : "2.5"}
                      className="transition-transform group-hover/tipB:scale-130 shadow-lg"
                    />
                    <circle
                      cx={vecB.tipX}
                      cy={vecB.tipY}
                      r="16"
                      fill="none"
                      stroke={isHighContrast ? "rgba(255,255,0,0.4)" : "rgba(251,191,36,0.3)"}
                      strokeWidth="1.5"
                      className="pointer-events-none"
                    />
                  </g>
                </>
              )}

              {/* Dynamically Injected High-Contrast Vector Schematic Legend Box */}
              {showVectorTelemetry && (
                <g id="vector-legend-box" transform="translate(15, 15)" className="select-none pointer-events-none transition-all duration-300">
                  {/* Outer Legend Container Box */}
                  <rect 
                    x="0" 
                    y="0" 
                    width="215" 
                    height={showResultant ? "172" : "148"} 
                    rx="8" 
                    fill={legendSyncTheme.bgFill} 
                    fillOpacity={legendSyncTheme.bgOpacity} 
                    stroke={legendSyncTheme.borderColor} 
                    strokeWidth="2" 
                    filter={`url(#glow-${instanceId})`} 
                  />
                  
                  {/* Legend Header Bar */}
                  <rect x="0" y="0" width="215" height="24" rx="8" fill={legendSyncTheme.headerBg} opacity="0.95" />
                  <text 
                    x="10" 
                    y="16" 
                    fill={legendSyncTheme.headerTextColor} 
                    fontSize="10" 
                    fontWeight={legendSyncTheme.fontWeightHeader} 
                    fontFamily="monospace" 
                    letterSpacing={legendSyncTheme.letterSpacing}
                  >
                    📐 SCHEMATIC LEGEND
                  </text>
                  <text 
                    x="205" 
                    y="16" 
                    fill={legendSyncTheme.isHighContrast ? "#000000" : (legendSyncTheme.isLightBg ? "#0369a1" : "#94a3b8")} 
                    fontSize="9" 
                    fontWeight={legendSyncTheme.fontWeightBody} 
                    textAnchor="end" 
                    fontFamily="monospace"
                  >
                    O=(0,0)
                  </text>

                  {/* Vector A Legend Row */}
                  <g transform="translate(10, 38)">
                    <circle cx="5" cy="-3" r="4" fill={colorA} stroke="#ffffff" strokeWidth="1.5" />
                    <text 
                      x="14" 
                      y="0" 
                      fill={legendSyncTheme.textColorA} 
                      fontSize="10" 
                      fontWeight={legendSyncTheme.fontWeightBody} 
                      fontFamily="monospace"
                      letterSpacing={legendSyncTheme.letterSpacing}
                    >
                      A⃗: |A|={magA} u | θ_A={angleA}°
                    </text>
                    <text 
                      x="14" 
                      y="11" 
                      fill={legendSyncTheme.textComponent} 
                      fontSize="9" 
                      fontWeight={legendSyncTheme.fontWeightBody} 
                      fontFamily="monospace" 
                      opacity="0.95"
                    >
                      Comp: ({dxA}î + {dyA}ĵ)
                    </text>
                  </g>

                  {/* Vector B Legend Row */}
                  <g transform="translate(10, 72)">
                    <circle cx="5" cy="-3" r="4" fill={colorB} stroke="#ffffff" strokeWidth="1.5" />
                    <text 
                      x="14" 
                      y="0" 
                      fill={legendSyncTheme.textColorB} 
                      fontSize="10" 
                      fontWeight={legendSyncTheme.fontWeightBody} 
                      fontFamily="monospace"
                      letterSpacing={legendSyncTheme.letterSpacing}
                    >
                      B⃗: |B|={magB} u | θ_B={angleB}°
                    </text>
                    <text 
                      x="14" 
                      y="11" 
                      fill={legendSyncTheme.textComponent} 
                      fontSize="9" 
                      fontWeight={legendSyncTheme.fontWeightBody} 
                      fontFamily="monospace" 
                      opacity="0.95"
                    >
                      Comp: ({dxB}î + {dyB}ĵ)
                    </text>
                  </g>

                  {/* Resultant Vector R Legend Row */}
                  {showResultant && (
                    <g transform="translate(10, 106)">
                      <circle cx="5" cy="-3" r="4" fill={colorR} stroke="#ffffff" strokeWidth="1.5" />
                      <text 
                        x="14" 
                        y="0" 
                        fill={legendSyncTheme.textColorR} 
                        fontSize="10" 
                        fontWeight={legendSyncTheme.fontWeightBody} 
                        fontFamily="monospace"
                        letterSpacing={legendSyncTheme.letterSpacing}
                      >
                        R⃗ (Net): |R|={magR} u | θ_R={angleR}°
                      </text>
                      <text 
                        x="14" 
                        y="11" 
                        fill={legendSyncTheme.textComponent} 
                        fontSize="9" 
                        fontWeight={legendSyncTheme.fontWeightBody} 
                        fontFamily="monospace" 
                        opacity="0.95"
                      >
                        Comp: ({rx}î + {ry}ĵ)
                      </text>
                    </g>
                  )}

                  {/* Inter-Vector Angle & Dot/Cross Product Legend Row */}
                  <g transform={`translate(10, ${showResultant ? 140 : 118})`}>
                    <line x1="0" y1="-8" x2="195" y2="-8" stroke={legendSyncTheme.dividerColor} strokeWidth="1" strokeDasharray="3 2" />
                    <text 
                      x="0" 
                      y="3" 
                      fill={legendSyncTheme.textColorAngle} 
                      fontSize="9" 
                      fontWeight={legendSyncTheme.fontWeightValue} 
                      fontFamily="monospace"
                      letterSpacing={legendSyncTheme.letterSpacing}
                    >
                      ∠(A,B)={acuteAngleBetween}° | A⃗·B⃗={dotProduct}
                    </text>
                  </g>

                  {/* Automated Sync Contrast Badge at Bottom of SVG Legend */}
                  <g transform={`translate(10, ${showResultant ? 158 : 136})`}>
                    <text 
                      x="0" 
                      y="4" 
                      fill={legendSyncTheme.isHighContrast ? "#00f5ff" : (legendSyncTheme.isLightBg ? "#0284c7" : "#64748b")} 
                      fontSize="8" 
                      fontWeight={legendSyncTheme.fontWeightHeader} 
                      fontFamily="monospace"
                    >
                      SYNC: {legendSyncTheme.contrastLevelLabel}
                    </text>
                  </g>
                </g>
              )}

              {/* Interactive Professor Laser Pointer / Teaching Cursor */}
              {isProfPointerActive && (
                <g 
                  id={`prof-laser-pointer-${instanceId}`}
                  transform={`translate(${profCursor.x}, ${profCursor.y})`}
                  className="pointer-events-none transition-all duration-700 ease-out select-none z-30"
                >
                  {/* Laser Aura Glow */}
                  <circle r="12" fill={isHighContrast ? "rgba(0, 245, 255, 0.18)" : "rgba(239, 68, 68, 0.18)"} stroke={isHighContrast ? "#00f5ff" : "#ef4444"} strokeWidth="1.5" strokeDasharray="3 2" />
                  
                  {/* Core Laser Target Dot */}
                  <circle r="5" fill={isHighContrast ? "#ff007f" : "#ef4444"} stroke="#ffffff" strokeWidth="2" />
                  <circle r="1.5" fill="#ffffff" />
                  
                  {/* Laser Crosshairs */}
                  <line x1="-14" y1="0" x2="-6" y2="0" stroke={isHighContrast ? "#00f5ff" : "#ef4444"} strokeWidth="2" />
                  <line x1="6" y1="0" x2="14" y2="0" stroke={isHighContrast ? "#00f5ff" : "#ef4444"} strokeWidth="2" />
                  <line x1="0" y1="-14" x2="0" y2="-6" stroke={isHighContrast ? "#00f5ff" : "#ef4444"} strokeWidth="2" />
                  <line x1="0" y1="6" x2="0" y2="14" stroke={isHighContrast ? "#00f5ff" : "#ef4444"} strokeWidth="2" />

                  {/* Floating Professor Badge Tag */}
                  <g transform="translate(16, -14)">
                    <rect 
                      x="0" 
                      y="0" 
                      width={Math.max(130, profCursor.activeNode.length * 6 + 24)} 
                      height="20" 
                      rx="5" 
                      fill="#020617" 
                      fillOpacity="0.95" 
                      stroke={isHighContrast ? "#00f5ff" : "#ef4444"} 
                      strokeWidth="1.5" 
                    />
                    <text 
                      x="7" 
                      y="14" 
                      fill="#ffffff" 
                      fontSize="9" 
                      fontWeight="800" 
                      fontFamily="monospace"
                    >
                      🎓 PROF. OMNI: {profCursor.activeNode}
                    </text>
                  </g>
                </g>
              )}
            </svg>
          )}
        </div>

        {/* Real-Time Chalk Draw Canvas Overlay */}
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          className={cn(
            "absolute inset-0 w-full h-full z-20 touch-none transition-opacity duration-200",
            isChalkMode ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-90"
          )}
        />

        {/* Chalk Palette & Controls Drawer (When Chalk Draw Mode is Active) */}
        {isChalkMode && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 px-3 py-2 rounded-2xl bg-slate-950/90 text-slate-100 border border-amber-500/40 shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-top-2 duration-200 max-w-[95%] overflow-x-auto">
            {/* Tool Selection */}
            <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/5">
              <button
                type="button"
                onClick={() => setActiveChalkTool('pen')}
                className={cn(
                  "p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer",
                  activeChalkTool === 'pen' ? "bg-amber-500 text-slate-950 shadow-sm" : "text-slate-400 hover:text-slate-200"
                )}
                title="Freehand Chalk Pen"
              >
                <Pencil size={13} />
                <span className="text-[11px] hidden sm:inline">Chalk</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveChalkTool('arrow')}
                className={cn(
                  "p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer",
                  activeChalkTool === 'arrow' ? "bg-amber-500 text-slate-950 shadow-sm" : "text-slate-400 hover:text-slate-200"
                )}
                title="Ray / Vector Arrow Tool"
              >
                <MoveUpRight size={13} />
                <span className="text-[11px] hidden sm:inline">Vector</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveChalkTool('line')}
                className={cn(
                  "p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer",
                  activeChalkTool === 'line' ? "bg-amber-500 text-slate-950 shadow-sm" : "text-slate-400 hover:text-slate-200"
                )}
                title="Straight Ray / Coordinate Line"
              >
                <Minus size={13} />
                <span className="text-[11px] hidden sm:inline">Ray</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveChalkTool('eraser')}
                className={cn(
                  "p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer",
                  activeChalkTool === 'eraser' ? "bg-rose-500 text-white shadow-sm" : "text-slate-400 hover:text-slate-200"
                )}
                title="Chalk Eraser"
              >
                <Eraser size={13} />
                <span className="text-[11px] hidden sm:inline">Eraser</span>
              </button>
            </div>

            {/* Chalk Color Palette */}
            {activeChalkTool !== 'eraser' && (
              <div className="flex items-center gap-1 px-1 bg-black/40 p-1 rounded-xl border border-white/5">
                {(isHighContrast ? NEON_CHALK_COLORS : CHALK_COLORS).map(c => (
                  <button
                    key={c.name}
                    type="button"
                    onClick={() => setSelectedColor(c.color)}
                    className={cn(
                      "w-5 h-5 rounded-full transition-transform cursor-pointer border",
                      c.bgClass,
                      selectedColor === c.color 
                        ? (isHighContrast 
                            ? "scale-130 border-white ring-2 ring-[#00f5ff] shadow-[0_0_10px_rgba(0,245,255,0.8)]" 
                            : "scale-125 border-white ring-2 ring-amber-400 shadow-md") 
                        : "border-transparent opacity-80 hover:opacity-100 hover:scale-110"
                    )}
                    title={`${c.name} (${c.color})`}
                  />
                ))}
              </div>
            )}

            {/* Stroke Width Selector */}
            <div className="flex items-center gap-1 bg-black/40 px-2 py-1 rounded-xl border border-white/5 text-[11px] font-mono text-slate-300">
              <span className="text-[10px] uppercase text-slate-500 font-sans font-bold">Size:</span>
              <button
                type="button"
                onClick={() => setChalkWidth(2)}
                className={cn("px-1.5 py-0.5 rounded font-bold transition", chalkWidth === 2 ? "bg-amber-500/30 text-amber-300" : "text-slate-400 hover:text-white")}
              >
                2
              </button>
              <button
                type="button"
                onClick={() => setChalkWidth(4)}
                className={cn("px-1.5 py-0.5 rounded font-bold transition", chalkWidth === 4 ? "bg-amber-500/30 text-amber-300" : "text-slate-400 hover:text-white")}
              >
                4
              </button>
              <button
                type="button"
                onClick={() => setChalkWidth(8)}
                className={cn("px-1.5 py-0.5 rounded font-bold transition", chalkWidth === 8 ? "bg-amber-500/30 text-amber-300" : "text-slate-400 hover:text-white")}
              >
                8
              </button>
            </div>

            {/* Action buttons: Undo, Redo & Clear */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleUndoChalk}
                disabled={chalkUndoStack.length === 0}
                className={cn(
                  "p-1.5 rounded-lg transition cursor-pointer border",
                  chalkUndoStack.length > 0 
                    ? "bg-black/40 hover:bg-slate-800 text-slate-200 hover:text-white border-white/10" 
                    : "opacity-40 bg-black/20 text-slate-500 border-transparent cursor-not-allowed"
                )}
                title={`Undo Chalk Annotation (Ctrl+Z)${chalkUndoStack.length > 0 ? ` (${chalkUndoStack.length} in history)` : ''}`}
              >
                <Undo2 size={13} />
              </button>
              <button
                type="button"
                onClick={handleRedoChalk}
                disabled={chalkRedoStack.length === 0}
                className={cn(
                  "p-1.5 rounded-lg transition cursor-pointer border",
                  chalkRedoStack.length > 0 
                    ? "bg-black/40 hover:bg-slate-800 text-slate-200 hover:text-white border-white/10" 
                    : "opacity-40 bg-black/20 text-slate-500 border-transparent cursor-not-allowed"
                )}
                title={`Redo Chalk Annotation (Ctrl+Y / Ctrl+Shift+Z)${chalkRedoStack.length > 0 ? ` (${chalkRedoStack.length} available)` : ''}`}
              >
                <Redo2 size={13} />
              </button>
              <button
                type="button"
                onClick={handleClearChalk}
                className="p-1.5 rounded-lg bg-black/40 hover:bg-rose-950/50 text-rose-400 hover:text-rose-200 transition cursor-pointer border border-rose-500/20"
                title="Wipe Chalkboard (Clear All)"
              >
                <Trash2 size={13} />
              </button>
            </div>
          </div>
        )}

        {/* Floating Interactive Classroom Toolbar - Hidden as per user directive to keep figure clean & unobstructed */}
        {/* Bottom tab removed so diagram is 100% visible and uncluttered */}

        {/* Floating Magnifying Glass Loupe Overlay (Renders when active or hovering over cluttered vector region) */}
        {(isMagnifierActive || isHoveringCluttered) && (() => {
          const mPos = magnifierPos || { clientX: 250, clientY: 180, svgX: 300, svgY: 200 };
          return (
            <div 
              className="pointer-events-none absolute z-40 rounded-full overflow-hidden border-4 transition-all duration-75 ease-out select-none shadow-[0_0_30px_rgba(0,0,0,0.95)]"
              style={{
                width: '210px',
                height: '210px',
                left: `${mPos.clientX - 105}px`,
                top: `${mPos.clientY - 105}px`,
                borderColor: isHighContrast ? '#00f5ff' : '#f59e0b',
                boxShadow: isHighContrast 
                  ? '0 0 30px rgba(0,245,255,0.8), inset 0 0 20px rgba(0,245,255,0.4)' 
                  : '0 0 30px rgba(245,158,11,0.7), inset 0 0 15px rgba(245,158,11,0.3)',
                backgroundColor: '#000000'
              }}
            >
              {/* Magnified High-Contrast SVG Viewport (2.8x Zoom) */}
              <svg
                viewBox={`${mPos.svgX - 35} ${mPos.svgY - 25} 70 50`}
                className="w-full h-full"
              >
                <rect x={mPos.svgX - 60} y={mPos.svgY - 60} width="120" height="120" fill="#000000" />
                
                {/* Grid Lines in Magnifier */}
                <path 
                  d={`M ${mPos.svgX - 60} ${vecA.originY} H ${mPos.svgX + 60} M ${vecA.originX} ${mPos.svgY - 60} V ${mPos.svgY + 60}`} 
                stroke={isHighContrast ? '#00f5ff' : '#64748b'} 
                strokeWidth="1" 
                strokeDasharray="2 2" 
                opacity="0.8"
              />

              {/* High-Contrast Vector A Line */}
              <line
                x1={vecA.originX}
                y1={vecA.originY}
                x2={vecA.tipX}
                y2={vecA.tipY}
                stroke={colorA}
                strokeWidth="3.5"
              />
              <circle cx={vecA.tipX} cy={vecA.tipY} r="3.5" fill={colorA} stroke="#ffffff" strokeWidth="1" />
              <text x={vecA.tipX + 4} y={vecA.tipY - 4} fill={colorA} fontSize="8" fontWeight="black" fontFamily="monospace">A⃗</text>

              {/* High-Contrast Vector B Line */}
              <line
                x1={vecB.originX}
                y1={vecB.originY}
                x2={vecB.tipX}
                y2={vecB.tipY}
                stroke={colorB}
                strokeWidth="3.5"
              />
              <circle cx={vecB.tipX} cy={vecB.tipY} r="3.5" fill={colorB} stroke="#ffffff" strokeWidth="1" />
              <text x={vecB.tipX + 4} y={vecB.tipY - 4} fill={colorB} fontSize="8" fontWeight="black" fontFamily="monospace">B⃗</text>

              {/* High-Contrast Resultant R Line */}
              {showResultant && (
                <line
                  x1={vecA.originX}
                  y1={vecA.originY}
                  x2={resultantTipX}
                  y2={resultantTipY}
                  stroke={colorR}
                  strokeWidth="3"
                  strokeDasharray="3 1.5"
                />
              )}

              {/* Overlap Dimension Line if tips are close */}
              {tipDistance < 60 && (
                <g>
                  <line
                    x1={vecA.tipX}
                    y1={vecA.tipY}
                    x2={vecB.tipX}
                    y2={vecB.tipY}
                    stroke="#ff007f"
                    strokeWidth="1.5"
                    strokeDasharray="2 1"
                  />
                  <text
                    x={(vecA.tipX + vecB.tipX) / 2}
                    y={(vecA.tipY + vecB.tipY) / 2 - 3}
                    fill="#ff007f"
                    fontSize="6"
                    fontWeight="black"
                    textAnchor="middle"
                    fontFamily="monospace"
                  >
                    Δ={tipDistance}u
                  </text>
                </g>
              )}

              {/* Origin Point Anchor */}
              <circle cx={vecA.originX} cy={vecA.originY} r="4" fill={colorOrigin} stroke="#ffffff" strokeWidth="1.5" />

              {/* Magnifier Reticle Crosshair */}
              {magnifierPos && (
                <>
                  <line x1={magnifierPos.svgX - 10} y1={magnifierPos.svgY} x2={magnifierPos.svgX + 10} y2={magnifierPos.svgY} stroke="#ffffff" strokeWidth="1" opacity="0.9" />
                  <line x1={magnifierPos.svgX} y1={magnifierPos.svgY - 10} x2={magnifierPos.svgX} y2={magnifierPos.svgY + 10} stroke="#ffffff" strokeWidth="1" opacity="0.9" />
                  <circle cx={magnifierPos.svgX} cy={magnifierPos.svgY} r="2" fill="none" stroke="#ffffff" strokeWidth="1" />
                </>
              )}
            </svg>

            {/* Top Badge: Magnifier Title */}
            <div className="absolute top-1.5 left-1/2 -translate-x-1/2 bg-black/90 text-[10px] font-mono font-black px-2 py-0.5 rounded-full border border-cyan-400 text-cyan-300 shadow flex items-center gap-1">
              <ZoomIn size={10} className="text-cyan-400" />
              <span>2.8x LENS</span>
            </div>

            {/* Bottom Badge: Coordinate & Overlap Status */}
            <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 bg-black/95 text-[9px] font-mono font-bold px-2 py-0.5 rounded-full border border-amber-400 text-amber-300 whitespace-nowrap shadow">
              {isClutteredRegion ? `⚠️ OVERLAP: Δ=${tipDistance}u` : `(${Math.round(mPos.svgX)}, ${Math.round(mPos.svgY)})`}
            </div>
          </div>
          );
        })()}

        {onExplainFigure && (
          <div className="absolute bottom-3 right-3 z-30 opacity-90 group-hover/viewer:opacity-100 transition-opacity duration-200">
            <button
              type="button"
              onClick={() => onExplainFigure(svgCode, title)}
              title="Explain this diagram"
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:from-indigo-500 hover:via-purple-500 hover:to-indigo-500 text-white font-black text-[11px] shadow-lg border border-indigo-400/40 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles size={12} className="text-amber-300 animate-pulse" />
              <span>Explain Diagram</span>
            </button>
          </div>
        )}
      </div>

      {/* Fullscreen Modal View */}
      {isFullscreen && (
        <div className="fixed inset-0 z-[999] bg-slate-950/95 backdrop-blur-md flex flex-col p-6 animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
            <div className="flex items-center gap-2">
              <Sparkles className="text-indigo-400" size={18} />
              <h3 className="text-base font-extrabold text-white uppercase tracking-wide">
                {title} (Fullscreen Presentation Mode)
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setIsFullscreen(false)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-auto flex items-center justify-center p-6 bg-slate-900 rounded-2xl border border-slate-800 relative">
            <div 
              className={cn(
                "w-full max-w-5xl transition-colors",
                !showGrid && "hide-grid",
                !showLabels && "hide-labels",
                !showResultant && "hide-resultant",
                isAnimating && "is-animating"
              )}
              dangerouslySetInnerHTML={{ __html: cleanSvg }}
            />
          </div>
        </div>
      )}
    </div>
  );
};



