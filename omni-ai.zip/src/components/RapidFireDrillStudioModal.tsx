import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  Zap,
  Target,
  Clock,
  Award,
  Sparkles,
  HelpCircle,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Layers,
  BookOpen,
  Filter,
  CheckCircle2,
  XCircle,
  Send,
  Download,
  Flame,
  BrainCircuit,
  Sliders,
  Maximize2
} from 'lucide-react';
import {
  DrillQuestion,
  RapidFireDrillPackage,
  DrillPlayMode,
  DrillQuestionType,
  DrillRigorLevel
} from '../types/rapidFireDrill';
import {
  SEED_AND_REPRODUCTION_100_DRILL_PACKAGE,
  generateChapterDrillPackage,
  formatQuestionFor3DSmartboard
} from '../services/rapidFireDrillService';
import { generateSpeech, convertPcmToWav } from '../lib/gemini';

interface RapidFireDrillStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme?: string;
  showNotification?: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  onSyncToSmartboard?: (markdownText: string, title?: string) => void;
  currentChapterTopic?: string;
}

export const RapidFireDrillStudioModal: React.FC<RapidFireDrillStudioModalProps> = ({
  isOpen,
  onClose,
  theme = 'dark',
  showNotification = () => {},
  onSyncToSmartboard,
  currentChapterTopic = 'Sexual Reproduction in Flowering Plants (बीज एवं फल निर्माण)'
}) => {
  // Master Active Package
  const [drillPackage, setDrillPackage] = useState<RapidFireDrillPackage>(SEED_AND_REPRODUCTION_100_DRILL_PACKAGE);
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [playMode, setPlayMode] = useState<DrillPlayMode>('socratic_interactive');
  
  // Interaction State per Question
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswerRevealed, setIsAnswerRevealed] = useState<boolean>(false);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [eliminatedOptions, setEliminatedOptions] = useState<string[]>([]);
  const [userScore, setUserScore] = useState<number>(0);
  const [currentStreak, setCurrentStreak] = useState<number>(0);
  const [bestStreak, setBestStreak] = useState<number>(0);
  const [answeredHistory, setAnsweredHistory] = useState<Record<string, { selected: string; isCorrect: boolean }>>({});

  // Timer & Audio
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [languageMode, setLanguageMode] = useState<'bilingual' | 'hindi' | 'english'>('bilingual');
  const [audioVoice, setAudioVoice] = useState<'Kore' | 'Puck' | 'Aoede'>('Kore');
  const [customTopicInput, setCustomTopicInput] = useState<string>(currentChapterTopic);
  const [customQuestionCount, setCustomQuestionCount] = useState<number>(20);
  const [customRigor, setCustomRigor] = useState<string>('neet_standard');
  const [isGeneratingAI, setIsGeneratingAI] = useState<boolean>(false);
  const [selectedFilterType, setSelectedFilterType] = useState<string>('all');

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const currentQ: DrillQuestion | undefined = drillPackage.questions[currentIdx] || drillPackage.questions[0];

  // Timer Effect for Speed Blitz
  useEffect(() => {
    let interval: any = null;
    if (playMode === 'timed_speed_blitz' && isTimerRunning && timeLeft > 0 && !isAnswerRevealed) {
      interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleTimeUp();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [playMode, isTimerRunning, timeLeft, isAnswerRevealed]);

  // Reset per question navigation
  useEffect(() => {
    if (!currentQ) return;
    const history = answeredHistory[currentQ.id];
    if (history) {
      setSelectedOption(history.selected);
      setIsAnswerRevealed(true);
    } else {
      setSelectedOption(null);
      setIsAnswerRevealed(false);
      setShowHint(false);
      setEliminatedOptions([]);
    }
    setTimeLeft(30);
    if (playMode === 'timed_speed_blitz') {
      setIsTimerRunning(true);
    }
  }, [currentIdx, currentQ?.id]);

  const handleTimeUp = () => {
    setIsAnswerRevealed(true);
    setCurrentStreak(0);
    showNotification?.('⏰ Time up on this question!', 'warning');
  };

  const handleOptionSelect = (optionId: string) => {
    if (isAnswerRevealed || !currentQ) return;
    setSelectedOption(optionId);
    setIsAnswerRevealed(true);
    setIsTimerRunning(false);

    const isCorrect = optionId === currentQ.correctOptionId;
    if (isCorrect) {
      const newStreak = currentStreak + 1;
      setCurrentStreak(newStreak);
      if (newStreak > bestStreak) setBestStreak(newStreak);
      setUserScore((prev) => prev + (playMode === 'timed_speed_blitz' ? 10 + Math.floor(timeLeft / 3) : 10));
      showNotification?.(`🎯 Brilliant! Option (${optionId}) is Correct! (+10 pts)`, 'success');
    } else {
      setCurrentStreak(0);
      showNotification?.(`⚠️ Option (${optionId}) is Incorrect. Let's see why!`, 'error');
    }

    setAnsweredHistory((prev) => ({
      ...prev,
      [currentQ.id]: { selected: optionId, isCorrect }
    }));
  };

  const handleApply5050Lifeline = () => {
    if (isAnswerRevealed || !currentQ || eliminatedOptions.length > 0) return;
    const wrongOptions = currentQ.options.filter((o) => !o.isCorrect).map((o) => o.id);
    const toEliminate = wrongOptions.slice(0, 2);
    setEliminatedOptions(toEliminate);
    showNotification?.('✂️ 50:50 Lifeline applied! 2 incorrect options eliminated.', 'info');
  };

  const handleSyncCurrentToSmartboard = () => {
    if (!currentQ) return;
    const md = formatQuestionFor3DSmartboard(currentQ, currentIdx, drillPackage.questions.length);
    if (onSyncToSmartboard) {
      onSyncToSmartboard(md, `Drill Q${currentIdx + 1}: ${currentQ.subtopic}`);
      showNotification?.(`📡 Question ${currentIdx + 1} synced to 3D Smartboard!`, 'success');
    }
  };

  const handlePlayProfessorSpeech = async () => {
    if (isSpeaking) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      setIsSpeaking(false);
      return;
    }

    if (!currentQ) return;
    setIsSpeaking(true);
    try {
      const speechText = isAnswerRevealed
        ? `${currentQ.questionHindi}. The correct answer is Option ${currentQ.correctOptionId}. ${currentQ.professorClarityExplanation.teachingNarrationHindi}. Remember this exam tip: ${currentQ.professorClarityExplanation.misconceptionTrapHindi}`
        : `${currentQ.questionHindi}. Here is a hint: ${currentQ.professorClarityExplanation.socraticHintHindi}. Which option do you choose?`;

      const pcmData = await generateSpeech(speechText, audioVoice);
      if (pcmData) {
        const wavBase64 = convertPcmToWav(pcmData, 24000);
        const audio = new Audio(`data:audio/wav;base64,${wavBase64}`);
        audioRef.current = audio;
        audio.onended = () => setIsSpeaking(false);
        audio.onerror = () => setIsSpeaking(false);
        await audio.play();
      } else {
        setIsSpeaking(false);
      }
    } catch (e) {
      console.warn("Speech generation error:", e);
      setIsSpeaking(false);
    }
  };

  const handleGenerateAIQuestions = async () => {
    if (!customTopicInput.trim()) return;
    setIsGeneratingAI(true);
    showNotification?.(`🤖 Generating ${customQuestionCount} high-yield questions for "${customTopicInput}"...`, 'info');

    try {
      const pkg = await generateChapterDrillPackage(
        customTopicInput,
        drillPackage.subject,
        customQuestionCount,
        customRigor
      );
      setDrillPackage(pkg);
      setCurrentIdx(0);
      setAnsweredHistory({});
      setUserScore(0);
      setCurrentStreak(0);
      showNotification?.(`🎉 Successfully loaded ${pkg.questions.length} questions into the Rapid Fire Studio!`, 'success');
    } catch (err) {
      showNotification?.('❌ Failed to generate custom questions, using master pack.', 'error');
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const filteredQuestions = useMemo(() => {
    if (selectedFilterType === 'all') return drillPackage.questions;
    return drillPackage.questions.filter((q) => q.type === selectedFilterType);
  }, [drillPackage.questions, selectedFilterType]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-6xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 animate-in fade-in zoom-in-95 duration-200">
        
        {/* HEADER BAR */}
        <div className="px-5 py-3.5 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-inner">
              <Zap size={22} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
                  Professor Clarity's 80–100 Rapid Fire Question Drill
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {drillPackage.questions.length} Questions Bank
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  NEET / Board AIIMS Rigor
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-xl">
                {drillPackage.chapterTitleHindi} • {drillPackage.chapterTitleEnglish}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Streak & Score Tracker */}
            <div className="flex items-center gap-3 bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-xl text-xs">
              <div className="flex items-center gap-1 text-amber-400 font-bold">
                <Flame size={15} className="text-amber-500" />
                <span>Streak: {currentStreak}</span>
              </div>
              <div className="w-px h-3.5 bg-slate-700" />
              <div className="flex items-center gap-1 text-emerald-400 font-bold">
                <Award size={15} className="text-emerald-500" />
                <span>Score: {userScore}</span>
              </div>
            </div>

            {/* Sync to 3D Smartboard Button */}
            <button
              onClick={handleSyncCurrentToSmartboard}
              className="px-3 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/40 text-cyan-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              title="Project this question onto the 3D Classroom Smartboard"
            >
              <Send size={13} />
              <span>Project on 3D Board</span>
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-rose-900/40 border border-slate-700 hover:border-rose-500/50 text-slate-400 hover:text-rose-300 flex items-center justify-center transition-all cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* SUB-HEADER CONTROLS & MODE SELECTOR */}
        <div className="px-5 py-2.5 bg-slate-950/70 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Mode Tabs */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 gap-1">
            <button
              onClick={() => setPlayMode('socratic_interactive')}
              className={`px-3 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                playMode === 'socratic_interactive'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BrainCircuit size={13} />
              <span>Socratic Drill</span>
            </button>

            <button
              onClick={() => {
                setPlayMode('timed_speed_blitz');
                setIsTimerRunning(true);
                setTimeLeft(30);
              }}
              className={`px-3 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                playMode === 'timed_speed_blitz'
                  ? 'bg-rose-500 text-white shadow-md font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock size={13} />
              <span>Speed Blitz (30s)</span>
            </button>

            <button
              onClick={() => setPlayMode('exam_trap_buster')}
              className={`px-3 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                playMode === 'exam_trap_buster'
                  ? 'bg-purple-600 text-white shadow-md font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <AlertTriangle size={13} />
              <span>Exam Trap Buster</span>
            </button>

            <button
              onClick={() => setPlayMode('professor_smartboard_lecture')}
              className={`px-3 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                playMode === 'professor_smartboard_lecture'
                  ? 'bg-cyan-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BookOpen size={13} />
              <span>Smartboard Teacher</span>
            </button>
          </div>

          {/* Question Filter & Language Toggle */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1 text-slate-300">
              <Filter size={12} className="mr-1.5 text-slate-400" />
              <select
                value={selectedFilterType}
                onChange={(e) => setSelectedFilterType(e.target.value)}
                className="bg-transparent outline-none font-bold text-xs text-indigo-300 cursor-pointer"
              >
                <option value="all">All Question Types ({drillPackage.questions.length})</option>
                <option value="mcq_single">Single Correct MCQs</option>
                <option value="assertion_reason">Assertion & Reason (AIIMS)</option>
                <option value="multi_statement">Multi-Statement Matching</option>
                <option value="diagram_based">Diagram-Based</option>
              </select>
            </div>

            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5">
              {(['bilingual', 'hindi', 'english'] as const).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setLanguageMode(lang)}
                  className={`px-2 py-0.5 rounded-lg text-[11px] font-bold capitalize transition-all ${
                    languageMode === lang ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* MAIN BODY: 2 COLUMNS (Left: Active Question & Options, Right: Pedagogical Insights & AI Generator) */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          
          {/* LEFT COLUMN: QUESTION CARD & OPTIONS (Cols 1-7) */}
          <div className="lg:col-span-7 border-r border-slate-800 p-5 overflow-y-auto flex flex-col justify-between">
            {currentQ ? (
              <div className="space-y-4">
                
                {/* Question Info Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-indigo-900/40 text-indigo-300 border border-indigo-500/30 text-xs font-black">
                      Question {currentIdx + 1} of {drillPackage.questions.length}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[11px] font-bold">
                      {currentQ.topicTag} • {currentQ.subtopic}
                    </span>
                    {currentQ.examTag && (
                      <span className="px-2 py-0.5 rounded-md bg-rose-950/50 text-rose-300 border border-rose-800/40 text-[10px] font-bold">
                        {currentQ.examTag}
                      </span>
                    )}
                  </div>

                  {/* Blitz Timer Badge */}
                  {playMode === 'timed_speed_blitz' && (
                    <div className={`px-2.5 py-1 rounded-xl text-xs font-black flex items-center gap-1.5 ${
                      timeLeft <= 10 ? 'bg-rose-600/30 text-rose-300 border border-rose-500 animate-pulse' : 'bg-slate-800 text-amber-300 border border-slate-700'
                    }`}>
                      <Clock size={13} />
                      <span>{timeLeft}s</span>
                    </div>
                  )}
                </div>

                {/* Question Text Box */}
                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 shadow-sm space-y-2">
                  {(languageMode === 'bilingual' || languageMode === 'hindi') && (
                    <p className="text-base font-bold text-white leading-relaxed">
                      {currentQ.questionHindi}
                    </p>
                  )}
                  {(languageMode === 'bilingual' || languageMode === 'english') && (
                    <p className="text-sm font-medium text-slate-300 italic leading-relaxed">
                      {currentQ.questionEnglish}
                    </p>
                  )}
                </div>

                {/* Socratic Hint Drawer */}
                {showHint && (
                  <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/40 text-xs text-amber-200 animate-in fade-in duration-150 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-amber-400">
                      <HelpCircle size={14} />
                      <span>Professor Clarity's Socratic Hint:</span>
                    </div>
                    <p className="font-semibold">{currentQ.professorClarityExplanation.socraticHintHindi}</p>
                    <p className="italic text-slate-300">{currentQ.professorClarityExplanation.socraticHintEnglish}</p>
                  </div>
                )}

                {/* Options List */}
                <div className="space-y-2.5 pt-1">
                  {currentQ.options.map((option) => {
                    const isSelected = selectedOption === option.id;
                    const isEliminated = eliminatedOptions.includes(option.id);
                    let optionStyle = "bg-slate-800/60 hover:bg-slate-800 border-slate-700 text-slate-200";

                    if (isAnswerRevealed) {
                      if (option.isCorrect) {
                        optionStyle = "bg-emerald-950/70 border-emerald-500 text-emerald-100 shadow-md ring-1 ring-emerald-400";
                      } else if (isSelected && !option.isCorrect) {
                        optionStyle = "bg-rose-950/70 border-rose-500 text-rose-100 shadow-md ring-1 ring-rose-400";
                      } else {
                        optionStyle = "opacity-50 bg-slate-900 border-slate-800 text-slate-400";
                      }
                    } else if (isEliminated) {
                      optionStyle = "opacity-30 line-through bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed";
                    }

                    return (
                      <button
                        key={option.id}
                        disabled={isAnswerRevealed || isEliminated}
                        onClick={() => handleOptionSelect(option.id)}
                        className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 cursor-pointer ${optionStyle}`}
                      >
                        <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black shrink-0 ${
                          isAnswerRevealed && option.isCorrect
                            ? 'bg-emerald-500 text-slate-950'
                            : isAnswerRevealed && isSelected && !option.isCorrect
                            ? 'bg-rose-500 text-white'
                            : 'bg-slate-700 text-white'
                        }`}>
                          {option.id}
                        </span>

                        <div className="flex-1 space-y-0.5">
                          {(languageMode === 'bilingual' || languageMode === 'hindi') && (
                            <div className="font-bold text-sm text-slate-100">{option.textHindi}</div>
                          )}
                          {(languageMode === 'bilingual' || languageMode === 'english') && (
                            <div className="text-xs text-slate-300 italic">{option.textEnglish}</div>
                          )}

                          {/* Elimination / Diagnostic Reason when Revealed */}
                          {isAnswerRevealed && !option.isCorrect && option.whyWrongHindi && (
                            <div className="text-[11px] text-rose-300/90 pt-1 font-medium flex items-center gap-1">
                              <XCircle size={12} className="shrink-0 text-rose-400" />
                              <span>{option.whyWrongHindi}</span>
                            </div>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Socratic Action Buttons (Lifeline, Audio, Hints) */}
                <div className="flex flex-wrap items-center gap-2 pt-2">
                  {!isAnswerRevealed && (
                    <>
                      <button
                        onClick={() => setShowHint(!showHint)}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <HelpCircle size={14} />
                        <span>{showHint ? 'Hide Socratic Hint' : 'Get Professor Hint'}</span>
                      </button>

                      <button
                        onClick={handleApply5050Lifeline}
                        disabled={eliminatedOptions.length > 0}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                          eliminatedOptions.length > 0
                            ? 'opacity-40 bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                            : 'bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300'
                        }`}
                      >
                        <Sparkles size={14} />
                        <span>50:50 Lifeline (Eliminate 2)</span>
                      </button>
                    </>
                  )}

                  {/* Professor Clarity Speech Audio */}
                  <button
                    onClick={handlePlayProfessorSpeech}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      isSpeaking
                        ? 'bg-rose-600/30 text-rose-300 border border-rose-500/50 animate-pulse'
                        : 'bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/40 text-cyan-300'
                    }`}
                  >
                    {isSpeaking ? <VolumeX size={14} /> : <Volume2 size={14} />}
                    <span>{isSpeaking ? 'Stop Professor Voice' : 'Listen Professor Explanation'}</span>
                  </button>
                </div>

              </div>
            ) : null}

            {/* Bottom Navigation Pagination Bar */}
            <div className="pt-5 border-t border-slate-800/80 flex items-center justify-between">
              <button
                disabled={currentIdx === 0}
                onClick={() => setCurrentIdx((prev) => Math.max(0, prev - 1))}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                  currentIdx === 0
                    ? 'opacity-40 bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed'
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-white'
                }`}
              >
                <ChevronLeft size={15} />
                <span>Previous</span>
              </button>

              {/* Quick Question Number Grid Pills */}
              <div className="flex items-center gap-1 overflow-x-auto max-w-sm px-2 py-1 scrollbar-none">
                {drillPackage.questions.slice(0, 15).map((q, idx) => {
                  const state = answeredHistory[q.id];
                  let btnBg = 'bg-slate-800 text-slate-400 border-slate-700';
                  if (state) {
                    btnBg = state.isCorrect
                      ? 'bg-emerald-600 text-white border-emerald-500 font-black'
                      : 'bg-rose-600 text-white border-rose-500 font-black';
                  } else if (idx === currentIdx) {
                    btnBg = 'bg-indigo-600 text-white border-indigo-400 ring-1 ring-indigo-300 font-black';
                  }

                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentIdx(idx)}
                      className={`w-6 h-6 rounded-lg text-[10px] font-bold border transition-all shrink-0 cursor-pointer ${btnBg}`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
                {drillPackage.questions.length > 15 && (
                  <span className="text-[10px] text-slate-500 font-bold">+{drillPackage.questions.length - 15}</span>
                )}
              </div>

              <button
                disabled={currentIdx >= drillPackage.questions.length - 1}
                onClick={() => setCurrentIdx((prev) => Math.min(drillPackage.questions.length - 1, prev + 1))}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                  currentIdx >= drillPackage.questions.length - 1
                    ? 'opacity-40 bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed'
                    : 'bg-indigo-600 hover:bg-indigo-500 border-indigo-500 text-white'
                }`}
              >
                <span>Next Question</span>
                <ChevronRight size={15} />
              </button>
            </div>

          </div>

          {/* RIGHT COLUMN: PROFESSOR CLARITY PEDAGOGICAL INSIGHTS & AI GENERATOR (Cols 8-12) */}
          <div className="lg:col-span-5 p-5 bg-slate-950/40 overflow-y-auto space-y-4">
            
            {/* Live Explanation & Pedagogy Card */}
            {currentQ && isAnswerRevealed && (
              <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-950/40 to-slate-900 border border-indigo-500/30 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs">
                  <BrainCircuit size={15} />
                  <span>Professor Clarity's Living Explanation</span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-200">
                  <p className="font-semibold text-white leading-relaxed">
                    {currentQ.professorClarityExplanation.teachingNarrationHindi}
                  </p>
                  <p className="italic text-slate-400">
                    {currentQ.professorClarityExplanation.teachingNarrationEnglish}
                  </p>
                </div>

                {/* Misconception Trap Buster */}
                <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-500/30 text-xs text-rose-200 space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-rose-400">
                    <AlertTriangle size={13} />
                    <span>Exam Trap Warning:</span>
                  </div>
                  <p>{currentQ.professorClarityExplanation.misconceptionTrapHindi}</p>
                </div>

                {/* Mnemonic Memory Anchor */}
                {currentQ.professorClarityExplanation.memoryMnemonic && (
                  <div className="p-2.5 rounded-lg bg-amber-950/30 border border-amber-500/30 text-xs text-amber-300 font-mono">
                    💡 <strong>Memory Mnemonic:</strong> {currentQ.professorClarityExplanation.memoryMnemonic}
                  </div>
                )}
              </div>
            )}

            {/* AI Dynamic Drill Generator Card */}
            <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-black text-white">
                  <Sliders size={16} className="text-amber-400" />
                  <span>Generate 20–100 Questions for ANY Topic</span>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-bold">
                  AI Master Architect
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <label className="text-slate-400 font-semibold block mb-1">Topic / Chapter Name:</label>
                  <input
                    type="text"
                    value={customTopicInput}
                    onChange={(e) => setCustomTopicInput(e.target.value)}
                    placeholder="e.g. Cellular Respiration, Photoelectric Effect, Genetics, Organic Chemistry"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-medium focus:border-amber-500 outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-slate-400 font-semibold block mb-1">Question Count:</label>
                    <select
                      value={customQuestionCount}
                      onChange={(e) => setCustomQuestionCount(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-amber-300 font-bold outline-none cursor-pointer"
                    >
                      <option value={20}>20 Questions (Express Drill)</option>
                      <option value={40}>40 Questions (Sprint)</option>
                      <option value={60}>60 Questions (Marathon)</option>
                      <option value={80}>80 Questions (Deep Vault)</option>
                      <option value={100}>100 Questions (Master Chapter)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-400 font-semibold block mb-1">Exam Standard:</label>
                    <select
                      value={customRigor}
                      onChange={(e) => setCustomRigor(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-indigo-300 font-bold outline-none cursor-pointer"
                    >
                      <option value="neet_standard">NEET UG / Medical</option>
                      <option value="board_standard">CBSE Board (NCERT)</option>
                      <option value="jee_advanced">JEE Main & Advanced</option>
                      <option value="olympiad">National Olympiad</option>
                    </select>
                  </div>
                </div>

                <button
                  disabled={isGeneratingAI}
                  onClick={handleGenerateAIQuestions}
                  className={`w-full py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer ${
                    isGeneratingAI
                      ? 'bg-amber-600/50 text-amber-200 animate-pulse'
                      : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950'
                  }`}
                >
                  <Sparkles size={14} />
                  <span>{isGeneratingAI ? 'Generating High-Yield Questions...' : `Generate ${customQuestionCount} Questions Now`}</span>
                </button>
              </div>
            </div>

            {/* Quick Summary & 18 Question Categories Breakdown */}
            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs text-slate-400">
              <div className="font-bold text-slate-200 flex items-center gap-1.5">
                <Target size={14} className="text-emerald-400" />
                <span>18-Category Comprehensive Examination Vault</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                This drill integrates all 18 board & competitive categories: Single MCQs, AIIMS Assertion-Reason, Diagrams, Stepwise Numericals, and 10-Year PYQ traps.
              </p>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
