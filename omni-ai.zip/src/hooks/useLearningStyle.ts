import { useState, useEffect, useCallback } from 'react';
import { LearningStyleProfile, AdaptationStrategy, VARKStyle } from '../modules/learning-style/types';
import { 
  getStoredProfile, 
  setManualOverrideStyle, 
  resetToAutoDetection, 
  subscribeToLearningStyleUpdates 
} from '../modules/learning-style/storage';
import { getAdaptationStrategy } from '../modules/learning-style/adaptationEngine';
import { 
  recordDiagramInteraction, 
  recordTextInteraction, 
  recordAudioInteraction, 
  recordHandsOnInteraction 
} from '../modules/learning-style/signalCollector';

export function useLearningStyle() {
  const [profile, setProfile] = useState<LearningStyleProfile>(getStoredProfile());

  useEffect(() => {
    const unsub = subscribeToLearningStyleUpdates(() => {
      setProfile(getStoredProfile());
    });
    return unsub;
  }, []);

  const adaptation: AdaptationStrategy = getAdaptationStrategy(profile);

  const setManualOverride = useCallback((style: VARKStyle) => {
    const updated = setManualOverrideStyle(style);
    setProfile(updated);
  }, []);

  const resetAutoDetect = useCallback(() => {
    const updated = resetToAutoDetection();
    setProfile(updated);
  }, []);

  return {
    profile,
    adaptation,
    setManualOverride,
    resetAutoDetect,
    recordDiagramInteraction,
    recordTextInteraction,
    recordAudioInteraction,
    recordHandsOnInteraction
  };
}
