// ai-tutor/strategies/LanguageStrategy.ts

export const LANGUAGE_PROMPTS: Record<string, string> = {
  'en': 'Generate the response in English.',
  'hi': 'Generate the response in Hindi (Devanagari script). Use standard Hindi educational and scientific vocabulary. Keep math formulas strictly in standard LaTeX.',
  'ta': 'Generate the response in Tamil (தமிழ்). Use standard Tamil educational terminology. Keep formulas in standard LaTeX.',
  'te': 'Generate the response in Telugu (తెలుగు). Use standard Telugu educational terminology. Keep formulas in standard LaTeX.',
  'bn': 'Generate the response in Bengali (বাংলা). Use standard Bengali educational terminology. Keep formulas in standard LaTeX.',
  'mr': 'Generate the response in Marathi (मराठी). Use standard Marathi educational terminology. Keep formulas in standard LaTeX.',
  'kn': 'Generate the response in Kannada (ಕನ್ನಡ). Use standard Kannada educational terminology. Keep formulas in standard LaTeX.',
  'ml': 'Generate the response in Malayalam (മലയാളം). Use standard Malayalam educational terminology. Keep formulas in standard LaTeX.',
  'gu': 'Generate the response in Gujarati (ગુજરાતી). Use standard Gujarati educational terminology. Keep formulas in standard LaTeX.',
  'pa': 'Generate the response in Punjabi (ਪੰਜਾਬੀ - Gurmukhi). Use standard Punjabi educational terminology. Keep formulas in standard LaTeX.',
  'ur': 'Generate the response in Urdu (اردو). Use standard Urdu educational terminology. Keep formulas in standard LaTeX.',
  'odia': 'Generate the response in Odia (ଓଡ଼ିଆ). Use standard Odia educational terminology. Keep formulas in standard LaTeX.',
  'as': 'Generate the response in Assamese (অসমীয়া). Use standard Assamese educational terminology. Keep formulas in standard LaTeX.',
  'fr': 'Generate the response in French (Français). Use standard academic French curriculum terminology.',
  'de': 'Generate the response in German (Deutsch). Use standard academic German curriculum terminology.',
  'es': 'Generate the response in Spanish (Español). Use standard academic Spanish curriculum terminology.',
};

export const LANGUAGE_NAMES: Record<string, string> = {
  en: 'English',
  hi: 'Hindi (हिन्दी)',
  ta: 'Tamil (தமிழ்)',
  te: 'Telugu (తెలుగు)',
  bn: 'Bengali (বাংলা)',
  mr: 'Marathi (मराठी)',
  kn: 'Kannada (ಕನ್ನಡ)',
  ml: 'Malayalam (മലയാളം)',
  gu: 'Gujarati (ગુજરાતી)',
  pa: 'Punjabi (ਪੰਜਾਬੀ)',
  ur: 'Urdu (اردو)',
  odia: 'Odia (ଓଡ଼ିଆ)',
  as: 'Assamese (অসমীয়া)',
  fr: 'French (Français)',
  de: 'German (Deutsch)',
  es: 'Spanish (Español)',
};

export function buildBilingualInstruction(language: string): string {
  if (language === 'en') return '';
  const langName = LANGUAGE_NAMES[language] || language;
  return `
BILINGUAL CLARITY INSTRUCTION:
Generate the response primarily in ${langName}.
Provide the English technical term in parentheses immediately following the vernacular term.
Example: "प्रकाश संश्लेषण (Photosynthesis) वह प्रक्रिया है..."
Keep all mathematical and chemical equations in standard LaTeX blocks (e.g. $$6CO_2 + 6H_2O \\rightarrow C_6H_{12}O_6 + 6O_2$$).
`;
}
