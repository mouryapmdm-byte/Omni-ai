import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, 
  MessageSquare, 
  Palette, 
  Eraser, 
  Layout, 
  Play, 
  Send, 
  Award, 
  Sparkles, 
  Check, 
  Layers, 
  RefreshCw, 
  Gamepad2, 
  Highlighter, 
  Code, 
  MousePointer, 
  X,
  Volume2,
  Tv,
  Plus,
  Trash2,
  ChevronRight
} from 'lucide-react';

interface Peer {
  id: string;
  name: string;
  color: string;
  avatar: string;
  activity: string;
  score: number;
  cursorX: number;
  cursorY: number;
}

interface Room {
  id: string;
  name: string;
  subject: string;
  activeCount: number;
  description: string;
  suggestedTopics: string[];
}

interface CanvasElement {
  id: string;
  type: 'sketch' | 'codeblock' | 'highlight';
  points?: { x: number; y: number }[];
  text?: string;
  x?: number;
  y?: number;
  color?: string;
  highlightText?: string;
}

interface ChallengeQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface BreakoutRoom {
  id: string;
  name: string;
  partitionName: string;
  partitionFocus: string;
  cognitiveProfile: {
    analytical: number;
    practical: number;
    collaboration: number;
  };
  assignedPeers: string[];
  challenge: {
    title: string;
    description: string;
    steps: { text: string; done: boolean; peerId?: string }[];
    aiCoachTip: string;
  };
}

export const BREAKOUT_ROOMS_BANK: Record<string, BreakoutRoom[]> = {
  'Physics': [
    {
      id: 'breakout-phys-1',
      name: '🌌 Room A: Quantum Operator Singularities',
      partitionName: 'Target Partition: Conceptual & Axiomatic Proofs',
      partitionFocus: 'Analytical Rigor, Hamiltonian Transformations, Spectral Theorem proofs',
      cognitiveProfile: { analytical: 96, practical: 42, collaboration: 88 },
      assignedPeers: ['p1', 'p3'], // Zuri, Aaliyah
      challenge: {
        title: 'Hamiltonian Eigenvalue Decryption',
        description: 'Prove the stability boundary of the quantum wave equation under negative energy potentials.',
        steps: [
          { text: 'Formulate the kinetic operator matrix in infinite dimensions', done: true, peerId: 'p1' },
          { text: 'Solve for the boundary boundary constraints where Ψ(±∞) = 0', done: false },
          { text: 'Prove orthogonality of non-degenerate energy eigenstates', done: false, peerId: 'p3' }
        ],
        aiCoachTip: 'Recall that for Bound States, energy (E) must be strictly less than potential V at infinity. Normalize Ψ before solving the eigenvalue matrix.'
      }
    },
    {
      id: 'breakout-phys-2',
      name: '⚙️ Room B: Numerical Wave Packet Simulators',
      partitionName: 'Target Partition: Computational & Systems Synthesis',
      partitionFocus: 'Discretized Waveforms, Flux Integrals, Empirical Modeling',
      cognitiveProfile: { analytical: 52, practical: 94, collaboration: 91 },
      assignedPeers: ['p2', 'p4'], // Chen, Devon
      challenge: {
        title: 'Wave Packet Propagation Code',
        description: 'Implement a real-time discretization function to calculate flux density vector movements.',
        steps: [
          { text: 'Construct a spatial mesh with grid step dx = 0.05', done: true, peerId: 'p2' },
          { text: 'Incorporate the Ampere-Maxwell time-rate displacement current factor', done: false },
          { text: 'Simulate packet collision and log the transmission coefficient', done: false, peerId: 'p4' }
        ],
        aiCoachTip: 'Verify that your temporal step dt satisfies the Courant-Friedrichs-Lewy (CFL) condition for stable numerical propagation.'
      }
    }
  ],
  'Mathematics': [
    {
      id: 'breakout-math-1',
      name: '🧠 Room A: Transcendental Topology & Limits',
      partitionName: 'Target Partition: Abstract Rigor & Structural Axioms',
      partitionFocus: 'Epsilon-Delta bounds, continuous manifolds, open covers',
      cognitiveProfile: { analytical: 98, practical: 38, collaboration: 85 },
      assignedPeers: ['p1', 'p3'], // Zuri, Aaliyah
      challenge: {
        title: 'Manifold Edge Continuity Proof',
        description: 'Verify boundary continuity on a non-orientable topological manifold.',
        steps: [
          { text: 'Define the open cover maps for the neighborhood', done: true, peerId: 'p1' },
          { text: 'Formulate the continuous transition function Jacobian', done: false },
          { text: 'Establish epsilon-delta parameters for boundary limits', done: false, peerId: 'p3' }
        ],
        aiCoachTip: 'Remember that topological boundaries are mapped by continuous homeomorphisms. Ensure the transition maps are smooth.'
      }
    },
    {
      id: 'breakout-math-2',
      name: '📊 Room B: Applied Algorithmic Gradient Ascent',
      partitionName: 'Target Partition: Systems Optimization & Multivariable Solvers',
      partitionFocus: 'Iterative Taylor expansions, Hessian optimization, multi-dimensional paths',
      cognitiveProfile: { analytical: 45, practical: 96, collaboration: 92 },
      assignedPeers: ['p2', 'p4'], // Chen, Devon
      challenge: {
        title: 'Hessian Optimization convergence loop',
        description: 'Develop an algorithm to find the exact extrema of a multivariable density field.',
        steps: [
          { text: 'Map the Jacobian partial derivatives matrix', done: true, peerId: 'p2' },
          { text: 'Formulate the Hessian second-order directional test', done: false },
          { text: 'Simulate convergence with custom learning rate alpha = 0.01', done: false, peerId: 'p4' }
        ],
        aiCoachTip: 'Check if the Hessian matrix is positive definite at the critical point to guarantee a local minimum.'
      }
    }
  ],
  'Chemistry': [
    {
      id: 'breakout-chem-1',
      name: '🔬 Room A: Quantum Molecular & Stereochemical Rigor',
      partitionName: 'Target Partition: Electron Densities & Orbital Configurations',
      partitionFocus: 'SN2 transition trajectories, activation limits, pi-bond delocalization',
      cognitiveProfile: { analytical: 92, practical: 48, collaboration: 89 },
      assignedPeers: ['p1', 'p3'], // Zuri, Aaliyah
      challenge: {
        title: 'SN2 Transition State Activation Barrier',
        description: 'Calculate transition state thermodynamics during a backside nucleophilic attack.',
        steps: [
          { text: 'Formulate the overlapping molecular orbital coordinate system', done: true, peerId: 'p1' },
          { text: 'Model the electrostatic repulsion energy at d = 1.2 Angstroms', done: false },
          { text: 'Determine the Arrhenius frequency factor for the steric path', done: false, peerId: 'p3' }
        ],
        aiCoachTip: 'The transition state represents the energetic peak. A carbon atom momentarily exhibits sp2 hybridization with p-orbital overlaps.'
      }
    },
    {
      id: 'breakout-chem-2',
      name: '🧪 Room B: Applied Catalyst Kinetics & Yield Optimization',
      partitionName: 'Target Partition: Microfluidic Flow & Equilibrium Balance',
      partitionFocus: 'Reagent kinetics, Gibbs free energy decay profiles, throughput loops',
      cognitiveProfile: { analytical: 48, practical: 95, collaboration: 94 },
      assignedPeers: ['p2', 'p4'], // Chen, Devon
      challenge: {
        title: 'Catalyst Reaction Chamber Simulation',
        description: 'Optimize chemical output throughput by tuning temperature and pressure bounds.',
        steps: [
          { text: 'Input steady-state concentration differential formulas', done: true, peerId: 'p2' },
          { text: 'Perform run-time pressure-density balance equations', done: false },
          { text: 'Analyze Gibbs decay rates to prevent chemical reversal', done: false, peerId: 'p4' }
        ],
        aiCoachTip: 'Use the van t Hoff relation to adjust the equilibrium constant K based on temperature steps.'
      }
    }
  ]
};

const STUDY_ROOMS: Room[] = [
  {
    id: 'room-physics',
    name: '🚀 Quantum Field & AP Physics Co-Lab',
    subject: 'Physics',
    activeCount: 4,
    description: 'Deconstruct Maxwell Equations, quantum operators, and wave packets collaboratively.',
    suggestedTopics: ['Hamiltonian Operators', 'Schrödinger Vector Proof', 'Flux Densities']
  },
  {
    id: 'room-math',
    name: '📐 Advanced Calculus & Topology Circle',
    subject: 'Mathematics',
    activeCount: 3,
    description: 'Solve infinite Taylor series, triple integrals, and vector field orientations.',
    suggestedTopics: ['Green Theorem Integrations', 'Gradient Ascent Lines', 'Epsilon-Delta Continuity']
  },
  {
    id: 'room-chem',
    name: '🧪 Organic Synthesis & Kinetic Forum',
    subject: 'Chemistry',
    activeCount: 5,
    description: 'Co-sketch nucleophilic back-attacks, thermodynamic yields, and catalyst mechanisms.',
    suggestedTopics: ['SN2 Transition States', 'Gibbs Free Energy Yields', 'Aromatic Rings']
  }
];

const INITIAL_PEERS: Peer[] = [
  { id: 'p1', name: 'Zuri', color: '#6366f1', avatar: '🦊', activity: 'Drawing Hamiltonian...', score: 140, cursorX: 120, cursorY: 150 },
  { id: 'p2', name: 'Chen', color: '#10b981', avatar: '🐼', activity: 'Drafting Code Nodes', score: 210, cursorX: 420, cursorY: 210 },
  { id: 'p3', name: 'Aaliyah', color: '#f59e0b', avatar: '🦁', activity: 'Highlighting Excerpt', score: 185, cursorX: 280, cursorY: 80 },
  { id: 'p4', name: 'Devon', color: '#ec4899', avatar: '🐨', activity: 'Thinking...', score: 95, cursorX: 550, cursorY: 340 }
];

const EXCERPTS = [
  "Maxwell’s Equation 4 (Ampere-Maxwell Law): ∇ × B = μ₀J + μ₀ε₀(∂E/∂t). The curl of the magnetic field B is proportional to the electric current density J and the time-rate-of-change of the electric field E.",
  "The fundamental theorem of calculus states that if f is continuous on [a, b], then the function g defined by g(x) = ∫_a^x f(t) dt has derivative g'(x) = f(x).",
  "Markov Chains satisfy the Markov Property: P(X_{n+1} = x | X_1 = x_1, X_2 = x_2, ..., X_n = x_n) = P(X_{n+1} = x | X_n = x_n), capturing zero-history future paths."
];

const CHALLENGES_BANK: Record<string, ChallengeQuestion[]> = {
  'Physics': [
    {
      id: 1,
      question: 'Which quantum mechanical operator corresponds to the physical variable of total system energy?',
      options: ['Momentum Operator (p)', 'Hamiltonian Operator (H)', 'Position Operator (x)', 'Laplacian Operator (Δ)'],
      correctIndex: 1,
      explanation: 'The Hamiltonian operator (H) is the quantum operator corresponding to the total energy of the physical system, including kinetic and potential fields.'
    },
    {
      id: 2,
      question: 'What term defines the specific magnetic flux density phenomenon where ferromagnetic materials retain magnetization after external fields depart?',
      options: ['Hysteresis', 'Superconductivity', 'Diamagnetism', 'Paramagnetic decay'],
      correctIndex: 0,
      explanation: 'Hysteresis is the lagging of magnetization of ferromagnetic substances behind the magnetizing force, meaning magnetization is preserved.'
    }
  ],
  'Mathematics': [
    {
      id: 1,
      question: 'What does the divergence theorem (Gauss Theorem) convert a flux surface integral into?',
      options: ['A line integral along boundaries', 'A triple volume integral of divergence', 'A double curl coordinate plane', 'A scalar quotient of partials'],
      correctIndex: 1,
      explanation: 'Gauss’s Divergence Theorem converts a closed surface flux integral into a triple volume integral of the divergence of that vector field over the bounded region.'
    },
    {
      id: 2,
      question: 'Which classification of infinite series diverges despite the limit of the nth term approaching zero?',
      options: ['Geometric Series with r < 1', 'Harmonic Series (Σ 1/n)', 'Telescoping Series', 'Power series in convergence intervals'],
      correctIndex: 1,
      explanation: 'The harmonic series Σ 1/n diverges to infinity, despite the fact that its individual terms lim (1/n) approach 0.'
    }
  ],
  'Chemistry': [
    {
      id: 1,
      question: 'Which reagent is universally utilized to convert primary alcohols into aldehydes without over-oxidizing to carboxylic acids?',
      options: ['PCC (Pyridinium chlorochromate)', 'KMnO4 (Potassium Permanganate)', 'CrO3 in sulfuric acid', 'NaOH'],
      correctIndex: 0,
      explanation: 'Pyridinium chlorochromate (PCC) is a mild oxidizing agent that selectively oxidizes primary alcohols to aldehydes, halting before carboxylic formation.'
    },
    {
      id: 2,
      question: 'What is the hybridization configuration of each carbon atom in a standard benzene resonance ring?',
      options: ['sp3', 'sp2', 'sp', 'dsp2'],
      correctIndex: 1,
      explanation: 'Benzene carbons are each bonded to two other carbons and one hydrogen, requiring three coplanar sp2 hybrid orbitals, forming a delocalized pi-cloud.'
    }
  ]
};

export const CollaborativeRooms: React.FC<{ theme: 'light' | 'dark' }> = ({ theme }) => {
  // Rooms & Peers States
  const [currentRoom, setCurrentRoom] = useState<Room>(STUDY_ROOMS[0]);
  const [peers, setPeers] = useState<Peer[]>(INITIAL_PEERS);
  const [roomLogs, setRoomLogs] = useState<string[]>([
    '🎉 Study Room loaded.',
    '🦊 Zuri connected to the co-working canvas.',
    '🐼 Chen entered the workspace with Code diagram blocks.'
  ]);

  // Drawing Canvas States
  const [toolMode, setToolMode] = useState<'pen' | 'eraser' | 'codeblock' | 'highlight'>('pen');
  const [brushColor, setBrushColor] = useState<string>('#6366f1');
  const [elements, setElements] = useState<CanvasElement[]>([
    // Prefilled diagrams
    { id: '1', type: 'codeblock', text: 'Initialize Vector (dx, dy)', x: 120, y: 110, color: '#3b82f6' },
    { id: '2', type: 'codeblock', text: 'Map Schrödinger Weights', x: 120, y: 190, color: '#6366f1' },
    { id: '3', type: 'highlight', highlightText: '∇ × B = μ₀J + μ₀ε₀(∂E/∂t)', x: 260, y: 50 }
  ]);

  // Temporary Sketch State
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [currentPoints, setCurrentPoints] = useState<{ x: number; y: number }[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Excerpt state
  const [excerptIndex, setExcerptIndex] = useState<number>(0);

  // Chat message feed
  const [chatInput, setChatInput] = useState<string>('');
  const [chatMessages, setChatMessages] = useState<{ sender: string; avatar: string; color: string; text: string; time: string }[]>([
    { sender: 'Zuri', avatar: '🦊', color: '#6366f1', text: 'Let\'s collaborate on this wave function formula', time: '11:15' },
    { sender: 'Chen', avatar: '🐼', color: '#10b981', text: 'I am mapping the state coordinates inside code blocks now', time: '11:16' }
  ]);

  // Peer Challenge Arena State
  const [challengeMode, setChallengeMode] = useState<boolean>(false);
  const [challengeSubject, setChallengeSubject] = useState<string>('Physics');
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState<number>(0);
  const [playerSelectedAns, setPlayerSelectedAns] = useState<number | null>(null);
  const [peerAnswers, setPeerAnswers] = useState<Record<string, { answer: number; time: number; correct: boolean }>>({});
  const [challengeActive, setChallengeActive] = useState<boolean>(false);
  const [quizTimer, setQuizTimer] = useState<number>(15);

  // AI Breakout Rooms states
  const [subMode, setSubMode] = useState<'canvas' | 'breakouts'>('canvas');
  const [selectedBreakoutIdx, setSelectedBreakoutIdx] = useState<number>(0);
  
  // Track progress and completed steps for all breakout rooms
  const [breakoutRoomsProgress, setBreakoutRoomsProgress] = useState<Record<string, { progress: number; stepsDone: boolean[] }>>({
    'breakout-phys-1': { progress: 35, stepsDone: [true, false, false] },
    'breakout-phys-2': { progress: 40, stepsDone: [true, false, false] },
    'breakout-math-1': { progress: 35, stepsDone: [true, false, false] },
    'breakout-math-2': { progress: 40, stepsDone: [true, false, false] },
    'breakout-chem-1': { progress: 35, stepsDone: [true, false, false] },
    'breakout-chem-2': { progress: 40, stepsDone: [true, false, false] }
  });

  // Track collaborative contribution logs in the breakout room
  const [breakoutLogs, setBreakoutLogs] = useState<Record<string, string[]>>({
    'breakout-phys-1': [
      '🤖 AI Coach: Welcome to the Theory Partition! Your team profile has high Analytical limits.',
      '🦊 Zuri completed step 1: Formulated the kinetic operator matrix.'
    ],
    'breakout-phys-2': [
      '🤖 AI Coach: Welcome to the Systems Partition! Focus is on numerical mesh simulations.',
      '🐼 Chen completed step 1: Constructed spatial grid mesh (dx=0.05).'
    ],
    'breakout-math-1': [
      '🤖 AI Coach: Abstract manifold rigor mode engaged.',
      '🦊 Zuri defined open cover maps.'
    ],
    'breakout-math-2': [
      '🤖 AI Coach: Multivariable Hessian solver initialized.',
      '🐼 Chen completed Step 1: Constructed the Jacobian vector gradient.'
    ],
    'breakout-chem-1': [
      '🤖 AI Coach: Electron orbital stereochemistry partition active.',
      '🦊 Zuri mapped overlapping MO orbitals.'
    ],
    'breakout-chem-2': [
      '🤖 AI Coach: Microfluidic flow balance optimization active.',
      '🐼 Chen entered the differential concentration parameters.'
    ]
  });

  const [customBreakoutSolution, setCustomBreakoutSolution] = useState<string>('');
  const [isRecalibrating, setIsRecalibrating] = useState<boolean>(false);

  // Simulated peer breakout contributions
  useEffect(() => {
    if (subMode !== 'breakouts') return;

    const interval = setInterval(() => {
      const currentSubject = currentRoom.subject;
      const currentBreakouts = BREAKOUT_ROOMS_BANK[currentSubject] || BREAKOUT_ROOMS_BANK['Physics'];
      const activeBreakout = currentBreakouts[selectedBreakoutIdx];
      if (!activeBreakout) return;

      const stateKey = activeBreakout.id;
      const currentState = breakoutRoomsProgress[stateKey];
      if (!currentState) return;

      // Find an incomplete step
      const incompleteIdx = currentState.stepsDone.findIndex(done => !done);
      if (incompleteIdx === -1) return; // All done!

      const assignedPeers = activeBreakout.assignedPeers || [];
      const peerId = assignedPeers.length > 0 ? assignedPeers[Math.floor(Math.random() * assignedPeers.length)] : null;
      const peerObj = (peerId ? peers.find(p => p.id === peerId) : null) || peers[0] || { avatar: '👤', name: 'Classmate' };

      const newStepsDone = [...currentState.stepsDone];
      newStepsDone[incompleteIdx] = true;

      const finishedCount = newStepsDone.filter(Boolean).length;
      const totalSteps = newStepsDone.length || 1;
      const newProgress = Math.round((finishedCount / totalSteps) * 100);

      setBreakoutRoomsProgress(prev => ({
        ...prev,
        [stateKey]: {
          progress: newProgress,
          stepsDone: newStepsDone
        }
      }));

      const stepText = activeBreakout.challenge.steps[incompleteIdx]?.text || 'Task';
      const logMsg = `${peerObj.avatar} ${peerObj.name} completed Step ${incompleteIdx + 1}: ${stepText} (+${Math.round(100 / totalSteps)}% progress)`;
      
      setBreakoutLogs(prev => ({
        ...prev,
        [stateKey]: [logMsg, ...(prev[stateKey] || [])]
      }));

    }, 12000);

    return () => clearInterval(interval);
  }, [subMode, selectedBreakoutIdx, currentRoom, breakoutRoomsProgress, peers]);

  // Peer Simulation logic triggers
  useEffect(() => {
    // Periodically update simulated peer cursors and activities to bring the board alive
    const peerInterval = setInterval(() => {
      setPeers(prev => prev.map(p => {
        // Randomly nudge coordinates slightly
        const deltaX = (Math.random() - 0.5) * 35;
        const deltaY = (Math.random() - 0.5) * 35;
        const newX = Math.min(680, Math.max(20, p.cursorX + deltaX));
        const newY = Math.min(380, Math.max(20, p.cursorY + deltaY));

        return {
          ...p,
          cursorX: Math.round(newX),
          cursorY: Math.round(newY)
        };
      }));
    }, 4000);

    // Occasional simulated logs/chat messages
    const activityInterval = setInterval(() => {
      const activePeers = ['Zuri', 'Chen', 'Aaliyah', 'Devon'];
      const chosenPeer = activePeers[Math.floor(Math.random() * activePeers.length)];
      const peerData = peers.find(p => p.name === chosenPeer);
      const colors = ['#6366f1', '#10b981', '#f59e0b', '#ec4899'];
      const avatars = ['🦊', '🐼', '🦁', '🐨'];
      const pIndex = activePeers.indexOf(chosenPeer);

      const peerActions = [
        `sketched a formula vector.`,
        `moved a logical connection coordinate.`,
        `is highlighting textbook excerpt lines.`,
        `checked classroom parameters.`
      ];
      const peerChats = [
        "This formula looks perfectly scaled now!",
        "Can we check the limit equations next?",
        "Our score margins are looking stellar!",
        "Agreed. Let's do a peer challenge round!",
        "Check out my block diagram layout!"
      ];

      const action = peerActions[Math.floor(Math.random() * peerActions.length)];
      const chatText = peerChats[Math.floor(Math.random() * peerChats.length)];

      // Alternate logging and chatting
      if (Math.random() > 0.5) {
        setRoomLogs(prev => [`📢 ${chosenPeer} ${action}`, ...prev.slice(0, 8)]);
      } else {
        setChatMessages(prev => [
          ...prev,
          {
            sender: chosenPeer,
            avatar: avatars[pIndex] || '🦊',
            color: colors[pIndex] || '#6366f1',
            text: chatText,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ].slice(-15)); // keep max 15
      }

      // Sometimes draw a simulated peer sketch element!
      if (Math.random() > 0.75) {
        const idStr = 'peer-sketch-' + Math.random().toString(36).slice(2, 6);
        const xOffset = Math.random() * 200 + 350;
        const yOffset = Math.random() * 150 + 100;
        setElements(prev => [
          ...prev,
          {
            id: idStr,
            type: 'sketch',
            points: [
              { x: xOffset, y: yOffset },
              { x: xOffset + 30, y: yOffset + 20 },
              { x: xOffset + 60, y: yOffset }
            ],
            color: colors[pIndex] || '#6366f1'
          }
        ]);
      }

    }, 9000);

    return () => {
      clearInterval(peerInterval);
      clearInterval(activityInterval);
    };
  }, [peers]);

  // Quiz timer count down logic
  useEffect(() => {
    let t: any;
    if (challengeActive && quizTimer > 0) {
      t = setTimeout(() => {
        setQuizTimer(prev => prev - 1);
      }, 1000);
    } else if (challengeActive && quizTimer === 0) {
      // Trigger automatic peer answers if they haven't yet
      resolveTurn();
    }
    return () => clearTimeout(t);
  }, [quizTimer, challengeActive]);

  // Re-render sketch paths onto HTML5 canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear and draw
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw grid background for a tech blueprint feel
    ctx.strokeStyle = theme === 'dark' ? '#1e293b' : '#f1f5f9';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvas.width; i += 20) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, canvas.height);
      ctx.stroke();
    }
    for (let j = 0; j < canvas.height; j += 20) {
      ctx.beginPath();
      ctx.moveTo(0, j);
      ctx.lineTo(canvas.width, j);
      ctx.stroke();
    }

    // Draw saved sketch elements
    elements.forEach(el => {
      if (el.type === 'sketch' && el.points && el.points.length > 0) {
        ctx.strokeStyle = el.color || '#6366f1';
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(el.points[0].x, el.points[0].y);
        for (let i = 1; i < el.points.length; i++) {
          ctx.lineTo(el.points[i].x, el.points[i].y);
        }
        ctx.stroke();
      }
    });

    // Draw ongoing drawing
    if (isDrawing && currentPoints.length > 0) {
      ctx.strokeStyle = brushColor;
      ctx.lineWidth = toolMode === 'eraser' ? 15 : 3;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(currentPoints[0].x, currentPoints[0].y);
      for (let i = 1; i < currentPoints.length; i++) {
        ctx.lineTo(currentPoints[i].x, currentPoints[i].y);
      }
      ctx.stroke();
    }

  }, [elements, isDrawing, currentPoints, brushColor, theme, toolMode]);

  // Drawing events
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (toolMode === 'pen' || toolMode === 'eraser') {
      setIsDrawing(true);
      setCurrentPoints([{ x, y }]);
    } else if (toolMode === 'codeblock') {
      const codeOptions = [
        "Initialize Integrals",
        "Define Boundary [0, π]",
        "Evaluate Vector divergence",
        "Print Entropy state",
        "Run recursion call stack"
      ];
      const randomText = codeOptions[Math.floor(Math.random() * codeOptions.length)];
      setElements(prev => [
        ...prev,
        {
          id: 'code-' + Math.random().toString(36).slice(2, 6),
          type: 'codeblock',
          text: randomText,
          x,
          y,
          color: brushColor
        }
      ]);
      setRoomLogs(prev => [`💻 Placed code block: "${randomText}"`, ...prev]);
    } else if (toolMode === 'highlight') {
      const currentExcerptText = EXCERPTS[excerptIndex];
      setElements(prev => [
        ...prev,
        {
          id: 'hl-' + Math.random().toString(36).slice(2, 6),
          type: 'highlight',
          highlightText: currentExcerptText.slice(0, 30) + '...',
          x,
          y
        }
      ]);
      setRoomLogs(prev => [`🖋️ Highlighted: "${currentExcerptText.slice(0, 20)}..."`, ...prev]);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setCurrentPoints(prev => [...prev, { x, y }]);
  };

  const handleMouseUp = () => {
    if (!isDrawing) return;
    setIsDrawing(false);

    if (currentPoints.length > 0) {
      setElements(prev => [
        ...prev,
        {
          id: 'sketch-' + Math.random().toString(36).slice(2, 6),
          type: 'sketch',
          points: currentPoints,
          color: toolMode === 'eraser' ? (theme === 'dark' ? '#0f172a' : '#ffffff') : brushColor
        }
      ]);
    }
    setCurrentPoints([]);
  };

  // Change active study room
  const handleRoomSelect = (room: Room) => {
    setCurrentRoom(room);
    setChallengeSubject(room.subject);
    setRoomLogs(prev => [`🚪 Moved to ${room.name}`, ...prev]);
  };

  // Draggable-like removal of items
  const removeElement = (id: string) => {
    setElements(prev => prev.filter(el => el.id !== id));
  };

  // Clear Canvas entirely
  const clearCanvas = () => {
    setElements([]);
    setRoomLogs(prev => ['🧹 Cleared the whiteboard canvas.', ...prev]);
  };

  // Post chat message
  const submitMessage = () => {
    if (!chatInput.trim()) return;
    setChatMessages(prev => [
      ...prev,
      {
        sender: 'You',
        avatar: '🎓',
        color: '#6366f1',
        text: chatInput,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    setChatInput('');
  };

  // Challenge Mode Functions
  const startChallengeMode = () => {
    setChallengeMode(true);
    setChallengeActive(true);
    setPlayerSelectedAns(null);
    setPeerAnswers({});
    setQuizTimer(15);
    setCurrentQuestionIdx(0);
  };

  const submitQuizAnswer = (ansIdx: number) => {
    if (playerSelectedAns !== null) return;
    setPlayerSelectedAns(ansIdx);

    const questionsList = CHALLENGES_BANK[challengeSubject] || CHALLENGES_BANK['Physics'];
    const activeQ = questionsList[currentQuestionIdx];
    const isCorrect = ansIdx === activeQ.correctIndex;

    // Simulate peer responses instantly or staggered
    const peersList = ['Zuri', 'Chen', 'Aaliyah', 'Devon'];
    const pAnswers: Record<string, { answer: number; time: number; correct: boolean }> = {};
    
    peersList.forEach(peer => {
      // Pick random option with weight to accuracy
      const rand = Math.random();
      let answerPick = activeQ.correctIndex;
      if (rand > 0.75) {
        // Pick wrong option
        answerPick = (activeQ.correctIndex + 1) % activeQ.options.length;
      }
      pAnswers[peer] = {
        answer: answerPick,
        time: Math.round(Math.random() * 8 + 2),
        correct: answerPick === activeQ.correctIndex
      };
    });

    setPeerAnswers(pAnswers);

    // Dynamic state scoring updates
    if (isCorrect) {
      setPeers(prev => prev.map(p => p)); // self gets simulated points
    }

    setPeers(prev => prev.map(p => {
      const match = pAnswers[p.name];
      if (match && match.correct) {
        return { ...p, score: p.score + 50, activity: 'Answered correctly!' };
      } else if (match) {
        return { ...p, activity: 'Failed answer challenge.' };
      }
      return p;
    }));
  };

  const resolveTurn = () => {
    // If player skipped
    if (playerSelectedAns === null) {
      setPlayerSelectedAns(-1); // marked as skipped
    }
  };

  const nextChallengeQuestion = () => {
    const questionsList = CHALLENGES_BANK[challengeSubject] || CHALLENGES_BANK['Physics'];
    if (currentQuestionIdx + 1 < questionsList.length) {
      setCurrentQuestionIdx(prev => prev + 1);
      setPlayerSelectedAns(null);
      setPeerAnswers({});
      setQuizTimer(15);
    } else {
      // Finished
      setChallengeActive(false);
    }
  };

  const activeQuestions = CHALLENGES_BANK[challengeSubject] || CHALLENGES_BANK['Physics'];

  return (
    <div id="colab-rooms-root" className="flex flex-col h-full overflow-y-auto pr-1">
      
      {/* Subject Room Selector Row */}
      <div id="rooms-deck" className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
        {STUDY_ROOMS.map(room => (
          <button
            id={`room-select-${room.id}`}
            key={room.id}
            onClick={() => handleRoomSelect(room)}
            className={`p-3.5 text-left rounded-2xl border transition-all cursor-pointer ${
              currentRoom.id === room.id
                ? 'bg-indigo-600 text-white border-indigo-700 shadow-md ring-2 ring-indigo-500/20'
                : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-500/50 text-slate-800 dark:text-slate-200'
            }`}
          >
            <div className="flex justify-between items-start gap-1 mb-1">
              <span className="text-xs font-black uppercase tracking-wider">{room.subject} Team</span>
              <span className={`px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest uppercase ${
                currentRoom.id === room.id ? 'bg-white/20 text-white' : 'bg-indigo-500/10 text-indigo-500'
              }`}>
                ● {room.activeCount} Classmates Active
              </span>
            </div>
            <h4 className="text-xs font-black line-clamp-1 mb-1">{room.name}</h4>
            <p className={`text-[10px] leading-snug line-clamp-2 ${
              currentRoom.id === room.id ? 'text-indigo-100' : 'text-slate-500'
            }`}>
              {room.description}
            </p>
          </button>
        ))}
      </div>

      {/* Main Assembly View vs AI Breakout Rooms mode switcher */}
      <div className="flex items-center gap-2 mb-4 bg-slate-100 dark:bg-slate-900/60 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setSubMode('canvas')}
          className={`flex-1 py-2 rounded-lg text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
            subMode === 'canvas'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Layout size={14} />
          🏛️ General Assembly Canvas
        </button>
        <button
          onClick={() => setSubMode('breakouts')}
          className={`flex-1 py-2 rounded-lg text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer relative ${
            subMode === 'breakouts'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Sparkles size={14} className="text-yellow-400" />
          ⚡ AI-Led Breakout Rooms
          <span className="absolute top-1.5 right-3 flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
          </span>
        </button>
      </div>

      <div id="colab-main-grid" className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Left Column: Presence & Canvas Workspace (Col 8) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          
          {subMode === 'canvas' ? (
            <>
              {/* Section: Co-Working Board Canvas */}
              <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Palette size={15} className="text-indigo-500" />
                      Co-Working Board Canvas
                    </h3>
                    <p className="text-[10px] text-slate-500 mt-0.5">Collaboratively sketch formulas, highlight excerpts, and connect logic flow diagrams.</p>
                  </div>

                  {/* Whiteboard Toolbox Controls */}
                  <div className="flex items-center gap-1 flex-wrap">
                    <button
                      id="tool-pen"
                      onClick={() => setToolMode('pen')}
                      className={`p-2 rounded-lg transition-all cursor-pointer ${
                        toolMode === 'pen' ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-850 text-slate-500 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                      }`}
                      title="Drawing Pen Tool"
                    >
                      <Palette size={13} />
                    </button>
                    <button
                      id="tool-eraser"
                      onClick={() => setToolMode('eraser')}
                      className={`p-2 rounded-lg transition-all cursor-pointer ${
                        toolMode === 'eraser' ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-850 text-slate-500 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                      }`}
                      title="Whiteboard Eraser"
                    >
                      <Eraser size={13} />
                    </button>
                    <button
                      id="tool-codeblock"
                      onClick={() => setToolMode('codeblock')}
                      className={`p-2 rounded-lg transition-all cursor-pointer ${
                        toolMode === 'codeblock' ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-850 text-slate-500 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                      }`}
                      title="Place Structural Code Diagram Block"
                    >
                      <Code size={13} />
                    </button>
                    <button
                      id="tool-highlight"
                      onClick={() => setToolMode('highlight')}
                      className={`p-2 rounded-lg transition-all cursor-pointer ${
                        toolMode === 'highlight' ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-850 text-slate-500 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                      }`}
                      title="Highlight Text Excerpt Overlays"
                    >
                      <Highlighter size={13} />
                    </button>
                    
                    {/* Brush Color Picker */}
                    <div className="flex items-center gap-1 px-1">
                      {['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#3b82f6'].map(col => (
                        <button
                          key={col}
                          onClick={() => setBrushColor(col)}
                          className="w-3.5 h-3.5 rounded-full border border-black/10 cursor-pointer"
                          style={{ backgroundColor: col, outline: brushColor === col ? '1.5px solid #6366f1' : 'none' }}
                        />
                      ))}
                    </div>

                    <button
                      id="btn-clear-canvas"
                      onClick={clearCanvas}
                      className="px-2.5 py-1.5 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer"
                    >
                      Clear All
                    </button>
                  </div>
                </div>

                {/* Document Highlight selection controller */}
                <div className="mb-3 p-2.5 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs">
                  <div className="flex-1 min-w-0">
                    <span className="text-[8px] font-black tracking-wider uppercase text-slate-400 block mb-0.5">Selected Document Highlight Block</span>
                    <p className="font-medium text-slate-700 dark:text-slate-300 truncate">"{EXCERPTS[excerptIndex]}"</p>
                  </div>
                  <button
                    id="btn-cycle-excerpt"
                    onClick={() => setExcerptIndex(prev => (prev + 1) % EXCERPTS.length)}
                    className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-750 text-slate-600 dark:text-slate-400 font-bold rounded-lg cursor-pointer text-[10px]"
                  >
                    Cycle Excerpt
                  </button>
                </div>

                {/* The Canvas Stage container */}
                <div className="relative border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-950 h-[380px]">
                  
                  {/* Actual HTML5 Canvas */}
                  <canvas
                    id="colab-canvas-drawing-stage"
                    ref={canvasRef}
                    width={700}
                    height={380}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                    className="absolute inset-0 z-0 cursor-crosshair block w-full h-full"
                  />

                  {/* Absolute Overlay Blocks rendering */}
                  <div className="absolute inset-0 pointer-events-none z-10">
                    {elements.map((el) => {
                      if (el.type === 'codeblock' && el.x !== undefined && el.y !== undefined) {
                        return (
                          <div
                            id={`rendered-block-${el.id}`}
                            key={el.id}
                            style={{ left: el.x, top: el.y }}
                            className="absolute p-2 bg-indigo-600 text-white font-mono text-[9px] font-bold rounded-lg border border-indigo-700/50 pointer-events-auto shadow flex items-center gap-1.5"
                          >
                            <Code size={10} />
                            <span>{el.text}</span>
                            <button
                              id={`btn-remove-block-${el.id}`}
                              onClick={() => removeElement(el.id)}
                              className="hover:text-red-300 cursor-pointer ml-1 text-white/80"
                            >
                              <X size={9} />
                            </button>
                          </div>
                        );
                      }

                      if (el.type === 'highlight' && el.x !== undefined && el.y !== undefined) {
                        return (
                          <div
                            id={`rendered-hl-${el.id}`}
                            key={el.id}
                            style={{ left: el.x, top: el.y }}
                            className="absolute px-2.5 py-1.5 bg-yellow-400/20 text-slate-950 dark:text-white font-semibold text-[10px] rounded border border-yellow-400/40 pointer-events-auto shadow-sm flex items-center gap-1.5"
                          >
                            <Highlighter size={10} className="text-yellow-500" />
                            <span className="bg-yellow-400/30 px-1 py-0.5 rounded">{el.highlightText}</span>
                            <button
                              id={`btn-remove-hl-${el.id}`}
                              onClick={() => removeElement(el.id)}
                              className="hover:text-red-500 cursor-pointer text-slate-500 dark:text-slate-300 ml-1"
                            >
                              <X size={9} />
                            </button>
                          </div>
                        );
                      }

                      return null;
                    })}

                    {/* Simulated live peer cursor silhouettes */}
                    {peers.map(peer => (
                      <div
                        id={`peer-cursor-${peer.id}`}
                        key={peer.id}
                        className="absolute pointer-events-none transition-all duration-300 flex flex-col items-start"
                        style={{ left: peer.cursorX, top: peer.cursorY }}
                      >
                        <MousePointer size={14} style={{ color: peer.color }} className="fill-current" />
                        <span 
                          className="text-[8px] font-black px-1.5 py-0.5 rounded text-white font-mono mt-1 opacity-80"
                          style={{ backgroundColor: peer.color }}
                        >
                          {peer.name}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Status footer inside board */}
                  <div className="absolute bottom-2 left-2 z-20 bg-slate-950/80 text-white rounded px-2 py-1 text-[8px] font-mono pointer-events-none">
                    STATUS: SYNCED | ROOM: {currentRoom.name}
                  </div>
                </div>
              </div>

              {/* Section: Live Activity Logs */}
              <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2.5">
                  <MessageSquare size={14} className="text-indigo-500" />
                  Whiteboard Room Activity Stream
                </h3>
                <div id="room-activities-deck" className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[140px] overflow-y-auto font-mono text-[10px] text-slate-500">
                  {roomLogs.map((log, lIdx) => (
                    <div key={lIdx} className="p-2 bg-white dark:bg-slate-850 rounded-lg border border-slate-150 dark:border-slate-800 truncate">
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            /* Section: AI Adaptive Breakout Rooms Dashboard */
            <div className="flex flex-col gap-4">
              
              {/* Status Alert Banner */}
              <div className="p-4 bg-indigo-500/10 border border-indigo-500/25 rounded-2xl flex items-start gap-3">
                <span className="text-xl leading-none">🤖</span>
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-indigo-400">AI-Led Cognitive Partitioning</h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-normal mt-0.5">
                    The AI Engine has partitioned this co-working class into <strong>2 specialized cognitive streams</strong> based on live speed, difficulty scaling, and analytical performance telemetry.
                  </p>
                </div>
              </div>

              {/* Breakout Room Selection Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(BREAKOUT_ROOMS_BANK[currentRoom.subject] || BREAKOUT_ROOMS_BANK['Physics']).map((bRoom, bIdx) => {
                  const isSelected = selectedBreakoutIdx === bIdx;
                  const progressData = breakoutRoomsProgress[bRoom.id] || { progress: 0, stepsDone: [false, false, false] };
                  const assignedPeersObj = bRoom.assignedPeers.map(id => peers.find(p => p.id === id)).filter(Boolean);

                  return (
                    <button
                      key={bRoom.id}
                      onClick={() => setSelectedBreakoutIdx(bIdx)}
                      className={`p-4 text-left rounded-2xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600/10 border-indigo-500 ring-2 ring-indigo-500/20'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-500/40'
                      }`}
                    >
                      <div className="flex justify-between items-start gap-2 mb-2">
                        <span className="text-[9px] font-black uppercase tracking-widest text-indigo-500 dark:text-indigo-400">
                          {bRoom.partitionName}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[8px] font-black ${
                          isSelected ? 'bg-indigo-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                        }`}>
                          {isSelected ? '🎯 Active' : 'Enter'}
                        </span>
                      </div>

                      <h4 className="text-xs font-black text-slate-800 dark:text-slate-100 mb-1 flex items-center gap-1.5">
                        {bRoom.name}
                      </h4>

                      <p className="text-[10px] text-slate-400 leading-snug mb-3">
                        {bRoom.partitionFocus}
                      </p>

                      {/* Progress slider track */}
                      <div className="mb-3">
                        <div className="flex justify-between text-[8px] font-bold text-slate-400 uppercase mb-1">
                          <span>Room Progress</span>
                          <span className="font-mono text-indigo-500 dark:text-indigo-400">{progressData.progress}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-indigo-500 transition-all duration-500"
                            style={{ width: `${progressData.progress}%` }}
                          />
                        </div>
                      </div>

                      {/* Assigned class members */}
                      <div className="flex items-center gap-1.5">
                        <span className="text-[8px] font-black text-slate-400 uppercase tracking-wider mr-1">Classmates:</span>
                        <div className="flex -space-x-1.5 overflow-hidden">
                          {assignedPeersObj.map((p: any) => (
                            <span
                              key={p.id}
                              className="inline-block h-5 w-5 rounded-full ring-2 ring-white dark:ring-slate-900 bg-slate-100 dark:bg-slate-850 text-center text-xs leading-5"
                              title={`${p.name} (${p.activity})`}
                            >
                              {p.avatar}
                            </span>
                          ))}
                        </div>
                      </div>

                    </button>
                  );
                })}
              </div>

              {/* Selected Breakout Workspace Area */}
              {(() => {
                const bRoom = (BREAKOUT_ROOMS_BANK[currentRoom.subject] || BREAKOUT_ROOMS_BANK['Physics'])[selectedBreakoutIdx];
                if (!bRoom) return null;

                const progressData = breakoutRoomsProgress[bRoom.id] || { progress: 0, stepsDone: [false, false, false] };
                const currentSubjectLogs = breakoutLogs[bRoom.id] || [];

                // Handle cooperative submission
                const handleCooperativeSubmit = () => {
                  if (!customBreakoutSolution.trim()) return;

                  // Find first incomplete step
                  const incompleteIdx = progressData.stepsDone.findIndex(done => !done);
                  if (incompleteIdx === -1) {
                    alert('All steps for this breakout challenge are already completed!');
                    return;
                  }

                  const newStepsDone = [...progressData.stepsDone];
                  newStepsDone[incompleteIdx] = true;

                  const finishedCount = newStepsDone.filter(Boolean).length;
                  const totalSteps = newStepsDone.length || 1;
                  const newProgress = Math.round((finishedCount / totalSteps) * 100);

                  setBreakoutRoomsProgress(prev => ({
                    ...prev,
                    [bRoom.id]: {
                      progress: newProgress,
                      stepsDone: newStepsDone
                    }
                  }));

                  const stepText = bRoom.challenge.steps[incompleteIdx]?.text || 'Task';
                  const userLog = `🎓 You completed Step ${incompleteIdx + 1}: ${stepText} (+${Math.round(100 / totalSteps)}% progress)`;
                  
                  setBreakoutLogs(prev => ({
                    ...prev,
                    [bRoom.id]: [userLog, ...(prev[bRoom.id] || [])]
                  }));

                  // Grant points to classmates
                  setPeers(prev => prev.map(p => {
                    return { ...p, score: p.score + 10 }; // slight peer score boost for user action
                  }));

                  setCustomBreakoutSolution('');
                };

                // Boost peer
                const handlePeerBoost = (pId: string) => {
                  const peerObj = peers.find(p => p.id === pId);
                  if (!peerObj) return;

                  // Update score
                  setPeers(prev => prev.map(p => {
                    if (p.id === pId) {
                      return { ...p, score: p.score + 35, activity: 'Received assist boost!' };
                    }
                    return p;
                  }));

                  const boostLog = `⚡ You boosted ${peerObj.avatar} ${peerObj.name}'s performance! Cooperation index increased.`;
                  setBreakoutLogs(prev => ({
                    ...prev,
                    [bRoom.id]: [boostLog, ...(prev[bRoom.id] || [])]
                  }));
                };

                // Recalibrate partitions animation trigger
                const handleRecalibrate = () => {
                  setIsRecalibrating(true);
                  setTimeout(() => {
                    setIsRecalibrating(false);

                    setBreakoutLogs(prev => ({
                      ...prev,
                      [bRoom.id]: [
                        '🔄 AI Recalibrator: Partition parameters optimized. Classroom matching synchronized with cognitive state telemetry.',
                        ...(prev[bRoom.id] || [])
                      ]
                    }));
                  }, 1200);
                };

                return (
                  <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col gap-4">
                    
                    {/* Workspace Title bar */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                      <div>
                        <span className="text-[8px] font-black text-indigo-500 uppercase tracking-widest block">ACTIVE CO-OPERATIVE TARGET</span>
                        <h3 className="text-sm font-black text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                          🏆 {bRoom.challenge.title}
                        </h3>
                      </div>

                      <button
                        onClick={handleRecalibrate}
                        disabled={isRecalibrating}
                        className="px-2.5 py-1.5 bg-indigo-500/10 hover:bg-indigo-50 hover:text-white text-indigo-500 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all disabled:opacity-50 cursor-pointer flex items-center gap-1"
                      >
                        <RefreshCw size={10} className={isRecalibrating ? 'animate-spin' : ''} />
                        {isRecalibrating ? 'Recalibrating...' : 'Recalibrate Partitions'}
                      </button>
                    </div>

                    {/* Challenge Description */}
                    <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-150 dark:border-slate-850">
                      <span className="font-bold text-indigo-500">Objective:</span> {bRoom.challenge.description}
                    </div>

                    {/* AI Coach Assistant tips */}
                    <div className="p-3.5 bg-amber-500/5 dark:bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-2.5">
                      <span className="text-amber-500">💡</span>
                      <div className="text-xs">
                        <span className="font-extrabold text-amber-500 block mb-0.5">AI COACH REAL-TIME RIGOR TIP:</span>
                        <p className="text-slate-600 dark:text-slate-300 leading-normal">{bRoom.challenge.aiCoachTip}</p>
                      </div>
                    </div>

                    {/* 2 Column sub layout: Steps vs Terminal Solution */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* Left Sub-Col: Steps list */}
                      <div className="flex flex-col gap-2.5">
                        <span className="text-[9px] font-black tracking-widest text-slate-400 uppercase">Cooperative Milestones</span>
                        
                        <div className="flex flex-col gap-2">
                          {bRoom.challenge.steps.map((step, sIdx) => {
                            const isDone = progressData.stepsDone[sIdx];
                            const stepAssignedPeer = peers.find(p => p.id === step.peerId);

                            return (
                              <div
                                key={sIdx}
                                className={`p-3 rounded-xl border flex items-center gap-2.5 justify-between ${
                                  isDone
                                    ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-800 dark:text-emerald-300'
                                    : 'bg-slate-55 dark:bg-slate-950 border-slate-200 dark:border-slate-850 text-slate-500'
                                }`}
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                                    isDone ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                                  }`}>
                                    {isDone ? <Check size={11} className="stroke-[3]" /> : <span className="text-[10px] font-bold">{sIdx + 1}</span>}
                                  </div>
                                  <span className="text-xs font-medium leading-tight truncate">{step.text}</span>
                                </div>

                                {/* Assignee / Finisher icon */}
                                {isDone && (
                                  <span className="text-xs shrink-0" title="Completed collaboratively!">
                                    {stepAssignedPeer ? stepAssignedPeer.avatar : '🎓'}
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </div>

                        {/* Peer Support/Boost controls */}
                        <div className="mt-2">
                          <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-2">Classmate Co-op Boosts</span>
                          <div className="flex flex-wrap gap-2">
                            {bRoom.assignedPeers.map(pId => {
                              const peerObj = peers.find(p => p.id === pId);
                              if (!peerObj) return null;
                              return (
                                <button
                                  key={pId}
                                  onClick={() => handlePeerBoost(pId)}
                                  className="px-2.5 py-1.5 bg-slate-100 hover:bg-indigo-50 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-750 text-slate-700 dark:text-slate-300 rounded-lg text-[9px] font-bold uppercase cursor-pointer flex items-center gap-1.5"
                                >
                                  <span>{peerObj.avatar} Assist {peerObj.name}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                      </div>

                      {/* Right Sub-Col: Solution Submission Terminal */}
                      <div className="flex flex-col gap-2.5">
                        <span className="text-[9px] font-black tracking-widest text-slate-400 uppercase">Cooperative Action Station</span>
                        
                        <div className="p-4 bg-slate-950 text-slate-100 rounded-xl border border-slate-800 font-mono text-xs flex-1 flex flex-col justify-between min-h-[200px]">
                          <div>
                            <div className="flex justify-between items-center mb-2 border-b border-slate-800 pb-1.5 text-[10px]">
                              <span className="text-indigo-400 font-bold">STUDENT_TERMINAL // COOP</span>
                              <span className="text-emerald-500">● ACTIVE</span>
                            </div>
                            
                            <p className="text-[10px] text-slate-400 leading-normal mb-3">
                              Type analytical theorems, numerical code snippets, or molecular balance steps to advance the co-operative solution bounds.
                            </p>

                            <textarea
                              value={customBreakoutSolution}
                              onChange={(e) => setCustomBreakoutSolution(e.target.value)}
                              placeholder="// Enter model formulas, equations, or code steps here..."
                              rows={4}
                              className="w-full p-2 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-slate-100 placeholder-slate-600 outline-none focus:border-indigo-500 resize-none"
                            />
                          </div>

                          <button
                            onClick={handleCooperativeSubmit}
                            className="mt-3 w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-mono font-black text-[10px] uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <span>Execute Solution Dispatch</span>
                            <span>🚀</span>
                          </button>
                        </div>

                      </div>

                    </div>

                    {/* Breakout live contribution log stream */}
                    <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-850 rounded-xl mt-2">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1.5">Active Room Collaboration Feed</span>
                      <div className="max-h-[110px] overflow-y-auto flex flex-col gap-1.5 font-mono text-[10px] text-slate-500">
                        {currentSubjectLogs.length === 0 ? (
                          <div className="text-center py-2 text-[9px]">No collaboration entries logged yet.</div>
                        ) : (
                          currentSubjectLogs.map((log, lIdx) => (
                            <div key={lIdx} className="p-1.5 bg-white dark:bg-slate-900 rounded border border-slate-100 dark:border-slate-800 truncate">
                              {log}
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                  </div>
                );
              })()}

            </div>
          )}

        </div>

        {/* Right Column: Classroom Peer List & Challenges (Col 4) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          
          {/* Section: Classroom Presence list */}
          <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-3.5">
              <Users size={15} className="text-indigo-500" />
              Connected Classmates
            </h3>

            <div id="peers-deck" className="flex flex-col gap-2">
              {peers.map(peer => (
                <div
                  id={`peer-row-${peer.id}`}
                  key={peer.id}
                  className="p-2.5 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xl">{peer.avatar}</span>
                    <div className="min-w-0">
                      <div className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                        <span>{peer.name}</span>
                        <span 
                          className="w-1.5 h-1.5 rounded-full animate-ping" 
                          style={{ backgroundColor: peer.color }} 
                        />
                      </div>
                      <span className="text-[10px] text-slate-400 font-extrabold block truncate">{peer.activity}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">SCORE</span>
                    <span className="font-mono font-bold text-indigo-500">{peer.score} pts</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Peer Challenges Arena */}
          <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex-1 flex flex-col">
            <div className="mb-4">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Gamepad2 size={15} className="text-indigo-500" />
                Peer Challenges Arena
              </h3>
              <p className="text-[10px] text-slate-500 mt-0.5">Real-time study games, trivia, and competitive problem rounds.</p>
            </div>

            {!challengeMode ? (
              <div id="challenge-setup" className="flex-1 p-4 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl text-center flex flex-col items-center justify-center">
                <div className="w-11 h-11 bg-indigo-100 dark:bg-indigo-950/40 text-indigo-500 rounded-full flex items-center justify-center mb-3">
                  <Award size={22} className="animate-pulse" />
                </div>
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 mb-1">Multiplayer Review Challenge</h4>
                <p className="text-[10px] text-slate-500 leading-relaxed max-w-[200px] mb-4">
                  Match up with <strong>Zuri, Chen, and Aaliyah</strong> in a rapid-fire quiz on {challengeSubject}.
                </p>
                <button
                  id="btn-trigger-peer-challenge"
                  onClick={startChallengeMode}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-[11px] uppercase tracking-wider cursor-pointer shadow-md flex items-center justify-center gap-1"
                >
                  <Play size={11} /> Start Challenge Match
                </button>
              </div>
            ) : (
              <div id="challenge-play" className="p-3.5 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs">
                {challengeActive ? (
                  <>
                    <div className="flex justify-between items-center mb-2.5 text-[9px] text-slate-400 font-black uppercase">
                      <span>QUESTION {currentQuestionIdx + 1} of {activeQuestions.length}</span>
                      <span className="text-indigo-500 flex items-center gap-1 animate-pulse">
                        ⌛ {quizTimer}s Left
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-800 dark:text-slate-100 mb-3.5 leading-normal">
                      {activeQuestions[currentQuestionIdx].question}
                    </h4>

                    {/* Options */}
                    <div className="flex flex-col gap-2 mb-3.5">
                      {activeQuestions[currentQuestionIdx].options.map((opt, oIdx) => {
                        const isSelected = playerSelectedAns === oIdx;
                        const isCorrect = oIdx === activeQuestions[currentQuestionIdx].correctIndex;
                        const hasAnswered = playerSelectedAns !== null;

                        return (
                          <button
                            id={`chal-opt-${oIdx}`}
                            key={oIdx}
                            disabled={hasAnswered}
                            onClick={() => submitQuizAnswer(oIdx)}
                            className={`p-2.5 rounded-xl border text-left text-[11px] font-medium transition-all ${
                              hasAnswered
                                ? isCorrect
                                  ? 'bg-emerald-500/15 border-emerald-500 text-emerald-600 dark:text-emerald-400 font-bold'
                                  : isSelected
                                    ? 'bg-red-500/15 border-red-500 text-red-600 dark:text-red-400 font-bold'
                                    : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 opacity-60'
                                : 'bg-slate-50 hover:bg-indigo-50/50 border-slate-200 hover:border-indigo-500 dark:bg-slate-900 dark:hover:bg-slate-800/50 dark:border-slate-800 cursor-pointer'
                            }`}
                          >
                            <span>{opt}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Peer Progress Answers display */}
                    {playerSelectedAns !== null && (
                      <div className="p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 mb-3 text-[10px]">
                        <span className="font-black text-slate-400 block mb-1 uppercase">PEER RESPONSES:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {Object.entries(peerAnswers).map(([pName, pData]) => (
                            <span 
                              key={pName} 
                              className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                                pData.correct ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'
                              }`}
                            >
                              {pName}: {pData.correct ? 'Correct' : 'Incorrect'} ({pData.time}s)
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {playerSelectedAns !== null && (
                      <button
                        id="btn-chal-next"
                        onClick={nextChallengeQuestion}
                        className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer"
                      >
                        {currentQuestionIdx + 1 === activeQuestions.length ? 'Calculate Leaderboard' : 'Next Question'}
                        <ChevronRight size={13} />
                      </button>
                    )}
                  </>
                ) : (
                  /* Completed Leaderboard */
                  <div className="text-center py-4">
                    <h4 className="text-xs font-black text-indigo-500 mb-2 uppercase tracking-wider">Tournament Completed!</h4>
                    
                    <div className="flex flex-col gap-2 mb-4">
                      {/* Sort peers by score */}
                      {[...peers].sort((a,b) => b.score - a.score).map((p, pIdx) => (
                        <div key={p.id} className="flex justify-between items-center p-2 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-[11px]">
                          <span className="font-bold flex items-center gap-1.5">
                            <span className="font-mono text-slate-400">#{pIdx+1}</span>
                            <span>{p.avatar} {p.name}</span>
                          </span>
                          <span className="font-mono font-black text-indigo-500">{p.score} pts</span>
                        </div>
                      ))}
                    </div>

                    <button
                      id="btn-exit-challenge"
                      onClick={() => setChallengeMode(false)}
                      className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-750 dark:text-slate-300 rounded-xl font-bold uppercase tracking-wider text-[10px] cursor-pointer"
                    >
                      Exit Challenge Arena
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Classroom Chat Panel (Always accessible in side row/bottom drawer) */}
      <div id="colab-chat-drawer" className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 mt-4 flex flex-col sm:flex-row justify-between gap-4 items-stretch">
        
        {/* Left Side: Live chat logs */}
        <div className="flex-1 flex flex-col max-h-[160px] min-h-[140px]">
          <span className="text-[9px] font-black tracking-widest text-slate-400 uppercase mb-2 flex items-center gap-1">
            <MessageSquare size={12} /> Class Group Chat
          </span>

          <div id="chat-messages-scroller" className="flex-1 overflow-y-auto flex flex-col gap-2 pr-1 text-[11px]">
            {chatMessages.map((msg, mIdx) => (
              <div key={mIdx} className="flex items-start gap-1.5 pb-1">
                <span className="text-base">{msg.avatar}</span>
                <div className="flex-1">
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-bold" style={{ color: msg.color }}>{msg.sender}</span>
                    <span className="text-[8px] text-slate-400 font-mono">{msg.time}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 mt-0.5 font-medium">{msg.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Chat input block */}
        <div className="sm:w-64 border-t sm:border-t-0 sm:border-l border-slate-200 dark:border-slate-800 pt-3 sm:pt-0 sm:pl-4 flex flex-col justify-end">
          <label className="block text-[8px] font-black uppercase text-slate-400 mb-1.5">Transmit message to room</label>
          <div className="flex gap-1.5">
            <input
              id="input-chat-msg"
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submitMessage()}
              placeholder="Ask peers a question..."
              className="flex-1 p-2 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold dark:text-white outline-none focus:border-indigo-500"
            />
            <button
              id="btn-send-chat"
              onClick={submitMessage}
              className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-all cursor-pointer flex-shrink-0"
            >
              <Send size={12} />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
