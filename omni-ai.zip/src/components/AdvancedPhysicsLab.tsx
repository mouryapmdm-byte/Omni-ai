import React, { useState, useEffect, useRef } from 'react';
import { 
  Orbit, Sun, Compass, Play, Pause, RotateCcw, Flame, 
  Sparkles, Sliders, Waves, Activity, Eye, Zap, ArrowRight,
  Info, Check, Layers, Share2, HelpCircle
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface AdvancedPhysicsLabProps {
  theme: 'light' | 'dark';
  onSendToChat?: (prompt: string) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

type PhysicsSubLab = 'orbital_mechanics' | 'optics_refraction' | 'thermo_heat_engine' | 'wave_doppler';

export const AdvancedPhysicsLab: React.FC<AdvancedPhysicsLabProps> = ({
  theme,
  onSendToChat,
  showNotification
}) => {
  const [activeLab, setActiveLab] = useState<PhysicsSubLab>('orbital_mechanics');
  const [isRunning, setIsRunning] = useState(true);

  // 1. Orbital Mechanics State
  const [orbitalPreset, setOrbitalPreset] = useState<'sun_earth_moon' | 'binary_star' | 'lagrange_points' | 'chaotic_three_body'>('sun_earth_moon');
  const [gravitationalConstant, setGravitationalConstant] = useState(1.0);
  const [trailLength, setTrailLength] = useState(120);
  const [showVectors, setShowVectors] = useState(true);

  // 2. Optics & Refraction State
  const [opticsMode, setOpticsMode] = useState<'snell_refraction' | 'thin_lens' | 'double_slit'>('thin_lens');
  const [incidentAngle, setIncidentAngle] = useState(35); // degrees
  const [medium1Index, setMedium1Index] = useState(1.0); // Air
  const [medium2Index, setMedium2Index] = useState(1.52); // Crown Glass
  const [lensFocalLength, setLensFocalLength] = useState(100); // px
  const [lensObjectDist, setLensObjectDist] = useState(180); // px
  const [lensObjectHeight, setLensObjectHeight] = useState(50); // px
  const [slitSeparation, setSlitSeparation] = useState(0.25); // mm
  const [wavelength, setWavelength] = useState(532); // nm (Green Laser)

  // 3. Thermodynamics Heat Engine State
  const [engineCycle, setEngineCycle] = useState<'carnot' | 'otto' | 'stirling' | 'diesel'>('carnot');
  const [tempHot, setTempHot] = useState(650); // Kelvin
  const [tempCold, setTempCold] = useState(300); // Kelvin
  const [compressionRatio, setCompressionRatio] = useState(8.0);
  const [cycleProgress, setCycleProgress] = useState(0); // 0 to 1

  // 4. Wave & Doppler State
  const [sourceVelocity, setSourceVelocity] = useState(0.4); // Mach fraction
  const [waveFrequency, setWaveFrequency] = useState(1.5); // Hz
  const [waveSpeed, setWaveSpeed] = useState(180); // px/sec

  // Canvas Refs
  const orbitCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const opticsCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const thermoCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const waveCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // N-Body Body State
  interface CelestialBody {
    name: string;
    x: number;
    y: number;
    vx: number;
    vy: number;
    mass: number;
    radius: number;
    color: string;
    trail: { x: number; y: number }[];
  }
  const bodiesRef = useRef<CelestialBody[]>([]);

  // Initialize N-Body Systems
  useEffect(() => {
    if (activeLab !== 'orbital_mechanics') return;

    if (orbitalPreset === 'sun_earth_moon') {
      bodiesRef.current = [
        { name: 'Sun', x: 300, y: 220, vx: 0, vy: 0, mass: 1200, radius: 16, color: '#f59e0b', trail: [] },
        { name: 'Earth', x: 300, y: 80, vx: 2.8, vy: 0, mass: 15, radius: 8, color: '#3b82f6', trail: [] },
        { name: 'Moon', x: 300, y: 62, vx: 3.8, vy: 0, mass: 1, radius: 4, color: '#cbd5e1', trail: [] },
      ];
    } else if (orbitalPreset === 'binary_star') {
      bodiesRef.current = [
        { name: 'Star Alpha', x: 240, y: 220, vx: 0, vy: 1.6, mass: 650, radius: 13, color: '#ef4444', trail: [] },
        { name: 'Star Beta', x: 360, y: 220, vx: 0, vy: -1.6, mass: 650, radius: 13, color: '#3b82f6', trail: [] },
        { name: 'Circumbinary Planet', x: 300, y: 40, vx: 2.4, vy: 0, mass: 5, radius: 6, color: '#10b981', trail: [] },
      ];
    } else if (orbitalPreset === 'lagrange_points') {
      // Sun-Jupiter system + Test particle at L4
      const R = 150;
      const omega = 0.02;
      bodiesRef.current = [
        { name: 'Primary (Sun)', x: 300, y: 220, vx: 0, vy: 0, mass: 1000, radius: 16, color: '#f59e0b', trail: [] },
        { name: 'Secondary (Jupiter)', x: 300 + R, y: 220, vx: 0, vy: 2.5, mass: 60, radius: 9, color: '#d97706', trail: [] },
        { name: 'Trojan Asteroid (L4)', x: 300 + R * Math.cos(Math.PI/3), y: 220 - R * Math.sin(Math.PI/3), vx: 2.5 * Math.sin(Math.PI/3), vy: 2.5 * Math.cos(Math.PI/3), mass: 0.01, radius: 4, color: '#a855f7', trail: [] }
      ];
    } else if (orbitalPreset === 'chaotic_three_body') {
      bodiesRef.current = [
        { name: 'Body 1', x: 260, y: 170, vx: 0.9, vy: -0.6, mass: 400, radius: 10, color: '#ec4899', trail: [] },
        { name: 'Body 2', x: 340, y: 170, vx: -0.9, vy: 0.6, mass: 400, radius: 10, color: '#06b6d4', trail: [] },
        { name: 'Body 3', x: 300, y: 280, vx: 0.4, vy: 0.2, mass: 400, radius: 10, color: '#10b981', trail: [] },
      ];
    }
  }, [activeLab, orbitalPreset]);

  // Orbital Mechanics Simulation Animation Loop
  useEffect(() => {
    if (activeLab !== 'orbital_mechanics') return;
    let animId: number;

    const canvas = orbitCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Background Starfield Grid
      ctx.fillStyle = theme === 'dark' ? '#090d16' : '#f8fafc';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Faint coordinate grid
      ctx.strokeStyle = theme === 'dark' ? '#1e293b' : '#e2e8f0';
      ctx.lineWidth = 1;
      for (let x = 0; x < canvas.width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      const bodies = bodiesRef.current;

      if (isRunning) {
        // Compute Gravitational Forces (Newton's Universal Gravity: F = G * m1 * m2 / r^2)
        const G = gravitationalConstant * 0.15;
        const dt = 0.5;

        for (let i = 0; i < bodies.length; i++) {
          let fx = 0;
          let fy = 0;
          const b1 = bodies[i];

          for (let j = 0; j < bodies.length; j++) {
            if (i === j) continue;
            const b2 = bodies[j];
            const dx = b2.x - b1.x;
            const dy = b2.y - b1.y;
            const distSq = dx * dx + dy * dy + 100; // Softening parameter to prevent singularity
            const dist = Math.sqrt(distSq);
            const force = (G * b1.mass * b2.mass) / distSq;

            fx += force * (dx / dist);
            fy += force * (dy / dist);
          }

          b1.vx += (fx / b1.mass) * dt;
          b1.vy += (fy / b1.mass) * dt;
          b1.x += b1.vx * dt;
          b1.y += b1.vy * dt;

          // Record trail
          b1.trail.push({ x: b1.x, y: b1.y });
          if (b1.trail.length > trailLength) {
            b1.trail.shift();
          }
        }
      }

      // Draw Trails
      bodies.forEach(b => {
        if (b.trail.length < 2) return;
        ctx.beginPath();
        ctx.moveTo(b.trail[0].x, b.trail[0].y);
        for (let i = 1; i < b.trail.length; i++) {
          ctx.lineTo(b.trail[i].x, b.trail[i].y);
        }
        ctx.strokeStyle = b.color + '66'; // Transparent trail
        ctx.lineWidth = 2;
        ctx.stroke();
      });

      // Draw Bodies & Vectors
      bodies.forEach(b => {
        // Outer Glow
        const gradient = ctx.createRadialGradient(b.x, b.y, b.radius * 0.3, b.x, b.y, b.radius * 2);
        gradient.addColorStop(0, b.color);
        gradient.addColorStop(1, b.color + '00');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.radius * 2, 0, Math.PI * 2);
        ctx.fill();

        // Main Core
        ctx.fillStyle = b.color;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
        ctx.fill();

        // Name Label
        ctx.fillStyle = theme === 'dark' ? '#cbd5e1' : '#334155';
        ctx.font = '10px system-ui';
        ctx.fillText(b.name, b.x + b.radius + 4, b.y + 3);

        // Velocity Vector Arrow
        if (showVectors) {
          const arrowLen = Math.sqrt(b.vx * b.vx + b.vy * b.vy) * 12;
          if (arrowLen > 2) {
            ctx.beginPath();
            ctx.moveTo(b.x, b.y);
            const targetX = b.x + b.vx * 12;
            const targetY = b.y + b.vy * 12;
            ctx.lineTo(targetX, targetY);
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 2;
            ctx.stroke();

            // Arrow head
            const angle = Math.atan2(b.vy, b.vx);
            ctx.beginPath();
            ctx.moveTo(targetX, targetY);
            ctx.lineTo(targetX - 6 * Math.cos(angle - Math.PI / 6), targetY - 6 * Math.sin(angle - Math.PI / 6));
            ctx.lineTo(targetX - 6 * Math.cos(angle + Math.PI / 6), targetY - 6 * Math.sin(angle + Math.PI / 6));
            ctx.fillStyle = '#38bdf8';
            ctx.fill();
          }
        }
      });

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [activeLab, isRunning, gravitationalConstant, trailLength, showVectors, theme]);

  // Optics & Ray Tracing Simulation Canvas Loop
  useEffect(() => {
    if (activeLab !== 'optics_refraction') return;
    const canvas = opticsCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = theme === 'dark' ? '#090d16' : '#f8fafc';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (opticsMode === 'thin_lens') {
      const opticalAxisY = canvas.height / 2;
      const lensX = canvas.width / 2;

      // Optical Axis Line
      ctx.strokeStyle = theme === 'dark' ? '#475569' : '#94a3b8';
      ctx.setLineDash([6, 4]);
      ctx.beginPath();
      ctx.moveTo(0, opticalAxisY);
      ctx.lineTo(canvas.width, opticalAxisY);
      ctx.stroke();
      ctx.setLineDash([]);

      // Focal Points F and 2F
      const f = lensFocalLength;
      [-2 * f, -f, f, 2 * f].forEach(offset => {
        const x = lensX + offset;
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(x, opticalAxisY, 3.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = theme === 'dark' ? '#cbd5e1' : '#475569';
        ctx.font = '10px sans-serif';
        const label = offset === -f ? 'F₁' : offset === -2 * f ? '2F₁' : offset === f ? 'F₂' : '2F₂';
        ctx.fillText(label, x - 6, opticalAxisY + 16);
      });

      // Convex Lens Glass Shape
      ctx.fillStyle = 'rgba(59, 130, 246, 0.2)';
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(lensX, opticalAxisY, 18, 110, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Object (Arrow on Left)
      const objX = lensX - lensObjectDist;
      const objTopY = opticalAxisY - lensObjectHeight;

      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(objX, opticalAxisY);
      ctx.lineTo(objX, objTopY);
      ctx.stroke();

      // Object Arrow head
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.moveTo(objX, objTopY);
      ctx.lineTo(objX - 5, objTopY + 10);
      ctx.lineTo(objX + 5, objTopY + 10);
      ctx.fill();
      ctx.fillText('Object (h₁)', objX - 25, objTopY - 8);

      // Lens Equation: 1/v - 1/u = 1/f => 1/v = 1/f + 1/u (with u = -lensObjectDist)
      const u = -lensObjectDist;
      const v = (f * u) / (u + f);
      const magnification = v / u;
      const imgHeight = lensObjectHeight * magnification;
      const imgX = lensX + v;
      const imgTopY = opticalAxisY - imgHeight;

      // 3 Principal Light Rays
      // Ray 1: Parallel to Axis -> Refracts through F2
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(objX, objTopY);
      ctx.lineTo(lensX, objTopY);
      ctx.lineTo(imgX, imgTopY);
      ctx.stroke();

      // Ray 2: Passes straight through Optical Center (0,0)
      ctx.strokeStyle = '#38bdf8';
      ctx.beginPath();
      ctx.moveTo(objX, objTopY);
      ctx.lineTo(imgX, imgTopY);
      ctx.stroke();

      // Ray 3: Passes through F1 -> Exits parallel to axis
      ctx.strokeStyle = '#a855f7';
      ctx.beginPath();
      ctx.moveTo(objX, objTopY);
      // find intersection with lens line x = lensX
      const slopeF1 = (opticalAxisY - objTopY) / ((lensX - f) - objX);
      const yAtLens = objTopY + slopeF1 * (lensX - objX);
      ctx.lineTo(lensX, yAtLens);
      ctx.lineTo(imgX, imgTopY);
      ctx.stroke();

      // Image Arrow (Real/Inverted or Virtual/Erect)
      if (Math.abs(v) < 1000) {
        ctx.strokeStyle = v > 0 ? '#f59e0b' : '#ec4899';
        ctx.lineWidth = 3;
        ctx.setLineDash(v > 0 ? [] : [4, 4]);
        ctx.beginPath();
        ctx.moveTo(imgX, opticalAxisY);
        ctx.lineTo(imgX, imgTopY);
        ctx.stroke();
        ctx.setLineDash([]);

        // Image Arrow head
        ctx.fillStyle = v > 0 ? '#f59e0b' : '#ec4899';
        ctx.beginPath();
        ctx.moveTo(imgX, imgTopY);
        const dir = imgHeight > 0 ? 1 : -1;
        ctx.lineTo(imgX - 5, imgTopY + dir * 10);
        ctx.lineTo(imgX + 5, imgTopY + dir * 10);
        ctx.fill();

        ctx.font = '11px sans-serif';
        ctx.fillText(`Image (v = ${v.toFixed(1)}px, m = ${magnification.toFixed(2)}x)`, imgX - 40, imgTopY + (imgHeight > 0 ? -12 : 20));
      }
    } else if (opticsMode === 'snell_refraction') {
      const midY = canvas.height / 2;
      const midX = canvas.width / 2;

      // Medium 1 (Top) & Medium 2 (Bottom)
      ctx.fillStyle = theme === 'dark' ? '#0f172a' : '#f1f5f9';
      ctx.fillRect(0, 0, canvas.width, midY);
      ctx.fillStyle = 'rgba(14, 165, 233, 0.15)';
      ctx.fillRect(0, midY, canvas.width, midY);

      // Interface line
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, midY);
      ctx.lineTo(canvas.width, midY);
      ctx.stroke();

      // Normal Line (Dotted Vertical)
      ctx.strokeStyle = theme === 'dark' ? '#64748b' : '#94a3b8';
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(midX, 20);
      ctx.lineTo(midX, canvas.height - 20);
      ctx.stroke();
      ctx.setLineDash([]);

      // Snell's Law: n1 * sin(theta1) = n2 * sin(theta2)
      const theta1Rad = (incidentAngle * Math.PI) / 180;
      const sinTheta2 = (medium1Index * Math.sin(theta1Rad)) / medium2Index;
      const isTotalInternalReflection = sinTheta2 > 1.0;
      const theta2Rad = isTotalInternalReflection ? 0 : Math.asin(sinTheta2);
      const theta2Deg = isTotalInternalReflection ? 0 : (theta2Rad * 180) / Math.PI;

      // Incident Ray
      const rayLen = 160;
      const incStartX = midX - rayLen * Math.sin(theta1Rad);
      const incStartY = midY - rayLen * Math.cos(theta1Rad);

      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(incStartX, incStartY);
      ctx.lineTo(midX, midY);
      ctx.stroke();

      // Laser Glow
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(incStartX, incStartY, 5, 0, Math.PI * 2);
      ctx.fill();

      if (!isTotalInternalReflection) {
        // Refracted Ray into Medium 2
        const refrEndX = midX + rayLen * Math.sin(theta2Rad);
        const refrEndY = midY + rayLen * Math.cos(theta2Rad);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(midX, midY);
        ctx.lineTo(refrEndX, refrEndY);
        ctx.stroke();

        // Partially Reflected Ray
        const reflEndX = midX + rayLen * Math.sin(theta1Rad);
        const reflEndY = midY - rayLen * Math.cos(theta1Rad);
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(midX, midY);
        ctx.lineTo(reflEndX, reflEndY);
        ctx.stroke();
      } else {
        // Total Internal Reflection Ray
        const tirEndX = midX + rayLen * Math.sin(theta1Rad);
        const tirEndY = midY - rayLen * Math.cos(theta1Rad);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(midX, midY);
        ctx.lineTo(tirEndX, tirEndY);
        ctx.stroke();

        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText('TOTAL INTERNAL REFLECTION (TIR)', midX + 20, midY - 60);
      }

      // Labels
      ctx.fillStyle = theme === 'dark' ? '#e2e8f0' : '#1e293b';
      ctx.font = '11px sans-serif';
      ctx.fillText(`Medium 1 (n₁ = ${medium1Index.toFixed(3)}) | θ₁ = ${incidentAngle}°`, 20, midY - 20);
      ctx.fillText(`Medium 2 (n₂ = ${medium2Index.toFixed(3)}) | θ₂ = ${isTotalInternalReflection ? 'TIR' : theta2Deg.toFixed(1) + '°'}`, 20, midY + 30);
    } else if (opticsMode === 'double_slit') {
      // Young's Double Slit Wave Interference Intensity Pattern
      const slitX = 140;
      const screenX = canvas.width - 60;
      const midY = canvas.height / 2;

      // Laser Emitter
      ctx.fillStyle = '#10b981';
      ctx.fillRect(20, midY - 15, 40, 30);
      ctx.fillStyle = '#fff';
      ctx.fillText('Laser', 26, midY + 4);

      // Barrier with 2 Slits
      ctx.fillStyle = theme === 'dark' ? '#334155' : '#64748b';
      ctx.fillRect(slitX, 20, 10, canvas.height - 40);

      const dPx = slitSeparation * 120;
      const slit1Y = midY - dPx / 2;
      const slit2Y = midY + dPx / 2;

      // Clear Slit Gaps
      ctx.clearRect(slitX, slit1Y - 4, 10, 8);
      ctx.clearRect(slitX, slit2Y - 4, 10, 8);

      // Screen
      ctx.fillStyle = theme === 'dark' ? '#1e293b' : '#cbd5e1';
      ctx.fillRect(screenX, 20, 12, canvas.height - 40);

      // Draw Diffraction Intensity Fringes on Screen
      for (let y = 30; y < canvas.height - 30; y++) {
        const dy = y - midY;
        const L = screenX - slitX;
        const theta = dy / L;
        const beta = (Math.PI * 0.05 * Math.sin(theta)) / (wavelength * 1e-6);
        const alpha = (Math.PI * slitSeparation * Math.sin(theta)) / (wavelength * 1e-6);

        const sinc = beta === 0 ? 1 : Math.sin(beta) / beta;
        const intensity = (sinc * sinc) * (Math.cos(alpha) * Math.cos(alpha));

        const r = 16, g = Math.floor(255 * intensity), b = 120;
        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${Math.max(intensity, 0.05)})`;
        ctx.fillRect(screenX, y, 12, 1);
      }

      // Plot Intensity Graph Curve
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let y = 30; y < canvas.height - 30; y++) {
        const dy = y - midY;
        const L = screenX - slitX;
        const theta = dy / L;
        const beta = (Math.PI * 0.05 * Math.sin(theta)) / (wavelength * 1e-6);
        const alpha = (Math.PI * slitSeparation * Math.sin(theta)) / (wavelength * 1e-6);
        const sinc = beta === 0 ? 1 : Math.sin(beta) / beta;
        const intensity = (sinc * sinc) * (Math.cos(alpha) * Math.cos(alpha));
        const plotX = screenX - 10 - intensity * 90;
        if (y === 30) ctx.moveTo(plotX, y);
        else ctx.lineTo(plotX, y);
      }
      ctx.stroke();
    }
  }, [activeLab, opticsMode, incidentAngle, medium1Index, medium2Index, lensFocalLength, lensObjectDist, lensObjectHeight, slitSeparation, wavelength, theme]);

  // Thermodynamics Heat Engine Loop
  useEffect(() => {
    if (activeLab !== 'thermo_heat_engine') return;
    let animId: number;
    const canvas = thermoCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let progress = cycleProgress;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = theme === 'dark' ? '#090d16' : '#f8fafc';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (isRunning) {
        progress = (progress + 0.006) % 1;
        setCycleProgress(progress);
      }

      // 1. P-V Diagram Axes (Left Side)
      const pvOriginX = 60;
      const pvOriginY = canvas.height - 50;
      const pvWidth = 220;
      const pvHeight = 160;

      ctx.strokeStyle = theme === 'dark' ? '#475569' : '#94a3b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(pvOriginX, pvOriginY - pvHeight);
      ctx.lineTo(pvOriginX, pvOriginY);
      ctx.lineTo(pvOriginX + pvWidth, pvOriginY);
      ctx.stroke();

      ctx.fillStyle = theme === 'dark' ? '#cbd5e1' : '#334155';
      ctx.font = '10px sans-serif';
      ctx.fillText('Pressure (P)', pvOriginX - 10, pvOriginY - pvHeight - 8);
      ctx.fillText('Volume (V)', pvOriginX + pvWidth - 15, pvOriginY + 16);

      // Carnot / Otto Cycle P-V Path
      const p1 = { x: pvOriginX + 40, y: pvOriginY - 140 }; // State 1: High P, Low V
      const p2 = { x: pvOriginX + 110, y: pvOriginY - 95 }; // State 2: Isothermal expansion
      const p3 = { x: pvOriginX + 190, y: pvOriginY - 40 }; // State 3: Adiabatic expansion
      const p4 = { x: pvOriginX + 90, y: pvOriginY - 55 }; // State 4: Isothermal compression

      ctx.fillStyle = 'rgba(99, 102, 241, 0.15)';
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.quadraticCurveTo(p1.x + 35, p1.y + 15, p2.x, p2.y);
      ctx.quadraticCurveTo(p2.x + 40, p2.y + 35, p3.x, p3.y);
      ctx.quadraticCurveTo(p3.x - 45, p3.y - 10, p4.x, p4.y);
      ctx.quadraticCurveTo(p4.x - 30, p4.y - 45, p1.x, p1.y);
      ctx.fill();

      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Current State Indicator Dot along Path
      let currX = p1.x;
      let currY = p1.y;
      if (progress < 0.25) {
        const t = progress / 0.25;
        currX = p1.x + (p2.x - p1.x) * t;
        currY = p1.y + (p2.y - p1.y) * t;
      } else if (progress < 0.5) {
        const t = (progress - 0.25) / 0.25;
        currX = p2.x + (p3.x - p2.x) * t;
        currY = p2.y + (p3.y - p2.y) * t;
      } else if (progress < 0.75) {
        const t = (progress - 0.5) / 0.25;
        currX = p3.x + (p4.x - p3.x) * t;
        currY = p3.y + (p4.y - p3.y) * t;
      } else {
        const t = (progress - 0.75) / 0.25;
        currX = p4.x + (p1.x - p4.x) * t;
        currY = p4.y + (p1.y - p4.y) * t;
      }

      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(currX, currY, 6, 0, Math.PI * 2);
      ctx.fill();

      // 2. Animated Piston-Cylinder Assembly (Right Side)
      const pistonCylX = canvas.width - 240;
      const pistonCylY = 80;
      const cylWidth = 140;
      const cylHeight = 160;

      // Cylinder Walls
      ctx.strokeStyle = theme === 'dark' ? '#94a3b8' : '#475569';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(pistonCylX, pistonCylY);
      ctx.lineTo(pistonCylX, pistonCylY + cylHeight);
      ctx.lineTo(pistonCylX + cylWidth, pistonCylY + cylHeight);
      ctx.lineTo(pistonCylX + cylWidth, pistonCylY);
      ctx.stroke();

      // Piston Motion Position (derived from current volume on P-V curve)
      const pistonY = pistonCylY + 30 + ((currX - (pvOriginX + 40)) / 150) * 80;

      // Hot Gas Inside Cylinder
      const gasGrad = ctx.createLinearGradient(0, pistonY, 0, pistonCylY + cylHeight);
      const isHotStroke = progress < 0.5;
      gasGrad.addColorStop(0, isHotStroke ? 'rgba(239, 68, 68, 0.4)' : 'rgba(59, 130, 246, 0.3)');
      gasGrad.addColorStop(1, isHotStroke ? 'rgba(245, 158, 11, 0.2)' : 'rgba(14, 165, 233, 0.1)');
      ctx.fillStyle = gasGrad;
      ctx.fillRect(pistonCylX + 3, pistonY + 12, cylWidth - 6, (pistonCylY + cylHeight) - (pistonY + 12));

      // Piston Head
      ctx.fillStyle = '#64748b';
      ctx.fillRect(pistonCylX + 4, pistonY, cylWidth - 8, 16);

      // Piston Connecting Rod
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(pistonCylX + cylWidth / 2 - 6, pistonY - 45, 12, 45);

      // Heat In / Heat Out Flame & Coolant indicators
      if (progress < 0.25) {
        ctx.fillStyle = '#f59e0b';
        ctx.fillText(`🔥 Heat Added Q_H (${tempHot} K)`, pistonCylX + 15, pistonCylY + cylHeight + 25);
      } else if (progress >= 0.5 && progress < 0.75) {
        ctx.fillStyle = '#38bdf8';
        ctx.fillText(`❄️ Heat Rejected Q_C (${tempCold} K)`, pistonCylX + 10, pistonCylY + cylHeight + 25);
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [activeLab, isRunning, engineCycle, tempHot, tempCold, theme]);

  // Wave & Doppler Effect Simulation Loop
  useEffect(() => {
    if (activeLab !== 'wave_doppler') return;
    let animId: number;
    const canvas = waveCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    interface Wavefront {
      x: number;
      y: number;
      radius: number;
      age: number;
    }
    const wavefronts: Wavefront[] = [];
    let sourceX = 80;
    let sourceY = canvas.height / 2;
    let lastEmitTime = 0;

    const render = (time: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = theme === 'dark' ? '#090d16' : '#f8fafc';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (isRunning) {
        // Move Sound Source
        const vSource = sourceVelocity * 100; // px/sec
        sourceX += (vSource / 60);
        if (sourceX > canvas.width - 60) sourceX = 80;

        // Emit new wave crest periodically
        const periodMs = 1000 / waveFrequency;
        if (time - lastEmitTime > periodMs) {
          wavefronts.push({ x: sourceX, y: sourceY, radius: 2, age: 0 });
          lastEmitTime = time;
        }

        // Expand Wavefronts at constant speed c
        for (let i = wavefronts.length - 1; i >= 0; i--) {
          const wf = wavefronts[i];
          wf.radius += (waveSpeed / 60);
          wf.age += 1;
          if (wf.radius > canvas.width) {
            wavefronts.splice(i, 1);
          }
        }
      }

      // Draw Wavefront Circles
      wavefronts.forEach(wf => {
        const alpha = Math.max(1 - wf.radius / (canvas.width * 0.8), 0.1);
        ctx.strokeStyle = `rgba(56, 189, 248, ${alpha})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(wf.x, wf.y, wf.radius, 0, Math.PI * 2);
        ctx.stroke();
      });

      // If Mach > 1 (Supersonic), draw Mach shock cone envelope!
      if (sourceVelocity >= 1.0) {
        const machAngle = Math.asin(1 / sourceVelocity);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(sourceX, sourceY);
        ctx.lineTo(sourceX - 350 * Math.cos(machAngle), sourceY - 350 * Math.sin(machAngle));
        ctx.moveTo(sourceX, sourceY);
        ctx.lineTo(sourceX - 350 * Math.cos(machAngle), sourceY + 350 * Math.sin(machAngle));
        ctx.stroke();

        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText(`⚡ Mach Cone (Shockwave sin μ = 1/M = ${(1/sourceVelocity).toFixed(2)})`, sourceX - 160, sourceY - 70);
      }

      // Draw Sound Source Object
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(sourceX, sourceY, 8, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = theme === 'dark' ? '#fff' : '#000';
      ctx.font = '10px sans-serif';
      ctx.fillText(`Source (v = ${(sourceVelocity).toFixed(2)} M)`, sourceX - 30, sourceY - 14);

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [activeLab, isRunning, sourceVelocity, waveFrequency, waveSpeed, theme]);

  // Efficiency calculation for heat engine
  const carnotEfficiency = (1 - tempCold / tempHot) * 100;

  const handleAskPhysicsTutor = () => {
    let prompt = '';
    if (activeLab === 'orbital_mechanics') {
      prompt = `Can you explain the orbital dynamics of "${orbitalPreset}" with gravitational constant G=${gravitationalConstant}? Discuss Kepler's laws of planetary motion, escape velocity derivations, and conservation of angular momentum.`;
    } else if (activeLab === 'optics_refraction') {
      if (opticsMode === 'thin_lens') {
        prompt = `Explain thin lens ray tracing for a convex lens with focal length f=${lensFocalLength}px, object distance u=${lensObjectDist}px. Derive the lens maker's formula 1/f = (n - 1)(1/R1 - 1/R2) and the linear magnification equation.`;
      } else if (opticsMode === 'snell_refraction') {
        prompt = `Explain Snell's Law of refraction at an interface between n1=${medium1Index} and n2=${medium2Index} at incident angle θ1=${incidentAngle}°. Discuss the critical angle condition for Total Internal Reflection (TIR) and its applications in optical fibers.`;
      } else {
        prompt = `Explain Young's Double Slit Experiment with slit spacing d=${slitSeparation}mm and laser wavelength λ=${wavelength}nm. Derive the constructive interference condition d sin θ = mλ and the fringe width formula β = λD/d.`;
      }
    } else if (activeLab === 'thermo_heat_engine') {
      prompt = `Explain the ${engineCycle.toUpperCase()} thermodynamic heat engine cycle operating between Th=${tempHot}K and Tc=${tempCold}K. Calculate the maximum theoretical Carnot efficiency (η = 1 - Tc/Th = ${carnotEfficiency.toFixed(1)}%), net work output W = ∮ P dV, and the Second Law of Thermodynamics (Kelvin-Planck statement).`;
    } else if (activeLab === 'wave_doppler') {
      prompt = `Explain the Doppler Effect and acoustic shockwaves for a sound source traveling at Mach ${sourceVelocity.toFixed(2)}. Derive the observer frequency formula f' = f(v ± vo)/(v ∓ vs) and the Mach cone half-angle sin(μ) = 1/M.`;
    }

    if (onSendToChat) {
      onSendToChat(prompt);
      showNotification?.("Sent Physics Simulation query to AI Tutor!", "success");
    }
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col lg:flex-row rounded-2xl overflow-hidden border shadow-xl",
      theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
    )}>
      {/* Control Sidebar */}
      <div className={cn(
        "w-full lg:w-84 flex-shrink-0 flex flex-col border-b lg:border-b-0 lg:border-r overflow-y-auto p-4 space-y-4",
        theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50/80 border-slate-200"
      )}>
        {/* Header */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-cyan-600 text-white flex items-center justify-center shadow-md">
            <Orbit size={18} />
          </div>
          <div>
            <h2 className="text-sm font-bold leading-tight">Physics Engine Sandbox</h2>
            <span className="text-[10px] text-cyan-500 font-semibold uppercase tracking-wider">Multi-Domain Simulator</span>
          </div>
        </div>

        {/* Sub-Lab Tabs */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-slate-200/60 dark:bg-slate-850">
          <button
            onClick={() => setActiveLab('orbital_mechanics')}
            className={cn(
              "py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1",
              activeLab === 'orbital_mechanics'
                ? "bg-white dark:bg-slate-700 text-cyan-600 dark:text-cyan-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Sun size={13} />
            <span>Orbits</span>
          </button>
          <button
            onClick={() => setActiveLab('optics_refraction')}
            className={cn(
              "py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1",
              activeLab === 'optics_refraction'
                ? "bg-white dark:bg-slate-700 text-cyan-600 dark:text-cyan-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Eye size={13} />
            <span>Optics</span>
          </button>
          <button
            onClick={() => setActiveLab('thermo_heat_engine')}
            className={cn(
              "py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1",
              activeLab === 'thermo_heat_engine'
                ? "bg-white dark:bg-slate-700 text-cyan-600 dark:text-cyan-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Flame size={13} />
            <span>Thermodynamics</span>
          </button>
          <button
            onClick={() => setActiveLab('wave_doppler')}
            className={cn(
              "py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-1",
              activeLab === 'wave_doppler'
                ? "bg-white dark:bg-slate-700 text-cyan-600 dark:text-cyan-300 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Waves size={13} />
            <span>Waves</span>
          </button>
        </div>

        {/* Lab-Specific Controls */}
        {activeLab === 'orbital_mechanics' && (
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Celestial Preset</label>
              <select
                value={orbitalPreset}
                onChange={e => setOrbitalPreset(e.target.value as any)}
                className={cn(
                  "w-full p-2 rounded-lg text-xs font-semibold border outline-none cursor-pointer",
                  theme === 'dark' ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-800"
                )}
              >
                <option value="sun_earth_moon">Sun - Earth - Moon System</option>
                <option value="binary_star">Binary Star with Circumbinary Planet</option>
                <option value="lagrange_points">Sun - Jupiter Lagrange Points (L4 Trojan)</option>
                <option value="chaotic_three_body">Chaotic 3-Body Problem</option>
              </select>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="opacity-75">Gravity Strength (G):</span>
                <span className="text-cyan-500 font-mono">{gravitationalConstant.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="3.0"
                step="0.1"
                value={gravitationalConstant}
                onChange={e => setGravitationalConstant(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-xs font-semibold opacity-80">Velocity Vectors:</span>
              <button
                onClick={() => setShowVectors(!showVectors)}
                className={cn(
                  "px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer",
                  showVectors ? "bg-cyan-600 text-white" : "bg-slate-200 dark:bg-slate-800 text-slate-500"
                )}
              >
                {showVectors ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>
        )}

        {activeLab === 'optics_refraction' && (
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Optics Experiment</label>
              <div className="grid grid-cols-3 gap-1">
                {(['thin_lens', 'snell_refraction', 'double_slit'] as const).map(mode => (
                  <button
                    key={mode}
                    onClick={() => setOpticsMode(mode)}
                    className={cn(
                      "py-1.5 rounded-lg text-[10px] font-bold capitalize border transition-all cursor-pointer text-center",
                      opticsMode === mode
                        ? "bg-cyan-600 text-white border-cyan-600 shadow-sm"
                        : "border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                    )}
                  >
                    {mode.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {opticsMode === 'thin_lens' && (
              <>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="opacity-75">Focal Length (f):</span>
                    <span className="text-cyan-500 font-mono">{lensFocalLength} px</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="160"
                    step="5"
                    value={lensFocalLength}
                    onChange={e => setLensFocalLength(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="opacity-75">Object Distance (u):</span>
                    <span className="text-cyan-500 font-mono">{lensObjectDist} px</span>
                  </div>
                  <input
                    type="range"
                    min="60"
                    max="260"
                    step="5"
                    value={lensObjectDist}
                    onChange={e => setLensObjectDist(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                  />
                </div>
              </>
            )}

            {opticsMode === 'snell_refraction' && (
              <>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="opacity-75">Incident Angle (θ₁):</span>
                    <span className="text-cyan-500 font-mono">{incidentAngle}°</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="85"
                    step="1"
                    value={incidentAngle}
                    onChange={e => setIncidentAngle(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold opacity-60">Medium 2 Material</label>
                  <select
                    value={medium2Index}
                    onChange={e => setMedium2Index(parseFloat(e.target.value))}
                    className={cn(
                      "w-full p-2 rounded-lg text-xs font-semibold border outline-none cursor-pointer",
                      theme === 'dark' ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-800"
                    )}
                  >
                    <option value={1.333}>Water (n = 1.333)</option>
                    <option value={1.52}>Crown Glass (n = 1.520)</option>
                    <option value={1.66}>Dense Flint Glass (n = 1.660)</option>
                    <option value={2.417}>Diamond (n = 2.417)</option>
                  </select>
                </div>
              </>
            )}

            {opticsMode === 'double_slit' && (
              <>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="opacity-75">Slit Distance (d):</span>
                    <span className="text-cyan-500 font-mono">{slitSeparation} mm</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="0.8"
                    step="0.05"
                    value={slitSeparation}
                    onChange={e => setSlitSeparation(parseFloat(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="opacity-75">Wavelength (λ):</span>
                    <span className="text-emerald-500 font-mono">{wavelength} nm</span>
                  </div>
                  <input
                    type="range"
                    min="400"
                    max="700"
                    step="10"
                    value={wavelength}
                    onChange={e => setWavelength(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                  />
                </div>
              </>
            )}
          </div>
        )}

        {activeLab === 'thermo_heat_engine' && (
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Thermodynamic Cycle</label>
              <select
                value={engineCycle}
                onChange={e => setEngineCycle(e.target.value as any)}
                className={cn(
                  "w-full p-2 rounded-lg text-xs font-semibold border outline-none cursor-pointer",
                  theme === 'dark' ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-800"
                )}
              >
                <option value="carnot">Carnot Cycle (Ideal Maximum)</option>
                <option value="otto">Otto Cycle (4-Stroke Petrol)</option>
                <option value="stirling">Stirling Cycle (External Heat)</option>
                <option value="diesel">Diesel Cycle (Compression Ignition)</option>
              </select>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="opacity-75">Hot Reservoir (T_H):</span>
                <span className="text-amber-500 font-mono">{tempHot} K</span>
              </div>
              <input
                type="range"
                min="400"
                max="1000"
                step="25"
                value={tempHot}
                onChange={e => setTempHot(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="opacity-75">Cold Reservoir (T_C):</span>
                <span className="text-blue-500 font-mono">{tempCold} K</span>
              </div>
              <input
                type="range"
                min="200"
                max="400"
                step="10"
                value={tempCold}
                onChange={e => setTempCold(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
            </div>

            {/* Efficiency Card */}
            <div className={cn(
              "p-3 rounded-xl border text-xs space-y-1",
              theme === 'dark' ? "bg-indigo-950/40 border-indigo-900" : "bg-indigo-50 border-indigo-200"
            )}>
              <div className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400">Carnot Efficiency Limit:</div>
              <div className="text-lg font-black text-indigo-500 font-mono">η = {carnotEfficiency.toFixed(1)}%</div>
              <div className="text-[10px] opacity-70">η = 1 - T_C / T_H = 1 - {tempCold}/{tempHot}</div>
            </div>
          </div>
        )}

        {activeLab === 'wave_doppler' && (
          <div className="space-y-3">
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="opacity-75">Source Speed (Mach):</span>
                <span className={cn("font-mono font-bold", sourceVelocity >= 1.0 ? "text-red-500" : "text-cyan-500")}>
                  {sourceVelocity.toFixed(2)} M {sourceVelocity >= 1.0 ? '(SUPERSONIC)' : ''}
                </span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.8"
                step="0.05"
                value={sourceVelocity}
                onChange={e => setSourceVelocity(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="opacity-75">Wave Frequency (f):</span>
                <span className="text-cyan-500 font-mono">{waveFrequency.toFixed(1)} Hz</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="3.0"
                step="0.1"
                value={waveFrequency}
                onChange={e => setWaveFrequency(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
            </div>
          </div>
        )}

        {/* Global Controls & Ask Tutor */}
        <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2 mt-auto">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={cn(
                "flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer",
                isRunning
                  ? "bg-amber-600 hover:bg-amber-500 text-white"
                  : "bg-emerald-600 hover:bg-emerald-500 text-white"
              )}
            >
              {isRunning ? <Pause size={14} /> : <Play size={14} />}
              <span>{isRunning ? 'Pause Engine' : 'Resume Engine'}</span>
            </button>
          </div>

          <button
            onClick={handleAskPhysicsTutor}
            className="w-full py-2.5 px-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/25 active:scale-95 transition-all cursor-pointer"
          >
            <Sparkles size={14} />
            <span>Consult AI Physics Tutor</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Physics Stage Viewport */}
      <div className="flex-1 relative flex flex-col min-h-[420px] bg-slate-950">
        {/* Lab Title Tag */}
        <div className="absolute top-4 left-4 z-10 flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700 text-white text-xs shadow-lg">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
          <span className="font-semibold capitalize">
            {activeLab === 'orbital_mechanics' && `Gravitational N-Body Simulation: ${orbitalPreset.replace(/_/g, ' ')}`}
            {activeLab === 'optics_refraction' && `Ray Optics & Wave Diffraction: ${opticsMode.replace(/_/g, ' ')}`}
            {activeLab === 'thermo_heat_engine' && `Thermodynamic Heat Engine: ${engineCycle.toUpperCase()} Cycle`}
            {activeLab === 'wave_doppler' && `Wave Mechanics & Doppler Sonic Cone (Mach ${sourceVelocity.toFixed(2)})`}
          </span>
        </div>

        {/* Canvases */}
        <div className="flex-1 w-full h-full flex items-center justify-center">
          {activeLab === 'orbital_mechanics' && (
            <canvas ref={orbitCanvasRef} width={680} height={460} className="w-full h-full max-w-full max-h-full block" />
          )}
          {activeLab === 'optics_refraction' && (
            <canvas ref={opticsCanvasRef} width={680} height={460} className="w-full h-full max-w-full max-h-full block" />
          )}
          {activeLab === 'thermo_heat_engine' && (
            <canvas ref={thermoCanvasRef} width={680} height={460} className="w-full h-full max-w-full max-h-full block" />
          )}
          {activeLab === 'wave_doppler' && (
            <canvas ref={waveCanvasRef} width={680} height={460} className="w-full h-full max-w-full max-h-full block" />
          )}
        </div>
      </div>
    </div>
  );
};
