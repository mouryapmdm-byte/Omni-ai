import React, { useState, useEffect, useRef } from 'react';
import {
  Sliders,
  Sparkles,
  Link,
  Link2Off,
  Volume2,
  Zap,
  Eye,
  ScrollText,
  RotateCcw,
  Check,
  X,
  Play,
  Activity,
  Layers,
  HelpCircle,
} from 'lucide-react';
import {
  QuadSpeedState,
  QuadSpeedPresetId,
  QUAD_SPEED_PRESETS,
  calculateHarmonicSpeeds,
  calculateHarmonyScore,
  deriveTypingPace,
  persistQuadSpeedState,
  TypingPace,
} from '../services/speedSyncCoordinator';

export interface QuadSpeedSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  speedState?: QuadSpeedState;
  speeds?: QuadSpeedState;
  onUpdateSpeedState?: (updated: QuadSpeedState) => void;
  onUpdateSpeeds?: (updated: QuadSpeedState) => void;
  theme?: string;
}

export const QuadSpeedSyncModal: React.FC<QuadSpeedSyncModalProps> = ({
  isOpen,
  onClose,
  speedState: propSpeedState,
  speeds: propSpeeds,
  onUpdateSpeedState: propOnUpdateSpeedState,
  onUpdateSpeeds: propOnUpdateSpeeds,
  theme = 'dark',
}) => {
  if (!isOpen) return null;

  const currentSpeeds = propSpeedState || propSpeeds || {
    typingSpeed: 1.0,
    typingPace: 'fluent',
    pronouncingSpeed: 1.0,
    visualizingSpeed: 1.0,
    scrollingSpeed: 1.0,
    isQuadLocked: true,
    presetId: 'harmonious_lecture',
  };

  const handleUpdate = (updated: QuadSpeedState) => {
    if (propOnUpdateSpeedState) propOnUpdateSpeedState(updated);
    if (propOnUpdateSpeeds) propOnUpdateSpeeds(updated);
  };

  const speedState = currentSpeeds;
  const onUpdateSpeedState = handleUpdate;

  // Local state for interactive test preview
  const [isPreviewRunning, setIsPreviewRunning] = useState<boolean>(true);
  const [previewTypedLength, setPreviewTypedLength] = useState<number>(0);
  const [previewScrollY, setPreviewScrollY] = useState<number>(0);
  const [previewShapeRotate, setPreviewShapeRotate] = useState<number>(0);

  const previewSampleText =
    "E = mc²  •  Photosynthesis transforms sunlight, water, and CO₂ into glucose  •  Newton's laws govern mechanical motion with crisp mathematical precision.";

  // Interactive live preview simulation
  useEffect(() => {
    if (!isPreviewRunning) return;

    let textPointer = 0;
    let rotation = 0;
    let scrollPos = 0;

    const interval = setInterval(() => {
      // 1. Typing progress
      textPointer = (textPointer + 1) % (previewSampleText.length + 15);
      setPreviewTypedLength(Math.min(textPointer, previewSampleText.length));

      // 2. Visualizing rotation/morph
      rotation = (rotation + 2.5 * speedState.visualizingSpeed) % 360;
      setPreviewShapeRotate(rotation);

      // 3. Scrolling position
      scrollPos = (scrollPos + 0.8 * speedState.scrollingSpeed) % 120;
      setPreviewScrollY(scrollPos);
    }, Math.max(10, Math.round(35 / speedState.typingSpeed)));

    return () => clearInterval(interval);
  }, [
    isPreviewRunning,
    speedState.typingSpeed,
    speedState.visualizingSpeed,
    speedState.scrollingSpeed,
  ]);

  const harmony = calculateHarmonyScore({
    typingSpeed: speedState.typingSpeed,
    pronouncingSpeed: speedState.pronouncingSpeed,
    visualizingSpeed: speedState.visualizingSpeed,
    scrollingSpeed: speedState.scrollingSpeed,
  });

  // Apply a curated preset
  const handleApplyPreset = (presetId: Exclude<QuadSpeedPresetId, 'custom'>) => {
    const preset = QUAD_SPEED_PRESETS[presetId];
    const updated: QuadSpeedState = {
      ...speedState,
      presetId,
      typingSpeed: preset.typingSpeed,
      typingPace: preset.typingPace,
      pronouncingSpeed: preset.pronouncingSpeed,
      visualizingSpeed: preset.visualizingSpeed,
      scrollingSpeed: preset.scrollingSpeed,
    };
    onUpdateSpeedState(updated);
    persistQuadSpeedState(updated);
  };

  // Toggle quad-harmonic lock
  const handleToggleLock = () => {
    const nextLocked = !speedState.isQuadLocked;
    const updated: QuadSpeedState = {
      ...speedState,
      isQuadLocked: nextLocked,
    };
    onUpdateSpeedState(updated);
    persistQuadSpeedState(updated);
  };

  // Speed adjusters with harmonic linking
  const handleUpdateSpeed = (
    field: 'typingSpeed' | 'pronouncingSpeed' | 'visualizingSpeed' | 'scrollingSpeed',
    val: number
  ) => {
    if (speedState.isQuadLocked) {
      const harmonics = calculateHarmonicSpeeds(field, val);
      const updated: QuadSpeedState = {
        ...speedState,
        ...harmonics,
        presetId: 'custom',
      };
      onUpdateSpeedState(updated);
      persistQuadSpeedState(updated);
    } else {
      const updated: QuadSpeedState = {
        ...speedState,
        [field]: val,
        typingPace: field === 'typingSpeed' ? deriveTypingPace(val) : speedState.typingPace,
        presetId: 'custom',
      };
      onUpdateSpeedState(updated);
      persistQuadSpeedState(updated);
    }
  };

  const handleUpdatePace = (pace: TypingPace) => {
    let speedVal = 1.0;
    if (pace === 'deliberate') speedVal = 0.65;
    else if (pace === 'fluent') speedVal = 1.0;
    else if (pace === 'swift') speedVal = 1.45;
    else if (pace === 'instant') speedVal = 2.1;

    handleUpdateSpeed('typingSpeed', speedVal);
  };

  const handleResetToGolden = () => {
    handleApplyPreset('harmonious_lecture');
  };

  return (
    <div
      id="quad-speed-sync-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-slate-900 border border-indigo-500/40 rounded-3xl p-5 sm:p-7 shadow-2xl text-slate-100 flex flex-col gap-6 ring-1 ring-indigo-500/30"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                <Sliders size={18} />
              </span>
              <h2 className="text-lg sm:text-xl font-black tracking-tight flex items-center gap-2">
                <span>Quad-Speed Synchronization Hub</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-400/40 text-indigo-300 font-mono font-bold">
                  4-Way Harmonic
                </span>
              </h2>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              Harmoniously balances <strong className="text-slate-200">1. Typing Speed</strong>,{' '}
              <strong className="text-slate-200">2. Pronouncing Speed</strong>,{' '}
              <strong className="text-slate-200">3. Visualizing Speed</strong>, and{' '}
              <strong className="text-slate-200">4. Scrolling Speed</strong> for seamless lecture
              orchestration.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
            title="Close Speed Hub"
          >
            <X size={18} />
          </button>
        </div>

        {/* Harmony Synergy Status Bar */}
        <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-inner">
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-teal-500/20 border border-indigo-400/40 text-indigo-300 font-mono font-black text-sm">
              <Sparkles size={16} className="absolute -top-1 -right-1 text-amber-300 animate-pulse" />
              {harmony.score}%
            </div>
            <div>
              <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <span>{harmony.label}</span>
                {harmony.status === 'perfect' && (
                  <span className="text-[10px] px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-semibold">
                    Optimal
                  </span>
                )}
              </div>
              <p className="text-[10px] text-slate-400">
                Pacing cadence across typewriter strokes, vocal phonemes, vector diagrams, and viewport
                lerp.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleToggleLock}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
                speedState.isQuadLocked
                  ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
              }`}
              title="Toggle Quad-Harmonic Lock: Locks all 4 speeds into golden pedagogical ratios"
            >
              {speedState.isQuadLocked ? (
                <>
                  <Link size={13} className="text-indigo-200 animate-pulse" />
                  <span>Quad-Lock: Active</span>
                </>
              ) : (
                <>
                  <Link2Off size={13} />
                  <span>Quad-Lock: Unlocked</span>
                </>
              )}
            </button>

            <button
              onClick={handleResetToGolden}
              className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all cursor-pointer flex items-center gap-1"
              title="Reset to 1.0x Golden Standard"
            >
              <RotateCcw size={12} />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Curated Golden Presets Grid */}
        <div className="space-y-2">
          <div className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Layers size={13} className="text-indigo-400" />
            <span>Master Curated Combinations</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {(
              Object.keys(QUAD_SPEED_PRESETS) as Array<
                Exclude<QuadSpeedPresetId, 'custom'>
              >
            ).map((key) => {
              const preset = QUAD_SPEED_PRESETS[key];
              const isSelected = speedState.presetId === key;

              return (
                <button
                  key={key}
                  onClick={() => handleApplyPreset(key)}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative flex flex-col justify-between gap-2.5 ${
                    isSelected
                      ? 'bg-gradient-to-b from-indigo-900/60 to-slate-900/90 border-indigo-400 shadow-lg shadow-indigo-950/40 ring-1 ring-indigo-400/50'
                      : 'bg-slate-800/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/70 text-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between w-full">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{preset.emoji}</span>
                      <div>
                        <div className="text-xs font-black text-white flex items-center gap-1">
                          <span>{preset.name}</span>
                          {isSelected && <Check size={12} className="text-emerald-400" />}
                        </div>
                        <div className="text-[10px] text-slate-400">{preset.tagline}</div>
                      </div>
                    </div>
                  </div>

                  <div className="w-full pt-1 border-t border-slate-700/50 flex flex-col gap-1">
                    <div className="text-[9px] font-mono text-indigo-300 font-bold bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-500/20 text-center">
                      {preset.badge}
                    </div>
                    <div className="grid grid-cols-4 gap-1 text-[8px] font-mono text-slate-400 text-center pt-0.5">
                      <span title="Typing Speed">✍ {preset.typingSpeed}x</span>
                      <span title="Pronouncing Speed">🗣 {preset.pronouncingSpeed}x</span>
                      <span title="Visualizing Speed">🎨 {preset.visualizingSpeed}x</span>
                      <span title="Scrolling Speed">📜 {preset.scrollingSpeed}x</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* The 4 Granular Interactive Speed Sliders */}
        <div className="space-y-4 pt-1">
          <div className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Sliders size={13} className="text-indigo-400" />
              <span>Independent Precision Calibration (The 4 Dimensions)</span>
            </span>
            {speedState.isQuadLocked && (
              <span className="text-[10px] text-indigo-300 font-normal flex items-center gap-1 lowercase">
                <Link size={10} />
                Harmonically coupled
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 1. TYPING SPEED */}
            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/70 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
                    <Zap size={14} />
                  </span>
                  <div>
                    <span className="text-xs font-bold text-slate-200">1. Typing Speed</span>
                    <span className="block text-[9px] text-slate-400">
                      Blackboard handwriting cadence & typewriter intervals
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-indigo-950/80 border border-indigo-500/30 text-indigo-300">
                    {speedState.typingSpeed.toFixed(2)}x
                  </span>
                  <span className="text-[9px] font-semibold text-slate-400 capitalize">
                    ({speedState.typingPace})
                  </span>
                </div>
              </div>

              {/* Slider */}
              <input
                id="quad-typing-speed-slider"
                type="range"
                min="0.25"
                max="3.0"
                step="0.05"
                value={speedState.typingSpeed}
                onChange={(e) => handleUpdateSpeed('typingSpeed', parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                aria-label="Typing Speed"
              />

              {/* Pace Quick Buttons */}
              <div className="grid grid-cols-4 gap-1.5">
                {(['deliberate', 'fluent', 'swift', 'instant'] as TypingPace[]).map((pace) => {
                  const isActive = speedState.typingPace === pace;
                  return (
                    <button
                      key={pace}
                      onClick={() => handleUpdatePace(pace)}
                      className={`py-1 text-[10px] font-bold rounded-lg capitalize border transition-all text-center ${
                        isActive
                          ? 'bg-indigo-600 border-indigo-400 text-white shadow-sm'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                      }`}
                    >
                      {pace}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. PRONOUNCING SPEED */}
            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/70 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-teal-500/20 text-teal-400">
                    <Volume2 size={14} />
                  </span>
                  <div>
                    <span className="text-xs font-bold text-slate-200">2. Pronouncing Speed</span>
                    <span className="block text-[9px] text-slate-400">
                      Vocal delivery tempo, phoneme timing & breathing pauses
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-teal-950/80 border border-teal-500/30 text-teal-300">
                  {speedState.pronouncingSpeed.toFixed(2)}x
                </span>
              </div>

              {/* Slider */}
              <input
                id="quad-pronouncing-speed-slider"
                type="range"
                min="0.5"
                max="2.0"
                step="0.05"
                value={speedState.pronouncingSpeed}
                onChange={(e) => handleUpdateSpeed('pronouncingSpeed', parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-teal-500"
                aria-label="Pronouncing Speed"
              />

              {/* Presets */}
              <div className="grid grid-cols-6 gap-1">
                {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => {
                  const isActive = Math.abs(speedState.pronouncingSpeed - rate) < 0.04;
                  return (
                    <button
                      key={rate}
                      onClick={() => handleUpdateSpeed('pronouncingSpeed', rate)}
                      className={`py-1 text-[9px] font-mono font-bold rounded-lg border transition-all text-center ${
                        isActive
                          ? 'bg-teal-600 border-teal-400 text-white shadow-sm'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                      }`}
                    >
                      {rate.toFixed(2)}x
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. VISUALIZING SPEED */}
            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/70 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                    <Eye size={14} />
                  </span>
                  <div>
                    <span className="text-xs font-bold text-slate-200">3. Visualizing Speed</span>
                    <span className="block text-[9px] text-slate-400">
                      Vector schematic build, SVG progressive drawing, laser pointer
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-950/80 border border-amber-500/30 text-amber-300">
                  {speedState.visualizingSpeed.toFixed(2)}x
                </span>
              </div>

              {/* Slider */}
              <input
                id="quad-visualizing-speed-slider"
                type="range"
                min="0.4"
                max="2.5"
                step="0.05"
                value={speedState.visualizingSpeed}
                onChange={(e) => handleUpdateSpeed('visualizingSpeed', parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                aria-label="Visualizing Speed"
              />

              {/* Presets */}
              <div className="grid grid-cols-6 gap-1">
                {[0.5, 0.75, 1.0, 1.35, 1.8, 2.2].map((spd) => {
                  const isActive = Math.abs(speedState.visualizingSpeed - spd) < 0.04;
                  return (
                    <button
                      key={spd}
                      onClick={() => handleUpdateSpeed('visualizingSpeed', spd)}
                      className={`py-1 text-[9px] font-mono font-bold rounded-lg border transition-all text-center ${
                        isActive
                          ? 'bg-amber-600 border-amber-400 text-white shadow-sm'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                      }`}
                    >
                      {spd.toFixed(2)}x
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. SCROLLING SPEED */}
            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/70 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-violet-500/20 text-violet-400">
                    <ScrollText size={14} />
                  </span>
                  <div>
                    <span className="text-xs font-bold text-slate-200">4. Scrolling Speed</span>
                    <span className="block text-[9px] text-slate-400">
                      Smartboard auto-tracking velocity, fluid viewport lerp
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-violet-950/80 border border-violet-500/30 text-violet-300">
                  {speedState.scrollingSpeed.toFixed(2)}x
                </span>
              </div>

              {/* Slider */}
              <input
                id="quad-scrolling-speed-slider"
                type="range"
                min="0.4"
                max="2.5"
                step="0.05"
                value={speedState.scrollingSpeed}
                onChange={(e) => handleUpdateSpeed('scrollingSpeed', parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-violet-500"
                aria-label="Scrolling Speed"
              />

              {/* Presets */}
              <div className="grid grid-cols-6 gap-1">
                {[0.5, 0.75, 1.0, 1.35, 1.8, 2.2].map((spd) => {
                  const isActive = Math.abs(speedState.scrollingSpeed - spd) < 0.04;
                  return (
                    <button
                      key={spd}
                      onClick={() => handleUpdateSpeed('scrollingSpeed', spd)}
                      className={`py-1 text-[9px] font-mono font-bold rounded-lg border transition-all text-center ${
                        isActive
                          ? 'bg-violet-600 border-violet-400 text-white shadow-sm'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                      }`}
                    >
                      {spd.toFixed(2)}x
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Live Interactive Preview Box */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Activity size={13} className="text-emerald-400 animate-pulse" />
              <span>Live Quad-Speed Synchronization Sandbox</span>
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              Live feedback across all 4 parameters
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
            {/* Live Typing & Scrolling Preview */}
            <div className="md:col-span-2 p-3 rounded-xl bg-slate-900 border border-slate-800 h-28 overflow-hidden relative font-mono text-xs text-slate-200">
              <div className="text-[9px] text-indigo-400 font-bold uppercase mb-1">
                Chalkboard Stream (Typing & Scroll Lerp)
              </div>
              <div
                className="transition-transform duration-200 ease-out"
                style={{ transform: `translateY(-${previewScrollY % 30}px)` }}
              >
                <span>{previewSampleText.slice(0, previewTypedLength)}</span>
                <span className="inline-block w-1.5 h-3.5 bg-indigo-400 ml-0.5 animate-pulse" />
              </div>
            </div>

            {/* Live Visualizing & Pronouncing Wave Preview */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 h-28 flex flex-col items-center justify-center relative overflow-hidden">
              <div className="text-[9px] text-amber-400 font-bold uppercase self-start mb-1">
                Visualizing & Phoneme Pulse
              </div>
              {/* Rotating vector glyph representing visual build speed */}
              <div
                className="w-10 h-10 border-2 border-dashed border-amber-400 rounded-lg flex items-center justify-center"
                style={{ transform: `rotate(${previewShapeRotate}deg)` }}
              >
                <div className="w-3 h-3 bg-teal-400 rounded-full animate-ping" />
              </div>
              <div className="text-[9px] text-slate-400 font-mono mt-2">
                Cadence: {speedState.visualizingSpeed.toFixed(2)}x visual •{' '}
                {speedState.pronouncingSpeed.toFixed(2)}x audio
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <div className="text-xs text-slate-400">
            Selected Preset:{' '}
            <strong className="text-indigo-300 capitalize">
              {speedState.presetId.replace('_', ' ')}
            </strong>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            Apply & Return to Classroom
          </button>
        </div>
      </div>
    </div>
  );
};
