import React, { useState, useEffect } from 'react';
import { 
  Wifi, WifiOff, Download, HardDrive, CheckCircle2, Trash2, 
  RefreshCw, Zap, ShieldCheck, Database, FileText, BookOpen
} from 'lucide-react';
import { cn } from '../lib/utils';

interface OfflinePack {
  id: string;
  chapterTitle: string;
  subject: string;
  sizeMb: number;
  isDownloaded: boolean;
  itemCount: { lessons: number; diagrams: number; audioClips: number; questions: number };
  lastSynced: string;
}

interface Props {
  theme?: 'light' | 'dark';
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const OfflineModeManager: React.FC<Props> = ({
  theme = 'light',
  showNotification
}) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [lowBandwidthMode, setLowBandwidthMode] = useState<boolean>(() => {
    return localStorage.getItem('omni_low_bandwidth_mode') === 'true';
  });
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const [packs, setPacks] = useState<OfflinePack[]>([
    {
      id: 'pack-physics-emi',
      chapterTitle: 'Physics: Electromagnetic Induction & AC Circuits',
      subject: 'Physics',
      sizeMb: 14.2,
      isDownloaded: true,
      itemCount: { lessons: 6, diagrams: 12, audioClips: 8, questions: 45 },
      lastSynced: '2 hours ago'
    },
    {
      id: 'pack-chem-organic',
      chapterTitle: 'Chemistry: Aldehydes, Ketones & Carboxylic Acids',
      subject: 'Chemistry',
      sizeMb: 18.5,
      isDownloaded: false,
      itemCount: { lessons: 8, diagrams: 24, audioClips: 10, questions: 60 },
      lastSynced: 'Not cached'
    },
    {
      id: 'pack-bio-genetics',
      chapterTitle: 'Biology: Principles of Inheritance & Molecular Basis',
      subject: 'Biology',
      sizeMb: 22.0,
      isDownloaded: true,
      itemCount: { lessons: 10, diagrams: 32, audioClips: 14, questions: 75 },
      lastSynced: 'Yesterday'
    },
    {
      id: 'pack-math-calc',
      chapterTitle: 'Mathematics: Differential Equations & Vector 3D',
      subject: 'Mathematics',
      sizeMb: 11.4,
      isDownloaded: false,
      itemCount: { lessons: 7, diagrams: 18, audioClips: 6, questions: 50 },
      lastSynced: 'Not cached'
    }
  ]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showNotification?.("Network restored! Synchronized with cloud.", "success");
    };
    const handleOffline = () => {
      setIsOnline(false);
      showNotification?.("You are offline. Seamlessly switched to cached lessons.", "warning");
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [showNotification]);

  const handleDownloadPack = (packId: string) => {
    setDownloadingId(packId);
    setTimeout(() => {
      setPacks(prev => prev.map(p => {
        if (p.id === packId) {
          return { ...p, isDownloaded: true, lastSynced: 'Just now' };
        }
        return p;
      }));
      setDownloadingId(null);
      showNotification?.("Offline lesson package cached locally!", "success");
    }, 1200);
  };

  const handleDeletePack = (packId: string) => {
    setPacks(prev => prev.map(p => {
      if (p.id === packId) {
        return { ...p, isDownloaded: false, lastSynced: 'Not cached' };
      }
      return p;
    }));
    showNotification?.("Package removed from local device cache.", "info");
  };

  const toggleLowBandwidth = () => {
    const newVal = !lowBandwidthMode;
    setLowBandwidthMode(newVal);
    localStorage.setItem('omni_low_bandwidth_mode', String(newVal));
    showNotification?.(
      newVal ? "Low-Bandwidth Mode Enabled (Saves 85% Data)" : "Standard High-Fidelity Mode Restored",
      "info"
    );
  };

  const totalDownloadedMb = packs.filter(p => p.isDownloaded).reduce((acc, p) => acc + p.sizeMb, 0);
  const isDark = theme === 'dark';

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center text-white shadow-md">
            {isOnline ? <Wifi size={22} /> : <WifiOff size={22} className="text-rose-300 animate-pulse" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Offline Mode & Low-Bandwidth Suite</h2>
              <span className={cn(
                "px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider border",
                isOnline ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-amber-500/10 text-amber-400 border-amber-500/20"
              )}>
                {isOnline ? "Cloud Synchronized" : "Local Storage Active"}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Zero-buffer offline playback &bull; 85% data saver &bull; IndexedDB persistent storage
            </p>
          </div>
        </div>

        {/* Low-Bandwidth Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleLowBandwidth}
            className={cn(
              "px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 cursor-pointer border",
              lowBandwidthMode 
                ? "bg-amber-500/20 text-amber-300 border-amber-500/40" 
                : (isDark ? "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700" : "bg-slate-100 text-slate-700 border-slate-200")
            )}
          >
            <Zap size={14} className={lowBandwidthMode ? "text-amber-400" : "text-slate-400"} />
            {lowBandwidthMode ? "Data Saver: ON" : "Data Saver: OFF"}
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Storage Health Metric */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className={cn(
            "p-4 rounded-xl border flex flex-col justify-between",
            isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Local Cached Footprint</span>
              <HardDrive size={16} className="text-sky-400" />
            </div>
            <div className="my-2">
              <span className="text-2xl font-black text-sky-400">{totalDownloadedMb.toFixed(1)} MB</span>
            </div>
            <p className="text-[11px] text-slate-400">500 MB Available on device</p>
          </div>

          <div className={cn(
            "p-4 rounded-xl border flex flex-col justify-between",
            isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Network State</span>
              {isOnline ? <Wifi size={16} className="text-emerald-400" /> : <WifiOff size={16} className="text-rose-400" />}
            </div>
            <div className="my-2">
              <span className="text-xl font-bold">{isOnline ? "High-Speed Online" : "Disconnected (Offline)"}</span>
            </div>
            <p className="text-[11px] text-slate-400">Auto-reconnects when signal recovers</p>
          </div>

          <div className={cn(
            "p-4 rounded-xl border flex flex-col justify-between",
            isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Low-Data Mode</span>
              <Zap size={16} className="text-amber-400" />
            </div>
            <div className="my-2">
              <span className="text-xl font-bold">{lowBandwidthMode ? "Aggressive (85% Saved)" : "Full Video/Audio"}</span>
            </div>
            <p className="text-[11px] text-slate-400">Replaces video streams with vector diagrams</p>
          </div>
        </div>

        {/* Offline Download Packages List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Database size={14} className="text-sky-400" /> Available Curriculum Offline Packages
            </h3>
            <span className="text-xs text-slate-400">Download once, learn anywhere without internet</span>
          </div>

          <div className="space-y-3">
            {packs.map((pack) => (
              <div
                key={pack.id}
                className={cn(
                  "p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition",
                  pack.isDownloaded
                    ? (isDark ? "bg-slate-950/80 border-sky-900/40" : "bg-sky-50/40 border-sky-200")
                    : (isDark ? "bg-slate-950/40 border-slate-800" : "bg-white border-slate-200")
                )}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-100">{pack.chapterTitle}</h4>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
                      {pack.sizeMb} MB
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                    <span>{pack.itemCount.lessons} Lessons</span> &bull;
                    <span>{pack.itemCount.diagrams} SVGs</span> &bull;
                    <span>{pack.itemCount.questions} Questions</span> &bull;
                    <span className="text-sky-400 font-medium">Status: {pack.lastSynced}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {pack.isDownloaded ? (
                    <>
                      <span className="px-3 py-1.5 bg-emerald-500/10 text-emerald-400 text-xs font-bold rounded-lg flex items-center gap-1 border border-emerald-500/20">
                        <CheckCircle2 size={13} /> Cached
                      </span>
                      <button
                        onClick={() => handleDeletePack(pack.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition cursor-pointer"
                        title="Delete from device"
                      >
                        <Trash2 size={15} />
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => handleDownloadPack(pack.id)}
                      disabled={downloadingId === pack.id}
                      className="px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-bold rounded-lg shadow-md transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download size={13} className={downloadingId === pack.id ? "animate-bounce" : ""} />
                      {downloadingId === pack.id ? "Caching..." : "Download for Offline"}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
