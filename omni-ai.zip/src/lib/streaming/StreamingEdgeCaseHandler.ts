/**
 * StreamingEdgeCaseHandler
 * Handles tricky edge cases during character-by-character live streaming:
 * - Unicode surrogate pairs & Devanagari combining marks (prevents splitting glyphs mid-stream)
 * - Nested markdown (e.g. bold inside headers: #### **Bold Heading**)
 * - Partial tables (hides incomplete markdown table rows)
 * - Partial LaTeX formulas & escaped dollar signs
 */
export class StreamingEdgeCaseHandler {
  /**
   * Safe Unicode split to ensure Devanagari / surrogate pairs are never split mid-character.
   */
  static safeUnicodeSplit(text: string, index: number): number {
    if (index <= 0 || index >= text.length) return index;

    // Surrogate pair check (0xD800 - 0xDBFF)
    const prevCharCode = text.charCodeAt(index - 1);
    if (prevCharCode >= 0xd800 && prevCharCode <= 0xdbff) {
      return Math.max(0, index - 1);
    }

    // Devanagari combining characters (0x0900 - 0x097F) & standard combining marks (0x0300 - 0x036F)
    const currentCharCode = text.charCodeAt(index);
    if (
      (currentCharCode >= 0x0300 && currentCharCode <= 0x036f) ||
      (currentCharCode >= 0x0900 && currentCharCode <= 0x0903) ||
      (currentCharCode >= 0x093a && currentCharCode <= 0x094f) ||
      (currentCharCode >= 0x0951 && currentCharCode <= 0x0957) ||
      (currentCharCode >= 0x0962 && currentCharCode <= 0x0963)
    ) {
      return Math.max(0, index - 1);
    }

    return index;
  }

  /**
   * Detects nested unclosed markdown (e.g. bold inside heading: "#### **Bold").
   */
  static findNestedMarkdown(text: string): number {
    const headerRegex = /(#{1,6}\s+)(.*)$/gm;
    let match;
    let safeIndex = text.length;

    while ((match = headerRegex.exec(text)) !== null) {
      const content = match[2];
      const boldCount = (content.match(/\*\*/g) || []).length;
      if (boldCount % 2 !== 0) {
        safeIndex = Math.min(safeIndex, match.index);
      }
    }

    return safeIndex;
  }

  /**
   * Detects partial tables and hides incomplete table rows at stream boundary.
   */
  static findPartialTable(text: string): number {
    const lines = text.split('\n');
    let tableStart = -1;
    let tableEnd = -1;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const isTableRow = line.includes('|');
      const isTableSeparator = /^\s*\|?[\s\-:|]+\|?\s*$/.test(line);

      if (isTableRow || isTableSeparator) {
        if (tableStart === -1) tableStart = i;
        tableEnd = i;
      } else if (tableStart !== -1) {
        break;
      }
    }

    if (tableStart !== -1 && tableEnd === lines.length - 1) {
      if (!text.endsWith('\n')) {
        return lines.slice(0, tableStart).join('\n').length;
      }
    }

    return text.length;
  }

  /**
   * Finds incomplete LaTeX formulas with open delimiters ($ or $$) or unclosed braces.
   */
  static findPartialFormula(text: string): number {
    const cleaned = text.replace(/\\\$/g, '');
    const displayCount = (cleaned.match(/\$\$/g) || []).length;
    if (displayCount % 2 !== 0) {
      const lastIndex = text.lastIndexOf('$$');
      return lastIndex >= 0 ? lastIndex : text.length;
    }

    // Inline math $...$
    const withoutDisplay = cleaned.replace(/\$\$/g, '  ');
    const dollarIndices: number[] = [];
    for (let i = 0; i < withoutDisplay.length; i++) {
      if (withoutDisplay[i] === '$') {
        dollarIndices.push(i);
      }
    }

    if (dollarIndices.length % 2 !== 0) {
      return dollarIndices[dollarIndices.length - 1];
    }

    return text.length;
  }
}
