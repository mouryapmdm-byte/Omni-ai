import React, { useState, useRef, useEffect } from 'react';
import { X, Monitor, MonitorOff, AlertCircle, Film, Radio } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { ScreenRecorder } from './ScreenRecorder';

interface ScreenShareProps {
  theme: 'light' | 'dark';
  onClose: () => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  initialTab?: 'share' | 'recorder';
}

export const ScreenShare: React.FC<ScreenShareProps> = ({ 
  theme, 
  onClose, 
  showNotification,
  initialTab = 'recorder'
}) => {
  const [activeTab, setActiveTab] = useState<'share' | 'recorder'>(initialTab);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const startSharing = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      });
      setStream(mediaStream);
      setError(null);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      showNotification?.("Screen sharing started successfully!", "success");
      
      mediaStream.getVideoTracks()[0].onended = () => {
        stopSharing();
      };
    } catch (err: any) {
      console.error("Error starting screen share:", err);
      setError("Permission denied or sharing failed.");
      showNotification?.("Screen share failed: " + err.message, "error");
    }
  };

  const stopSharing = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    return () => stopSharing();
  }, []);

  if (activeTab === 'recorder') {
    return (
      <div className="w-full h-full flex flex-col relative">
        <div className="absolute top-3 right-16 z-20 flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800 backdrop-blur-md">
          <button
            onClick={() => setActiveTab('recorder')}
            className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer bg-rose-600 text-white shadow-md"
          >
            <Film size={14} /> Screen Recorder
          </button>
          <button
            onClick={() => setActiveTab('share')}
            className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer text-slate-400 hover:text-slate-200"
          >
            <Monitor size={14} /> Live Screen Share
          </button>
        </div>
        <ScreenRecorder 
          theme={theme} 
          onClose={onClose} 
          showNotification={showNotification} 
        />
      </div>
    );
  }

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-hidden border-l transition-all duration-300 shadow-2xl animate-in fade-in zoom-in-95 rounded-2xl border",
      theme === 'dark' ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
    )}>
      {/* Header */}
      <div className={cn(
        "px-6 py-4 border-b flex items-center justify-between shrink-0",
        theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center border transition-all duration-500",
            stream 
              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/25" 
              : "bg-indigo-500/10 text-indigo-400 border-indigo-500/25"
          )}>
            <Monitor size={20} className={stream ? "animate-pulse" : ""} />
          </div>
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider">Screen Share Studio</h3>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">
              {stream ? "Active Broadcast" : "Ready to Share Screen"}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800 backdrop-blur-md">
            <button
              onClick={() => setActiveTab('recorder')}
              className="px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer text-slate-400 hover:text-slate-200"
            >
              <Film size={14} /> Screen Recorder
            </button>
            <button
              onClick={() => setActiveTab('share')}
              className="px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer bg-indigo-600 text-white shadow-md"
            >
              <Monitor size={14} /> Live Screen Share
            </button>
          </div>

          <button 
            onClick={onClose} 
            className="p-2 rounded-full hover:bg-slate-500/20 text-slate-400 transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-6 flex flex-col items-center justify-center relative overflow-hidden bg-[radial-gradient(rgba(99,102,241,0.03)_1px,transparent_1px)] bg-[size:20px_20px]">
        {stream ? (
          <div className="w-full h-full max-w-5xl relative group animate-in fade-in duration-500">
            <video 
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-contain bg-black rounded-2xl shadow-2xl ring-1 ring-slate-800"
            />
            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
              <button 
                onClick={stopSharing}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl shadow-lg transition-all active:scale-95 flex items-center gap-2 text-xs font-bold cursor-pointer"
              >
                <MonitorOff size={16} /> Stop Sharing
              </button>
            </div>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-900/80 backdrop-blur-md px-4 py-2 rounded-full border border-slate-700/50 flex items-center gap-3 shadow-2xl">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Live: Sharing Screen</span>
            </div>
          </div>
        ) : (
          <div className="text-center max-w-md space-y-6">
            <div className="relative">
              <div className="absolute inset-0 bg-indigo-500/20 blur-3xl rounded-full scale-150"></div>
              <Monitor size={64} className="mx-auto text-indigo-500 relative animate-bounce" />
            </div>
            <div className="space-y-2 relative">
              <h4 className="text-xl font-black tracking-tight">Share Your Workspace</h4>
              <p className="text-xs text-slate-500 font-medium leading-relaxed">
                Seamlessly broadcast your desktop, a specific window, or a browser tab. Perfect for showing code, presentations, or solving problems together.
              </p>
            </div>
            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 flex items-center gap-2 text-red-400 text-[11px] font-bold">
                <AlertCircle size={14} /> {error}
              </div>
            )}
            <button
              onClick={startSharing}
              className="px-8 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-indigo-600/20 transition-all active:scale-95 flex items-center gap-2 mx-auto cursor-pointer"
            >
              <Monitor size={16} />
              Start Screen Share
            </button>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest pt-4">
              Requires browser permissions
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

