/**
 * Professor Clarity's Active Pedagogy Vocabulary Enhancement Architecture
 * Complete subject-specific vocabulary engine with root breakdown (Greek/Latin),
 * visual cards, network graphs, confusion pairs, pronunciation guides,
 * sentence progressions, bilingual translations, and automatic quizzes.
 */

export interface WordRootPart {
  part: string;
  meaning: string;
  origin: 'Greek' | 'Latin' | 'French' | 'German' | 'Arabic' | 'Sanskrit';
}

export interface VocabularyTerm {
  id: string;
  term: string;
  subject: 'biology' | 'chemistry' | 'physics' | 'mathematics' | 'general_science';
  subtopic: string;
  syllables: string;
  syllableCount: number;
  phoneticIpa: string;
  hindiTranslation: string;
  hindiPhonetic: string;
  roots: WordRootPart[];
  literalMeaning: string;
  clarityExplanation: string; // The active teaching explanation (not robotic definition)
  analogy: string;
  sentences: {
    simple: string;
    technical: string;
    exam: string;
    application: string;
  };
  examRelevance: 'High' | 'Very High' | 'Critical';
  examQuestionTypes: string[];
  confusionPair?: {
    pairWith: string;
    keyDifference: string;
    aspects: { aspect: string; thisTerm: string; otherTerm: string }[];
  };
  network: {
    category: string;
    children: string[];
    related: string[];
  };
  quiz: {
    question: string;
    options: string[];
    correctAnswer: string;
    explanation: string;
  };
  mnemonic?: string;
}

export const VOCABULARY_MASTER_DATABASE: Record<string, VocabularyTerm> = {
  // =========================================================================
  // BIOLOGY VOCABULARY
  // =========================================================================
  'transcription': {
    id: 'bio-transcription',
    term: 'Transcription',
    subject: 'biology',
    subtopic: 'Molecular Genetics & Central Dogma',
    syllables: 'Tran-scrip-tion',
    syllableCount: 3,
    phoneticIpa: '/trænˈskrɪpʃən/',
    hindiTranslation: 'अनुलेखन',
    hindiPhonetic: 'Anulekhan',
    roots: [
      { part: 'Trans', meaning: 'Across / Over', origin: 'Latin' },
      { part: 'Scribere', meaning: 'To write', origin: 'Latin' }
    ],
    literalMeaning: 'Writing across genetic code from DNA into RNA',
    clarityExplanation: 'The enzymatic process in the cell nucleus where RNA Polymerase synthesizes a complementary messenger RNA (mRNA) strand using a DNA template.',
    analogy: 'Like copying a master reference blueprint in a locked library onto a portable note sheet you can take to the workshop.',
    sentences: {
      simple: 'Transcription copies genetic instructions from DNA into messenger RNA.',
      technical: 'Transcription is driven by RNA Polymerase II binding to core promoter consensus sequences such as the TATA box.',
      exam: "During eukaryotic transcription, pre-mRNA undergoes 5' capping, polyadenylation, and intron splicing before nuclear export.",
      application: 'Synthetic transcription factors are leveraged in targeted gene therapy to activate silenced protective genes.'
    },
    examRelevance: 'Critical',
    examQuestionTypes: ['Central Dogma (5 Marks)', 'RNA Polymerase Steps', 'Transcription Unit Structure'],
    confusionPair: {
      pairWith: 'Translation',
      keyDifference: 'Transcription copies DNA into mRNA in the nucleus; Translation decodes mRNA into polypeptide proteins at the ribosome.',
      aspects: [
        { aspect: 'Starting Template', thisTerm: 'DNA template strand', otherTerm: 'mRNA codon transcript' },
        { aspect: 'Primary Enzyme', thisTerm: 'RNA Polymerase', otherTerm: 'Ribosome & Peptidyl Transferase' },
        { aspect: 'Location (Eukaryotes)', thisTerm: 'Cell Nucleus', otherTerm: 'Cytoplasm / Rough ER' },
        { aspect: 'Final Molecule', thisTerm: 'Single-stranded RNA', otherTerm: 'Functional protein polypeptide' }
      ]
    },
    network: {
      category: 'Molecular Genetics',
      children: ['Promoter', 'TATA Box', 'RNA Polymerase', 'mRNA', 'Exons'],
      related: ['Translation', 'Codon', 'DNA Replication', 'Gene Expression']
    },
    quiz: {
      question: "What is the literal Latin origin of the term 'Transcription'?",
      options: ['Trans (Across) + Scribere (To Write)', 'Tran (Break) + Script (Language)', 'Tract (Pull) + Script (Book)', 'Trans (Transfer) + Cript (Hidden)'],
      correctAnswer: 'Trans (Across) + Scribere (To Write)',
      explanation: "'Trans' means across and 'scribere' means to write. Literally: rewriting information across from DNA to RNA!"
    },
    mnemonic: 'D-to-R (DNA to RNA = Transcription; RNA to Protein = Translation)'
  },

  'translation': {
    id: 'bio-translation',
    term: 'Translation',
    subject: 'biology',
    subtopic: 'Protein Biosynthesis',
    syllables: 'Trans-la-tion',
    syllableCount: 3,
    phoneticIpa: '/trænzˈleɪʃən/',
    hindiTranslation: 'रूपांतरण / प्रोटीन संश्लेषण',
    hindiPhonetic: 'Rupantaran',
    roots: [
      { part: 'Trans', meaning: 'Across', origin: 'Latin' },
      { part: 'Latus', meaning: 'Carried / Borne', origin: 'Latin' }
    ],
    literalMeaning: 'Carrying across information from nucleic acid into amino acid language',
    clarityExplanation: 'The cellular ribosomal process where mRNA triplet codons are translated into a sequence of amino acids to construct a protein.',
    analogy: 'Like an interpreter reading a message in one language and speaking it in another language for the builder.',
    sentences: {
      simple: 'Translation builds proteins using instructions carried by mRNA.',
      technical: "Ribosomes read mRNA 5' to 3', facilitating peptide bond formation catalyzed by 23S/28S rRNA peptidyl transferase.",
      exam: 'AUG functions as the universal initiation start codon coding for Methionine in translation.',
      application: 'Ribosome-targeting antibiotics selectively inhibit bacterial translation without harming human cells.'
    },
    examRelevance: 'Critical',
    examQuestionTypes: ['Genetic Code Characteristics', 'Role of tRNA Adapter', 'Initiation & Termination'],
    confusionPair: {
      pairWith: 'Transcription',
      keyDifference: 'Translation makes proteins at ribosomes; Transcription makes RNA in the nucleus.',
      aspects: [
        { aspect: 'Builder Organelle', thisTerm: 'Ribosome', otherTerm: 'RNA Polymerase' },
        { aspect: 'Adapter Molecule', thisTerm: 'tRNA with anticodon', otherTerm: 'Ribonucleotide triphosphates' },
        { aspect: 'Product', thisTerm: 'Polypeptide chain', otherTerm: 'Single-stranded mRNA' }
      ]
    },
    network: {
      category: 'Molecular Biology',
      children: ['Ribosome', 'tRNA', 'Codon', 'Anticodon', 'Aminoacyl-tRNA Synthetase'],
      related: ['Central Dogma', 'Peptide Bond', 'Genetic Code']
    },
    quiz: {
      question: "Which organelle serves as the workbench for translation?",
      options: ['Nucleus', 'Ribosome', 'Golgi Apparatus', 'Lysosome'],
      correctAnswer: 'Ribosome',
      explanation: "Ribosomes bind mRNA and tRNA to catalyze peptide bond formation during translation."
    },
    mnemonic: 'Translate = Turn nucleic acid language into protein language!'
  },

  'stomata': {
    id: 'bio-stoma',
    term: 'Stomata',
    subject: 'biology',
    subtopic: 'Plant Histology & Gas Exchange',
    syllables: 'Sto-ma-ta (Singular: Sto-ma)',
    syllableCount: 3,
    phoneticIpa: '/ˈstəʊmətə/',
    hindiTranslation: 'रंध्र / पर्णरंध्र',
    hindiPhonetic: 'Randhra',
    roots: [
      { part: 'Stoma', meaning: 'Mouth / Opening', origin: 'Greek' }
    ],
    literalMeaning: 'Microscopic mouth-like pores',
    clarityExplanation: 'Microscopic adjustable doorways on the leaf surface regulated by kidney-shaped guard cells to let $CO_2$ enter and let $O_2$ and water vapor exit.',
    analogy: 'Like automatic sliding glass doors of a shopping mall opening and closing based on crowd traffic and weather.',
    sentences: {
      simple: 'Stomata open in daylight so leaves can take in carbon dioxide.',
      technical: 'Stomatal aperture is actively regulated by reversible $K^+$ ion transport and turgor pressure changes in guard cells.',
      exam: 'Stomata facilitate gaseous exchange ($CO_2/O_2$) and drive the transpiration pull necessary for water ascent.',
      application: 'Drought-tolerant transgenic crops possess engineered stomatal sensitivity to minimize irrigation requirements.'
    },
    examRelevance: 'High',
    examQuestionTypes: ['Mechanism of Opening (3 Marks)', 'Diagram of Guard Cells', 'Transpiration Regulation'],
    network: {
      category: 'Epidermal Tissue',
      children: ['Guard Cells', 'Subsidiary Cells', 'Stomatal Pore'],
      related: ['Transpiration', 'Turgor Pressure', 'Potassium Ion Flux', 'Abscisic Acid']
    },
    quiz: {
      question: "What does the root word 'Stoma' mean in Greek?",
      options: ['Skin', 'Mouth / Opening', 'Green cell', 'Water channel'],
      correctAnswer: 'Mouth / Opening',
      explanation: "'Stoma' means mouth in Greek (also used in stomach and stomatology). Stomata are literally the mouths of the leaf."
    }
  },

  'mitochondria': {
    id: 'bio-mito',
    term: 'Mitochondria',
    subject: 'biology',
    subtopic: 'Cell Biology',
    syllables: 'Mi-to-chon-dri-a (Singular: Mi-to-chon-dri-on)',
    syllableCount: 5,
    phoneticIpa: '/ˌmaɪtəˈkɒndriə/',
    hindiTranslation: 'माइटोकॉन्ड्रिया / सूत्रकणिका',
    hindiPhonetic: 'Sootra-kanika',
    roots: [
      { part: 'Mitos', meaning: 'Thread / Warp', origin: 'Greek' },
      { part: 'Chondrion', meaning: 'Granule / Grain-like', origin: 'Greek' }
    ],
    literalMeaning: 'Thread-like granules',
    clarityExplanation: 'The cellular power plants that oxidize metabolic fuels through the Krebs cycle and oxidative phosphorylation to produce cellular ATP currency.',
    analogy: 'The power generating station of a bustling smart city producing electricity for every home.',
    sentences: {
      simple: 'Mitochondria are known as the powerhouses of the cell.',
      technical: 'Mitochondria feature a folded inner membrane (cristae) generating an electrochemical proton gradient for $F_0-F_1$ ATP synthase.',
      exam: 'Mitochondria carry out oxidative phosphorylation and aerobic cellular respiration yielding up to 36-38 ATP per glucose.',
      application: 'Mitochondrial replacement therapy helps prevent severe inherited neuromuscular disorders.'
    },
    examRelevance: 'Very High',
    examQuestionTypes: ['Chemiosmosis (5 Marks)', 'Structure of Cristae', 'Endosymbiotic Theory'],
    confusionPair: {
      pairWith: 'Ribosome',
      keyDifference: 'Mitochondria generate energy currency (ATP); Ribosomes consume energy to synthesize proteins.',
      aspects: [
        { aspect: 'Primary Output', thisTerm: 'ATP energy currency', otherTerm: 'Polypeptide proteins' },
        { aspect: 'Membrane Boundary', thisTerm: 'Double-membrane bound', otherTerm: 'Non-membranous complex' },
        { aspect: 'Metabolic Nature', thisTerm: 'Catabolic oxidation', otherTerm: 'Anabolic polymer synthesis' }
      ]
    },
    network: {
      category: 'Cellular Organelles',
      children: ['Cristae', 'Mitochondrial Matrix', 'ATP Synthase', 'Cytochrome c'],
      related: ['Krebs Cycle', 'Electron Transport Chain', 'Proton Gradient', 'Endosymbiosis']
    },
    quiz: {
      question: "Which Greek roots combine to form the word 'Mitochondria'?",
      options: ['Mitos (Thread) + Chondrion (Granule)', 'Mikros (Small) + Tonos (Tension)', 'Mito (Center) + Chondros (Cartilage)', 'Mega (Large) + Dria (Energy)'],
      correctAnswer: 'Mitos (Thread) + Chondrion (Granule)',
      explanation: "Microscopists named it from 'mitos' (thread) and 'chondrion' (grain) because it appeared as tiny granular threads under early microscopes."
    }
  },

  'ribosome': {
    id: 'bio-ribosome',
    term: 'Ribosome',
    subject: 'biology',
    subtopic: 'Cell Organelles & Protein Machinery',
    syllables: 'Ri-bo-some',
    syllableCount: 3,
    phoneticIpa: '/ˈraɪbəsoʊm/',
    hindiTranslation: 'राइबोसोम',
    hindiPhonetic: 'Ribosome',
    roots: [
      { part: 'Ribo', meaning: 'Ribose nucleic acid', origin: 'German' },
      { part: 'Soma', meaning: 'Body', origin: 'Greek' }
    ],
    literalMeaning: 'RNA-rich cellular body',
    clarityExplanation: 'Non-membranous ribonucleoprotein complexes made of ribosomal RNA and proteins that assemble amino acids into polypeptide chains.',
    analogy: 'The 3D printer of the cell that takes digital digital blueprints (mRNA) and prints physical functional parts (proteins).',
    sentences: {
      simple: 'Ribosomes are the protein factories of all living cells.',
      technical: 'Bacterial 70S ribosomes consist of 50S and 30S subunits, whereas eukaryotic 80S ribosomes consist of 60S and 40S subunits.',
      exam: 'The catalytic core of the ribosome is a ribozyme (23S rRNA in bacteria, 28S in eukaryotes) that forms peptide bonds.',
      application: 'Structural biology of ribosomes earned the 2009 Nobel Prize and enabled structure-based design of novel antibiotics.'
    },
    examRelevance: 'Very High',
    examQuestionTypes: ['Prokaryotic vs Eukaryotic Ribosomes', 'Ribozyme Concept', 'Sites A, P, and E'],
    network: {
      category: 'Cellular Machinery',
      children: ['Large Subunit', 'Small Subunit', 'A Site', 'P Site', 'E Site'],
      related: ['rRNA', 'Peptidyl Transferase', 'Polysome', 'Rough Endoplasmic Reticulum']
    },
    quiz: {
      question: "The Greek root 'Soma' in Ribosome means:",
      options: ['Thread', 'Body', 'Color', 'Seed'],
      correctAnswer: 'Body',
      explanation: "'Soma' means body in Greek (also found in chromosome, centrosome, and somatic cells)."
    }
  },

  // =========================================================================
  // CHEMISTRY VOCABULARY
  // =========================================================================
  'electrolysis': {
    id: 'chem-electro',
    term: 'Electrolysis',
    subject: 'chemistry',
    subtopic: 'Electrochemistry',
    syllables: 'E-lec-trol-y-sis',
    syllableCount: 5,
    phoneticIpa: '/ɪˌlekˈtrɒlɪsɪs/',
    hindiTranslation: 'विद्युत अपघटन',
    hindiPhonetic: 'Vidyut Apaghatan',
    roots: [
      { part: 'Electro', meaning: 'Electricity (from Amber / Elektron)', origin: 'Greek' },
      { part: 'Lysis', meaning: 'Splitting / Breaking apart', origin: 'Greek' }
    ],
    literalMeaning: 'Splitting chemical compounds using electric current',
    clarityExplanation: 'Driving a non-spontaneous chemical decomposition by passing direct electric current through an electrolyte melt or solution.',
    analogy: 'Using electric scissors to snip strong chemical bonds apart into pure elements.',
    sentences: {
      simple: 'Electrolysis uses electricity to split water into hydrogen and oxygen.',
      technical: 'Electrolysis induces non-spontaneous redox transformations where reduction occurs at the cathode and oxidation at the anode.',
      exam: 'Faraday’s First Law of Electrolysis states that the mass deposited $m = Z \\cdot I \\cdot t = Z \\cdot Q$.',
      application: 'Industrial electrolysis is universally employed in the Hall-Héroult process for commercial aluminum smelting.'
    },
    examRelevance: 'Critical',
    examQuestionTypes: ['Faraday’s Laws Numericals (3-5 Marks)', 'Anode/Cathode Reactions', 'Overvoltage Concept'],
    confusionPair: {
      pairWith: 'Galvanic / Voltaic Cell',
      keyDifference: 'Electrolytic cells consume electrical energy to drive chemical reactions; Galvanic cells produce electrical energy from spontaneous chemical reactions.',
      aspects: [
        { aspect: 'Energy Conversion', thisTerm: 'Electrical $\\to$ Chemical Energy', otherTerm: 'Chemical $\\to$ Electrical Energy' },
        { aspect: 'Spontaneity', thisTerm: 'Non-spontaneous ($\\Delta G > 0$)', otherTerm: 'Spontaneous ($\\Delta G < 0$)' },
        { aspect: 'Anode Polarity', thisTerm: 'Positive ($+$) pole', otherTerm: 'Negative ($-$) pole' }
      ]
    },
    network: {
      category: 'Electrochemistry',
      children: ['Anode', 'Cathode', 'Electrolyte', 'Faraday Constant'],
      related: ['Overpotential', 'Standard Electrode Potential', 'Electroplating']
    },
    quiz: {
      question: "In electrolysis, oxidation always occurs at the:",
      options: ['Cathode', 'Anode', 'Salt bridge', 'External voltmeter'],
      correctAnswer: 'Anode',
      explanation: "Remember the mnemonic 'An Ox and Red Cat' — Oxidation always occurs at the Anode, Reduction at the Cathode!"
    },
    mnemonic: 'An Ox, Red Cat (Anode = Oxidation, Reduction = Cathode)'
  },

  'polymerisation': {
    id: 'chem-poly',
    term: 'Polymerisation',
    subject: 'chemistry',
    subtopic: 'Macromolecules & Polymers',
    syllables: 'Pol-y-mer-i-sa-tion',
    syllableCount: 6,
    phoneticIpa: '/pəˌlɪməraɪˈzeɪʃn/',
    hindiTranslation: 'बहुलकीकरण',
    hindiPhonetic: 'Bahulakikaran',
    roots: [
      { part: 'Poly', meaning: 'Many / Multiple', origin: 'Greek' },
      { part: 'Meros', meaning: 'Part / Share / Unit', origin: 'Greek' }
    ],
    literalMeaning: 'Linking many repeating parts together into one giant chain',
    clarityExplanation: 'The chemical reaction in which hundreds of tiny building-block molecules (monomers) join covalently into giant macro-chains (polymers).',
    analogy: 'Snapping thousands of individual plastic Lego bricks together to build an unbreakable suspension bridge.',
    sentences: {
      simple: 'Polymerisation joins small monomer units to make plastics and DNA.',
      technical: 'Addition polymerisation occurs via radical or ionic chain mechanisms without eliminating byproduct molecules.',
      exam: 'Differentiate between chain-growth (addition) and step-growth (condensation) polymerisation with suitable equations.',
      application: 'Bio-compatible polymerisation enables self-healing synthetic skin and targeted drug delivery hydrogels.'
    },
    examRelevance: 'High',
    examQuestionTypes: ['Addition vs Condensation (3 Marks)', 'Classification by Molecular Forces', 'Ziegler-Natta Catalyst'],
    network: {
      category: 'Organic Macromolecules',
      children: ['Monomer', 'Addition Polymer', 'Condensation Polymer', 'Copolymer'],
      related: ['Cross-linking', 'Vulcanization', 'Thermoplastics', 'Thermosets']
    },
    quiz: {
      question: "The Greek root 'meros' in polymer literally translates to:",
      options: ['Chain', 'Part / Unit', 'Heavy', 'Plastic'],
      correctAnswer: 'Part / Unit',
      explanation: "'Poly' means many, and 'meros' means parts. A polymer is literally made of 'many parts'."
    }
  },

  // =========================================================================
  // PHYSICS VOCABULARY
  // =========================================================================
  'thermodynamics': {
    id: 'phys-thermo',
    term: 'Thermodynamics',
    subject: 'physics',
    subtopic: 'Thermal Physics',
    syllables: 'Ther-mo-dy-nam-ics',
    syllableCount: 5,
    phoneticIpa: '/ˌθɜːməʊdaɪˈnæmɪks/',
    hindiTranslation: 'ऊष्मागतिकी',
    hindiPhonetic: 'Ooshmagatiki',
    roots: [
      { part: 'Therme', meaning: 'Heat', origin: 'Greek' },
      { part: 'Dynamis', meaning: 'Power / Motion / Force', origin: 'Greek' }
    ],
    literalMeaning: 'Heat-power and the movement of thermal energy',
    clarityExplanation: 'The fundamental branch of physics that governs how heat energy converts into mechanical work and how entropy dictates the arrow of time.',
    analogy: 'The master rulebook for how energy flows in the universe, proving you can never get something for nothing.',
    sentences: {
      simple: 'Thermodynamics explains how heat transforms into power and motion.',
      technical: 'The First Law states energy conservation ($dQ = dU + dW$), while the Second Law dictates that net entropy of an isolated system must increase ($\\Delta S \\ge 0$).',
      exam: 'Calculate the theoretical maximum efficiency of a Carnot heat engine operating between source $T_H$ and sink $T_C$.',
      application: 'Thermodynamic optimization powers rocket propulsion nozzles, jet engines, and cryocoolers.'
    },
    examRelevance: 'Critical',
    examQuestionTypes: ['First Law Applications (3 Marks)', 'Carnot Engine Efficiency (5 Marks)', 'Entropy & Reversibility'],
    network: {
      category: 'Thermal Physics',
      children: ['Entropy', 'Enthalpy', 'Carnot Cycle', 'Internal Energy'],
      related: ['Isothermal Process', 'Adiabatic Process', 'Heat Engine', 'Second Law']
    },
    quiz: {
      question: "What do the Greek roots 'Therme' and 'Dynamis' mean?",
      options: ['Temperature and Cold', 'Heat and Power / Force', 'Pressure and Gas', 'Work and Speed'],
      correctAnswer: 'Heat and Power / Force',
      explanation: "'Therme' means heat (thermometer, thermal) and 'dynamis' means power/force (dynamic, dynamite)."
    }
  },

  'hypotenuse': {
    id: 'math-hypo',
    term: 'Hypotenuse',
    subject: 'mathematics',
    subtopic: 'Geometry & Trigonometry',
    syllables: 'Hy-pot-e-nuse',
    syllableCount: 4,
    phoneticIpa: '/haɪˈpɒtənjuːz/',
    hindiTranslation: 'कर्ण',
    hindiPhonetic: 'Karna',
    roots: [
      { part: 'Hypo', meaning: 'Under / Below', origin: 'Greek' },
      { part: 'Teinein', meaning: 'To stretch / Draw tight', origin: 'Greek' }
    ],
    literalMeaning: 'Stretched under (subtended opposite to the right angle)',
    clarityExplanation: 'The longest side of a right-angled triangle, resting directly opposite the $90^\\circ$ angle and governed by Pythagoras: $c^2 = a^2 + b^2$.',
    analogy: 'A taut zipline stretched diagonally from the top of a cliff down to the flat ground.',
    sentences: {
      simple: 'The hypotenuse is always the longest side of a right-angled triangle.',
      technical: 'In Euclidean geometry, the hypotenuse subtends the right angle and represents the magnitude of the vector resultant in Cartesian space.',
      exam: 'By the Pythagorean theorem, hypotenuse $h = \\sqrt{p^2 + b^2}$, and $\\sin(\\theta) = \\frac{\\text{Perpendicular}}{\\text{Hypotenuse}}$.',
      application: 'GPS satellite triangulation calculates exact surface coordinates by solving 3D hypotenuse distance vectors.'
    },
    examRelevance: 'Very High',
    examQuestionTypes: ['Pythagorean Proof', 'Trigonometric Ratios', 'Coordinate Geometry Distance Formula'],
    network: {
      category: 'Euclidean Geometry',
      children: ['Perpendicular', 'Base', 'Pythagorean Theorem', 'Sine / Cosine'],
      related: ['Right-angled Triangle', 'Euclidean Distance', 'Trigonometry']
    },
    quiz: {
      question: "What is the ancient Greek etymological meaning of 'Hypotenuse'?",
      options: ['Longest cut', 'Stretched under the right angle', 'Three-sided ruler', 'Slanted shadow'],
      correctAnswer: 'Stretched under the right angle',
      explanation: "From hypo (under) + teinein (to stretch). Ancient Greek surveyors literally stretched a tight cord under the right angle."
    }
  },

  'asymptote': {
    id: 'math-asymp',
    term: 'Asymptote',
    subject: 'mathematics',
    subtopic: 'Calculus & Curve Sketching',
    syllables: 'As-ymp-tote',
    syllableCount: 3,
    phoneticIpa: '/ˈæsɪmptəʊt/',
    hindiTranslation: 'अनंतस्पर्शी',
    hindiPhonetic: 'Anantasparshi',
    roots: [
      { part: 'A-', meaning: 'Not / Without', origin: 'Greek' },
      { part: 'Syn', meaning: 'Together with', origin: 'Greek' },
      { part: 'Pipto / Ptoton', meaning: 'To fall', origin: 'Greek' }
    ],
    literalMeaning: 'Not falling together / Never meeting',
    clarityExplanation: 'A straight line that a curve gets infinitely close to as it stretches toward infinity, but never actually touches or crosses.',
    analogy: 'Two parallel high-speed train tracks that appear to merge on the far horizon but never actually touch.',
    sentences: {
      simple: 'An asymptote is a boundary line that a curve approaches forever without touching.',
      technical: 'A line $x = c$ is a vertical asymptote of $f(x)$ if $\\lim_{x \\to c} f(x) = \\pm \\infty$.',
      exam: 'Find all horizontal and vertical asymptotes for the rational function $f(x) = \\frac{2x^2 + 1}{x^2 - 4}$.',
      application: 'Asymptotic analysis (Big-O notation) evaluates the limiting time complexity of computer algorithms.'
    },
    examRelevance: 'High',
    examQuestionTypes: ['Limits at Infinity', 'Curve Sketching', 'Rational Functions'],
    network: {
      category: 'Differential Calculus',
      children: ['Vertical Asymptote', 'Horizontal Asymptote', 'Oblique / Slant Asymptote'],
      related: ['Limits', 'Inflection Points', 'Continuity', 'Discontinuity']
    },
    quiz: {
      question: "The literal translation of the Greek roots in 'Asymptote' is:",
      options: ['Crossing at zero', 'Never falling together / Never meeting', 'Infinite gradient', 'Bending curve'],
      correctAnswer: 'Never falling together / Never meeting',
      explanation: "'a' (not) + 'syn' (together) + 'ptotos' (falling). The curve and line never fall together!"
    }
  }
};

/**
 * Helper to get technical terms from text matching our dictionary
 */
export function detectTechnicalTerms(text: string): VocabularyTerm[] {
  if (!text) return [];
  const lower = text.toLowerCase();
  const detected: VocabularyTerm[] = [];

  Object.keys(VOCABULARY_MASTER_DATABASE).forEach((key) => {
    if (lower.includes(key)) {
      detected.push(VOCABULARY_MASTER_DATABASE[key]);
    }
  });

  return detected;
}

/**
 * Generates the complete, dedicated Active Pedagogy Vocabulary Enhancement Suite Markdown.
 */
export function generateVocabularyMasterclassSection(topicTitle: string): string {
  const lower = topicTitle.toLowerCase();
  
  // Select primary featured terms based on topic domain
  let featuredTerms: VocabularyTerm[] = [];
  if (lower.includes('thermo') || lower.includes('heat') || lower.includes('engine') || lower.includes('physic')) {
    featuredTerms = [
      VOCABULARY_MASTER_DATABASE['thermodynamics'],
      VOCABULARY_MASTER_DATABASE['electrolysis'],
      VOCABULARY_MASTER_DATABASE['asymptote']
    ];
  } else if (lower.includes('chem') || lower.includes('bond') || lower.includes('reaction')) {
    featuredTerms = [
      VOCABULARY_MASTER_DATABASE['electrolysis'],
      VOCABULARY_MASTER_DATABASE['polymerisation'],
      VOCABULARY_MASTER_DATABASE['thermodynamics']
    ];
  } else {
    // Default to mathematics and analytical science core set
    featuredTerms = [
      VOCABULARY_MASTER_DATABASE['hypotenuse'],
      VOCABULARY_MASTER_DATABASE['asymptote'],
      VOCABULARY_MASTER_DATABASE['thermodynamics']
    ];
  }

  let md = `\n\n---\n\n## 📚 7. Professor Clarity's Subject Vocabulary Mastery Engine\n\n`;
  md += `*“Never just memorize a definition — master its roots, understand its anatomy, and speak the language of science with absolute clarity.”*\n\n`;

  // =========================================================================
  // TECHNIQUE 1 & 2: WORD BREAKDOWN MATRIX & VISUAL VOCABULARY CARDS
  // =========================================================================
  md += `### 🔬 Part A: Etymological Word Breakdown & Root Anatomy Matrix\n\n`;
  md += `Scientific terms are built from classical Greek and Latin root building blocks. When you unlock the roots, the meaning becomes instant and unforgettable:\n\n`;

  md += `| Technical Term | Syllable & IPA Pronunciation | Classical Greek / Latin Roots | Literal Root Meaning | Hindi Meaning & Phonetic | Exam Relevance |\n`;
  md += `| :--- | :--- | :--- | :--- | :--- | :--- |\n`;

  featuredTerms.forEach(vt => {
    const rootsStr = vt.roots.map(r => `**${r.part}** (*${r.origin}* = "${r.meaning}")`).join(' + ');
    md += `| **${vt.term}** | \`${vt.syllables}\`<br/>*${vt.phoneticIpa}* | ${rootsStr} | **"${vt.literalMeaning}"** | ${vt.hindiTranslation}<br/>*(${vt.hindiPhonetic})* | ⭐⭐⭐ **${vt.examRelevance}** |\n`;
  });

  md += `\n\n### 📇 Part B: Visual Vocabulary Deep-Dive Cards & Concept Anatomy\n\n`;

  featuredTerms.slice(0, 3).forEach(vt => {
    md += `#### 🏷️ Vocabulary Card: **${vt.term.toUpperCase()}** (${vt.hindiTranslation})\n`;
    md += `> 🎙️ **Pronunciation Guide**: *"${vt.syllables}"* — \`${vt.phoneticIpa}\` (Spoken: *"${vt.hindiPhonetic}"*)\n`;
    md += `> 💡 **The Clarity Explanation**: ${vt.clarityExplanation}\n`;
    md += `> 🌟 **Everyday Intuitive Analogy**: *${vt.analogy}*\n\n`;

    md += `**Sentence Progression Ladder:**\n`;
    md += `1. 🟢 **Simple Intuitive**: *"${vt.sentences.simple}"*\n`;
    md += `2. 🔵 **Technical Precision**: *"${vt.sentences.technical}"*\n`;
    md += `3. 🟣 **Exam Model Answer**: *"${vt.sentences.exam}"*\n`;
    md += `4. 🟡 **Real-World Application**: *"${vt.sentences.application}"*\n\n`;

    if (vt.mnemonic) {
      md += `⚡ **Memory Mnemonic Anchor**: *${vt.mnemonic}*\n\n`;
    }
  });

  // =========================================================================
  // TECHNIQUE 4: VOCABULARY RELATIONSHIP NETWORKS & CONCEPT MIND MAPS
  // =========================================================================
  md += `### 🕸️ Part C: Vocabulary Concept Networks & Semantic Family Trees\n\n`;
  md += `Concepts do not exist in isolation. Master the hierarchical semantic network showing parent structures, sub-components, and related mathematical and analytical processes:\n\n`;

  if (lower.includes('physic') || lower.includes('thermo')) {
    md += `\`\`\`text
                      ┌─────────────────────────────────────────┐
                      │             THERMODYNAMICS              │
                      │         (Heat & Mechanical Power)       │
                      └────────────────────┬────────────────────┘
                                           │
         ┌─────────────────────────────────┼─────────────────────────────────┐
         ▼                                 ▼                                 ▼
┌─────────────────┐               ┌─────────────────┐               ┌─────────────────┐
│   FIRST LAW     │               │   SECOND LAW    │               │  STATE VARIABLE │
│ (Conservation)  │               │    (Entropy)    │               │ (P, V, T, U)    │
└────────┬────────┘               └────────┬────────┘               └────────┬────────┘
         │                                 │                                 │
   ┌─────┴─────┐                     ┌─────┴─────┐                     ┌─────┴─────┐
   ▼           ▼                     ▼           ▼                     ▼           ▼
ΔQ = ΔU + W  Work Done           Carnot Engine  Irreversibility     Isothermal   Adiabatic
(Joules)     (∫ P dV)            (η = 1 - Tc/Th) (ΔS_univ ≥ 0)      (ΔT = 0)     (ΔQ = 0)
\`\`\`\n\n`;
  } else {
    md += `\`\`\`text
                      ┌─────────────────────────────────────────┐
                      │          MATHEMATICAL ANALYSIS          │
                      │        (Axioms, Limits & Curves)        │
                      └────────────────────┬────────────────────┘
                                           │
         ┌─────────────────────────────────┼─────────────────────────────────┐
         ▼                                 ▼                                 ▼
┌─────────────────┐               ┌─────────────────┐               ┌─────────────────┐
│    FUNCTIONS    │               │   DIFFERENTIAL  │               │    INTEGRAL     │
│  (Domain/Range) │               │   (Rate/Slope)  │               │   (Total Area)  │
└────────┬────────┘               └────────┬────────┘               └────────┬────────┘
         │                                 │                                 │
   ┌─────┴─────┐                     ┌─────┴─────┐                     ┌─────┴─────┐
   ▼           ▼                     ▼           ▼                     ▼           ▼
Asymptotes   Extrema             Tangent Slope  Inflection          Indefinite   Definite
(Limits)     (f'(c) = 0)         (df/dx)        (f''(x) = 0)        (F(x) + C)   (∫_a^b f)
\`\`\`\n\n`;
  }

  // =========================================================================
  // EXAM-FOCUSED CONFUSION PAIR ALERTS
  // =========================================================================
  md += `### ⚠️ Part D: Examiner "Confusion Pair" Alerts & Diagnostic Differentiators\n\n`;
  md += `Examiners frequently set trap questions around closely sounding or functionally opposite term pairs. Study these side-by-side matrices to guarantee zero marks lost:\n\n`;

  const pairTerm = featuredTerms.find(t => t.confusionPair) || VOCABULARY_MASTER_DATABASE['asymptote'];
  if (pairTerm && pairTerm.confusionPair) {
    const cp = pairTerm.confusionPair;
    md += `#### ⚖️ Diagnostic Comparison: **${pairTerm.term}** vs **${cp.pairWith}**\n`;
    md += `> 🚨 **Critical Distinction**: *${cp.keyDifference}*\n\n`;

    md += `| Evaluation Dimension | ${pairTerm.term} | ${cp.pairWith} |\n`;
    md += `| :--- | :--- | :--- |\n`;
    cp.aspects.forEach(asp => {
      md += `| **${asp.aspect}** | ${asp.thisTerm} | ${asp.otherTerm} |\n`;
    });
    md += `\n`;
  }

  // Add standard second confusion pair
  md += `#### ⚖️ Diagnostic Comparison: **Derivative (Rate of Change)** vs **Integral (Accumulation)**\n`;
  md += `| Evaluation Dimension | Derivative | Integral |\n`;
  md += `| :--- | :--- | :--- |\n`;
  md += `| **Core Operation** | Measures instantaneous rate of change (tangent slope) | Accumulates distributed quantities (area under curve) |\n`;
  md += `| **Fundamental Notation** | $f'(x) = \\lim_{h \\to 0} \\frac{f(x+h) - f(x)}{h}$ | $F(x) = \\int f(x) dx$ |\n`;
  md += `| **Geometric Meaning** | Steepness / velocity at a single instantaneous point | Total sum / displacement over a continuous interval |\n`;
  md += `| **Inversion Relationship** | Differentiation undoes integration | $\\frac{d}{dx} \\left[ \\int f(x) dx \\right] = f(x)$ (Fundamental Theorem) |\n\n`;

  // =========================================================================
  // VOCABULARY QUIZ & RETENTION ENGINE
  // =========================================================================
  md += `### 🎯 Part E: Rapid Vocabulary Active Recall & Root Quiz Engine\n\n`;
  md += `Test your etymological mastery with these high-yield root recognition questions:\n\n`;

  featuredTerms.slice(0, 3).forEach((vt, i) => {
    md += `**Q${i + 1}: ${vt.quiz.question}**\n`;
    vt.quiz.options.forEach(opt => {
      const isCorrect = opt === vt.quiz.correctAnswer;
      md += `- ${isCorrect ? '✅' : '⚪'} ${opt}\n`;
    });
    md += `👉 **Clarity Master Solution**: \`${vt.quiz.correctAnswer}\` — *${vt.quiz.explanation}*\n\n`;
  });

  return md;
}
