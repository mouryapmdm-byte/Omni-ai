import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  X,
  Play,
  Pause,
  RotateCcw,
  BookOpen,
  HelpCircle,
  Sparkles,
  Calculator,
  User,
  GraduationCap,
  Zap,
  Activity,
  Layers,
  Camera,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Sliders,
  Flame,
  Radio,
  Dna,
  Atom,
  Compass,
  Sun,
  Moon,
  Pencil,
  Video,
  Timer,
  MessageSquare,
  Trash2,
  FileText,
  ChevronRight,
  CornerDownLeft,
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface CommandItem {
  id: string;
  title: string;
  category: 'Lecture' | 'Pedagogy' | 'Tools' | 'Display' | 'Lab & 3D' | 'Audio & Media' | 'System';
  icon: React.ReactNode;
  keywords: string[];
  shortcut?: string;
  action: () => void;
}

interface SmartCommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  commands: CommandItem[];
}

export const SmartCommandPalette: React.FC<SmartCommandPaletteProps> = ({
  isOpen,
  onClose,
  commands,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  const filteredCommands = query.trim()
    ? commands.filter((cmd) => {
        const q = query.toLowerCase();
        return (
          cmd.title.toLowerCase().includes(q) ||
          cmd.category.toLowerCase().includes(q) ||
          cmd.keywords.some((kw) => kw.toLowerCase().includes(q))
        );
      })
    : commands;

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(1, filteredCommands.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + filteredCommands.length) % Math.max(1, filteredCommands.length));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredCommands[selectedIndex]) {
        filteredCommands[selectedIndex].action();
        onClose();
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150">
      <div 
        className="w-full max-w-2xl bg-slate-900 border-2 border-indigo-500/50 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh] ring-1 ring-indigo-400/30"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-800 gap-3 bg-slate-950/60">
          <Search size={20} className="text-indigo-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a command or search feature... (e.g. notes, khan, formula, lab)"
            className="w-full bg-transparent text-white text-sm sm:text-base placeholder-slate-500 focus:outline-none font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
            >
              <X size={16} />
            </button>
          )}
          <span className="hidden sm:inline-block text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
            ESC to close
          </span>
        </div>

        {/* Commands List */}
        <div ref={listRef} className="overflow-y-auto p-2 space-y-1 divide-y divide-slate-800/40">
          {filteredCommands.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              <Sparkles size={24} className="mx-auto mb-2 text-indigo-400/50 animate-pulse" />
              <p className="font-semibold text-slate-300">No matching command found</p>
              <p className="text-xs text-slate-500 mt-1">Try searching "notes", "avatar", "quiz", "formula", or "camera"</p>
            </div>
          ) : (
            filteredCommands.map((cmd, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <button
                  key={cmd.id}
                  onClick={() => {
                    cmd.action();
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={cn(
                    "w-full px-3.5 py-2.5 rounded-xl flex items-center justify-between transition-all text-left cursor-pointer group",
                    isSelected
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                      : "hover:bg-slate-800/80 text-slate-200"
                  )}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={cn(
                      "p-2 rounded-xl shrink-0 transition-colors",
                      isSelected ? "bg-white/20 text-white" : "bg-slate-800 text-indigo-400 group-hover:text-indigo-300"
                    )}>
                      {cmd.icon}
                    </div>
                    <div className="truncate">
                      <div className="text-xs sm:text-sm font-bold truncate flex items-center gap-2">
                        <span>{cmd.title}</span>
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className={cn(
                          "text-[9px] uppercase tracking-wider font-bold px-1.5 py-0.2 rounded",
                          isSelected ? "bg-indigo-900/60 text-indigo-200" : "bg-slate-800 text-slate-400"
                        )}>
                          {cmd.category}
                        </span>
                        <span className={cn(
                          "text-[10px] truncate",
                          isSelected ? "text-indigo-200" : "text-slate-500"
                        )}>
                          {cmd.keywords.slice(0, 3).join(', ')}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-2">
                    {cmd.shortcut && (
                      <span className={cn(
                        "text-[10px] font-mono px-2 py-0.5 rounded border",
                        isSelected
                          ? "bg-indigo-700/60 border-indigo-400 text-white"
                          : "bg-slate-950/80 border-slate-800 text-slate-400"
                      )}>
                        {cmd.shortcut}
                      </span>
                    )}
                    <CornerDownLeft size={13} className={cn(
                      "transition-opacity",
                      isSelected ? "opacity-100 text-white" : "opacity-0"
                    )} />
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 bg-slate-950/90 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-300">Tip:</span>
            <span>Press <kbd className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-200 font-mono">/</kbd> anytime to open this palette</span>
          </div>
          <span className="font-mono text-slate-500">{filteredCommands.length} commands</span>
        </div>
      </div>
    </div>
  );
};
