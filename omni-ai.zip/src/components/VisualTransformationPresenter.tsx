import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Sparkles,
  ArrowRight,
  Brain,
  Layers,
  Award,
  AlertTriangle,
  Play,
  Pause,
  RotateCcw,
  FastForward,
  Copy,
  Check,
  Send,
  Eye,
  EyeOff,
  HelpCircle,
  BookOpen,
  Volume2,
  VolumeX,
  Maximize2,
  Sliders,
  CheckCircle2,
  XCircle,
  ChevronRight,
  ChevronLeft,
  Flame,
  Shield,
  Search,
  Filter,
  RefreshCw,
  Info
} from 'lucide-react';
import { cn } from '../lib/utils';
import {
  TransformationPresentationPackage,
  TransformationItem,
  PresentationMode,
  PloidyLevel
} from '../types/transformationPresentation';
import {
  transformationPresentationService,
  SEED_AND_FRUIT_FORMATION_PACKAGE
} from '../services/transformationPresentationService';

interface VisualTransformationPresenterProps {
  packageData?: TransformationPresentationPackage;
  rawInputTable?: string;
  theme?: 'light' | 'dark' | string;
  onDeliverToSmartboard?: (contentMarkdown: string, topicTitle: string) => void;
  onSpeak?: (text: string) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onExpandFullscreen?: () => void;
  isInsideModal?: boolean;
}

export const VisualTransformationPresenter: React.FC<VisualTransformationPresenterProps> = ({
  packageData,
  rawInputTable,
  theme = 'dark',
  onDeliverToSmartboard,
  onSpeak,
  showNotification,
  onExpandFullscreen,
  isInsideModal = false
}) => {
  // Current Active Presentation Mode
  const [activeMode, setActiveMode] = useState<PresentationMode>('transformation_flow');

  // Package Data State
  const [currentPkg, setCurrentPkg] = useState<TransformationPresentationPackage>(
    packageData || SEED_AND_FRUIT_FORMATION_PACKAGE
  );
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPloidyFilter, setSelectedPloidyFilter] = useState<string>('all');

  // Progressive Revelation Player
  const [activeStepIndex, setActiveStepIndex] = useState<number>(0);
  const [isPlayingAutoFlow, setIsPlayingAutoFlow] = useState<boolean>(false);
  const [autoFlowSpeedMs, setAutoFlowSpeedMs] = useState<number>(4500);

  // Interactive Spotlights
  const [selectedItemId, setSelectedItemId] = useState<string>(currentPkg.items[0]?.id || 'ovary_to_fruit');

  // Flashcard Mode States
  const [flashcardIndex, setFlashcardIndex] = useState<number>(0);
  const [isFlashcardRevealed, setIsFlashcardRevealed] = useState<boolean>(false);
  const [flashcardScore, setFlashcardScore] = useState<{ correct: number; incorrect: number }>({ correct: 0, incorrect: 0 });

  // Quiz / Practice Questions State
  const [userQuizAnswers, setUserQuizAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  // Copy Status
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Audio mute toggle
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Sync or generate package if rawInputTable provided
  useEffect(() => {
    if (rawInputTable) {
      setIsLoading(true);
      transformationPresentationService.generateDynamicTransformation(rawInputTable)
        .then(pkg => {
          setCurrentPkg(pkg);
          setSelectedItemId(pkg.items[0]?.id || '');
          setIsLoading(false);
        })
        .catch(() => setIsLoading(false));
    } else if (packageData) {
      setCurrentPkg(packageData);
      setSelectedItemId(packageData.items[0]?.id || '');
    }
  }, [packageData, rawInputTable]);

  // Progressive Auto Flow Player Timer
  useEffect(() => {
    if (!isPlayingAutoFlow || !currentPkg?.items?.length) return;

    const interval = setInterval(() => {
      setActiveStepIndex(prev => {
        const next = prev + 1;
        if (next >= currentPkg.items.length) {
          setIsPlayingAutoFlow(false);
          return prev;
        }
        const item = currentPkg.items[next];
        if (item) {
          setSelectedItemId(item.id);
          if (!isMuted && item.spokenNarrationHindi && onSpeak) {
            onSpeak(item.spokenNarrationHindi);
          }
        }
        return next;
      });
    }, autoFlowSpeedMs);

    return () => clearInterval(interval);
  }, [isPlayingAutoFlow, currentPkg, autoFlowSpeedMs, isMuted, onSpeak]);

  // Toggle Auto-Flow
  const toggleAutoFlow = () => {
    if (!isPlayingAutoFlow) {
      setIsPlayingAutoFlow(true);
      const currentItem = currentPkg.items[activeStepIndex];
      if (currentItem && !isMuted && currentItem.spokenNarrationHindi && onSpeak) {
        onSpeak(currentItem.spokenNarrationHindi);
      }
    } else {
      setIsPlayingAutoFlow(false);
    }
  };

  // Deliver to 3D Smartboard
  const handleDeliverToSmartboard = () => {
    const md = transformationPresentationService.formatSmartboardMarkdown(currentPkg);
    if (onDeliverToSmartboard) {
      onDeliverToSmartboard(md, currentPkg.titleHindi);
    }
    showNotification?.(`Delivered Visual Transformation "${currentPkg.titleHindi}" to 3D Smartboard!`, 'success');
  };

  // Copy Markdown
  const handleCopyMarkdown = () => {
    const md = transformationPresentationService.formatSmartboardMarkdown(currentPkg);
    navigator.clipboard.writeText(md).then(() => {
      setIsCopied(true);
      showNotification?.('Transformation markdown copied to clipboard!', 'info');
      setTimeout(() => setIsCopied(false), 2000);
    });
  };

  // Speak Current Selection
  const handleSpeakCurrent = (item: TransformationItem) => {
    if (onSpeak && item.spokenNarrationHindi) {
      onSpeak(item.spokenNarrationHindi);
    }
  };

  // Filter items
  const filteredItems = useMemo(() => {
    return currentPkg.items.filter(item => {
      const q = searchQuery.toLowerCase();
      const matchesSearch = !searchQuery ||
        item.before.hindiName.toLowerCase().includes(q) ||
        item.before.englishName.toLowerCase().includes(q) ||
        item.after.hindiName.toLowerCase().includes(q) ||
        item.after.englishName.toLowerCase().includes(q) ||
        item.after.description.toLowerCase().includes(q);

      const matchesPloidy = selectedPloidyFilter === 'all' || item.ploidy.level === selectedPloidyFilter;
      return matchesSearch && matchesPloidy;
    });
  }, [currentPkg, searchQuery, selectedPloidyFilter]);

  // Active highlighted item
  const activeItem = useMemo(() => {
    return currentPkg.items.find(i => i.id === selectedItemId) || currentPkg.items[0];
  }, [currentPkg, selectedItemId]);

  return (
    <div className={cn(
      "w-full rounded-2xl border transition-all flex flex-col overflow-hidden text-left",
      theme === 'dark'
        ? "bg-slate-950/95 border-cyan-500/40 text-slate-100 shadow-2xl"
        : "bg-slate-900 border-slate-700 text-slate-100 shadow-xl"
    )}>
      
      {/* 1. TOP HEADER & PEDAGOGICAL TITLE BAR */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3.5 bg-slate-950/90 border-b border-cyan-500/30 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-pink-600 text-white shadow-lg shadow-cyan-500/20">
            <Sparkles size={22} className="animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-0.5 rounded-full border border-cyan-500/40">
                Visual Transformation Architect
              </span>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-500/30">
                BEFORE → AFTER • PLOIDY MATRIX
              </span>
              <span className="text-[10px] font-extrabold text-pink-400 bg-pink-950/80 px-2 py-0.5 rounded-full border border-pink-500/30">
                ⭐ 3N Triploid Endosperm Highlight
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2 mt-0.5">
              {currentPkg.titleHindi}
              <span className="text-xs sm:text-sm font-semibold text-slate-400 font-sans hidden md:inline">
                ({currentPkg.titleEnglish})
              </span>
            </h3>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleDeliverToSmartboard}
            className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center gap-1.5 cursor-pointer"
            title="Deliver this visual transformation presentation to the 3D Classroom Smartboard"
          >
            <Send size={14} />
            <span>Deliver to Smartboard</span>
          </button>

          <button
            onClick={handleCopyMarkdown}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            title="Copy Smartboard Markdown"
          >
            {isCopied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
            <span>{isCopied ? 'Copied' : 'Copy'}</span>
          </button>

          {onExpandFullscreen && !isInsideModal && (
            <button
              onClick={onExpandFullscreen}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700 cursor-pointer"
              title="Fullscreen Studio Mode"
            >
              <Maximize2 size={16} />
            </button>
          )}
        </div>
      </div>

      {/* 2. 5 PRESENTATION MODES NAVIGATION TABS */}
      <div className="flex items-center gap-2 px-4 sm:px-6 py-2.5 bg-slate-950/70 border-b border-slate-800 overflow-x-auto shrink-0 select-none">
        {[
          {
            id: 'transformation_flow' as PresentationMode,
            label: '1. Transformation Flow',
            desc: 'BEFORE ➔ AFTER with animated flow & ploidy badges',
            icon: ArrowRight,
            color: 'from-cyan-600 to-blue-600'
          },
          {
            id: 'table_summary' as PresentationMode,
            label: '2. Table Summary',
            desc: 'Structured high-contrast visual matrix',
            icon: Layers,
            color: 'from-blue-600 to-indigo-600'
          },
          {
            id: 'flashcard_mode' as PresentationMode,
            label: '3. Flashcard Mode',
            desc: 'Interactive self-test with active recall',
            icon: HelpCircle,
            color: 'from-purple-600 to-pink-600'
          },
          {
            id: 'diagram_mode' as PresentationMode,
            label: '4. Diagram Mode',
            desc: 'Morphological tree & organ relationships',
            icon: Brain,
            color: 'from-emerald-600 to-teal-600'
          },
          {
            id: 'comparison_mode' as PresentationMode,
            label: '5. Comparison & Exam Prep',
            desc: 'Ploidy spotlight, traps & practice MCQs',
            icon: Award,
            color: 'from-amber-600 to-orange-600'
          }
        ].map(mode => {
          const IconComp = mode.icon;
          const isActive = activeMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => setActiveMode(mode.id)}
              className={cn(
                "px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 cursor-pointer border",
                isActive
                  ? `bg-gradient-to-r ${mode.color} text-white border-transparent shadow-md`
                  : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800"
              )}
            >
              <IconComp size={14} className={isActive ? "animate-pulse" : ""} />
              <span>{mode.label}</span>
            </button>
          );
        })}
      </div>

      {/* 3. AUTO-PLAY & REVELATION HUD BAR */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-2 bg-slate-900/90 border-b border-slate-800 text-xs shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={toggleAutoFlow}
            className={cn(
              "px-3 py-1 rounded-xl font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm",
              isPlayingAutoFlow
                ? "bg-amber-600 text-white animate-pulse"
                : "bg-cyan-600 hover:bg-cyan-500 text-white"
            )}
          >
            {isPlayingAutoFlow ? <Pause size={14} /> : <Play size={14} />}
            <span>{isPlayingAutoFlow ? "Pause Auto-Flow" : "Play Progressive Flow"}</span>
          </button>

          <button
            onClick={() => {
              setActiveStepIndex(0);
              setSelectedItemId(currentPkg.items[0]?.id || '');
              if (onSpeak && currentPkg.items[0]?.spokenNarrationHindi) {
                onSpeak(currentPkg.items[0].spokenNarrationHindi);
              }
            }}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700 cursor-pointer"
            title="Reset from Step 1"
          >
            <RotateCcw size={13} />
          </button>

          <button
            onClick={() => setIsMuted(prev => !prev)}
            className={cn(
              "p-1.5 rounded-lg transition-colors border cursor-pointer",
              isMuted
                ? "bg-red-950/60 border-red-800 text-red-400"
                : "bg-slate-800 border-slate-700 text-slate-300 hover:text-white"
            )}
            title={isMuted ? "Unmute Professor Voice" : "Mute Professor Voice"}
          >
            {isMuted ? <VolumeX size={13} /> : <Volume2 size={13} />}
          </button>

          <div className="hidden sm:flex items-center gap-1.5 text-slate-400 ml-2">
            <span className="text-[11px] font-semibold">Speed:</span>
            <select
              value={autoFlowSpeedMs}
              onChange={(e) => setAutoFlowSpeedMs(parseInt(e.target.value))}
              className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-0.5 text-[11px] text-cyan-300 focus:outline-none"
            >
              <option value={3000}>Fast (3s)</option>
              <option value={4500}>Normal (4.5s)</option>
              <option value={6000}>Lecture (6s)</option>
            </select>
          </div>
        </div>

        {/* Color Legend HUD */}
        <div className="flex items-center gap-3 text-[11px] font-semibold flex-wrap">
          <div className="flex items-center gap-1 text-cyan-400">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 shadow-sm shadow-cyan-500/50" />
            <span>Before: Pre-Fertilization</span>
          </div>
          <div className="flex items-center gap-1 text-red-400">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-sm shadow-red-500/50" />
            <span>After: Post-Fertilization</span>
          </div>
          <div className="flex items-center gap-1 text-blue-300">
            <span className="px-1.5 py-0.2 rounded-full bg-blue-900 border border-blue-500 text-[10px] font-black">2N</span>
            <span>Diploid</span>
          </div>
          <div className="flex items-center gap-1 text-rose-300">
            <span className="px-1.5 py-0.2 rounded-full bg-red-900 border border-red-400 text-[10px] font-black animate-pulse">3N</span>
            <span>Triploid (Endosperm)</span>
          </div>
        </div>
      </div>

      {/* 4. MAIN WORKSPACE CONTAINER */}
      <div className="p-4 sm:p-6 space-y-6">

        {/* ----------------- MODE 1: TRANSFORMATION FLOW (DEFAULT) ----------------- */}
        {activeMode === 'transformation_flow' && (
          <div className="space-y-6">
            
            {/* Overview Intro Banner */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-slate-900 to-indigo-950/70 border border-cyan-500/40 relative">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400 flex items-center gap-1">
                    <Info size={12} />
                    Pedagogical Transformation Flow
                  </span>
                  <p className="text-xs text-slate-200 leading-relaxed max-w-3xl">
                    {currentPkg.overviewSummary.hindi}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] font-bold text-slate-400">
                    Step {activeStepIndex + 1} of {currentPkg.items.length}
                  </span>
                  <div className="flex items-center gap-1 mt-1">
                    {currentPkg.items.map((it, idx) => (
                      <button
                        key={it.id}
                        onClick={() => {
                          setActiveStepIndex(idx);
                          setSelectedItemId(it.id);
                          handleSpeakCurrent(it);
                        }}
                        className={cn(
                          "w-3 h-3 rounded-full transition-all cursor-pointer",
                          activeStepIndex === idx
                            ? "bg-cyan-400 scale-125 shadow-md shadow-cyan-400/50"
                            : "bg-slate-700 hover:bg-slate-500"
                        )}
                        title={`Go to ${it.before.hindiName} ➔ ${it.after.hindiName}`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Visual Transformation Cards List */}
            <div className="space-y-3.5">
              {currentPkg.items.map((item, index) => {
                const isSelected = selectedItemId === item.id || activeStepIndex === index;
                const is3N = item.ploidy.level === '3N';

                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setSelectedItemId(item.id);
                      setActiveStepIndex(index);
                      handleSpeakCurrent(item);
                    }}
                    className={cn(
                      "p-4 sm:p-5 rounded-2xl border-2 transition-all cursor-pointer relative overflow-hidden group",
                      isSelected
                        ? is3N
                          ? "bg-red-950/40 border-red-500 shadow-xl shadow-red-500/20 scale-[1.01]"
                          : "bg-cyan-950/40 border-cyan-400 shadow-xl shadow-cyan-500/20 scale-[1.01]"
                        : "bg-slate-900/80 border-slate-800/90 hover:border-slate-700 hover:bg-slate-900"
                    )}
                  >
                    {/* Top Item Badge Row */}
                    <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        <span className={cn(
                          "w-6 h-6 rounded-full text-xs font-black flex items-center justify-center",
                          isSelected ? "bg-cyan-500 text-slate-950 font-black" : "bg-slate-800 text-slate-400"
                        )}>
                          {item.order}
                        </span>
                        <span className="text-[11px] font-black uppercase tracking-wider text-slate-400">
                          {item.before.subsystemOrCategory}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {item.examRelevance.isHighYield && (
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 flex items-center gap-1">
                            ⭐ High Yield ({item.examRelevance.marksWeightage} Marks)
                          </span>
                        )}
                        <span className={cn(
                          "text-[10px] font-black px-2 py-0.5 rounded-full border",
                          is3N
                            ? "bg-red-950 text-red-200 border-red-500 animate-pulse"
                            : "bg-blue-950 text-blue-200 border-blue-500"
                        )}>
                          {item.ploidy.labelHindi}
                        </span>
                      </div>
                    </div>

                    {/* Core Transformation Row: BEFORE ➔ AFTER ➔ PLOIDY */}
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                      
                      {/* Left: BEFORE (Pre-Fertilization) */}
                      <div className="md:col-span-4 p-3.5 rounded-xl bg-slate-950/80 border border-cyan-500/30 flex items-start gap-3">
                        <div className="text-2xl p-2 rounded-xl bg-cyan-950 text-cyan-300 border border-cyan-700/50 shrink-0">
                          {item.before.iconSymbol}
                        </div>
                        <div className="space-y-0.5 overflow-hidden">
                          <span className="text-[9px] font-black uppercase text-cyan-400 tracking-wider">
                            निषेचन से पूर्व (Pre-Fertilization)
                          </span>
                          <h4 className="text-base font-black text-white leading-tight">
                            {item.before.hindiName}
                          </h4>
                          <span className="text-xs text-slate-400 font-semibold block">
                            {item.before.englishName}
                          </span>
                          <p className="text-[11px] text-slate-300 leading-snug pt-1 line-clamp-2">
                            {item.before.description}
                          </p>
                        </div>
                      </div>

                      {/* Middle: DYNAMIC GLOWING ARROW & TRANSITION MECHANISM */}
                      <div className="md:col-span-2 flex flex-col items-center justify-center py-1">
                        <span className="text-[10px] font-extrabold uppercase text-slate-400 mb-1">
                          becomes (रूपांतरण)
                        </span>
                        <div className="flex items-center w-full justify-center">
                          <div className={cn(
                            "h-1 w-12 rounded-full bg-gradient-to-r",
                            is3N ? "from-cyan-500 via-amber-500 to-red-500" : "from-cyan-500 via-indigo-500 to-red-500",
                            isSelected ? "animate-pulse" : ""
                          )} />
                          <ChevronRight size={18} className={cn(
                            "-ml-1 font-black",
                            is3N ? "text-red-400" : "text-red-400"
                          )} />
                        </div>
                        <span className="text-[9px] font-mono text-cyan-400 mt-1">
                          Post-Fertilization
                        </span>
                      </div>

                      {/* Right: AFTER (Post-Fertilization Structure) */}
                      <div className="md:col-span-4 p-3.5 rounded-xl bg-slate-950/80 border border-red-500/30 flex items-start gap-3">
                        <div className="text-2xl p-2 rounded-xl bg-red-950 text-red-300 border border-red-700/50 shrink-0">
                          {item.after.iconSymbol}
                        </div>
                        <div className="space-y-0.5 overflow-hidden">
                          <span className="text-[9px] font-black uppercase text-red-400 tracking-wider">
                            निषेचन के बाद (Post-Fertilization)
                          </span>
                          <h4 className="text-base font-black text-white leading-tight">
                            {item.after.hindiName}
                          </h4>
                          <span className="text-xs text-slate-400 font-semibold block">
                            {item.after.englishName}
                          </span>
                          <p className="text-[11px] text-slate-300 leading-snug pt-1 line-clamp-2">
                            {item.after.description}
                          </p>
                        </div>
                      </div>

                      {/* Far Right: PLOIDY LEVEL BADGE */}
                      <div className="md:col-span-2 flex flex-col items-center justify-center p-3 rounded-xl bg-slate-950/90 border border-slate-800 text-center">
                        <span className="text-[9px] font-black uppercase text-slate-400 mb-0.5">
                          गुणसूत्रता (Ploidy)
                        </span>
                        <span className={cn(
                          "text-xl font-black px-3 py-1 rounded-xl shadow-inner",
                          is3N
                            ? "bg-red-600 text-white animate-bounce shadow-red-500/50"
                            : "bg-blue-600 text-white shadow-blue-500/50"
                        )}>
                          {item.ploidy.level}
                        </span>
                        <span className="text-[10px] text-slate-300 font-bold mt-1">
                          {item.ploidy.labelEnglish}
                        </span>
                      </div>

                    </div>

                    {/* Bottom Expanded Drawer: Real World Examples & Common Trap Warning */}
                    {isSelected && (
                      <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs animate-fadeIn">
                        {/* Real-World Examples */}
                        {item.realWorldExamples && item.realWorldExamples.length > 0 && (
                          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                            <span className="text-[10px] font-black uppercase text-emerald-400 flex items-center gap-1">
                              🌱 वास्तविक उदाहरण (Real-World Examples)
                            </span>
                            {item.realWorldExamples.map((ex, exIdx) => (
                              <div key={exIdx} className="text-[11px] text-slate-300">
                                <strong className="text-white">{ex.hindi} ({ex.english})</strong>: {ex.details}
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Exam Trap Warning */}
                        <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-800/60 space-y-1">
                          <span className="text-[10px] font-black uppercase text-amber-400 flex items-center gap-1">
                            ⚠️ परीक्षा में होने वाली सामान्य भूल (Common Exam Trap)
                          </span>
                          <p className="text-[11px] text-slate-300">
                            <span className="text-red-400 font-bold">❌ भूल: </span>
                            {item.examRelevance.commonMistakeWarning.wrongConception}
                          </p>
                          <p className="text-[11px] text-emerald-300">
                            <span className="text-emerald-400 font-bold">✅ सही तथ्य: </span>
                            {item.examRelevance.commonMistakeWarning.correctFact}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ----------------- MODE 2: TABLE SUMMARY (REVISION) ----------------- */}
        {activeMode === 'table_summary' && (
          <div className="space-y-4">
            {/* Search & Ploidy Filter HUD */}
            <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900/90 border border-slate-800 rounded-xl">
              <div className="relative flex-1 min-w-[200px] max-w-md">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search structures (e.g. Ovary, PEN, Nucellus, बीजांड)..."
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-400 font-bold">Filter Ploidy:</span>
                <div className="flex items-center gap-1">
                  {['all', '2N', '3N'].map(p => (
                    <button
                      key={p}
                      onClick={() => setSelectedPloidyFilter(p)}
                      className={cn(
                        "px-2.5 py-1 rounded-lg text-xs font-bold transition-all border cursor-pointer",
                        selectedPloidyFilter === p
                          ? "bg-cyan-600 border-cyan-500 text-white"
                          : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                      )}
                    >
                      {p === 'all' ? 'All Structures' : `${p} Only`}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* High-Contrast Interactive Table */}
            <div className="overflow-x-auto rounded-2xl border border-slate-800 shadow-xl bg-slate-950">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900/90 text-slate-300 border-b border-slate-800">
                    <th className="p-3.5 font-black uppercase text-[10px] tracking-wider">#</th>
                    <th className="p-3.5 font-black uppercase text-[10px] tracking-wider text-cyan-400">
                      निषेचन से पूर्व (Pre-Fertilization)
                    </th>
                    <th className="p-3.5 font-black uppercase text-[10px] tracking-wider text-center">
                      रूपांतरण (Flow)
                    </th>
                    <th className="p-3.5 font-black uppercase text-[10px] tracking-wider text-red-400">
                      निषेचन के बाद की संरचना (Post-Fertilization)
                    </th>
                    <th className="p-3.5 font-black uppercase text-[10px] tracking-wider text-center">
                      गुणसूत्रता (Ploidy)
                    </th>
                    <th className="p-3.5 font-black uppercase text-[10px] tracking-wider">
                      मुख्य उदाहरण / परीक्षा महत्व
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {filteredItems.map((item, idx) => {
                    const is3N = item.ploidy.level === '3N';
                    return (
                      <tr
                        key={item.id}
                        className={cn(
                          "transition-colors hover:bg-slate-900/60",
                          is3N ? "bg-red-950/20" : ""
                        )}
                      >
                        <td className="p-3.5 font-black text-slate-500">{idx + 1}</td>
                        <td className="p-3.5">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{item.before.iconSymbol}</span>
                            <div>
                              <div className="font-extrabold text-white text-sm">{item.before.hindiName}</div>
                              <div className="text-[10px] text-cyan-400">{item.before.englishName}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-3.5 text-center">
                          <div className="inline-flex items-center justify-center p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400">
                            <ArrowRight size={14} className="text-cyan-400" />
                          </div>
                        </td>
                        <td className="p-3.5">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{item.after.iconSymbol}</span>
                            <div>
                              <div className="font-extrabold text-white text-sm">{item.after.hindiName}</div>
                              <div className="text-[10px] text-red-400">{item.after.englishName}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-3.5 text-center">
                          <span className={cn(
                            "px-3 py-1 rounded-full text-xs font-black inline-block",
                            is3N
                              ? "bg-red-600 text-white shadow-md shadow-red-600/40 animate-pulse"
                              : "bg-blue-600 text-white"
                          )}>
                            {item.ploidy.level}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <div className="text-[11px] text-slate-300 leading-snug">
                            {item.realWorldExamples?.[0]?.hindi || item.after.functionOrFate}
                            {item.examRelevance.isHighYield && (
                              <span className="ml-1 text-amber-400 font-bold">⭐ {item.examRelevance.marksWeightage}M</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ----------------- MODE 3: FLASHCARD MODE (SELF-TEST) ----------------- */}
        {activeMode === 'flashcard_mode' && (
          <div className="max-w-2xl mx-auto space-y-6">
            
            {/* Flashcard Header & Progress */}
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-400">
                Card {flashcardIndex + 1} of {currentPkg.items.length}
              </span>
              <div className="flex items-center gap-3">
                <span className="text-emerald-400 font-bold">Correct: {flashcardScore.correct}</span>
                <span className="text-red-400 font-bold">Incorrect: {flashcardScore.incorrect}</span>
              </div>
            </div>

            {/* Interactive Flip Card */}
            {currentPkg.items[flashcardIndex] && (
              <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-tr from-slate-900 via-slate-950 to-indigo-950 border-2 border-purple-500/50 shadow-2xl text-center space-y-6 relative overflow-hidden">
                
                {/* Before Prompt */}
                <div className="space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-3 py-1 rounded-full border border-cyan-500/30">
                    निषेचन से पूर्व (Pre-Fertilization Structure)
                  </span>
                  <div className="text-4xl my-2">
                    {currentPkg.items[flashcardIndex].before.iconSymbol}
                  </div>
                  <h3 className="text-2xl font-black text-white">
                    {currentPkg.items[flashcardIndex].before.hindiName}
                  </h3>
                  <p className="text-sm text-cyan-300 font-semibold">
                    {currentPkg.items[flashcardIndex].before.englishName}
                  </p>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    {currentPkg.items[flashcardIndex].before.description}
                  </p>
                </div>

                {/* Transformation Prompt Divider */}
                <div className="flex items-center justify-center gap-2">
                  <div className="h-0.5 w-16 bg-slate-700" />
                  <span className="text-xs font-bold text-purple-300 uppercase">
                    निषेचन के बाद क्या बनता है और गुणसूत्रता क्या है?
                  </span>
                  <div className="h-0.5 w-16 bg-slate-700" />
                </div>

                {/* Revealed Answer Box */}
                {isFlashcardRevealed ? (
                  <div className="p-5 rounded-2xl bg-slate-900 border border-emerald-500/50 space-y-3 animate-fadeIn">
                    <div className="text-3xl">
                      {currentPkg.items[flashcardIndex].after.iconSymbol}
                    </div>
                    <h4 className="text-xl font-black text-emerald-400">
                      {currentPkg.items[flashcardIndex].after.hindiName} ({currentPkg.items[flashcardIndex].after.englishName})
                    </h4>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950 border border-slate-800">
                      <span className="text-xs text-slate-400 font-bold">गुणसूत्रता (Ploidy):</span>
                      <span className={cn(
                        "text-xs font-black px-2 py-0.5 rounded",
                        currentPkg.items[flashcardIndex].ploidy.level === '3N'
                          ? "bg-red-600 text-white animate-pulse"
                          : "bg-blue-600 text-white"
                      )}>
                        {currentPkg.items[flashcardIndex].ploidy.level} ({currentPkg.items[flashcardIndex].ploidy.labelEnglish})
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
                      {currentPkg.items[flashcardIndex].after.description}
                    </p>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsFlashcardRevealed(true)}
                    className="px-6 py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-black text-sm transition-all shadow-lg shadow-purple-600/30 flex items-center gap-2 mx-auto cursor-pointer"
                  >
                    <Eye size={18} />
                    <span>उत्तर प्रकट करें (Reveal Answer)</span>
                  </button>
                )}

                {/* Score & Navigation Controls */}
                {isFlashcardRevealed && (
                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => {
                        setFlashcardScore(prev => ({ ...prev, correct: prev.correct + 1 }));
                        setIsFlashcardRevealed(false);
                        setFlashcardIndex(prev => (prev + 1) % currentPkg.items.length);
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                    >
                      <CheckCircle2 size={16} />
                      मुझे याद था (I Knew This)
                    </button>
                    <button
                      onClick={() => {
                        setFlashcardScore(prev => ({ ...prev, incorrect: prev.incorrect + 1 }));
                        setIsFlashcardRevealed(false);
                        setFlashcardIndex(prev => (prev + 1) % currentPkg.items.length);
                      }}
                      className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                    >
                      <XCircle size={16} />
                      दोहराना होगा (Review Again)
                    </button>
                  </div>
                )}

              </div>
            )}

            {/* Flashcard Next/Previous Pagination */}
            <div className="flex items-center justify-between">
              <button
                onClick={() => {
                  setIsFlashcardRevealed(false);
                  setFlashcardIndex(prev => (prev - 1 + currentPkg.items.length) % currentPkg.items.length);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold transition-all border border-slate-800 flex items-center gap-1.5 cursor-pointer"
              >
                <ChevronLeft size={16} /> Previous Card
              </button>
              <button
                onClick={() => {
                  setIsFlashcardRevealed(false);
                  setFlashcardIndex(prev => (prev + 1) % currentPkg.items.length);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold transition-all border border-slate-800 flex items-center gap-1.5 cursor-pointer"
              >
                Next Card <ChevronRight size={16} />
              </button>
            </div>

          </div>
        )}

        {/* ----------------- MODE 4: DIAGRAM MODE (ORGAN RELATIONSHIPS) ----------------- */}
        {activeMode === 'diagram_mode' && (
          <div className="space-y-6">
            <div className="text-center max-w-xl mx-auto space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 bg-emerald-950 px-3 py-1 rounded-full border border-emerald-500/30">
                Floral Morphology ➔ Seed & Fruit Architecture
              </span>
              <h4 className="text-base font-black text-white">
                पुष्पीय संरचनाओं का संगठनात्मक रूपांतरण वृक्ष
              </h4>
            </div>

            {/* Tree Network Visualization */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              
              {/* Branch 1: Ovary ➔ Fruit & Pericarp */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border-2 border-cyan-500/40 space-y-4 shadow-xl">
                <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                  <span className="p-2 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-700/50">🔵</span>
                  <div>
                    <h5 className="font-extrabold text-sm text-white">शाखा 1: अंडाशय एवं फल तंत्र (Fruit Subsystem)</h5>
                    <span className="text-[10px] text-cyan-300">Floral Carpel & Ovary Wall Derivatives</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-xs">अंडाशय (Ovary) ➔ फल (Fruit)</div>
                      <div className="text-[10px] text-slate-400">सत्य फल निर्माण (2N)</div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white text-[10px] font-black">2N</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-xs">अंडाशय भित्ति ➔ फलभित्ति (Pericarp)</div>
                      <div className="text-[10px] text-slate-400">Epicarp + Mesocarp + Endocarp (2N)</div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white text-[10px] font-black">2N</span>
                  </div>
                </div>
              </div>

              {/* Branch 2: Ovule ➔ Seed & Internal Contents */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border-2 border-amber-500/40 space-y-4 shadow-xl">
                <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                  <span className="p-2 rounded-xl bg-amber-950 text-amber-400 border border-amber-700/50">🟢</span>
                  <div>
                    <h5 className="font-extrabold text-sm text-white">शाखा 2: बीजांड एवं बीज तंत्र (Seed Subsystem)</h5>
                    <span className="text-[10px] text-amber-300">Ovule, Embryo Sac & Nutritive Envelopes</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-xs">बीजांड (Ovule) ➔ बीज (Seed)</div>
                      <div className="text-[10px] text-slate-400">समग्र बीज संरचना (2N)</div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white text-[10px] font-black">2N</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-xs">युग्मनज (Zygote) ➔ भ्रूण (Embryo)</div>
                      <div className="text-[10px] text-slate-400">प्रांकुर + मूलांकुर + बीजपत्र (2N)</div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white text-[10px] font-black">2N</span>
                  </div>

                  <div className="p-3 rounded-xl bg-red-950/60 border border-red-500 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-red-200 text-xs">PEN ➔ भ्रूणपोष (Endosperm)</div>
                      <div className="text-[10px] text-red-300">त्रिसंलयन द्वारा निर्मित पोषक ऊतक ⭐</div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-black animate-pulse">3N</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-xs">अध्यावरण ➔ बीजावरण (Seed Coat)</div>
                      <div className="text-[10px] text-slate-400">टेस्टा (Testa) + टेग्मेन (Tegmen) (2N)</div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white text-[10px] font-black">2N</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-xs">बीजांडकाय ➔ परिभ्रूणपोष (Perisperm)</div>
                      <div className="text-[10px] text-slate-400">काली मिर्च, चुकंदर में अवशिष्ट ऊतक (2N)</div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white text-[10px] font-black">2N</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ----------------- MODE 5: COMPARISON & EXAM PREP ----------------- */}
        {activeMode === 'comparison_mode' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            
            {/* Ploidy Spotlight Alert */}
            <div className="p-5 rounded-3xl bg-gradient-to-r from-red-950/80 via-slate-900 to-red-950/80 border-2 border-red-500 shadow-2xl space-y-2">
              <div className="flex items-center gap-2 text-red-400 font-black text-sm">
                <Flame size={18} className="animate-pulse" />
                <span>BOARD & NEET EXAM SPOTLIGHT: गुणसूत्रता (PLOIDY LEVEL) नियम</span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                {currentPkg.examPreparation.ploidyEmphasisNote}
              </p>
            </div>

            {/* Memory Mnemonic & Story Box */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Mnemonic Code & Hindi Rhyme */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-purple-500/40 space-y-2">
                <div className="flex items-center gap-2">
                  <Brain size={16} className="text-purple-400" />
                  <h5 className="font-extrabold text-sm text-white">स्मृति सूत्र (Memory Mnemonic)</h5>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-purple-800/50 font-mono text-xs text-purple-300 text-center font-black">
                  {currentPkg.memoryAids.mnemonicCode}
                </div>
                <pre className="text-xs text-slate-300 font-sans whitespace-pre-wrap leading-relaxed bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  {currentPkg.memoryAids.mnemonicHindi}
                </pre>
              </div>

              {/* Transformation Story */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/40 space-y-2">
                <div className="flex items-center gap-2">
                  <BookOpen size={16} className="text-emerald-400" />
                  <h5 className="font-extrabold text-sm text-white">{currentPkg.memoryAids.storyTitle}</h5>
                </div>
                <div className="text-xs text-slate-300 italic whitespace-pre-wrap leading-relaxed bg-slate-950/70 p-3 rounded-xl border border-slate-800 max-h-48 overflow-y-auto">
                  {currentPkg.memoryAids.storyHindi}
                </div>
              </div>
            </div>

            {/* Practice Quiz Section */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-cyan-500/40 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Award size={18} className="text-amber-400" />
                  <h4 className="text-sm font-black text-white">स्व-मूल्यांकन अभ्यास प्रश्न (Self-Test Practice MCQs)</h4>
                </div>
                <span className="text-xs text-slate-400 font-bold">
                  {currentPkg.examPreparation.practiceQuestions.length} Board Exam Questions
                </span>
              </div>

              <div className="space-y-4">
                {currentPkg.examPreparation.practiceQuestions.map((q, qIdx) => {
                  const selectedOpt = userQuizAnswers[q.id];
                  const isAnswered = selectedOpt !== undefined;
                  const isCorrect = selectedOpt === q.correctAnswerIndex;

                  return (
                    <div key={q.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <h5 className="text-xs font-black text-white leading-snug">
                          Q{qIdx + 1}. {q.questionHindi}
                          <span className="block text-[11px] font-normal text-slate-400 mt-0.5">
                            {q.questionEnglish}
                          </span>
                        </h5>
                        <span className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 text-[10px] font-extrabold shrink-0">
                          {q.examMarks} Marks
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {q.options.map((opt, optIdx) => {
                          const isOptionSelected = selectedOpt === optIdx;
                          const isOptionCorrect = q.correctAnswerIndex === optIdx;

                          return (
                            <button
                              key={optIdx}
                              onClick={() => {
                                setUserQuizAnswers(prev => ({ ...prev, [q.id]: optIdx }));
                              }}
                              className={cn(
                                "p-2.5 rounded-xl text-left text-xs font-semibold transition-all border flex items-center justify-between cursor-pointer",
                                isAnswered
                                  ? isOptionCorrect
                                    ? "bg-emerald-950/80 border-emerald-500 text-emerald-200"
                                    : isOptionSelected
                                      ? "bg-red-950/80 border-red-500 text-red-200"
                                      : "bg-slate-900 border-slate-800 text-slate-400 opacity-60"
                                  : isOptionSelected
                                    ? "bg-cyan-950 border-cyan-500 text-cyan-200"
                                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800"
                              )}
                            >
                              <span>{opt}</span>
                              {isAnswered && isOptionCorrect && <CheckCircle2 size={14} className="text-emerald-400" />}
                              {isAnswered && isOptionSelected && !isOptionCorrect && <XCircle size={14} className="text-red-400" />}
                            </button>
                          );
                        })}
                      </div>

                      {isAnswered && (
                        <div className={cn(
                          "p-2.5 rounded-xl text-[11px] leading-snug border animate-fadeIn",
                          isCorrect ? "bg-emerald-950/50 border-emerald-800 text-emerald-200" : "bg-red-950/50 border-red-800 text-red-200"
                        )}>
                          <strong>{isCorrect ? "✅ बिल्कुल सही! " : "❌ सही उत्तर: "}</strong>
                          {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
