export * from '../../src/modules/diagnostic/types';
