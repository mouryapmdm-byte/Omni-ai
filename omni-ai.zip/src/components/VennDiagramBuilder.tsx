import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Layers, Sparkles, RefreshCw, Move, HelpCircle, 
  Send, Copy, Check, ChevronRight, Sliders, Info, Eye, Zap, Maximize2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';

interface VennDiagramBuilderProps {
  isOpen: boolean;
  onClose: () => void;
  onSendToChat?: (prompt: string) => void;
  initialTopic?: string;
  theme?: 'light' | 'dark';
}

export function VennDiagramBuilder({
  isOpen,
  onClose,
  onSendToChat,
  initialTopic = 'Set Theory & Venn Diagrams',
  theme = 'dark'
}: VennDiagramBuilderProps) {
  // Sets configuration mode: '2-set' | '3-set'
  const [numSets, setNumSets] = useState<'2-set' | '3-set'>('2-set');

  // Set names & elements
  const [setNameA, setSetNameA] = useState('Set A (Math)');
  const [setNameB, setSetNameB] = useState('Set B (Science)');
  const [setNameC, setSetNameC] = useState('Set C (Logic)');

  const [rawElementsA, setRawElementsA] = useState('1, 2, 3, 4, 5, 8, 10');
  const [rawElementsB, setRawElementsB] = useState('4, 5, 6, 7, 8, 9, 12');
  const [rawElementsC, setRawElementsC] = useState('2, 5, 8, 11, 12, 15');
  const [rawElementsU, setRawElementsU] = useState('1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 20');

  // Dragging & Overlap position state (Circle centers in percentage 0-100)
  const [circleAPos, setCircleAPos] = useState({ x: 38, y: 50, r: 28 });
  const [circleBPos, setCircleBPos] = useState({ x: 62, y: 50, r: 28 });
  const [circleCPos, setCircleCPos] = useState({ x: 50, y: 68, r: 26 });

  // Active region selection for formula highlight
  const [selectedRegion, setSelectedRegion] = useState<string>('A_intersect_B');
  const [copiedFormula, setCopiedFormula] = useState(false);

  // SVG Canvas Dragging tracking
  const [isDragging, setIsDragging] = useState<'A' | 'B' | 'C' | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // Process elements into clean arrays
  const parseElements = (str: string) => {
    return Array.from(new Set(
      str.split(/[,;\s]+/)
        .map(e => e.trim())
        .filter(e => e.length > 0)
    ));
  };

  const elemA = parseElements(rawElementsA);
  const elemB = parseElements(rawElementsB);
  const elemC = parseElements(rawElementsC);
  const elemU = parseElements(rawElementsU);

  // Calculate intersections & set regions
  const intersectAB = elemA.filter(e => elemB.includes(e));
  const intersectAC = elemA.filter(e => elemC.includes(e));
  const intersectBC = elemB.filter(e => elemC.includes(e));
  const intersectABC = elemA.filter(e => elemB.includes(e) && elemC.includes(e));

  const onlyA = elemA.filter(e => !elemB.includes(e) && (numSets === '2-set' || !elemC.includes(e)));
  const onlyB = elemB.filter(e => !elemA.includes(e) && (numSets === '2-set' || !elemC.includes(e)));
  const onlyC = elemC.filter(e => !elemA.includes(e) && !elemB.includes(e));

  const unionAB = Array.from(new Set([...elemA, ...elemB]));
  const unionABC = Array.from(new Set([...elemA, ...elemB, ...elemC]));

  const outsideU = elemU.filter(e => 
    numSets === '2-set' 
      ? (!elemA.includes(e) && !elemB.includes(e))
      : (!elemA.includes(e) && !elemB.includes(e) && !elemC.includes(e))
  );

  // Calculate distance between center A and B for visual overlap
  const distanceAB = Math.hypot(circleBPos.x - circleAPos.x, circleBPos.y - circleAPos.y);
  const overlapPercent = Math.max(0, Math.min(100, Math.round((1 - (distanceAB / (circleAPos.r + circleBPos.r))) * 100)));

  // SVG Pointer Events for interactive dragging
  const handlePointerDown = (circle: 'A' | 'B' | 'C') => {
    setIsDragging(circle);
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!isDragging || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = Math.max(15, Math.min(85, ((e.clientX - rect.left) / rect.width) * 100));
    const y = Math.max(20, Math.min(80, ((e.clientY - rect.top) / rect.height) * 100));

    if (isDragging === 'A') setCircleAPos(prev => ({ ...prev, x, y }));
    else if (isDragging === 'B') setCircleBPos(prev => ({ ...prev, x, y }));
    else if (isDragging === 'C') setCircleCPos(prev => ({ ...prev, x, y }));
  };

  const handlePointerUp = () => {
    setIsDragging(null);
  };

  // Presets
  const applyPreset = (preset: 'overlapping' | 'disjoint' | 'subset' | 'equal') => {
    if (preset === 'overlapping') {
      setCircleAPos({ x: 38, y: 50, r: 28 });
      setCircleBPos({ x: 62, y: 50, r: 28 });
      setCircleCPos({ x: 50, y: 68, r: 26 });
      setRawElementsA('1, 2, 3, 4, 5, 8');
      setRawElementsB('4, 5, 6, 7, 8, 9');
      setSelectedRegion('A_intersect_B');
    } else if (preset === 'disjoint') {
      setCircleAPos({ x: 28, y: 50, r: 22 });
      setCircleBPos({ x: 72, y: 50, r: 22 });
      setCircleCPos({ x: 50, y: 75, r: 20 });
      setRawElementsA('1, 2, 3');
      setRawElementsB('6, 7, 8, 9');
      setSelectedRegion('disjoint');
    } else if (preset === 'subset') {
      setCircleAPos({ x: 50, y: 50, r: 35 });
      setCircleBPos({ x: 50, y: 50, r: 18 });
      setRawElementsA('1, 2, 3, 4, 5, 6, 7, 8');
      setRawElementsB('3, 4, 5');
      setSelectedRegion('subset');
    } else if (preset === 'equal') {
      setCircleAPos({ x: 50, y: 50, r: 28 });
      setCircleBPos({ x: 50, y: 50, r: 28 });
      setRawElementsA('1, 2, 3, 4, 5');
      setRawElementsB('1, 2, 3, 4, 5');
      setSelectedRegion('equal');
    }
  };

  // Formula generator based on selected region & current set numbers
  const getFormulaLaTeX = () => {
    switch (selectedRegion) {
      case 'A_intersect_B':
        return `A \\cap B = \\{${intersectAB.join(', ')}\\}, \\quad |A \\cap B| = ${intersectAB.length}`;
      case 'A_union_B':
        return `A \\cup B = \\{${unionAB.join(', ')}\\}, \\quad |A \\cup B| = |A| + |B| - |A \\cap B| = ${elemA.length} + ${elemB.length} - ${intersectAB.length} = ${unionAB.length}`;
      case 'A_minus_B':
        return `A \\setminus B = \\{${onlyA.join(', ')}\\}, \\quad |A \\setminus B| = |A| - |A \\cap B| = ${onlyA.length}`;
      case 'B_minus_A':
        return `B \\setminus A = \\{${onlyB.join(', ')}\\}, \\quad |B \\setminus A| = |B| - |A \\cap B| = ${onlyB.length}`;
      case 'complement':
        return `(A \\cup B)' = U \\setminus (A \\cup B) = \\{${outsideU.join(', ')}\\}, \\quad |(A \\cup B)'| = ${outsideU.length}`;
      case 'disjoint':
        return `A \\cap B = \\emptyset, \\quad |A \\cap B| = 0 \\implies |A \\cup B| = |A| + |B|`;
      case 'subset':
        return `B \\subseteq A \\implies A \\cap B = B, \\quad A \\cup B = A`;
      case 'equal':
        return `A = B \\implies A \\cap B = A = B, \\quad A \\cup B = A`;
      default:
        return `|A \\cup B| = |A| + |B| - |A \\cap B|`;
    }
  };

  const handleCopyFormula = () => {
    navigator.clipboard.writeText(getFormulaLaTeX());
    setCopiedFormula(true);
    setTimeout(() => setCopiedFormula(false), 2000);
  };

  const handleAskAI = () => {
    const prompt = `Please explain the set theory concept based on this interactive Venn Diagram configuration:
- Set A: ${setNameA} = {${elemA.join(', ')}} (size: ${elemA.length})
- Set B: ${setNameB} = {${elemB.join(', ')}} (size: ${elemB.length})
- Overlap (A ∩ B): {${intersectAB.join(', ')}} (size: ${intersectAB.length})
- Union (A ∪ B): {${unionAB.join(', ')}} (size: ${unionAB.length})
- Selected Formula: $${getFormulaLaTeX()}$
- Distance Overlap percentage: ${overlapPercent}%

Explain the mathematical relationship, principle of inclusion-exclusion, and real-world application step-by-step with LaTeX equations.`;
    onSendToChat?.(prompt);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="relative w-full max-w-5xl bg-slate-900 border border-indigo-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between px-5 py-4 bg-slate-950 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 font-bold">
                <Layers size={20} />
              </div>
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  Interactive Venn Diagram Builder & Formula Solver
                  <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] uppercase font-mono tracking-wider border border-indigo-500/30">
                    Real-Time Math Engine
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  Drag circles to adjust overlap, modify elements, and generate live set theory formulas.
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>

          {/* Body Content Grid */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Interactive Canvas Column */}
            <div className="lg:col-span-7 flex flex-col space-y-4">
              {/* Presets & Set Selector Header */}
              <div className="flex items-center justify-between bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400">Mode:</span>
                  <button
                    onClick={() => setNumSets('2-set')}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                      numSets === '2-set' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    2-Set Venn
                  </button>
                  <button
                    onClick={() => setNumSets('3-set')}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                      numSets === '3-set' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    3-Set Venn
                  </button>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[11px] text-slate-500 font-medium mr-1">Presets:</span>
                  <button
                    onClick={() => applyPreset('overlapping')}
                    className="px-2 py-1 rounded bg-slate-800 hover:bg-indigo-950 hover:text-indigo-300 text-slate-300 text-[11px] font-medium transition cursor-pointer"
                  >
                    Intersecting
                  </button>
                  <button
                    onClick={() => applyPreset('disjoint')}
                    className="px-2 py-1 rounded bg-slate-800 hover:bg-indigo-950 hover:text-indigo-300 text-slate-300 text-[11px] font-medium transition cursor-pointer"
                  >
                    Disjoint
                  </button>
                  <button
                    onClick={() => applyPreset('subset')}
                    className="px-2 py-1 rounded bg-slate-800 hover:bg-indigo-950 hover:text-indigo-300 text-slate-300 text-[11px] font-medium transition cursor-pointer"
                  >
                    Subset ($B \subseteq A$)
                  </button>
                </div>
              </div>

              {/* Interactive SVG Canvas Area */}
              <div className="relative w-full aspect-[4/3] bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex flex-col justify-between shadow-inner select-none">
                {/* Canvas Top Bar */}
                <div className="absolute top-3 left-3 z-10 flex items-center gap-2 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-slate-300 backdrop-blur-sm">
                  <Move size={14} className="text-indigo-400 animate-bounce" />
                  <span className="font-semibold text-[11px]">Click & Drag Circle Centers</span>
                  <span className="text-slate-500 font-mono">| Overlap: {overlapPercent}%</span>
                </div>

                {/* Universal Set Label */}
                <div className="absolute bottom-3 right-3 z-10 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-400">
                  Universal Set U = &#123;{elemU.length} elements&#125;
                </div>

                {/* SVG Canvas */}
                <svg
                  ref={svgRef}
                  className="w-full h-full cursor-crosshair touch-none"
                  viewBox="0 0 100 100"
                  onPointerMove={handlePointerMove}
                  onPointerUp={handlePointerUp}
                >
                  <defs>
                    <radialGradient id="gradA" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#818cf8" stopOpacity="0.45" />
                      <stop offset="100%" stopColor="#4f46e5" stopOpacity="0.2" />
                    </radialGradient>
                    <radialGradient id="gradB" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#34d399" stopOpacity="0.45" />
                      <stop offset="100%" stopColor="#059669" stopOpacity="0.2" />
                    </radialGradient>
                    <radialGradient id="gradC" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#fbbf24" stopOpacity="0.45" />
                      <stop offset="100%" stopColor="#d97706" stopOpacity="0.2" />
                    </radialGradient>
                  </defs>

                  {/* Universal Set Rectangle */}
                  <rect x="2" y="2" width="96" height="96" rx="6" fill="none" stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />

                  {/* Circle A */}
                  <circle
                    cx={circleAPos.x}
                    cy={circleAPos.y}
                    r={circleAPos.r}
                    fill="url(#gradA)"
                    stroke="#818cf8"
                    strokeWidth={isDragging === 'A' ? "1.5" : "1"}
                    className="transition-opacity duration-150 cursor-grab active:cursor-grabbing hover:opacity-90"
                    onPointerDown={() => handlePointerDown('A')}
                  />

                  {/* Circle B */}
                  <circle
                    cx={circleBPos.x}
                    cy={circleBPos.y}
                    r={circleBPos.r}
                    fill="url(#gradB)"
                    stroke="#34d399"
                    strokeWidth={isDragging === 'B' ? "1.5" : "1"}
                    className="transition-opacity duration-150 cursor-grab active:cursor-grabbing hover:opacity-90"
                    onPointerDown={() => handlePointerDown('B')}
                  />

                  {/* Circle C (if 3-set mode) */}
                  {numSets === '3-set' && (
                    <circle
                      cx={circleCPos.x}
                      cy={circleCPos.y}
                      r={circleCPos.r}
                      fill="url(#gradC)"
                      stroke="#fbbf24"
                      strokeWidth={isDragging === 'C' ? "1.5" : "1"}
                      className="transition-opacity duration-150 cursor-grab active:cursor-grabbing hover:opacity-90"
                      onPointerDown={() => handlePointerDown('C')}
                    />
                  )}

                  {/* Labels on Circles */}
                  <text
                    x={circleAPos.x - (circleAPos.r * 0.4)}
                    y={circleAPos.y - (circleAPos.r * 0.4)}
                    fill="#a5b4fc"
                    fontSize="3.8"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {setNameA.split(' ')[0]}
                  </text>

                  <text
                    x={circleBPos.x + (circleBPos.r * 0.4)}
                    y={circleBPos.y - (circleBPos.r * 0.4)}
                    fill="#6ee7b7"
                    fontSize="3.8"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {setNameB.split(' ')[0]}
                  </text>

                  {numSets === '3-set' && (
                    <text
                      x={circleCPos.x}
                      y={circleCPos.y + (circleCPos.r * 0.6)}
                      fill="#fde047"
                      fontSize="3.8"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {setNameC.split(' ')[0]}
                    </text>
                  )}

                  {/* Elements Text inside regions */}
                  <text
                    x={circleAPos.x - (circleAPos.r * 0.4)}
                    y={circleAPos.y + 1}
                    fill="#cbd5e1"
                    fontSize="2.8"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    {onlyA.slice(0, 3).join(', ')}{onlyA.length > 3 ? '...' : ''}
                  </text>

                  <text
                    x={circleBPos.x + (circleBPos.r * 0.4)}
                    y={circleBPos.y + 1}
                    fill="#cbd5e1"
                    fontSize="2.8"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    {onlyB.slice(0, 3).join(', ')}{onlyB.length > 3 ? '...' : ''}
                  </text>

                  {/* Overlap Text */}
                  <text
                    x={(circleAPos.x + circleBPos.x) / 2}
                    y={(circleAPos.y + circleBPos.y) / 2}
                    fill="#f8fafc"
                    fontSize="3.2"
                    fontWeight="bold"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    {intersectAB.slice(0, 2).join(', ')}
                  </text>
                </svg>
              </div>

              {/* Slider Controls for Precise Radius Adjustments */}
              <div className="grid grid-cols-2 gap-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-xs">
                <div>
                  <label className="text-slate-400 font-semibold flex justify-between mb-1">
                    <span>Set A Radius ($r_A$)</span>
                    <span className="font-mono text-indigo-400">{circleAPos.r}px</span>
                  </label>
                  <input
                    type="range"
                    min="15"
                    max="40"
                    value={circleAPos.r}
                    onChange={(e) => setCircleAPos(prev => ({ ...prev, r: Number(e.target.value) }))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-semibold flex justify-between mb-1">
                    <span>Set B Radius ($r_B$)</span>
                    <span className="font-mono text-emerald-400">{circleBPos.r}px</span>
                  </label>
                  <input
                    type="range"
                    min="15"
                    max="40"
                    value={circleBPos.r}
                    onChange={(e) => setCircleBPos(prev => ({ ...prev, r: Number(e.target.value) }))}
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Right Formula & Elements Controls Column */}
            <div className="lg:col-span-5 flex flex-col space-y-4">
              
              {/* Formula & Set Notation Display Box */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-indigo-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                    <Sparkles size={14} /> Live Set Formula & LaTeX
                  </span>
                  <button
                    onClick={handleCopyFormula}
                    className="px-2.5 py-1 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                  >
                    {copiedFormula ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                    {copiedFormula ? 'Copied!' : 'Copy LaTeX'}
                  </button>
                </div>

                <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 text-white font-mono text-sm overflow-x-auto min-h-[60px] flex items-center">
                  <ReactMarkdown
                    remarkPlugins={[remarkMath, remarkGfm]}
                    rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
                  >
                    {`$$${getFormulaLaTeX()}$$`}
                  </ReactMarkdown>
                </div>

                {/* Region Highlight Buttons */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-400">Select Region to Calculate:</span>
                  <div className="grid grid-cols-2 gap-1.5 text-xs">
                    <button
                      onClick={() => setSelectedRegion('A_intersect_B')}
                      className={`p-2 rounded-lg text-left transition font-semibold cursor-pointer ${
                        selectedRegion === 'A_intersect_B' 
                          ? 'bg-indigo-600 text-white border border-indigo-400' 
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                      }`}
                    >
                      $A \\cap B$ (Intersection)
                    </button>
                    <button
                      onClick={() => setSelectedRegion('A_union_B')}
                      className={`p-2 rounded-lg text-left transition font-semibold cursor-pointer ${
                        selectedRegion === 'A_union_B' 
                          ? 'bg-indigo-600 text-white border border-indigo-400' 
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                      }`}
                    >
                      $A \\cup B$ (Union)
                    </button>
                    <button
                      onClick={() => setSelectedRegion('A_minus_B')}
                      className={`p-2 rounded-lg text-left transition font-semibold cursor-pointer ${
                        selectedRegion === 'A_minus_B' 
                          ? 'bg-indigo-600 text-white border border-indigo-400' 
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                      }`}
                    >
                      $A \\setminus B$ (Only A)
                    </button>
                    <button
                      onClick={() => setSelectedRegion('complement')}
                      className={`p-2 rounded-lg text-left transition font-semibold cursor-pointer ${
                        selectedRegion === 'complement' 
                          ? 'bg-indigo-600 text-white border border-indigo-400' 
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                      }`}
                    >
                      $(A \\cup B)'$ (Complement)
                    </button>
                  </div>
                </div>
              </div>

              {/* Elements Input Form */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                  <span>Set Elements & Members</span>
                  <span className="text-[10px] text-slate-500 font-normal">Comma-separated</span>
                </h3>

                {/* Set A Input */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <input
                      type="text"
                      value={setNameA}
                      onChange={(e) => setSetNameA(e.target.value)}
                      className="bg-transparent font-bold text-indigo-400 focus:outline-none focus:underline"
                    />
                    <span className="text-slate-400 font-mono text-[11px]">&#124;A&#124; = {elemA.length}</span>
                  </div>
                  <input
                    type="text"
                    value={rawElementsA}
                    onChange={(e) => setRawElementsA(e.target.value)}
                    placeholder="e.g. 1, 2, 3, 4"
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:border-indigo-500 focus:outline-none font-mono"
                  />
                </div>

                {/* Set B Input */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <input
                      type="text"
                      value={setNameB}
                      onChange={(e) => setSetNameB(e.target.value)}
                      className="bg-transparent font-bold text-emerald-400 focus:outline-none focus:underline"
                    />
                    <span className="text-slate-400 font-mono text-[11px]&#124;">&#124;B&#124; = {elemB.length}</span>
                  </div>
                  <input
                    type="text"
                    value={rawElementsB}
                    onChange={(e) => setRawElementsB(e.target.value)}
                    placeholder="e.g. 4, 5, 6, 7"
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none font-mono"
                  />
                </div>

                {/* Universal Set Input */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
                    <span>Universal Set (U)</span>
                    <span className="font-mono text-[11px]">&#124;U&#124; = {elemU.length}</span>
                  </div>
                  <input
                    type="text"
                    value={rawElementsU}
                    onChange={(e) => setRawElementsU(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 focus:border-slate-600 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Action Button: Send to AI Tutor */}
              <button
                onClick={handleAskAI}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold text-sm shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 transition cursor-pointer active:scale-98"
              >
                <Send size={16} />
                Ask AI Tutor to Analyze This Venn Diagram
              </button>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
