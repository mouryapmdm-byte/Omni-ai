import React from 'react';
import { 
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  AreaChart, Area, Legend
} from 'recharts';
import { 
  Activity, Microscope, TestTube, BarChart2, TrendingUp, Info, ChevronRight, 
  Dna, Heart, FlaskConical, Wind, Zap
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface BiologyDashboardProps {
  theme?: 'light' | 'dark';
  onOpenLab?: (tab: string) => void;
}

const ENZYME_DATA = [
  { temp: 10, activity: 15 },
  { temp: 20, activity: 35 },
  { temp: 30, activity: 75 },
  { temp: 37, activity: 100 },
  { temp: 45, activity: 60 },
  { temp: 55, activity: 20 },
  { temp: 65, activity: 5 },
];

const DNA_HYBRIDIZATION_DATA = [
  { time: 0, percent: 100 },
  { time: 10, percent: 85 },
  { time: 20, percent: 65 },
  { time: 30, percent: 45 },
  { time: 40, percent: 30 },
  { time: 50, percent: 22 },
  { time: 60, percent: 18 },
];

const POPULATION_GROWTH_DATA = [
  { day: 0, count: 10 },
  { day: 5, count: 25 },
  { day: 10, count: 60 },
  { day: 15, count: 150 },
  { day: 20, count: 320 },
  { day: 25, count: 580 },
  { day: 30, count: 850 },
  { day: 35, count: 980 },
  { day: 40, count: 1050 },
];

export const BiologyDashboard: React.FC<BiologyDashboardProps> = ({ 
  theme = 'dark',
  onOpenLab 
}) => {
  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 overflow-y-auto">
      {/* Header */}
      <div className="p-8 bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-rose-500/10 text-rose-500 text-[10px] font-black uppercase tracking-widest border border-rose-500/20">
                Interactive Lab Hub
              </span>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-tight">Class 12 Biology</span>
            </div>
            <h1 className="text-3xl font-black tracking-tight text-slate-900 dark:text-white">
              Biological Metrics Dashboard
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-2xl">
              Explore real-time experimental metrics, growth dynamics, and kinetic analysis tools mapped to the CBSE Class 12 curriculum.
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="p-4 rounded-2xl bg-rose-500/5 border border-rose-500/10 flex items-center gap-4">
              <div className="text-right">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Avg. Lab Mastery</p>
                <p className="text-2xl font-black text-rose-500">88%</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-rose-500 flex items-center justify-center text-white shadow-lg shadow-rose-500/20">
                <Activity className="w-6 h-6" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-8 space-y-8 max-w-7xl mx-auto w-full">
        {/* Main Analytics Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Card 1: Enzyme Kinetics */}
          <div className="lg:col-span-2 p-6 rounded-3xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500">
                  <FlaskConical className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-white">Enzyme Activity Rate</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Temperature vs Efficiency</p>
                </div>
              </div>
              <button className="text-[10px] font-black text-indigo-500 uppercase tracking-widest hover:underline">
                View Protocol
              </button>
            </div>

            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <AreaChart data={ENZYME_DATA}>
                  <defs>
                    <linearGradient id="colorActivity" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={theme === 'dark' ? '#1e293b' : '#f1f5f9'} />
                  <XAxis 
                    dataKey="temp" 
                    unit="°C"
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 'bold', fill: '#64748b' }}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false}
                    unit="%"
                    tick={{ fontSize: 10, fontWeight: 'bold', fill: '#64748b' }}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                      border: 'none',
                      borderRadius: '12px',
                      boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="activity" 
                    stroke="#f59e0b" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorActivity)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="p-4 rounded-2xl bg-amber-500/5 border border-amber-500/10">
              <p className="text-xs text-amber-700 dark:text-amber-500 leading-relaxed italic">
                <strong>Insight:</strong> Optimum activity is reached at 37°C. Denaturation occurs rapidly beyond 45°C as protein tertiary structures begin to collapse.
              </p>
            </div>
          </div>

          {/* Quick Access Sidebar */}
          <div className="space-y-6">
            <div className="p-6 rounded-3xl bg-indigo-600 shadow-xl shadow-indigo-600/20 text-white space-y-4">
              <div className="flex items-center gap-3">
                <Microscope className="w-6 h-6" />
                <h3 className="font-bold">Virtual Labs</h3>
              </div>
              <p className="text-xs text-indigo-100 leading-relaxed">
                Dive into interactive simulations for Genetics, Cell Anatomy, and Ecology.
              </p>
              <div className="space-y-2">
                {[
                  { name: 'Genetics Lab', tab: 'genetics', icon: <Dna className="w-3.5 h-3.5" /> },
                  { name: 'Life Cycle Explorer', tab: 'lifecycles', icon: <TrendingUp className="w-3.5 h-3.5" /> },
                  { name: 'Ecosystem Sandbox', tab: 'ecology', icon: <Wind className="w-3.5 h-3.5" /> }
                ].map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => onOpenLab?.(item.tab)}
                    className="w-full flex items-center justify-between p-3 rounded-xl bg-white/10 hover:bg-white/20 transition-all group"
                  >
                    <span className="text-xs font-bold flex items-center gap-2">
                      {item.icon}
                      {item.name}
                    </span>
                    <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                  </button>
                ))}
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-rose-500" />
                <h3 className="text-sm font-bold">DNA Hybridization</h3>
              </div>
              <div className="h-[120px] w-full">
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                  <LineChart data={DNA_HYBRIDIZATION_DATA}>
                    <XAxis dataKey="time" hide />
                    <YAxis hide domain={[0, 100]} />
                    <Tooltip 
                      contentStyle={{ fontSize: '10px', borderRadius: '8px' }}
                    />
                    <Line 
                      type="step" 
                      dataKey="percent" 
                      stroke="#ec4899" 
                      strokeWidth={2} 
                      dot={false} 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-[10px] text-slate-500 font-medium">
                Kinetics of reassociation in heterogeneous DNA samples.
              </p>
            </div>
          </div>

          {/* Population Growth Chart */}
          <div className="lg:col-span-3 p-6 rounded-3xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-white">Sigmoid Population Growth (S-Curve)</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Logistic Growth with Carrying Capacity (K)</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                  <span className="text-[10px] font-bold text-slate-400">Measured Growth</span>
                </div>
              </div>
            </div>

            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <LineChart data={POPULATION_GROWTH_DATA}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={theme === 'dark' ? '#1e293b' : '#f1f5f9'} />
                  <XAxis 
                    dataKey="day" 
                    label={{ value: 'Time (Days)', position: 'insideBottomRight', offset: -5, fontSize: 10, fontWeight: 'bold' }}
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 'bold', fill: '#64748b' }}
                  />
                  <YAxis 
                    label={{ value: 'Individuals', angle: -90, position: 'insideLeft', fontSize: 10, fontWeight: 'bold' }}
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 10, fontWeight: 'bold', fill: '#64748b' }}
                  />
                  <Tooltip 
                    cursor={{ stroke: '#10b981', strokeWidth: 2, strokeDasharray: '5 5' }}
                    contentStyle={{ 
                      backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                      border: 'none',
                      borderRadius: '12px',
                      boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="count" 
                    stroke="#10b981" 
                    strokeWidth={4}
                    dot={{ r: 4, fill: '#10b981', strokeWidth: 2, stroke: '#fff' }}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Phase 1</span>
                <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-1">Lag Phase</p>
                <p className="text-[10px] text-slate-500 mt-1">Initial period of adaptation with slow numerical increase.</p>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-500/5 border border-emerald-500/10">
                <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Phase 2</span>
                <p className="text-xs font-bold text-emerald-700 dark:text-emerald-400 mt-1">Exponential Phase</p>
                <p className="text-[10px] text-emerald-600/70 dark:text-emerald-500/70 mt-1">Rapid multiplication as resources are abundant.</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Phase 3</span>
                <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-1">Stationary Phase</p>
                <p className="text-[10px] text-slate-500 mt-1">Carrying capacity reached; birth rate equals death rate.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
