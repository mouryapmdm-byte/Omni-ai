import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronDown,
  ChevronRight,
  BookOpen,
  Check,
  Sparkles,
  Layers,
  Search,
  Maximize2,
  Minimize2,
  ListTree,
  FolderOpen
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { LECTURE_SECTIONS_META } from '@/src/lib/studyContentGenerator';

export interface SyllabusExpansionControlsProps {
  currentSection: number | 'all';
  onSelectSection: (sectionId: number | 'all') => void;
  topicTitle?: string;
  userSubject?: string;
  onSelectTopic?: (topicTitle: string) => void;
  buttonLabel?: string;
  align?: 'left' | 'right';
  className?: string;
  disabled?: boolean;
}

// Built-in Syllabus Knowledge Tree organized by subject
export const SYLLABUS_TREE: Record<string, { category: string; topics: string[] }[]> = {
  physics: [
    {
      category: 'Mechanics & Motion',
      topics: [
        'Kinematics & Motion in 1D/2D',
        'Newton\'s Laws of Motion & Momentum',
        'Work, Power & Kinetic Energy',
        'Rotational Dynamics & Torque',
        'Gravitation & Orbital Mechanics'
      ]
    },
    {
      category: 'Thermodynamics & Waves',
      topics: [
        'Laws of Thermodynamics & Heat Engines',
        'Kinetic Theory of Gases',
        'Simple Harmonic Motion & Oscillations',
        'Wave Motion & Sound Waves'
      ]
    },
    {
      category: 'Electromagnetism & Modern Physics',
      topics: [
        'Electrostatics & Electric Fields',
        'Current Electricity & Ohm\'s Law',
        'Electromagnetic Induction & Faraday\'s Law',
        'Optics, Wave Interference & Diffraction',
        'Atomic Structure, Quantum & Nuclear Physics'
      ]
    }
  ],
  chemistry: [
    {
      category: 'Physical Chemistry',
      topics: [
        'Atomic Structure & Quantum Numbers',
        'Chemical Bonding & Molecular Geometry',
        'Chemical Energetics & Thermodynamics',
        'Chemical Equilibrium & Le Chatelier',
        'Electrochemistry & Nernst Equation'
      ]
    },
    {
      category: 'Inorganic Chemistry',
      topics: [
        'Periodic Table & Periodicity',
        's-Block & p-Block Elements',
        'Transition Elements & Coordination Compounds'
      ]
    },
    {
      category: 'Organic Chemistry',
      topics: [
        'IUPAC Nomenclature & Reaction Mechanisms',
        'Hydrocarbons: Alkanes, Alkenes & Alkynes',
        'Organic Halo & Oxygen Compounds',
        'Biomolecules, Polymers & Daily Chemistry'
      ]
    }
  ],
  biology: [
    {
      category: 'Cellular & Molecular Biology',
      topics: [
        'Cell Structure, Organelles & Membrane',
        'Biomolecules: Proteins, Carbohydrates & Lipids',
        'Cell Cycle, Mitosis & Meiosis',
        'DNA Replication, Transcription & Translation'
      ]
    },
    {
      category: 'Plant & Animal Physiology',
      topics: [
        'Photosynthesis & Carbon Fixation',
        'Cellular Respiration & ATP Synthesis',
        'Human Circulatory & Respiratory Systems',
        'Nervous System & Neural Conduction'
      ]
    },
    {
      category: 'Genetics, Evolution & Ecology',
      topics: [
        'Mendelian Genetics & Inheritance Patterns',
        'Molecular Basis of Genetics & Mutations',
        'Ecology, Ecosystems & Conservation'
      ]
    }
  ],
  mathematics: [
    {
      category: 'Algebra & Calculus',
      topics: [
        'Quadratic Equations & Polynomials',
        'Matrices, Determinants & Linear Systems',
        'Limits, Continuity & Derivatives',
        'Definite & Indefinite Integration',
        'Differential Equations & Applications'
      ]
    },
    {
      category: 'Vectors & Coordinate Geometry',
      topics: [
        'Vector Algebra & Dot/Cross Products',
        '3D Geometry: Lines & Planes in Space',
        'Conic Sections: Parabola, Ellipse, Hyperbola'
      ]
    },
    {
      category: 'Statistics & Probability',
      topics: [
        'Probability, Bayes\' Theorem & Random Variables',
        'Permutations, Combinations & Binomial Theorem'
      ]
    }
  ]
};

export const SyllabusExpansionControls: React.FC<SyllabusExpansionControlsProps> = ({
  currentSection = 'all',
  onSelectSection,
  topicTitle = '',
  userSubject = 'physics',
  onSelectTopic,
  buttonLabel = 'Syllabus Expansion ▾',
  align = 'left',
  className = '',
  disabled = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'syllabus_tree' | 'sections'>('syllabus_tree');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const dropdownRef = useRef<HTMLDivElement>(null);

  const normalizedSubject = (userSubject || 'physics').toLowerCase();
  const subjectSyllabus = SYLLABUS_TREE[normalizedSubject] || SYLLABUS_TREE.physics;

  // Initialize all categories as expanded
  useEffect(() => {
    const initialExpanded: Record<string, boolean> = {};
    subjectSyllabus.forEach((cat, idx) => {
      initialExpanded[`cat-${idx}`] = true;
    });
    setExpandedCategories(initialExpanded);
  }, [normalizedSubject]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  const toggleCategory = (catKey: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [catKey]: !prev[catKey]
    }));
  };

  const expandAllCategories = () => {
    const next: Record<string, boolean> = {};
    subjectSyllabus.forEach((_, idx) => {
      next[`cat-${idx}`] = true;
    });
    setExpandedCategories(next);
  };

  const collapseAllCategories = () => {
    setExpandedCategories({});
  };

  const activeMeta = typeof currentSection === 'number'
    ? LECTURE_SECTIONS_META.find(s => s.id === currentSection)
    : null;

  return (
    <div ref={dropdownRef} className={cn("relative inline-block text-left shrink-0", className)}>
      {/* Syllabus Expansion Controls Trigger Button */}
      <button
        id="syllabus-expansion-controls-trigger"
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(prev => !prev)}
        className={cn(
          "px-2 py-1 sm:px-2.5 sm:py-1 rounded-xl text-[10px] sm:text-xs font-bold flex items-center gap-1 sm:gap-1.5 transition-all cursor-pointer border shadow-sm select-none shrink-0",
          isOpen
            ? "bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400/40"
            : currentSection !== 'all'
              ? "bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-200 hover:text-white border-amber-500/50 hover:border-amber-400"
              : "bg-slate-900/95 hover:bg-slate-800 text-amber-300 hover:text-amber-200 border-amber-500/40 hover:border-amber-400",
          disabled && "opacity-50 cursor-not-allowed"
        )}
        title="Syllabus Expansion Controls: Explore syllabus units, expand chapters, and select curriculum sections"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <ListTree size={12} className={cn("shrink-0", isOpen ? "text-slate-950" : "text-amber-400")} />
        <span className="font-extrabold tracking-tight hidden sm:inline">
          {activeMeta ? `Syllabus: S${activeMeta.id}` : 'Syllabus Controls'}
        </span>
        <span className="font-extrabold tracking-tight inline sm:hidden">
          {activeMeta ? `S${activeMeta.id}` : 'Syllabus'}
        </span>
        {currentSection !== 'all' && (
          <span className={cn(
            "px-1.5 py-0.2 rounded-full text-[9px] font-black shrink-0",
            isOpen ? "bg-slate-950 text-amber-300" : "bg-amber-400/20 text-amber-300 border border-amber-400/40"
          )}>
            S{currentSection}
          </span>
        )}
        <ChevronDown
          size={11}
          className={cn("transition-transform duration-200 shrink-0", isOpen ? "rotate-180 text-slate-950" : "text-amber-400")}
        />
      </button>

      {/* Expanded Syllabus Panel */}
      {isOpen && (
        <div
          className={cn(
            "absolute z-50 mt-1.5 w-[360px] sm:w-[440px] max-w-[94vw] rounded-2xl bg-slate-950/98 backdrop-blur-2xl border border-amber-500/40 shadow-2xl shadow-black/80 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[82vh]",
            align === 'left' ? 'left-0 origin-top-left' : 'right-0 origin-top-right'
          )}
        >
          {/* Header */}
          <div className="px-3.5 py-2.5 bg-gradient-to-r from-amber-950/50 via-slate-900 to-indigo-950/50 border-b border-white/10 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-400">
                <BookOpen size={15} />
              </div>
              <div>
                <h4 className="text-xs font-black text-amber-300 tracking-wide uppercase flex items-center gap-1.5">
                  Syllabus Expansion Controls
                  <span className="px-1.5 py-0.2 rounded bg-amber-400/15 text-amber-300 text-[9px] font-bold border border-amber-500/25">
                    {normalizedSubject.toUpperCase()}
                  </span>
                </h4>
                <p className="text-[10px] text-slate-400 font-medium truncate max-w-[260px]">
                  {topicTitle ? `Active Topic: ${topicTitle}` : 'Expand syllabus tree & select curriculum units'}
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-amber-300 bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-500/30">
              {currentSection === 'all' ? 'Full Syllabus' : `Sec ${currentSection}`}
            </span>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center border-b border-white/10 bg-slate-900/60 px-2 pt-2 gap-1 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('syllabus_tree')}
              className={cn(
                "px-3 py-1.5 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 border-t border-x cursor-pointer",
                activeTab === 'syllabus_tree'
                  ? "bg-slate-950 border-amber-500/40 text-amber-300 shadow-sm"
                  : "bg-transparent border-transparent text-slate-400 hover:text-slate-200"
              )}
            >
              <ListTree size={13} />
              <span>Syllabus Expansion Tree</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('sections')}
              className={cn(
                "px-3 py-1.5 rounded-t-xl text-xs font-bold transition-all flex items-center gap-1.5 border-t border-x cursor-pointer",
                activeTab === 'sections'
                  ? "bg-slate-950 border-amber-500/40 text-amber-300 shadow-sm"
                  : "bg-transparent border-transparent text-slate-400 hover:text-slate-200"
              )}
            >
              <Layers size={13} />
              <span>Lecture Sections (7)</span>
            </button>
          </div>

          {/* Tab Content 1: Syllabus Expansion Tree */}
          {activeTab === 'syllabus_tree' && (
            <div className="p-3 space-y-2 overflow-y-auto max-h-[380px] custom-scrollbar">
              {/* Search & Expand All Controls */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Filter syllabus chapters..."
                    className="w-full pl-7 pr-3 py-1 rounded-xl bg-slate-900 border border-slate-700/80 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>
                <button
                  type="button"
                  onClick={expandAllCategories}
                  className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] font-bold text-amber-300 flex items-center gap-1 cursor-pointer"
                  title="Expand All Syllabus Categories"
                >
                  <Maximize2 size={10} />
                  <span>Expand All</span>
                </button>
                <button
                  type="button"
                  onClick={collapseAllCategories}
                  className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] font-bold text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                  title="Collapse All Syllabus Categories"
                >
                  <Minimize2 size={10} />
                  <span>Collapse</span>
                </button>
              </div>

              {/* Syllabus Categories & Topics */}
              <div className="space-y-2 mt-2">
                {subjectSyllabus.map((cat, idx) => {
                  const catKey = `cat-${idx}`;
                  const isCatExpanded = !!expandedCategories[catKey];
                  const filteredTopics = searchQuery
                    ? cat.topics.filter(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
                    : cat.topics;

                  if (searchQuery && filteredTopics.length === 0) return null;

                  return (
                    <div key={catKey} className="rounded-xl border border-slate-800/80 bg-slate-900/40 overflow-hidden">
                      <button
                        type="button"
                        onClick={() => toggleCategory(catKey)}
                        className="w-full px-3 py-2 bg-slate-900/80 hover:bg-slate-800/80 flex items-center justify-between text-left cursor-pointer transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          {isCatExpanded ? (
                            <FolderOpen size={13} className="text-amber-400 shrink-0" />
                          ) : (
                            <ChevronRight size={13} className="text-slate-400 shrink-0" />
                          )}
                          <span className="text-xs font-bold text-slate-200">{cat.category}</span>
                          <span className="text-[10px] text-slate-500 font-mono">({filteredTopics.length})</span>
                        </div>
                        <ChevronDown
                          size={12}
                          className={cn("text-slate-400 transition-transform duration-150", isCatExpanded ? "rotate-180" : "rotate-0")}
                        />
                      </button>

                      {isCatExpanded && (
                        <div className="p-1.5 space-y-1 bg-slate-950/60 border-t border-slate-800/60">
                          {filteredTopics.map((topicItem, tIdx) => {
                            const isCurrent = topicTitle.toLowerCase() === topicItem.toLowerCase();
                            return (
                              <button
                                key={`t-${tIdx}`}
                                type="button"
                                onClick={() => {
                                  if (onSelectTopic) {
                                    onSelectTopic(topicItem);
                                  }
                                  setIsOpen(false);
                                }}
                                className={cn(
                                  "w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-all flex items-center justify-between cursor-pointer group border",
                                  isCurrent
                                    ? "bg-amber-500/20 border-amber-400/50 text-amber-200 font-bold"
                                    : "bg-slate-900/40 hover:bg-slate-800/80 border-transparent text-slate-300 hover:text-white"
                                )}
                              >
                                <span className="truncate pr-2">{topicItem}</span>
                                {isCurrent ? (
                                  <Check size={12} className="text-amber-400 shrink-0" />
                                ) : (
                                  <Sparkles size={10} className="text-slate-600 group-hover:text-amber-400 transition-colors shrink-0" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab Content 2: Lecture Sections */}
          {activeTab === 'sections' && (
            <div className="p-2 space-y-1 overflow-y-auto max-h-[380px] custom-scrollbar">
              {/* Option: All Sections */}
              <button
                type="button"
                onClick={() => {
                  onSelectSection('all');
                  setIsOpen(false);
                }}
                className={cn(
                  "w-full text-left p-2 rounded-xl transition-all flex items-center justify-between group cursor-pointer border",
                  currentSection === 'all'
                    ? "bg-amber-500/15 border-amber-400/50 text-white shadow-sm"
                    : "bg-slate-900/60 hover:bg-slate-800/80 border-white/5 text-slate-300 hover:text-white"
                )}
              >
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs shrink-0",
                    currentSection === 'all' ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-amber-400 group-hover:bg-slate-700"
                  )}>
                    ★
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300 block">
                      All 7 Sections (Complete Master Lecture)
                    </span>
                    <span className="text-[10px] text-slate-400 block">
                      Full 360° syllabus coverage from core foundations to competitive exam questions
                    </span>
                  </div>
                </div>
                {currentSection === 'all' && <Check size={14} className="text-amber-400 shrink-0" />}
              </button>

              {/* 7 Lecture Sections */}
              {LECTURE_SECTIONS_META.map((sec) => {
                const isSelected = currentSection === sec.id;
                return (
                  <button
                    key={sec.id}
                    type="button"
                    onClick={() => {
                      onSelectSection(sec.id);
                      setIsOpen(false);
                    }}
                    className={cn(
                      "w-full text-left p-2 rounded-xl transition-all flex items-center justify-between group cursor-pointer border",
                      isSelected
                        ? "bg-amber-500/15 border-amber-400/50 text-white shadow-sm"
                        : "bg-slate-900/40 hover:bg-slate-800/70 border-white/5 text-slate-300 hover:text-white"
                    )}
                  >
                    <div className="flex items-start gap-2.5">
                      <div className={cn(
                        "w-6 h-6 rounded-lg flex items-center justify-center font-black text-xs shrink-0 mt-0.5",
                        isSelected ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-amber-400"
                      )}>
                        {sec.id}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300">
                            {sec.fullName}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-tight mt-0.5">
                          {sec.summary}
                        </p>
                      </div>
                    </div>
                    {isSelected && <Check size={14} className="text-amber-400 shrink-0 ml-1" />}
                  </button>
                );
              })}
            </div>
          )}

          {/* Footer */}
          <div className="p-2.5 bg-slate-900/90 border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400 shrink-0">
            <span>Click any section or syllabus topic to switch lecture focus</span>
            <span className="text-amber-300 font-bold">Standard Mode Aligned</span>
          </div>
        </div>
      )}
    </div>
  );
};
