import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  X, 
  Search, 
  Download, 
  Share2, 
  Bookmark, 
  Check, 
  Copy, 
  Calendar, 
  Link as LinkIcon, 
  HelpCircle, 
  BarChart2, 
  FileText, 
  Sparkles, 
  ExternalLink, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  Award, 
  Zap, 
  Volume2, 
  Maximize2,
  Clock,
  BookOpen,
  ArrowRight,
  ChevronRight,
  Flame,
  Star,
  Target,
  GraduationCap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { cn } from '../lib/utils';

export interface LaptopViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicTitle?: string;
  lectureNotesMarkdown?: string;
  onSelectTopic?: (topic: string) => void;
  showNotification?: (message: string, type: 'info' | 'success' | 'warning' | 'error') => void;
}

type TabType = 'notes' | 'schedule' | 'links' | 'quiz' | 'stats';

export const LaptopViewModal: React.FC<LaptopViewModalProps> = ({
  isOpen,
  onClose,
  topicTitle = 'Foundational Calculus & Analytical Geometry',
  lectureNotesMarkdown,
  onSelectTopic,
  showNotification
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('notes');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isBookmarked, setIsBookmarked] = useState<boolean>(false);
  const [isBooting, setIsBooting] = useState<boolean>(true);
  const [isSleeping, setIsSleeping] = useState<boolean>(false);

  // Inactivity Sleep Mode Timer (30s)
  const sleepTimerRef = useRef<NodeJS.Timeout | null>(null);

  const resetSleepTimer = () => {
    if (isSleeping) setIsSleeping(false);
    if (sleepTimerRef.current) clearTimeout(sleepTimerRef.current);
    sleepTimerRef.current = setTimeout(() => {
      setIsSleeping(true);
    }, 30000);
  };

  useEffect(() => {
    if (isOpen) {
      setIsBooting(true);
      const timer = setTimeout(() => setIsBooting(false), 600);
      resetSleepTimer();
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleActivity = () => resetSleepTimer();
    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('keydown', handleActivity);
    return () => {
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      if (sleepTimerRef.current) clearTimeout(sleepTimerRef.current);
    };
  }, [isSleeping]);

  // Keyboard shortcut listener (Esc to close, 1-5 for tabs)
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === '1') {
        setActiveTab('notes');
      } else if (e.key === '2') {
        setActiveTab('schedule');
      } else if (e.key === '3') {
        setActiveTab('links');
      } else if (e.key === '4') {
        setActiveTab('quiz');
      } else if (e.key === '5') {
        setActiveTab('stats');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Default rich lecture notes fallback
  const defaultNotes = useMemo(() => {
    const title = topicTitle || 'Differential Calculus & Mathematical Analysis';
    return `
# ${title}

## 1. Overview & Fundamental Equation
The instantaneous rate of change describes how a dependent variable changes with respect to an infinitesimal increment in an independent variable:

$$\\mathbf{f'(x) = \\lim_{h \\to 0} \\frac{f(x+h) - f(x)}{h}}$$

* **Analytical Domain:** Continuous and differentiable real-valued functions
* **Geometric Meaning:** Tangent line slope at point $(x, f(x))$
* **Stationary Points:** Points where $f'(x) = 0$ identify local extrema and optimization thresholds.

---

## 2. Key Mathematical & Physical Principles
* **Linear Approximation:** $f(x + \\Delta x) \\approx f(x) + f'(x) \\Delta x$ gives the optimal first-order local prediction.
* **Curvature & Concavity:** The second derivative $f''(x)$ indicates whether the trajectory is concave up ($> 0$) or concave down ($< 0$).
* **Conservation & Rate Matching:** Instantaneous velocity $v(t) = \\frac{ds}{dt}$ and acceleration $a(t) = \\frac{dv}{dt}$.

---

## 3. Quantitative Worked Example
Calculate the critical points of $f(x) = 2x^3 - 9x^2 + 12x + 1$:
1. Compute the first derivative: $f'(x) = 6x^2 - 18x + 12 = 6(x-1)(x-2)$
2. Set $f'(x) = 0$: critical points at $x = 1$ and $x = 2$
3. Second derivative test: $f''(x) = 12x - 18$
   * At $x = 1$: $f''(1) = -6 < 0 \\implies$ **Local Maximum** at $(1, 6)$
   * At $x = 2$: $f''(2) = +6 > 0 \\implies$ **Local Minimum** at $(2, 5)$.
`;
  }, [topicTitle]);

  const activeNotes = lectureNotesMarkdown || defaultNotes;

  // Filtered Notes based on search
  const filteredNotes = useMemo(() => {
    if (!searchQuery.trim()) return activeNotes;
    const lines = activeNotes.split('\n');
    const matched = lines.filter(l => l.toLowerCase().includes(searchQuery.toLowerCase()));
    return matched.join('\n\n') || `*No matching notes found for "${searchQuery}"*`;
  }, [activeNotes, searchQuery]);

  // Copy Notes to Clipboard
  const handleCopyNotes = () => {
    navigator.clipboard.writeText(activeNotes);
    setIsCopied(true);
    showNotification?.('Lecture notes copied to clipboard!', 'success');
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Download Notes
  const handleDownload = (format: 'md' | 'txt' | 'json') => {
    let content = activeNotes;
    let mime = 'text/markdown';
    if (format === 'json') {
      content = JSON.stringify({ topic: topicTitle, notes: activeNotes, date: new Date().toISOString() }, null, 2);
      mime = 'application/json';
    } else if (format === 'txt') {
      content = activeNotes.replace(/#|\*|\$/g, '');
      mime = 'text/plain';
    }

    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${topicTitle.replace(/\s+/g, '_')}_notes.${format}`;
    a.click();
    URL.revokeObjectURL(url);
    showNotification?.(`Downloaded lecture notes as .${format}`, 'success');
  };

  // Quiz State
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [isQuizSubmitted, setIsQuizSubmitted] = useState<boolean>(false);

  const isPhysicsTopic = /physics|motion|force|optics|electric|magnetic|thermo/i.test(topicTitle);
  const isChemistryTopic = /chem|reaction|acid|base|organic|equilibrium|molar/i.test(topicTitle);

  const quizQuestions = useMemo(() => {
    if (isPhysicsTopic) {
      return [
        {
          id: 1,
          question: "What does the area under a force-displacement graph represent?",
          options: ["Acceleration", "Work Done", "Power", "Momentum"],
          correct: 1,
          explanation: "Work done is given by the integral of force over displacement: W = ∫ F dx."
        },
        {
          id: 2,
          question: "What is the escape velocity from the surface of the Earth?",
          options: ["9.8 m/s", "11.2 km/s", "3.0 x 10^8 m/s", "42 km/s"],
          correct: 1,
          explanation: "Escape velocity v_e = √(2gR) ≈ 11.2 km/s."
        },
        {
          id: 3,
          question: "Which law states that induced emf opposes the change producing it?",
          options: ["Coulomb's Law", "Lenz's Law", "Ampere's Law", "Hooke's Law"],
          correct: 1,
          explanation: "Lenz's Law ensures conservation of energy by opposing the flux change."
        },
        {
          id: 4,
          question: "In an adiabatic expansion of an ideal gas, what happens to temperature?",
          options: ["Increases", "Decreases", "Remains constant", "Drops to absolute zero"],
          correct: 1,
          explanation: "Work is done at the expense of internal energy (ΔU = -W), lowering the temperature."
        }
      ];
    }
    if (isChemistryTopic) {
      return [
        {
          id: 1,
          question: "What is the standard free energy change at dynamic chemical equilibrium?",
          options: ["ΔG = 0", "ΔG = 1", "ΔG = -RT", "ΔG = ∞"],
          correct: 0,
          explanation: "At equilibrium, forward and reverse rates balance, so ΔG = 0."
        },
        {
          id: 2,
          question: "According to Le Chatelier's principle, increasing pressure on gas equilibrium shifts toward:",
          options: ["Endothermic side", "Side with fewer moles of gas", "Side with more moles of gas", "Catalyst phase"],
          correct: 1,
          explanation: "Higher pressure favors the side occupying smaller volume (fewer moles of gas)."
        },
        {
          id: 3,
          question: "What is the oxidation state of Chromium in K2Cr2O7?",
          options: ["+3", "+6", "+4", "+7"],
          correct: 1,
          explanation: "2(+1) + 2(Cr) + 7(-2) = 0 => 2(Cr) = +12 => Cr = +6."
        },
        {
          id: 4,
          question: "What effect does adding a catalyst have on the equilibrium constant K?",
          options: ["Increases K", "Decreases K", "Leaves K unchanged", "Inverts K"],
          correct: 2,
          explanation: "A catalyst speeds up both forward and reverse rates equally, leaving equilibrium constant K unchanged."
        }
      ];
    }
    // Mathematics & Universal Analytical Science (Default)
    return [
      {
        id: 1,
        question: "What is the derivative of f(x) = x^n with respect to x?",
        options: ["n x^(n-1)", "x^(n+1) / (n+1)", "n! x", "(n-1) x^n"],
        correct: 0,
        explanation: "By the power rule of differential calculus, d/dx (x^n) = n x^(n-1)."
      },
      {
        id: 2,
        question: "What is the condition for two non-zero vectors u and v to be orthogonal?",
        options: ["u × v = 0", "u · v = 0", "|u| = |v|", "u + v = 0"],
        correct: 1,
        explanation: "Two vectors are perpendicular/orthogonal if and only if their scalar dot product equals zero."
      },
      {
        id: 3,
        question: "What is the value of the limit lim (x -> 0) [sin(x) / x] in radians?",
        options: ["0", "1", "π", "Undefined"],
        correct: 1,
        explanation: "The fundamental trigonometric limit lim (x -> 0) (sin x / x) = 1."
      },
      {
        id: 4,
        question: "At a local extremum of a differentiable function f(x), what is f'(x)?",
        options: ["f'(x) = 1", "f'(x) = 0", "f'(x) = ∞", "f'(x) = -1"],
        correct: 1,
        explanation: "Fermat's theorem on stationary points states that f'(c) = 0 at any local extremum."
      }
    ];
  }, [isPhysicsTopic, isChemistryTopic]);

  const quizScore = useMemo(() => {
    let score = 0;
    quizQuestions.forEach(q => {
      if (quizAnswers[q.id] === q.correct) score += 1;
    });
    return score;
  }, [quizAnswers, quizQuestions]);

  // Schedule Timeline Data
  const scheduleItems = useMemo(() => [
    { time: "09:00 AM", title: `${topicTitle} Axiomatic Foundations`, duration: "25 min", active: true, desc: "First principles derivation and core governing theorems." },
    { time: "09:30 AM", title: "Stepwise Proof & Intermediate Lemmas", duration: "20 min", active: false, desc: "Rigorous algebraic transformations and boundary behavior." },
    { time: "10:00 AM", title: "Quantitative Problem-Solving Lab", duration: "15 min", active: false, desc: "Step-by-step numerical drills and examiner trap analysis." },
    { time: "10:20 AM", title: "Interactive Coordinate Visualization & Q&A", duration: "15 min", active: false, desc: "Multi-dimensional visual projection and student concept mastery." }
  ], [topicTitle]);

  // Curated Reference Links
  const referenceLinks = [
    { title: "ArXiv Mathematical Sciences & Applied Physics Vault", category: "Research Paper", url: "https://arxiv.org", desc: "Peer-reviewed preprints and foundational mathematical proofs." },
    { title: "PhET Interactive Mathematics & Science Simulations", category: "Lab Tool", url: "https://phet.colorado.edu", desc: "Hands-on virtual simulations for functions, vectors, and dynamics." },
    { title: "MIT OpenCourseWare: Mathematical Methods", category: "Lecture Video", url: "https://ocw.mit.edu", desc: "Rigorous academic lectures and structured problem sets." },
    { title: "Wolfram MathWorld & Computational Knowledge", category: "Reference Engine", url: "https://mathworld.wolfram.com", desc: "Comprehensive mathematical encyclopedia with verified equations." }
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div 
        id="laptop-view-modal-backdrop"
        className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-10 bg-slate-950/80 backdrop-blur-xl"
        onClick={onClose}
      >
        {/* Laptop Outer Frame with Spring Physics */}
        <motion.div
          id="laptop-hardware-chassis"
          initial={{ scale: 0.85, opacity: 0, y: 40, rotateX: 15 }}
          animate={{ 
            scale: 1, 
            opacity: 1, 
            y: 0, 
            rotateX: 0,
            transition: { type: 'spring', stiffness: 150, damping: 14, mass: 1 }
          }}
          exit={{ scale: 0.85, opacity: 0, y: 30, rotateX: 10 }}
          onClick={(e) => e.stopPropagation()}
          className={cn(
            "relative w-full max-w-5xl h-[88vh] max-h-[820px] rounded-3xl bg-slate-900 border-2 border-slate-700/80 shadow-[0_25px_70px_rgba(0,0,0,0.8),0_0_50px_rgba(56,189,248,0.15)] flex flex-col overflow-hidden transition-all",
            isSleeping && "opacity-40 brightness-50"
          )}
        >
          {/* Subtle Screen Reflection & Ambient Occlusion Sheen */}
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-transparent via-white/[0.02] to-sky-400/[0.04] z-30 rounded-3xl" />

          {/* Sleep Mode Overlay */}
          {isSleeping && (
            <div 
              onClick={resetSleepTimer}
              className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-slate-950/85 backdrop-blur-md text-slate-300 cursor-pointer"
            >
              <Sparkles className="w-10 h-10 text-sky-400 animate-pulse mb-3" />
              <p className="text-base font-semibold">Professor Slate is in Power Saving Mode</p>
              <p className="text-xs text-slate-400 mt-1">Click anywhere or press any key to wake</p>
            </div>
          )}

          {/* Laptop Hardware Header Bar */}
          <div className="relative flex items-center justify-between px-6 py-3.5 bg-slate-950 border-b border-slate-800/80 select-none z-20">
            {/* Window Controls / Branding */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <button onClick={onClose} className="w-3.5 h-3.5 rounded-full bg-rose-500 hover:bg-rose-600 transition-colors shadow-sm" title="Close (Esc)" />
                <button onClick={() => setIsSleeping(true)} className="w-3.5 h-3.5 rounded-full bg-amber-500 hover:bg-amber-600 transition-colors shadow-sm" title="Sleep" />
                <button onClick={() => showNotification?.('Classroom Slate in High-Definition Fullscreen', 'info')} className="w-3.5 h-3.5 rounded-full bg-emerald-500 hover:bg-emerald-600 transition-colors shadow-sm" title="Fullscreen" />
              </div>
              <div className="h-4 w-px bg-slate-800 ml-1" />
              <div className="flex items-center gap-2 text-slate-300 font-semibold text-xs tracking-wide">
                <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                <span>Classroom Slate OS</span>
                <span className="text-slate-500 font-mono text-[11px]">• Professor Clarity Workstation</span>
              </div>
            </div>

            {/* Global Actions (Search & Close) */}
            <div className="flex items-center gap-3">
              <div className="relative flex items-center">
                <Search className="w-4 h-4 absolute left-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search notes, formulas..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-44 focus:w-64 pl-9 pr-3 py-1 text-xs rounded-full bg-slate-900 border border-slate-700 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-all font-medium"
                />
              </div>

              <button
                onClick={() => setIsBookmarked(!isBookmarked)}
                className={cn(
                  "p-1.5 rounded-lg border transition-colors",
                  isBookmarked 
                    ? "bg-amber-500/20 border-amber-500 text-amber-300" 
                    : "bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200"
                )}
                title={isBookmarked ? "Bookmarked" : "Bookmark Lesson"}
              >
                <Bookmark className="w-4 h-4" />
              </button>

              <button
                onClick={onClose}
                className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-400 hover:text-white transition-colors"
                title="Close Window (Esc)"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Navigation Tab Strip (5 Interactive Tabs) */}
          <div className="flex items-center px-6 bg-slate-950/60 border-b border-slate-800/80 gap-2 select-none z-20 overflow-x-auto py-1">
            {[
              { id: 'notes', label: 'Lecture Notes', icon: FileText, num: '1' },
              { id: 'schedule', label: 'Class Schedule', icon: Calendar, num: '2' },
              { id: 'links', label: 'Curated Links', icon: LinkIcon, num: '3' },
              { id: 'quiz', label: 'Interactive Quiz', icon: HelpCircle, num: '4' },
              { id: 'stats', label: 'Learning Stats', icon: BarChart2, num: '5' }
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all relative",
                    isActive
                      ? "text-sky-400 bg-sky-500/10 border border-sky-500/30 shadow-inner"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  <span className="text-[10px] font-mono px-1 rounded bg-slate-800/80 text-slate-400 border border-slate-700/60 ml-0.5">
                    {tab.num}
                  </span>
                  {isActive && (
                    <motion.div
                      layoutId="activeTabGlow"
                      className="absolute bottom-0 left-3 right-3 h-0.5 bg-sky-400 rounded-full shadow-[0_0_8px_#38bdf8]"
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Main Content Viewport */}
          <div className="flex-1 overflow-y-auto p-6 sm:p-8 bg-slate-900/90 text-slate-200 custom-scrollbar z-10">
            {/* TAB 1: LECTURE NOTES */}
            {activeTab === 'notes' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="max-w-4xl mx-auto space-y-6"
              >
                {/* Notes Toolbar */}
                <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-slate-950/70 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-sky-400" />
                    <div>
                      <h3 className="text-sm font-bold text-slate-100">{topicTitle}</h3>
                      <p className="text-xs text-slate-400">Classroom Slate Digital Textbook & Notes</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopyNotes}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                      <span>{isCopied ? 'Copied' : 'Copy'}</span>
                    </button>

                    <div className="flex items-center rounded-lg bg-slate-800 border border-slate-700 p-0.5">
                      <button
                        onClick={() => handleDownload('md')}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
                        title="Download Markdown"
                      >
                        .MD
                      </button>
                      <button
                        onClick={() => handleDownload('txt')}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
                        title="Download Text"
                      >
                        .TXT
                      </button>
                      <button
                        onClick={() => handleDownload('json')}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
                        title="Download JSON"
                      >
                        .JSON
                      </button>
                    </div>
                  </div>
                </div>

                {/* Markdown Rendered Content */}
                <div className="prose prose-invert prose-sky max-w-none bg-slate-950/40 p-6 rounded-2xl border border-slate-800/80 leading-relaxed font-sans">
                  <ReactMarkdown
                    remarkPlugins={[remarkMath]}
                    rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
                  >
                    {filteredNotes}
                  </ReactMarkdown>
                </div>
              </motion.div>
            )}

            {/* TAB 2: CLASS SCHEDULE */}
            {activeTab === 'schedule' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="max-w-3xl mx-auto space-y-6"
              >
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div>
                    <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-amber-400" />
                      Classroom Slate Master Schedule
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">Synchronized lecture modules and hands-on laboratory phases</p>
                  </div>
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    Lecture in Progress
                  </span>
                </div>

                <div className="space-y-3">
                  {scheduleItems.map((item, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        "flex items-start gap-4 p-4 rounded-2xl border transition-all",
                        item.active
                          ? "bg-sky-500/10 border-sky-500/40 shadow-lg"
                          : "bg-slate-950/50 border-slate-800 hover:border-slate-700"
                      )}
                    >
                      <div className="flex flex-col items-center justify-center w-20 px-2 py-2 rounded-xl bg-slate-900 border border-slate-800 text-center">
                        <Clock className="w-4 h-4 text-sky-400 mb-1" />
                        <span className="text-xs font-bold text-slate-200">{item.time}</span>
                        <span className="text-[10px] text-slate-500 font-medium">{item.duration}</span>
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-slate-100">{item.title}</h4>
                          {item.active && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500 text-slate-950 uppercase">
                              Current
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{item.desc}</p>
                      </div>

                      <button
                        onClick={() => {
                          onSelectTopic?.(item.title);
                          showNotification?.(`Loaded topic: ${item.title}`, 'info');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-sky-600 hover:text-white text-xs font-semibold text-slate-300 border border-slate-700 transition-colors"
                      >
                        Load
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* TAB 3: CURATED REFERENCE LINKS */}
            {activeTab === 'links' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="max-w-3xl mx-auto space-y-6"
              >
                <div className="pb-4 border-b border-slate-800">
                  <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                    <LinkIcon className="w-5 h-5 text-purple-400" />
                    Curated Scientific References & Lab Simulations
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">Authoritative academic journals, virtual labs, and open datasets</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {referenceLinks.map((link, idx) => (
                    <a
                      key={idx}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex flex-col justify-between p-4 rounded-2xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-purple-500/40 transition-all group"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 px-2 py-0.5 rounded bg-purple-500/10 border border-purple-500/20">
                            {link.category}
                          </span>
                          <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-purple-400 transition-colors" />
                        </div>
                        <h4 className="text-sm font-bold text-slate-200 group-hover:text-purple-300 transition-colors mt-2.5">
                          {link.title}
                        </h4>
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          {link.desc}
                        </p>
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 mt-3 pt-2 border-t border-slate-900 truncate">
                        {link.url}
                      </div>
                    </a>
                  ))}
                </div>
              </motion.div>
            )}

            {/* TAB 4: INTERACTIVE PRACTICE QUIZ */}
            {activeTab === 'quiz' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="max-w-3xl mx-auto space-y-6"
              >
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div>
                    <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                      <HelpCircle className="w-5 h-5 text-emerald-400" />
                      Classroom Practice & Mastery Check
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">Test your understanding of {topicTitle} with instant evaluation</p>
                  </div>

                  {isQuizSubmitted && (
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
                      <Award className="w-4 h-4" />
                      <span>Score: {quizScore} / {quizQuestions.length} ({Math.round((quizScore / quizQuestions.length) * 100)}%)</span>
                    </div>
                  )}
                </div>

                <div className="space-y-6">
                  {quizQuestions.map((q, qIndex) => {
                    const selected = quizAnswers[q.id];
                    const isCorrect = selected === q.correct;
                    return (
                      <div key={q.id} className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                        <h4 className="text-sm font-bold text-slate-100 flex items-start gap-2">
                          <span className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-mono text-sky-400 shrink-0">
                            {qIndex + 1}
                          </span>
                          <span>{q.question}</span>
                        </h4>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                          {q.options.map((opt, optIdx) => {
                            const isOptionSelected = selected === optIdx;
                            let btnStyle = "bg-slate-900/80 hover:bg-slate-800 border-slate-700/80 text-slate-300";
                            
                            if (isQuizSubmitted) {
                              if (optIdx === q.correct) {
                                btnStyle = "bg-emerald-500/20 border-emerald-500 text-emerald-200 font-semibold";
                              } else if (isOptionSelected && !isCorrect) {
                                btnStyle = "bg-rose-500/20 border-rose-500 text-rose-200";
                              }
                            } else if (isOptionSelected) {
                              btnStyle = "bg-sky-500/20 border-sky-500 text-sky-200 font-semibold shadow-inner";
                            }

                            return (
                              <button
                                key={optIdx}
                                disabled={isQuizSubmitted}
                                onClick={() => setQuizAnswers(prev => ({ ...prev, [q.id]: optIdx }))}
                                className={cn(
                                  "flex items-center justify-between px-4 py-2.5 rounded-xl border text-xs text-left transition-all",
                                  btnStyle
                                )}
                              >
                                <span>{opt}</span>
                                {isQuizSubmitted && optIdx === q.correct && (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 ml-2" />
                                )}
                                {isQuizSubmitted && isOptionSelected && !isCorrect && (
                                  <XCircle className="w-4 h-4 text-rose-400 shrink-0 ml-2" />
                                )}
                              </button>
                            );
                          })}
                        </div>

                        {/* Explanation on submit */}
                        {isQuizSubmitted && (
                          <div className={cn(
                            "p-3 rounded-xl border text-xs leading-relaxed mt-2",
                            isCorrect ? "bg-emerald-950/30 border-emerald-800/60 text-emerald-300" : "bg-rose-950/30 border-rose-800/60 text-rose-300"
                          )}>
                            <span className="font-bold">{isCorrect ? 'Correct!' : 'Incorrect.'}</span> {q.explanation}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Quiz Bottom Actions */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                  <button
                    onClick={() => {
                      setQuizAnswers({});
                      setIsQuizSubmitted(false);
                    }}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-300 transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Reset Quiz</span>
                  </button>

                  <button
                    onClick={() => {
                      if (Object.keys(quizAnswers).length < quizQuestions.length) {
                        showNotification?.('Please answer all quiz questions before submitting.', 'warning');
                        return;
                      }
                      setIsQuizSubmitted(true);
                      showNotification?.(`Quiz submitted! You scored ${quizScore}/${quizQuestions.length}`, 'success');
                    }}
                    className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs shadow-lg shadow-sky-500/20 transition-all"
                  >
                    <Check className="w-4 h-4" />
                    <span>{isQuizSubmitted ? 'Re-Submit' : 'Submit Answers'}</span>
                  </button>
                </div>
              </motion.div>
            )}

            {/* TAB 5: LEARNING PROGRESS & STATS */}
            {activeTab === 'stats' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="max-w-3xl mx-auto space-y-6"
              >
                <div className="pb-4 border-b border-slate-800">
                  <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                    <BarChart2 className="w-5 h-5 text-sky-400" />
                    Student Engagement & Lecture Mastery
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">Real-time learning telemetry and concept mastery index</p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {[
                    { label: "Mastery Index", val: "94%", icon: Target, color: "text-sky-400" },
                    { label: "Active Streak", val: "5 Days", icon: Flame, color: "text-amber-400" },
                    { label: "Points Earned", val: "380 XP", icon: Star, color: "text-emerald-400" },
                    { label: "Concepts Covered", val: "12 / 14", icon: GraduationCap, color: "text-purple-400" }
                  ].map((stat, i) => {
                    const StatIcon = stat.icon;
                    return (
                      <div key={i} className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 text-center space-y-1">
                        <StatIcon className={cn("w-5 h-5 mx-auto mb-1", stat.color)} />
                        <span className="text-lg font-bold text-slate-100">{stat.val}</span>
                        <p className="text-[11px] text-slate-400 font-medium">{stat.label}</p>
                      </div>
                    );
                  })}
                </div>

                <div className="p-5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Topic Breakdown & Retention
                  </h4>

                  {[
                    { topic: "Light Reactions & Electron Transport", pct: 95, color: "bg-sky-400" },
                    { topic: "Calvin-Benson Carbon Fixation", pct: 88, color: "bg-emerald-400" },
                    { topic: "Stoichiometry & Molar Yields", pct: 92, color: "bg-purple-400" },
                    { topic: "Chloroplast Molecular Structure", pct: 85, color: "bg-amber-400" }
                  ].map((bar, idx) => (
                    <div key={idx} className="space-y-1.5">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="text-slate-300">{bar.topic}</span>
                        <span className="font-mono text-slate-400">{bar.pct}%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden border border-slate-800">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${bar.pct}%` }}
                          transition={{ duration: 0.6, delay: idx * 0.1 }}
                          className={cn("h-full rounded-full", bar.color)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Laptop Keyboard & Trackpad Base Illumination Deck */}
          <div className="px-6 py-2.5 bg-slate-950 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-500 font-mono select-none z-20">
            <div className="flex items-center gap-4">
              <span>PROXIMITY: <strong className="text-sky-400">SYNCED</strong></span>
              <span>SCREEN: <strong className="text-slate-300">PBR RETINA GLOW</strong></span>
              <span>AUDIO: <strong className="text-emerald-400">TYPEWRITER ACTIVE</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-slate-400">Classroom Slate 60 FPS</span>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
