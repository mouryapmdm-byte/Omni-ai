const fs = require('fs');
const file = 'src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

const oldBlock = `      let imageUrl: string | undefined;
      let videoUrl: string | undefined;
      let annotations: any[] = [];
      const imageRequestMatch = response.match(/<DRAW_IMAGE>(.*?)</\\/DRAW_IMAGE>/is);
      if (imageRequestMatch) {
        const prompt = imageRequestMatch[1].trim();
        imageUrl = await handleGenerateMedia(prompt, 'image');
        finalContent = finalContent.replace(/<DRAW_IMAGE>.*?<\\/DRAW_IMAGE>/is, "").trim();
        const annotationMatch = response.match(/<ANNOTATIONS>(.*?)<\\/ANNOTATIONS>/s);
        if (annotationMatch) {
          try {
            annotations = JSON.parse(annotationMatch[1]);
          } catch (e) {
            console.error("Failed to parse annotations", e);
          }
        }
        finalContent = finalContent.replace(/<ANNOTATIONS>.*?<\\/ANNOTATIONS>/s, "").trim();
      }`;

const newBlock = `      let imageUrl: string | undefined;
      let videoUrl: string | undefined;
      let annotations: any[] = [];
      let mathGraphFunctions: string[] | undefined;
      const imageRequestMatch = response.match(/<DRAW_IMAGE>(.*?)<\\/DRAW_IMAGE>/is);
      if (imageRequestMatch) {
        const prompt = imageRequestMatch[1].trim();
        
        const isGraph = prompt.toLowerCase().includes('graph') || prompt.toLowerCase().includes('plot');
        const funcMatches = [...prompt.matchAll(/(?:f\\(x\\)|g\\(x\\)|h\\(x\\)|y)\\s*=\\s*([a-zA-Z0-9_\\-\\+\\*\\/\\^\\(\\)\\.\\s]+?)(?:\\s+and|\\s+on|\\s+with|$)/gi)].map(m => m[1].trim());
        
        if (isGraph && funcMatches.length > 0) {
            mathGraphFunctions = funcMatches;
        } else if (isGraph) {
            const possible = prompt.match(/Graph of\\s+([a-zA-Z0-9_\\-\\+\\*\\/\\^\\(\\)\\.\\s]+?)\\s+(?:and|with|on)/i);
            if (possible && possible[1]) {
                mathGraphFunctions = [possible[1].trim()];
            }
        }
        
        if (mathGraphFunctions && mathGraphFunctions.length > 0) {
            // It's a math graph, do not generate an image
        } else {
            imageUrl = await handleGenerateMedia(prompt, 'image');
        }
        
        finalContent = finalContent.replace(/<DRAW_IMAGE>.*?<\\/DRAW_IMAGE>/is, "").trim();
        const annotationMatch = response.match(/<ANNOTATIONS>(.*?)<\\/ANNOTATIONS>/s);
        if (annotationMatch) {
          try {
            annotations = JSON.parse(annotationMatch[1]);
          } catch (e) {
            console.error("Failed to parse annotations", e);
          }
        }
        finalContent = finalContent.replace(/<ANNOTATIONS>.*?<\\/ANNOTATIONS>/s, "").trim();
      }`;

content = content.replace(oldBlock.replace(/<\//g, '</'), newBlock);
fs.writeFileSync(file, content);
console.log("Patched App.tsx block");
