// Web Audio API Synthesizer for Authentic Chalkboard Sound Effects
// Generates realistic scratching, tapping, dusting, and lecture sound sequences

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export type ChalkSoundType = 'scratch' | 'tap' | 'dust' | 'sequence' | 'thud' | 'equation';

export function isChalkSoundEnabled(): boolean {
  if (typeof localStorage === 'undefined') return true;
  return localStorage.getItem('omni_chalkboard_sound') !== 'false';
}

export function setChalkSoundEnabled(enabled: boolean): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('omni_chalkboard_sound', enabled ? 'true' : 'false');
  }
}

export function isEquationChalkSoundEnabled(): boolean {
  if (typeof localStorage === 'undefined') return true;
  return localStorage.getItem('omni_equation_chalk_sound') !== 'false';
}

export function setEquationChalkSoundEnabled(enabled: boolean): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('omni_equation_chalk_sound', enabled ? 'true' : 'false');
  }
}

export function isDiagramThudEnabled(): boolean {
  if (typeof localStorage === 'undefined') return true;
  return localStorage.getItem('omni_diagram_thud_sound') !== 'false';
}

export function setDiagramThudEnabled(enabled: boolean): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('omni_diagram_thud_sound', enabled ? 'true' : 'false');
  }
}

export function isKeyboardClickSoundEnabled(): boolean {
  if (typeof localStorage === 'undefined') return true;
  return localStorage.getItem('omni_keyboard_sound') !== 'false';
}

export function setKeyboardClickSoundEnabled(enabled: boolean): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('omni_keyboard_sound', enabled ? 'true' : 'false');
  }
}

/**
 * Feature 4: Keyboard Click Sounds (Optional Audio)
 * Synthesizes soft, realistic mechanical/tactile laptop keyboard clicks synchronized with typing
 */
export function playKeyboardClick(customVolume: number = 0.18) {
  if (!isKeyboardClickSoundEnabled()) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    // Slight randomized variation for realistic acoustic variety
    const volumeVar = customVolume * (0.85 + Math.random() * 0.3);
    masterGain.gain.setValueAtTime(volumeVar, now);
    masterGain.connect(ctx.destination);

    // 1. High-frequency tactile switch click (transient)
    const clickFreq = 1800 + Math.random() * 1200;
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(clickFreq, now);
    osc.frequency.exponentialRampToValueAtTime(350, now + 0.025);

    oscGain.gain.setValueAtTime(0.4, now);
    oscGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);

    osc.connect(oscGain);
    oscGain.connect(masterGain);
    osc.start(now);
    osc.stop(now + 0.025);

    // 2. Tactile keycap bottom-out thud
    const bufferSize = Math.floor(ctx.sampleRate * 0.02);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.3));
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(850 + Math.random() * 400, now);
    filter.Q.setValueAtTime(3.5, now);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.5, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.02);

    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(masterGain);
    noise.start(now);
    noise.stop(now + 0.02);
  } catch (err) {
    // Graceful fallback
  }
}

/**
 * Play a soft 'thud' sound when a diagram or slate card is placed on the blackboard slate.
 * Synthesizes a damped wood/slate impact transient with warm low-frequency body resonance.
 */
export function playDiagramThud(customVolume: number = 0.28) {
  if (!isChalkSoundEnabled() || !isDiagramThudEnabled()) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(customVolume, now);
    masterGain.connect(ctx.destination);

    // 1. Low body thud oscillator (slate resonance)
    const bodyOsc = ctx.createOscillator();
    const bodyGain = ctx.createGain();
    bodyOsc.type = 'triangle';
    bodyOsc.frequency.setValueAtTime(115, now);
    bodyOsc.frequency.exponentialRampToValueAtTime(42, now + 0.14);

    bodyGain.gain.setValueAtTime(0.7, now);
    bodyGain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    bodyOsc.connect(bodyGain);
    bodyGain.connect(masterGain);
    bodyOsc.start(now);
    bodyOsc.stop(now + 0.16);

    // 2. High contact transient (felt / wood frame tap)
    const bufferSize = Math.floor(ctx.sampleRate * 0.04);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.25));
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(650, now);

    const clickGain = ctx.createGain();
    clickGain.gain.setValueAtTime(0.5, now);
    clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    noise.connect(filter);
    filter.connect(clickGain);
    clickGain.connect(masterGain);

    noise.start(now);
    noise.stop(now + 0.04);
  } catch (err) {
    console.warn("Could not play diagram slate thud sound:", err);
  }
}

/**
 * Play real-time chalk scratching sounds that pitch-shift dynamically based on the length/complexity of drawn equations.
 * Short equations produce higher, crisper scratching; long complex multi-variable equations produce deeper, resonant sweeping strokes.
 */
export function playEquationChalkScratch(equationLength: number = 20, customVolume: number = 0.25) {
  if (!isChalkSoundEnabled() || !isEquationChalkSoundEnabled()) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(customVolume, now);
    masterGain.connect(ctx.destination);

    // Calculate pitch shift factor based on equation length:
    // length <= 10: ~3200Hz (high/sharp)
    // length 40: ~2100Hz (standard)
    // length 120+: ~1100Hz (deep, resonant, grand derivation)
    const clampedLength = Math.max(5, Math.min(180, equationLength));
    const lengthRatio = (clampedLength - 5) / 175; // 0 (short) to 1 (long)

    // Base center frequency: from 3300 Hz down to 1050 Hz
    const baseFreq = 3300 - lengthRatio * 2250;
    const duration = Math.min(0.38, 0.12 + lengthRatio * 0.22);

    const bufferSize = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      const progress = i / bufferSize;
      const envelope = Math.sin(progress * Math.PI);
      data[i] = (Math.random() * 2 - 1) * envelope;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const bandpass = ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.setValueAtTime(baseFreq + (Math.random() * 200 - 100), now);
    // Dynamic pitch modulation during the stroke: longer equations sweep down subtly
    bandpass.frequency.linearRampToValueAtTime(baseFreq * (0.88 + Math.random() * 0.1), now + duration);
    bandpass.Q.setValueAtTime(4.5 + (1 - lengthRatio) * 3, now);

    const scratchGain = ctx.createGain();
    scratchGain.gain.setValueAtTime(0.001, now);
    scratchGain.gain.linearRampToValueAtTime(0.55, now + 0.02);
    scratchGain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    noise.connect(bandpass);
    bandpass.connect(scratchGain);
    scratchGain.connect(masterGain);

    // For longer equations, add a soft underlying acoustic chalk-stick friction resonance
    if (clampedLength > 30) {
      const frictionOsc = ctx.createOscillator();
      const frictionGain = ctx.createGain();
      frictionOsc.type = 'triangle';
      frictionOsc.frequency.setValueAtTime(baseFreq * 0.4, now);
      frictionOsc.frequency.linearRampToValueAtTime(baseFreq * 0.35, now + duration);

      frictionGain.gain.setValueAtTime(0.001, now);
      frictionGain.gain.linearRampToValueAtTime(0.12, now + 0.03);
      frictionGain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      frictionOsc.connect(frictionGain);
      frictionGain.connect(masterGain);
      frictionOsc.start(now);
      frictionOsc.stop(now + duration);
    }

    noise.start(now);
    noise.stop(now + duration);
  } catch (err) {
    console.warn("Could not play equation pitch-shifted chalk scratch:", err);
  }
}

/**
 * Play a light chalk stick tap when switching colors on the palette.
 */
export function playChalkColorSwitchSound(colorOrVolume?: string | number, customVolume: number = 0.22) {
  if (!isChalkSoundEnabled()) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const finalVolume = typeof colorOrVolume === 'number' ? colorOrVolume : customVolume;

  try {
    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(finalVolume, now);
    masterGain.connect(ctx.destination);

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    
    // Pitch shift slightly based on chalk color for distinct tactile feedback
    let baseFreq = 1400;
    if (typeof colorOrVolume === 'string') {
      if (colorOrVolume === 'yellow') baseFreq = 1600;
      else if (colorOrVolume === 'red') baseFreq = 1200;
      else if (colorOrVolume === 'blue') baseFreq = 1800;
      else baseFreq = 1400;
    }
    
    osc.frequency.setValueAtTime(baseFreq + Math.random() * 150, now);
    osc.frequency.exponentialRampToValueAtTime(350, now + 0.035);

    gain.gain.setValueAtTime(0.6, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(now);
    osc.stop(now + 0.04);
  } catch (err) {
    console.warn("Could not play chalk color switch sound:", err);
  }
}

/**
 * Play an authentic chalkboard sound effect (scratching, tapping, dusting, or sequence)
 */
export function playChalkSound(type: ChalkSoundType = 'scratch', customVolume: number = 0.3) {
  if (!isChalkSoundEnabled()) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;
    const mainGain = ctx.createGain();
    mainGain.gain.setValueAtTime(customVolume, now);
    mainGain.connect(ctx.destination);

    if (type === 'tap') {
      // Chalk tap: crisp resonant impulse
      const osc = ctx.createOscillator();
      const tapGain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1600 + Math.random() * 400, now);
      filter.Q.setValueAtTime(8, now);

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(800 + Math.random() * 300, now);
      osc.frequency.exponentialRampToValueAtTime(120, now + 0.04);

      tapGain.gain.setValueAtTime(0.8, now);
      tapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      osc.connect(filter);
      filter.connect(tapGain);
      tapGain.connect(mainGain);

      osc.start(now);
      osc.stop(now + 0.05);
    } else if (type === 'scratch') {
      // Chalk scratch: filtered noise with frequency modulation
      const bufferSize = ctx.sampleRate * 0.2; // 200ms
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / bufferSize, 0.5);
      }

      const noise = ctx.createBufferSource();
      noise.buffer = buffer;

      const bandpass = ctx.createBiquadFilter();
      bandpass.type = 'bandpass';
      bandpass.frequency.setValueAtTime(2200 + Math.random() * 600, now);
      bandpass.Q.setValueAtTime(3 + Math.random() * 2, now);

      const scratchGain = ctx.createGain();
      scratchGain.gain.setValueAtTime(0.01, now);
      scratchGain.gain.linearRampToValueAtTime(0.5, now + 0.03);
      scratchGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      noise.connect(bandpass);
      bandpass.connect(scratchGain);
      scratchGain.connect(mainGain);

      noise.start(now);
      noise.stop(now + 0.2);
    } else if (type === 'dust') {
      // Chalk eraser dusting: low-pass pink noise sweep
      const duration = 0.5;
      const bufferSize = ctx.sampleRate * duration;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        data[i] = (b0 + b1 + b2) * 0.15;
      }

      const noise = ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, now);
      filter.frequency.exponentialRampToValueAtTime(300, now + duration);

      const dustGain = ctx.createGain();
      dustGain.gain.setValueAtTime(0.01, now);
      dustGain.gain.linearRampToValueAtTime(0.4, now + 0.1);
      dustGain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      noise.connect(filter);
      filter.connect(dustGain);
      dustGain.connect(mainGain);

      noise.start(now);
      noise.stop(now + duration);
    } else if (type === 'sequence') {
      // Realistic classroom sequence: Dust sweep -> Chalk tap -> Chalk scratch writing
      playChalkSound('dust', customVolume * 0.7);
      setTimeout(() => playChalkSound('tap', customVolume * 0.9), 280);
      setTimeout(() => playChalkSound('scratch', customVolume), 420);
      setTimeout(() => playChalkSound('scratch', customVolume * 0.8), 600);
      setTimeout(() => playChalkSound('tap', customVolume * 0.9), 780);
    }
  } catch (err) {
    console.warn("Could not play chalk sound effect:", err);
  }
}

/**
 * Play a crystal-clear, harmonic auditory feedback cue when the virtual lesson environment is initializing.
 * Synthesizes an ascending harmonic chime triad (C5 -> E5 -> G5 -> C6) with warm acoustic resonance.
 */
export function playLessonInitializingCue(customVolume: number = 0.35) {
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(customVolume, now);
    masterGain.connect(ctx.destination);

    // Warm sub foundation tone (C4 - 261.63 Hz)
    const subOsc = ctx.createOscillator();
    const subGain = ctx.createGain();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(261.63, now);
    subGain.gain.setValueAtTime(0.01, now);
    subGain.gain.linearRampToValueAtTime(0.3, now + 0.05);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
    subOsc.connect(subGain);
    subGain.connect(masterGain);
    subOsc.start(now);
    subOsc.stop(now + 0.65);

    // Ascending chime notes: C5 (523Hz), E5 (659Hz), G5 (784Hz), C6 (1046.5Hz)
    const notes = [
      { freq: 523.25, time: 0, duration: 0.55, gain: 0.45 },
      { freq: 659.25, time: 0.08, duration: 0.55, gain: 0.5 },
      { freq: 783.99, time: 0.16, duration: 0.6, gain: 0.55 },
      { freq: 1046.50, time: 0.24, duration: 0.8, gain: 0.6 }
    ];

    notes.forEach(note => {
      const noteStart = now + note.time;
      const osc = ctx.createOscillator();
      const noteGain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(note.freq, noteStart);

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(note.freq * 1.5, noteStart);
      filter.Q.setValueAtTime(4, noteStart);

      // Attack & decay envelope
      noteGain.gain.setValueAtTime(0.001, noteStart);
      noteGain.gain.linearRampToValueAtTime(note.gain, noteStart + 0.02);
      noteGain.gain.exponentialRampToValueAtTime(0.0001, noteStart + note.duration);

      osc.connect(filter);
      filter.connect(noteGain);
      noteGain.connect(masterGain);

      // Shimmer secondary harmonic (triangle wave for crystalline brightness)
      const shimmerOsc = ctx.createOscillator();
      const shimmerGain = ctx.createGain();
      shimmerOsc.type = 'triangle';
      shimmerOsc.frequency.setValueAtTime(note.freq * 2, noteStart);
      shimmerGain.gain.setValueAtTime(0.001, noteStart);
      shimmerGain.gain.linearRampToValueAtTime(note.gain * 0.25, noteStart + 0.015);
      shimmerGain.gain.exponentialRampToValueAtTime(0.0001, noteStart + (note.duration * 0.6));

      shimmerOsc.connect(shimmerGain);
      shimmerGain.connect(masterGain);

      osc.start(noteStart);
      osc.stop(noteStart + note.duration);
      shimmerOsc.start(noteStart);
      shimmerOsc.stop(noteStart + (note.duration * 0.6));
    });

    // Subtle chalk dust tactile sweep at start
    setTimeout(() => {
      playChalkSound('tap', customVolume * 0.6);
    }, 40);
  } catch (err) {
    console.warn("Could not play lesson initializing cue:", err);
  }
}

