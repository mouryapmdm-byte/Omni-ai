import React, { useState } from 'react';
import { X, BookOpen, Layers, Link2, Check, ExternalLink } from 'lucide-react';
import { ChaptersExplorer } from '../ChaptersExplorer';
import { SavedNote } from '../../types';

export interface ClassroomSyllabusModalProps {
  isOpen: boolean;
  onClose: () => void;
  subject: string;
  topic?: string;
  currentTopic?: string;
  difficulty: string;
  setTopic?: (topic: string) => void;
  onSelectTopic?: (topic: string) => void;
  onSelectSubject?: (subject: string) => void;
  selectedBoard?: {
    nation: string;
    acronym: string;
  } | null;
  onStudyLesson?: (lessonTitle: string, chapterTitle: string, depth?: 'quick' | 'standard' | 'deep' | 'academic') => void;
  onGenerateQuiz?: (chapterTitle: string) => void;
  savedNotes?: SavedNote[];
  onDeleteNote?: (id: string) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  theme?: 'light' | 'dark';
}

export const ClassroomSyllabusModal: React.FC<ClassroomSyllabusModalProps> = ({
  isOpen,
  onClose,
  subject,
  topic,
  currentTopic,
  difficulty,
  setTopic,
  onSelectTopic,
  onSelectSubject,
  selectedBoard,
  onStudyLesson,
  onGenerateQuiz,
  savedNotes = [],
  onDeleteNote = () => {},
  showNotification,
  theme = 'dark'
}) => {
  if (!isOpen) return null;

  const resolvedTopic = topic || currentTopic || 'Electric Charges and Fields';
  const [copiedLink, setCopiedLink] = useState(false);

  const handleGenerateDeepLink = () => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('mode', '3d');
      url.searchParams.set('topic', resolvedTopic);
      if (subject) url.searchParams.set('subject', subject);
      if (difficulty) url.searchParams.set('difficulty', difficulty);
      if (selectedBoard?.acronym) url.searchParams.set('board', selectedBoard.acronym);
      const deepLinkUrl = url.toString();

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(deepLinkUrl).then(() => {
          setCopiedLink(true);
          showNotification?.(`Deep link copied to clipboard: "${resolvedTopic}"`, 'success');
          setTimeout(() => setCopiedLink(false), 2500);
        }).catch(() => {
          showNotification?.(`Generated deep link: ${deepLinkUrl}`, 'info');
        });
      } else {
        showNotification?.(`Generated deep link: ${deepLinkUrl}`, 'info');
      }
    } catch (e) {
      console.warn('Error generating deep link:', e);
    }
  };

  const handleSetTopic = (newTopic: string) => {
    if (setTopic) setTopic(newTopic);
    if (onSelectTopic) onSelectTopic(newTopic);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-6xl h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-3 sm:p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80 shrink-0 gap-2 flex-wrap">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 shrink-0">
              <Layers size={22} />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-black text-white flex items-center gap-2 flex-wrap">
                <span>Complete Syllabus & Chapter Explorer</span>
                {selectedBoard?.acronym && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                    {selectedBoard.acronym}
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-slate-400 truncate">
                Browse detailed units, weightage, and click "Study Lesson" to project directly onto the 3D Smartboard
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Deep Link to Current Lesson */}
            <button
              onClick={handleGenerateDeepLink}
              className="h-8 px-3 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              title={`Generate and copy deep link to "${resolvedTopic}" in Virtual 3D`}
            >
              {copiedLink ? (
                <>
                  <Check size={14} className="text-emerald-400" />
                  <span className="text-emerald-300 font-bold">Copied Deep Link!</span>
                </>
              ) : (
                <>
                  <Link2 size={14} className="text-indigo-400" />
                  <span className="hidden sm:inline">Deep Link:</span>
                  <span className="max-w-[120px] md:max-w-[180px] truncate text-white">{resolvedTopic}</span>
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Close"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Embedded ChaptersExplorer */}
        <div className="flex-1 overflow-y-auto custom-scrollbar touch-pan-y overscroll-contain p-2 sm:p-4 bg-slate-950/40">
          <ChaptersExplorer
            theme={theme}
            subject={subject}
            topic={resolvedTopic}
            difficulty={difficulty}
            setTopic={(newTopic) => {
              handleSetTopic(newTopic);
              onClose();
            }}
            selectedBoard={selectedBoard}
            onStudyLesson={(lessonTitle, chapterTitle, depth) => {
              if (onStudyLesson) {
                onStudyLesson(lessonTitle, chapterTitle, depth);
              }
              onClose();
            }}
            onGenerateQuiz={onGenerateQuiz || (() => {})}
            savedNotes={savedNotes}
            onDeleteNote={onDeleteNote}
            showNotification={showNotification}
            mode="3d_classroom"
            selectedEntranceExam="none"
          />
        </div>
      </div>
    </div>
  );
};
