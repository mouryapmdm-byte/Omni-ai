import React from 'react';
import { 
  Smartphone, Cpu, Activity, Zap, HardDrive, Wifi, 
  RotateCw, CheckCircle2, ShieldCheck, Gauge, Sliders, Volume2, Monitor 
} from 'lucide-react';
import { useDeviceTier } from './useDeviceTier';

interface DeviceSettingsUIProps {
  isDark?: boolean;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
}

export const DeviceSettingsUI: React.FC<DeviceSettingsUIProps> = ({
  isDark = true,
  showNotification
}) => {
  const { 
    profile, 
    setRenderMode, 
    toggleDataSaver, 
    metrics, 
    dataSaverStats,
    reProbeDevice 
  } = useDeviceTier();

  const handleModeChange = (mode: 'full' | 'lite' | 'audio-only') => {
    setRenderMode(mode);
    showNotification?.(`Render mode switched to ${mode.toUpperCase()} mode.`, 'success');
  };

  const handleReProbe = () => {
    reProbeDevice();
    showNotification?.('Hardware capabilities re-evaluated successfully.', 'info');
  };

  return (
    <div className={`p-6 rounded-2xl border space-y-6 ${
      isDark ? 'bg-slate-900/90 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
    }`}>
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800/60">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <Smartphone size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold">Device Performance & Lite Mode Hub</h2>
              <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border ${
                profile.deviceTier === 'high' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                profile.deviceTier === 'medium' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                'bg-amber-500/20 text-amber-400 border-amber-500/30'
              }`}>
                Detected Tier: {profile.deviceTier.toUpperCase()}
              </span>
            </div>
            <p className="text-xs opacity-60">Adaptive 2D Lite & Audio-Only fallbacks for 1GB RAM budget Android devices</p>
          </div>
        </div>

        <button
          onClick={handleReProbe}
          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCw size={13} /> Re-detect Hardware
        </button>
      </div>

      {/* Render Mode Selectors */}
      <div className="space-y-3">
        <label className="text-xs font-bold uppercase tracking-wider opacity-60 block">
          Select Classroom Rendering Engine
        </label>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Mode 1: 3D Full Classroom */}
          <button
            onClick={() => handleModeChange('full')}
            className={`p-4 rounded-xl border text-left flex flex-col justify-between transition ${
              profile.mode === 'full'
                ? 'bg-indigo-600/20 border-indigo-500 ring-2 ring-indigo-500 text-white'
                : isDark ? 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs flex items-center gap-1.5 text-indigo-400">
                  <Monitor size={14} /> 3D Spatial WebGL
                </span>
                {profile.mode === 'full' && <CheckCircle2 size={14} className="text-indigo-400" />}
              </div>
              <p className="text-[11px] opacity-70">
                Full 3D Classroom Slate with dynamic camera, avatar gestures, and spatial lighting.
              </p>
            </div>
            <span className="text-[10px] font-mono mt-3 opacity-60">Requires 4GB+ RAM & WebGL2</span>
          </button>

          {/* Mode 2: 2D Lite Smartboard */}
          <button
            onClick={() => handleModeChange('lite')}
            className={`p-4 rounded-xl border text-left flex flex-col justify-between transition ${
              profile.mode === 'lite'
                ? 'bg-cyan-600/20 border-cyan-500 ring-2 ring-cyan-500 text-white'
                : isDark ? 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs flex items-center gap-1.5 text-cyan-400">
                  <Zap size={14} /> 2D Lite Flat Mode
                </span>
                {profile.mode === 'lite' && <CheckCircle2 size={14} className="text-cyan-400" />}
              </div>
              <p className="text-[11px] opacity-70">
                Fast 2D vector smartboard with instant step animations and zero-lag physics sandbox.
              </p>
            </div>
            <span className="text-[10px] font-mono mt-3 text-emerald-400">Optimized for 2GB RAM | 60 FPS</span>
          </button>

          {/* Mode 3: Audio-Only */}
          <button
            onClick={() => handleModeChange('audio-only')}
            className={`p-4 rounded-xl border text-left flex flex-col justify-between transition ${
              profile.mode === 'audio-only'
                ? 'bg-purple-600/20 border-purple-500 ring-2 ring-purple-500 text-white'
                : isDark ? 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs flex items-center gap-1.5 text-purple-400">
                  <Volume2 size={14} /> Audio-First Mode
                </span>
                {profile.mode === 'audio-only' && <CheckCircle2 size={14} className="text-purple-400" />}
              </div>
              <p className="text-[11px] opacity-70">
                Zero GPU usage. Pedagogical podcast with synchronized transcripts and formula cards.
              </p>
            </div>
            <span className="text-[10px] font-mono mt-3 text-purple-300">Runs on 1GB RAM Android | &lt; 50MB/mo</span>
          </button>
        </div>
      </div>

      {/* Live Performance Telemetry */}
      <div className={`p-4 rounded-xl border grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs ${
        isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
      }`}>
        <div>
          <span className="text-[10px] uppercase font-bold opacity-60 block">Live FPS:</span>
          <span className="font-mono font-black text-emerald-400 text-sm">{metrics.averageFps} FPS</span>
          <span className="text-[10px] opacity-60 block">Budget: ≥ 30 FPS</span>
        </div>

        <div>
          <span className="text-[10px] uppercase font-bold opacity-60 block">App Memory Heap:</span>
          <span className="font-mono font-black text-cyan-400 text-sm">{metrics.memoryUsedMB} MB</span>
          <span className="text-[10px] opacity-60 block">Budget: &lt; 200 MB</span>
        </div>

        <div>
          <span className="text-[10px] uppercase font-bold opacity-60 block">Device RAM:</span>
          <span className="font-mono font-black text-amber-400 text-sm">{(profile.ramMB / 1024).toFixed(1)} GB</span>
          <span className="text-[10px] opacity-60 block">{profile.cpuCores} CPU Cores</span>
        </div>

        <div>
          <span className="text-[10px] uppercase font-bold opacity-60 block">Data Saver Budget:</span>
          <span className="font-mono font-black text-purple-400 text-sm">{dataSaverStats.currentMonthUsageMB} / {dataSaverStats.monthlyBudgetMB} MB</span>
          <span className="text-[10px] opacity-60 block">{(dataSaverStats.cacheHitRatio * 100).toFixed(0)}% Cache Hits</span>
        </div>
      </div>

      {/* Data Saver Mode Toggle */}
      <div className={`p-4 rounded-2xl border flex items-center justify-between gap-3 ${
        profile.dataSaverEnabled
          ? 'bg-emerald-950/20 border-emerald-500/50 text-emerald-100'
          : isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
      }`}>
        <div>
          <div className="flex items-center gap-2">
            <h4 className="font-bold text-xs">Aggressive Data Saver (&lt; 50MB/month)</h4>
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
              Active Caching
            </span>
          </div>
          <p className="text-[11px] opacity-70 mt-0.5">
            Pre-caches lessons offline, compresses API responses, and strips heavy media assets.
          </p>
        </div>
        <button
          onClick={toggleDataSaver}
          className={`px-4 py-1.5 rounded-xl text-xs font-bold transition shadow ${
            profile.dataSaverEnabled
              ? 'bg-emerald-600 text-white'
              : 'bg-slate-800 text-slate-400'
          }`}
        >
          {profile.dataSaverEnabled ? 'Enabled' : 'Disabled'}
        </button>
      </div>
    </div>
  );
};
