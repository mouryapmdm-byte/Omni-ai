import React from "react";

interface WordTimestamp {
  word: string;
  startTime: number; // in seconds
}

interface StreamingTextHighlighterProps {
  wordTimestamps: WordTimestamp[];
  currentTime: number; // current audio playback time in seconds
}

/**
 * A component that highlights words in a text based on audio playback time.
 * Words are highlighted in blue once the audio playback time exceeds their start time.
 */
export function StreamingTextHighlighter({
  wordTimestamps,
  currentTime,
}: StreamingTextHighlighterProps) {
  return (
    <div className="leading-relaxed text-gray-800 text-lg">
      {wordTimestamps.map((item, index) => (
        <span
          key={index}
          className={`${
            item.startTime <= currentTime
              ? "text-blue-600 font-semibold"
              : "text-gray-500"
          } transition-colors duration-200`}
        >
          {item.word}{" "}
        </span>
      ))}
    </div>
  );
}
