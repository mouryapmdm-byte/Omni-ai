import React, { useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Sphere } from "@react-three/drei";
import { cn } from "@/src/lib/utils";

interface ChemistryLabProps {
  theme: 'light' | 'dark';
}

export const ChemistryLab: React.FC<ChemistryLabProps> = ({ theme }) => {
  const [moles, setMoles] = useState({ A: 1, B: 1 });
  
  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-950 p-2">
      <div className="flex-1 border rounded-lg overflow-hidden relative bg-slate-50 dark:bg-slate-900">
        <Canvas>
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} />
          <Sphere args={[1, 32, 32]} position={[-1.2, 0, 0]}>
            <meshStandardMaterial color="hotpink" />
          </Sphere>
          <Sphere args={[1, 32, 32]} position={[1.2, 0, 0]}>
            <meshStandardMaterial color="cyan" />
          </Sphere>
          <OrbitControls />
        </Canvas>
      </div>
      <div className="p-2 border-t mt-2 text-xs">
        <div className="font-bold mb-2">Reaction: A + B &rarr; C</div>
        <div className="flex gap-4">
          <label>Moles A: <input type="number" className="w-12 border p-1" value={moles.A} onChange={(e) => setMoles({...moles, A: Number(e.target.value)})} /></label>
          <label>Moles B: <input type="number" className="w-12 border p-1" value={moles.B} onChange={(e) => setMoles({...moles, B: Number(e.target.value)})} /></label>
        </div>
      </div>
    </div>
  );
};
