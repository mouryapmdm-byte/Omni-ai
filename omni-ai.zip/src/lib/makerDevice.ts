/**
 * Maker Device Detection & Privilege Management Utility
 * 
 * Ensures buttons (Active Users, Chat History, Settings, Install App) are
 * visible on the Maker's device (dhannanjaymourya36738@gmail.com / development environment),
 * while remaining cleanly hidden on regular end-user devices.
 */

import { useState, useEffect } from 'react';

// Maker credentials & identifiers
export const MAKER_EMAILS = [
  'dhannanjaymourya36738@gmail.com',
  'dhannanjaymourya',
];

/**
 * Synchronous check to determine if the current device/session belongs to the maker.
 */
export function isMakerDevice(user?: { email?: string | null } | null): boolean {
  if (typeof window === 'undefined') return true;

  try {
    // 1. Query parameter check (e.g. ?maker=true or ?maker=1 or ?role=maker or ?admin=true)
    const params = new URLSearchParams(window.location.search);
    if (
      params.get('maker') === 'true' ||
      params.get('maker') === '1' ||
      params.get('role') === 'maker' ||
      params.get('creator') === 'true' ||
      params.get('admin') === 'true'
    ) {
      localStorage.setItem('omni_is_maker', 'true');
      return true;
    }

    // 2. Persisted maker device flag in localStorage
    const stored = localStorage.getItem('omni_is_maker');
    if (stored === 'true') return true;
    if (stored === 'false') return false;

    // 3. User authenticated with maker email
    const email = user?.email?.toLowerCase() || '';
    if (email) {
      for (const makerEmail of MAKER_EMAILS) {
        if (email.includes(makerEmail)) {
          localStorage.setItem('omni_is_maker', 'true');
          return true;
        }
      }
    }

    // 4. Hostname check: Dev environment (ais-dev-*, localhost, 127.0.0.1, or top-level dev sandbox)
    const hostname = window.location.hostname;
    const isDevHost =
      hostname.includes('ais-dev-') ||
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname === '';

    if (isDevHost) {
      // Maker is working in the AI Studio development environment
      localStorage.setItem('omni_is_maker', 'true');
      return true;
    }

    // 5. Check if it's the public shared link (ais-pre-*)
    const isSharedLink =
      hostname.includes('ais-pre-') ||
      params.get('shared') === 'true';

    // If it's a shared link and none of the maker credentials matched, it is a regular user's device
    if (isSharedLink) {
      return false;
    }

    // Default to maker in any other direct development preview context
    return true;
  } catch {
    return true;
  }
}

/**
 * Set or toggle Maker mode on the current device.
 */
export function setMakerMode(enabled: boolean): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem('omni_is_maker', enabled ? 'true' : 'false');
    window.dispatchEvent(new CustomEvent('omni-maker-mode-changed', { detail: { isMaker: enabled } }));
  } catch (e) {
    console.error('Failed to set maker mode in localStorage', e);
  }
}

/**
 * React hook to reactively track maker status on the device.
 */
export function useIsMaker(user?: { email?: string | null } | null): boolean {
  const [isMaker, setIsMaker] = useState<boolean>(() => isMakerDevice(user));

  useEffect(() => {
    setIsMaker(isMakerDevice(user));

    const handleStorageChange = () => {
      setIsMaker(isMakerDevice(user));
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('omni-maker-mode-changed', handleStorageChange);

    // Expose helper on window for developer testing
    if (typeof window !== 'undefined') {
      (window as any).__IS_MAKER__ = isMaker;
      (window as any).setMakerMode = (enabled: boolean) => {
        setMakerMode(enabled);
        setIsMaker(enabled);
      };
    }

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('omni-maker-mode-changed', handleStorageChange);
    };
  }, [user?.email]);

  return isMaker;
}
