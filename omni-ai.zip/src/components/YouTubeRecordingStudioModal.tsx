import React, { useState, useRef, useEffect } from 'react';
import {
  Video,
  X,
  Download,
  Copy,
  Check,
  Sparkles,
  Image as ImageIcon,
  Tag,
  FileText,
  Clock,
  BarChart3,
  Share2,
  Film,
  Layers,
  Sliders,
  CheckCircle2,
  Play,
  Pause,
  Maximize,
  Volume2,
  VolumeX,
  RefreshCw,
  Palette,
  Timer
} from 'lucide-react';
import { cn } from '../lib/utils';
import { stripAllRawMarkdown } from '../lib/streaming/cleanStreamingMarkdown';

export interface RecordedChapter {
  time: number;
  formattedTime: string;
  title: string;
  category?: string;
}

export interface RecordingAnalyticsData {
  resolution: string;
  fps: number;
  bitrateMbps: number;
  audioSpec: string;
  durationSeconds: number;
  fileSizeMb: number;
  chaptersCount: number;
  retentionPrediction: number;
}

export interface YouTubeRecordingStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl: string | null;
  activeTopic: string;
  boardContent?: string;
  recordedDuration: number;
  chapters: RecordedChapter[];
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  sessionTimerStyle?: 'minimal' | 'digital-clock' | 'progress-bar';
  onTimerStyleChange?: (style: 'minimal' | 'digital-clock' | 'progress-bar') => void;
  sessionTimerEnabled?: boolean;
  onTimerEnabledChange?: (enabled: boolean) => void;
}

export const YouTubeRecordingStudioModal: React.FC<YouTubeRecordingStudioModalProps> = ({
  isOpen,
  onClose,
  videoUrl,
  activeTopic,
  boardContent = '',
  recordedDuration,
  chapters = [],
  showNotification,
  sessionTimerStyle = 'digital-clock',
  onTimerStyleChange,
  sessionTimerEnabled = true,
  onTimerEnabledChange
}) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'thumbnail' | 'metadata' | 'analytics'>('preview');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [selectedTitleIdx, setSelectedTitleIdx] = useState<number>(0);
  const [thumbnailTheme, setThumbnailTheme] = useState<'indigo' | 'emerald' | 'amber' | 'rose' | 'cyber'>('indigo');
  const [customThumbnailTitle, setCustomThumbnailTitle] = useState<string>(activeTopic || 'Professor Clarity Lecture');
  
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  useEffect(() => {
    if (activeTopic) {
      setCustomThumbnailTitle(stripAllRawMarkdown(activeTopic.split(':')[0]).trim());
    }
  }, [activeTopic]);

  if (!isOpen || !videoUrl) return null;

  const topicName = activeTopic && activeTopic !== 'None' ? stripAllRawMarkdown(activeTopic.split(':')[0]).trim() : 'Masterclass Lecture';

  // Format Time Helper
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Compile Dynamic Timestamps
  const dynamicTimestamps: RecordedChapter[] = chapters.length > 0 ? chapters : [
    { time: 0, formattedTime: '0:00', title: 'Introduction & Context', category: 'Intro' },
    { time: Math.min(15, Math.floor(recordedDuration * 0.2)), formattedTime: formatTime(Math.min(15, Math.floor(recordedDuration * 0.2))), title: `Understanding ${topicName}`, category: 'Concept' },
    { time: Math.min(45, Math.floor(recordedDuration * 0.5)), formattedTime: formatTime(Math.min(45, Math.floor(recordedDuration * 0.5))), title: 'Step-by-Step Breakdown & Equations', category: 'Deep Dive' },
    { time: Math.min(90, Math.floor(recordedDuration * 0.8)), formattedTime: formatTime(Math.min(90, Math.floor(recordedDuration * 0.8))), title: 'Exam Tips & Practice Questions', category: 'Practice' },
    { time: Math.floor(recordedDuration * 0.95), formattedTime: formatTime(Math.floor(recordedDuration * 0.95)), title: 'Summary & Key Takeaways', category: 'Summary' },
  ];

  // Auto-Generated YouTube Titles (SEO-Optimized)
  const youtubeTitles = [
    `${topicName} Explained — Complete Full HD Guide | Professor Clarity`,
    `${topicName} Made Easy — Step by Step 3D Masterclass | Professor Clarity`,
    `${topicName} in One Shot | NEET, CBSE & Board Exam Masterclass`,
    `Mastering ${topicName} — Visual Intuition & Formula Breakdown | 1080p50`,
    `How to Solve Any ${topicName} Question Fast — High-Score Strategy`
  ];

  // Auto-Generated YouTube Tags (15-20 categorized tags)
  const baseTag = topicName.replace(/[^a-zA-Z0-9 ]/g, '').trim();
  const youtubeTags = [
    baseTag,
    `${baseTag} Lecture`,
    `${baseTag} Explained`,
    `${baseTag} Made Easy`,
    `${baseTag} Class 12`,
    `${baseTag} Class 11`,
    'Professor Clarity',
    'Classroom Slate 3D',
    'NEET Preparation',
    'JEE Main',
    'CBSE Board Exam',
    'Science Education',
    'STEM Visuals',
    '3D Interactive Lecture',
    'Step by Step Tutorial',
    'High Yield Revision',
    'Physics Wallah Style Intuition',
    'Full HD 1080p50'
  ];

  // Auto-Generated Description with Timestamps and Bullet Points
  const autoDescription = `📚 In this lecture, Professor Clarity delivers a comprehensive Full HD 1080p50 masterclass on ${topicName} — engineered for complete conceptual clarity, exam preparation, and visual intuition.

⏱️ CHAPTER TIMESTAMPS:
${dynamicTimestamps.map(c => `${c.formattedTime} — ${c.title}`).join('\n')}

📖 KEY CONCEPTS COVERED:
• Core intuition and everyday analogies behind ${topicName}
• Step-by-step smartboard derivations and visual models
• Key formula applications and metric traps to avoid
• Exam-style multi-level practice questions solved live
• High-yield summary and mnemonics for rapid recall

📝 DOWNLOAD CLASSROOM NOTES & SUMMARY:
Access full markdown transcript, formula sheets, and interactive 3D figures directly in Professor Clarity's Classroom Slate.

📱 CONNECT & EXPLORE:
• AI Tutor: Professor Clarity Active Pedagogy System
• Environment: Classroom Slate 3D Interactive Virtual Learning Lab
• Resolution: Full HD 1080p at 50fps (YouTube Recommended Standard)

#${baseTag.replace(/\s+/g, '')} #Science #Education #ProfessorClarity #NEET #CBSE #BoardExam #FullHD1080p`;

  // Draw 1920x1080 Full HD YouTube Thumbnail onto Canvas
  const drawThumbnail = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 1920;
    canvas.height = 1080;

    // Theme Color Palettes
    const palettes = {
      indigo: { bg1: '#090d16', bg2: '#1e1b4b', accent: '#6366f1', glow: '#818cf8', tagBg: '#312e81', tagText: '#c7d2fe' },
      emerald: { bg1: '#022c22', bg2: '#064e3b', accent: '#10b981', glow: '#34d399', tagBg: '#065f46', tagText: '#a7f3d0' },
      amber: { bg1: '#1c1917', bg2: '#451a03', accent: '#f59e0b', glow: '#fbbf24', tagBg: '#78350f', tagText: '#fde68a' },
      rose: { bg1: '#1f1319', bg2: '#4c0519', accent: '#f43f5e', glow: '#fb7185', tagBg: '#881337', tagText: '#fecdd3' },
      cyber: { bg1: '#05050c', bg2: '#0f172a', accent: '#06b6d4', glow: '#22d3ee', tagBg: '#164e63', tagText: '#a5f3fc' },
    };

    const p = palettes[thumbnailTheme] || palettes.indigo;

    // 1. Background Gradient
    const bgGradient = ctx.createLinearGradient(0, 0, 1920, 1080);
    bgGradient.addColorStop(0, p.bg1);
    bgGradient.addColorStop(0.6, p.bg2);
    bgGradient.addColorStop(1, '#020617');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, 1920, 1080);

    // 2. Decorative Modern Tech Grid & Glow Orbs
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1.5;
    for (let x = 0; x < 1920; x += 80) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 1080);
      ctx.stroke();
    }
    for (let y = 0; y < 1080; y += 80) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(1920, y);
      ctx.stroke();
    }

    // Top Right Radial Glow
    const radGlow = ctx.createRadialGradient(1500, 300, 50, 1500, 300, 700);
    radGlow.addColorStop(0, p.glow + '40');
    radGlow.addColorStop(1, 'transparent');
    ctx.fillStyle = radGlow;
    ctx.fillRect(0, 0, 1920, 1080);

    // Bottom Left Radial Glow
    const leftGlow = ctx.createRadialGradient(300, 800, 50, 300, 800, 600);
    leftGlow.addColorStop(0, p.accent + '30');
    leftGlow.addColorStop(1, 'transparent');
    ctx.fillStyle = leftGlow;
    ctx.fillRect(0, 0, 1920, 1080);

    // 3. Top Header Badge: PROFESSOR CLARITY AI EDUCATOR
    ctx.fillStyle = p.tagBg;
    ctx.beginPath();
    ctx.roundRect(100, 90, 420, 56, 16);
    ctx.fill();
    ctx.strokeStyle = p.accent;
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = p.tagText;
    ctx.font = 'bold 16px system-ui, -apple-system, sans-serif';
    ctx.fillText('🎓 PROFESSOR CLARITY • 3D LAB', 125, 126);

    // 4. Quality Tag: FULL HD 1080p50
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.roundRect(540, 90, 220, 56, 16);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 15px system-ui, -apple-system, sans-serif';
    ctx.fillText('🔴 1080p 50 FPS', 565, 126);

    // 5. Main Topic Headline (25% reduced from 86px to 64px)
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 64px system-ui, -apple-system, sans-serif';
    ctx.shadowColor = p.glow;
    ctx.shadowBlur = 24;

    const displayTitle = customThumbnailTitle.toUpperCase();
    const words = displayTitle.split(' ');
    let line1 = '';
    let line2 = '';
    for (let i = 0; i < words.length; i++) {
      if ((line1 + words[i]).length < 24 && !line2) {
        line1 += (line1 ? ' ' : '') + words[i];
      } else {
        line2 += (line2 ? ' ' : '') + words[i];
      }
    }

    ctx.fillText(line1 || displayTitle, 100, 290);
    if (line2) {
      ctx.fillText(line2, 100, 375);
    }
    ctx.shadowBlur = 0;

    // 6. Impact Sub-badge: "MADE EASY — COMPLETE GUIDE" (25% reduced from 42px to 32px)
    const subY = line2 ? 465 : 370;
    ctx.fillStyle = p.accent;
    ctx.font = '800 32px system-ui, -apple-system, sans-serif';
    ctx.fillText('✦ MADE EASY — COMPLETE VISUAL GUIDE', 100, subY);

    // 7. Right Side Visual Card: Simulated Smartboard & Professor Avatar Frame
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = p.accent + '80';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.roundRect(1140, 180, 680, 720, 32);
    ctx.fill();
    ctx.stroke();

    // Board Header in Card
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.roundRect(1140, 180, 680, 75, [32, 32, 0, 0]);
    ctx.fill();

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 18px system-ui, -apple-system, sans-serif';
    ctx.fillText('📐 SMARTBOARD DERIVATION & DIAGRAM', 1180, 228);

    // Board Content Snippets (25% reduced)
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 18px monospace, sans-serif';
    ctx.fillText('// Synchronized Pedagogy Formula Deck', 1180, 310);
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 27px monospace, sans-serif';
    ctx.fillText('E = hν = hc / λ', 1180, 370);
    ctx.fillText('K_max = hν - Φ_0', 1180, 430);

    ctx.fillStyle = '#34d399';
    ctx.font = 'bold 20px system-ui, -apple-system, sans-serif';
    ctx.fillText('✔ Multi-level practice questions', 1180, 520);
    ctx.fillText('✔ 5-Phase Active Pedagogy Model', 1180, 570);
    ctx.fillText('✔ Dynamic Figure Annotations', 1180, 620);
    ctx.fillText('✔ Exam Ready Marking Points', 1180, 670);

    // Professor Clarity Avatar Badge Inside Card
    ctx.fillStyle = p.accent;
    ctx.beginPath();
    ctx.roundRect(1180, 740, 600, 120, 20);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 24px system-ui, -apple-system, sans-serif';
    ctx.fillText('PROFESSOR CLARITY', 1210, 790);
    ctx.font = '500 15px system-ui, -apple-system, sans-serif';
    ctx.fillStyle = '#e0e7ff';
    ctx.fillText('World-Class AI Educator • Classroom Slate', 1210, 828);

    // 8. Bottom Feature Pill Highlights (Left Column)
    const features = ['NEET • JEE • CBSE Ready', 'Formula Derivations', 'Intuitive Analogies'];
    features.forEach((feat, idx) => {
      const featX = 100 + idx * 320;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.beginPath();
      ctx.roundRect(featX, 920, 300, 60, 16);
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = '#f1f5f9';
      ctx.font = 'bold 15px system-ui, -apple-system, sans-serif';
      ctx.fillText(`⚡ ${feat}`, featX + 24, 958);
    });
  };

  useEffect(() => {
    if (activeTab === 'thumbnail' || isOpen) {
      setTimeout(() => drawThumbnail(), 100);
    }
  }, [thumbnailTheme, customThumbnailTitle, activeTab, isOpen]);

  const downloadThumbnail = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `${topicName.replace(/\s+/g, '_')}_YouTube_Thumbnail_1080p.png`;
    a.click();
    showNotification?.('Downloaded YouTube Full HD Thumbnail (1920×1080 PNG)', 'success');
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(label);
    showNotification?.(`Copied ${label} to clipboard!`, 'success');
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const estimatedBitrate = 14.2; // Mbps
  const estimatedSizeMb = Math.max(1, Math.round((recordedDuration * estimatedBitrate) / 8));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-xl animate-fade-in text-slate-100">
      <div className="bg-slate-900 border border-slate-800/90 rounded-3xl max-w-5xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden relative">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800/80 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-rose-500 flex items-center justify-center text-white shadow-lg shadow-red-600/30">
              <Film size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Full HD Smartboard Recording Studio (1080p50)</h3>
                <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 text-[10px] font-black border border-red-500/40 uppercase tracking-wider">
                  Smartboard Only
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/40 uppercase tracking-wider">
                  YouTube MP4
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Pure smartboard formulas, diagrams & solutions • Zero UI elements • 1080p Full HD at 50fps
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={videoUrl}
              download={`${topicName.replace(/\s+/g, '_')}_Smartboard_Lecture_1080p50.mp4`}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
              title="Download clean Full HD 1080p50 MP4 for YouTube"
            >
              <Download size={15} />
              <span>Download MP4</span>
            </a>
            <a
              href={videoUrl}
              download={`${topicName.replace(/\s+/g, '_')}_Smartboard_Lecture_1080p50.webm`}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer"
              title="Download WebM format"
            >
              <Download size={13} />
              <span>WebM</span>
            </a>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
              title="Close Modal"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-6 border-b border-slate-800 bg-slate-950/30 gap-2 overflow-x-auto text-xs font-bold">
          <button
            onClick={() => setActiveTab('preview')}
            className={cn(
              "py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all cursor-pointer",
              activeTab === 'preview'
                ? "border-indigo-500 text-indigo-400 bg-indigo-500/5"
                : "border-transparent text-slate-400 hover:text-white"
            )}
          >
            <Play size={14} />
            <span>Video Playback ({formatTime(recordedDuration)})</span>
          </button>

          <button
            onClick={() => setActiveTab('thumbnail')}
            className={cn(
              "py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all cursor-pointer",
              activeTab === 'thumbnail'
                ? "border-indigo-500 text-indigo-400 bg-indigo-500/5"
                : "border-transparent text-slate-400 hover:text-white"
            )}
          >
            <ImageIcon size={14} />
            <span>Auto-Thumbnail (1920×1080)</span>
          </button>

          <button
            onClick={() => setActiveTab('metadata')}
            className={cn(
              "py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all cursor-pointer",
              activeTab === 'metadata'
                ? "border-indigo-500 text-indigo-400 bg-indigo-500/5"
                : "border-transparent text-slate-400 hover:text-white"
            )}
          >
            <Sparkles size={14} />
            <span>YouTube SEO & Timestamps</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={cn(
              "py-3 px-3.5 border-b-2 flex items-center gap-2 transition-all cursor-pointer",
              activeTab === 'analytics'
                ? "border-indigo-500 text-indigo-400 bg-indigo-500/5"
                : "border-transparent text-slate-400 hover:text-white"
            )}
          >
            <BarChart3 size={14} />
            <span>Recording Analytics</span>
          </button>
        </div>

        {/* Studio Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* TAB 1: PREVIEW & PLAYBACK */}
          {activeTab === 'preview' && (
            <div className="space-y-4">
              <div className="relative rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-2xl aspect-video max-h-[460px] flex items-center justify-center group">
                <video
                  ref={videoRef}
                  src={videoUrl}
                  controls
                  autoPlay
                  className="w-full h-full object-contain"
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                />
              </div>

              {/* Bottom Quick Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center gap-3">
                  <Clock size={18} className="text-indigo-400 shrink-0" />
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Duration</div>
                    <div className="text-sm font-black text-white">{formatTime(recordedDuration)}</div>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center gap-3">
                  <Video size={18} className="text-emerald-400 shrink-0" />
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Resolution & FPS</div>
                    <div className="text-sm font-black text-white">1080p @ 50fps</div>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center gap-3">
                  <Sliders size={18} className="text-cyan-400 shrink-0" />
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Target Bitrate</div>
                    <div className="text-sm font-black text-white">~14.2 Mbps</div>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center gap-3">
                  <Layers size={18} className="text-amber-400 shrink-0" />
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Detected Chapters</div>
                    <div className="text-sm font-black text-white">{dynamicTimestamps.length} Chapters</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: THUMBNAIL GENERATOR */}
          {activeTab === 'thumbnail' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Palette size={16} className="text-indigo-400" />
                    <span>Auto-Generated YouTube Thumbnail (1920×1080)</span>
                  </h4>
                  <p className="text-xs text-slate-400">
                    High-contrast typography, Professor Clarity branding, and smartboard preview
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Theme Selector */}
                  <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-800">
                    {(['indigo', 'emerald', 'amber', 'rose', 'cyber'] as const).map(t => (
                      <button
                        key={t}
                        onClick={() => setThumbnailTheme(t)}
                        className={cn(
                          "w-6 h-6 rounded-lg capitalize text-[10px] font-bold transition-all cursor-pointer",
                          thumbnailTheme === t ? "ring-2 ring-white scale-110" : "opacity-60 hover:opacity-100",
                          t === 'indigo' && "bg-indigo-600",
                          t === 'emerald' && "bg-emerald-600",
                          t === 'amber' && "bg-amber-500",
                          t === 'rose' && "bg-rose-500",
                          t === 'cyber' && "bg-cyan-500"
                        )}
                        title={`Theme: ${t}`}
                      />
                    ))}
                  </div>

                  <button
                    onClick={downloadThumbnail}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
                  >
                    <Download size={14} />
                    <span>Download Thumbnail (PNG)</span>
                  </button>
                </div>
              </div>

              {/* Title Customizer */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={customThumbnailTitle}
                  onChange={(e) => setCustomThumbnailTitle(e.target.value)}
                  placeholder="Thumbnail Title Headline..."
                  className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm font-bold text-white focus:outline-none focus:border-indigo-500"
                />
                <button
                  onClick={() => drawThumbnail()}
                  className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white cursor-pointer"
                  title="Redraw Thumbnail"
                >
                  <RefreshCw size={16} />
                </button>
              </div>

              {/* Canvas Preview Container */}
              <div className="rounded-2xl overflow-hidden border border-slate-800 bg-black shadow-2xl flex items-center justify-center p-2">
                <canvas
                  ref={canvasRef}
                  className="w-full h-auto max-h-[420px] object-contain rounded-xl"
                />
              </div>
            </div>
          )}

          {/* TAB 3: YOUTUBE SEO METADATA & TIMESTAMPS */}
          {activeTab === 'metadata' && (
            <div className="space-y-6">
              
              {/* Titles Section */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles size={16} className="text-amber-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">SEO Optimized YouTube Titles</h4>
                  </div>
                  <span className="text-[11px] text-slate-400">Click to select & copy</span>
                </div>

                <div className="space-y-2">
                  {youtubeTitles.map((title, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setSelectedTitleIdx(idx);
                        copyToClipboard(title, 'Title');
                      }}
                      className={cn(
                        "p-3 rounded-xl border flex items-center justify-between text-xs font-medium cursor-pointer transition-all",
                        selectedTitleIdx === idx
                          ? "bg-indigo-600/20 border-indigo-500/50 text-white"
                          : "bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-300"
                      )}
                    >
                      <span className="truncate pr-3">{title}</span>
                      <div className="flex items-center gap-1.5 shrink-0 text-slate-400">
                        {copiedSection === 'Title' && selectedTitleIdx === idx ? (
                          <Check size={14} className="text-emerald-400" />
                        ) : (
                          <Copy size={14} />
                        )}
                        <span className="text-[10px] uppercase font-bold">Copy</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Timestamps & Chapters */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock size={16} className="text-cyan-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">Smart Scene Timestamps</h4>
                  </div>
                  <button
                    onClick={() => copyToClipboard(dynamicTimestamps.map(c => `${c.formattedTime} — ${c.title}`).join('\n'), 'Timestamps')}
                    className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedSection === 'Timestamps' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>Copy Timestamps</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {dynamicTimestamps.map((c, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2 truncate">
                        <span className="font-mono text-cyan-400 font-bold">{c.formattedTime}</span>
                        <span className="text-slate-300 truncate">{c.title}</span>
                      </div>
                      {c.category && (
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-400 font-semibold shrink-0">
                          {c.category}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* YouTube Description Box */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText size={16} className="text-emerald-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">Complete YouTube Description</h4>
                  </div>
                  <button
                    onClick={() => copyToClipboard(autoDescription, 'Description')}
                    className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 cursor-pointer"
                  >
                    {copiedSection === 'Description' ? <Check size={12} /> : <Copy size={12} />}
                    <span>Copy Description</span>
                  </button>
                </div>

                <textarea
                  readOnly
                  value={autoDescription}
                  rows={8}
                  className="w-full p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 focus:outline-none resize-none"
                />
              </div>

              {/* YouTube Tags Box */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Tag size={16} className="text-rose-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">YouTube Search Tags ({youtubeTags.length})</h4>
                  </div>
                  <button
                    onClick={() => copyToClipboard(youtubeTags.join(', '), 'Tags')}
                    className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedSection === 'Tags' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>Copy Comma-Separated Tags</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {youtubeTags.map((tag, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 font-medium">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 4: RECORDING ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Video Fidelity</div>
                  <div className="text-xl font-black text-emerald-400">1080p50 Full HD</div>
                  <p className="text-[11px] text-slate-400">1920×1080 @ 50.00 fps progressive capture</p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Video & Audio Bitrate</div>
                  <div className="text-xl font-black text-cyan-400">14.2 Mbps / 320 kbps</div>
                  <p className="text-[11px] text-slate-400">High bitrate H.264/VP9 + 48kHz Stereo audio</p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Predicted YouTube Retention</div>
                  <div className="text-xl font-black text-indigo-400">92.4% High Rating</div>
                  <p className="text-[11px] text-slate-400">Paced chapter transitions maximize watch time</p>
                </div>
              </div>

              {/* Session Timer Video Overlay Settings Toggle Card */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                      <Timer size={18} />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">Session Timer Video Overlay</h4>
                      <p className="text-[11px] text-slate-400">Duration tracker rendered directly onto 1080p50 recording canvas</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400 font-medium">Overlay Status:</span>
                    <button
                      type="button"
                      onClick={() => onTimerEnabledChange && onTimerEnabledChange(!sessionTimerEnabled)}
                      className={cn(
                        "px-3 py-1 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5",
                        sessionTimerEnabled
                          ? "bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-600/20"
                          : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"
                      )}
                    >
                      <span className={cn("w-2 h-2 rounded-full", sessionTimerEnabled ? "bg-white animate-pulse" : "bg-slate-500")} />
                      <span>{sessionTimerEnabled ? "ACTIVE ON VIDEO" : "DISABLED"}</span>
                    </button>
                  </div>
                </div>

                {/* Style Selector */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                      Choose Duration Tracker Style:
                    </label>
                    <span className="text-[10px] text-cyan-400 font-mono">
                      Selected: {sessionTimerStyle}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {[
                      {
                        id: 'minimal' as const,
                        name: 'Minimal Pill',
                        desc: 'Compact dark pill with red indicator dot & HD tag',
                        preview: '● 02:45 HD'
                      },
                      {
                        id: 'digital-clock' as const,
                        name: 'Digital Clock',
                        desc: 'Classic broadcast monospace timecode (1080p50)',
                        preview: 'REC: 02:45 • 1080p50'
                      },
                      {
                        id: 'progress-bar' as const,
                        name: 'Progress Bar',
                        desc: 'Timecode with live timeline fill bar & percentage',
                        preview: '● REC 02:45  65% [━━━━━░░░]'
                      }
                    ].map((style) => (
                      <button
                        key={style.id}
                        type="button"
                        onClick={() => onTimerStyleChange && onTimerStyleChange(style.id)}
                        className={cn(
                          "p-3 rounded-2xl border text-left cursor-pointer transition-all flex flex-col justify-between",
                          sessionTimerStyle === style.id
                            ? "bg-indigo-600/20 border-indigo-500 shadow-lg shadow-indigo-500/10 text-white"
                            : "bg-slate-900 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
                        )}
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-white">{style.name}</span>
                            {sessionTimerStyle === style.id && (
                              <Check size={14} className="text-indigo-400 shrink-0" />
                            )}
                          </div>
                          <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">{style.desc}</p>
                        </div>
                        <div className="mt-3 p-2 rounded-xl bg-slate-950/80 border border-slate-800 font-mono text-[10px] text-cyan-300 text-center">
                          {style.preview}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Technical Specifications Table */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">Recording Specifications Audit</h4>
                <div className="divide-y divide-slate-800 text-xs">
                  <div className="py-2 flex justify-between">
                    <span className="text-slate-400">Resolution Standard</span>
                    <span className="font-semibold text-white">1920 × 1080 (16:9 Aspect Ratio)</span>
                  </div>
                  <div className="py-2 flex justify-between">
                    <span className="text-slate-400">Frame Rate</span>
                    <span className="font-semibold text-white">50.00 fps (Smooth Fluid Motion)</span>
                  </div>
                  <div className="py-2 flex justify-between">
                    <span className="text-slate-400">Audio Channels & Sample Rate</span>
                    <span className="font-semibold text-white">Stereo 2.0 @ 48,000 Hz, 24-bit depth</span>
                  </div>
                  <div className="py-2 flex justify-between">
                    <span className="text-slate-400">Audio Codec</span>
                    <span className="font-semibold text-white">AAC-LC / Opus (320 kbps)</span>
                  </div>
                  <div className="py-2 flex justify-between">
                    <span className="text-slate-400">Target Platform</span>
                    <span className="font-semibold text-emerald-400">YouTube Ready (Direct Upload Optimized)</span>
                  </div>
                  <div className="py-2 flex justify-between">
                    <span className="text-slate-400">Session Timer Video Overlay</span>
                    <span className={cn("font-semibold", sessionTimerEnabled ? "text-emerald-400" : "text-slate-500")}>
                      {sessionTimerEnabled ? `Active (${sessionTimerStyle === 'minimal' ? 'Minimal' : sessionTimerStyle === 'progress-bar' ? 'Progress Bar' : 'Digital Clock'})` : 'Disabled'}
                    </span>
                  </div>
                  <div className="py-2 flex justify-between">
                    <span className="text-slate-400">Scene Markers Registered</span>
                    <span className="font-semibold text-cyan-400">{dynamicTimestamps.length} Scene Markers</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
