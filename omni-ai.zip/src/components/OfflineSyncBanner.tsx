import React, { useState, useEffect } from 'react';
import { useOnlineSync } from '../hooks/useOnlineSync';
import { isMakerDevice } from '../lib/makerDevice';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const OfflineSyncBanner: React.FC = () => {
  const { isOnline, syncStatus } = useOnlineSync(async () => {
    // Simulating IndexedDB local transaction queue release
    return new Promise((resolve) => setTimeout(resolve, 1500));
  });

  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  useEffect(() => {
    const standaloneCheck =
      typeof window !== 'undefined' &&
      (window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true);
    setIsStandalone(standaloneCheck);

    const handlePrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handlePrompt);
    return () => window.removeEventListener('beforeinstallprompt', handlePrompt);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  const isIOS = typeof navigator !== 'undefined' && /iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase());

  return (
    <>
      {/* Offline and Sync Status Toast */}
      {!isOnline && (
        <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2.5 rounded-xl bg-amber-600 px-4 py-2 text-sm font-semibold text-white shadow-2xl">
          <span className="h-2.5 w-2.5 rounded-full bg-white animate-pulse" />
          <span>Using Offline Study Mode. Sync pending.</span>
        </div>
      )}

      {isOnline && syncStatus === 'syncing' && (
        <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2.5 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-2xl">
          <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          <span>Syncing study progress with Cloud...</span>
        </div>
      )}

      {/* PWA App Install Banner (only shows if not standalone & installable) - Visible on Maker's device */}
      {isMakerDevice() && !isStandalone && (deferredPrompt || isIOS) && (
        <div className="fixed bottom-4 right-4 z-50 max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-4 text-white shadow-2xl flex flex-col gap-3">
          <div>
            <h4 className="font-bold text-sm">Download Omni AI App</h4>
            <p className="text-xs text-slate-400 mt-1">Install the app on your device for immersive full-screen study and offline lecture access.</p>
          </div>
          <div className="flex gap-2">
            {deferredPrompt && (
              <button
                onClick={handleInstallClick}
                className="flex-1 rounded-lg bg-indigo-600 py-1.5 text-xs font-semibold hover:bg-indigo-700 transition cursor-pointer"
              >
                Install App
              </button>
            )}
            {isIOS && (
              <button
                onClick={() => setShowIOSGuide(true)}
                className="flex-1 rounded-lg border border-slate-700 py-1.5 text-xs font-semibold hover:bg-slate-800 transition cursor-pointer"
              >
                iOS Guide
              </button>
            )}
          </div>
        </div>
      )}

      {/* iOS Safari Share Sheet Overlay */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm rounded-2xl bg-slate-950 border border-slate-800 p-6 text-white shadow-2xl">
            <h3 className="text-base font-bold">Install on iPhone & iPad</h3>
            <p className="mt-3 text-xs leading-relaxed text-slate-300">
              1. Tap the <strong className="text-indigo-400">Share</strong> icon in the Safari navigation bar.<br />
              2. Scroll down the option sheet and tap <strong className="text-indigo-400">Add to Home Screen</strong>.<br />
              3. Launch the app from your Home Screen for complete immersive study.
            </p>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-5 w-full rounded-lg bg-slate-800 py-2 text-xs font-semibold hover:bg-slate-700 transition cursor-pointer"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
