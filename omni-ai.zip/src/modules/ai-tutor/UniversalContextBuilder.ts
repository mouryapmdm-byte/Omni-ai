// ai-tutor/UniversalContextBuilder.ts
import {
  BoardId,
  ClassLevel,
  SubjectId,
  StudentProfile,
  TutorRequest,
  CurriculumContext,
  ExamPattern,
  ExamTarget,
} from './types';
import { CurriculumService } from './CurriculumService';

export class UniversalContextBuilder {
  constructor(private curriculumService: CurriculumService = new CurriculumService()) {}

  async build(studentProfile: StudentProfile, request: TutorRequest): Promise<CurriculumContext> {
    const subjectId = request.context.subjectId || studentProfile.subjectId || 'physics';
    const topicQuery = request.context.topicId || request.message;

    // Load curriculum data
    const curriculum = await this.curriculumService.getCurriculumContext(
      studentProfile.board,
      studentProfile.classLevel,
      subjectId,
      topicQuery
    );

    const vocabularyLevel = this.determineVocabularyLevel(studentProfile.classLevel, studentProfile.board);
    const contentDepth = this.determineDepth(studentProfile.classLevel, studentProfile.board);
    const culturalContext = this.determineCulture(studentProfile.region);

    const examPattern = this.buildExamPattern(
      studentProfile.board,
      studentProfile.classLevel,
      studentProfile.examTargets[0]
    );

    return {
      board: studentProfile.board,
      classLevel: studentProfile.classLevel,
      subjectId,
      subjectName: curriculum.subjectName,
      chapterId: request.context.chapterId || curriculum.chapterId,
      chapterName: curriculum.chapterName,
      topicId: request.context.topicId || curriculum.topicId,
      topicName: curriculum.topicName,
      subtopicId: request.context.subtopicId || curriculum.subtopicId,
      subtopicName: curriculum.subtopicName,
      learningObjectives: curriculum.learningObjectives,
      prerequisites: curriculum.prerequisites,
      standardFormulas: curriculum.standardFormulas,
      examPattern,
      language: studentProfile.preferredLanguage || 'en',
      vocabularyLevel,
      contentDepth,
      culturalContext,
    };
  }

  private determineVocabularyLevel(
    classLevel: ClassLevel,
    board: BoardId
  ): 'simple' | 'standard' | 'technical' {
    if (typeof classLevel === 'number') {
      if (classLevel <= 8) return 'simple';
      if (classLevel <= 10) return 'standard';
      if (['ib-dp', 'cambridge-a'].includes(board)) return 'technical';
      return 'standard';
    }
    return 'technical';
  }

  private determineDepth(classLevel: ClassLevel, board: BoardId): 1 | 2 | 3 | 4 | 5 {
    if (typeof classLevel === 'number') {
      if (classLevel <= 3) return 1;
      if (classLevel <= 5) return 2;
      if (classLevel <= 8) return 2;
      if (classLevel <= 10) return 3;
      if (['ib-dp', 'cambridge-a', 'cambridge-as'].includes(board)) return 5;
      return 4;
    }
    return 5;
  }

  private determineCulture(region: string): string {
    const reg = (region || '').toUpperCase();
    if (reg.includes('IN') || reg.includes('MH') || reg.includes('TN') || reg.includes('KA') || reg.includes('UP')) {
      return 'India';
    }
    if (reg.includes('US') || reg.includes('NA')) return 'USA';
    if (reg.includes('UK') || reg.includes('GB')) return 'UK';
    if (reg.includes('AU')) return 'Australia';
    if (reg.includes('SG')) return 'Singapore';
    if (reg.includes('AE')) return 'UAE';
    return 'Global';
  }

  private buildExamPattern(
    board: BoardId,
    classLevel: ClassLevel,
    examTarget?: ExamTarget
  ): ExamPattern {
    if (examTarget === 'jee-main' || examTarget === 'jee-advanced' || examTarget === 'neet') {
      return {
        board,
        classLevel,
        style: 'mcq-heavy',
        maxMarks: 300,
        durationMinutes: 180,
        questionTypes: ['Single Correct MCQ', 'Numerical Value Type', 'Assertion-Reasoning'],
        difficultyDistribution: { easy: 20, medium: 50, hard: 30 }
      };
    }

    if (board === 'ib-dp') {
      return {
        board,
        classLevel,
        style: 'essay-heavy',
        maxMarks: 100,
        durationMinutes: 120,
        questionTypes: ['Data-Based Question', 'Short Structured', 'Extended Essay Response'],
        difficultyDistribution: { easy: 15, medium: 45, hard: 40 }
      };
    }

    // Default Board standard (CBSE / ICSE / State)
    return {
      board,
      classLevel,
      style: 'mixed',
      maxMarks: 80,
      durationMinutes: 180,
      questionTypes: ['Section A (MCQs)', 'Section B (2 Marks)', 'Section C (3 Marks)', 'Section D (5 Marks Long)', 'Section E (Case Study)'],
      difficultyDistribution: { easy: 30, medium: 50, hard: 20 }
    };
  }
}
