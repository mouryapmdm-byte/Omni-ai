import React, { useEffect, useRef, useState } from 'react';
import { AlertTriangle, Activity, CheckCircle2, RefreshCw } from 'lucide-react';
import { cn } from '../lib/utils';

export interface RenderTrackerProps {
  componentName: string;
  children: React.ReactNode;
  showVisualBadge?: boolean;
  warnThreshold?: number;
  highlightRenders?: boolean;
}

/**
 * Diagnostic wrapper component that monitors render frequency,
 * logs render cycles, and provides visual alerts against runaway loops.
 */
export const RenderTracker: React.FC<RenderTrackerProps> = ({
  componentName,
  children,
  showVisualBadge = false,
  warnThreshold = 80,
  highlightRenders = false
}) => {
  const renderCountRef = useRef<number>(0);
  const [isFlashing, setIsFlashing] = useState<boolean>(false);

  renderCountRef.current++;
  const currentCount = renderCountRef.current;

  useEffect(() => {
    if (highlightRenders) {
      setIsFlashing(true);
      const timer = setTimeout(() => setIsFlashing(false), 200);
      return () => clearTimeout(timer);
    }

    if (currentCount > warnThreshold) {
      console.error(
        `%c[RenderTracker] ⚠️ Warning: <${componentName}> rendered ${currentCount} times!`,
        'background: #dc2626; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold;'
      );
    }
  }, [currentCount, highlightRenders, warnThreshold, componentName]);

  const isWarning = currentCount > warnThreshold;

  return (
    <div
      className={cn(
        "relative transition-all duration-200",
        isFlashing && "outline-2 outline-amber-500 rounded-xl",
        isWarning && "ring-2 ring-red-500/50"
      )}
    >
      {showVisualBadge && (
        <div
          className={cn(
            "absolute top-2 right-2 z-30 px-2 py-1 rounded-lg text-[10px] font-mono font-bold flex items-center gap-1.5 shadow-md backdrop-blur-md border transition-all",
            isWarning
              ? "bg-red-950/90 text-red-300 border-red-500/50 animate-pulse"
              : "bg-slate-900/90 text-emerald-300 border-emerald-500/30"
          )}
          title={`Render tracker for ${componentName}`}
        >
          {isWarning ? <AlertTriangle size={12} className="text-red-400" /> : <Activity size={12} className="text-emerald-400" />}
          <span>{componentName}: #{currentCount}</span>
        </div>
      )}
      {children}
    </div>
  );
};
