import React, { useState, useEffect } from 'react';
import { GraduationCap, Sparkles, Clock, Users, CheckCircle, HelpCircle, ArrowRight, Play, Pause, RotateCcw, BarChart2, MessageSquare, Lightbulb, Zap, Shield, X } from 'lucide-react';
import { cn } from '../lib/utils';

interface SocraticLessonOrchestratorProps {
  theme?: string;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  onClose: () => void;
}

const LESSON_PHASES = [
  { id: 'hook', title: '1. Concept Hook & Analogy', duration: '5 min', desc: 'Engage students with a real-world intuition or provocative physics/chemistry paradox before introducing formal theory.' },
  { id: 'socratic', title: '2. Socratic Guided Prompt', duration: '10 min', desc: 'Ask targeted probing questions instead of lecturing. Guide learners to discover the core principle through guided inquiry.' },
  { id: 'derivation', title: '3. Collaborative Derivation', duration: '15 min', desc: 'Students collaborate on the digital whiteboard or scratchpad to derive equations step-by-step.' },
  { id: 'mastery', title: '4. Rapid Mastery Check', duration: '5 min', desc: 'Broadcast instant diagnostic poll to verify comprehension and address remaining misconceptions.' }
];

export const SocraticLessonOrchestrator: React.FC<SocraticLessonOrchestratorProps> = ({
  theme = 'light',
  showNotification,
  onClose
}) => {
  const [activePhaseIdx, setActivePhaseIdx] = useState<number>(0);
  const [timerSeconds, setTimerSeconds] = useState<number>(300); // 5 min default for hook
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [customPrompt, setCustomPrompt] = useState<string>('Why does total internal reflection occur only when moving from optically denser to rarer medium?');
  const [socraticAiHint, setSocraticAiHint] = useState<string>('Ask students: "What happens to the angle of refraction as angle of incidence increases? At what critical angle does refraction disappear?"');
  
  // Simulated student poll state
  const [pollActive, setPollActive] = useState<boolean>(false);
  const [pollQuestion, setPollQuestion] = useState<string>('What is the refractive index if critical angle is 45°?');
  const [pollResponses, setPollResponses] = useState<{ option: string; count: number; percentage: number }[]>([
    { option: 'A) 1.414 (√2)', count: 28, percentage: 70 },
    { option: 'B) 1.000', count: 4, percentage: 10 },
    { option: 'C) 1.732 (√3)', count: 6, percentage: 15 },
    { option: 'D) 0.707', count: 2, percentage: 5 }
  ]);

  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(prev => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setIsTimerRunning(false);
      showNotification?.("⏱️ Lesson phase timer completed!", "info");
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleSelectPhase = (idx: number) => {
    setActivePhaseIdx(idx);
    setIsTimerRunning(false);
    const durations = [300, 600, 900, 300];
    setTimerSeconds(durations[idx] || 300);
    showNotification?.(`Switched to phase: ${LESSON_PHASES[idx].title}`, 'info');
  };

  const handleBroadcastPoll = () => {
    setPollActive(true);
    showNotification?.("📡 Broadcasted Socratic Diagnostic Poll to all connected classroom students!", "success");
  };

  const handleAiPromptGenerate = () => {
    const prompts = [
      { prompt: 'Why do higher-order reactions exhibit temperature dependence described by the Arrhenius equation?', hint: 'Ask: "How does kinetic energy distribution change at higher temperatures according to Boltzmann distribution?"' },
      { prompt: 'What physical property dictates why transition metals form colored coordination complexes?', hint: 'Ask: "What happens to degenerate d-orbitals when ligands approach along the axis?"' },
      { prompt: 'How does Lenz\'s Law uphold the Law of Conservation of Energy in electromagnetic induction?', hint: 'Ask: "What would happen to kinetic energy of a magnet falling through a coil if the induced current repelled instead of opposed?"' }
    ];
    const rand = prompts[Math.floor(Math.random() * prompts.length)];
    setCustomPrompt(rand.prompt);
    setSocraticAiHint(rand.hint);
    showNotification?.("✨ Generated new Socratic prompt & AI tone cue!", "success");
  };

  return (
    <div className="fixed inset-0 z-[350] flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className={cn(
        "max-w-4xl w-full rounded-3xl border shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200",
        theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
      )}>
        {/* Header */}
        <div className={cn(
          "px-6 py-5 border-b flex items-center justify-between",
          theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-200"
        )}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 flex items-center justify-center text-indigo-500">
              <GraduationCap size={22} />
            </div>
            <div>
              <h2 className="text-base font-black tracking-wide flex items-center gap-2">
                Socratic Lesson Orchestrator
                <span className="text-[9px] font-black px-2 py-0.5 bg-indigo-500/10 text-indigo-400 rounded-full border border-indigo-500/20">
                  TEACHING STYLE ACCELERATOR
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Guide student inquiry, time pedagogical phases, and broadcast instant Socratic diagnostic polls
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-slate-500/20 transition cursor-pointer text-slate-400 hover:text-slate-200"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[78vh] overflow-y-auto">

          {/* Phase Stepper & Timer Bar */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            {LESSON_PHASES.map((phase, idx) => {
              const isActive = activePhaseIdx === idx;
              return (
                <div
                  key={phase.id}
                  onClick={() => handleSelectPhase(idx)}
                  className={cn(
                    "p-4 rounded-2xl border transition-all cursor-pointer space-y-2 relative overflow-hidden",
                    isActive
                      ? (theme === 'dark' ? "bg-indigo-950/40 border-indigo-500/50 shadow-lg shadow-indigo-600/10" : "bg-indigo-50 border-indigo-300 shadow-md shadow-indigo-100")
                      : (theme === 'dark' ? "bg-slate-950/40 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300")
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className={cn(
                      "text-[10px] font-black uppercase px-2 py-0.5 rounded-full border",
                      isActive ? "bg-indigo-600 text-white border-indigo-500" : "bg-slate-500/10 text-slate-400 border-slate-500/20"
                    )}>
                      {phase.duration}
                    </span>
                    {isActive && <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />}
                  </div>
                  <div>
                    <h4 className="text-xs font-black tracking-wide">{phase.title}</h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">{phase.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Phase Controls & Timer */}
          <div className={cn(
            "p-5 rounded-2xl border flex flex-col md:flex-row items-center justify-between gap-4",
            theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-200"
          )}>
            <div className="space-y-1 text-center md:text-left">
              <span className="text-xs font-bold uppercase text-indigo-400 tracking-wider">Current Active Phase</span>
              <h3 className="text-lg font-black">{LESSON_PHASES[activePhaseIdx].title}</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xl">{LESSON_PHASES[activePhaseIdx].desc}</p>
            </div>

            <div className="flex items-center gap-4 bg-slate-900/40 p-3 rounded-2xl border border-slate-800">
              <div className="text-2xl font-black font-mono text-indigo-400">
                {formatTime(timerSeconds)}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsTimerRunning(!isTimerRunning)}
                  className={cn(
                    "p-2.5 rounded-xl text-white font-bold transition flex items-center gap-1.5 cursor-pointer",
                    isTimerRunning ? "bg-amber-600 hover:bg-amber-500" : "bg-emerald-600 hover:bg-emerald-500"
                  )}
                  title={isTimerRunning ? "Pause Timer" : "Start Timer"}
                >
                  {isTimerRunning ? <Pause size={16} /> : <Play size={16} />}
                </button>
                <button
                  onClick={() => {
                    setIsTimerRunning(false);
                    const durations = [300, 600, 900, 300];
                    setTimerSeconds(durations[activePhaseIdx] || 300);
                  }}
                  className="p-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-white transition cursor-pointer"
                  title="Reset Timer"
                >
                  <RotateCcw size={16} />
                </button>
              </div>
            </div>
          </div>

          {/* Socratic Prompt & Tone Cue Studio */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <div className={cn(
              "p-5 rounded-2xl border space-y-4",
              theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
            )}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Lightbulb size={18} className="text-amber-400" />
                  <h3 className="text-sm font-black uppercase tracking-wider">Socratic Guiding Prompt</h3>
                </div>
                <button
                  onClick={handleAiPromptGenerate}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border border-indigo-500/20 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles size={14} />
                  AI Prompt Generator
                </button>
              </div>

              <textarea
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                rows={3}
                className={cn(
                  "w-full p-3 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none",
                  theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                )}
                placeholder="Type your Socratic inquiry prompt for students..."
              />

              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-1">
                <div className="text-[11px] font-black text-amber-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap size={13} />
                  Teacher Tone Cue & Follow-up
                </div>
                <p className="text-xs text-slate-300 dark:text-slate-300 leading-relaxed italic">
                  "{socraticAiHint}"
                </p>
              </div>
            </div>

            {/* Instant Student Diagnostic Poll */}
            <div className={cn(
              "p-5 rounded-2xl border space-y-4",
              theme === 'dark' ? "bg-slate-950/40 border-slate-800" : "bg-slate-50 border-slate-200"
            )}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BarChart2 size={18} className="text-emerald-400" />
                  <h3 className="text-sm font-black uppercase tracking-wider">Instant Student Poll & Heatmap</h3>
                </div>
                <span className={cn(
                  "text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider",
                  pollActive ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-slate-500/10 text-slate-400 border border-slate-500/20"
                )}>
                  {pollActive ? "Poll Active 🟢" : "Ready to Broadcast"}
                </span>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase">Diagnostic Question</label>
                <input
                  type="text"
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  className={cn(
                    "w-full px-3 py-2.5 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500",
                    theme === 'dark' ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
                  )}
                />
              </div>

              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between text-xs font-bold text-slate-400">
                  <span>Live Student Responses (40 Connected)</span>
                  <span>70% Correct</span>
                </div>
                <div className="space-y-1.5">
                  {pollResponses.map((res, i) => (
                    <div key={i} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span>{res.option}</span>
                        <span className="text-slate-400">{res.count} students ({res.percentage}%)</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={cn("h-full rounded-full transition-all duration-500", i === 0 ? "bg-emerald-500" : "bg-indigo-500/50")}
                          style={{ width: `${res.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={handleBroadcastPoll}
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs uppercase tracking-wider transition shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles size={16} />
                Broadcast Diagnostic Poll to Classroom
              </button>
            </div>

          </div>

        </div>

        {/* Footer */}
        <div className={cn(
          "px-6 py-4 border-t flex items-center justify-between text-xs text-slate-500",
          theme === 'dark' ? "bg-slate-950/60 border-slate-800" : "bg-slate-50 border-slate-200"
        )}>
          <div className="flex items-center gap-2">
            <CheckCircle size={14} className="text-emerald-500" />
            <span>Socratic methodology keeps students intellectually active and self-correcting</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl font-bold bg-slate-700 hover:bg-slate-600 text-white transition cursor-pointer"
          >
            Close Orchestrator
          </button>
        </div>
      </div>
    </div>
  );
};
