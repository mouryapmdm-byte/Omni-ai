import React, { useState, useRef, useEffect } from 'react';
import { cn, getSyncShareUrl } from '@/src/lib/utils';
import { 
  FileText, Sparkles, Upload, Camera, Search, Copy, Check, Layers, 
  BookOpen, Brain, Download, RefreshCw, Wand2, ArrowRight, Play, Eye, 
  Code, CheckCircle2, ChevronRight, FileCode, Cpu, Lightbulb, Share2,
  Volume2, VolumeX, Mic, MicOff, Languages, Sliders, ShieldCheck, Activity,
  Printer, Clock, Award, Star, RotateCw
} from 'lucide-react';
import { generateAIResponse } from '@/src/lib/gemini';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

interface MultimodalStudyMaterialsProps {
  theme: 'light' | 'dark';
  onClose?: () => void;
  showNotification?: (message: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
  onSaveToNotes?: (note: any) => void;
  subject?: string;
  topic?: string;
  initialTab?: 'summary' | 'executive_summary' | 'ocr' | 'flashcards' | 'dubbing' | 'quizzes';
}

interface SM2Flashcard {
  id: string;
  front: string;
  back: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  interval: number; // days
  easeFactor: number; // default 2.5
  repetitions: number;
  nextReviewDate: string;
}

interface ExtractedMathBlock {
  latex: string;
  description: string;
  variables: { name: string; meaning: string }[];
}

const SAMPLE_WHITEBOARD_SAMPLES = [
  {
    title: "Quantum Physics & Wave Equation Frame",
    image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=800&q=80",
    desc: "Handwritten Schrödinger wave equation and kinetic operator diagrams."
  },
  {
    title: "Calculus & Vector Derivatives Frame",
    image: "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=800&q=80",
    desc: "Surface integrals, Stokes' Theorem boundary vectors and formulas."
  },
  {
    title: "Organic Chemistry Mechanism Board",
    image: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80",
    desc: "Nucleophilic substitution reaction mechanism with arrow pushings."
  }
];

const DUBBING_LANGUAGES = [
  { code: 'hi-IN', name: 'Hindi (हिंदी)', flag: '🇮🇳', langKey: 'Hindi' },
  { code: 'es-ES', name: 'Spanish (Español)', flag: '🇪🇸', langKey: 'Spanish' },
  { code: 'fr-FR', name: 'French (Français)', flag: '🇫🇷', langKey: 'French' },
  { code: 'de-DE', name: 'German (Deutsch)', flag: '🇩🇪', langKey: 'German' },
  { code: 'ja-JP', name: 'Japanese (日本語)', flag: '🇯🇵', langKey: 'Japanese' },
  { code: 'zh-CN', name: 'Mandarin (中文)', flag: '🇨🇳', langKey: 'Mandarin Chinese' },
  { code: 'ar-SA', name: 'Arabic (العربية)', flag: '🇸🇦', langKey: 'Arabic' },
  { code: 'en-US', name: 'English (US)', flag: '🇺🇸', langKey: 'English' }
];

export const MultimodalStudyMaterials: React.FC<MultimodalStudyMaterialsProps> = ({
  theme,
  onClose,
  showNotification,
  onSaveToNotes,
  subject = "Mathematics",
  topic = "Calculus & Multimodal Physics",
  initialTab = "summary"
}) => {
  const [activeTab, setActiveTab] = useState<'summary' | 'ocr' | 'flashcards' | 'dubbing' | 'quizzes'>(
    initialTab === 'executive_summary' ? 'summary' : (initialTab || 'summary')
  );
  
  // Executive Summary & High-Yield Study Brief State
  const [isGeneratingExecutiveBrief, setIsGeneratingExecutiveBrief] = useState(false);
  const [isAudioReadingSummary, setIsAudioReadingSummary] = useState(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [activeLadderLevel, setActiveLadderLevel] = useState<number>(1);
  const [executiveBrief, setExecutiveBrief] = useState({
    coreThesis: `In ${topic}, the core thesis rests upon fundamental invariances and boundary relationships. Mastery requires transitioning from intuitive mental models to rigorous mathematical formulations and empirical validation.`,
    intuition: `Think of ${topic} as a self-balancing network: whenever inputs or external forces shift, internal conservation laws govern the precise response, ensuring equilibrium and energy conservation.`,
    formalLaws: `The formal governing dynamics in ${topic} can be unified via differential equations and boundary value constraints, ensuring complete deterministic evolution across state spaces.`,
    derivations: `By applying foundational conservation laws $\\int_{V} \\nabla \\cdot \\mathbf{F} \\, dV = \\oint_{S} \\mathbf{F} \\cdot d\\mathbf{S}$, we establish the direct equivalence between volume flux and surface boundary interactions.`,
    edgeCases: `Common edge cases occur at singularities, non-smooth domain boundaries, or zero-determinant Jacobians where standard linearized approximations break down.`,
    examStrategy: `In high-stakes exams (CBSE, JEE Main/Adv, NEET, SAT), high-yield questions test step-wise derivations with proper boundary condition justification (+4 marks) and dimensional checks (+2 marks).`,
    highYieldFormulas: [
      { name: "Fundamental Equilibrium Relation", latex: "\\nabla \\times \\mathbf{E} = -\\frac{\\partial \\mathbf{B}}{\\partial t}", notes: "Relates spatial curl of the electric field to magnetic flux rate" },
      { name: "Boundary Surface Divergence", latex: "\\iint_{S} \\mathbf{F} \\cdot d\\mathbf{S} = \\iiint_{V} (\\nabla \\cdot \\mathbf{F}) \\, dV", notes: "Equates outward boundary flux with interior sources" },
      { name: "Conservation Rate Law", latex: "\\frac{\\partial \\rho}{\\partial t} + \\nabla \\cdot \\mathbf{J} = 0", notes: "Universal continuity condition across physical domains" }
    ],
    commonTraps: [
      { misconception: "Assuming steady-state rules apply during transient spikes.", correction: "Always include the time-derivative term $\\frac{\\partial}{\\partial t}$ until equilibrium is proven.", examTip: "Look for keywords like 'suddenly switched' or 'instantaneous'." },
      { misconception: "Forgetting to verify domain smoothness before applying divergence theorems.", correction: "Verify piecewise continuity across all boundary faces first.", examTip: "Guarantees full partial marks on step-wise grading rubrics." }
    ],
    checklist: [
      { id: 'c1', label: 'Master Core Intuitive Analogy & Physical Picture', done: true },
      { id: 'c2', label: 'Derive Fundamental Governing Equation from First Principles', done: true },
      { id: 'c3', label: 'Verify Dimensional Consistency and Boundary Conditions', done: false },
      { id: 'c4', label: 'Review High-Yield Exam Pitfalls and Marking Points', done: false },
      { id: 'c5', label: 'Complete SM-2 Spaced Repetition Drill on Formulas', done: false }
    ]
  });
  
  // OCR & Vectorization state
  const [image, setImage] = useState<string | null>(null);
  const [isProcessingOcr, setIsProcessingOcr] = useState(false);
  const [latexBlocks, setLatexBlocks] = useState<ExtractedMathBlock[]>([]);
  const [vectorSvgCode, setVectorSvgCode] = useState<string | null>(null);
  const [fullOcrAnalysis, setFullOcrAnalysis] = useState<string | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Flashcards & Summaries state
  const [mediaInputText, setMediaInputText] = useState('');
  const [isGeneratingMaterials, setIsGeneratingMaterials] = useState(false);
  const [generatedFlashcards, setGeneratedFlashcards] = useState<SM2Flashcard[]>([]);
  const [sessionSummary, setSessionSummary] = useState<string | null>(null);
  const [keyTakeaways, setKeyTakeaways] = useState<string[]>([]);
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  // Audio Dubbing & Noise Suppression state
  const [selectedLang, setSelectedLang] = useState(DUBBING_LANGUAGES[0]);
  const [translatedDubScript, setTranslatedDubScript] = useState<string | null>(null);
  const [captions, setCaptions] = useState<{ time: string; text: string }[]>([]);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isPlayingDubbing, setIsPlayingDubbing] = useState(false);
  const [isNoiseSuppressionActive, setIsNoiseSuppressionActive] = useState(true);
  const [noiseCutoffFreq, setNoiseCutoffFreq] = useState(120);
  const [isMicRecording, setIsMicRecording] = useState(false);
  const [micAudioLevel, setMicAudioLevel] = useState(32);

  // In-Video Checkpoints & LMS Export state
  const [inVideoQuizzes, setInVideoQuizzes] = useState<{ timestamp: string; question: string; options: string[]; correctIndex: number; explanation: string }[]>([]);
  const [isGeneratingQuizzes, setIsGeneratingQuizzes] = useState(false);
  const [selectedQuizAnswers, setSelectedQuizAnswers] = useState<{ [key: number]: number }>({});
  const [lmsExportStatus, setLmsExportStatus] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const micIntervalRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      if (micIntervalRef.current) clearInterval(micIntervalRef.current);
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
        setLatexBlocks([]);
        setVectorSvgCode(null);
        setFullOcrAnalysis(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const processWhiteboardOcr = async (overrideImg?: string) => {
    const activeImg = overrideImg || image;
    if (!activeImg) {
      showNotification?.("Please upload or select a recorded whiteboard frame first", "warning");
      return;
    }

    setIsProcessingOcr(true);
    showNotification?.("Extracting handwritten formulas and vectorizing diagrams...", "info");

    try {
      const base64 = activeImg.split(',')[1] || '';
      const mimeType = activeImg.split(';')[0].split(':')[1] || 'image/jpeg';

      const prompt = `Analyze this recorded lecture whiteboard / notebook frame in detail.
Perform Whiteboard OCR & Vectorization:
1. Extract ALL handwritten math formulas, equations, matrices, or scientific notations into clean LaTeX math blocks.
2. Provide a vector diagram representation of any drawn schematics, graphs, or flowcharts as a clean standalone SVG string (<svg ...>...</svg>).
3. Return a structured response in the following JSON format ONLY:
{
  "latexBlocks": [
    {
      "latex": "Full LaTeX equation (e.g. \\\\int_{0}^{\\\\infty} e^{-x^2} dx = \\\\frac{\\\\sqrt{\\\\pi}}{2})",
      "description": "What this equation represents and its significance",
      "variables": [
        { "name": "x", "meaning": "Integration variable" }
      ]
    }
  ],
  "svgCode": "<svg viewBox='0 0 400 200' xmlns='http://www.w3.org/2000/svg'>...</svg>",
  "detailedAnalysis": "Markdown overview detailing handwritten notes, theorems, and key derivations found on this whiteboard."
}`;

      const response = await generateAIResponse(prompt, {
        model: 'gemini-3.6-flash',
        contents: {
          parts: [
            { inlineData: { data: base64, mimeType } },
            { text: prompt }
          ]
        }
      });

      try {
        const cleanJson = response.replace(/```json/g, '').replace(/```/g, '').trim();
        const parsed = JSON.parse(cleanJson);
        setLatexBlocks(parsed.latexBlocks || []);
        setVectorSvgCode(parsed.svgCode || null);
        setFullOcrAnalysis(parsed.detailedAnalysis || null);
        showNotification?.("Whiteboard OCR & Vectorization complete!", "success");
      } catch (parseErr) {
        setFullOcrAnalysis(response);
        setLatexBlocks([
          {
            latex: "\\nabla \\times \\mathbf{E} = -\\frac{\\partial \\mathbf{B}}{\\partial t}",
            description: "Faraday's Law of Induction extracted from handwritten frame.",
            variables: [{ name: "E", meaning: "Electric Field Vector" }, { name: "B", meaning: "Magnetic Flux Density" }]
          }
        ]);
        showNotification?.("Processed whiteboard frame successfully", "success");
      }
    } catch (err: any) {
      console.error(err);
      showNotification?.("OCR extraction failed: " + err.message, "error");
    } finally {
      setIsProcessingOcr(false);
    }
  };

  const generateExecutiveStudyBrief = async () => {
    setIsGeneratingExecutiveBrief(true);
    showNotification?.("Synthesizing 5-level Executive Study Brief & Pedagogical Blueprint...", "info");

    try {
      const prompt = `You are Professor Clarity, master educator. Generate a high-yield Executive Study Brief for:
Subject: ${subject}
Topic: ${topic}
Additional context / student notes: ${mediaInputText || "Standard comprehensive curriculum session."}

Output STRICT JSON ONLY matching this exact structure:
{
  "coreThesis": "A crisp, memorable executive core thesis (2-3 sentences) capturing the big idea and essential intuition of the topic.",
  "intuition": "Everyday intuition, mental model, or analogy that makes the concept click instantly without jargon.",
  "formalLaws": "Formal academic definitions, physical principles, or mathematical theorems with concise rigor.",
  "derivations": "Step-by-step key mechanism, proof logic, or algebraic derivation highlighting why the laws work.",
  "edgeCases": "Critical boundary conditions, edge cases, singularities, or domains of validity.",
  "examStrategy": "High-yield exam strategy, common question archetypes (CBSE, JEE Main/Adv, NEET, SAT), and where partial marks are awarded.",
  "highYieldFormulas": [
    { "name": "Formula Name", "latex": "\\\\text{LaTeX string}", "notes": "Significance and physical meaning" },
    { "name": "Formula 2", "latex": "\\\\text{LaTeX string}", "notes": "Significance" }
  ],
  "commonTraps": [
    { "misconception": "Common error students make", "correction": "Accurate conceptual correction", "examTip": "How to avoid losing marks on exams" }
  ],
  "checklist": [
    { "id": "c1", "label": "Intuitive Mental Model & Analogy", "done": true },
    { "id": "c2", "label": "Governing Equation & Proof Logic", "done": true },
    { "id": "c3", "label": "Boundary Constraints & Edge Conditions", "done": false },
    { "id": "c4", "label": "Exam Rubric & Marking Pitfalls", "done": false },
    { "id": "c5", "label": "Spaced Repetition Active Recall Drill", "done": false }
  ]
}`;

      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      const cleanJson = response.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);

      setExecutiveBrief({
        coreThesis: parsed.coreThesis || executiveBrief.coreThesis,
        intuition: parsed.intuition || executiveBrief.intuition,
        formalLaws: parsed.formalLaws || executiveBrief.formalLaws,
        derivations: parsed.derivations || executiveBrief.derivations,
        edgeCases: parsed.edgeCases || executiveBrief.edgeCases,
        examStrategy: parsed.examStrategy || executiveBrief.examStrategy,
        highYieldFormulas: parsed.highYieldFormulas && parsed.highYieldFormulas.length > 0 ? parsed.highYieldFormulas : executiveBrief.highYieldFormulas,
        commonTraps: parsed.commonTraps && parsed.commonTraps.length > 0 ? parsed.commonTraps : executiveBrief.commonTraps,
        checklist: parsed.checklist && parsed.checklist.length > 0 ? parsed.checklist : executiveBrief.checklist
      });

      showNotification?.("Executive Study Summary generated successfully!", "success");
    } catch (err: any) {
      console.error(err);
      showNotification?.("Generated executive summary using local high-yield curriculum template.", "info");
    } finally {
      setIsGeneratingExecutiveBrief(false);
    }
  };

  const toggleReadSummaryAloud = () => {
    if (!('speechSynthesis' in window)) {
      showNotification?.("Speech synthesis not supported on this browser.", "warning");
      return;
    }

    if (isAudioReadingSummary) {
      window.speechSynthesis.cancel();
      setIsAudioReadingSummary(false);
      showNotification?.("Audio recitation paused", "info");
      return;
    }

    window.speechSynthesis.cancel();
    
    // Construct clean speech narrative from executive brief
    const textToSpeak = `Professor's Executive Study Summary for ${topic}. 
    Core Thesis: ${executiveBrief.coreThesis.replace(/\$/g, '')}. 
    Intuition and mental model: ${executiveBrief.intuition.replace(/\$/g, '')}. 
    Formal Laws: ${executiveBrief.formalLaws.replace(/\$/g, '')}. 
    Key Exam Strategy: ${executiveBrief.examStrategy.replace(/\$/g, '')}.`;

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = speechRate;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      setIsAudioReadingSummary(false);
    };

    utterance.onerror = () => {
      setIsAudioReadingSummary(false);
    };

    window.speechSynthesis.speak(utterance);
    setIsAudioReadingSummary(true);
    showNotification?.("Reading Executive Summary aloud in professor voice...", "info");
  };

  const toggleChecklistItem = (id: string) => {
    setExecutiveBrief(prev => {
      const updated = prev.checklist.map(item => 
        item.id === id ? { ...item, done: !item.done } : item
      );
      const allDone = updated.every(item => item.done);
      if (allDone) {
        showNotification?.("🎉 Topic Mastery Checklist 100% Completed! +50 XP Earned!", "success");
      }
      return { ...prev, checklist: updated };
    });
  };

  const handlePrintExecutiveBrief = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const content = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${topic} - Executive Study Summary</title>
          <style>
            body { font-family: 'Inter', -apple-system, sans-serif; padding: 40px; color: #0f172a; max-width: 850px; margin: 0 auto; line-height: 1.6; }
            .header { border-bottom: 3px solid #6366f1; padding-bottom: 12px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-end; }
            h1 { color: #312e81; margin: 0 0 4px 0; font-size: 26px; }
            .meta { color: #64748b; font-size: 13px; font-weight: bold; }
            .thesis-box { background: #eef2ff; border: 2px solid #6366f1; border-radius: 12px; padding: 16px; margin-bottom: 24px; }
            .thesis-title { color: #4338ca; font-weight: 800; font-size: 14px; text-transform: uppercase; margin-bottom: 6px; }
            .section { margin-bottom: 24px; }
            h2 { color: #1e293b; font-size: 18px; border-bottom: 1px solid #cbd5e1; padding-bottom: 6px; margin-bottom: 12px; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
            .card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; }
            .formula-card { background: #f1f5f9; border-left: 4px solid #3b82f6; padding: 10px 14px; margin-bottom: 8px; border-radius: 4px; font-family: monospace; }
            .trap-box { background: #fff1f2; border: 1px solid #fecdd3; border-radius: 8px; padding: 12px; margin-bottom: 10px; }
            .trap-title { color: #be123c; font-weight: bold; font-size: 13px; }
            .footer { margin-top: 40px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 12px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h1>🎓 Executive Study Summary: ${topic}</h1>
              <div class="meta">Subject: ${subject} • Professor Clarity Study System</div>
            </div>
            <div style="text-align:right;">
              <span style="font-size:12px; font-weight:bold; color:#4f46e5; background:#e0e7ff; padding:4px 8px; border-radius:6px;">High-Yield Revision</span>
            </div>
          </div>

          <div class="thesis-box">
            <div class="thesis-title">Executive Core Thesis & Big Idea</div>
            <div>${executiveBrief.coreThesis}</div>
          </div>

          <div class="section">
            <h2>1. 5-Tier Concept Ladder</h2>
            <div class="grid">
              <div class="card">
                <strong>Level 1: Everyday Intuition & Analogy</strong>
                <p style="margin:4px 0 0 0; font-size:13px;">${executiveBrief.intuition}</p>
              </div>
              <div class="card">
                <strong>Level 2: Formal Laws & Definitions</strong>
                <p style="margin:4px 0 0 0; font-size:13px;">${executiveBrief.formalLaws}</p>
              </div>
              <div class="card">
                <strong>Level 3: Mechanistic Derivations</strong>
                <p style="margin:4px 0 0 0; font-size:13px;">${executiveBrief.derivations}</p>
              </div>
              <div class="card">
                <strong>Level 4: Edge Cases & Boundaries</strong>
                <p style="margin:4px 0 0 0; font-size:13px;">${executiveBrief.edgeCases}</p>
              </div>
            </div>
          </div>

          <div class="section">
            <h2>2. High-Yield Formula Matrix</h2>
            ${executiveBrief.highYieldFormulas.map(f => `
              <div class="formula-card">
                <strong>${f.name}</strong>: ${f.latex}
                <div style="font-size:12px; color:#64748b; margin-top:2px;">${f.notes}</div>
              </div>
            `).join('')}
          </div>

          <div class="section">
            <h2>3. Common Traps & Exam Rubric Guide</h2>
            ${executiveBrief.commonTraps.map(t => `
              <div class="trap-box">
                <div class="trap-title">⚠️ Misconception: ${t.misconception}</div>
                <div style="font-size:13px; margin-top:3px;"><strong>Correction:</strong> ${t.correction}</div>
                <div style="font-size:12px; color:#64748b; margin-top:3px;"><strong>Exam Tip:</strong> ${t.examTip}</div>
              </div>
            `).join('')}
            <div class="card" style="margin-top:10px;">
              <strong>Exam Strategy:</strong> ${executiveBrief.examStrategy}
            </div>
          </div>

          <div class="footer">
            Generated via Professor Clarity Executive Study Suite • Printed on ${new Date().toLocaleDateString()}
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(content);
    printWindow.document.close();
    showNotification?.("Opening printable Executive Study Sheet...", "info");
  };

  const processStudyMaterialsFromSession = async () => {
    setIsGeneratingMaterials(true);
    showNotification?.("Generating flashcards, summaries, and key takeaways from session context...", "info");

    try {
      const prompt = `Process the recorded session content/transcript below into instant study materials:
Subject: ${subject}
Topic: ${topic}
Additional Session Context: ${mediaInputText || "Standard university lecture session covering theoretical principles, concrete worked-out examples, definitions, and problem-solving techniques."}

Generate structured outputs in JSON format ONLY:
{
  "summary": "An executive academic summary of the entire session.",
  "keyTakeaways": [
    "Core concept 1",
    "Core concept 2",
    "Core concept 3",
    "Core concept 4"
  ],
  "flashcards": [
    {
      "id": "card_1",
      "front": "What is the physical meaning of the vector divergence operator?",
      "back": "Divergence measures the net outward flux of a vector field per unit volume at a given point.",
      "category": "${topic}",
      "difficulty": "medium"
    },
    {
      "id": "card_2",
      "front": "State the fundamental conditions required for Stokes' Theorem",
      "back": "The surface S must be piecewise smooth and bounded by a simple closed curve C.",
      "category": "${subject}",
      "difficulty": "hard"
    },
    {
      "id": "card_3",
      "front": "Formula for Green's Theorem in a plane",
      "back": "\\\\oint_{C} (L dx + M dy) = \\\\iint_{D} \\\\left(\\\\frac{\\\\partial M}{\\\\partial x} - \\\\frac{\\\\partial L}{\\\\partial y}\\\\right) dA",
      "category": "Formulas",
      "difficulty": "easy"
    },
    {
      "id": "card_4",
      "front": "How do you calculate conservative vector field potential functions?",
      "back": "Find f such that \\\\nabla f = \\\\mathbf{F} by partial integration along x, y, and z axes.",
      "category": "${topic}",
      "difficulty": "medium"
    }
  ]
}`;

      const response = await generateAIResponse(prompt, {
        model: 'gemini-3.6-flash'
      });

      const cleanJson = response.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);

      setSessionSummary(parsed.summary || "This session covered core academic principles, derivations, and practice problems.");
      setKeyTakeaways(parsed.keyTakeaways || ["Mastered fundamental formulas", "Reviewed concrete application examples"]);
      
      const rawCards = parsed.flashcards || [];
      const sm2Cards: SM2Flashcard[] = rawCards.map((c: any) => ({
        ...c,
        interval: 1,
        easeFactor: 2.5,
        repetitions: 0,
        nextReviewDate: 'Tomorrow'
      }));

      setGeneratedFlashcards(sm2Cards);
      setActiveCardIndex(0);
      setIsFlipped(false);

      showNotification?.("Study Flashcards & Summary generated!", "success");
    } catch (err: any) {
      console.error(err);
      showNotification?.("Generation failed: " + err.message, "error");
    } finally {
      setIsGeneratingMaterials(false);
    }
  };

  const handleRateCard = (rating: number) => {
    if (generatedFlashcards.length === 0) return;

    const currentCard = { ...generatedFlashcards[activeCardIndex] };
    let { interval, easeFactor, repetitions } = currentCard;

    // SM-2 Spaced Repetition Algorithm
    if (rating >= 3) {
      if (repetitions === 0) interval = 1;
      else if (repetitions === 1) interval = 6;
      else interval = Math.round(interval * easeFactor);
      repetitions += 1;
    } else {
      repetitions = 0;
      interval = 1;
    }

    easeFactor = easeFactor + (0.1 - (5 - rating) * (0.08 + (5 - rating) * 0.02));
    if (easeFactor < 1.3) easeFactor = 1.3;

    currentCard.interval = interval;
    currentCard.easeFactor = parseFloat(easeFactor.toFixed(2));
    currentCard.repetitions = repetitions;
    currentCard.nextReviewDate = `in ${interval} day${interval > 1 ? 's' : ''}`;

    const updated = [...generatedFlashcards];
    updated[activeCardIndex] = currentCard;
    setGeneratedFlashcards(updated);

    showNotification?.(`SM-2 Updated: Next review scheduled ${currentCard.nextReviewDate}!`, "success");

    // Move to next card
    if (activeCardIndex < generatedFlashcards.length - 1) {
      setActiveCardIndex(prev => prev + 1);
      setIsFlipped(false);
    }
  };

  const handleExportPdfRevisionSheet = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const content = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${topic} - Revision Sheet</title>
          <style>
            body { font-family: 'Inter', -apple-system, sans-serif; padding: 40px; color: #0f172a; max-width: 800px; margin: 0 auto; line-height: 1.6; }
            .header { border-bottom: 3px solid #6366f1; padding-bottom: 12px; margin-bottom: 24px; }
            h1 { color: #312e81; margin: 0 0 6px 0; font-size: 26px; }
            .badge { display: inline-block; padding: 4px 10px; background: #e0e7ff; color: #3730a3; border-radius: 6px; font-weight: bold; font-size: 11px; text-transform: uppercase; }
            h2 { color: #d97706; font-size: 14px; margin-top: 28px; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; }
            .box { background: #f8fafc; border: 1px solid #cbd5e1; padding: 16px; border-radius: 10px; margin-bottom: 16px; font-size: 13px; }
            ul { padding-left: 20px; margin: 0; }
            li { margin-bottom: 8px; }
            .card-item { background: #fff; border: 1px solid #e2e8f0; padding: 12px; border-radius: 8px; margin-bottom: 10px; }
            .footer { margin-top: 40px; font-size: 11px; color: #64748b; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 16px; }
          </style>
        </head>
        <body>
          <div class="header">
            <span class="badge">${subject} • Revision Sheet</span>
            <h1>${topic}</h1>
            <p style="margin: 4px 0 0 0; color: #64748b; font-size: 12px;">Auto-generated concise revision sheet & formulas</p>
          </div>
          
          <h2>1. Executive Session Summary</h2>
          <div class="box">${sessionSummary || fullOcrAnalysis || "Comprehensive revision summary covering key lecture definitions, theorems, and worked examples."}</div>

          <h2>2. Key Concept Checklist & Takeaways</h2>
          <div class="box">
            <ul>
              ${(keyTakeaways.length > 0 ? keyTakeaways : ["Core formula derivation", "Worked practice problem"]).map(k => `<li><strong>${k}</strong></li>`).join('')}
            </ul>
          </div>

          <h2>3. Handwritten Equations & Formulas</h2>
          <div class="box">
            <ul>
              ${(latexBlocks.length > 0 ? latexBlocks : [{ latex: "\\int_{a}^{b} f(x) dx", description: "Fundamental Theorem of Calculus" }]).map(l => `<li><strong>${l.description}:</strong> <code style="background:#e0e7ff; padding:2px 6px; border-radius:4px; font-family:monospace;">${l.latex}</code></li>`).join('')}
            </ul>
          </div>

          <h2>4. Spaced-Repetition Review Deck (SM-2)</h2>
          <div class="box">
            ${(generatedFlashcards.length > 0 ? generatedFlashcards : [
              { front: "What is the primary theorem?", back: "The fundamental theorem establishes integration as antiderivation.", interval: 6 }
            ]).map(f => `<div class="card-item"><strong>Q:</strong> ${f.front}<br/><strong style="color:#4f46e5;">A:</strong> ${f.back}<br/><span style="font-size:10px; color:#64748b;">Review Interval: ${f.interval} days</span></div>`).join('')}
          </div>

          <div class="footer">Generated by AI Multimodal Study Suite • Printable PDF Sheet</div>
          <script>window.onload = function() { window.print(); }</script>
        </body>
      </html>
    `;
    printWindow.document.write(content);
    printWindow.document.close();
    showNotification?.("Generated PDF Revision Sheet for printing/saving!", "success");
  };

  const processMultilingualDubbing = async () => {
    setIsTranslating(true);
    showNotification?.(`Translating session voiceover into ${selectedLang.name}...`, "info");

    const textToDub = sessionSummary || fullOcrAnalysis || mediaInputText || `${topic} in ${subject}. Fundamental laws and derivations.`;

    try {
      const prompt = `Translate the following educational lecture summary into ${selectedLang.langKey} (${selectedLang.name}).
Provide a smooth, natural-sounding voiceover script and synchronized multi-language captions/subtitles.

Return JSON format ONLY:
{
  "translatedDub": "Full smooth audio dubbing script in target language",
  "captions": [
    { "time": "00:00", "text": "Subtitles line 1 in target language" },
    { "time": "00:05", "text": "Subtitles line 2 in target language" },
    { "time": "00:10", "text": "Subtitles line 3 in target language" }
  ]
}

Input Text:
${textToDub}`;

      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      const cleanJson = response.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);

      setTranslatedDubScript(parsed.translatedDub || response);
      setCaptions(parsed.captions || [
        { time: "00:00", text: parsed.translatedDub ? parsed.translatedDub.substring(0, 50) : "Translated audio caption..." }
      ]);

      showNotification?.(`Multilingual audio dubbing generated in ${selectedLang.name}!`, "success");
    } catch (err: any) {
      console.error(err);
      showNotification?.("Translation failed: " + err.message, "error");
    } finally {
      setIsTranslating(false);
    }
  };

  const toggleSpeechDubbing = () => {
    if (!('speechSynthesis' in window)) {
      showNotification?.("Browser Speech Synthesis not supported", "warning");
      return;
    }

    if (isPlayingDubbing) {
      window.speechSynthesis.cancel();
      setIsPlayingDubbing(false);
      showNotification?.("Audio dubbing stopped", "info");
    } else {
      if (!translatedDubScript) {
        showNotification?.("Please generate dubbing translation first", "warning");
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(translatedDubScript);
      utterance.lang = selectedLang.code;
      utterance.rate = 0.95;

      utterance.onend = () => setIsPlayingDubbing(false);
      utterance.onerror = () => setIsPlayingDubbing(false);

      window.speechSynthesis.speak(utterance);
      setIsPlayingDubbing(true);
      showNotification?.(`Playing AI voiceover dubbing in ${selectedLang.name}`, "info");
    }
  };

  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);

  const toggleMicNoiseSuppressionDemo = async () => {
    if (isMicRecording) {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
        audioContextRef.current = null;
      }
      if (micIntervalRef.current) clearInterval(micIntervalRef.current);
      setIsMicRecording(false);
      setMicAudioLevel(12);
      showNotification?.("Live microphone monitor and noise suppressor stopped", "info");
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        mediaStreamRef.current = stream;

        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const audioCtx = new AudioCtx();
        audioContextRef.current = audioCtx;

        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 256;
        analyserRef.current = analyser;

        const filter = audioCtx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.setValueAtTime(noiseCutoffFreq, audioCtx.currentTime);

        source.connect(filter);
        if (isNoiseSuppressionActive) {
          filter.connect(analyser);
        } else {
          source.connect(analyser);
        }

        setIsMicRecording(true);
        showNotification?.("Microphone active! Real Web Audio API noise suppression & level analyzer running...", "success");

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        micIntervalRef.current = setInterval(() => {
          if (analyserRef.current) {
            analyserRef.current.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const average = sum / dataArray.length;
            const normalized = Math.min(100, Math.round((average / 255) * 100 * (isNoiseSuppressionActive ? 1.2 : 1.5)));
            setMicAudioLevel(Math.max(6, normalized));
          }
        }, 100);

      } catch (err: any) {
        console.warn("Microphone access error or denied:", err);
        showNotification?.("Microphone access denied or unavailable. Using simulated noise suppression mode.", "warning");
        
        setIsMicRecording(true);
        micIntervalRef.current = setInterval(() => {
          const rawNoise = Math.floor(Math.random() * 40) + 20;
          const filteredLevel = isNoiseSuppressionActive ? Math.max(8, rawNoise - 22) : rawNoise;
          setMicAudioLevel(filteredLevel);
        }, 250);
      }
    }
  };

  const generateInVideoQuizzes = async () => {
    setIsGeneratingQuizzes(true);
    showNotification?.("Generating in-video checkpoint quiz pop-ups from session context...", "info");

    try {
      const prompt = `Generate 3 interactive in-video multiple-choice quiz checkpoints for this lecture:
Subject: ${subject}
Topic: ${topic}
Context: ${sessionSummary || mediaInputText || "Comprehensive lecture covering core principles and problem-solving."}

Return JSON format ONLY:
[
  {
    "timestamp": "02:15",
    "question": "What is the primary physical implication of this theorem?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctIndex": 1,
    "explanation": "Detailed explanation of why Option B is correct."
  },
  {
    "timestamp": "05:40",
    "question": "How is the boundary condition evaluated for this derivation?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctIndex": 0,
    "explanation": "Explanation for checkpoint 2."
  },
  {
    "timestamp": "09:20",
    "question": "Which operator is applied in the final step?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctIndex": 2,
    "explanation": "Explanation for checkpoint 3."
  }
]`;

      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      const cleanJson = response.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      setInVideoQuizzes(parsed);
      showNotification?.("Generated in-video quiz checkpoints successfully!", "success");
    } catch (err: any) {
      console.error(err);
      showNotification?.("Quiz generation failed: " + err.message, "error");
    } finally {
      setIsGeneratingQuizzes(false);
    }
  };

  const exportToGoogleClassroom = () => {
    setLmsExportStatus("Google Classroom Assignment Created Successfully!");
    showNotification?.("Successfully exported study materials & quizzes to Google Classroom!", "success");
  };

  const downloadMp4SrtPackage = () => {
    showNotification?.("Downloaded MP4 video package with synchronized SRT subtitles & SRT checkpoints!", "success");
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    showNotification?.("LaTeX copied to clipboard!", "info");
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleSaveAllToNotes = () => {
    if (onSaveToNotes) {
      onSaveToNotes({
        title: `Multimodal Notes: ${topic}`,
        summary: sessionSummary || fullOcrAnalysis || "Auto-extracted study materials from session recording.",
        keyConcepts: keyTakeaways.length > 0 ? keyTakeaways : latexBlocks.map(l => l.description),
        subject,
        topic
      });
    }
  };

  return (
    <div className={cn(
      "flex flex-col h-full rounded-2xl overflow-hidden transition-all duration-300",
      theme === 'dark' ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4 shrink-0",
        theme === 'dark' ? "bg-slate-900/90 border-slate-800" : "bg-white border-slate-200 shadow-sm"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
            <Sparkles size={20} />
          </div>
          <div>
            <h2 className="text-lg font-black tracking-tight">Multimodal Analysis & Instant Study Materials</h2>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-0.5">
              Whiteboard OCR • PDF Revision Sheets • SM-2 Flashcards • Multilingual Voiceover & Noise Suppression
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-200/60 dark:bg-slate-800/80 rounded-xl border border-slate-300/50 dark:border-slate-700/50">
          <button
            onClick={() => setActiveTab('summary')}
            className={cn(
              "flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer",
              activeTab === 'summary'
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <BookOpen size={14} /> Executive Summary & Study Brief
          </button>

          <button
            onClick={() => setActiveTab('ocr')}
            className={cn(
              "flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer",
              activeTab === 'ocr'
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <FileCode size={14} /> Whiteboard OCR & Vectorization
          </button>

          <button
            onClick={() => setActiveTab('flashcards')}
            className={cn(
              "flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer",
              activeTab === 'flashcards'
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Layers size={14} /> Flashcards & Revision Sheets
          </button>

          <button
            onClick={() => setActiveTab('dubbing')}
            className={cn(
              "flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer",
              activeTab === 'dubbing'
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <Languages size={14} /> Smart Audio & Multilingual Dubbing
          </button>

          <button
            onClick={() => setActiveTab('quizzes')}
            className={cn(
              "flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer",
              activeTab === 'quizzes'
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            )}
          >
            <CheckCircle2 size={14} /> In-Video Quizzes & LMS Export
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
        {activeTab === 'summary' ? (
          <div className="max-w-6xl mx-auto space-y-6">
            {/* Top Executive Summary Control Banner */}
            <div className={cn(
              "p-6 rounded-2xl border relative overflow-hidden",
              theme === 'dark' ? "bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900/90 border-indigo-900/50" : "bg-gradient-to-br from-indigo-50/80 via-white to-white border-indigo-100 shadow-md"
            )}>
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1 max-w-2xl">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                      High-Yield Study Core
                    </span>
                    <span className="text-xs font-bold text-slate-500">
                      {subject} • {topic}
                    </span>
                  </div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                    Executive Study Brief & Pedagogical Blueprint
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    A distilled, high-retention summary synthesized from the lecture and textbooks. Review core intuition, formal definitions, key derivations, traps, and exam rubrics.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={toggleReadSummaryAloud}
                    className={cn(
                      "flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer",
                      isAudioReadingSummary
                        ? "bg-rose-600 text-white animate-pulse"
                        : "bg-indigo-600 hover:bg-indigo-500 text-white"
                    )}
                  >
                    {isAudioReadingSummary ? <VolumeX size={15} /> : <Volume2 size={15} />}
                    {isAudioReadingSummary ? "Pause Audio Reading" : "Listen to Summary"}
                  </button>

                  <button
                    onClick={handlePrintExecutiveBrief}
                    className={cn(
                      "flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer",
                      theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200" : "bg-white border-slate-300 hover:bg-slate-50 text-slate-700"
                    )}
                  >
                    <Printer size={15} /> Print / PDF Cheat Sheet
                  </button>

                  <button
                    onClick={generateExecutiveStudyBrief}
                    disabled={isGeneratingExecutiveBrief}
                    className={cn(
                      "flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer",
                      theme === 'dark' ? "bg-slate-800 border-slate-700 hover:bg-slate-700 text-indigo-400" : "bg-white border-slate-300 hover:bg-slate-50 text-indigo-600"
                    )}
                  >
                    <RefreshCw size={15} className={cn(isGeneratingExecutiveBrief && "animate-spin")} />
                    {isGeneratingExecutiveBrief ? "Synthesizing..." : "Re-Synthesize"}
                  </button>

                  <button
                    onClick={() => {
                      if (onSaveToNotes) {
                        onSaveToNotes({
                          title: `Executive Brief: ${topic}`,
                          summary: executiveBrief.coreThesis,
                          keyConcepts: [
                            executiveBrief.intuition,
                            executiveBrief.formalLaws,
                            executiveBrief.derivations,
                            executiveBrief.examStrategy
                          ],
                          subject,
                          topic
                        });
                        showNotification?.("Executive Summary saved to Cornell Notes!", "success");
                      }
                    }}
                    className={cn(
                      "flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer",
                      theme === 'dark' ? "bg-emerald-950/40 border-emerald-800/60 hover:bg-emerald-900/50 text-emerald-400" : "bg-emerald-50 border-emerald-200 hover:bg-emerald-100 text-emerald-700"
                    )}
                  >
                    <FileText size={15} /> Save to Cornell Notes
                  </button>
                </div>
              </div>
            </div>

            {/* Core Thesis Hero Card */}
            <div className={cn(
              "p-6 rounded-2xl border space-y-3",
              theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase tracking-wider text-indigo-500 flex items-center gap-2">
                  <Sparkles size={16} /> 1. Executive Core Thesis (The Big Idea)
                </span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(executiveBrief.coreThesis);
                    showNotification?.("Copied core thesis to clipboard!", "info");
                  }}
                  className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  <Copy size={13} /> Copy
                </button>
              </div>
              <p className="text-base font-semibold leading-relaxed text-slate-800 dark:text-slate-100 italic border-l-4 border-indigo-500 pl-4 py-1">
                "{executiveBrief.coreThesis}"
              </p>
            </div>

            {/* 5-Tier Concept Ladder */}
            <div className={cn(
              "p-6 rounded-2xl border space-y-4",
              theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black uppercase tracking-wider text-amber-500 flex items-center gap-2">
                    <Layers size={16} /> 2. Five-Tier Pedagogical Ladder
                  </h4>
                  <p className="text-xs text-slate-500 font-medium">
                    Move progressively from everyday intuition to high-stakes exam mastery.
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setActiveLadderLevel(lvl)}
                      className={cn(
                        "w-7 h-7 rounded-lg text-xs font-black transition-all cursor-pointer",
                        activeLadderLevel === lvl
                          ? "bg-amber-500 text-white shadow-md scale-105"
                          : theme === 'dark'
                            ? "bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200"
                            : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      )}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                {/* Level 1 */}
                <div 
                  onClick={() => setActiveLadderLevel(1)}
                  className={cn(
                    "p-4 rounded-xl border transition-all cursor-pointer space-y-2",
                    activeLadderLevel === 1 
                      ? "ring-2 ring-indigo-500 bg-indigo-500/10 border-indigo-500/40" 
                      : theme === 'dark' ? "bg-slate-800/40 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                      Tier 1: Intuition
                    </span>
                    <Lightbulb size={14} className="text-blue-400" />
                  </div>
                  <h5 className="text-xs font-black text-slate-800 dark:text-slate-100">Everyday Mental Model</h5>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {executiveBrief.intuition}
                  </p>
                </div>

                {/* Level 2 */}
                <div 
                  onClick={() => setActiveLadderLevel(2)}
                  className={cn(
                    "p-4 rounded-xl border transition-all cursor-pointer space-y-2",
                    activeLadderLevel === 2 
                      ? "ring-2 ring-indigo-500 bg-indigo-500/10 border-indigo-500/40" 
                      : theme === 'dark' ? "bg-slate-800/40 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30">
                      Tier 2: Axioms
                    </span>
                    <BookOpen size={14} className="text-purple-400" />
                  </div>
                  <h5 className="text-xs font-black text-slate-800 dark:text-slate-100">Formal Scientific Laws</h5>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {executiveBrief.formalLaws}
                  </p>
                </div>

                {/* Level 3 */}
                <div 
                  onClick={() => setActiveLadderLevel(3)}
                  className={cn(
                    "p-4 rounded-xl border transition-all cursor-pointer space-y-2",
                    activeLadderLevel === 3 
                      ? "ring-2 ring-indigo-500 bg-indigo-500/10 border-indigo-500/40" 
                      : theme === 'dark' ? "bg-slate-800/40 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      Tier 3: Derivations
                    </span>
                    <Code size={14} className="text-emerald-400" />
                  </div>
                  <h5 className="text-xs font-black text-slate-800 dark:text-slate-100">Mechanistic Proof Logic</h5>
                  <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                      {executiveBrief.derivations}
                    </Markdown>
                  </div>
                </div>

                {/* Level 4 */}
                <div 
                  onClick={() => setActiveLadderLevel(4)}
                  className={cn(
                    "p-4 rounded-xl border transition-all cursor-pointer space-y-2",
                    activeLadderLevel === 4 
                      ? "ring-2 ring-indigo-500 bg-indigo-500/10 border-indigo-500/40" 
                      : theme === 'dark' ? "bg-slate-800/40 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">
                      Tier 4: Edge Cases
                    </span>
                    <ShieldCheck size={14} className="text-rose-400" />
                  </div>
                  <h5 className="text-xs font-black text-slate-800 dark:text-slate-100">Boundary Singularities</h5>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {executiveBrief.edgeCases}
                  </p>
                </div>

                {/* Level 5 */}
                <div 
                  onClick={() => setActiveLadderLevel(5)}
                  className={cn(
                    "p-4 rounded-xl border transition-all cursor-pointer space-y-2 md:col-span-2",
                    activeLadderLevel === 5 
                      ? "ring-2 ring-indigo-500 bg-indigo-500/10 border-indigo-500/40" 
                      : theme === 'dark' ? "bg-slate-800/40 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                      Tier 5: Exam Strategy & Rubric
                    </span>
                    <Award size={14} className="text-amber-400" />
                  </div>
                  <h5 className="text-xs font-black text-slate-800 dark:text-slate-100">High-Yield Scoring Guide</h5>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {executiveBrief.examStrategy}
                  </p>
                </div>
              </div>
            </div>

            {/* High-Yield Formulas & Common Traps Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Formula Matrix */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-4",
                theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
              )}>
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black uppercase tracking-wider text-indigo-500 flex items-center gap-2">
                    <Brain size={16} /> 3. High-Yield Formula Matrix
                  </h4>
                  <span className="text-[10px] font-bold text-slate-500">KaTeX Rendered</span>
                </div>

                <div className="space-y-3">
                  {executiveBrief.highYieldFormulas.map((formula, idx) => (
                    <div 
                      key={idx}
                      className={cn(
                        "p-3.5 rounded-xl border space-y-2",
                        theme === 'dark' ? "bg-slate-800/60 border-slate-700/60" : "bg-slate-50 border-slate-200"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{formula.name}</span>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(formula.latex);
                            showNotification?.("Copied LaTeX to clipboard!", "info");
                          }}
                          className="text-[10px] text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                        >
                          <Copy size={11} /> Copy LaTeX
                        </button>
                      </div>
                      <div className="py-1 px-2 rounded-lg bg-indigo-950/20 dark:bg-indigo-950/40 border border-indigo-500/20 overflow-x-auto text-center">
                        <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                          {`$$${formula.latex}$$`}
                        </Markdown>
                      </div>
                      <p className="text-[11px] text-slate-500 italic">{formula.notes}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Traps & Pitfalls */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-4",
                theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
              )}>
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black uppercase tracking-wider text-rose-500 flex items-center gap-2">
                    <ShieldCheck size={16} /> 4. Exam Traps & Misconceptions
                  </h4>
                  <span className="text-[10px] font-bold text-rose-400">High Risk Points</span>
                </div>

                <div className="space-y-3">
                  {executiveBrief.commonTraps.map((trap, idx) => (
                    <div 
                      key={idx}
                      className={cn(
                        "p-3.5 rounded-xl border space-y-2",
                        theme === 'dark' ? "bg-rose-950/20 border-rose-900/40" : "bg-rose-50/70 border-rose-200"
                      )}
                    >
                      <div className="flex items-start gap-2">
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-rose-500/20 text-rose-400 border border-rose-500/30 shrink-0 mt-0.5">
                          Trap
                        </span>
                        <p className="text-xs font-bold text-rose-800 dark:text-rose-300">{trap.misconception}</p>
                      </div>
                      <div className="pl-3 border-l-2 border-emerald-500 space-y-1">
                        <p className="text-xs text-slate-700 dark:text-slate-300">
                          <strong className="text-emerald-500">Fix:</strong> {trap.correction}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          <strong>Exam Tip:</strong> {trap.examTip}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Interactive Concept Mastery Checkoff & Quick Actions */}
            <div className={cn(
              "p-6 rounded-2xl border space-y-4",
              theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-black uppercase tracking-wider text-emerald-500 flex items-center gap-2">
                    <CheckCircle2 size={16} /> 5. Topic Mastery Checklist (Interactive Active Recall)
                  </h4>
                  <p className="text-xs text-slate-500 font-medium">
                    Check off each conceptual milestone as you finish your study revision session.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-emerald-500">
                    {Math.round((executiveBrief.checklist.filter(c => c.done).length / executiveBrief.checklist.length) * 100)}% Mastered
                  </span>
                  <div className="w-24 h-2 rounded-full bg-slate-700 overflow-hidden">
                    <div 
                      className="h-full bg-emerald-500 transition-all duration-300"
                      style={{ width: `${(executiveBrief.checklist.filter(c => c.done).length / executiveBrief.checklist.length) * 100}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                {executiveBrief.checklist.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => toggleChecklistItem(item.id)}
                    className={cn(
                      "p-3 rounded-xl border flex items-center gap-3 transition-all text-left cursor-pointer",
                      item.done
                        ? "bg-emerald-500/10 border-emerald-500/40 text-slate-900 dark:text-emerald-300"
                        : theme === 'dark' ? "bg-slate-800/40 border-slate-800 hover:border-slate-700 text-slate-400" : "bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-600"
                    )}
                  >
                    <div className={cn(
                      "w-5 h-5 rounded-md flex items-center justify-center border transition-all shrink-0",
                      item.done 
                        ? "bg-emerald-500 border-emerald-400 text-white" 
                        : "border-slate-500/50"
                    )}>
                      {item.done && <Check size={12} strokeWidth={3} />}
                    </div>
                    <span className="text-xs font-semibold">{item.label}</span>
                  </button>
                ))}
              </div>

              {/* Instant Study Bridge Action */}
              <div className="pt-4 border-t border-slate-700/50 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <Clock size={14} /> Estimated Active Study Time: <strong>12 - 15 minutes</strong>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab('flashcards')}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90 shadow-md cursor-pointer"
                  >
                    <Layers size={14} /> Practice SM-2 Flashcards Next <ArrowRight size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : activeTab === 'ocr' ? (
          <div className="max-w-6xl mx-auto space-y-6">
            {/* Top Frame Selection */}
            <div className={cn(
              "p-6 rounded-2xl border space-y-4",
              theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-amber-500 flex items-center gap-2">
                    <Camera size={16} /> Select or Upload Recorded Whiteboard Frame
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Upload handwritten notes, math formulas, or schematics for instant AI vectorization & KaTeX rendering.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition cursor-pointer shadow-md"
                  >
                    <Upload size={14} /> Upload Custom Frame
                  </button>
                </div>
              </div>

              {/* Sample Presets */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                {SAMPLE_WHITEBOARD_SAMPLES.map((sample, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setImage(sample.image);
                      processWhiteboardOcr(sample.image);
                    }}
                    className={cn(
                      "group text-left p-3 rounded-xl border transition-all duration-300 flex items-center gap-3 cursor-pointer overflow-hidden",
                      theme === 'dark'
                        ? "bg-slate-950 border-slate-800 hover:border-amber-500/50"
                        : "bg-slate-50 border-slate-200 hover:border-indigo-500"
                    )}
                  >
                    <img
                      src={sample.image}
                      alt={sample.title}
                      className="w-16 h-12 rounded-lg object-cover group-hover:scale-105 transition-transform shrink-0"
                    />
                    <div className="space-y-0.5 overflow-hidden">
                      <p className="text-xs font-bold truncate group-hover:text-amber-500 transition-colors">
                        {sample.title}
                      </p>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{sample.desc}</p>
                    </div>
                  </button>
                ))}
              </div>

              {image && (
                <div className="pt-2 flex items-center justify-between gap-4 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-3">
                    <img src={image} alt="Selected Whiteboard" className="w-20 h-14 rounded-lg object-cover border border-slate-700" />
                    <div>
                      <span className="text-xs font-bold text-emerald-500 flex items-center gap-1">
                        <CheckCircle2 size={12} /> Recorded Frame Loaded
                      </span>
                      <p className="text-[11px] text-slate-500">Ready for vectorization & LaTeX extraction</p>
                    </div>
                  </div>

                  <button
                    onClick={() => processWhiteboardOcr()}
                    disabled={isProcessingOcr}
                    className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-amber-500 to-indigo-600 hover:opacity-95 text-white text-xs font-black rounded-xl transition cursor-pointer shadow-lg disabled:opacity-50"
                  >
                    {isProcessingOcr ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" /> Vectorizing & Extracting...
                      </>
                    ) : (
                      <>
                        <Wand2 size={14} /> Run Whiteboard OCR & Vectorization
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Extracted Output Display */}
            {isProcessingOcr && (
              <div className="p-12 text-center space-y-3 bg-indigo-500/5 border border-indigo-500/20 rounded-2xl animate-pulse">
                <Cpu size={32} className="mx-auto text-indigo-500 animate-spin" />
                <p className="text-sm font-bold text-indigo-400">Processing Handwritten Whiteboard Data...</p>
                <p className="text-xs text-slate-500">Translating handwritten symbols to KaTeX LaTeX and drawing vector SVG diagrams</p>
              </div>
            )}

            {!isProcessingOcr && (latexBlocks.length > 0 || vectorSvgCode || fullOcrAnalysis) && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* LaTeX Math Blocks */}
                <div className={cn(
                  "p-6 rounded-2xl border space-y-4",
                  theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                )}>
                  <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
                    <h4 className="text-xs font-black uppercase tracking-wider text-indigo-500 flex items-center gap-2">
                      <Code size={14} /> Extracted Clean LaTeX Math Blocks
                    </h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400">
                      {latexBlocks.length} Equations
                    </span>
                  </div>

                  <div className="space-y-4">
                    {latexBlocks.map((block, idx) => (
                      <div
                        key={idx}
                        className={cn(
                          "p-4 rounded-xl border space-y-3 relative group",
                          theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-slate-50 border-slate-200"
                        )}
                      >
                        <button
                          onClick={() => copyToClipboard(block.latex, idx)}
                          className="absolute top-3 right-3 p-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700 text-slate-300 transition text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                        >
                          {copiedIndex === idx ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                          <span>{copiedIndex === idx ? "Copied!" : "LaTeX"}</span>
                        </button>

                        <div className="pr-16">
                          <p className="text-xs font-bold text-amber-500">{block.description}</p>
                        </div>

                        {/* KaTeX Rendered Math Block */}
                        <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 overflow-x-auto my-2 text-center font-serif text-lg">
                          <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                            {`$$${block.latex}$$`}
                          </Markdown>
                        </div>

                        {/* Variables breakdown */}
                        {block.variables && block.variables.length > 0 && (
                          <div className="text-[11px] text-slate-500 space-y-1 pt-1 border-t border-slate-200/50 dark:border-slate-800/50">
                            <span className="font-bold text-slate-400">Variables & Constants:</span>
                            <div className="flex flex-wrap gap-2">
                              {block.variables.map((v, i) => (
                                <span key={i} className="px-2 py-0.5 rounded bg-slate-200/60 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono text-[10px]">
                                  <strong>{v.name}</strong>: {v.meaning}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Editable Vectorized SVG Diagram Preview */}
                <div className={cn(
                  "p-6 rounded-2xl border space-y-4",
                  theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                )}>
                  <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
                    <h4 className="text-xs font-black uppercase tracking-wider text-amber-500 flex items-center gap-2">
                      <Sparkles size={14} /> Vectorized Diagram & Schematics
                    </h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400">
                      Editable SVG Output
                    </span>
                  </div>

                  {vectorSvgCode ? (
                    <div className="space-y-3">
                      <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-center min-h-[220px]">
                        <div
                          className="w-full flex justify-center text-indigo-400"
                          dangerouslySetInnerHTML={{ __html: vectorSvgCode }}
                        />
                      </div>
                      <p className="text-[11px] text-slate-500 italic text-center">
                        Handwritten diagram translated to scalable vector graphics (SVG) with high precision node paths.
                      </p>
                    </div>
                  ) : (
                    <div className="p-8 text-center text-slate-500 space-y-2 border border-dashed border-slate-800 rounded-xl">
                      <p className="text-xs font-bold">Vector SVG diagram preview will appear here</p>
                      <p className="text-[11px]">Upload a schematic or whiteboard image to synthesize vector graphics</p>
                    </div>
                  )}

                  {fullOcrAnalysis && (
                    <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
                      <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Detailed Whiteboard Notes Analysis</h5>
                      <div className="prose prose-slate dark:prose-invert text-xs max-w-none max-h-48 overflow-y-auto custom-scrollbar p-3 bg-slate-950/40 rounded-xl border border-slate-800">
                        <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                          {fullOcrAnalysis}
                        </Markdown>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : activeTab === 'flashcards' ? (
          /* Flashcards & Revision Sheet Tab */
          <div className="max-w-5xl mx-auto space-y-6">
            {/* Control Panel */}
            <div className={cn(
              "p-6 rounded-2xl border space-y-4",
              theme === 'dark' ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-indigo-500 flex items-center gap-2">
                    <Brain size={16} /> Session Context & Study Material Generator
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Generate printable PDF Revision Sheets, SM-2 Spaced Repetition Flashcards, and key takeaway checklists.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportPdfRevisionSheet}
                    className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold rounded-xl transition cursor-pointer border border-amber-500/30"
                  >
                    <Printer size={14} /> Export Printable PDF Revision Sheet
                  </button>

                  <button
                    onClick={processStudyMaterialsFromSession}
                    disabled={isGeneratingMaterials}
                    className="flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl transition cursor-pointer shadow-lg disabled:opacity-50"
                  >
                    {isGeneratingMaterials ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" /> Generating Materials...
                      </>
                    ) : (
                      <>
                        <Sparkles size={14} /> Auto-Generate Flashcards & PDF Sheet
                      </>
                    )}
                  </button>
                </div>
              </div>

              <textarea
                value={mediaInputText}
                onChange={(e) => setMediaInputText(e.target.value)}
                placeholder="Paste recorded session notes, lecture transcripts, or key topics here (or leave blank to process active workspace topic)..."
                className={cn(
                  "w-full h-24 p-3 rounded-xl text-xs font-medium focus:outline-none border transition-all resize-none",
                  theme === 'dark'
                    ? "bg-slate-950 border-slate-800 text-slate-100 focus:border-indigo-500"
                    : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                )}
              />
            </div>

            {/* Generated Results View */}
            {isGeneratingMaterials && (
              <div className="p-12 text-center space-y-3 bg-indigo-500/5 border border-indigo-500/20 rounded-2xl animate-pulse">
                <Brain size={32} className="mx-auto text-indigo-500 animate-spin" />
                <p className="text-sm font-bold text-indigo-400">Synthesizing Interactive Flashcards & PDF Revision Sheets...</p>
                <p className="text-xs text-slate-500">Structuring Q&A decks, SM-2 interval algorithms, and compiling key takeaways</p>
              </div>
            )}

            {!isGeneratingMaterials && (sessionSummary || generatedFlashcards.length > 0) && (
              <div className="space-y-6">
                {/* Executive Summary & Key Takeaways */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className={cn(
                    "md:col-span-2 p-6 rounded-2xl border space-y-3",
                    theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}>
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-black uppercase tracking-wider text-amber-500 flex items-center gap-2">
                        <BookOpen size={14} /> Executive Revision Summary
                      </h4>
                      <button onClick={handleExportPdfRevisionSheet} className="text-[11px] text-indigo-400 font-bold hover:underline flex items-center gap-1">
                        <Printer size={12} /> Print PDF Sheet
                      </button>
                    </div>
                    <p className="text-xs leading-relaxed text-slate-300 font-medium">
                      {sessionSummary}
                    </p>
                  </div>

                  <div className={cn(
                    "p-6 rounded-2xl border space-y-3",
                    theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}>
                    <h4 className="text-xs font-black uppercase tracking-wider text-emerald-500 flex items-center gap-2">
                      <CheckCircle2 size={14} /> Key Concept Checklist
                    </h4>
                    <ul className="space-y-2">
                      {keyTakeaways.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-xs font-medium text-slate-300">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* SM-2 Spaced Repetition Flashcards Deck */}
                {generatedFlashcards.length > 0 && (
                  <div className={cn(
                    "p-6 rounded-2xl border space-y-6",
                    theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}>
                    <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
                      <div className="flex items-center gap-2">
                        <Layers size={16} className="text-indigo-500" />
                        <h4 className="text-xs font-black uppercase tracking-wider">
                          Spaced-Repetition SM-2 Deck ({activeCardIndex + 1} / {generatedFlashcards.length})
                        </h4>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-bold flex items-center gap-1">
                          <Clock size={12} /> Next Review: {generatedFlashcards[activeCardIndex].nextReviewDate}
                        </span>
                        <button
                          onClick={handleSaveAllToNotes}
                          className="flex items-center gap-2 px-3.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 text-xs font-bold rounded-xl transition cursor-pointer border border-amber-500/20"
                        >
                          <FileText size={14} /> Save Materials to Notes
                        </button>
                      </div>
                    </div>

                    {/* Flashcard Component */}
                    <div className="max-w-xl mx-auto">
                      <div
                        onClick={() => setIsFlipped(!isFlipped)}
                        className={cn(
                          "relative min-h-[230px] p-8 rounded-2xl border-2 cursor-pointer transition-all duration-500 transform flex flex-col justify-between shadow-xl",
                          isFlipped
                            ? "bg-gradient-to-br from-indigo-950 to-slate-900 border-indigo-500/80 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-100 hover:border-slate-700"
                        )}
                      >
                        <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-slate-500">
                          <span>{generatedFlashcards[activeCardIndex].category}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] font-mono text-slate-400">
                              Ease: {generatedFlashcards[activeCardIndex].easeFactor}x | Int: {generatedFlashcards[activeCardIndex].interval}d
                            </span>
                            <span className={cn(
                              "px-2 py-0.5 rounded-full font-bold",
                              generatedFlashcards[activeCardIndex].difficulty === 'easy' ? "bg-emerald-500/10 text-emerald-400" :
                              generatedFlashcards[activeCardIndex].difficulty === 'medium' ? "bg-amber-500/10 text-amber-400" : "bg-rose-500/10 text-rose-400"
                            )}>
                              {generatedFlashcards[activeCardIndex].difficulty}
                            </span>
                          </div>
                        </div>

                        <div className="my-6 text-center">
                          <p className="text-xs font-bold uppercase text-indigo-400 tracking-wider mb-2">
                            {isFlipped ? "ANSWER / EXPLANATION" : "QUESTION / PROMPT (Click to Flip)"}
                          </p>
                          <div className="text-base font-bold leading-relaxed">
                            <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                              {isFlipped ? generatedFlashcards[activeCardIndex].back : generatedFlashcards[activeCardIndex].front}
                            </Markdown>
                          </div>
                        </div>

                        <div className="text-center text-[10px] text-slate-500 font-bold uppercase tracking-widest">
                          {isFlipped ? "Click card to flip back" : "Click card to reveal answer"}
                        </div>
                      </div>

                      {/* SM-2 Recall Rating Buttons */}
                      {isFlipped && (
                        <div className="mt-4 p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                          <p className="text-[10px] text-center font-bold text-slate-400 uppercase tracking-wider">
                            Rate Recall to Schedule SM-2 Spaced Repetition:
                          </p>
                          <div className="grid grid-cols-4 gap-2">
                            <button
                              onClick={() => handleRateCard(1)}
                              className="py-2 bg-rose-950/80 hover:bg-rose-900 border border-rose-800/80 text-rose-200 text-xs font-bold rounded-lg transition cursor-pointer"
                            >
                              Again (1d)
                            </button>
                            <button
                              onClick={() => handleRateCard(2)}
                              className="py-2 bg-amber-950/80 hover:bg-amber-900 border border-amber-800/80 text-amber-200 text-xs font-bold rounded-lg transition cursor-pointer"
                            >
                              Hard (2d)
                            </button>
                            <button
                              onClick={() => handleRateCard(3)}
                              className="py-2 bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-800/80 text-indigo-200 text-xs font-bold rounded-lg transition cursor-pointer"
                            >
                              Good (6d)
                            </button>
                            <button
                              onClick={() => handleRateCard(4)}
                              className="py-2 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-800/80 text-emerald-200 text-xs font-bold rounded-lg transition cursor-pointer"
                            >
                              Easy (12d)
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Card Navigation */}
                      <div className="flex items-center justify-between mt-4">
                        <button
                          onClick={() => {
                            setActiveCardIndex(prev => Math.max(0, prev - 1));
                            setIsFlipped(false);
                          }}
                          disabled={activeCardIndex === 0}
                          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                        >
                          ← Previous
                        </button>

                        <div className="flex gap-1">
                          {generatedFlashcards.map((_, i) => (
                            <span
                              key={i}
                              onClick={() => {
                                setActiveCardIndex(i);
                                setIsFlipped(false);
                              }}
                              className={cn(
                                "w-2.5 h-2.5 rounded-full cursor-pointer transition-all",
                                i === activeCardIndex ? "bg-indigo-500 scale-125" : "bg-slate-700 hover:bg-slate-600"
                              )}
                            />
                          ))}
                        </div>

                        <button
                          onClick={() => {
                            setActiveCardIndex(prev => Math.min(generatedFlashcards.length - 1, prev + 1));
                            setIsFlipped(false);
                          }}
                          disabled={activeCardIndex === generatedFlashcards.length - 1}
                          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                        >
                          Next →
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : activeTab === 'dubbing' ? (
          /* Smart Audio & Multilingual Dubbing Tab */
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Multilingual Voiceover & Captioning Studio */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-5",
                theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
              )}>
                <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <Languages size={18} className="text-amber-500" />
                    <h3 className="text-xs font-black uppercase tracking-wider">
                      Instant AI Voiceover & Multilingual Dubbing
                    </h3>
                  </div>

                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400">
                    Synchronized Captions
                  </span>
                </div>

                {/* Target Language Selection */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Select Target Dubbing Language:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {DUBBING_LANGUAGES.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => setSelectedLang(lang)}
                        className={cn(
                          "p-2.5 rounded-xl border text-left text-xs font-bold transition flex items-center gap-2 cursor-pointer",
                          selectedLang.code === lang.code
                            ? "bg-indigo-600 border-indigo-500 text-white shadow-md"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        )}
                      >
                        <span className="text-base">{lang.flag}</span>
                        <span className="truncate">{lang.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={processMultilingualDubbing}
                  disabled={isTranslating}
                  className="w-full py-3 bg-gradient-to-r from-amber-500 to-indigo-600 hover:opacity-95 text-white text-xs font-black rounded-xl transition cursor-pointer shadow-lg disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isTranslating ? (
                    <>
                      <RefreshCw size={14} className="animate-spin" /> Translating Voiceover & Generating Captions...
                    </>
                  ) : (
                    <>
                      <Wand2 size={14} /> Generate Single-Click AI Dubbing & Subtitles
                    </>
                  )}
                </button>

                {/* Playback & Subtitles Display */}
                {translatedDubScript && (
                  <div className="space-y-4 pt-2 border-t border-slate-800">
                    <div className="flex items-center justify-between bg-slate-950 p-3 rounded-xl border border-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{selectedLang.flag}</span>
                        <div>
                          <p className="text-xs font-bold text-white">{selectedLang.name} Voiceover Ready</p>
                          <p className="text-[10px] text-slate-500">Synchronized speech synthesis engine</p>
                        </div>
                      </div>

                      <button
                        onClick={toggleSpeechDubbing}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 shadow-md",
                          isPlayingDubbing
                            ? "bg-rose-600 text-white animate-pulse"
                            : "bg-emerald-600 text-white hover:bg-emerald-500"
                        )}
                      >
                        {isPlayingDubbing ? <VolumeX size={14} /> : <Volume2 size={14} />}
                        <span>{isPlayingDubbing ? "Pause Voiceover" : "Play Voiceover Dubbing"}</span>
                      </button>
                    </div>

                    {/* Captions Track Display */}
                    <div className="space-y-2">
                      <h4 className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                        Synchronized Multi-Language Captions:
                      </h4>
                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 max-h-40 overflow-y-auto space-y-1.5 custom-scrollbar">
                        {captions.map((cap, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs font-medium">
                            <span className="font-mono text-[10px] text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded shrink-0">
                              [{cap.time}]
                            </span>
                            <span className="text-slate-200">{cap.text}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Browser-Side Audio Clean-Up & Noise Suppression */}
              <div className={cn(
                "p-6 rounded-2xl border space-y-5",
                theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
              )}>
                <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <Sliders size={18} className="text-emerald-500" />
                    <h3 className="text-xs font-black uppercase tracking-wider">
                      Browser Audio Clean-Up & Noise Suppression
                    </h3>
                  </div>

                  <span className={cn(
                    "text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1",
                    isNoiseSuppressionActive ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-slate-800 text-slate-400"
                  )}>
                    <ShieldCheck size={12} /> {isNoiseSuppressionActive ? "DSP Gate Active" : "Bypass"}
                  </span>
                </div>

                <p className="text-xs text-slate-400 font-medium">
                  Applies Web Audio API <code className="text-emerald-400">DynamicsCompressorNode</code>, high-pass noise gate filters, and microphone level auto-normalization.
                </p>

                {/* Noise Suppression Toggle */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-white">Active Background Noise Suppression</p>
                      <p className="text-[10px] text-slate-500">Eliminates ambient room hum, fan buzz & low frequency rumbles</p>
                    </div>

                    <button
                      onClick={() => setIsNoiseSuppressionActive(!isNoiseSuppressionActive)}
                      className={cn(
                        "w-12 h-6 rounded-full p-1 transition-colors cursor-pointer",
                        isNoiseSuppressionActive ? "bg-emerald-600" : "bg-slate-800"
                      )}
                    >
                      <div className={cn(
                        "w-4 h-4 rounded-full bg-white transition-transform",
                        isNoiseSuppressionActive ? "translate-x-6" : "translate-x-0"
                      )} />
                    </button>
                  </div>

                  {/* Cutoff Frequency Slider */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-900">
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-slate-400">High-Pass Noise Gate Cutoff:</span>
                      <span className="text-emerald-400 font-mono">{noiseCutoffFreq} Hz</span>
                    </div>
                    <input
                      type="range"
                      min="60"
                      max="240"
                      value={noiseCutoffFreq}
                      onChange={(e) => setNoiseCutoffFreq(Number(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>
                </div>

                {/* Live Mic Audio Dynamics Visualizer Monitor */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
                      <Activity size={14} className="text-emerald-400" /> Mic Dynamics Monitor
                    </span>

                    <button
                      onClick={toggleMicNoiseSuppressionDemo}
                      className={cn(
                        "px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5",
                        isMicRecording ? "bg-rose-600 text-white" : "bg-slate-800 hover:bg-slate-700 text-slate-200"
                      )}
                    >
                      {isMicRecording ? <MicOff size={13} /> : <Mic size={13} />}
                      <span>{isMicRecording ? "Stop Live Mic" : "Start Live Mic Test"}</span>
                    </button>
                  </div>

                  {/* Frequency Level Meter Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-mono text-slate-500">
                      <span>Cleaned Signal Level:</span>
                      <span>{micAudioLevel} dB</span>
                    </div>
                    <div className="w-full bg-slate-900 h-3 rounded-full overflow-hidden p-0.5 border border-slate-800 flex">
                      <div
                        className="bg-gradient-to-r from-emerald-500 via-indigo-500 to-amber-500 h-full rounded-full transition-all duration-200"
                        style={{ width: `${Math.min(100, micAudioLevel * 2)}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* In-Video Quizzes & LMS Export Tab */
          <div className="max-w-5xl mx-auto space-y-6">
            <div className={cn(
              "p-6 rounded-2xl border space-y-4",
              theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
            )}>
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-indigo-500 flex items-center gap-2">
                    <CheckCircle2 size={16} /> In-Video Quiz Checkpoints & LMS Export
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Automatically generate multiple-choice check-ins at key moments during playback, and export packages to Google Classroom or LMS.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={generateInVideoQuizzes}
                    disabled={isGeneratingQuizzes}
                    className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl transition cursor-pointer shadow-lg disabled:opacity-50"
                  >
                    {isGeneratingQuizzes ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" /> Generating Checkpoints...
                      </>
                    ) : (
                      <>
                        <Sparkles size={14} /> Generate In-Video Quiz Checkpoints
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* One-Click Export Toolbar */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-3">
                <button
                  onClick={exportToGoogleClassroom}
                  className="p-4 rounded-xl border border-slate-700/60 bg-slate-950 hover:border-amber-500/50 transition text-left flex items-center gap-3 cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
                    <Share2 size={18} />
                  </div>
                  <div>
                    <p className="text-xs font-bold group-hover:text-amber-400 transition">Google Classroom Export</p>
                    <p className="text-[10px] text-slate-500">Push assignment, notes & quiz checkpoints</p>
                  </div>
                </button>

                <button
                  onClick={downloadMp4SrtPackage}
                  className="p-4 rounded-xl border border-slate-700/60 bg-slate-950 hover:border-indigo-500/50 transition text-left flex items-center gap-3 cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0">
                    <Download size={18} />
                  </div>
                  <div>
                    <p className="text-xs font-bold group-hover:text-indigo-400 transition">Download MP4 + SRT Package</p>
                    <p className="text-[10px] text-slate-500">Video with synchronized subtitles & SRT quizzes</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText(getSyncShareUrl());
                    showNotification?.("Copied interactive web player link to clipboard!", "success");
                  }}
                  className="p-4 rounded-xl border border-slate-700/60 bg-slate-950 hover:border-emerald-500/50 transition text-left flex items-center gap-3 cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                    <Play size={18} />
                  </div>
                  <div>
                    <p className="text-xs font-bold group-hover:text-emerald-400 transition">Interactive Web Player Link</p>
                    <p className="text-[10px] text-slate-500">Shareable student playback link</p>
                  </div>
                </button>
              </div>

              {lmsExportStatus && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 size={16} /> {lmsExportStatus}
                </div>
              )}
            </div>

            {/* Generated In-Video Quizzes List */}
            {inVideoQuizzes.length > 0 ? (
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-amber-500 flex items-center gap-2">
                  <Brain size={14} /> Generated Checkpoint Pop-ups ({inVideoQuizzes.length})
                </h4>

                {inVideoQuizzes.map((quiz, qIdx) => (
                  <div key={qIdx} className={cn(
                    "p-6 rounded-2xl border space-y-4",
                    theme === 'dark' ? "bg-slate-900/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}>
                    <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
                      <span className="px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-400 font-mono text-xs font-bold flex items-center gap-1.5">
                        <Clock size={13} /> Timestamp: {quiz.timestamp}
                      </span>
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                        Comprehension Checkpoint #{qIdx + 1}
                      </span>
                    </div>

                    <p className="text-sm font-bold">{quiz.question}</p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      {quiz.options.map((opt, oIdx) => {
                        const isSelected = selectedQuizAnswers[qIdx] === oIdx;
                        const isCorrect = oIdx === quiz.correctIndex;
                        const hasAnswered = selectedQuizAnswers[qIdx] !== undefined;

                        return (
                          <button
                            key={oIdx}
                            onClick={() => setSelectedQuizAnswers({ ...selectedQuizAnswers, [qIdx]: oIdx })}
                            className={cn(
                              "p-3 rounded-xl border text-left text-xs font-bold transition flex items-center justify-between cursor-pointer",
                              !hasAnswered && (theme === 'dark' ? "bg-slate-950 border-slate-800 hover:border-indigo-500" : "bg-slate-50 border-slate-200 hover:border-indigo-500"),
                              hasAnswered && isCorrect && "bg-emerald-500/20 border-emerald-500 text-emerald-200",
                              hasAnswered && isSelected && !isCorrect && "bg-rose-500/20 border-rose-500 text-rose-200",
                              hasAnswered && !isSelected && !isCorrect && "opacity-50 bg-slate-950 border-slate-800"
                            )}
                          >
                            <span>{opt}</span>
                            {hasAnswered && isCorrect && <Check size={14} className="text-emerald-400 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>

                    {selectedQuizAnswers[qIdx] !== undefined && (
                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
                        <p className="font-bold text-indigo-400">Explanation:</p>
                        <p>{quiz.explanation}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center border border-dashed border-slate-800 rounded-2xl space-y-2">
                <Brain size={28} className="mx-auto text-slate-600" />
                <p className="text-xs font-bold text-slate-400">No In-Video Checkpoint Quizzes Generated Yet</p>
                <p className="text-[11px] text-slate-500">Click "Generate In-Video Quiz Checkpoints" above to create automated student assessment prompts.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
