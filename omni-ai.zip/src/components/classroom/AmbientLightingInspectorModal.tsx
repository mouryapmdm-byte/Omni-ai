import React, { useState } from 'react';
import { X, Sun, Moon, Zap, Sparkles, Activity, Layers, RefreshCw, Eye, Image, Check, Sliders } from 'lucide-react';
import { generateImage } from '@/src/lib/gemini';

export type LightingPreset = 'daylight' | 'golden_hour' | 'cyber_night' | 'exam_bright';

export interface AmbientLightingInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  activePreset: LightingPreset;
  onSelectPreset: (preset: LightingPreset) => void;
  activeTopicTitle: string;
  onInsertGeneratedImageToBoard?: (imageUrl: string, title: string) => void;
  showNotification?: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export function AmbientLightingInspectorModal({
  isOpen,
  onClose,
  activePreset,
  onSelectPreset,
  activeTopicTitle,
  onInsertGeneratedImageToBoard,
  showNotification
}: AmbientLightingInspectorModalProps) {
  const [isGeneratingTest, setIsGeneratingTest] = useState(false);
  const [testImageUrl, setTestImageUrl] = useState<string | null>(null);
  const [recalibrateAnim, setRecalibrateAnim] = useState(false);

  if (!isOpen) return null;

  const lightingProfiles: Record<LightingPreset, {
    name: string;
    kelvin: string;
    lux: string;
    keyColorHex: string;
    ambientColorHex: string;
    materialStyle: string;
    specularGloss: string;
    ambientOcclusion: string;
    directive: string;
    icon: React.ReactNode;
    bgGradient: string;
    borderColor: string;
  }> = {
    daylight: {
      name: 'Natural Daylight Studio',
      kelvin: '5,200K Neutral',
      lux: '1.80 Lux',
      keyColorHex: '#fffaed',
      ambientColorHex: '#e2e8f0',
      materialStyle: 'Balanced Diffuse Satin & Glass Refraction',
      specularGloss: '78% Neutral Specular',
      ambientOcclusion: 'Soft Diffuse GI (0.80x)',
      directive: 'Automated 3D Scene Lighting Calibration: Studio neutral daylight balance (5200K), soft ambient fill, balanced diffuse material shading, satin metal and glass reflections.',
      icon: <Sun className="w-5 h-5 text-amber-300" />,
      bgGradient: 'from-amber-950/40 via-sky-950/30 to-slate-900/90',
      borderColor: 'border-amber-500/30'
    },
    golden_hour: {
      name: 'Warm Golden Hour',
      kelvin: '3,200K Amber',
      lux: '2.20 Lux',
      keyColorHex: '#f59e0b',
      ambientColorHex: '#fde68a',
      materialStyle: 'Metallic Gold Specular & Warm Rim Shadow',
      specularGloss: '92% Metallic Gold Satin',
      ambientOcclusion: 'Directional Warm Occlusion (0.60x)',
      directive: 'Automated 3D Scene Lighting Calibration: Warm golden sun key light (3200K, 2.2x luminance), directional rim shadows, metallic specular highlights, warm amber rim refraction.',
      icon: <Sun className="w-5 h-5 text-orange-400" />,
      bgGradient: 'from-orange-950/40 via-amber-950/30 to-slate-900/90',
      borderColor: 'border-orange-500/30'
    },
    cyber_night: {
      name: 'Cyber Neon Night',
      kelvin: '10,000K Indigo',
      lux: '0.80 Lux',
      keyColorHex: '#6366f1',
      ambientColorHex: '#1e1b4b',
      materialStyle: 'Emissive Cyan Gloss & Subsurface Glow',
      specularGloss: '96% Emissive Cyan Gloss (#00f5ff)',
      ambientOcclusion: 'Deep High-Contrast Shadow Occlusion (#090d16)',
      directive: 'Automated 3D Scene Lighting Calibration: Deep dark slate background (#090d16), dramatic indigo key light (#6366f1), electric cyan emissive vector paths (#00f5ff), high specular gloss, subsurface glow.',
      icon: <Moon className="w-5 h-5 text-indigo-400" />,
      bgGradient: 'from-indigo-950/50 via-purple-950/30 to-slate-900/90',
      borderColor: 'border-indigo-500/40'
    },
    exam_bright: {
      name: 'High-Contrast Exam Focus',
      kelvin: '6,500K Pure White',
      lux: '2.00 Lux',
      keyColorHex: '#ffffff',
      ambientColorHex: '#f8fafc',
      materialStyle: 'Crisp Non-Glare Matte Shading',
      specularGloss: '45% Non-Glare Matte Finish',
      ambientOcclusion: 'Balanced Studio Occlusion (1.00x)',
      directive: 'Automated 3D Scene Lighting Calibration: Ultra-clean high-contrast white illumination (6500K), zero shadow noise, crisp high-definition edge legibility, matte non-glare finish.',
      icon: <Zap className="w-5 h-5 text-emerald-400" />,
      bgGradient: 'from-emerald-950/40 via-teal-950/30 to-slate-900/90',
      borderColor: 'border-emerald-500/30'
    }
  };

  const currentProfile = lightingProfiles[activePreset];

  const handleTriggerTestGeneration = async () => {
    setIsGeneratingTest(true);
    showNotification?.(`Generating test Nano Banana 2 image calibrated to ${currentProfile.name}...`, 'info');
    try {
      const topic = activeTopicTitle || 'Thermodynamic Carnot Engine & Energy Vector Diagram';
      const prompt = `High-resolution clean 2D vector scientific photo diagram illustrating ${topic}. ${currentProfile.directive} Professional textbook figure quality, zero photographic wooden frames, zero hands.`;
      
      const img = await generateImage(prompt, {
        aspectRatio: '16:9',
        lightingPreset: activePreset,
        lightingDirective: currentProfile.directive
      });

      if (img) {
        setTestImageUrl(img);
        showNotification?.(`Nano Banana 2 image successfully generated with ${currentProfile.kelvin} lighting calibration!`, 'success');
      } else {
        showNotification?.("Test generation returned fallback image.", 'warning');
      }
    } catch (err) {
      console.error("Failed test generation:", err);
      showNotification?.("Failed to generate test image.", 'error');
    } finally {
      setIsGeneratingTest(false);
    }
  };

  const handleRecalibrate = () => {
    setRecalibrateAnim(true);
    setTimeout(() => setRecalibrateAnim(false), 800);
    showNotification?.(`💡 Scene ambient light re-sampled: Key ${currentProfile.lux} (${currentProfile.kelvin})`, 'info');
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xl animate-in fade-in duration-200">
      <div className={`relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl border ${currentProfile.borderColor} bg-slate-900/95 shadow-2xl p-6 md:p-8 text-slate-100 bg-gradient-to-br ${currentProfile.bgGradient}`}>
        
        {/* Header */}
        <div className="flex items-center justify-between pb-5 border-b border-slate-800/80 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-amber-400 shadow-inner">
              <Activity className={`w-6 h-6 ${recalibrateAnim ? 'animate-spin text-cyan-400' : ''}`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold tracking-tight text-white">Ambient Lighting Inspector</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Nano Banana 2 Visual Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Real-time 3D classroom light vector sampling & material realism parameter calibration
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRecalibrate}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-all active:scale-95"
              title="Recalibrate Light Vectors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${recalibrateAnim ? 'animate-spin' : ''}`} />
              Recalibrate
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Real-time Light Vectors Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-6">
          {/* Metric 1: Color Temp */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Color Temperature</span>
              <div className="w-3 h-3 rounded-full border border-white/20" style={{ backgroundColor: currentProfile.keyColorHex }} />
            </div>
            <div className="text-lg font-extrabold text-amber-300">{currentProfile.kelvin}</div>
            <div className="text-[10px] text-slate-500 mt-1">Spectral Tint: {currentProfile.keyColorHex}</div>
          </div>

          {/* Metric 2: Key Light Lux */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Key Luminance</span>
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="text-lg font-extrabold text-cyan-300">{currentProfile.lux}</div>
            <div className="text-[10px] text-slate-500 mt-1">Directional Vector: (10, 25, 15)</div>
          </div>

          {/* Metric 3: Specular Reflectivity */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Specular Gloss</span>
              <Layers className="w-3.5 h-3.5 text-purple-400" />
            </div>
            <div className="text-xs font-bold text-purple-300 truncate" title={currentProfile.specularGloss}>
              {currentProfile.specularGloss}
            </div>
            <div className="text-[10px] text-slate-500 mt-1">Shading: {currentProfile.materialStyle}</div>
          </div>

          {/* Metric 4: Ambient Occlusion */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Ambient Occlusion</span>
              <Eye className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-xs font-bold text-emerald-300 truncate" title={currentProfile.ambientOcclusion}>
              {currentProfile.ambientOcclusion}
            </div>
            <div className="text-[10px] text-slate-500 mt-1">Fill Tint: {currentProfile.ambientColorHex}</div>
          </div>
        </div>

        {/* Preset Selector */}
        <div className="mb-6">
          <label className="block text-xs font-semibold text-slate-300 mb-2.5 uppercase tracking-wider">
            Select 3D Classroom Ambient Preset
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {(Object.keys(lightingProfiles) as LightingPreset[]).map((presetKey) => {
              const prof = lightingProfiles[presetKey];
              const isSelected = activePreset === presetKey;
              return (
                <button
                  key={presetKey}
                  onClick={() => onSelectPreset(presetKey)}
                  className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'bg-slate-800/90 border-amber-400/80 shadow-lg ring-1 ring-amber-400/50'
                      : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-2">
                    <div className="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                      {prof.icon}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white truncate">{prof.name}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{prof.kelvin}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Live Nano Banana 2 Adapted Directive Box */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/90 mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Nano Banana 2 Adapted Generation Directive
            </span>
            <span className="text-[10px] font-mono text-slate-500">model: gemini-3.1-flash-image</span>
          </div>
          <p className="text-xs text-slate-300 font-mono leading-relaxed bg-slate-900/90 p-3 rounded-xl border border-slate-800/80">
            "{currentProfile.directive}"
          </p>
        </div>

        {/* Test Generation Preview Section */}
        {testImageUrl && (
          <div className="mb-6 p-4 rounded-2xl bg-slate-950/90 border border-amber-500/30 animate-in fade-in duration-300">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Image className="w-4 h-4 text-cyan-400" />
                Live Calibrated Generation Test ({currentProfile.kelvin})
              </span>
              {onInsertGeneratedImageToBoard && (
                <button
                  onClick={() => {
                    onInsertGeneratedImageToBoard(testImageUrl, activeTopicTitle);
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all active:scale-95"
                >
                  Insert Image onto 3D Smartboard
                </button>
              )}
            </div>
            <div className="relative overflow-hidden rounded-xl border border-slate-800 max-h-[320px] bg-black flex items-center justify-center">
              <img src={testImageUrl} alt="Nano Banana 2 Test" className="w-full h-auto object-contain max-h-[320px]" />
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800/80">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all"
          >
            Close Inspector
          </button>
          <button
            onClick={handleTriggerTestGeneration}
            disabled={isGeneratingTest}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 transition-all active:scale-95 disabled:opacity-50"
          >
            <Sparkles className={`w-4 h-4 ${isGeneratingTest ? 'animate-spin' : ''}`} />
            {isGeneratingTest ? 'Calibrating & Generating Nano Banana 2 Image...' : 'Test Nano Banana 2 Realism Generation'}
          </button>
        </div>

      </div>
    </div>
  );
}
