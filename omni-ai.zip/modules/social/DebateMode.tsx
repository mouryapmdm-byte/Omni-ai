export * from '../../src/components/DebateMode';
export { DebateMode as default } from '../../src/components/DebateMode';
