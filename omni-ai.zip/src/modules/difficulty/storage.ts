import { DifficultyState } from './types';
import { DifficultyEngine } from './difficultyEngine';

const STORAGE_PREFIX = 'omni_difficulty_state_';
const LISTENERS: Array<(state: DifficultyState) => void> = [];

export function getStoredDifficultyState(
  studentId: string = 'student_default',
  topicId: string = 'general'
): DifficultyState {
  try {
    const key = `${STORAGE_PREFIX}${studentId}_${topicId}`;
    const raw = localStorage.getItem(key);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error loading difficulty state:', e);
  }
  return DifficultyEngine.createInitialState(studentId, topicId);
}

export function saveDifficultyState(state: DifficultyState): void {
  try {
    const key = `${STORAGE_PREFIX}${state.studentId}_${state.topicId}`;
    localStorage.setItem(key, JSON.stringify(state));
    LISTENERS.forEach(fn => {
      try { fn(state); } catch {}
    });
  } catch (e) {
    console.error('Error saving difficulty state:', e);
  }
}

export function resetStoredDifficultyState(
  studentId: string = 'student_default',
  topicId: string = 'general'
): DifficultyState {
  const initial = DifficultyEngine.createInitialState(studentId, topicId);
  saveDifficultyState(initial);
  return initial;
}

export function subscribeDifficultyUpdates(
  callback: (state: DifficultyState) => void
): () => void {
  LISTENERS.push(callback);
  return () => {
    const idx = LISTENERS.indexOf(callback);
    if (idx !== -1) LISTENERS.splice(idx, 1);
  };
}
