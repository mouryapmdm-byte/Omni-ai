import { DifficultyState, QuestionCandidate, DifficultyLevel } from './types';

export const DEFAULT_QUESTION_BANK: QuestionCandidate[] = [
  // --- LEVEL 1: EASY (Expected Accuracy: 60%) ---
  {
    id: 'diff_q1_01',
    topicId: 'physics_mechanics',
    difficultyLevel: 1,
    itemDifficulty: 1.1,
    text: "A car accelerates from rest at a constant rate of 2 m/s² for 5 seconds. What is its final velocity?",
    formulaOrCode: "v = u + at",
    options: ["10 m/s", "2.5 m/s", "25 m/s", "7 m/s"],
    correctIndex: 0,
    explanation: "Using v = u + at with u = 0, a = 2, t = 5: v = 0 + 2 * 5 = 10 m/s.",
    hint: "Recall the first kinematic equation: v = u + at with zero initial speed."
  },
  {
    id: 'diff_q1_02',
    topicId: 'physics_mechanics',
    difficultyLevel: 1,
    itemDifficulty: 1.4,
    text: "An object of mass 4 kg experiences a net force of 12 N. What is its acceleration?",
    formulaOrCode: "F = ma",
    options: ["3 m/s²", "48 m/s²", "0.33 m/s²", "8 m/s²"],
    correctIndex: 0,
    explanation: "Newton's 2nd Law: a = F / m = 12 N / 4 kg = 3 m/s².",
    hint: "Rearrange F = ma into a = F / m."
  },
  {
    id: 'diff_q1_03',
    topicId: 'physics_electromagnetism',
    difficultyLevel: 1,
    itemDifficulty: 1.5,
    text: "What is the SI unit of electrical resistance?",
    options: ["Ohm (Ω)", "Volt (V)", "Ampere (A)", "Tesla (T)"],
    correctIndex: 0,
    explanation: "Resistance is measured in Ohms (Ω), defined by R = V / I.",
    hint: "Think of Georg Ohm."
  },

  // --- LEVEL 2: MEDIUM (Expected Accuracy: 50%) ---
  {
    id: 'diff_q2_01',
    topicId: 'physics_mechanics',
    difficultyLevel: 2,
    itemDifficulty: 2.1,
    text: "A projectile is launched from ground level with speed 20 m/s at an angle of 30° to the horizontal. Take g = 10 m/s². What is its total time of flight?",
    formulaOrCode: "T = (2 u \\sin \\theta) / g",
    options: ["2.0 seconds", "1.0 second", "3.46 seconds", "4.0 seconds"],
    correctIndex: 0,
    explanation: "T = (2 * 20 * sin 30°) / 10 = (40 * 0.5) / 10 = 2.0 s.",
    hint: "Use T = 2 u_y / g where vertical velocity u_y = u sin θ."
  },
  {
    id: 'diff_q2_02',
    topicId: 'physics_electromagnetism',
    difficultyLevel: 2,
    itemDifficulty: 2.4,
    text: "Two point charges +2 μC and -2 μC are separated by 0.1 m in air. The electric dipole moment of this pair is:",
    formulaOrCode: "p = q \\cdot 2a",
    options: ["2.0 × 10⁻⁷ C·m", "4.0 × 10⁻⁷ C·m", "1.0 × 10⁻⁷ C·m", "Zero"],
    correctIndex: 0,
    explanation: "p = q * d = (2 * 10⁻⁶ C) * (0.1 m) = 2.0 * 10⁻⁷ C·m.",
    hint: "Dipole moment equals magnitude of one charge times separation distance."
  },
  {
    id: 'diff_q2_03',
    topicId: 'physics_thermodynamics',
    difficultyLevel: 2,
    itemDifficulty: 2.5,
    text: "An ideal gas expands isothermally from volume V to 2V at temperature T. The work done by the gas is:",
    formulaOrCode: "W = nRT \\ln(V_2 / V_1)",
    options: ["nRT ln(2)", "nRT / 2", "2 nRT", "Zero"],
    correctIndex: 0,
    explanation: "For an isothermal process, W = ∫ P dV = nRT ln(V₂ / V₁) = nRT ln(2).",
    hint: "In an isothermal expansion, work involves the natural logarithm of volume ratio."
  },

  // --- LEVEL 3: HARD (Expected Accuracy: 40%) ---
  {
    id: 'diff_q3_01',
    topicId: 'physics_mechanics',
    difficultyLevel: 3,
    itemDifficulty: 3.1,
    text: "A uniform cylinder of mass M and radius R rolls without slipping down an incline of angle θ. Its linear acceleration down the slope is:",
    formulaOrCode: "a = \\frac{g \\sin \\theta}{1 + I / (M R^2)}",
    options: ["(2/3) g sin θ", "(1/2) g sin θ", "(3/4) g sin θ", "g sin θ"],
    correctIndex: 0,
    explanation: "For a solid cylinder, I = (1/2)MR². So a = g sin θ / (1 + 1/2) = (2/3) g sin θ.",
    hint: "Account for rotational inertia I = (1/2) M R² resisting linear acceleration."
  },
  {
    id: 'diff_q3_02',
    topicId: 'physics_electromagnetism',
    difficultyLevel: 3,
    itemDifficulty: 3.5,
    text: "In a series LCR circuit with L = 100 mH, C = 100 μF, and R = 10 Ω, what is the resonant angular frequency ω₀?",
    formulaOrCode: "\\omega_0 = \\frac{1}{\\sqrt{LC}}",
    options: ["316.2 rad/s", "1000 rad/s", "100 rad/s", "50 rad/s"],
    correctIndex: 0,
    explanation: "ω₀ = 1 / √(L C) = 1 / √(0.1 * 10⁻⁴) = 1 / √(10⁻⁵) = 1 / 0.003162 ≈ 316.2 rad/s.",
    hint: "Convert millihenries and microfarads to base SI units before calculating 1/√(LC)."
  },

  // --- LEVEL 4: ADVANCED (Expected Accuracy: 30%) ---
  {
    id: 'diff_q4_01',
    topicId: 'physics_electromagnetism',
    difficultyLevel: 4,
    itemDifficulty: 4.1,
    text: "A spherical shell of radius R carries surface charge density σ. What is the electrostatic pressure acting outwards on the surface of the shell?",
    formulaOrCode: "P = \\frac{\\sigma^2}{2 \\varepsilon_0}",
    options: [
      "σ² / (2 ε₀)",
      "σ² / ε₀",
      "2 σ² / ε₀",
      "σ / (4πε₀ R)"
    ],
    correctIndex: 0,
    explanation: "Electrostatic pressure is given by P = (1/2) ε₀ E² where surface field is σ/ε₀, yielding P = σ² / (2ε₀).",
    hint: "The force per unit area on surface charges uses average electric field across the boundary: E_avg = (E_in + E_out) / 2 = σ / (2ε₀)."
  },
  {
    id: 'diff_q4_02',
    topicId: 'physics_mechanics',
    difficultyLevel: 4,
    itemDifficulty: 4.5,
    text: "A chain of length L and mass M is held vertically above a table with its lower end just touching the surface. If released, what is the normal force exerted on the table when length x has fallen?",
    formulaOrCode: "N = 3 \\cdot \\left(\\frac{M}{L}\\right) g x",
    options: [
      "3 (M / L) g x",
      "2 (M / L) g x",
      "(M / L) g x",
      "4 (M / L) g x"
    ],
    correctIndex: 0,
    explanation: "Weight of resting chain is (M/L)gx. Force from destroying downward momentum is v(dm/dt) = √(2gx) * (M/L)√(2gx) = 2(M/L)gx. Net normal force = 1 + 2 = 3(M/L)gx.",
    hint: "Combine the static weight of the fallen chain with the momentum impact rate of the newly landing links."
  },

  // --- LEVEL 5: EXPERT / OLYMPIAD CHALLENGE (Expected Accuracy: 20%) ---
  {
    id: 'diff_q5_01',
    topicId: 'physics_electromagnetism',
    difficultyLevel: 5,
    itemDifficulty: 4.9,
    isChallengeVariant: true,
    text: "A conducting sphere of radius R is placed in an originally uniform electric field E₀. What is the surface charge density σ(θ) induced on the sphere at polar angle θ?",
    formulaOrCode: "\\sigma(\\theta) = 3 \\varepsilon_0 E_0 \\cos \\theta",
    options: [
      "3 ε₀ E₀ cos θ",
      "ε₀ E₀ cos θ",
      "2 ε₀ E₀ sin θ",
      "3/2 ε₀ E₀ cos² θ"
    ],
    correctIndex: 0,
    explanation: "Using Legendre polynomial boundary conditions on Laplace's equation: V(r, θ) = -E₀ r cos θ + (E₀ R³/r²) cos θ. Surface field E_r(R) = 3 E₀ cos θ, giving σ = ε₀ E_r = 3 ε₀ E₀ cos θ.",
    hint: "Solve Laplace's equation in spherical coordinates with dipole perturbation term R³/r²."
  },
  {
    id: 'diff_q5_02',
    topicId: 'physics_thermodynamics',
    difficultyLevel: 5,
    itemDifficulty: 5.0,
    isChallengeVariant: true,
    text: "One mole of an ideal monoatomic gas undergoes an open polytropic cycle where P V^n = constant. If the molar heat capacity during the process is C = -2 R, what is the polytropic index n?",
    formulaOrCode: "C = C_v + \\frac{R}{1 - n}",
    options: [
      "9/7 ≈ 1.285",
      "5/3 ≈ 1.667",
      "7/5 ≈ 1.400",
      "4/3 ≈ 1.333"
    ],
    correctIndex: 0,
    explanation: "C = C_v + R/(1 - n). For monoatomic gas, C_v = (3/2)R. Thus -2R = (3/2)R + R/(1 - n) => -7/2 = 1/(1 - n) => 1 - n = -2/7 => n = 1 + 2/7 = 9/7.",
    hint: "Use the general polytropic molar heat capacity equation: C = C_v + R / (1 - n)."
  }
];

export class QuestionFilter {
  private bank: QuestionCandidate[];

  constructor(customBank?: QuestionCandidate[]) {
    this.bank = customBank && customBank.length > 0 ? customBank : [...DEFAULT_QUESTION_BANK];
  }

  /**
   * Filters and selects the optimal question candidate according to DifficultyState
   */
  public filterNextQuestion(
    state: DifficultyState,
    answeredIds: string[] = []
  ): QuestionCandidate {
    const answeredSet = new Set(answeredIds);
    let pool = this.bank.filter(q => !answeredSet.has(q.id));

    // Fallback if all answered: allow repeats
    if (pool.length === 0) {
      pool = [...this.bank];
    }

    // 1. Frustration intervention: easier question
    if (state.intervention === 'easier_question') {
      const easyPool = pool.filter(q => q.difficultyLevel <= 2 || q.itemDifficulty <= state.fineDifficulty);
      if (easyPool.length > 0) {
        return easyPool.sort((a, b) => a.itemDifficulty - b.itemDifficulty)[0];
      }
    }

    // 2. Boredom intervention: harder challenge variant
    if (state.intervention === 'harder_variant') {
      const challengePool = pool.filter(q => q.isChallengeVariant || q.difficultyLevel >= 4);
      if (challengePool.length > 0) {
        return challengePool.sort((a, b) => b.itemDifficulty - a.itemDifficulty)[0];
      }
    }

    // 3. Normal Selection: items matching currentLevel or closest fineDifficulty
    const sameLevelCandidates = pool.filter(q => q.difficultyLevel === state.currentLevel);
    const candidates = sameLevelCandidates.length > 0 ? sameLevelCandidates : pool;

    // Pick candidate with minimum difference to fineDifficulty
    let best = candidates[0];
    let minDiff = Infinity;

    for (const item of candidates) {
      const diff = Math.abs(item.itemDifficulty - state.fineDifficulty);
      if (diff < minDiff) {
        minDiff = diff;
        best = item;
      }
    }

    return best;
  }
}
