/**
 * TokenClassifier
 * Analyzes streaming text to detect syntax tokens:
 * headings, math blocks, code fences, bold/italic, lists, and tables.
 */
export type TokenType =
  | 'heading'
  | 'bold'
  | 'italic'
  | 'code-inline'
  | 'code-block'
  | 'math-inline'
  | 'math-display'
  | 'list'
  | 'table'
  | 'link'
  | 'plain-text';

export interface TokenState {
  type: TokenType;
  isComplete: boolean;
  isStreaming: boolean;
  content: string;
  startIndex: number;
  endIndex: number;
}

export class TokenClassifier {
  /**
   * Classify all syntax tokens in the given text buffer.
   */
  classify(text: string): TokenState[] {
    const tokens: TokenState[] = [];

    // Headings
    tokens.push(...this.findHeadings(text));

    // Math Blocks
    tokens.push(...this.findMathTokens(text));

    // Code Blocks
    tokens.push(...this.findCodeTokens(text));

    // Bold / Italic
    tokens.push(...this.findEmphasisTokens(text));

    return tokens.sort((a, b) => a.startIndex - b.startIndex);
  }

  private findHeadings(text: string): TokenState[] {
    const tokens: TokenState[] = [];
    const regex = /(?:^|\n)(#{1,6})\s+([^\n]*)/g;
    let match;

    while ((match = regex.exec(text)) !== null) {
      const startIndex = match.index;
      const endIndex = startIndex + match[0].length;
      const isAtEnd = endIndex === text.length;

      tokens.push({
        type: 'heading',
        isComplete: !isAtEnd || text[endIndex] === '\n',
        isStreaming: isAtEnd,
        content: match[0],
        startIndex,
        endIndex,
      });
    }

    return tokens;
  }

  private findMathTokens(text: string): TokenState[] {
    const tokens: TokenState[] = [];

    // Display math ($$...$$)
    const displayRegex = /\$\$([\s\S]*?)\$\$/g;
    let match;
    while ((match = displayRegex.exec(text)) !== null) {
      tokens.push({
        type: 'math-display',
        isComplete: true,
        isStreaming: false,
        content: match[0],
        startIndex: match.index,
        endIndex: match.index + match[0].length,
      });
    }

    // Inline math ($...$)
    const inlineRegex = /(?<!\$)\$(?!\$)([^$\n]+?)\$(?!\$)/g;
    while ((match = inlineRegex.exec(text)) !== null) {
      tokens.push({
        type: 'math-inline',
        isComplete: true,
        isStreaming: false,
        content: match[0],
        startIndex: match.index,
        endIndex: match.index + match[0].length,
      });
    }

    return tokens;
  }

  private findCodeTokens(text: string): TokenState[] {
    const tokens: TokenState[] = [];

    // Code blocks
    const blockRegex = /```[\s\S]*?```/g;
    let match;
    while ((match = blockRegex.exec(text)) !== null) {
      tokens.push({
        type: 'code-block',
        isComplete: true,
        isStreaming: false,
        content: match[0],
        startIndex: match.index,
        endIndex: match.index + match[0].length,
      });
    }

    return tokens;
  }

  private findEmphasisTokens(text: string): TokenState[] {
    const tokens: TokenState[] = [];

    // Bold (**...**)
    const boldRegex = /\*\*([^*]+?)\*\*/g;
    let match;
    while ((match = boldRegex.exec(text)) !== null) {
      tokens.push({
        type: 'bold',
        isComplete: true,
        isStreaming: false,
        content: match[0],
        startIndex: match.index,
        endIndex: match.index + match[0].length,
      });
    }

    return tokens;
  }
}
