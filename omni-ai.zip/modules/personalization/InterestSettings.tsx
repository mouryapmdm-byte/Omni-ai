export * from '../../src/components/InterestSettings';
export { InterestSettings as default } from '../../src/components/InterestSettings';
