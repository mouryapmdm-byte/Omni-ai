export * from '../../src/components/PersonalizedPath';
export { PersonalizedPath as default } from '../../src/components/PersonalizedPath';
