import React, { useState } from 'react';
import { 
  Timer, 
  Zap, 
  Forward, 
  Activity, 
  Flame, 
  BarChart3, 
  Award, 
  CheckCircle2, 
  Sparkles,
  Play,
  RotateCcw,
  Clock
} from 'lucide-react';
import { SpeedRun } from '../modules/time-coach/SpeedRun';
import { SkipDrill } from '../modules/time-coach/SkipDrill';
import { TimeInsights } from '../modules/time-coach/TimeInsights';
import { TimeCoachSessionResult } from '../modules/time-coach/types';

interface TimeCoachHubProps {
  isDark?: boolean;
  theme?: string;
  studentId?: string;
  initialSubject?: string;
  onRewardXp?: (xp: number) => void;
  showNotification?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
}

export const TimeCoachHub: React.FC<TimeCoachHubProps> = ({
  isDark = true,
  theme,
  studentId = 'student_alex',
  onRewardXp,
  showNotification
}) => {
  const darkMode = theme ? theme === 'dark' : isDark;
  const [activeTab, setActiveTab] = useState<'insights' | 'speed_run' | 'rapid_fire' | 'skip_drill'>('insights');

  const handleFinishDrill = (result: TimeCoachSessionResult) => {
    const xpReward = result.accuracy >= 80 ? 150 : 75;
    onRewardXp?.(xpReward);
    showNotification?.(`⚡ Drill completed! +${xpReward} XP earned. Banked ${result.timeSavedSeconds}s of exam time!`, 'success');
  };

  return (
    <div className={`flex flex-col h-full ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>
      {/* Top Hub Navigation Bar */}
      <div className={`p-4 border-b flex flex-wrap items-center justify-between gap-4 ${
        darkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-amber-500/20">
            <Timer className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold">Exam Time Management & Speed Coach</h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                100ms Precision
              </span>
            </div>
            <p className="text-xs opacity-60">Master question pacing, eliminate time traps, and build 3-hour exam endurance</p>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className={`flex items-center p-1 rounded-xl border ${darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-100 border-slate-300'}`}>
          <button
            onClick={() => setActiveTab('insights')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'insights'
                ? 'bg-indigo-600 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Time Insights
          </button>

          <button
            onClick={() => setActiveTab('speed_run')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'speed_run'
                ? 'bg-amber-500 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            Speed Run (Half-Time)
          </button>

          <button
            onClick={() => setActiveTab('rapid_fire')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'rapid_fire'
                ? 'bg-orange-500 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            Rapid Fire Sprint
          </button>

          <button
            onClick={() => setActiveTab('skip_drill')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'skip_drill'
                ? 'bg-purple-600 text-white shadow'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <Forward className="w-3.5 h-3.5" />
            Skip Strategy Drill
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-6 overflow-y-auto">
        {activeTab === 'insights' && (
          <TimeInsights
            isDark={darkMode}
            studentId={studentId}
            onLaunchSpeedRun={() => setActiveTab('speed_run')}
            onLaunchSkipDrill={() => setActiveTab('skip_drill')}
          />
        )}

        {activeTab === 'speed_run' && (
          <div className="max-w-3xl mx-auto">
            <SpeedRun
              mode="speed_run"
              isDark={darkMode}
              onFinish={handleFinishDrill}
            />
          </div>
        )}

        {activeTab === 'rapid_fire' && (
          <div className="max-w-3xl mx-auto">
            <SpeedRun
              mode="rapid_fire"
              isDark={darkMode}
              onFinish={handleFinishDrill}
            />
          </div>
        )}

        {activeTab === 'skip_drill' && (
          <div className="max-w-3xl mx-auto">
            <SkipDrill
              isDark={darkMode}
              onFinish={handleFinishDrill}
            />
          </div>
        )}
      </div>
    </div>
  );
};
