import React, { useState, useRef, useEffect, useCallback } from "react";
import { 
  Pencil, 
  Eraser, 
  RotateCcw, 
  RotateCw, 
  Trash2, 
  Download, 
  Send, 
  Type, 
  Square, 
  Circle, 
  Maximize2, 
  Grid, 
  Sparkles, 
  Palette, 
  X, 
  Check, 
  Copy,
  Ruler,
  TrendingUp,
  Activity,
  Zap,
  HelpCircle,
  Users,
  Share2,
  Plus,
  RefreshCw,
  Layers,
  Compass,
  Volume2,
  BookOpen
} from 'lucide-react';
import { cn, sanitizeLatex, safeKatexOptions } from "@/src/lib/utils";
import { doc, onSnapshot, setDoc, updateDoc } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { generateAIResponse } from "@/src/lib/gemini";
import katex from "katex";

export interface CollaborativeWhiteboardProps {
  isOpen?: boolean;
  onClose?: () => void;
  onSendToBoard?: (content: string) => void;
  theme?: 'light' | 'dark';
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  currentTopic?: string;
  className?: string;
}

type ToolMode = 'pen' | 'highlighter' | 'eraser' | 'line' | 'arrow' | 'axes' | 'circle' | 'rectangle' | 'text' | 'formula' | 'parabola';
type CanvasBackground = 'chalkboard' | 'grid' | 'blue-grid' | 'dot-grid' | 'white';

interface Point {
  x: number;
  y: number;
}

interface StrokePath {
  id: string;
  tool: ToolMode;
  points: Point[];
  color: string;
  size: number;
  startPoint?: Point;
  endPoint?: Point;
}

interface PlacedFormula {
  id: string;
  latex: string;
  x: number;
  y: number;
  color: string;
  fontSize: number;
  label?: string;
}

interface Participant {
  id: string;
  name: string;
  role: string;
  color: string;
  active: boolean;
  isHost?: boolean;
}

const PRESET_MATH_FORMULAS = [
  { label: 'Gaussian Integral', latex: '\\int_{-\\infty}^{\\infty} e^{-x^2} dx = \\sqrt{\\pi}' },
  { label: 'Quadratic Formula', latex: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}' },
  { label: 'Euler\'s Identity', latex: 'e^{i\\pi} + 1 = 0' },
  { label: 'Schrödinger Eq.', latex: 'i\\hbar \\frac{\\partial}{\\partial t}\\Psi = \\hat{H}\\Psi' },
  { label: 'Maxwell\'s Eq.', latex: '\\nabla \\cdot \\mathbf{E} = \\frac{\\rho}{\\epsilon_0}' },
  { label: 'Derivative Def.', latex: 'f\'(x) = \\lim_{h \\to 0} \\frac{f(x+h) - f(x)}{h}' },
  { label: 'Trig Identity', latex: '\\sin^2(\\theta) + \\cos^2(\\theta) = 1' },
  { label: 'Einstein Rel.', latex: 'E = m c^2' },
];

const QUICK_MATH_SYMBOLS = [
  'π', '∑', '∫', '√', 'θ', '∞', 'Δ', 'α', 'β', '±', '≠', '≈', '≤', '≥', '∈', 'f(x)', 'dy/dx', 'x²', 'x³', '∠', 'λ', 'ω', 'ℏ', '∇'
];

const COLOR_PALETTE = [
  { name: 'Chalk White', hex: '#FFFFFF', bgClass: 'bg-white' },
  { name: 'Golden Yellow', hex: '#FACC15', bgClass: 'bg-yellow-400' },
  { name: 'Cyan Electric', hex: '#38BDF8', bgClass: 'bg-sky-400' },
  { name: 'Emerald Math', hex: '#34D399', bgClass: 'bg-emerald-400' },
  { name: 'Vibrant Rose', hex: '#FB7185', bgClass: 'bg-rose-400' },
  { name: 'Purple Proof', hex: '#C084FC', bgClass: 'bg-purple-400' },
  { name: 'Bright Orange', hex: '#FB923C', bgClass: 'bg-orange-400' },
  { name: 'Obsidian Dark', hex: '#0F172A', bgClass: 'bg-slate-900' },
];

const STUDY_ROOMS = [
  { id: 'default_session', name: 'General Classroom Board', topic: 'Interactive STEM Study' },
  { id: 'room_physics_3d', name: 'Physics & Laser Lab', topic: 'Quantum Mechanics & Optics' },
  { id: 'room_calculus_adv', name: 'Calculus & Proofs Group', topic: 'Multivariable Integration' },
  { id: 'room_chemistry_lab', name: 'Molecular Chemistry Room', topic: 'Chemical Kinetics & Bonding' },
];

export const CollaborativeWhiteboard: React.FC<CollaborativeWhiteboardProps> = ({
  isOpen = true,
  onClose,
  onSendToBoard,
  theme = 'dark',
  showNotification,
  currentTopic = 'Stem Collaborative Study',
  className = ""
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Room & State Management
  const [activeRoomId, setActiveRoomId] = useState<string>('default_session');
  const [tool, setTool] = useState<ToolMode>('pen');
  const [strokeColor, setStrokeColor] = useState<string>('#FFFFFF');
  const [strokeWidth, setStrokeWidth] = useState<number>(3);
  const [background, setBackground] = useState<CanvasBackground>('chalkboard');

  // Board Data
  const [strokes, setStrokes] = useState<StrokePath[]>([]);
  const [formulas, setFormulas] = useState<PlacedFormula[]>([]);
  const [undoStack, setUndoStack] = useState<StrokePath[]>([]);
  const [redoStack, setRedoStack] = useState<StrokePath[]>([]);

  // Drawing Refs
  const isDrawing = useRef<boolean>(false);
  const currentPathRef = useRef<StrokePath | null>(null);

  // Math Inserter Modal / Input
  const [latexInput, setLatexInput] = useState<string>('\\int_{0}^{1} x^2 dx = \\frac{1}{3}');
  const [customText, setCustomText] = useState<string>('');
  const [isInsertingFormula, setIsInsertingFormula] = useState<boolean>(false);
  const [formulaPreviewHtml, setFormulaPreviewHtml] = useState<string>('');

  // Remote Study Participants
  const [participants, setParticipants] = useState<Participant[]>([
    { id: 'user-1', name: 'You (Alex M.)', role: 'Student Host', color: '#38BDF8', active: true, isHost: true },
    { id: 'user-2', name: 'Prof. Quantum', role: 'AI Tutor', color: '#C084FC', active: true },
    { id: 'user-3', name: 'Maya S.', role: 'Peer Collaborator', color: '#34D399', active: true },
    { id: 'user-4', name: 'Liam T.', role: 'Study Partner', color: '#FACC15', active: false },
  ]);

  // AI Math Analysis State
  const [isAnalyzingAi, setIsAnalyzingAi] = useState<boolean>(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<string | null>(null);
  const [showAiModal, setShowAiModal] = useState<boolean>(false);

  // Render KaTeX Preview when latexInput changes
  useEffect(() => {
    if (!latexInput.trim()) {
      setFormulaPreviewHtml('');
      return;
    }
    try {
      const cleanInput = sanitizeLatex(latexInput);
      const html = katex.renderToString(cleanInput, { ...safeKatexOptions, displayMode: true });
      setFormulaPreviewHtml(html);
    } catch (err) {
      setFormulaPreviewHtml(`<span class="text-rose-400 font-mono text-xs">Invalid LaTeX Expression</span>`);
    }
  }, [latexInput]);

  // Real-time Firestore Synchronization for Active Room
  useEffect(() => {
    let unsubscribe: () => void;
    try {
      const docRef = doc(db, "whiteboard_sessions", activeRoomId);
      unsubscribe = onSnapshot(docRef, (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.strokes) setStrokes(data.strokes);
          if (data.formulas) setFormulas(data.formulas);
        }
      }, (error) => {
        console.warn("Firestore sync error (using local memory fallback):", error);
      });
    } catch (err) {
      console.warn("Firestore listener initialization failed:", err);
    }
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [activeRoomId]);

  // Save strokes and formulas to Firestore (or local state)
  const saveBoardData = async (updatedStrokes: StrokePath[], updatedFormulas: PlacedFormula[]) => {
    setStrokes(updatedStrokes);
    setFormulas(updatedFormulas);
    try {
      const docRef = doc(db, "whiteboard_sessions", activeRoomId);
      await setDoc(docRef, {
        id: activeRoomId,
        strokes: updatedStrokes,
        formulas: updatedFormulas,
        updatedAt: Date.now(),
        topic: currentTopic
      }, { merge: true });
    } catch (err) {
      // Local fallback silently maintains state
    }
  };

  // Canvas Drawing Redraw Engine
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // 1. Draw Background
    ctx.clearRect(0, 0, width, height);

    if (background === 'chalkboard') {
      ctx.fillStyle = '#061a12'; // Deep matte slate/chalkboard green
      ctx.fillRect(0, 0, width, height);
      
      // Subtle chalk grain texture
      ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
      for (let i = 0; i < 400; i++) {
        ctx.fillRect((i * 37) % width, (i * 91) % height, 2, 2);
      }
    } else if (background === 'white') {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, width, height);
    } else if (background === 'grid' || background === 'blue-grid') {
      ctx.fillStyle = background === 'blue-grid' ? '#0f172a' : '#090d16';
      ctx.fillRect(0, 0, width, height);

      const gridSize = 30;
      ctx.strokeStyle = background === 'blue-grid' ? 'rgba(56, 189, 248, 0.15)' : 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1;

      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }
    } else if (background === 'dot-grid') {
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, width, height);

      const gridSize = 25;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      for (let x = gridSize; x < width; x += gridSize) {
        for (let y = gridSize; y < height; y += gridSize) {
          ctx.beginPath();
          ctx.arc(x, y, 1.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    // 2. Render Strokes
    strokes.forEach((stroke) => {
      ctx.save();
      ctx.strokeStyle = stroke.color;
      ctx.fillStyle = stroke.color;
      ctx.lineWidth = stroke.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (stroke.tool === 'highlighter') {
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = stroke.size * 3.5;
      } else {
        ctx.globalAlpha = 1.0;
      }

      if (stroke.tool === 'eraser') {
        ctx.strokeStyle = background === 'chalkboard' ? '#061a12' : background === 'white' ? '#FFFFFF' : '#090d16';
        ctx.lineWidth = stroke.size * 4;
      }

      if (stroke.tool === 'pen' || stroke.tool === 'highlighter' || stroke.tool === 'eraser') {
        if (stroke.points.length > 0) {
          ctx.beginPath();
          ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
          for (let i = 1; i < stroke.points.length; i++) {
            ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
          }
          ctx.stroke();
        }
      } else if (stroke.startPoint && stroke.endPoint) {
        const { x: sx, y: sy } = stroke.startPoint;
        const { x: ex, y: ey } = stroke.endPoint;

        ctx.beginPath();
        if (stroke.tool === 'line') {
          ctx.moveTo(sx, sy);
          ctx.lineTo(ex, ey);
          ctx.stroke();
        } else if (stroke.tool === 'arrow') {
          ctx.moveTo(sx, sy);
          ctx.lineTo(ex, ey);
          ctx.stroke();
          
          // Draw Arrowhead
          const angle = Math.atan2(ey - sy, ex - sx);
          const headLen = stroke.size * 3.5 + 8;
          ctx.beginPath();
          ctx.moveTo(ex, ey);
          ctx.lineTo(ex - headLen * Math.cos(angle - Math.PI / 6), ey - headLen * Math.sin(angle - Math.PI / 6));
          ctx.lineTo(ex - headLen * Math.cos(angle + Math.PI / 6), ey - headLen * Math.sin(angle + Math.PI / 6));
          ctx.closePath();
          ctx.fill();
        } else if (stroke.tool === 'rectangle') {
          ctx.strokeRect(sx, sy, ex - sx, ey - sy);
        } else if (stroke.tool === 'circle') {
          const radius = Math.hypot(ex - sx, ey - sy);
          ctx.arc(sx, sy, radius, 0, Math.PI * 2);
          ctx.stroke();
        } else if (stroke.tool === 'axes') {
          // Draw Cartesian Axes
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.lineWidth = 1.5;
          
          // X-Axis
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(ex, sy);
          ctx.stroke();

          // Y-Axis
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(sx, ey);
          ctx.stroke();

          // Labels
          ctx.font = '12px Inter, sans-serif';
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.fillText('X', ex + 5, sy + 4);
          ctx.fillText('Y', sx - 4, ey - 6);
        } else if (stroke.tool === 'parabola') {
          // Draw Quadratic Parabola Curve
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          const controlX = (sx + ex) / 2;
          const controlY = Math.min(sy, ey) - 80;
          ctx.quadraticCurveTo(controlX, controlY, ex, ey);
          ctx.stroke();
        }
      }
      ctx.restore();
    });
  }, [strokes, background]);

  // Adjust canvas crisp resolution on mount & resize
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const resizeCanvas = () => {
      const rect = container.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        canvas.width = rect.width;
        canvas.height = rect.height;
        redrawCanvas();
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    return () => window.removeEventListener('resize', resizeCanvas);
  }, [redrawCanvas]);

  useEffect(() => {
    redrawCanvas();
  }, [strokes, background, redrawCanvas]);

  // Get Relative Mouse/Touch Coordinates
  const getCanvasPos = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    if ('touches' in e) {
      const touch = e.touches[0];
      return {
        x: touch.clientX - rect.left,
        y: touch.clientY - rect.top
      };
    } else {
      return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };
    }
  };

  // Drawing Event Handlers
  const handleStartDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    isDrawing.current = true;
    const pos = getCanvasPos(e);

    const newStroke: StrokePath = {
      id: `stroke-${Date.now()}-${Math.random()}`,
      tool,
      points: [pos],
      color: strokeColor,
      size: strokeWidth,
      startPoint: pos,
      endPoint: pos
    };

    currentPathRef.current = newStroke;
    setStrokes(prev => [...prev, newStroke]);
  };

  const handleMoveDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current || !currentPathRef.current) return;
    const pos = getCanvasPos(e);

    if (tool === 'pen' || tool === 'highlighter' || tool === 'eraser') {
      currentPathRef.current.points.push(pos);
      setStrokes(prev => [...prev.slice(0, -1), { ...currentPathRef.current! }]);
    } else {
      currentPathRef.current.endPoint = pos;
      setStrokes(prev => [...prev.slice(0, -1), { ...currentPathRef.current! }]);
    }
  };

  const handleEndDraw = () => {
    if (!isDrawing.current) return;
    isDrawing.current = false;
    
    if (currentPathRef.current) {
      const updatedStrokes = [...strokes];
      saveBoardData(updatedStrokes, formulas);
      setUndoStack([...strokes]);
      setRedoStack([]);
    }
    currentPathRef.current = null;
  };

  // Insert Placed Formula onto Canvas
  const handleInsertFormulaToBoard = () => {
    if (!latexInput.trim()) return;

    const newFormula: PlacedFormula = {
      id: `formula-${Date.now()}`,
      latex: latexInput,
      x: Math.random() * 200 + 80,
      y: Math.random() * 150 + 100,
      color: strokeColor === '#0F172A' ? '#FFFFFF' : strokeColor,
      fontSize: 18
    };

    const updatedFormulas = [...formulas, newFormula];
    saveBoardData(strokes, updatedFormulas);
    setIsInsertingFormula(false);
    showNotification?.("Live Math Formula inserted onto Whiteboard!", "success");
  };

  // Remove Formula
  const handleRemoveFormula = (id: string) => {
    const updatedFormulas = formulas.filter(f => f.id !== id);
    saveBoardData(strokes, updatedFormulas);
  };

  // Clear Whiteboard
  const handleClearBoard = () => {
    if (confirm("Are you sure you want to clear all drawing strokes and formulas on this board?")) {
      saveBoardData([], []);
      showNotification?.("Whiteboard cleared", "info");
    }
  };

  // Undo / Redo
  const handleUndo = () => {
    if (strokes.length === 0) return;
    const last = strokes[strokes.length - 1];
    setRedoStack(prev => [last, ...prev]);
    const updated = strokes.slice(0, -1);
    saveBoardData(updated, formulas);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[0];
    setRedoStack(prev => prev.slice(1));
    const updated = [...strokes, next];
    saveBoardData(updated, formulas);
  };

  // AI Formula / Board Analysis via Gemini
  const handleAnalyzeBoardWithAi = async () => {
    setIsAnalyzingAi(true);
    setShowAiModal(true);

    const formulasText = formulas.map(f => f.latex).join(' ; ');
    const prompt = `You are an expert STEM professor inspecting a collaborative study whiteboard.
Current Study Topic: ${currentTopic}
Formulas on Board: ${formulasText || 'Geometric shapes, axes, and calculus sketches.'}
Strokes Count: ${strokes.length}

Provide a concise, high-yield mathematical breakdown:
1. **Mathematical Concepts & Formulas Identified**: Explain what these formulas represent.
2. **Step-by-Step Proof or Solution**: Show how to compute or solve them.
3. **Key Insights for Remote Study**: 2-3 key takeaways for students.`;

    try {
      const response = await generateAIResponse(prompt, { systemInstruction: "Provide clear markdown math explanations." });
      setAiAnalysisResult(response);
      showNotification?.("AI Whiteboard Math Analysis complete!", "success");
    } catch (err) {
      setAiAnalysisResult("Unable to analyze board math at this moment. Please check network connection.");
    } finally {
      setIsAnalyzingAi(false);
    }
  };

  // Export Board Image as PNG
  const handleDownloadBoardImage = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Create a temporary canvas to render both strokes AND math formulas for export
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = canvas.width;
    exportCanvas.height = canvas.height;
    const ctx = exportCanvas.getContext('2d');
    if (!ctx) return;

    // Draw main canvas
    ctx.drawImage(canvas, 0, 0);

    // Draw formulas as text overlay onto export canvas
    formulas.forEach((f) => {
      ctx.font = '16px "KaTeX_Main", serif, sans-serif';
      ctx.fillStyle = f.color;
      ctx.fillText(f.latex, f.x, f.y);
    });

    const url = exportCanvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `3D-Classroom-Whiteboard-${activeRoomId}.png`;
    link.href = url;
    link.click();
    showNotification?.("Whiteboard PNG exported successfully!", "success");
  };

  // Send Board Content to 3D Classroom Smartboard
  const handleSendToClassroomBoard = () => {
    const formulasText = formulas.map(f => `$$${f.latex}$$`).join('\n\n');
    const contentToSend = `### 🖊️ Collaborative Study Whiteboard Snapshot\n**Room:** ${activeRoomId.replace('_', ' ').toUpperCase()} | **Topic:** ${currentTopic}\n\n${formulasText || '*Drawing strokes & geometric derivations active on board*'}\n\n*Synced live across remote study session participants.*`;
    
    if (onSendToBoard) {
      onSendToBoard(contentToSend);
      showNotification?.("Whiteboard formulas & drawings projected onto 3D Presentation Board!", "success");
    }
  };

  if (!isOpen) return null;

  return (
    <div className={cn(
      "flex flex-col bg-slate-950/95 border border-indigo-500/30 rounded-3xl shadow-2xl backdrop-blur-2xl overflow-hidden w-full h-full text-slate-100",
      className
    )}>
      
      {/* HEADER TOOLBAR & SESSION CONTROLS */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800/80 bg-slate-900/90 shrink-0 gap-2 flex-wrap">
        
        {/* Left: Room & Topic Badge */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-indigo-950/80 border border-indigo-500/40 px-3 py-1.5 rounded-2xl shadow-sm">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs font-black uppercase tracking-wider text-indigo-300">
              Live Whiteboard
            </span>
          </div>

          {/* Room Selector Dropdown */}
          <select
            value={activeRoomId}
            onChange={(e) => {
              setActiveRoomId(e.target.value);
              showNotification?.(`Joined Whiteboard Session: ${e.target.value}`, 'info');
            }}
            className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1 text-xs text-slate-200 font-bold focus:outline-none focus:border-indigo-500 cursor-pointer"
          >
            {STUDY_ROOMS.map((room) => (
              <option key={room.id} value={room.id}>
                {room.name} ({room.topic})
              </option>
            ))}
          </select>
        </div>

        {/* Center: Remote Study Participants Indicator */}
        <div className="hidden lg:flex items-center gap-2 bg-slate-950/80 border border-slate-800/80 px-3 py-1 rounded-2xl">
          <Users size={14} className="text-indigo-400 shrink-0" />
          <span className="text-[11px] font-bold text-slate-400">Remote Study Peers:</span>
          <div className="flex items-center -space-x-1.5">
            {participants.map((p) => (
              <div
                key={p.id}
                className="w-5 h-5 rounded-full border border-slate-900 flex items-center justify-center text-[9px] font-black text-slate-950 shadow-sm"
                style={{ backgroundColor: p.color }}
                title={`${p.name} (${p.role}) - ${p.active ? 'Active Now' : 'Away'}`}
              >
                {p.name.charAt(0)}
              </div>
            ))}
          </div>
        </div>

        {/* Right: Actions (AI Math Analyzer, Project to 3D, Download, Close) */}
        <div className="flex items-center gap-2">
          
          {/* AI Math Formulas Analyzer */}
          <button
            onClick={handleAnalyzeBoardWithAi}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-all cursor-pointer border border-indigo-400/30"
            title="Analyze board formulas and sketches with Gemini AI"
          >
            <Sparkles size={13} className="animate-spin text-amber-300" />
            <span className="hidden sm:inline">AI Math Solver</span>
          </button>

          {/* Project to 3D Smartboard */}
          <button
            onClick={handleSendToClassroomBoard}
            className="px-3 py-1.5 rounded-xl bg-indigo-950 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Project whiteboard formulas onto the Virtual Learning Presentation Smartboard"
          >
            <Send size={13} />
            <span className="hidden md:inline">Project to 3D Board</span>
          </button>

          {/* Export PNG */}
          <button
            onClick={handleDownloadBoardImage}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer border border-slate-700"
            title="Download Whiteboard PNG"
          >
            <Download size={14} />
          </button>

          {/* Close Button */}
          {onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer border border-slate-700"
              title="Close Whiteboard"
            >
              <X size={15} />
            </button>
          )}
        </div>
      </div>

      {/* SECONDARY TOOLBAR: Drawing Tools, Shapes, Colors, Math Formula Inserter */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/60 bg-slate-900/60 shrink-0 gap-2 flex-wrap">
        
        {/* Drawing Tools Group */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800">
          <button
            onClick={() => setTool('pen')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'pen' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-400 hover:text-white")}
            title="Freehand Chalk Pen"
          >
            <Pencil size={15} />
          </button>

          <button
            onClick={() => setTool('highlighter')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'highlighter' ? "bg-amber-500 text-slate-950 font-bold shadow-sm" : "text-slate-400 hover:text-white")}
            title="Fluorescent Highlighter"
          >
            <Zap size={15} />
          </button>

          <button
            onClick={() => setTool('eraser')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'eraser' ? "bg-rose-600 text-white shadow-sm" : "text-slate-400 hover:text-white")}
            title="Board Eraser"
          >
            <Eraser size={15} />
          </button>

          <div className="w-px h-5 bg-slate-800 mx-1" />

          {/* Shapes */}
          <button
            onClick={() => setTool('line')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'line' ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white")}
            title="Straight Line"
          >
            <Ruler size={15} />
          </button>

          <button
            onClick={() => setTool('arrow')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'arrow' ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white")}
            title="Vector Arrow"
          >
            <TrendingUp size={15} />
          </button>

          <button
            onClick={() => setTool('axes')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'axes' ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white")}
            title="Coordinate Axes (X-Y)"
          >
            <Compass size={15} />
          </button>

          <button
            onClick={() => setTool('parabola')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'parabola' ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white")}
            title="Function Parabola Curve"
          >
            <Activity size={15} />
          </button>

          <button
            onClick={() => setTool('rectangle')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'rectangle' ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white")}
            title="Rectangle / Box"
          >
            <Square size={15} />
          </button>

          <button
            onClick={() => setTool('circle')}
            className={cn("p-2 rounded-xl transition-all cursor-pointer", tool === 'circle' ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white")}
            title="Circle"
          >
            <Circle size={15} />
          </button>
        </div>

        {/* Color Palette Picker */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
          {COLOR_PALETTE.map((c) => (
            <button
              key={c.name}
              onClick={() => setStrokeColor(c.hex)}
              className={cn(
                "w-5 h-5 rounded-full transition-all cursor-pointer border border-slate-700/80 hover:scale-110",
                c.bgClass,
                strokeColor === c.hex ? "ring-2 ring-indigo-400 ring-offset-2 ring-offset-slate-950 scale-110" : ""
              )}
              title={c.name}
            />
          ))}
        </div>

        {/* Stroke Size Slider */}
        <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-2xl border border-slate-800">
          <span className="text-[10px] font-mono text-slate-400">Size: {strokeWidth}px</span>
          <input
            type="range"
            min="1"
            max="14"
            value={strokeWidth}
            onChange={(e) => setStrokeWidth(Number(e.target.value))}
            className="w-16 accent-indigo-500 cursor-pointer"
          />
        </div>

        {/* Background Canvas Selector */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800">
          <button
            onClick={() => setBackground('chalkboard')}
            className={cn("px-2 py-1 rounded-xl text-[10px] font-bold transition-all cursor-pointer", background === 'chalkboard' ? "bg-emerald-900 text-emerald-200 border border-emerald-500/40" : "text-slate-400 hover:text-white")}
            title="Green Chalkboard"
          >
            Chalkboard
          </button>
          <button
            onClick={() => setBackground('grid')}
            className={cn("px-2 py-1 rounded-xl text-[10px] font-bold transition-all cursor-pointer", background === 'grid' ? "bg-indigo-900 text-indigo-200 border border-indigo-500/40" : "text-slate-400 hover:text-white")}
            title="Coordinate Grid"
          >
            Grid
          </button>
          <button
            onClick={() => setBackground('dot-grid')}
            className={cn("px-2 py-1 rounded-xl text-[10px] font-bold transition-all cursor-pointer", background === 'dot-grid' ? "bg-indigo-900 text-indigo-200 border border-indigo-500/40" : "text-slate-400 hover:text-white")}
            title="Dot Grid"
          >
            Dots
          </button>
          <button
            onClick={() => setBackground('white')}
            className={cn("px-2 py-1 rounded-xl text-[10px] font-bold transition-all cursor-pointer", background === 'white' ? "bg-white text-slate-950" : "text-slate-400 hover:text-white")}
            title="White Paper"
          >
            White
          </button>
        </div>

        {/* Undo, Redo, Clear */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800">
          <button
            onClick={handleUndo}
            disabled={strokes.length === 0}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white disabled:opacity-30 cursor-pointer"
            title="Undo stroke"
          >
            <RotateCcw size={14} />
          </button>
          <button
            onClick={handleRedo}
            disabled={redoStack.length === 0}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white disabled:opacity-30 cursor-pointer"
            title="Redo stroke"
          >
            <RotateCw size={14} />
          </button>
          <button
            onClick={handleClearBoard}
            className="p-1.5 rounded-xl text-rose-400 hover:text-rose-200 hover:bg-rose-950/60 transition-colors cursor-pointer"
            title="Clear Board"
          >
            <Trash2 size={14} />
          </button>
        </div>

        {/* Live Math Formula Inserter Button */}
        <button
          onClick={() => setIsInsertingFormula(!isInsertingFormula)}
          className={cn(
            "px-3 py-1.5 rounded-2xl text-xs font-bold flex items-center gap-1.5 border transition-all cursor-pointer",
            isInsertingFormula ? "bg-indigo-600 text-white border-indigo-400" : "bg-slate-950 text-indigo-300 border-indigo-500/40 hover:bg-slate-900"
          )}
        >
          <BookOpen size={14} />
          <span>+ Insert Math Formula</span>
        </button>
      </div>

      {/* FORMULA INSERTER PANEL */}
      {isInsertingFormula && (
        <div className="px-4 py-3 border-b border-indigo-500/30 bg-slate-900/95 flex flex-col gap-2.5 animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black uppercase tracking-wider text-indigo-300 flex items-center gap-2">
              <Sparkles size={14} className="text-amber-400" /> Live Mathematical Formula & Equation Inserter
            </span>
            <button onClick={() => setIsInsertingFormula(false)} className="text-slate-400 hover:text-white">
              <X size={14} />
            </button>
          </div>

          {/* Quick Symbol Toolbar */}
          <div className="flex items-center gap-1 flex-wrap">
            <span className="text-[10px] text-slate-400 font-bold uppercase mr-1">Symbols:</span>
            {QUICK_MATH_SYMBOLS.map((sym) => (
              <button
                key={sym}
                onClick={() => setLatexInput(prev => prev + ' ' + sym)}
                className="px-2 py-1 rounded-lg bg-slate-950 hover:bg-indigo-900 border border-slate-800 text-xs font-mono text-indigo-300 hover:text-white cursor-pointer"
              >
                {sym}
              </button>
            ))}
          </div>

          {/* Preset Formulas Picker */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase mr-1 shrink-0">Presets:</span>
            {PRESET_MATH_FORMULAS.map((f) => (
              <button
                key={f.label}
                onClick={() => setLatexInput(f.latex)}
                className="px-2.5 py-1 rounded-xl bg-indigo-950/60 hover:bg-indigo-900 border border-indigo-500/30 text-[11px] text-indigo-200 hover:text-white font-medium shrink-0 cursor-pointer"
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* LaTeX Input & Live KaTeX Preview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">LaTeX Expression:</label>
              <textarea
                value={latexInput}
                onChange={(e) => setLatexInput(e.target.value)}
                placeholder="Type LaTeX expression e.g. \int_{0}^{\infty} f(x) dx"
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">Rendered KaTeX Preview:</label>
              <div 
                className="w-full h-full min-h-[50px] bg-slate-950 border border-indigo-500/30 rounded-xl p-2.5 flex items-center justify-center text-white overflow-x-auto"
                dangerouslySetInnerHTML={{ __html: formulaPreviewHtml }}
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleInsertFormulaToBoard}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Plus size={14} />
              <span>Place Formula on Whiteboard</span>
            </button>
          </div>
        </div>
      )}

      {/* MAIN CANVAS AREA */}
      <div 
        ref={containerRef} 
        className="relative flex-1 w-full h-full min-h-[420px] overflow-hidden cursor-crosshair select-none"
      >
        <canvas
          ref={canvasRef}
          onMouseDown={handleStartDraw}
          onMouseMove={handleMoveDraw}
          onMouseUp={handleEndDraw}
          onMouseLeave={handleEndDraw}
          onTouchStart={handleStartDraw}
          onTouchMove={handleMoveDraw}
          onTouchEnd={handleEndDraw}
          className="absolute inset-0 w-full h-full touch-none"
        />

        {/* OVERLAY PLACED FORMULAS */}
        {formulas.map((f) => (
          <div
            key={f.id}
            style={{ left: f.x, top: f.y, color: f.color }}
            className="absolute p-2 bg-slate-950/80 border border-indigo-500/40 rounded-xl shadow-xl backdrop-blur-md cursor-move group flex items-center gap-2 border-dashed hover:border-solid hover:border-indigo-400"
          >
            <div 
              className="text-base select-none"
              dangerouslySetInnerHTML={{ 
                __html: katex.renderToString(sanitizeLatex(f.latex), { ...safeKatexOptions, displayMode: true }) 
              }}
            />
            <button
              onClick={() => handleRemoveFormula(f.id)}
              className="p-1 rounded-lg bg-rose-950 text-rose-300 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-rose-900 cursor-pointer"
              title="Remove Formula"
            >
              <X size={12} />
            </button>
          </div>
        ))}
      </div>

      {/* FOOTER STATUS BAR */}
      <div className="px-4 py-2 border-t border-slate-800/80 bg-slate-900/90 flex items-center justify-between text-[11px] text-slate-400 shrink-0">
        <div className="flex items-center gap-3">
          <span>Strokes: <strong className="text-indigo-300 font-mono">{strokes.length}</strong></span>
          <span>Formulas: <strong className="text-amber-300 font-mono">{formulas.length}</strong></span>
          <span>Room: <strong className="text-emerald-300 font-mono">{activeRoomId}</strong></span>
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden sm:inline">Collaborative Remote Study Active</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
        </div>
      </div>

      {/* AI MATH ANALYSIS MODAL */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-3xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto shadow-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles size={18} className="text-amber-400 animate-spin" />
                <h3 className="text-base font-bold text-white">Gemini AI Whiteboard Math Analysis</h3>
              </div>
              <button onClick={() => setShowAiModal(false)} className="text-slate-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            {isAnalyzingAi ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3 text-slate-400">
                <RefreshCw size={24} className="animate-spin text-indigo-400" />
                <span className="text-xs font-bold">Analyzing whiteboard formulas, equations & derivations...</span>
              </div>
            ) : (
              <div className="prose prose-invert prose-sm max-w-none text-slate-200">
                <div className="whitespace-pre-wrap font-sans text-xs leading-relaxed">
                  {aiAnalysisResult}
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowAiModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold cursor-pointer"
              >
                Close Analysis
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
