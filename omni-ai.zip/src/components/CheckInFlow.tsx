import React, { useState } from 'react';
import { 
  X, CheckCircle2, Flame, Clock, BookOpen, Smile, Send, Zap, Award
} from 'lucide-react';
import { cn } from '../lib/utils';
import { StudyBuddyMatch } from '../modules/study-buddies/types';
import { StudyBuddyService } from '../modules/study-buddies/studyBuddyService';

interface CheckInFlowProps {
  match: StudyBuddyMatch;
  isDark?: boolean;
  onClose: () => void;
  onCheckInComplete: () => void;
}

export const CheckInFlow: React.FC<CheckInFlowProps> = ({
  match,
  isDark = true,
  onClose,
  onCheckInComplete,
}) => {
  const partner = match.partnerProfile;
  const [studiedToday, setStudiedToday] = useState<boolean>(true);
  const [minutesStudied, setMinutesStudied] = useState<number>(60);
  const [topicsCovered, setTopicsCovered] = useState<string[]>(
    match.sharedGoal?.targetTopics.slice(0, 2) || ['Concept Derivations', 'Numerical Practice']
  );
  const [customTopic, setCustomTopic] = useState<string>('');
  const [reflectionNote, setReflectionNote] = useState<string>('');
  const [mood, setMood] = useState<'fired_up' | 'steady' | 'tired' | 'stuck'>('fired_up');
  const [submitted, setSubmitted] = useState<boolean>(false);

  const predefinedTopics = [
    'Electrostatics', 'Gauss Law', 'Electric Field', 'Capacitors',
    'Current Electricity', 'Kirchhoff Laws', 'Magnetism', 'Wave Optics',
    'Chemical Kinetics', 'Organic Mechanisms', 'Calculus', 'Vectors'
  ];

  const toggleTopic = (t: string) => {
    if (topicsCovered.includes(t)) {
      setTopicsCovered(topicsCovered.filter(item => item !== t));
    } else {
      setTopicsCovered([...topicsCovered, t]);
    }
  };

  const handleAddCustomTopic = () => {
    if (customTopic.trim() && !topicsCovered.includes(customTopic.trim())) {
      setTopicsCovered([...topicsCovered, customTopic.trim()]);
      setCustomTopic('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    StudyBuddyService.submitCheckIn(
      match.id,
      studiedToday,
      minutesStudied,
      topicsCovered,
      reflectionNote,
      mood
    );
    setSubmitted(true);
    setTimeout(() => {
      onCheckInComplete();
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className={cn(
        "w-full max-w-lg rounded-2xl border shadow-2xl p-5 sm:p-6 transition-all animate-in fade-in zoom-in-95",
        isDark ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-800"
      )}>
        {/* Header */}
        <div className="flex items-center justify-between border-b pb-4 mb-4 border-slate-700/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white font-bold shadow-lg shadow-amber-500/20">
              <Flame size={20} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">Daily Study Check-in</h2>
              <p className="text-xs text-slate-400">
                Accountability partner: <span className="font-semibold text-amber-400">{partner?.alias || 'Your Study Buddy'}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {submitted ? (
          <div className="py-10 text-center flex flex-col items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mb-3 animate-bounce">
              <CheckCircle2 size={32} />
            </div>
            <h3 className="text-lg font-bold text-emerald-400">Check-In Broadcasted!</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">
              Your study stats and streak have been recorded and shared to your buddy thread.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Did you study prompt */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Did you study today?
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setStudiedToday(true)}
                  className={cn(
                    "p-3 rounded-xl border flex items-center justify-center gap-2 font-bold text-sm transition cursor-pointer",
                    studiedToday
                      ? "bg-emerald-600/20 border-emerald-500 text-emerald-400 shadow-md shadow-emerald-500/10"
                      : isDark ? "bg-slate-800/40 border-slate-700 text-slate-400 hover:bg-slate-800" : "bg-slate-100 border-slate-200 text-slate-600"
                  )}
                >
                  <Zap size={16} /> Yes, I Studied!
                </button>
                <button
                  type="button"
                  onClick={() => setStudiedToday(false)}
                  className={cn(
                    "p-3 rounded-xl border flex items-center justify-center gap-2 font-bold text-sm transition cursor-pointer",
                    !studiedToday
                      ? "bg-amber-600/20 border-amber-500 text-amber-400 shadow-md shadow-amber-500/10"
                      : isDark ? "bg-slate-800/40 border-slate-700 text-slate-400 hover:bg-slate-800" : "bg-slate-100 border-slate-200 text-slate-600"
                  )}
                >
                  <Smile size={16} /> Rest / Off Day
                </button>
              </div>
            </div>

            {studiedToday && (
              <>
                {/* Minutes studied */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                      <Clock size={13} className="text-indigo-400" /> Focus Time
                    </label>
                    <span className="text-xs font-bold text-indigo-400">{minutesStudied} minutes</span>
                  </div>
                  <input
                    type="range"
                    min={15}
                    max={240}
                    step={15}
                    value={minutesStudied}
                    onChange={(e) => setMinutesStudied(Number(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                  <div className="flex justify-between items-center gap-1.5 mt-2">
                    {[30, 45, 60, 90, 120].map((mins) => (
                      <button
                        key={mins}
                        type="button"
                        onClick={() => setMinutesStudied(mins)}
                        className={cn(
                          "px-2.5 py-1 rounded-lg text-[11px] font-semibold border transition cursor-pointer",
                          minutesStudied === mins
                            ? "bg-indigo-600 text-white border-indigo-500"
                            : isDark ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700" : "bg-slate-100 border-slate-200 text-slate-700"
                        )}
                      >
                        {mins}m
                      </button>
                    ))}
                  </div>
                </div>

                {/* Topics Covered */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                    <BookOpen size={13} className="text-amber-400" /> Topics / Chapters Covered
                  </label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {predefinedTopics.slice(0, 8).map((topic) => {
                      const isSelected = topicsCovered.includes(topic);
                      return (
                        <button
                          key={topic}
                          type="button"
                          onClick={() => toggleTopic(topic)}
                          className={cn(
                            "px-2.5 py-1 rounded-lg text-xs font-medium border transition cursor-pointer",
                            isSelected
                              ? "bg-amber-500/20 border-amber-500 text-amber-300"
                              : isDark ? "bg-slate-800/60 border-slate-700 text-slate-400 hover:border-slate-600" : "bg-slate-50 border-slate-200 text-slate-600"
                          )}
                        >
                          {isSelected ? '✓ ' : '+ '}{topic}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Add another topic..."
                      value={customTopic}
                      onChange={(e) => setCustomTopic(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddCustomTopic();
                        }
                      }}
                      className={cn(
                        "flex-1 px-3 py-1.5 rounded-lg border text-xs outline-none transition",
                        isDark ? "bg-slate-800 border-slate-700 text-slate-200 focus:border-indigo-500" : "bg-white border-slate-300 text-slate-800 focus:border-indigo-500"
                      )}
                    />
                    <button
                      type="button"
                      onClick={handleAddCustomTopic}
                      className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-xs font-medium cursor-pointer"
                    >
                      Add
                    </button>
                  </div>
                </div>

                {/* Mood / Session Vibe */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    How did the session feel?
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { key: 'fired_up', label: '🔥 Fired Up' },
                      { key: 'steady', label: '⚡ Steady' },
                      { key: 'tired', label: '😴 Tired' },
                      { key: 'stuck', label: '🧩 Stuck' },
                    ].map((item) => (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() => setMood(item.key as typeof mood)}
                        className={cn(
                          "py-2 px-1 rounded-xl text-xs font-semibold border text-center transition cursor-pointer",
                          mood === item.key
                            ? "bg-indigo-600/30 border-indigo-500 text-indigo-300 shadow-sm"
                            : isDark ? "bg-slate-800/40 border-slate-700 text-slate-400 hover:bg-slate-800" : "bg-slate-50 border-slate-200 text-slate-600"
                        )}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Quick reflection note */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Note for {partner?.alias || 'Your Buddy'} (Optional)
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Solved 10 Gauss theorem questions, feeling confident about electric flux!"
                value={reflectionNote}
                onChange={(e) => setReflectionNote(e.target.value)}
                maxLength={200}
                className={cn(
                  "w-full px-3 py-2 rounded-xl border text-xs outline-none transition resize-none",
                  isDark ? "bg-slate-800 border-slate-700 text-slate-200 focus:border-indigo-500" : "bg-white border-slate-300 text-slate-800 focus:border-indigo-500"
                )}
              />
            </div>

            {/* Submit */}
            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-slate-700 text-slate-400 hover:text-slate-200 text-xs font-semibold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white text-xs font-bold shadow-lg shadow-amber-500/20 flex items-center gap-1.5 transition cursor-pointer"
              >
                <Send size={13} /> Complete Check-In
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
