import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { 
  Flame, Play, Pause, RotateCcw, ArrowRight, BookOpen, Sparkles, 
  Zap, Atom, Search, HelpCircle, CheckCircle2, XCircle, Info, 
  Sliders, Plus, Check, ChevronRight, GraduationCap, AlertCircle
} from 'lucide-react';

interface ReactionStep {
  title: string;
  description: string;
  energyChange: string; // e.g. "Activation barrier" or "Exothermic release"
  // Custom positions for SVG animations per step
  positions: {
    nucleophile?: { x: number; y: number; opacity: number; rotation?: number };
    leavingGroup?: { x: number; y: number; opacity: number };
    carbocation?: { opacity: number; scale?: number };
    bonds?: { name: string; x1: number; y1: number; x2: number; y2: number; dashArray?: string; opacity: number }[];
    arrows?: { fromX: number; fromY: number; toX: number; toY: number; controlY?: number; opacity: number }[];
    labels?: { text: string; x: number; y: number; color?: string }[];
  };
}

interface ReactionTemplate {
  id: string;
  name: string;
  classType: string; // e.g., "Nucleophilic Substitution (SN2)", "Electrophilic Addition", etc.
  reactantsInput: string;
  reagentInput: string;
  products: string;
  details: {
    rateLaw: string;
    solvent: string;
    stereochemistry: string;
    energyProfile: string;
  };
  quiz: {
    question: string;
    options: string[];
    answerIndex: number;
    explanation: string;
  };
  steps: ReactionStep[];
}

const REACTION_TEMPLATES: Record<string, ReactionTemplate> = {
  sn2_substitution: {
    id: 'sn2_substitution',
    name: 'S_N2 Backside Attack on Bromomethane',
    classType: 'Bimolecular Nucleophilic Substitution (SN2)',
    reactantsInput: 'CH₃Br',
    reagentInput: 'OH⁻',
    products: 'CH₃OH + Br⁻',
    details: {
      rateLaw: 'Rate = k [CH₃Br] [OH⁻]',
      solvent: 'Polar Aprotic (e.g., DMSO, Acetone)',
      stereochemistry: 'Stereochemical Inversion (Walden Inversion)',
      energyProfile: 'Concerted single-step transition state with no intermediates.'
    },
    quiz: {
      question: 'Which type of solvent is ideal for accelerating an SN2 reaction like this one?',
      options: [
        'Polar Protic solvents (like water or ethanol)',
        'Polar Aprotic solvents (like DMSO or DMF)',
        'Nonpolar solvents (like hexane)',
        'Solvent choice has no effect on SN2 kinetics'
      ],
      answerIndex: 1,
      explanation: 'Polar aprotic solvents do not form strong hydrogen-bonding cages around nucleophiles, keeping the nucleophile "naked" and highly reactive for nucleophilic attack.'
    },
    steps: [
      {
        title: 'Step 1: Backside Nucleophilic Attack Approach',
        description: 'The strong nucleophile (OH⁻) approaches the methyl carbon from the backside, exactly 180° opposite to the C–Br polar bond to avoid electron repulsion.',
        energyChange: 'System potential energy begins to climb as reactants approach.',
        positions: {
          nucleophile: { x: 100, y: 200, opacity: 1, rotation: 0 },
          leavingGroup: { x: 400, y: 200, opacity: 1 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C-Br', x1: 280, y1: 200, x2: 400, y2: 200, opacity: 1 },
            { name: 'C-H1', x1: 280, y1: 200, x2: 240, y2: 130, opacity: 1 },
            { name: 'C-H2', x1: 280, y1: 200, x2: 240, y2: 270, opacity: 1 },
            { name: 'C-H3', x1: 280, y1: 200, x2: 210, y2: 200, opacity: 1 }
          ],
          arrows: [
            { fromX: 110, fromY: 200, toX: 250, toY: 200, controlY: 150, opacity: 1 }
          ],
          labels: [
            { text: 'Hydroxide (OH⁻)', x: 100, y: 160, color: 'text-rose-500' },
            { text: 'Electrophilic Carbon', x: 280, y: 160, color: 'text-indigo-400' },
            { text: 'Leaving Group (Br)', x: 400, y: 160, color: 'text-emerald-500' }
          ]
        }
      },
      {
        title: 'Step 2: Transition State (Pentavalent Carbon)',
        description: 'A transient transition state is reached. The C–OH bond is half-formed and the C–Br bond is half-broken. The three central hydrogens are aligned in a flat planar configuration.',
        energyChange: 'Peak Activation Energy (Transition State)',
        positions: {
          nucleophile: { x: 200, y: 200, opacity: 0.9, rotation: 0 },
          leavingGroup: { x: 360, y: 200, opacity: 0.9 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C-OH-partial', x1: 200, y1: 200, x2: 280, y2: 200, dashArray: '4,4', opacity: 0.8 },
            { name: 'C-Br-partial', x1: 280, y1: 200, x2: 360, y2: 200, dashArray: '4,4', opacity: 0.8 },
            { name: 'C-H1-plane', x1: 280, y1: 200, x2: 280, y2: 120, opacity: 1 },
            { name: 'C-H2-plane', x1: 280, y1: 200, x2: 280, y2: 280, opacity: 1 },
            { name: 'C-H3-plane', x1: 280, y1: 200, x2: 250, y2: 200, opacity: 1 }
          ],
          arrows: [
            { fromX: 280, fromY: 195, toX: 350, toY: 195, controlY: 180, opacity: 0.6 }
          ],
          labels: [
            { text: 'Partial Bond forming (δ-)', x: 190, y: 240, color: 'text-rose-400' },
            { text: 'Transition State [Pentavalent]', x: 280, y: 80, color: 'text-amber-500 font-extrabold' },
            { text: 'Partial Bond breaking (δ-)', x: 370, y: 240, color: 'text-emerald-400' }
          ]
        }
      },
      {
        title: 'Step 3: Inversion and Product Separation',
        description: 'The bromide leaving group departs completely with the bonding electron pair, forming a stable Bromide ion (Br⁻). The central carbon undergoes Walden inversion, complete with inverted stereochemistry.',
        energyChange: 'Energy drops rapidly to an exothermic state.',
        positions: {
          nucleophile: { x: 280, y: 200, opacity: 1, rotation: 180 },
          leavingGroup: { x: 480, y: 200, opacity: 1 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C-OH-full', x1: 280, y1: 200, x2: 200, y2: 200, opacity: 1 },
            { name: 'C-H1-inv', x1: 280, y1: 200, x2: 320, y2: 130, opacity: 1 },
            { name: 'C-H2-inv', x1: 280, y1: 200, x2: 320, y2: 270, opacity: 1 },
            { name: 'C-H3-inv', x1: 280, y1: 200, x2: 350, y2: 200, opacity: 1 }
          ],
          arrows: [],
          labels: [
            { text: 'Inverted Methanol (CH₃OH)', x: 240, y: 110, color: 'text-rose-500' },
            { text: 'Bromide Leaving Group (Br⁻)', x: 480, y: 160, color: 'text-emerald-500 font-bold' }
          ]
        }
      }
    ]
  },
  sn1_substitution: {
    id: 'sn1_substitution',
    name: 'S_N1 Ionization of Tert-Butyl Chloride',
    classType: 'Unimolecular Nucleophilic Substitution (SN1)',
    reactantsInput: '(CH₃)₃CCl',
    reagentInput: 'H₂O',
    products: '(CH₃)₃COH + Cl⁻',
    details: {
      rateLaw: 'Rate = k [(CH₃)₃CCl]',
      solvent: 'Polar Protic (e.g., Water, Ethanol, Methanol)',
      stereochemistry: 'Racemization (mixture of inversion & retention)',
      energyProfile: 'Two-step profile with a carbocation intermediate barrier.'
    },
    quiz: {
      question: 'What is the rate-determining step in an SN1 reaction?',
      options: [
        'The nucleophilic attack of the water molecule',
        'Spontaneous heterolytic ionization to form the carbocation',
        'Loss of a proton from the oxonium intermediate',
        'All steps occur at the same speed'
      ],
      answerIndex: 1,
      explanation: 'The spontaneous breaking of the carbon-leaving group bond (ionization) is the slow, rate-determining step because it requires overcoming a high activation barrier to form a highly energetic intermediate.'
    },
    steps: [
      {
        title: 'Step 1: Spontaneous Leaving Group Ionization',
        description: 'Due to polar protic solvation assistance, the polar carbon-chlorine bond undergoes heterolytic cleavage. The chloride leaving group departs with the bonding electrons.',
        energyChange: 'Climbing the high primary activation energy barrier.',
        positions: {
          nucleophile: { x: 100, y: 100, opacity: 0.2 },
          leavingGroup: { x: 380, y: 200, opacity: 1 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C-Cl', x1: 280, y1: 200, x2: 380, y2: 200, opacity: 1 },
            { name: 'C-CH3a', x1: 280, y1: 200, x2: 210, y2: 120, opacity: 1 },
            { name: 'C-CH3b', x1: 280, y1: 200, x2: 210, y2: 280, opacity: 1 },
            { name: 'C-CH3c', x1: 280, y1: 200, x2: 320, y2: 200, opacity: 0.4 } // wedged/dashed perspective
          ],
          arrows: [
            { fromX: 300, fromY: 200, toX: 370, toY: 200, controlY: 170, opacity: 1 }
          ],
          labels: [
            { text: 'Heterolysis of C-Cl', x: 330, y: 150, color: 'text-amber-500 font-bold' },
            { text: 'Leaving Group', x: 390, y: 240, color: 'text-emerald-500' }
          ]
        }
      },
      {
        title: 'Step 2: Planar Carbocation Intermediate',
        description: 'The departure of chloride leaves behind a flat, planar, sp²-hybridized carbocation. It has an empty p-orbital perpendicular to the molecular plane, making it open to attack from either side.',
        energyChange: 'Relatively stable high-energy intermediate state.',
        positions: {
          nucleophile: { x: 150, y: 120, opacity: 1 },
          leavingGroup: { x: 480, y: 200, opacity: 0.7 },
          carbocation: { opacity: 1, scale: 1 },
          bonds: [
            { name: 'C-CH3a-planar', x1: 280, y1: 200, x2: 280, y2: 100, opacity: 1 },
            { name: 'C-CH3b-planar', x1: 280, y1: 200, x2: 220, y2: 250, opacity: 1 },
            { name: 'C-CH3c-planar', x1: 280, y1: 200, x2: 340, y2: 250, opacity: 1 }
          ],
          arrows: [
            { fromX: 170, fromY: 130, toX: 270, toY: 180, controlY: 140, opacity: 1 }
          ],
          labels: [
            { text: 'Planar Carbocation (R⁺)', x: 280, y: 230, color: 'text-rose-500 font-extrabold' },
            { text: 'Water nucleophile approaches', x: 120, y: 80, color: 'text-blue-400' }
          ]
        }
      },
      {
        title: 'Step 3: Nucleophilic Attack and Deprotonation',
        description: 'Water attacks the highly electrophilic carbocation. A subsequent fast deprotonation by another solvent molecule yields the final neutral tert-butyl alcohol and HCl.',
        energyChange: 'Exothermic decay to final product stability.',
        positions: {
          nucleophile: { x: 280, y: 200, opacity: 1 },
          leavingGroup: { x: 500, y: 300, opacity: 0.9 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C-OH', x1: 280, y1: 200, x2: 280, y2: 100, opacity: 1 },
            { name: 'C-CH3a-final', x1: 280, y1: 200, x2: 210, y2: 250, opacity: 1 },
            { name: 'C-CH3b-final', x1: 280, y1: 200, x2: 350, y2: 250, opacity: 1 },
            { name: 'C-CH3c-final', x1: 280, y1: 200, x2: 300, y2: 160, opacity: 1 }
          ],
          arrows: [],
          labels: [
            { text: 'Tert-Butyl Alcohol', x: 280, y: 60, color: 'text-indigo-400 font-black' },
            { text: 'Chloride Ion (Cl⁻)', x: 500, y: 270, color: 'text-emerald-500' }
          ]
        }
      }
    ]
  },
  electrophilic_addition: {
    id: 'electrophilic_addition',
    name: 'Electrophilic Bromination of Ethene',
    classType: 'Electrophilic Addition via Cyclic Halonium Ion',
    reactantsInput: 'CH₂=CH₂',
    reagentInput: 'Br₂',
    products: '1,2-Dibromoethane',
    details: {
      rateLaw: 'Rate = k [Ethene] [Br₂]',
      solvent: 'Nonpolar / Inert (e.g., CCl₄, CH₂Cl₂)',
      stereochemistry: 'Stereospecific Anti-Addition (Trans-isomer preference)',
      energyProfile: 'Three-membered cyclic bromonium intermediate pathway.'
    },
    quiz: {
      question: 'Why does bromine addition to alkenes yield anti-addition (trans product)?',
      options: [
        'Because the intermediate is a planar carbocation',
        'Due to sterics, the incoming bromide ion must attack from the opposite side of the bulky cyclic bromonium ring',
        'Because bromine molecules undergo a synchronized frontal attack',
        'Bromine atoms repel each other and turn upside-down'
      ],
      answerIndex: 1,
      explanation: 'The three-membered cyclic bromonium ion blocks one face of the carbon chain completely. Therefore, the bromide nucleophile must attack from the opposite side (backside attack) in a stereo-exclusive anti-addition.'
    },
    steps: [
      {
        title: 'Step 1: Polarization and Attack on Br₂',
        description: 'As Br₂ approaches the electron-dense π double bond of ethene, the Br–Br bond is polarized. The nucleophilic π electrons attack the electrophilic Br, displacing the other Br as a bromide ion.',
        energyChange: 'Formation of initial π complex.',
        positions: {
          nucleophile: { x: 280, y: 220, opacity: 1 },
          leavingGroup: { x: 280, y: 100, opacity: 1 }, // electrophilic Br
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C=C', x1: 220, y1: 220, x2: 340, y2: 220, opacity: 1 },
            { name: 'Br-Br', x1: 280, y1: 100, x2: 380, y2: 60, opacity: 1 }
          ],
          arrows: [
            { fromX: 280, fromY: 220, toX: 280, toY: 110, controlY: 160, opacity: 1 },
            { fromX: 300, fromY: 90, toX: 370, toY: 65, controlY: 75, opacity: 1 }
          ],
          labels: [
            { text: 'Alkene π-electrons attack', x: 210, y: 170, color: 'text-amber-500 font-bold' },
            { text: 'Polarized Br-Br', x: 330, y: 120, color: 'text-orange-400' }
          ]
        }
      },
      {
        title: 'Step 2: Cyclic Bromonium Ion Intermediate',
        description: 'A stable three-membered cyclic bromonium ring is formed. The bromine atom holds a positive charge, sharing bonds with both carbon atoms. A free bromide nucleophile (Br⁻) is produced.',
        energyChange: 'Slightly stable halonium intermediate.',
        positions: {
          nucleophile: { x: 360, y: 300, opacity: 1 }, // free Br- nucleophile
          leavingGroup: { x: 280, y: 140, opacity: 1 }, // cyclic Br+
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C-C-single', x1: 220, y1: 220, x2: 340, y2: 220, opacity: 1 },
            { name: 'C1-Br-ring', x1: 220, y1: 220, x2: 280, y2: 140, opacity: 1, dashArray: '2,2' },
            { name: 'C2-Br-ring', x1: 340, y1: 220, x2: 280, y2: 140, opacity: 1, dashArray: '2,2' }
          ],
          arrows: [
            { fromX: 350, fromY: 290, toX: 340, toY: 230, controlY: 260, opacity: 1 }
          ],
          labels: [
            { text: 'Cyclic Bromonium Ring (Br⁺)', x: 280, y: 110, color: 'text-rose-500 font-extrabold' },
            { text: 'Bromide Nucleophile (Br⁻) attacks from bottom', x: 390, y: 340, color: 'text-amber-500' }
          ]
        }
      },
      {
        title: 'Step 3: Backside Attack to form Anti-Product',
        description: 'The bromide ion (Br⁻) attacks one of the carbons from the backside, causing the highly strained cyclic three-membered ring to open. The reaction yields trans-1,2-dibromoethane.',
        energyChange: 'Exothermic transition to stable alkane product.',
        positions: {
          nucleophile: { x: 340, y: 280, opacity: 1 },
          leavingGroup: { x: 220, y: 140, opacity: 1 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C-C-final', x1: 220, y1: 220, x2: 340, y2: 220, opacity: 1 },
            { name: 'C1-Br-up', x1: 220, y1: 220, x2: 220, y2: 140, opacity: 1 },
            { name: 'C2-Br-down', x1: 340, y1: 220, x2: 340, y2: 280, opacity: 1 }
          ],
          arrows: [],
          labels: [
            { text: 'trans-1,2-Dibromoethane', x: 280, y: 90, color: 'text-indigo-400 font-extrabold' },
            { text: 'Anti-Addition Complete', x: 280, y: 320, color: 'text-emerald-500 font-bold' }
          ]
        }
      }
    ]
  },
  hydrohalogenation: {
    id: 'hydrohalogenation',
    name: 'Hydrohalogenation of Propene (Markovnikov)',
    classType: 'Electrophilic Addition of Hydrogen Halide (HBr)',
    reactantsInput: 'CH₃-CH=CH₂',
    reagentInput: 'HBr',
    products: '2-Bromopropane',
    details: {
      rateLaw: 'Rate = k [Propene] [HBr]',
      solvent: 'Polar/Nonpolar organic solvents',
      stereochemistry: 'Regioselective Markovnikov addition (carbocation stability)',
      energyProfile: 'Formation of the more stable secondary carbocation intermediate.'
    },
    quiz: {
      question: 'Why does HBr addition to propene selectively form 2-bromopropane instead of 1-bromopropane?',
      options: [
        'The primary carbocation is more stable than the secondary carbocation',
        'The secondary carbocation is more stable than the primary carbocation due to hyperconjugation and inductive donation',
        'Bromine atoms prefer primary positions for steric reasons',
        'Hydrogen ions repel the central carbon'
      ],
      answerIndex: 1,
      explanation: 'According to Markovnikov\'s rule, protonation occurs to yield the more stable carbocation intermediate. The secondary carbocation is stabilized by two methyl electron-donating groups, whereas the primary has only one, creating a much lower energy path.'
    },
    steps: [
      {
        title: 'Step 1: Protonation to Secondary Carbocation',
        description: 'The carbon-carbon double bond attacks the hydrogen of polar HBr. The hydrogen atom attaches to the terminal CH₂ carbon to form a secondary carbocation, which is much more stable than a primary one.',
        energyChange: 'High activation barrier to protonate the alkene.',
        positions: {
          nucleophile: { x: 280, y: 100, opacity: 1 }, // H-Br
          leavingGroup: { x: 380, y: 100, opacity: 1 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C=C-propene', x1: 200, y1: 220, x2: 320, y2: 220, opacity: 1 },
            { name: 'C-CH3-branch', x1: 200, y1: 220, x2: 130, y2: 280, opacity: 1 },
            { name: 'H-Br-bond', x1: 280, y1: 100, x2: 360, y2: 100, opacity: 1 }
          ],
          arrows: [
            { fromX: 260, fromY: 220, toX: 280, toY: 110, controlY: 170, opacity: 1 },
            { fromX: 300, fromY: 100, toX: 350, toY: 100, controlY: 80, opacity: 1 }
          ],
          labels: [
            { text: 'Double bond acts as nucleophile', x: 190, y: 170, color: 'text-amber-500' },
            { text: 'Hydrogen Bromide (H-Br)', x: 320, y: 70, color: 'text-indigo-400' }
          ]
        }
      },
      {
        title: 'Step 2: Nucleophilic Attack by Bromide',
        description: 'The secondary carbocation intermediate is planar and highly reactive. The bromide ion (Br⁻), generated in step 1, attacks the positively charged central carbon.',
        energyChange: 'Relatively low barrier, fast reaction rate.',
        positions: {
          nucleophile: { x: 260, y: 120, opacity: 1 }, // Br- attacking
          leavingGroup: { x: 380, y: 300, opacity: 0.1 },
          carbocation: { opacity: 1 },
          bonds: [
            { name: 'C-C-single', x1: 200, y1: 220, x2: 320, y2: 220, opacity: 1 },
            { name: 'C-CH3-branch', x1: 200, y1: 220, x2: 130, y2: 280, opacity: 1 },
            { name: 'C-H-terminal', x1: 320, y1: 220, x2: 380, y2: 170, opacity: 1 }
          ],
          arrows: [
            { fromX: 260, fromY: 130, toX: 205, toY: 200, controlY: 160, opacity: 1 }
          ],
          labels: [
            { text: 'Stable Secondary Carbocation (2°)', x: 215, y: 180, color: 'text-rose-500 font-extrabold' },
            { text: 'Bromide attacks C⁺', x: 290, y: 100, color: 'text-amber-500' }
          ]
        }
      },
      {
        title: 'Step 3: 2-Bromopropane Formation',
        description: 'Bromide bonds to the central carbon. The double bond has fully substituted to a single carbon-bromine bond, forming 2-bromopropane regioselectively according to Markovnikov\'s rule.',
        energyChange: 'Exothermic heat released, highly stable product.',
        positions: {
          nucleophile: { x: 200, y: 140, opacity: 1 },
          leavingGroup: { x: 380, y: 300, opacity: 0 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C-C-final', x1: 200, y1: 220, x2: 320, y2: 220, opacity: 1 },
            { name: 'C-CH3-branch', x1: 200, y1: 220, x2: 130, y2: 280, opacity: 1 },
            { name: 'C-Br-final', x1: 200, y1: 220, x2: 200, y2: 140, opacity: 1 },
            { name: 'C-H-final', x1: 320, y1: 220, x2: 380, y2: 220, opacity: 1 }
          ],
          arrows: [],
          labels: [
            { text: '2-Bromopropane Product', x: 200, y: 100, color: 'text-indigo-400 font-extrabold' },
            { text: 'Markovnikov Addition Complete', x: 280, y: 300, color: 'text-emerald-500 font-bold' }
          ]
        }
      }
    ]
  },
  e2_elimination: {
    id: 'e2_elimination',
    name: 'E2 Elimination of Bromoethane',
    classType: 'Bimolecular Elimination (E2)',
    reactantsInput: 'CH₃CH₂Br',
    reagentInput: 'OH⁻',
    products: 'CH₂=CH₂ + H₂O + Br⁻',
    details: {
      rateLaw: 'Rate = k [CH₃CH₂Br] [OH⁻]',
      solvent: 'Highly Polar, strongly basic (e.g., Alkoxide in Alcohol)',
      stereochemistry: 'Stereospecific anti-periplanar transition geometry',
      energyProfile: 'Concerted removal of β-proton, double bond formation and loss of leaving group.'
    },
    quiz: {
      question: 'What is the required relative geometric orientation of the β-hydrogen and the leaving group in an E2 mechanism?',
      options: [
        'Syn-coplanar (aligned on the same side)',
        'Anti-periplanar (aligned 180° opposite to each other)',
        'Orthogonal (90° perpendicular)',
        'E2 has no stereochemical or geometric requirements'
      ],
      answerIndex: 1,
      explanation: 'The C-H and C-LG bonds must be anti-periplanar (180° dihedral angle). This maximizes orbital overlap between the breaking C-H bonding σ-orbital and the breaking C-LG antibonding σ*-orbital, facilitating concerted π-bond formation.'
    },
    steps: [
      {
        title: 'Step 1: Concerted Anti-Periplanar Attack',
        description: 'The strong hydroxide base (OH⁻) attacks the β-hydrogen, while simultaneously the C–H bonding electrons shift to form the C=C double bond, pushing out the bromine leaving group from the opposite face.',
        energyChange: 'System potential energy climbs towards concerted peak.',
        positions: {
          nucleophile: { x: 100, y: 120, opacity: 1 }, // Base (OH-)
          leavingGroup: { x: 380, y: 220, opacity: 1 }, // Br leaving group
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C1-C2', x1: 220, y1: 220, x2: 320, y2: 220, opacity: 1 },
            { name: 'C1-H-beta', x1: 220, y1: 220, x2: 160, y2: 140, opacity: 1 }, // beta-proton
            { name: 'C2-Br-alpha', x1: 320, y1: 220, x2: 380, y2: 280, opacity: 1 } // alpha leaving group
          ],
          arrows: [
            { fromX: 110, fromY: 130, toX: 155, toY: 135, controlY: 110, opacity: 1 },
            { fromX: 180, fromY: 160, toX: 270, toY: 215, controlY: 190, opacity: 1 },
            { fromX: 330, fromY: 230, toX: 380, toY: 275, controlY: 240, opacity: 1 }
          ],
          labels: [
            { text: 'Base attacks β-Hydrogen', x: 115, y: 90, color: 'text-rose-400' },
            { text: 'Bond shifts to make π-bond', x: 230, y: 170, color: 'text-amber-500' },
            { text: 'Leaving Group departs', x: 420, y: 310, color: 'text-emerald-400' }
          ]
        }
      },
      {
        title: 'Step 2: Concerted Transition State',
        description: 'A concerted transition state is reached. The base-hydrogen bond is half-formed, the C–H bond is half-broken, the C=C double bond is half-formed, and the C–Br bond is half-broken.',
        energyChange: 'Peak concerted activation energy.',
        positions: {
          nucleophile: { x: 140, y: 130, opacity: 0.9 },
          leavingGroup: { x: 360, y: 260, opacity: 0.9 },
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C1-C2-partial-double', x1: 220, y1: 220, x2: 320, y2: 220, opacity: 1 },
            { name: 'C1-C2-pi-partial', x1: 220, y1: 210, x2: 320, y2: 210, dashArray: '3,3', opacity: 0.7 },
            { name: 'C1-H-partial', x1: 220, y1: 220, x2: 160, y2: 140, dashArray: '3,3', opacity: 0.7 },
            { name: 'Base-H-partial', x1: 140, y1: 130, x2: 160, y2: 140, dashArray: '3,3', opacity: 0.7 },
            { name: 'C2-Br-partial', x1: 320, y1: 220, x2: 360, y2: 260, dashArray: '3,3', opacity: 0.7 }
          ],
          arrows: [],
          labels: [
            { text: 'Transition State [Concerted]', x: 270, y: 90, color: 'text-amber-500 font-extrabold' },
            { text: 'Partial Pi double bond forming', x: 270, y: 175, color: 'text-amber-400 text-[10px]' }
          ]
        }
      },
      {
        title: 'Step 3: Product Separation (Ethene, Water, and Br⁻)',
        description: 'The beta-proton is fully removed as water (H₂O). The double bond is fully formed yielding ethene (CH₂=CH₂), and the bromide ion (Br⁻) is fully liberated.',
        energyChange: 'Stable thermodynamic release.',
        positions: {
          nucleophile: { x: 130, y: 100, opacity: 1 }, // Water molecule now
          leavingGroup: { x: 420, y: 300, opacity: 1 }, // Br-
          carbocation: { opacity: 0 },
          bonds: [
            { name: 'C1=C2-final', x1: 220, y1: 215, x2: 320, y2: 215, opacity: 1 },
            { name: 'C1=C2-final-double', x1: 220, y1: 225, x2: 320, y2: 225, opacity: 1 }
          ],
          arrows: [],
          labels: [
            { text: 'Ethene Product (CH₂=CH₂)', x: 270, y: 170, color: 'text-indigo-400 font-extrabold' },
            { text: 'Water (H₂O)', x: 110, y: 70, color: 'text-blue-400 font-bold' },
            { text: 'Bromide Ion (Br⁻)', x: 420, y: 270, color: 'text-emerald-500 font-bold' }
          ]
        }
      }
    ]
  }
};

interface ChemicalReactionAnimatorProps {
  theme: 'light' | 'dark';
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onOpenChapter?: (chapterNumber: number) => void;
}

export const ChemicalReactionAnimator: React.FC<ChemicalReactionAnimatorProps> = ({
  theme,
  showNotification,
  onOpenChapter
}) => {
  const [selectedKey, setSelectedKey] = useState<string>('sn2_substitution');
  const [reactantsInput, setReactantsInput] = useState<string>('CH₃Br');
  const [reagentInput, setReagentInput] = useState<string>('OH⁻');
  
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [animationSpeed, setAnimationSpeed] = useState<number>(2500); // ms per step
  
  // Custom smart match results
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [matchingResults, setMatchingResults] = useState<ReactionTemplate[]>([]);
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  // Quiz State
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  const activeReaction = REACTION_TEMPLATES[selectedKey] || REACTION_TEMPLATES['sn2_substitution'];

  // Match logic whenever custom input fields change
  const handleSmartMatch = (reactStr: string, reagentStr: string) => {
    const normReact = reactStr.toLowerCase().replace(/\s+/g, '');
    const normReag = reagentStr.toLowerCase().replace(/\s+/g, '');

    if ((normReact.includes('ch3br') || normReact.includes('ch3cl') || normReact.includes('methyl') || normReact.includes('chloromethane') || normReact.includes('bromomethane')) && 
        (normReag.includes('oh') || normReag.includes('hydroxide') || normReag.includes('naoh') || normReag.includes('koh'))) {
      setSelectedKey('sn2_substitution');
      setCurrentStep(0);
      setIsPlaying(false);
      return 'sn2_substitution';
    } 
    else if ((normReact.includes('ch33c') || normReact.includes('tert-butyl') || normReact.includes('t-butyl') || normReact.includes('2-chloro-2-methyl') || normReact.includes('cch33')) && 
             (normReag.includes('h2o') || normReag.includes('water') || normReag.includes('alcohol') || normReag.includes('solvolysis'))) {
      setSelectedKey('sn1_substitution');
      setCurrentStep(0);
      setIsPlaying(false);
      return 'sn1_substitution';
    } 
    else if ((normReact.includes('ch2=ch2') || normReact.includes('ethene') || normReact.includes('ethylene')) && 
             (normReag.includes('br2') || normReag.includes('bromine'))) {
      setSelectedKey('electrophilic_addition');
      setCurrentStep(0);
      setIsPlaying(false);
      return 'electrophilic_addition';
    } 
    else if ((normReact.includes('propene') || normReact.includes('propylene') || normReact.includes('ch3ch=ch2')) && 
             (normReag.includes('hbr') || normReag.includes('hydrogenbromide'))) {
      setSelectedKey('hydrohalogenation');
      setCurrentStep(0);
      setIsPlaying(false);
      return 'hydrohalogenation';
    }
    else if ((normReact.includes('ch3ch2br') || normReact.includes('bromoethane') || normReact.includes('ethyl')) && 
             (normReag.includes('oh') || normReag.includes('base') || normReag.includes('koh') || normReag.includes('hydroxide'))) {
      setSelectedKey('e2_elimination');
      setCurrentStep(0);
      setIsPlaying(false);
      return 'e2_elimination';
    }
    return null;
  };

  // Autoplay Timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev >= activeReaction.steps.length - 1) {
            setIsPlaying(false);
            showNotification?.("Animation completed successfully!", "success");
            return prev;
          }
          return prev + 1;
        });
      }, animationSpeed);
    }
    return () => clearInterval(timer);
  }, [isPlaying, activeReaction, animationSpeed, showNotification]);

  // Load a template
  const loadTemplate = (key: string) => {
    const tmpl = REACTION_TEMPLATES[key];
    if (tmpl) {
      setSelectedKey(key);
      setReactantsInput(tmpl.reactantsInput);
      setReagentInput(tmpl.reagentInput);
      setCurrentStep(0);
      setIsPlaying(false);
      setSelectedQuizOption(null);
      setQuizSubmitted(false);
      showNotification?.(`Loaded reaction template: ${tmpl.name}`, 'info');
    }
  };

  // Handle Search Input matching
  const handleSearch = () => {
    setHasSearched(true);
    const query = searchQuery.toLowerCase().trim();
    if (!query) {
      setMatchingResults([]);
      return;
    }

    const matches = Object.values(REACTION_TEMPLATES).filter(tmpl => 
      tmpl.name.toLowerCase().includes(query) || 
      tmpl.classType.toLowerCase().includes(query) || 
      tmpl.reactantsInput.toLowerCase().includes(query) || 
      tmpl.products.toLowerCase().includes(query)
    );
    setMatchingResults(matches);
  };

  const currentStepData = activeReaction.steps[currentStep] || activeReaction.steps[0];

  return (
    <div className={cn(
      "w-full h-full flex flex-col p-6 md:p-8 space-y-6 overflow-y-auto selection:bg-indigo-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-800"
    )}>
      
      {/* Visual Identity Title Section */}
      <div className={cn(
        "p-6 rounded-3xl border flex flex-col lg:flex-row lg:items-center justify-between gap-6 shadow-md transition-all",
        theme === 'dark' ? "bg-gradient-to-r from-slate-950/80 via-slate-900 to-indigo-950/50 border-slate-800" : "bg-gradient-to-r from-white via-indigo-50/20 to-indigo-50/40 border-slate-200/80"
      )}>
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-violet-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 flex-shrink-0">
            <Atom size={28} className="animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                Interactive Chemical Kinetics & Geometry
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Chemical Reaction Animator
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Input custom reactants or pick standard templates to see 3D-plane orbital substitutions, nucleophilic backside attacks, cyclic halonium ions, and elimination mechanisms with step-by-step SVG animations.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Hand Controls & Reactant Inputs (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Custom Input Panel */}
          <div className={cn(
            "p-5 rounded-2xl border space-y-4 shadow-sm",
            theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"
          )}>
            <div className="flex items-center gap-2 border-b pb-2 border-dashed border-slate-200 dark:border-slate-800">
              <Sparkles size={16} className="text-indigo-500" />
              <h2 className="text-sm font-black uppercase tracking-wider">Custom Reactant Input</h2>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Organic Substrate Reactant
                </label>
                <div className="relative">
                  <input 
                    type="text"
                    value={reactantsInput}
                    onChange={(e) => {
                      setReactantsInput(e.target.value);
                      handleSmartMatch(e.target.value, reagentInput);
                    }}
                    placeholder="e.g. CH3Br or Ethene"
                    className={cn(
                      "w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold outline-none transition-all",
                      theme === 'dark' 
                        ? "bg-slate-950 border-slate-800 text-slate-100 focus:border-indigo-500" 
                        : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                    )}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Reagent / Nucleophile / Base
                </label>
                <input 
                  type="text"
                  value={reagentInput}
                  onChange={(e) => {
                    setReagentInput(e.target.value);
                    handleSmartMatch(reactantsInput, e.target.value);
                  }}
                  placeholder="e.g. OH- or Br2"
                  className={cn(
                    "w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold outline-none transition-all",
                    theme === 'dark' 
                      ? "bg-slate-950 border-slate-800 text-slate-100 focus:border-indigo-500" 
                      : "bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500"
                  )}
                />
              </div>
            </div>

            {/* Smart Match Recognition Indicator */}
            <div className={cn(
              "p-3.5 rounded-xl border flex items-start gap-3 text-xs leading-normal",
              theme === 'dark' ? "bg-slate-950/40 border-slate-800/60" : "bg-slate-50 border-slate-150"
            )}>
              <Info size={16} className="text-indigo-500 mt-0.5 flex-shrink-0" />
              <div>
                <span className="font-bold text-slate-400 block mb-0.5">Automated Parsing State:</span>
                <p className="text-slate-500 dark:text-slate-400">
                  Matches template: <strong className="text-indigo-600 dark:text-indigo-400">{activeReaction.name}</strong> ({activeReaction.classType})
                </p>
              </div>
            </div>
          </div>

          {/* Quick Organic Templates Selection */}
          <div className={cn(
            "p-5 rounded-2xl border space-y-4 shadow-sm",
            theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"
          )}>
            <div className="flex items-center gap-2 border-b pb-2 border-dashed border-slate-200 dark:border-slate-800">
              <BookOpen size={16} className="text-indigo-500" />
              <h2 className="text-sm font-black uppercase tracking-wider">Verified Organic Templates</h2>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {Object.values(REACTION_TEMPLATES).map((tmpl) => {
                const isSelected = selectedKey === tmpl.id;
                return (
                  <button
                    key={tmpl.id}
                    onClick={() => loadTemplate(tmpl.id)}
                    className={cn(
                      "w-full p-3 rounded-xl border text-left transition-all active:scale-[0.99] flex items-center justify-between gap-3 cursor-pointer",
                      isSelected
                        ? "bg-indigo-600/10 border-indigo-500/50 text-indigo-700 dark:text-indigo-400 shadow-sm"
                        : theme === 'dark'
                          ? "bg-slate-950/40 border-slate-800 hover:border-slate-700 text-slate-300"
                          : "bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-700"
                    )}
                  >
                    <div>
                      <span className="text-[9px] font-black uppercase tracking-wider block text-slate-400 mb-0.5">
                        {tmpl.classType}
                      </span>
                      <span className="text-xs font-bold block leading-snug">
                        {tmpl.name}
                      </span>
                    </div>
                    {isSelected && <Check size={14} className="text-indigo-600 dark:text-indigo-400 flex-shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Reaction Mechanism Insights */}
          <div className={cn(
            "p-5 rounded-2xl border space-y-3.5 shadow-sm text-xs",
            theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"
          )}>
            <div className="flex items-center gap-2 border-b pb-2 border-dashed border-slate-200 dark:border-slate-800">
              <Sliders size={16} className="text-indigo-500" />
              <h2 className="text-sm font-black uppercase tracking-wider">Kinetics & Insights</h2>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-2.5 rounded-xl bg-slate-100/50 dark:bg-slate-950/40 border border-slate-200/40 dark:border-slate-800/40">
                <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">Rate Law</span>
                <span className="font-mono text-xs font-bold text-slate-700 dark:text-slate-300 block">{activeReaction.details.rateLaw}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-100/50 dark:bg-slate-950/40 border border-slate-200/40 dark:border-slate-800/40">
                <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">Preferred Solvent</span>
                <span className="font-semibold text-xs text-slate-700 dark:text-slate-300 block">{activeReaction.details.solvent}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-100/50 dark:bg-slate-950/40 border border-slate-200/40 dark:border-slate-800/40 col-span-2">
                <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">Stereochemical Stereospecificity</span>
                <span className="font-semibold text-xs text-slate-700 dark:text-slate-300 block">{activeReaction.details.stereochemistry}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-100/50 dark:bg-slate-950/40 border border-slate-200/40 dark:border-slate-800/40 col-span-2">
                <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">Thermodynamic Energy Profile</span>
                <span className="font-semibold text-xs text-slate-700 dark:text-slate-300 block leading-relaxed">{activeReaction.details.energyProfile}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Right Hand SVG Animator Viewport and Explanations (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Main SVG Animator Workspace */}
          <div className={cn(
            "p-5 rounded-3xl border flex flex-col gap-4 shadow-sm",
            theme === 'dark' ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"
          )}>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 border-b pb-4 border-dashed border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Flame size={14} className="text-amber-500 fill-current animate-pulse" />
                  Active Space-Time Animation Sandbox
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Visualizing mechanisms with step-by-step molecular structural orbitals
                </p>
              </div>

              {/* Step Navigation Controls */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    setCurrentStep(0);
                    setIsPlaying(false);
                  }}
                  className={cn(
                    "p-2.5 rounded-xl border transition active:scale-95 cursor-pointer",
                    theme === 'dark' ? "border-slate-800 text-slate-300 hover:bg-slate-900" : "border-slate-200 text-slate-700 hover:bg-slate-50"
                  )}
                  title="Reset to Step 1"
                >
                  <RotateCcw size={14} />
                </button>
                <button
                  onClick={() => {
                    setCurrentStep(prev => Math.max(0, prev - 1));
                    setIsPlaying(false);
                  }}
                  disabled={currentStep === 0}
                  className={cn(
                    "px-3.5 py-2 rounded-xl border text-xs font-bold transition active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer",
                    theme === 'dark' ? "border-slate-800 text-slate-300 hover:bg-slate-900" : "border-slate-200 text-slate-700 hover:bg-slate-50"
                  )}
                >
                  Prev
                </button>
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition active:scale-95 flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/10"
                >
                  {isPlaying ? <Pause size={13} /> : <Play size={13} />}
                  {isPlaying ? 'Pause' : 'Play Auto'}
                </button>
                <button
                  onClick={() => {
                    setCurrentStep(prev => Math.min(activeReaction.steps.length - 1, prev + 1));
                    setIsPlaying(false);
                  }}
                  disabled={currentStep === activeReaction.steps.length - 1}
                  className={cn(
                    "px-3.5 py-2 rounded-xl border text-xs font-bold transition active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer",
                    theme === 'dark' ? "border-slate-800 text-slate-300 hover:bg-slate-900" : "border-slate-200 text-slate-700 hover:bg-slate-50"
                  )}
                >
                  Next
                </button>
              </div>
            </div>

            {/* Animation Speed Slider */}
            <div className="flex items-center gap-3 bg-slate-100/50 dark:bg-slate-900/40 p-3 rounded-2xl border border-slate-200/40 dark:border-slate-800/40">
              <Sliders size={14} className="text-slate-400" />
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Speed Multiplier</span>
              <input 
                type="range"
                min="1000"
                max="5000"
                step="500"
                value={6000 - animationSpeed}
                onChange={(e) => setAnimationSpeed(6000 - Number(e.target.value))}
                className="flex-1 accent-indigo-600 h-1 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[10px] font-mono font-bold text-slate-500">
                {((6000 - animationSpeed) / 1000).toFixed(1)}x
              </span>
            </div>

            {/* 2D Vector SVG Canvas Viewport */}
            <div className="relative w-full aspect-[4/3] bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-850 flex items-center justify-center">
              
              {/* Starry Grid lines background inside SVG viewport */}
              <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />

              <svg 
                viewBox="0 0 600 400" 
                className="w-full h-full select-none"
              >
                {/* Arrow Defs for Curly Arrow pointers */}
                <defs>
                  <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="8" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#f59e0b" />
                  </marker>
                  <marker id="cyan-arrowhead" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
                    <polygon points="0 0, 8 3, 0 6" fill="#06b6d4" />
                  </marker>
                </defs>

                {/* Draw custom static/dynamic bonds defined in the step */}
                {currentStepData.positions.bonds?.map((bond, idx) => {
                  const isDashed = !!bond.dashArray;
                  return (
                    <motion.line 
                      key={bond.name + idx}
                      x1={bond.x1}
                      y1={bond.y1}
                      x2={bond.x2}
                      y2={bond.y2}
                      stroke={theme === 'dark' ? '#475569' : '#94a3b8'}
                      strokeWidth="4.5"
                      strokeLinecap="round"
                      strokeDasharray={bond.dashArray}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: bond.opacity }}
                      transition={{ duration: 0.6 }}
                    />
                  );
                })}

                {/* Draw standard hydrogen spheres if not fully detailed */}
                {selectedKey === 'sn2_substitution' && (
                  <>
                    {/* Centered electrophilic carbon */}
                    <circle cx="280" cy="200" r="30" fill="#3b82f6" opacity="0.9" />
                    <text x="280" y="205" fill="#ffffff" fontWeight="black" textAnchor="middle" fontSize="16">C</text>

                    {/* Hydrogen 1 */}
                    <circle cx={240} cy={130} r="14" fill="#64748b" />
                    <text x={240} y="134" fill="#ffffff" fontWeight="bold" textAnchor="middle" fontSize="10">H</text>

                    {/* Hydrogen 2 */}
                    <circle cx={240} cy={270} r="14" fill="#64748b" />
                    <text x={240} y="274" fill="#ffffff" fontWeight="bold" textAnchor="middle" fontSize="10">H</text>

                    {/* Hydrogen 3 */}
                    <circle cx={210} cy={200} r="14" fill="#64748b" />
                    <text x={210} y="204" fill="#ffffff" fontWeight="bold" textAnchor="middle" fontSize="10">H</text>
                  </>
                )}

                {selectedKey === 'sn1_substitution' && (
                  <>
                    {/* Centered carbocation carbon */}
                    <circle cx="280" cy="200" r="32" fill="#8b5cf6" opacity="0.95" />
                    <text x="280" y="205" fill="#ffffff" fontWeight="black" textAnchor="middle" fontSize="15">C⁺</text>

                    {/* Methyl groups */}
                    <circle cx="210" cy="120" r="18" fill="#475569" />
                    <text x="210" y="124" fill="#ffffff" fontWeight="bold" textAnchor="middle" fontSize="9">CH₃</text>

                    <circle cx="210" cy="280" r="18" fill="#475569" />
                    <text x="210" y="284" fill="#ffffff" fontWeight="bold" textAnchor="middle" fontSize="9">CH₃</text>
                  </>
                )}

                {selectedKey === 'electrophilic_addition' && (
                  <>
                    {/* Two double bonded carbons */}
                    <circle cx="220" cy="220" r="28" fill="#3b82f6" />
                    <text x="220" y="225" fill="#ffffff" fontWeight="black" textAnchor="middle" fontSize="14">C1</text>

                    <circle cx="340" cy="220" r="28" fill="#3b82f6" />
                    <text x="340" y="225" fill="#ffffff" fontWeight="black" textAnchor="middle" fontSize="14">C2</text>
                  </>
                )}

                {selectedKey === 'hydrohalogenation' && (
                  <>
                    <circle cx="200" cy="220" r="28" fill="#3b82f6" />
                    <text x="200" y="225" fill="#ffffff" fontWeight="black" textAnchor="middle" fontSize="14">C2</text>

                    <circle cx="320" cy="220" r="26" fill="#475569" />
                    <text x="320" y="224" fill="#ffffff" fontWeight="bold" textAnchor="middle" fontSize="12">CH₂</text>

                    <circle cx="130" cy="280" r="22" fill="#475569" />
                    <text x="130" y="284" fill="#ffffff" fontWeight="bold" textAnchor="middle" fontSize="11">CH₃</text>
                  </>
                )}

                {selectedKey === 'e2_elimination' && (
                  <>
                    {/* Concerted elimination carbons */}
                    <circle cx="220" cy="220" r="28" fill="#3b82f6" />
                    <text x="220" y="225" fill="#ffffff" fontWeight="black" textAnchor="middle" fontSize="14">C1</text>

                    <circle cx="320" cy="220" r="28" fill="#3b82f6" />
                    <text x="320" y="225" fill="#ffffff" fontWeight="black" textAnchor="middle" fontSize="14">C2</text>
                  </>
                )}

                {/* Animated Nucleophile Group */}
                {currentStepData.positions.nucleophile && (
                  <g>
                    <motion.circle 
                      cx={currentStepData.positions.nucleophile.x}
                      cy={currentStepData.positions.nucleophile.y}
                      r="24"
                      fill="#ec4899"
                      opacity={currentStepData.positions.nucleophile.opacity}
                      initial={{ scale: 0.8 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", damping: 10 }}
                    />
                    <text 
                      x={currentStepData.positions.nucleophile.x}
                      y={currentStepData.positions.nucleophile.y + 5}
                      fill="#ffffff"
                      fontWeight="black"
                      textAnchor="middle"
                      fontSize="12"
                      opacity={currentStepData.positions.nucleophile.opacity}
                    >
                      {reagentInput}
                    </text>
                  </g>
                )}

                {/* Animated Leaving Group */}
                {currentStepData.positions.leavingGroup && (
                  <g>
                    <motion.circle 
                      cx={currentStepData.positions.leavingGroup.x}
                      cy={currentStepData.positions.leavingGroup.y}
                      r="24"
                      fill="#10b981"
                      opacity={currentStepData.positions.leavingGroup.opacity}
                      initial={{ scale: 0.8 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", damping: 12 }}
                    />
                    <text 
                      x={currentStepData.positions.leavingGroup.x}
                      y={currentStepData.positions.leavingGroup.y + 4}
                      fill="#ffffff"
                      fontWeight="black"
                      textAnchor="middle"
                      fontSize="12"
                      opacity={currentStepData.positions.leavingGroup.opacity}
                    >
                      {selectedKey === 'sn1_substitution' || selectedKey === 'sn2_substitution' ? 'Br⁻' : 'Br'}
                    </text>
                  </g>
                )}

                {/* Curly electron movement arrows */}
                {currentStepData.positions.arrows?.map((arrow, idx) => {
                  const pathString = `M ${arrow.fromX} ${arrow.fromY} Q ${arrow.fromX + (arrow.toX - arrow.fromX)/2} ${arrow.controlY || (arrow.fromY - 40)} ${arrow.toX} ${arrow.toY}`;
                  return (
                    <g key={idx}>
                      <motion.path 
                        d={pathString}
                        fill="none"
                        stroke="#f59e0b"
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        markerEnd="url(#arrowhead)"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: arrow.opacity }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                      />
                      {/* Electron pair label moving along the arrow */}
                      <circle cx={(arrow.fromX + arrow.toX) / 2} cy={(arrow.fromY + arrow.toY) / 2 - 15} r="6" fill="#f59e0b" />
                      <text x={(arrow.fromX + arrow.toX) / 2} y={(arrow.fromY + arrow.toY) / 2 - 12} fill="#ffffff" fontWeight="black" fontSize="8" textAnchor="middle">:</text>
                    </g>
                  );
                })}

                {/* Dynamic text labels overlay */}
                {currentStepData.positions.labels?.map((lbl, idx) => (
                  <g key={idx}>
                    <text 
                      x={lbl.x} 
                      y={lbl.y} 
                      fill={theme === 'dark' ? '#cbd5e1' : '#f1f5f9'}
                      fontWeight="bold" 
                      fontSize="11" 
                      textAnchor="middle"
                    >
                      {lbl.text}
                    </text>
                  </g>
                ))}
              </svg>

              {/* Progress Stepper indicators overlay */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none bg-slate-950/80 px-4 py-2.5 rounded-xl border border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  Progress Tracker
                </span>
                <div className="flex items-center gap-1.5 pointer-events-auto">
                  {activeReaction.steps.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setCurrentStep(idx);
                        setIsPlaying(false);
                      }}
                      className={cn(
                        "w-5 h-5 rounded-full text-[9px] font-bold flex items-center justify-center transition active:scale-95 cursor-pointer",
                        currentStep === idx
                          ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                          : "bg-slate-800 text-slate-400 hover:text-white"
                      )}
                    >
                      {idx + 1}
                    </button>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* Explanation, Chemistry Energy Barriers & Quick assessment Quiz */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            
            {/* Step Explanation Block (7 cols) */}
            <div className={cn(
              "md:col-span-7 p-5 rounded-2xl border space-y-3.5 shadow-sm",
              theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"
            )}>
              <div className="flex items-center gap-2 border-b pb-2 border-dashed border-slate-200 dark:border-slate-800">
                <Info size={16} className="text-indigo-500" />
                <h3 className="text-xs font-black uppercase tracking-wider">
                  Mechanism Details: Step {currentStep + 1}
                </h3>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 leading-snug">
                  {currentStepData.title}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {currentStepData.description}
                </p>
              </div>

              <div className={cn(
                "p-3 rounded-xl border flex items-center gap-2.5 text-[11px]",
                theme === 'dark' ? "bg-amber-950/20 border-amber-900/30 text-amber-400" : "bg-amber-50 border-amber-100 text-amber-800"
              )}>
                <Zap size={14} className="flex-shrink-0 text-amber-500" />
                <span>
                  <strong>Barrier:</strong> {currentStepData.energyChange}
                </span>
              </div>
            </div>

            {/* Assessment Mini-Quiz Block (5 cols) */}
            <div className={cn(
              "md:col-span-5 p-5 rounded-2xl border space-y-3.5 shadow-sm text-xs",
              theme === 'dark' ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"
            )}>
              <div className="flex items-center gap-2 border-b pb-2 border-dashed border-slate-200 dark:border-slate-800">
                <GraduationCap size={16} className="text-indigo-500" />
                <h3 className="text-xs font-black uppercase tracking-wider">
                  Conceptual Review Quiz
                </h3>
              </div>

              <div className="space-y-3">
                <p className="font-bold text-slate-700 dark:text-slate-300 leading-snug">
                  {activeReaction.quiz.question}
                </p>

                <div className="space-y-1.5">
                  {activeReaction.quiz.options.map((option, idx) => {
                    const isSelected = selectedQuizOption === idx;
                    const isCorrect = idx === activeReaction.quiz.answerIndex;
                    return (
                      <button
                        key={idx}
                        onClick={() => {
                          if (!quizSubmitted) {
                            setSelectedQuizOption(idx);
                          }
                        }}
                        disabled={quizSubmitted}
                        className={cn(
                          "w-full p-2.5 rounded-xl border text-left text-[11px] font-semibold transition active:scale-[0.99] cursor-pointer disabled:cursor-default",
                          isSelected
                            ? "bg-indigo-600/10 border-indigo-500 text-indigo-700 dark:text-indigo-400"
                            : theme === 'dark'
                              ? "bg-slate-950/40 border-slate-800 hover:border-slate-700 text-slate-300"
                              : "bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-700"
                        )}
                      >
                        {option}
                      </button>
                    );
                  })}
                </div>

                {!quizSubmitted ? (
                  <button
                    onClick={() => {
                      if (selectedQuizOption !== null) {
                        setQuizSubmitted(true);
                        if (selectedQuizOption === activeReaction.quiz.answerIndex) {
                          showNotification?.("Outstanding! Correct answer selected.", "success");
                        } else {
                          showNotification?.("Incorrect option. Review the explanation details.", "error");
                        }
                      } else {
                        showNotification?.("Please select an option to submit.", "warning");
                      }
                    }}
                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-[11px] uppercase tracking-wider transition active:scale-95 cursor-pointer shadow-sm text-center"
                  >
                    Submit Answer
                  </button>
                ) : (
                  <div className={cn(
                    "p-3 rounded-xl border space-y-1.5",
                    selectedQuizOption === activeReaction.quiz.answerIndex
                      ? theme === 'dark' ? "bg-emerald-950/20 border-emerald-900/40 text-emerald-400" : "bg-emerald-50 border-emerald-100 text-emerald-850"
                      : theme === 'dark' ? "bg-rose-950/20 border-rose-900/40 text-rose-400" : "bg-rose-50 border-rose-100 text-rose-850"
                  )}>
                    <div className="flex items-center gap-1.5 font-bold">
                      {selectedQuizOption === activeReaction.quiz.answerIndex ? (
                        <>
                          <CheckCircle2 size={13} />
                          <span>Correct</span>
                        </>
                      ) : (
                        <>
                          <XCircle size={13} />
                          <span>Incorrect (Correct: Option {activeReaction.quiz.answerIndex + 1})</span>
                        </>
                      )}
                    </div>
                    <p className="text-[10px] leading-relaxed opacity-90">
                      {activeReaction.quiz.explanation}
                    </p>
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
