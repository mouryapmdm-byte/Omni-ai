export * from '../../src/modules/diagnostic/questionSelector';
