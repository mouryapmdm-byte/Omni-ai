import { Document, Packer, Paragraph, TextRun } from 'docx';
import { saveAs } from 'file-saver';

export async function exportToDocx(content: any) {
  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        new Paragraph({ children: [new TextRun({ text: content.title, bold: true, size: 32 })] }),
        new Paragraph({ children: [new TextRun(content.body)] }),
      ],
    }],
  });
  const blob = await Packer.toBlob(doc);
  saveAs(blob, `${content.title.replace(/\s+/g, '_')}.docx`);
}
