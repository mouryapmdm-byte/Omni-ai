// ai-tutor/types.ts

export type BoardId =
  | 'cbse'
  | 'icse'
  | 'ib-pyp' | 'ib-myp' | 'ib-dp'
  | 'cambridge-primary' | 'cambridge-lower-secondary'
  | 'cambridge-igcse' | 'cambridge-as' | 'cambridge-a'
  | 'state-maharashtra' | 'state-tamilnadu' | 'state-karnataka'
  | 'state-up' | 'state-kerala' | 'state-gujarat'
  | 'nios'
  | 'custom';

export type ClassLevel =
  | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12
  | 'ug-1' | 'ug-2' | 'ug-3' | 'ug-4';

export type SubjectId =
  | 'mathematics' | 'physics' | 'chemistry' | 'biology'
  | 'computer-science' | 'information-technology'
  | 'english' | 'hindi' | 'tamil' | 'telugu' | 'bengali' | 'marathi'
  | 'history' | 'geography' | 'civics' | 'economics'
  | 'accountancy' | 'business-studies'
  | 'psychology' | 'sociology' | 'political-science'
  | 'environmental-science' | 'general-knowledge'
  | 'foreign-french' | 'foreign-german' | 'foreign-spanish';

export type ExamTarget =
  | 'school-term' | 'school-final' | 'board'
  | 'jee-main' | 'jee-advanced' | 'neet'
  | 'sat' | 'act' | 'cuet'
  | 'olympiad' | 'ntse' | 'kvpy'
  | 'ib-dp-exam' | 'igcse-exam' | 'a-level-exam'
  | 'none';

export type IntentType =
  | 'explain'
  | 'question'
  | 'analogy'
  | 'summarise'
  | 'clarify'
  | 'example'
  | 'check'
  | 'other';

export interface StudentProfile {
  studentId: string;
  board: BoardId;
  classLevel: ClassLevel;
  subjectId: SubjectId;
  preferredLanguage: string;         // 'en', 'hi', 'ta', etc.
  secondaryLanguage?: string;
  examTargets: ExamTarget[];
  region: string;                    // 'IN-MH', 'IN-TN', etc.
  learningStyle?: 'visual' | 'auditory' | 'reading' | 'kinaesthetic';
  priorProgress: {
    topicsMastered: string[];
    topicsStrugglingWith: string[];
    averageAccuracy: number;
    lastActiveAt: string;
  };
}

export interface TutorRequest {
  studentId: string;
  message: string;
  context: {
    subjectId?: SubjectId;
    chapterId?: string;
    topicId?: string;
    subtopicId?: string;
    currentLectureId?: string;
  };
  conversationHistory: ChatMessage[];
}

export interface TutorPracticeQuestion {
  type: 'mcq' | 'short' | 'long' | 'fill-blanks' | 'true-false' | 'case-study';
  difficulty: 1 | 2 | 3 | 4 | 5;
  text: string;
  options?: string[];
  correctAnswer: string;
  solution: string;
  hint: string;
  commonMistake?: string;
  marks: number;
  boardAlignment: string;
}

export interface TutorResponse {
  id: string;
  intent: IntentType;
  outputType: 'explanation' | 'question' | 'analogy' | 'summary';
  generatedFor: {
    board: BoardId;
    classLevel: ClassLevel;
    subjectId: SubjectId;
    language: string;
    examTarget?: ExamTarget;
  };
  content: {
    text: string;             // markdown-rendered text
    mathBlocks?: string[];    // LaTeX for KaTeX
    diagramLinks?: string[];  // links to SVG/3D viewers
    questionIds?: string[];   // if questions, IDs from bank
    questions?: TutorPracticeQuestion[];
    keyTakeaway?: string;
    whereItBreaks?: string;
  };
  metadata: {
    model: string;
    tokensUsed: number;
    latencyMs: number;
    cached: boolean;
    verified: boolean;
    confidence: number;
    curriculumVersion: string;
  };
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: 'student' | 'ai';
  content: string;
  createdAt: string;
}

export interface ExamPattern {
  board: BoardId;
  classLevel: ClassLevel;
  style: 'mcq-heavy' | 'essay-heavy' | 'mixed' | 'practical';
  maxMarks: number;
  durationMinutes: number;
  questionTypes: string[];
  difficultyDistribution: {
    easy: number;      // percentage
    medium: number;
    hard: number;
  };
}

export interface CurriculumContext {
  board: BoardId;
  classLevel: ClassLevel;
  subjectId: SubjectId;
  subjectName: string;
  chapterId: string;
  chapterName: string;
  topicId: string;
  topicName: string;
  subtopicId?: string;
  subtopicName?: string;
  learningObjectives: string[];
  prerequisites: string[];
  standardFormulas: string[];
  examPattern: ExamPattern;
  language: string;
  vocabularyLevel: 'simple' | 'standard' | 'technical';
  contentDepth: 1 | 2 | 3 | 4 | 5;
  culturalContext: string;   // 'India', 'USA', 'UK', etc.
}

export interface VerificationResult {
  passed: boolean;
  failures: string[];
  warnings: string[];
}

export interface BoardStrategy {
  name: string;
  emphasis: string;
  vocabulary: string;
  questionStyle: string;
  languageSupport: string[];
  formulaPresentation: string;
  examples: string;
  depthBias: string;
}

export interface ClassStrategy {
  wordCount: { min: number; max: number };
  vocabulary: string;
  examples: string;
  sentenceLength: string;
  analogies: string;
  questionTypes: string[];
  readingLevel: string;
}
