import { 
  BehavioralSignals, 
  LearningStyleProfile, 
  VARKStyle 
} from './types';

/**
 * Checks if 2 weeks (14 days) have passed since last detection
 */
export function isRedetectionDue(lastDetectedAt: string): boolean {
  if (!lastDetectedAt) return true;
  const last = new Date(lastDetectedAt).getTime();
  const diffDays = (Date.now() - last) / (1000 * 60 * 60 * 24);
  return diffDays >= 14;
}

/**
 * Computes exponential recency weight for signals (30 days decay window)
 */
function computeRecencyWeight(timestampStr: string): number {
  const now = Date.now();
  const time = new Date(timestampStr).getTime();
  const ageInDays = (now - time) / (1000 * 60 * 60 * 24);
  
  if (ageInDays > 30) return 0.05; // Stale events past 30 days have minimal weight
  // Exponential decay e^(-0.05 * age) over 30 days
  return Math.exp(-0.05 * ageInDays);
}

/**
 * Bayesian VARK Style Detector
 * Combines equal priors (25, 25, 25, 25) with weighted behavioral evidence.
 * Normalizes by duration, weights by recency (30 days), and calculates confidence.
 */
export function detectLearningStyle(
  signals: BehavioralSignals,
  studentId: string = 'student_default'
): LearningStyleProfile {
  // 1. Bayesian Priors: Equal 25% probability distribution
  let rawVisual = 25;
  let rawAuditory = 25;
  let rawReading = 25;
  let rawKinaesthetic = 25;

  let totalSignalCount = 0;

  // 2. Process Visual Signals (diagram viewing, zooming, animation replays)
  signals.diagrams.forEach(d => {
    const w = computeRecencyWeight(d.timestamp);
    // Normalize duration (capped at 300s per interaction)
    const normDuration = Math.min(300, Math.max(1, d.duration));
    const scoreAdd = ((normDuration / 60) * 3 + d.zoomCount * 4 + d.replayCount * 6) * w;
    rawVisual += scoreAdd;
    totalSignalCount++;
  });

  // 3. Process Auditory Signals (narration listens, speech commands)
  signals.audios.forEach(a => {
    const w = computeRecencyWeight(a.timestamp);
    const normDuration = Math.min(300, Math.max(1, a.listenDuration));
    const scoreAdd = ((normDuration / 60) * 3 + a.voiceCommandCount * 5) * w;
    rawAuditory += scoreAdd;
    totalSignalCount++;
  });

  // 4. Process Reading/Writing Signals (scroll depth, note taking, reread count)
  signals.texts.forEach(t => {
    const w = computeRecencyWeight(t.timestamp);
    const scoreAdd = ((t.scrollDepth / 100) * 4 + t.rereadCount * 5 + t.noteCount * 8) * w;
    rawReading += scoreAdd;
    totalSignalCount++;
  });

  // 5. Process Kinaesthetic Signals (drawing, 3D model manipulation)
  signals.handsOn.forEach(h => {
    const w = computeRecencyWeight(h.timestamp);
    const scoreAdd = (h.drawCount * 6 + h.modelInteractionCount * 5) * w;
    rawKinaesthetic += scoreAdd;
    totalSignalCount++;
  });

  // 6. Normalize scores to sum to 100
  const totalRaw = rawVisual + rawAuditory + rawReading + rawKinaesthetic;
  
  const visualScore = Math.round((rawVisual / totalRaw) * 100);
  const auditoryScore = Math.round((rawAuditory / totalRaw) * 100);
  const readingScore = Math.round((rawReading / totalRaw) * 100);
  const kinaestheticScore = Math.round((rawKinaesthetic / totalRaw) * 100);

  // 7. Determine dominant style based on whether top style is significantly higher (>40% higher or clear margin)
  const scores: Array<{ style: VARKStyle; score: number }> = [
    { style: 'visual' as VARKStyle, score: visualScore },
    { style: 'auditory' as VARKStyle, score: auditoryScore },
    { style: 'reading' as VARKStyle, score: readingScore },
    { style: 'kinaesthetic' as VARKStyle, score: kinaestheticScore }
  ].sort((a, b) => b.score - a.score);

  const top = scores[0];
  const second = scores[1];
  const othersAvg = (scores[1].score + scores[2].score + scores[3].score) / 3;

  // Dominant if top style is > 40% of total score or > 40% higher relative to average of others
  let dominantStyle: VARKStyle = 'balanced';
  const relativeLead = othersAvg > 0 ? ((top.score - othersAvg) / othersAvg) : 0;

  if (top.score >= 38 || (relativeLead >= 0.40 && (top.score - second.score) >= 6)) {
    dominantStyle = top.style;
  }

  // 8. Confidence: calculated based on sample volume and separation margin
  const sampleConfidence = Math.min(1, totalSignalCount / 12);
  const marginConfidence = Math.min(1, (top.score - second.score) / 12);
  
  const confidence = totalSignalCount === 0 
    ? 25 // cold start initial prior confidence
    : Math.round((sampleConfidence * 0.5 + marginConfidence * 0.5) * 100);

  const nowStr = new Date().toISOString();

  return {
    studentId,
    visualScore,
    auditoryScore,
    readingScore,
    kinaestheticScore,
    dominantStyle,
    confidence: Math.min(100, Math.max(10, confidence)),
    isManualOverride: false,
    detectedAt: nowStr,
    updatedAt: nowStr
  };
}
