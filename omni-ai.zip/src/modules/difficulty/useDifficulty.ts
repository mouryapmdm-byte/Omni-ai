import { useState, useEffect, useCallback } from 'react';
import { 
  DifficultyState, 
  DifficultyLevel, 
  DifficultyAdjustmentEvent 
} from './types';
import { DifficultyEngine } from './difficultyEngine';
import { 
  getStoredDifficultyState, 
  saveDifficultyState, 
  resetStoredDifficultyState, 
  subscribeDifficultyUpdates 
} from './storage';

export function useDifficulty(
  studentId: string = 'student_default',
  topicId: string = 'general'
) {
  const [state, setState] = useState<DifficultyState>(() => 
    getStoredDifficultyState(studentId, topicId)
  );
  const [lastEvent, setLastEvent] = useState<DifficultyAdjustmentEvent | null>(null);

  useEffect(() => {
    setState(getStoredDifficultyState(studentId, topicId));
    const unsubscribe = subscribeDifficultyUpdates((updated) => {
      if (updated.studentId === studentId && updated.topicId === topicId) {
        setState(updated);
      }
    });
    return unsubscribe;
  }, [studentId, topicId]);

  const recordAnswer = useCallback((isCorrect: boolean) => {
    const { nextState, event } = DifficultyEngine.processAnswer(state, isCorrect);
    saveDifficultyState(nextState);
    setState(nextState);
    if (event) {
      setLastEvent(event);
    }
    return { nextState, event };
  }, [state]);

  const setLevelManually = useCallback((level: DifficultyLevel) => {
    const updated: DifficultyState = {
      ...state,
      currentLevel: level,
      fineDifficulty: level * 1.0,
      consecutiveCorrect: 0,
      consecutiveWrong: 0,
      intervention: null,
      interventionMessage: undefined,
      lastAdjustedAt: new Date().toISOString()
    };
    saveDifficultyState(updated);
    setState(updated);
  }, [state]);

  const dismissIntervention = useCallback(() => {
    const updated: DifficultyState = {
      ...state,
      intervention: null,
      interventionMessage: undefined
    };
    saveDifficultyState(updated);
    setState(updated);
  }, [state]);

  const resetDifficulty = useCallback(() => {
    const fresh = resetStoredDifficultyState(studentId, topicId);
    setState(fresh);
    setLastEvent(null);
  }, [studentId, topicId]);

  return {
    difficultyState: state,
    currentLevel: state.currentLevel,
    fineDifficulty: state.fineDifficulty,
    flowState: state.flowState,
    rollingAccuracy: state.rollingAccuracy,
    consecutiveCorrect: state.consecutiveCorrect,
    consecutiveWrong: state.consecutiveWrong,
    adaptiveRate: state.adaptiveRate,
    intervention: state.intervention,
    interventionMessage: state.interventionMessage,
    lastEvent,
    recordAnswer,
    setLevelManually,
    dismissIntervention,
    resetDifficulty
  };
}
