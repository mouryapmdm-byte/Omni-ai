import React, { useState, useEffect } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { History, QrCode, Share2, Copy, Check, Trash2, ArrowUpRight, BookOpen, Clock, Download, X, Sparkles } from 'lucide-react';
import { cn, getQrHistory, removeQrHistoryItem, clearQrHistory, QrHistoryItem, triggerHapticFeedback, downloadElegantQR } from '../lib/utils';
import { UserProfile } from '../types';

interface QrHistoryTabProps {
  theme: 'light' | 'dark';
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  showNotification: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onApplyHistoryItem?: (item: QrHistoryItem) => void;
}

export const QrHistoryTab: React.FC<QrHistoryTabProps> = ({
  theme,
  user,
  setUser,
  showNotification,
  onApplyHistoryItem
}) => {
  const [historyItems, setHistoryItems] = useState<QrHistoryItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'generated' | 'scanned'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activePreviewItem, setActivePreviewItem] = useState<QrHistoryItem | null>(null);

  const loadHistory = () => {
    setHistoryItems(getQrHistory());
  };

  useEffect(() => {
    loadHistory();
    const handleHistoryChange = () => loadHistory();
    window.addEventListener('omni_qr_history_changed', handleHistoryChange);
    return () => window.removeEventListener('omni_qr_history_changed', handleHistoryChange);
  }, []);

  const filteredItems = historyItems.filter(item => {
    if (filter === 'generated') return item.type === 'generated';
    if (filter === 'scanned') return item.type === 'scanned';
    return true;
  });

  const handleCopyPayload = async (item: QrHistoryItem) => {
    try {
      await navigator.clipboard.writeText(item.payload);
      setCopiedId(item.id);
      triggerHapticFeedback(15);
      showNotification('QR Code payload copied to clipboard!', 'success');
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      showNotification('Failed to copy payload', 'error');
    }
  };

  const handleApply = (item: QrHistoryItem) => {
    triggerHapticFeedback([20, 40, 20]);
    const updates: Partial<UserProfile> = {};
    if (item.subject) updates.subject = item.subject;
    if (item.topic) updates.topic = item.topic;
    if (item.difficulty) updates.difficulty = item.difficulty;
    if (item.tutor) updates.tutor = item.tutor;

    setUser(prev => {
      const next = { ...prev, ...updates };
      localStorage.setItem('omni_user', JSON.stringify(next));
      return next;
    });

    if (onApplyHistoryItem) {
      onApplyHistoryItem(item);
    }

    showNotification(
      item.topic ? `Re-applied session configuration: ${item.topic} (${item.subject || 'STEM'})` : 'Re-applied QR code configuration!',
      'success'
    );
  };

  const handleDelete = (id: string) => {
    triggerHapticFeedback(10);
    removeQrHistoryItem(id);
    showNotification('History item removed.', 'info');
  };

  const handleClearAll = () => {
    triggerHapticFeedback([30, 20, 10]);
    clearQrHistory();
    showNotification('QR Code History cleared.', 'info');
  };

  const formatDate = (timestamp: number) => {
    const d = new Date(timestamp);
    return d.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-5 py-2">
      {/* Intro Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="space-y-0.5">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <History size={16} className="text-indigo-500" />
            QR Code Study History
          </h3>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            View, re-apply, or re-share previously generated and scanned study session QR codes.
          </p>
        </div>

        {historyItems.length > 0 && (
          <button
            type="button"
            onClick={handleClearAll}
            className="self-start sm:self-auto px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-500 hover:text-rose-500 hover:border-rose-300 dark:hover:border-rose-950 transition cursor-pointer flex items-center gap-1.5"
          >
            <Trash2 size={12} />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => setFilter('all')}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer",
            filter === 'all'
              ? "bg-indigo-600 text-white shadow-sm font-black"
              : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          )}
        >
          All ({historyItems.length})
        </button>
        <button
          type="button"
          onClick={() => setFilter('generated')}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer",
            filter === 'generated'
              ? "bg-indigo-600 text-white shadow-sm font-black"
              : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          )}
        >
          Generated ({historyItems.filter(i => i.type === 'generated').length})
        </button>
        <button
          type="button"
          onClick={() => setFilter('scanned')}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer",
            filter === 'scanned'
              ? "bg-indigo-600 text-white shadow-sm font-black"
              : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          )}
        >
          Scanned ({historyItems.filter(i => i.type === 'scanned').length})
        </button>
      </div>

      {/* History Items List */}
      {filteredItems.length === 0 ? (
        <div className="p-8 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 text-center space-y-2">
          <QrCode size={32} className="mx-auto text-slate-300 dark:text-slate-700" />
          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
            No QR code history records found.
          </p>
          <p className="text-[11px] text-slate-400">
            Generate or scan QR codes in the Study Studio tab to record entries here for quick re-access!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3">
          {filteredItems.map(item => (
            <div
              key={item.id}
              className={cn(
                "p-4 rounded-xl border transition-all duration-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
                theme === 'dark'
                  ? "bg-slate-900/60 border-slate-800 hover:border-slate-700"
                  : "bg-white border-slate-200 hover:border-indigo-300 shadow-sm"
              )}
            >
              <div className="flex items-start gap-3">
                <div className={cn(
                  "p-2.5 rounded-xl text-white shadow-sm flex-shrink-0 mt-0.5",
                  item.type === 'generated' ? "bg-indigo-600" : "bg-emerald-600"
                )}>
                  <QrCode size={18} />
                </div>
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-black text-slate-800 dark:text-slate-100">
                      {item.title}
                    </span>
                    <span className={cn(
                      "text-[9px] font-black uppercase px-2 py-0.5 rounded-full border",
                      item.type === 'generated'
                        ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-600 dark:text-indigo-400"
                        : "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400"
                    )}>
                      {item.type}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
                    <span>{item.subtitle}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1 font-mono text-[10px]">
                      <Clock size={10} />
                      {formatDate(item.timestamp)}
                    </span>
                  </p>
                  <span className="text-[10px] font-mono text-slate-400 block truncate max-w-xs sm:max-w-md">
                    {item.payload}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1.5 self-end sm:self-center flex-shrink-0">
                <button
                  type="button"
                  onClick={() => handleApply(item)}
                  title="Re-Apply Study Session Parameters"
                  className="px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 transition cursor-pointer shadow-sm active:scale-95"
                >
                  <ArrowUpRight size={13} />
                  <span>Re-Apply</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActivePreviewItem(item)}
                  title="View QR Code"
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                  <QrCode size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => handleCopyPayload(item)}
                  title="Copy Link/Payload"
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                  {copiedId === item.id ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(item.id)}
                  title="Delete Item"
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* QR Code Modal Preview for History Item */}
      {activePreviewItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className={cn(
            "p-5 rounded-2xl border-2 max-w-sm w-full space-y-4 shadow-2xl animate-in zoom-in-95 duration-200",
            theme === 'dark' ? "bg-slate-900 border-indigo-500/60 text-slate-100" : "bg-white border-indigo-400 text-slate-900"
          )}>
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h4 className="text-xs font-black uppercase tracking-wider flex items-center gap-2">
                <QrCode size={16} className="text-indigo-500" />
                {activePreviewItem.title}
              </h4>
              <button
                type="button"
                onClick={() => setActivePreviewItem(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <div className="flex flex-col items-center justify-center p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="p-3 bg-white rounded-2xl shadow-lg border border-slate-200">
                <QRCodeCanvas
                  id={`history-qr-${activePreviewItem.id}`}
                  value={activePreviewItem.payload}
                  size={160}
                  level="H"
                  includeMargin={true}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  downloadElegantQR(`history-qr-${activePreviewItem.id}`, `qr-${activePreviewItem.id}.png`);
                  triggerHapticFeedback(15);
                  showNotification('QR image downloaded.', 'success');
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <Download size={13} />
                <span>Download Image</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  handleApply(activePreviewItem);
                  setActivePreviewItem(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl border border-indigo-500 text-indigo-600 dark:text-indigo-400 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
              >
                <ArrowUpRight size={13} />
                <span>Re-Apply Session</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
