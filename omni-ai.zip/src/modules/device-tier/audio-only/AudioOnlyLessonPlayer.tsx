import React, { useState, useEffect } from 'react';
import { 
  Headphones, Play, Pause, RotateCcw, Volume2, 
  Sparkles, Radio, Bookmark, CheckCircle2, ChevronRight, Zap 
} from 'lucide-react';
import { TranslationService } from '../../i18n/TranslationService';
import { useI18n } from '../../i18n/useI18n';

interface AudioOnlyLessonPlayerProps {
  topic?: string;
  subject?: string;
  isDark?: boolean;
}

export const AudioOnlyLessonPlayer: React.FC<AudioOnlyLessonPlayerProps> = ({
  topic = "Newton's Second Law of Motion",
  subject = "Physics",
  isDark = true
}) => {
  const { language, bilingualMode } = useI18n();
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [activeSegmentIndex, setActiveSegmentIndex] = useState<number>(0);
  const [audioSpeed, setAudioSpeed] = useState<number>(1.0);

  const audioSegments = [
    {
      id: 'seg-1',
      title: "Introduction: The Real-World Intuition",
      duration: "0:45",
      spokenScript: "Welcome, scholars! Imagine you are riding a bicycle on a flat road. If you apply a slight force on the pedals, you accelerate slowly. But if you stomp down with high power, you accelerate instantly. This direct relationship between force and acceleration is the heart of mechanics.",
      keyFormula: "F ∝ a",
      examTip: "Always state that force and acceleration share the identical vector direction."
    },
    {
      id: 'seg-2',
      title: "The Role of Inertial Mass",
      duration: "1:10",
      spokenScript: "Now imagine trying to push a giant boulder with that same strength. It barely budges! Why? Because greater mass resists changes in motion. Acceleration is inversely proportional to mass. Heavy objects demand massive force.",
      keyFormula: "a ∝ 1/m",
      examTip: "Mass is a scalar measure of inertia; it never changes with gravitational field strength."
    },
    {
      id: 'seg-3',
      title: "Master Equation & Practice Breakdown",
      duration: "1:30",
      spokenScript: "Putting it together: Net Force equals Mass times Acceleration (F = ma). If a cricket ball of mass 0.15 kilograms accelerates at 20 meters per second squared, the net force exerted by the bowler's hand is exactly 3 Newtons.",
      keyFormula: "F = m · a  ⇒  (0.15 kg)(20 m/s²) = 3.0 N",
      examTip: "Ensure mass is converted to SI units (kg) before multiplying."
    }
  ];

  const currentSegment = audioSegments[activeSegmentIndex];

  useEffect(() => {
    let timer: any;
    if (isPlaying) {
      // Speak current script automatically
      TranslationService.speakText(currentSegment.spokenScript, language);
      timer = setTimeout(() => {
        if (activeSegmentIndex < audioSegments.length - 1) {
          setActiveSegmentIndex(prev => prev + 1);
        } else {
          setIsPlaying(false);
        }
      }, 12000);
    }
    return () => clearTimeout(timer);
  }, [isPlaying, activeSegmentIndex, language]);

  const togglePlay = () => {
    if (!isPlaying) {
      setIsPlaying(true);
      TranslationService.speakText(currentSegment.spokenScript, language);
    } else {
      setIsPlaying(false);
      window.speechSynthesis?.cancel();
    }
  };

  return (
    <div className={`w-full rounded-2xl border flex flex-col overflow-hidden ${
      isDark ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
    }`}>
      {/* Audio-Only Mode Header */}
      <div className={`p-4 border-b flex flex-wrap items-center justify-between gap-3 ${
        isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-slate-50 border-slate-200'
      }`}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
            <Headphones size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-xs">Audio-First Ultra-Lite Player</h3>
              <span className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">
                1GB RAM Optimized
              </span>
            </div>
            <p className="text-[11px] opacity-60">High-fidelity pedagogical podcast with synchronized transcript &bull; &lt; 50MB/mo</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-2 py-0.5 rounded bg-slate-800 text-emerald-400 font-mono text-[10px] font-bold">
            64 kbps Audio Mode
          </span>
          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono text-[10px]">
            RAM: 35MB
          </span>
        </div>
      </div>

      {/* Main Content Body */}
      <div className="p-6 space-y-6">
        {/* Audio Waveform & Status Indicator */}
        <div className={`p-5 rounded-2xl border text-center space-y-4 ${
          isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center justify-center gap-1 h-8">
            {[40, 75, 100, 60, 30, 85, 95, 45, 65, 80, 50, 90, 70, 40].map((h, i) => (
              <span
                key={i}
                className={`w-1.5 rounded-full transition-all duration-300 ${
                  isPlaying ? 'bg-purple-500 animate-pulse' : 'bg-slate-700'
                }`}
                style={{ height: isPlaying ? `${h}%` : '20%' }}
              />
            ))}
          </div>

          <div>
            <h4 className="font-extrabold text-sm text-purple-300">{currentSegment.title}</h4>
            <p className="text-xs text-slate-400 mt-1">{subject} &bull; {topic}</p>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => setActiveSegmentIndex(Math.max(0, activeSegmentIndex - 1))}
              disabled={activeSegmentIndex === 0}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white disabled:opacity-40 cursor-pointer"
            >
              <RotateCcw size={16} />
            </button>

            <button
              onClick={togglePlay}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black text-xs shadow-lg transition flex items-center gap-2 cursor-pointer"
            >
              {isPlaying ? <Pause size={16} /> : <Play size={16} />}
              {isPlaying ? 'Pause Audio' : 'Play Lesson Audio'}
            </button>

            <button
              onClick={() => setActiveSegmentIndex(Math.min(audioSegments.length - 1, activeSegmentIndex + 1))}
              disabled={activeSegmentIndex === audioSegments.length - 1}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white disabled:opacity-40 cursor-pointer"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Live Synchronized Transcript */}
        <div className={`p-4 rounded-xl border space-y-2 ${
          isDark ? 'bg-slate-900/50 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
            <Radio size={12} /> Live Lesson Transcript:
          </span>
          <p className="text-xs sm:text-sm font-medium leading-relaxed">
            "{currentSegment.spokenScript}"
          </p>
          <div className="pt-2 border-t border-slate-800/60 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
            <span className="text-amber-400 font-bold">{currentSegment.keyFormula}</span>
            <span className="text-emerald-400 font-sans text-[11px] flex items-center gap-1">
              <CheckCircle2 size={12} /> {currentSegment.examTip}
            </span>
          </div>
        </div>

        {/* Lesson Segments Playlist */}
        <div className="space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Chapters & Key Milestones</span>
          <div className="space-y-1.5">
            {audioSegments.map((seg, idx) => (
              <button
                key={seg.id}
                onClick={() => {
                  setActiveSegmentIndex(idx);
                  if (isPlaying) {
                    TranslationService.speakText(seg.spokenScript, language);
                  }
                }}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between text-xs transition ${
                  activeSegmentIndex === idx
                    ? 'bg-purple-950/40 border-purple-500/80 text-purple-200 font-bold ring-1 ring-purple-500/50'
                    : isDark ? 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-700' : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] opacity-60">0{idx + 1}.</span>
                  <span>{seg.title}</span>
                </div>
                <span className="font-mono text-[10px] opacity-60">{seg.duration}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
