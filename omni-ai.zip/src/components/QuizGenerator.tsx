import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Brain, 
  Timer, 
  Settings2, 
  Play, 
  CheckCircle2, 
  XCircle, 
  ChevronRight, 
  ChevronLeft, 
  ChevronDown,
  ChevronUp,
  Share2, 
  RotateCcw, 
  Trophy,
  Clock,
  Layout,
  Layers,
  Target,
  AlertCircle,
  Loader2,
  Maximize2,
  Minimize2,
  Upload,
  Mic,
  MicOff,
  BarChart3,
  Flame,
  Zap,
  BookOpen,
  HelpCircle,
  FileText,
  Image as ImageIcon,
  History,
  TrendingUp,
  Award,
  Lightbulb,
  Search,
  Check,
  X,
  Eye,
  EyeOff,
  ArrowRight,
  Info,
  Sparkles,
  MessageSquare,
  Volume2,
  VolumeX,
  Download,
  Globe
} from 'lucide-react';
import { generateAIResponse } from '../lib/gemini';
import { cn, expandAbbreviationsForSpeech, getSyncShareUrl } from '../lib/utils';
import { LANGUAGES } from '../lib/constants';
import * as pdfjsLib from 'pdfjs-dist';
import Tesseract from 'tesseract.js';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  BarChart, 
  Bar, 
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';

// --- Constants & Types ---

const SUBJECT_DATA = [
  'Mathematics', 'Physics', 'Chemistry', 'Biology', 'History', 
  'Geography', 'Economics', 'Computer Science', 'Literature', 
  'Philosophy', 'Psychology', 'Sociology', 'Political Science', 
  'Art History', 'Music Theory', 'Astronomy', 'Environmental Science',
  'Business', 'Marketing', 'Finance', 'Law', 'Medicine', 'Engineering'
];

const DIFFICULTY_LEVELS = ['Beginner', 'Intermediate', 'Advanced', 'Expert', 'Adaptive'];
const QUESTION_FORMATS = ['MCQ', 'True/False', 'Short Answer', 'Assertion & Reasoning', 'Case-based'];

interface Question {
  id: string;
  type: string; // 'mcq' | 'tf' | 'short' | 'assertion' | 'case'
  question: string;
  options?: string[]; // For MCQ, TF, Assertion
  correctAnswer: any; // index for MCQ/TF, string for short
  passage?: string; // For case-based passage scenario
  context?: string; // For case-based context details
  assertion?: string; // For assertion-reasoning questions
  reason?: string; // For assertion-reasoning questions
  explanation: {
    stepByStep: (string | { what: string; why: string; formula?: string })[];
    whyCorrect: string;
    whyWrong: Record<string, string>; // Map option index to explanation
    alternativeMethod?: string;
    eli5?: string;
  };
  metadata: {
    topic: string;
    subtopic: string;
    difficulty: string;
    learningObjective: string;
    tags: string[];
  };
}

interface AnalyticsData {
  accuracy: number;
  avgTimePerQuestion: number;
  topicMastery: Record<string, number>;
  timeTrend: { question: number, time: number }[];
  difficultyTrend: { question: number, difficulty: number }[];
  weaknesses: string[];
  strengths: string[];
}

interface QuizGeneratorProps {
  userName: string;
  initialSubject?: string;
  initialTopic?: string;
  initialDifficulty?: string;
  initialLanguage?: string;
  onComplete?: (score: number, xp: number) => void;
  onGenerateMedia: (prompt: string, type: 'image' | 'video', options?: any) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

// --- Helper Components ---

const ProgressBar = ({ current, total, color = "bg-indigo-500" }: { current: number, total: number, color?: string }) => (
  <div className="h-2 bg-slate-100 rounded-full overflow-hidden w-full">
    <motion.div 
      initial={{ width: 0 }}
      animate={{ width: `${(current / total) * 100}%` }}
      className={cn("h-full transition-all duration-500", color)}
    />
  </div>
);

const Badge = ({ children, variant = 'default' }: { children: React.ReactNode, variant?: 'default' | 'success' | 'warning' | 'error' | 'indigo' }) => {
  const styles = {
    default: "bg-slate-100 text-slate-600",
    success: "bg-green-100 text-green-600",
    warning: "bg-amber-100 text-amber-600",
    error: "bg-red-100 text-red-600",
    indigo: "bg-indigo-100 text-indigo-600"
  };
  return (
    <span className={cn("px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider", styles[variant])}>
      {children}
    </span>
  );
};

// --- Main Component ---

export const QuizGenerator: React.FC<QuizGeneratorProps> = ({
  userName,
  initialSubject,
  initialTopic,
  initialDifficulty,
  initialLanguage,
  onComplete,
  onGenerateMedia,
  showNotification
}) => {
  // --- State ---
  const [step, setStep] = useState<'setup' | 'loading' | 'quiz' | 'results' | 'analytics' | 'review'>('setup');
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // Concept Breakdown Review states
  const [deepDiveLoading, setDeepDiveLoading] = useState<Record<number, boolean>>({});
  const [deepDiveExplanations, setDeepDiveExplanations] = useState<Record<number, string>>({});
  const [expandedExplanations, setExpandedExplanations] = useState<Record<number, boolean>>({});
  const [addedToDeck, setAddedToDeck] = useState<Record<string | number, boolean>>({});

  // Adaptive Performance Scaling States
  const [consecutiveCorrectCount, setConsecutiveCorrectCount] = useState(0);
  const [consecutiveIncorrectCount, setConsecutiveIncorrectCount] = useState(0);
  const [isAdaptingNextQuestion, setIsAdaptingNextQuestion] = useState(false);
  const [adaptiveScaleDirection, setAdaptiveScaleDirection] = useState<'escalate' | 'de-escalate' | null>(null);
  
  // Setup State
  const [customTopic, setCustomTopic] = useState<string>(initialTopic || '');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(initialSubject ? [initialSubject] : ['Mathematics']);

  useEffect(() => {
    if (initialTopic) {
      setCustomTopic(initialTopic);
    }
  }, [initialTopic]);
  const [level, setLevel] = useState(initialDifficulty || 'Intermediate');
  const [formatCounts, setFormatCounts] = useState<Record<string, number>>({
    'MCQ': 5,
    'True/False': 5,
    'Short Answer': 0,
    'Assertion & Reasoning': 0,
    'Case-based': 0
  });
  const questionCount = Object.values(formatCounts).reduce((a, b) => a + b, 0);
  const [duration, setDuration] = useState(15); // minutes
  const [formats, setFormats] = useState<string[]>(['MCQ']);
  const [isAdaptive, setIsAdaptive] = useState(false);
  const [isELI5, setIsELI5] = useState(false);
  const [isExamMode, setIsExamMode] = useState(false);
  const [learningMode, setLearningMode] = useState<'Learning' | 'Entrance Exam' | 'Practice'>('Learning');
  const [language, setLanguage] = useState(initialLanguage || 'English');
  const [quizMode, setQuizMode] = useState<'one-by-one' | 'all-at-once'>('one-by-one');

  // File Upload State
  const [uploadedText, setUploadedText] = useState<string | null>(null);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Quiz State
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, any>>({});
  const [questionTimes, setQuestionTimes] = useState<Record<number, number>>({});
  const [startTime, setStartTime] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  
  // Analytics State
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [xpEarned, setXpEarned] = useState(0);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const questionStartTimeRef = useRef<number>(0);

  const handleSpeak = (text: string) => {
    if (!text) return;
    const utterance = new SpeechSynthesisUtterance(expandAbbreviationsForSpeech(text));
    const rate = parseFloat(localStorage.getItem('omni_tts_rate') || '1.0');
    utterance.rate = rate;
    window.speechSynthesis.speak(utterance);
  };

  // Voice and Short Answer State
  const [shortAnswerText, setShortAnswerText] = useState('');
  const [isRecordingAnswer, setIsRecordingAnswer] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        
        if (finalTranscript) {
          const currentQ = questions[currentIndex];
          if (!currentQ) return;
          
          const text = finalTranscript.toLowerCase().trim();
          setShortAnswerText(text);

          if (currentQ.options && currentQ.options.length > 0) {
            let matchedIdx = -1;
            if (text.match(/^(option )?a$/i)) matchedIdx = 0;
            else if (text.match(/^(option )?b$/i)) matchedIdx = 1;
            else if (text.match(/^(option )?c$/i)) matchedIdx = 2;
            else if (text.match(/^(option )?d$/i)) matchedIdx = 3;
            else {
              matchedIdx = currentQ.options.findIndex(opt => opt.toLowerCase().includes(text));
            }

            if (matchedIdx !== -1) {
              handleAnswer(matchedIdx);
            }
          }
        } else if (interimTranscript && (!questions[currentIndex]?.options)) {
          setShortAnswerText(interimTranscript);
        }
      };

      recognitionRef.current.onend = () => {
        setIsRecordingAnswer(false);
      };
      
      recognitionRef.current.onerror = (event: any) => {
        const errorType = event?.error || '';
        if (errorType === 'no-speech' || errorType === 'aborted') {
          setIsRecordingAnswer(false);
          return;
        }
        if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
          showNotification?.('Microphone access denied.', 'warning');
        }
        setIsRecordingAnswer(false);
      };
    }
  }, [currentIndex, questions]);

  const toggleRecording = () => {
    if (isRecordingAnswer) {
      recognitionRef.current?.stop();
      setIsRecordingAnswer(false);
    } else {
      setShortAnswerText('');
      recognitionRef.current?.start();
      setIsRecordingAnswer(true);
    }
  };

  const submitShortAnswer = () => {
    if (shortAnswerText.trim()) {
      handleAnswer(shortAnswerText.trim());
      setShortAnswerText('');
    }
  };

  // --- Effects ---

  // Timer Logic
  useEffect(() => {
    if (step === 'quiz' && timeLeft > 0 && !isPaused) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleFinishQuiz();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [step, isPaused, timeLeft]);

  // Track time per question
  useEffect(() => {
    if (step === 'quiz') {
      questionStartTimeRef.current = Date.now();
    }
  }, [currentIndex, step]);

  // --- Handlers ---

  const toggleSubject = (s: string) => {
    setSelectedSubjects(prev => 
      prev.includes(s) ? prev.filter(item => item !== s) : [...prev, s]
    );
  };

  const extractTextFromPDF = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ');
      fullText += pageText + '\n';
    }
    return fullText;
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsProcessingFile(true);
    setUploadError(null);
    setUploadedFileName(file.name);

    try {
      let text = '';
      if (file.type === 'application/pdf') {
        text = await extractTextFromPDF(file);
      } else if (file.type === 'text/plain') {
        text = await file.text();
      } else {
        throw new Error('Unsupported file type. Please upload a PDF or TXT file.');
      }

      if (text.trim().length < 50) {
        throw new Error('The file content is too short to generate a meaningful quiz.');
      }

      setUploadedText(text);
    } catch (err: any) {
      setUploadError(err.message || 'Failed to process file');
      setUploadedFileName(null);
      setUploadedText(null);
    } finally {
      setIsProcessingFile(false);
    }
  };

  const handleImageScan = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsProcessingFile(true);
    setUploadError(null);
    setUploadedFileName(file.name);

    try {
      const result = await Tesseract.recognize(file, 'eng', {
        logger: m => console.log(m)
      });
      
      const text = result.data.text;
      if (text.trim().length < 50) {
        throw new Error('Could not extract enough text from the image. Please try a clearer photo.');
      }

      setUploadedText(text);
    } catch (err: any) {
      setUploadError(err.message || 'Failed to scan image');
      setUploadedFileName(null);
      setUploadedText(null);
    } finally {
      setIsProcessingFile(false);
    }
  };

  const clearUploadedContent = () => {
    setUploadedText(null);
    setUploadedFileName(null);
    setUploadError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  const handleGenerateQuiz = async () => {
    if (selectedSubjects.length === 0 && !uploadedText) {
      alert("Please select at least one subject or upload study material.");
      return;
    }
    
    const totalQuestions = Object.values(formatCounts).reduce((a, b) => a + b, 0);
    if (totalQuestions === 0) {
      alert("Please specify at least one question.");
      return;
    }

    setStep('loading');
    try {
      const prompt = `Generate a comprehensive quiz with the following question counts per format: ${JSON.stringify(formatCounts)}.
      ${uploadedText ? `IMPORTANT: The quiz MUST be based on the following content provided by the user:\n\n${uploadedText}\n\n` : `Subjects: ${selectedSubjects.join(', ')}`}
      ${customTopic ? `Focus Topic/Concept: ${customTopic}` : ''}
      Level: ${level}
      Language: ${language}
      Quiz Mode (Structure): ${quizMode}
      Learning Mode (Style): ${learningMode}
      Adaptive Mode: ${isAdaptive ? 'ON' : 'OFF'}
      ELI5 Mode: ${isELI5 ? 'ON' : 'OFF'}

      Requirements & Rules:
      1. Diverse question types as requested.
      2. Concept-level tagging (topic, subtopic, learning objective).
      3. For "case" (Case-based) type questions, you MUST provide a detailed background story or reading passage in a "passage" field, and the question itself in "question" field. Never leave out the context passage!
      4. For "assertion" (Assertion & Reasoning) type questions, you MUST specify the "assertion" statement and "reason" statement as separate "assertion" and "reason" fields, while the "question" field describes the overall problem. Ensure standard Assertion & Reasoning options are provided in "options" (usually A: Both Assertion and Reason are true and Reason is correct explanation, B: Both true but Reason is not correct, C: Assertion is true Reason is false, D: Assertion is false Reason is true).
      5. Explanations: step-by-step (each step MUST be an object with "what", "why", and optional "formula"), why correct, why wrong (for each option), alternative methods.
      6. If ELI5 is ON, include a simplified explanation using analogies.
      7. Keep explanations and text concise, clear, and highly focused to prevent token limit truncation. Ensure everything is complete and grammatically perfect.

      Output ONLY a JSON array of objects with this structure:
      [
        {
          "id": "q1",
          "type": "mcq", // or tf, short, assertion, case
          "question": "...", // The question itself
          "passage": "...", // REQUIRED for case-based. Complete background passage/scenario.
          "context": "...", // Optional for case-based. Additional metadata/scenario context.
          "assertion": "...", // REQUIRED for assertion-reasoning. The Assertion (A) statement.
          "reason": "...", // REQUIRED for assertion-reasoning. The Reason (R) statement.
          "options": ["...", "...", "...", "..."], // if applicable (MCQ, TF, Assertion)
          "correctAnswer": 0, // index or string
          "explanation": {
            "stepByStep": ["Step 1...", "Step 2..."],
            "whyCorrect": "...",
            "whyWrong": { "0": "...", "1": "..." }, // Map option index to explanation
            "alternativeMethod": "...",
            "eli5": "..." // if requested
          },
          "metadata": {
            "topic": "...",
            "subtopic": "...",
            "difficulty": "...",
            "learningObjective": "...",
            "tags": ["...", "..."]
          }
        }
      ]`;

      const response = await generateAIResponse(prompt, {
        systemInstruction: "You are a professional 2025-2026 learning engine and assessment system. Output ONLY valid JSON.",
        responseMimeType: "application/json"
      });

      const data = JSON.parse(response);
      setQuestions(data);
      setTimeLeft(duration * 60);
      setStartTime(Date.now());
      setStep('quiz');
      setCurrentIndex(0);
      setUserAnswers({});
      setQuestionTimes({});
      setConsecutiveCorrectCount(0);
      setConsecutiveIncorrectCount(0);
      setIsAdaptingNextQuestion(false);
      setAdaptiveScaleDirection(null);
    } catch (error) {
      console.error('Failed to generate quiz:', error);
      setStep('setup');
      alert('Failed to generate quiz. Please try again.');
    }
  };

  const adaptNextQuestion = async (direction: 'escalate' | 'de-escalate') => {
    setIsAdaptingNextQuestion(true);
    try {
      const currentTopicString = customTopic || (selectedSubjects.length > 0 ? selectedSubjects.join(', ') : 'Study Topic');
      const difficultyGoal = direction === 'escalate' ? 'Advanced/Case-Study' : 'Beginner/Conceptual';
      
      const prompt = `You are a world-class adaptive learning coach.
      The student has just answered questions on "${currentTopicString}".
      Based on their performance, we are dynamically scaling the difficulty.
      
      Scaling Direction: ${direction === 'escalate' ? 'ESCALATE (User got 3 correct in a row)' : 'DE-ESCALATE (User got 2 wrong in a row)'}
      Target Difficulty: ${difficultyGoal}
      
      Please generate a single, highly refined question matching this difficulty level.
      - If escalating, generate an advanced, multi-step application or Case-study style question with a detailed passage (context scenario).
      - If de-escalating, generate an illustrative, beginner-friendly conceptual question that clarifies core principles and includes simple analogies in ELI5.

      Requirements:
      1. Output exactly one valid JSON object (NOT an array) representing the question.
      2. The schema MUST match the following structure:
      {
        "id": "quiz-adapted-${Date.now()}",
        "type": "mcq", // mcq, tf, short, assertion, case
        "question": "The question text...",
        "passage": "Detailed scenario passage (highly recommended for Case-based/Escalated)",
        "context": "Any additional background context",
        "assertion": "For assertion type, the Assertion (A)",
        "reason": "For assertion type, the Reason (R)",
        "options": ["Option A", "Option B", "Option C", "Option D"], // If applicable
        "correctAnswer": 0, // index or string
        "explanation": {
          "stepByStep": [{"what": "Step 1...", "why": "Why this step..."}, {"what": "Step 2...", "why": "Why..."}],
          "whyCorrect": "Clear explanation of why the correct option is right.",
          "whyWrong": {
            "0": "Reason option A is incorrect",
            "1": "Reason option B is incorrect"
          },
          "alternativeMethod": "Alternative approach or conceptual shortcut",
          "eli5": "ELI5 analogy explaining the core concept in simple terms"
        },
        "metadata": {
          "topic": "${currentTopicString}",
          "subtopic": "Adapted Concept",
          "difficulty": "${direction === 'escalate' ? 'Advanced' : 'Beginner'}",
          "learningObjective": "Targeted cognitive reinforcement"
        }
      }
      
      Output ONLY the raw JSON object. Do not wrap in markdown or any text outside of the JSON.`;

      const response = await generateAIResponse(prompt, {
        systemInstruction: "You are a professional adaptive learning engine. Output ONLY a single valid JSON object.",
        responseMimeType: "application/json"
      });

      const newQuestion = JSON.parse(response);
      
      // Update the next question in the list!
      const updatedQuestions = [...questions];
      updatedQuestions[currentIndex + 1] = newQuestion;
      setQuestions(updatedQuestions);

      // Toast notification
      if (showNotification) {
        if (direction === 'escalate') {
          showNotification('🚀 Performance Escalation: Next question upgraded to Advanced Case-Study level!', 'success');
        } else {
          showNotification('💡 Adaptive Calibration: Next question calibrated to Beginner Conceptual level!', 'info');
        }
      }
      
      // Reset the triggers
      setConsecutiveCorrectCount(0);
      setConsecutiveIncorrectCount(0);
      setAdaptiveScaleDirection(null);
    } catch (err) {
      console.error("Adaptive scaling error:", err);
      // Fallback: reset if generation fails
      setConsecutiveCorrectCount(0);
      setConsecutiveIncorrectCount(0);
      setAdaptiveScaleDirection(null);
    } finally {
      setIsAdaptingNextQuestion(false);
    }
  };

  const handleAnswer = async (answer: any) => {
    const timeSpent = (Date.now() - questionStartTimeRef.current) / 1000;
    setQuestionTimes(prev => ({ ...prev, [currentIndex]: (prev[currentIndex] || 0) + timeSpent }));
    setUserAnswers(prev => ({ ...prev, [currentIndex]: answer }));
    
    // Adaptive Performance Scaling tracking
    const currentQ = questions[currentIndex];
    const isCorrect = answer === currentQ.correctAnswer;
    const isAdaptiveActive = isAdaptive || level === 'Adaptive';

    if (isAdaptiveActive) {
      if (isCorrect) {
        setConsecutiveCorrectCount(prev => {
          const nextVal = prev + 1;
          if (nextVal >= 3) {
            setAdaptiveScaleDirection('escalate');
          }
          return nextVal;
        });
        setConsecutiveIncorrectCount(0);
      } else {
        setConsecutiveIncorrectCount(prev => {
          const nextVal = prev + 1;
          if (nextVal >= 2) {
            setAdaptiveScaleDirection('de-escalate');
          }
          return nextVal;
        });
        setConsecutiveCorrectCount(0);
      }
    }

    if (!isExamMode) {
      setShowExplanation(true);
    } else {
      await handleNext();
    }
  };

  const handleNext = async () => {
    setShowExplanation(false);
    if (currentIndex < questions.length - 1) {
      const isAdaptiveActive = isAdaptive || level === 'Adaptive';
      
      if (isAdaptiveActive && adaptiveScaleDirection) {
        await adaptNextQuestion(adaptiveScaleDirection);
      }
      
      setCurrentIndex(prev => prev + 1);
    } else {
      handleFinishQuiz();
    }
  };

  const handleFinishQuiz = () => {
    const endTime = Date.now();
    const totalTime = (endTime - startTime) / 1000;
    
    // Calculate Score
    let correctCount = 0;
    const topicStats: Record<string, { correct: number, total: number }> = {};
    const timeTrend: { question: number, time: number }[] = [];
    
    questions.forEach((q, idx) => {
      const isCorrect = userAnswers[idx] === q.correctAnswer;
      if (isCorrect) correctCount++;
      
      const topic = q.metadata.topic;
      if (!topicStats[topic]) topicStats[topic] = { correct: 0, total: 0 };
      topicStats[topic].total++;
      if (isCorrect) topicStats[topic].correct++;
      
      timeTrend.push({ question: idx + 1, time: questionTimes[idx] || 0 });
    });

    const accuracy = (correctCount / questions.length) * 100;
    const avgTime = totalTime / questions.length;
    
    const mastery: Record<string, number> = {};
    Object.entries(topicStats).forEach(([topic, stats]) => {
      mastery[topic] = (stats.correct / stats.total) * 100;
    });

    const strengths = Object.entries(mastery)
      .filter(([_, score]) => score >= 80)
      .map(([topic]) => topic);
    
    const weaknesses = Object.entries(mastery)
      .filter(([_, score]) => score < 60)
      .map(([topic]) => topic);

    const analyticsData: AnalyticsData = {
      accuracy,
      avgTimePerQuestion: avgTime,
      topicMastery: mastery,
      timeTrend,
      difficultyTrend: questions.map((q, i) => ({ question: i + 1, difficulty: q.metadata.difficulty === 'Expert' ? 4 : q.metadata.difficulty === 'Advanced' ? 3 : 2 })),
      strengths,
      weaknesses
    };

    const xp = Math.round(correctCount * 50 + (isPassed(accuracy) ? 500 : 100));
    setXpEarned(xp);
    setAnalytics(analyticsData);
    
    // Clear old diagnostics and pre-populate expanded states
    setDeepDiveLoading({});
    setDeepDiveExplanations({});
    const initialExpanded: Record<number, boolean> = {};
    questions.forEach((q, idx) => {
      initialExpanded[idx] = userAnswers[idx] !== q.correctAnswer;
    });
    setExpandedExplanations(initialExpanded);

    setStep('results');
    onComplete?.(correctCount, xp);
  };

  const isPassed = (acc: number) => acc >= 70;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleShare = () => {
    if (!analytics) return;
    const text = `I just completed an AI-powered ${selectedSubjects.join(' & ')} quiz with ${Math.round(analytics.accuracy)}% accuracy! 🚀\nCheck out this AI Learning Engine!`;
    if (navigator.share) {
      navigator.share({
        title: 'Quiz Results',
        text: text,
        url: getSyncShareUrl(),
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(text).then(() => {
        alert('Results copied to clipboard!');
      });
    }
  };

  // --- Render Functions ---

  const renderSetup = () => (
    <div className={cn(
      "p-8 mx-auto space-y-10 transition-all duration-500",
      isFullscreen ? "fixed inset-0 z-[200] bg-white overflow-y-auto" : "max-w-4xl"
    )}>
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-200">
            <Brain size={32} />
          </div>
          <div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">AI Learning Engine</h2>
            <p className="text-slate-500 font-medium">Next-Gen Assessment & Personalization</p>
          </div>
        </div>
        <button 
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="p-3 hover:bg-slate-100 rounded-2xl text-slate-400 transition-all"
        >
          {isFullscreen ? <Minimize2 size={24} /> : <Maximize2 size={24} />}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Subjects */}
        <div className="lg:col-span-2 space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                <Layers size={18} className="text-indigo-600" /> Select Subjects
              </label>
              <span className="text-xs font-bold text-slate-400">{selectedSubjects.length} selected</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {SUBJECT_DATA.map(s => (
                <button
                  key={s}
                  onClick={() => toggleSubject(s)}
                  className={cn(
                    "px-4 py-3 rounded-xl text-xs font-bold transition-all border-2 text-left flex items-center justify-between",
                    selectedSubjects.includes(s) 
                      ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100" 
                      : "bg-white border-slate-100 text-slate-600 hover:border-indigo-200"
                  )}
                >
                  {s}
                  {selectedSubjects.includes(s) && <Check size={14} />}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
              <Brain size={18} className="text-indigo-600" /> Focus Concept or Topic (Optional)
            </label>
            <input
              type="text"
              value={customTopic}
              onChange={(e) => setCustomTopic(e.target.value)}
              placeholder="e.g. Coulomb's Law, Quadratic Formula, Wave Optics..."
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-slate-800 shadow-sm"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                <Settings2 size={18} className="text-indigo-600" /> Difficulty
              </label>
              <div className="grid grid-cols-2 gap-2">
                {DIFFICULTY_LEVELS.map(l => (
                  <button
                    key={l}
                    onClick={() => setLevel(l)}
                    className={cn(
                      "px-4 py-3 rounded-xl text-xs font-bold transition-all border-2",
                      level === l 
                        ? "bg-slate-900 border-slate-900 text-white" 
                        : "bg-white border-slate-100 text-slate-600 hover:border-slate-200"
                    )}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-3">
              <label className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                <Layout size={18} className="text-indigo-600" /> Formats
              </label>
              <div className="grid grid-cols-2 gap-2">
                {QUESTION_FORMATS.map(f => (
                  <button
                    key={f}
                    onClick={() => setFormats(prev => prev.includes(f) ? prev.filter(i => i !== f) : [...prev, f])}
                    className={cn(
                      "px-4 py-3 rounded-xl text-xs font-bold transition-all border-2",
                      formats.includes(f) 
                        ? "bg-indigo-50 border-indigo-200 text-indigo-600" 
                        : "bg-white border-slate-100 text-slate-600 hover:border-slate-200"
                    )}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                <Play size={18} className="text-indigo-600" /> Display Mode
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setQuizMode('one-by-one')}
                  className={cn(
                    "px-4 py-3 rounded-xl text-xs font-bold transition-all border-2",
                    quizMode === 'one-by-one' 
                      ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100" 
                      : "bg-white border-slate-100 text-slate-600 hover:border-indigo-200"
                  )}
                >
                  One by One
                </button>
                <button
                  onClick={() => setQuizMode('all-at-once')}
                  className={cn(
                    "px-4 py-3 rounded-xl text-xs font-bold transition-all border-2",
                    quizMode === 'all-at-once' 
                      ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100" 
                      : "bg-white border-slate-100 text-slate-600 hover:border-indigo-200"
                  )}
                >
                  All at Once
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                <BookOpen size={18} className="text-indigo-600" /> Learning Mode
              </label>
              <div className="grid grid-cols-1 gap-2">
                {(['Learning', 'Entrance Exam', 'Practice'] as const).map(mode => (
                  <button
                    key={mode}
                    onClick={() => setLearningMode(mode)}
                    className={cn(
                      "px-4 py-3 rounded-xl text-xs font-bold transition-all border-2",
                      learningMode === mode 
                        ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100" 
                        : "bg-white border-slate-100 text-slate-600 hover:border-indigo-200"
                    )}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                <Globe size={18} className="text-indigo-600" /> Quiz Language
              </label>
              <select
                value={LANGUAGES.find(l => l.name.toLowerCase() === language.toLowerCase())?.code || 'en'}
                onChange={(e) => {
                  const selectedLangObj = LANGUAGES.find(l => l.code === e.target.value);
                  if (selectedLangObj) {
                    setLanguage(selectedLangObj.name);
                  }
                }}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-slate-800 shadow-sm"
              >
                {LANGUAGES.map(lang => (
                  <option key={lang.code} value={lang.code}>
                    {lang.flag} {lang.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Right Column: Config & Modes */}
        <div className="space-y-8 bg-slate-50 p-6 rounded-3xl border border-slate-100">
          <div className="space-y-6">
            <div className="space-y-3">
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Questions per Format</label>
              <div className="space-y-2">
                {formats.map(format => (
                  <div key={format} className="flex items-center gap-4">
                    <span className="text-xs font-bold text-slate-700 w-32">{format}</span>
                    <input 
                      type="number" min="0" max="50"
                      value={formatCounts[format] || 0}
                      onChange={(e) => setFormatCounts(prev => ({ ...prev, [format]: parseInt(e.target.value) || 0 }))}
                      className="w-16 p-2 rounded-lg border border-slate-200 text-xs font-bold text-center"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Duration (Mins)</label>
              <div className="flex items-center gap-4">
                <input 
                  type="range" min="5" max="180" step="5"
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  className="flex-1 accent-indigo-600"
                />
                <span className="w-12 text-center font-black text-slate-900">{duration}</span>
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-200">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap size={16} className="text-amber-500" />
                    <span className="text-sm font-bold text-slate-700">Adaptive Intelligence</span>
                  </div>
                  <button 
                    onClick={() => setIsAdaptive(!isAdaptive)}
                    className={cn(
                      "w-12 h-6 rounded-full transition-all relative",
                      isAdaptive ? "bg-indigo-600" : "bg-slate-300"
                    )}
                  >
                    <div className={cn("absolute top-1 w-4 h-4 bg-white rounded-full transition-all", isAdaptive ? "left-7" : "left-1")} />
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-relaxed">
                  Scales difficulty dynamically mid-quiz. Escalates to Advanced Case-Study style after 3 correct answers, or calibrates to Conceptual level after 2 incorrect answers to keep you in the optimal learning zone.
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Lightbulb size={16} className="text-indigo-500" />
                  <span className="text-sm font-bold text-slate-700">ELI5 Mode</span>
                </div>
                <button 
                  onClick={() => setIsELI5(!isELI5)}
                  className={cn(
                    "w-12 h-6 rounded-full transition-all relative",
                    isELI5 ? "bg-indigo-600" : "bg-slate-300"
                  )}
                >
                  <div className={cn("absolute top-1 w-4 h-4 bg-white rounded-full transition-all", isELI5 ? "left-7" : "left-1")} />
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertCircle size={16} className="text-red-500" />
                  <span className="text-sm font-bold text-slate-700">Exam Simulation</span>
                </div>
                <button 
                  onClick={() => setIsExamMode(!isExamMode)}
                  className={cn(
                    "w-12 h-6 rounded-full transition-all relative",
                    isExamMode ? "bg-indigo-600" : "bg-slate-300"
                  )}
                >
                  <div className={cn("absolute top-1 w-4 h-4 bg-white rounded-full transition-all", isExamMode ? "left-7" : "left-1")} />
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {uploadedFileName && (
              <div className="flex items-center justify-between p-3 bg-indigo-50 border border-indigo-100 rounded-xl">
                <div className="flex items-center gap-2 overflow-hidden">
                  <FileText size={16} className="text-indigo-600 shrink-0" />
                  <span className="text-xs font-bold text-indigo-900 truncate">{uploadedFileName}</span>
                </div>
                <button onClick={clearUploadedContent} className="p-1 hover:bg-indigo-100 rounded-full text-indigo-600">
                  <X size={14} />
                </button>
              </div>
            )}
            
            {uploadError && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-xl flex items-center gap-2 text-red-600">
                <AlertCircle size={14} />
                <span className="text-[10px] font-bold uppercase">{uploadError}</span>
              </div>
            )}

            <div className="flex gap-2">
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                accept=".pdf,.txt" 
                className="hidden" 
              />
              <input 
                type="file" 
                ref={imageInputRef} 
                onChange={handleImageScan} 
                accept="image/*" 
                className="hidden" 
              />
              
              <button 
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessingFile}
                className="flex-1 p-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 flex items-center justify-center gap-2 hover:bg-slate-50 transition-all disabled:opacity-50"
              >
                {isProcessingFile ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />} 
                Upload PDF/Notes
              </button>
              <button 
                onClick={() => imageInputRef.current?.click()}
                disabled={isProcessingFile}
                className="flex-1 p-3 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 flex items-center justify-center gap-2 hover:bg-slate-50 transition-all disabled:opacity-50"
              >
                {isProcessingFile ? <Loader2 size={14} className="animate-spin" /> : <ImageIcon size={14} />} 
                Scan Image
              </button>
            </div>
            <button 
              onClick={handleGenerateQuiz}
              disabled={isProcessingFile}
              className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 flex items-center justify-center gap-3 group disabled:opacity-50"
            >
              Start Learning Engine <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderLoading = () => (
    <div className={cn(
      "flex flex-col items-center justify-center p-20 space-y-8 transition-all duration-500",
      isFullscreen ? "fixed inset-0 z-[200] bg-white" : ""
    )}>
      <div className="relative">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          className="text-indigo-600"
        >
          <Loader2 size={80} strokeWidth={1.5} />
        </motion.div>
        <div className="absolute inset-0 flex items-center justify-center">
          <Brain size={32} className="text-indigo-600 animate-pulse" />
        </div>
      </div>
      <div className="text-center space-y-3 max-w-md">
        <h3 className="text-2xl font-black text-slate-900">Synthesizing Knowledge</h3>
        <p className="text-slate-500 font-medium leading-relaxed">
          Omni AI is analyzing {selectedSubjects.join(' & ')} to create a personalized {level} level assessment with {questionCount} questions.
        </p>
        <div className="flex gap-2 justify-center pt-4">
          <Badge variant="indigo">Deep Conceptual Analysis</Badge>
          <Badge variant="indigo">Smart Explanations</Badge>
          <Badge variant="indigo">Adaptive Flow</Badge>
        </div>
      </div>
    </div>
  );

  const renderQuiz = () => {
    const currentQ = questions[currentIndex];
    const progress = ((currentIndex + 1) / questions.length) * 100;

    return (
      <div className={cn(
        "relative flex flex-col bg-white transition-all duration-500",
        isFullscreen ? "fixed inset-0 z-[200] h-screen" : "h-[700px] rounded-3xl overflow-hidden border border-slate-200 shadow-2xl"
      )}>
        {isAdaptingNextQuestion && (
          <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-md z-[210] flex flex-col items-center justify-center p-8 text-center text-white">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="max-w-md space-y-6 flex flex-col items-center"
            >
              <div className="p-4 bg-indigo-600/20 text-indigo-400 rounded-3xl border border-indigo-500/30 animate-pulse">
                <Brain size={48} />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black tracking-tight">
                  {adaptiveScaleDirection === 'escalate' ? '🚀 Performance Escalating' : '💡 Calibrating Difficulty'}
                </h3>
                <p className="text-indigo-400 font-bold text-xs uppercase tracking-widest">
                  {adaptiveScaleDirection === 'escalate' ? '3 Correct Answers in a Row' : 'Strengthening Core Fundamentals'}
                </p>
              </div>
              <p className="text-sm font-semibold text-slate-300 leading-relaxed">
                {adaptiveScaleDirection === 'escalate'
                  ? 'You are doing amazing! The AI assessment engine is dynamically upgrading your next question to an Advanced Case-Study level to keep you in the optimal learning zone.'
                  : 'Let’s take a breath! The AI assessment engine is tailoring the next question to standard Conceptual level to ensure solid foundation before moving forward.'}
              </p>
              <div className="flex items-center gap-3 text-indigo-400 font-bold text-sm">
                <Loader2 className="animate-spin" size={18} />
                <span>Synthesizing custom challenge...</span>
              </div>
            </motion.div>
          </div>
        )}
        {/* Header */}
        <div className="bg-white border-b px-6 py-4 flex justify-between items-center sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-md shadow-indigo-100">
              <Brain size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-sm text-slate-900">{currentQ.metadata.topic}</h3>
                <Badge variant="indigo">{currentQ.metadata.difficulty}</Badge>
              </div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{currentQ.metadata.subtopic}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-2xl font-black text-sm transition-all",
              timeLeft < 60 ? "bg-red-50 text-red-600 animate-pulse" : "bg-slate-50 text-slate-600"
            )}>
              <Clock size={16} />
              {formatTime(timeLeft)}
            </div>
            <div className="h-8 w-px bg-slate-200" />
            <button 
              onClick={toggleRecording}
              className={cn(
                "p-2.5 rounded-xl transition-all",
                isRecordingAnswer ? "bg-red-500 text-white shadow-lg shadow-red-200 animate-pulse" : "bg-slate-50 text-slate-400 hover:bg-slate-100"
              )}
            >
              {isRecordingAnswer ? <Mic size={20} /> : <MicOff size={20} />}
            </button>
            <button 
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2.5 bg-slate-50 text-slate-400 rounded-xl hover:bg-slate-100 transition-all"
            >
              {isFullscreen ? <Minimize2 size={20} /> : <Maximize2 size={20} />}
            </button>
            <button 
              onClick={handleFinishQuiz}
              className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-slate-800 transition-all"
            >
              Finish
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-1.5 bg-slate-100 w-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className="h-full bg-indigo-600 shadow-[0_0_10px_rgba(79,70,229,0.5)]"
          />
        </div>

        {/* Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {quizMode === 'one-by-one' ? (
            <>
              {/* Main Question Area */}
              <div className={cn(
                "flex-1 overflow-y-auto p-8 md:p-12 transition-all duration-500",
                showExplanation ? "w-1/2" : "w-full"
              )}>
                <div className="max-w-3xl mx-auto space-y-10">
                  <div className="space-y-6">
                    <div className="flex items-center gap-3">
                      <span className="w-10 h-10 bg-slate-900 dark:bg-indigo-600 text-white rounded-xl flex items-center justify-center font-black text-lg">
                        {currentIndex + 1}
                      </span>
                      <div className="h-px flex-1 bg-slate-100 dark:bg-slate-800" />
                      <span className="text-xs font-black text-slate-400 uppercase tracking-widest">
                        {currentIndex + 1} / {questions.length}
                      </span>
                    </div>
                    
                    <div className="space-y-4">
                      {currentQ.passage && (
                        <div className="p-6 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                          <h4 className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                            <Layers size={14} /> Case Passage / Context
                          </h4>
                          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                            {currentQ.passage}
                          </p>
                          {currentQ.context && (
                            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 italic">
                              Context: {currentQ.context}
                            </p>
                          )}
                        </div>
                      )}

                      {(currentQ.assertion || currentQ.reason) && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {currentQ.assertion && (
                            <div className="p-5 bg-blue-50/50 dark:bg-blue-950/20 rounded-2xl border border-blue-100 dark:border-blue-900/30 space-y-1">
                              <span className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-wider block">Assertion (A)</span>
                              <p className="text-sm font-bold text-slate-800 dark:text-slate-200 leading-relaxed">
                                {currentQ.assertion}
                              </p>
                            </div>
                          )}
                          {currentQ.reason && (
                            <div className="p-5 bg-purple-50/50 dark:bg-purple-950/20 rounded-2xl border border-purple-100 dark:border-purple-900/30 space-y-1">
                              <span className="text-[10px] font-black text-purple-600 dark:text-purple-400 uppercase tracking-wider block">Reason (R)</span>
                              <p className="text-sm font-bold text-slate-800 dark:text-slate-200 leading-relaxed">
                                {currentQ.reason}
                              </p>
                            </div>
                          )}
                        </div>
                      )}

                      <h2 className="text-3xl font-black text-slate-900 dark:text-white leading-tight">
                        {currentQ.question}
                      </h2>
                      <p className="text-sm font-medium text-slate-500 italic">
                        Objective: {currentQ.metadata.learningObjective}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    {currentQ.options && currentQ.options.length > 0 ? (
                      currentQ.options.map((option, idx) => {
                        const isSelected = userAnswers[currentIndex] === idx;
                        const isCorrect = idx === currentQ.correctAnswer;
                        const showResult = showExplanation;

                        const OptionWrapper = showResult ? "div" : "button";

                        return (
                          <OptionWrapper
                            key={idx}
                            {...(!showResult && { onClick: () => handleAnswer(idx) })}
                            className={cn(
                              "p-6 rounded-3xl border-2 text-left transition-all flex items-center justify-between group relative overflow-hidden",
                              isSelected && !showResult && "border-indigo-600 bg-indigo-50/50",
                              showResult && isCorrect && "border-green-500 bg-green-50/50",
                              showResult && isSelected && !isCorrect && "border-red-500 bg-red-50/50",
                              !isSelected && !showResult && "border-slate-100 bg-white hover:border-indigo-200 hover:bg-slate-50"
                            )}
                          >
                            <div className="flex items-center gap-4 z-10 w-full pr-12">
                              <span className={cn(
                                "w-8 h-8 flex-shrink-0 rounded-xl flex items-center justify-center font-black text-sm transition-all",
                                isSelected && !showResult && "bg-indigo-600 text-white",
                                showResult && isCorrect && "bg-green-500 text-white",
                                showResult && isSelected && !isCorrect && "bg-red-500 text-white",
                                !isSelected && !showResult && "bg-slate-100 text-slate-400 group-hover:bg-indigo-100 group-hover:text-indigo-600"
                              )}>
                                {String.fromCharCode(65 + idx)}
                              </span>
                              <span className={cn(
                                "font-bold text-lg",
                                isSelected || (showResult && isCorrect) ? "text-slate-900" : "text-slate-600"
                              )}>
                                {option}
                              </span>
                            </div>
                            
                            <div className="z-10 flex flex-col items-end justify-center gap-2 flex-shrink-0">
                              {showResult && isCorrect && <CheckCircle2 className="text-green-500" size={24} />}
                              {showResult && isSelected && !isCorrect && <XCircle className="text-red-500" size={24} />}
                              {showResult && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleSpeak(option);
                                  }}
                                  className="p-2 bg-indigo-100 text-indigo-600 rounded-lg hover:bg-indigo-200 transition-colors pointer-events-auto mt-2"
                                >
                                  <Volume2 size={20} />
                                </button>
                              )}
                            </div>
                          </OptionWrapper>
                        );
                      })
                    ) : (
                      <div className="space-y-4">
                        <div className="relative">
                          <textarea
                            disabled={showExplanation}
                            value={showExplanation ? String(userAnswers[currentIndex] || '') : shortAnswerText}
                            onChange={(e) => setShortAnswerText(e.target.value)}
                            placeholder="Type or speak your answer..."
                            className={cn(
                              "w-full min-h-[120px] p-6 pr-16 rounded-3xl border-2 text-lg font-medium resize-none transition-all outline-none",
                              showExplanation && userAnswers[currentIndex] ? "border-slate-200 bg-slate-50 text-slate-800" : "border-slate-200 bg-white focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/20"
                            )}
                          />
                          {!showExplanation && (
                            <button
                              onClick={toggleRecording}
                              className={cn(
                                "absolute right-4 bottom-4 p-3 rounded-2xl transition-all",
                                isRecordingAnswer 
                                  ? "bg-red-500 text-white shadow-lg shadow-red-200 animate-pulse" 
                                  : "bg-indigo-100 text-indigo-600 hover:bg-indigo-200"
                              )}
                            >
                              <Mic size={24} />
                            </button>
                          )}
                        </div>
                        
                        {!showExplanation && (
                          <div className="flex justify-end">
                            <button
                              onClick={submitShortAnswer}
                              disabled={!shortAnswerText.trim()}
                              className="px-8 py-3 bg-indigo-600 text-white rounded-2xl font-black disabled:opacity-50 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
                            >
                              Submit Answer
                            </button>
                          </div>
                        )}
                        {showExplanation && (
                          <div className="flex justify-end py-2">
                            <button
                              onClick={() => handleSpeak(shortAnswerText || userAnswers[currentIndex])}
                              className="flex items-center gap-2 px-4 py-2 bg-indigo-100 text-indigo-600 rounded-xl hover:bg-indigo-200 transition-colors font-bold text-sm"
                            >
                              <Volume2 size={16} /> Read Answer
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {isExamMode && (
                    <div className="flex justify-between pt-10">
                      <button 
                        disabled={currentIndex === 0}
                        onClick={() => setCurrentIndex(prev => prev - 1)}
                        className="flex items-center gap-2 px-8 py-4 rounded-2xl font-black text-slate-400 disabled:opacity-30 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
                      >
                        <ChevronLeft size={24} /> Previous
                      </button>
                      <button 
                        onClick={() => handleNext()}
                        className="flex items-center gap-2 px-10 py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-slate-800 transition-all shadow-xl shadow-slate-200"
                      >
                        {currentIndex === questions.length - 1 ? 'Finish Quiz' : 'Next Question'} <ChevronRight size={24} />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Explanation Side Panel */}
              <AnimatePresence>
                {showExplanation && (
                  <motion.div 
                    initial={{ x: '100%' }}
                    animate={{ x: 0 }}
                    exit={{ x: '100%' }}
                    className="w-1/2 bg-slate-50 dark:bg-slate-950 border-l border-slate-200 dark:border-slate-800 overflow-y-auto p-10 space-y-10"
                  >
                    <div className="flex justify-between items-center">
                      <h3 className="text-2xl font-black text-slate-900 dark:text-white flex items-center gap-3">
                        <Lightbulb className="text-amber-500" size={28} /> Smart Insight
                      </h3>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => onGenerateMedia(currentQ.question as any, 'image')}
                          className="p-3 bg-indigo-100 text-indigo-600 rounded-2xl hover:bg-indigo-200 transition-all"
                        >
                          <ImageIcon size={24} />
                        </button>
                        <button 
                          onClick={handleNext}
                          className="p-3 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 dark:shadow-none"
                        >
                          <ChevronRight size={24} />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div className="space-y-4">
                        <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Step-by-Step Solution</h4>
                        <div className="space-y-3">
                          {currentQ.explanation.stepByStep.map((step, i) => {
                            const isDetailed = typeof step === 'object';
                            return (
                              <div key={i} className="flex gap-4 p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
                                <span className="w-6 h-6 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center text-xs font-black flex-shrink-0">
                                  {i + 1}
                                </span>
                                <div className="space-y-2">
                                  {isDetailed ? (
                                    <>
                                      <p className="text-sm font-black text-slate-900 dark:text-white leading-relaxed">{step.what}</p>
                                      <p className="text-xs font-bold text-slate-500 dark:text-slate-400 leading-relaxed italic">Why: {step.why}</p>
                                      {step.formula && (
                                        <div className="p-2 bg-slate-900 rounded-lg text-center font-mono text-xs text-indigo-300">
                                          <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>{`$${step.formula}$`}</Markdown>
                                        </div>
                                      )}
                                    </>
                                  ) : (
                                    <p className="text-sm font-bold text-slate-700 dark:text-slate-200 leading-relaxed">{step}</p>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="p-6 bg-indigo-600 text-white rounded-3xl shadow-xl shadow-indigo-100 dark:shadow-none space-y-3 relative group">
                        <div className="flex justify-between items-center">
                          <h4 className="text-xs font-black uppercase tracking-widest opacity-70">The Core Concept</h4>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSpeak(currentQ.explanation.whyCorrect);
                            }}
                            className="p-2 bg-indigo-500 hover:bg-indigo-400 text-white rounded-lg transition-colors"
                            title="Read aloud"
                          >
                            <Volume2 size={16} />
                          </button>
                        </div>
                        <p className="text-lg font-bold leading-tight">{currentQ.explanation.whyCorrect}</p>
                      </div>

                      {userAnswers[currentIndex] !== currentQ.correctAnswer && (
                        <div className="p-6 bg-red-50 dark:bg-red-900/20 border-2 border-red-100 dark:border-red-900/30 rounded-3xl space-y-3">
                          <h4 className="text-xs font-black text-red-400 uppercase tracking-widest">Why your answer was incorrect</h4>
                          <p className="text-sm font-bold text-red-900 dark:text-red-200 leading-relaxed">
                            {currentQ.explanation.whyWrong[userAnswers[currentIndex]] || "This option doesn't address the core requirement of the question."}
                          </p>
                        </div>
                      )}

                      {isELI5 && currentQ.explanation.eli5 && (
                        <div className="p-6 bg-amber-50 dark:bg-amber-900/20 border-2 border-amber-100 dark:border-amber-900/30 rounded-3xl space-y-3">
                          <h4 className="text-xs font-black text-amber-600 uppercase tracking-widest flex items-center gap-2">
                            <Award size={14} /> Simplified (ELI5)
                          </h4>
                          <p className="text-sm font-bold text-amber-900 dark:text-amber-200 leading-relaxed italic">
                            "{currentQ.explanation.eli5}"
                          </p>
                        </div>
                      )}

                      {currentQ.explanation.alternativeMethod && (
                        <div className="p-6 bg-green-50 border-2 border-green-100 rounded-3xl space-y-3">
                          <h4 className="text-xs font-black text-green-600 uppercase tracking-widest">Alternative Method</h4>
                          <p className="text-sm font-bold text-green-900 leading-relaxed">
                            {currentQ.explanation.alternativeMethod}
                          </p>
                        </div>
                      )}
                    </div>

                    <button 
                      onClick={handleNext}
                      className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-3"
                    >
                      Continue Learning <ChevronRight size={24} />
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          ) : (
            <div className="flex-1 overflow-y-auto p-8 md:p-12">
              <div className="max-w-4xl mx-auto space-y-12">
                {questions.map((q, qIdx) => (
                  <div key={q.id} className="space-y-6 pb-12 border-b border-slate-100 last:border-0">
                    <div className="flex items-center gap-3">
                      <span className="w-8 h-8 bg-slate-900 text-white rounded-lg flex items-center justify-center font-black text-sm">
                        {qIdx + 1}
                      </span>
                      <Badge variant="indigo">{q.metadata.topic}</Badge>
                    </div>

                    {q.passage && (
                      <div className="p-6 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                        <h4 className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                          <Layers size={14} /> Case Passage / Context
                        </h4>
                        <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                          {q.passage}
                        </p>
                        {q.context && (
                          <p className="text-xs font-medium text-slate-500 dark:text-slate-400 italic">
                            Context: {q.context}
                          </p>
                        )}
                      </div>
                    )}

                    {(q.assertion || q.reason) && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {q.assertion && (
                          <div className="p-5 bg-blue-50/50 dark:bg-blue-950/20 rounded-2xl border border-blue-100 dark:border-blue-900/30 space-y-1">
                            <span className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-wider block">Assertion (A)</span>
                            <p className="text-sm font-bold text-slate-800 dark:text-slate-200 leading-relaxed">
                              {q.assertion}
                            </p>
                          </div>
                        )}
                        {q.reason && (
                          <div className="p-5 bg-purple-50/50 dark:bg-purple-950/20 rounded-2xl border border-purple-100 dark:border-purple-900/30 space-y-1">
                            <span className="text-[10px] font-black text-purple-600 dark:text-purple-400 uppercase tracking-wider block">Reason (R)</span>
                            <p className="text-sm font-bold text-slate-800 dark:text-slate-200 leading-relaxed">
                              {q.reason}
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    <h3 className="text-2xl font-black text-slate-900 leading-tight">{q.question}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {q.options?.map((option, oIdx) => {
                        const isSelected = userAnswers[qIdx] === oIdx;
                        return (
                          <button
                            key={oIdx}
                            onClick={() => setUserAnswers(prev => ({ ...prev, [qIdx]: oIdx }))}
                            className={cn(
                              "p-4 rounded-2xl border-2 text-left transition-all flex items-center gap-3",
                              isSelected ? "border-indigo-600 bg-indigo-50" : "border-slate-100 bg-white hover:border-indigo-200"
                            )}
                          >
                            <span className={cn(
                              "w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black",
                              isSelected ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-400"
                            )}>
                              {String.fromCharCode(65 + oIdx)}
                            </span>
                            <span className="font-bold text-slate-700">{option}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
                <div className="pt-10 flex justify-center">
                  <button 
                    onClick={handleFinishQuiz}
                    className="px-12 py-5 bg-indigo-600 text-white rounded-3xl font-black text-xl hover:bg-indigo-700 transition-all shadow-2xl shadow-indigo-200 flex items-center gap-3"
                  >
                    Submit All Answers <CheckCircle2 size={24} />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderResults = () => {
    if (!analytics) return null;

    return (
      <div className={cn(
        "p-8 mx-auto space-y-12 transition-all duration-500",
        isFullscreen ? "fixed inset-0 z-[200] bg-white overflow-y-auto" : "max-w-5xl"
      )}>
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 bg-indigo-600 text-white rounded-3xl flex items-center justify-center shadow-2xl shadow-indigo-200">
              <Trophy size={48} />
            </div>
            <div className="space-y-1">
              <h2 className="text-5xl font-black text-slate-900 tracking-tighter">Assessment Complete</h2>
              <div className="flex items-center gap-3">
                <Badge variant={isPassed(analytics.accuracy) ? 'success' : 'warning'}>
                  {isPassed(analytics.accuracy) ? 'Mastery Achieved' : 'Learning in Progress'}
                </Badge>
                <span className="text-slate-400 font-bold text-sm">•</span>
                <span className="text-slate-500 font-bold text-sm">{selectedSubjects.join(', ')}</span>
              </div>
            </div>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => setStep('analytics')}
              className="px-8 py-4 bg-white border-2 border-slate-100 rounded-2xl font-black text-slate-600 hover:bg-slate-50 transition-all flex items-center gap-2"
            >
              <BarChart3 size={20} /> Deep Analytics
            </button>
            <button 
              onClick={handleShare}
              className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center gap-2"
            >
              <Share2 size={20} /> Share Results
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-8 bg-slate-50 rounded-3xl border border-slate-100 space-y-2">
            <span className="text-4xl font-black text-slate-900">{Math.round(analytics.accuracy)}%</span>
            <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Overall Accuracy</p>
            <ProgressBar current={analytics.accuracy} total={100} color="bg-indigo-600" />
          </div>
          <div className="p-8 bg-slate-50 rounded-3xl border border-slate-100 space-y-2">
            <span className="text-4xl font-black text-slate-900">{formatTime(analytics.avgTimePerQuestion)}s</span>
            <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Avg Time / Question</p>
            <div className="flex items-center gap-1 text-green-500 text-[10px] font-bold">
              <TrendingUp size={12} /> Optimal Pace
            </div>
          </div>
          <div className="p-8 bg-slate-50 rounded-3xl border border-slate-100 space-y-2">
            <span className="text-4xl font-black text-indigo-600">+{xpEarned}</span>
            <p className="text-xs font-black text-slate-400 uppercase tracking-widest">XP Earned</p>
            <div className="flex items-center gap-1 text-indigo-500 text-[10px] font-bold">
              <Zap size={12} /> Streak Bonus Included
            </div>
          </div>
          <div className="p-8 bg-slate-50 rounded-3xl border border-slate-100 space-y-2">
            <span className="text-4xl font-black text-slate-900">{questions.length}</span>
            <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Total Questions</p>
            <div className="flex items-center gap-1 text-slate-400 text-[10px] font-bold">
              <BookOpen size={12} /> Comprehensive Coverage
            </div>
          </div>
        </div>

        {/* Topic Mastery & Heatmap */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="p-10 bg-white rounded-[40px] border border-slate-100 shadow-xl shadow-slate-100 space-y-8">
            <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
              <Target className="text-indigo-600" size={28} /> Topic Mastery
            </h3>
            <div className="space-y-6">
              {Object.entries(analytics.topicMastery).map(([topic, score]) => (
                <div key={topic} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-700">{topic}</span>
                    <span className={cn(
                      "font-black",
                      score >= 80 ? "text-green-500" : score >= 60 ? "text-amber-500" : "text-red-500"
                    )}>{Math.round(score)}%</span>
                  </div>
                  <ProgressBar current={score} total={100} color={score >= 80 ? "bg-green-500" : score >= 60 ? "bg-amber-500" : "bg-red-500"} />
                </div>
              ))}
            </div>
          </div>

          <div className="p-10 bg-slate-900 rounded-[40px] text-white space-y-8 shadow-2xl shadow-slate-200">
            <h3 className="text-2xl font-black flex items-center gap-3">
              <TrendingUp className="text-indigo-400" size={28} /> Growth Insights
            </h3>
            <div className="space-y-8">
              <div className="space-y-4">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Strengths</h4>
                <div className="flex flex-wrap gap-2">
                  {analytics.strengths.length > 0 ? analytics.strengths.map(s => (
                    <span key={s} className="px-4 py-2 bg-indigo-500/20 text-indigo-300 rounded-xl text-sm font-bold border border-indigo-500/30">
                      {s}
                    </span>
                  )) : <span className="text-slate-500 italic">Keep practicing to build strengths!</span>}
                </div>
              </div>
              <div className="space-y-4">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Areas for Improvement</h4>
                <div className="flex flex-wrap gap-2">
                  {analytics.weaknesses.length > 0 ? analytics.weaknesses.map(w => (
                    <span key={w} className="px-4 py-2 bg-red-500/20 text-red-300 rounded-xl text-sm font-bold border border-red-500/30">
                      {w}
                    </span>
                  )) : <span className="text-slate-500 italic">No major weaknesses detected!</span>}
                </div>
              </div>
              <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-3">
                <h4 className="text-xs font-black text-indigo-400 uppercase tracking-widest">AI Recommendation</h4>
                <p className="text-sm font-medium text-slate-300 leading-relaxed">
                  Based on your performance, we recommend focusing on <span className="text-white font-bold">{analytics.weaknesses[0] || 'advanced concepts'}</span> next. Your speed is excellent, but conceptual depth in <span className="text-white font-bold">{analytics.weaknesses[1] || 'certain subtopics'}</span> can be improved.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col md:flex-row gap-4 pt-8">
          <button 
            onClick={() => setStep('setup')}
            className="flex-1 py-5 bg-slate-100 text-slate-900 rounded-3xl font-black text-lg hover:bg-slate-200 transition-all flex items-center justify-center gap-3"
          >
            <RotateCcw size={24} /> New Assessment
          </button>
          <button 
            onClick={() => setStep('review')}
            className="flex-1 py-5 bg-slate-900 text-white rounded-3xl font-black text-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-3"
          >
            <History size={24} /> Review All Answers
          </button>
        </div>
      </div>
    );
  };

  const handleTriggerDeepDive = async (index: number, q: Question) => {
    setDeepDiveLoading(prev => ({ ...prev, [index]: true }));
    try {
      const prompt = `You are a world-class cognitive learning coach and assessment diagnostic engine.
      Provide a highly engaging, personalized concept breakdown for this question:
      
      Question: "${q.question}"
      Options: ${JSON.stringify(q.options)}
      Correct Option Index: ${q.correctAnswer} (Correct Option: "${q.options?.[q.correctAnswer] || q.correctAnswer}")
      Student's Selection: ${userAnswers[index] !== undefined ? `Option ${userAnswers[index]} ("${q.options?.[userAnswers[index]] || userAnswers[index]}")` : "No answer submitted"}
      
      Requirements:
      1. Explain the underlying primary core concept in a very intuitive, clear way using real-world analogies.
      2. Provide a personalized diagnosis of why the student's selected answer was correct/incorrect. Specifically address any underlying misconceptions they might have had.
      3. Give 1 key tip or mnemonic to remember this concept forever.
      4. Write in a friendly, encouraging, and highly academic yet accessible style. Use formatting (bold text, lists) for high readability.`;

      const response = await generateAIResponse(prompt, {
        systemInstruction: "You are a professional assessment coach who specializes in diagnosing student misconceptions and explaining concepts simply and clearly.",
        model: "gemini-3.6-flash"
      });

      setDeepDiveExplanations(prev => ({ ...prev, [index]: response }));
    } catch (err) {
      console.error("Failed to generate AI deep dive:", err);
    } finally {
      setDeepDiveLoading(prev => ({ ...prev, [index]: false }));
    }
  };

  const handleAddToSpacedRepetition = (q: Question, idx: number) => {
    try {
      const stored = localStorage.getItem('omni_spaced_repetition');
      let currentCards: any[] = [];
      if (stored) {
        try {
          currentCards = JSON.parse(stored);
        } catch (e) {
          currentCards = [];
        }
      }

      // Check if it's already in there
      const cardId = `quiz-${q.id || idx}`;
      const exists = currentCards.some(card => card.id === cardId);
      
      if (!exists) {
        // Prepare Back side
        let backContent = `**Expected Core Answer:**\n${q.options ? q.options[q.correctAnswer] : q.correctAnswer}\n\n`;
        backContent += `**Diagnostic Breakdown:**\n${q.explanation.whyCorrect || 'Concept review.'}\n\n`;
        
        if (q.explanation.eli5) {
          backContent += `**Analogy (ELI5):**\n_${q.explanation.eli5}_\n\n`;
        }
        
        if (q.explanation.whyWrong) {
          const wrongExps = Object.entries(q.explanation.whyWrong)
            .map(([optIdx, reason]) => {
              const optLetter = String.fromCharCode(65 + parseInt(optIdx));
              const optText = q.options ? q.options[parseInt(optIdx)] : '';
              return `- **Option ${optLetter}** (${optText}): ${reason}`;
            })
            .join('\n');
          if (wrongExps) {
            backContent += `**Distractor Explanations:**\n${wrongExps}\n\n`;
          }
        }

        let frontText = "";
        if (q.passage) {
          frontText += `**Case Passage:**\n${q.passage}\n\n`;
          if (q.context) {
            frontText += `**Context:** ${q.context}\n\n`;
          }
        }
        if (q.assertion || q.reason) {
          if (q.assertion) frontText += `**Assertion (A):** ${q.assertion}\n`;
          if (q.reason) frontText += `**Reason (R):** ${q.reason}\n`;
          frontText += `\n`;
        }
        frontText += q.question;
        if (q.options && q.options.length > 0) {
          frontText += `\n\n${q.options.map((opt, oIdx) => `${String.fromCharCode(65 + oIdx)}) ${opt}`).join('\n')}`;
        }

        const newCard = {
          id: cardId,
          front: frontText,
          back: backContent,
          subject: initialSubject || q.metadata.topic || 'General',
          topic: customTopic || q.metadata.subtopic || 'Concept Review',
          interval: 1,
          repetitions: 1,
          easeFactor: 2.5,
          nextReviewDate: new Date().toISOString()
        };

        currentCards.unshift(newCard);
        localStorage.setItem('omni_spaced_repetition', JSON.stringify(currentCards));
      }

      setAddedToDeck(prev => ({ ...prev, [q.id || idx]: true }));
      
      if (showNotification) {
        showNotification('Added question to your Adaptive Flashcard Deck!', 'success');
      }
    } catch (err) {
      console.error("Failed to add to spaced repetition deck:", err);
    }
  };

  const renderReview = () => {
    if (!analytics) return null;

    return (
      <div className={cn(
        "p-8 mx-auto space-y-12 transition-all duration-500",
        isFullscreen ? "fixed inset-0 z-[200] bg-white dark:bg-slate-900 overflow-y-auto" : "max-w-5xl"
      )}>
        {/* Navigation & Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 border-b border-slate-100 dark:border-slate-800 pb-8">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setStep('results')}
              className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-750 rounded-2xl text-slate-600 dark:text-slate-200 transition-all flex items-center justify-center shadow-sm cursor-pointer"
              title="Back to Results Overview"
            >
              <ChevronLeft size={24} />
            </button>
            <div className="space-y-1">
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter">Diagnostic Concept Review</h2>
              <p className="text-slate-500 dark:text-slate-400 font-bold text-sm">
                Analyze and correct misconceptions across {questions.length} assessed items
              </p>
            </div>
          </div>
          
          {/* Summary Badge */}
          <div className="flex gap-4">
            <div className="px-6 py-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl text-center">
              <span className="block text-xs font-black text-emerald-500 uppercase tracking-wider">Passed</span>
              <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                {questions.filter((q, idx) => userAnswers[idx] === q.correctAnswer).length} / {questions.length}
              </span>
            </div>
            <div className="px-6 py-3 bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30 rounded-2xl text-center">
              <span className="block text-xs font-black text-red-500 uppercase tracking-wider">Missed</span>
              <span className="text-lg font-black text-red-600 dark:text-red-400">
                {questions.filter((q, idx) => userAnswers[idx] !== q.correctAnswer).length} / {questions.length}
              </span>
            </div>
          </div>
        </div>

        {/* List of Questions */}
        <div className="space-y-10">
          {questions.map((q, idx) => {
            const isCorrect = userAnswers[idx] === q.correctAnswer;
            const isExpanded = expandedExplanations[idx];

            return (
              <div 
                key={q.id} 
                className={cn(
                  "p-8 bg-white dark:bg-slate-900/80 rounded-[32px] border shadow-xl shadow-slate-100 dark:shadow-none space-y-6 relative transition-all",
                  isCorrect 
                    ? "border-emerald-100 dark:border-emerald-900/30 hover:border-emerald-200 dark:hover:border-emerald-900/50" 
                    : "border-red-100 dark:border-red-900/30 hover:border-red-200 dark:hover:border-red-900/50"
                )}
              >
                {/* Correct/Incorrect Status Ribbon */}
                <div className={cn(
                  "absolute top-0 right-10 transform -translate-y-1/2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-md",
                  isCorrect 
                    ? "bg-emerald-600 text-white shadow-emerald-200 dark:shadow-none" 
                    : "bg-red-500 text-white shadow-red-200 dark:shadow-none"
                )}>
                  {isCorrect ? (
                    <>
                      <CheckCircle2 size={12} /> Correct (+50 XP)
                    </>
                  ) : (
                    <>
                      <AlertCircle size={12} /> Concept Gap Found
                    </>
                  )}
                </div>

                {/* Top Question Row Metadata */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="w-9 h-9 bg-slate-900 dark:bg-slate-800 text-white rounded-xl flex items-center justify-center font-black text-sm shadow-sm">
                      {idx + 1}
                    </span>
                    <Badge variant="indigo">{q.metadata.topic}</Badge>
                    {q.metadata.subtopic && <Badge variant="default">{q.metadata.subtopic}</Badge>}
                    <Badge variant={q.metadata.difficulty === 'Expert' ? 'error' : q.metadata.difficulty === 'Advanced' ? 'warning' : 'default'}>
                      {q.metadata.difficulty}
                    </Badge>
                  </div>
                  
                  {/* Send to Flashcards Button */}
                  <button
                    onClick={() => handleAddToSpacedRepetition(q, idx)}
                    disabled={addedToDeck[q.id || idx]}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all border shadow-xs cursor-pointer",
                      addedToDeck[q.id || idx]
                        ? "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400 dark:text-slate-500 cursor-not-allowed"
                        : !isCorrect
                          ? "bg-indigo-600 hover:bg-indigo-700 border-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none animate-pulse"
                          : "bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                    )}
                  >
                    <Brain size={14} />
                    {addedToDeck[q.id || idx] ? "Added to Deck!" : "Add to Spaced Repetition Deck"}
                  </button>
                </div>

                {/* Question Body with custom formats */}
                {q.passage && (
                  <div className="p-6 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                    <h4 className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                      <Layers size={14} /> Case Passage / Context
                    </h4>
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                      {q.passage}
                    </p>
                    {q.context && (
                      <p className="text-xs font-medium text-slate-500 dark:text-slate-400 italic">
                        Context: {q.context}
                      </p>
                    )}
                  </div>
                )}

                {(q.assertion || q.reason) && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {q.assertion && (
                      <div className="p-5 bg-blue-50/50 dark:bg-blue-950/20 rounded-2xl border border-blue-100 dark:border-blue-900/30 space-y-1">
                        <span className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-wider block">Assertion (A)</span>
                        <p className="text-sm font-bold text-slate-800 dark:text-slate-200 leading-relaxed">
                          {q.assertion}
                        </p>
                      </div>
                    )}
                    {q.reason && (
                      <div className="p-5 bg-purple-50/50 dark:bg-purple-950/20 rounded-2xl border border-purple-100 dark:border-purple-900/30 space-y-1">
                        <span className="text-[10px] font-black text-purple-600 dark:text-purple-400 uppercase tracking-wider block">Reason (R)</span>
                        <p className="text-sm font-bold text-slate-800 dark:text-slate-200 leading-relaxed">
                          {q.reason}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                <h3 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white leading-tight">
                  {q.question}
                </h3>

                {/* Choices / Interactive Options Block */}
                {q.options && q.options.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {q.options.map((option, oIdx) => {
                      const isCorrectOption = oIdx === q.correctAnswer;
                      const isSelectedOption = userAnswers[idx] === oIdx;

                      let optionStyle = "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300 text-slate-800 dark:text-slate-100";
                      let badgeStyle = "bg-slate-100 text-slate-400 dark:bg-slate-700 dark:text-slate-400";
                      let Icon = null;

                      if (isCorrectOption) {
                        optionStyle = "border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-100 font-extrabold";
                        badgeStyle = "bg-emerald-500 text-white";
                        Icon = <Check size={14} className="stroke-[3]" />;
                      } else if (isSelectedOption) {
                        optionStyle = "border-red-500 bg-red-50/50 dark:bg-red-950/20 text-red-900 dark:text-red-100 font-extrabold";
                        badgeStyle = "bg-red-500 text-white";
                        Icon = <X size={14} className="stroke-[3]" />;
                      }

                      return (
                        <div
                          key={oIdx}
                          className={cn(
                            "p-5 rounded-2xl border-2 text-left flex items-center gap-4 transition-all shadow-sm",
                            optionStyle
                          )}
                        >
                          <span className={cn(
                            "w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black shrink-0 shadow-sm",
                            badgeStyle
                          )}>
                            {Icon || String.fromCharCode(65 + oIdx)}
                          </span>
                          <span className="text-sm md:text-base leading-snug">{option}</span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  // Short answer feedback layout
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-5 bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl">
                      <h4 className="text-xs font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest mb-2 flex items-center gap-1.5">
                        <CheckCircle2 size={14} /> Expected Core Answer
                      </h4>
                      <p className="text-sm font-bold text-slate-800 dark:text-slate-100 leading-relaxed">
                        {q.correctAnswer}
                      </p>
                    </div>
                    <div className={cn(
                      "p-5 rounded-2xl border",
                      isCorrect 
                        ? "bg-emerald-50/20 border-emerald-100 dark:border-emerald-900/20" 
                        : "bg-red-50/20 border-red-100 dark:border-red-900/20"
                    )}>
                      <h4 className={cn("text-xs font-black uppercase tracking-widest mb-2 flex items-center gap-1.5", isCorrect ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400")}>
                        {isCorrect ? <CheckCircle2 size={14} /> : <XCircle size={14} />} Your Submitted Response
                      </h4>
                      <p className="text-sm font-bold text-slate-800 dark:text-slate-100 leading-relaxed">
                        {userAnswers[idx] || <span className="text-slate-400 dark:text-slate-500 italic font-medium">No answer provided</span>}
                      </p>
                    </div>
                  </div>
                )}

                {/* Explanation Toggle */}
                <div className="pt-2">
                  <button
                    onClick={() => setExpandedExplanations(prev => ({ ...prev, [idx]: !prev[idx] }))}
                    className={cn(
                      "w-full flex justify-between items-center px-6 py-4 rounded-2xl border font-bold text-sm transition-all shadow-sm cursor-pointer",
                      isExpanded 
                        ? "bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white" 
                        : "bg-slate-50 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                    )}
                  >
                    <span className="flex items-center gap-2">
                      <Lightbulb size={18} className="text-amber-500" />
                      {isExpanded ? 'Hide Concept Breakdown & Diagnostics' : 'Show Concept Breakdown & Diagnostics'}
                    </span>
                    {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </button>
                </div>

                {/* Smooth diagnostics slide-down block */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="pt-4 space-y-6 border-t border-slate-100 dark:border-slate-800 mt-6">
                        
                        {/* Why Correct Diagnostic Block */}
                        <div className="p-6 bg-emerald-50/50 dark:bg-emerald-950/10 border border-emerald-100 dark:border-emerald-900/20 rounded-[24px] space-y-2">
                          <h4 className="text-xs font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                            <CheckCircle2 size={14} /> Diagnostic: Why Option {q.options ? String.fromCharCode(65 + q.correctAnswer) : 'this answer'} is Correct
                          </h4>
                          <p className="text-sm md:text-base font-bold text-slate-800 dark:text-slate-100 leading-relaxed">
                            {q.explanation.whyCorrect}
                          </p>
                        </div>

                        {/* Distractor Diagnosis Block (Strict user requirement) */}
                        {q.options && q.options.length > 0 && q.explanation.whyWrong && (
                          <div className="p-6 bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800 rounded-[24px] space-y-4">
                            <h4 className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest flex items-center gap-2">
                              <XCircle size={14} className="text-red-400" /> Distractor Diagnostics: Why wrong choices are incorrect
                            </h4>
                            <div className="grid grid-cols-1 gap-3">
                              {q.options.map((option, oIdx) => {
                                if (oIdx === q.correctAnswer) return null;
                                const wrongReason = q.explanation.whyWrong[oIdx.toString()] || q.explanation.whyWrong[oIdx] || "This option is factually incorrect or fails to fully answer the problem criteria.";
                                return (
                                  <div key={oIdx} className="p-4 bg-white dark:bg-slate-800/80 rounded-xl border border-slate-100 dark:border-slate-700/50 flex flex-col sm:flex-row sm:items-start gap-3 shadow-xs">
                                    <span className="px-2.5 py-1 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg text-xs font-black uppercase tracking-wider shrink-0 text-center sm:w-20">
                                      Option {String.fromCharCode(65 + oIdx)}
                                    </span>
                                    <div className="space-y-1">
                                      <p className="text-xs font-bold text-slate-400 dark:text-slate-500 italic">"{option}"</p>
                                      <p className="text-sm font-bold text-slate-700 dark:text-slate-300 leading-relaxed">{wrongReason}</p>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {/* Step-by-Step Timeline block */}
                        {q.explanation.stepByStep && q.explanation.stepByStep.length > 0 && (
                          <div className="space-y-3">
                            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                              <Layers size={14} /> Logical Step-by-Step Breakdown
                            </h4>
                            <div className="grid grid-cols-1 gap-3 pl-2">
                              {q.explanation.stepByStep.map((step, i) => {
                                const isDetailed = typeof step === 'object';
                                return (
                                  <div key={i} className="flex gap-4 p-4 bg-white dark:bg-slate-800/30 rounded-2xl border border-slate-100 dark:border-slate-700/50 shadow-xs">
                                    <span className="w-6 h-6 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center text-xs font-black flex-shrink-0">
                                      {i + 1}
                                    </span>
                                    <div className="space-y-1.5">
                                      {isDetailed ? (
                                        <>
                                          <p className="text-sm font-black text-slate-900 dark:text-white leading-relaxed">{step.what}</p>
                                          <p className="text-xs font-bold text-slate-500 dark:text-slate-400 leading-relaxed italic">Why: {step.why}</p>
                                          {step.formula && (
                                            <div className="p-2.5 bg-slate-950 dark:bg-black rounded-lg text-center font-mono text-xs text-indigo-300 overflow-x-auto">
                                              <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>{`$${step.formula}$`}</Markdown>
                                            </div>
                                          )}
                                        </>
                                      ) : (
                                        <p className="text-sm font-bold text-slate-700 dark:text-slate-200 leading-relaxed">{step}</p>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {/* ELI5 Concept Analogy */}
                        {q.explanation.eli5 && (
                          <div className="p-6 bg-amber-50/50 dark:bg-amber-950/10 border border-amber-100 dark:border-amber-900/20 rounded-[24px] space-y-2">
                            <h4 className="text-xs font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest flex items-center gap-2">
                              <Award size={14} /> Simplified Analogy (ELI5 Concept)
                            </h4>
                            <p className="text-sm font-bold text-amber-900 dark:text-amber-200 leading-relaxed italic">
                              "{q.explanation.eli5}"
                            </p>
                          </div>
                        )}

                        {/* Alternate Method */}
                        {q.explanation.alternativeMethod && (
                          <div className="p-6 bg-green-50/50 dark:bg-green-950/10 border border-green-100 dark:border-green-900/20 rounded-[24px] space-y-2">
                            <h4 className="text-xs font-black text-green-600 dark:text-green-400 uppercase tracking-widest flex items-center gap-2">
                              <Sparkles size={14} /> Alternative Approach / Shortcut Method
                            </h4>
                            <p className="text-sm font-bold text-green-950 dark:text-green-300 leading-relaxed">
                              {q.explanation.alternativeMethod}
                            </p>
                          </div>
                        )}

                        {/* Ask Omni AI - Interactive Deep Diagnostic */}
                        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-4">
                          <div className="flex items-center justify-between flex-wrap gap-3">
                            <div className="space-y-0.5">
                              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Interactive AI Diagnostics</p>
                              <p className="text-xs font-bold text-slate-500 dark:text-slate-400">Request bespoke, personalized concept analysis tailored to your choice</p>
                            </div>
                            <button
                              onClick={() => handleTriggerDeepDive(idx, q)}
                              disabled={deepDiveLoading[idx]}
                              className="flex items-center gap-2 px-6 py-3.5 bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 rounded-2xl font-black text-sm transition-all shadow-lg shadow-indigo-200/40 dark:shadow-none cursor-pointer animate-pulse"
                            >
                              {deepDiveLoading[idx] ? (
                                <>
                                  <Loader2 size={16} className="animate-spin" />
                                  Analyzing Concept...
                                </>
                              ) : (
                                <>
                                  <Sparkles size={16} />
                                  {deepDiveExplanations[idx] ? 'Regenerate AI Diagnostic' : '🧠 Request Omni AI Deep Dive'}
                                </>
                              )}
                            </button>
                          </div>

                          {/* Render AI custom response */}
                          <AnimatePresence>
                            {deepDiveExplanations[idx] && (
                              <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -10 }}
                                className="p-6 bg-indigo-50/30 dark:bg-indigo-950/10 border-2 border-indigo-100/40 dark:border-indigo-900/20 rounded-3xl space-y-4"
                              >
                                <div className="flex items-center gap-2">
                                  <span className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center font-black">
                                    <Sparkles size={16} />
                                  </span>
                                  <div>
                                    <h5 className="text-sm font-black text-indigo-950 dark:text-indigo-100">Bespoke Omni AI Diagnostic</h5>
                                    <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Dynamically compiled for {userName}</p>
                                  </div>
                                </div>
                                <div className="prose prose-slate dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 font-semibold text-sm leading-relaxed space-y-3">
                                  <Markdown>{deepDiveExplanations[idx]}</Markdown>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>

                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

        {/* Footer Navigation Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 pt-10 border-t border-slate-100 dark:border-slate-800">
          <button 
            onClick={() => setStep('results')}
            className="flex-1 py-5 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-3xl font-black text-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-all flex items-center justify-center gap-3 cursor-pointer"
          >
            <ChevronLeft size={24} /> Back to Overview
          </button>
          <button 
            onClick={() => setStep('setup')}
            className="flex-1 py-5 bg-indigo-600 text-white rounded-3xl font-black text-lg hover:bg-indigo-700 transition-all flex items-center justify-center gap-3 shadow-xl shadow-indigo-200/40 dark:shadow-none cursor-pointer"
          >
            <RotateCcw size={24} /> Start New Assessment
          </button>
        </div>
      </div>
    );
  };

  const renderAnalytics = () => {
    if (!analytics) return null;

    const radarData = Object.entries(analytics.topicMastery).map(([topic, score]) => ({
      subject: topic,
      A: score,
      fullMark: 100,
    }));

    return (
      <div className={cn(
        "p-8 mx-auto space-y-12 transition-all duration-500",
        isFullscreen ? "fixed inset-0 z-[200] bg-white overflow-y-auto" : "max-w-6xl"
      )}>
        <div className="flex justify-between items-center">
          <button 
            onClick={() => setStep('results')}
            className="p-3 hover:bg-slate-100 rounded-2xl text-slate-400 transition-all"
          >
            <ChevronLeft size={32} />
          </button>
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter">Deep Performance Analytics</h2>
          <div className="w-12" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Time Trend Chart */}
          <div className="p-10 bg-white rounded-[40px] border border-slate-100 shadow-xl space-y-6">
            <h3 className="text-xl font-black text-slate-900 flex items-center gap-3">
              <Clock className="text-indigo-600" size={24} /> Time per Question (s)
            </h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <LineChart data={analytics.timeTrend}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="question" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 'bold' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 'bold' }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }}
                    cursor={{ stroke: '#6366f1', strokeWidth: 2 }}
                  />
                  <Line type="monotone" dataKey="time" stroke="#6366f1" strokeWidth={4} dot={{ r: 6, fill: '#6366f1', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 8 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Mastery Radar */}
          <div className="p-10 bg-white rounded-[40px] border border-slate-100 shadow-xl space-y-6">
            <h3 className="text-xl font-black text-slate-900 flex items-center gap-3">
              <Target className="text-indigo-600" size={24} /> Conceptual Mastery
            </h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                  <PolarGrid stroke="#f1f5f9" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 10, fontWeight: 'bold' }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar
                    name="Mastery"
                    dataKey="A"
                    stroke="#6366f1"
                    fill="#6366f1"
                    fillOpacity={0.6}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Difficulty vs Performance */}
          <div className="p-10 bg-white rounded-[40px] border border-slate-100 shadow-xl space-y-6 lg:col-span-2">
            <h3 className="text-xl font-black text-slate-900 flex items-center gap-3">
              <TrendingUp className="text-indigo-600" size={24} /> Difficulty Trend Analysis
            </h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics.difficultyTrend}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="question" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 'bold' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 'bold' }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }}
                  />
                  <Bar dataKey="difficulty" radius={[10, 10, 0, 0]}>
                    {analytics.difficultyTrend.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.difficulty >= 4 ? '#ef4444' : entry.difficulty >= 3 ? '#f59e0b' : '#6366f1'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <button 
          onClick={() => setStep('results')}
          className="w-full py-5 bg-slate-900 text-white rounded-3xl font-black text-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-3"
        >
          Back to Overview <ChevronRight size={24} />
        </button>
      </div>
    );
  };

  // --- Main Render ---

  return (
    <div className="min-h-full bg-white text-slate-900 font-sans">
      <AnimatePresence mode="wait">
        {step === 'setup' && (
          <motion.div key="setup" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
            {renderSetup()}
          </motion.div>
        )}
        {step === 'loading' && (
          <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {renderLoading()}
          </motion.div>
        )}
        {step === 'quiz' && (
          <motion.div key="quiz" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.05 }}>
            {renderQuiz()}
          </motion.div>
        )}
        {step === 'results' && (
          <motion.div key="results" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
            {renderResults()}
          </motion.div>
        )}
        {step === 'analytics' && (
          <motion.div key="analytics" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            {renderAnalytics()}
          </motion.div>
        )}
        {step === 'review' && (
          <motion.div key="review" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
            {renderReview()}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
