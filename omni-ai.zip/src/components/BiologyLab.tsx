import React, { useState, useEffect, useRef } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Sphere, Torus, Box } from "@react-three/drei";
import { Camera, RefreshCw, Play, Pause, Save, HelpCircle, BarChart2, Zap, GitBranch, AlertTriangle } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { BiologyMetricsVisualization } from "./BiologyMetricsVisualization";
import { LifeCycleExplorer } from "./LifeCycleExplorer";
import { PunnettSquareSimulator } from "./PunnettSquareSimulator";
import { BiologyDashboard } from "./BiologyDashboard";
import { LayoutDashboard } from "lucide-react";
import { validateBioVariable, BIO_RULES } from "@/src/lib/bioValidation";

interface BiologyLabProps {
  theme: 'light' | 'dark';
  onSendMessage: (text: string) => void;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
}

interface Organelle {
  id: string;
  name: string;
  color: string;
  position: [number, number, number];
  scale: [number, number, number];
  shape: 'sphere' | 'torus' | 'box';
  functionTheory: string;
  description: string;
  keyFacts: string[];
}

const ORGANELLES: Organelle[] = [
  {
    id: "nucleus",
    name: "Nucleus",
    color: "#3b82f6", // Blue
    position: [0, 0, 0],
    scale: [1, 1, 1],
    shape: 'sphere',
    description: "The control center of the cell housing DNA.",
    functionTheory: "Stores genetic instructions for cell growth, survival, and reproduction. Directly aligns with Cell Theory's principle that all cells arise from pre-existing cells (via mitosis directed by the nucleus).",
    keyFacts: ["Contains chromatin (DNA + proteins)", "Surrounded by a double membrane nuclear envelope", "Directs protein synthesis"]
  },
  {
    id: "mitochondria",
    name: "Mitochondria",
    color: "#ef4444", // Red
    position: [1.8, 0.8, -0.5],
    scale: [0.6, 0.4, 0.4],
    shape: 'box',
    description: "The power plant of the cell, generating ATP.",
    functionTheory: "Performs cellular respiration, converting chemical energy from food into ATP. Aligns with Cell Theory's principle that cells are the fundamental unit of chemical activity and metabolic machinery.",
    keyFacts: ["Has its own mitochondrial DNA (supports Endosymbiotic Theory)", "Double-membrane structure with inner cristae folds", "Site of Krebs Cycle and Electron Transport Chain"]
  },
  {
    id: "golgi",
    name: "Golgi Apparatus",
    color: "#eab308", // Yellow
    position: [-1.5, -0.6, 0.5],
    scale: [0.6, 0.6, 0.2],
    shape: 'torus',
    description: "The packaging and distribution center of the cell.",
    functionTheory: "Modifies, sorts, and packages macromolecules for secretion or intracellular delivery. Demonstrates cell specialization and compartmentalization required for complex multicellular life.",
    keyFacts: ["Consists of flattened membrane-bound sacs (cisternae)", "Sorts secretory proteins and lysosomal enzymes", "Has distinct cis and trans faces"]
  },
  {
    id: "er",
    name: "Endoplasmic Reticulum (ER)",
    color: "#a855f7", // Purple
    position: [-0.8, 1.2, -0.8],
    scale: [0.8, 0.4, 0.6],
    shape: 'box',
    description: "Intracellular highway for protein and lipid synthesis.",
    functionTheory: "Synthesizes lipids, proteins, and carbohydrates. Rough ER (studded with ribosomes) and Smooth ER represent the structural and functional baseline of active cellular protein manufacture.",
    keyFacts: ["Rough ER modifies proteins post-translation", "Smooth ER metabolizes lipids and detoxifies toxins", "Continuous with the nuclear membrane outer envelope"]
  },
  {
    id: "lysosome",
    name: "Lysosome",
    color: "#22c55e", // Green
    position: [0.8, -1.3, 0.8],
    scale: [0.35, 0.35, 0.35],
    shape: 'sphere',
    description: "The waste disposal and recycling unit.",
    functionTheory: "Contains digestive enzymes that break down waste materials, foreign invaders, and cellular debris. Prevents cell degradation and supports self-sustaining metabolic homeostasis.",
    keyFacts: ["Maintains an acidic internal pH", "Involved in autolysis (programmed cell death/apoptosis)", "Recycles worn-out organelles (autophagy)"]
  }
];

export const BiologyLab: React.FC<BiologyLabProps> = ({ theme, onSendMessage, showNotification }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'cell' | 'ecology' | 'metrics' | 'lifecycles' | 'genetics'>('dashboard');
  
  // 3D Cell State
  const [selectedOrganelle, setSelectedOrganelle] = useState<Organelle>(ORGANELLES[0]);
  const [hoveredOrganelleId, setHoveredOrganelleId] = useState<string | null>(null);

  // Ecosystem State
  const [isPlaying, setIsPlaying] = useState(false);
  const [grassGrowth, setGrassGrowth] = useState(3.0);
  const [temperature, setTemperature] = useState(25.0); // °C
  const [phLevel, setPhLevel] = useState(7.0); // pH
  const [climate, setClimate] = useState<'optimal' | 'drought' | 'cold'>('optimal');
  const [rabbits, setRabbits] = useState<number[]>([50]);
  const [wolves, setWolves] = useState<number[]>([15]);
  const [stepCount, setStepCount] = useState(0);

  // Validation Handlers with Toasts
  const handleGrassGrowthChange = (val: number) => {
    const res = validateBioVariable('grassGrowth', val, showNotification);
    setGrassGrowth(res.value);
  };

  const handleTemperatureChange = (val: number) => {
    const res = validateBioVariable('temperature', val, showNotification);
    setTemperature(res.value);
  };

  const handlePhChange = (val: number) => {
    const res = validateBioVariable('ph', val, showNotification);
    setPhLevel(res.value);
  };

  // Reset Ecosystem simulation
  const handleResetEcosystem = () => {
    setRabbits([50]);
    setWolves([15]);
    setStepCount(0);
    setIsPlaying(false);
    setTemperature(25.0);
    setPhLevel(7.0);
    setGrassGrowth(3.0);
  };

  // Voice Command Listener
  useEffect(() => {
    const handleVoiceCommand = (event: any) => {
      const { command } = event.detail;
      if (!command) return;
      const lower = command.toLowerCase();

      if (lower.includes("increase grass")) {
        handleGrassGrowthChange(grassGrowth + 0.5);
      } else if (lower.includes("decrease grass")) {
        handleGrassGrowthChange(grassGrowth - 0.5);
      } else if (lower.includes("increase temperature") || lower.includes("raise temperature")) {
        handleTemperatureChange(temperature + 5);
      } else if (lower.includes("decrease temperature") || lower.includes("lower temperature")) {
        handleTemperatureChange(temperature - 5);
      } else if (lower.includes("temperature to") || lower.includes("set temperature")) {
        const match = lower.match(/(?:temperature to|set temperature to|temperature) (-?\d+(?:\.\d+)?)/);
        if (match) {
          handleTemperatureChange(parseFloat(match[1]));
        }
      } else if (lower.includes("increase ph") || lower.includes("raise ph")) {
        handlePhChange(phLevel + 0.5);
      } else if (lower.includes("decrease ph") || lower.includes("lower ph")) {
        handlePhChange(phLevel - 0.5);
      } else if (lower.includes("ph to") || lower.includes("set ph")) {
        const match = lower.match(/(?:ph to|set ph to|ph) (\d+(?:\.\d+)?)/);
        if (match) {
          handlePhChange(parseFloat(match[1]));
        }
      } else if (lower.includes("climate to drought")) {
        setClimate('drought');
        showNotification?.('Climate set to drought', 'info');
      } else if (lower.includes("climate to optimal")) {
        setClimate('optimal');
        showNotification?.('Climate set to optimal', 'info');
      } else if (lower.includes("climate to cold")) {
        setClimate('cold');
        showNotification?.('Climate set to cold', 'info');
      }
    };
    window.addEventListener('voice_command', handleVoiceCommand);
    return () => window.removeEventListener('voice_command', handleVoiceCommand);
  }, [grassGrowth, temperature, phLevel]);

  // Real-time data sync
  useEffect(() => {
    if (isPlaying) {
      const update = `[Biology Lab Real-time Sync]
- Temp: ${temperature.toFixed(1)}°C | pH: ${phLevel.toFixed(1)}
- Rabbits: ${rabbits[rabbits.length - 1]}
- Wolves: ${wolves[wolves.length - 1]}`;
      window.dispatchEvent(new CustomEvent('lab_data_sync', { detail: { update } }));
    }
  }, [stepCount]);

  const takeSnapshot = () => {
    const snapshot = `[Biology Lab Quick Snapshot]
- Environmental Climate: ${climate}
- Ambient Temp: ${temperature.toFixed(1)}°C
- Soil/Water pH: ${phLevel.toFixed(1)}
- Grass Growth Rate: ${grassGrowth.toFixed(1)}x
- Prey (Rabbits): ${rabbits[rabbits.length - 1]}
- Predator (Wolves): ${wolves[wolves.length - 1]}
- System Balance: ${stability.label}`;
    onSendMessage(snapshot);
    showNotification?.('Snapshot posted directly into chat!', 'success');
  };

  // Run Ecosystem step
  const runEcosystemStep = () => {
    setRabbits(prevRabbits => {
      const currentR = prevRabbits[prevRabbits.length - 1];
      const currentW = wolves[wolves.length - 1];

      // Climate factors
      const climateFactor = climate === 'optimal' ? 1.0 : climate === 'drought' ? 0.6 : 0.8;
      
      // Prey (Rabbit) birth and death rate
      const rabbitBirthRate = 0.15 * (grassGrowth / 3.0) * climateFactor;
      const predationRate = 0.005;
      
      // Calculate next rabbit count
      const newR = Math.max(0, currentR + (rabbitBirthRate * currentR) - (predationRate * currentR * currentW));

      setWolves(prevWolves => {
        const currentWolves = prevWolves[prevWolves.length - 1];
        // Predator (Wolf) birth and death rate
        const wolfBirthRate = 0.0015 * currentR * climateFactor;
        const wolfNaturalDeathRate = 0.08 / climateFactor;
        
        const newW = Math.max(0, currentWolves + (wolfBirthRate * currentWolves) - (wolfNaturalDeathRate * currentWolves));

        return [...prevWolves.slice(-19), Math.round(newW)];
      });

      return [...prevRabbits.slice(-19), Math.round(newR)];
    });
    setStepCount(prev => prev + 1);
  };

  useEffect(() => {
    let timer: any = null;
    if (isPlaying) {
      timer = setInterval(() => {
        runEcosystemStep();
      }, 600);
    }
    return () => clearInterval(timer);
  }, [isPlaying, grassGrowth, climate, wolves]);

  // Determine Ecosystem stability status
  const getStabilityStatus = () => {
    const r = rabbits[rabbits.length - 1];
    const w = wolves[wolves.length - 1];
    if (r === 0 && w === 0) return { label: 'Extinct', color: 'text-red-500 bg-red-50 dark:bg-red-950/20', desc: 'No organic life remains in this ecosystem.' };
    if (r > 150) return { label: 'Overpopulated Prey', color: 'text-amber-500 bg-amber-50 dark:bg-amber-950/20', desc: 'Extreme resource pressure. Rabbits will deplete the grassland.' };
    if (w === 0) return { label: 'Predator Extinction', color: 'text-rose-500 bg-rose-50 dark:bg-rose-950/20', desc: 'Predator population has collapsed, prey will multiply unboundedly.' };
    if (w > r) return { label: 'Predator Heavy', color: 'text-orange-500 bg-orange-50 dark:bg-orange-950/20', desc: 'High predation pressure might cause rabbit crash.' };
    return { label: 'Stable Equilibrium', color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/20', desc: 'Predator and prey cycles are in balanced synchronization.' };
  };

  const stability = getStabilityStatus();

  // Custom Event Snapshot Saver for cell anatomy
  const saveCellSnapshot = () => {
    const snapshotNote = {
      title: `3D Cell Anatomy Study: ${selectedOrganelle.name}`,
      summary: `Detailed architectural study of the cellular component: ${selectedOrganelle.name}. ${selectedOrganelle.description} Under Cell Theory: ${selectedOrganelle.functionTheory}`,
      keyConcepts: [selectedOrganelle.name, "Cell Theory", "Organelle Function", "Metabolic Homeostasis"],
      subject: "Science (Biology)",
      topic: "Cell Structure and Function"
    };

    window.dispatchEvent(new CustomEvent('save_omni_note', { detail: snapshotNote }));
  };

  // Custom Event Snapshot Saver for ecosystem simulation
  const saveEcologySnapshot = () => {
    const latestR = rabbits[rabbits.length - 1];
    const latestW = wolves[wolves.length - 1];
    const snapshotNote = {
      title: `Ecosystem Predator-Prey Balance Analysis`,
      summary: `Simulation parameters at step ${stepCount}: Climate was set to ${climate}, grass growth index at ${grassGrowth}. Current rabbit count: ${latestR}, wolves count: ${latestW}. Ecosystem Status: ${stability.label} - ${stability.desc}`,
      keyConcepts: ["Predator-Prey Cycles", "Ecosystem Stability", "Ecological Carrying Capacity"],
      subject: "Science (Biology)",
      topic: "Ecosystem Stability & Ecological Dynamics"
    };

    window.dispatchEvent(new CustomEvent('save_omni_note', { detail: snapshotNote }));
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 overflow-hidden text-slate-800 dark:text-slate-200">
      {/* Header Tabs */}
      <div className="flex justify-between items-center border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-2 select-none overflow-x-auto">
        <div className="flex gap-1">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={cn(
              "px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5",
              activeTab === 'dashboard' 
                ? "bg-rose-500 text-white" 
                : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
            )}
          >
            <LayoutDashboard size={14} /> Dashboard
          </button>
          <button
            onClick={() => setActiveTab('cell')}
            className={cn(
              "px-3 py-1.5 text-xs font-semibold rounded-lg transition-all",
              activeTab === 'cell' 
                ? "bg-emerald-500 text-white" 
                : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
            )}
          >
            🔬 3D Anatomy
          </button>
          <button
            onClick={() => setActiveTab('ecology')}
            className={cn(
              "px-3 py-1.5 text-xs font-semibold rounded-lg transition-all",
              activeTab === 'ecology' 
                ? "bg-emerald-500 text-white" 
                : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
            )}
          >
            🦊 Ecosystem
          </button>
          <button
            onClick={() => setActiveTab('metrics')}
            className={cn(
              "px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1",
              activeTab === 'metrics' 
                ? "bg-emerald-500 text-white" 
                : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
            )}
          >
            📊 Lab Metrics
          </button>
          <button
            onClick={() => setActiveTab('lifecycles')}
            className={cn(
              "px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1",
              activeTab === 'lifecycles' 
                ? "bg-emerald-500 text-white" 
                : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
            )}
          >
            🌱 Life Cycles
          </button>
          <button
            onClick={() => setActiveTab('genetics')}
            className={cn(
              "px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1",
              activeTab === 'genetics' 
                ? "bg-emerald-500 text-white" 
                : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
            )}
          >
            🧬 Genetics
          </button>
        </div>
        <div className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          BIOLOGY ENGINE v2.5
        </div>
      </div>

      {activeTab === 'dashboard' ? (
        <BiologyDashboard theme={theme} onOpenLab={(tab) => setActiveTab(tab as any)} />
      ) : activeTab === 'cell' ? (
        // Cell Anatomy Dashboard
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Canvas Screen */}
          <div className="flex-1 flex flex-col relative h-[220px] md:h-auto border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800">
            <div className="absolute top-2 left-2 z-10 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md px-2 py-1 rounded border text-xs flex flex-col">
              <span className="font-bold text-slate-700 dark:text-slate-300">Click Organelle to Study</span>
              <span className="text-[10px] text-slate-500">Hold & drag to rotate</span>
            </div>
            
            <div className="flex-1 w-full h-full bg-slate-100 dark:bg-slate-950/40">
              <Canvas camera={{ position: [0, 0, 4], fov: 60 }}>
                <ambientLight intensity={0.4} />
                <pointLight position={[10, 10, 10]} intensity={0.8} />
                <directionalLight position={[-5, 5, 5]} intensity={0.5} />
                
                {/* 3D Model Group representing simplified cell */}
                <group position={[0, 0, 0]}>
                  {/* Outer Cytoplasm Boundary / Semi-Transparent sphere */}
                  <mesh>
                    <sphereGeometry args={[2.5, 32, 16]} />
                    <meshStandardMaterial 
                      color="#10b981" 
                      transparent 
                      opacity={0.06} 
                      wireframe 
                    />
                  </mesh>

                  {/* Render Organelles */}
                  {ORGANELLES.map((org) => {
                    const isSelected = selectedOrganelle.id === org.id;
                    const isHovered = hoveredOrganelleId === org.id;
                    const activeColor = isSelected ? "#ffffff" : isHovered ? "#38bdf8" : org.color;
                    
                    return (
                      <group key={org.id}>
                        {org.shape === 'sphere' && (
                          <Sphere 
                            args={[1, 32, 32]} 
                            position={org.position} 
                            scale={org.scale}
                            onClick={() => setSelectedOrganelle(org)}
                            onPointerOver={() => setHoveredOrganelleId(org.id)}
                            onPointerOut={() => setHoveredOrganelleId(null)}
                          >
                            <meshStandardMaterial 
                              color={activeColor} 
                              roughness={0.3} 
                              metalness={0.1}
                            />
                          </Sphere>
                        )}
                        {org.shape === 'box' && (
                          <Box 
                            args={[1, 1, 1]} 
                            position={org.position} 
                            scale={org.scale}
                            onClick={() => setSelectedOrganelle(org)}
                            onPointerOver={() => setHoveredOrganelleId(org.id)}
                            onPointerOut={() => setHoveredOrganelleId(null)}
                          >
                            <meshStandardMaterial 
                              color={activeColor} 
                              roughness={0.4}
                            />
                          </Box>
                        )}
                        {org.shape === 'torus' && (
                          <Torus 
                            args={[0.5, 0.15, 12, 24]} 
                            position={org.position} 
                            scale={org.scale}
                            onClick={() => setSelectedOrganelle(org)}
                            onPointerOver={() => setHoveredOrganelleId(org.id)}
                            onPointerOut={() => setHoveredOrganelleId(null)}
                          >
                            <meshStandardMaterial 
                              color={activeColor} 
                              roughness={0.2}
                            />
                          </Torus>
                        )}
                      </group>
                    );
                  })}
                </group>
                <OrbitControls enableZoom={true} maxDistance={6} minDistance={2} />
              </Canvas>
            </div>
          </div>

          {/* Explanation Detail Panel */}
          <div className="w-full md:w-[350px] flex flex-col bg-white dark:bg-slate-950 overflow-y-auto p-4 select-text">
            <div className="flex justify-between items-start mb-3">
              <div>
                <span className="text-[10px] text-emerald-500 uppercase font-bold tracking-widest">Active Anatomy Component</span>
                <h2 className="text-xl font-bold font-sans flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedOrganelle.color }}></span>
                  {selectedOrganelle.name}
                </h2>
              </div>
              <button
                onClick={saveCellSnapshot}
                title="Save Snapshot to Chapters Notes"
                className="p-1.5 bg-slate-100 hover:bg-emerald-100 hover:text-emerald-700 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 rounded transition"
              >
                <Save className="w-4 h-4" />
              </button>
            </div>

            <p className="text-sm text-slate-600 dark:text-slate-400 mb-4 font-sans leading-relaxed">
              {selectedOrganelle.description}
            </p>

            <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg mb-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <HelpCircle className="w-3 h-3 text-emerald-500" />
                Under Cellular Theory
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-sans">
                {selectedOrganelle.functionTheory}
              </p>
            </div>

            <div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Key Structure Facts</h3>
              <ul className="space-y-1.5">
                {selectedOrganelle.keyFacts.map((fact, idx) => (
                  <li key={idx} className="text-xs flex items-start gap-2 text-slate-600 dark:text-slate-300">
                    <span className="text-emerald-500 font-bold mt-0.5">•</span>
                    <span>{fact}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      ) : activeTab === 'ecology' ? (
        // Ecosystem Predator-Prey Simulator
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Controls & Configuration Panel */}
          <div className="w-full md:w-[320px] bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 flex flex-col p-4">
            <h2 className="text-sm font-bold uppercase text-slate-400 mb-3">Ecosystem Sandbox Settings</h2>
            
            {/* Parameters */}
            <div className="space-y-4 flex-1 overflow-y-auto pr-1">
              {/* Parameter 1: Temperature Control */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-xs font-medium">
                  <span className="flex items-center gap-1">
                    Ambient Temperature
                    {(temperature < 10 || temperature > 40) && (
                      <span className="inline-flex items-center gap-0.5 text-[10px] text-amber-600 dark:text-amber-400 font-semibold" title="Stress zone">
                        <AlertTriangle className="w-3 h-3" />
                        {temperature > 40 ? 'Thermal Stress' : 'Hypothermia'}
                      </span>
                    )}
                  </span>
                  <span className={cn(
                    "font-mono font-bold px-1.5 py-0.5 rounded text-[11px]",
                    temperature < 10 || temperature > 40 ? "bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300" : "text-emerald-500"
                  )}>
                    {temperature.toFixed(1)}°C
                  </span>
                </div>
                <input 
                  type="range" 
                  min="-10.0" 
                  max="60.0" 
                  step="1.0" 
                  value={temperature} 
                  onChange={(e) => handleTemperatureChange(parseFloat(e.target.value))} 
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[9px] text-slate-400">
                  <span>-10°C (Freezing)</span>
                  <span>25°C (Optimal)</span>
                  <span>60°C (Lethal)</span>
                </div>
              </div>

              {/* Parameter 2: pH Level Control */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-xs font-medium">
                  <span className="flex items-center gap-1">
                    System pH Level
                    {(phLevel < 4.0 || phLevel > 10.0) && (
                      <span className="inline-flex items-center gap-0.5 text-[10px] text-amber-600 dark:text-amber-400 font-semibold" title="Severe pH imbalance">
                        <AlertTriangle className="w-3 h-3" />
                        {phLevel < 4.0 ? 'Acid Stress' : 'Alkaline Stress'}
                      </span>
                    )}
                  </span>
                  <span className={cn(
                    "font-mono font-bold px-1.5 py-0.5 rounded text-[11px]",
                    phLevel < 4.0 || phLevel > 10.0 ? "bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300" : "text-emerald-500"
                  )}>
                    pH {phLevel.toFixed(1)}
                  </span>
                </div>
                <input 
                  type="range" 
                  min="0.0" 
                  max="14.0" 
                  step="0.5" 
                  value={phLevel} 
                  onChange={(e) => handlePhChange(parseFloat(e.target.value))} 
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-[9px] text-slate-400">
                  <span>0 (Acidic)</span>
                  <span>7.0 (Neutral)</span>
                  <span>14 (Alkaline)</span>
                </div>
              </div>

              {/* Parameter 3: Grass Growth */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-medium">
                  <span>Grass Growth Rate</span>
                  <span className="text-emerald-500 font-mono font-bold">{grassGrowth.toFixed(1)}x</span>
                </div>
                <input 
                  type="range" 
                  min="1.0" 
                  max="5.0" 
                  step="0.5" 
                  value={grassGrowth} 
                  onChange={(e) => handleGrassGrowthChange(parseFloat(e.target.value))} 
                  className="w-full accent-emerald-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-[10px] text-slate-500">Determines primary biomass carrying capacity.</span>
              </div>

              {/* Parameter 4: Climate */}
              <div className="space-y-2">
                <label className="text-xs font-medium">Climate Scenario</label>
                <div className="grid grid-cols-3 gap-1">
                  {(['optimal', 'drought', 'cold'] as const).map(mode => (
                    <button
                      key={mode}
                      onClick={() => setClimate(mode)}
                      className={cn(
                        "text-[10px] py-1 capitalize font-medium rounded transition border",
                        climate === mode 
                          ? "bg-emerald-100 text-emerald-800 border-emerald-500 dark:bg-emerald-950/40 dark:text-emerald-300" 
                          : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900"
                      )}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              {/* Simulator Metrics */}
              <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg space-y-2">
                <div className="text-[10px] uppercase font-bold text-slate-400">Current Populations</div>
                <div className="flex justify-between text-xs">
                  <span className="flex items-center gap-1">🐇 Rabbits (Prey)</span>
                  <span className="font-mono font-bold text-blue-500">{rabbits[rabbits.length - 1] || 0}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="flex items-center gap-1">🦊 Wolves (Predators)</span>
                  <span className="font-mono font-bold text-red-500">{wolves[wolves.length - 1] || 0}</span>
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex gap-2 pt-4 border-t border-slate-200 dark:border-slate-800 mt-4">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="flex-1 flex justify-center items-center gap-1 py-1.5 text-xs font-semibold rounded bg-emerald-500 text-white hover:bg-emerald-600 transition"
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                {isPlaying ? "Pause" : "Simulate"}
              </button>
              <button
                onClick={handleResetEcosystem}
                className="p-1.5 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 rounded transition text-slate-500"
                title="Reset simulation parameters"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={takeSnapshot}
                className="p-1.5 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 rounded transition text-slate-500"
                title="Take Quick Snapshot"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={saveEcologySnapshot}
                className="p-1.5 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 rounded transition text-slate-500"
                title="Save study note snapshot"
              >
                <Save className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Visualizing Chart and Feedback Screen */}
          <div className="flex-1 flex flex-col p-4 select-text">
            {/* Stability Gauge */}
            <div className="mb-4 p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 flex flex-col">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider mb-1">Ecological Stability Index</span>
              <div className="flex items-center justify-between">
                <span className={cn("text-xs font-bold px-2 py-0.5 rounded", stability.color)}>
                  {stability.label}
                </span>
                <span className="text-xs font-mono text-slate-400">Step: {stepCount}</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1.5 font-sans">
                {stability.desc}
              </p>
            </div>

            {/* Line Graph representation using SVG */}
            <div className="flex-1 min-h-[180px] bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-3 flex flex-col">
              <span className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1.5">
                <BarChart2 className="w-4 h-4 text-emerald-500" /> Population Waves (Time Series)
              </span>
              
              <div className="flex-1 w-full relative">
                {/* SVG Line Graph */}
                <svg className="w-full h-full overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
                  {/* Grid Lines */}
                  <line x1="0" y1="25" x2="100" y2="25" stroke="#e2e8f0" strokeDasharray="2,2" strokeWidth="0.5" className="dark:stroke-slate-800" />
                  <line x1="0" y1="50" x2="100" y2="50" stroke="#e2e8f0" strokeDasharray="2,2" strokeWidth="0.5" className="dark:stroke-slate-800" />
                  <line x1="0" y1="75" x2="100" y2="75" stroke="#e2e8f0" strokeDasharray="2,2" strokeWidth="0.5" className="dark:stroke-slate-800" />

                  {/* Rabbit population line */}
                  {rabbits.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="1.5"
                      points={rabbits.map((val, idx) => {
                        const x = (idx / (rabbits.length - 1)) * 100;
                        const y = 100 - Math.min(100, (val / 160) * 100);
                        return `${x},${y}`;
                      }).join(' ')}
                    />
                  )}

                  {/* Wolf population line */}
                  {wolves.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="#ef4444"
                      strokeWidth="1.5"
                      points={wolves.map((val, idx) => {
                        const x = (idx / (wolves.length - 1)) * 100;
                        const y = 100 - Math.min(100, (val / 50) * 100);
                        return `${x},${y}`;
                      }).join(' ')}
                    />
                  )}
                </svg>

                {/* Graph Labels */}
                <div className="absolute top-1 right-2 flex gap-3 text-[10px]">
                  <span className="flex items-center gap-1 text-blue-500 font-bold">● Rabbits (Prey)</span>
                  <span className="flex items-center gap-1 text-red-500 font-bold">● Wolves (Predator)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : activeTab === 'metrics' ? (
        <div className="flex-1 p-3 overflow-hidden">
          <BiologyMetricsVisualization theme={theme} showNotification={showNotification} />
        </div>
      ) : activeTab === 'lifecycles' ? (
        <div className="flex-1 p-4 overflow-hidden">
          <LifeCycleExplorer theme={theme} />
        </div>
      ) : (
        <div className="flex-1 p-4 overflow-hidden">
          <PunnettSquareSimulator theme={theme} />
        </div>
      )}
    </div>
  );
};
