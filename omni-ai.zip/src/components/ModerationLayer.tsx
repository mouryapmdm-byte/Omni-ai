import React from 'react';
import { ShieldCheck, AlertCircle, Sparkles, Check, Lock, EyeOff } from 'lucide-react';
import { cn } from '../lib/utils';

export interface ModerationResult {
  isSafe: boolean;
  category?: 'toxic' | 'unconstructive' | 'offensive' | 'spam';
  suggestion?: string;
  flaggedTerms?: string[];
}

export class ModerationEngine {
  private static toxicPatterns = [
    /\b(stupid|dumb|idiot|trash|garbage|shut up|nonsense|useless|worthless|hate you)\b/i,
    /\b(loser|moron|retard|clown)\b/i
  ];

  private static unconstructivePatterns = [
    /\b(this is wrong)\b(?!\s*because)/i,
    /\b(you don't know anything)\b/i,
    /\b(bad explanation)\b/i
  ];

  /**
   * Screens content and offers constructive pedagogical reframing
   */
  public static screenContent(text: string): ModerationResult {
    if (!text || text.trim().length === 0) {
      return { isSafe: true };
    }

    // Toxic check
    for (const pattern of this.toxicPatterns) {
      const match = text.match(pattern);
      if (match) {
        return {
          isSafe: false,
          category: 'offensive',
          flaggedTerms: [match[0]],
          suggestion: 'Omni Peer Learning requires mutual respect. Try rephrasing with constructive, specific feedback.'
        };
      }
    }

    // Unconstructive check
    for (const pattern of this.unconstructivePatterns) {
      const match = text.match(pattern);
      if (match) {
        return {
          isSafe: true,
          category: 'unconstructive',
          suggestion: 'Tip: Instead of stating something is wrong, point out which step or formula could be refined!'
        };
      }
    }

    return { isSafe: true };
  }
}

export interface ModerationNoticeProps {
  isOptedIn: boolean;
  onToggleOptIn?: (value: boolean) => void;
  className?: string;
}

export const ModerationLayer: React.FC<ModerationNoticeProps> = ({
  isOptedIn,
  onToggleOptIn,
  className
}) => {
  return (
    <div className={cn(
      "p-4 rounded-2xl border transition-all relative overflow-hidden",
      "bg-slate-50 dark:bg-slate-900/90 border-slate-200 dark:border-slate-800 text-xs",
      className
    )}>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
            <ShieldCheck size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                AI Moderation & Privacy Guard
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                Active
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              100% Anonymized review system. Real names and student identifiers are strictly masked.
            </p>
          </div>
        </div>

        {onToggleOptIn && (
          <div className="flex items-center gap-3 self-end sm:self-center">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-300">
              {isOptedIn ? (
                <>
                  <EyeOff size={13} className="text-emerald-500" />
                  <span>Opted in (Anonymous)</span>
                </>
              ) : (
                <>
                  <Lock size={13} className="text-slate-400" />
                  <span>Private Only</span>
                </>
              )}
            </div>

            <button
              type="button"
              onClick={() => onToggleOptIn(!isOptedIn)}
              className={cn(
                "relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                isOptedIn ? "bg-emerald-600" : "bg-slate-300 dark:bg-slate-700"
              )}
            >
              <span
                className={cn(
                  "pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out",
                  isOptedIn ? "translate-x-5" : "translate-x-0"
                )}
              />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
