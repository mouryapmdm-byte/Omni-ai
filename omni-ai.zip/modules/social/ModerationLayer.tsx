export * from '../../src/components/ModerationLayer';
export { ModerationLayer as default } from '../../src/components/ModerationLayer';
