/**
 * Hindi Comprehensive Study Content Generator
 * Professor Clarity's Active Pedagogy in Natural Hindi
 *
 * Teaches EXCLUSIVELY the selected chapter/topic across all 7 sections in authentic Hindi (Devanagari).
 * 1. ⚛️ Section 1: Core Conceptual Foundation & Active Pedagogy
 * 2. 📐 Section 2: Master 10-Step Formula & Algorithmic Problem-Solving Framework
 * 3. 📊 Section 3: Master Tabular Summaries & Comparative Matrix Suite
 * 4. 📝 Section 4: Academic & Board Exam Preparation Suite
 * 5. 🎯 Section 5: Competitive Entrance Exam Vault (NEET / JEE / AIIMS)
 * 6. 🗣️ Section 6: High-Yield Question Bank, Vocabulary Masterclass & Spoken Units Guide
 * 7. ⚡ Section 7: The 5-Layer Progressive High Voltage Summary (The Final Section)
 */

import { getCurriculumProfile } from './topicCurriculumKnowledge';

export function buildComprehensiveHindiStudyContent(
  topicTitle: string, 
  baseLectureText?: string, 
  sectionId?: number | 'all'
): string {
  const cleanTitle = (topicTitle || 'सार्वभौमिक वैज्ञानिक एवं गणितीय सिद्धांत').replace(/^(###\s*|Topic:\s*)/i, '').trim();
  const profile = getCurriculumProfile(cleanTitle);

  // Section 1: Core Conceptual Foundation
  const section1Content = `# ⚛️ Section 1: Core Conceptual Foundation & Active Pedagogy

### अध्याय / विषय: ${cleanTitle}

नमस्ते छात्रों! मैं **Professor Clarity** हूँ। आज हम **${cleanTitle}** को बुनियादी प्रथम-सिद्धांतों (First Principles) से बिना किसी जटिल शब्दावली के समझेंगे। विज्ञान केवल सूत्रों को रटना नहीं है, बल्कि प्रकृति के खूबसूरत नियमों को अपनी आँखों से देखना है!

---

#### 🌟 व्यावहारिक उपमा (Real-World Analogy):
${profile.analogy}

#### ❓ जिज्ञासा-प्रेरक प्रश्न (The Curiosity Question):
${profile.questionFirst}

---

#### 🎨 संवादात्मक 3D रेखाचित्र (Interactive Scientific Vector Schematic):
${profile.svgDiagram}

---
*इस आरेख को ध्यानपूर्वक देखिए: यह दर्शाता है कि ${cleanTitle} में सभी भौतिक एवं गणितीय राशियां किस प्रकार एक दूसरे से पूर्णतः संतुलित रहती हैं।*`;

  // Section 2: Master 10-Step Formula & Technique 11 Adaptive Practice
  const section2Content = `# 📐 Section 2: Master 10-Step Formula & Algorithmic Problem-Solving Framework

### अध्याय / विषय: ${cleanTitle}

इस मॉड्यूल का प्रत्येक सूत्र प्रोफेसर क्लैरिटी के 10-चरणीय शैक्षणिक रूपांतरण का पालन करता है और सीधे बहु-स्तरीय प्रश्नों के अभ्यास से जुड़ता है:

### 🎯 मुख्य गवर्निंग समीकरण: ${profile.governingEquationName}
$$${profile.governingEquationLatex}$$

| चरण | प्रोटोकॉल चरण | सरल हिन्दी व्याख्या | वैज्ञानिक सूत्र / मान | परीक्षा का स्वर्णिम नियम एवं जाल |
| :--- | :--- | :--- | :--- | :--- |
${profile.tenStepProtocol.map(s => `| **चरण ${s.step}** | **${s.phase}** | ${s.explanation} | $${s.formulaOrValue}$ | ${s.trapAndTip} |`).join('\n')}

---

### 🧪 तकनीक 11: सूत्र-से-अभ्यास प्राकृतिक प्रवाह (5-स्तरीय बहु-चरणीय अभ्यास प्रश्न)

अब जब हमने **${cleanTitle}** के मुख्य समीकरण को समझ लिया है, आइए सीधे 5 विभिन्न कठिनाई स्तरों के प्रश्नों को हल करें:

${profile.technique11Questions.map(q => `#### ${q.level === 1 ? '🟢' : q.level === 2 ? '🟡' : q.level === 3 ? '🟠' : q.level === 4 ? '🔴' : '🟣'} स्तर ${q.level}: ${q.levelName} (${q.difficulty === 'Easy' ? 'सरल' : q.difficulty === 'Medium' ? 'मध्यम' : q.difficulty === 'Hard' ? 'कठिन' : q.difficulty === 'Advanced' ? 'उच्च स्तर' : 'प्रतियोगी स्तर'})
- **प्रश्न:** ${q.question}
- **सूत्र अनुप्रयोग:** ${q.formulaApplication}
- **चरण-दर-चरण हल:**
${q.stepByStepSolution.map((step, idx) => `  ${idx + 1}. ${step}`).join('\n')}
- **👉 सटीक उत्तर:** ${q.answer}
`).join('\n')}`;

  // Section 3: Master Tabular Summaries & Comparative Matrices
  const section3Content = `# 📊 Section 3: Master Tabular Summaries & Comparative Matrix Suite

### अध्याय / विषय: ${cleanTitle}

यहाँ **${cleanTitle}** के सभी प्रमुख नियमों, सीमाओं और भौतिक स्थितियों का तुलनात्मक विश्लेषण प्रस्तुत है:

${profile.comparativeMatrices.map(mat => `### 📊 ${mat.title}

| ${mat.headers.join(' | ')} |
| ${mat.headers.map(() => ':---').join(' | ')} |
${mat.rows.map(row => `| ${row.join(' | ')} |`).join('\n')}
`).join('\n\n')}

---

### 🧭 ${profile.diagnosticDecisionMatrix.title}

| ${profile.diagnosticDecisionMatrix.headers.join(' | ')} |
| ${profile.diagnosticDecisionMatrix.headers.map(() => ':---').join(' | ')} |
${profile.diagnosticDecisionMatrix.rows.map(row => `| ${row.join(' | ')} |`).join('\n')}`;

  // Section 4: Academic & Board Exam Preparation Suite (8 Categories)
  const section4Content = `# 📝 Section 4: Academic & Board Exam Preparation Suite

### अध्याय / विषय: ${cleanTitle}

बोर्ड परीक्षाओं में शत-प्रतिशत अंक प्राप्त करने के लिए नवीनतम अंकन योजना (Marking Scheme) पर आधारित 8 संरचित प्रश्न श्रेणियाँ:

${profile.academicQuestions.map((q, i) => `#### 📝 प्रश्न ${i + 1} [${q.category}] (${q.marks} अंक)
- **प्रश्न:** ${q.question}
- **आधिकारिक आदर्श उत्तर:** ${q.answer}
- **अंकन योजना (Marking Scheme):**
${q.markingScheme.map(m => `  - ✓ ${m}`).join('\n')}
`).join('\n')}`;

  // Section 5: Competitive Entrance Exam Vault (NEET / JEE / AIIMS)
  const section5Content = `# 🎯 Section 5: Competitive Entrance Exam Vault (NEET / JEE / AIIMS)

### अध्याय / विषय: ${cleanTitle}

प्रतियोगी परीक्षाओं में समय बचाने और नकारात्मक अंकन (Negative Marking) से बचने के लिए उच्च-स्तरीय प्रश्न एवं शॉर्टकट तकनीकें:

${profile.competitiveQuestions.map((q, i) => `#### 🎯 चुनौती ${i + 1}: ${q.category}
- **प्रश्न:** ${q.question}
${q.options && q.options.length ? q.options.map(opt => `  - ${opt}`).join('\n') : ''}
${q.correctOption ? `- **👉 सही विकल्प:** ${q.correctOption}` : ''}
- **विस्तृत हल:** ${q.solution}
- **⚡ स्पीड ट्रिक / शॉर्टकट:** ${q.speedTrick}
- **⚠️ नकारात्मक अंकन का जाल (Trap):** ${q.negativeMarkingTrap}
`).join('\n')}`;

  // Section 6: High-Yield Question Bank, Vocabulary & Spoken Units
  const section6Content = `# 🗣️ Section 6: High-Yield Question Bank, Vocabulary Masterclass & Spoken Units Guide

### अध्याय / विषय: ${cleanTitle}

### ⚡ रैपिड-फायर उच्च-प्राथमिकता प्रश्न बैंक (${cleanTitle})
${profile.rapidFireQuestions.map(q => `**प्रश्न ${q.qNumber}. ${q.question}**  
- *सटीक उत्तर:* ${q.answer}  
- *वैज्ञानिक कारण:* ${q.shortExplanation}
`).join('\n')}

---

### 📖 वैज्ञानिक शब्दावली एवं व्युत्पत्ति (Vocabulary Masterclass)
| वैज्ञानिक शब्द | मूल व्युत्पत्ति | सटीक वैज्ञानिक परिभाषा | याद रखने का सूत्र |
| :--- | :--- | :--- | :--- |
${profile.vocabularyMasterclass.map(v => `| **${v.term}** | ${v.etymology} | ${v.definition} | *${v.memoryHook}* |`).join('\n')}

---

### 🎙️ वैज्ञानिक इकाइयाँ एवं शुद्ध हिन्दी उच्चारण गाइड
| प्रतीक | वैज्ञानिक इकाई | शुद्ध उच्चारण | भौतिक संदर्भ (${cleanTitle}) |
| :--- | :--- | :--- | :--- |
${profile.spokenUnits.map(u => `| **${u.symbol}** | ${u.unitName} | *"${u.spokenForm}"* | ${u.physicalMeaning} |`).join('\n')}

---

### 🎙️ प्रोफेसर क्लैरिटी के स्वाभाविक वाचन नियम:
- **प्रतीकों को सीधे स्वाभाविक शब्दों में बोलें**: सूत्रों को बिना अटके सहज रूप से समझाएं।
- **फॉर्मेटिंग चिन्हों का उच्चारण न करें**: बुलेट पॉइंट्स, तारों, या कोष्ठकों को मुखरित न करें।`;

  // Section 7: The 5-Layer Progressive High Voltage Summary
  const section7Content = `# ⚡ Section 7: The 5-Layer Progressive High Voltage Summary (The Final Section)

### अध्याय / विषय: ${cleanTitle}

#### ⚡ स्तर 1: 30-सेकंड अति-संक्षिप्त सार (Ultra-Compressed Core)
${profile.fiveLayerSummary.layer1UltraRapid}

#### 🎯 स्तर 2: 5-बिंदु बुनियादी सिद्धांत (First Principles)
${profile.fiveLayerSummary.layer2FirstPrinciples.map(p => `- ${p}`).join('\n')}

#### 📐 स्तर 3: स्वर्णिम सूत्र केंद्र (Golden Formula Hub)
${profile.fiveLayerSummary.layer3GoldenEquations.map(e => `$$${e}$$`).join('\n')}

#### ⚠️ स्तर 4: सामान्य गलतियाँ एवं परीक्षक के जाल (Pitfalls & Traps)
${profile.fiveLayerSummary.layer4ExaminerTraps.map(t => `- 🚨 **सावधानी:** ${t}`).join('\n')}

#### 🧠 स्तर 5: विजुअल स्मार्टबोर्ड मानसिक आरेख (Visual Mental Schema)
\`\`\`
${profile.fiveLayerSummary.layer5VisualMentalSchema}
\`\`\``;

  if (sectionId === 1) return section1Content;
  if (sectionId === 2) return section2Content;
  if (sectionId === 3) return section3Content;
  if (sectionId === 4) return section4Content;
  if (sectionId === 5) return section5Content;
  if (sectionId === 6) return section6Content;
  if (sectionId === 7) return section7Content;

  return `${section1Content}\n\n---\n\n${section2Content}\n\n---\n\n${section3Content}\n\n---\n\n${section4Content}\n\n---\n\n${section5Content}\n\n---\n\n${section6Content}\n\n---\n\n${section7Content}`;
}
