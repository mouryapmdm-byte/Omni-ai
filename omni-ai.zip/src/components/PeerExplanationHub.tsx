import React, { useState } from 'react';
import { ExplainBackCard } from './ExplainBackCard';
import { StudyRoom } from './StudyRoom';
import { DebateMode } from './DebateMode';
import { 
  Users, 
  MessageSquare, 
  Swords, 
  Sparkles, 
  X,
  BookOpen,
  HelpCircle,
  GraduationCap
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface PeerExplanationHubProps {
  currentStudentId?: string;
  currentStudentName?: string;
  initialTopic?: string;
  onClose?: () => void;
  className?: string;
}

export const PeerExplanationHub: React.FC<PeerExplanationHubProps> = ({
  currentStudentId = 'student_user',
  currentStudentName = 'Alex',
  initialTopic = 'Faraday-Lenz Principle & Induction',
  onClose,
  className
}) => {
  const [activeMode, setActiveMode] = useState<'explain' | 'study_room' | 'debate'>('explain');
  const [topic, setTopic] = useState(initialTopic);

  return (
    <div className={cn(
      "p-4 sm:p-6 rounded-3xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 shadow-2xl max-w-5xl w-full mx-auto space-y-5 text-slate-900 dark:text-slate-100",
      className
    )}>
      {/* Top Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/30 shrink-0">
            <GraduationCap size={24} />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              Social Learning & Peer Explanation Suite
              <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-bold border border-indigo-500/20 uppercase tracking-wider">
                Active Pedagogy
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Transform passive study into active mastery through peer teaching, collaborative smartboards, and evidence debates.
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X size={20} />
          </button>
        )}
      </div>

      {/* Navigation Switcher Tabs */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-200 dark:bg-slate-900 border border-slate-300 dark:border-slate-800 w-full sm:w-fit overflow-x-auto">
        <button
          onClick={() => setActiveMode('explain')}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap",
            activeMode === 'explain'
              ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
          )}
        >
          <Sparkles size={15} />
          <span>Explain-Back & Peer Review</span>
        </button>

        <button
          onClick={() => setActiveMode('study_room')}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap",
            activeMode === 'study_room'
              ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
          )}
        >
          <Users size={15} />
          <span>4-Student Study Room (Live Canvas)</span>
        </button>

        <button
          onClick={() => setActiveMode('debate')}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer whitespace-nowrap",
            activeMode === 'debate'
              ? "bg-white dark:bg-slate-800 text-purple-600 dark:text-purple-400 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
          )}
        >
          <Swords size={15} />
          <span>Academic Debate Mode</span>
        </button>
      </div>

      {/* Mode Renderers */}
      {activeMode === 'explain' && (
        <ExplainBackCard
          conceptId={topic ? topic.toLowerCase().replace(/[^a-z0-9]/g, '_') : 'faradays_law'}
          conceptTitle={topic || "Faraday's Law of Electromagnetic Induction"}
          studentId={currentStudentId}
          studentName={currentStudentName}
        />
      )}

      {activeMode === 'study_room' && (
        <StudyRoom
          currentStudentId={currentStudentId}
          currentStudentName={currentStudentName}
          conceptTitle={topic}
        />
      )}

      {activeMode === 'debate' && (
        <DebateMode
          currentStudentName={currentStudentName}
        />
      )}
    </div>
  );
};
