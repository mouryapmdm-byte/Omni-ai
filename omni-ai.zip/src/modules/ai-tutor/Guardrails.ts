export interface GuardrailCheck {
  passed: boolean;
  reason?: string;
  sanitizedMessage?: string;
  suggestedResponse?: string;
}

export class Guardrails {
  // Prohibited topics that have absolutely no educational or academic context
  private static OFF_TOPIC_KEYWORDS = [
    "bomb", "weapon", "drugs", "hacks", "warez", "bypass security",
    "love letter", "relationship advice", "gaming hacks", "torrent",
    "cheating in exam", "copy pasta", "steal"
  ];

  static checkQuery(query: string): GuardrailCheck {
    const normalized = query.toLowerCase().trim();

    if (!normalized) {
      return { passed: true };
    }

    // Check for inappropriate keywords
    for (const keyword of this.OFF_TOPIC_KEYWORDS) {
      if (normalized.includes(keyword)) {
        return {
          passed: false,
          reason: `contains_restricted_keyword`,
          suggestedResponse: `I'm your academic AI Tutor, here to help you study! I cannot assist with this topic. Let's redirect our attention to your syllabus. What topics in Math, Physics, Chemistry, or Biology can we explore together?`
        };
      }
    }

    // Heuristics to check if query is completely unrelated to academics
    const academicWords = [
      "solve", "physics", "math", "chemistry", "biology", "explain", "derive",
      "formula", "equation", "problem", "lesson", "chapter", "concept", "vector",
      "calculus", "optics", "reactions", "cell", "mitosis", "photosynthesis", "carbon",
      "atoms", "force", "gravity", "speed", "velocity", "syllabus", "exam", "college",
      "quiz", "how does", "why is", "what is", "help me understand", "diagram", "draw"
    ];

    const hasAcademicContext = academicWords.some(word => normalized.includes(word));

    // Allow general conversation starts ("hello", "who are you"), but flag extreme non-academic rants
    if (normalized.length > 50 && !hasAcademicContext) {
      // It is a long message without any academic reference. Provide a warning check.
      // We don't want to block users starting general chat, but keep them on topic.
      return {
        passed: true,
        sanitizedMessage: query // Keep query but note educational warning could be appended
      };
    }

    return { passed: true };
  }

  // Wraps user message to prevent the model from answering directly if it detects homework-doing attempts
  static enforcePedagogicalSocrates(query: string): string {
    const normalized = query.toLowerCase();
    
    // Check if student is demanding a direct solution
    const demandsDirectSolution = [
      "solve this", "give me the answer", "do my homework", "write this essay",
      "what is the direct answer", "give me the final code"
    ].some(phrase => normalized.includes(phrase));

    if (demandsDirectSolution) {
      return `${query}\n\n[Pedagogical Constraint: The student is asking for a direct solution. Please do NOT give the direct final answer immediately. Instead, explain the principles step-by-step, outline the formula, guide them through the first step, and ask them to perform the final calculation or write the next line of code themselves to reinforce their learning.]`;
    }

    return query;
  }
}
