import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play, Pause, Music, CloudRain, Trees, Radio, Sliders, Sparkles, Check } from 'lucide-react';
import { AmbientSoundTrack, AmbientSoundType } from './types';

interface AmbientSoundsProps {
  isDark?: boolean;
}

export const AmbientSounds: React.FC<AmbientSoundsProps> = ({ isDark = true }) => {
  const [tracks, setTracks] = useState<AmbientSoundTrack[]>([
    {
      id: 'lofi',
      name: 'Lofi Focus Beats',
      category: 'Music',
      description: 'Muted warm electric piano chords & subtle vinyl crackle',
      iconName: 'Music',
      volume: 0.6,
      isPlaying: false
    },
    {
      id: 'rain',
      name: 'Gentle Rain & Thunder',
      category: 'Nature',
      description: 'Soft rooftop rainfall with distance thunder low-pass rumbles',
      iconName: 'CloudRain',
      volume: 0.7,
      isPlaying: false
    },
    {
      id: 'forest',
      name: 'Pine Forest Breeze',
      category: 'Nature',
      description: 'Calming forest wind & high-frequency leafrustle harmonics',
      iconName: 'Trees',
      volume: 0.5,
      isPlaying: false
    },
    {
      id: 'whitenoise',
      name: 'Pink Noise Masking',
      category: 'Noise',
      description: 'Balanced frequency acoustic masking for noisy study environments',
      iconName: 'Radio',
      volume: 0.4,
      isPlaying: false
    },
    {
      id: 'binaural',
      name: '432Hz Alpha Binaural',
      category: 'Therapy',
      description: '10Hz Alpha brainwave binaural tone for deep flow state focus',
      iconName: 'Sparkles',
      volume: 0.5,
      isPlaying: false
    }
  ]);

  const [masterVolume, setMasterVolume] = useState<number>(0.8);
  const [masterPlaying, setMasterPlaying] = useState<boolean>(false);

  // Web Audio Context & Nodes
  const audioCtxRef = useRef<AudioContext | null>(null);
  const soundNodesRef = useRef<{
    [key in AmbientSoundType]?: {
      sourceNode: AudioNode;
      gainNode: GainNode;
      stopFn?: () => void;
    };
  }>({});

  const initAudioCtx = () => {
    if (!audioCtxRef.current) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtxRef.current = new AudioContextClass();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const startTrackSound = (trackId: AmbientSoundType, vol: number) => {
    initAudioCtx();
    const ctx = audioCtxRef.current;
    if (!ctx) return;

    // Stop existing if any
    stopTrackSound(trackId);

    const masterGain = vol * masterVolume;
    const gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(masterGain, ctx.currentTime);
    gainNode.connect(ctx.destination);

    if (trackId === 'whitenoise') {
      // Pink/White Noise Generator
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        output[i] *= 0.11; // scale down
        b6 = white * 0.115926;
      }

      const whiteNoiseSource = ctx.createBufferSource();
      whiteNoiseSource.buffer = noiseBuffer;
      whiteNoiseSource.loop = true;
      whiteNoiseSource.connect(gainNode);
      whiteNoiseSource.start();

      soundNodesRef.current[trackId] = {
        sourceNode: whiteNoiseSource,
        gainNode,
        stopFn: () => whiteNoiseSource.stop()
      };
    } else if (trackId === 'rain') {
      // Rain simulator using filtered noise
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.2;
      }

      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = noiseBuffer;
      noiseSource.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, ctx.currentTime);

      noiseSource.connect(filter);
      filter.connect(gainNode);
      noiseSource.start();

      soundNodesRef.current[trackId] = {
        sourceNode: noiseSource,
        gainNode,
        stopFn: () => noiseSource.stop()
      };
    } else if (trackId === 'binaural') {
      // 432 Hz + 10 Hz Alpha Binaural Beat
      const oscL = ctx.createOscillator();
      const oscR = ctx.createOscillator();
      const merger = ctx.createChannelMerger(2);

      oscL.frequency.setValueAtTime(432, ctx.currentTime); // Left ear 432 Hz
      oscR.frequency.setValueAtTime(442, ctx.currentTime); // Right ear 442 Hz (10Hz Alpha differential)

      oscL.connect(merger, 0, 0);
      oscR.connect(merger, 0, 1);
      merger.connect(gainNode);

      oscL.start();
      oscR.start();

      soundNodesRef.current[trackId] = {
        sourceNode: oscL,
        gainNode,
        stopFn: () => {
          oscL.stop();
          oscR.stop();
        }
      };
    } else if (trackId === 'lofi' || trackId === 'forest') {
      // Warm chord / breeze synthesizer
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();

      osc1.type = 'sine';
      osc2.type = 'triangle';

      if (trackId === 'lofi') {
        osc1.frequency.setValueAtTime(220, ctx.currentTime); // A3 chord
        osc2.frequency.setValueAtTime(277.18, ctx.currentTime); // C#4
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(450, ctx.currentTime);
      } else {
        osc1.frequency.setValueAtTime(130, ctx.currentTime);
        osc2.frequency.setValueAtTime(196, ctx.currentTime);
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(600, ctx.currentTime);
      }

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gainNode);

      osc1.start();
      osc2.start();

      soundNodesRef.current[trackId] = {
        sourceNode: osc1,
        gainNode,
        stopFn: () => {
          osc1.stop();
          osc2.stop();
        }
      };
    }
  };

  const stopTrackSound = (trackId: AmbientSoundType) => {
    const node = soundNodesRef.current[trackId];
    if (node) {
      if (node.stopFn) node.stopFn();
      delete soundNodesRef.current[trackId];
    }
  };

  const toggleTrack = (trackId: AmbientSoundType) => {
    setTracks(prev =>
      prev.map(t => {
        if (t.id === trackId) {
          const nextState = !t.isPlaying;
          if (nextState) {
            startTrackSound(t.id, t.volume);
          } else {
            stopTrackSound(t.id);
          }
          return { ...t, isPlaying: nextState };
        }
        return t;
      })
    );
  };

  const updateTrackVolume = (trackId: AmbientSoundType, vol: number) => {
    setTracks(prev =>
      prev.map(t => {
        if (t.id === trackId) {
          const updated = { ...t, volume: vol };
          const node = soundNodesRef.current[trackId];
          if (node && audioCtxRef.current) {
            node.gainNode.gain.setValueAtTime(vol * masterVolume, audioCtxRef.current.currentTime);
          }
          return updated;
        }
        return t;
      })
    );
  };

  const handleToggleMaster = () => {
    const nextMaster = !masterPlaying;
    setMasterPlaying(nextMaster);

    if (!nextMaster) {
      // Pause all active tracks
      tracks.forEach(t => {
        if (t.isPlaying) stopTrackSound(t.id);
      });
      setTracks(prev => prev.map(t => ({ ...t, isPlaying: false })));
    } else {
      // Turn on first track by default if none playing
      if (!tracks.some(t => t.isPlaying)) {
        toggleTrack('lofi');
      }
    }
  };

  useEffect(() => {
    return () => {
      // Cleanup all nodes on unmount
      Object.keys(soundNodesRef.current).forEach(key => {
        stopTrackSound(key as AmbientSoundType);
      });
    };
  }, []);

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Music': return <Music className="w-5 h-5" />;
      case 'CloudRain': return <CloudRain className="w-5 h-5" />;
      case 'Trees': return <Trees className="w-5 h-5" />;
      case 'Radio': return <Radio className="w-5 h-5" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  return (
    <div className={`rounded-2xl p-6 border ${isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Music className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-100">Ambient Study Soundscape</h3>
            <p className="text-xs text-slate-400">100% Royalty-free acoustic focus masking</p>
          </div>
        </div>

        {/* Master Toggle Button */}
        <button
          onClick={handleToggleMaster}
          className={`px-4 py-2 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all shadow-md ${
            masterPlaying
              ? 'bg-purple-500 text-slate-950 border-purple-400 font-bold'
              : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
          }`}
        >
          {masterPlaying ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          <span>{masterPlaying ? 'Soundscape Active' : 'All Muted'}</span>
        </button>
      </div>

      {/* Sound Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {tracks.map(track => (
          <div
            key={track.id}
            className={`p-4 rounded-xl border transition-all ${
              track.isPlaying
                ? 'bg-purple-950/30 border-purple-500/50 shadow-lg shadow-purple-500/10'
                : 'bg-slate-800/40 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                  track.isPlaying ? 'bg-purple-500/20 text-purple-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  {renderIcon(track.iconName)}
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                    {track.name}
                    {track.isPlaying && (
                      <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
                    )}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">{track.description}</p>
                </div>
              </div>

              {/* Play / Pause Toggle button */}
              <button
                onClick={() => {
                  toggleTrack(track.id);
                  if (!masterPlaying) setMasterPlaying(true);
                }}
                className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${
                  track.isPlaying
                    ? 'bg-purple-500 text-slate-950 border-purple-400 shadow'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {track.isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
              </button>
            </div>

            {/* Volume Slider */}
            {track.isPlaying && (
              <div className="mt-4 pt-3 border-t border-purple-500/20 flex items-center gap-3 animate-in fade-in duration-150">
                <Volume2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={track.volume}
                  onChange={e => updateTrackVolume(track.id, parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-purple-400"
                />
                <span className="text-[10px] font-mono text-purple-300 w-8 text-right">
                  {Math.round(track.volume * 100)}%
                </span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
