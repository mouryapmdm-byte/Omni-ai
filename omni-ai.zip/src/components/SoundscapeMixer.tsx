import React from 'react';
import { Volume2, BookOpen, PenTool, Waves } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface SoundscapeMixerProps {
  theme: 'light' | 'dark';
  reverbVolume: number;
  setReverbVolume: (val: number) => void;
  writingVolume: number;
  setWritingVolume: (val: number) => void;
  noiseVolume: number;
  setNoiseVolume: (val: number) => void;
  isDucking: boolean;
}

export const SoundscapeMixer: React.FC<SoundscapeMixerProps> = ({
  theme,
  reverbVolume, setReverbVolume,
  writingVolume, setWritingVolume,
  noiseVolume, setNoiseVolume,
  isDucking,
}) => {
  const getVolume = (vol: number) => isDucking ? vol * 0.2 : vol;

  return (
    <div className={cn(
        "absolute top-20 right-4 p-4 rounded-2xl shadow-2xl border backdrop-blur-xl z-50 w-64 space-y-4",
        theme === 'dark'
          ? "bg-slate-900/90 border-slate-700 text-white"
          : "bg-white/90 border-slate-200 text-slate-800"
    )}>
        <h3 className="text-sm font-bold flex items-center gap-2 mb-2">
            <Volume2 size={16}/> Soundscape Mixer
            {isDucking && <span className="text-[10px] bg-indigo-500 text-white px-1.5 py-0.5 rounded">Ducking</span>}
        </h3>
        
        <div className="space-y-3">
            <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-wider flex justify-between text-slate-500">
                    <span className="flex items-center gap-1"><Waves size={12}/> Reverb</span>
                    <span>{Math.round(getVolume(reverbVolume) * 100)}%</span>
                </label>
                <input type="range" min="0" max="1" step="0.05" value={reverbVolume} onChange={e => setReverbVolume(parseFloat(e.target.value))} className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-700" />
            </div>
            
            <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-wider flex justify-between text-slate-500">
                    <span className="flex items-center gap-1"><PenTool size={12}/> Writing</span>
                    <span>{Math.round(getVolume(writingVolume) * 100)}%</span>
                </label>
                <input type="range" min="0" max="1" step="0.05" value={writingVolume} onChange={e => setWritingVolume(parseFloat(e.target.value))} className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-700" />
            </div>
            
            <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-wider flex justify-between text-slate-500">
                    <span className="flex items-center gap-1"><BookOpen size={12}/> Noise</span>
                    <span>{Math.round(getVolume(noiseVolume) * 100)}%</span>
                </label>
                <input type="range" min="0" max="1" step="0.05" value={noiseVolume} onChange={e => setNoiseVolume(parseFloat(e.target.value))} className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-700" />
            </div>
        </div>
    </div>
  );
};
