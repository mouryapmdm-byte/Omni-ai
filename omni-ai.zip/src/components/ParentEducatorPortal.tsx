import React, { useState, useEffect } from 'react';
import { auth, db } from '../lib/firebase';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { MultiModelEngagementAnalytics } from './MultiModelEngagementAnalytics';
import { expandAbbreviationsForSpeech, getSyncShareUrl } from '../lib/utils';
import { 
  Users, 
  BookOpen, 
  Send, 
  FileText, 
  Mail, 
  Sparkles, 
  Plus, 
  Check, 
  TrendingUp, 
  AlertTriangle, 
  Heart, 
  Clock, 
  ShieldAlert, 
  Download, 
  RefreshCw, 
  ChevronRight, 
  Calendar,
  Layers,
  ThumbsUp,
  Award,
  Trash2,
  Globe,
  Volume2,
  Square,
  Eye,
  Settings,
  LogOut
} from 'lucide-react';

interface ClassGroup {
  id: string;
  name: string;
  studentCount: number;
  grade: string;
}

interface AssignedTask {
  id: string;
  title: string;
  classId: string;
  type: 'quiz' | 'lesson' | 'research';
  dueDate: string;
  status: 'active' | 'completed';
}

interface StudentPerformance {
  name: string;
  hoursSpent: number;
  completedQuests: number;
  averageMastery: number;
  roadblocks: string[];
  strengths: string[];
}

const CLASS_GROUPS: ClassGroup[] = [
  { id: 'c1', name: 'AP Physics - Period 3', studentCount: 24, grade: 'Grade 11' },
  { id: 'c2', name: 'Honors Calculus - Period 1', studentCount: 18, grade: 'Grade 12' },
  { id: 'c3', name: 'Organic Chemistry - Period 5', studentCount: 22, grade: 'Grade 11' }
];

const INITIAL_ASSIGNMENTS: AssignedTask[] = [
  { id: 'a1', title: 'Quantum Superposition Deep Dive', classId: 'c1', type: 'lesson', dueDate: '2026-07-05', status: 'active' },
  { id: 'a2', title: 'Taylor Series Expansion Drill', classId: 'c2', type: 'quiz', dueDate: '2026-07-03', status: 'active' },
  { id: 'a3', title: 'Sn2 Reaction Speed Benchmark', classId: 'c3', type: 'research', dueDate: '2026-06-29', status: 'completed' }
];

const STUDENT_METRICS: StudentPerformance = {
  name: 'Alex Thorne',
  hoursSpent: 12.4,
  completedQuests: 6,
  averageMastery: 78,
  roadblocks: [
    'Complex plane rotations in Complex Numbers',
    'Friction calculations in Rotational Mechanics',
    'Sn1 substitution reactions speed'
  ],
  strengths: [
    'Matrix & determinant properties',
    'Thermodynamic cycle formulas',
    'Spaced repetition retention consistency'
  ]
};

const CURRICULUM_OPTIONS = [
  {
    id: 'physics',
    name: 'AP Physics Mechanics',
    text: `AP Physics Mechanics Syllabus Outline:
• Vectors & 2D Kinematics: Understanding displacement, velocity vectors, projectile motion, and relative velocity.
• Newton's Laws of Motion: Static and dynamic equilibrium, friction coefficients, and inclined plane solvers.
• Work, Energy, and Power: Conservative forces, potential energy curves, and conservation of mechanical energy.
• Systems of Particles & Linear Momentum: Center of mass calculations, impulse-momentum theorem, and elastic collisions.`
  },
  {
    id: 'cbse_physics',
    name: 'CBSE Class XII Physics Companion',
    text: `CBSE Class XII Physics Core Syllabus:
• Electrostatics & Electric Potential: Gauss's Law applications, electric field lines, potential energy of charge systems.
• Current Electricity: Ohm's Law, resistivity, Kirchhoff's Rules, potentiometer principles, and Wheatstone bridge structures.
• Magnetic Effects of Current: Biot-Savart Law, Ampere's Circuital Law, moving charges in magnetic fields, and cyclotrons.
• Electromagnetic Induction: Faraday's Law of Induction, Lenz's Law, self and mutual inductance, and alternating current (AC) generator mechanisms.`
  },
  {
    id: 'calculus',
    name: 'AP Calculus BC Companion',
    text: `AP Calculus BC Syllabus Checklists:
• Limits and Continuity: Definition of limits, vertical and horizontal asymptotes, squeeze theorem, and intermediate value theorem.
• Derivatives & Integration: Product and quotient rules, chain rule, implicit differentiation, Riemann sums, and fundamental theorem of calculus.
• Infinite Sequences & Series: Taylor and Maclaurin series expansion, convergence tests (ratio, root, integral tests), and radius of convergence.`
  }
];

const ACCESSIBILITY_LANGUAGES = [
  { code: 'es', name: 'Spanish (Español)', flag: '🇪🇸', dialect: 'es-ES' },
  { code: 'fr', name: 'French (Français)', flag: '🇫🇷', dialect: 'fr-FR' },
  { code: 'de', name: 'German (Deutsch)', flag: '🇩🇪', dialect: 'de-DE' },
  { code: 'hi', name: 'Hindi (हिन्दी)', flag: '🇮🇳', dialect: 'hi-IN' },
  { code: 'ja', name: 'Japanese (日本語)', flag: '🇯🇵', dialect: 'ja-JP' },
  { code: 'zh', name: 'Chinese (中文)', flag: '🇨🇳', dialect: 'zh-CN' },
  { code: 'ar', name: 'Arabic (العربية)', flag: '🇸🇦', dialect: 'ar-SA' },
];

export const ParentEducatorPortal: React.FC<{ 
  theme: 'light' | 'dark';
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}> = ({ theme, showNotification }) => {
  const [activeTab, setActiveTab] = useState<'assignor' | 'newsletter' | 'accessibility' | 'analytics'>('assignor');
  
  // Assignor state
  const [assignments, setAssignments] = useState<AssignedTask[]>(INITIAL_ASSIGNMENTS);
  const [newTitle, setNewTitle] = useState<string>('');
  const [selectedClass, setSelectedClass] = useState<string>('c1');
  const [assignmentType, setAssignmentType] = useState<'quiz' | 'lesson' | 'research'>('lesson');
  const [dueDate, setDueDate] = useState<string>('2026-07-10');
  const [broadcasted, setBroadcasted] = useState<boolean>(false);

  // Parent Newsletter state
  const [parentEmail, setParentEmail] = useState<string>('parent.thorne@quantummail.org');
  const [newsletterSent, setNewsletterSent] = useState<boolean>(false);
  const [generatingReport, setGeneratingReport] = useState<boolean>(false);
  const [generatedContent, setGeneratedContent] = useState<string>('');

  // Google Classroom Integration State
  const [classroomToken, setClassroomToken] = useState<string | null>(null);
  const [classroomUser, setClassroomUser] = useState<any | null>(null);
  const [courses, setCourses] = useState<any[]>([]);
  const [selectedCourseId, setSelectedCourseId] = useState<string>('');
  const [isFetchingCourses, setIsFetchingCourses] = useState<boolean>(false);
  const [isDispatching, setIsDispatching] = useState<boolean>(false);
  const [classroomStatus, setClassroomStatus] = useState<string>('');
  const [dispatchToClassroom, setDispatchToClassroom] = useState<boolean>(false);

  // Dual-Language & Accessibility Hub State
  const [selectedCurriculum, setSelectedCurriculum] = useState<string>('physics');
  const [targetLang, setTargetLang] = useState<string>('es');
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [translatedText, setTranslatedText] = useState<string>('');
  const [a11yFont, setA11yFont] = useState<'standard' | 'dyslexic'>('standard');
  const [highContrast, setHighContrast] = useState<boolean>(false);
  const [isReadingAloud, setIsReadingAloud] = useState<boolean>(false);

  // Google Classroom Authenticate handler
  const handleClassroomLogin = async () => {
    setIsFetchingCourses(true);
    setCourses([]);
    setClassroomStatus('Initializing Google Workspace connection...');
    try {
      const provider = new GoogleAuthProvider();
      provider.addScope('https://www.googleapis.com/auth/classroom.courses.readonly');
      provider.addScope('https://www.googleapis.com/auth/classroom.coursework.me');
      provider.addScope('https://www.googleapis.com/auth/classroom.courseworkmaterials');
      
      const result = await signInWithPopup(auth, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setClassroomToken(credential.accessToken);
        setClassroomUser(result.user);
        setClassroomStatus('Connected! Syncing Google Classroom courses...');
        showNotification?.("Successfully authenticated with Google Workspace!", "success");

        // Fetch courses immediately
        const coursesRes = await fetch('https://classroom.googleapis.com/v1/courses', {
          headers: { Authorization: `Bearer ${credential.accessToken}` }
        });
        if (coursesRes.ok) {
          const data = await coursesRes.json();
          const coursesList = data.courses || [];
          setCourses(coursesList);
          if (coursesList.length > 0) {
            setSelectedCourseId(coursesList[0].id);
            setDispatchToClassroom(true);
            setClassroomStatus(`Synced with ${coursesList.length} Classroom courses.`);
          } else {
            setClassroomStatus('Authenticated, but no Google Classroom courses were found.');
          }
        } else {
          const errText = await coursesRes.text();
          console.error('Failed to fetch courses:', errText);
          setClassroomStatus('Authenticated, but failed to load courses. Check teacher status.');
        }
      } else {
        throw new Error("Could not fetch Google API Access Token.");
      }
    } catch (error: any) {
      console.error('Classroom login failed:', error);
      setClassroomStatus(`Connection failed: ${error.message || 'Auth popup closed'}`);
      showNotification?.("Authentication failed or was cancelled.", "error");
    } finally {
      setIsFetchingCourses(false);
    }
  };

  const handleClassroomLogout = () => {
    setClassroomToken(null);
    setClassroomUser(null);
    setCourses([]);
    setSelectedCourseId('');
    setClassroomStatus('');
    setDispatchToClassroom(false);
    showNotification?.("Disconnected from Google Classroom.", "info");
  };

  // Dynamic syllabus translator handler using server-side Gemini endpoint
  const handleTranslateCurriculum = async () => {
    setIsTranslating(true);
    setTranslatedText('');
    const curriculumObj = CURRICULUM_OPTIONS.find(c => c.id === selectedCurriculum);
    const targetLangObj = ACCESSIBILITY_LANGUAGES.find(l => l.code === targetLang);
    if (!curriculumObj || !targetLangObj) return;

    try {
      const response = await fetch('/api/translate-curriculum', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: curriculumObj.text,
          targetLanguage: targetLangObj.name
        })
      });

      if (response.ok) {
        const data = await response.json();
        setTranslatedText(data.translated || '');
        showNotification?.(`Translated syllabus standard into ${targetLangObj.name}!`, "success");
      } else {
        showNotification?.("Dynamic Translation failed. Using standard multilingual simulation.", "warning");
        // Fallback simulation text
        setTranslatedText(`[Bilingual Companion - ${targetLangObj.name}]\n\nAdaptación del plan de estudios:\n\n• ${curriculumObj.text.replace(/•/g, '').split('\n').filter(Boolean).join('\n• ')}`);
      }
    } catch (error) {
      console.error('Translation error:', error);
      showNotification?.("Connection failed. Utilizing offline localized fallback.", "warning");
    } finally {
      setIsTranslating(false);
    }
  };

  // Read Aloud Speech Synthesizer
  const handleReadAloud = () => {
    if ('speechSynthesis' in window) {
      if (isReadingAloud) {
        window.speechSynthesis.cancel();
        setIsReadingAloud(false);
        return;
      }
      const textToSpeak = translatedText || CURRICULUM_OPTIONS.find(c => c.id === selectedCurriculum)?.text || '';
      const cleanText = textToSpeak.replace(/[•\*]/g, '');
      const utterance = new SpeechSynthesisUtterance(expandAbbreviationsForSpeech(cleanText));
      
      const targetLangObj = ACCESSIBILITY_LANGUAGES.find(l => l.code === targetLang);
      if (targetLangObj) {
        utterance.lang = targetLangObj.dialect;
        const voices = window.speechSynthesis.getVoices();
        const matchingVoice = voices.find(v => v.lang.startsWith(targetLangObj.code));
        if (matchingVoice) {
          utterance.voice = matchingVoice;
        }
      }
      
      utterance.onend = () => {
        setIsReadingAloud(false);
      };
      utterance.onerror = () => {
        setIsReadingAloud(false);
      };
      
      setIsReadingAloud(true);
      window.speechSynthesis.speak(utterance);
    } else {
      showNotification?.("Text-to-Speech is not supported in this browser.", "warning");
    }
  };

  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Trigger simulated parent report generation
  const handleGenerateReport = () => {
    setGeneratingReport(true);
    setTimeout(() => {
      const markdownNewsletter = `Weekly Student Progress Report - Alex Thorne
      
Dear Parent/Educator,

Here is your smart diagnostic digest regarding Alex Thorne's academic learning trajectory for the week ending June 30, 2026.

📊 COGNITIVE FOCUS METRICS:
• Weekly Study Time: 12.4 hours (Increase of 14% over last week)
• Quests Accomplished: 6 story milestones cleared
• Average Synaptic Mastery: 78% proficiency

🌟 ACADEMIC HIGHLIGHTS & STRENGTHS:
Alex showed exemplary performance in spatial-logical operations:
1. Matrix & determinant properties (92% mastery)
2. Thermodynamic cycle formulas (82% mastery)
3. Spaced repetition retention consistency (Average recall interval expanded to 14 days)

⚠️ ROADBLOCKS & CRITICAL KNOWLEDGE GAPS:
Our diagnostic heatmap engines identified three active learning barriers:
1. Complex plane rotations in Complex Numbers (35% mastery) - Retrying drills with high latency (12.8s response lag)
2. Friction coefficients in Rotational Mechanics (28% mastery) - Undergoes cognitive saturation
3. Sn1 nucleophilic substitution reaction kinetics (31% mastery)

💡 TAILORED PARENTAL OFFLINE SUPPORT ADVICE:
• Physics Support: Ask Alex to explain the difference between static and kinetic friction using a real-world object like a book sliding on a table (Feynman technique).
• Mathematics Spacing: Challenge Alex to sketch complex coordinates on grid paper during dinner. 10 minutes of active visualization will clear the complex number roadblock.
• Rest Intervals: Encourage a 20-minute cognitive break after heavy chemistry solver sessions to allow synaptic stabilization.

Sincerely,
Omni AI Learning Engine Support`;

      setGeneratedContent(markdownNewsletter);
      setGeneratingReport(false);
    }, 1200);
  };

  // Broadcast assignment & Google Classroom coursework Dispatcher
  const handleBroadcastAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const localId = 'a-' + Math.random().toString(36).slice(2, 6);
    let taskTitle = newTitle;

    if (dispatchToClassroom && classroomToken && selectedCourseId) {
      setIsDispatching(true);
      try {
        const baseOrigin = getSyncShareUrl().replace(/\/$/, '');
        const quizLink = `${baseOrigin}/?launchTask=quiz&title=${encodeURIComponent(newTitle)}`;
        const whiteboardLink = `${baseOrigin}/?launchTask=whiteboard&title=${encodeURIComponent(newTitle)}`;
        
        const body = {
          title: newTitle,
          description: `Omni AI Tutor Classroom Assignment!\n\nSubject: ${assignmentType.toUpperCase()}\nDue Date: ${dueDate}\n\nStudents can launch their customized board diagrams and quizzes directly in the Omni AI Sandbox below.\n\n📚 Interactive Whiteboard Board Diagram:\n${whiteboardLink}\n\n❓ Interactive Quiz Link:\n${quizLink}\n\nGood luck!`,
          materials: [
            {
              link: {
                url: quizLink,
                title: `❓ Interactive Quiz Solver: ${newTitle}`
              }
            },
            {
              link: {
                url: whiteboardLink,
                title: `📚 Interactive Whiteboard Board Diagram: ${newTitle}`
              }
            }
          ],
          workType: 'ASSIGNMENT',
          state: 'PUBLISHED',
          dueDate: dueDate ? {
            year: parseInt(dueDate.split('-')[0]),
            month: parseInt(dueDate.split('-')[1]),
            day: parseInt(dueDate.split('-')[2])
          } : undefined
        };

        const res = await fetch(`https://classroom.googleapis.com/v1/courses/${selectedCourseId}/courseWork`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${classroomToken}`
          },
          body: JSON.stringify(body)
        });

        if (res.ok) {
          taskTitle = `[Google Classroom] ${newTitle}`;
          showNotification?.("Dispatched homework assignment to Google Classroom successfully!", "success");
        } else {
          const errText = await res.text();
          console.error('Google Classroom coursework creation failed:', errText);
          showNotification?.("Failed to dispatch to Google Classroom, but recorded locally.", "warning");
        }
      } catch (err) {
        console.error('Error dispatching to Google Classroom:', err);
        showNotification?.("Error connecting to Google Classroom API.", "warning");
      } finally {
        setIsDispatching(false);
      }
    }

    const newTask: AssignedTask = {
      id: localId,
      title: taskTitle,
      classId: dispatchToClassroom && selectedCourseId ? selectedCourseId : selectedClass,
      type: assignmentType,
      dueDate: dueDate,
      status: 'active'
    };

    setAssignments(prev => [newTask, ...prev]);
    setNewTitle('');
    setBroadcasted(true);
    setTimeout(() => setBroadcasted(false), 2500);
  };

  const handleDeleteAssignment = (id: string) => {
    setAssignments(prev => prev.filter(a => a.id !== id));
  };

  return (
    <div id="parent-portal-root" className="flex flex-col h-full overflow-y-auto pr-1">
      
      {/* Navigation tabs */}
      <div id="portal-tab-header" className="flex gap-2 p-1.5 bg-slate-100 dark:bg-slate-900 rounded-2xl mb-4 border border-slate-200 dark:border-slate-800">
        <button
          id="tab-educator-assignor"
          onClick={() => setActiveTab('assignor')}
          className={`flex-1 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
            activeTab === 'assignor'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-850'
          }`}
        >
          <Users size={13} />
          Educator Assignor Panel
        </button>
        <button
          id="tab-parent-newsletter"
          onClick={() => setActiveTab('newsletter')}
          className={`flex-1 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
            activeTab === 'newsletter'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-850'
          }`}
        >
          <Mail size={13} />
          Smart Diagnostic Newsletters
        </button>
        <button
          id="tab-accessibility-hub"
          onClick={() => setActiveTab('accessibility')}
          className={`flex-1 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
            activeTab === 'accessibility'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-850'
          }`}
        >
          <Globe size={13} />
          Dual-Language & Accessibility
        </button>
        <button
          id="tab-engagement-analytics"
          onClick={() => setActiveTab('analytics')}
          className={`flex-1 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
            activeTab === 'analytics'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-slate-850'
          }`}
        >
          <TrendingUp size={13} />
          Multi-Model Analytics
        </button>
      </div>

      {activeTab === 'assignor' ? (
        /* Educator Assignor Workspace */
        <div id="assignor-workspace" className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in fade-in duration-200">
          
          {/* Create Assignment Form (Col 5) */}
          <div className="lg:col-span-5 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col justify-between gap-4">
            <form onSubmit={handleBroadcastAssignment} className="flex flex-col gap-3 text-xs">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-indigo-500 flex items-center gap-1.5 mb-1">
                  <BookOpen size={14} /> Broadcast Custom Assignment
                </h3>
                <p className="text-[10px] text-slate-500">Push personalized, targeted curriculum tasks straight to student feeds.</p>
              </div>

              <div>
                <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Task Title / Chapter Objective</label>
                <input
                  id="assign-title-input"
                  type="text"
                  required
                  placeholder="e.g. Schrödinger Wave Packet Solver Challenge"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2.5 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold dark:text-white outline-none focus:border-indigo-500"
                />
              </div>

              {/* Classroom Dropdowns & Auth */}
              <div className="p-3 bg-white dark:bg-slate-850 rounded-xl border border-indigo-500/10 dark:border-indigo-500/20 flex flex-col gap-2">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black uppercase tracking-wider text-indigo-500 flex items-center gap-1">
                    <Globe size={11} /> Google Classroom Sync
                  </span>
                  {classroomToken ? (
                    <button
                      type="button"
                      onClick={handleClassroomLogout}
                      className="text-[9px] font-black text-red-500 uppercase tracking-wider flex items-center gap-0.5 hover:underline cursor-pointer"
                    >
                      <LogOut size={10} /> Disconnect
                    </button>
                  ) : (
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">OFFLINE</span>
                  )}
                </div>

                {!classroomToken ? (
                  <div className="flex flex-col gap-1.5 py-1">
                    <p className="text-[9px] text-slate-400 leading-normal">
                      Connect your Google Classroom to immediately dispatch synthesized board diagrams and quiz links as official coursework assignments.
                    </p>
                    <button
                      type="button"
                      onClick={handleClassroomLogin}
                      disabled={isFetchingCourses}
                      className="py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer transition-all"
                    >
                      {isFetchingCourses ? (
                        <RefreshCw size={11} className="animate-spin" />
                      ) : (
                        <Globe size={11} />
                      )}
                      {isFetchingCourses ? "Connecting Google..." : "Connect Google Classroom"}
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-2 pt-1 text-[10px]">
                    <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      <span className="text-slate-500">Connected as:</span>
                      <strong className="text-slate-800 dark:text-slate-200 truncate max-w-[150px]">{classroomUser?.email}</strong>
                    </div>

                    {courses.length > 0 ? (
                      <div>
                        <label className="block text-[8px] font-black uppercase text-slate-400 mb-1">Select Google Classroom Course</label>
                        <select
                          value={selectedCourseId}
                          onChange={(e) => setSelectedCourseId(e.target.value)}
                          className="w-full p-2 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 text-[10px] font-bold dark:text-white outline-none cursor-pointer focus:border-indigo-500"
                        >
                          {courses.map(course => (
                            <option key={course.id} value={course.id}>{course.name} ({course.section || 'General'})</option>
                          ))}
                        </select>
                      </div>
                    ) : (
                      <span className="text-[9px] text-amber-500 font-bold block">No courses found on this Classroom teacher account.</span>
                    )}

                    <div className="flex items-center gap-1.5 mt-1.5">
                      <input
                        type="checkbox"
                        id="dispatch-classroom-check"
                        checked={dispatchToClassroom}
                        onChange={(e) => setDispatchToClassroom(e.target.checked)}
                        className="w-3.5 h-3.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                      />
                      <label htmlFor="dispatch-classroom-check" className="text-[10px] font-bold text-slate-600 dark:text-slate-300 cursor-pointer">
                        Immediately Dispatch to Classroom stream
                      </label>
                    </div>
                  </div>
                )}
              </div>

              {!dispatchToClassroom && (
                <div>
                  <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Target Class Group</label>
                  <select
                    id="assign-class-select"
                    value={selectedClass}
                    onChange={(e) => setSelectedClass(e.target.value)}
                    className="w-full p-2.5 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold dark:text-white outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    {CLASS_GROUPS.map(cg => (
                      <option key={cg.id} value={cg.id}>{cg.name} ({cg.studentCount} students)</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Activity Genre</label>
                  <select
                    id="assign-type-select"
                    value={assignmentType}
                    onChange={(e) => setAssignmentType(e.target.value as any)}
                    className="w-full p-2.5 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold dark:text-white outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="lesson">Lecture Lesson Track</option>
                    <option value="quiz">Interactive Quiz Review</option>
                    <option value="research">Research Sandbox Lab</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Required Due Date</label>
                  <input
                    id="assign-due-input"
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-850 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-bold dark:text-white outline-none focus:border-indigo-500 cursor-pointer"
                  />
                </div>
              </div>

              {broadcasted && (
                <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 rounded-lg text-[10px] font-bold text-center flex items-center justify-center gap-1">
                  <Check size={11} /> Task Broadcasted successfully!
                </div>
              )}

              <button
                id="btn-broadcast-assign"
                type="submit"
                disabled={isDispatching}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-all mt-1"
              >
                {isDispatching ? (
                  <RefreshCw size={12} className="animate-spin" />
                ) : (
                  <Send size={12} />
                )}
                {isDispatching ? "Dispatching To Classroom..." : "Broadcast To Student Feeds"}
              </button>
            </form>

            {classroomStatus && (
              <div className="p-2.5 bg-indigo-500/5 border border-indigo-500/10 text-indigo-500 rounded-xl text-[9px] font-bold flex items-center gap-1.5">
                <Globe size={12} className="shrink-0" />
                <span>{classroomStatus}</span>
              </div>
            )}
          </div>

          {/* Current Broadcasted Tasks & Rosters (Col 7) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            
            {/* Active Class Assignment Feed */}
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-3">
                <Layers size={14} className="text-indigo-500" /> Current Class Tasks Feed
              </h3>

              <div id="broadcast-tasks-list" className="flex flex-col gap-2.5 max-h-[280px] overflow-y-auto pr-1">
                {assignments.map(asg => {
                  const targetClass = CLASS_GROUPS.find(cg => cg.id === asg.classId);
                  const isClassroom = asg.title.includes('[Google Classroom]');
                  
                  return (
                    <div
                      id={`asg-card-${asg.id}`}
                      key={asg.id}
                      className="p-3 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm ${
                          asg.type === 'quiz' ? 'bg-amber-100 text-amber-500' :
                          asg.type === 'lesson' ? 'bg-indigo-100 text-indigo-500' :
                          'bg-emerald-100 text-emerald-500'
                        }`}>
                          {asg.type === 'quiz' ? '❓' : asg.type === 'lesson' ? '📖' : '🔬'}
                        </span>

                        <div>
                          <h4 className="font-bold text-slate-850 dark:text-slate-100 flex items-center gap-1">
                            {asg.title}
                            {isClassroom && (
                              <span className="text-[8px] bg-emerald-500/10 text-emerald-500 px-1 py-0.5 rounded font-black uppercase tracking-widest">GOOGLE</span>
                            )}
                          </h4>
                          <span className="text-[9px] text-slate-400 font-extrabold uppercase block mt-0.5">
                            Class: {isClassroom ? 'Google Classroom' : (targetClass?.name || 'All')} • Type: {asg.type}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">DUE DATE</span>
                          <span className="font-mono text-[10px] text-slate-600 dark:text-slate-300 font-bold">{asg.dueDate}</span>
                        </div>

                        <button
                          id={`btn-delete-asg-${asg.id}`}
                          onClick={() => handleDeleteAssignment(asg.id)}
                          className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-lg cursor-pointer"
                          title="Remove Assignment"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Class Analytics mini panel */}
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2.5">
                <TrendingUp size={14} className="text-indigo-500" /> Educator Quick Stats
              </h3>
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl text-center">
                  <span className="text-lg font-black font-mono text-indigo-500">3 Active</span>
                  <span className="text-[9px] font-black text-slate-400 block uppercase mt-0.5">CLASSES</span>
                </div>
                <div className="p-3 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl text-center">
                  <span className="text-lg font-black font-mono text-indigo-500">64 Total</span>
                  <span className="text-[9px] font-black text-slate-400 block uppercase mt-0.5">STUDENTS</span>
                </div>
                <div className="p-3 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl text-center">
                  <span className="text-lg font-black font-mono text-indigo-500">89%</span>
                  <span className="text-[9px] font-black text-slate-400 block uppercase mt-0.5">COMPLETION</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      ) : activeTab === 'newsletter' ? (
        /* Automated Diagnostic Newsletters */
        <div id="newsletter-workspace" className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in fade-in duration-200">
          
          {/* Settings and Trigger sidebar (Col 5) */}
          <div className="lg:col-span-5 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
            <div className="flex flex-col gap-3.5 text-xs">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-1">
                  <Mail size={14} /> Send Smart Progress Digest
                </h3>
                <p className="text-[10px] text-slate-500">Delivers an AI-compiled overview regarding learning velocity, roadblocks, and tailored tips straight to parent inboxes.</p>
              </div>

              <div>
                <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Select Student Target</label>
                <div className="p-3 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between">
                  <span className="font-bold text-slate-800 dark:text-slate-100">{STUDENT_METRICS.name}</span>
                  <span className="text-[10px] bg-indigo-500/10 text-indigo-500 px-2 py-0.5 rounded font-black uppercase tracking-widest">Active student</span>
                </div>
              </div>

              <div>
                <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Recipient Parent / Educator Email</label>
                <input
                  id="newsletter-recipient-input"
                  type="email"
                  required
                  placeholder="parent.thorne@quantummail.org"
                  value={parentEmail}
                  onChange={(e) => setParentEmail(e.target.value)}
                  className="w-full p-2.5 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold dark:text-white outline-none focus:border-indigo-500"
                />
              </div>

              <div className="border-t border-slate-150 dark:border-slate-800 pt-3 flex flex-col gap-2">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">DIAGNOSTIC SNAPSHOT</span>
                
                <div className="grid grid-cols-2 gap-2 text-[10px] font-bold text-slate-500">
                  <div className="flex items-center gap-1.5 p-1.5 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-lg">
                    <Clock size={11} className="text-slate-400" />
                    <span>Time: <strong className="font-mono text-indigo-500">{STUDENT_METRICS.hoursSpent}h</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 p-1.5 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-lg">
                    <Award size={11} className="text-slate-400" />
                    <span>Average: <strong className="font-mono text-indigo-500">{STUDENT_METRICS.averageMastery}%</strong></span>
                  </div>
                </div>
              </div>

              {newsletterSent && (
                <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 rounded-lg text-[10px] font-bold text-center flex items-center justify-center gap-1">
                  <Check size={11} /> Smart Report Newsletter Transmitted!
                </div>
              )}

              <button
                id="btn-trigger-report-generation"
                onClick={handleGenerateReport}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-all mt-2"
              >
                <Sparkles size={12} className="animate-pulse" /> AI Generate Weekly Newsletter
              </button>
            </div>
          </div>

          {/* Generated Newsletter Preview Screen (Col 7) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex-1 flex flex-col">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <FileText size={14} className="text-indigo-500" /> Newsletter Preview
                </h3>

                {generatedContent && (
                  <button
                    id="btn-transmit-newsletter"
                    onClick={() => {
                      setNewsletterSent(true);
                      setTimeout(() => setNewsletterSent(false), 2500);
                    }}
                    className="px-2.5 py-1 bg-indigo-500/15 hover:bg-indigo-500/20 text-indigo-500 border border-indigo-500/20 rounded-lg font-black text-[9px] uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all"
                  >
                    <Send size={11} /> Transmit Report
                  </button>
                )}
              </div>

              {!generatedContent ? (
                <div className="flex-1 p-6 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl text-center flex flex-col items-center justify-center min-h-[300px]">
                  <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-950/40 text-indigo-500 rounded-full flex items-center justify-center mb-2.5">
                    <Sparkles size={20} />
                  </div>
                  <h4 className="text-xs font-bold text-slate-850 dark:text-slate-100 mb-1">Diagnostic Report is Empty</h4>
                  <p className="text-[10px] text-slate-500 max-w-xs leading-relaxed mb-4">
                    Click the "AI Generate Weekly Newsletter" button to run cognitive spacing analysis calculations and render support strategies.
                  </p>
                </div>
              ) : (
                <div className="flex-1 p-4 bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl relative overflow-hidden flex flex-col max-h-[440px]">
                  <div className="absolute top-2 right-2 text-[8px] font-black uppercase tracking-widest text-slate-400 bg-slate-100 dark:bg-slate-900 px-1.5 py-0.5 rounded">
                    SMTP DIGEST PREVIEW
                  </div>

                  <div className="flex-1 overflow-y-auto pr-1">
                    <pre className="font-sans text-[11px] leading-relaxed text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                      {generatedContent}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>
      ) : activeTab === 'accessibility' ? (
        /* Dual-Language & Accessibility Hub */
        <div id="accessibility-hub-workspace" className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in fade-in duration-200">
          
          {/* Controls Panel (Col 4) */}
          <div className="lg:col-span-4 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col gap-4 text-xs">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-indigo-500 flex items-center gap-1.5 mb-1">
                <Globe size={14} /> Multi-Lingual Adaptation
              </h3>
              <p className="text-[10px] text-slate-500">Dynamically adapt, localize, and translate standardized textbook curricula for bilingual, ESL, and international rosters.</p>
            </div>

            <div>
              <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Select Curriculum Standard</label>
              <select
                value={selectedCurriculum}
                onChange={(e) => {
                  setSelectedCurriculum(e.target.value);
                  setTranslatedText('');
                }}
                className="w-full p-2.5 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold dark:text-white outline-none cursor-pointer focus:border-indigo-500"
              >
                {CURRICULUM_OPTIONS.map(opt => (
                  <option key={opt.id} value={opt.id}>{opt.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-black uppercase text-slate-400 mb-1">Target Language Adaptation</label>
              <select
                value={targetLang}
                onChange={(e) => {
                  setTargetLang(e.target.value);
                  setTranslatedText('');
                }}
                className="w-full p-2.5 bg-white dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold dark:text-white outline-none cursor-pointer focus:border-indigo-500"
              >
                {ACCESSIBILITY_LANGUAGES.map(lang => (
                  <option key={lang.code} value={lang.code}>{lang.flag} {lang.name}</option>
                ))}
              </select>
            </div>

            {/* Accessibility Customization Settings */}
            <div className="border-t border-slate-200 dark:border-slate-800 pt-3 flex flex-col gap-3">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block flex items-center gap-1">
                <Settings size={11} /> Cognitive Accessibility Profile
              </span>

              {/* Font Dyslexia Profile */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-[10px] block text-slate-700 dark:text-slate-300">Dyslexic-Friendly Alignment</span>
                  <span className="text-[9px] text-slate-400 block leading-tight">Increases character tracking and letter spacing.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setA11yFont(prev => prev === 'standard' ? 'dyslexic' : 'standard')}
                  className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-wider cursor-pointer border transition-all ${
                    a11yFont === 'dyslexic'
                      ? 'bg-indigo-600 border-indigo-600 text-white'
                      : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  {a11yFont === 'dyslexic' ? 'ON' : 'OFF'}
                </button>
              </div>

              {/* High Contrast Monochrome */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-[10px] block text-slate-700 dark:text-slate-300">High-Contrast Monochrome</span>
                  <span className="text-[9px] text-slate-400 block leading-tight">Swaps colors to full high-contrast monochrome.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setHighContrast(prev => !prev)}
                  className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-wider cursor-pointer border transition-all ${
                    highContrast
                      ? 'bg-indigo-600 border-indigo-600 text-white'
                      : 'bg-white dark:bg-slate-850 border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  {highContrast ? 'ON' : 'OFF'}
                </button>
              </div>

              {/* Speech Synthesis Voice adaptation */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-[10px] block text-slate-700 dark:text-slate-300">Regional Voice Synthesizer</span>
                  <span className="text-[9px] text-slate-400 block leading-tight">Read translated content aloud with proper accent.</span>
                </div>
                <button
                  type="button"
                  onClick={handleReadAloud}
                  disabled={isTranslating}
                  className={`p-2 rounded-xl flex items-center justify-center gap-1 cursor-pointer border transition-all ${
                    isReadingAloud
                      ? 'bg-red-500 border-red-500 text-white animate-pulse'
                      : 'bg-slate-100 dark:bg-slate-800 border-transparent text-slate-600 dark:text-slate-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 hover:text-indigo-500'
                  }`}
                  title={isReadingAloud ? "Stop Speech" : "Play Speech"}
                >
                  {isReadingAloud ? (
                    <>
                      <Square size={12} />
                      <span className="text-[9px] font-black uppercase tracking-wider">Stop</span>
                    </>
                  ) : (
                    <>
                      <Volume2 size={12} />
                      <span className="text-[9px] font-black uppercase tracking-wider">Speak</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <button
              onClick={handleTranslateCurriculum}
              disabled={isTranslating}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-all mt-auto"
            >
              {isTranslating ? (
                <RefreshCw size={12} className="animate-spin" />
              ) : (
                <Sparkles size={12} />
              )}
              {isTranslating ? "Translating Curriculum..." : "AI Translate Curriculum Pack"}
            </button>
          </div>

          {/* Bilingual Syllabus split comparison panels (Col 8) */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex-1 flex flex-col justify-between">
              
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <FileText size={14} className="text-indigo-500" /> Bilingual Curriculum Comparison Stream
                </h3>
                <span className="text-[8px] font-black bg-indigo-500/15 text-indigo-500 px-2 py-0.5 rounded uppercase tracking-widest flex items-center gap-1">
                  <Eye size={10} /> Dynamic A11y Lens active
                </span>
              </div>

              {/* Split screen content display */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
                
                {/* Left Panel: English Standard */}
                <div className={`p-3.5 bg-white dark:bg-slate-850 rounded-xl border border-slate-150 dark:border-slate-800 max-h-[340px] overflow-y-auto flex flex-col ${
                  highContrast ? 'border-2 border-black dark:border-white bg-white text-black dark:bg-black dark:text-white' : ''
                }`}>
                  <div className="border-b border-slate-100 dark:border-slate-800 pb-1.5 mb-2 flex justify-between items-center">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">🇺🇸 Standard English (Original)</span>
                  </div>
                  <pre className={`whitespace-pre-wrap font-sans text-[11px] leading-relaxed text-slate-700 dark:text-slate-300 ${
                    a11yFont === 'dyslexic' ? 'tracking-[0.14em] leading-[2] font-mono' : ''
                  } ${highContrast ? '!text-black dark:!text-white font-black' : ''}`}>
                    {CURRICULUM_OPTIONS.find(c => c.id === selectedCurriculum)?.text}
                  </pre>
                </div>

                {/* Right Panel: Translated Adaptation */}
                <div className={`p-3.5 bg-white dark:bg-slate-850 rounded-xl border max-h-[340px] overflow-y-auto flex flex-col transition-all duration-200 ${
                  isTranslating ? 'border-dashed border-indigo-400' : 'border-slate-150 dark:border-slate-800'
                } ${
                  highContrast ? 'border-2 border-black dark:border-white bg-white text-black dark:bg-black dark:text-white' : ''
                }`}>
                  <div className="border-b border-slate-100 dark:border-slate-800 pb-1.5 mb-2 flex justify-between items-center">
                    <span className="text-[9px] font-black text-indigo-500 dark:text-indigo-400 uppercase tracking-widest flex items-center gap-1">
                      <span>{ACCESSIBILITY_LANGUAGES.find(l => l.code === targetLang)?.flag}</span>
                      <span>{ACCESSIBILITY_LANGUAGES.find(l => l.code === targetLang)?.name} Adaptation</span>
                    </span>
                  </div>

                  {isTranslating ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-12">
                      <RefreshCw size={24} className="text-indigo-500 animate-spin mb-2" />
                      <span className="text-[10px] font-bold text-slate-400">Synthesizing translations with Omni AI API...</span>
                    </div>
                  ) : !translatedText ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-12 text-center">
                      <div className="w-8 h-8 rounded-full bg-indigo-50 dark:bg-indigo-950/20 text-indigo-500 flex items-center justify-center mb-2">
                        <Globe size={16} />
                      </div>
                      <span className="text-[10px] font-bold text-slate-500 max-w-[200px] leading-normal block">
                        Select a target language and click "AI Translate Curriculum Pack" to generate a localized translation.
                      </span>
                    </div>
                  ) : (
                    <pre className={`whitespace-pre-wrap font-sans text-[11px] leading-relaxed text-slate-700 dark:text-slate-300 ${
                      a11yFont === 'dyslexic' ? 'tracking-[0.14em] leading-[2] font-mono' : ''
                    } ${highContrast ? '!text-black dark:!text-white font-black' : ''}`}>
                      {translatedText}
                    </pre>
                  )}
                </div>

              </div>

              {/* Explanatory summary footer */}
              <div className="mt-3 p-2 bg-indigo-500/5 border border-indigo-500/10 rounded-xl text-[10px] text-slate-500 leading-normal flex items-start gap-1.5">
                <Sparkles size={13} className="text-indigo-500 mt-0.5 shrink-0" />
                <span>
                  <strong>A11y Adaptive Delivery:</strong> Handing over bilingual guides, adjusting visual contrast parameters, and introducing dyslexic spacing directly ensures equitable mastery across classroom boundaries.
                </span>
              </div>

            </div>
          </div>

        </div>
      ) : (
        /* Multi-Model Engagement Analytics Workspace */
        <div id="analytics-suite-workspace" className="animate-in fade-in duration-200">
          <MultiModelEngagementAnalytics theme={theme} showNotification={showNotification} />
        </div>
      )}

    </div>
  );
};
