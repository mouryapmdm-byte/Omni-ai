import { SupportedLanguageCode, BilingualSegment } from './types';
import { SUPPORTED_LANGUAGES } from './i18nConfig';
import { CulturalAdaptation } from './CulturalAdaptation';

export class TranslationService {
  /**
   * Pre-packaged pedagogical scientific glossaries with preserved formulas
   */
  private static readonly SAMPLE_LESSONS: Record<string, Record<SupportedLanguageCode, BilingualSegment>> = {
    newtons_second_law: {
      en: {
        id: 'n2l_en',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "Newton's Second Law of Motion",
        pronunciation: "Newton's Second Law",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        culturalAnalogy: "Just like it is easy to accelerate a lightweight bicycle, but requires immense force to push a heavy truck.",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      hi: {
        id: 'n2l_hi',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "न्यूटन का गति का दूसरा नियम (Newton's Second Law)",
        pronunciation: "Newton ka gati ka doosra niyam",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "किसी वस्तु का त्वरण (Acceleration) उस पर लगने वाले कुल बल (Force) के समानुपाती और उसके द्रव्यमान (Mass) के व्युत्क्रमानुपाती होता है।",
        culturalAnalogy: "जैसे एक हल्की साइकिल को तेज चलाना आसान है, लेकिन भारी भरी हुई बैलगाड़ी या ट्रक को गति देने के लिए बहुत ज्यादा बल लगाना पड़ता है।",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      ta: {
        id: 'n2l_ta',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "நியூட்டனின் இரண்டாம் இயக்க விதி (Newton's Second Law)",
        pronunciation: "Newton-in irandaam iyakka vidhi",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "ஒரு பொருளின் முடுக்கம் (Acceleration) அதன் மீது செயல்படும் நிகர விசைக்கு (Force) நேர்விகிதத்திலும், அதன் நிறைக்கு (Mass) எதிர்விகிதத்திலும் இருக்கும்.",
        culturalAnalogy: "ஒரு இலகுவான மிதிவண்டியை எளிதில் முடுக்கிவிடலாம், ஆனால் கனமான மாட்டுவண்டியை நகர்த்த அதிக விசை தேவைப்படுகிறது.",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      te: {
        id: 'n2l_te',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "న్యూటన్ రెండవ గమన నియమం (Newton's Second Law)",
        pronunciation: "Newton rendava gamana niyamam",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "వస్తువు యొక్క త్వరణం (Acceleration) దానిపై పనిచేసే ఫలిత బలానికి (Force) అనులోమానుపాతంలోను, దాని ద్రవ్యరాశికి (Mass) విలోమానుపాతంలోను ఉంటుంది.",
        culturalAnalogy: "తేలికపాటి సైకిల్‌ను త్వరగా ముందుకు నడపడం సులభం, కానీ భారీ ఎడ్లబండిని కదిలించడానికి ఎక్కువ బలం అవసరం.",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      bn: {
        id: 'n2l_bn',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "নিউটনের দ্বিতীয় গতিসূত্র (Newton's Second Law)",
        pronunciation: "Newton-er dwitiyo gotisutra",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "কোনো বস্তুর ত্বরণ (Acceleration) তার উপর প্রযুক্ত মোট বলের (Force) সমানুপাতিক এবং তার ভরের (Mass) ব্যস্তানুপাতিক।",
        culturalAnalogy: "একটি হালকা সাইকেল চালানো সহজ, কিন্তু একটি ভারী গরুর গাড়ি টানতে অনেক বেশি বল প্রয়োগ করতে হয়।",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      mr: {
        id: 'n2l_mr',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "न्यूटनचा गतीविषयक दुसरा नियम (Newton's Second Law)",
        pronunciation: "Newton-cha gativishayak doosra niyam",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "एखाद्या वस्तूचे त्वरण (Acceleration) त्यावर प्रयुक्त होणाऱ्या निव्वळ बलाच्या (Force) सम प्रमाणात आणि वस्तुमानाच्या (Mass) व्यस्त प्रमाणात असते.",
        culturalAnalogy: "हलकी सायकल चालवणे सोपे असते, परंतु जड बैलगाडी किंवा ट्रॅक्टर ओढण्यासाठी जास्त ताकद लावावी लागते.",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      kn: {
        id: 'n2l_kn',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "ನ್ಯೂಟನ್‌ನ ಎರಡನೇ ಚಲನೆಯ ನಿಯಮ (Newton's Second Law)",
        pronunciation: "Newton-na eradane chalaneya niyama",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "ವಸ್ತುವಿನ ವೇಗೋತ್ಕರ್ಷವು (Acceleration) ಅದರ ಮೇಲೆ ವರ್ತಿಸುವ ನಿವ್ವಳ ಬಲಕ್ಕೆ (Force) ನೇರ ಅನುಪಾತದಲ್ಲಿ ಮತ್ತು ರಾಶಿಗೆ (Mass) ವಿಲೋಮ ಅನುಪಾತದಲ್ಲಿರುತ್ತದೆ.",
        culturalAnalogy: "ಹಗುರವಾದ ಸೈಕಲ್ ಅನ್ನು ಚಲಿಸುವುದು ಸುಲಭ, ಆದರೆ ಭಾರವಾದ ಎತ್ತಿನ ಬಂಡಿಯನ್ನು ಎಳೆಯಲು ಹೆಚ್ಚಿನ ಬಲ ಬೇಕಾಗುತ್ತದೆ.",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      ml: {
        id: 'n2l_ml',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "ന്യൂട്ടന്റെ രണ്ടാം ചലനനിയമം (Newton's Second Law)",
        pronunciation: "Newton-te randaam chalana niyamam",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "ഒരു വസ്തുവിന്റെ ത്വരണം (Acceleration) അതിൽ പ്രയോഗിക്കുന്ന ആകെ ബലത്തിന് (Force) നേർ അനുപാതത്തിലും അതിന്റെ മാസിന് (Mass) വിപരീത അനുപാതത്തിലും ആയിരിക്കും.",
        culturalAnalogy: "ഭാരം കുറഞ്ഞ സൈക്കിൾ വേഗത്തിൽ ഓടിക്കാൻ എളുപ്പമാണ്, എന്നാൽ ഭാരമുള്ള കാളവണ്ടി നീക്കാൻ കൂടുതൽ ബലം ആവശ്യമാണ്.",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      gu: {
        id: 'n2l_gu',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "ન્યૂટનનો ગતિનો બીજો નિયમ (Newton's Second Law)",
        pronunciation: "Newton no gatino beejo niyam",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "કોઈ પદાર્થનો પ્રવેગ (Acceleration) તેના પર લાગતા ચોખ્ખા બળ (Force) ના સમપ્રમાણમાં અને તેના દળ (Mass) ના વ્યસ્ત પ્રમાણમાં હોય છે.",
        culturalAnalogy: "હળવી સાયકલને ઝડપથી ચલાવવી સરળ છે, પરંતુ ભારે બળદગાડાને ખેંચવા વધુ બળની જરૂર પડે છે.",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      pa: {
        id: 'n2l_pa',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "ਨਿਊਟਨ ਦਾ ਗਤੀ ਦਾ ਦੂਜਾ ਨਿਯਮ (Newton's Second Law)",
        pronunciation: "Newton da gati da dooja niyam",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "ਕਿਸੇ ਵਸਤੂ ਦਾ ਪ੍ਰਵੇਗ (Acceleration) ਉਸ 'ਤੇ ਲੱਗਣ ਵਾਲੇ ਕੁੱਲ ਬਲ (Force) ਦੇ ਸਿੱਧੇ ਅਨੁਪਾਤੀ ਅਤੇ ਉਸਦੇ ਪੁੰਜ (Mass) ਦੇ ਉਲਟ ਅਨੁਪਾਤੀ ਹੁੰਦਾ ਹੈ।",
        culturalAnalogy: "ਹਲਕੀ ਸਾਈਕਲ ਨੂੰ ਤੇਜ਼ ਚਲਾਉਣਾ ਆਸਾਨ ਹੈ, ਪਰ ਭਾਰੀ ਟਰੈਕਟਰ-ਟਰਾਲੀ ਨੂੰ ਖਿੱਚਣ ਲਈ ਬਹੁਤ ਜ਼ਿਆਦਾ ਜ਼ੋਰ ਚਾਹੀਦਾ ਹੈ।",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      },
      ur: {
        id: 'n2l_ur',
        termEnglish: "Newton's Second Law of Motion",
        termRegional: "نیوٹن کا حرکت کا دوسرا قانون (Newton's Second Law)",
        pronunciation: "Newton ka harkat ka doosra qanoon",
        conceptDefinitionEnglish: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass.",
        conceptDefinitionRegional: "کسی جسم کا اسراع (Acceleration) اس پر عمل کرنے والی مجموعی قوت (Force) کے براہ راست متناسب اور اس کی کمیت (Mass) کے الٹ متناسب ہوتا ہے۔",
        culturalAnalogy: "ایک ہلکی سائیکل کو تیزی سے چلانا آسان ہے لیکن ایک بھاری گاڑی کو حرکت دینے کے لیے زیادہ قوت درکار ہوتی ہے۔",
        formulaPreserved: "F = ma \\quad \\Rightarrow \\quad a = \\frac{F}{m}"
      }
    }
  };

  /**
   * Retrieves pedagogical bilingual lesson content
   */
  static getBilingualLesson(lessonKey: string, lang: SupportedLanguageCode = 'en'): BilingualSegment {
    const lesson = this.SAMPLE_LESSONS[lessonKey] || this.SAMPLE_LESSONS['newtons_second_law'];
    return lesson[lang] || lesson['en'];
  }

  /**
   * Synthesizes audio speech using Web Speech API in native regional accent
   */
  static speakText(text: string, lang: SupportedLanguageCode = 'en'): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!('speechSynthesis' in window)) {
        console.warn('Speech synthesis not supported on this device');
        resolve();
        return;
      }

      window.speechSynthesis.cancel();
      const meta = SUPPORTED_LANGUAGES[lang] || SUPPORTED_LANGUAGES['en'];
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = meta.voiceCode;
      utterance.rate = 0.95; // Clear pedagogical cadence

      utterance.onend = () => resolve();
      utterance.onerror = (e) => {
        console.warn('Speech error', e);
        resolve();
      };

      window.speechSynthesis.speak(utterance);
    });
  }
}
