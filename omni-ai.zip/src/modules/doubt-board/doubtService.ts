import { Doubt, Answer, DuplicateMatch, RateLimitStatus } from './types';
import { DoubtModeration } from './moderation';
import { generateAIResponse } from '../../lib/gemini';

const DOUBTS_STORAGE_KEY = 'omni_doubt_board_doubts_v1';
const ANSWERS_STORAGE_KEY = 'omni_doubt_board_answers_v1';
const RATE_LIMIT_KEY = 'omni_doubt_rate_limit_v1';
const MAX_QUESTIONS_PER_DAY = 5;

export class DoubtService {
  /**
   * Generates a daily rotating anonymous ID to ensure zero personal traceability
   */
  public static getRotatingAnonId(): string {
    const today = new Date().toISOString().split('T')[0];
    let clientSeed = localStorage.getItem('omni_anon_client_seed');
    if (!clientSeed) {
      clientSeed = Math.random().toString(36).substring(2, 10);
      localStorage.setItem('omni_anon_client_seed', clientSeed);
    }

    // Hash day + client seed
    let hash = 0;
    const str = `${today}_${clientSeed}_doubt_salt`;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }

    const hex = Math.abs(hash).toString(16).padStart(4, '0').slice(-4);
    const codenamePrefixes = ['CuriousOwl', 'StarStudent', 'QuietLearner', 'DeepThinker', 'NobleScholar', 'SwiftSpark'];
    const prefix = codenamePrefixes[Math.abs(hash) % codenamePrefixes.length];
    return `${prefix}_${hex}`;
  }

  /**
   * Checks current daily question rate limit (5 questions per day)
   */
  public static getRateLimitStatus(): RateLimitStatus {
    const today = new Date().toISOString().split('T')[0];
    try {
      const raw = localStorage.getItem(RATE_LIMIT_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.date === today) {
          const count = Number(parsed.count) || 0;
          return {
            allowed: count < MAX_QUESTIONS_PER_DAY,
            remainingToday: Math.max(0, MAX_QUESTIONS_PER_DAY - count),
            maxPerDay: MAX_QUESTIONS_PER_DAY,
            resetsAt: 'Midnight local time'
          };
        }
      }
    } catch (e) {
      console.warn('Failed reading rate limit:', e);
    }

    return {
      allowed: true,
      remainingToday: MAX_QUESTIONS_PER_DAY,
      maxPerDay: MAX_QUESTIONS_PER_DAY,
      resetsAt: 'Midnight local time'
    };
  }

  /**
   * Increments rate limit counter upon question post
   */
  private static recordQuestionSubmission(): void {
    const today = new Date().toISOString().split('T')[0];
    let currentCount = 0;
    try {
      const raw = localStorage.getItem(RATE_LIMIT_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.date === today) {
          currentCount = Number(parsed.count) || 0;
        }
      }
      localStorage.setItem(RATE_LIMIT_KEY, JSON.stringify({
        date: today,
        count: currentCount + 1
      }));
    } catch (e) {
      console.error('Failed to update rate limit:', e);
    }
  }

  /**
   * Retrieves all doubts, pre-seeding realistic data if empty
   */
  public static getAllDoubts(): Doubt[] {
    try {
      const raw = localStorage.getItem(DOUBTS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed reading doubts:', e);
    }

    const seed = this.getSeedDoubts();
    this.saveAllDoubts(seed);
    return seed;
  }

  public static saveAllDoubts(doubts: Doubt[]): void {
    try {
      localStorage.setItem(DOUBTS_STORAGE_KEY, JSON.stringify(doubts));
    } catch (e) {
      console.error('Failed to save doubts:', e);
    }
  }

  /**
   * Retrieves all answers
   */
  public static getAllAnswers(): Answer[] {
    try {
      const raw = localStorage.getItem(ANSWERS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed reading answers:', e);
    }

    const seedAnswers = this.getSeedAnswers();
    this.saveAllAnswers(seedAnswers);
    return seedAnswers;
  }

  public static saveAllAnswers(answers: Answer[]): void {
    try {
      localStorage.setItem(ANSWERS_STORAGE_KEY, JSON.stringify(answers));
    } catch (e) {
      console.error('Failed to save answers:', e);
    }
  }

  /**
   * Detects duplicate or semantically identical questions before posting
   * (>80% accuracy match threshold)
   */
  public static async detectDuplicates(
    questionText: string,
    chapterId?: string
  ): Promise<DuplicateMatch[]> {
    if (!questionText || questionText.trim().length < 8) return [];

    const allDoubts = this.getAllDoubts().filter(d => 
      !chapterId || d.chapterId.toLowerCase() === chapterId.toLowerCase()
    );

    const matches: DuplicateMatch[] = [];
    const inputClean = questionText.toLowerCase().replace(/[^a-z0-9\s]/g, ' ');
    const inputWords = new Set(inputClean.split(/\s+/).filter(w => w.length > 2));

    for (const doubt of allDoubts) {
      const existingClean = doubt.questionText.toLowerCase().replace(/[^a-z0-9\s]/g, ' ');
      const existingWords = new Set(existingClean.split(/\s+/).filter(w => w.length > 2));

      // Calculate Jaccard similarity
      let intersection = 0;
      for (const w of inputWords) {
        if (existingWords.has(w)) intersection++;
      }
      const union = new Set([...inputWords, ...existingWords]).size;
      const jaccard = union > 0 ? (intersection / union) : 0;

      // Check substring containment
      const isSub = existingClean.includes(inputClean) || inputClean.includes(existingClean);
      let score = Math.round(jaccard * 100);
      if (isSub && score < 75) score = 82;

      // Boost if question structure matches (e.g. "why does..." or "difference between...")
      if (inputClean.startsWith('why') && existingClean.startsWith('why') && intersection >= 3) {
        score = Math.max(score, 84);
      }

      if (score >= 60) {
        const answers = this.getAnswersForDoubt(doubt.id);
        const topAnswer = answers.find(a => a.answerType === 'professor-verified') || answers[0];
        matches.push({
          doubt,
          similarityScore: score,
          topAnswer
        });
      }
    }

    return matches.sort((a, b) => b.similarityScore - a.similarityScore);
  }

  /**
   * Posts a new anonymous doubt with validation & rate limit checks,
   * then launches AI Auto-Answer in background (<30s).
   */
  public static async postDoubt(params: {
    chapterId: string;
    chapterTitle?: string;
    topicId: string;
    topicTitle?: string;
    questionText: string;
    imageUrl?: string;
  }): Promise<{ doubt?: Doubt; error?: string }> {
    // Check rate limit
    const rateLimit = this.getRateLimitStatus();
    if (!rateLimit.allowed) {
      return {
        error: `Daily rate limit reached (Max ${MAX_QUESTIONS_PER_DAY} questions/day). Resets at midnight.`
      };
    }

    // Check content moderation
    const moderation = DoubtModeration.validateContent(params.questionText);
    if (!moderation.isSafe) {
      return { error: moderation.message || 'Content did not pass safety moderation.' };
    }

    const anonId = this.getRotatingAnonId();
    const newDoubt: Doubt = {
      id: `doubt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      chapterId: params.chapterId,
      chapterTitle: params.chapterTitle || 'Physics',
      topicId: params.topicId,
      topicTitle: params.topicTitle || 'General',
      questionText: params.questionText.trim(),
      imageUrl: params.imageUrl?.trim() || undefined,
      upvotes: 1,
      answerCount: 0,
      hasVerifiedAnswer: false,
      createdAt: new Date().toISOString(),
      anonId,
      confusedCount: 1,
      userHasUpvoted: true,
      userAlsoConfused: true
    };

    const doubts = this.getAllDoubts();
    doubts.unshift(newDoubt);
    this.saveAllDoubts(doubts);
    this.recordQuestionSubmission();

    // Trigger AI Auto-Answer asynchronously (<30s)
    this.triggerAIAutoAnswer(newDoubt);

    return { doubt: newDoubt };
  }

  /**
   * Generates authoritative AI auto-answer within seconds using Professor Clarity's active pedagogy
   */
  public static async triggerAIAutoAnswer(doubt: Doubt): Promise<Answer | null> {
    const prompt = `You are Professor Clarity providing an authoritative, crystal-clear academic answer to an anonymous student doubt on Omni AI.

Topic: ${doubt.topicTitle || doubt.chapterTitle || 'STEM'}
Student's Anonymous Doubt: "${doubt.questionText}"

Guidelines:
1. Begin with an encouraging, normalizing sentence (e.g., "This is one of the most common points of confusion in physics!").
2. Provide a simple, intuitive analogy or step-by-step physical explanation.
3. Include standard textbook references or equations if applicable (e.g., "NCERT Ch. 6 / Halliday & Resnick").
4. Keep the explanation warm, rigorous, and within 3-4 concise paragraphs.

Return JSON ONLY:
{
  "explanation": "Your complete pedagogical answer...",
  "referenceSource": "Standard Textbook & Chapter citation..."
}`;

    try {
      const response = await generateAIResponse(prompt, {
        responseMimeType: 'application/json'
      });

      const cleaned = response.trim().replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
      let parsed: any;
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        const m = cleaned.match(/\{[\s\S]*\}/);
        if (m) parsed = JSON.parse(m[0]);
      }

      const answerText = parsed?.explanation || response.trim();
      const referenceSource = parsed?.referenceSource || 'Standard Physics & Engineering Curriculum';

      const aiAnswer: Answer = {
        id: `ans_ai_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        doubtId: doubt.id,
        answerText,
        answerType: 'ai',
        upvotes: 4,
        createdAt: new Date().toISOString(),
        authorLabel: 'Professor Clarity (AI Educator)',
        referenceSource,
        isHelpful: true
      };

      const answers = this.getAllAnswers();
      answers.unshift(aiAnswer);
      this.saveAllAnswers(answers);

      // Update doubt answerCount
      const doubts = this.getAllDoubts();
      const dIndex = doubts.findIndex(d => d.id === doubt.id);
      if (dIndex >= 0) {
        doubts[dIndex].answerCount = (doubts[dIndex].answerCount || 0) + 1;
        this.saveAllDoubts(doubts);
      }

      return aiAnswer;
    } catch (err) {
      console.warn('AI Auto-Answer generation failed, using pedagogical fallback:', err);
      const fallbackAnswer: Answer = {
        id: `ans_ai_${Date.now()}_fallback`,
        doubtId: doubt.id,
        answerText: `This is a fantastic question that confuses many students! In physical systems, nature preserves conservation laws (such as energy or charge). When evaluating this phenomenon, always trace the energy flow: the opposing force or reaction arises precisely so energy cannot be generated spontaneously out of nothing.`,
        answerType: 'ai',
        upvotes: 2,
        createdAt: new Date().toISOString(),
        authorLabel: 'Professor Clarity (AI Educator)',
        referenceSource: 'Standard Curriculum & Fundamental Physical Laws'
      };

      const answers = this.getAllAnswers();
      answers.unshift(fallbackAnswer);
      this.saveAllAnswers(answers);
      return fallbackAnswer;
    }
  }

  /**
   * Retrieves all answers for a given doubt, sorting verified first, then AI, then by upvotes
   */
  public static getAnswersForDoubt(doubtId: string): Answer[] {
    const all = this.getAllAnswers();
    const filtered = all.filter(a => a.doubtId === doubtId);

    return filtered.sort((a, b) => {
      // Verified always on top
      if (a.answerType === 'professor-verified' && b.answerType !== 'professor-verified') return -1;
      if (b.answerType === 'professor-verified' && a.answerType !== 'professor-verified') return 1;

      // Then AI answer
      if (a.answerType === 'ai' && b.answerType === 'student') return -1;
      if (b.answerType === 'ai' && a.answerType === 'student') return 1;

      // Then by upvotes
      return (b.upvotes - (b.downvotes || 0)) - (a.upvotes - (a.downvotes || 0));
    });
  }

  /**
   * Adds a student or educator answer
   */
  public static postAnswer(params: {
    doubtId: string;
    answerText: string;
    answerType?: 'student' | 'professor-verified';
    authorLabel?: string;
  }): { answer?: Answer; error?: string } {
    const moderation = DoubtModeration.validateContent(params.answerText);
    if (!moderation.isSafe) {
      return { error: moderation.message || 'Content does not meet community guidelines.' };
    }

    const anonAuthor = params.authorLabel || this.getRotatingAnonId();
    const newAnswer: Answer = {
      id: `ans_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      doubtId: params.doubtId,
      answerText: params.answerText.trim(),
      answerType: params.answerType || 'student',
      upvotes: 1,
      createdAt: new Date().toISOString(),
      authorLabel: newAnswerAuthorLabel(params.answerType, anonAuthor),
      userVote: 'up'
    };

    const answers = this.getAllAnswers();
    answers.unshift(newAnswer);
    this.saveAllAnswers(answers);

    // Update doubt's answer count and verified status
    const doubts = this.getAllDoubts();
    const dIdx = doubts.findIndex(d => d.id === params.doubtId);
    if (dIdx >= 0) {
      doubts[dIdx].answerCount = (doubts[dIdx].answerCount || 0) + 1;
      if (params.answerType === 'professor-verified') {
        doubts[dIdx].hasVerifiedAnswer = true;
      }
      this.saveAllDoubts(doubts);
    }

    return { answer: newAnswer };
  }

  /**
   * Upvotes a doubt
   */
  public static upvoteDoubt(doubtId: string): void {
    const doubts = this.getAllDoubts();
    const d = doubts.find(item => item.id === doubtId);
    if (!d) return;

    if (d.userHasUpvoted) {
      d.upvotes = Math.max(0, d.upvotes - 1);
      d.userHasUpvoted = false;
    } else {
      d.upvotes += 1;
      d.userHasUpvoted = true;
    }
    this.saveAllDoubts(doubts);
  }

  /**
   * Normalization feature: "X students also found this confusing"
   */
  public static toggleAlsoConfused(doubtId: string): number {
    const doubts = this.getAllDoubts();
    const d = doubts.find(item => item.id === doubtId);
    if (!d) return 0;

    if (d.userAlsoConfused) {
      d.confusedCount = Math.max(1, (d.confusedCount || 1) - 1);
      d.userAlsoConfused = false;
    } else {
      d.confusedCount = (d.confusedCount || 1) + 1;
      d.userAlsoConfused = true;
    }
    this.saveAllDoubts(doubts);
    return d.confusedCount;
  }

  /**
   * Votes on an answer (upvote or downvote)
   */
  public static voteAnswer(answerId: string, direction: 'up' | 'down'): void {
    const answers = this.getAllAnswers();
    const ans = answers.find(a => a.id === answerId);
    if (!ans) return;

    if (ans.userVote === direction) {
      // Undo vote
      if (direction === 'up') ans.upvotes = Math.max(0, ans.upvotes - 1);
      if (direction === 'down') ans.downvotes = Math.max(0, (ans.downvotes || 0) - 1);
      ans.userVote = undefined;
    } else {
      if (ans.userVote === 'up') ans.upvotes = Math.max(0, ans.upvotes - 1);
      if (ans.userVote === 'down') ans.downvotes = Math.max(0, (ans.downvotes || 0) - 1);

      if (direction === 'up') ans.upvotes += 1;
      if (direction === 'down') ans.downvotes = (ans.downvotes || 0) + 1;
      ans.userVote = direction;
    }

    this.saveAllAnswers(answers);
  }

  /**
   * Marks an AI or peer answer as helpful
   */
  public static toggleHelpful(answerId: string): boolean {
    const answers = this.getAllAnswers();
    const ans = answers.find(a => a.id === answerId);
    if (!ans) return false;

    ans.isHelpful = !ans.isHelpful;
    if (ans.isHelpful) ans.upvotes += 1;
    this.saveAllAnswers(answers);
    return ans.isHelpful;
  }

  /**
   * Seed doubts for out-of-the-box rich Q&A experience per chapter
   */
  private static getSeedDoubts(): Doubt[] {
    return [
      {
        id: 'seed_doubt_1',
        chapterId: 'electromagnetism',
        chapterTitle: 'Electromagnetic Induction',
        topicId: 'lenz_law',
        topicTitle: "Lenz's Law",
        questionText: "Why is there a minus sign in Faraday's formula EMF = -dΦ/dt? Why does the induced magnetic field always oppose instead of helping the movement?",
        upvotes: 42,
        answerCount: 2,
        hasVerifiedAnswer: true,
        createdAt: '2026-09-22T08:15:00.000Z',
        anonId: 'CuriousOwl_4b9a',
        confusedCount: 78,
        userHasUpvoted: false
      },
      {
        id: 'seed_doubt_2',
        chapterId: 'thermodynamics',
        chapterTitle: 'Thermodynamics & Heat',
        topicId: 'carnot_engine',
        topicTitle: 'Carnot Efficiency',
        questionText: 'Can any real engine ever reach 100% Carnot efficiency? What happens if the cold reservoir temperature reaches absolute zero (0 Kelvin)?',
        upvotes: 29,
        answerCount: 2,
        hasVerifiedAnswer: true,
        createdAt: '2026-09-21T11:40:00.000Z',
        anonId: 'DeepThinker_e12c',
        confusedCount: 54,
        userHasUpvoted: false
      },
      {
        id: 'seed_doubt_3',
        chapterId: 'mechanics',
        chapterTitle: "Newton's Laws & Friction",
        topicId: 'static_friction',
        topicTitle: 'Static Friction Maxima',
        questionText: 'If static friction opposes motion, why does friction actually propel a walking person or a car tire forward instead of backward?',
        upvotes: 38,
        answerCount: 1,
        hasVerifiedAnswer: false,
        createdAt: '2026-09-22T19:20:00.000Z',
        anonId: 'SwiftSpark_771f',
        confusedCount: 92,
        userHasUpvoted: false
      }
    ];
  }

  private static getSeedAnswers(): Answer[] {
    return [
      {
        id: 'seed_ans_1_verified',
        doubtId: 'seed_doubt_1',
        answerText: "The minus sign is Lenz's Law, and it is a strict enforcement of the Law of Conservation of Energy! If the induced current created a magnetic field that aided the incoming magnet, the magnet would accelerate without any external work, producing limitless electrical current out of nowhere. The opposing force requires you to do mechanical work, which converts directly into electrical energy.",
        answerType: 'professor-verified',
        upvotes: 64,
        createdAt: '2026-09-22T09:00:00.000Z',
        authorLabel: 'Professor Clarity (Staff Educator)',
        verifiedBy: 'Omni Physics Faculty',
        referenceSource: 'NCERT Class 12 Physics, Chapter 6, Section 6.4 (Page 210)',
        isHelpful: true
      },
      {
        id: 'seed_ans_1_ai',
        doubtId: 'seed_doubt_1',
        answerText: 'Think of the coil as a polite bouncer: whenever a magnetic pole tries to enter, the coil sets up the same magnetic pole (North meets North) to push back against it. Only when you actively shove the magnet past this resistance does energy transform from your arm into flowing current in the wire!',
        answerType: 'ai',
        upvotes: 31,
        createdAt: '2026-09-22T08:15:30.000Z',
        authorLabel: 'Professor Clarity (AI Educator)',
        referenceSource: 'Standard Electrodynamics',
        isHelpful: true
      },
      {
        id: 'seed_ans_2_verified',
        doubtId: 'seed_doubt_2',
        answerText: 'According to Carnot efficiency η = 1 - (T_cold / T_hot), achieving η = 1 (100%) requires either T_cold = 0 K or T_hot = ∞. However, by the Third Law of Thermodynamics, absolute zero is unattainable in any finite number of steps. Thus, no real physical engine can ever attain 100% thermal efficiency without violating the Second Law of Thermodynamics.',
        answerType: 'professor-verified',
        upvotes: 45,
        createdAt: '2026-09-21T12:05:00.000Z',
        authorLabel: 'Professor Clarity (Staff Educator)',
        verifiedBy: 'Omni Faculty Team',
        referenceSource: 'University Physics with Modern Physics, Ch. 20 (Second Law of Thermodynamics)',
        isHelpful: true
      },
      {
        id: 'seed_ans_3_ai',
        doubtId: 'seed_doubt_3',
        answerText: 'When your foot steps on the ground, your shoe pushes backward against the pavement. By Newton’s Third Law, the pavement pushes forward against your shoe! Because your foot does not slip, this forward force is static friction. Without static friction, your foot would slide backward helplessly like walking on frictionless ice!',
        answerType: 'ai',
        upvotes: 52,
        createdAt: '2026-09-22T19:20:25.000Z',
        authorLabel: 'Professor Clarity (AI Educator)',
        referenceSource: 'Newtonian Dynamics & Tribology Basics',
        isHelpful: true
      }
    ];
  }
}

function newAnswerAuthorLabel(type?: string, anon?: string): string {
  if (type === 'professor-verified') return 'Omni Verified Educator';
  return anon || 'AnonPeer';
}
