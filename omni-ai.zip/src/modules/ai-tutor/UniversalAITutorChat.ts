// ai-tutor/UniversalAITutorChat.ts
import {
  StudentProfile,
  TutorRequest,
  TutorResponse,
  IntentType,
  CurriculumContext,
  ClassLevel,
  BoardId,
  ClassStrategy,
  BoardStrategy,
} from './types';
import { IntentClassifier } from './IntentClassifier';
import { UniversalContextBuilder } from './UniversalContextBuilder';
import { AIService } from './AIService';
import { UniversalVerifier } from './UniversalVerifier';
import { UniversalTutorCache } from './UniversalTutorCache';
import { CurriculumService } from './CurriculumService';
import { BOARD_STRATEGIES } from './strategies/BoardStrategies';
import { CLASS_STRATEGIES } from './strategies/ClassStrategies';
import { LANGUAGE_PROMPTS, LANGUAGE_NAMES, buildBilingualInstruction } from './strategies/LanguageStrategy';
import {
  EXPLANATION_PROMPT,
  QUESTION_PROMPT,
  ANALOGY_PROMPT,
  SUMMARY_PROMPT,
} from './prompts/universal-templates';

export class UniversalAITutorChat {
  constructor(
    private classifier: IntentClassifier = new IntentClassifier(),
    private contextBuilder: UniversalContextBuilder = new UniversalContextBuilder(),
    private aiService: AIService = new AIService(),
    private verifier: UniversalVerifier = new UniversalVerifier(),
    private cache: UniversalTutorCache = new UniversalTutorCache(),
    private curriculumService: CurriculumService = new CurriculumService(),
  ) {}

  async respond(profile: StudentProfile, request: TutorRequest): Promise<TutorResponse> {
    const startTime = Date.now();

    // 1. Classify student intent (explain, question, analogy, summarise, clarify, example, check)
    const intent = await this.classifier.classify(request.message, request.context);

    // 2. Check universal cache
    const cacheKey = this.cache.buildKey(profile, request, intent);
    const cached = await this.cache.get(cacheKey);
    if (cached) {
      return {
        ...cached,
        metadata: {
          ...cached.metadata,
          cached: true,
          latencyMs: Date.now() - startTime,
        },
      };
    }

    // 3. Build rich curriculum context
    const context = await this.contextBuilder.build(profile, request);

    // 4. Construct prompt with board, class, language, and cultural calibration
    const prompt = this.buildPrompt(request, context, intent, profile);

    // 5. Select model tier
    const model = this.selectModel(profile.classLevel, profile.board, intent);

    try {
      // 6. Generate via AI Service
      const raw = await this.aiService.generate(prompt, {
        model,
        maxTokens: this.selectMaxTokens(context, intent),
        temperature: 0.3,
      });

      // 7. Verify generated output
      const verification = await this.verifier.verify(raw.text, intent, context);

      if (!verification.passed) {
        console.warn('[UniversalAITutorChat] Verification failed:', verification.failures);
        return this.fallback(request, context, intent, profile);
      }

      // 8. Clean and parse JSON
      let cleaned = raw.text.trim();
      if (cleaned.startsWith('```json')) {
        cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
      } else if (cleaned.startsWith('```')) {
        cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
      }

      let parsed: any;
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          try {
            parsed = JSON.parse(jsonMatch[0]);
          } catch {
            parsed = { text: raw.text, keyTakeaway: 'Focus on core definitions and standard units.' };
          }
        } else {
          parsed = { text: raw.text, keyTakeaway: 'Focus on core definitions and standard units.' };
        }
      }

      const response: TutorResponse = {
        id: this.generateId(),
        intent,
        outputType: this.intentToOutputType(intent),
        generatedFor: {
          board: profile.board,
          classLevel: profile.classLevel,
          subjectId: profile.subjectId,
          language: profile.preferredLanguage,
          examTarget: profile.examTargets[0],
        },
        content: this.formatContent(parsed, intent),
        metadata: {
          model: raw.model,
          tokensUsed: raw.tokensUsed,
          latencyMs: Date.now() - startTime,
          cached: false,
          verified: true,
          confidence: parsed.confidence ?? 0.95,
          curriculumVersion: `${context.board}-${context.classLevel}-v1`,
        },
        createdAt: new Date().toISOString(),
      };

      // 9. Store in cache
      await this.cache.set(cacheKey, response);

      return response;
    } catch (err: any) {
      console.warn('[UniversalAITutorChat] Falling back due to generation exception:', err?.message || err);
      return this.fallback(request, context, intent, profile);
    }
  }

  private buildPrompt(
    request: TutorRequest,
    context: CurriculumContext,
    intent: IntentType,
    profile: StudentProfile
  ): string {
    const templates: Record<IntentType, string> = {
      explain: EXPLANATION_PROMPT,
      question: QUESTION_PROMPT,
      analogy: ANALOGY_PROMPT,
      summarise: SUMMARY_PROMPT,
      clarify: EXPLANATION_PROMPT,
      example: QUESTION_PROMPT,
      check: EXPLANATION_PROMPT,
      other: EXPLANATION_PROMPT,
    };

    const strategy: BoardStrategy = BOARD_STRATEGIES[context.board] || BOARD_STRATEGIES['cbse'];
    const classBucketName = typeof context.classLevel === 'number'
      ? this.classBucket(context.classLevel)
      : 'undergraduate';
    const classStrategy: ClassStrategy = CLASS_STRATEGIES[classBucketName] || CLASS_STRATEGIES['secondary-9-10'];

    const langPrompt = LANGUAGE_PROMPTS[context.language] || LANGUAGE_PROMPTS['en'];
    const bilingualInstruction = buildBilingualInstruction(context.language);
    const effectiveLanguage = `${LANGUAGE_NAMES[context.language] || 'English'} (${langPrompt} ${bilingualInstruction})`;

    const template = templates[intent] || EXPLANATION_PROMPT;

    return this.interpolate(template, {
      boardName: strategy.name,
      boardEmphasis: strategy.emphasis,
      classLevel: String(context.classLevel),
      subjectName: context.subjectName,
      chapterName: context.chapterName,
      topicName: context.topicName,
      objectives: context.learningObjectives.join('; ') || 'Standard syllabus objectives',
      prerequisites: context.prerequisites.join('; ') || 'Foundational prerequisite concepts',
      formulas: context.standardFormulas.join('; ') || 'Governing algebraic / physical formulas',
      vocabularyLevel: context.vocabularyLevel,
      contentDepth: String(context.contentDepth),
      culturalContext: context.culturalContext,
      examPattern: `${context.examPattern.style} (Max Marks: ${context.examPattern.maxMarks}, ${context.examPattern.durationMinutes} mins)`,
      examTarget: profile.examTargets[0] || 'board-exam',
      language: effectiveLanguage,
      region: profile.region || 'India',
      level: this.studentLevel(context.contentDepth),
      mastered: profile.priorProgress?.topicsMastered?.join(', ') || 'Core foundation',
      struggling: profile.priorProgress?.topicsStrugglingWith?.join(', ') || 'Complex derivations',
      accuracy: String(profile.priorProgress?.averageAccuracy ?? 85),
      question: request.message,
      concept: context.subtopicName || context.topicName,
      wordCount: String(this.calculateWordCount(classStrategy)),
      count: '3',
      questionTypes: classStrategy.questionTypes.join(', '),
    });
  }

  private selectModel(classLevel: ClassLevel, board: BoardId, intent: IntentType): string {
    // Fast & high-quality reasoning across all boards & classes
    return 'gemini-3.8-flash';
  }

  private classBucket(classLevel: number): string {
    if (classLevel <= 3) return 'primary-1-3';
    if (classLevel <= 5) return 'primary-4-5';
    if (classLevel <= 8) return 'middle-6-8';
    if (classLevel <= 10) return 'secondary-9-10';
    if (classLevel <= 12) return 'senior-11-12';
    return 'undergraduate';
  }

  private calculateWordCount(classStrategy: ClassStrategy): number {
    return Math.round((classStrategy.wordCount.min + classStrategy.wordCount.max) / 2);
  }

  private studentLevel(depth: number): string {
    if (depth <= 2) return 'beginner';
    if (depth <= 4) return 'intermediate';
    return 'advanced';
  }

  private selectMaxTokens(context: CurriculumContext, intent: IntentType): number {
    const base = intent === 'question' ? 1800 : 1200;
    return base + context.contentDepth * 100;
  }

  private intentToOutputType(intent: IntentType): TutorResponse['outputType'] {
    if (intent === 'question' || intent === 'example') return 'question';
    if (intent === 'analogy') return 'analogy';
    if (intent === 'summarise') return 'summary';
    return 'explanation';
  }

  private formatContent(parsed: any, intent: IntentType): TutorResponse['content'] {
    if (intent === 'question' || intent === 'example') {
      const qList = parsed.questions || [];
      const formattedText = qList
        .map(
          (q: any, i: number) =>
            `### Question ${i + 1} (${q.type?.toUpperCase()} — ${q.marks} Marks)\n${q.text}\n\n` +
            (q.options?.length ? q.options.map((opt: string) => `- ${opt}`).join('\n') + '\n\n' : '') +
            `> **Hint**: ${q.hint}\n\n` +
            `<details><summary><strong>View Solution & Common Trap</strong></summary>\n\n**Solution**:\n${q.solution}\n\n**Common Pitfall**: ${q.commonMistake || 'Watch negative signs and units.'}\n</details>`
        )
        .join('\n\n---\n\n');

      return {
        text: formattedText || parsed.text || 'Practice questions generated.',
        questions: qList,
        mathBlocks: parsed.mathBlocks || [],
        diagramLinks: parsed.diagramLinks || [],
        keyTakeaway: 'Practice step-by-step substitution and avoid common algebra traps.',
      };
    }

    if (intent === 'analogy') {
      const text = `${parsed.analogy}\n\n` +
        (parsed.mapping?.length
          ? `### Conceptual Mapping\n` +
            parsed.mapping.map((m: any) => `- **${m.concept_part}** $\\longleftrightarrow$ *${m.analogy_part}*`).join('\n') +
            '\n\n'
          : '') +
        (parsed.whereItBreaks ? `> ⚠️ **Where this analogy breaks down**: ${parsed.whereItBreaks}` : '');

      return {
        text,
        whereItBreaks: parsed.whereItBreaks,
        mathBlocks: parsed.mathBlocks || [],
        diagramLinks: parsed.diagramLinks || [],
        keyTakeaway: parsed.keyTakeaway || 'Analogies provide physical intuition, but mathematical laws dictate the exact boundaries.',
      };
    }

    if (intent === 'summarise') {
      const points = Array.isArray(parsed.keyPoints) ? parsed.keyPoints.map((p: string) => `- ${p}`).join('\n') : '';
      const text = `### High-Yield Revision Summary\n${points}\n\n` +
        (parsed.formula ? `**Governing Formula**: $$${parsed.formula}$$\n\n` : '') +
        (parsed.commonMistake ? `> ⚠️ **Common Trap**: ${parsed.commonMistake}\n\n` : '') +
        (parsed.examTip ? `💡 **Top Exam Tip**: ${parsed.examTip}\n\n` : '') +
        (parsed.boardSpecificNote ? `📌 **Board Marking Note**: ${parsed.boardSpecificNote}` : '');

      return {
        text,
        mathBlocks: parsed.formula ? [parsed.formula] : [],
        keyTakeaway: parsed.examTip || 'Focus on precise formulas, SI units, and step marking.',
      };
    }

    return {
      text: parsed.text || 'Explanation generated successfully.',
      mathBlocks: parsed.mathBlocks || [],
      diagramLinks: parsed.diagramLinks || [],
      keyTakeaway: parsed.keyTakeaway || 'Ensure clear definition, standard formulas, and contextual units.',
    };
  }

  private async fallback(
    request: TutorRequest,
    context: CurriculumContext,
    intent: IntentType,
    profile: StudentProfile
  ): Promise<TutorResponse> {
    const fallbackText = await this.curriculumService.getFallbackContent(context, intent);

    return {
      id: this.generateId(),
      intent,
      outputType: this.intentToOutputType(intent),
      generatedFor: {
        board: profile.board,
        classLevel: profile.classLevel,
        subjectId: profile.subjectId,
        language: profile.preferredLanguage,
        examTarget: profile.examTargets[0],
      },
      content: {
        text: fallbackText,
        mathBlocks: context.standardFormulas,
        diagramLinks: [],
        keyTakeaway: 'Verified syllabus standard answer.',
      },
      metadata: {
        model: 'curriculum-verified-fallback',
        tokensUsed: 0,
        latencyMs: 10,
        cached: false,
        verified: true,
        confidence: 0.98,
        curriculumVersion: `${context.board}-${context.classLevel}-offline-v1`,
      },
      createdAt: new Date().toISOString(),
    };
  }

  private interpolate(template: string, vars: Record<string, string>): string {
    return template.replace(/\{(\w+)\}/g, (_, key) => vars[key] ?? '');
  }

  private generateId(): string {
    return `resp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }
}
