import { useState, useEffect, useCallback } from 'react';
import { generateInterleavedSession } from '../modules/interleaving/questionMixer';
import { InterleavedQuestion } from '../modules/interleaving/interleavedQuestionsData';
import { recordConfusion, recordSuccessfulDiscrimination } from '../modules/interleaving/confusionMatrix';

const WEAKNESS_KEY = 'omni_weakness_scores_v1';
const WEIGHTAGE_KEY = 'omni_exam_weightages_v1';
const RECENCY_KEY = 'omni_last_practiced_times_v1';
const COMPLETED_LESSONS_KEY = 'completed_lessons_v1';

export interface UseInterleavedPracticeProps {
  subject: string;
  currentChapterId: string;
  sessionSize?: number;
}

export function useInterleavedPractice({
  subject,
  currentChapterId,
  sessionSize = 10
}: UseInterleavedPracticeProps) {
  const [questions, setQuestions] = useState<InterleavedQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [score, setScore] = useState<number>(0);

  // Load various states from localStorage
  const loadState = useCallback((key: string): Record<string, any> => {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : {};
    } catch {
      return {};
    }
  }, []);

  const saveState = useCallback((key: string, data: Record<string, any>) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error(`Error saving ${key}`, e);
    }
  }, []);

  // Initialize and generate session questions
  const startNewSession = useCallback(() => {
    setIsLoading(true);
    setCurrentIndex(0);
    setUserAnswers({});
    setIsSubmitted(false);
    setScore(0);

    const completedLessons = loadState(COMPLETED_LESSONS_KEY);
    const weaknessScores = loadState(WEAKNESS_KEY);
    const examWeightages = loadState(WEIGHTAGE_KEY);
    const lastPracticedTimes = loadState(RECENCY_KEY);

    const sessionQs = generateInterleavedSession({
      subject,
      currentChapterId,
      completedLessons,
      weaknessScores,
      examWeightages,
      lastPracticedTimes,
      sessionSize
    });

    setQuestions(sessionQs);
    setIsLoading(false);
  }, [subject, currentChapterId, sessionSize, loadState]);

  // Load session on mount or current chapter change
  useEffect(() => {
    startNewSession();
  }, [subject, currentChapterId, sessionSize]);

  // Handle answering a question
  const submitAnswer = useCallback((questionId: string, answer: string) => {
    if (isSubmitted) return;

    setUserAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  }, [isSubmitted]);

  // End the practice session, grade answers, and update cognitive metadata (closed-loop updates)
  const finishSession = useCallback(() => {
    if (isSubmitted) return;
    setIsSubmitted(true);

    const weaknessScores = loadState(WEAKNESS_KEY);
    const lastPracticedTimes = loadState(RECENCY_KEY);

    let correctCount = 0;

    questions.forEach(q => {
      const userAnswer = userAnswers[q.id];
      const isCorrect = userAnswer === q.correctAnswer;

      if (isCorrect) {
        correctCount++;
        // Decrease weakness for this topic/concept
        const currentWeakness = weaknessScores[q.conceptTested] ?? 0.5;
        weaknessScores[q.conceptTested] = Math.max(0, currentWeakness - 0.1);

        // If it's a discrimination question, mitigate confusion
        if (q.isDiscriminationQuestion && q.discriminationTarget) {
          recordSuccessfulDiscrimination(q.conceptTested, q.discriminationTarget);
        }
      } else {
        // Increase weakness for this topic/concept
        const currentWeakness = weaknessScores[q.conceptTested] ?? 0.5;
        weaknessScores[q.conceptTested] = Math.min(1, currentWeakness + 0.15);

        // Record confusion between topic and its discrimination target
        if (q.discriminationTarget) {
          recordConfusion(q.conceptTested, q.discriminationTarget);
        }
      }

      // Record last practiced time
      lastPracticedTimes[q.conceptTested] = Date.now();
      lastPracticedTimes[q.chapterId] = Date.now();
    });

    // Persist updated metadata
    saveState(WEAKNESS_KEY, weaknessScores);
    saveState(RECENCY_KEY, lastPracticedTimes);
    setScore(correctCount);

    return correctCount;
  }, [questions, userAnswers, isSubmitted, loadState, saveState]);

  return {
    questions,
    currentIndex,
    setCurrentIndex,
    userAnswers,
    isSubmitted,
    isLoading,
    score,
    submitAnswer,
    finishSession,
    startNewSession
  };
}
