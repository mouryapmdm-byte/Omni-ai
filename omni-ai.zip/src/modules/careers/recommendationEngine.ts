import { Career, careerDatabase } from './careerDatabase';

export interface CareerRecommendation {
  studentId: string;
  careerId: string;
  matchScore: number;
  reasons: string[];
  generatedAt: string;
}

export function generateCareerRecommendations(
  studentId: string,
  preferredSubjects: string[],
  selectedInterests: string[],
  userPerformance?: { subject: string; score: number }[] // Optional grades support to make recommendations feel personal!
): CareerRecommendation[] {
  
  const recommendations: CareerRecommendation[] = [];

  for (const career of careerDatabase) {
    let matchScore = 55; // Base score
    const reasons: string[] = [];

    // 1. Subject matching weight: +10% to +15% per matching subject
    let matchedSubjectsCount = 0;
    const matchedSubjectNames: string[] = [];
    career.requiredSubjects.forEach(sub => {
      if (preferredSubjects.includes(sub)) {
        matchScore += 12;
        matchedSubjectsCount++;
        matchedSubjectNames.push(sub);
      }
    });

    if (matchedSubjectsCount > 0) {
      reasons.push(`Strong alignment with your preferred subjects: ${matchedSubjectNames.join(', ')}.`);
    } else {
      // Small penalty if no core preferred subjects are selected
      matchScore -= 15;
    }

    // 2. Performance-based multiplier (Boost score if student excels in the required fields!)
    if (userPerformance && userPerformance.length > 0) {
      let subjectBoost = 0;
      let excellentSubject: string | null = null;
      
      career.requiredSubjects.forEach(sub => {
        const perf = userPerformance.find(p => p.subject.toLowerCase() === sub.toLowerCase());
        if (perf && perf.score >= 85) {
          subjectBoost += 8;
          excellentSubject = sub;
        }
      });

      if (subjectBoost > 0) {
        matchScore += subjectBoost;
        reasons.push(`Your high performance marks (85%+) in ${excellentSubject || 'relevant areas'} suggest a natural aptitude for this field!`);
      }
    }

    // 3. Specific interest associations
    if (selectedInterests.includes('space') && career.id === 'aerospace_navigator') {
      matchScore += 25;
      reasons.push('Directly matches your passion for astronautics, satellites, and gravitational trajectories.');
    }
    if (selectedInterests.includes('coding')) {
      if (['quantum_architect', 'robotics_engineer', 'quantitative_analyst', 'bioinformatics_architect'].includes(career.id)) {
        matchScore += 20;
        reasons.push('Leverages your deep programming background for high-performance low-level optimization and system architectures.');
      }
    }
    if (selectedInterests.includes('healthcare')) {
      if (['biomedical_engineer', 'epidemiological_analyst', 'bioinformatics_architect', 'clinical_geneticist'].includes(career.id)) {
        matchScore += 25;
        reasons.push('Fulfills your motivation to improve clinical healthcare systems, map human genes, or analyze cellular epidemics.');
      }
    }
    if (selectedInterests.includes('environment')) {
      if (['renewable_architect', 'bioinformatics_architect'].includes(career.id)) {
        matchScore += 25;
        reasons.push('Sustains your motivation to design climate-tech structures, clean energy grids, or optimize synthetic biology carbon capture.');
      }
    }
    if (selectedInterests.includes('building')) {
      if (['quantum_architect', 'renewable_architect', 'robotics_engineer', 'acoustic_engineer'].includes(career.id)) {
        matchScore += 18;
        reasons.push('Perfectly utilizes your physical prototyping, hardware modeling, and spatial CAD capabilities.');
      }
    }
    if (selectedInterests.includes('math_puzzles')) {
      if (['quantitative_analyst', 'acoustic_engineer', 'quantum_architect', 'aerospace_navigator'].includes(career.id)) {
        matchScore += 22;
        reasons.push('Leverages your flair for advanced mathematical formulas, wave physics, and complex algorithmic riddles.');
      }
    }

    // Cap score at 99%, floor at 30%
    matchScore = Math.max(30, Math.min(matchScore, 99));

    // Filter to careers with meaningful scores or matches
    if (matchScore >= 50) {
      recommendations.push({
        studentId,
        careerId: career.id,
        matchScore,
        reasons: reasons.length > 0 ? reasons : ['Aligns with your cross-disciplinary science prerequisites.'],
        generatedAt: new Date().toISOString()
      });
    }
  }

  // Sort by highest score first
  return recommendations.sort((a, b) => b.matchScore - a.matchScore);
}
