import React, { useMemo, useRef, useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';
import rehypeRaw from 'rehype-raw';
import { StreamingBuffer } from '../lib/streaming/StreamingBuffer';
import { cleanStreamingMarkdown } from '../lib/streaming/cleanStreamingMarkdown';

interface CleanStreamingRendererProps {
  streamText: string;
  isStreaming: boolean;
  className?: string;
  onContentChange?: (safeText: string) => void;
  showCursor?: boolean;
}

/**
 * CleanStreamingRenderer
 * Renders streaming Markdown and LaTeX math without flashing raw syntax tokens.
 */
export const CleanStreamingRenderer: React.FC<CleanStreamingRendererProps> = ({
  streamText,
  isStreaming,
  className = '',
  onContentChange,
  showCursor = true,
}) => {
  const bufferRef = useRef<StreamingBuffer>(new StreamingBuffer());
  const [safeContent, setSafeContent] = useState<string>('');

  useEffect(() => {
    if (!isStreaming) {
      const finalContent = bufferRef.current.flush();
      const cleanFinal = cleanStreamingMarkdown(finalContent, false);
      setSafeContent(cleanFinal);
      onContentChange?.(cleanFinal);
      return;
    }

    // Reset buffer if content reset/shrunk
    if (streamText.length < bufferRef.current.getRawBuffer().length) {
      bufferRef.current.reset();
    }

    const newChunk = streamText.slice(bufferRef.current.getRawBuffer().length);
    const safe = bufferRef.current.append(newChunk);
    
    // Also sanitize any partial dangling syntax and code fences at the tail
    const sanitizedSafe = cleanStreamingMarkdown(safe || streamText, true);
    setSafeContent(sanitizedSafe);
    onContentChange?.(sanitizedSafe);
  }, [streamText, isStreaming, onContentChange]);

  const renderedMarkdown = useMemo(() => {
    if (!safeContent) return null;

    return (
      <ReactMarkdown
        remarkPlugins={[remarkMath, remarkGfm]}
        rehypePlugins={[rehypeKatex, rehypeRaw]}
        components={{
          h1: ({ children }) => <h1 className="stream-h1">{children}</h1>,
          h2: ({ children }) => <h2 className="stream-h2">{children}</h2>,
          h3: ({ children }) => <h3 className="stream-h3">{children}</h3>,
          h4: ({ children }) => <h4 className="stream-h4">{children}</h4>,
          p: ({ children }) => <p className="stream-p">{children}</p>,
          text: ({ children, node, ...props }: any) => (
            <span
              style={{
                fontFamily: props['font-family'] || props.fontFamily,
                fontSize: props['font-size'] || props.fontSize,
                fontWeight: props['font-weight'] || props.fontWeight,
                color: props.fill || undefined
              }}
            >
              {children}
            </span>
          ),
        }}
      >
        {safeContent}
      </ReactMarkdown>
    );
  }, [safeContent]);

  return (
    <div className={`clean-streaming-renderer ${className}`}>
      {renderedMarkdown}
      {isStreaming && showCursor && <StreamingCursor />}
    </div>
  );
};

export const StreamingCursor: React.FC = () => (
  <span className="streaming-cursor" aria-hidden="true">
    ▌
  </span>
);
