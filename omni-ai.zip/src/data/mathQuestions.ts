export const MATH_QUESTIONS = [
  {
    id: 'q1',
    chapterId: 'relations_functions',
    chapterTitle: '1. Relations and Functions',
    section: 'A',
    marks: 1,
    questionText: 'Let R be the relation in the set {1, 2, 3, 4} given by R = {(1, 2), (2, 2), (1, 1), (4, 4), (1, 3), (3, 3), (3, 2)}. Choose the correct option:',
    options: [
      'R is reflexive and symmetric but not transitive',
      'R is reflexive and transitive but not symmetric',
      'R is an equivalence relation',
      'R is symmetric and transitive but not reflexive'
    ],
    correctAnswer: 'R is reflexive and transitive but not symmetric',
    solution: 'Reflexive as (1,1), (2,2), (3,3), (4,4) are in R. Transitive holds for all elements. Symmetric fails since (1,2) ∈ R but (2,1) ∉ R.',
    subtopicRef: 'Reflexive, symmetric, transitive and equivalence relations'
  },
  // Add other questions here...
];
