import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Globe, Sparkles, AlertCircle, Volume2 } from 'lucide-react';
import { cn } from '../lib/utils';

export interface VoiceInputProps {
  onTranscriptChange: (text: string) => void;
  currentValue: string;
  className?: string;
  placeholder?: string;
}

export const VoiceInput: React.FC<VoiceInputProps> = ({
  onTranscriptChange,
  currentValue,
  className,
  placeholder = "Speak or write everything you remember..."
}) => {
  const [isListening, setIsListening] = useState(false);
  const [language, setLanguage] = useState<'en-US' | 'en-IN' | 'hi-IN'>('en-IN');
  const [isSupported, setIsSupported] = useState(true);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check Web Speech API availability
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognition.lang = language;

      recognition.onresult = (event: any) => {
        let finalChunk = '';
        let interimChunk = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalChunk += event.results[i][0].transcript + ' ';
          } else {
            interimChunk += event.results[i][0].transcript;
          }
        }

        if (finalChunk) {
          // Capitalize and append
          const formatted = finalChunk.trim();
          const separator = currentValue && !currentValue.endsWith(' ') ? ' ' : '';
          onTranscriptChange(currentValue + separator + formatted);
        }
        setInterimTranscript(interimChunk);
      };

      recognition.onerror = (event: any) => {
        console.warn('[VoiceInput] Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          setErrorMessage('Microphone access denied. Please allow microphone permissions in browser.');
        } else if (event.error === 'network') {
          setErrorMessage('Network error during speech recognition.');
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setInterimTranscript('');
        // Auto restart if user didn't explicitly stop it
        if (isListening) {
          try {
            recognition.start();
          } catch {
            setIsListening(false);
          }
        }
      };

      recognitionRef.current = recognition;
    } catch (err) {
      console.error('[VoiceInput] Initialization error:', err);
      setIsSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
    };
  }, [language, currentValue, onTranscriptChange]);

  const toggleListening = () => {
    setErrorMessage(null);
    if (!isSupported) {
      setErrorMessage('Web Speech API dictation is not natively supported in this browser. You can type directly below.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
    } else {
      setIsListening(true);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.lang = language;
          recognitionRef.current.start();
        } catch (e) {
          console.warn('[VoiceInput] Start error:', e);
          setIsListening(false);
        }
      }
    }
  };

  return (
    <div className={cn("flex flex-col gap-2.5", className)}>
      {/* Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-100 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700/60">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleListening}
            className={cn(
              "flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 shadow-sm cursor-pointer",
              isListening
                ? "bg-rose-500 text-white animate-pulse shadow-rose-500/20"
                : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/10"
            )}
          >
            {isListening ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-200 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                </span>
                <MicOff size={14} />
                Listening... (Click to Stop)
              </>
            ) : (
              <>
                <Mic size={14} />
                Start Voice Dictation
              </>
            )}
          </button>

          {/* Language Selector */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/80 px-2.5 py-1 rounded-lg text-xs">
            <Globe size={13} className="text-slate-400" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
              className="bg-transparent text-slate-700 dark:text-slate-300 font-medium focus:outline-none cursor-pointer"
            >
              <option value="en-IN">English (India)</option>
              <option value="en-US">English (US)</option>
              <option value="hi-IN">Hindi (हिंदी)</option>
            </select>
          </div>
        </div>

        {/* Real-time Indicator */}
        <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
          <Sparkles size={12} className="text-indigo-400" />
          <span>Real-time Speech Recognition & Auto-punctuation</span>
        </div>
      </div>

      {/* Error / Fallback Notification */}
      {errorMessage && (
        <div className="flex items-center gap-2 text-xs bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 p-2.5 rounded-lg">
          <AlertCircle size={14} className="shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Live Interim Transcript Badge */}
      {isListening && interimTranscript && (
        <div className="flex items-center gap-2 bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 dark:text-indigo-300 p-2 rounded-lg text-xs italic">
          <Volume2 size={13} className="animate-pulse shrink-0 text-indigo-400" />
          <span className="truncate">Hearing: "{interimTranscript}"</span>
        </div>
      )}

      {/* Main Textarea */}
      <textarea
        value={currentValue}
        onChange={(e) => onTranscriptChange(e.target.value)}
        placeholder={placeholder}
        rows={6}
        className="w-full p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-100 placeholder:text-slate-400 text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500 transition resize-none shadow-sm"
      />
    </div>
  );
};
