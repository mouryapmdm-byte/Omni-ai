import React, { useState, useEffect } from 'react';
import { 
  Sparkles, CheckCircle2, AlertTriangle, ArrowRight, Brain, Clock, 
  Target, Award, BookOpen, RefreshCw, BarChart3, ChevronRight, Zap, Play, Calendar, UserCheck, Gauge, Heart, Users, HelpCircle
} from 'lucide-react';
import { generateAIResponse } from '../lib/gemini';
import { cn } from '../lib/utils';
import { LearningStyleCard } from './LearningStyleCard';
import { DiagnosticTest } from './DiagnosticTest';
import { PersonalizedPath } from './PersonalizedPath';
import { DifficultyTunerCard } from './DifficultyTunerCard';
import { ExampleCard } from './ExampleCard';
import { InterestSettings } from './InterestSettings';
import { ExplainBackCard } from './ExplainBackCard';
import { PeerExplanationHub } from './PeerExplanationHub';
import { DoubtBoard } from './DoubtBoard';
import { StudyBuddyList } from './StudyBuddyList';
import { useDifficulty } from '../hooks/useDifficulty';
import { getDiagnosticResult, saveDiagnosticResult } from '../modules/diagnostic/storage';
import { DiagnosticResult } from '../modules/diagnostic/types';

interface LearningStep {
  id: string;
  title: string;
  type: 'concept_review' | 'deep_mastery' | 'practice_drill' | 'checkpoint_quiz' | 'next_topic';
  durationMinutes: number;
  status: 'completed' | 'in_progress' | 'locked';
  description: string;
  keyFormulas?: string[];
  remediationTips?: string;
  difficulty: 'Foundation' | 'Intermediate' | 'Honors' | 'Olympiad';
}

interface PersonalisedPathData {
  studentName: string;
  subject: string;
  targetExam: string;
  overallMasteryScore: number;
  weakAreas: string[];
  strongAreas: string[];
  recommendedSteps: LearningStep[];
  estimatedCompletionHours: number;
  revisionSchedule: { day: string; task: string }[];
}

interface Props {
  theme?: 'light' | 'dark';
  subject?: string;
  topic?: string;
  difficulty?: string;
  userName?: string;
  onStartLesson?: (lessonTitle: string, rigor: string) => void;
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const AdaptiveLearningPath: React.FC<Props> = ({
  theme = 'light',
  subject = 'Physics',
  topic = 'Electromagnetism',
  difficulty = 'Class 12 / Advanced',
  userName = 'Student',
  onStartLesson,
  showNotification
}) => {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'path' | 'diagnostic' | 'revision' | 'style' | 'difficulty'>('path');
  const [diagnosticResult, setDiagnosticResult] = useState<DiagnosticResult | null>(() => getDiagnosticResult(topic));
  const {
    difficultyState,
    setLevelManually,
    resetDifficulty,
    dismissIntervention
  } = useDifficulty(userName || 'student_default', topic || 'general');
  const [diagnosticAnswers, setDiagnosticAnswers] = useState<Record<number, string>>({});
  const [diagnosticSubmitted, setDiagnosticSubmitted] = useState(false);
  const [showInterestSettingsModal, setShowInterestSettingsModal] = useState(false);
  const [showPeerSocialModal, setShowPeerSocialModal] = useState(false);
  const [showDoubtBoardModal, setShowDoubtBoardModal] = useState(false);
  const [showStudyBuddyModal, setShowStudyBuddyModal] = useState(false);
  
  // Stored or generated curriculum
  const [pathData, setPathData] = useState<PersonalisedPathData>(() => {
    const saved = localStorage.getItem(`omni_adaptive_path_${subject}_${topic}`);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {
      studentName: userName,
      subject: subject,
      targetExam: 'CBSE Class 12 / JEE / NEET',
      overallMasteryScore: 68,
      weakAreas: [`${topic}: Boundary Conditions & Field Calculations`, 'Numerical Problem Setup with Vector Calc'],
      strongAreas: [`${topic}: Basic Qualitative Laws`, 'Dimensional Analysis'],
      estimatedCompletionHours: 8.5,
      recommendedSteps: [
        {
          id: 'step-1',
          title: `Diagnostic Review: Foundational Concepts in ${topic}`,
          type: 'concept_review',
          durationMinutes: 45,
          status: 'completed',
          description: 'Review core vector definitions, constitutive relations, and unit standards.',
          difficulty: 'Foundation',
          keyFormulas: ['\\nabla \\times \\mathbf{E} = -\\frac{\\partial \\mathbf{B}}{\\partial t}', '\\oint \\mathbf{B} \\cdot d\\mathbf{A} = 0']
        },
        {
          id: 'step-2',
          title: `Remediation Module: Mastering Challenging Problem Patterns`,
          type: 'deep_mastery',
          durationMinutes: 90,
          status: 'in_progress',
          description: 'Step-by-step resolution of high-frequency exam pitfalls and multi-step derivations.',
          difficulty: 'Intermediate',
          keyFormulas: ['\\mathbf{F} = q(\\mathbf{E} + \\mathbf{v} \\times \\mathbf{B})'],
          remediationTips: 'Focus on drawing the right-hand rule coordinates before setting up integrals.'
        },
        {
          id: 'step-3',
          title: `Targeted Practice: 30+ Adaptive Questions`,
          type: 'practice_drill',
          durationMinutes: 60,
          status: 'locked',
          description: 'AI-curated question bank adjusting dynamically from single-step to multi-concept problems.',
          difficulty: 'Honors'
        },
        {
          id: 'step-4',
          title: `Milestone Assessment & Confidence Check`,
          type: 'checkpoint_quiz',
          durationMinutes: 30,
          status: 'locked',
          description: 'Timed diagnostic check with automated step-by-step marking rubrics.',
          difficulty: 'Honors'
        },
        {
          id: 'step-5',
          title: `Next Frontier: Advanced Applications & Electrodynamics`,
          type: 'next_topic',
          durationMinutes: 75,
          status: 'locked',
          description: 'Seamless progression to electromagnetic waves and energy transport (Poynting vector).',
          difficulty: 'Olympiad'
        }
      ],
      revisionSchedule: [
        { day: 'Day 1 (Today)', task: 'Complete Remediation Module + 10 Drill Questions' },
        { day: 'Day 3 (+48h)', task: 'Active Recall Check: Review Key Formulas without looking at notes' },
        { day: 'Day 7 (+1 Week)', task: 'Full Chapter Checkpoint Quiz & Spaced Repetition Flashcards' },
        { day: 'Day 14 (+2 Weeks)', task: 'Mixed Mock Exam with previous year questions' }
      ]
    };
  });

  const diagnosticQuestions = [
    {
      id: 1,
      question: `In ${topic}, what happens to the energy density when the field intensity is doubled?`,
      options: ['It remains constant', 'It doubles (2x)', 'It quadruples (4x)', 'It halves (1/2x)'],
      correct: 'It quadruples (4x)',
      explanation: 'Energy density scales with the square of the field intensity ($u \\propto E^2$ or $B^2$).'
    },
    {
      id: 2,
      question: `Which mathematical operator represents the circulation or vortex nature of a vector field?`,
      options: ['Gradient (\\nabla f)', 'Divergence (\\nabla \\cdot \\mathbf{F})', 'Curl (\\nabla \\times \\mathbf{F})', 'Laplacian (\\nabla^2 f)'],
      correct: 'Curl (\\nabla \\times \\mathbf{F})',
      explanation: 'The curl measures the infinitesimal rotational circulation around a point.'
    },
    {
      id: 3,
      question: 'When solving a multi-step physics/math problem, which step comes first in standard pedagogy?',
      options: ['Plugging in numerical values', 'Drawing a clean free-body / field coordinate diagram and stating assumptions', 'Guessing the answer', 'Skipping algebra'],
      correct: 'Drawing a clean free-body / field coordinate diagram and stating assumptions',
      explanation: 'Visualizing coordinates and boundary conditions prevents 80% of sign errors.'
    }
  ];

  const handleGenerateAIPath = async () => {
    setLoading(true);
    showNotification?.("Professor Clarity is analyzing your mastery gaps and generating an adaptive curriculum...", "info");
    try {
      const prompt = `You are Professor Clarity, world-class AI pedagogical architect.
Create a personalized adaptive curriculum roadmap for student: "${userName}"
Subject: "${subject}"
Current Topic: "${topic}"
Target Level: "${difficulty}"

Analyze typical student learning gaps in this topic and return a JSON object with:
{
  "studentName": "${userName}",
  "subject": "${subject}",
  "targetExam": "Board & Entrance Honors Exam",
  "overallMasteryScore": 72,
  "weakAreas": ["Specific weak subtopic 1", "Specific weak subtopic 2"],
  "strongAreas": ["Solid area 1", "Solid area 2"],
  "estimatedCompletionHours": 7.5,
  "recommendedSteps": [
    {
      "id": "step-1",
      "title": "Step 1 Title",
      "type": "concept_review",
      "durationMinutes": 45,
      "status": "completed",
      "description": "Crisp overview of what is mastered.",
      "difficulty": "Foundation",
      "keyFormulas": ["Formula 1", "Formula 2"]
    },
    {
      "id": "step-2",
      "title": "Step 2 Title",
      "type": "deep_mastery",
      "durationMinutes": 60,
      "status": "in_progress",
      "description": "Deep dive into weak areas with analogies.",
      "difficulty": "Intermediate",
      "keyFormulas": ["Formula 3"],
      "remediationTips": "Pedagogical trick or mnemonic."
    },
    {
      "id": "step-3",
      "title": "Step 3 Title",
      "type": "practice_drill",
      "durationMinutes": 50,
      "status": "locked",
      "description": "30+ Adaptive questions description",
      "difficulty": "Honors"
    },
    {
      "id": "step-4",
      "title": "Step 4 Title",
      "type": "checkpoint_quiz",
      "durationMinutes": 30,
      "status": "locked",
      "description": "Timed assessment with scoring guide",
      "difficulty": "Honors"
    },
    {
      "id": "step-5",
      "title": "Step 5 Title",
      "type": "next_topic",
      "durationMinutes": 60,
      "status": "locked",
      "description": "Seamless transition to next chapter",
      "difficulty": "Olympiad"
    }
  ],
  "revisionSchedule": [
    { "day": "Day 1 (Today)", "task": "Task 1 description" },
    { "day": "Day 3 (+48h)", "task": "Task 2 description" },
    { "day": "Day 7 (+1 Week)", "task": "Task 3 description" },
    { "day": "Day 14 (+2 Weeks)", "task": "Task 4 description" }
  ]
}
Return ONLY valid JSON with no markdown tags or wrapper text.`;

      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      if (response) {
        const cleaned = response.replace(/```json/g, '').replace(/```/g, '').trim();
        const parsed: PersonalisedPathData = JSON.parse(cleaned);
        setPathData(parsed);
        localStorage.setItem(`omni_adaptive_path_${subject}_${topic}`, JSON.stringify(parsed));
        showNotification?.("Adaptive learning path generated with precision!", "success");
      }
    } catch (e) {
      console.error(e);
      showNotification?.("Generated path using standard pedagogical model.", "info");
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteStep = (stepId: string) => {
    const updated = {
      ...pathData,
      recommendedSteps: pathData.recommendedSteps.map((s, idx, arr) => {
        if (s.id === stepId) {
          return { ...s, status: 'completed' as const };
        }
        // Unlock next step if locked
        const prevStep = arr[idx - 1];
        if (prevStep && prevStep.id === stepId && s.status === 'locked') {
          return { ...s, status: 'in_progress' as const };
        }
        return s;
      }),
      overallMasteryScore: Math.min(100, pathData.overallMasteryScore + 8)
    };
    setPathData(updated);
    localStorage.setItem(`omni_adaptive_path_${subject}_${topic}`, JSON.stringify(updated));
    showNotification?.("Step completed! Mastery increased +8%", "success");
  };

  const isDark = theme === 'dark';

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Top Banner */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
            <Brain size={22} className="animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Adaptive Curriculum Builder</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-indigo-500/10 text-indigo-500 border border-indigo-500/20">
                AI Powered
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Personalised mastery sequence for <span className="font-semibold text-indigo-400">{userName}</span> &bull; {subject} &bull; {topic}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('path')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              activeTab === 'path'
                ? "bg-indigo-600 text-white shadow-sm"
                : (isDark ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-600 hover:bg-slate-200")
            )}
          >
            <Target size={14} /> Learning Path
          </button>
          <button
            onClick={() => setActiveTab('diagnostic')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              activeTab === 'diagnostic'
                ? "bg-indigo-600 text-white shadow-sm"
                : (isDark ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-600 hover:bg-slate-200")
            )}
          >
            <BarChart3 size={14} /> Pre-Assessment
          </button>
          <button
            onClick={() => setActiveTab('revision')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              activeTab === 'revision'
                ? "bg-indigo-600 text-white shadow-sm"
                : (isDark ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-600 hover:bg-slate-200")
            )}
          >
            <Calendar size={14} /> Revision Plan
          </button>
          <button
            onClick={() => setActiveTab('style')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              activeTab === 'style'
                ? "bg-indigo-600 text-white shadow-sm"
                : (isDark ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-600 hover:bg-slate-200")
            )}
          >
            <UserCheck size={14} /> Learning Style (VARK)
          </button>
          <button
            onClick={() => setActiveTab('difficulty')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              activeTab === 'difficulty'
                ? "bg-indigo-600 text-white shadow-sm"
                : (isDark ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-600 hover:bg-slate-200")
            )}
          >
            <Gauge size={14} /> Difficulty Auto-Tuner
          </button>
          <button
            onClick={() => setShowInterestSettingsModal(true)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              isDark ? "bg-slate-800 text-pink-400 hover:bg-slate-700 border border-pink-500/20" : "bg-pink-50 text-pink-600 hover:bg-pink-100 border border-pink-200"
            )}
            title="Configure student interests for personalized examples"
          >
            <Heart size={14} className="fill-current" /> Interests
          </button>
          <button
            onClick={() => setShowPeerSocialModal(true)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              isDark ? "bg-slate-800 text-indigo-400 hover:bg-slate-700 border border-indigo-500/20" : "bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border border-indigo-200"
            )}
            title="Peer Teaching, 4-Student Study Room & Academic Debate"
          >
            <Users size={14} /> Peer Teach & Study
          </button>
          <button
            onClick={() => setShowDoubtBoardModal(true)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              isDark ? "bg-slate-800 text-amber-400 hover:bg-slate-700 border border-amber-500/20" : "bg-amber-50 text-amber-600 hover:bg-amber-100 border border-amber-200"
            )}
            title="Ask anonymous doubts for this topic without fear of judgment"
          >
            <HelpCircle size={14} /> Doubt Board
          </button>
          <button
            onClick={() => setShowStudyBuddyModal(true)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer",
              isDark ? "bg-slate-800 text-purple-400 hover:bg-slate-700 border border-purple-500/20" : "bg-purple-50 text-purple-600 hover:bg-purple-100 border border-purple-200"
            )}
            title="Find accountability study buddies matched to your velocity & strengths"
          >
            <Users size={14} /> Study Buddies
          </button>
          <button
            onClick={handleGenerateAIPath}
            disabled={loading}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
            {loading ? "Recalibrating..." : "Recalibrate AI Path"}
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Metric Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className={cn(
            "p-4 rounded-xl border flex flex-col justify-between",
            isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Overall Mastery</span>
              <Award size={16} className="text-amber-500" />
            </div>
            <div className="my-2 flex items-baseline gap-2">
              <span className="text-2xl font-black text-indigo-500">{pathData.overallMasteryScore}%</span>
              <span className="text-[11px] text-slate-400">Target: 95%+</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                style={{ width: `${pathData.overallMasteryScore}%` }}
              />
            </div>
          </div>

          <div className={cn(
            "p-4 rounded-xl border flex flex-col justify-between",
            isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Est. Time to Mastery</span>
              <Clock size={16} className="text-blue-500" />
            </div>
            <div className="my-2">
              <span className="text-2xl font-black">{pathData.estimatedCompletionHours} hrs</span>
            </div>
            <p className="text-[11px] text-slate-400">5 focused adaptive modules remaining</p>
          </div>

          <div className={cn(
            "p-4 rounded-xl border flex flex-col justify-between",
            isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <div className="flex items-center justify-between text-rose-500 text-xs font-semibold">
              <span>Identified Weak Areas</span>
              <AlertTriangle size={16} />
            </div>
            <div className="my-1 space-y-1">
              {pathData.weakAreas.map((w, idx) => (
                <div key={idx} className="text-[11px] font-bold text-rose-400 truncate flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
                  {w}
                </div>
              ))}
            </div>
            <span className="text-[10px] text-slate-500">Auto-prioritized in Step 2</span>
          </div>

          <div className={cn(
            "p-4 rounded-xl border flex flex-col justify-between",
            isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <div className="flex items-center justify-between text-emerald-500 text-xs font-semibold">
              <span>Strong Foundations</span>
              <CheckCircle2 size={16} />
            </div>
            <div className="my-1 space-y-1">
              {pathData.strongAreas.map((s, idx) => (
                <div key={idx} className="text-[11px] font-bold text-emerald-500 truncate flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                  {s}
                </div>
              ))}
            </div>
            <span className="text-[10px] text-slate-500">Skipped redundant reviews</span>
          </div>
        </div>

        {/* Tab 1: Recommended Step Progression */}
        {activeTab === 'path' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-2">
                <Zap size={16} className="text-amber-500" />
                Adaptive Sequence (Personalised to Rahul / You)
              </h3>
              <span className="text-xs text-slate-400">
                Difficulty dynamically scales with performance
              </span>
            </div>

            {/* Interest-Based Pedagogical Scenario Card */}
            <ExampleCard
              concept={{
                conceptId: topic ? topic.toLowerCase().replace(/[^a-z0-9]/g, '_') : 'electromagnetism',
                conceptTitle: topic || 'Electromagnetic Induction & Flux',
                modelFormula: '\\mathcal{E} = -\\frac{d\\Phi_B}{dt}',
                summary: 'Faraday-Lenz principle governing electromotive force induced by time-varying magnetic flux.'
              }}
              studentId={userName || 'student_default'}
              onOpenSettings={() => setShowInterestSettingsModal(true)}
            />

            {/* Explain-Back & Peer Review Prompt */}
            <ExplainBackCard
              conceptId={topic ? topic.toLowerCase().replace(/[^a-z0-9]/g, '_') : 'faradays_law'}
              conceptTitle={topic || "Faraday's Law of Electromagnetic Induction"}
              studentId={userName ? `student_${userName.toLowerCase().replace(/[^a-z0-9]/g, '_')}` : 'student_default'}
              studentName={userName || 'Alex'}
              onSubmissionSuccess={(sub) => {
                showNotification?.(`Explanation submitted! AI Score: ${sub.aiScore}/100.`, 'success');
              }}
            />

            <div className="space-y-3">
              {pathData.recommendedSteps.map((step, idx) => {
                const isCompleted = step.status === 'completed';
                const isInProgress = step.status === 'in_progress';
                const isLocked = step.status === 'locked';

                return (
                  <div 
                    key={step.id}
                    className={cn(
                      "p-4 rounded-xl border transition-all duration-200 flex flex-col md:flex-row md:items-center justify-between gap-4",
                      isCompleted 
                        ? (isDark ? "bg-slate-950/40 border-emerald-900/40 opacity-85" : "bg-emerald-50/40 border-emerald-200") 
                        : isInProgress
                          ? (isDark ? "bg-indigo-950/30 border-indigo-500 ring-1 ring-indigo-500/30" : "bg-indigo-50/60 border-indigo-300 ring-2 ring-indigo-400/20")
                          : (isDark ? "bg-slate-950/20 border-slate-800/60 opacity-60" : "bg-slate-100/60 border-slate-200 opacity-60")
                    )}
                  >
                    <div className="flex items-start gap-3.5">
                      <div className={cn(
                        "w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm shrink-0 mt-0.5",
                        isCompleted ? "bg-emerald-500 text-white" : isInProgress ? "bg-indigo-600 text-white animate-pulse" : "bg-slate-700 text-slate-300"
                      )}>
                        {isCompleted ? <CheckCircle2 size={18} /> : (idx + 1)}
                      </div>

                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h4 className="text-sm font-bold">{step.title}</h4>
                          <span className={cn(
                            "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                            step.difficulty === 'Foundation' ? "bg-blue-500/10 text-blue-500" :
                            step.difficulty === 'Intermediate' ? "bg-amber-500/10 text-amber-500" :
                            step.difficulty === 'Honors' ? "bg-purple-500/10 text-purple-500" :
                            "bg-rose-500/10 text-rose-500"
                          )}>
                            {step.difficulty}
                          </span>
                          <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                            <Clock size={11} /> {step.durationMinutes} mins
                          </span>
                        </div>

                        <p className="text-xs text-slate-400 leading-relaxed">
                          {step.description}
                        </p>

                        {step.keyFormulas && step.keyFormulas.length > 0 && (
                          <div className="flex flex-wrap gap-2 pt-1 font-mono text-[11px]">
                            {step.keyFormulas.map((f, fIdx) => (
                              <span key={fIdx} className="px-2 py-0.5 rounded bg-slate-800 text-indigo-300 border border-slate-700">
                                {f}
                              </span>
                            ))}
                          </div>
                        )}

                        {step.remediationTips && (
                          <p className="text-[11px] text-amber-400 font-semibold flex items-center gap-1 pt-1">
                            <Sparkles size={12} /> {step.remediationTips}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                      {isInProgress && (
                        <>
                          <button
                            onClick={() => onStartLesson?.(step.title, step.difficulty.toLowerCase())}
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
                          >
                            <Play size={13} /> Start Study
                          </button>
                          <button
                            onClick={() => handleCompleteStep(step.id)}
                            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-md transition-all cursor-pointer"
                          >
                            Mark Done
                          </button>
                        </>
                      )}

                      {isCompleted && (
                        <span className="text-xs font-bold text-emerald-500 flex items-center gap-1 px-3 py-1.5 bg-emerald-500/10 rounded-lg">
                          <CheckCircle2 size={14} /> Completed
                        </span>
                      )}

                      {isLocked && (
                        <span className="text-xs text-slate-500 font-medium px-3 py-1.5 bg-slate-800/40 rounded-lg">
                          Locked (Finish Step {idx})
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 2: Adaptive Prior Knowledge Diagnostic Quiz (IRT Powered) */}
        {activeTab === 'diagnostic' && (
          <div className="w-full">
            {diagnosticResult && !diagnosticResult.isSkipped ? (
              <PersonalizedPath
                result={diagnosticResult}
                onRetake={() => {
                  setDiagnosticResult(null);
                  showNotification?.("Diagnostic reset. You can take the adaptive assessment again.", "info");
                }}
                onStartLesson={(subId, title, action) => {
                  onStartLesson?.(title, 'intermediate');
                  showNotification?.(`Commencing ${title} (${action})`, 'info');
                }}
              />
            ) : (
              <DiagnosticTest
                chapterId={topic}
                chapterTitle={topic}
                subject={subject}
                studentId={userName}
                onComplete={(res) => {
                  setDiagnosticResult(res);
                  showNotification?.(`Diagnostic evaluated! You already know ${res.overallScore}% of this chapter.`, 'success');
                }}
                onSkip={() => {
                  setActiveTab('path');
                  showNotification?.("Diagnostic skipped. All topics scheduled in standard curriculum.", "info");
                }}
              />
            )}
          </div>
        )}

        {/* Tab 3: Revision Schedule */}
        {activeTab === 'revision' && (
          <div className="space-y-4 max-w-3xl">
            <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-2">
              <Calendar size={16} className="text-indigo-400" />
              Optimal Ebbinghaus Spaced Revision Schedule
            </h3>
            <p className="text-xs text-slate-400">
              Scientifically scheduled intervals (24h, 7d, 14d) to cement memory from temporary working recall into permanent neurological long-term storage.
            </p>

            <div className="space-y-3">
              {pathData.revisionSchedule.map((item, idx) => (
                <div 
                  key={idx}
                  className={cn(
                    "p-4 rounded-xl border flex items-center justify-between gap-4",
                    isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200 shadow-sm"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span className="px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      {item.day}
                    </span>
                    <span className="text-xs font-semibold">{item.task}</span>
                  </div>
                  <button
                    onClick={() => showNotification?.(`Reminder set for ${item.day}!`, 'success')}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
                  >
                    Set Reminder
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Adaptive Learning Style (VARK) */}
        {activeTab === 'style' && (
          <div className="space-y-4">
            <LearningStyleCard />
          </div>
        )}

        {/* Tab 5: Difficulty Auto-Tuner (Flow State) */}
        {activeTab === 'difficulty' && (
          <div className="space-y-4">
            <DifficultyTunerCard
              state={difficultyState}
              onSetLevel={setLevelManually}
              onReset={resetDifficulty}
              onDismissIntervention={dismissIntervention}
            />
          </div>
        )}
      </div>

      {/* Modal Overlay for InterestSettings */}
      {showInterestSettingsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <InterestSettings
            studentId={userName || 'student_default'}
            onClose={() => setShowInterestSettingsModal(false)}
            onSaved={(p) => {
              showNotification?.(`Interests updated! Examples personalized to ${p.interests.map(i => i.category).join(', ')}.`, 'success');
            }}
          />
        </div>
      )}

      {/* Modal Overlay for PeerExplanationHub */}
      {showPeerSocialModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <PeerExplanationHub
            currentStudentId={userName ? `student_${userName.toLowerCase().replace(/[^a-z0-9]/g, '_')}` : 'student_default'}
            currentStudentName={userName || 'Alex'}
            initialTopic={topic || "Faraday's Law of Electromagnetic Induction"}
            onClose={() => setShowPeerSocialModal(false)}
          />
        </div>
      )}

      {/* Modal Overlay for DoubtBoard */}
      {showDoubtBoardModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="w-full max-w-5xl my-auto animate-in fade-in zoom-in-95 duration-200">
            <DoubtBoard
              chapterId={`${subject.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${topic.toLowerCase().replace(/[^a-z0-9]/g, '_')}`}
              chapterTitle={`${subject}: ${topic}`}
              topicId={topic.toLowerCase().replace(/[^a-z0-9]/g, '_')}
              topicTitle={topic}
              isDark={isDark}
              onClose={() => setShowDoubtBoardModal(false)}
            />
          </div>
        </div>
      )}

      {/* Modal Overlay for StudyBuddyList */}
      {showStudyBuddyModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="w-full max-w-5xl my-auto animate-in fade-in zoom-in-95 duration-200">
            <StudyBuddyList
              currentSubject={subject}
              isDark={isDark}
              onClose={() => setShowStudyBuddyModal(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
};
