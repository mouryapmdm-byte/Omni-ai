import React from 'react';
import { X, Shield, Scale, FileText, AlertCircle } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: 'light' | 'dark';
}

export const TermsModal: React.FC<TermsModalProps> = ({ isOpen, onClose, theme }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className={cn(
          "relative w-full max-w-2xl max-h-[85vh] overflow-hidden rounded-3xl shadow-2xl flex flex-col animate-in zoom-in-95 duration-300",
          theme === 'dark' ? "bg-slate-900 border border-slate-800 text-slate-200" : "bg-white border border-slate-100 text-slate-800"
        )}
      >
        {/* Header */}
        <div className={cn(
          "px-6 py-5 border-b flex items-center justify-between shrink-0",
          theme === 'dark' ? "border-slate-800 bg-slate-900/50" : "border-slate-100 bg-slate-50/50"
        )}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-500">
              <Scale size={20} />
            </div>
            <div>
              <h2 className="font-black text-lg leading-tight">Terms & Conditions</h2>
              <p className="text-[11px] opacity-60 font-medium uppercase tracking-wider">Omni AI Legal Framework</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-500/10 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 scrollbar-thin scrollbar-thumb-indigo-500/20">
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-indigo-500 font-bold">
              <Shield size={16} />
              <h3>1. Acceptance of Service</h3>
            </div>
            <p className="text-sm leading-relaxed opacity-80">
              By accessing and using <strong>Omni AI</strong>, you agree to be bound by these terms. This platform is designed as an interactive educational simulator. Users must use the service responsibly and in accordance with all local and international educational standards.
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-indigo-500 font-bold">
              <FileText size={16} />
              <h3>2. AI-Generated Content Notice</h3>
            </div>
            <p className="text-sm leading-relaxed opacity-80">
              Omni AI utilizes large language models (LLMs) to provide real-time academic assistance, code generation, and curriculum translation. While we strive for absolute precision, <strong>all AI-generated content should be independently verified</strong> for accuracy. Omni AI is not liable for errors in calculation or theoretical interpretation.
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-indigo-500 font-bold">
              <AlertCircle size={16} />
              <h3>3. Prohibited Usage</h3>
            </div>
            <ul className="list-disc list-inside text-sm space-y-2 opacity-80 pl-2">
              <li>No use of Omni AI for generating deceptive or harmful academic content.</li>
              <li>No automated "scraping" or excessive API polling beyond standard educational use.</li>
              <li>No injection of malicious payloads into the interactive sandboxes or code playground.</li>
              <li>Users are prohibited from attempting to reverse-engineer the proprietary system instructions of Omni AI.</li>
            </ul>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-indigo-500 font-bold">
              <Shield size={16} />
              <h3>4. Privacy & Data Integrity</h3>
            </div>
            <p className="text-sm leading-relaxed opacity-80">
              Omni AI respects your privacy. All interactions within the sandbox are encrypted. Personal data collected via Firebase Authentication is handled according to our secure architecture, ensuring that "Read-Only" modes are enforced on shared links to prevent unauthorized data mutation.
            </p>
          </section>

          <div className={cn(
            "p-4 rounded-2xl border",
            theme === 'dark' ? "bg-indigo-500/5 border-indigo-500/20" : "bg-indigo-50 border-indigo-100"
          )}>
            <p className="text-xs italic text-center opacity-70">
              Omni AI reserves the right to suspend access to any user who violates these safety protocols. Last updated: July 2026.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className={cn(
          "px-6 py-4 border-t flex justify-end shrink-0",
          theme === 'dark' ? "border-slate-800 bg-slate-900/50" : "border-slate-100 bg-slate-50/50"
        )}>
          <button 
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-indigo-600 text-white text-sm font-bold hover:bg-indigo-500 transition-all active:scale-95 shadow-lg shadow-indigo-500/20"
          >
            I Understand & Agree
          </button>
        </div>
      </div>
    </div>
  );
};
