import React, { useState } from 'react';
import {
  GraduationCap,
  Layers,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Sparkles,
  Mic,
  Sliders,
  Check,
  Zap,
  Globe,
  HelpCircle
} from 'lucide-react';
import { EducationBoard } from '../../data/boards';
import { TeacherPedagogyStyle } from '../../data/teacherStyles';
import { ContentLoadingEstimate } from '../../utils/networkEstimation';
import { SYLLABUS_TREE } from '../SyllabusExpansionControls';
import * as SubtopicsConstants from '../../lib/constants';

export interface Virtual3DCurriculumBarProps {
  // 1. Board & University
  selectedBoard?: { nation: string; acronym: string } | null;
  onOpenBoardSelector: () => void;

  // 2. Learning Level
  difficulty?: string;
  onSelectDifficulty: (difficulty: string) => void;

  // 3. Subjects
  currentSubject?: string;
  subject?: string;
  availableSubjects?: { id: string; name: string; icon: string }[];
  onSelectSubject: (subjectId: string) => void;

  // 4. Topics and Chapters
  currentTopicTitle?: string;
  activeTopic?: string;
  onOpenTopicSelector?: () => void;
  onOpenTopicsModal?: () => void;
  onSelectTopic?: (topic: string) => void;

  // 5. Active Subject Lesson
  activeLessonNumber?: string | number;
  activeLesson?: string | number;
  availableLessons?: { id: number; title: string; subtitle?: string }[];
  onSelectLessonIndex?: (idx: number) => void;
  onSelectLesson?: (lesson: string) => void;
  onPrevLesson?: () => void;
  onNextLesson?: () => void;
  totalLessons?: number;

  // 6. Syllabus & Chapters
  onOpenSyllabusModal?: () => void;
  onOpenSyllabus?: () => void;

  // 7. AI Tools
  onOpenAiTools: () => void;

  // 8. Vocal Persona & Voice Agent
  selectedTeacherStyle?: TeacherPedagogyStyle;
  onOpenVocalPersona: () => void;

  // Loading & Network Estimation State
  isLoadingContent?: boolean;
  loadingEstimate?: ContentLoadingEstimate | null;
  loadingEstimateFormatted?: string;
  pingSpeedMs?: number;
  networkStatus?: any;

  // Visual layout state
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

const DEFAULT_SUBJECTS = [
  { id: 'physics', name: 'Physics', icon: '⚛️' },
  { id: 'chemistry', name: 'Chemistry', icon: '🧪' },
  { id: 'biology', name: 'Biology', icon: '🧬' },
  { id: 'mathematics', name: 'Mathematics', icon: '📐' }
];

const LEARNING_LEVELS = [
  { id: 'class_9', label: 'Class 9', badge: 'Secondary' },
  { id: 'class_10', label: 'Class 10 (Board)', badge: 'Secondary' },
  { id: 'class_11', label: 'Class 11', badge: 'Sr. Secondary' },
  { id: 'class_12', label: 'Class 12 (Board)', badge: 'Sr. Secondary' },
  { id: 'undergraduate', label: 'Undergraduate', badge: 'University' },
  { id: 'competitive_jee_neet', label: 'Competitive (JEE/NEET/AP)', badge: 'Competitive' }
];

export const Virtual3DCurriculumBar: React.FC<Virtual3DCurriculumBarProps> = ({
  selectedBoard,
  onOpenBoardSelector,
  difficulty = 'class_12',
  onSelectDifficulty,
  currentSubject,
  subject,
  availableSubjects = DEFAULT_SUBJECTS,
  onSelectSubject,
  currentTopicTitle,
  activeTopic,
  onOpenTopicSelector,
  onOpenTopicsModal,
  onSelectTopic,
  activeLessonNumber,
  activeLesson,
  availableLessons = [],
  onSelectLessonIndex,
  onSelectLesson,
  onPrevLesson,
  onNextLesson,
  totalLessons = 12,
  onOpenSyllabusModal,
  onOpenSyllabus,
  onOpenAiTools,
  selectedTeacherStyle,
  onOpenVocalPersona,
  isLoadingContent = false,
  loadingEstimate = null,
  loadingEstimateFormatted,
  pingSpeedMs,
  networkStatus,
  isCollapsed = false,
  onToggleCollapse
}) => {
  const resolvedTopicTitle = activeTopic || currentTopicTitle || 'Select Topic';
  const handleOpenTopics = onOpenTopicsModal || onOpenTopicSelector || (() => {});
  const handleOpenSyllabus = onOpenSyllabus || onOpenSyllabusModal || (() => {});
  const effectiveSubject = subject || currentSubject || 'physics';
  const effectiveLessonNum = activeLesson !== undefined ? String(activeLesson) : (activeLessonNumber !== undefined ? String(activeLessonNumber) : '1');

  // Compute Syllabus-based flat topics for the active subject
  const subjectSyllabus = SYLLABUS_TREE[effectiveSubject.toLowerCase()] || SYLLABUS_TREE.physics;
  const allFlatTopics = subjectSyllabus.flatMap(cat => cat.topics);

  // 1. Check if resolvedTopicTitle belongs to any specialized subtopic array from constants.ts
  const allConstants = SubtopicsConstants as Record<string, any>;
  let matchedSubtopicArray: string[] | null = null;

  for (const key in allConstants) {
    if (key.endsWith('_SUBTOPICS') && Array.isArray(allConstants[key])) {
      const arr = allConstants[key];
      const hasMatch = arr.some((t: string) => 
        t.toLowerCase() === resolvedTopicTitle.toLowerCase() ||
        resolvedTopicTitle.toLowerCase().includes(t.toLowerCase()) ||
        t.toLowerCase().includes(resolvedTopicTitle.toLowerCase())
      );
      if (hasMatch) {
        matchedSubtopicArray = arr;
        break;
      }
    }
  }

  // 2. If no specialized constants match, find the category (chapter/lesson) within SYLLABUS_TREE
  if (!matchedSubtopicArray) {
    const activeCategory = subjectSyllabus.find(cat => 
      cat.topics.some(t => 
        t.toLowerCase() === resolvedTopicTitle.toLowerCase() ||
        resolvedTopicTitle.toLowerCase().includes(t.toLowerCase()) ||
        t.toLowerCase().includes(resolvedTopicTitle.toLowerCase())
      )
    );
    if (activeCategory) {
      matchedSubtopicArray = activeCategory.topics;
    }
  }

  // 3. Fallback to all flat topics if still not found
  const finalTopicsList = matchedSubtopicArray || allFlatTopics;

  // 4. Calculate previous and next topic indices within the scoped list
  const currentTopicIndex = finalTopicsList.findIndex(t => 
    t.toLowerCase() === resolvedTopicTitle.toLowerCase() ||
    resolvedTopicTitle.toLowerCase().includes(t.toLowerCase()) ||
    t.toLowerCase().includes(resolvedTopicTitle.toLowerCase())
  );
  const prevTopic = currentTopicIndex > 0 ? finalTopicsList[currentTopicIndex - 1] : null;
  const nextTopic = currentTopicIndex >= 0 && currentTopicIndex < finalTopicsList.length - 1 ? finalTopicsList[currentTopicIndex + 1] : null;

  const [showLevelDropdown, setShowLevelDropdown] = useState(false);
  const [showSubjectDropdown, setShowSubjectDropdown] = useState(false);
  const [showLessonDropdown, setShowLessonDropdown] = useState(false);

  const activeLevelObj =
    LEARNING_LEVELS.find(l => l.id === difficulty || l.label.toLowerCase().includes(difficulty.toLowerCase())) ||
    LEARNING_LEVELS[3];

  const currentSubjectObj =
    availableSubjects.find(s => s.id === effectiveSubject) ||
    availableSubjects[0] || { id: 'physics', name: 'Physics', icon: '⚛️' };

  return (
    <div className="pointer-events-auto bg-slate-950/95 border border-indigo-500/30 shadow-2xl rounded-2xl p-1.5 sm:p-2 backdrop-blur-xl flex flex-wrap items-center justify-between gap-1.5 sm:gap-2 max-w-full select-none text-xs transition-all relative z-30">
      {/* LEFT SECTION: Board, Level, Subject */}
      <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
        {/* 1. Quick Select Board & University */}
        <button
          onClick={onOpenBoardSelector}
          className="h-7 sm:h-8 px-2.5 py-1 rounded-xl bg-gradient-to-r from-indigo-900/60 to-slate-900 hover:from-indigo-800/80 hover:to-slate-800 border border-indigo-500/40 text-white font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm group shrink-0"
          title="1. Quick Select Board & University"
        >
          <GraduationCap size={14} className="text-indigo-400 group-hover:scale-110 transition-transform" />
          <span className="font-extrabold text-indigo-200 truncate max-w-[90px] sm:max-w-[130px]">
            {selectedBoard?.acronym || 'CBSE / Univ'}
          </span>
          <span className="text-[10px] text-slate-400 font-mono">▾</span>
        </button>

        {/* 2. Learning Level */}
        <div className="relative">
          <button
            onClick={() => setShowLevelDropdown(prev => !prev)}
            className="h-7 sm:h-8 px-2 py-1 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700/80 text-slate-200 hover:text-white font-semibold flex items-center gap-1 transition-all cursor-pointer shrink-0"
            title="2. Change Learning Level"
          >
            <span className="text-xs">📊</span>
            <span className="truncate max-w-[80px] sm:max-w-[110px] text-[11px] font-bold">
              {activeLevelObj.label}
            </span>
            <ChevronDown size={12} className="text-slate-400" />
          </button>

          {showLevelDropdown && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowLevelDropdown(false)} />
              <div className="absolute top-full left-0 mt-1.5 w-52 max-h-64 sm:max-h-80 overflow-y-auto custom-scrollbar touch-pan-y overscroll-contain bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 p-1 space-y-0.5 animate-fadeIn">
                <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 sticky top-0 bg-slate-900 z-10">
                  Learning Level
                </div>
                {LEARNING_LEVELS.map(lvl => (
                  <button
                    key={lvl.id}
                    onClick={() => {
                      onSelectDifficulty(lvl.id);
                      setShowLevelDropdown(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between transition-colors cursor-pointer ${
                      activeLevelObj.id === lvl.id
                        ? 'bg-indigo-600 text-white font-bold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{lvl.label}</span>
                    {activeLevelObj.id === lvl.id && <Check size={12} />}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* 3. Syllabus & Chapters */}
        <button
          onClick={handleOpenSyllabus}
          className="h-7 sm:h-8 px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 border border-indigo-500/40 text-indigo-300 hover:text-white text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer shrink-0 shadow-sm"
          title="Open Complete Syllabus & Chapter Explorer"
        >
          <Layers size={13} className="text-indigo-400" />
          <span>Syllabus</span>
        </button>

        {/* 4. Subjects */}
        <div className="relative">
          <button
            onClick={() => setShowSubjectDropdown(prev => !prev)}
            className="h-7 sm:h-8 px-2 py-1 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700/80 text-slate-200 hover:text-white font-semibold flex items-center gap-1 transition-all cursor-pointer shrink-0"
            title="3. Switch Subject"
          >
            <span className="text-xs">{currentSubjectObj.icon}</span>
            <span className="text-[11px] font-bold capitalize">{currentSubjectObj.name}</span>
            <ChevronDown size={12} className="text-slate-400" />
          </button>

          {showSubjectDropdown && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowSubjectDropdown(false)} />
              <div className="absolute top-full left-0 mt-1.5 w-48 max-h-64 sm:max-h-80 overflow-y-auto custom-scrollbar touch-pan-y overscroll-contain bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 p-1 space-y-0.5 animate-fadeIn">
                <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 sticky top-0 bg-slate-900 z-10">
                  Choose Subject
                </div>
                {availableSubjects.map(sub => (
                  <button
                    key={sub.id}
                    onClick={() => {
                      onSelectSubject(sub.id);
                      setShowSubjectDropdown(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between transition-colors cursor-pointer ${
                      currentSubject === sub.id
                        ? 'bg-indigo-600 text-white font-bold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span className="flex items-center gap-1.5">
                      <span>{sub.icon}</span>
                      <span className="capitalize">{sub.name}</span>
                    </span>
                    {currentSubject === sub.id && <Check size={12} />}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Topic Pill Navigation */}
        <div className="flex items-center bg-slate-900 border border-slate-700/80 rounded-xl p-0.5 shrink-0 ml-1">
          <span className="text-[10px] font-bold text-slate-400 px-1.5 uppercase select-none tracking-wider border-r border-slate-800 mr-0.5">
            Topic
          </span>
          {/* Previous Topic Button */}
          <button
            type="button"
            onClick={() => prevTopic && onSelectTopic?.(prevTopic)}
            disabled={!prevTopic}
            className={`p-1 rounded-lg transition-colors flex items-center justify-center ${
              prevTopic
                ? 'text-indigo-400 hover:text-white hover:bg-slate-800 cursor-pointer'
                : 'text-slate-600 cursor-not-allowed opacity-50'
            }`}
            title={prevTopic ? `Previous Topic: ${prevTopic}` : 'No previous topic'}
          >
            <ChevronLeft size={14} />
          </button>

          {/* Current Topic Button */}
          <button
            type="button"
            onClick={handleOpenTopics}
            className="px-2 py-0.5 rounded-lg text-[11px] font-extrabold text-amber-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1 max-w-[100px] sm:max-w-[140px] md:max-w-[180px] lg:max-w-[220px]"
            title={`Current Topic: ${resolvedTopicTitle} (Click to browse topics)`}
          >
            <span className="truncate">
              {resolvedTopicTitle}
            </span>
          </button>

          {/* Next Topic Button */}
          <button
            type="button"
            onClick={() => nextTopic && onSelectTopic?.(nextTopic)}
            disabled={!nextTopic}
            className={`p-1 rounded-lg transition-colors flex items-center justify-center ${
              nextTopic
                ? 'text-indigo-400 hover:text-white hover:bg-slate-800 cursor-pointer'
                : 'text-slate-600 cursor-not-allowed opacity-50'
            }`}
            title={nextTopic ? `Next Topic: ${nextTopic}` : 'No next topic'}
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>



      {/* RIGHT SECTION: AI Tools, Vocal Persona */}
      <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
        {/* Hidden per user request: AI Tools Suite */}

        {/* 8. Vocal Persona & Voice Agent */}
        <button
          onClick={onOpenVocalPersona}
          className="h-7 sm:h-8 px-2.5 py-1 rounded-xl bg-gradient-to-r from-amber-600/30 to-violet-600/30 hover:from-amber-600/50 hover:to-violet-600/50 border border-amber-500/40 text-amber-200 hover:text-white text-[11px] font-black flex items-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-sm"
          title="8. Vocal Persona & Voice Agent Settings"
        >
          <span>{selectedTeacherStyle?.avatarIcon || '🎓'}</span>
          <span className="hidden sm:inline font-bold">{selectedTeacherStyle?.shortName || 'Professor Clarity'}</span>
          <Mic size={12} className="text-amber-300" />
        </button>

        {/* LIVE CONTENT LOADING TIMER & ESTIMATED TIME REMAINING (USER REQUEST) */}
        {isLoadingContent && (loadingEstimate || loadingEstimateFormatted) && (
          <div className="h-7 sm:h-8 px-2 py-0.5 rounded-xl bg-amber-950/90 border border-amber-500/70 text-amber-200 flex items-center gap-2 shadow-lg shadow-amber-500/10 shrink-0 animate-pulse">
            <div className="relative flex items-center justify-center shrink-0">
              <div className="w-3.5 h-3.5 rounded-full border-2 border-amber-500/30 border-t-amber-400 animate-spin" />
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono">
              {loadingEstimateFormatted ? (
                <span className="font-bold text-amber-300">{loadingEstimateFormatted}</span>
              ) : (
                <>
                  <span className="font-bold text-amber-300">⏱️ {loadingEstimate?.formattedElapsed}</span>
                  <span className="text-slate-500">|</span>
                  <span className="text-amber-100 font-medium">Est. ~{loadingEstimate?.formattedRemaining}</span>
                </>
              )}
              {pingSpeedMs && (
                <span className="text-emerald-400 text-[9px] font-bold">({pingSpeedMs}ms)</span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
