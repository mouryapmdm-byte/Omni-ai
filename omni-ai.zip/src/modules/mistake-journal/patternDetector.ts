import { Mistake, MistakeCategory, MistakePattern, WeeklyMistakeReview } from './types';
import { MISTAKE_CATEGORY_INFO } from './mistakeClassifier';

export class PatternDetector {
  /**
   * Scans mistake records and extracts recurrent cognitive traps and fatigue patterns
   */
  static detectPatterns(mistakes: Mistake[]): MistakePattern[] {
    const patterns: MistakePattern[] = [];

    if (mistakes.length === 0) return patterns;

    // 1. Group by category
    const categoryCounts: Record<string, Mistake[]> = {};
    mistakes.forEach(m => {
      if (!categoryCounts[m.mistakeType]) {
        categoryCounts[m.mistakeType] = [];
      }
      categoryCounts[m.mistakeType].push(m);
    });

    // 2. Detect high frequency category traps (e.g. Sign Error or Calculation Error)
    Object.entries(categoryCounts).forEach(([cat, list]) => {
      const catTyped = cat as MistakeCategory;
      const info = MISTAKE_CATEGORY_INFO[catTyped];
      if (list.length >= 2) {
        patterns.push({
          id: 'pat_cat_' + cat,
          type: 'recurring_mistake_type',
          title: `Recurring Pattern: ${info?.name || cat} (${list.length} occurrences)`,
          description: `You have made ${list.length} ${info?.name.toLowerCase()}s recently. This accounts for ${Math.round((list.length / mistakes.length) * 100)}% of your lost marks.`,
          count: list.length,
          subject: list[0].subject,
          chapterName: list[0].chapterName,
          severity: list.length >= 4 ? 'high' : 'medium',
          remediationSuggestion: cat === 'sign_error' 
            ? 'Always write Cartesian coordinate axes (+ / -) explicitly before applying formulas.'
            : cat === 'unit_error'
            ? 'Standardize all values into SI units (m, kg, s, J) in Step 1 of your derivation.'
            : cat === 'reading_comprehension'
            ? 'Underline keywords like "NOT", "INCORRECT", "FINAL" in the question stem.'
            : 'Double check algebraic simplification steps before picking final option.'
        });
      }
    });

    // 3. Detect Fatigue / Late Session Spike
    const slowMistakes = mistakes.filter(m => m.timeSpent > 75);
    if (slowMistakes.length >= 2) {
      patterns.push({
        id: 'pat_fatigue_spike',
        type: 'fatigue_spike',
        title: 'Cognitive Hesitation & Fatigue Spike (>75s solving time)',
        description: `${slowMistakes.length} mistakes occurred on questions where you hesitated over 75 seconds. Indecision often leads to second-guessing correct intuitions.`,
        count: slowMistakes.length,
        subject: 'Overall',
        severity: 'medium',
        remediationSuggestion: 'Apply the 60s Rule: If a clear solution path is not visible within 60 seconds, flag for Round 2 and move on.'
      });
    }

    // 4. Specific Concept Confusion (e.g. Optics sign convention or Meiosis/Mitosis)
    const opticsMistakes = mistakes.filter(m => m.chapterId === 'optics' && m.mistakeType === 'sign_error');
    if (opticsMistakes.length >= 1) {
      patterns.push({
        id: 'pat_optics_sign',
        type: 'concept_confusion',
        title: 'Optics Focal Length & Image Distance Sign Confusion',
        description: 'Frequent sign confusion between convex lens (f > 0) vs concave lens (f < 0) and virtual vs real images.',
        count: opticsMistakes.length,
        subject: 'Physics',
        chapterName: 'Ray & Wave Optics',
        severity: 'high',
        remediationSuggestion: 'Remember: Light direction is positive (+X). All distances opposite to incident ray are negative.'
      });
    }

    return patterns;
  }

  /**
   * Generates weekly review summary
   */
  static getWeeklyReview(mistakes: Mistake[]): WeeklyMistakeReview {
    const totalMistakes = mistakes.length;
    const resolvedMistakes = mistakes.filter(m => m.improved).length;

    const categoryMap: Record<string, number> = {};
    mistakes.forEach(m => {
      categoryMap[m.mistakeType] = (categoryMap[m.mistakeType] || 0) + 1;
    });

    const sortedCats = Object.entries(categoryMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([cat, count]) => {
        const catTyped = cat as MistakeCategory;
        return {
          type: catTyped,
          displayName: MISTAKE_CATEGORY_INFO[catTyped]?.name || cat,
          count,
          percentage: totalMistakes > 0 ? Math.round((count / totalMistakes) * 100) : 0,
          trend: 'improved' as const
        };
      });

    return {
      weekStartDate: new Date(Date.now() - 7 * 86400000).toLocaleDateString(),
      totalMistakes,
      resolvedMistakes,
      top3MistakeTypes: sortedCats,
      accuracyDeltaVsLastWeek: +14.5,
      recommendedFocusHours: 3
    };
  }
}
