with open('src/components/Chat.tsx', 'r') as f:
    code = f.read()

target = """              {/* Digital Math Whiteboard */}
              <button
                onClick={() => {
                  setIsWhiteboardOpen(true);
                  showNotification?.('Digital Math Whiteboard opened!', 'info');
                }}
                className={cn(
                  "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors",
                  theme === 'dark' ? "hover:bg-slate-800 text-indigo-400" : "hover:bg-slate-100 text-indigo-500"
                )}
              >
                <Edit3 size={13} />
                Math Whiteboard
              </button>

              <div className="h-px w-full bg-slate-300 dark:bg-slate-800 my-1 shrink-0" />"""

replacement = """              {/* Digital Math Whiteboard */}
              <button
                onClick={() => {
                  setIsWhiteboardOpen(true);
                  showNotification?.('Digital Math Whiteboard opened!', 'info');
                }}
                className={cn(
                  "w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors",
                  theme === 'dark' ? "hover:bg-slate-800 text-indigo-400" : "hover:bg-slate-100 text-indigo-500"
                )}
              >
                <Edit3 size={13} />
                Math Whiteboard
              </button>

              <div className="h-px w-full bg-slate-300 dark:bg-slate-800 my-1 shrink-0" />

              {/* Viewport controls */}
              <div className="px-3 py-1 space-y-2">
                {/* Width */}
                <div className="flex items-center justify-between">
                  <span className={cn("text-[10px] uppercase font-bold", theme === 'dark' ? "text-slate-500" : "text-slate-400")}>Width: {contentWidth || 100}%</span>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setContentWidth?.(prev => Math.max(70, prev - 5))} className={cn("p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700")}><ChevronLeft size={12} /></button>
                    <button onClick={() => setContentWidth?.(prev => Math.min(100, prev + 5))} className={cn("p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700")}><ChevronRight size={12} /></button>
                  </div>
                </div>
                {/* Zoom */}
                <div className="flex items-center justify-between">
                  <span className={cn("text-[10px] uppercase font-bold", theme === 'dark' ? "text-slate-500" : "text-slate-400")}>Zoom: {Math.round((zoomLevel || 1) * 100)}%</span>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setZoomLevel?.(prev => Math.max(0.7, prev - 0.05))} className={cn("p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700")}><Minus size={12} /></button>
                    <button onClick={() => setZoomLevel?.(prev => Math.min(1.3, prev + 0.05))} className={cn("p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700")}><Plus size={12} /></button>
                  </div>
                </div>
              </div>
              <div className="h-px w-full bg-slate-300 dark:bg-slate-800 my-1 shrink-0" />"""

if target in code:
    with open('src/components/Chat.tsx', 'w') as f:
        f.write(code.replace(target, replacement))
    print("Patched!")
else:
    print("Target not found")
