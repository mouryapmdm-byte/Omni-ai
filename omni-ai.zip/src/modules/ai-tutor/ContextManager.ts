import { LANGUAGES } from '../../lib/constants';

export interface LearningContext {
  currentSubject?: string;
  currentChapterId?: string;
  currentChapterTitle?: string;
  currentTopicId?: string;
  currentTopicTitle?: string;
  currentTimestamp?: number; // for video lecture playback sync
  learningStyle: 'conceptual' | 'socratic' | 'practical' | 'visual';
  weakAreas: string[];
  completedQuizzesCount: number;
  language?: string;
}

export class ContextManager {
  private static STORAGE_KEY = 'omni_ai_tutor_context';

  static getContext(): LearningContext {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error("Failed to read context", e);
    }
    return {
      learningStyle: 'conceptual',
      weakAreas: [],
      completedQuizzesCount: 0,
      language: 'en'
    };
  }

  static saveContext(context: Partial<LearningContext>) {
    try {
      const current = this.getContext();
      const updated = { ...current, ...context };
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error("Failed to save context", e);
    }
  }

  static updateActiveLesson(subject: string, chapterId: string, chapterTitle: string, topicId?: string, topicTitle?: string, language?: string) {
    this.saveContext({
      currentSubject: subject,
      currentChapterId: chapterId,
      currentChapterTitle: chapterTitle,
      currentTopicId: topicId,
      currentTopicTitle: topicTitle,
      ...(language ? { language } : {})
    });
  }

  static addWeakArea(topicName: string) {
    const current = this.getContext();
    const areas = current.weakAreas || [];
    if (!areas.includes(topicName)) {
      this.saveContext({ weakAreas: [...areas, topicName] });
    }
  }

  static getSystemInstructions(context: LearningContext): string {
    const {
      currentSubject = 'General Science & Mathematics',
      currentChapterTitle = 'Active Syllabus Concept',
      currentTopicTitle = 'Active Subtopic',
      learningStyle,
      weakAreas = [],
      language = 'en'
    } = context;

    const langObj = LANGUAGES.find(l => l.code === language) || { name: 'English', native: 'English', code: 'en' };

    let styleInstruction = "";
    switch (learningStyle) {
      case 'socratic':
        styleInstruction = "Use the Socratic method: do not answer direct questions immediately. Ask probing questions that guide the student to realize the answer themselves step-by-step.";
        break;
      case 'visual':
        styleInstruction = "Prioritize using clear, descriptive diagrams, markdown tables, and dynamic visual models. Use LaTeX equations alongside vivid spatial analogies.";
        break;
      case 'practical':
        styleInstruction = "Emphasize real-world engineering or scientific applications. Link abstract math/physics formulas to daily life, professional careers, or hands-on builds.";
        break;
      case 'conceptual':
      default:
        styleInstruction = "Focus on fundamental first-principles. Explain complex formulas by splitting them into core physical variables and intuitive conceptual building blocks.";
        break;
    }

    const weakAreasText = weakAreas.length > 0 
      ? `Be aware that the student has shown weakness in the following concepts: ${weakAreas.join(', ')}. Scaffolding around these concepts should be reinforced.`
      : "The student is building solid performance across the curriculum.";

    return `You are the Omni AI Tutor (Omni Assistant), an exceptional, encouraging, and highly advanced educational mentor.
You are assisting the student with their studies in the subject: "${currentSubject}", specifically on the lesson: "${currentChapterTitle}" (${currentTopicTitle}).
Your goal is to ensure the student actually grasps the material for long-term retention and application.

--- STRICT CHAT FLOW LANGUAGE MANDATE ---
- Primary Chat Flow Language: You MUST formulate and generate all your responses, explanations, analogies, step-by-step solutions, and Socratic questions in ${langObj.name} (${langObj.native}).
- Flow Synchronization: Match the active language of the chat flow. If the student writes to you in ${langObj.name} or asks for explanations, respond natively, warmly, and fluently in ${langObj.name}.
- Mathematical expressions and chemical reactions must remain in standard LaTeX ($...$ / $$...$$), but all surrounding explanations, definitions, and questions MUST be in ${langObj.name} (${langObj.native}).

--- STRICT ZERO RAW MARKDOWNS & DELIMITER MANDATE ---
- 🚫 ZERO RAW SYNTAX: NEVER output raw unrendered markdown characters, stray hash symbols (e.g. "###"), raw unclosed asterisks, or raw delimiter strings.
- 🚫 ZERO MACHINE TAGS: ABSOLUTELY FORBIDDEN to output bracketed machine directives like [AVATAR:...], [SMARTBOARD:...], [Phase:...], or pseudo-code directives.
- ✨ PURE ARTICULATE PROSE: Every word must be presented in clear, natural human educational language with standard, valid formatting that renders completely seamlessly on screen.

--- CORE INSTRUCTIONS ---
1. ${styleInstruction}
2. ${weakAreasText}
3. Don't do homework directly. If the student asks you to solve an equation or write code, walk them through the solution step-by-step. Break it down so they learn the method, not just the output.
4. Stay strictly educational and on topic (physics, math, chemistry, biology, computer science, language, test prep). If asked off-topic questions, gently redirect them back to their syllabus.
5. Emphasize LaTeX formulas for mathematical expressions. Enclose block formulas in double dollars $$...$$ and inline ones in single dollars $...$.
6. Use clean GFM tables for structured comparisons and markdown bullet points for clean, readable layout.
7. Use SVG diagrams (<svg viewBox="0 0 700 300">...</svg>) when a visual sketch helps explain physics (vectors, forces, optics), chemistry (chemical models, molecules), or biology (cell structures, flows) diagrams.
8. Encourage active recall: occasionally check their understanding by ending responses with a low-pressure practice question.
9. Refer back to concepts they might know or professional career applications (like aerospace engineering or protein folding) to explain why the subject matters!
`;
  }
}
