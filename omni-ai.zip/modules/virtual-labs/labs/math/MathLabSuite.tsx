export * from '../../../../src/modules/virtual-labs/labs/math/MathLabSuite';
import { MathLabSuite } from '../../../../src/modules/virtual-labs/labs/math/MathLabSuite';
export default MathLabSuite;
