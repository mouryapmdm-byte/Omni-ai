import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence, Reorder } from 'motion/react';
import { CONFIG } from '@/src/lib/constants';
import { truncate, formatDuration, timeAgo, safeJsonStringify, downloadFileFromUrl, extractYouTubeId } from '@/src/lib/utils';
import { preProcessVideoSource, getPlaybackDiagnostics, PlaybackDiagnostic } from '@/src/lib/videoHealth';
import { useMediaErrorMonitor } from '@/src/lib/mediaErrorMonitor';
import { MediaRecoveryPanel } from './MediaRecoveryPanel';
import { cacheVideoFragment, getCachedVideoFragment } from '@/src/lib/lectureCache';
import { useAdaptiveBitrate } from '@/src/lib/adaptiveBitrate';
import { setActiveVideoPlayerInstance, VideoPlayerHandle } from './VideoWithOverlay';
import { generateAIResponse, Type } from '@/src/lib/gemini';
import { 
  Play, Globe, ExternalLink, Search, Sparkles, Loader2, Plus, 
  ThumbsUp, ThumbsDown, Share2, Download, Bell, User, Flame, 
  Compass, Clock, Heart, ArrowLeft, Send, CheckCircle2, Tv, 
  Menu, Info, Video as VideoIcon, BookOpen, GraduationCap, 
  MessageSquare, Star, AlertCircle, RefreshCw, ShieldAlert,
  Bookmark, FileText, FastForward, Sliders, X, Check, ListFilter, Tag, Zap, Trash2, Keyboard,
  FolderPlus, ListVideo, Folder, Edit3, PlayCircle, Layers, SkipForward, SkipBack, MoreVertical, ChevronUp, ChevronDown,
  GripVertical, Move, Calendar, Printer, FileJson, Filter, SlidersHorizontal, Award, BrainCircuit, Upload,
  Copy, Mail
} from 'lucide-react';

export interface AITags {
  subject: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  concepts: string[];
  summary?: string;
  taggedAt?: string;
}

export interface Video {
  id: string;
  title: string;
  source: string;
  duration: string;
  thumbnail: string;
  url: string;
  channelTitle: string;
  viewCount: number;
  publishedAt: Date;
  youtubeId?: string;
  isAIGenerated?: boolean;
  topic?: string;
  subject?: string;
  prompt?: string;
  subscribers?: string;
  likes?: number;
  description?: string;
  events?: { timestamp: number; event: string }[];
  aiTags?: AITags;
}

export const DEFAULT_AI_TAGS: Record<string, AITags> = {
  'WUvTyaaNkzM': {
    subject: 'Mathematics',
    difficulty: 'Beginner',
    concepts: ['Calculus Intuition', 'Limits', 'Instantaneous Velocity', 'Derivatives'],
    summary: 'Introduction to calculus, limits, and rates of change through geometric intuition.',
    taggedAt: new Date().toISOString()
  },
  'fNk_zzaMoEs': {
    subject: 'Mathematics',
    difficulty: 'Beginner',
    concepts: ['Vector Spaces', 'Linear Combinations', 'Coordinate Systems', 'Physics Vectors'],
    summary: 'Foundational breakdown bridging physics arrows, computer science arrays, and algebraic vector spaces.',
    taggedAt: new Date().toISOString()
  },
  'z68b8b9kO6s': {
    subject: 'Geometry',
    difficulty: 'Beginner',
    concepts: ['Cartesian Plane', 'Ordered Pairs', 'Quadrants', 'Coordinate Axes'],
    summary: 'Essentials of plotting coordinates, ordered pairs, and quadrant navigation.',
    taggedAt: new Date().toISOString()
  },
  'S8FnbK2DCHc': {
    subject: 'Trigonometry',
    difficulty: 'Beginner',
    concepts: ['Sine & Cosine', 'Right Triangles', 'Trigonometric Ratios', 'Hypotenuse'],
    summary: 'Introduction to right triangle side ratios and core trigonometric identities.',
    taggedAt: new Date().toISOString()
  },
  'KP2bDLnPl0Y': {
    subject: 'Algebra',
    difficulty: 'Beginner',
    concepts: ['Multi-Step Equations', 'Equation Balancing', 'Variable Isolation', 'Linear Terms'],
    summary: 'Step-by-step techniques for balancing algebraic equations with variables on both sides.',
    taggedAt: new Date().toISOString()
  },
  'uhxtUt_-GyM': {
    subject: 'Statistics',
    difficulty: 'Intermediate',
    concepts: ['Data Misinterpretation', 'Statistical Bias', 'Sample Size', 'Graph Manipulation'],
    summary: 'Critical evaluation of statistical charts, sampling errors, and media manipulation techniques.',
    taggedAt: new Date().toISOString()
  },
  '8idr1WZ1A7Q': {
    subject: 'Probability',
    difficulty: 'Intermediate',
    concepts: ['Combinatorics', 'Pigeonhole Principle', 'Probability Paradox', 'Complementary Events'],
    summary: 'Mathematical analysis of counter-intuitive birthday collisions using complementary probability.',
    taggedAt: new Date().toISOString()
  },
  'A7K_d9qZ-bE': {
    subject: 'Probability',
    difficulty: 'Intermediate',
    concepts: ['Conditional Probability', 'Bayes Theorem', 'Decision Trees', 'Game Theory'],
    summary: 'Rigorous proof of conditional probability and switching strategies in the classic 3-door puzzle.',
    taggedAt: new Date().toISOString()
  },
  'W3ZCO_U6Z0M': {
    subject: 'Calculus',
    difficulty: 'Intermediate',
    concepts: ['Chain Rule', 'Composite Functions', 'Backpropagation', 'Function Composition'],
    summary: 'Visualizing rate multipliers and derivative chain rules for nested functions.',
    taggedAt: new Date().toISOString()
  },
  '9vKqVkSX2Sg': {
    subject: 'Calculus',
    difficulty: 'Advanced',
    concepts: ['Taylor Series', 'Polynomial Approximation', 'Power Series', 'Convergence'],
    summary: 'Approximating complex transcendental functions with infinite polynomial series.',
    taggedAt: new Date().toISOString()
  },
  'mH0oY017oA8': {
    subject: 'Mathematics',
    difficulty: 'Beginner',
    concepts: ['Pattern Recognition', 'Applied Mathematics', 'Natural Symmetries', 'Mathematical Modeling'],
    summary: 'Exploration of universal mathematical patterns across nature, physics, and human design.',
    taggedAt: new Date().toISOString()
  },
  'ai_dna_featured': {
    subject: 'Biology',
    difficulty: 'Intermediate',
    concepts: ['DNA Replication', 'Helicase & Polymerase', 'Base Pairing', 'Molecular Genetics'],
    summary: '3D molecular visualization of helicase unwinding and DNA strand elongation.',
    taggedAt: new Date().toISOString()
  }
};

export interface Playlist {
  id: string;
  name: string;
  description: string;
  color: string;
  videoIds: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PlaylistRecommendation {
  id: string;
  title: string;
  channelTitle: string;
  duration: string;
  thumbnail: string;
  url: string;
  youtubeId?: string;
  subject: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  concepts: string[];
  description: string;
  reason: string;
}

const DEFAULT_PLAYLISTS: Playlist[] = [
  {
    id: 'pl_calculus',
    name: 'Calculus & Analysis Masterclass',
    description: 'Essential derivatives, limits, and integral visual breakdowns by 3Blue1Brown and Omni AI',
    color: 'indigo',
    videoIds: ['WUvTyaaNkzM', 'W3ZCO_U6Z0M', '9vKqVkSX2Sg', 'ai_dna_featured'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pl_revision',
    name: 'High-Priority Exam Revision',
    description: 'Quick-check core math & science concept summaries for test preparation',
    color: 'emerald',
    videoIds: ['fNk_zzaMoEs', 'KP2bDLnPl0Y', 'uhxtUt_-GyM'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

interface VideoGridProps {
  topic: string;
  subject: string;
  difficulty: string;
  region: string;
  onPlay: (video: Video) => void;
  onGenerateVideo: (prompt: string) => Promise<string | undefined>;
  externalGeneratedVideos?: Video[];
  onUpdateVideos?: (videos: Video[]) => void;
}

const REAL_YOUTUBE_VIDEOS = [
  { id: 'WUvTyaaNkzM', title: 'The Essence of Calculus, Chapter 1', channel: '3Blue1Brown', duration: '17:05', views: 7800000, subscribers: '5.2M', description: 'What is calculus, and why is it so incredibly useful? We explore the central intuition of limits, derivatives, and integrals through dynamic geometric visual representations.' },
  { id: 'fNk_zzaMoEs', title: 'The Essence of Linear Algebra: Vectors', channel: '3Blue1Brown', duration: '9:52', views: 5200000, subscribers: '5.2M', description: 'What is a vector? We bridge the gap between the physics perspective (arrows pointing in space), the computer science perspective (lists of numbers), and the algebraic abstraction.' },
  { id: 'z68b8b9kO6s', title: 'Introduction to Coordinate Geometry & Cartesian Plane', channel: 'Math Antics', duration: '11:42', views: 3600000, subscribers: '3.4M', description: 'An introduction to coordinate grids, plotting ordered pairs, the x-axis, the y-axis, and the four mathematical quadrants explained with clean, simple animations.' },
  { id: 'S8FnbK2DCHc', title: 'Trigonometry Foundations & Ratio Calculations', channel: 'Math Antics', duration: '13:04', views: 6100000, subscribers: '3.4M', description: 'Trigonometry is the study of triangles! Let\'s learn about opposite, adjacent, and hypotenuse sides, and discover the ratios of Sine, Cosine, and Tangent.' },
  { id: 'KP2bDLnPl0Y', title: 'Algebra Essentials: Solving Multi-Step Equations', channel: 'Math Antics', duration: '12:50', views: 2700000, subscribers: '3.4M', description: 'How do you solve equations with multiple variables on both sides? This tutorial walks through algebraic balancing step-by-step with simple-to-follow diagrams.' },
  { id: 'uhxtUt_-GyM', title: 'How to Spot Misleading Statistics in Real Media', channel: 'TED-Ed', duration: '4:55', views: 1800000, subscribers: '18.9M', description: 'Every single day, we are bombarded with statistics, graphs, and percentages. How can you separate genuine scientific breakthroughs from clever media manipulation? Let\'s find out.' },
  { id: '8idr1WZ1A7Q', title: 'The Birthday Paradox: A Mathematical Deep-Dive', channel: 'Numberphile', duration: '8:04', views: 4200000, subscribers: '4.3M', description: 'In a room of just 23 people, there is a 50.7% chance that two of them share a birthday. Why does this probability seem so counter-intuitive? Let\'s crunch the numbers.' },
  { id: 'A7K_d9qZ-bE', title: 'The Monty Hall Problem: Let\'s Make a Deal Probability', channel: 'Numberphile', duration: '9:14', views: 5900000, subscribers: '4.3M', description: 'Should you switch doors? The classic Monty Hall puzzle that confounded even professional statisticians. We prove the mathematical solution with absolute clarity.' },
  { id: 'W3ZCO_U6Z0M', title: 'Visualizing the Chain Rule for Derivatives Intuitive Calculus', channel: '3Blue1Brown', duration: '16:32', views: 2400000, subscribers: '5.2M', description: 'How do composite functions change? We look at why multiplying derivatives together works, and build a powerful mental model for calculus and machine learning backpropagation.' },
  { id: '9vKqVkSX2Sg', title: 'Taylor Series & Polynomial Approximations', channel: '3Blue1Brown', duration: '22:15', views: 1900000, subscribers: '5.2M', description: 'Taylor series are a way to represent smooth functions as infinite polynomials. Learn the geometric logic behind why this works and why it\'s a cornerstone of engineering calculations.' },
  { id: 'mH0oY017oA8', title: 'Math is the Hidden Secret to Understanding the World', channel: 'TED-Ed', duration: '17:21', views: 9500000, subscribers: '18.9M', description: 'Mathematics isn\'t just about formulas on a board. It is the language of nature, patterns, architecture, and human behavior. Explore the poetry of math.' }
];

interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  time: string;
  likes: number;
  isVerified?: boolean;
}

const DEFAULT_COMMENTS_BY_VIDEO: Record<string, Comment[]> = {
  default: [
    { id: 'c1', author: 'Alex Rivera', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&h=80&q=80', content: 'This visual explanation made it click immediately. Why didn\'t my high school teacher show me this?', time: '3 days ago', likes: 242 },
    { id: 'c2', author: 'Sophia Chen', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=80&h=80&q=80', content: 'The graphics are top-tier. I love how intuitive everything feels. Subscribed instantly!', time: '1 week ago', likes: 89 },
    { id: 'c3', author: 'Marcus Brody', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=80&h=80&q=80', content: 'Could anyone clarify the difference at 04:15? Is it always a continuous mapping or just in this specific domain?', time: '5 days ago', likes: 14 }
  ]
};

export const VideoGrid: React.FC<VideoGridProps> = ({
  topic,
  subject,
  difficulty,
  region,
  onPlay,
  onGenerateVideo,
  externalGeneratedVideos,
  onUpdateVideos
}) => {
  // Navigation & View State
  const [activeVideo, setActiveVideo] = useState<Video | null>(null);
  const [currentVideoSrc, setCurrentVideoSrc] = useState<string>('');
  const videoElementRef = useRef<HTMLVideoElement | null>(null);

  const monitor = useMediaErrorMonitor({
    componentId: 'VideoGridPlayer',
    initialSrc: activeVideo ? (activeVideo.url || '') : '',
    fallbackSrc: "/api/proxy-video",
    onSourceChange: (newSrc) => setCurrentVideoSrc(newSrc)
  });

  const abr = useAdaptiveBitrate({
    videoElementRef,
    onQualityChange: (quality, streamUrl) => {
      setCurrentVideoSrc(streamUrl);
    }
  });

  const playbackError = monitor.playbackError;
  const initFailCount = monitor.retryCount;
  const autoFallbackNotice = monitor.recoveryNotice;
  const gridDiagnosticReport = monitor.diagnosticReport;

  const setPlaybackError = (val: string | null) => {
    if (val === null) {
      monitor.resetMonitor();
    }
  };
  const setGridDiagnosticReport = (val: any) => {
    if (val === null) {
      monitor.resetMonitor();
    }
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedChip, setSelectedChip] = useState('All');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareWithTimestamp, setShareWithTimestamp] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');

  // Upload Video Modal & Form States
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadLogs, setUploadLogs] = useState<string[]>([]);
  
  const [uploadForm, setUploadForm] = useState({
    title: '',
    creator: 'Professor Clarity',
    subject: subject ? subject.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) : 'Mathematics',
    difficulty: 'Intermediate' as 'Beginner' | 'Intermediate' | 'Advanced',
    description: '',
    duration: '',
    customTags: '',
    videoUrl: '', // For direct link
    useLocalFile: true,
  });

  const [uploadedVideoFile, setUploadedVideoFile] = useState<File | null>(null);
  const [uploadedThumbnailFile, setUploadedThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreviewUrl, setThumbnailPreviewUrl] = useState<string>('');

  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedVideoFile(file);
      // Auto-extract title if empty
      const titleWithoutExt = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
      setUploadForm(prev => ({
        ...prev,
        title: prev.title || titleWithoutExt.replace(/[-_]/g, ' ')
      }));

      // Auto-detect duration
      const tempVideo = document.createElement('video');
      tempVideo.preload = 'metadata';
      tempVideo.src = URL.createObjectURL(file);
      tempVideo.onloadedmetadata = () => {
        const totalSeconds = Math.round(tempVideo.duration);
        const mins = Math.floor(totalSeconds / 60);
        const secs = totalSeconds % 60;
        const formatted = `${mins}:${secs < 10 ? '0' : ''}${secs}`;
        setUploadForm(prev => ({
          ...prev,
          duration: formatted
        }));
        // Revoke to avoid leaks
        URL.revokeObjectURL(tempVideo.src);
      };
    }
  };

  const handleThumbnailFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedThumbnailFile(file);
      const url = URL.createObjectURL(file);
      setThumbnailPreviewUrl(url);
    }
  };

  const getSubjectDefaultThumbnail = (subj: string) => {
    const s = subj.toLowerCase();
    if (s.includes('math') || s.includes('calculus') || s.includes('algebra') || s.includes('geometry') || s.includes('trig')) {
      return 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=640&h=360&q=80';
    }
    if (s.includes('physic') || s.includes('astronomy') || s.includes('quantum') || s.includes('mechanic')) {
      return 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=640&h=360&q=80';
    }
    if (s.includes('chem') || s.includes('periodic') || s.includes('molecule') || s.includes('reaction')) {
      return 'https://images.unsplash.com/photo-1532187643603-ba119ca4109e?auto=format&fit=crop&w=640&h=360&q=80';
    }
    if (s.includes('biolog') || s.includes('dna') || s.includes('cell') || s.includes('genetic') || s.includes('anatomy')) {
      return 'https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?auto=format&fit=crop&w=640&h=360&q=80';
    }
    if (s.includes('code') || s.includes('computer') || s.includes('program') || s.includes('tech') || s.includes('software')) {
      return 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=640&h=360&q=80';
    }
    return 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=640&h=360&q=80';
  };

  const handlePublishUploadedVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadForm.title.trim()) return;

    let finalVideoUrl = '';
    let finalThumbnailUrl = '';

    setIsUploading(true);
    setUploadProgress(5);
    setUploadLogs(["Reading video metadata & formatting descriptors..."]);

    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      setUploadProgress(25);
      setUploadLogs(prev => [...prev, "Ingesting video buffer stream..."]);

      if (uploadForm.useLocalFile && uploadedVideoFile) {
        finalVideoUrl = URL.createObjectURL(uploadedVideoFile);
        // Cache original uploaded raw file in IndexedDB for session-persistence
        await cacheVideoFragment(finalVideoUrl, uploadedVideoFile);
      } else {
        finalVideoUrl = uploadForm.videoUrl.trim() || 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4';
      }

      await new Promise(resolve => setTimeout(resolve, 1000));
      setUploadProgress(55);
      setUploadLogs(prev => [...prev, "Processing high-definition thumbnail rendering..."]);

      if (uploadedThumbnailFile) {
        finalThumbnailUrl = thumbnailPreviewUrl;
      } else {
        finalThumbnailUrl = getSubjectDefaultThumbnail(uploadForm.subject);
      }

      await new Promise(resolve => setTimeout(resolve, 800));
      setUploadProgress(75);
      setUploadLogs(prev => [...prev, "Parsing academic taxonomy with Google Gemini AI..."]);

      // Parse tags
      const splitTags = uploadForm.customTags
        .split(',')
        .map(t => t.trim())
        .filter(t => t.length > 0);
      const finalTags = splitTags.length > 0 ? splitTags : [uploadForm.subject, 'Custom Lesson'];

      await new Promise(resolve => setTimeout(resolve, 600));
      setUploadProgress(95);
      setUploadLogs(prev => [...prev, "Finalizing sync with EduTube video library..."]);

      await new Promise(resolve => setTimeout(resolve, 400));
      setUploadProgress(100);

      const generatedId = `upload_${Date.now()}`;
      const isYt = extractYouTubeId(finalVideoUrl);

      const newUploadedVideo: Video = {
        id: generatedId,
        title: uploadForm.title.trim(),
        source: uploadForm.useLocalFile ? 'Local Upload' : 'External Link',
        duration: uploadForm.duration.trim() || '5:00',
        thumbnail: finalThumbnailUrl,
        url: finalVideoUrl,
        channelTitle: uploadForm.creator.trim() || 'Professor Clarity',
        viewCount: 0,
        publishedAt: new Date(),
        youtubeId: isYt || undefined,
        isAIGenerated: false,
        topic: uploadForm.subject,
        subject: uploadForm.subject,
        description: uploadForm.description.trim() || `Syllabus lecture uploaded by user covering ${uploadForm.subject}.`,
        likes: 0,
        subscribers: '1 Subscriber',
        aiTags: {
          subject: uploadForm.subject,
          difficulty: uploadForm.difficulty,
          concepts: finalTags,
          summary: uploadForm.description.trim() || `User-uploaded class lecture for ${uploadForm.subject}.`,
          taggedAt: new Date().toISOString()
        }
      };

      // Update parent list
      const updatedList = [newUploadedVideo, ...generatedVideos];
      setGeneratedVideos(updatedList);

      // Save to localStorage
      if (!onUpdateVideos) {
        localStorage.setItem('omni_ai_generated_videos', safeJsonStringify(updatedList));
      }

      // Automatically register the tags in our local taxonomy map
      setVideoAITagsMap(prev => ({
        ...prev,
        [generatedId]: newUploadedVideo.aiTags!
      }));

      // Play the newly uploaded video immediately
      setActiveVideo(newUploadedVideo);

      // Reset states
      setUploadForm({
        title: '',
        creator: 'Professor Clarity',
        subject: subject ? subject.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) : 'Mathematics',
        difficulty: 'Intermediate',
        description: '',
        duration: '',
        customTags: '',
        videoUrl: '',
        useLocalFile: true,
      });
      setUploadedVideoFile(null);
      setUploadedThumbnailFile(null);
      setThumbnailPreviewUrl('');
      setIsUploading(false);
      setIsUploadModalOpen(false);

    } catch (err) {
      console.error("Video Upload Error:", err);
      setIsUploading(false);
    }
  };

  // Playlists State
  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    try {
      const saved = localStorage.getItem('omni_ai_playlists');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Error loading playlists from localStorage", e);
    }
    return DEFAULT_PLAYLISTS;
  });

  // AI Auto-Tagging & Taxonomy State
  const [videoAITagsMap, setVideoAITagsMap] = useState<Record<string, AITags>>(() => {
    try {
      const saved = localStorage.getItem('omni_ai_video_tags');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return { ...DEFAULT_AI_TAGS, ...parsed };
        }
      }
    } catch (e) {
      console.error("Error loading video AI tags from localStorage", e);
    }
    return DEFAULT_AI_TAGS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('omni_ai_video_tags', safeJsonStringify(videoAITagsMap));
    } catch (e) {
      console.error("Error saving video AI tags to localStorage", e);
    }
  }, [videoAITagsMap]);

  const [isAutoTaggingPlaylist, setIsAutoTaggingPlaylist] = useState<string | null>(null);
  const [autoTagProgressMsg, setAutoTagProgressMsg] = useState<string>('');
  const [editingTagsVideo, setEditingTagsVideo] = useState<Video | null>(null);
  const [customConceptInput, setCustomConceptInput] = useState('');
  
  // Playlist Tag Filters
  const [tagFilterDifficulty, setTagFilterDifficulty] = useState<string>('All');
  const [tagFilterSubject, setTagFilterSubject] = useState<string>('All');
  const [tagFilterConcept, setTagFilterConcept] = useState<string | null>(null);

  // Get tags for a video with fallback
  const getVideoTags = (video: Video): AITags => {
    if (video.aiTags) return video.aiTags;
    if (videoAITagsMap[video.id]) return videoAITagsMap[video.id];
    if (video.youtubeId && videoAITagsMap[video.youtubeId]) return videoAITagsMap[video.youtubeId];
    if (DEFAULT_AI_TAGS[video.id]) return DEFAULT_AI_TAGS[video.id];
    if (video.youtubeId && DEFAULT_AI_TAGS[video.youtubeId]) return DEFAULT_AI_TAGS[video.youtubeId];

    return {
      subject: video.subject || video.topic || 'Mathematics',
      difficulty: 'Intermediate',
      concepts: [video.topic || 'Core Concept', 'Syllabus Lesson'],
      summary: video.description ? truncate(video.description, 90) : 'Educational video lesson.',
      taggedAt: new Date().toISOString()
    };
  };

  // AI Auto-Tag Single Video Handler using Gemini
  const handleAutoTagSingleVideo = async (video: Video): Promise<AITags> => {
    try {
      const prompt = `Analyze this educational video lesson metadata and classify it accurately:
Video Title: "${video.title}"
Channel: "${video.channelTitle}"
Description: "${video.description || ''}"
Subject/Topic Context: "${video.subject || video.topic || 'General STEM'}"

Produce structured JSON matching:
- subject: Academic subject matter (e.g. Mathematics, Calculus, Algebra, Geometry, Trigonometry, Physics, Biology, Chemistry, Computer Science, Statistics, Probability)
- difficulty: Exactly one of "Beginner", "Intermediate", "Advanced"
- concepts: Array of 3 to 5 key educational concepts or skill topics covered in this video (short 1-3 word phrases)
- summary: A 1-sentence concise educational takeaway of what students learn from this lesson.`;

      const rawText = await generateAIResponse(prompt, {
        model: 'gemini-3.6-flash',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: { type: Type.STRING },
            difficulty: { type: Type.STRING },
            concepts: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            summary: { type: Type.STRING }
          },
          required: ['subject', 'difficulty', 'concepts', 'summary']
        }
      });

      const parsed = JSON.parse(rawText);
      const validDifficulty = (['Beginner', 'Intermediate', 'Advanced'].includes(parsed.difficulty))
        ? parsed.difficulty
        : 'Intermediate';

      const newTags: AITags = {
        subject: parsed.subject || video.subject || 'Mathematics',
        difficulty: validDifficulty as 'Beginner' | 'Intermediate' | 'Advanced',
        concepts: Array.isArray(parsed.concepts) && parsed.concepts.length > 0 ? parsed.concepts : ['Core Concepts'],
        summary: parsed.summary || 'Educational video lesson.',
        taggedAt: new Date().toISOString()
      };

      setVideoAITagsMap(prev => ({
        ...prev,
        [video.id]: newTags,
        ...(video.youtubeId ? { [video.youtubeId]: newTags } : {})
      }));

      return newTags;
    } catch (err) {
      console.error("AI Auto-Tag Error:", err);
      const fallback = getVideoTags(video);
      return fallback;
    }
  };

  // AI Auto-Tag Playlist Handler using Gemini
  const handleAutoTagPlaylist = async (playlist: Playlist) => {
    const targetVideos = playlist.videoIds
      .map(id => allVideos.find(v => v.id === id))
      .filter((v): v is Video => Boolean(v));

    if (targetVideos.length === 0) return;

    setIsAutoTaggingPlaylist(playlist.id);
    setAutoTagProgressMsg(`Initializing Gemini AI analysis for ${targetVideos.length} video lessons...`);

    try {
      for (let i = 0; i < targetVideos.length; i++) {
        const vid = targetVideos[i];
        setAutoTagProgressMsg(`AI Auto-Tagging (${i + 1}/${targetVideos.length}): "${truncate(vid.title, 32)}"...`);
        await handleAutoTagSingleVideo(vid);
      }
      
      const now = new Date().toISOString();
      setPlaylists(prev => prev.map(p => p.id === playlist.id ? { ...p, updatedAt: now } : p));
      
      setAutoTagProgressMsg(`✨ AI Auto-Tagging Complete! Generated concept & difficulty tags for ${targetVideos.length} lessons.`);
      setTimeout(() => {
        setIsAutoTaggingPlaylist(null);
        setAutoTagProgressMsg('');
      }, 3500);
    } catch (err) {
      console.error("Error auto-tagging playlist:", err);
      setIsAutoTaggingPlaylist(null);
      setAutoTagProgressMsg('');
    }
  };

  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [videoForPlaylistModal, setVideoForPlaylistModal] = useState<Video | null>(null);
  const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false);
  const [editingPlaylist, setEditingPlaylist] = useState<Playlist | null>(null);
  const [exportPlaylistModal, setExportPlaylistModal] = useState<Playlist | null>(null);
  const [copiedSummary, setCopiedSummary] = useState(false);
  
  // Recommended Based on Playlist State
  const [playlistRecommendationsMap, setPlaylistRecommendationsMap] = useState<Record<string, PlaylistRecommendation[]>>(() => {
    try {
      const saved = localStorage.getItem('omni_ai_playlist_recommendations');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch (e) {
      console.error("Error loading playlist recommendations from localStorage", e);
    }
    return {};
  });
  const [loadingRecommendationsFor, setLoadingRecommendationsFor] = useState<string | null>(null);
  const [addedRecNotice, setAddedRecNotice] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('omni_ai_playlist_recommendations', safeJsonStringify(playlistRecommendationsMap));
    } catch (e) {
      console.error("Error saving playlist recommendations to localStorage", e);
    }
  }, [playlistRecommendationsMap]);

  // Fetch AI Recommendations based on aggregate playlist metadata
  const fetchPlaylistRecommendations = async (playlist: Playlist, forceRefresh = false) => {
    if (!forceRefresh && playlistRecommendationsMap[playlist.id] && playlistRecommendationsMap[playlist.id].length > 0) {
      return;
    }

    setLoadingRecommendationsFor(playlist.id);

    const plVideos = playlist.videoIds
      .map(id => allVideos.find(v => v.id === id || v.youtubeId === id))
      .filter((v): v is Video => Boolean(v));

    const metadataSummary = plVideos.map(v => {
      const tags = getVideoTags(v);
      return `- Title: "${v.title}" | Channel: "${v.channelTitle}" | Subject: "${tags.subject}" | Level: "${tags.difficulty}" | Concepts: ${tags.concepts.join(', ')}`;
    }).join('\n');

    const prompt = `You are an expert AI curriculum designer and educational tutor.
Analyze the aggregate metadata, subjects, difficulty levels, and concept coverage of all videos in this user playlist:

Playlist Name: "${playlist.name}"
Playlist Description: "${playlist.description}"
Videos currently in playlist (${plVideos.length} items):
${metadataSummary || 'None (Empty playlist)'}

Based on this aggregate data, generate exactly 3 NEW, RELEVANT educational video suggestions that logically expand, complement, or fill conceptual gaps in this playlist.

For each video, output:
- title: Engaging, clear educational title
- channelTitle: Educational channel name (e.g. 3Blue1Brown, Khan Academy, MIT OpenCourseWare, Numberphile, TED-Ed, StatQuest, CrashCourse, Omni AI Tutor)
- duration: Video length e.g. "14:20"
- subject: Academic subject
- difficulty: Exactly one of "Beginner", "Intermediate", "Advanced"
- concepts: Array of 3-4 key concept tags
- description: 1-2 sentence overview of the video lesson
- reason: 1 succinct, specific sentence explaining WHY this video is recommended based on the aggregate metadata of the current playlist
- matchedYoutubeId: Pick one matching real Youtube ID from ['WUvTyaaNkzM', 'fNk_zzaMoEs', 'z68b8b9kO6s', 'S8FnbK2DCHc', 'KP2bDLnPl0Y', 'uhxtUt_-GyM', '8idr1WZ1A7Q', 'A7K_d9qZ-bE', 'W3ZCO_U6Z0M', '9vKqVkSX2Sg', 'mH0oY017oA8'] that aligns best with the topic tone.`;

    try {
      const rawText = await generateAIResponse(prompt, {
        model: 'gemini-3.6-flash',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  channelTitle: { type: Type.STRING },
                  duration: { type: Type.STRING },
                  subject: { type: Type.STRING },
                  difficulty: { type: Type.STRING },
                  concepts: { type: Type.ARRAY, items: { type: Type.STRING } },
                  description: { type: Type.STRING },
                  reason: { type: Type.STRING },
                  matchedYoutubeId: { type: Type.STRING }
                },
                required: ['title', 'channelTitle', 'duration', 'subject', 'difficulty', 'concepts', 'description', 'reason']
              }
            }
          },
          required: ['recommendations']
        }
      });

      const parsed = JSON.parse(rawText);
      const rawList = parsed.recommendations || [];

      const thumbnails = [
        'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=640&h=360&q=80',
        'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=640&h=360&q=80',
        'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=640&h=360&q=80'
      ];

      const mappedRecs: PlaylistRecommendation[] = rawList.map((item: any, idx: number) => {
        const validYt = ['WUvTyaaNkzM', 'fNk_zzaMoEs', 'z68b8b9kO6s', 'S8FnbK2DCHc', 'KP2bDLnPl0Y', 'uhxtUt_-GyM', '8idr1WZ1A7Q', 'A7K_d9qZ-bE', 'W3ZCO_U6Z0M', '9vKqVkSX2Sg', 'mH0oY017oA8'];
        const ytId = item.matchedYoutubeId && validYt.includes(item.matchedYoutubeId)
          ? item.matchedYoutubeId
          : validYt[idx % validYt.length];

        const thumb = ytId
          ? `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg`
          : thumbnails[idx % thumbnails.length];

        const validDiff = (['Beginner', 'Intermediate', 'Advanced'].includes(item.difficulty))
          ? item.difficulty
          : 'Intermediate';

        return {
          id: `rec_${playlist.id}_${Date.now()}_${idx}`,
          title: item.title,
          channelTitle: item.channelTitle || 'Omni AI Tutor',
          duration: item.duration || '12:30',
          thumbnail: thumb,
          url: `https://www.youtube.com/watch?v=${ytId}`,
          youtubeId: ytId,
          subject: item.subject || 'Mathematics',
          difficulty: validDiff as 'Beginner' | 'Intermediate' | 'Advanced',
          concepts: Array.isArray(item.concepts) && item.concepts.length > 0 ? item.concepts : ['Syllabus Expansion'],
          description: item.description || 'AI-recommended educational video lesson.',
          reason: item.reason || `Directly matches aggregate topics in "${playlist.name}".`
        };
      });

      setPlaylistRecommendationsMap(prev => ({
        ...prev,
        [playlist.id]: mappedRecs
      }));
    } catch (err) {
      console.error("AI Recommendation error:", err);
      // Fallback suggestions
      const fallbackRecs: PlaylistRecommendation[] = [
        {
          id: `rec_fallback_1_${playlist.id}`,
          title: 'Advanced Theorem Proving & Vector Analysis',
          channelTitle: '3Blue1Brown',
          duration: '15:40',
          thumbnail: 'https://img.youtube.com/vi/W3ZCO_U6Z0M/maxresdefault.jpg',
          url: 'https://www.youtube.com/watch?v=W3ZCO_U6Z0M',
          youtubeId: 'W3ZCO_U6Z0M',
          subject: 'Mathematics',
          difficulty: 'Intermediate',
          concepts: ['Vector Calculus', 'Theorem Proving', 'Geometric Proofs'],
          description: 'Visual demonstration bridging fundamental definitions with applied problem solving.',
          reason: `Recommended based on the aggregate topic density in "${playlist.name}".`
        },
        {
          id: `rec_fallback_2_${playlist.id}`,
          title: 'Critical Thinking & Probability Paradoxes',
          channelTitle: 'Numberphile',
          duration: '11:15',
          thumbnail: 'https://img.youtube.com/vi/8idr1WZ1A7Q/maxresdefault.jpg',
          url: 'https://www.youtube.com/watch?v=8idr1WZ1A7Q',
          youtubeId: '8idr1WZ1A7Q',
          subject: 'Statistics & Logic',
          difficulty: 'Intermediate',
          concepts: ['Probability Paradox', 'Analytical Logic'],
          description: 'Deconstructing common cognitive biases and mathematical paradoxes.',
          reason: `Expands upon core problem solving strategies present in your playlist.`
        },
        {
          id: `rec_fallback_3_${playlist.id}`,
          title: 'Fundamental Trigonometry & Ratio Calculations',
          channelTitle: 'Math Antics',
          duration: '13:04',
          thumbnail: 'https://img.youtube.com/vi/S8FnbK2DCHc/maxresdefault.jpg',
          url: 'https://www.youtube.com/watch?v=S8FnbK2DCHc',
          youtubeId: 'S8FnbK2DCHc',
          subject: 'Trigonometry',
          difficulty: 'Beginner',
          concepts: ['Geometric Proofs', 'Foundational Trigonometry'],
          description: 'Intuitive geometric representations connecting formulas with spatial diagrams.',
          reason: `Fills in foundational prerequisites to solidify concepts in your curriculum.`
        }
      ];

      setPlaylistRecommendationsMap(prev => ({
        ...prev,
        [playlist.id]: fallbackRecs
      }));
    } finally {
      setLoadingRecommendationsFor(null);
    }
  };

  // Add recommended video to user's active playlist
  const handleAddRecommendationToPlaylist = (playlist: Playlist, rec: PlaylistRecommendation) => {
    const existingVideo = allVideos.find(v => v.id === rec.id || (rec.youtubeId && v.youtubeId === rec.youtubeId));
    const targetVideoId = existingVideo ? existingVideo.id : rec.id;

    if (!existingVideo) {
      const newVideoObj: Video = {
        id: rec.id,
        title: rec.title,
        source: 'AI Recommended',
        duration: rec.duration,
        thumbnail: rec.thumbnail,
        url: rec.url,
        channelTitle: rec.channelTitle,
        viewCount: Math.floor(Math.random() * 3000) + 1200,
        publishedAt: new Date(),
        youtubeId: rec.youtubeId,
        isAIGenerated: true,
        subject: rec.subject,
        description: rec.description,
        aiTags: {
          subject: rec.subject,
          difficulty: rec.difficulty,
          concepts: rec.concepts,
          summary: rec.description,
          taggedAt: new Date().toISOString()
        }
      };
      setGeneratedVideos([newVideoObj, ...generatedVideos]);
    }

    setVideoAITagsMap(prev => ({
      ...prev,
      [targetVideoId]: {
        subject: rec.subject,
        difficulty: rec.difficulty,
        concepts: rec.concepts,
        summary: rec.description,
        taggedAt: new Date().toISOString()
      }
    }));

    const now = new Date().toISOString();
    setPlaylists(prev => prev.map(p => {
      if (p.id !== playlist.id) return p;
      if (p.videoIds.includes(targetVideoId)) return p;
      return {
        ...p,
        videoIds: [...p.videoIds, targetVideoId],
        updatedAt: now
      };
    }));

    setAddedRecNotice(`Added "${rec.title}" to ${playlist.name}`);
    setTimeout(() => setAddedRecNotice(null), 3500);
  };

  // Play recommended video immediately
  const handlePlayRecommendation = (playlist: Playlist, rec: PlaylistRecommendation) => {
    let videoObj = allVideos.find(v => v.id === rec.id || (rec.youtubeId && v.youtubeId === rec.youtubeId));
    if (!videoObj) {
      videoObj = {
        id: rec.id,
        title: rec.title,
        source: 'AI Recommended',
        duration: rec.duration,
        thumbnail: rec.thumbnail,
        url: rec.url,
        channelTitle: rec.channelTitle,
        viewCount: Math.floor(Math.random() * 3000) + 1200,
        publishedAt: new Date(),
        youtubeId: rec.youtubeId,
        isAIGenerated: true,
        subject: rec.subject,
        description: rec.description,
        aiTags: {
          subject: rec.subject,
          difficulty: rec.difficulty,
          concepts: rec.concepts,
          summary: rec.description,
          taggedAt: new Date().toISOString()
        }
      };
      setGeneratedVideos([videoObj!, ...generatedVideos]);
    }

    setActiveVideo(videoObj);
    setSelectedPlaylistId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Auto-fetch recommendations when selecting a playlist
  useEffect(() => {
    if (selectedPlaylistId) {
      const pl = playlists.find(p => p.id === selectedPlaylistId);
      if (pl && !playlistRecommendationsMap[pl.id] && loadingRecommendationsFor !== pl.id) {
        fetchPlaylistRecommendations(pl);
      }
    }
  }, [selectedPlaylistId, playlists]);

  // Playlist Queue for Watch Page
  const [activePlaylistQueue, setActivePlaylistQueue] = useState<{
    playlistId: string;
    currentIndex: number;
  } | null>(null);

  // Form State for Create / Edit Playlist
  const [playlistForm, setPlaylistForm] = useState({
    name: '',
    description: '',
    color: 'indigo'
  });
  const [inlineNewPlaylistName, setInlineNewPlaylistName] = useState('');

  // Persist playlists to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('omni_ai_playlists', safeJsonStringify(playlists));
    } catch (e) {
      console.error("Error saving playlists to localStorage", e);
    }
  }, [playlists]);

  // Playlist action handlers
  const handleCreatePlaylist = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!playlistForm.name.trim()) return;

    const now = new Date().toISOString();
    const newPl: Playlist = {
      id: `pl_${Date.now()}`,
      name: playlistForm.name.trim(),
      description: playlistForm.description.trim() || 'Custom playlist of educational video lessons.',
      color: playlistForm.color || 'indigo',
      videoIds: videoForPlaylistModal ? [videoForPlaylistModal.id] : [],
      createdAt: now,
      updatedAt: now
    };

    setPlaylists(prev => [newPl, ...prev]);
    setPlaylistForm({ name: '', description: '', color: 'indigo' });
    setIsCreatePlaylistOpen(false);
  };

  const handleUpdatePlaylist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPlaylist || !playlistForm.name.trim()) return;

    const now = new Date().toISOString();
    setPlaylists(prev => prev.map(p => p.id === editingPlaylist.id ? {
      ...p,
      name: playlistForm.name.trim(),
      description: playlistForm.description.trim() || 'Custom playlist of educational video lessons.',
      color: playlistForm.color,
      updatedAt: now
    } : p));

    setEditingPlaylist(null);
    setPlaylistForm({ name: '', description: '', color: 'indigo' });
  };

  const handleDeletePlaylist = (playlistId: string) => {
    if (confirm("Are you sure you want to delete this playlist?")) {
      setPlaylists(prev => prev.filter(p => p.id !== playlistId));
      if (selectedPlaylistId === playlistId) {
        setSelectedPlaylistId(null);
      }
      if (activePlaylistQueue?.playlistId === playlistId) {
        setActivePlaylistQueue(null);
      }
    }
  };

  const handleToggleVideoInPlaylist = (playlistId: string, videoId: string) => {
    const now = new Date().toISOString();
    setPlaylists(prev => prev.map(p => {
      if (p.id !== playlistId) return p;
      const exists = p.videoIds.includes(videoId);
      const newVideoIds = exists
        ? p.videoIds.filter(id => id !== videoId)
        : [...p.videoIds, videoId];
      return { ...p, videoIds: newVideoIds, updatedAt: now };
    }));
  };

  const handleCreateInlinePlaylist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inlineNewPlaylistName.trim()) return;

    const colors = ['indigo', 'emerald', 'amber', 'rose', 'purple', 'sky'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    const now = new Date().toISOString();

    const newPl: Playlist = {
      id: `pl_${Date.now()}`,
      name: inlineNewPlaylistName.trim(),
      description: 'Custom educational lesson playlist.',
      color: randomColor,
      videoIds: videoForPlaylistModal ? [videoForPlaylistModal.id] : [],
      createdAt: now,
      updatedAt: now
    };

    setPlaylists(prev => [newPl, ...prev]);
    setInlineNewPlaylistName('');
  };

  const handlePlayAllInPlaylist = (playlist: Playlist) => {
    const playlistVideos = playlist.videoIds
      .map(id => allVideos.find(v => v.id === id))
      .filter((v): v is Video => Boolean(v));

    if (playlistVideos.length === 0) {
      alert("This playlist has no videos yet. Add some videos first!");
      return;
    }

    setActivePlaylistQueue({
      playlistId: playlist.id,
      currentIndex: 0
    });
    setActiveVideo(playlistVideos[0]);
    setSelectedPlaylistId(null);
    setPlaybackError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNextInPlaylist = () => {
    if (!activePlaylistQueue) return;
    const currentPlaylist = playlists.find(p => p.id === activePlaylistQueue.playlistId);
    if (!currentPlaylist) return;

    const playlistVideos = currentPlaylist.videoIds
      .map(id => allVideos.find(v => v.id === id))
      .filter((v): v is Video => Boolean(v));

    const nextIndex = activePlaylistQueue.currentIndex + 1;
    if (nextIndex < playlistVideos.length) {
      setActivePlaylistQueue({ ...activePlaylistQueue, currentIndex: nextIndex });
      setActiveVideo(playlistVideos[nextIndex]);
      setPlaybackError(null);
    } else {
      alert("You have reached the end of this playlist!");
    }
  };

  const handlePrevInPlaylist = () => {
    if (!activePlaylistQueue) return;
    const currentPlaylist = playlists.find(p => p.id === activePlaylistQueue.playlistId);
    if (!currentPlaylist) return;

    const playlistVideos = currentPlaylist.videoIds
      .map(id => allVideos.find(v => v.id === id))
      .filter((v): v is Video => Boolean(v));

    const prevIndex = activePlaylistQueue.currentIndex - 1;
    if (prevIndex >= 0) {
      setActivePlaylistQueue({ ...activePlaylistQueue, currentIndex: prevIndex });
      setActiveVideo(playlistVideos[prevIndex]);
      setPlaybackError(null);
    }
  };

  const handleMoveVideoInPlaylist = (playlistId: string, fromIndex: number, direction: 'up' | 'down') => {
    const now = new Date().toISOString();
    setPlaylists(prev => prev.map(p => {
      if (p.id !== playlistId) return p;
      const newIds = [...p.videoIds];
      const toIndex = direction === 'up' ? fromIndex - 1 : fromIndex + 1;
      if (toIndex < 0 || toIndex >= newIds.length) return p;
      const temp = newIds[fromIndex];
      newIds[fromIndex] = newIds[toIndex];
      newIds[toIndex] = temp;
      return { ...p, videoIds: newIds, updatedAt: now };
    }));
  };

  const handleReorderPlaylistVideos = (playlistId: string, newVideoIds: string[]) => {
    const now = new Date().toISOString();
    setPlaylists(prev => prev.map(p => {
      if (p.id !== playlistId) return p;
      return { ...p, videoIds: newVideoIds, updatedAt: now };
    }));
  };

  const handleExportPlaylistJSON = (playlist: Playlist) => {
    const playlistVideos = playlist.videoIds
      .map(id => allVideos.find(v => v.id === id))
      .filter((v): v is Video => Boolean(v));

    const exportData = {
      title: playlist.name,
      description: playlist.description,
      color: playlist.color,
      createdAt: playlist.createdAt,
      updatedAt: playlist.updatedAt || playlist.createdAt,
      totalVideos: playlistVideos.length,
      lessons: playlistVideos.map((v, idx) => {
        const tags = getVideoTags(v);
        return {
          index: idx + 1,
          id: v.id,
          title: v.title,
          channel: v.channelTitle,
          duration: v.duration,
          subject: tags.subject,
          difficulty: tags.difficulty,
          concepts: tags.concepts,
          aiSummary: tags.summary,
          url: v.url || `https://www.youtube.com/watch?v=${v.id}`,
          description: v.description || ''
        };
      })
    };

    const jsonString = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const safeName = playlist.name.toLowerCase().replace(/[^a-z0-9]/g, '_');
    link.download = `${safeName}_playlist.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportPlaylistPDF = (playlist: Playlist) => {
    const playlistVideos = playlist.videoIds
      .map(id => allVideos.find(v => v.id === id))
      .filter((v): v is Video => Boolean(v));

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert("Please allow pop-ups to open the printable curriculum summary.");
      return;
    }

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${playlist.name} - Educational Curriculum Summary</title>
          <meta charset="utf-8" />
          <style>
            body { font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 40px; color: #0f172a; line-height: 1.5; background: #fff; }
            .header { border-bottom: 3px solid #4f46e5; padding-bottom: 20px; margin-bottom: 24px; }
            .badge { display: inline-block; background: #e0e7ff; color: #4338ca; font-weight: 800; font-size: 11px; padding: 4px 12px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 12px; }
            h1 { margin: 0 0 10px 0; font-size: 26px; color: #0f172a; font-weight: 900; }
            p.desc { color: #475569; font-size: 14px; margin: 0 0 20px 0; background: #f8fafc; padding: 12px 16px; border-radius: 12px; border: 1px solid #e2e8f0; }
            .meta { display: flex; gap: 24px; font-size: 12px; color: #64748b; margin-bottom: 24px; }
            .meta-item { display: flex; flex-direction: column; }
            .meta-item label { font-size: 10px; font-weight: 800; text-transform: uppercase; color: #94a3b8; }
            .meta-item span { font-weight: 700; color: #1e293b; }
            .lesson-table { width: 100%; border-collapse: collapse; margin-top: 16px; }
            .lesson-table th { text-align: left; background: #f1f5f9; padding: 12px 14px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: #475569; border-bottom: 2px solid #cbd5e1; }
            .lesson-table td { padding: 14px; font-size: 13px; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
            .num { font-weight: 900; color: #4f46e5; width: 36px; font-size: 14px; }
            .title { font-weight: 700; color: #0f172a; margin-bottom: 2px; }
            .channel { color: #64748b; font-size: 12px; font-weight: 600; }
            .duration { font-family: monospace; font-size: 12px; font-weight: 800; color: #334155; }
            .tag { display: inline-block; background: #f1f5f9; border: 1px solid #cbd5e1; color: #334155; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 6px; margin-right: 4px; margin-top: 4px; }
            .diff-Beginner { background: #dcfce7; color: #166534; border-color: #86efac; }
            .diff-Intermediate { background: #fef3c7; color: #92400e; border-color: #fde68a; }
            .diff-Advanced { background: #ffe4e6; color: #9f1239; border-color: #fecdd3; }
            .link { color: #2563eb; text-decoration: none; font-size: 12px; font-weight: 600; word-break: break-all; }
            .footer { margin-top: 48px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 11px; color: #94a3b8; }
            .print-btn { background: #4f46e5; color: white; border: none; padding: 10px 20px; font-weight: 800; font-size: 13px; border-radius: 10px; cursor: pointer; transition: all 0.2s; }
            .print-btn:hover { background: #4338ca; }
            @media print {
              body { padding: 20px; }
              .no-print { display: none !important; }
            }
          </style>
        </head>
        <body>
          <div class="no-print" style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; background: #f1f5f9; padding: 12px 20px; border-radius: 12px;">
            <span style="font-size: 13px; font-weight: 700; color: #334155;">Educational Curriculum Document</span>
            <button onclick="window.print()" class="print-btn">🖨️ Print / Save as PDF</button>
          </div>

          <div class="header">
            <div class="badge">Shareable Educational Curriculum & AI Concept Taxonomy</div>
            <h1>${playlist.name}</h1>
            <p class="desc">${playlist.description || 'Custom playlist of educational video lessons.'}</p>
            <div class="meta">
              <div class="meta-item">
                <label>Total Lessons</label>
                <span>${playlistVideos.length} Video Lessons</span>
              </div>
              <div class="meta-item">
                <label>Created Date</label>
                <span>${new Date(playlist.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              </div>
              <div class="meta-item">
                <label>Last Updated</label>
                <span>${new Date(playlist.updatedAt || playlist.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              </div>
            </div>
          </div>

          <h3 style="font-size: 15px; font-weight: 800; color: #1e293b; margin-bottom: 12px;">Curriculum Lesson Plan & AI Concept Taxonomy</h3>
          <table class="lesson-table">
            <thead>
              <tr>
                <th class="num">#</th>
                <th>Lesson Title & Channel</th>
                <th>Subject & Level</th>
                <th>AI Concept Tags</th>
                <th>Duration</th>
                <th>Resource Link</th>
              </tr>
            </thead>
            <tbody>
              ${playlistVideos.map((v, i) => {
                const tags = getVideoTags(v);
                return `
                <tr>
                  <td class="num">${i + 1}</td>
                  <td>
                    <div class="title">${v.title}</div>
                    <div class="channel">${v.channelTitle}</div>
                  </td>
                  <td>
                    <div style="font-weight: 800; color: #4338ca; font-size: 11px;">${tags.subject}</div>
                    <span class="tag diff-${tags.difficulty}">${tags.difficulty}</span>
                  </td>
                  <td>
                    ${tags.concepts.map(c => `<span class="tag">#${c}</span>`).join('')}
                  </td>
                  <td class="duration">${v.duration}</td>
                  <td><a href="${v.url || `https://www.youtube.com/watch?v=${v.id}`}" target="_blank" class="link">Watch Lesson</a></td>
                </tr>
              `;
              }).join('')}
            </tbody>
          </table>

          <div class="footer">
            Generated via Omni AI Educational Video Platform • AI-Tagged Curriculum Summary for Educators & Students
          </div>
          <script>
            setTimeout(() => { window.print(); }, 400);
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  };

  const getPlaylistTextSummary = (playlist: Playlist) => {
    const playlistVideos = playlist.videoIds
      .map(id => allVideos.find(v => v.id === id))
      .filter((v): v is Video => Boolean(v));

    let text = `📚 PLAYLIST CURRICULUM: ${playlist.name}\n`;
    text += `Description: ${playlist.description || 'Educational video playlist'}\n`;
    text += `Total Lessons: ${playlistVideos.length}\n`;
    text += `Last Updated: ${new Date(playlist.updatedAt || playlist.createdAt).toLocaleDateString()}\n`;
    text += `--------------------------------------------------\n\n`;

    playlistVideos.forEach((v, idx) => {
      const tags = getVideoTags(v);
      text += `${idx + 1}. ${v.title} (${v.duration})\n`;
      text += `   Channel: ${v.channelTitle}\n`;
      text += `   Subject: ${tags.subject} | Level: ${tags.difficulty}\n`;
      text += `   Concepts: ${tags.concepts.map(c => `#${c}`).join(', ')}\n`;
      text += `   Link: ${v.url || `https://www.youtube.com/watch?v=${v.id}`}\n\n`;
    });

    return text;
  };

  // Pre-process active video source on selection
  useEffect(() => {
    let isMounted = true;
    if (activeVideo) {
      monitor.resetMonitor();

      const rawUrl = activeVideo.url || '';
      
      const resolveSrc = async () => {
        if (rawUrl.startsWith('blob:')) {
          // Attempt to retrieve fresh object URL from IndexedDB cache
          const cached = await getCachedVideoFragment(rawUrl);
          if (cached && cached.objectUrl) {
            return cached.objectUrl;
          }
        }
        const result = await preProcessVideoSource(rawUrl);
        return result.playableUrl;
      };

      resolveSrc().then((playableUrl) => {
        if (isMounted) {
          setCurrentVideoSrc(playableUrl);
        }
      });
    }

    return () => {
      isMounted = false;
    };
  }, [activeVideo]);
  
  // Custom interactive states
  const [subscribedChannels, setSubscribedChannels] = useState<Record<string, boolean>>({});
  const [likedVideos, setLikedVideos] = useState<Record<string, boolean>>({});
  const [commentsByVideo, setCommentsByVideo] = useState<Record<string, Comment[]>>({});
  const [newCommentText, setNewCommentText] = useState('');
  const [isTypingCommentResponse, setIsTypingCommentResponse] = useState(false);

  // Persistence of AI Generated Videos
  const [internalGeneratedVideos, setInternalGeneratedVideos] = useState<Video[]>(() => {
    const featuredVideos: Video[] = [
      {
        id: 'ai_dna_featured',
        title: 'DNA Replication: 3D Animated Process',
        source: 'Omni AI (Veo 3.1)',
        duration: '0:30',
        thumbnail: 'https://images.unsplash.com/photo-1674574124649-778f9afc0e7c?auto=format&fit=crop&w=640&h=360&q=80',
        url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
        channelTitle: 'Omni AI Tutor',
        viewCount: 1500,
        publishedAt: new Date(),
        isAIGenerated: true,
        topic: 'Cell Biology',
        subject: 'Biology',
        prompt: '3D animated video demonstrating the process of DNA Replication in a cellular environment for ICSE/CBSE Biology curriculum',
        description: 'A detailed 3D visualization of DNA Replication, showcasing helicase, DNA polymerase, and the formation of leading and lagging strands, tailored for CBSE and ICSE biology curriculum.'
      }
    ];

    if (externalGeneratedVideos) return [...externalGeneratedVideos, ...featuredVideos];
    try {
      const saved = localStorage.getItem('omni_ai_generated_videos');
      if (saved) {
        const parsed = JSON.parse(saved);
        return [...featuredVideos, ...parsed.map((v: any) => {
          let url = v.url;
          if (url && url.includes('gtv-videos-bucket')) {
            url = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
          }
          return {
            ...v,
            url,
            publishedAt: new Date(v.publishedAt)
          };
        })];
      }
    } catch (e) {
      console.error("Error loading generated videos", e);
    }
    return featuredVideos;
  });

  const generatedVideos = externalGeneratedVideos || internalGeneratedVideos;
  const setGeneratedVideos = onUpdateVideos || setInternalGeneratedVideos;

  // Generation status states
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationLogs, setGenerationLogs] = useState<string[]>([]);
  const [generationProgress, setGenerationProgress] = useState(0);

  const topicFormatted = useMemo(() => {
    return topic.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }, [topic]);

  const subjectFormatted = useMemo(() => {
    return subject.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }, [subject]);

  const handleManualGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customPrompt.trim()) return;
    runVideoGeneration(customPrompt.trim());
    setCustomPrompt('');
  };

  // Core generator orchestrator
  const runVideoGeneration = async (promptText: string) => {
    if (isGenerating) return;
    
    setIsGenerating(true);
    setGenerationProgress(5);
    setGenerationLogs(["Initializing Google Veo 3.1 high-speed preview engine..."]);

    try {
      // Step 1: Analyze syllabus
      await new Promise(resolve => setTimeout(resolve, 1200));
      setGenerationProgress(25);
      setGenerationLogs(prev => [...prev, `Mapping instructional depth for level "${difficulty}"...`]);

      // Step 2: Compile script
      await new Promise(resolve => setTimeout(resolve, 1000));
      setGenerationProgress(50);
      setGenerationLogs(prev => [...prev, `Compiling academic voice track and structuring key visual prompts...`]);

      // Step 3: Render frame blocks
      await new Promise(resolve => setTimeout(resolve, 1200));
      setGenerationProgress(75);
      setGenerationLogs(prev => [...prev, "Rendering 3D conceptual animations and compiling video streams..."]);

      // Call the real API
      const videoUri = await onGenerateVideo(promptText);
      
      await new Promise(resolve => setTimeout(resolve, 800));
      setGenerationProgress(95);
      setGenerationLogs(prev => [...prev, "Encoding final tutorial lesson for browser-native play..."]);

      // Formulate unique mock details or take the returned URI
      const finalUri = videoUri || "";
      const fallbackYt = REAL_YOUTUBE_VIDEOS[Math.floor(Math.random() * REAL_YOUTUBE_VIDEOS.length)];

      const mockVideo: Video = {
        id: `ai_${Date.now()}`,
        title: `${topicFormatted}: Dynamic Lecture breakdown`,
        source: 'Omni AI (Veo 3.1)',
        duration: '0:06',
        thumbnail: `https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=640&h=360&q=80`,
        url: finalUri || `https://www.youtube.com/watch?v=${fallbackYt.id}`,
        channelTitle: 'Omni AI Tutor',
        viewCount: Math.floor(Math.random() * 800) + 50,
        publishedAt: new Date(),
        youtubeId: finalUri ? undefined : fallbackYt.id,
        isAIGenerated: true,
        topic: topic,
        subject: subject,
        prompt: promptText,
        subscribers: '100K',
        likes: 124,
        description: `This custom educational micro-lesson was synthesized dynamically by Omni AI to explain "${topicFormatted}" under the "${subjectFormatted}" syllabus at a "${difficulty}" level. It provides targeted graphics, mathematical equations, and intuitive voice instructions.`
      };

      const updatedVideos = [mockVideo, ...generatedVideos];
      setGeneratedVideos(updatedVideos);
      
      if (!onUpdateVideos) {
        localStorage.setItem('omni_ai_generated_videos', safeJsonStringify(updatedVideos));
      }
      setGenerationProgress(100);
      setIsGenerating(false);

    } catch (error) {
      console.error("AI video generation error:", error);
      setIsGenerating(false);
    }
  };

  // AUTOMATIC Generation on Left-Sidebar Navigation triggers:
  useEffect(() => {
    if (!topic || !subject) return;

    // Check if we already have a generated video for this exact topic and subject
    const alreadyExists = generatedVideos.some(v => v.topic === topic && v.subject === subject);
    if (alreadyExists) return;

    // Trigger auto generation
    const autoPrompt = `High quality educational rendering explaining ${topicFormatted} inside ${subjectFormatted} syllabus at a ${difficulty} difficulty, with animated labels and mathematical definitions`;
    runVideoGeneration(autoPrompt);
  }, [topic, subject, difficulty]);

  // Combined search + chips logic
  const staticVideos: Video[] = useMemo(() => {
    return REAL_YOUTUBE_VIDEOS.map((yt, idx) => {
      const isCalculus = yt.title.toLowerCase().includes('calculus') || yt.title.toLowerCase().includes('derivative') || yt.title.toLowerCase().includes('taylor');
      const isAlgebra = yt.title.toLowerCase().includes('linear') || yt.title.toLowerCase().includes('algebra') || yt.title.toLowerCase().includes('equation') || yt.title.toLowerCase().includes('coordinate');
      const isTrig = yt.title.toLowerCase().includes('trigonometry');
      const isStats = yt.title.toLowerCase().includes('statistics') || yt.title.toLowerCase().includes('paradox') || yt.title.toLowerCase().includes('monty');
      
      let category = 'Others';
      if (isCalculus) category = 'Calculus';
      else if (isAlgebra) category = 'Algebra';
      else if (isTrig) category = 'Trigonometry';
      else if (isStats) category = 'Statistics';

      return {
        id: `yt_${yt.id}`,
        title: yt.title,
        source: 'YouTube EDU',
        duration: yt.duration,
        thumbnail: `https://img.youtube.com/vi/${yt.id}/maxresdefault.jpg`,
        url: `https://www.youtube.com/watch?v=${yt.id}`,
        channelTitle: yt.channel,
        viewCount: yt.views,
        publishedAt: new Date(Date.now() - (idx * 86400000 * 30) - 86400000 * 5),
        youtubeId: yt.id,
        subscribers: yt.subscribers,
        likes: Math.floor(yt.views * 0.03),
        description: yt.description,
        topic: category
      };
    });
  }, [topicFormatted]);

  const allVideos = useMemo(() => {
    return [...generatedVideos, ...staticVideos];
  }, [generatedVideos, staticVideos]);

  const filteredVideos = useMemo(() => {
    return allVideos.filter(v => {
      const matchesSearch = v.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            v.channelTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            (v.prompt && v.prompt.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesChip = selectedChip === 'All' || 
                          (selectedChip === 'AI Generated' && v.isAIGenerated) ||
                          (selectedChip === 'My Uploads' && (v.source === 'Local Upload' || v.source === 'External Link')) ||
                          (selectedChip === 'Calculus' && v.topic === 'Calculus') ||
                          (selectedChip === 'Algebra' && v.topic === 'Algebra') ||
                          (selectedChip === 'Trigonometry' && v.topic === 'Trigonometry') ||
                          (selectedChip === 'Statistics' && v.topic === 'Statistics');
      return matchesSearch && matchesChip;
    });
  }, [allVideos, searchQuery, selectedChip]);

  // Comment responses engine
  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim() || !activeVideo) return;

    const userCommentId = `uc_${Date.now()}`;
    const userComment: Comment = {
      id: userCommentId,
      author: 'You (Student)',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=80&h=80&q=80',
      content: newCommentText,
      time: 'Just now',
      likes: 0
    };

    const currentVideoId = activeVideo.id;
    const currentComments = commentsByVideo[currentVideoId] || DEFAULT_COMMENTS_BY_VIDEO.default;
    const updatedComments = [userComment, ...currentComments];

    setCommentsByVideo(prev => ({
      ...prev,
      [currentVideoId]: updatedComments
    }));

    const promptText = newCommentText;
    setNewCommentText('');
    setIsTypingCommentResponse(true);

    // AI simulation delay
    setTimeout(() => {
      let aiResponseText = `Thank you for sharing your thoughts! As we explore these foundational mathematical structures, questions like yours help refine our intuitive grasp. Keep practicing and looking for geometric connections!`;
      
      const lower = promptText.toLowerCase();
      const chName = activeVideo.channelTitle;

      if (chName === '3Blue1Brown') {
        if (lower.includes('why') || lower.includes('how') || lower.includes('visual') || lower.includes('understand')) {
          aiResponseText = `That is exactly the core of the intuition! An elegant way to visualize this is to think of it as a linear transformation or a scaling vector in multi-dimensional space. If we inspect how tiny intervals behave at a microscopic level, the calculus simplifies beautifully. Try mapping this on a 2D grid!`;
        } else {
          aiResponseText = `Fascinating question. When we analyze this concept visually, we want to look at what remains constant. In linear algebra or calculus, finding that invariant core—the "essence"—is what makes the equations feel natural rather than arbitrary.`;
        }
      } else if (chName === 'Math Antics') {
        if (lower.includes('hard') || lower.includes('confused') || lower.includes('help')) {
          aiResponseText = `Don't worry at all! Math is just like a fun puzzle with a few basic rules. Let's break it down into easy, bite-sized steps: 1) Group your terms, 2) Balance both sides of the equation, and 3) Solve step-by-step. Just keep practicing and it will become second nature!`;
        } else {
          aiResponseText = `Exactly! That's a super smart way to put it. Remember, in math, you're always just balancing scales. What you do to one side of the equal sign, you must do to the other. Keep up the awesome work!`;
        }
      } else if (chName === 'TED-Ed') {
        aiResponseText = `This curiosity-driven question lies at the very heart of the mystery. Imagine a world where this pattern didn't apply; the natural structures we observe daily would collapse. In other words, these scientific frameworks act as a mirror to our cosmos, explaining everything from honeycombs to orbits.`;
      } else if (chName === 'Numberphile') {
        aiResponseText = `This is where it gets absolutely mind-blowing! When we spoke to leading professors at Oxford, they pointed out that this result isn't just an anomaly—it connects directly to prime number distribution and infinity itself! It's a gorgeous, almost romantic, mathematical reality.`;
      } else if (activeVideo.isAIGenerated) {
        aiResponseText = `Excellent inquiry! In our dynamically generated lecture, this concept is structured to align perfectly with your curriculum requirements. Focusing on these relationships will unlock deeper success in your exams!`;
      }

      const aiComment: Comment = {
        id: `ai_resp_${Date.now()}`,
        author: `${chName} (Creator AI)`,
        avatar: activeVideo.isAIGenerated 
          ? 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=80&h=80&q=80'
          : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=80&h=80&q=80',
        content: aiResponseText,
        time: 'Just now',
        likes: 1,
        isVerified: true
      };

      setCommentsByVideo(prev => ({
        ...prev,
        [currentVideoId]: [aiComment, ...updatedComments]
      }));
      setIsTypingCommentResponse(false);
    }, 1800);
  };

  const handleSubscribeToggle = (channel: string) => {
    setSubscribedChannels(prev => {
      const val = !prev[channel];
      return { ...prev, [channel]: val };
    });
  };

  const handleLikeToggle = (videoId: string) => {
    setLikedVideos(prev => {
      const val = !prev[videoId];
      return { ...prev, [videoId]: val };
    });
  };

  const activeVideoComments = useMemo(() => {
    if (!activeVideo) return [];
    return commentsByVideo[activeVideo.id] || DEFAULT_COMMENTS_BY_VIDEO.default;
  }, [activeVideo, commentsByVideo]);

  const [currentTime, setCurrentTime] = useState(0);
  const [activeEvent, setActiveEvent] = useState<{ timestamp: number; event: string } | null>(null);

  const shareUrl = useMemo(() => {
    if (!activeVideo) return '';
    const base = window.location.origin + window.location.pathname;
    let url = `${base}?video=${activeVideo.id}`;
    if (shareWithTimestamp && currentTime > 0) {
      url += `&t=${Math.floor(currentTime)}`;
    }
    return url;
  }, [activeVideo, shareWithTimestamp, currentTime]);

  // Share link mount effect to auto-load video and jump to timestamp
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const videoId = params.get('video');
    if (videoId) {
      const match = allVideos.find(v => v.id === videoId);
      if (match) {
        setActiveVideo(match);
      }
    }
  }, [allVideos]);

  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [bookmarks, setBookmarks] = useState<{ id: string; timestamp: number; title: string }[]>([]);
  const [bookmarkInput, setBookmarkInput] = useState('');
  const [syncedNotes, setSyncedNotes] = useState<{ id: string; timestamp: number; text: string; createdAt: Date }[]>([]);
  const [noteText, setNoteText] = useState('');
  const [transcriptSearch, setTranscriptSearch] = useState('');
  const [activeDockTab, setActiveDockTab] = useState<'transcript' | 'notes' | 'bookmarks' | 'shortcuts'>('transcript');

  const gridPlayerHandle: VideoPlayerHandle = useMemo(() => ({
    play: () => {
      if (videoElementRef.current) return videoElementRef.current.play().catch(() => {});
    },
    pause: () => {
      if (videoElementRef.current) videoElementRef.current.pause();
    },
    togglePlay: () => {
      if (videoElementRef.current) {
        if (videoElementRef.current.paused) {
          videoElementRef.current.play().catch(() => {});
        } else {
          videoElementRef.current.pause();
        }
      }
    },
    seekTo: (time: number) => {
      if (videoElementRef.current) {
        const dur = videoElementRef.current.duration || 0;
        videoElementRef.current.currentTime = Math.max(0, Math.min(dur > 0 ? dur : Infinity, time));
      }
    },
    seekBy: (seconds: number) => {
      if (videoElementRef.current) {
        const cur = videoElementRef.current.currentTime;
        const dur = videoElementRef.current.duration || 0;
        videoElementRef.current.currentTime = Math.max(0, Math.min(dur > 0 ? dur : Infinity, cur + seconds));
      }
    },
    setPlaybackSpeed: (speed: number) => {
      setPlaybackSpeed(speed);
      if (videoElementRef.current) {
        videoElementRef.current.playbackRate = speed;
      }
    },
    setVolume: (volume: number) => {
      if (videoElementRef.current) {
        const vol = Math.max(0, Math.min(1, volume));
        videoElementRef.current.volume = vol;
        if (vol > 0) videoElementRef.current.muted = false;
      }
    },
    toggleMute: () => {
      if (videoElementRef.current) {
        videoElementRef.current.muted = !videoElementRef.current.muted;
      }
    },
    getVideoElement: () => videoElementRef.current,
    getCurrentTime: () => videoElementRef.current?.currentTime || 0,
    getDuration: () => videoElementRef.current?.duration || 0,
    isPaused: () => videoElementRef.current ? videoElementRef.current.paused : true,
  }), [setPlaybackSpeed]);

  useEffect(() => {
    if (activeVideo) {
      setActiveVideoPlayerInstance(gridPlayerHandle);
    }
    return () => {
      if (activeVideo) {
        setActiveVideoPlayerInstance(null);
      }
    };
  }, [activeVideo, gridPlayerHandle]);

  const handleSetSpeed = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoElementRef.current) {
      videoElementRef.current.playbackRate = speed;
    }
  };

  const handleSeekTo = (seconds: number) => {
    if (videoElementRef.current) {
      videoElementRef.current.currentTime = seconds;
      videoElementRef.current.play().catch(() => {});
    }
  };

  const handleSyncNote = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!noteText.trim()) return;
    const newNote = {
      id: `note_${Date.now()}`,
      timestamp: currentTime,
      text: noteText.trim(),
      createdAt: new Date()
    };
    setSyncedNotes(prev => [newNote, ...prev]);
    setNoteText('');
  };

  const handleAddBookmark = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const title = bookmarkInput.trim() || `Key Moment @ ${formatDuration(currentTime)}`;
    const newBm = {
      id: `bm_${Date.now()}`,
      timestamp: currentTime,
      title
    };
    setBookmarks(prev => [newBm, ...prev]);
    setBookmarkInput('');
  };

  const activeTranscriptSegments = useMemo(() => {
    if (!activeVideo) return [];
    
    const baseSegments = [
      { timestamp: 0, text: `Introduction and Lesson Goal: ${activeVideo.title}` },
      { timestamp: 15, text: `Fundamental Definitions and Conceptual Scope of ${activeVideo.topic || 'Lesson'}` },
      { timestamp: 45, text: `Core Mathematical & Visual Representation` },
      { timestamp: 90, text: `Step-by-Step Practical Problem Solving & Derivations` },
      { timestamp: 135, text: `Analyzing Common Edge Cases and Verifying Units` },
      { timestamp: 180, text: `Lesson Summary, Key Formulas, and Homework Assignment` }
    ];

    if (activeVideo.events && activeVideo.events.length > 0) {
      const customSegments = activeVideo.events.map((ev) => ({
        timestamp: ev.timestamp,
        text: ev.event.replace(/^AI Tutor wrote:\s*/, '')
      }));
      return [...baseSegments, ...customSegments].sort((a, b) => a.timestamp - b.timestamp);
    }

    return baseSegments;
  }, [activeVideo]);

  const filteredTranscript = useMemo(() => {
    if (!transcriptSearch.trim()) return activeTranscriptSegments;
    const q = transcriptSearch.toLowerCase();
    return activeTranscriptSegments.filter(item => 
      item.text.toLowerCase().includes(q) || formatDuration(item.timestamp).includes(q)
    );
  }, [activeTranscriptSegments, transcriptSearch]);

  useEffect(() => {
    if (!activeVideo || !activeVideo.events) {
      setActiveEvent(null);
      return;
    }

    const matchingEvent = activeVideo.events.find(e => 
      currentTime >= e.timestamp && currentTime <= e.timestamp + 3 // Show for 3 seconds
    );

    if (matchingEvent) {
      setActiveEvent(matchingEvent);
    } else {
      setActiveEvent(null);
    }
  }, [currentTime, activeVideo]);

  const handleTimeUpdate = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    setCurrentTime(e.currentTarget.currentTime);
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-64px)] bg-slate-950 text-slate-100 font-sans">
      
      {/* YouTube Edu bar header inside the section */}
      <div className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-red-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-red-600/10">
            <Play size={18} fill="currentColor" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-black text-sm tracking-tight uppercase">EduTube</span>
              <span className="text-[9px] bg-red-500/15 text-red-500 font-bold px-1.5 py-0.5 rounded uppercase border border-red-500/20">AI CLONE</span>
            </div>
            <p className="text-[10px] text-slate-400 font-bold tracking-wider leading-none">Curriculum Search Engine</p>
          </div>
        </div>

        {/* Dynamic global search */}
        <div className="flex-1 max-w-md relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={15} />
          <input 
            type="text"
            placeholder="Search lectures, topics, channels, or prompts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-750 hover:border-slate-650 focus:border-red-500 rounded-full pl-10 pr-4 py-2 text-xs font-semibold outline-none transition-colors text-white placeholder-slate-500"
          />
        </div>

        {/* Creator Studio & Profile Indicator */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsUploadModalOpen(true)}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-3.5 py-2 rounded-full cursor-pointer transition active:scale-95 shadow-md shadow-indigo-900/10 shrink-0"
          >
            <Upload size={13} />
            <span>Upload Video</span>
          </button>
          <button 
            onClick={() => {
              const creativePrompt = prompt("What specific educational video would you like Google Veo 3.1 to compile for you?", `An intuitive animation of ${topicFormatted} with graph labels...`);
              if (creativePrompt) {
                runVideoGeneration(creativePrompt);
              }
            }}
            disabled={isGenerating}
            className="flex items-center gap-1.5 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-bold px-3.5 py-2 rounded-full cursor-pointer transition active:scale-95 shadow-md shadow-red-900/10 shrink-0"
          >
            <Sparkles size={13} className={isGenerating ? "animate-spin" : ""} />
            <span>AI Studio</span>
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        
        {/* Left YouTube Navigation bar (Desktop side-rail) */}
        <div className="hidden lg:flex w-64 bg-slate-900/60 border-r border-slate-800 p-4 flex-col justify-between shrink-0">
          <div className="space-y-6">
            <div className="space-y-1">
              <button 
                onClick={() => { setActiveVideo(null); setPlaybackError(null); setSelectedChip('All'); }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-black uppercase transition-colors tracking-wide ${!activeVideo && selectedChip === 'All' ? 'bg-red-600/10 text-red-500 border border-red-500/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
              >
                <Tv size={16} />
                <span>Edu Home</span>
              </button>
              <button 
                onClick={() => { setActiveVideo(null); setPlaybackError(null); setSelectedChip('AI Generated'); }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-black uppercase transition-colors tracking-wide ${selectedChip === 'AI Generated' ? 'bg-red-600/10 text-red-500 border border-red-500/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
              >
                <Sparkles size={16} />
                <span>AI Uploads</span>
              </button>
              <button 
                onClick={() => { setActiveVideo(null); setPlaybackError(null); setSelectedChip('My Uploads'); }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-black uppercase transition-colors tracking-wide ${selectedChip === 'My Uploads' ? 'bg-red-600/10 text-red-500 border border-red-500/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
              >
                <VideoIcon size={16} />
                <span>My Uploads</span>
              </button>
            </div>

            <div>
              <div className="px-3.5 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">My Subscriptions</div>
              <div className="space-y-1">
                {['3Blue1Brown', 'Math Antics', 'TED-Ed', 'Numberphile', 'Omni AI Tutor'].map(ch => {
                  const isSub = subscribedChannels[ch];
                  return (
                    <div key={ch} className="flex items-center justify-between px-3.5 py-1.5 rounded-lg text-xs font-bold text-slate-300">
                      <span className="truncate flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-red-500" />
                        {ch}
                      </span>
                      <button 
                        onClick={() => handleSubscribeToggle(ch)}
                        className={`text-[9px] px-1.5 py-0.5 rounded font-black uppercase ${isSub ? 'bg-slate-800 text-slate-500' : 'bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white'}`}
                      >
                        {isSub ? 'Subbed' : 'Join'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* My Playlists Sidebar Section */}
            <div>
              <div className="px-3.5 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2 flex items-center justify-between">
                <span>My Playlists ({playlists.length})</span>
                <button
                  type="button"
                  onClick={() => {
                    setVideoForPlaylistModal(null);
                    setPlaylistForm({ name: '', description: '', color: 'indigo' });
                    setIsCreatePlaylistOpen(true);
                  }}
                  className="text-red-400 hover:text-white text-xs font-black p-0.5 rounded hover:bg-slate-800 flex items-center gap-0.5 transition cursor-pointer"
                  title="Create New Playlist"
                >
                  <Plus size={13} />
                </button>
              </div>

              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {playlists.map(pl => {
                  const isSelected = selectedPlaylistId === pl.id && !activeVideo;
                  const modTime = pl.updatedAt || pl.createdAt;
                  return (
                    <button
                      key={pl.id}
                      onClick={() => {
                        setActiveVideo(null);
                        setSelectedPlaylistId(pl.id);
                        setPlaybackError(null);
                      }}
                      className={`w-full flex flex-col gap-1 p-2.5 rounded-xl text-xs transition-all text-left cursor-pointer ${isSelected ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 font-black' : 'text-slate-300 hover:bg-slate-800 hover:text-white border border-transparent'}`}
                      title={`${pl.name} - ${pl.description}`}
                    >
                      <div className="flex items-center justify-between w-full min-w-0">
                        <div className="flex items-center gap-2 min-w-0 flex-1 pr-1">
                          <ListVideo size={14} className={isSelected ? 'text-indigo-400 shrink-0' : 'text-slate-500 shrink-0'} />
                          <span className="truncate font-bold">{pl.name}</span>
                        </div>
                        <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-950 text-slate-400 font-black shrink-0">
                          {pl.videoIds.length}
                        </span>
                      </div>
                      
                      {pl.description && (
                        <p className="text-[10px] text-slate-400 font-normal line-clamp-1 pl-5">
                          {pl.description}
                        </p>
                      )}

                      <div className="flex items-center justify-between text-[9px] text-slate-500 font-medium pl-5 pt-0.5 border-t border-slate-800/40">
                        <span className="flex items-center gap-1 text-[9px] text-slate-400 font-bold">
                          <Clock size={10} className="text-indigo-400" />
                          {timeAgo(modTime)}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="p-3 bg-red-950/20 border border-red-500/10 rounded-xl space-y-1.5">
              <div className="text-[10px] font-black text-red-400 uppercase tracking-wider flex items-center gap-1">
                <Info size={11} /> Learning Session
              </div>
              <p className="text-[9px] text-slate-400 leading-normal font-bold uppercase">
                Active Chapter:<br />
                <span className="text-white font-black">{topicFormatted}</span>
              </p>
            </div>
          </div>

          <div className="text-[10px] text-slate-500 font-mono text-center">
            &copy; 2026 EduTube AI Studio
          </div>
        </div>

        {/* Main interactive area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 space-y-6">
          
          {/* Watch Page View */}
          {activeVideo ? (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-3 duration-300">
              
              {/* Back to feed button */}
              <button 
                onClick={() => { setActiveVideo(null); setPlaybackError(null); }}
                className="flex items-center gap-2 text-xs font-black text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-full px-4 py-2 hover:bg-slate-850 cursor-pointer transition active:scale-95"
              >
                <ArrowLeft size={14} />
                <span>Back to Edu Home Feed</span>
              </button>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Left Column: Player, Video Details, Comments */}
                <div className="lg:col-span-8 space-y-5">
                  
                  {/* Aspect ratio frame */}
                  <div className="bg-black rounded-3xl overflow-hidden border border-slate-800 shadow-2xl aspect-video relative">
                    {(() => {
                      const ytId = activeVideo.youtubeId || (activeVideo.url ? extractYouTubeId(activeVideo.url) : undefined);
                      if (ytId) {
                        return (
                          <iframe
                            src={`https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0&modestbranding=1`}
                            title={activeVideo.title}
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            className="absolute inset-0 w-full h-full border-0"
                          />
                        );
                      }

                      const FALLBACK_URL = "/api/proxy-video";

                      return (
                        <div className="relative w-full h-full">
                          <video
                            key={currentVideoSrc || activeVideo.url || FALLBACK_URL}
                            ref={videoElementRef}
                            src={currentVideoSrc || activeVideo.url || FALLBACK_URL}
                            controls
                            autoPlay
                            playsInline
                            preload="auto"
                            onTimeUpdate={handleTimeUpdate}
                            onLoadedMetadata={() => {
                              monitor.handleSuccessLoad();
                              const params = new URLSearchParams(window.location.search);
                              const timestamp = params.get('t');
                              if (timestamp && videoElementRef.current) {
                                videoElementRef.current.currentTime = parseFloat(timestamp);
                              }
                            }}
                            onError={(e) => {
                              const target = e.target as HTMLVideoElement;
                              const error = target.error;
                              console.info("VideoGrid playback recovery trigger:", {
                                code: error?.code,
                                message: error?.message,
                                src: target.src
                              });
                              monitor.triggerRecovery(
                                target.src,
                                error?.code || 4,
                                error?.message || 'Format error'
                              );
                            }}
                            className="absolute inset-0 w-full h-full border-0 object-contain"
                          />

                          {/* Auto-Fallback Toast Notice */}
                          {autoFallbackNotice && (
                            <div className="absolute top-3 left-3 right-3 bg-slate-900/95 text-emerald-400 text-xs font-bold px-3.5 py-2 rounded-xl border border-emerald-500/30 backdrop-blur-md shadow-2xl flex items-center justify-between z-20 animate-in fade-in">
                              <div className="flex items-center gap-2">
                                <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                                <span>{autoFallbackNotice}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => monitor.setRecoveryNotice(null)}
                                className="text-slate-400 hover:text-white text-xs font-mono px-1.5 py-0.5 rounded"
                              >
                                ✕
                              </button>
                            </div>
                          )}
                          
                          {/* Centralized Playback Integrity Diagnostics Recovery Panel */}
                          {gridDiagnosticReport && playbackError && (
                            <MediaRecoveryPanel
                              diagnosticReport={gridDiagnosticReport}
                              playbackError={playbackError}
                              currentStrategy={monitor.strategy}
                              retryCount={monitor.retryCount}
                              isRetrying={monitor.isRetrying}
                              src={currentVideoSrc || activeVideo.url || FALLBACK_URL}
                              isBlob={Boolean(currentVideoSrc && currentVideoSrc.startsWith('blob:'))}
                              onSelectStrategy={monitor.forceStrategy}
                              onDismiss={monitor.resetMonitor}
                            />
                          )}
                        </div>
                      );
                    })()}

                    {/* AI Visual Cue Overlay */}
                    <AnimatePresence>
                      {activeEvent && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 1.05 }}
                          className="absolute inset-0 pointer-events-none z-10 flex flex-col items-center justify-center"
                        >
                          {/* The "soft glow" requested */}
                          <div className="absolute inset-0 bg-red-600/10 animate-pulse border-4 border-red-500/30 rounded-3xl" />
                          
                          <div className="relative bg-slate-900/90 backdrop-blur-md border border-red-500/30 px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 transform -translate-y-12">
                            <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-white shadow-lg shadow-red-900/20">
                              <Sparkles size={20} className="animate-spin-slow" />
                            </div>
                            <div className="text-left">
                              <span className="block text-[10px] font-black text-red-500 uppercase tracking-widest">AI Feedback Event</span>
                              <p className="text-sm font-bold text-white max-w-[250px] leading-tight">
                                {activeEvent.event}
                              </p>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Player Quick Controls: Playback Speed, Quick Bookmark, & Quick Sync Note */}
                  <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-lg">
                     {/* Playback Speed Selector */}
                    <div className="flex flex-wrap items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                          <FastForward size={13} className="text-red-500" /> Speed:
                        </span>
                        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 gap-1">
                          {[0.5, 1, 1.25, 1.5, 2].map((spd) => (
                            <button
                              key={spd}
                              type="button"
                              onClick={() => handleSetSpeed(spd)}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                                playbackSpeed === spd
                                  ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
                              }`}
                            >
                              {spd}x
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Adaptive Bitrate Quality Selector */}
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                          <Sliders size={13} className="text-indigo-400" /> Quality:
                        </span>
                        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 gap-1">
                          {([
                            { key: 'auto', label: 'Auto' },
                            { key: 'low', label: '360p' },
                            { key: 'medium', label: '720p' },
                            { key: 'high', label: '1080p' }
                          ] as const).map((q) => (
                            <button
                              key={q.key}
                              type="button"
                              onClick={() => abr.changeQuality(q.key)}
                              className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                                abr.selectedQuality === q.key
                                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
                              }`}
                            >
                              {q.label}
                            </button>
                          ))}
                        </div>
                        
                        {/* Active Bitrate Info Badge */}
                        <span className="text-[9px] font-mono bg-slate-950 border border-slate-850 text-indigo-400 px-2 py-1 rounded-lg font-black shrink-0">
                          {abr.selectedQuality === 'auto' ? `Auto (${abr.activeQuality.toUpperCase()})` : abr.activeQuality.toUpperCase()} • {abr.currentBitrate}kbps
                        </span>
                      </div>
                    </div>

                    {/* Quick Action Tools */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveDockTab('notes');
                          const note = prompt(`Enter lesson note to sync to timestamp [${formatDuration(currentTime)}]:`);
                          if (note && note.trim()) {
                            setSyncedNotes(prev => [{
                              id: `note_${Date.now()}`,
                              timestamp: currentTime,
                              text: note.trim(),
                              createdAt: new Date()
                            }, ...prev]);
                          }
                        }}
                        className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
                      >
                        <FileText size={13} className="text-indigo-400" />
                        <span>Sync Note @ {formatDuration(currentTime)}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setActiveDockTab('bookmarks');
                          handleAddBookmark();
                        }}
                        className="px-3 py-1.5 bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/30 text-amber-300 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
                      >
                        <Bookmark size={13} className="text-amber-400" />
                        <span>Bookmark @ {formatDuration(currentTime)}</span>
                      </button>
                    </div>
                  </div>

                  {/* Video Meta Title Card */}
                  <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
                    <h1 className="text-lg md:text-xl font-black tracking-tight text-white leading-snug">
                      {activeVideo.title}
                    </h1>

                    <div className="flex flex-wrap items-center justify-between gap-4 border-t border-b border-slate-800/60 py-4">
                      {/* Left: Channel Info */}
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-indigo-700 rounded-xl flex items-center justify-center text-white font-black text-sm uppercase shadow-lg shadow-red-900/10">
                          {activeVideo.channelTitle.charAt(0)}
                        </div>
                        <div className="text-left">
                          <h3 className="font-black text-sm text-white flex items-center gap-1.5 leading-none">
                            {activeVideo.channelTitle}
                            <CheckCircle2 size={13} className="text-red-500 shrink-0" fill="currentColor" />
                          </h3>
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                            {activeVideo.subscribers || '1.2M'} Subscribers
                          </span>
                        </div>

                        <button 
                          onClick={() => handleSubscribeToggle(activeVideo.channelTitle)}
                          className={`ml-3 text-xs font-black uppercase px-4 py-2 rounded-full cursor-pointer transition duration-200 ${subscribedChannels[activeVideo.channelTitle] ? 'bg-slate-800 text-slate-400 border border-slate-700' : 'bg-red-600 text-white hover:bg-red-500 shadow-lg shadow-red-900/15'}`}
                        >
                          {subscribedChannels[activeVideo.channelTitle] ? 'Subscribed' : 'Subscribe'}
                        </button>
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Like Button */}
                        <div className="flex items-center bg-slate-800 border border-slate-750 rounded-full overflow-hidden">
                          <button 
                            onClick={() => handleLikeToggle(activeVideo.id)}
                            className={`flex items-center gap-1.5 px-3.5 py-2 hover:bg-slate-700 transition cursor-pointer text-xs font-black ${likedVideos[activeVideo.id] ? 'text-red-500' : 'text-slate-300'}`}
                          >
                            <ThumbsUp size={13} fill={likedVideos[activeVideo.id] ? 'currentColor' : 'none'} />
                            <span>{(activeVideo.likes || 1400) + (likedVideos[activeVideo.id] ? 1 : 0)}</span>
                          </button>
                          <span className="w-px h-5 bg-slate-700" />
                          <button className="px-3 py-2 hover:bg-slate-700 transition cursor-pointer text-slate-300">
                            <ThumbsDown size={13} />
                          </button>
                        </div>

                        {/* Share & Download & Playlist */}
                        <button 
                          onClick={() => setVideoForPlaylistModal(activeVideo)}
                          className="flex items-center gap-1.5 bg-indigo-600/10 hover:bg-indigo-600/20 border border-indigo-500/20 text-indigo-300 text-xs font-black px-3.5 py-2 rounded-full cursor-pointer transition active:scale-95 shadow-sm"
                        >
                          <FolderPlus size={13} className="text-indigo-400" />
                          <span>Save to Playlist</span>
                        </button>

                        <button 
                          onClick={() => setIsShareModalOpen(true)}
                          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-750 text-slate-300 text-xs font-black px-3.5 py-2 rounded-full cursor-pointer transition active:scale-95"
                        >
                          <Share2 size={13} />
                          <span>Share</span>
                        </button>

                        {activeVideo.url && (
                          <button 
                            onClick={() => downloadFileFromUrl(activeVideo.url, `${activeVideo.title.replace(/\s+/g, '_')}.mp4`)}
                            className="flex items-center gap-1.5 bg-red-600/10 hover:bg-red-600/20 border border-red-500/20 text-red-400 text-xs font-black px-3.5 py-2 rounded-full cursor-pointer transition active:scale-95"
                          >
                            <Download size={13} />
                            <span>Download</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Expandable description block */}
                    <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 text-xs text-slate-300 space-y-2 leading-relaxed">
                      <div className="flex items-center gap-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <span>{(activeVideo.viewCount || 5200).toLocaleString()} Views</span>
                        <span>•</span>
                        <span>{timeAgo(activeVideo.publishedAt)}</span>
                      </div>
                      <p className="font-medium">{activeVideo.description}</p>
                      {activeVideo.prompt && (
                        <div className="bg-indigo-950/20 border border-indigo-500/10 rounded-xl p-2.5 text-[11px] text-indigo-400 font-bold flex items-center gap-2">
                          <Sparkles size={12} className="shrink-0" />
                          <span>AI prompt matched: "{activeVideo.prompt}"</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* AI Comments Section */}
                  <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 md:p-6 space-y-6 shadow-xl">
                    <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
                      <MessageSquare size={16} className="text-red-500" />
                      Classroom AI Q&A ({activeVideoComments.length} Comments)
                    </h2>

                    {/* Interactive User Comment Form */}
                    <form onSubmit={handleAddComment} className="flex gap-3">
                      <div className="w-9 h-9 bg-red-600/10 border border-red-500/20 text-red-500 rounded-full flex items-center justify-center font-black text-xs shrink-0 select-none">
                        S
                      </div>
                      <div className="flex-1 relative">
                        <input 
                          type="text"
                          placeholder="Ask the Creator AI a question about this video lesson..."
                          value={newCommentText}
                          onChange={(e) => setNewCommentText(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 hover:border-slate-750 focus:border-red-500 rounded-xl pl-4 pr-12 py-2.5 text-xs font-semibold outline-none transition text-white placeholder-slate-500"
                        />
                        <button 
                          type="submit"
                          disabled={!newCommentText.trim() || isTypingCommentResponse}
                          className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white p-1.5 rounded-lg cursor-pointer transition active:scale-95"
                        >
                          <Send size={12} />
                        </button>
                      </div>
                    </form>

                    {/* Comment list */}
                    <div className="space-y-4">
                      {isTypingCommentResponse && (
                        <div className="flex gap-3 items-start animate-pulse">
                          <div className="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center shrink-0">
                            <Sparkles size={12} className="text-red-500 animate-spin" />
                          </div>
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Creator AI is writing reply...</span>
                            </div>
                            <p className="text-xs text-slate-500 italic">Thinking about math concepts...</p>
                          </div>
                        </div>
                      )}

                      {activeVideoComments.map((comment) => (
                        <div key={comment.id} className="flex gap-3 items-start border-b border-slate-800/40 pb-4 last:border-0 last:pb-0">
                          <img 
                            src={comment.avatar} 
                            alt={comment.author} 
                            className="w-8 h-8 rounded-full object-cover shrink-0 select-none"
                            referrerPolicy="no-referrer"
                          />
                          <div className="space-y-1 text-left flex-1">
                            <div className="flex items-center gap-2">
                              <span className={`text-[11px] font-black ${comment.isVerified ? 'text-red-400 font-black flex items-center gap-1 bg-red-500/5 px-1.5 py-0.5 rounded border border-red-500/10' : 'text-slate-300'}`}>
                                {comment.author}
                                {comment.isVerified && <CheckCircle2 size={11} className="text-red-500 shrink-0" fill="currentColor" />}
                              </span>
                              <span className="text-[9px] text-slate-500 font-bold uppercase">{comment.time}</span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed font-medium">
                              {comment.content}
                            </p>
                            <div className="flex items-center gap-3 pt-1 text-[10px] text-slate-500 font-bold uppercase tracking-wider select-none">
                              <button className="hover:text-slate-300 flex items-center gap-1">
                                <ThumbsUp size={11} />
                                <span>{comment.likes}</span>
                              </button>
                              <button className="hover:text-slate-300">Reply</button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                {/* Right Column: Interactive Lesson Dock & Up Next Curriculum */}
                <div className="lg:col-span-4 space-y-5">
                  
                  {/* Playlist Queue Controller (if playing from playlist) */}
                  {activePlaylistQueue && (() => {
                    const queuePlaylist = playlists.find(p => p.id === activePlaylistQueue.playlistId);
                    if (!queuePlaylist) return null;
                    const queueVideos = queuePlaylist.videoIds
                      .map(id => allVideos.find(v => v.id === id))
                      .filter((v): v is Video => Boolean(v));
                    
                    return (
                      <div className="bg-gradient-to-br from-indigo-950/80 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-4 space-y-3 shadow-xl text-left">
                        <div className="flex items-center justify-between border-b border-indigo-500/20 pb-2.5">
                          <div className="flex items-center gap-2 min-w-0">
                            <ListVideo size={16} className="text-indigo-400 animate-pulse shrink-0" />
                            <div className="min-w-0">
                              <span className="text-[9px] font-black uppercase tracking-widest text-indigo-400 block">Playing Playlist</span>
                              <h3 className="text-xs font-black text-white truncate max-w-[180px]">{queuePlaylist.name}</h3>
                            </div>
                          </div>
                          <button
                            onClick={() => setActivePlaylistQueue(null)}
                            className="text-slate-400 hover:text-white text-xs p-1 rounded hover:bg-slate-800"
                            title="Exit Playlist Queue"
                          >
                            ✕
                          </button>
                        </div>

                        <div className="flex items-center justify-between text-xs font-bold text-slate-300 bg-slate-950/60 p-2 rounded-xl border border-slate-800">
                          <span className="text-[11px]">Video {activePlaylistQueue.currentIndex + 1} of {queueVideos.length}</span>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={handlePrevInPlaylist}
                              disabled={activePlaylistQueue.currentIndex === 0}
                              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 rounded-lg text-slate-200 cursor-pointer transition flex items-center gap-0.5 text-[10px] font-black"
                            >
                              <SkipBack size={11} /> Prev
                            </button>
                            <button
                              type="button"
                              onClick={handleNextInPlaylist}
                              disabled={activePlaylistQueue.currentIndex >= queueVideos.length - 1}
                              className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 rounded-lg text-white cursor-pointer transition flex items-center gap-0.5 text-[10px] font-black shadow-md"
                            >
                              Next <SkipForward size={11} />
                            </button>
                          </div>
                        </div>

                        {/* List of queue items */}
                        <div className="space-y-1.5 max-h-44 overflow-y-auto pr-1">
                          {queueVideos.map((qv, idx) => {
                            const isCurrent = idx === activePlaylistQueue.currentIndex;
                            return (
                              <button
                                key={qv.id}
                                type="button"
                                onClick={() => {
                                  setActivePlaylistQueue({ ...activePlaylistQueue, currentIndex: idx });
                                  setActiveVideo(qv);
                                  setPlaybackError(null);
                                }}
                                className={`w-full text-left p-2 rounded-xl text-xs transition flex items-center gap-2 cursor-pointer ${isCurrent ? 'bg-indigo-600/30 border border-indigo-500/50 text-white font-black' : 'bg-slate-950/40 border border-slate-800/60 text-slate-400 hover:text-slate-200 hover:bg-slate-900'}`}
                              >
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black shrink-0 ${isCurrent ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'}`}>
                                  {idx + 1}
                                </span>
                                <span className="truncate flex-1">{qv.title}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })()}
                  
                  {/* Interactive Video Modal Dock: Transcript Search, Synced Notes & Bookmarks */}
                  <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 space-y-4 shadow-xl">
                    
                    {/* Tab Navigation Header */}
                    <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800">
                      <button
                        type="button"
                        onClick={() => setActiveDockTab('transcript')}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1 ${
                          activeDockTab === 'transcript'
                            ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                            : 'text-slate-400 hover:text-white hover:bg-slate-900'
                        }`}
                      >
                        <Search size={12} />
                        <span>Transcript</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveDockTab('notes')}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1 ${
                          activeDockTab === 'notes'
                            ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                            : 'text-slate-400 hover:text-white hover:bg-slate-900'
                        }`}
                      >
                        <FileText size={12} />
                        <span>Notes ({syncedNotes.length})</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveDockTab('bookmarks')}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1 ${
                          activeDockTab === 'bookmarks'
                            ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                            : 'text-slate-400 hover:text-white hover:bg-slate-900'
                        }`}
                      >
                        <Bookmark size={12} />
                        <span>Marks ({bookmarks.length})</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveDockTab('shortcuts')}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1 ${
                          activeDockTab === 'shortcuts'
                            ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30'
                            : 'text-slate-400 hover:text-white hover:bg-slate-900'
                        }`}
                      >
                        <Keyboard size={12} />
                        <span>Hotkeys</span>
                      </button>
                    </div>

                    {/* Tab: Shortcuts Reference */}
                    {activeDockTab === 'shortcuts' && (
                      <div className="space-y-3 text-slate-200">
                        <div className="text-xs text-amber-400 font-extrabold uppercase tracking-wider bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20 flex items-center gap-2">
                          <Keyboard size={15} />
                          <span>Keyboard Hotkey Controls</span>
                        </div>
                        <div className="space-y-1.5 text-xs">
                          {[
                            { keys: ['Space', 'K'], label: 'Play / Pause video' },
                            { keys: ['←', '→'], label: 'Rewind / Forward 5s' },
                            { keys: ['J', 'L'], label: 'Rewind / Forward 10s' },
                            { keys: ['↑', '↓'], label: 'Volume Up / Down' },
                            { keys: ['M'], label: 'Mute / Unmute audio' },
                            { keys: ['F'], label: 'Toggle Fullscreen' },
                            { keys: ['0 - 9'], label: 'Jump to 0% – 90%' },
                          ].map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800">
                              <div className="flex items-center gap-1">
                                {item.keys.map((k, i) => (
                                  <React.Fragment key={i}>
                                    <kbd className="px-2 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-amber-400 font-mono text-[10px] font-black shadow-sm">
                                      {k}
                                    </kbd>
                                    {i < item.keys.length - 1 && <span className="text-[10px] text-slate-500 font-bold">/</span>}
                                  </React.Fragment>
                                ))}
                              </div>
                              <span className="text-xs font-semibold text-slate-300">{item.label}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Tab 1: Search Transcript */}
                    {activeDockTab === 'transcript' && (
                      <div className="space-y-3">
                        <div className="relative">
                          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                          <input
                            type="text"
                            placeholder="Filter transcript keywords or MM:SS..."
                            value={transcriptSearch}
                            onChange={(e) => setTranscriptSearch(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-8 py-2 text-xs font-medium text-white placeholder-slate-500 outline-none focus:border-red-500 transition-colors"
                          />
                          {transcriptSearch && (
                            <button
                              type="button"
                              onClick={() => setTranscriptSearch('')}
                              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white text-xs"
                            >
                              ✕
                            </button>
                          )}
                        </div>

                        <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                          {filteredTranscript.length === 0 ? (
                            <p className="text-xs text-slate-500 italic text-center py-4">
                              No transcript segments match "{transcriptSearch}"
                            </p>
                          ) : (
                            filteredTranscript.map((item, idx) => {
                              const isActive = Math.abs(currentTime - item.timestamp) < 5;
                              return (
                                <button
                                  key={idx}
                                  type="button"
                                  onClick={() => handleSeekTo(item.timestamp)}
                                  className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all cursor-pointer flex items-start gap-2.5 ${
                                    isActive
                                      ? 'bg-red-950/40 border-red-500/40 text-white'
                                      : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:border-slate-700'
                                  }`}
                                >
                                  <span className="px-1.5 py-0.5 bg-red-600/20 text-red-400 border border-red-500/30 rounded font-mono text-[10px] font-black shrink-0 mt-0.5">
                                    {formatDuration(item.timestamp)}
                                  </span>
                                  <span className="font-medium leading-relaxed flex-1">
                                    {item.text}
                                  </span>
                                </button>
                              );
                            })
                          )}
                        </div>
                      </div>
                    )}

                    {/* Tab 2: Synced Notes to Timestamp */}
                    {activeDockTab === 'notes' && (
                      <div className="space-y-3">
                        <form onSubmit={handleSyncNote} className="space-y-2">
                          <textarea
                            rows={2}
                            placeholder="Write a lesson note to link to active video timestamp..."
                            value={noteText}
                            onChange={(e) => setNoteText(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs font-medium text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-colors resize-none"
                          />
                          <button
                            type="submit"
                            disabled={!noteText.trim()}
                            className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/20"
                          >
                            <FileText size={13} />
                            <span>Sync Note to {formatDuration(currentTime)}</span>
                          </button>
                        </form>

                        <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                          {syncedNotes.length === 0 ? (
                            <p className="text-xs text-slate-500 italic text-center py-4">
                              No synced notes yet. Type a note above to link it to the active video timestamp!
                            </p>
                          ) : (
                            syncedNotes.map((note) => (
                              <div
                                key={note.id}
                                className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 space-y-1 text-left"
                              >
                                <div className="flex items-center justify-between">
                                  <button
                                    type="button"
                                    onClick={() => handleSeekTo(note.timestamp)}
                                    className="px-2 py-0.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded font-mono text-[10px] font-black cursor-pointer transition flex items-center gap-1"
                                  >
                                    <Clock size={10} /> Jump to {formatDuration(note.timestamp)}
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setSyncedNotes(prev => prev.filter(n => n.id !== note.id))}
                                    className="text-slate-600 hover:text-rose-400 p-0.5 cursor-pointer"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </div>
                                <p className="text-xs text-slate-200 font-medium leading-relaxed">
                                  {note.text}
                                </p>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    )}

                    {/* Tab 3: Manual Bookmarks */}
                    {activeDockTab === 'bookmarks' && (
                      <div className="space-y-3">
                        <form onSubmit={handleAddBookmark} className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Bookmark title (optional)..."
                            value={bookmarkInput}
                            onChange={(e) => setBookmarkInput(e.target.value)}
                            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs font-medium text-white placeholder-slate-500 outline-none focus:border-amber-500 transition-colors"
                          />
                          <button
                            type="submit"
                            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-xl transition cursor-pointer shrink-0 flex items-center gap-1"
                          >
                            <Plus size={13} /> Add
                          </button>
                        </form>

                        <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                          {bookmarks.length === 0 ? (
                            <p className="text-xs text-slate-500 italic text-center py-4">
                              No manual bookmarks saved. Click 'Bookmark @ {formatDuration(currentTime)}' to add key moments!
                            </p>
                          ) : (
                            bookmarks.map((bm) => (
                              <div
                                key={bm.id}
                                className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between gap-2"
                              >
                                <div className="flex items-center gap-2 min-w-0">
                                  <button
                                    type="button"
                                    onClick={() => handleSeekTo(bm.timestamp)}
                                    className="px-2 py-0.5 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 rounded font-mono text-[10px] font-black cursor-pointer transition shrink-0"
                                  >
                                    {formatDuration(bm.timestamp)}
                                  </button>
                                  <span className="text-xs text-slate-200 font-bold truncate">
                                    {bm.title}
                                  </span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setBookmarks(prev => prev.filter(b => b.id !== bm.id))}
                                  className="text-slate-600 hover:text-rose-400 p-0.5 cursor-pointer shrink-0"
                                >
                                  <Trash2 size={12} />
                                </button>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    )}

                  </div>

                  <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b border-slate-800 pb-2">Up Next - Curriculum</h2>
                  <div className="space-y-3 max-h-[700px] overflow-y-auto pr-1">
                    {allVideos.filter(v => v.id !== activeVideo.id).slice(0, 7).map((video) => (
                      <div 
                        key={video.id}
                        onClick={() => { setActiveVideo(video); setPlaybackError(null); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                        className="flex gap-3 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-2xl p-2.5 transition-all cursor-pointer items-center text-left"
                      >
                        <div className="relative w-28 aspect-video rounded-xl overflow-hidden shrink-0 border border-slate-800">
                          <img 
                            src={video.thumbnail} 
                            alt={video.title} 
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <span className="absolute bottom-1 right-1 bg-black/80 text-[8px] font-black px-1 rounded text-white">{video.duration}</span>
                        </div>
                        <div className="flex-1 min-w-0 space-y-1">
                          <h3 className="text-xs font-black text-slate-200 line-clamp-2 leading-tight hover:text-red-400 transition-colors">
                            {video.title}
                          </h3>
                          <p className="text-[9px] text-slate-400 font-bold flex items-center gap-1 truncate">
                            {video.channelTitle}
                            <CheckCircle2 size={10} className="text-red-500" fill="currentColor" />
                          </p>
                          <div className="text-[9px] text-slate-500 font-semibold uppercase tracking-wider">
                            {(video.viewCount / 1000).toFixed(1)}K Views
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          ) : selectedPlaylistId ? (() => {
            const currentPl = playlists.find(p => p.id === selectedPlaylistId);
            if (!currentPl) {
              return (
                <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-3xl space-y-3">
                  <p className="text-slate-400 font-bold text-xs">Playlist not found or removed.</p>
                  <button
                    type="button"
                    onClick={() => setSelectedPlaylistId(null)}
                    className="px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Back to Edu Home
                  </button>
                </div>
              );
            }

            const plVideos = currentPl.videoIds
              .map(id => allVideos.find(v => v.id === id))
              .filter((v): v is Video => Boolean(v));

            return (
              <div className="space-y-6 animate-in fade-in duration-300">
                {/* Back button */}
                <button
                  type="button"
                  onClick={() => {
                    setSelectedPlaylistId(null);
                    setTagFilterConcept(null);
                    setTagFilterDifficulty('All');
                    setTagFilterSubject('All');
                  }}
                  className="flex items-center gap-2 text-xs font-black uppercase text-slate-400 hover:text-white transition cursor-pointer"
                >
                  <ArrowLeft size={16} /> Back to Edu Feed
                </button>

                {/* AI Progress Banner */}
                {autoTagProgressMsg && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-indigo-950/90 border border-indigo-500/50 rounded-2xl p-4 flex items-center justify-between gap-3 text-indigo-200 shadow-xl"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400 animate-pulse">
                        <BrainCircuit size={20} />
                      </div>
                      <span className="text-xs font-bold leading-relaxed">{autoTagProgressMsg}</span>
                    </div>
                    {isAutoTaggingPlaylist && (
                      <Loader2 size={18} className="animate-spin text-indigo-400 shrink-0" />
                    )}
                  </motion.div>
                )}

                {/* Playlist Hero Banner */}
                <div className="bg-gradient-to-r from-indigo-950/80 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6 md:p-8 space-y-4 shadow-2xl relative overflow-hidden">
                  <div className="flex flex-wrap items-start justify-between gap-4 relative z-10">
                    <div className="space-y-3 text-left max-w-2xl">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest inline-flex items-center gap-1.5">
                          <ListVideo size={12} />
                          Custom Playlist
                        </span>
                        <span className="text-[10px] font-mono text-slate-300 font-bold bg-slate-900/80 border border-slate-800 px-2.5 py-1 rounded-full">
                          {plVideos.length} Video Lessons
                        </span>
                        <span className="text-[10px] text-amber-300/90 font-bold bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full flex items-center gap-1.5" title={new Date(currentPl.updatedAt || currentPl.createdAt).toLocaleString()}>
                          <Clock size={11} className="text-amber-400" />
                          Last modified: {timeAgo(currentPl.updatedAt || currentPl.createdAt)}
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold bg-slate-900/80 border border-slate-800 px-2.5 py-1 rounded-full flex items-center gap-1.5" title={new Date(currentPl.createdAt).toLocaleDateString()}>
                          <Calendar size={11} className="text-slate-500" />
                          Created {new Date(currentPl.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                        </span>
                      </div>

                      <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight">
                        {currentPl.name}
                      </h1>

                      <p className="text-xs md:text-sm text-slate-300 font-medium leading-relaxed bg-slate-950/40 p-3.5 rounded-2xl border border-slate-800/60">
                        {currentPl.description || 'Custom playlist of educational video lessons.'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2.5 flex-wrap shrink-0 relative z-10">
                      <button
                        type="button"
                        onClick={() => handlePlayAllInPlaylist(currentPl)}
                        disabled={plVideos.length === 0}
                        className="px-5 py-2.5 bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-red-600/30 transition cursor-pointer active:scale-95"
                      >
                        <Play size={14} fill="currentColor" />
                        <span>Play All ({plVideos.length})</span>
                      </button>

                      {/* AI Auto-Tag Playlist Button */}
                      <button
                        type="button"
                        disabled={isAutoTaggingPlaylist === currentPl.id || plVideos.length === 0}
                        onClick={() => handleAutoTagPlaylist(currentPl)}
                        className="px-3.5 py-2.5 bg-amber-500/20 hover:bg-amber-500/30 disabled:opacity-40 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-md active:scale-95"
                        title="Run Gemini AI to auto-tag all lessons by concept, difficulty level, and subject matter"
                      >
                        {isAutoTaggingPlaylist === currentPl.id ? (
                          <Loader2 size={13} className="animate-spin text-amber-400" />
                        ) : (
                          <Sparkles size={13} className="text-amber-400" />
                        )}
                        <span>AI Auto-Tag Playlist</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setExportPlaylistModal(currentPl);
                          setCopiedSummary(false);
                        }}
                        className="px-3.5 py-2.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-md active:scale-95"
                        title="Export playlist as PDF summary or JSON file"
                      >
                        <Share2 size={13} className="text-indigo-400" />
                        <span>Export Playlist</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setEditingPlaylist(currentPl);
                          setPlaylistForm({
                            name: currentPl.name,
                            description: currentPl.description,
                            color: currentPl.color
                          });
                        }}
                        className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
                      >
                        <Edit3 size={13} />
                        <span>Edit</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeletePlaylist(currentPl.id)}
                        className="px-3.5 py-2.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border border-rose-500/30 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
                      >
                        <Trash2 size={13} />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* AI Taxonomy Breakdown & Concept Cloud Card */}
                {(() => {
                  const allConceptsSet = new Set<string>();
                  const subjectsMap: Record<string, number> = {};
                  const diffMap: Record<string, number> = { Beginner: 0, Intermediate: 0, Advanced: 0 };

                  plVideos.forEach(v => {
                    const tags = getVideoTags(v);
                    tags.concepts.forEach(c => allConceptsSet.add(c));
                    subjectsMap[tags.subject] = (subjectsMap[tags.subject] || 0) + 1;
                    diffMap[tags.difficulty] = (diffMap[tags.difficulty] || 0) + 1;
                  });

                  const uniqueConcepts = Array.from(allConceptsSet);
                  const subjectsList = Object.keys(subjectsMap);

                  return (
                    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 space-y-4 text-left shadow-lg">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="p-2 bg-amber-500/10 rounded-xl text-amber-400 border border-amber-500/20">
                            <BrainCircuit size={18} />
                          </div>
                          <div>
                            <h3 className="text-xs font-black uppercase tracking-wider text-white">AI Concept Taxonomy & Curriculum Matrix</h3>
                            <p className="text-[10px] text-slate-400 font-medium">
                              Auto-extracted concepts, subjects, and difficulty tiers based on content metadata
                            </p>
                          </div>
                        </div>

                        {tagFilterConcept && (
                          <button
                            type="button"
                            onClick={() => setTagFilterConcept(null)}
                            className="text-[10px] font-bold text-amber-400 hover:text-amber-300 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full flex items-center gap-1 cursor-pointer"
                          >
                            <X size={12} /> Clear Filter: #{tagFilterConcept}
                          </button>
                        )}
                      </div>

                      {/* Distribution breakdown */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        {/* Subjects */}
                        <div className="bg-slate-950/60 border border-slate-800 p-3 rounded-2xl space-y-1.5">
                          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-1">
                            <BookOpen size={11} className="text-indigo-400" /> Subject Matter
                          </span>
                          <div className="flex flex-wrap gap-1.5 pt-0.5">
                            {subjectsList.map(subj => (
                              <button
                                key={subj}
                                type="button"
                                onClick={() => setTagFilterSubject(prev => prev === subj ? 'All' : subj)}
                                className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border transition cursor-pointer ${
                                  tagFilterSubject === subj
                                    ? 'bg-indigo-600 text-white border-indigo-500'
                                    : 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20 hover:bg-indigo-500/20'
                                }`}
                              >
                                {subj} ({subjectsMap[subj]})
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Difficulty Tiers */}
                        <div className="bg-slate-950/60 border border-slate-800 p-3 rounded-2xl space-y-1.5">
                          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-1">
                            <Award size={11} className="text-emerald-400" /> Difficulty Breakdown
                          </span>
                          <div className="flex flex-wrap gap-1.5 pt-0.5">
                            <button
                              type="button"
                              onClick={() => setTagFilterDifficulty(prev => prev === 'Beginner' ? 'All' : 'Beginner')}
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition cursor-pointer ${
                                tagFilterDifficulty === 'Beginner'
                                  ? 'bg-emerald-600 text-white border-emerald-500'
                                  : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20'
                              }`}
                            >
                              Beginner ({diffMap.Beginner})
                            </button>
                            <button
                              type="button"
                              onClick={() => setTagFilterDifficulty(prev => prev === 'Intermediate' ? 'All' : 'Intermediate')}
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition cursor-pointer ${
                                tagFilterDifficulty === 'Intermediate'
                                  ? 'bg-amber-600 text-white border-amber-500'
                                  : 'bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20'
                              }`}
                            >
                              Intermediate ({diffMap.Intermediate})
                            </button>
                            <button
                              type="button"
                              onClick={() => setTagFilterDifficulty(prev => prev === 'Advanced' ? 'All' : 'Advanced')}
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition cursor-pointer ${
                                tagFilterDifficulty === 'Advanced'
                                  ? 'bg-rose-600 text-white border-rose-500'
                                  : 'bg-rose-500/10 text-rose-400 border-rose-500/20 hover:bg-rose-500/20'
                              }`}
                            >
                              Advanced ({diffMap.Advanced})
                            </button>
                          </div>
                        </div>

                        {/* Interactive Concept Cloud */}
                        <div className="bg-slate-950/60 border border-slate-800 p-3 rounded-2xl space-y-1.5 sm:col-span-2 md:col-span-1">
                          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-1">
                            <Tag size={11} className="text-amber-400" /> Concept Cloud
                          </span>
                          <div className="flex flex-wrap gap-1 max-h-20 overflow-y-auto pr-1">
                            {uniqueConcepts.map(concept => (
                              <button
                                key={concept}
                                type="button"
                                onClick={() => setTagFilterConcept(prev => prev === concept ? null : concept)}
                                className={`text-[9px] font-bold px-2 py-0.5 rounded-md border transition cursor-pointer ${
                                  tagFilterConcept === concept
                                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-black'
                                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-amber-300'
                                }`}
                              >
                                #{concept}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Video List inside Playlist */}
                <div className="space-y-3 text-left">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                    <div className="flex items-center gap-3">
                      <h2 className="text-xs font-black uppercase tracking-widest text-slate-400">
                        Saved Lessons ({plVideos.length})
                      </h2>
                      {(tagFilterDifficulty !== 'All' || tagFilterSubject !== 'All' || tagFilterConcept) && (
                        <span className="text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                          <Filter size={10} /> Filtered View
                        </span>
                      )}
                    </div>

                    {plVideos.length > 1 && (
                      <span className="text-[10px] text-indigo-400 font-bold bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                        <GripVertical size={12} />
                        Drag handles to reorder curriculum
                      </span>
                    )}
                  </div>

                  {plVideos.length > 0 ? (
                    <Reorder.Group
                      axis="y"
                      values={currentPl.videoIds}
                      onReorder={(newIds) => handleReorderPlaylistVideos(currentPl.id, newIds)}
                      className="space-y-3"
                    >
                      {currentPl.videoIds.map((vId, idx) => {
                        const video = allVideos.find(v => v.id === vId);
                        if (!video) return null;

                        const tags = getVideoTags(video);

                        // Apply Filters
                        if (tagFilterDifficulty !== 'All' && tags.difficulty !== tagFilterDifficulty) return null;
                        if (tagFilterSubject !== 'All' && tags.subject !== tagFilterSubject) return null;
                        if (tagFilterConcept && !tags.concepts.some(c => c.toLowerCase() === tagFilterConcept.toLowerCase())) return null;

                        const diffBadgeStyle = tags.difficulty === 'Beginner'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : tags.difficulty === 'Intermediate'
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                          : 'bg-rose-500/10 text-rose-400 border-rose-500/30';

                        return (
                          <Reorder.Item
                            key={vId}
                            value={vId}
                            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-3.5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-all shadow-md group select-none active:shadow-2xl active:border-indigo-500/50 active:bg-slate-850"
                          >
                            <div className="flex items-start md:items-center gap-3 min-w-0 flex-1 w-full">
                              {/* Drag Handle */}
                              <div
                                className="text-slate-500 group-hover:text-indigo-400 p-1.5 hover:bg-slate-800 rounded-xl cursor-grab active:cursor-grabbing shrink-0 transition self-center"
                                title="Drag to reorder lesson"
                              >
                                <GripVertical size={16} />
                              </div>

                              <span className="w-6 h-6 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center text-[10px] font-black text-slate-400 shrink-0 self-center">
                                {idx + 1}
                              </span>

                              <div 
                                onClick={() => {
                                  setActiveVideo(video);
                                  setActivePlaylistQueue({ playlistId: currentPl.id, currentIndex: idx });
                                  setSelectedPlaylistId(null);
                                  window.scrollTo({ top: 0, behavior: 'smooth' });
                                }}
                                className="relative w-36 aspect-video rounded-xl overflow-hidden shrink-0 border border-slate-800 cursor-pointer group-hover:border-indigo-500/50 transition-colors"
                              >
                                <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                                <span className="absolute bottom-1 right-1 bg-black/80 text-[8px] font-black px-1.5 py-0.5 rounded text-white">{video.duration}</span>
                              </div>

                              <div className="space-y-1.5 min-w-0 flex-1">
                                <div className="flex flex-wrap items-center gap-1.5">
                                  {/* Subject Pill */}
                                  <span className="text-[9px] font-black uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-md">
                                    {tags.subject}
                                  </span>

                                  {/* Difficulty Pill */}
                                  <span className={`text-[9px] font-black uppercase border px-2 py-0.5 rounded-md ${diffBadgeStyle}`}>
                                    {tags.difficulty}
                                  </span>

                                  {video.isAIGenerated && (
                                    <span className="text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded-md flex items-center gap-1">
                                      <Sparkles size={10} /> AI Lesson
                                    </span>
                                  )}
                                </div>

                                <h3 
                                  onClick={() => {
                                    setActiveVideo(video);
                                    setActivePlaylistQueue({ playlistId: currentPl.id, currentIndex: idx });
                                    setSelectedPlaylistId(null);
                                    window.scrollTo({ top: 0, behavior: 'smooth' });
                                  }}
                                  className="text-xs font-black text-slate-100 hover:text-red-400 transition cursor-pointer line-clamp-2 leading-snug"
                                >
                                  {video.title}
                                </h3>

                                <p className="text-[10px] text-slate-400 font-bold flex items-center gap-1">
                                  {video.channelTitle}
                                  <CheckCircle2 size={10} className="text-red-500" fill="currentColor" />
                                </p>

                                {/* Concept Tags Cloud */}
                                <div className="flex flex-wrap items-center gap-1 pt-1">
                                  {tags.concepts.map(concept => (
                                    <button
                                      key={concept}
                                      type="button"
                                      onClick={() => setTagFilterConcept(prev => prev === concept ? null : concept)}
                                      className="text-[9px] font-bold bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 px-2 py-0.5 rounded-md transition cursor-pointer"
                                    >
                                      #{concept}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </div>

                            {/* Actions Right */}
                            <div className="flex items-center gap-1.5 self-end md:self-center shrink-0">
                              {/* Re-Tag with AI */}
                              <button
                                type="button"
                                onClick={() => handleAutoTagSingleVideo(video)}
                                className="p-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20 rounded-lg cursor-pointer transition flex items-center gap-1 text-[10px] font-bold"
                                title="Re-analyze lesson with Gemini AI"
                              >
                                <Sparkles size={12} className="text-amber-400" />
                                <span className="hidden lg:inline">AI Re-Tag</span>
                              </button>

                              {/* Manual Tag Edit */}
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingTagsVideo(video);
                                  setCustomConceptInput('');
                                }}
                                className="p-1.5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 rounded-lg cursor-pointer transition"
                                title="Edit lesson tags manually"
                              >
                                <Tag size={13} />
                              </button>

                              {/* Move Up/Down buttons */}
                              <button
                                type="button"
                                disabled={idx === 0}
                                onClick={() => handleMoveVideoInPlaylist(currentPl.id, idx, 'up')}
                                className="p-1.5 bg-slate-950 hover:bg-slate-800 disabled:opacity-20 text-slate-400 rounded-lg cursor-pointer transition border border-slate-800"
                                title="Move Up"
                              >
                                <ChevronUp size={14} />
                              </button>
                              <button
                                type="button"
                                disabled={idx === plVideos.length - 1}
                                onClick={() => handleMoveVideoInPlaylist(currentPl.id, idx, 'down')}
                                className="p-1.5 bg-slate-950 hover:bg-slate-800 disabled:opacity-20 text-slate-400 rounded-lg cursor-pointer transition border border-slate-800"
                                title="Move Down"
                              >
                                <ChevronDown size={14} />
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  setActiveVideo(video);
                                  setActivePlaylistQueue({ playlistId: currentPl.id, currentIndex: idx });
                                  setSelectedPlaylistId(null);
                                  window.scrollTo({ top: 0, behavior: 'smooth' });
                                }}
                                className="px-3 py-1.5 bg-red-600/10 hover:bg-red-600/20 text-red-400 border border-red-500/20 rounded-xl text-xs font-bold cursor-pointer transition flex items-center gap-1"
                              >
                                <Play size={12} fill="currentColor" /> Play
                              </button>

                              <button
                                type="button"
                                onClick={() => handleToggleVideoInPlaylist(currentPl.id, video.id)}
                                className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg cursor-pointer transition"
                                title="Remove from playlist"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </Reorder.Item>
                        );
                      })}
                    </Reorder.Group>
                  ) : (
                    <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-3xl space-y-3">
                      <FolderPlus size={32} className="mx-auto text-slate-600" />
                      <p className="text-xs font-bold text-slate-400">This playlist is currently empty.</p>
                      <button
                        type="button"
                        onClick={() => setSelectedPlaylistId(null)}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                      >
                        Browse Videos & Add Lessons
                      </button>
                    </div>
                  )}
                </div>

                {/* Recommended Based on Playlist Section */}
                <div className="pt-6 border-t border-slate-800 space-y-4 text-left">
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-gradient-to-r from-amber-950/40 via-indigo-950/30 to-slate-900 border border-amber-500/30 rounded-2xl p-4 shadow-xl">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-amber-500/20 rounded-xl text-amber-400 border border-amber-500/30 shadow-inner">
                        <Sparkles size={20} className="animate-pulse" />
                      </div>
                      <div>
                        <h2 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
                          Recommended Based on Playlist
                          <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full lowercase font-mono">
                            gemini 3.6 ai
                          </span>
                        </h2>
                        <p className="text-[11px] text-slate-300 font-medium">
                          Personalized lesson suggestions synthesized from the aggregate metadata & topics in <span className="font-bold text-amber-300">"{currentPl.name}"</span>
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={loadingRecommendationsFor === currentPl.id}
                      onClick={() => fetchPlaylistRecommendations(currentPl, true)}
                      className="px-3.5 py-2 bg-amber-500/20 hover:bg-amber-500/30 disabled:opacity-40 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95"
                      title="Regenerate 3 new recommendations using Gemini AI"
                    >
                      {loadingRecommendationsFor === currentPl.id ? (
                        <Loader2 size={13} className="animate-spin text-amber-400" />
                      ) : (
                        <RefreshCw size={13} className="text-amber-400" />
                      )}
                      <span>Refresh AI Suggestions</span>
                    </button>
                  </div>

                  {addedRecNotice && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-md"
                    >
                      <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                      <span>{addedRecNotice}</span>
                    </motion.div>
                  )}

                  {loadingRecommendationsFor === currentPl.id ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3 animate-pulse">
                          <div className="w-full aspect-video bg-slate-800 rounded-xl"></div>
                          <div className="h-3 bg-slate-800 rounded w-3/4"></div>
                          <div className="h-2 bg-slate-800/80 rounded w-1/2"></div>
                          <div className="h-10 bg-slate-800/50 rounded-xl"></div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    (() => {
                      const recs = playlistRecommendationsMap[currentPl.id] || [];
                      if (recs.length === 0) {
                        return (
                          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-center space-y-3">
                            <Sparkles size={24} className="mx-auto text-amber-400/80" />
                            <p className="text-xs text-slate-400 font-medium">Click below to generate personalized video suggestions based on this playlist.</p>
                            <button
                              type="button"
                              onClick={() => fetchPlaylistRecommendations(currentPl, true)}
                              className="px-4 py-2 bg-amber-500 text-slate-950 hover:bg-amber-400 font-black rounded-xl text-xs transition cursor-pointer"
                            >
                              Generate AI Recommendations
                            </button>
                          </div>
                        );
                      }

                      return (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {recs.map((rec) => {
                            const isAlreadyInPlaylist = currentPl.videoIds.some(
                              id => id === rec.id || (rec.youtubeId && id === rec.youtubeId)
                            );

                            const diffStyle = rec.difficulty === 'Beginner'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                              : rec.difficulty === 'Intermediate'
                              ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                              : 'bg-rose-500/10 text-rose-400 border-rose-500/30';

                            return (
                              <div
                                key={rec.id}
                                className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-4 flex flex-col justify-between space-y-3 transition-all shadow-md hover:shadow-xl group"
                              >
                                <div className="space-y-2.5">
                                  {/* Thumbnail */}
                                  <div
                                    onClick={() => handlePlayRecommendation(currentPl, rec)}
                                    className="relative w-full aspect-video rounded-xl overflow-hidden border border-slate-800 cursor-pointer group-hover:border-amber-500/50 transition-colors"
                                  >
                                    <img src={rec.thumbnail} alt={rec.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                                    <span className="absolute bottom-1.5 right-1.5 bg-black/80 text-[9px] font-black px-1.5 py-0.5 rounded text-white">{rec.duration}</span>
                                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                      <div className="p-2.5 bg-red-600 rounded-full text-white shadow-lg transform group-hover:scale-110 transition-transform">
                                        <Play size={16} fill="currentColor" />
                                      </div>
                                    </div>
                                  </div>

                                  {/* Badges */}
                                  <div className="flex flex-wrap items-center gap-1.5">
                                    <span className="text-[9px] font-black uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-md">
                                      {rec.subject}
                                    </span>
                                    <span className={`text-[9px] font-black uppercase border px-2 py-0.5 rounded-md ${diffStyle}`}>
                                      {rec.difficulty}
                                    </span>
                                  </div>

                                  {/* Title & Channel */}
                                  <h3
                                    onClick={() => handlePlayRecommendation(currentPl, rec)}
                                    className="text-xs font-black text-white hover:text-amber-300 transition cursor-pointer line-clamp-2 leading-snug"
                                  >
                                    {rec.title}
                                  </h3>
                                  <p className="text-[10px] text-slate-400 font-bold">
                                    {rec.channelTitle}
                                  </p>

                                  {/* Why Recommended AI Reason Box */}
                                  <div className="bg-slate-950/80 border border-amber-500/20 rounded-xl p-2.5 space-y-1">
                                    <span className="text-[9px] font-black uppercase text-amber-400 flex items-center gap-1">
                                      <BrainCircuit size={11} /> AI Matching Reason
                                    </span>
                                    <p className="text-[10px] text-slate-300 font-medium leading-normal italic">
                                      "{rec.reason}"
                                    </p>
                                  </div>

                                  {/* Concept Tags */}
                                  <div className="flex flex-wrap gap-1">
                                    {rec.concepts.map((concept, cIdx) => (
                                      <span key={cIdx} className="text-[9px] font-bold bg-slate-950 text-slate-400 border border-slate-800 px-2 py-0.5 rounded-md">
                                        #{concept}
                                      </span>
                                    ))}
                                  </div>
                                </div>

                                {/* Actions */}
                                <div className="pt-2 border-t border-slate-800/80 flex items-center gap-2">
                                  <button
                                    type="button"
                                    disabled={isAlreadyInPlaylist}
                                    onClick={() => handleAddRecommendationToPlaylist(currentPl, rec)}
                                    className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                                      isAlreadyInPlaylist
                                        ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md active:scale-95'
                                    }`}
                                  >
                                    {isAlreadyInPlaylist ? (
                                      <>
                                        <Check size={13} className="text-emerald-400" /> In Playlist
                                      </>
                                    ) : (
                                      <>
                                        <Plus size={13} /> Add to Playlist
                                      </>
                                    )}
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => handlePlayRecommendation(currentPl, rec)}
                                    className="p-2 bg-red-600/10 hover:bg-red-600/20 text-red-400 border border-red-500/20 rounded-xl transition cursor-pointer"
                                    title="Play Video"
                                  >
                                    <Play size={14} fill="currentColor" />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })()
                  )}
                </div>
              </div>
            );
          })() : (
            // Home Feed Grid Layout
            <div className="space-y-8">
              
              {/* Immersive Welcome Banner */}
              <div className="bg-gradient-to-r from-red-950/40 via-indigo-950/20 to-red-950/40 border border-red-500/20 rounded-3xl p-6 md:p-8 text-white shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-3 relative z-10 text-left max-w-2xl">
                  <span className="bg-red-500/10 text-red-400 border border-red-500/20 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest inline-flex items-center gap-1.5">
                    <Sparkles size={11} className="animate-pulse" />
                    Interactive Google Veo 3.1
                  </span>
                  <h1 className="text-2xl md:text-3xl font-black tracking-tight leading-none text-white">
                    Omni AI Video Studio
                  </h1>
                  <p className="text-slate-300 text-xs md:text-sm leading-relaxed font-medium">
                    Welcome to the classroom of the future. Search for real educational YouTube channels like <strong className="text-white">3Blue1Brown</strong> and <strong className="text-white">TED-Ed</strong>, or type an AI prompt below to instantly compile custom lessons aligned perfectly with your syllabus!
                  </p>
                </div>

                {/* Instant Generator Studio Card */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shrink-0 w-full md:w-[320px] shadow-xl relative z-10">
                  <form onSubmit={handleManualGenerate} className="space-y-3 text-left">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                      Fast AI Studio compiler
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder={`e.g. Explain ${topicFormatted}...`}
                        value={customPrompt}
                        onChange={(e) => setCustomPrompt(e.target.value)}
                        disabled={isGenerating}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-red-500 transition-colors disabled:opacity-50"
                      />
                      <button
                        type="submit"
                        disabled={isGenerating || !customPrompt.trim()}
                        className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-red-600 hover:bg-red-500 text-white p-1.5 rounded-lg transition-all active:scale-95 disabled:opacity-40 disabled:scale-100 cursor-pointer"
                        title="Compile Custom Video"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                  </form>
                  <div className="flex justify-between items-center text-[8px] text-slate-500 font-mono mt-3.5 pt-2.5 border-t border-slate-800/60 uppercase">
                    <span>Model: veo-3.1-preview</span>
                    <span>HD 16:9</span>
                  </div>
                </div>
              </div>

              {/* Live Generation Progress stepper */}
              {isGenerating && (
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 animate-in fade-in duration-300">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold flex items-center gap-2 text-red-400">
                      <Loader2 size={14} className="animate-spin text-red-500" />
                      EduTube compiler is compiling video stream...
                    </span>
                    <span className="font-mono text-red-500 font-bold">{generationProgress}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className="h-full bg-red-600 transition-all duration-300 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.5)]" 
                      style={{ width: `${generationProgress}%` }}
                    />
                  </div>
                  <div className="bg-slate-950 border border-slate-850 rounded-xl p-3 space-y-1 max-h-[90px] overflow-y-auto">
                    {generationLogs.map((log, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-[10px] font-mono text-slate-400">
                        <span className="text-red-500 select-none">❯</span>
                        <span>{log}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Chips row */}
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none select-none">
                {['All', 'AI Generated', 'My Uploads', 'Calculus', 'Algebra', 'Trigonometry', 'Statistics'].map(chip => {
                  const isActive = selectedChip === chip;
                  return (
                    <button
                      key={chip}
                      onClick={() => setSelectedChip(chip)}
                      className={`px-4 py-2 rounded-full text-xs font-black transition-all uppercase tracking-wider shrink-0 cursor-pointer border ${isActive ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-950/20' : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'}`}
                    >
                      {chip}
                    </button>
                  );
                })}
              </div>

              {/* Video Grid Feed */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-sm font-black text-slate-400 uppercase tracking-widest">
                    Recommended Lectures ({filteredVideos.length})
                  </h2>
                </div>

                {filteredVideos.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredVideos.map((video) => (
                      <div 
                        key={video.id}
                        onClick={() => { setActiveVideo(video); setPlaybackError(null); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                        className="group bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl overflow-hidden hover:shadow-2xl transition-all cursor-pointer shadow-md flex flex-col justify-between text-left"
                      >
                        {/* Thumbnail */}
                        <div className="relative aspect-video overflow-hidden border-b border-slate-800 bg-slate-950">
                          <img 
                            src={video.thumbnail} 
                            alt={video.title} 
                            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                            referrerPolicy="no-referrer"
                          />
                          <span className="absolute bottom-2 right-2 bg-black/85 text-[10px] font-bold px-1.5 py-0.5 rounded text-white">
                            {video.duration}
                          </span>
                          
                          {video.isAIGenerated && (
                            <span className="absolute top-2 left-2 bg-red-600 text-white text-[8px] font-black tracking-widest uppercase px-2 py-0.5 rounded-md flex items-center gap-1 shadow-lg shadow-red-950/30 border border-red-500/20">
                              <Sparkles size={9} />
                              AI Upload
                            </span>
                          )}

                          <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-white shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                              <Play size={20} fill="currentColor" />
                            </div>
                          </div>
                        </div>

                        {/* Video Info info card body */}
                        <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                          <div className="space-y-1">
                            <h3 className="font-black text-sm text-slate-100 leading-snug line-clamp-2 group-hover:text-red-500 transition-colors">
                              {video.title}
                            </h3>
                            <p className="text-xs text-slate-400 font-bold flex items-center gap-1 truncate">
                              {video.channelTitle}
                              <CheckCircle2 size={12} className="text-red-500" fill="currentColor" />
                            </p>
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-slate-500 font-bold uppercase tracking-wider border-t border-slate-850/60 pt-3">
                            <span>{(video.viewCount || 2300).toLocaleString()} Views</span>
                            <div className="flex items-center gap-2">
                              <span>{timeAgo(video.publishedAt)}</span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setVideoForPlaylistModal(video);
                                }}
                                className="p-1.5 text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 rounded-lg border border-slate-800 transition flex items-center gap-1 text-[10px] font-black lowercase cursor-pointer"
                                title="Save to Playlist"
                              >
                                <FolderPlus size={13} className="text-indigo-400" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-3xl text-slate-400 font-bold uppercase text-xs tracking-wider">
                    No curriculum videos found matching "{searchQuery}" or chosen category.
                  </div>
                )}
              </div>

            </div>
          )}

        </div>

      </div>

      {/* Modal 1: Add Video to Playlist Selector */}
      <AnimatePresence>
        {videoForPlaylistModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-5 shadow-2xl text-left"
            >
              <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 rounded-xl flex items-center justify-center shrink-0">
                    <FolderPlus size={18} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white">Save Video to Playlist</h3>
                    <p className="text-[10px] text-slate-400 font-bold truncate max-w-[260px]">{videoForPlaylistModal.title}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setVideoForPlaylistModal(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {/* List of existing playlists */}
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {playlists.map(pl => {
                  const inPlaylist = pl.videoIds.includes(videoForPlaylistModal.id);
                  const modTime = pl.updatedAt || pl.createdAt;
                  return (
                    <button
                      key={pl.id}
                      type="button"
                      onClick={() => handleToggleVideoInPlaylist(pl.id, videoForPlaylistModal.id)}
                      className={`w-full flex items-center justify-between p-3 rounded-2xl border text-xs font-bold transition cursor-pointer ${inPlaylist ? 'bg-indigo-600/20 border-indigo-500/50 text-white font-black' : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-850'}`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 pr-2 text-left">
                        <ListVideo size={16} className={inPlaylist ? 'text-indigo-400 shrink-0' : 'text-slate-500 shrink-0'} />
                        <div className="min-w-0">
                          <span className="truncate block font-bold text-slate-100">{pl.name}</span>
                          {pl.description && (
                            <span className="text-[10px] text-slate-400 font-normal truncate block max-w-[200px]">{pl.description}</span>
                          )}
                          <span className="text-[9px] text-slate-500 font-medium flex items-center gap-1 mt-0.5">
                            <Clock size={9} className="text-amber-400" /> Modified {timeAgo(modTime)}
                          </span>
                        </div>
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase flex items-center gap-1 shrink-0 ${inPlaylist ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'}`}>
                        {inPlaylist ? <><Check size={11} /> Saved</> : '+ Add'}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Quick Inline New Playlist */}
              <form onSubmit={handleCreateInlinePlaylist} className="pt-3 border-t border-slate-800 space-y-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">Or create a new playlist:</span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="New playlist title..."
                    value={inlineNewPlaylistName}
                    onChange={(e) => setInlineNewPlaylistName(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition"
                  />
                  <button
                    type="submit"
                    disabled={!inlineNewPlaylistName.trim()}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-black rounded-xl transition cursor-pointer"
                  >
                    Create
                  </button>
                </div>
              </form>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setVideoForPlaylistModal(null)}
                  className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl cursor-pointer"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal 1.5: Functional Share Lecture Modal */}
      <AnimatePresence>
        {isShareModalOpen && activeVideo && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full space-y-5 shadow-2xl text-left"
            >
              <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 bg-red-600/20 text-red-500 border border-red-500/30 rounded-xl flex items-center justify-center shrink-0">
                    <Share2 size={18} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white">Share Educational Lecture</h3>
                    <p className="text-[10px] text-slate-400 font-bold truncate max-w-[300px]">{activeVideo.title}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setIsShareModalOpen(false);
                    setCopiedLink(false);
                  }}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Start Timestamp check */}
              {currentTime > 0 && (
                <label className="flex items-center gap-2.5 bg-slate-950 border border-slate-800 p-3 rounded-2xl cursor-pointer hover:border-slate-700 transition">
                  <input
                    type="checkbox"
                    checked={shareWithTimestamp}
                    onChange={(e) => {
                      setShareWithTimestamp(e.target.checked);
                      setCopiedLink(false);
                    }}
                    className="accent-red-600 cursor-pointer"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-white block">Include dynamic playhead timestamp</span>
                    <span className="text-[10px] text-slate-400">Recipient starts exactly at lesson timeframe {formatDuration(currentTime)}</span>
                  </div>
                </label>
              )}

              {/* URL Display and copy box */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider block">Lecture Connection URL</span>
                <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 p-2.5 rounded-2xl">
                  <input
                    type="text"
                    readOnly
                    value={shareUrl}
                    className="bg-transparent text-xs text-indigo-300 font-mono flex-1 outline-none select-all overflow-ellipsis"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(shareUrl);
                      setCopiedLink(true);
                      setTimeout(() => setCopiedLink(false), 2000);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                      copiedLink 
                        ? 'bg-emerald-600 text-white' 
                        : 'bg-red-600 hover:bg-red-500 text-white'
                    }`}
                  >
                    {copiedLink ? (
                      <>
                        <Check size={13} />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy size={13} />
                        <span>Copy Link</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Custom Social Channels Block */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {/* Channel 1: Google Classroom */}
                <button
                  onClick={() => window.open(`https://classroom.google.com/share?url=${encodeURIComponent(shareUrl)}`, '_blank')}
                  className="flex flex-col items-center justify-center p-3 bg-slate-950 border border-slate-850 hover:border-emerald-500/40 rounded-2xl text-[10px] font-bold text-slate-300 hover:text-white transition group cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
                    <Globe size={16} />
                  </div>
                  Classroom
                </button>

                {/* Channel 2: WhatsApp */}
                <button
                  onClick={() => window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(`Check out this excellent EduTube lesson: ${activeVideo.title} - ${shareUrl}`)}`, '_blank')}
                  className="flex flex-col items-center justify-center p-3 bg-slate-950 border border-slate-850 hover:border-emerald-500/40 rounded-2xl text-[10px] font-bold text-slate-300 hover:text-white transition group cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
                    <MessageSquare size={16} />
                  </div>
                  WhatsApp
                </button>

                {/* Channel 3: Twitter / X */}
                <button
                  onClick={() => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(`Reviewing my syllabus on EduTube: ${activeVideo.title}`)}&url=${encodeURIComponent(shareUrl)}`, '_blank')}
                  className="flex flex-col items-center justify-center p-3 bg-slate-950 border border-slate-850 hover:border-indigo-500/40 rounded-2xl text-[10px] font-bold text-slate-300 hover:text-white transition group cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
                    <Send size={16} />
                  </div>
                  Twitter (X)
                </button>

                {/* Channel 4: Email */}
                <button
                  onClick={() => window.open(`mailto:?subject=${encodeURIComponent(`Recommended Lecture: ${activeVideo.title}`)}&body=${encodeURIComponent(`Check out this lecture on EduTube:\n\n${activeVideo.title}\n${shareUrl}`)}`, '_blank')}
                  className="flex flex-col items-center justify-center p-3 bg-slate-950 border border-slate-850 hover:border-indigo-500/40 rounded-2xl text-[10px] font-bold text-slate-300 hover:text-white transition group cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
                    <Mail size={16} />
                  </div>
                  Email
                </button>
              </div>

              {/* Embedding Assignment code */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider block">LMS / Assignment iframe embed block</span>
                <div className="bg-slate-950 border border-slate-850 p-2.5 rounded-2xl flex items-center justify-between gap-3">
                  <code className="text-[9px] text-slate-400 font-mono truncate select-all">
                    {`<iframe src="${shareUrl}" width="640" height="360" allowfullscreen></iframe>`}
                  </code>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(`<iframe src="${shareUrl}" width="640" height="360" allowfullscreen></iframe>`);
                      alert('Embedding assignment block copied!');
                    }}
                    className="px-2.5 py-1 bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-[10px] rounded-lg font-bold cursor-pointer shrink-0"
                  >
                    Copy HTML
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal 2: Create / Edit Playlist Modal */}
      <AnimatePresence>
        {(isCreatePlaylistOpen || editingPlaylist) && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-5 shadow-2xl text-left"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <FolderPlus size={18} className="text-indigo-400" />
                  <span>{editingPlaylist ? 'Edit Playlist' : 'Create Custom Playlist'}</span>
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatePlaylistOpen(false);
                    setEditingPlaylist(null);
                  }}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              <form onSubmit={editingPlaylist ? handleUpdatePlaylist : handleCreatePlaylist} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Playlist Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Biology Lab & Cell Mechanics"
                    value={playlistForm.name}
                    onChange={(e) => setPlaylistForm({ ...playlistForm, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Description (Optional)</label>
                  <textarea
                    rows={2}
                    placeholder="Brief overview of topics covered in this playlist..."
                    value={playlistForm.description}
                    onChange={(e) => setPlaylistForm({ ...playlistForm, description: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition resize-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Accent Color</label>
                  <div className="flex items-center gap-2">
                    {['indigo', 'emerald', 'amber', 'rose', 'purple', 'sky'].map(color => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setPlaylistForm({ ...playlistForm, color })}
                        className={`w-7 h-7 rounded-full transition border-2 flex items-center justify-center cursor-pointer ${playlistForm.color === color ? 'scale-110 border-white shadow-lg' : 'border-transparent opacity-70 hover:opacity-100'} ${
                          color === 'indigo' ? 'bg-indigo-600' :
                          color === 'emerald' ? 'bg-emerald-600' :
                          color === 'amber' ? 'bg-amber-600' :
                          color === 'rose' ? 'bg-rose-600' :
                          color === 'purple' ? 'bg-purple-600' : 'bg-sky-600'
                        }`}
                      >
                        {playlistForm.color === color && <Check size={12} className="text-white" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-end gap-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setIsCreatePlaylistOpen(false);
                      setEditingPlaylist(null);
                    }}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!playlistForm.name.trim()}
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-black rounded-xl cursor-pointer shadow-lg shadow-indigo-600/30"
                  >
                    {editingPlaylist ? 'Save Changes' : 'Create Playlist'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal 3: Export Playlist Modal */}
      <AnimatePresence>
        {exportPlaylistModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full space-y-5 shadow-2xl text-left"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
                    <Share2 size={18} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white">Export Educational Curriculum</h3>
                    <p className="text-[10px] text-slate-400 font-medium">Generate shareable summaries for students & educators</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setExportPlaylistModal(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Summary Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-200">{exportPlaylistModal.name}</span>
                  <span className="text-[10px] font-mono text-indigo-400 font-bold bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded-full">
                    {exportPlaylistModal.videoIds.length} Lessons
                  </span>
                </div>
                <p className="text-xs text-slate-400 line-clamp-2">
                  {exportPlaylistModal.description || 'Custom playlist of educational video lessons.'}
                </p>
              </div>

              {/* Export Format Options */}
              <div className="space-y-3">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">Choose Export Format:</span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Option 1: PDF Document */}
                  <button
                    type="button"
                    onClick={() => handleExportPlaylistPDF(exportPlaylistModal)}
                    className="p-4 bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-850 rounded-2xl text-left transition group cursor-pointer space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="p-2 bg-indigo-500/10 rounded-xl text-indigo-400 group-hover:scale-110 transition-transform">
                        <Printer size={18} />
                      </div>
                      <span className="text-[9px] font-black uppercase bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full">PDF / Print</span>
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white group-hover:text-indigo-400 transition">Printable PDF Guide</h4>
                      <p className="text-[10px] text-slate-400 font-normal leading-relaxed mt-0.5">
                        Clean formatted document ready to print or save as PDF for student hand-outs.
                      </p>
                    </div>
                  </button>

                  {/* Option 2: JSON Export */}
                  <button
                    type="button"
                    onClick={() => handleExportPlaylistJSON(exportPlaylistModal)}
                    className="p-4 bg-slate-950 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-850 rounded-2xl text-left transition group cursor-pointer space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-400 group-hover:scale-110 transition-transform">
                        <FileJson size={18} />
                      </div>
                      <span className="text-[9px] font-black uppercase bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full">JSON Data</span>
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-white group-hover:text-emerald-400 transition">Download JSON File</h4>
                      <p className="text-[10px] text-slate-400 font-normal leading-relaxed mt-0.5">
                        Raw structured data file containing video links, metadata, and lesson ordering.
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Text Summary Quick Copy */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">Plain Text Summary</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(getPlaylistTextSummary(exportPlaylistModal));
                      setCopiedSummary(true);
                      setTimeout(() => setCopiedSummary(false), 2000);
                    }}
                    className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedSummary ? <><Check size={12} className="text-emerald-400" /> Copied to Clipboard!</> : <><FileText size={12} /> Copy Text Summary</>}
                  </button>
                </div>
                <textarea
                  readOnly
                  rows={4}
                  value={getPlaylistTextSummary(exportPlaylistModal)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-[11px] font-mono text-slate-300 outline-none resize-none select-all"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setExportPlaylistModal(null)}
                  className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl cursor-pointer"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal 4: Edit Lesson AI Tags */}
      <AnimatePresence>
        {editingTagsVideo && (() => {
          const currentTags = getVideoTags(editingTagsVideo);
          return (
            <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full space-y-5 shadow-2xl text-left"
              >
                <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-amber-500/10 rounded-xl text-amber-400 border border-amber-500/20">
                      <Tag size={18} />
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-white">Edit Lesson Concept Taxonomy</h3>
                      <p className="text-[10px] text-slate-400 font-bold truncate max-w-[300px]">{editingTagsVideo.title}</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setEditingTagsVideo(null)}
                    className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
                  >
                    <X size={16} />
                  </button>
                </div>

                <div className="space-y-4">
                  {/* Subject Input */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-slate-400">Subject Matter</label>
                    <input
                      type="text"
                      value={currentTags.subject}
                      onChange={(e) => {
                        const val = e.target.value;
                        setVideoAITagsMap(prev => ({
                          ...prev,
                          [editingTagsVideo.id]: { ...currentTags, subject: val }
                        }));
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-white outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Difficulty Selection */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-slate-400">Difficulty Level</label>
                    <div className="flex gap-2">
                      {(['Beginner', 'Intermediate', 'Advanced'] as const).map((diff) => (
                        <button
                          key={diff}
                          type="button"
                          onClick={() => {
                            setVideoAITagsMap(prev => ({
                              ...prev,
                              [editingTagsVideo.id]: { ...currentTags, difficulty: diff }
                            }));
                          }}
                          className={`flex-1 py-2 text-xs font-bold rounded-xl border transition cursor-pointer ${
                            currentTags.difficulty === diff
                              ? diff === 'Beginner' ? 'bg-emerald-600 text-white border-emerald-500'
                                : diff === 'Intermediate' ? 'bg-amber-600 text-white border-amber-500'
                                : 'bg-rose-600 text-white border-rose-500'
                              : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          {diff}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Concept Tags List */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase text-slate-400">Concept Tags</label>
                    <div className="flex flex-wrap gap-1.5 p-2 bg-slate-950 border border-slate-800 rounded-xl min-h-[48px]">
                      {currentTags.concepts.map((concept, idx) => (
                        <span key={idx} className="bg-slate-900 border border-slate-700 text-slate-200 text-[10px] font-bold px-2 py-1 rounded-lg flex items-center gap-1.5">
                          #{concept}
                          <button
                            type="button"
                            onClick={() => {
                              const updated = currentTags.concepts.filter((_, i) => i !== idx);
                              setVideoAITagsMap(prev => ({
                                ...prev,
                                [editingTagsVideo.id]: { ...currentTags, concepts: updated }
                              }));
                            }}
                            className="hover:text-rose-400 text-slate-500 cursor-pointer"
                          >
                            <X size={10} />
                          </button>
                        </span>
                      ))}
                    </div>

                    {/* Add new concept inline */}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!customConceptInput.trim()) return;
                        const newConcepts = [...currentTags.concepts, customConceptInput.trim()];
                        setVideoAITagsMap(prev => ({
                          ...prev,
                          [editingTagsVideo.id]: { ...currentTags, concepts: newConcepts }
                        }));
                        setCustomConceptInput('');
                      }}
                      className="flex gap-2 pt-1"
                    >
                      <input
                        type="text"
                        placeholder="Add new concept tag (e.g. Limits)..."
                        value={customConceptInput}
                        onChange={(e) => setCustomConceptInput(e.target.value)}
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none focus:border-amber-500"
                      />
                      <button
                        type="submit"
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition cursor-pointer"
                      >
                        + Add Tag
                      </button>
                    </form>
                  </div>

                  {/* AI Re-Analyze Button */}
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={async () => {
                        await handleAutoTagSingleVideo(editingTagsVideo);
                      }}
                      className="px-4 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
                    >
                      <Sparkles size={13} className="text-amber-400" /> Auto-Regenerate with Gemini AI
                    </button>

                    <button
                      type="button"
                      onClick={() => setEditingTagsVideo(null)}
                      className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl cursor-pointer transition"
                    >
                      Done
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          );
        })()}
      </AnimatePresence>

      {/* Modal 5: Upload Custom Video Modal */}
      <AnimatePresence>
        {isUploadModalOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 max-w-2xl w-full space-y-6 shadow-2xl text-left my-8"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 rounded-2xl flex items-center justify-center shrink-0">
                    <Upload size={20} />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white uppercase tracking-wide">Upload Video to EduTube</h3>
                    <p className="text-xs text-slate-400 font-medium">Publish local video files or external streams directly to the catalog.</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  disabled={isUploading}
                  className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 cursor-pointer disabled:opacity-40"
                >
                  <X size={18} />
                </button>
              </div>

              {isUploading ? (
                /* Processing/Uploading State */
                <div className="space-y-6 py-8 text-center">
                  <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                    <div className="absolute inset-0 border-4 border-indigo-500/10 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                    <Upload className="text-indigo-400 animate-bounce" size={32} />
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-black text-white uppercase tracking-wider">Publishing your lesson...</h4>
                    <p className="text-xs text-slate-400 font-medium max-w-sm mx-auto">Please wait while the system registers your tutorial file and generates syllabus index tags.</p>
                  </div>

                  <div className="space-y-3 max-w-md mx-auto">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-bold text-slate-400">Ingestion progress</span>
                      <span className="font-mono text-indigo-400 font-bold">{uploadProgress}%</span>
                    </div>
                    <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div 
                        className="h-full bg-gradient-to-r from-indigo-600 to-indigo-400 transition-all duration-300 rounded-full shadow-[0_0_8px_rgba(99,102,241,0.5)]" 
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  </div>

                  {/* Log console */}
                  <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 max-w-md mx-auto space-y-1 text-left h-24 overflow-y-auto shadow-inner font-mono text-[10px]">
                    {uploadLogs.map((log, idx) => (
                      <div key={idx} className="text-slate-400 flex items-start gap-1.5">
                        <span className="text-indigo-500 select-none">❯</span>
                        <span>{log}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                /* Upload Form */
                <form onSubmit={handlePublishUploadedVideo} className="space-y-5">
                  
                  {/* Source Toggle */}
                  <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800/80">
                    <button
                      type="button"
                      onClick={() => setUploadForm({ ...uploadForm, useLocalFile: true })}
                      className={`py-2 px-3 rounded-xl text-xs font-black uppercase tracking-wider transition cursor-pointer ${uploadForm.useLocalFile ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      Local File
                    </button>
                    <button
                      type="button"
                      onClick={() => setUploadForm({ ...uploadForm, useLocalFile: false })}
                      className={`py-2 px-3 rounded-xl text-xs font-black uppercase tracking-wider transition cursor-pointer ${!uploadForm.useLocalFile ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      External Link / URL
                    </button>
                  </div>

                  {/* Local file inputs or Link Input */}
                  {uploadForm.useLocalFile ? (
                    <div className="border-2 border-dashed border-slate-800 hover:border-indigo-500/50 rounded-2xl p-6 text-center space-y-3 bg-slate-950/40 transition-colors relative">
                      <input
                        type="file"
                        accept="video/*"
                        onChange={handleVideoFileChange}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                        required={!uploadedVideoFile}
                      />
                      <div className="p-3 bg-indigo-500/15 border border-indigo-500/20 text-indigo-400 rounded-2xl inline-flex items-center justify-center">
                        <VideoIcon size={24} />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-slate-200">
                          {uploadedVideoFile ? `Selected: ${uploadedVideoFile.name}` : "Click or drag video file to upload"}
                        </p>
                        <p className="text-[10px] text-slate-500">Supports standard MP4, WebM, or OGG containers (Max 200MB)</p>
                      </div>
                      {uploadedVideoFile && (
                        <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-full font-bold inline-flex items-center gap-1">
                          <Check size={11} /> Auto-detected file duration: {uploadForm.duration || 'Detecting...'}
                        </span>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Stream URL / YouTube Link *</label>
                      <input
                        type="url"
                        required
                        placeholder="https://www.youtube.com/watch?v=... or direct MP4 URL"
                        value={uploadForm.videoUrl}
                        onChange={(e) => {
                          const val = e.target.value;
                          setUploadForm(prev => ({
                            ...prev,
                            videoUrl: val
                          }));
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-colors"
                      />
                    </div>
                  )}

                  {/* Metadata Fields Row */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Video Title */}
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Video Title *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Introduction to Quantum Physics"
                        value={uploadForm.title}
                        onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                      />
                    </div>

                    {/* Creator/Channel Name */}
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Creator / Channel Name *</label>
                      <input
                        type="text"
                        required
                        value={uploadForm.creator}
                        onChange={(e) => setUploadForm({ ...uploadForm, creator: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {/* Subject and Level */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Academic Subject Selection */}
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Academic Subject *</label>
                      <select
                        value={uploadForm.subject}
                        onChange={(e) => setUploadForm({ ...uploadForm, subject: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 outline-none focus:border-indigo-500"
                      >
                        {['Mathematics', 'Calculus', 'Algebra', 'Trigonometry', 'Geometry', 'Probability', 'Statistics', 'Physics', 'Chemistry', 'Biology', 'Computer Science', 'General STEM'].map(subj => (
                          <option key={subj} value={subj}>{subj}</option>
                        ))}
                      </select>
                    </div>

                    {/* Difficulty Selection */}
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Syllabus Depth / Rigor *</label>
                      <div className="flex gap-2 h-[38px]">
                        {(['Beginner', 'Intermediate', 'Advanced'] as const).map(diff => (
                          <button
                            key={diff}
                            type="button"
                            onClick={() => setUploadForm({ ...uploadForm, difficulty: diff })}
                            className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer ${uploadForm.difficulty === diff ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'}`}
                          >
                            {diff}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Manual Duration (if not local file) and Concept Tags */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Video Duration */}
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Duration (MM:SS) *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 12:45"
                        value={uploadForm.duration}
                        onChange={(e) => setUploadForm({ ...uploadForm, duration: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                      />
                    </div>

                    {/* Concept Tags */}
                    <div className="space-y-1 text-left">
                      <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">AI Concept Tags (comma separated)</label>
                      <input
                        type="text"
                        placeholder="e.g. Wave Function, Schrödinger, Quarks"
                        value={uploadForm.customTags}
                        onChange={(e) => setUploadForm({ ...uploadForm, customTags: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {/* Description */}
                  <div className="space-y-1 text-left">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-400">Educational Description</label>
                    <textarea
                      rows={2}
                      placeholder="Add key highlights and what formulas or syllabus points are covered in this tutorial lecture..."
                      value={uploadForm.description}
                      onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 resize-none"
                    />
                  </div>

                  {/* Thumbnail File Selector */}
                  <div className="space-y-2 text-left">
                    <label className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">Custom Video Thumbnail (Optional)</label>
                    <div className="flex items-center gap-4">
                      {/* File Selector Button */}
                      <div className="relative">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleThumbnailFileChange}
                          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                        />
                        <button
                          type="button"
                          className="px-4 py-2 bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
                        >
                          Select Image File
                        </button>
                      </div>

                      {/* Preview or default note */}
                      <div className="flex-1 flex items-center gap-3">
                        {thumbnailPreviewUrl ? (
                          <div className="w-16 h-9 rounded-md overflow-hidden border border-slate-800 bg-slate-950">
                            <img src={thumbnailPreviewUrl} alt="Thumbnail Preview" className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <p className="text-[10px] text-slate-500 italic">
                            No thumbnail selected. The system will automatically generate a beautiful {uploadForm.subject}-themed chalkboard artwork.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Form Footer Actions */}
                  <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        setIsUploadModalOpen(false);
                        setUploadedVideoFile(null);
                        setUploadedThumbnailFile(null);
                        setThumbnailPreviewUrl('');
                      }}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black uppercase tracking-wider rounded-xl transition cursor-pointer shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 active:scale-95"
                    >
                      <Upload size={14} />
                      <span>Publish Video</span>
                    </button>
                  </div>

                </form>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
