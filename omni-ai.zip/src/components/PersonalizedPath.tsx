import React from 'react';
import { 
  DiagnosticResult, 
  LecturePathStep, 
  MasteryLevel 
} from '../modules/diagnostic/types';
import { QuestionSelector } from '../modules/diagnostic/questionSelector';
import { 
  CheckCircle2, 
  Sparkles, 
  Clock, 
  FastForward, 
  BookOpen, 
  AlertTriangle, 
  ArrowRight, 
  RotateCcw, 
  Play, 
  ShieldCheck, 
  TrendingUp, 
  Award,
  Zap,
  Check
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface PersonalizedPathProps {
  result: DiagnosticResult;
  onStartLesson?: (subtopicId: string, subtopicTitle: string, action: string) => void;
  onRetake?: () => void;
  className?: string;
}

export const PersonalizedPath: React.FC<PersonalizedPathProps> = ({
  result,
  onStartLesson,
  onRetake,
  className
}) => {
  const lectureSteps: LecturePathStep[] = QuestionSelector.generateLecturePath(result);

  const getMasteryBadge = (level: MasteryLevel) => {
    switch (level) {
      case 'mastered':
        return (
          <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
            <CheckCircle2 size={12} /> Mastered (&gt;80%) &bull; Skipped
          </span>
        );
      case 'proficient':
        return (
          <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 flex items-center gap-1">
            <Zap size={12} /> Proficient (60-80%) &bull; Quick Review
          </span>
        );
      case 'developing':
        return (
          <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 flex items-center gap-1">
            <BookOpen size={12} /> Developing (40-60%) &bull; Full Lecture
          </span>
        );
      case 'beginner':
        return (
          <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20 flex items-center gap-1">
            <AlertTriangle size={12} /> Beginner (&lt;40%) &bull; Foundation
          </span>
        );
    }
  };

  const hoursSavedDecimal = (result.totalMinutesSaved / 60).toFixed(1);
  const masteredCount = Object.values(result.topicScores).filter(t => t.masteryLevel === 'mastered').length;
  const proficientCount = Object.values(result.topicScores).filter(t => t.masteryLevel === 'proficient').length;
  const totalSubtopics = Object.keys(result.topicScores).length || 6;

  return (
    <div className={cn("flex flex-col gap-6 p-6 sm:p-8 max-w-4xl mx-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl", className)}>
      {/* 1. Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-900 via-indigo-800 to-purple-900 text-white p-6 sm:p-8 shadow-md">
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-white/10 backdrop-blur-sm border border-white/20 text-indigo-200 flex items-center gap-1.5 w-fit">
              <Sparkles size={13} className="text-amber-300" />
              Prior Knowledge Diagnostic Results
            </span>

            {/* Headline Requirement 3: "You already know X% of this chapter" */}
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              You already know {result.overallScore}% of this chapter!
            </h2>

            <p className="text-indigo-200 text-sm max-w-xl leading-relaxed">
              Based on your Item Response Theory diagnostic, we've trimmed the curriculum so you never waste time on topics you've already mastered.
            </p>
          </div>

          {/* Time Saved Stat Callout Requirement 3: "You're skipping 45 minutes of content" */}
          <div className="shrink-0 p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex flex-col items-center justify-center text-center sm:min-w-[170px]">
            <FastForward size={24} className="text-emerald-400 mb-1 animate-bounce" />
            <span className="text-2xl font-black text-emerald-300">
              {result.totalMinutesSaved} Mins
            </span>
            <span className="text-[11px] font-semibold text-indigo-100">
              You're skipping {result.totalMinutesSaved} minutes of content!
            </span>
          </div>
        </div>
      </div>

      {/* 2. Key Metrics Summary Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex flex-col">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Overall Score</span>
          <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">{result.overallScore}%</span>
          <span className="text-[11px] text-slate-400 mt-0.5">IRT Latent θ: {result.abilityTheta}</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex flex-col">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Mastered Topics</span>
          <span className="text-2xl font-black text-emerald-500 mt-1">{masteredCount} of {totalSubtopics}</span>
          <span className="text-[11px] text-emerald-600/80 dark:text-emerald-400/80 mt-0.5">100% Skipped in lectures</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex flex-col">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Quick Reviews</span>
          <span className="text-2xl font-black text-amber-500 mt-1">{proficientCount} topics</span>
          <span className="text-[11px] text-slate-400 mt-0.5">Accelerated 5-min recap</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex flex-col">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Diagnostic Time</span>
          <span className="text-2xl font-black text-slate-700 dark:text-slate-300 mt-1">
            {Math.floor(result.timeTaken / 60)}m {result.timeTaken % 60}s
          </span>
          <span className="text-[11px] text-slate-400 mt-0.5">{result.totalQuestionsAnswered} items evaluated</span>
        </div>
      </div>

      {/* 3. Personalized Lecture Sequence Timeline */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-black text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Award size={18} className="text-indigo-500" />
              Your Custom Lecture Path
            </h3>
            <p className="text-xs text-slate-500">
              Mastered topics are bypassed automatically. Focus exclusively on where you need growth.
            </p>
          </div>

          {onRetake && (
            <button
              onClick={onRetake}
              className="text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 transition cursor-pointer"
            >
              <RotateCcw size={12} /> Retake Diagnostic
            </button>
          )}
        </div>

        <div className="space-y-3">
          {lectureSteps.map((step) => {
            const isSkipped = step.action === 'skip';

            return (
              <div 
                key={step.subtopicId}
                className={cn(
                  "p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
                  isSkipped 
                    ? "bg-slate-50/70 dark:bg-slate-800/30 border-slate-200/50 dark:border-slate-800/50 opacity-80" 
                    : "bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 shadow-sm hover:border-indigo-400"
                )}
              >
                <div className="flex items-start gap-3.5">
                  <div className={cn(
                    "w-8 h-8 rounded-xl font-bold text-xs flex items-center justify-center shrink-0 mt-0.5",
                    isSkipped 
                      ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" 
                      : "bg-indigo-500/10 text-indigo-500 border border-indigo-500/20"
                  )}>
                    {isSkipped ? <Check size={14} /> : step.stepNumber}
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <h4 className={cn(
                        "text-sm font-bold",
                        isSkipped ? "line-through text-slate-500 dark:text-slate-400" : "text-slate-800 dark:text-slate-100"
                      )}>
                        {step.subtopicTitle}
                      </h4>
                      {getMasteryBadge(step.masteryLevel)}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {step.description}
                    </p>
                  </div>
                </div>

                {/* Duration / Action */}
                <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                  <div className="text-right">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      {isSkipped ? "0 mins" : `${step.durationMinutes} mins`}
                    </span>
                    {step.timeSavedMinutes > 0 && (
                      <span className="block text-[10px] text-emerald-500 font-semibold">
                        Saved {step.timeSavedMinutes}m
                      </span>
                    )}
                  </div>

                  {!isSkipped && (
                    <button
                      onClick={() => onStartLesson?.(step.subtopicId, step.subtopicTitle, step.action)}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Play size={12} /> Start Lesson
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
