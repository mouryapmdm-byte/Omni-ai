export * from '../../../../src/modules/virtual-labs/labs/biology/BiologyLabSuite';
import { BiologyLabSuite } from '../../../../src/modules/virtual-labs/labs/biology/BiologyLabSuite';
export default BiologyLabSuite;
