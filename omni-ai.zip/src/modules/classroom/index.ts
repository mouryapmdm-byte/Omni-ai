/**
 * Classroom Module Public API
 * Responsibilities: 3D Classroom rendering, Avatar control, Smartboard presentation, and lecture management.
 */

export * from '../../components/ThreeDClassroom';
export * from '../../components/SmartboardVisualPresentationArchitect';
export * from '../../components/AvatarEngineControlModal';
export * from '../../components/Minimal3DControls';
export * from '../../components/ClassroomSyncControl';
export * from '../../components/LectureControlsDropdown';
export * from '../../components/LectureProgressTimeline';
