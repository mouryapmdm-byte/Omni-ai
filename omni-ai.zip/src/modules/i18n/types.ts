export type SupportedLanguageCode = 
  | 'en' // English (Default)
  | 'hi' // Hindi
  | 'ta' // Tamil
  | 'te' // Telugu
  | 'bn' // Bengali
  | 'mr' // Marathi
  | 'kn' // Kannada
  | 'ml' // Malayalam
  | 'gu' // Gujarati
  | 'pa' // Punjabi
  | 'ur'; // Urdu (RTL)

export interface LanguagePreference {
  studentId: string;
  primaryLanguage: SupportedLanguageCode;
  secondaryLanguage?: SupportedLanguageCode;
  bilingualMode: boolean;
  prefersRegionalExamples: boolean;
  numberSystem: 'indian' | 'international';
  dateFormat: 'DD/MM/YYYY' | 'MM/DD/YYYY';
  currency: 'INR' | 'USD';
  updatedAt: string;
}

export interface LanguageMetadata {
  code: SupportedLanguageCode;
  name: string;
  nativeName: string;
  script: string;
  dir: 'ltr' | 'rtl';
  voiceCode: string;
  flagEmoji: string;
  sampleGreeting: string;
}

export interface CulturalAdaptationRule {
  category: 'names' | 'sports' | 'food' | 'festivals' | 'real_world_objects';
  westernTerm: string;
  indianEquivalents: Record<SupportedLanguageCode, string>;
  explanation: string;
}

export interface BilingualSegment {
  id: string;
  termEnglish: string;
  termRegional: string;
  pronunciation?: string;
  conceptDefinitionEnglish: string;
  conceptDefinitionRegional: string;
  culturalAnalogy: string;
  formulaPreserved?: string;
}

export interface TranslationDictionary {
  [key: string]: string | TranslationDictionary;
}
