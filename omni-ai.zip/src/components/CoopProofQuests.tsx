import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, Sparkles, Trophy, MessageSquare, Shield, Activity, Play, 
  RotateCcw, CheckCircle2, ChevronRight, HelpCircle, Send, Radio,
  AlertCircle, RefreshCw, Zap, Award, Coins
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

interface ProofOption {
  text: string;
  isCorrect: boolean;
  explanation: string;
}

interface ProofStep {
  id: string;
  title: string;
  instruction: string;
  mathPrompt: string;
  options: ProofOption[];
  peerHints: {
    peerName: string;
    text: string;
  }[];
}

interface CoopQuest {
  id: string;
  title: string;
  difficulty: 'Novice' | 'Expert' | 'Grandmaster' | 'Archmage';
  field: 'Mathematical Analysis' | 'Set Theory' | 'Algebra' | 'Geometry';
  icon: string;
  description: string;
  steps: ProofStep[];
  successRewardXp: number;
  successRewardCoins: number;
}

const COOP_QUESTS: CoopQuest[] = [
  {
    id: 'coop_q1',
    title: "Transcendence of Euler's Identity",
    difficulty: 'Expert',
    field: 'Mathematical Analysis',
    icon: '🌌',
    description: "Connect three separate branches of science (algebra, trigonometry, and calculus) into a single unified equation: e^{i\\pi} + 1 = 0.",
    successRewardXp: 400,
    successRewardCoins: 250,
    steps: [
      {
        id: 'q1_s1',
        title: "Taylor Expansion of e^x",
        instruction: "Identify the correct power series expansion of the exponential function e^x centered at 0.",
        mathPrompt: "e^x = \\sum_{n=0}^{\\infty} \\frac{x^n}{n!}",
        options: [
          {
            text: "e^x = 1 + x + \\frac{x^2}{2!} + \\frac{x^3}{3!} + \\dots = \\sum_{n=0}^{\\infty} \\frac{x^n}{n!}",
            isCorrect: true,
            explanation: "This is the standard Maclaurin series for e^x, which converges absolutely for all complex numbers x."
          },
          {
            text: "e^x = 1 - \\frac{x^2}{2!} + \\frac{x^4}{4!} - \\dots = \\sum_{n=0}^{\\infty} \\frac{(-1)^n x^{2n}}{(2n)!}",
            isCorrect: false,
            explanation: "This represents the Taylor series expansion of cos(x), not e^x."
          },
          {
            text: "e^x = x - \\frac{x^2}{2} + \\frac{x^3}{3} - \\dots = \\sum_{n=1}^{\\infty} \\frac{(-1)^{n-1}x^n}{n}",
            isCorrect: false,
            explanation: "This is the Taylor expansion for the natural logarithm ln(1+x)."
          }
        ],
        peerHints: [
          { peerName: "Rohan Sharma", text: "We need the full infinite summation of powers divided by factorial. Check the signs, e^x has only positive elements!" },
          { peerName: "Sneha Kapoor", text: "Right, and it should start at n=0 so the first constant element is 1." }
        ]
      },
      {
        id: 'q1_s2',
        title: "Substituting the Imaginary Variable iθ",
        instruction: "Substitute x = iθ into the Taylor series and evaluate the powers of the imaginary unit i (where i^2 = -1, i^3 = -i, i^4 = 1).",
        mathPrompt: "e^{i\\theta} = \\sum_{n=0}^{\\infty} \\frac{(i\\theta)^n}{n!}",
        options: [
          {
            text: "e^{i\\theta} = \\left(1 - \\frac{\\theta^2}{2!} + \\frac{\\theta^4}{4!} - \\dots\\right) + i\\left(\\theta - \\frac{\\theta^3}{3!} + \\frac{\\theta^5}{5!} - \\dots\\right)",
            isCorrect: true,
            explanation: "By calculating the powers of i, the even terms become real with alternating signs, and the odd terms remain imaginary with alternating signs."
          },
          {
            text: "e^{i\\theta} = \\left(1 + \\theta^2 + \\theta^4 + \\dots\\right) + i\\left(\\theta + \\theta^3 + \\theta^5 + \\dots\\right)",
            isCorrect: false,
            explanation: "This is incorrect because it ignores the alternating signs introduced by multiplying the imaginary units (i^2 = -1)."
          },
          {
            text: "e^{i\\theta} = e^\\theta \\cdot (\\cos\\theta + i\\sin\\theta)",
            isCorrect: false,
            explanation: "This expression multiplies the exponential growth with the rotation, which is redundant."
          }
        ],
        peerHints: [
          { peerName: "Priya Nair", text: "Note how even powers of i flip signs between +1 and -1, while odd powers contain a lingering coefficient i." },
          { peerName: "Rohan Sharma", text: "Yes! Separating real and imaginary components is the key to creating Euler's trigonometry formula." }
        ]
      },
      {
        id: 'q1_s3',
        title: "Reassembling into Trigonometric Parts",
        instruction: "Recognize the real and imaginary subseries inside the brackets as the Taylor expansions of sine and cosine.",
        mathPrompt: "e^{i\\theta} = \\text{Re} + i\\text{Im}",
        options: [
          {
            text: "e^{i\\theta} = \\cos\\theta + i\\sin\\theta",
            isCorrect: true,
            explanation: "The real subseries matches the Taylor series of cos(θ), and the imaginary subseries matches sin(θ), forming Euler's Formula."
          },
          {
            text: "e^{i\\theta} = \\sin\\theta + i\\cos\\theta",
            isCorrect: false,
            explanation: "The terms are reversed; cos(θ) is the even function (real parts) and sin(θ) is the odd function (imaginary parts)."
          },
          {
            text: "e^{i\\theta} = \\cos(i\\theta) + \\sin(i\\theta)",
            isCorrect: false,
            explanation: "This doesn't separate the complex rotation properly and is not Euler's formula."
          }
        ],
        peerHints: [
          { peerName: "Sneha Kapoor", text: "Look at the first term: cos(0) = 1, and the real series starts with 1. So cos(θ) represents the real section!" },
          { peerName: "Priya Nair", text: "And sin(θ) starts with θ, which matches the starting term of our imaginary series section!" }
        ]
      },
      {
        id: 'q1_s4',
        title: "Evaluating at θ = π",
        instruction: "Substitute θ = π into Euler's formula and solve to reveal the final transcendental beauty.",
        mathPrompt: "e^{i\\pi} + 1 = 0",
        options: [
          {
            text: "e^{i\\pi} = \\cos\\pi + i\\sin\\pi = -1 + i(0) = -1 \\implies e^{i\\pi} + 1 = 0",
            isCorrect: true,
            explanation: "Since cos(π) = -1 and sin(π) = 0, the equation simplifies perfectly to e^{i\pi} + 1 = 0."
          },
          {
            text: "e^{i\\pi} = \\cos\\pi - i\\sin\\pi = 1 - 0 = 1 \\implies e^{i\\pi} - 1 = 0",
            isCorrect: false,
            explanation: "This is incorrect because cos(π) is -1, not 1."
          },
          {
            text: "e^{i\\pi} = 0 + i(-1) = -i \\implies e^{i\\pi} + i = 0",
            isCorrect: false,
            explanation: "This is incorrect because cos(π) is -1 and sin(π) is 0, not vice-versa."
          }
        ],
        peerHints: [
          { peerName: "Rohan Sharma", text: "We are at the finish line! Evaluate the trigonometric coordinates of π on the unit circle." },
          { peerName: "Sneha Kapoor", text: "The x-coordinate is cos(π) = -1, the y-coordinate is sin(π) = 0. Combine them!" }
        ]
      }
    ]
  },
  {
    id: 'coop_q2',
    title: "Dual Relations of De Morgan's Laws",
    difficulty: 'Novice',
    field: 'Set Theory',
    icon: '🔮',
    description: "Establish the dual set relation between logical union and intersection complements: \\overline{A \\cup B} = \\overline{A} \\cap \\overline{B}.",
    successRewardXp: 200,
    successRewardCoins: 120,
    steps: [
      {
        id: 'q2_s1',
        title: "Element Membership Assumption",
        instruction: "Assume an arbitrary element x is in the complement of the union of sets A and B, and express what this means.",
        mathPrompt: "x \\in \\overline{A \\cup B}",
        options: [
          {
            text: "x \\in \\overline{A \\cup B} \\implies x \\notin (A \\cup B)",
            isCorrect: true,
            explanation: "By definition, an element is in the complement of a set if and only if it is not a member of the original set."
          },
          {
            text: "x \\in \\overline{A \\cup B} \\implies x \\in A \\text{ and } x \\in B",
            isCorrect: false,
            explanation: "This states the opposite: that x is in both sets, which is the intersection."
          },
          {
            text: "x \\in \\overline{A \\cup B} \\implies x \\in \\overline{A} \\cup \\overline{B}",
            isCorrect: false,
            explanation: "This is what we want to prove, we cannot assume it in step 1."
          }
        ],
        peerHints: [
          { peerName: "Amit Mehra", text: "Let's unpack the definition of a complement. If something is in the complement of S, it is NOT in S!" }
        ]
      },
      {
        id: 'q2_s2',
        title: "Applying Logical Negation of Disjunction",
        instruction: "Express what it means for x NOT to be in the union (A ∪ B) in terms of individual membership.",
        mathPrompt: "x \\notin (A \\cup B)",
        options: [
          {
            text: "x \\notin A \\text{ and } x \\notin B",
            isCorrect: true,
            explanation: "For an element to NOT be in the union, it must not belong to A AND it must not belong to B. A disjunction negation translates to a conjunction."
          },
          {
            text: "x \\notin A \\text{ or } x \\notin B",
            isCorrect: false,
            explanation: "This is incorrect because if x was not in A but was in B, it would still belong to the union."
          },
          {
            text: "x \\in A \\text{ or } x \\in B",
            isCorrect: false,
            explanation: "This defines the union itself, not its negation."
          }
        ],
        peerHints: [
          { peerName: "Sneha Kapoor", text: "If x is not in the union, it cannot be in either set! So it's an 'AND' condition." }
        ]
      },
      {
        id: 'q2_s3',
        title: "Rewriting as Set Complements",
        instruction: "Translate the logical conditions back into complement notation for each set individually.",
        mathPrompt: "x \\notin A \\land x \\notin B",
        options: [
          {
            text: "x \\in \\overline{A} \\text{ and } x \\in \\overline{B}",
            isCorrect: true,
            explanation: "Since x is not in A, it is in A's complement. Since x is not in B, it is in B's complement."
          },
          {
            text: "x \\notin \\overline{A} \\text{ or } x \\notin \\overline{B}",
            isCorrect: false,
            explanation: "This is incorrect complement translation."
          },
          {
            text: "x \\in \\overline{A \\cap B}",
            isCorrect: false,
            explanation: "This is a different set entirely, we must translate individually first."
          }
        ],
        peerHints: [
          { peerName: "Priya Nair", text: "Translate 'not in A' to 'in complement of A'." }
        ]
      },
      {
        id: 'q2_s4',
        title: "Final Intersection Inclusion",
        instruction: "Conclude that x must lie in the intersection of the two complements, completing the proof.",
        mathPrompt: "\\overline{A \\cup B} \\subseteq \\overline{A} \\cap \\overline{B}",
        options: [
          {
            text: "x \\in \\overline{A} \\cap \\overline{B} \\implies \\overline{A \\cup B} \\subseteq \\overline{A} \\cap \\overline{B}",
            isCorrect: true,
            explanation: "Since x is in both complements, it is in their intersection. Double inclusion completes the proof."
          },
          {
            text: "x \\in \\overline{A} \\cup \\overline{B} \\implies \\overline{A \\cup B} \\subseteq \\overline{A} \\cup \\overline{B}",
            isCorrect: false,
            explanation: "This is incorrect because we established a conjunction (and), which matches intersection (∩), not union (∪)."
          }
        ],
        peerHints: [
          { peerName: "Rohan Sharma", text: "Awesome! We have shown inclusion. The dual proof works exactly symmetrically in reverse!" }
        ]
      }
    ]
  },
  {
    id: 'coop_q3',
    title: "Arithmetic Progression Induction",
    difficulty: 'Grandmaster',
    field: 'Algebra',
    icon: '⚡',
    description: "Rigorously prove the formula for the sum of the first n positive integers, \\sum_{i=1}^n i = \\frac{n(n+1)}{2}, using the principle of induction.",
    successRewardXp: 350,
    successRewardCoins: 180,
    steps: [
      {
        id: 'q3_s1',
        title: "Base Case verification",
        instruction: "Verify the base case. Demonstrate that the summation formula holds true for n=1.",
        mathPrompt: "P(1)",
        options: [
          {
            text: "\\text{LHS} = 1, \\text{ RHS} = \\frac{1(1+1)}{2} = \\frac{2}{2} = 1 \\implies \\text{LHS} = \\text{RHS}",
            isCorrect: true,
            explanation: "For n=1, the left-hand sum contains just 1, and the right-hand formula evaluates to 1. The base case holds."
          },
          {
            text: "\\text{LHS} = 1, \\text{ RHS} = \\frac{1(1-1)}{2} = 0 \\implies \\text{LHS} \\neq \\text{RHS}",
            isCorrect: false,
            explanation: "This is the wrong formula (minus instead of plus)."
          }
        ],
        peerHints: [
          { peerName: "Rohan Sharma", text: "Simple start! Plug n=1 into LHS and RHS." }
        ]
      },
      {
        id: 'q3_s2',
        title: "State Inductive Hypothesis",
        instruction: "State the induction hypothesis. Assume the formula holds for an arbitrary positive integer k.",
        mathPrompt: "P(k)",
        options: [
          {
            text: "1 + 2 + 3 + \\dots + k = \\frac{k(k+1)}{2}",
            isCorrect: true,
            explanation: "This is the induction hypothesis. We assume this relationship holds in order to prove it holds for k+1."
          },
          {
            text: "1 + 2 + 3 + \\dots + k + (k+1) = \\frac{(k+1)(k+2)}{2}",
            isCorrect: false,
            explanation: "This is the target P(k+1) we want to prove, not the hypothesis P(k)."
          }
        ],
        peerHints: [
          { peerName: "Sneha Kapoor", text: "Just assume the theorem works for k. That's our stepping stone." }
        ]
      },
      {
        id: 'q3_s3',
        title: "Setting up the Inductive Step",
        instruction: "Add the next sequential term (k+1) to both sides of our induction hypothesis equation.",
        mathPrompt: "P(k) \\implies P(k+1)",
        options: [
          {
            text: "(1 + 2 + \\dots + k) + (k+1) = \\frac{k(k+1)}{2} + (k+1)",
            isCorrect: true,
            explanation: "By adding (k+1) to both sides of the hypothesis, we obtain an expression representing the sum up to k+1."
          },
          {
            text: "(1 + 2 + \\dots + k) \\times (k+1) = \\frac{k(k+1)}{2} \\times (k+1)",
            isCorrect: false,
            explanation: "This is multiplying both sides, which does not represent summation addition."
          }
        ],
        peerHints: [
          { peerName: "Priya Nair", text: "Add the (k+1)th term to both sides. Keep the algebra clean." }
        ]
      },
      {
        id: 'q3_s4',
        title: "Algebraic Simplification",
        instruction: "Simplify the right-hand expression to match the formula's format for n = k + 1.",
        mathPrompt: "\\frac{k(k+1)}{2} + (k+1)",
        options: [
          {
            text: "(k+1)\\left[\\frac{k}{2} + 1\\right] = (k+1)\\left[\\frac{k+2}{2}\\right] = \\frac{(k+1)(k+2)}{2}",
            isCorrect: true,
            explanation: "Factoring out (k+1) from both terms yields (k+1)(k/2 + 1) = (k+1)(k+2)/2. This completes the induction step!"
          },
          {
            text: "\\frac{k^2 + k}{2} + k + 1 = \\frac{k^2 + 3k + 1}{2}",
            isCorrect: false,
            explanation: "This algebraic simplification is incorrect; a common denominator makes it (k^2+3k+2)/2, not (k^2+3k+1)/2."
          }
        ],
        peerHints: [
          { peerName: "Rohan Sharma", text: "Factor out (k+1) first! It's much easier than expanding everything." },
          { peerName: "Sneha Kapoor", text: "Amazing! We proved P(k+1). Induction completes." }
        ]
      }
    ]
  },
  {
    id: 'coop_q4',
    title: "Visual Pythagorean Decomposition",
    difficulty: 'Expert',
    field: 'Geometry',
    icon: '📐',
    description: "Derive the fundamental relation a^2 + b^2 = c^2 using a geometric decomposition of a larger boundary square.",
    successRewardXp: 300,
    successRewardCoins: 150,
    steps: [
      {
        id: 'q4_s1',
        title: "Framing the Outer Square Area",
        instruction: "Construct a large square of side length (a+b) that contains four congruent right triangles (with legs a, b and hypotenuse c) and an inner square of side c. What is its total outer area?",
        mathPrompt: "A_{\\text{outer}} = (a+b)^2",
        options: [
          {
            text: "A_{\\text{outer}} = (a+b)^2 = a^2 + 2ab + b^2",
            isCorrect: true,
            explanation: "The total area of a square of side a+b is (a+b)^2, which expands algebraically to a^2 + 2ab + b^2."
          },
          {
            text: "A_{\\text{outer}} = a^2 + b^2",
            isCorrect: false,
            explanation: "This is the hypotenuse equation we want to prove, not the area of the combined boundary square."
          }
        ],
        peerHints: [
          { peerName: "Amit Mehra", text: "Expand (a+b)^2 algebraically. Remember the middle cross term 2ab!" }
        ]
      },
      {
        id: 'q4_s2',
        title: "Summing the Internal Parts",
        instruction: "Express the total area as the sum of its parts: 4 right-angled triangles of area (1/2)ab and the inner square of side c.",
        mathPrompt: "A_{\\text{parts}} = 4 \\times A_{\\text{triangle}} + A_{\\text{inner}}",
        options: [
          {
            text: "A_{\\text{parts}} = 4 \\times \\left(\\frac{1}{2}ab\\right) + c^2 = 2ab + c^2",
            isCorrect: true,
            explanation: "Four triangles of area 1/2*ab contribute 2ab. Adding the inner square area c^2 gives 2ab + c^2."
          },
          {
            text: "A_{\\text{parts}} = 4ab + c^2",
            isCorrect: false,
            explanation: "This is incorrect because it uses ab instead of 1/2*ab for the area of right triangles."
          }
        ],
        peerHints: [
          { peerName: "Sneha Kapoor", text: "The area of a right triangle is 1/2 * base * height. We have four of them." }
        ]
      },
      {
        id: 'q4_s3',
        title: "Equating Total Area with Parts",
        instruction: "Equate the total boundary area with the sum of its internal component parts.",
        mathPrompt: "A_{\\text{outer}} = A_{\\text{parts}}",
        options: [
          {
            text: "a^2 + 2ab + b^2 = 2ab + c^2",
            isCorrect: true,
            explanation: "By equating the expanded total area and the sum-of-parts area, we form the equality."
          },
          {
            text: "a^2 + b^2 = 2ab + c^2",
            isCorrect: false,
            explanation: "This ignores the left-hand 2ab cross term."
          }
        ],
        peerHints: [
          { peerName: "Priya Nair", text: "Just put the results of Step 1 and Step 2 on opposite sides of an equal sign!" }
        ]
      },
      {
        id: 'q4_s4',
        title: "Final Cancellation",
        instruction: "Subtract the common term 2ab from both sides of the equation to finish.",
        mathPrompt: "a^2 + b^2 = c^2",
        options: [
          {
            text: "a^2 + b^2 = c^2",
            isCorrect: true,
            explanation: "Subtracting 2ab from both sides leaves exactly a^2 + b^2 = c^2, completing Pythagoras' ancient proof."
          },
          {
            text: "a^2 - b^2 = c^2",
            isCorrect: false,
            explanation: "This is incorrect subtraction."
          }
        ],
        peerHints: [
          { peerName: "Rohan Sharma", text: "Subtract 2ab from both sides! It cancels out perfectly. We did it!" }
        ]
      }
    ]
  }
];

interface PeerCursor {
  name: string;
  color: string;
  x: number; // percentage
  y: number; // percentage
  avatar: string;
  actionText?: string;
  activityStatus?: string;
}

interface ChatMessage {
  sender: string;
  text: string;
  timestamp: string;
  isPeer: boolean;
  color: string;
}

export const CoopProofQuests: React.FC<{
  userLevel: number;
  tokens: number;
  addXp: (xp: number, badgeOption?: { name: string; icon: string }, tokenBonus?: number) => { finalXp: number; finalTokens: number };
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
}> = ({ userLevel, tokens, addXp, showNotification }) => {
  const [selectedQuest, setSelectedQuest] = useState<CoopQuest | null>(null);
  const [questStepIdx, setQuestStepIdx] = useState<number>(0);
  const [selectedOptionIdx, setSelectedOptionIdx] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);
  const [provedSteps, setProvedSteps] = useState<Set<string>>(new Set());
  const [questFinished, setQuestFinished] = useState<boolean>(false);

  // Network State
  const [ping, setPing] = useState<number>(24);
  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [peerCount, setPeerCount] = useState<number>(3);
  const [multiplier, setMultiplier] = useState<number>(2.5);

  // Peers Realtime Cursor Simulation
  const [peers, setPeers] = useState<PeerCursor[]>([
    { name: "Rohan Sharma", color: "bg-orange-500", x: 45, y: 30, avatar: "🧙", activityStatus: "Exploring algebraic blocks" },
    { name: "Sneha Kapoor", color: "bg-pink-500", x: 20, y: 70, avatar: "⚡", activityStatus: "Drafting proof notes" },
    { name: "Priya Nair", color: "bg-emerald-500", x: 80, y: 45, avatar: "📐", activityStatus: "Evaluating equations" }
  ]);

  // Peer Chat logs
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { sender: "System", text: "🔒 Collaborative Workspace Synced (Channel #MATH-PROOF-90)", timestamp: "02:26", isPeer: false, color: "text-indigo-400" },
    { sender: "Rohan Sharma", text: "Hey team! Let's conquer these proof quests together. Which one should we do?", timestamp: "02:27", isPeer: true, color: "text-orange-400" },
    { sender: "Sneha Kapoor", text: "Let's work on Euler's Identity first! It connects everything so beautifully.", timestamp: "02:27", isPeer: true, color: "text-pink-400" }
  ]);
  const [userChatInput, setUserChatInput] = useState<string>("");
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Workspace pointer
  const workspaceRef = useRef<HTMLDivElement>(null);

  // Simulate cursor movements and incoming chat hints contextually
  useEffect(() => {
    // 1. Move peer cursors dynamically inside workspace
    const cursorInterval = setInterval(() => {
      setPeers(curr => curr.map(peer => {
        // Create subtle natural path movement
        const dx = (Math.random() - 0.5) * 8;
        const dy = (Math.random() - 0.5) * 8;
        const newX = Math.max(5, Math.min(95, peer.x + dx));
        const newY = Math.max(5, Math.min(95, peer.y + dy));
        
        // Randomly update status text sometimes
        const statusPool = ["Syncing...", "Viewing Formula", "Analyzing steps", "Hovering block", "Idle"];
        const status = Math.random() > 0.85 ? statusPool[Math.floor(Math.random() * statusPool.length)] : peer.activityStatus;

        return {
          ...peer,
          x: newX,
          y: newY,
          activityStatus: status
        };
      }));
    }, 1200);

    // 2. Ping fluctuations
    const pingInterval = setInterval(() => {
      setPing(p => {
        const delta = Math.floor((Math.random() - 0.5) * 6);
        return Math.max(12, Math.min(48, p + delta));
      });
    }, 3000);

    return () => {
      clearInterval(cursorInterval);
      clearInterval(pingInterval);
    };
  }, []);

  // When active step changes, peers post helpful hints into the chat
  useEffect(() => {
    if (!selectedQuest) return;
    const currentStep = selectedQuest.steps[questStepIdx];
    if (!currentStep) return;

    // Simulate classmates discussing the active step
    const hints = currentStep.peerHints;
    if (hints.length > 0) {
      const timers: any[] = [];
      hints.forEach((hint, idx) => {
        const timer = setTimeout(() => {
          const colors = {
            "Rohan Sharma": "text-orange-400",
            "Sneha Kapoor": "text-pink-400",
            "Priya Nair": "text-emerald-400",
            "Amit Mehra": "text-blue-400"
          };
          const color = (colors as any)[hint.peerName] || "text-slate-400";
          
          setChatMessages(prev => [
            ...prev,
            {
              sender: hint.peerName,
              text: hint.text,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              isPeer: true,
              color
            }
          ]);
          
          // Also focus classmate cursors on the active mathematical steps
          setPeers(curr => curr.map(p => {
            if (p.name === hint.peerName) {
              return {
                ...p,
                x: 40 + (idx * 15),
                y: 50 + (idx * 5),
                activityStatus: "Answering step..."
              };
            }
            return p;
          }));
        }, (idx + 1) * 3500);
        timers.push(timer);
      });

      return () => {
        timers.forEach(t => clearTimeout(t));
      };
    }
  }, [selectedQuest, questStepIdx]);

  // Scroll chat to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleQuestSelect = (quest: CoopQuest) => {
    setSelectedQuest(quest);
    setQuestStepIdx(0);
    setSelectedOptionIdx(null);
    setShowExplanation(false);
    setProvedSteps(new Set());
    setQuestFinished(false);

    setChatMessages(prev => [
      ...prev,
      {
        sender: "System",
        text: `🚀 Started proof quest: "${quest.title}" [${quest.field}]`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isPeer: false,
        color: "text-indigo-400"
      }
    ]);
  };

  const handleSelectOption = (optIdx: number) => {
    if (selectedOptionIdx !== null) return;
    setSelectedOptionIdx(optIdx);
    setShowExplanation(true);

    const activeStep = selectedQuest!.steps[questStepIdx];
    const isCorrect = activeStep.options[optIdx].isCorrect;

    if (isCorrect) {
      setProvedSteps(curr => {
        const next = new Set(curr);
        next.add(activeStep.id);
        return next;
      });

      setChatMessages(prev => [
        ...prev,
        {
          sender: "System",
          text: `🎉 STEP PROVED: ${activeStep.title} has been successfully verified!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isPeer: false,
          color: "text-emerald-500 font-extrabold"
        }
      ]);

      // Move classmates' cursors to dance/celebrate around the step!
      setPeers(curr => curr.map(p => ({
        ...p,
        x: p.x + (Math.random() - 0.5) * 20,
        y: p.y - 15,
        activityStatus: "🎉 Celebrating correct proof!"
      })));

      if (showNotification) {
        showNotification(`Step Proved! Accurate logical deduction.`, 'success');
      }
    } else {
      setChatMessages(prev => [
        ...prev,
        {
          sender: "System",
          text: `❌ PROOF CONFLICT: An logical error occurred at ${activeStep.title}. Let's re-evaluate!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isPeer: false,
          color: "text-rose-500 font-bold"
        }
      ]);
    }
  };

  const handleNextStep = () => {
    setSelectedOptionIdx(null);
    setShowExplanation(false);

    if (questStepIdx + 1 < selectedQuest!.steps.length) {
      setQuestStepIdx(prev => prev + 1);
    } else {
      // Completed full proof quest!
      setQuestFinished(true);
      
      const xpReward = selectedQuest!.successRewardXp;
      const coinsReward = selectedQuest!.successRewardCoins;
      
      // Award rewards!
      addXp(xpReward, { name: `${selectedQuest!.title} Scholar`, icon: '🎓' }, coinsReward);

      setChatMessages(prev => [
        ...prev,
        {
          sender: "System",
          text: `🏆 THEOREM COMPLETE: "${selectedQuest!.title}" successfully proved! Synergy rewarded: +${xpReward} XP, 🪙 +${coinsReward}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isPeer: false,
          color: "text-amber-500 font-black tracking-wide"
        }
      ]);

      if (showNotification) {
        showNotification(`Theorem Proved! Synergy Reward Distributed.`, 'success');
      }
    }
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userChatInput.trim()) return;

    setChatMessages(prev => [
      ...prev,
      {
        sender: "You (Learner)",
        text: userChatInput,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isPeer: false,
        color: "text-indigo-400 font-bold"
      }
    ]);

    const msgText = userChatInput.toLowerCase();
    setUserChatInput("");

    // Simulate reactive teammate answers
    setTimeout(() => {
      let reply = "I agree! Let's check the mathematical logic.";
      let responder = "Rohan Sharma";
      let resColor = "text-orange-400";

      if (msgText.includes("help") || msgText.includes("what") || msgText.includes("stuck")) {
        reply = "Look at the formulas! One is cosine, the other is sine. Check the signs carefully!";
        responder = "Priya Nair";
        resColor = "text-emerald-400";
      } else if (msgText.includes("euler") || msgText.includes("identity")) {
        reply = "Euler's identity is legendary. Merging circles and exponents is so cool.";
        responder = "Sneha Kapoor";
        resColor = "text-pink-400";
      } else if (msgText.includes("correct") || msgText.includes("yes") || msgText.includes("got it")) {
        reply = "Exactly! Great team collaboration, let's proceed to the next formula step.";
        responder = "Rohan Sharma";
        resColor = "text-orange-400";
      }

      setChatMessages(prev => [
        ...prev,
        {
          sender: responder,
          text: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isPeer: true,
          color: resColor
        }
      ]);
    }, 1500);
  };

  const resetQuest = () => {
    setQuestStepIdx(0);
    setSelectedOptionIdx(null);
    setShowExplanation(false);
    setProvedSteps(new Set());
    setQuestFinished(false);
  };

  return (
    <div className="flex flex-col gap-4 text-left">
      
      {/* Sync Status Header */}
      <div className="p-4 bg-indigo-600/5 dark:bg-indigo-600/10 border border-indigo-500/20 rounded-2xl flex flex-wrap justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 bg-indigo-600/20 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center">
              <Users size={20} className="animate-pulse" />
            </div>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" />
          </div>
          <div>
            <h3 className="text-xs font-black text-slate-800 dark:text-slate-100 flex items-center gap-1.5 uppercase tracking-wider">
              Cooperative Study Workspace
            </h3>
            <div className="flex items-center gap-3 mt-0.5 text-[9px] font-mono text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1">
                <Radio size={10} className="text-emerald-500 animate-pulse" /> Channel: <strong className="text-indigo-500 font-extrabold">#MATH-PROOF-90</strong>
              </span>
              <span>•</span>
              <span className="text-emerald-500 font-bold">● CONNECTED</span>
              <span>•</span>
              <span>Ping: <strong className="font-bold text-slate-700 dark:text-slate-200">{ping}ms</strong></span>
            </div>
          </div>
        </div>

        {/* Real-time stats */}
        <div className="flex items-center gap-4">
          <div className="text-right">
            <span className="text-[8px] font-black text-slate-400 uppercase block tracking-wider">Cooperative Peers</span>
            <span className="text-[11px] font-mono font-bold text-slate-700 dark:text-slate-200">{peerCount} online classmate cursors</span>
          </div>
          <div className="text-right">
            <span className="text-[8px] font-black text-slate-400 uppercase block tracking-wider">Study Alliance Mult.</span>
            <span className="px-1.5 py-0.5 rounded bg-gradient-to-r from-pink-500 to-indigo-500 text-white text-[10px] font-black font-mono flex items-center gap-1 animate-pulse">
              <Zap size={10} className="fill-white" /> {multiplier}x
            </span>
          </div>
        </div>
      </div>

      {!selectedQuest ? (
        /* Quest Selection Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in duration-300">
          {COOP_QUESTS.map((quest) => (
            <div 
              key={quest.id}
              className="p-5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl hover:border-indigo-500/50 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex justify-between items-start gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl filter drop-shadow">{quest.icon}</span>
                    <div>
                      <h4 className="text-xs font-black text-slate-800 dark:text-slate-100">{quest.title}</h4>
                      <span className="text-[9px] text-slate-400 font-extrabold">{quest.field}</span>
                    </div>
                  </div>
                  
                  <span className={cn(
                    "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider",
                    quest.difficulty === 'Novice' ? 'bg-emerald-500/10 text-emerald-500' :
                    quest.difficulty === 'Expert' ? 'bg-indigo-500/10 text-indigo-500' :
                    'bg-rose-500/10 text-rose-500'
                  )}>
                    {quest.difficulty}
                  </span>
                </div>

                <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal mb-4">
                  {quest.description}
                </p>

                {/* Steps Timeline Preview */}
                <div className="mb-4 bg-slate-50 dark:bg-slate-900 p-2.5 rounded-xl border border-slate-150 dark:border-slate-850">
                  <span className="text-[8px] font-black uppercase text-slate-400 tracking-wider block mb-1.5">Proof Sequence Breakdown</span>
                  <div className="flex items-center gap-1.5">
                    {quest.steps.map((step, sIdx) => (
                      <React.Fragment key={step.id}>
                        <div className="px-2 py-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded text-[9px] font-bold text-slate-600 dark:text-slate-300">
                          {sIdx + 1}. {step.title.split(' ')[0]}
                        </div>
                        {sIdx < quest.steps.length - 1 && <ChevronRight size={10} className="text-slate-400" />}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-850">
                <div className="flex gap-3 text-[10px] font-bold">
                  <span className="text-indigo-500 font-black flex items-center gap-0.5">
                    <Zap size={11} /> +{quest.successRewardXp * multiplier} XP
                  </span>
                  <span className="text-amber-500 font-black flex items-center gap-0.5">
                    🪙 +{quest.successRewardCoins * multiplier} Coins
                  </span>
                </div>

                <button
                  onClick={() => handleQuestSelect(quest)}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[9px] font-black uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center gap-1 shadow hover:shadow-indigo-500/20"
                >
                  <Play size={11} className="fill-white" /> Launch Team Proof
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Workspace Active Quest Board */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 animate-in zoom-in-95 duration-200">
          
          {/* Main Workspace (Col 8) */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            
            {/* Active Workspace Board & Live Cursors Container */}
            <div 
              ref={workspaceRef}
              className="relative p-5 bg-slate-950 text-white rounded-3xl border border-slate-800 min-h-[420px] overflow-hidden flex flex-col justify-between"
            >
              {/* Background decorative coordinate lines */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-950/25 via-slate-950 to-slate-950 opacity-90" />
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:32px_24px] opacity-10" />

              {/* Simulated Peer Cursor Elements rendered in absolute coordinates */}
              <div className="absolute inset-0 pointer-events-none z-30">
                {peers.map((peer, pIdx) => (
                  <motion.div 
                    key={pIdx}
                    className="absolute transition-all duration-300 ease-out"
                    style={{ left: `${peer.x}%`, top: `${peer.y}%` }}
                  >
                    {/* Tiny visual cursor icon */}
                    <div className="flex flex-col items-start gap-1">
                      <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-full px-2 py-0.5 shadow-xl text-[9px] text-white">
                        <span>{peer.avatar}</span>
                        <span className="font-extrabold">{peer.name}</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                      </div>
                      
                      {/* Subtitle status activity */}
                      <span className="text-[7px] font-mono px-1 py-0.5 rounded bg-black/80 text-indigo-400 border border-indigo-900 tracking-wider">
                        {peer.activityStatus}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Workspace Contents */}
              <div className="relative z-10 flex flex-col gap-4 h-full justify-between">
                
                {/* Board header */}
                <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{selectedQuest.icon}</span>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-widest text-indigo-400">{selectedQuest.title}</h4>
                      <span className="text-[9px] text-slate-400 block font-bold">Double-inclusion inductive geometric proof sequence</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedQuest(null)}
                    className="px-2.5 py-1 text-[8px] font-black uppercase text-slate-400 hover:text-white border border-slate-800 rounded-lg hover:border-slate-700 cursor-pointer transition-all"
                  >
                    ← Exit Board
                  </button>
                </div>

                {!questFinished ? (
                  <>
                    {/* Steps Progress Checklist */}
                    <div className="grid grid-cols-4 gap-2">
                      {selectedQuest.steps.map((step, sIdx) => {
                        const isActive = sIdx === questStepIdx;
                        const isProved = provedSteps.has(step.id);
                        return (
                          <div 
                            key={step.id}
                            className={cn(
                              "p-2 rounded-xl border text-center transition-all",
                              isProved ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-400" :
                              isActive ? "bg-indigo-600/20 border-indigo-500/50 text-indigo-300 ring-1 ring-indigo-500/20" :
                              "bg-slate-900/40 border-slate-900 text-slate-500"
                            )}
                          >
                            <span className="text-[8px] font-black tracking-widest block uppercase">Step {sIdx + 1}</span>
                            <span className="text-[10px] font-bold truncate block">{step.title}</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Active Theorem Step Prompt & LaTeX */}
                    <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 flex flex-col gap-3 min-h-[140px] justify-center items-center relative text-center">
                      <span className="absolute top-2 left-3 text-[7px] font-black tracking-widest text-indigo-400 uppercase">Interactive Theorem Segment</span>
                      
                      <div className="max-w-md">
                        <span className="text-[10px] font-black text-slate-400 block mb-1">
                          {selectedQuest.steps[questStepIdx].instruction}
                        </span>
                        
                        <div className="p-3 bg-slate-950/80 border border-slate-850 rounded-xl text-lg text-indigo-300 inline-block font-sans select-none my-2">
                          <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                            {`$$${selectedQuest.steps[questStepIdx].mathPrompt}$$`}
                          </Markdown>
                        </div>
                      </div>
                    </div>

                    {/* Interactive Proof Block Options */}
                    <div>
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-2">Collaborative Option Selection</span>
                      <div className="flex flex-col gap-2">
                        {selectedQuest.steps[questStepIdx].options.map((option, oIdx) => {
                          const isSelected = selectedOptionIdx === oIdx;
                          const isCorrect = option.isCorrect;
                          const hasSubmitted = selectedOptionIdx !== null;

                          return (
                            <button
                              key={oIdx}
                              disabled={hasSubmitted}
                              onClick={() => handleSelectOption(oIdx)}
                              className={cn(
                                "p-3 rounded-xl border text-left text-xs font-bold transition-all relative overflow-hidden group/opt",
                                hasSubmitted 
                                  ? isCorrect
                                    ? "bg-emerald-500/10 border-emerald-500 text-emerald-400"
                                    : isSelected
                                      ? "bg-rose-500/10 border-rose-500 text-rose-400"
                                      : "bg-slate-900/30 border-slate-900 text-slate-500 opacity-40"
                                  : "bg-slate-900/60 hover:bg-slate-900 border-slate-850 hover:border-indigo-500/50 cursor-pointer"
                              )}
                            >
                              <div className="flex items-center gap-3">
                                <span className={cn(
                                  "w-6 h-6 rounded flex items-center justify-center font-mono font-bold text-[10px]",
                                  hasSubmitted
                                    ? isCorrect
                                      ? "bg-emerald-500 text-white"
                                      : isSelected
                                        ? "bg-rose-500 text-white"
                                        : "bg-slate-800 text-slate-400"
                                    : "bg-slate-800 text-slate-400 group-hover/opt:bg-indigo-600 group-hover/opt:text-white"
                                )}>
                                  {String.fromCharCode(65 + oIdx)}
                                </span>
                                <div className="text-left font-sans select-none">
                                  <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                                    {option.text}
                                  </Markdown>
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Explanation Feedback Area */}
                    {showExplanation && (
                      <div className="p-3 bg-indigo-500/5 border border-indigo-500/15 rounded-xl text-[11px] leading-relaxed text-slate-300">
                        <span className="font-black text-indigo-400 block mb-1">🔍 PROOF ANALYSIS</span>
                        {selectedQuest.steps[questStepIdx].options[selectedOptionIdx!].explanation}
                      </div>
                    )}

                    {/* Next sequential step action CTA */}
                    {selectedOptionIdx !== null && selectedQuest.steps[questStepIdx].options[selectedOptionIdx].isCorrect && (
                      <button
                        onClick={handleNextStep}
                        className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/10"
                      >
                        Advance Proof Sequence <ChevronRight size={14} />
                      </button>
                    )}
                  </>
                ) : (
                  /* Theorem Proved Celebration Visual */
                  <div className="p-6 bg-slate-900/50 rounded-2xl border border-slate-800 text-center flex flex-col items-center justify-center flex-1 my-auto">
                    <div className="w-16 h-16 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-full flex items-center justify-center mb-4">
                      <Trophy size={32} className="animate-bounce" />
                    </div>

                    <h3 className="text-xl font-black text-amber-400">Collaborative Proof Solved!</h3>
                    <p className="text-xs text-slate-400 max-w-md mt-1.5 mb-5 leading-normal">
                      Rigorous peer verification completed! You and your classmates have established the structural dual relationships for <strong>{selectedQuest.title}</strong> successfully.
                    </p>

                    <div className="grid grid-cols-2 gap-4 max-w-sm w-full mb-6 text-center">
                      <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                        <span className="text-[8px] font-black text-slate-400 uppercase block tracking-wider">Synergy XP Gain</span>
                        <span className="text-lg font-black text-indigo-400">+{selectedQuest.successRewardXp * multiplier} XP</span>
                      </div>
                      <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                        <span className="text-[8px] font-black text-slate-400 uppercase block tracking-wider">Shared Tokens</span>
                        <span className="text-lg font-black text-amber-400">🪙 +{selectedQuest.successRewardCoins * multiplier}</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={resetQuest}
                        className="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer border border-slate-850 transition-all"
                      >
                        <RotateCcw size={13} /> Prove Again
                      </button>
                      <button
                        onClick={() => setSelectedQuest(null)}
                        className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer shadow hover:shadow-indigo-600/20"
                      >
                        Back to Library
                      </button>
                    </div>
                  </div>
                )}

              </div>
            </div>

          </div>

          {/* Peer Chat & Hints Panel (Col 4) */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            
            {/* Live Synchronised Chat Feed */}
            <div className="p-4 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-3xl flex flex-col h-[420px] justify-between">
              <div>
                <div className="flex justify-between items-center pb-2.5 border-b border-slate-100 dark:border-slate-900 mb-3">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                    <MessageSquare size={13} className="text-indigo-500" /> Synced Team Chat
                  </span>
                  <span className="text-[8px] font-mono px-1 rounded bg-slate-100 dark:bg-slate-900 text-slate-500 font-bold">
                    3 Peers Online
                  </span>
                </div>

                {/* Messages Scroller */}
                <div className="overflow-y-auto max-h-[300px] flex flex-col gap-2.5 pr-1">
                  {chatMessages.map((msg, idx) => (
                    <div key={idx} className="text-xs">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className={cn("font-black text-[10px]", msg.color)}>
                          {msg.sender}
                        </span>
                        <span className="text-[8px] text-slate-400 font-mono">
                          {msg.timestamp}
                        </span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-300 leading-normal pl-0.5 font-sans bg-slate-50 dark:bg-slate-900/50 p-1.5 rounded-lg border border-slate-100 dark:border-slate-900">
                        {msg.text}
                      </p>
                    </div>
                  ))}
                  <div ref={chatBottomRef} />
                </div>
              </div>

              {/* Chat Send Input Form */}
              <form onSubmit={handleSendChat} className="flex gap-2 border-t border-slate-100 dark:border-slate-900 pt-3">
                <input
                  type="text"
                  placeholder="Type proof hints or chat..."
                  value={userChatInput}
                  onChange={(e) => setUserChatInput(e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs outline-none focus:border-indigo-500 placeholder-slate-400"
                />
                <button
                  type="submit"
                  className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-all cursor-pointer shadow hover:shadow-indigo-500/10"
                  title="Send to study channel"
                >
                  <Send size={12} />
                </button>
              </form>
            </div>

            {/* Simulated Live Packets / Telemetry Data Stream */}
            <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl">
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1.5 flex items-center gap-1">
                <Activity size={10} className="text-emerald-500" /> Live Synchronization Stream
              </span>
              <div className="font-mono text-[9px] text-slate-500 dark:text-slate-400 leading-relaxed flex flex-col gap-1 max-h-[80px] overflow-y-auto">
                <div>[02:26:09] Initializing WebSocket secure handshake...</div>
                <div>[02:26:10] Session ID: <span className="text-indigo-400">c251ca05-cd59-4204</span></div>
                <div>[02:26:11] Connected. Subscribing to proof_state_broadcast...</div>
                {provedSteps.size > 0 && <div>[02:26:34] Broadcast packet: Step {provedSteps.size} approved.</div>}
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
