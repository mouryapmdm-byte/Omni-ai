// IndexedDB Local Caching Utility for Lecture Metadata & Video Fragments

const DB_NAME = 'omni_lecture_offline_cache';
const DB_VERSION = 1;

export interface CachedVideoFragment {
  url: string;
  blob: Blob;
  size: number;
  type: string;
  cachedAt: number;
  metadata?: any;
}

export interface CachedLectureMetadata {
  key: string;
  data: any;
  updatedAt: number;
}

let dbPromise: Promise<IDBDatabase> | null = null;

export const getLectureDB = (): Promise<IDBDatabase> => {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB is not supported in this environment'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains('metadata')) {
        db.createObjectStore('metadata', { keyPath: 'key' });
      }

      if (!db.objectStoreNames.contains('video_fragments')) {
        const videoStore = db.createObjectStore('video_fragments', { keyPath: 'url' });
        videoStore.createIndex('cachedAt', 'cachedAt', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      resolve((event.target as IDBOpenDBRequest).result);
    };

    request.onerror = (event) => {
      dbPromise = null;
      reject((event.target as IDBOpenDBRequest).error);
    };
  });

  return dbPromise;
};

/**
 * Cache lecture metadata (e.g., bookmarks, transcripts, verbal questions, chat history)
 */
export async function cacheLectureMetadata(key: string, data: any): Promise<void> {
  try {
    const db = await getLectureDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('metadata', 'readwrite');
      const store = tx.objectStore('metadata');
      const item: CachedLectureMetadata = {
        key,
        data,
        updatedAt: Date.now()
      };
      const req = store.put(item);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[LectureCache] Failed to cache metadata:', err);
  }
}

/**
 * Retrieve cached lecture metadata
 */
export async function getLectureMetadata<T = any>(key: string): Promise<T | null> {
  try {
    const db = await getLectureDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('metadata', 'readonly');
      const store = tx.objectStore('metadata');
      const req = store.get(key);
      req.onsuccess = () => {
        resolve(req.result ? (req.result.data as T) : null);
      };
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[LectureCache] Failed to read metadata:', err);
    return null;
  }
}

/**
 * Delete cached lecture metadata
 */
export async function deleteLectureMetadata(key: string): Promise<void> {
  try {
    const db = await getLectureDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('metadata', 'readwrite');
      const store = tx.objectStore('metadata');
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[LectureCache] Failed to delete metadata:', err);
  }
}

/**
 * Cache a video fragment or complete video Blob in IndexedDB
 */
export async function cacheVideoFragment(url: string, blob: Blob, metadata?: any): Promise<void> {
  try {
    const db = await getLectureDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('video_fragments', 'readwrite');
      const store = tx.objectStore('video_fragments');
      const fragment: CachedVideoFragment = {
        url,
        blob,
        size: blob.size,
        type: blob.type,
        cachedAt: Date.now(),
        metadata
      };
      const req = store.put(fragment);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[LectureCache] Failed to cache video fragment:', err);
  }
}

/**
 * Retrieve a cached video fragment as an object URL for seamless offline playback
 */
export async function getCachedVideoFragment(url: string): Promise<{ objectUrl: string; size: number; cachedAt: number } | null> {
  try {
    const db = await getLectureDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('video_fragments', 'readonly');
      const store = tx.objectStore('video_fragments');
      const req = store.get(url);
      req.onsuccess = () => {
        const record = req.result as CachedVideoFragment | undefined;
        if (record && record.blob) {
          const objectUrl = URL.createObjectURL(record.blob);
          resolve({
            objectUrl,
            size: record.size,
            cachedAt: record.cachedAt
          });
        } else {
          resolve(null);
        }
      };
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[LectureCache] Failed to fetch cached video fragment:', err);
    return null;
  }
}

/**
 * Smart fetch & cache strategy for video resources.
 * If online: attempts fetch, caches blob into IndexedDB, and returns objectURL.
 * If network fails or offline: retrieves from IndexedDB cache.
 */
export async function fetchWithOfflineLectureCache(url: string): Promise<{ url: string; isFromCache: boolean }> {
  // First check if already in cache
  const cached = await getCachedVideoFragment(url);

  if (!navigator.onLine) {
    if (cached) {
      return { url: cached.objectUrl, isFromCache: true };
    }
    return { url, isFromCache: false };
  }

  try {
    // If online, fetch fresh video data
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const blob = await res.blob();
    await cacheVideoFragment(url, blob);
    const objectUrl = URL.createObjectURL(blob);
    return { url: objectUrl, isFromCache: false };
  } catch (err) {
    console.warn('[LectureCache] Network fetch failed, falling back to cache:', err);
    if (cached) {
      return { url: cached.objectUrl, isFromCache: true };
    }
    return { url, isFromCache: false };
  }
}

/**
 * Get summary stats of cached data for debug/UI feedback
 */
export async function getLectureCacheStats(): Promise<{ metadataItems: number; cachedVideos: number; totalBytes: number }> {
  try {
    const db = await getLectureDB();
    return new Promise((resolve) => {
      const tx = db.transaction(['metadata', 'video_fragments'], 'readonly');
      const metaStore = tx.objectStore('metadata');
      const videoStore = tx.objectStore('video_fragments');

      let metadataItems = 0;
      let cachedVideos = 0;
      let totalBytes = 0;

      metaStore.count().onsuccess = (e) => {
        metadataItems = (e.target as IDBRequest).result || 0;
      };

      const videoReq = videoStore.openCursor();
      videoReq.onsuccess = (e) => {
        const cursor = (e.target as IDBRequest).result as IDBCursorWithValue;
        if (cursor) {
          cachedVideos++;
          if (cursor.value && cursor.value.size) {
            totalBytes += cursor.value.size;
          }
          cursor.continue();
        } else {
          resolve({ metadataItems, cachedVideos, totalBytes });
        }
      };

      tx.onerror = () => resolve({ metadataItems: 0, cachedVideos: 0, totalBytes: 0 });
    });
  } catch (err) {
    return { metadataItems: 0, cachedVideos: 0, totalBytes: 0 };
  }
}

/**
 * Clear all cached lecture data
 */
export async function clearLectureCache(): Promise<void> {
  try {
    const db = await getLectureDB();
    const tx = db.transaction(['metadata', 'video_fragments'], 'readwrite');
    tx.objectStore('metadata').clear();
    tx.objectStore('video_fragments').clear();
  } catch (err) {
    console.warn('[LectureCache] Error clearing cache:', err);
  }
}
