export * from '../../src/modules/personalization/interestProfile';
