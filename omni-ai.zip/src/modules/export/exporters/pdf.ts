import { jsPDF } from 'jspdf';

export async function exportToPDF(content: any) {
  const doc = new jsPDF();
  doc.text(content.title, 10, 10);
  doc.text(content.body, 10, 20);
  doc.save(`${content.title.replace(/\s+/g, '_')}.pdf`);
}
