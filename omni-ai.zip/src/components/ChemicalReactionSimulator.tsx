import React, { useState, useEffect, useRef } from 'react';
import { cn } from '@/src/lib/utils';
import { Flame, Play, Pause, RotateCcw, ArrowRight, BookOpen, ExternalLink, Sparkles, Zap, Atom } from 'lucide-react';

interface ReactionMechanism {
  id: string;
  name: string;
  type: 'SN1' | 'SN2' | 'E1' | 'E2';
  reactant: string;
  nucleophileOrBase: string;
  product: string;
  description: string;
  steps: {
    title: string;
    details: string;
    arrowDescription: string;
  }[];
  chapter: string;
}

const MECHANISMS: Record<string, ReactionMechanism> = {
  'sn2_methyl_chloride': {
    id: 'sn2_methyl_chloride',
    name: 'S_N2 Reaction of Chloromethane with OH⁻',
    type: 'SN2',
    reactant: 'CH₃Cl (Chloromethane) + OH⁻',
    nucleophileOrBase: 'Hydroxide Ion (OH⁻)',
    product: 'CH₃OH (Methanol) + Cl⁻',
    description: 'Bimolecular nucleophilic substitution proceeding via a single concerted step with inversion of configuration (Walden inversion).',
    steps: [
      {
        title: 'Step 1: Concerted Nucleophilic Attack',
        details: 'The hydroxide ion (OH⁻) attacks the electrophilic carbon from the backside opposite to the leaving group (Cl⁻).',
        arrowDescription: 'Curly arrow from OH⁻ lone pair to the C-Cl carbon atom.'
      },
      {
        title: 'Step 2: Transition State & Inversion',
        details: 'A penta-coordinated pentavalent transition state forms momentarily as the C-Cl bond lengthens and the C-OH bond forms.',
        arrowDescription: 'Curly arrow breaking the C-Cl bond, transferring electrons entirely to Chlorine.'
      },
      {
        title: 'Step 3: Product Formation',
        details: 'Methanol (CH₃OH) is formed with inverted stereochemical configuration, accompanied by departing chloride ion (Cl⁻).',
        arrowDescription: 'Reaction complete with stable products.'
      }
    ],
    chapter: 'Chapter 10: Haloalkanes and Haloarenes'
  },
  'sn1_tert_butyl': {
    id: 'sn1_tert_butyl',
    name: 'S_N1 Solvolysis of Tert-Butyl Chloride',
    type: 'SN1',
    reactant: '(CH₃)₃CCl (2-Chloro-2-methylpropane)',
    nucleophileOrBase: 'Water / Solvent (H₂O)',
    product: '(CH₃)₃COH (Tert-butyl alcohol) + HCl',
    description: 'Unimolecular nucleophilic substitution proceeding in two steps via a stable planar carbocation intermediate.',
    steps: [
      {
        title: 'Step 1: Ionization (Rate-Determining Step)',
        details: 'Heterolytic cleavage of the C-Cl bond occurs spontaneously, producing a planar sp² hybridized carbocation and chloride.',
        arrowDescription: 'Curly arrow from C-Cl bonding pair directly onto Chlorine atom.'
      },
      {
        title: 'Step 2: Nucleophilic Attack',
        details: 'Water molecule acts as a nucleophile, attacking the electron-deficient planar carbocation from either top or bottom face.',
        arrowDescription: 'Curly arrow from H₂O oxygen lone pair to the carbocation center (+).'
      },
      {
        title: 'Step 3: Deprotonation',
        details: 'Loss of a proton from the oxonium intermediate yields tert-butanol and hydronium ion.',
        arrowDescription: 'Curly arrow breaking O-H bond to neutralize charge.'
      }
    ],
    chapter: 'Chapter 10: Haloalkanes and Haloarenes'
  },
  'alcohol_dehydration': {
    id: 'alcohol_dehydration',
    name: 'Acid-Catalyzed Dehydration of Ethanol',
    type: 'E1',
    reactant: 'CH₃CH₂OH (Ethanol) + H₂SO₄',
    nucleophileOrBase: 'Acid Catalyst (H⁺)',
    product: 'CH₂=CH₂ (Ethene) + H₂O',
    description: 'Elimination reaction producing an alkene via protonation of hydroxyl group followed by water departure and deprotonation.',
    steps: [
      {
        title: 'Step 1: Protonation of Hydroxyl',
        details: 'Ethanol is rapidly protonated by sulfuric acid to convert the poor leaving group (-OH) into an excellent leaving group (-OH₂⁺).',
        arrowDescription: 'Curly arrow from alcohol oxygen lone pair to H⁺.'
      },
      {
        title: 'Step 2: Loss of Water (Carbocation Formation)',
        details: 'Water departs, leaving behind an ethyl carbocation intermediate.',
        arrowDescription: 'Curly arrow breaking C-O bond to form neutral H₂O.'
      },
      {
        title: 'Step 3: Elimination of Proton',
        details: 'A weak base (HSO₄⁻ or H₂O) removes a beta-proton, forming the carbon-carbon double bond in ethene.',
        arrowDescription: 'Curly arrow from C-H bond forming the π bond.'
      }
    ],
    chapter: 'Chapter 11: Alcohols, Phenols and Ethers'
  }
};

interface ChemicalReactionSimulatorProps {
  theme: 'light' | 'dark';
  onOpenChapter: (chapterNum: number) => void;
  showNotification?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const ChemicalReactionSimulator: React.FC<ChemicalReactionSimulatorProps> = ({
  theme,
  onOpenChapter,
  showNotification
}) => {
  const [selectedKey, setSelectedKey] = useState<string>('sn2_methyl_chloride');
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const activeMechanism = MECHANISMS[selectedKey] || MECHANISMS['sn2_methyl_chloride'];

  // Auto-play animation timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev >= activeMechanism.steps.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, 2500);
    }
    return () => clearInterval(timer);
  }, [isPlaying, activeMechanism]);

  // Canvas drawing for animated curly arrows & mechanism
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // Background styling
    ctx.fillStyle = theme === 'dark' ? '#0f172a' : '#f8fafc';
    ctx.fillRect(0, 0, width, height);

    // Draw grid lines
    ctx.strokeStyle = theme === 'dark' ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 30) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw mechanism visualization based on type and step
    ctx.font = 'bold 14px sans-serif';
    ctx.fillStyle = theme === 'dark' ? '#f8fafc' : '#1e293b';

    if (activeMechanism.type === 'SN2') {
      // Draw Nucleophile OH-
      ctx.fillStyle = '#ec4899';
      ctx.beginPath();
      ctx.arc(80 + currentStepIndex * 30, height / 2, 24, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('OH⁻', 80 + currentStepIndex * 30, height / 2);

      // Draw Central Carbon C
      ctx.fillStyle = '#3b82f6';
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, 32, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillText('C', width / 2, height / 2);

      // Draw Leaving Group Cl-
      const clX = width - 100 - currentStepIndex * 30;
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(clX, height / 2, 24, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillText('Cl⁻', clX, height / 2);

      // Draw Animated Curly Arrow
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(110 + currentStepIndex * 10, height / 2 - 20);
      ctx.quadraticCurveTo(width / 2, height / 2 - 80 - currentStepIndex * 10, width / 2 - 20, height / 2 - 25);
      ctx.stroke();

      // Arrowhead
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.moveTo(width / 2 - 20, height / 2 - 25);
      ctx.lineTo(width / 2 - 12, height / 2 - 32);
      ctx.lineTo(width / 2 - 15, height / 2 - 20);
      ctx.fill();

    } else if (activeMechanism.type === 'SN1') {
      // SN1 Carbocation generation & attack
      ctx.fillStyle = '#8b5cf6';
      ctx.beginPath();
      ctx.arc(width / 2, height / 2, 36, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(currentStepIndex === 0 ? '(CH₃)₃C-Cl' : 'R⁺ Carbocation', width / 2, height / 2);

      if (currentStepIndex > 0) {
        // Water attacking
        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.arc(width / 2 + 120 - currentStepIndex * 40, height / 2 - 80, 24, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.fillText('H₂O', width / 2 + 120 - currentStepIndex * 40, height / 2 - 80);

        // Curly arrow from water to carbocation
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(width / 2 + 90 - currentStepIndex * 30, height / 2 - 70);
        ctx.quadraticCurveTo(width / 2 + 40, height / 2 - 40, width / 2 + 15, height / 2 - 15);
        ctx.stroke();
      }

    } else {
      // Elimination E1 / E2
      ctx.fillStyle = '#f97316';
      ctx.beginPath();
      ctx.arc(width / 2 - 60, height / 2, 28, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('C-H', width / 2 - 60, height / 2);

      ctx.fillStyle = '#3b82f6';
      ctx.beginPath();
      ctx.arc(width / 2 + 60, height / 2, 28, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillText('C-OH₂⁺', width / 2 + 60, height / 2);

      // Pi bond formation indicator
      if (currentStepIndex === 2) {
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(width / 2, height / 2 + 40, 50, 0, Math.PI);
        ctx.stroke();
        ctx.fillStyle = '#10b981';
        ctx.fillText('Alkenes (C=C) Formed!', width / 2, height / 2 + 75);
      }
    }

  }, [selectedKey, currentStepIndex, theme]);

  return (
    <div className={cn(
      "w-full h-full flex flex-col overflow-y-auto p-6 md:p-8 selection:bg-amber-500 selection:text-white",
      theme === 'dark' ? "bg-slate-900 text-white" : "bg-slate-50/50 text-slate-900"
    )}>
      {/* Header Banner */}
      <div className={cn(
        "p-6 rounded-3xl border mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl",
        theme === 'dark' ? "bg-gradient-to-r from-amber-950/60 via-slate-900 to-orange-950/40 border-amber-900/40" : "bg-gradient-to-r from-amber-50 via-white to-orange-50 border-amber-100"
      )}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-gradient-to-br from-amber-600 to-orange-700 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-amber-500/30">
            <Flame size={28} />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                Interactive Reaction Mechanism Simulator
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Chemical Reaction Simulator
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Select haloalkane or alcohol reactants and visualize organic reaction mechanisms ($S_N1$, $S_N2$, $E_1$) with animated curly arrows.
            </p>
          </div>
        </div>

        {/* Dropdown Selector */}
        <select
          value={selectedKey}
          onChange={(e) => {
            setSelectedKey(e.target.value);
            setCurrentStepIndex(0);
            setIsPlaying(false);
            showNotification?.(`Switched mechanism to ${MECHANISMS[e.target.value].name}`, 'info');
          }}
          className={cn(
            "px-4 py-3 rounded-2xl border text-xs font-bold outline-none cursor-pointer shadow-sm",
            theme === 'dark' ? "bg-slate-800 border-slate-700 text-white" : "bg-white border-slate-200 text-slate-800"
          )}
        >
          {Object.entries(MECHANISMS).map(([k, m]) => (
            <option key={k} value={k}>
              {m.name} ({m.type})
            </option>
          ))}
        </select>
      </div>

      {/* Main Grid: Canvas & Mechanism Steps */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Canvas Animation Stage */}
        <div className={cn(
          "lg:col-span-2 p-6 md:p-8 rounded-3xl border shadow-xl flex flex-col justify-between",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div>
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-100 dark:border-slate-700/60">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider px-3 py-1 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                  {activeMechanism.type} Mechanism Canvas
                </span>
                <span className="text-xs text-slate-400 font-bold">Step {currentStepIndex + 1} of {activeMechanism.steps.length}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="flex items-center gap-1.5 bg-amber-600 hover:bg-amber-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-lg shadow-amber-500/20"
                >
                  {isPlaying ? <Pause size={14} /> : <Play size={14} />}
                  <span>{isPlaying ? 'Pause' : 'Animate'}</span>
                </button>
                <button
                  onClick={() => { setCurrentStepIndex(0); setIsPlaying(false); }}
                  className="p-2 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors cursor-pointer"
                >
                  <RotateCcw size={14} />
                </button>
              </div>
            </div>

            {/* Canvas Stage */}
            <div className="relative w-full rounded-2xl overflow-hidden border border-slate-700/60 shadow-inner">
              <canvas
                ref={canvasRef}
                width={700}
                height={320}
                className="w-full h-auto block"
              />
            </div>
          </div>

          <div className="mt-6 p-4 rounded-2xl bg-slate-900/60 border border-slate-700/80 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-400 block font-bold mb-0.5">Reactant:</span>
              <span className="font-mono text-amber-400">{activeMechanism.reactant}</span>
            </div>
            <ArrowRight size={18} className="text-slate-500" />
            <div>
              <span className="text-slate-400 block font-bold mb-0.5">Product:</span>
              <span className="font-mono text-emerald-400">{activeMechanism.product}</span>
            </div>
          </div>
        </div>

        {/* Right Col: Step-by-Step Breakdown */}
        <div className={cn(
          "p-6 md:p-8 rounded-3xl border shadow-xl flex flex-col justify-between",
          theme === 'dark' ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-200"
        )}>
          <div>
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-700/60">
              <h3 className="text-lg font-black tracking-tight">Step-by-Step Breakdown</h3>
              <span className="text-xs font-mono font-bold text-amber-500">{activeMechanism.type}</span>
            </div>

            <div className="space-y-3">
              {activeMechanism.steps.map((step, idx) => {
                const isCurrent = currentStepIndex === idx;
                return (
                  <div
                    key={idx}
                    onClick={() => { setCurrentStepIndex(idx); setIsPlaying(false); }}
                    className={cn(
                      "p-4 rounded-2xl border transition-all cursor-pointer",
                      isCurrent
                        ? "bg-amber-600 text-white border-amber-500 shadow-lg shadow-amber-500/20 scale-[1.02]"
                        : theme === 'dark'
                        ? "bg-slate-900/60 border-slate-700 hover:border-amber-500/50 text-slate-300"
                        : "bg-slate-50 border-slate-200 hover:border-amber-300 text-slate-700"
                    )}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-black">{step.title}</span>
                      <span className={cn("text-[10px] font-mono px-2 py-0.5 rounded-full font-bold", isCurrent ? "bg-amber-700 text-white" : "bg-slate-200 dark:bg-slate-800")}>
                        Step {idx + 1}
                      </span>
                    </div>
                    <p className={cn("text-xs leading-relaxed mb-2", isCurrent ? "text-amber-100" : "text-slate-500 dark:text-slate-400")}>
                      {step.details}
                    </p>
                    <div className={cn("text-[11px] font-mono font-bold italic", isCurrent ? "text-amber-200" : "text-amber-600 dark:text-amber-400")}>
                      ⚡ {step.arrowDescription}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400">
              <BookOpen size={14} />
              <span>{activeMechanism.chapter}</span>
            </div>
            <button
              onClick={() => {
                const num = parseInt(activeMechanism.chapter.replace(/[^0-9]/g, '')) || 10;
                onOpenChapter(num);
              }}
              className="flex items-center gap-1 bg-amber-50 hover:bg-amber-600 text-amber-600 hover:text-white dark:bg-amber-950/60 dark:hover:bg-amber-600 dark:text-amber-300 text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              <span>Read Chapter</span>
              <ExternalLink size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
