import React from 'react';

export const AdminDashboard: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-bold text-white">School Admin Dashboard</h2>
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
        <h3 className="text-lg font-semibold text-white">License Management</h3>
        <p className="text-slate-400">Total Licenses: 500 | Used: 480</p>
      </div>
    </div>
  );
};
