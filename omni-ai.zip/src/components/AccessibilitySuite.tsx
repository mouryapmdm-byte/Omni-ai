import React, { useState } from 'react';
import { 
  Eye, 
  Type, 
  Volume2, 
  Sparkles, 
  CheckCircle2, 
  Sliders, 
  Sun, 
  Moon, 
  Shield, 
  Hand, 
  Layers, 
  AlertCircle,
  Keyboard,
  ShieldCheck
} from 'lucide-react';
import { cn } from '../lib/utils';
import { A11yProvider } from '../modules/accessibility/A11yProvider';
import { PreferencesUI } from '../modules/accessibility/PreferencesUI';
import { ScreenReaderTestSuite } from '../modules/accessibility/ScreenReaderTestSuite';

interface Props {
  theme?: 'light' | 'dark';
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  onUpdateAccessibilitySettings?: (settings: any) => void;
}

export const AccessibilitySuite: React.FC<Props> = ({
  theme = 'light',
  showNotification,
  onUpdateAccessibilitySettings
}) => {
  const isDark = theme === 'dark';
  const [activeTab, setActiveTab] = useState<'preferences' | 'tester'>('preferences');

  return (
    <A11yProvider>
      <div className={cn(
        "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
        isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
      )}>
        {/* Navigation Switcher */}
        <div className={cn(
          "px-6 py-3 border-b flex items-center justify-between gap-4",
          isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
        )}>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('preferences')}
              className={cn(
                "px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5",
                activeTab === 'preferences'
                  ? "bg-cyan-600 text-white shadow-md"
                  : isDark ? "bg-slate-800 text-slate-400 hover:text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              )}
            >
              <Sliders size={14} /> Universal Preferences & Controls
            </button>

            <button
              onClick={() => setActiveTab('tester')}
              className={cn(
                "px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5",
                activeTab === 'tester'
                  ? "bg-purple-600 text-white shadow-md"
                  : isDark ? "bg-slate-800 text-slate-400 hover:text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              )}
            >
              <Keyboard size={14} /> Screen Reader Live Simulation
            </button>
          </div>

          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
            <ShieldCheck size={14} /> WCAG 2.1 AA Compliant
          </span>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === 'preferences' ? (
            <PreferencesUI
              isDark={isDark}
              showNotification={showNotification}
            />
          ) : (
            <div className="p-6">
              <ScreenReaderTestSuite
                isDark={isDark}
              />
            </div>
          )}
        </div>
      </div>
    </A11yProvider>
  );
};
