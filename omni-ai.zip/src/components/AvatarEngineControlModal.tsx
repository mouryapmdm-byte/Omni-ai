import React, { useState, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  MapPin, 
  Activity, 
  Play, 
  Square,
  User, 
  Check, 
  Layers, 
  Zap, 
  Compass, 
  Smile, 
  BookOpen, 
  Radio,
  Sliders,
  ChevronRight,
  Eye,
  Laptop,
  Maximize2,
  Minimize2,
  Table,
  DoorClosed,
  Clock,
  Volume2
} from 'lucide-react';
import { 
  avatarEngine, 
  LectureZone, 
  AvatarGesture, 
  AvatarExpression, 
  ProximityState,
  PROXIMITY_CONFIGS,
  ZONE_CONFIGS,
  GestureIntensity,
  MASTER_SYNCHRONISATION_TABLE,
  MasterSyncTimelineItem
} from '../services/avatarAnimationEngine';
import { cn } from '../lib/utils';

interface AvatarEngineControlModalProps {
  isOpen: boolean;
  onClose: () => void;
  showNotification?: (message: string, type: 'info' | 'success' | 'warning' | 'error') => void;
}

export const AvatarEngineControlModal: React.FC<AvatarEngineControlModalProps> = ({
  isOpen,
  onClose,
  showNotification
}) => {
  const [activeZone, setActiveZone] = useState<LectureZone>(avatarEngine.getActiveZone());
  const [activeGesture, setActiveGesture] = useState<AvatarGesture>(avatarEngine.getActiveGesture());
  const [activeExpression, setActiveExpression] = useState<AvatarExpression>(avatarEngine.getActiveExpression());
  const [activeProximity, setActiveProximity] = useState<ProximityState>(() => avatarEngine.getProximityState());
  const [isWalking, setIsWalking] = useState<boolean>(false);
  const [isStickExtended, setIsStickExtended] = useState<boolean>(false);
  const [isLaserOn, setIsLaserOn] = useState<boolean>(false);
  const [isFrontLaptopOpen, setIsFrontLaptopOpen] = useState<boolean>(true);
  const [isDoorOpen, setIsDoorOpen] = useState<boolean>(false);
  const [isSitting, setIsSitting] = useState<boolean>(false);
  const [isRoutinePlaying, setIsRoutinePlaying] = useState<boolean>(false);
  const [activeRoutineName, setActiveRoutineName] = useState<string>('');
  const [selectedIntensity, setSelectedIntensity] = useState<GestureIntensity>('natural');
  const [activeTab, setActiveTab] = useState<'routines' | 'master_table' | 'props' | 'proximity' | 'zones' | 'gestures' | 'expressions'>('routines');
  const [spokenLine, setSpokenLine] = useState<string>('');

  useEffect(() => {
    const unsub = avatarEngine.subscribe((state) => {
      setActiveZone(state.zone);
      setActiveGesture(state.gesture);
      setActiveExpression(state.expression);
      if (state.proximityState) setActiveProximity(state.proximityState);
      setIsWalking(state.isWalking);
      setIsStickExtended(state.isStickExtended);
      setIsLaserOn(state.isLaserOn);
      setIsFrontLaptopOpen(state.isFrontLaptopOpen);
      setIsDoorOpen(state.isDoorOpen);
      setIsSitting(state.isSitting);
      setIsRoutinePlaying(state.isRoutinePlaying);
      setActiveRoutineName(state.activeRoutineName);
    });
    return unsub;
  }, []);

  if (!isOpen) return null;

  const handleSpeech = (text: string) => {
    setSpokenLine(text);
    showNotification?.(text, 'info');
  };

  const handleSelectZone = (zone: LectureZone) => {
    avatarEngine.setZone(zone, true);
    showNotification?.(`Professor Clarity navigating smoothly to ${ZONE_CONFIGS[zone].name}`, 'info');
  };

  const handleTriggerGesture = (gesture: AvatarGesture, duration?: number) => {
    avatarEngine.triggerGesture(gesture, duration, selectedIntensity);
    showNotification?.(`Triggered gesture: ${gesture.replace(/_/g, ' ')}`, 'success');
  };

  const handleSetExpression = (expr: AvatarExpression) => {
    avatarEngine.triggerGesture(activeGesture, undefined, selectedIntensity, expr);
    showNotification?.(`Professor Clarity expression set to: ${expr.replace(/_/g, ' ')}`, 'info');
  };

  const stopRoutine = () => {
    avatarEngine.stopActiveRoutine();
    setSpokenLine('');
    showNotification?.('Stopped active routine', 'warning');
  };

  const executeRoutine = (routineIdx: number) => {
    switch (routineIdx) {
      case 1: avatarEngine.executeRoutine1_Entry(handleSpeech); break;
      case 2: avatarEngine.executeRoutine2_Greeting(handleSpeech); break;
      case 3: avatarEngine.executeRoutine3_Sitting(handleSpeech); break;
      case 4: avatarEngine.executeRoutine4_OpenLaptop(handleSpeech); break;
      case 5: avatarEngine.executeRoutine5_LaptopWriting(handleSpeech); break;
      case 6: avatarEngine.executeRoutine6_Speaking(handleSpeech); break;
      case 7: avatarEngine.executeRoutine7_IndicatingStick(handleSpeech); break;
      case 8: avatarEngine.executeRoutine8_StartLecture(handleSpeech); break;
      case 9: avatarEngine.executeRoutine9_FinishLecture(handleSpeech); break;
      case 10: avatarEngine.executeRoutine10_Exit(handleSpeech); break;
    }
  };

  const ROUTINE_CARDS = [
    { idx: 1, title: "1. Entry into Lecture Hall", zone: "Door → Desk → Podium", icon: "🚪", desc: "Opens entrance door, walks to front desk, drops bag, checks notes, walks to podium." },
    { idx: 2, title: "2. Greeting Students", zone: "Podium (Zone 4)", icon: "👋", desc: "Stands at center podium, opens arms warmly, adjusts microphone, makes direct eye contact." },
    { idx: 3, title: "3. Sitting on Chair", zone: "Front Desk (Zone 1)", icon: "🪑", desc: "Walks to desk, pulls out executive chair, sits down comfortably, pulls chair in, leans back." },
    { idx: 4, title: "4. Opening Laptop", zone: "Front Desk (Zone 1)", icon: "💻", desc: "Reaches for aluminum laptop, lifts screen open, backlight glows blue, affirms connection." },
    { idx: 5, title: "5. Writing on Laptop", zone: "Desk → Smartboard Sync", icon: "⌨️", desc: "Places hands on keyboard, types formula live, looks up at smartboard as text renders." },
    { idx: 6, title: "6. Speaking about Topic", zone: "Desk → Podium → Board", icon: "🗣️", desc: "Stands up, moves to podium, points with open palm, counts 3 key points, steps to board." },
    { idx: 7, title: "7. Indicating with Stick", zone: "Smartboard (Zone 2)", icon: "🪄", desc: "Picks up stick from hook, extends telescopic tube, activates laser, points A/B/C, circles & collapses." },
    { idx: 8, title: "8. Starting the Lecture", zone: "Podium → Smartboard", icon: "🏁", desc: "Places notes on podium, strides to board, picks up digital marker, writes topic title." },
    { idx: 9, title: "9. Finishing the Lecture", zone: "Board → Podium", icon: "🏆", desc: "Puts down marker, sweeping arm summary, walks to podium, hand on heart, final proud nod." },
    { idx: 10, title: "10. Exit of Professor", zone: "Podium → Desk → Door", icon: "🚶", desc: "Gathers notes, walks to desk, closes laptop, waves goodbye to students, exits through door." },
  ];

  const ZONE_LIST: { id: LectureZone; title: string; icon: string; desc: string; color: string }[] = [
    { id: 'front_desk', title: "Zone 1: Front Desk", icon: "🪑", desc: "Wooden teacher's desk, notebooks, lamp, water glass & nameplate", color: "from-sky-500/20 to-blue-600/10 border-sky-500/30" },
    { id: 'smartboard', title: "Zone 2: Smartboard", icon: "📊", desc: "Center interactive digital board, stylus tray, live formulas & diagrams", color: "from-indigo-500/20 to-purple-600/10 border-indigo-500/30" },
    { id: 'lab_bench', title: "Zone 3: Lab Bench", icon: "🔬", desc: "Science demo bench with Bunsen burner, microscope, molecular models", color: "from-emerald-500/20 to-teal-600/10 border-emerald-500/30" },
    { id: 'podium', title: "Zone 4: Lecture Podium", icon: "🎙️", desc: "Center-front podium with gooseneck mic, laptop & overhead projector", color: "from-amber-500/20 to-orange-600/10 border-amber-500/30" },
    { id: 'students', title: "Student Row Approach", icon: "👥", desc: "Front student interaction stance for direct engagement", color: "from-pink-500/20 to-rose-600/10 border-pink-500/30" },
    { id: 'door_entrance', title: "Hall Entrance / Exit", icon: "🚪", desc: "Entrance doorway for lecture greeting & dismissals", color: "from-slate-500/20 to-slate-600/10 border-slate-500/30" },
  ];

  const GESTURE_GROUPS: { category: string; icon: string; items: { name: AvatarGesture; label: string; desc: string }[] }[] = [
    {
      category: "Indicating Stick & Laser Gestures",
      icon: "🪄",
      items: [
        { name: 'stick_pick_up', label: 'Pick up Pointer Stick', desc: 'Lifts telescopic pointer stick from wall hook' },
        { name: 'stick_extend', label: 'Extend Telescopic Stick', desc: 'Extends pointer stick to 3x reach length' },
        { name: 'stick_point_board', label: 'Point Stick at Board', desc: 'Directs laser pointer dot at smartboard diagram' },
        { name: 'point_to_element_A', label: 'Point to Element A', desc: 'Points laser beam directly to top left item' },
        { name: 'point_to_element_B', label: 'Point to Element B', desc: 'Points laser beam directly to middle item' },
        { name: 'point_to_element_C', label: 'Point to Element C', desc: 'Points laser beam directly to bottom item' },
        { name: 'stick_trace_arrow', label: 'Trace Arrow with Stick', desc: 'Traces energy flow curve on board' },
        { name: 'stick_circle_element', label: 'Circle Formula with Stick', desc: 'Draws laser circle around key equation' },
        { name: 'stick_collapse', label: 'Collapse Stick', desc: 'Smoothly collapses stick to compact length' },
        { name: 'stick_hang_on_hook', label: 'Hang Stick on Hook', desc: 'Places stick back on magnetic smartboard hook' },
      ]
    },
    {
      category: "Laptop & Typing Gestures",
      icon: "💻",
      items: [
        { name: 'reach_for_laptop', label: 'Reach for Laptop', desc: 'Extends hands toward aluminum laptop' },
        { name: 'laptop_open', label: 'Open Laptop Lid', desc: 'Rotates screen lid open with glowing display' },
        { name: 'place_hands_on_keyboard', label: 'Place Hands on Keys', desc: 'Positions fingertips over laptop keyboard' },
        { name: 'laptop_typing', label: 'Type Live on Laptop', desc: 'Natural fast typing that mirrors to smartboard' },
        { name: 'look_up_at_smartboard', label: 'Look up at Board', desc: 'Glances up from laptop to check board sync' },
        { name: 'laptop_close', label: 'Close Laptop Lid', desc: 'Folds laptop screen down closed' },
      ]
    },
    {
      category: "Chair & Front Desk Controls",
      icon: "🪑",
      items: [
        { name: 'chair_pull_out', label: 'Pull Chair Out', desc: 'Slides chair back to prepare to sit' },
        { name: 'sit_at_desk', label: 'Sit at Desk', desc: 'Sits in teacher chair for student practice' },
        { name: 'chair_pull_in', label: 'Pull Chair In', desc: 'Slides chair close to desk edge' },
        { name: 'chair_swivel_left', label: 'Swivel Left', desc: 'Swivels chair 25° toward students' },
        { name: 'chair_swivel_right', label: 'Swivel Right', desc: 'Swivels chair 25° toward smartboard' },
        { name: 'stand_up_from_desk', label: 'Stand Up', desc: 'Rises smoothly to resume standing lecture' },
        { name: 'table_drawer_open', label: 'Open Desk Drawer', desc: 'Pulls out top supply drawer' },
        { name: 'table_drawer_close', label: 'Close Desk Drawer', desc: 'Slides drawer shut' },
        { name: 'table_lamp_on', label: 'Turn On Desk Lamp', desc: 'Illuminates warm brass gooseneck lamp' },
        { name: 'table_lamp_off', label: 'Turn Off Desk Lamp', desc: 'Extinguishes desk lamp' },
      ]
    },
    {
      category: "Smartboard Writing & Drawing",
      icon: "📊",
      items: [
        { name: 'writing_on_smartboard', label: 'Write on Board', desc: 'Right arm writes equations with digital marker' },
        { name: 'drawing_on_smartboard', label: 'Draw Diagram', desc: 'Renders visual schematic on smartboard' },
        { name: 'point_to_smartboard', label: 'Point to Board', desc: 'Directs students to key definition' },
        { name: 'touch_zoom_in', label: 'Touch Zoom In', desc: 'Two-hand expanding gesture on smartboard' },
        { name: 'touch_zoom_out', label: 'Touch Zoom Out', desc: 'Two-hand pinching gesture on smartboard' },
        { name: 'swipe_scroll_up', label: 'Swipe Scroll Up', desc: 'Vertical swipe to advance notes' },
        { name: 'underline_on_board', label: 'Underline Term', desc: 'Draws crisp underline under key keyword' },
        { name: 'circle_on_board', label: 'Circle Formula', desc: 'Highlights core formula in loop' },
        { name: 'erase_on_board', label: 'Erase Section', desc: 'Uses magnetic eraser to wipe board' },
        { name: 'turn_to_students_from_board', label: 'Turn to Students', desc: 'Pivots body from board back to class' },
      ]
    },
    {
      category: "Lab Bench & Molecular Props",
      icon: "🔬",
      items: [
        { name: 'use_microscope', label: 'Look in Microscope', desc: 'Peers into ocular with dual hands on knobs' },
        { name: 'adjust_microscope', label: 'Adjust Focus Knob', desc: 'Fine-tunes microscope objective stage' },
        { name: 'hold_up_prop', label: 'Hold Up Specimen', desc: 'Lifts plant leaf prop to camera height' },
        { name: 'hold_model', label: 'Hold Molecular Model', desc: 'Displays 3D molecular ball-and-stick' },
        { name: 'rotate_model', label: 'Rotate Molecule', desc: 'Rotates molecule model in 3D' },
        { name: 'demonstrate_reaction', label: 'Demonstrate Reaction', desc: 'Gestures above Bunsen burner & flasks' },
      ]
    },
    {
      category: "Rhetorical & Expressive Gestures",
      icon: "✨",
      items: [
        { name: 'open_palms_both', label: 'Open Palms (Both)', desc: 'Warm inclusive address to class' },
        { name: 'finger_count', label: 'Count Points (1-2-3)', desc: 'Sequentially counts key concepts' },
        { name: 'hand_on_heart', label: 'Hand on Heart', desc: 'Sincere inspirational connection' },
        { name: 'sweeping_arm', label: 'Sweeping Arm Gesture', desc: 'Grand overview of entire domain' },
        { name: 'look_at_wristwatch', label: 'Check Wristwatch', desc: 'Glances at watch to track lecture pacing' },
        { name: 'wave_goodbye', label: 'Wave Goodbye', desc: 'Warm farewell wave to students' },
        { name: 'encouraging_nod', label: 'Encouraging Nod', desc: 'Affirms student comprehension' },
        { name: 'shake_head', label: 'Shake Head (Warning)', desc: 'Highlights common misconception' },
        { name: 'proud_smile', label: 'Proud Smile', desc: 'Celebrates student mastery milestone' },
      ]
    }
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-5xl max-h-[92vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100 font-sans">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-2xl shadow-inner">
              🧑‍🏫
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-2">
                  Professor Clarity
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    Visual Avatar Animation Engine
                  </span>
                </h2>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Full Picture Elements (Laptop, Chair, Stick/Laser, Door) & 10 Lecture Routines
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {isRoutinePlaying ? (
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-300 text-xs font-bold flex items-center gap-1.5 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
                  {activeRoutineName}
                </span>
                <button
                  onClick={stopRoutine}
                  className="px-2.5 py-1 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Square size={12} /> Stop
                </button>
              </div>
            ) : (
              <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-xl bg-slate-800/80 border border-slate-700 text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-slate-400 font-medium">Zone:</span>
                <span className="font-bold text-indigo-300">{ZONE_CONFIGS[activeZone].name.split('(')[0]}</span>
              </div>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Live Speech HUD Strip */}
        {spokenLine && (
          <div className="px-5 py-2.5 bg-indigo-950/60 border-b border-indigo-500/30 flex items-center gap-3 text-xs text-indigo-200">
            <Volume2 size={16} className="text-indigo-400 animate-pulse shrink-0" />
            <span className="font-medium italic truncate">"{spokenLine}"</span>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 sm:gap-2 px-4 sm:px-6 pt-3 border-b border-slate-800/60 bg-slate-900/50 overflow-x-auto">
          <button
            onClick={() => setActiveTab('routines')}
            className={cn(
              "px-3 sm:px-4 py-2 text-xs font-bold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center gap-1.5 shrink-0",
              activeTab === 'routines'
                ? "border-purple-500 text-white bg-purple-600/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            )}
          >
            <Sparkles size={14} className="text-purple-400" />
            <span>10 Lecture Routines</span>
          </button>

          <button
            onClick={() => setActiveTab('master_table')}
            className={cn(
              "px-3 sm:px-4 py-2 text-xs font-bold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center gap-1.5 shrink-0",
              activeTab === 'master_table'
                ? "border-sky-500 text-white bg-sky-600/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            )}
          >
            <Clock size={14} className="text-sky-400" />
            <span>Master Sync Table (0:00 - 36:00)</span>
          </button>

          <button
            onClick={() => setActiveTab('props')}
            className={cn(
              "px-3 sm:px-4 py-2 text-xs font-bold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center gap-1.5 shrink-0",
              activeTab === 'props'
                ? "border-indigo-500 text-white bg-indigo-600/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            )}
          >
            <Laptop size={14} className="text-indigo-400" />
            <span>Picture Props Controls</span>
          </button>

          <button
            onClick={() => setActiveTab('proximity')}
            className={cn(
              "px-3 sm:px-4 py-2 text-xs font-bold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center gap-1.5 shrink-0",
              activeTab === 'proximity'
                ? "border-sky-500 text-white bg-sky-600/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            )}
          >
            <Radio size={14} className="text-sky-400" />
            <span>5-State Proximity Ring</span>
          </button>

          <button
            onClick={() => setActiveTab('zones')}
            className={cn(
              "px-3 sm:px-4 py-2 text-xs font-bold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center gap-1.5 shrink-0",
              activeTab === 'zones'
                ? "border-emerald-500 text-white bg-emerald-600/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            )}
          >
            <MapPin size={14} className="text-emerald-400" />
            <span>4 Zones</span>
          </button>

          <button
            onClick={() => setActiveTab('gestures')}
            className={cn(
              "px-3 sm:px-4 py-2 text-xs font-bold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center gap-1.5 shrink-0",
              activeTab === 'gestures'
                ? "border-amber-500 text-white bg-amber-600/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            )}
          >
            <Activity size={14} className="text-amber-400" />
            <span>Gestures</span>
          </button>

          <button
            onClick={() => setActiveTab('expressions')}
            className={cn(
              "px-3 sm:px-4 py-2 text-xs font-bold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center gap-1.5 shrink-0",
              activeTab === 'expressions'
                ? "border-pink-500 text-white bg-pink-600/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            )}
          >
            <Smile size={14} className="text-pink-400" />
            <span>Expressions</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">

          {/* TAB 1: 10 DISTINCT LECTURE ROUTINES */}
          {activeTab === 'routines' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-white">10 Pedagogical Teaching Routines</h3>
                  <p className="text-xs text-slate-400">Click any routine to execute the animated kinematic flow with synchronized speech</p>
                </div>
                {isRoutinePlaying && (
                  <button
                    onClick={stopRoutine}
                    className="px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-bold flex items-center gap-1.5 self-start cursor-pointer hover:bg-rose-500"
                  >
                    <Square size={13} /> Cancel Active Routine
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {ROUTINE_CARDS.map((r) => (
                  <div
                    key={r.idx}
                    onClick={() => executeRoutine(r.idx)}
                    className={cn(
                      "p-4 rounded-2xl border transition-all cursor-pointer bg-gradient-to-b relative overflow-hidden group flex flex-col justify-between",
                      activeRoutineName.includes(`Routine ${r.idx}`)
                        ? "from-purple-600/30 to-indigo-950/40 border-purple-400 ring-2 ring-purple-400 shadow-xl"
                        : "from-slate-800/60 to-slate-900/80 border-slate-800 hover:border-purple-500/50 hover:bg-slate-800"
                    )}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-2xl">{r.icon}</span>
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-slate-800 text-purple-300 border border-purple-500/30">
                          {r.zone}
                        </span>
                      </div>
                      <h4 className="font-extrabold text-sm text-white mb-1 group-hover:text-purple-300 transition-colors">
                        {r.title}
                      </h4>
                      <p className="text-xs text-slate-300 leading-relaxed mb-3">{r.desc}</p>
                    </div>

                    <button className="w-full mt-2 py-1.5 px-3 rounded-xl bg-purple-600/80 hover:bg-purple-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors">
                      <Play size={12} className="fill-white" /> Play Routine {r.idx}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: MASTER SYNCHRONISATION TABLE */}
          {activeTab === 'master_table' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white">Master Synchronisation Table (0:00 to 36:00)</h3>
                <p className="text-xs text-slate-400">Complete multi-modal synchronization matrix across time, zone, picture elements, voice, and smartboard.</p>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60 shadow-xl">
                <table className="w-full text-left text-xs text-slate-300 border-collapse">
                  <thead className="bg-slate-950/90 text-[11px] font-black uppercase text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="p-3">Time</th>
                      <th className="p-3">Action</th>
                      <th className="p-3">Zone</th>
                      <th className="p-3">Picture Element</th>
                      <th className="p-3">Animation Trigger</th>
                      <th className="p-3">Spoken Line</th>
                      <th className="p-3">Smartboard</th>
                      <th className="p-3 text-right">Trigger</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-sans">
                    {MASTER_SYNCHRONISATION_TABLE.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-3 font-mono font-bold text-indigo-400">{item.time}</td>
                        <td className="p-3 font-bold text-white">{item.professorAction}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                            {item.zone}
                          </span>
                        </td>
                        <td className="p-3 text-amber-300">{item.pictureElement}</td>
                        <td className="p-3 font-mono text-[11px] text-emerald-400">{item.animation}</td>
                        <td className="p-3 italic text-slate-300 max-w-xs truncate" title={item.voice}>"{item.voice}"</td>
                        <td className="p-3 text-sky-300">{item.smartboard}</td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => {
                              avatarEngine.setZone(item.zone, true);
                              avatarEngine.triggerGesture(item.animation, 3.0, 'natural');
                              handleSpeech(item.voice);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold cursor-pointer"
                          >
                            Play
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: PICTURE PROPS CONTROLS */}
          {activeTab === 'props' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-bold text-white">Picture Elements Interactive Controllers</h3>
                <p className="text-xs text-slate-400">Directly control 3D props, telescopic indicating stick, laptop hinges, drawers, and doors</p>
              </div>

              {/* Telescopic Indicating Stick & Laser */}
              <div className="p-4 rounded-2xl border border-indigo-500/30 bg-slate-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">🪄</span>
                    <div>
                      <h4 className="text-xs font-bold text-white">Telescopic Indicating Stick & Smartboard Laser</h4>
                      <p className="text-[11px] text-slate-400">Controls 3x reach extension and red laser dot on smartboard formulas</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold", isStickExtended ? "bg-emerald-500/20 text-emerald-300" : "bg-slate-700 text-slate-400")}>
                      {isStickExtended ? 'Stick Extended (3x)' : 'Stick Collapsed'}
                    </span>
                    <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold", isLaserOn ? "bg-rose-500/20 text-rose-300" : "bg-slate-700 text-slate-400")}>
                      {isLaserOn ? 'Laser Active' : 'Laser Off'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  <button
                    onClick={() => { avatarEngine.triggerGesture('stick_pick_up'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    1. Pick up Stick
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('stick_extend'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    2. Extend Stick
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('point_to_element_A'); }}
                    className="p-2.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-xs font-bold text-indigo-200 text-left"
                  >
                    3. Point Element A
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('point_to_element_B'); }}
                    className="p-2.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-xs font-bold text-indigo-200 text-left"
                  >
                    4. Point Element B
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('stick_trace_arrow'); }}
                    className="p-2.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-xs font-bold text-indigo-200 text-left"
                  >
                    5. Trace Arrow
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('stick_circle_element'); }}
                    className="p-2.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-xs font-bold text-indigo-200 text-left"
                  >
                    6. Circle Formula
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('stick_collapse'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    7. Collapse Stick
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('stick_hang_on_hook'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    8. Hang on Hook
                  </button>
                </div>
              </div>

              {/* Front Desk Laptop Controls */}
              <div className="p-4 rounded-2xl border border-sky-500/30 bg-slate-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">💻</span>
                    <div>
                      <h4 className="text-xs font-bold text-white">Aluminum Laptop Screen & Typing Mirror</h4>
                      <p className="text-[11px] text-slate-400">Controls screen open/close angle and live typewriter keyboard animations</p>
                    </div>
                  </div>
                  <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold", isFrontLaptopOpen ? "bg-sky-500/20 text-sky-300" : "bg-slate-700 text-slate-400")}>
                    {isFrontLaptopOpen ? 'Lid Open (Screen Glowing)' : 'Lid Closed'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  <button
                    onClick={() => { avatarEngine.triggerGesture('laptop_open'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Open Laptop Lid
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('place_hands_on_keyboard'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Hands on Keyboard
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('laptop_typing'); }}
                    className="p-2.5 rounded-xl bg-sky-600/30 hover:bg-sky-600/50 border border-sky-500/40 text-xs font-bold text-sky-200 text-left"
                  >
                    Type Live
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('laptop_close'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Close Laptop Lid
                  </button>
                </div>
              </div>

              {/* Front Desk Executive Chair & Drawers */}
              <div className="p-4 rounded-2xl border border-amber-500/30 bg-slate-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">🪑</span>
                    <div>
                      <h4 className="text-xs font-bold text-white">Executive Swivel Chair & Desk Drawers</h4>
                      <p className="text-[11px] text-slate-400">Controls chair distance slide, 25° left/right swivel, and supply drawer sliding</p>
                    </div>
                  </div>
                  <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold", isSitting ? "bg-amber-500/20 text-amber-300" : "bg-slate-700 text-slate-400")}>
                    {isSitting ? 'Seated on Chair' : 'Standing'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  <button
                    onClick={() => { avatarEngine.triggerGesture('chair_pull_out'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Pull Chair Out
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('sit_at_desk'); }}
                    className="p-2.5 rounded-xl bg-amber-600/30 hover:bg-amber-600/50 border border-amber-500/40 text-xs font-bold text-amber-200 text-left"
                  >
                    Sit on Chair
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('chair_swivel_left'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Swivel Left 25°
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('chair_swivel_right'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Swivel Right 25°
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('stand_up_from_desk'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Stand Up
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('table_drawer_open'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Open Desk Drawer
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('table_drawer_close'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Close Drawer
                  </button>
                  <button
                    onClick={() => { avatarEngine.triggerGesture('table_lamp_on'); }}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 text-left"
                  >
                    Toggle Lamp
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: 5-STATE PROXIMITY INDICATOR */}
          {activeTab === 'proximity' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Radio size={16} className="text-sky-400" />
                    5-State Glowing Floor Proximity Indicator Ring
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Controls the animated glowing ground projection underneath Professor Clarity
                  </p>
                </div>
                <div 
                  className="px-3 py-1.5 rounded-full border text-xs font-bold flex items-center gap-2"
                  style={{
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    borderColor: PROXIMITY_CONFIGS[activeProximity].colorHex,
                    color: '#f8fafc'
                  }}
                >
                  <span 
                    className="w-2.5 h-2.5 rounded-full animate-ping"
                    style={{ backgroundColor: PROXIMITY_CONFIGS[activeProximity].colorHex }}
                  />
                  <span>Active: {PROXIMITY_CONFIGS[activeProximity].name}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(Object.keys(PROXIMITY_CONFIGS) as ProximityState[]).map((stateKey) => {
                  const cfg = PROXIMITY_CONFIGS[stateKey];
                  const isCurrent = activeProximity === stateKey;
                  return (
                    <div
                      key={stateKey}
                      onClick={() => {
                        avatarEngine.setProximityState(stateKey);
                        showNotification?.(`Proximity State switched to ${cfg.name}`, 'info');
                      }}
                      className={cn(
                        "p-5 rounded-2xl border transition-all cursor-pointer bg-slate-950/60 relative overflow-hidden flex flex-col justify-between group",
                        isCurrent 
                          ? "ring-2 shadow-xl" 
                          : "hover:border-slate-700 hover:bg-slate-900/60 border-slate-800"
                      )}
                      style={{
                        borderColor: isCurrent ? cfg.colorHex : undefined,
                        boxShadow: isCurrent ? `0 0 25px ${cfg.colorHex}33` : undefined
                      }}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <span 
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: cfg.colorHex }}
                          />
                          <span className="text-[10px] font-mono text-slate-400">
                            Width: {cfg.ringWidth}px • Pulse: {cfg.pulsePeriodSec}s
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white group-hover:text-sky-300 transition-colors">
                          {cfg.name} ({cfg.label})
                        </h4>
                        <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                          {cfg.description}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-900 flex items-center justify-between text-[11px]">
                        <span className="text-slate-500">Floor Color: <strong style={{ color: cfg.colorHex }}>{cfg.colorHex}</strong></span>
                        {isCurrent && (
                          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold flex items-center gap-1 text-[10px]">
                            <Check size={10} /> Active
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: ZONES */}
          {activeTab === 'zones' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Interactive 3D Lecture Hall Zones</h3>
                  <p className="text-xs text-slate-400">Click any zone to navigate Professor Clarity with smooth path kinematics</p>
                </div>
                {isWalking && (
                  <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5 animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                    Walking to target zone...
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {ZONE_LIST.map((zone) => {
                  const isCurrent = activeZone === zone.id;
                  return (
                    <div
                      key={zone.id}
                      onClick={() => handleSelectZone(zone.id)}
                      className={cn(
                        "p-4 rounded-2xl border transition-all cursor-pointer bg-gradient-to-b relative overflow-hidden group",
                        zone.color,
                        isCurrent ? "ring-2 ring-indigo-400 shadow-lg shadow-indigo-500/20" : "hover:border-slate-600 hover:bg-slate-800/60"
                      )}
                    >
                      {isCurrent && (
                        <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                          <Check size={10} /> Active Here
                        </span>
                      )}
                      <div className="text-2xl mb-2">{zone.icon}</div>
                      <h4 className="font-extrabold text-sm text-white mb-1 group-hover:text-indigo-300 transition-colors">
                        {zone.title}
                      </h4>
                      <p className="text-xs text-slate-300/80 leading-relaxed">{zone.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: GESTURES */}
          {activeTab === 'gestures' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-800/40 p-3 rounded-2xl border border-slate-800">
                <div className="flex items-center gap-2">
                  <Sliders size={14} className="text-indigo-400" />
                  <span className="text-xs font-bold text-slate-300">Gesture Intensity:</span>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {(['subtle', 'natural', 'energetic', 'careful', 'proud'] as GestureIntensity[]).map((int) => (
                    <button
                      key={int}
                      onClick={() => setSelectedIntensity(int)}
                      className={cn(
                        "px-2.5 py-1 rounded-lg text-[11px] font-bold capitalize transition-colors cursor-pointer",
                        selectedIntensity === int
                          ? "bg-indigo-600 text-white shadow-sm"
                          : "bg-slate-800 text-slate-400 hover:text-white"
                      )}
                    >
                      {int}
                    </button>
                  ))}
                </div>
              </div>

              {GESTURE_GROUPS.map((group) => (
                <div key={group.category} className="space-y-3">
                  <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
                    <span className="text-lg">{group.icon}</span>
                    <h3 className="text-xs font-black uppercase tracking-wider text-slate-300">{group.category}</h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                    {group.items.map((item) => {
                      const isCurrent = activeGesture === item.name;
                      return (
                        <button
                          key={item.name}
                          onClick={() => handleTriggerGesture(item.name)}
                          className={cn(
                            "p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between",
                            isCurrent
                              ? "bg-indigo-600/20 border-indigo-500 text-white shadow-md"
                              : "bg-slate-800/50 border-slate-700/60 text-slate-200 hover:bg-slate-800 hover:border-slate-600"
                          )}
                        >
                          <div className="flex items-center justify-between w-full">
                            <span className="font-bold text-xs">{item.label}</span>
                            {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping" />}
                          </div>
                          <p className="text-[10px] text-slate-400 mt-1 leading-snug">{item.desc}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 6: EXPRESSIONS */}
          {activeTab === 'expressions' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white">Professor Clarity Expressions & Smart Visor Glow</h3>
                <p className="text-xs text-slate-400">Controls head tilt, eye-contact, and optical visor emissive shader state</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {[
                  { id: 'warm_smile', label: 'Warm Smile', color: 'text-sky-400', desc: 'Encouraging pedagogical smile with warm sky-blue visor glow' },
                  { id: 'proud_smile', label: 'Proud Smile', color: 'text-amber-400', desc: 'Broad affirming smile celebrating student breakthroughs' },
                  { id: 'focused', label: 'Deep Focus', color: 'text-indigo-400', desc: 'Analytical derivation posture with indigo visor illumination' },
                  { id: 'curious', label: 'Curious Inquiry', color: 'text-emerald-400', desc: 'Inquisitive head tilt and emerald visor tone' },
                  { id: 'concerned', label: 'Concerned / Misconception Warning', color: 'text-rose-400', desc: 'Gentle corrective shake for classic misconceptions' },
                  { id: 'confident', label: 'Confident Mastery', color: 'text-purple-400', desc: 'Academic authority and final lesson stance' },
                ].map((expr) => {
                  const isCurrent = activeExpression === expr.id;
                  return (
                    <div
                      key={expr.id}
                      onClick={() => handleSetExpression(expr.id as AvatarExpression)}
                      className={cn(
                        "p-4 rounded-2xl border transition-all cursor-pointer bg-slate-800/40",
                        isCurrent
                          ? "border-indigo-500 bg-indigo-600/10 ring-2 ring-indigo-500/30"
                          : "border-slate-800 hover:border-slate-700 hover:bg-slate-800/80"
                      )}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className={cn("font-bold text-sm", expr.color)}>{expr.label}</span>
                        {isCurrent && <Check size={14} className="text-emerald-400" />}
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{expr.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Kinematic Rig: Active (30 FPS Synced)</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};

