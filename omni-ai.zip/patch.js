const fs = require('fs');
let code = fs.readFileSync('src/components/Chat.tsx', 'utf8');
code = code.replace(
`                                className={cn(                                                      <button 
                          className="w-full py-2 bg-indigo-600 text-white rounded-xl font-black text-xs shadow-lg shadow-indigo-500/20"`,
`                                className={cn(
                                  "py-1 px-2 rounded text-[10px] font-bold border transition-all",
                                  aspectRatio === ratio 
                                    ? "bg-indigo-500 border-indigo-500 text-white" 
                                    : (theme === 'dark' ? "border-slate-800 text-slate-400 hover:border-slate-700" : "border-slate-200 text-slate-600 hover:border-indigo-200")
                                )}
                              >
                                {ratio}
                              </button>
                            ))}
                          </div>
                        </div>

                        <button 
                          className="w-full py-2 bg-indigo-600 text-white rounded-xl font-black text-xs shadow-lg shadow-indigo-500/20"`);
fs.writeFileSync('src/components/Chat.tsx', code);
