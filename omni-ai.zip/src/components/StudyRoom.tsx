import React, { useState, useRef, useEffect } from 'react';
import { 
  StudyGroupParticipant, 
  StudyGroupMessage, 
  StudyGroupRoom 
} from '../modules/social/types';
import { 
  Users, 
  Mic, 
  MicOff, 
  Hand, 
  Send, 
  Eraser, 
  Trash2, 
  Sparkles, 
  GraduationCap, 
  MessageSquare, 
  Share2, 
  Check, 
  Volume2, 
  ShieldCheck,
  ChevronRight,
  Maximize2
} from 'lucide-react';
import { cn } from '../lib/utils';
import { generateAIResponse } from '../lib/gemini';
import { ModerationEngine } from './ModerationLayer';

export interface StudyRoomProps {
  currentStudentId?: string;
  currentStudentName?: string;
  conceptTitle?: string;
  onLeave?: () => void;
  className?: string;
}

export const StudyRoom: React.FC<StudyRoomProps> = ({
  currentStudentId = 'student_user',
  currentStudentName = 'Alex',
  conceptTitle = 'Faraday-Lenz Law & Magnetic Induction',
  onLeave,
  className
}) => {
  // 4 concurrent participants
  const [participants, setParticipants] = useState<StudyGroupParticipant[]>([
    { id: currentStudentId, name: `${currentStudentName} (You)`, avatar: '🎓', role: 'teacher', isSpeaking: false, isMuted: false },
    { id: 'peer_priya', name: 'Priya R.', avatar: '⚡', role: 'learner', isSpeaking: false, isMuted: true },
    { id: 'peer_marcus', name: 'Marcus Chen', avatar: '🔬', role: 'learner', isSpeaking: false, isMuted: true },
    { id: 'peer_sara', name: 'Sara K.', avatar: '🚀', role: 'learner', isSpeaking: false, isMuted: true }
  ]);

  const [teacherId, setTeacherId] = useState<string>(currentStudentId);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [handRaised, setHandRaised] = useState<boolean>(false);
  const [messages, setMessages] = useState<StudyGroupMessage[]>([
    {
      id: 'msg_0',
      senderId: 'prof_clarity',
      senderName: 'Professor Clarity (AI Moderator)',
      senderRole: 'moderator',
      text: `Welcome to the Study Room on "${conceptTitle}". Alex has the floor as Teacher. Priya, Marcus, and Sara can ask questions on the smartboard!`,
      timestamp: 'Just now',
      isAiModeration: true
    },
    {
      id: 'msg_1',
      senderId: 'peer_priya',
      senderName: 'Priya R.',
      senderRole: 'learner',
      text: 'Alex, when the magnet moves into the coil, why does the current create an opposing magnetic field instead of aiding it?',
      timestamp: '1m ago',
      isQuestion: true
    }
  ]);

  const [inputMsg, setInputMsg] = useState('');
  const [aiThinking, setAiThinking] = useState(false);

  // Smartboard canvas state
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawColor, setDrawColor] = useState('#6366f1');
  const [drawSize, setDrawSize] = useState(3);
  const [isEraser, setIsEraser] = useState(false);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set high DPI canvas resolution
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Draw initial smartboard diagram
    drawSeedDiagram(ctx, rect.width, rect.height);
  }, []);

  const drawSeedDiagram = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    ctx.clearRect(0, 0, w, h);
    
    // Draw wire coil
    ctx.strokeStyle = '#818cf8';
    ctx.lineWidth = 4;
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const cx = w * 0.45 + i * 24;
      const cy = h * 0.45;
      ctx.ellipse(cx, cy, 14, 40, 0, 0, Math.PI * 2);
    }
    ctx.stroke();

    // Draw bar magnet approaching
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(w * 0.15, h * 0.40, 50, 24);
    ctx.fillStyle = '#3b82f6';
    ctx.fillRect(w * 0.15 + 50, h * 0.40, 50, 24);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText('N', w * 0.15 + 18, h * 0.40 + 16);
    ctx.fillText('S', w * 0.15 + 68, h * 0.40 + 16);

    // Arrow pointing to coil
    ctx.strokeStyle = '#22c55e';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(w * 0.28, h * 0.45);
    ctx.lineTo(w * 0.38, h * 0.45);
    ctx.lineTo(w * 0.36, h * 0.42);
    ctx.moveTo(w * 0.38, h * 0.45);
    ctx.lineTo(w * 0.36, h * 0.48);
    ctx.stroke();

    // Equation label
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 13px monospace';
    ctx.fillText('EMF = - d(Phi_B) / dt', w * 0.35, h * 0.85);
  };

  const handleStartDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const handleMoveDraw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.strokeStyle = isEraser ? '#0f172a' : drawColor;
    ctx.lineWidth = isEraser ? 18 : drawSize;
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const handleStopDraw = () => {
    setIsDrawing(false);
  };

  const handleClearBoard = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.clearRect(0, 0, rect.width, rect.height);
  };

  const handlePassChalk = (targetId: string) => {
    setTeacherId(targetId);
    setParticipants(prev => prev.map(p => ({
      ...p,
      role: p.id === targetId ? 'teacher' : 'learner'
    })));

    const targetUser = participants.find(p => p.id === targetId);
    setMessages(prev => [
      ...prev,
      {
        id: `msg_${Date.now()}`,
        senderId: 'prof_clarity',
        senderName: 'Professor Clarity (AI Moderator)',
        senderRole: 'moderator',
        text: `Chalk handed over! ${targetUser?.name || 'Classmate'} is now leading the smartboard explanation.`,
        timestamp: 'Just now',
        isAiModeration: true
      }
    ]);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim()) return;

    // Run moderation
    const mod = ModerationEngine.screenContent(inputMsg);
    if (!mod.isSafe) {
      alert(mod.suggestion || 'Please keep discussion constructive and supportive.');
      return;
    }

    const userMessage: StudyGroupMessage = {
      id: `msg_${Date.now()}`,
      senderId: currentStudentId,
      senderName: `${currentStudentName} (You)`,
      senderRole: teacherId === currentStudentId ? 'teacher' : 'learner',
      text: inputMsg,
      timestamp: 'Just now',
      isQuestion: inputMsg.includes('?')
    };

    setMessages(prev => [...prev, userMessage]);
    const sentText = inputMsg;
    setInputMsg('');

    // Trigger AI co-teacher response if student asked a question or explained a concept
    if (sentText.toLowerCase().includes('clarity') || sentText.includes('?') || teacherId === currentStudentId) {
      setAiThinking(true);
      try {
        const prompt = `You are Professor Clarity, acting as the pedagogical co-teacher and moderator in a virtual 4-student STEM study room.
Topic: "${conceptTitle}".
Student said: "${sentText}".
Participants: Alex (Teacher), Priya, Marcus, Sara.

Provide a concise 1-2 sentence response to either:
1. Validate and praise the student's teaching breakdown.
2. Answer the question with supreme clarity using a quick analogy.
Keep it warm, encouraging, and scientifically rigorous.`;

        const reply = await generateAIResponse(prompt);
        if (reply && reply.trim()) {
          setMessages(prev => [
            ...prev,
            {
              id: `msg_ai_${Date.now()}`,
              senderId: 'prof_clarity',
              senderName: 'Professor Clarity (AI Co-Teacher)',
              senderRole: 'moderator',
              text: reply.trim(),
              timestamp: 'Just now',
              isAiModeration: true
            }
          ]);
        }
      } catch {
        // Fallback response
        setMessages(prev => [
          ...prev,
          {
            id: `msg_ai_${Date.now()}`,
            senderId: 'prof_clarity',
            senderName: 'Professor Clarity (AI Co-Teacher)',
            senderRole: 'moderator',
            text: 'Spot on! By Lenz\'s law, the induced field opposes the motion to preserve conservation of energy. If it aided it, we would get free runaway energy!',
            timestamp: 'Just now',
            isAiModeration: true
          }
        ]);
      } finally {
        setAiThinking(false);
      }
    }
  };

  const isCurrentStudentTeacher = teacherId === currentStudentId;

  return (
    <div className={cn(
      "rounded-3xl border overflow-hidden shadow-2xl flex flex-col bg-slate-900 text-slate-100 border-slate-800",
      className
    )}>
      {/* Top Header Bar */}
      <div className="px-5 py-3.5 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-600/30">
            <Users size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-black text-white">
                Study Group Room (4/4 Students)
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Concept: <span className="text-indigo-300 font-semibold">{conceptTitle}</span>
            </p>
          </div>
        </div>

        {/* Action controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsMuted(!isMuted)}
            className={cn(
              "px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border",
              isMuted 
                ? "bg-rose-500/20 text-rose-300 border-rose-500/30"
                : "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
            )}
          >
            {isMuted ? <MicOff size={14} /> : <Mic size={14} />}
            <span>{isMuted ? 'Muted' : 'Mic Live'}</span>
          </button>

          <button
            type="button"
            onClick={() => setHandRaised(!handRaised)}
            className={cn(
              "px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border",
              handRaised 
                ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
            )}
          >
            <Hand size={14} />
            <span>{handRaised ? 'Hand Raised' : 'Raise Hand'}</span>
          </button>

          {onLeave && (
            <button
              type="button"
              onClick={onLeave}
              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer"
            >
              Leave Room
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Smartboard (Left) + Participants & Chat (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 flex-1">
        {/* Smartboard Canvas Area (8 cols) */}
        <div className="lg:col-span-8 p-4 flex flex-col border-b lg:border-b-0 lg:border-r border-slate-800 bg-slate-950/60">
          {/* Smartboard Toolbar */}
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-800/80 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold text-indigo-400 flex items-center gap-1.5">
                <GraduationCap size={16} />
                Shared Smartboard
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
                Current Teacher: {participants.find(p => p.id === teacherId)?.name || 'Alex'}
              </span>
            </div>

            {/* Drawing Tools */}
            <div className="flex items-center gap-1.5">
              {['#6366f1', '#ec4899', '#22c55e', '#eab308', '#f8fafc'].map(col => (
                <button
                  key={col}
                  onClick={() => { setDrawColor(col); setIsEraser(false); }}
                  className={cn(
                    "w-5 h-5 rounded-full border transition cursor-pointer",
                    drawColor === col && !isEraser ? "ring-2 ring-white scale-110" : "opacity-70 hover:opacity-100"
                  )}
                  style={{ backgroundColor: col }}
                />
              ))}

              <div className="h-4 w-px bg-slate-700 mx-1" />

              <button
                onClick={() => setIsEraser(!isEraser)}
                className={cn(
                  "p-1.5 rounded-lg text-xs transition cursor-pointer",
                  isEraser ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
                )}
                title="Eraser"
              >
                <Eraser size={14} />
              </button>

              <button
                onClick={handleClearBoard}
                className="p-1.5 rounded-lg text-xs bg-slate-800 text-slate-400 hover:text-rose-400 hover:bg-slate-700 transition cursor-pointer"
                title="Clear Board"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>

          {/* Interactive Canvas */}
          <div className="flex-1 w-full min-h-[340px] relative rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden cursor-crosshair">
            <canvas
              ref={canvasRef}
              onMouseDown={handleStartDraw}
              onMouseMove={handleMoveDraw}
              onMouseUp={handleStopDraw}
              onMouseLeave={handleStopDraw}
              onTouchStart={handleStartDraw}
              onTouchMove={handleMoveDraw}
              onTouchEnd={handleStopDraw}
              className="w-full h-full block touch-none"
            />

            {!isCurrentStudentTeacher && (
              <div className="absolute top-3 right-3 bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-xl text-[11px] font-semibold text-slate-300 border border-slate-800">
                👀 Observing Mode (Alex is Drawing)
              </div>
            )}
          </div>
        </div>

        {/* Sidebar: 4 Concurrent Participants + Discussion & AI Moderator (4 cols) */}
        <div className="lg:col-span-4 p-4 flex flex-col bg-slate-900/90 gap-4">
          {/* Participants Grid (4 concurrent seats) */}
          <div className="space-y-2">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 block">
              Active Room Seats (4 Max)
            </span>

            <div className="grid grid-cols-2 gap-2">
              {participants.map(p => {
                const isThisTeacher = p.id === teacherId;
                return (
                  <div
                    key={p.id}
                    className={cn(
                      "p-2.5 rounded-xl border transition-all flex items-center justify-between",
                      isThisTeacher 
                        ? "bg-indigo-950/50 border-indigo-500/50 text-indigo-200 ring-1 ring-indigo-500/30"
                        : "bg-slate-950/40 border-slate-800 text-slate-300"
                    )}
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <span className="text-base shrink-0">{p.avatar}</span>
                      <div className="truncate">
                        <p className="text-xs font-bold truncate leading-tight">{p.name}</p>
                        <span className={cn(
                          "text-[9px] font-extrabold uppercase tracking-wider",
                          isThisTeacher ? "text-indigo-400" : "text-slate-500"
                        )}>
                          {isThisTeacher ? 'Teacher' : 'Learner'}
                        </span>
                      </div>
                    </div>

                    {isCurrentStudentTeacher && p.id !== currentStudentId && (
                      <button
                        type="button"
                        onClick={() => handlePassChalk(p.id)}
                        className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 hover:underline px-1.5 py-0.5 rounded cursor-pointer"
                        title="Pass chalk to this student"
                      >
                        Pass
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Chat & AI Moderation Log */}
          <div className="flex-1 flex flex-col min-h-[220px] max-h-[300px] rounded-2xl bg-slate-950/60 border border-slate-800 p-3 overflow-hidden">
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
              {messages.map(msg => (
                <div
                  key={msg.id}
                  className={cn(
                    "p-2.5 rounded-xl text-xs space-y-1",
                    msg.isAiModeration
                      ? "bg-indigo-950/40 border border-indigo-500/30 text-indigo-200"
                      : msg.isQuestion
                        ? "bg-amber-950/30 border border-amber-500/30 text-amber-200"
                        : "bg-slate-800/60 border border-slate-700/50 text-slate-200"
                  )}
                >
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span className="font-bold text-slate-300 flex items-center gap-1">
                      {msg.isAiModeration && <Sparkles size={11} className="text-indigo-400" />}
                      {msg.senderName}
                    </span>
                    <span>{msg.timestamp}</span>
                  </div>
                  <p className="leading-relaxed font-normal">{msg.text}</p>
                </div>
              ))}
              {aiThinking && (
                <div className="p-2 rounded-xl bg-indigo-950/30 border border-indigo-500/20 text-[11px] text-indigo-300 flex items-center gap-2">
                  <Sparkles size={12} className="animate-spin" />
                  <span>Professor Clarity is synthesizing answer...</span>
                </div>
              )}
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendMessage} className="pt-2 flex gap-1.5 mt-2 border-t border-slate-800">
              <input
                type="text"
                placeholder="Ask a question or explain a point..."
                value={inputMsg}
                onChange={(e) => setInputMsg(e.target.value)}
                className="flex-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                disabled={!inputMsg.trim()}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition flex items-center justify-center cursor-pointer disabled:opacity-40"
              >
                <Send size={13} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
