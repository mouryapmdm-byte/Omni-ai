// ai-tutor/UniversalTutorCache.ts
import { StudentProfile, TutorRequest, IntentType, TutorResponse } from './types';

interface CacheEntry {
  response: TutorResponse;
  expiresAt: number;
}

export class UniversalTutorCache {
  private memoryCache: Map<string, CacheEntry> = new Map();
  private readonly defaultTtlMs = 7 * 24 * 60 * 60 * 1000; // 7 days TTL
  private hits = 0;
  private misses = 0;

  /**
   * Builds the canonical composite cache key
   */
  buildKey(
    profile: StudentProfile,
    request: TutorRequest,
    intent: IntentType
  ): string {
    const rawMessageKey = request.message
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]/g, '_')
      .slice(0, 40);

    return [
      profile.board,
      String(profile.classLevel),
      request.context.subjectId || profile.subjectId || 'general',
      request.context.chapterId || 'ch_gen',
      request.context.topicId || rawMessageKey,
      intent,
      profile.preferredLanguage || 'en',
      profile.examTargets?.[0] || 'general'
    ].join('::');
  }

  async get(key: string): Promise<TutorResponse | null> {
    const now = Date.now();

    // 1. Check in-memory cache
    const mem = this.memoryCache.get(key);
    if (mem && mem.expiresAt > now) {
      this.hits++;
      return mem.response;
    }

    // 2. Check localStorage (for browser persistence & offline support)
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        const item = window.localStorage.getItem(`omni_tutor_${key}`);
        if (item) {
          const entry: CacheEntry = JSON.parse(item);
          if (entry.expiresAt > now) {
            this.memoryCache.set(key, entry);
            this.hits++;
            return entry.response;
          } else {
            window.localStorage.removeItem(`omni_tutor_${key}`);
          }
        }
      } catch (e) {
        // Benign storage quota error handling
      }
    }

    this.misses++;
    return null;
  }

  async set(key: string, response: TutorResponse, ttlMs: number = this.defaultTtlMs): Promise<void> {
    const entry: CacheEntry = {
      response,
      expiresAt: Date.now() + ttlMs,
    };

    // Store in memory
    this.memoryCache.set(key, entry);

    // Store in localStorage
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        window.localStorage.setItem(`omni_tutor_${key}`, JSON.stringify(entry));
      } catch (e) {
        // Gracefully ignore local storage overflow
      }
    }
  }

  getMetrics() {
    const total = this.hits + this.misses;
    return {
      hits: this.hits,
      misses: this.misses,
      hitRate: total > 0 ? (this.hits / total) * 100 : 0,
      size: this.memoryCache.size,
    };
  }

  clear() {
    this.memoryCache.clear();
  }
}
