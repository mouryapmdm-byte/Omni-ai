export type ConfidenceRating = 1 | 2 | 3 | 4 | 5;

export interface CalibrationRecord {
  questionId: string;
  topicId: string;
  topicTitle: string;
  subject: string;
  confidenceRating: ConfidenceRating;
  isCorrect: boolean;
  timeSpent: number; // seconds
  timestamp: string; // ISO string
}

export interface CalibrationSummary {
  topicId: string;
  topicTitle: string;
  subject: string;
  totalAnswers: number;
  avgConfidence: number; // 0.0 - 1.0 scale
  rawAvgConfidence: number; // 1 - 5 scale
  accuracy: number; // 0.0 - 1.0 scale
  calibrationScore: number; // 0.0 - 1.0 scale (1.0 = perfect match)
  masteredCount: number;
  dangerousCount: number;
  underconfidentCount: number;
  learningCount: number;
}

export type QuadrantType = 'mastered' | 'dangerous' | 'underconfident' | 'learning';

export interface QuadrantPoint {
  id: string;
  questionId: string;
  topicId: string;
  topicTitle: string;
  confidenceNormalized: number; // 0.0 - 1.0
  rawConfidence: number; // 1 - 5
  isCorrect: boolean;
  quadrant: QuadrantType;
  timestamp: string;
}
