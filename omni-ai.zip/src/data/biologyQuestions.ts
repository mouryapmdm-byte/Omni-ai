export const BIOLOGY_QUESTIONS = [
  // Section A: 1-Mark MCQs
  {
    id: 'bio-q1',
    chapterId: 'sexual_reproduction_plants',
    chapterTitle: '1. Sexual Reproduction in Flowering Plants',
    section: 'A',
    marks: 1,
    questionText: 'Which chemical substance forms the tough outer layer (exine) of pollen grains, making them highly resistant to enzymatic degradation?',
    options: ['Pectocellulose', 'Sporopollenin', 'Lignin', 'Suberin'],
    correctAnswer: 'Sporopollenin',
    solution: 'Sporopollenin is one of the most resistant organic materials known. It can withstand high temperatures and strong acids and alkali, making the exine durable.',
    subtopicRef: 'Microsporogenesis & Stamen Architecture'
  },
  {
    id: 'bio-q2',
    chapterId: 'human_reproduction',
    chapterTitle: '2. Human Reproduction',
    section: 'A',
    marks: 1,
    questionText: 'Secretions from which endocrine cells in the human male testis stimulate spermatogenesis under the influence of LH (ICSH)?',
    options: ['Sertoli cells', 'Leydig (Interstitial) cells', 'Spermatogonia', 'Cowper\'s glands'],
    correctAnswer: 'Leydig (Interstitial) cells',
    solution: 'Luteinizing Hormone (LH) acts on the Leydig cells to stimulate the synthesis and secretion of androgens (testosterone), which in turn stimulate spermatogenesis.',
    subtopicRef: 'Hormonal Cascade & Menstrual Cycle Phases'
  },
  {
    id: 'bio-q3',
    chapterId: 'reproductive_health',
    chapterTitle: '3. Reproductive Health',
    section: 'A',
    marks: 1,
    questionText: 'Which non-steroidal oral contraceptive pill was developed by scientists at the Central Drug Research Institute (CDRI) in Lucknow, India?',
    options: ['Mala-D', 'Saheli (Centchroman)', 'LNG-20', 'Norplant'],
    correctAnswer: 'Saheli (Centchroman)',
    solution: 'Saheli is a once-a-week non-steroidal oral contraceptive with high contraceptive value and very few side effects, engineered by CDRI Lucknow.',
    subtopicRef: 'Medical Contraceptives & Sterilization Techniques'
  },
  {
    id: 'bio-q4',
    chapterId: 'principles_inheritance',
    chapterTitle: '4. Principles of Inheritance and Variation',
    section: 'A',
    marks: 1,
    questionText: 'In Sickle-cell anemia, the substitution of Glutamic acid by Valine at the 6th position of the beta-globin chain is caused by a single base substitution from:',
    options: ['GAG to GUG', 'GUG to GAG', 'AAG to UAG', 'CTC to CAC'],
    correctAnswer: 'GAG to GUG',
    solution: 'Sickle-cell anemia is a point mutation caused by the substitution of Glutamic acid (encoded by GAG) by Valine (encoded by GUG) at the sixth position of the beta-globin chain.',
    subtopicRef: 'Mendelian disorders: Sickle-cell anemia'
  },
  {
    id: 'bio-q5',
    chapterId: 'molecular_basis_inheritance',
    chapterTitle: '5. Molecular Basis of Inheritance',
    section: 'A',
    marks: 1,
    questionText: 'If a double-stranded DNA sample contains 20% Cytosine, what percentage of Adenine will be present according to Chargaff\'s rules?',
    options: ['20%', '30%', '40%', '60%'],
    correctAnswer: '30%',
    solution: 'According to Chargaff\'s rule: %G = %C = 20%. So %G + %C = 40%. The remaining 60% is shared equally between A and T (%A = %T = 30%).',
    subtopicRef: 'Nucleic Acid Architecture & Chromatin Packaging'
  },
  {
    id: 'bio-q6',
    chapterId: 'evolution',
    chapterTitle: '6. Evolution',
    section: 'A',
    marks: 1,
    questionText: 'Thorns of Bougainvillea and tendrils of Cucurbita represent which anatomical evolutionary evidence?',
    options: ['Analogous organs showing convergent evolution', 'Homologous organs showing divergent evolution', 'Vestigial organs showing atavism', 'Atavistic structures showing adaptive radiation'],
    correctAnswer: 'Homologous organs showing divergent evolution',
    solution: 'Both thorns of Bougainvillea and tendrils of Cucurbita arise from the axillary position (same origin), but perform different functions (defense vs climbing), demonstrating homology and divergent evolution.',
    subtopicRef: 'Morphological, Anatomical & Adaptive Radiation Evidences'
  },
  {
    id: 'bio-q7',
    chapterId: 'human_health_disease',
    chapterTitle: '7. Human Health and Disease',
    section: 'A',
    marks: 1,
    questionText: 'Which class of immunoglobulins is predominantly present in human colostrum to provide natural passive immunity to the newborn infant?',
    options: ['IgG', 'IgA', 'IgM', 'IgE'],
    correctAnswer: 'IgA',
    solution: 'Colostrum secreted by the mother during initial days of lactation contains abundant IgA antibodies to protect the infant against pathogens.',
    subtopicRef: 'Innate & Acquired Immunology, Antibody Structure'
  },
  {
    id: 'bio-q8',
    chapterId: 'microbes_human_welfare',
    chapterTitle: '8. Microbes in Human Welfare',
    section: 'A',
    marks: 1,
    questionText: 'Statins, used clinically as blood-cholesterol lowering agents, are competitively produced by which micro-fungus?',
    options: ['Trichoderma polysporum', 'Monascus purpureus', 'Penicillium notatum', 'Aspergillus niger'],
    correctAnswer: 'Monascus purpureus',
    solution: 'Statins produced by the yeast Monascus purpureus act as competitive inhibitors for the enzyme responsible for cholesterol synthesis.',
    subtopicRef: 'Bioactive Metabolites & Sewage Treatment Bio-Process'
  },
  {
    id: 'bio-q9',
    chapterId: 'biotechnology_principles',
    chapterTitle: '9. Biotechnology: Principles and Processes',
    section: 'A',
    marks: 1,
    questionText: 'The restriction endonuclease EcoRI cleaves DNA at the palindromic sequence 5\'-GAATTC-3\' between which two adjacent nucleotides?',
    options: ['G and A', 'A and A', 'A and T', 'T and C'],
    correctAnswer: 'G and A',
    solution: 'EcoRI recognizes the 5\'-GAATTC-3\' palindrome and cuts the sugar-phosphate backbone specifically between G and A on both opposite strands.',
    subtopicRef: 'Restriction Enzymes, Palindromes & Gel Electrophoresis'
  },
  {
    id: 'bio-q10',
    chapterId: 'biotechnology_applications',
    chapterTitle: '10. Biotechnology and its Applications',
    section: 'A',
    marks: 1,
    questionText: 'In RNA interference (RNAi), gene silencing of specific mRNA in plants is triggered by which double-stranded nucleic acid molecule?',
    options: ['dsDNA', 'dsRNA', 'ssDNA', 'hnRNA'],
    correctAnswer: 'dsRNA',
    solution: 'RNA interference takes place in all eukaryotic organisms as a method of cellular defense. It involves silencing of specific mRNA due to a complementary dsRNA molecule.',
    subtopicRef: 'Agricultural Biotechnology: Bt Cotton & RNAi'
  },

  // Section B: 2-Marks Short Answer Questions
  {
    id: 'bio-q11',
    chapterId: 'sexual_reproduction_plants',
    chapterTitle: '1. Sexual Reproduction in Flowering Plants',
    section: 'B',
    marks: 2,
    questionText: 'Differentiate between Apomixis and Parthenocarpy, providing one commercial plant example for each.',
    options: [
      'Apomixis: seedless fruit development (Banana); Parthenocarpy: asexual seed formation (Citrus)',
      'Apomixis: asexual seed formation mimicking sexual reproduction (Asteraceae/Grasses); Parthenocarpy: fruit formation without fertilization (Banana)',
      'Apomixis: double fertilization in ovules (Maize); Parthenocarpy: triple fusion in endosperm (Coconut)',
      'Apomixis: microspore tetrad division (Wheat); Parthenocarpy: megaspore degenerated sac (Mango)'
    ],
    correctAnswer: 'Apomixis: asexual seed formation mimicking sexual reproduction (Asteraceae/Grasses); Parthenocarpy: fruit formation without fertilization (Banana)',
    solution: 'Apomixis is a form of asexual reproduction that mimics sexual reproduction by producing seeds without fertilization. Parthenocarpy is the development of fruit without fertilization, yielding seedless fruits like banana.',
    subtopicRef: 'Seed Development, Fruit Formation & Apomixis'
  },
  {
    id: 'bio-q12',
    chapterId: 'principles_inheritance',
    chapterTitle: '4. Principles of Inheritance and Variation',
    section: 'B',
    marks: 2,
    questionText: 'A test cross is performed to determine the unknown genotype of a dominant phenotype plant. What genotypic ratio is expected when crossing a heterozygous tall plant (Tt) with a dwarf plant (tt)?',
    options: ['3 : 1', '1 : 1', '9 : 3 : 3 : 1', '1 : 2 : 1'],
    correctAnswer: '1 : 1',
    solution: 'Crossing Tt × tt yields 50% Tt (Tall) and 50% tt (Dwarf), establishing a classic 1 : 1 test cross ratio.',
    subtopicRef: 'Mendelian Genetics & Monohybrid/Dihybrid Ratios'
  },
  {
    id: 'bio-q13',
    chapterId: 'human_health_disease',
    chapterTitle: '7. Human Health and Disease',
    section: 'B',
    marks: 2,
    questionText: 'Compare Active Immunity and Passive Immunity based on onset of protection and memory cell formation.',
    options: [
      'Active: slow onset with memory cells; Passive: immediate protection without memory cells',
      'Active: immediate protection without memory; Passive: slow onset with memory cells',
      'Active: transient 24-hour protection; Passive: lifelong permanent genome alteration',
      'Active: induced only by antitoxins; Passive: induced by live attenuated pathogens'
    ],
    correctAnswer: 'Active: slow onset with memory cells; Passive: immediate protection without memory cells',
    solution: 'Active immunity develops when a host produces antibodies in response to antigen exposure, taking time but generating long-lasting immunological memory. Passive immunity involves direct antibody transfer for immediate relief without memory generation.',
    subtopicRef: 'Innate & Acquired Immunology, Antibody Structure'
  },

  // Section C: 3-Marks Short Answer Questions
  {
    id: 'bio-q14',
    chapterId: 'human_reproduction',
    chapterTitle: '2. Human Reproduction',
    section: 'C',
    marks: 3,
    questionText: 'Explain the physiological rationale behind the LH surge during day 14 of the human 28-day menstrual cycle and its direct follicular outcome.',
    options: [
      'LH surge induces rapid endometrial sloughing and menses initiation',
      'Rapid secretion of LH induces rupture of the mature Graafian follicle and release of the secondary oocyte (ovulation)',
      'LH surge converts primary spermatocytes into mature polar bodies inside the uterine lining',
      'LH surge inhibits progesterone secretion from the corpus luteum causing immediate menopause'
    ],
    correctAnswer: 'Rapid secretion of LH induces rupture of the mature Graafian follicle and release of the secondary oocyte (ovulation)',
    solution: 'Maximum level of LH (LH surge) during the mid-cycle (around 14th day) induces rupture of the mature Graafian follicle and thereby the release of an ovum (ovulation).',
    subtopicRef: 'Hormonal Cascade & Menstrual Cycle Phases'
  },
  {
    id: 'bio-q15',
    chapterId: 'molecular_basis_inheritance',
    chapterTitle: '5. Molecular Basis of Inheritance',
    section: 'C',
    marks: 3,
    questionText: 'In the Lac Operon model of E. coli, what happens when allolactose binds to the repressor protein produced by the i-gene?',
    options: [
      'The repressor binds tightly to the operator, shutting down transcription of z, y, a structural genes',
      'The repressor undergoes a conformational change, inactivating it so RNA polymerase transcribes z, y, a structural genes',
      'The repressor degrades promoter site (p) directly preventing binding of beta-galactosidase',
      'The repressor converts lactose into glucose without requiring transcription'
    ],
    correctAnswer: 'The repressor undergoes a conformational change, inactivating it so RNA polymerase transcribes z, y, a structural genes',
    solution: 'Allolactose acts as an inducer. It binds to the repressor protein, inactivating it. This allows RNA polymerase access to the promoter and operator, transcribing z, y, and a genes.',
    subtopicRef: 'Translation, Lac Operon Regulation & DNA Fingerprinting'
  },
  {
    id: 'bio-q16',
    chapterId: 'biotechnology_applications',
    chapterTitle: '10. Biotechnology and its Applications',
    section: 'C',
    marks: 3,
    questionText: 'How did Eli Lilly company overcome the challenge of assembling functional human insulin (Humulin) using recombinant E. coli?',
    options: [
      'They synthesized chain A and chain B DNA sequences separately, expressed them in E. coli, and joined them via disulfide bonds',
      'They expressed complete pro-insulin containing C-peptide in E. coli and cleaved C-peptide using synthetic restriction enzymes',
      'They cloned human pancreatic islet cells directly into yeast vectors without recombinant DNA',
      'They used RNA interference to silence C-peptide gene expression prior to transcription'
    ],
    correctAnswer: 'They synthesized chain A and chain B DNA sequences separately, expressed them in E. coli, and joined them via disulfide bonds',
    solution: 'In 1983, Eli Lilly prepared two DNA sequences corresponding to A and B chains of human insulin and introduced them in E. coli to produce chains A and B separately. Chains A and B were extracted and combined by creating disulfide bonds.',
    subtopicRef: 'Medical Biotechnology: Humulin & ADA Gene Therapy'
  },

  // Section D: 4-Marks Case Study Questions
  {
    id: 'bio-q17',
    chapterId: 'biotechnology_applications',
    chapterTitle: '10. Biotechnology and its Applications',
    section: 'D',
    marks: 4,
    questionText: 'Case Study: Bacillus thuringiensis produces crystal proteins (Cry proteins) during sporulation. Cry1Ac and Cry2Ab control cotton bollworm, while Cry1Ab controls corn borer. Why does the Bt protoxin kill the insect pest but not Bacillus thuringiensis itself?',
    options: [
      'Bt protoxin is inactive in the bacterium; inside the insect midgut, alkaline pH solubilizes the crystal and midgut proteases cleave it into active toxin',
      'Bt protoxin is active in the bacterium, but bacterial cell walls are coated with chitin making them immune to pore formation',
      'Bt toxin requires mammalian body temperature (37°C) to undergo hyper-mutation',
      'Insect hemolymph secretes acidic gastric juices that digest the bacterial plasmid vector'
    ],
    correctAnswer: 'Bt protoxin is inactive in the bacterium; inside the insect midgut, alkaline pH solubilizes the crystal and midgut proteases cleave it into active toxin',
    solution: 'The Bt toxin exists as an inactive protoxin in the bacterium. Once an insect ingests the protoxin, it is converted into an active form due to the alkaline pH of the gut, which solubilizes the crystals. The activated toxin binds to midgut epithelial cells, creating pores that cause cell swelling and lysis.',
    subtopicRef: 'Agricultural Biotechnology: Bt Cotton & RNAi'
  },

  // Section E: 5-Marks Long Answer Questions
  {
    id: 'bio-q18',
    chapterId: 'sexual_reproduction_plants',
    chapterTitle: '1. Sexual Reproduction in Flowering Plants',
    section: 'E',
    marks: 5,
    questionText: 'Trace the developmental steps of megasporogenesis and female gametophyte development leading to a 7-celled, 8-nucleate Polygonum-type embryo sac in angiosperms.',
    options: [
      'MMC undergoes 1 mitotic division -> 2 megaspores -> 4 mitotic nuclear divisions -> 8-celled embryo sac',
      'MMC (2n) undergoes meiosis -> 4 haploid megaspores -> 3 degenerate -> 1 functional megaspore undergoes 3 sequential free-nuclear mitotic divisions -> 8 nuclei distributed as 3 antipodals, 2 polar nuclei in central cell, and 2 synergids + 1 egg cell in egg apparatus',
      'MMC (2n) fuses with microspore mother cell -> double meiosis -> 16-nucleate embryo sac',
      'Functional megaspore undergoes 2 meiotic divisions yielding 4 synergids and 4 antipodals without an egg cell'
    ],
    correctAnswer: 'MMC (2n) undergoes meiosis -> 4 haploid megaspores -> 3 degenerate -> 1 functional megaspore undergoes 3 sequential free-nuclear mitotic divisions -> 8 nuclei distributed as 3 antipodals, 2 polar nuclei in central cell, and 2 synergids + 1 egg cell in egg apparatus',
    solution: 'The Megaspore Mother Cell (2n) undergoes meiosis to produce 4 megaspores. Three degenerate, leaving one functional megaspore (monosporic development). It undergoes three sequential free-nuclear mitotic divisions to produce 8 nuclei. Wall formation organizes them into a 7-celled, 8-nucleate embryo sac (3 antipodals at chalazal end, 1 large central cell with 2 polar nuclei, and egg apparatus at micropylar end with 2 synergids and 1 egg cell).',
    subtopicRef: 'Megasporogenesis & Female Gametophyte Architecture'
  },
  {
    id: 'bio-q19',
    chapterId: 'organisms_populations',
    chapterTitle: '11. Organisms and Populations',
    section: 'E',
    marks: 5,
    questionText: 'Evaluate the logistic population growth equation dN/dt = rN[(K-N)/K]. What happens to population growth when N equals Carrying Capacity (K)?',
    options: [
      'Growth rate reaches infinity (dN/dt -> ∞)',
      'Growth rate becomes zero (dN/dt = 0), yielding a stable asymptote population curve',
      'Intrinsic rate of increase r becomes negative causing exponential collapse',
      'Carrying capacity K doubles to accommodate expanding population density'
    ],
    correctAnswer: 'Growth rate becomes zero (dN/dt = 0), yielding a stable asymptote population curve',
    solution: 'When N = K, the factor (K-N)/K equals (K-K)/K = 0. Therefore, dN/dt = rN(0) = 0. The population growth rate becomes zero, forming a sigmoid curve reaching an asymptote at carrying capacity K.',
    subtopicRef: 'Population Metrics & Growth Kinetics Equations'
  }
];
