const fs = require('fs');
const file = 'src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

const importStatement = `import { AlgebraicPropertiesModal } from './components/AlgebraicPropertiesModal';\n`;
if (!content.includes('AlgebraicPropertiesModal')) {
    content = content.replace("import { CollaborativeRooms } from './components/CollaborativeRooms';", importStatement + "import { CollaborativeRooms } from './components/CollaborativeRooms';");
    
    const caseStatement = `
      case 'algebraic_properties':
        setModal({
          title: 'Algebraic Properties Quick Reference',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <AlgebraicPropertiesModal theme={theme} onClose={() => setModal(null)} />
            </div>
          ),
          size: 'large'
        });
        break;
`;
    content = content.replace("case 'dashboard':", caseStatement + "      case 'dashboard':");
    fs.writeFileSync(file, content);
    console.log("Patched App.tsx successfully");
} else {
    console.log("Already patched");
}
