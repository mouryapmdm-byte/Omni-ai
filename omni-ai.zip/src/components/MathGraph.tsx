import React, { useMemo, useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Legend
} from 'recharts';
import { cn } from '../lib/utils';

interface MathGraphProps {
  functions: string[];
  domain?: [number, number];
  theme?: 'dark' | 'light';
}

const COLORS = ['#6366f1', '#f43f5e', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4'];

export const detectMathFunctions = (text: string): string[] => {
  if (!text) return [];
  const found: string[] = [];

  const cleanText = text
    .replace(/\\\(/g, '')
    .replace(/\\\)/g, '')
    .replace(/\\\[/g, '')
    .replace(/\\\]/g, '')
    .replace(/\$/g, '');

  // 1. Detect standard equations: f(x) = x^2, g(x) = 2*x, y = x^2 - 4
  const eqRegex = /(?:[fghyFGH](?:_\d+)?(?:\(x\))?|y)\s*=\s*([0-9xX+\-*/^().\s\w\\]+?)(?=(?:[,;.]|\s+(?:and|where|for|with|or|<|\$)|$|\n))/gi;
  let match;
  while ((match = eqRegex.exec(cleanText)) !== null) {
    let expr = match[1].trim();
    expr = expr.replace(/\\left|\\right|\\cdot/g, '').replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '($1)/($2)');
    
    // Strip common physical units so they don't break function parsing
    const exprNoUnits = expr.replace(/\b(?:cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW|m|s|deg|rad)\b/gi, '').trim();

    if (
      exprNoUnits &&
      exprNoUnits.length >= 1 &&
      exprNoUnits.length < 60 &&
      /[xX]/.test(exprNoUnits) && // Require x or X so parameter constants like f_o = 90 cm aren't treated as 2D function plots
      !/[a-zA-Z]{4,}/.test(exprNoUnits.replace(/(?:sin|cos|tan|exp|log|sqrt|pi|text)/gi, ''))
    ) {
      found.push(exprNoUnits);
    }
  }

  // 2. Detect phrases like "graph of f(x)=x^2 and g(x)=2x" or "graph x^2 and 2x"
  if (/(?:graph|plot|function|curve|coordinate plane)/i.test(cleanText)) {
    const inlineRegex = /(?:(?:graph|plot|and|or|,)\s+)(?:(?:[fghy](?:\(x\))?\s*=\s*)?)([xX0-9][xX0-9+\-*/^().\s]{1,40})(?=[,;.]|\s+(?:and|on|with|in|for|$)|\n)/gi;
    let inlineMatch;
    while ((inlineMatch = inlineRegex.exec(cleanText)) !== null) {
      const expr = inlineMatch[1].trim();
      const exprNoUnits = expr.replace(/\b(?:cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW|m|s|deg|rad)\b/gi, '').trim();
      if (
        exprNoUnits &&
        exprNoUnits.length > 1 &&
        /[xX]/.test(exprNoUnits) &&
        !/[a-zA-Z]{3,}/.test(exprNoUnits.replace(/(?:sin|cos|tan|exp|log|sqrt|pi|text)/gi, ''))
      ) {
        found.push(exprNoUnits);
      }
    }
  }

  return Array.from(new Set(found.map(f => f.trim()))).filter(Boolean);
};

export const MathGraph: React.FC<MathGraphProps> = ({
  functions,
  domain = [-10, 10],
  theme = 'dark'
}) => {
  const [hoveredCoordinate, setHoveredCoordinate] = useState<{ x: number; y: number; name: string } | null>(null);
  const [gridType, setGridType] = useState<'major' | 'minor' | 'none'>('major');

  const data = useMemo(() => {
    try {
      const parsedFuncs: { original: string; evaluator: (x: number) => number }[] = [];

      for (const funcStr of functions) {
        try {
          let cleanStr = funcStr
            .replace(/^(?:[a-zA-Z](?:\([a-zA-Z]\))?)\s*=\s*/i, '')
            .replace(/\\text\{[^}]*\}/g, '')
            .replace(/\\(text|mathrm|textbf|mathit|mathsf|mathtt|mbox)\b/g, '')
            .replace(/\b(?:cm|mm|nm|km|kg|mg|sec|ms|Hz|kHz|MHz|GHz|mA|kW|MW|m|s|deg|rad)\b/gi, '')
            .trim();

          if (!cleanStr) continue;

          let jsFunc = cleanStr
            .replace(/\^/g, '**')
            .replace(/\bsin\b/gi, 'Math.sin')
            .replace(/\bcos\b/gi, 'Math.cos')
            .replace(/\btan\b/gi, 'Math.tan')
            .replace(/\bexp\b/gi, 'Math.exp')
            .replace(/\blog\b/gi, 'Math.log')
            .replace(/\bsqrt\b/gi, 'Math.sqrt')
            .replace(/\bpi\b/gi, 'Math.PI')
            .replace(/\be\b/gi, 'Math.E');

          // Handle implicit multiplication like 2x -> 2*x, 3(x) -> 3*(x)
          jsFunc = jsFunc.replace(/(\d)([a-zA-Z(])/g, '$1*$2');

          const evaluator = new Function('x', `
            try {
              return ${jsFunc};
            } catch (err) {
              return NaN;
            }
          `) as (x: number) => number;

          // Validate output at test points
          const test1 = evaluator(1);
          const test0 = evaluator(0);
          if ((typeof test1 === 'number' && !isNaN(test1)) || (typeof test0 === 'number' && !isNaN(test0))) {
            parsedFuncs.push({ original: funcStr, evaluator });
          }
        } catch (e) {
          // Ignore invalid function syntax
        }
      }

      if (parsedFuncs.length === 0) return [];

      const points = [];
      const step = (domain[1] - domain[0]) / 100;
      for (let x = domain[0]; x <= domain[1]; x += step) {
        const point: any = { x: Number(x.toFixed(2)) };
        parsedFuncs.forEach((item, i) => {
          try {
            const y = item.evaluator(x);
            if (Number.isFinite(y) && Math.abs(y) < 1e6) {
              point[`f${i}(x)`] = Number(y.toFixed(4));
            }
          } catch (e) {
            // Ignore evaluation errors
          }
        });
        points.push(point);
      }
      return points;
    } catch (e) {
      return [];
    }
  }, [functions, domain]);

  const textColor = theme === 'dark' ? '#94a3b8' : '#64748b';
  const gridColor = theme === 'dark' ? '#334155' : '#e2e8f0';

  if (data.length === 0) return null;

  return (
    <div className="w-full p-4 rounded-2xl border bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 my-4 shadow-md animate-in fade-in zoom-in-95 duration-500">
      <div className="flex items-center justify-between mb-3 px-1 flex-wrap gap-2">
        <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200 flex items-center gap-2">
          <span>📈 Interactive Coordinate Plane</span>
          <span className="text-xs font-normal text-slate-500 dark:text-slate-400">
            ({functions.length} {functions.length === 1 ? 'function' : 'functions'})
          </span>
        </h3>

        <div className="flex items-center gap-3">
          {/* Grid Style Toggle */}
          <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 p-0.5 text-xs">
            <button
              onClick={() => setGridType('major')}
              className={cn(
                "px-2.5 py-1 rounded-md font-medium transition-all",
                gridType === 'major'
                  ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              )}
            >
              Major Grid
            </button>
            <button
              onClick={() => setGridType('minor')}
              className={cn(
                "px-2.5 py-1 rounded-md font-medium transition-all",
                gridType === 'minor'
                  ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              )}
            >
              Minor Grid
            </button>
            <button
              onClick={() => setGridType('none')}
              className={cn(
                "px-2.5 py-1 rounded-md font-medium transition-all",
                gridType === 'none'
                  ? "bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              )}
            >
              No Grid
            </button>
          </div>

          {hoveredCoordinate && (
            <div className="text-xs font-mono px-3 py-1.5 rounded-lg bg-indigo-500/10 dark:bg-indigo-500/20 border border-indigo-500/30 text-indigo-700 dark:text-indigo-300 shadow-sm transition-all flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
              <span>
                Hover Point: <strong className="font-semibold">{hoveredCoordinate.name}</strong> = ({hoveredCoordinate.x}, {hoveredCoordinate.y})
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="h-72 w-full relative">
        <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
          <LineChart 
            data={data} 
            margin={{ top: 15, right: 30, bottom: 25, left: 15 }}
            onMouseMove={(state: any) => {
              if (state && state.activePayload && state.activePayload.length > 0) {
                const payload = state.activePayload[0];
                setHoveredCoordinate({
                  x: payload.payload.x,
                  y: payload.value,
                  name: payload.name
                });
              }
            }}
            onMouseLeave={() => setHoveredCoordinate(null)}
          >
            {gridType !== 'none' && (
              <CartesianGrid 
                strokeDasharray={gridType === 'minor' ? '2 2' : '3 3'} 
                stroke={gridColor} 
                strokeOpacity={gridType === 'minor' ? 0.4 : 0.7} 
              />
            )}
            <XAxis 
              dataKey="x" 
              stroke={textColor} 
              type="number" 
              domain={['dataMin', 'dataMax']} 
              tickCount={gridType === 'minor' ? 21 : 11}
              label={{ value: 'X-Axis (Domain)', position: 'insideBottom', offset: -15, fill: textColor, fontSize: 12 }}
            />
            <YAxis 
              stroke={textColor} 
              domain={['auto', 'auto']}
              tickCount={gridType === 'minor' ? 15 : 8}
              label={{ value: 'Y-Axis (Range)', angle: -90, position: 'insideLeft', offset: -5, fill: textColor, fontSize: 12 }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: theme === 'dark' ? '#1e293b' : '#fff',
                borderColor: theme === 'dark' ? '#334155' : '#e2e8f0',
                color: theme === 'dark' ? '#f8fafc' : '#0f172a',
                borderRadius: '12px',
                boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.2)',
                fontSize: '12px'
              }}
              labelFormatter={(val) => `X Coordinate: ${val}`}
              formatter={(value: any, name: any) => [`Y = ${value}`, name] as any}
            />
            <Legend 
              verticalAlign="top" 
              height={36} 
              wrapperStyle={{ paddingBottom: '8px', fontSize: '13px', fontWeight: 500 }}
            />
            <ReferenceLine y={0} stroke={textColor} strokeWidth={2} />
            <ReferenceLine x={0} stroke={textColor} strokeWidth={2} />
            
            {functions.map((func, i) => {
              const label = func.includes('=') 
                ? func 
                : `${['f', 'g', 'h', 'p', 'q', 'r'][i % 6]}(x) = ${func}`;
              return (
                <Line 
                  key={i}
                  type="monotone" 
                  dataKey={`f${i}(x)`} 
                  stroke={COLORS[i % COLORS.length]} 
                  strokeWidth={2.5} 
                  dot={false} 
                  activeDot={{ r: 6, strokeWidth: 2, stroke: '#fff' }}
                  name={label}
                  isAnimationActive={false}
                />
              );
            })}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
