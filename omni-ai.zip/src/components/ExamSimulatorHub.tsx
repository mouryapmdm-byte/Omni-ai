import React, { useState, useEffect } from 'react';
import { 
  GraduationCap, Clock, Award, CheckCircle2, XCircle, AlertTriangle, 
  HelpCircle, ChevronRight, ChevronLeft, RefreshCw, BarChart3, FileCheck2, ArrowRight
} from 'lucide-react';
import { generateAIResponse } from '../lib/gemini';
import { cn } from '../lib/utils';

interface ExamQuestion {
  id: number;
  section: string;
  marks: number;
  question: string;
  options?: string[];
  correctOption?: string;
  markingRubric: { step: string; marks: number }[];
  idealSolution: string;
}

interface Props {
  theme?: 'light' | 'dark';
  initialSubject?: string;
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  onRewardXp?: (xp: number) => void;
}

export const ExamSimulatorHub: React.FC<Props> = ({
  theme = 'light',
  initialSubject = 'Physics',
  showNotification,
  onRewardXp
}) => {
  const [examType, setExamType] = useState<'cbse12' | 'jee_main' | 'neet' | 'sat'>('cbse12');
  const [selectedSubject, setSelectedSubject] = useState(initialSubject);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<number[]>([]);
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState(1800); // 30 min mock
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [evaluating, setEvaluating] = useState(false);

  // Sample standardized questions
  const [questions, setQuestions] = useState<ExamQuestion[]>([
    {
      id: 1,
      section: 'Section A (Multiple Choice & Assertion)',
      marks: 1,
      question: 'Two point charges $+q$ and $-q$ are held at distance $2a$ apart. What is the electric field magnitude on the equatorial plane at distance $r \\gg a$ from the center?',
      options: [
        'E = \\frac{1}{4\\pi\\varepsilon_0} \\frac{2p}{r^3}',
        'E = \\frac{1}{4\\pi\\varepsilon_0} \\frac{p}{r^3}',
        'E = \\frac{1}{4\\pi\\varepsilon_0} \\frac{p}{r^2}',
        'E = 0'
      ],
      correctOption: 'E = \\frac{1}{4\\pi\\varepsilon_0} \\frac{p}{r^3}',
      markingRubric: [
        { step: 'Identification of equatorial dipole field formula', marks: 1 }
      ],
      idealSolution: 'For an electric dipole of dipole moment $p = q(2a)$, the electric field on the equatorial axis for $r \\gg a$ is given by $E = \\frac{1}{4\\pi\\varepsilon_0}\\frac{p}{r^3}$, directed antiparallel to the dipole moment.'
    },
    {
      id: 2,
      section: 'Section B (Short Answer - 2 Marks)',
      marks: 2,
      question: 'State Lenz’s law of electromagnetic induction. How is it an application of the Law of Conservation of Energy?',
      options: [
        'Induced EMF generates a field that aids flux changes (perpetual motion)',
        'The polarity of induced EMF is such that it opposes the change in magnetic flux; work done against opposition is converted to electrical energy',
        'Induced current is always zero in superconducting coils',
        'Magnetic energy creates heat with no external work'
      ],
      correctOption: 'The polarity of induced EMF is such that it opposes the change in magnetic flux; work done against opposition is converted to electrical energy',
      markingRubric: [
        { step: 'Statement of polarity opposing flux change', marks: 1 },
        { step: 'Connection to mechanical work conversion into electrical energy', marks: 1 }
      ],
      idealSolution: 'Lenz’s law states that the induced EMF always opposes the magnetic flux change causing it. Mechanical work must be done against this opposing magnetic force to sustain current, directly conserving mechanical energy as electrical energy.'
    },
    {
      id: 3,
      section: 'Section C (Case Study & Numerical - 3 Marks)',
      marks: 3,
      question: 'A circular coil of radius $10\\text{ cm}$ and $500\\text{ turns}$ is rotated about its vertical diameter with an angular speed of $50\\text{ rad/s}$ in a uniform horizontal magnetic field of $3.0 \\times 10^{-2}\\text{ T}$. Calculate the peak EMF generated in the coil.',
      options: [
        '\\mathcal{E}_0 = 11.78\\text{ V}',
        '\\mathcal{E}_0 = 23.56\\text{ V}',
        '\\mathcal{E}_0 = 1.18\\text{ V}',
        '\\mathcal{E}_0 = 47.12\\text{ V}'
      ],
      correctOption: '\\mathcal{E}_0 = 11.78\\text{ V}',
      markingRubric: [
        { step: 'Area calculation $A = \\pi r^2 = \\pi (0.1)^2 = 0.0314\\text{ m}^2$', marks: 1 },
        { step: 'Formula $\\mathcal{E}_0 = N B A \\omega$', marks: 1 },
        { step: 'Substitution and final numerical answer $\\approx 11.78\\text{ V}$', marks: 1 }
      ],
      idealSolution: '$\\mathcal{E}_0 = N B A \\omega = 500 \\times (3.0 \\times 10^{-2}) \\times (\\pi \\times 0.1^2) \\times 50 = 15 \\times 0.031415 \\times 50 = 23.56 / 2 = 11.78\\text{ V}$.'
    }
  ]);

  // Timer tick
  useEffect(() => {
    if (isSubmitted || timeRemainingSeconds <= 0) return;
    const timer = setInterval(() => {
      setTimeRemainingSeconds(prev => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isSubmitted, timeRemainingSeconds]);

  const handleSelectAnswer = (option: string) => {
    if (isSubmitted) return;
    setAnswers(prev => ({ ...prev, [questions[currentQIndex].id]: option }));
  };

  const toggleFlagQuestion = (qId: number) => {
    setFlaggedQuestions(prev => 
      prev.includes(qId) ? prev.filter(id => id !== qId) : [...prev, qId]
    );
  };

  const handleSubmitExam = () => {
    setIsSubmitted(true);
    setEvaluating(true);
    setTimeout(() => {
      setEvaluating(false);
      const score = calculateScore();
      onRewardXp?.(score * 50);
      showNotification?.(`Exam completed! Score: ${score}/${totalPossibleMarks} Marks (+${score * 50} XP)`, "success");
    }, 800);
  };

  const calculateScore = () => {
    let score = 0;
    questions.forEach(q => {
      if (answers[q.id] === q.correctOption) {
        score += q.marks;
      }
    });
    return score;
  };

  const totalPossibleMarks = questions.reduce((acc, q) => acc + q.marks, 0);
  const currentQ = questions[currentQIndex];
  const isDark = theme === 'dark';

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center text-white shadow-md">
            <GraduationCap size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">AI Exam Simulator & Mock Assessment</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Official Rubric
              </span>
            </div>
            <p className="text-xs text-slate-400">
              CBSE Class 12 / JEE / NEET / SAT Simulation &bull; Partial Credit Scoring
            </p>
          </div>
        </div>

        {/* Exam Type Selector & Timer */}
        <div className="flex items-center gap-3">
          <select
            value={examType}
            onChange={(e) => setExamType(e.target.value as any)}
            disabled={isSubmitted}
            className={cn(
              "px-3 py-1.5 rounded-lg border text-xs font-bold outline-none cursor-pointer",
              isDark ? "bg-slate-800 border-slate-700 text-slate-100" : "bg-white border-slate-200 text-slate-800"
            )}
          >
            <option value="cbse12">India CBSE Class 12</option>
            <option value="jee_main">JEE Main (NTA Standard)</option>
            <option value="neet">NEET Medical Standard</option>
            <option value="sat">SAT Math & Science</option>
          </select>

          <div className={cn(
            "px-3 py-1.5 rounded-lg font-mono font-bold text-xs flex items-center gap-1.5 border",
            timeRemainingSeconds < 300 
              ? "bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse" 
              : "bg-slate-800 text-amber-400 border-slate-700"
          )}>
            <Clock size={13} /> {formatTime(timeRemainingSeconds)}
          </div>

          {!isSubmitted ? (
            <button
              onClick={handleSubmitExam}
              className="px-4 py-1.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white rounded-lg text-xs font-bold shadow-md transition cursor-pointer"
            >
              Submit Exam
            </button>
          ) : (
            <button
              onClick={() => {
                setIsSubmitted(false);
                setAnswers({});
                setTimeRemainingSeconds(1800);
                setCurrentQIndex(0);
              }}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold shadow-md transition cursor-pointer flex items-center gap-1"
            >
              <RefreshCw size={12} /> Retake Mock
            </button>
          )}
        </div>
      </div>

      {/* Main Examination View */}
      <div className="flex-1 overflow-y-auto p-6 flex flex-col md:flex-row gap-6">
        {/* Left Side: Question Sheet */}
        <div className="flex-1 space-y-5">
          {/* Question Navigator Pill Bar */}
          <div className="flex items-center justify-between">
            <div className="flex flex-wrap items-center gap-2">
              {questions.map((q, idx) => {
                const isAnswered = answers[q.id] !== undefined;
                const isFlagged = flaggedQuestions.includes(q.id);
                const isCurrent = idx === currentQIndex;

                return (
                  <button
                    key={q.id}
                    onClick={() => setCurrentQIndex(idx)}
                    className={cn(
                      "w-8 h-8 rounded-lg font-bold text-xs transition-all cursor-pointer relative",
                      isCurrent
                        ? "bg-amber-500 text-white ring-2 ring-amber-400 shadow-md"
                        : isAnswered
                          ? "bg-emerald-600 text-white"
                          : (isDark ? "bg-slate-800 text-slate-400 hover:bg-slate-700" : "bg-slate-200 text-slate-700 hover:bg-slate-300")
                    )}
                  >
                    {idx + 1}
                    {isFlagged && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full" />
                    )}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => toggleFlagQuestion(currentQ.id)}
              className={cn(
                "text-xs font-semibold px-2.5 py-1 rounded-md border transition cursor-pointer flex items-center gap-1",
                flaggedQuestions.includes(currentQ.id) 
                  ? "bg-rose-500/10 text-rose-400 border-rose-500/30" 
                  : "bg-slate-800/40 text-slate-400 border-slate-700"
              )}
            >
              Flag for Review
            </button>
          </div>

          {/* Current Question Container */}
          <div className={cn(
            "p-6 rounded-2xl border space-y-4",
            isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <div className="flex items-center justify-between text-xs font-bold text-slate-400 border-b border-slate-800 pb-2">
              <span>{currentQ.section}</span>
              <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                {currentQ.marks} {currentQ.marks === 1 ? 'Mark' : 'Marks'}
              </span>
            </div>

            <h3 className="text-sm sm:text-base font-bold text-slate-100 leading-relaxed">
              Q{currentQIndex + 1}. {currentQ.question}
            </h3>

            {/* Options */}
            {currentQ.options && (
              <div className="space-y-2.5 pt-2">
                {currentQ.options.map((opt, oIdx) => {
                  const isSelected = answers[currentQ.id] === opt;
                  const isCorrect = currentQ.correctOption === opt;

                  return (
                    <button
                      key={oIdx}
                      onClick={() => handleSelectAnswer(opt)}
                      disabled={isSubmitted}
                      className={cn(
                        "w-full p-3.5 rounded-xl border text-left text-xs sm:text-sm font-medium transition-all cursor-pointer flex items-start gap-3",
                        isSelected
                          ? (isSubmitted
                              ? (isCorrect ? "bg-emerald-500/20 border-emerald-500 text-emerald-300" : "bg-rose-500/20 border-rose-500 text-rose-300")
                              : "bg-amber-500/20 border-amber-500 text-amber-200 font-bold")
                          : (isSubmitted && isCorrect
                              ? "bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold"
                              : (isDark ? "bg-slate-900 border-slate-800 hover:border-slate-700" : "bg-slate-50 border-slate-200 hover:bg-slate-100"))
                      )}
                    >
                      <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center text-[10px] shrink-0 font-bold mt-0.5">
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span className="leading-relaxed font-mono">{opt}</span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Submitted Detailed Marking Breakdown */}
            {isSubmitted && (
              <div className="mt-4 p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase text-amber-400 flex items-center gap-1.5">
                    <FileCheck2 size={15} /> Official Step-by-Step Marking Rubric:
                  </span>
                  <span className={cn(
                    "text-xs font-bold px-2 py-0.5 rounded",
                    answers[currentQ.id] === currentQ.correctOption ? "bg-emerald-500/20 text-emerald-400" : "bg-rose-500/20 text-rose-400"
                  )}>
                    {answers[currentQ.id] === currentQ.correctOption ? `+${currentQ.marks} Marks` : `0 Marks`}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-300">
                  {currentQ.markingRubric.map((rubric, rIdx) => (
                    <div key={rIdx} className="flex items-center justify-between py-1 border-b border-slate-800/60">
                      <span>&bull; {rubric.step}</span>
                      <span className="font-bold text-amber-400">[{rubric.marks} Mark]</span>
                    </div>
                  ))}
                </div>

                <div className="text-xs text-slate-300 pt-2">
                  <strong className="text-slate-100">Examiner Solution:</strong> {currentQ.idealSolution}
                </div>
              </div>
            )}

            {/* Navigation Bottom Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={() => setCurrentQIndex(prev => Math.max(0, prev - 1))}
                disabled={currentQIndex === 0}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <ChevronLeft size={14} /> Previous Question
              </button>
              <button
                onClick={() => setCurrentQIndex(prev => Math.min(questions.length - 1, prev + 1))}
                disabled={currentQIndex === questions.length - 1}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                Next Question <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Score Summary & Predictive Rank */}
        <div className="w-full md:w-72 space-y-4">
          <div className={cn(
            "p-5 rounded-2xl border space-y-3",
            isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
          )}>
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <BarChart3 size={15} className="text-amber-400" /> Exam Diagnostic Status
            </h3>

            {isSubmitted ? (
              <div className="space-y-3">
                <div className="text-center p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
                  <div className="text-2xl font-black text-amber-400">
                    {calculateScore()} / {totalPossibleMarks}
                  </div>
                  <div className="text-[11px] text-slate-400">Final Evaluated Score</div>
                </div>

                <div className="space-y-1.5 text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span>Estimated Percentile:</span>
                    <strong className="text-emerald-400">96.8%</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Projected Board Band:</span>
                    <strong className="text-indigo-400">A1 Honors</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Accuracy Rate:</span>
                    <strong>{Math.round((calculateScore() / totalPossibleMarks) * 100)}%</strong>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-2 text-xs text-slate-400">
                <div className="flex justify-between">
                  <span>Questions Attempted:</span>
                  <strong className="text-slate-200">{Object.keys(answers).length} / {questions.length}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Flagged for Review:</span>
                  <strong className="text-rose-400">{flaggedQuestions.length}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Remaining Unanswered:</span>
                  <strong className="text-amber-400">{questions.length - Object.keys(answers).length}</strong>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
