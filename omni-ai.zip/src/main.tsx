import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary';
import { A11yProvider } from './modules/accessibility/A11yProvider';
import { I18nProvider } from './modules/i18n/I18nProvider';
import { DeviceTierProvider } from './modules/device-tier/DeviceTierProvider';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register Service Worker for offline study material caching
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  registerSW({
    immediate: true,
    onNeedRefresh() {
      console.log('[OmniAI PWA] New study materials and offline content available.');
    },
    onOfflineReady() {
      console.log('[OmniAI PWA] App ready to work offline with cached study materials.');
    },
  });
}

// Filter benign KaTeX font metric warnings, Vite dev server HMR WebSocket connection logs, & handled video playback warnings
const originalWarn = console.warn;
console.warn = (...args: any[]) => {
  if (typeof args[0] === 'string') {
    const logStr = args[0];
    if (
      logStr.includes('No character metrics for') || 
      logStr.includes('[vite] failed to connect to websocket') ||
      logStr.includes('VideoGrid playback error') ||
      logStr.includes('VideoWithOverlay playback error') ||
      logStr.includes('playback error:')
    ) {
      return;
    }
  }
  originalWarn.apply(console, args);
};

// Catch & suppress benign Vite HMR WebSocket unhandled rejections in dev mode
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    if (
      reason && 
      (
        (typeof reason === 'string' && (reason.includes('WebSocket') || reason.includes('vite'))) ||
        (reason.message && (reason.message.includes('WebSocket closed') || reason.message.includes('vite')))
      )
    ) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary>
    <A11yProvider>
      <I18nProvider>
        <DeviceTierProvider>
          <App />
        </DeviceTierProvider>
      </I18nProvider>
    </A11yProvider>
  </ErrorBoundary>,
);

