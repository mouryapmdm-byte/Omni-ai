import React, { useState, useMemo } from 'react';
import { 
  Compass, 
  Sparkles, 
  Eye, 
  EyeOff, 
  ExternalLink 
} from 'lucide-react';
import { cn } from '../lib/utils';
import { SvgDiagramViewer } from './SvgDiagramViewer';

interface SubtopicHeadingDiagramProps {
  level: 1 | 2 | 3;
  children: React.ReactNode;
  fullContent?: string;
  theme?: 'light' | 'dark';
  onOpenWhiteboard?: (svgDataUrl: string) => void;
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  onRenderComplete?: () => void;
  embeddedSvg?: string;
  isLectureMode?: boolean;
}

// Generate contextual chalkboard vector SVG ONLY when specifically needed by the subtopic
function generateContextualSubtopicSvg(headingText: string, contentContext: string = ''): {
  svg: string;
  category: string;
} | null {
  const hText = headingText.toLowerCase().trim();
  if (!hText) return null;

  // Matrix Taxonomy & Classification
  if (
    hText.includes('matrix') || 
    hText.includes('matrices') || 
    hText.includes('आव्यूह') || 
    hText.includes('taxonomy') || 
    hText.includes('square matrix')
  ) {
    return {
      category: '📊 Taxonomy of Matrices (आव्यूह के प्रकार)',
      svg: `<svg viewBox="0 0 1000 500" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <!-- Scientific Arrow Markers -->
    <marker id="sci-arrow-indigo" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#818cf8"/>
    </marker>
    <marker id="sci-arrow-purple" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#a855f7"/>
    </marker>
    <marker id="sci-pointer-cyan" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <polygon points="0,2 8,5 0,8" fill="#38bdf8"/>
    </marker>
    <marker id="sci-pointer-amber" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
      <polygon points="0,2 8,5 0,8" fill="#f59e0b"/>
    </marker>

    <!-- Linear Gradients for Card Backgrounds -->
    <linearGradient id="sci-card-grad-blue" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#0284c7" stop-opacity="0.15"/>
    </linearGradient>
    <linearGradient id="sci-card-grad-purple" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#6366f1" stop-opacity="0.15"/>
    </linearGradient>
    <linearGradient id="sci-card-grad-emerald" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#059669" stop-opacity="0.15"/>
    </linearGradient>
    <linearGradient id="sci-card-grad-amber" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#d97706" stop-opacity="0.15"/>
    </linearGradient>

    <!-- Subtle Glow Filter -->
    <filter id="sci-glow-subtle" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#000000" flood-opacity="0.5"/>
    </filter>
  </defs>

  <!-- Chalkboard Frame & Outer Background -->
  <rect width="1000" height="500" fill="#0f172a" rx="14"/>
  <rect x="10" y="10" width="980" height="480" fill="none" stroke="#334155" stroke-width="2.5" rx="12"/>
  <rect x="14" y="14" width="972" height="472" fill="none" stroke="#1e293b" stroke-width="1.5" rx="10"/>

  <!-- Top Title Banner -->
  <g transform="translate(500, 42)">
    <text x="0" y="0" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-size="20" font-weight="800" fill="#f8fafc" text-anchor="middle" letter-spacing="0.5">
      आकार एवं संरचना के आधार पर आव्यूह के प्रकार
    </text>
    <text x="0" y="22" font-family="'JetBrains Mono', monospace" font-size="12" font-weight="600" fill="#38bdf8" text-anchor="middle">
      (Taxonomy &amp; Classification of Matrices)
    </text>
    <line x1="-300" y1="32" x2="300" y2="32" stroke="#0284c7" stroke-width="1.5" opacity="0.6"/>
  </g>

  <!-- Interactive Legend Toggle Button (Top Right) -->
  <g id="matrix-legend-btn" transform="translate(820, 26)" cursor="pointer" onclick="var leg=document.getElementById('matrix-legend-overlay');if(leg){leg.style.display=(leg.style.display==='none'||leg.style.display==='')?'block':'none';}">
    <rect width="140" height="30" rx="15" fill="#1e293b" stroke="#38bdf8" stroke-width="1.5"/>
    <circle cx="20" cy="15" r="7" fill="#0284c7" fill-opacity="0.4" stroke="#38bdf8" stroke-width="1.2"/>
    <text x="20" y="19" font-family="sans-serif" font-size="11" font-weight="bold" fill="#38bdf8" text-anchor="middle">i</text>
    <text x="78" y="19" font-family="sans-serif" font-size="11" font-weight="bold" fill="#e2e8f0" text-anchor="middle">Matrix Legend</text>
  </g>

  <!-- ==================== COLUMN 1: Row/Column & Main Diagonal (x=40, width=280) ==================== -->
  <g id="col-1-group">
    <!-- Box 1A: Row & Column Matrices -->
    <g transform="translate(40, 90)" filter="url(#sci-glow-subtle)">
      <rect width="280" height="185" fill="url(#sci-card-grad-blue)" stroke="#0284c7" stroke-width="1.5" rx="8"/>
      <text x="140" y="24" font-family="sans-serif" font-size="13" font-weight="700" fill="#38bdf8" text-anchor="middle">
        1. पंक्ति एवं स्तंभ आव्यूह
      </text>
      <line x1="15" y1="34" x2="265" y2="34" stroke="#0284c7" stroke-width="1" opacity="0.3"/>

      <!-- Row Vector Annotation & Visualization -->
      <g transform="translate(15, 46)">
        <text x="0" y="20" font-family="sans-serif" font-size="12" fill="#94a3b8" font-weight="600">
          Row Vector:
        </text>
        <g transform="translate(90, 4)">
          <path d="M 0 0 h -5 v 26 h 5" stroke="#38bdf8" stroke-width="1.8" fill="none"/>
          <text x="8" y="17" fill="#f1f5f9" font-family="monospace" font-size="12" font-weight="600">
            a₁₁   a₁₂   a₁₃
          </text>
          <path d="M 90 0 h 5 v 26 h -5" stroke="#38bdf8" stroke-width="1.8" fill="none"/>
        </g>
        <rect x="202" y="8" width="42" height="18" rx="4" fill="#0c4a6e" stroke="#0284c7" stroke-width="1"/>
        <text x="223" y="21" fill="#38bdf8" font-size="10" font-family="monospace" font-weight="bold" text-anchor="middle">
          1×3
        </text>
        <!-- Pointer line for Row Vector -->
        <path d="M 75 16 L 85 16" stroke="#38bdf8" stroke-width="1.2" marker-end="url(#sci-pointer-cyan)"/>
      </g>

      <!-- Column Vector Annotation & Visualization -->
      <g transform="translate(15, 106)">
        <text x="0" y="24" font-family="sans-serif" font-size="12" fill="#94a3b8" font-weight="600">
          Col Vector:
        </text>
        <g transform="translate(90, 0)">
          <path d="M 0 0 h -5 v 42 h 5" stroke="#38bdf8" stroke-width="1.8" fill="none"/>
          <text x="10" y="17" fill="#f1f5f9" font-family="monospace" font-size="12" font-weight="600">
            b₁₁
          </text>
          <text x="10" y="35" fill="#f1f5f9" font-family="monospace" font-size="12" font-weight="600">
            b₂₁
          </text>
          <path d="M 38 0 h 5 v 42 h -5" stroke="#38bdf8" stroke-width="1.8" fill="none"/>
        </g>
        <rect x="202" y="12" width="42" height="18" rx="4" fill="#0c4a6e" stroke="#0284c7" stroke-width="1"/>
        <text x="223" y="25" fill="#38bdf8" font-size="10" font-family="monospace" font-weight="bold" text-anchor="middle">
          2×1
        </text>
        <!-- Pointer line for Column Vector -->
        <path d="M 72 20 L 85 20" stroke="#38bdf8" stroke-width="1.2" marker-end="url(#sci-pointer-cyan)"/>
      </g>
    </g>

    <!-- Box 1B: Main Diagonal & Trace (Gap of 15px vertically) -->
    <g transform="translate(40, 290)" filter="url(#sci-glow-subtle)">
      <rect width="280" height="185" fill="url(#sci-card-grad-amber)" stroke="#d97706" stroke-width="1.5" stroke-dasharray="5 3" rx="8"/>
      <text x="140" y="24" font-family="sans-serif" font-size="13" font-weight="700" fill="#fbbf24" text-anchor="middle">
        मुख्य विकर्ण (Main Diagonal)
      </text>
      <line x1="15" y1="34" x2="265" y2="34" stroke="#d97706" stroke-width="1" opacity="0.3"/>

      <text x="15" y="55" font-family="sans-serif" font-size="11" fill="#cbd5e1">
        • केवल वर्ग आव्यूह में (In Square Matrix)
      </text>
      <text x="15" y="75" font-family="sans-serif" font-size="11" fill="#cbd5e1">
        • अवयव: <tspan fill="#f59e0b" font-weight="bold" font-family="monospace">a₁₁, a₂₂, a₃₃ ...</tspan>
      </text>

      <!-- Trace Badge -->
      <g transform="translate(15, 95)">
        <rect width="250" height="65" rx="6" fill="#1e1b4b" fill-opacity="0.85" stroke="#f59e0b" stroke-width="1.2"/>
        <text x="125" y="22" font-family="sans-serif" font-size="11" font-weight="bold" fill="#fbbf24" text-anchor="middle">
          अनुरेख (Trace of Matrix):
        </text>
        <text x="125" y="46" font-family="monospace" font-size="12" font-weight="bold" fill="#f1f5f9" text-anchor="middle">
          Trace(A) = Σ aᵢᵢ = a₁₁ + a₂₂ + ...
        </text>
      </g>
    </g>
  </g>

  <!-- ==================== COLUMN 2: Square Matrix Hierarchy (x=360, width=280) [40px GAP] ==================== -->
  <g id="col-2-group" transform="translate(360, 90)" filter="url(#sci-glow-subtle)">
    <rect width="280" height="385" fill="url(#sci-card-grad-purple)" stroke="#6366f1" stroke-width="1.5" rx="8"/>
    <text x="140" y="24" font-family="sans-serif" font-size="13" font-weight="700" fill="#818cf8" text-anchor="middle">
      2. वर्ग आव्यूह एवं उप-प्रकार
    </text>
    <line x1="15" y1="34" x2="265" y2="34" stroke="#6366f1" stroke-width="1" opacity="0.3"/>

    <!-- Step 1: Square Matrix -->
    <g transform="translate(15, 45)">
      <rect width="250" height="75" rx="6" fill="#1e1b4b" fill-opacity="0.9" stroke="#6366f1" stroke-width="1.2"/>
      <text x="125" y="20" font-family="sans-serif" font-size="12" font-weight="700" fill="#c7d2fe" text-anchor="middle">
        वर्ग आव्यूह (Square Matrix: m = n)
      </text>
      
      <!-- Matrix Representation -->
      <g transform="translate(80, 28)">
        <path d="M 0 0 h -5 v 34 h 5" stroke="#818cf8" stroke-width="1.8" fill="none"/>
        <text x="6" y="15" fill="#f1f5f9" font-family="monospace" font-size="11">a₁₁   a₁₂</text>
        <text x="6" y="30" fill="#f1f5f9" font-family="monospace" font-size="11">a₂₁   a₂₂</text>
        <path d="M 58 0 h 5 v 34 h -5" stroke="#818cf8" stroke-width="1.8" fill="none"/>
      </g>
      <!-- Order Badge -->
      <rect x="190" y="34" width="42" height="18" rx="4" fill="#312e81" stroke="#818cf8" stroke-width="1"/>
      <text x="211" y="47" fill="#c7d2fe" font-size="10" font-family="monospace" font-weight="bold" text-anchor="middle">
        2×2
      </text>
    </g>

    <!-- Down Arrow 1 -->
    <path d="M 140 120 L 140 144" stroke="#818cf8" stroke-width="2" marker-end="url(#sci-arrow-indigo)"/>
    <rect x="75" y="125" width="130" height="16" rx="8" fill="#0f172a" stroke="#818cf8" stroke-width="1"/>
    <text x="140" y="137" fill="#c7d2fe" font-size="9" font-family="monospace" font-weight="bold" text-anchor="middle">
      aᵢⱼ = 0  (i ≠ j)
    </text>

    <!-- Step 2: Diagonal Matrix -->
    <g transform="translate(15, 148)">
      <rect width="250" height="75" rx="6" fill="#2e1065" fill-opacity="0.9" stroke="#a855f7" stroke-width="1.2"/>
      <text x="125" y="20" font-family="sans-serif" font-size="12" font-weight="700" fill="#e9d5ff" text-anchor="middle">
        विकर्ण आव्यूह (Diagonal Matrix)
      </text>
      
      <!-- Matrix Representation -->
      <g transform="translate(90, 28)">
        <path d="M 0 0 h -5 v 34 h 5" stroke="#a855f7" stroke-width="1.8" fill="none"/>
        <text x="8" y="15" font-family="monospace" font-size="11">
          <tspan fill="#fbbf24" font-weight="bold">3</tspan>   <tspan fill="#64748b">0</tspan>
        </text>
        <text x="8" y="30" font-family="monospace" font-size="11">
          <tspan fill="#64748b">0</tspan>   <tspan fill="#fbbf24" font-weight="bold">5</tspan>
        </text>
        <path d="M 48 0 h 5 v 34 h -5" stroke="#a855f7" stroke-width="1.8" fill="none"/>
      </g>
    </g>

    <!-- Down Arrow 2 -->
    <path d="M 140 223 L 140 247" stroke="#a855f7" stroke-width="2" marker-end="url(#sci-arrow-purple)"/>
    <rect x="70" y="228" width="140" height="16" rx="8" fill="#0f172a" stroke="#a855f7" stroke-width="1"/>
    <text x="140" y="240" fill="#e9d5ff" font-size="9" font-family="monospace" font-weight="bold" text-anchor="middle">
      विकर्ण अवयव = 1 (k = 1)
    </text>

    <!-- Step 3: Identity Matrix -->
    <g transform="translate(15, 252)">
      <rect width="250" height="115" rx="6" fill="#4c0519" fill-opacity="0.9" stroke="#ec4899" stroke-width="1.2"/>
      <text x="125" y="20" font-family="sans-serif" font-size="12" font-weight="700" fill="#fbcfe8" text-anchor="middle">
        तत्समक आव्यूह (Identity Matrix I)
      </text>

      <g transform="translate(90, 28)">
        <path d="M 0 0 h -5 v 34 h 5" stroke="#ec4899" stroke-width="1.8" fill="none"/>
        <text x="8" y="15" font-family="monospace" font-size="12">
          <tspan fill="#f43f5e" font-weight="bold">1</tspan>   <tspan fill="#64748b">0</tspan>
        </text>
        <text x="8" y="30" font-family="monospace" font-size="12">
          <tspan fill="#64748b">0</tspan>   <tspan fill="#f43f5e" font-weight="bold">1</tspan>
        </text>
        <path d="M 48 0 h 5 v 34 h -5" stroke="#ec4899" stroke-width="1.8" fill="none"/>
      </g>

      <text x="125" y="92" font-family="monospace" font-size="11" font-weight="bold" fill="#fda4af" text-anchor="middle">
        गुणधर्म: I · A = A · I = A
      </text>
    </g>
  </g>

  <!-- ==================== COLUMN 3: Zero Matrix & Scalar Matrix (x=680, width=280) [40px GAP] ==================== -->
  <g id="col-3-group">
    <!-- Box 3A: Zero Matrix -->
    <g transform="translate(680, 90)" filter="url(#sci-glow-subtle)">
      <rect width="280" height="185" fill="url(#sci-card-grad-emerald)" stroke="#059669" stroke-width="1.5" rx="8"/>
      <text x="140" y="24" font-family="sans-serif" font-size="13" font-weight="700" fill="#34d399" text-anchor="middle">
        3. शून्य आव्यूह (Zero Matrix O)
      </text>
      <line x1="15" y1="34" x2="265" y2="34" stroke="#059669" stroke-width="1" opacity="0.3"/>

      <text x="140" y="55" font-family="sans-serif" font-size="11" fill="#94a3b8" text-anchor="middle">
        सभी अवयव शून्य (aᵢⱼ = 0,  ∀ i, j)
      </text>

      <!-- Matrix Representation -->
      <g transform="translate(35, 75)">
        <text x="0" y="26" fill="#34d399" font-family="monospace" font-size="13" font-weight="bold">
          O₂×₃ =
        </text>
        <g transform="translate(62, 0)">
          <path d="M 0 0 h -5 v 42 h 5" stroke="#34d399" stroke-width="1.8" fill="none"/>
          <text x="12" y="17" fill="#a7f3d0" font-family="monospace" font-size="12">
            0   0   0
          </text>
          <text x="12" y="34" fill="#a7f3d0" font-family="monospace" font-size="12">
            0   0   0
          </text>
          <path d="M 95 0 h 5 v 42 h -5" stroke="#34d399" stroke-width="1.8" fill="none"/>
        </g>
      </g>

      <!-- Property Pill -->
      <rect x="30" y="135" width="220" height="28" rx="6" fill="#064e3b" fill-opacity="0.6" stroke="#34d399" stroke-width="1"/>
      <text x="140" y="153" fill="#a7f3d0" font-family="monospace" font-size="11" font-weight="bold" text-anchor="middle">
        योग तत्समक: A + O = A
      </text>
    </g>

    <!-- Box 3B: Scalar Matrix -->
    <g transform="translate(680, 290)" filter="url(#sci-glow-subtle)">
      <rect width="280" height="185" fill="url(#sci-card-grad-blue)" stroke="#0284c7" stroke-width="1.5" rx="8"/>
      <text x="140" y="24" font-family="sans-serif" font-size="13" font-weight="700" fill="#22d3ee" text-anchor="middle">
        अदिश आव्यूह (Scalar Matrix)
      </text>
      <line x1="15" y1="34" x2="265" y2="34" stroke="#0284c7" stroke-width="1" opacity="0.3"/>

      <!-- Scalar Annotation & Pointer -->
      <g transform="translate(15, 45)">
        <text x="0" y="14" font-family="sans-serif" font-size="11" fill="#94a3b8">
          Scalar Matrix:
        </text>
        <text x="80" y="14" font-family="sans-serif" font-size="11" fill="#22d3ee" font-weight="bold">
          (aᵢᵢ = k)
        </text>
      </g>

      <!-- Matrix Representation -->
      <g transform="translate(50, 75)">
        <g transform="translate(0, 0)">
          <path d="M 0 0 h -5 v 38 h 5" stroke="#22d3ee" stroke-width="1.8" fill="none"/>
          <text x="8" y="16" font-family="monospace" font-size="12">
            <tspan fill="#22d3ee" font-weight="bold">k</tspan>   <tspan fill="#64748b">0</tspan>
          </text>
          <text x="8" y="32" font-family="monospace" font-size="12">
            <tspan fill="#64748b">0</tspan>   <tspan fill="#22d3ee" font-weight="bold">k</tspan>
          </text>
          <path d="M 48 0 h 5 v 38 h -5" stroke="#22d3ee" stroke-width="1.8" fill="none"/>
        </g>
        <text x="75" y="24" fill="#e0f2fe" font-family="monospace" font-size="13" font-weight="bold">
          =  k · I
        </text>
        <!-- Pointer line for scalar matrix k value -->
        <path d="M -15 16 L -5 16" stroke="#22d3ee" stroke-width="1.2" marker-end="url(#sci-pointer-cyan)"/>
      </g>

      <!-- Note Badge -->
      <rect x="25" y="130" width="230" height="32" rx="6" fill="#0c4a6e" fill-opacity="0.8" stroke="#0284c7" stroke-width="1"/>
      <text x="140" y="150" fill="#e0f2fe" font-family="sans-serif" font-size="11" font-weight="600" text-anchor="middle">
        यदि k = 1 ➔ तत्समक आव्यूह (I)
      </text>
    </g>
  </g>

  <!-- ==================== INTERACTIVE LEGEND OVERLAY ==================== -->
  <g id="matrix-legend-overlay" style="display: none;" transform="translate(260, 80)" filter="url(#sci-glow-subtle)">
    <rect width="480" height="340" rx="12" fill="#0f172a" stroke="#38bdf8" stroke-width="2" fill-opacity="0.98"/>
    <!-- Header -->
    <rect width="480" height="42" rx="12" fill="#1e293b"/>
    <text x="20" y="27" font-family="sans-serif" font-size="14" font-weight="bold" fill="#38bdf8">
      📖 Matrix Notation &amp; Symbol Legend
    </text>
    <g cursor="pointer" onclick="document.getElementById('matrix-legend-overlay').style.display='none'">
      <circle cx="455" cy="21" r="12" fill="#334155"/>
      <text x="455" y="26" font-family="sans-serif" font-size="13" font-weight="bold" fill="#f8fafc" text-anchor="middle">✕</text>
    </g>
    <!-- Legend Items -->
    <g transform="translate(20, 60)" font-family="sans-serif" font-size="12">
      <!-- Item 1 -->
      <text x="0" y="15" fill="#38bdf8" font-family="monospace" font-weight="bold">m × n</text>
      <text x="80" y="15" fill="#cbd5e1">: Matrix Order (m rows × n columns)</text>

      <!-- Item 2 -->
      <text x="0" y="45" fill="#818cf8" font-family="monospace" font-weight="bold">a_ij</text>
      <text x="80" y="45" fill="#cbd5e1">: Element at row i and column j</text>

      <!-- Item 3 -->
      <text x="0" y="75" fill="#fbbf24" font-family="monospace" font-weight="bold">a_ii</text>
      <text x="80" y="75" fill="#cbd5e1">: Main diagonal elements (a₁₁, a₂₂, ...)</text>

      <!-- Item 4 -->
      <text x="0" y="105" fill="#f59e0b" font-family="monospace" font-weight="bold">Trace(A)</text>
      <text x="80" y="105" fill="#cbd5e1">: Sum of main diagonal elements (Σ a_ii)</text>

      <!-- Item 5 -->
      <text x="0" y="135" fill="#ec4899" font-family="monospace" font-weight="bold">I</text>
      <text x="80" y="135" fill="#cbd5e1">: Identity matrix with 1 on diagonal</text>

      <!-- Item 6 -->
      <text x="0" y="165" fill="#34d399" font-family="monospace" font-weight="bold">O</text>
      <text x="80" y="165" fill="#cbd5e1">: Zero/Null matrix with all elements = 0</text>

      <!-- Item 7 -->
      <text x="0" y="195" fill="#22d3ee" font-family="monospace" font-weight="bold">k · I</text>
      <text x="80" y="195" fill="#cbd5e1">: Scalar matrix with diagonal constant k</text>

      <!-- Close hint -->
      <rect x="140" y="225" width="160" height="28" rx="6" fill="#1e293b" stroke="#475569" stroke-width="1" cursor="pointer" onclick="document.getElementById('matrix-legend-overlay').style.display='none'"/>
      <text x="220" y="243" font-family="sans-serif" font-size="11" font-weight="bold" fill="#94a3b8" text-anchor="middle" cursor="pointer" onclick="document.getElementById('matrix-legend-overlay').style.display='none'">Click to Close</text>
    </g>
  </g>
</svg>`
    };
  }

  // 1. Coordinate Mechanics Grid - clean axes without default overlay vectors
  if (
    hText.includes('vector') || 
    hText.includes('सदिश') || 
    hText.includes('cross product') || 
    hText.includes('dot product') || 
    hText.includes('triangle law') || 
    hText.includes('parallelogram law') || 
    hText.includes('vector resolution') ||
    hText.includes('resultant vector') ||
    hText.includes('unit vector')
  ) {
    return {
      category: '📐 2D Coordinate Mechanics Grid',
      svg: `<svg viewBox="0 0 500 320" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
  <defs>
    <marker id="arrow-cyan" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#38bdf8"/>
    </marker>
  </defs>
  <!-- Background grid lines -->
  <path d="M 40 50 L 460 50 M 40 100 L 460 100 M 40 150 L 460 150 M 40 200 L 460 200 M 40 250 L 460 250" stroke="#334155" stroke-width="1" stroke-dasharray="3 3" opacity="0.4"/>
  <path d="M 80 40 L 80 280 M 160 40 L 160 280 M 240 40 L 240 280 M 320 40 L 320 280 M 400 40 L 400 280" stroke="#334155" stroke-width="1" stroke-dasharray="3 3" opacity="0.4"/>
  
  <!-- Coordinate Axes -->
  <line x1="60" y1="250" x2="450" y2="250" stroke="#94a3b8" stroke-width="2" marker-end="url(#arrow-cyan)"/>
  <line x1="60" y1="250" x2="60" y2="40" stroke="#94a3b8" stroke-width="2" marker-end="url(#arrow-cyan)"/>
  <text x="445" y="270" fill="#94a3b8" font-size="12" font-family="monospace">X-Axis</text>
  <text x="40" y="35" fill="#94a3b8" font-size="12" font-family="monospace">Y-Axis</text>
  <text x="48" y="265" fill="#94a3b8" font-size="12" font-family="monospace">O(0,0)</text>

  <!-- Mathematical Callout -->
  <rect x="250" y="30" width="220" height="42" rx="8" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5" opacity="0.95"/>
  <text x="260" y="55" fill="#38bdf8" font-size="11" font-weight="bold" font-family="monospace">2D Coordinate Blackboard Grid</text>
</svg>`
    };
  }

  // 2. Calculus & Functions / Derivatives / Integrals
  if (
    hText.includes('derivative') || 
    hText.includes('integral') || 
    hText.includes('tangent slope') || 
    hText.includes('curve analysis') ||
    hText.includes('अवकलन') ||
    hText.includes('समाकलन')
  ) {
    return {
      category: '📊 Calculus & Functions',
      svg: `<svg viewBox="0 0 500 320" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
  <defs>
    <linearGradient id="area-grad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.35"/>
      <stop offset="100%" stop-color="#38bdf8" stop-opacity="0.05"/>
    </linearGradient>
  </defs>
  <!-- Axes -->
  <line x1="50" y1="270" x2="450" y2="270" stroke="#94a3b8" stroke-width="2"/>
  <line x1="50" y1="270" x2="50" y2="40" stroke="#94a3b8" stroke-width="2"/>
  <text x="440" y="290" fill="#94a3b8" font-size="12" font-family="monospace">x</text>
  <text x="30" y="45" fill="#94a3b8" font-size="12" font-family="monospace">f(x)</text>

  <!-- Definite Integral Shaded Area -->
  <path d="M 120 270 L 120 210 Q 220 70 340 130 L 340 270 Z" fill="url(#area-grad)"/>
  <text x="210" y="235" fill="#38bdf8" font-size="14" font-weight="bold" font-family="monospace">∫ f(x) dx</text>

  <!-- Function Curve -->
  <path d="M 70 240 Q 220 40 430 140" fill="none" stroke="#fde047" stroke-width="4"/>
  <text x="380" y="125" fill="#fde047" font-size="14" font-weight="bold" font-family="monospace">y = f(x)</text>

  <!-- Tangent Line at x0 -->
  <line x1="140" y1="180" x2="310" y2="90" stroke="#f43f5e" stroke-width="2.5" stroke-dasharray="5 3"/>
  <circle cx="225" cy="135" r="5" fill="#f43f5e"/>
  <text x="235" y="115" fill="#f43f5e" font-size="12" font-weight="bold" font-family="monospace">Slope m = f'(x)</text>

  <!-- Limits a and b -->
  <line x1="120" y1="270" x2="120" y2="210" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="3 3"/>
  <line x1="340" y1="270" x2="340" y2="130" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="3 3"/>
  <text x="115" y="290" fill="#38bdf8" font-size="13" font-weight="bold" font-family="monospace">a</text>
  <text x="335" y="290" fill="#38bdf8" font-size="13" font-weight="bold" font-family="monospace">b</text>
</svg>`
    };
  }

  // 3. Free-Body Diagrams (FBD) & Forces
  if (
    hText.includes('free body diagram') || 
    hText.includes('fbd') || 
    hText.includes('force balance') ||
    hText.includes('friction force')
  ) {
    return {
      category: '⚙️ Forces & Dynamics (FBD)',
      svg: `<svg viewBox="0 0 500 320" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
  <!-- Ground surface -->
  <line x1="60" y1="220" x2="440" y2="220" stroke="#94a3b8" stroke-width="3"/>
  <path d="M 70 220 L 55 235 M 120 220 L 105 235 M 170 220 L 155 235 M 220 220 L 205 235 M 270 220 L 255 235 M 320 220 L 305 235 M 370 220 L 355 235 M 420 220 L 405 235" stroke="#475569" stroke-width="2"/>

  <!-- Mass Block (m) -->
  <rect x="190" y="120" width="120" height="100" rx="6" fill="#1e293b" stroke="#fde047" stroke-width="3.5"/>
  <text x="238" y="175" fill="#fde047" font-size="20" font-weight="bold" font-family="monospace">m</text>

  <!-- Force Vectors -->
  <!-- 1. Normal Force N (Upward) -->
  <line x1="250" y1="120" x2="250" y2="40" stroke="#38bdf8" stroke-width="4"/>
  <polygon points="250,30 244,45 256,45" fill="#38bdf8"/>
  <text x="260" y="55" fill="#38bdf8" font-size="15" font-weight="bold" font-family="monospace">N (Normal)</text>

  <!-- 2. Gravity Force mg (Downward) -->
  <line x1="250" y1="220" x2="250" y2="300" stroke="#f43f5e" stroke-width="4"/>
  <polygon points="250,310 244,295 256,295" fill="#f43f5e"/>
  <text x="260" y="295" fill="#f43f5e" font-size="15" font-weight="bold" font-family="monospace">W = mg</text>

  <!-- 3. Applied Force F (Rightward) -->
  <line x1="310" y1="170" x2="410" y2="170" stroke="#4ade80" stroke-width="4"/>
  <polygon points="420,170 405,164 405,176" fill="#4ade80"/>
  <text x="350" y="155" fill="#4ade80" font-size="15" font-weight="bold" font-family="monospace">F_applied</text>

  <!-- 4. Friction Force f_k (Leftward) -->
  <line x1="190" y1="210" x2="100" y2="210" stroke="#fb923c" stroke-width="3.5"/>
  <polygon points="90,210 105,204 105,216" fill="#fb923c"/>
  <text x="100" y="195" fill="#fb923c" font-size="13" font-weight="bold" font-family="monospace">f_k = μ_k N</text>

  <!-- Equilibrium Badge -->
  <rect x="310" y="30" width="160" height="36" rx="8" fill="#0f172a" stroke="#38bdf8" stroke-width="1.5"/>
  <text x="325" y="53" fill="#38bdf8" font-size="12" font-weight="bold" font-family="monospace">ΣF_y = N - mg = 0</text>
</svg>`
    };
  }

  // 4. Electric Circuit & Resistor Network
  if (
    hText.includes('circuit diagram') || 
    hText.includes('resistor network') || 
    hText.includes('kirchhoff') || 
    hText.includes('ohm\'s law')
  ) {
    return {
      category: '⚡ Electric Circuit Schematic',
      svg: `<svg viewBox="0 0 500 320" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
  <!-- Circuit Loop Wire -->
  <path d="M 120 160 L 120 70 L 210 70" fill="none" stroke="#94a3b8" stroke-width="3"/>
  <path d="M 310 70 L 400 70 L 400 250 L 120 250 L 120 190" fill="none" stroke="#94a3b8" stroke-width="3"/>

  <!-- DC Voltage Source (Left) -->
  <line x1="100" y1="160" x2="140" y2="160" stroke="#fde047" stroke-width="4"/>
  <line x1="110" y1="175" x2="130" y2="175" stroke="#94a3b8" stroke-width="3"/>
  <line x1="100" y1="190" x2="140" y2="190" stroke="#fde047" stroke-width="4"/>
  <text x="60" y="175" fill="#fde047" font-size="16" font-weight="bold" font-family="monospace">V (+)</text>

  <!-- Resistor (Top) -->
  <path d="M 210 70 L 220 55 L 235 85 L 250 55 L 265 85 L 280 55 L 295 85 L 310 70" fill="none" stroke="#38bdf8" stroke-width="3.5"/>
  <text x="245" y="45" fill="#38bdf8" font-size="15" font-weight="bold" font-family="monospace">R (Ω)</text>

  <!-- Current Arrow Loop -->
  <path d="M 230 130 A 30 30 0 1 1 270 170" fill="none" stroke="#4ade80" stroke-width="2.5" stroke-dasharray="4 2"/>
  <polygon points="270,175 260,165 275,160" fill="#4ade80"/>
  <text x="240" y="160" fill="#4ade80" font-size="14" font-weight="bold" font-family="monospace">I = V/R</text>
</svg>`
    };
  }

  // 5. Chemical Bond & Molecular Structure
  if (
    hText.includes('molecular structure') || 
    hText.includes('chemical bond') || 
    hText.includes('covalent bond') || 
    hText.includes('ionic bond')
  ) {
    return {
      category: '🧪 Molecular Chemistry & Bonds',
      svg: `<svg viewBox="0 0 500 320" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
  <!-- Central Molecule A -->
  <circle cx="180" cy="160" r="45" fill="#1e293b" stroke="#38bdf8" stroke-width="3.5"/>
  <text x="168" y="167" fill="#38bdf8" font-size="22" font-weight="bold" font-family="monospace">H</text>

  <!-- Molecule B -->
  <circle cx="320" cy="160" r="45" fill="#1e293b" stroke="#f43f5e" stroke-width="3.5"/>
  <text x="308" y="167" fill="#f43f5e" font-size="22" font-weight="bold" font-family="monospace">O</text>

  <!-- Covalent Bond Bridge -->
  <line x1="225" y1="150" x2="275" y2="150" stroke="#fde047" stroke-width="4"/>
  <line x1="225" y1="170" x2="275" y2="170" stroke="#fde047" stroke-width="4"/>
  <text x="235" y="135" fill="#fde047" font-size="11" font-weight="bold" font-family="monospace">Bond</text>
</svg>`
    };
  }

  // Explicitly marked diagram in heading
  if (hText.includes('[diagram]') || hText.includes('[figure]') || hText.includes('[schematic]') || hText.includes('आरेख')) {
    return {
      category: '📐 Academic Schematic',
      svg: `<svg viewBox="0 0 500 320" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
  <rect x="60" y="80" width="160" height="150" rx="14" fill="#1e293b" stroke="#38bdf8" stroke-width="3"/>
  <text x="95" y="145" fill="#38bdf8" font-size="16" font-weight="bold" font-family="monospace">Hypothesis</text>
  <text x="100" y="175" fill="#94a3b8" font-size="12" font-family="monospace">Inputs</text>

  <line x1="220" y1="155" x2="270" y2="155" stroke="#fde047" stroke-width="3.5"/>
  <polygon points="280,155 268,149 268,161" fill="#fde047"/>

  <rect x="280" y="80" width="160" height="150" rx="14" fill="#1e293b" stroke="#4ade80" stroke-width="3"/>
  <text x="315" y="145" fill="#4ade80" font-size="16" font-weight="bold" font-family="monospace">Conclusion</text>
  <text x="315" y="175" fill="#94a3b8" font-size="12" font-family="monospace">Derived Law</text>
</svg>`
    };
  }

  // Otherwise, NO diagram is needed. Return null so clean headings are rendered.
  return null;
}

export const SubtopicHeadingDiagram: React.FC<SubtopicHeadingDiagramProps> = React.memo(({
  level,
  children,
  fullContent = '',
  theme = 'dark',
  onOpenWhiteboard,
  showNotification,
  onRenderComplete,
  embeddedSvg,
  isLectureMode = true
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(true);

  // Extract raw string title from children
  const headingTitle = useMemo(() => {
    if (typeof children === 'string') return children;
    if (Array.isArray(children)) {
      return children.map(c => (typeof c === 'string' ? c : '')).join(' ');
    }
    return '';
  }, [children]);

  // Generate or retrieve contextual diagram only if needed
  const diagramData = useMemo(() => {
    if (embeddedSvg && embeddedSvg.includes('<svg')) {
      return {
        category: '📐 Sub-Topic Teaching Schematic',
        svg: embeddedSvg
      };
    }
    return generateContextualSubtopicSvg(headingTitle, fullContent);
  }, [headingTitle, fullContent, embeddedSvg]);

  // If no diagram is needed, render clean standard academic heading directly
  if (!diagramData) {
    if (level === 1) {
      return (
        <h1 className={cn(
          "text-2xl font-black mb-4 tracking-tight mt-6 first:mt-0",
          theme === 'dark' ? "text-amber-200" : "text-amber-950"
        )}>
          {children}
        </h1>
      );
    }
    if (level === 2) {
      return (
        <h2 className={cn(
          "text-xl font-black mb-3 tracking-tight mt-5 first:mt-0",
          theme === 'dark' ? "text-amber-200" : "text-amber-950"
        )}>
          {children}
        </h2>
      );
    }
    return (
      <h3 className={cn(
        "text-lg font-black mb-2 tracking-tight mt-4 first:mt-0",
        theme === 'dark' ? "text-amber-200" : "text-amber-950"
      )}>
        {children}
      </h3>
    );
  }

  const TagHeading = level === 1 ? 'h1' : level === 2 ? 'h2' : 'h3';

  return (
    <div className="not-prose my-6 w-full group/subtopic">
      {/* Subtopic Header Bar with Title & Dedicated Diagram Controls */}
      <div className={cn(
        "rounded-2xl p-4 transition-all duration-300 border shadow-lg backdrop-blur-md",
        theme === 'dark' 
          ? "bg-slate-900/90 border-amber-400/30 text-amber-100 shadow-black/40" 
          : "bg-amber-50/90 border-amber-300 text-slate-800 shadow-amber-900/5"
      )}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Subtopic Title and Category Badge */}
          <div className="flex items-center gap-2.5 flex-1 min-w-[240px]">
            <span className="p-2 rounded-xl bg-amber-400/15 border border-amber-400/30 text-amber-300 shadow-inner">
              <Compass size={18} />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-black tracking-widest px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  {diagramData.category}
                </span>
                <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 font-bold">
                  <Sparkles size={11} />
                  Visual Schematic
                </span>
              </div>
              <TagHeading className={cn(
                "font-black tracking-tight mt-1",
                level === 1 ? "text-2xl text-amber-200" : level === 2 ? "text-xl text-amber-300" : "text-lg text-amber-400"
              )}>
                {children}
              </TagHeading>
            </div>
          </div>

          {/* Quick Action Controls */}
          <div className="flex items-center gap-1.5 bg-black/40 p-1.5 rounded-xl border border-white/10">
            <button
              type="button"
              onClick={() => setIsOpen(!isOpen)}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 border",
                isOpen 
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" 
                  : "bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700"
              )}
              title="Show/Hide Subtopic Diagram"
            >
              {isOpen ? <Eye size={13} /> : <EyeOff size={13} />}
              <span>{isOpen ? "Diagram Active" : "Show Diagram"}</span>
            </button>

            {onOpenWhiteboard && (
              <button
                type="button"
                onClick={() => {
                  const blob = new Blob([diagramData.svg], { type: 'image/svg+xml' });
                  const url = URL.createObjectURL(blob);
                  onOpenWhiteboard(url);
                  showNotification?.("Opened subtopic schematic in full Whiteboard!", "success");
                }}
                className="p-1.5 rounded-lg bg-slate-800 text-sky-300 border border-slate-700 hover:bg-sky-500/20 hover:border-sky-400 transition-all"
                title="Open on Interactive Whiteboard"
              >
                <ExternalLink size={13} />
              </button>
            )}
          </div>
        </div>

        {/* Dedicated Subtopic Diagram Canvas */}
        {isOpen && (
          <div className="mt-4 pt-4 border-t border-amber-400/20 transition-all duration-300">
            <div className="w-full">
              <div className="relative rounded-xl overflow-hidden border border-amber-400/30 bg-slate-950/80 shadow-2xl p-1">
                <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 bg-black/80 px-2.5 py-1 rounded-lg border border-amber-400/30 text-[10px] font-mono text-amber-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Chalkboard Figure</span>
                </div>

                <SvgDiagramViewer
                  svgCode={diagramData.svg}
                  theme={theme}
                  title={`Diagram: ${headingTitle}`}
                  onOpenWhiteboard={onOpenWhiteboard}
                  showNotification={showNotification}
                  onRenderComplete={onRenderComplete}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
});
