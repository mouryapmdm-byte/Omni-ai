import { DiagnosticQuestion } from './types';

export const DEFAULT_DIAGNOSTIC_BANK: DiagnosticQuestion[] = [
  // --- SUBTOPIC 1: Coulomb's Law & Electric Fields (Foundation to Advanced) ---
  {
    id: 'q_ef_01',
    chapterId: 'electromagnetism',
    subtopicId: 'electric_field_coulomb',
    subtopicTitle: "Coulomb's Law & Electric Fields",
    difficulty: -1.2, // Easy / Medium-Low
    discrimination: 1.1,
    pseudoGuessing: 0.25,
    questionText: "Two point charges +q and +4q are separated by distance r. At what point along the line joining them is the net electric field zero?",
    options: [
      "r/3 from +q",
      "r/2 from +q",
      "2r/3 from +q",
      "r/4 from +q"
    ],
    correctOptionIndex: 0,
    explanation: "For net field to vanish: k*q / x² = k*(4q) / (r - x)², so 1/x = 2/(r - x) => r - x = 2x => x = r/3 from +q."
  },
  {
    id: 'q_ef_02',
    chapterId: 'electromagnetism',
    subtopicId: 'electric_field_coulomb',
    subtopicTitle: "Coulomb's Law & Electric Fields",
    difficulty: 0.0, // Medium
    discrimination: 1.3,
    pseudoGuessing: 0.25,
    questionText: "An electric dipole of moment p is placed in a uniform electric field E at angle θ. What is the electrostatic torque experienced by the dipole?",
    formulaOrCode: "\\vec{\\tau} = \\vec{p} \\times \\vec{E}",
    options: [
      "pE sin θ",
      "pE cos θ",
      "pE (1 - cos θ)",
      "Zero"
    ],
    correctOptionIndex: 0,
    explanation: "Torque is given by the cross product τ = p × E, whose magnitude is pE sin θ."
  },
  {
    id: 'q_ef_03',
    chapterId: 'electromagnetism',
    subtopicId: 'electric_field_coulomb',
    subtopicTitle: "Coulomb's Law & Electric Fields",
    difficulty: 1.4, // Hard / Advanced
    discrimination: 1.5,
    pseudoGuessing: 0.25,
    questionText: "A non-conducting ring of radius R has uniform linear charge density λ. A point charge q is released from rest on the axis at distance x << R. The motion of the charge is:",
    options: [
      "Simple Harmonic Motion with frequency proportional to 1/√(R³)",
      "Purely exponential runaway",
      "Periodic but strictly non-harmonic",
      "Static equilibrium with zero net restoring force"
    ],
    correctOptionIndex: 0,
    explanation: "For x << R, axial field E ≈ (kq x) / R³, so restoring force F = -kq²x / R³, which is Hooke's form F = -kx resulting in SHM."
  },

  // --- SUBTOPIC 2: Gauss's Law & Flux (Foundation to Advanced) ---
  {
    id: 'q_gauss_01',
    chapterId: 'electromagnetism',
    subtopicId: 'gauss_law_flux',
    subtopicTitle: "Gauss's Law & Electric Flux",
    difficulty: -0.8,
    discrimination: 1.0,
    pseudoGuessing: 0.25,
    questionText: "A point charge +Q is positioned at the geometric centre of a hollow cube. What is the total electric flux passing through ANY SINGLE FACE of the cube?",
    options: [
      "Q / (6 ε₀)",
      "Q / ε₀",
      "Q / (12 ε₀)",
      "Zero due to symmetry"
    ],
    correctOptionIndex: 0,
    explanation: "Total flux through all 6 faces is Q/ε₀ by Gauss's Law. By 6-fold cubic symmetry, each face receives exactly 1/6th: Q / (6ε₀)."
  },
  {
    id: 'q_gauss_02',
    chapterId: 'electromagnetism',
    subtopicId: 'gauss_law_flux',
    subtopicTitle: "Gauss's Law & Electric Flux",
    difficulty: 0.2,
    discrimination: 1.2,
    pseudoGuessing: 0.25,
    questionText: "An infinitely long straight wire has uniform linear charge density λ. The electric field at radial distance r from the wire varies as:",
    options: [
      "1 / r",
      "1 / r²",
      "Independent of r",
      "1 / r³"
    ],
    correctOptionIndex: 0,
    explanation: "Using cylindrical Gaussian surface of radius r and length L: E * (2πr L) = λL / ε₀ => E = λ / (2πε₀ r), which decays as 1/r."
  },
  {
    id: 'q_gauss_03',
    chapterId: 'electromagnetism',
    subtopicId: 'gauss_law_flux',
    subtopicTitle: "Gauss's Law & Electric Flux",
    difficulty: 1.6,
    discrimination: 1.6,
    pseudoGuessing: 0.25,
    questionText: "A solid sphere of radius R has non-uniform volume charge density ρ(r) = ρ₀ (r / R). What is the electric field inside at radial distance r < R?",
    options: [
      "ρ₀ r² / (4 ε₀ R)",
      "ρ₀ r / (3 ε₀ R)",
      "ρ₀ r³ / (5 ε₀ R²)",
      "Zero everywhere inside"
    ],
    correctOptionIndex: 0,
    explanation: "Enclosed charge Q_enc = ∫₀^r 4πs² ρ₀(s/R) ds = (4πρ₀/R) [r⁴/4]. By Gauss's Law: E * 4πr² = Q_enc/ε₀ => E = ρ₀ r² / (4ε₀ R)."
  },

  // --- SUBTOPIC 3: Electric Potential & Capacitance ---
  {
    id: 'q_pot_01',
    chapterId: 'electromagnetism',
    subtopicId: 'potential_and_capacitance',
    subtopicTitle: "Electric Potential & Capacitance",
    difficulty: -1.0,
    discrimination: 1.0,
    pseudoGuessing: 0.25,
    questionText: "A parallel plate capacitor with plate area A and separation d is filled with a dielectric slab of dielectric constant K. Its capacitance becomes:",
    options: [
      "K * (ε₀ A / d)",
      "(1/K) * (ε₀ A / d)",
      "ε₀ A / (K * d)",
      "(K - 1) * (ε₀ A / d)"
    ],
    correctOptionIndex: 0,
    explanation: "The introduction of dielectric constant K increases capacitance by factor K: C = K * C₀."
  },
  {
    id: 'q_pot_02',
    chapterId: 'electromagnetism',
    subtopicId: 'potential_and_capacitance',
    subtopicTitle: "Electric Potential & Capacitance",
    difficulty: 0.3,
    discrimination: 1.3,
    pseudoGuessing: 0.25,
    questionText: "If the electric potential in a region is given by V(x, y, z) = 6xy - y² + 2yz, the electric field vector E at point (1, 1, 0) is:",
    options: [
      "-6î - 4ĵ - 2k̂",
      "6î + 4ĵ + 2k̂",
      "-6î + 2ĵ",
      "-4î - 6ĵ"
    ],
    correctOptionIndex: 0,
    explanation: "E = -∇V: E_x = -∂V/∂x = -6y = -6; E_y = -∂V/∂y = -(6x - 2y + 2z) = -(6 - 2) = -4; E_z = -∂V/∂z = -2y = -2."
  },
  {
    id: 'q_pot_03',
    chapterId: 'electromagnetism',
    subtopicId: 'potential_and_capacitance',
    subtopicTitle: "Electric Potential & Capacitance",
    difficulty: 1.5,
    discrimination: 1.4,
    pseudoGuessing: 0.25,
    questionText: "Two concentric thin metallic spherical shells of radii a and b (a < b) have charges Q_a and Q_b. The potential difference V_a - V_b depends only on:",
    options: [
      "Charge Q_a on the inner sphere",
      "Charge Q_b on the outer sphere",
      "Sum of charges (Q_a + Q_b)",
      "Product of charges (Q_a * Q_b)"
    ],
    correctOptionIndex: 0,
    explanation: "The potential difference ΔV = ∫_a^b E dr depends solely on field between shells, where E = k Q_a / r², completely independent of outer charge Q_b."
  },

  // --- SUBTOPIC 4: Biot-Savart & Magnetic Forces ---
  {
    id: 'q_mag_01',
    chapterId: 'electromagnetism',
    subtopicId: 'biot_savart_magnetic_force',
    subtopicTitle: "Biot-Savart Law & Magnetic Forces",
    difficulty: -0.6,
    discrimination: 1.1,
    pseudoGuessing: 0.25,
    questionText: "A charged particle of charge q and velocity v enters a perpendicular uniform magnetic field B. What is the radius of its circular trajectory?",
    options: [
      "m v / (q B)",
      "q B / (m v)",
      "q v / (m B)",
      "m B / (q v)"
    ],
    correctOptionIndex: 0,
    explanation: "Centripetal force is supplied by Lorentz force: m v² / r = q v B => r = m v / (q B)."
  },
  {
    id: 'q_mag_02',
    chapterId: 'electromagnetism',
    subtopicId: 'biot_savart_magnetic_force',
    subtopicTitle: "Biot-Savart Law & Magnetic Forces",
    difficulty: 0.4,
    discrimination: 1.3,
    pseudoGuessing: 0.25,
    questionText: "Two long, parallel conductors separated by distance d carry currents I₁ and I₂ in opposite directions. The magnetic force between them is:",
    options: [
      "Repulsive, magnitude μ₀ I₁ I₂ / (2π d)",
      "Attractive, magnitude μ₀ I₁ I₂ / (2π d)",
      "Repulsive, magnitude μ₀ I₁ I₂ / (4π d²)",
      "Zero because opposite currents cancel"
    ],
    correctOptionIndex: 0,
    explanation: "Anti-parallel currents repel with force per unit length F/L = μ₀ I₁ I₂ / (2π d)."
  },
  {
    id: 'q_mag_03',
    chapterId: 'electromagnetism',
    subtopicId: 'biot_savart_magnetic_force',
    subtopicTitle: "Biot-Savart Law & Magnetic Forces",
    difficulty: 1.7,
    discrimination: 1.6,
    pseudoGuessing: 0.25,
    questionText: "A circular current loop of radius R and current I lies in the xy-plane. The ratio of magnetic field on its axis at distance x = R to that at the loop center is:",
    options: [
      "1 / (2√2)",
      "1 / 4",
      "1 / (4√2)",
      "1 / 2"
    ],
    correctOptionIndex: 0,
    explanation: "B(x) = μ₀ I R² / [2(R² + x²)^(3/2)]. At x = 0, B_center = μ₀ I / (2R). At x = R, B(R) = μ₀ I / [2(2R²)^(3/2)] = B_center / 2^(3/2) = 1/(2√2)."
  },

  // --- SUBTOPIC 5: Faraday's Law & Electromagnetic Induction ---
  {
    id: 'q_emi_01',
    chapterId: 'electromagnetism',
    subtopicId: 'faraday_emi_inductance',
    subtopicTitle: "Faraday's Law & EMI",
    difficulty: -0.7,
    discrimination: 1.0,
    pseudoGuessing: 0.25,
    questionText: "According to Lenz's law, the polarity of induced electromotive force (EMF) is such that it always:",
    options: [
      "Opposes the change in magnetic flux producing it",
      "Reinforces the magnetic flux that created it",
      "Aligns with the applied electric field",
      "Maximizes heat dissipation via eddy currents"
    ],
    correctOptionIndex: 0,
    explanation: "Lenz's law is a consequence of conservation of energy: ε = -dΦ/dt, always opposing the flux alteration."
  },
  {
    id: 'q_emi_02',
    chapterId: 'electromagnetism',
    subtopicId: 'faraday_emi_inductance',
    subtopicTitle: "Faraday's Law & EMI",
    difficulty: 0.5,
    discrimination: 1.3,
    pseudoGuessing: 0.25,
    questionText: "A conducting rod of length L rotates with constant angular velocity ω about one endpoint perpendicular to uniform magnetic field B. The induced EMF across its ends is:",
    options: [
      "(1/2) B ω L²",
      "B ω L²",
      "(1/4) B ω L²",
      "Zero because it rotates in a plane"
    ],
    correctOptionIndex: 0,
    explanation: "EMF = ∫₀^L v B dr = ∫₀^L (ω r) B dr = (1/2) B ω L²."
  },
  {
    id: 'q_emi_03',
    chapterId: 'electromagnetism',
    subtopicId: 'faraday_emi_inductance',
    subtopicTitle: "Faraday's Law & EMI",
    difficulty: 1.8,
    discrimination: 1.7,
    pseudoGuessing: 0.25,
    questionText: "An RL circuit with inductance L and resistance R is connected to DC source V₀. The time constant τ represents the duration required for the current to reach what fraction of its maximum steady-state value?",
    options: [
      "1 - 1/e ≈ 63.2%",
      "1/e ≈ 36.8%",
      "50.0% (half-life)",
      "90.0%"
    ],
    correctOptionIndex: 0,
    explanation: "i(t) = (V₀/R)(1 - e^(-t/τ)). At t = τ, i = I_max (1 - e⁻¹) ≈ 0.632 I_max."
  },

  // --- SUBTOPIC 6: Alternating Currents & Resonance ---
  {
    id: 'q_ac_01',
    chapterId: 'electromagnetism',
    subtopicId: 'ac_circuits_resonance',
    subtopicTitle: "AC Circuits & Resonance",
    difficulty: -0.4,
    discrimination: 1.1,
    pseudoGuessing: 0.25,
    questionText: "In a series RLC circuit at electrical resonance, the impedance of the circuit is:",
    options: [
      "Minimum and equal to R",
      "Maximum and equal to √(R² + (ωL - 1/ωC)²)",
      "Infinite due to capacitive reactance",
      "Zero"
    ],
    correctOptionIndex: 0,
    explanation: "At resonance, X_L = X_C, so reactive component vanishes and total impedance Z = R (minimum), causing current amplitude to peak."
  },
  {
    id: 'q_ac_02',
    chapterId: 'electromagnetism',
    subtopicId: 'ac_circuits_resonance',
    subtopicTitle: "AC Circuits & Resonance",
    difficulty: 0.6,
    discrimination: 1.4,
    pseudoGuessing: 0.25,
    questionText: "The Quality factor (Q-factor) of a series resonant RLC circuit is expressed by:",
    options: [
      "(1/R) * √(L / C)",
      "R * √(L / C)",
      "(1/R) * √(C / L)",
      "ω₀ L R"
    ],
    correctOptionIndex: 0,
    explanation: "Q = ω₀ L / R = (1/√(LC)) * (L / R) = (1/R) * √(L/C)."
  },
  {
    id: 'q_ac_03',
    chapterId: 'electromagnetism',
    subtopicId: 'ac_circuits_resonance',
    subtopicTitle: "AC Circuits & Resonance",
    difficulty: 1.9,
    discrimination: 1.8,
    pseudoGuessing: 0.25,
    questionText: "In an AC circuit, voltage V = V₀ sin(ωt) and current I = I₀ sin(ωt - π/3). The average power dissipated over one complete cycle is:",
    options: [
      "(1/4) V₀ I₀",
      "(1/2) V₀ I₀",
      "(√3/4) V₀ I₀",
      "Zero because phase shift is π/3"
    ],
    correctOptionIndex: 0,
    explanation: "P_avg = V_rms I_rms cos φ = (V₀/√2)(I₀/√2) cos(π/3) = (1/2) V₀ I₀ * (1/2) = (1/4) V₀ I₀."
  }
];

export interface ChapterSubtopicConfig {
  id: string;
  title: string;
  lectureDurationMinutes: number;
  weight: number;
}

export const ELECTROMAGNETISM_SUBTOPICS: ChapterSubtopicConfig[] = [
  { id: 'electric_field_coulomb', title: "Coulomb's Law & Electric Fields", lectureDurationMinutes: 30, weight: 1.0 },
  { id: 'gauss_law_flux', title: "Gauss's Law & Flux", lectureDurationMinutes: 25, weight: 1.0 },
  { id: 'potential_and_capacitance', title: "Electric Potential & Capacitance", lectureDurationMinutes: 35, weight: 1.2 },
  { id: 'biot_savart_magnetic_force', title: "Biot-Savart Law & Magnetic Forces", lectureDurationMinutes: 30, weight: 1.1 },
  { id: 'faraday_emi_inductance', title: "Faraday's Law & EMI", lectureDurationMinutes: 30, weight: 1.0 },
  { id: 'ac_circuits_resonance', title: "AC Circuits & Resonance", lectureDurationMinutes: 30, weight: 1.0 }
];
