import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Zap, Volume2, ShieldAlert, X, ChevronRight, Gauge } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface AudioDiagnosticsProps {
  isOpen: boolean;
  onClose: () => void;
  analyser: AnalyserNode | null;
  audioContext: AudioContext | null;
  isSpeaking: boolean;
}

export const AudioDiagnostics: React.FC<AudioDiagnosticsProps> = ({ isOpen, onClose, analyser, audioContext, isSpeaking }) => {
  const [stats, setStats] = useState({
    peak: 0,
    average: 0,
    state: 'unknown',
    sampleRate: 0,
    latency: 0
  });
  
  const requestRef = useRef<number>(0);
  const dataArrayRef = useRef<Uint8Array | null>(null);

  useEffect(() => {
    if (analyser) {
      dataArrayRef.current = new Uint8Array(analyser.frequencyBinCount);
    } else {
      dataArrayRef.current = null;
    }
  }, [analyser]);

  const update = () => {
    if (analyser && dataArrayRef.current) {
      analyser.getByteFrequencyData(dataArrayRef.current as any);
      let sum = 0;
      let peak = 0;
      for (let i = 0; i < dataArrayRef.current.length; i++) {
        const val = dataArrayRef.current[i];
        sum += val;
        if (val > peak) peak = val;
      }
      
      setStats({
        peak: Math.round((peak / 255) * 100),
        average: Math.round((sum / dataArrayRef.current.length / 255) * 100),
        state: audioContext?.state || 'unknown',
        sampleRate: audioContext?.sampleRate || 0,
        latency: Math.round((audioContext?.baseLatency || 0) * 1000)
      });
    } else if (audioContext) {
       setStats(prev => ({
         ...prev,
         state: audioContext.state,
         peak: 0,
         average: 0
       }));
    }
    requestRef.current = requestAnimationFrame(update);
  };

  useEffect(() => {
    if (isOpen) {
      requestRef.current = requestAnimationFrame(update);
    } else {
      cancelAnimationFrame(requestRef.current);
    }
    return () => cancelAnimationFrame(requestRef.current);
  }, [isOpen, analyser, audioContext]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, x: 300 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 300 }}
          className="fixed right-6 top-24 w-80 bg-slate-900/95 border border-white/10 rounded-2xl shadow-2xl backdrop-blur-xl z-[100] overflow-hidden"
        >
          <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/5">
            <div className="flex items-center gap-2">
              <Activity size={18} className="text-amber-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Audio Engine Diagnostics</h3>
            </div>
            <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
              <X size={18} />
            </button>
          </div>

          <div className="p-4 space-y-4">
            {/* Status Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                <div className="text-[10px] text-white/40 uppercase font-bold mb-1">Engine State</div>
                <div className={cn(
                  "text-sm font-mono font-bold",
                  stats.state === 'running' ? "text-emerald-400" : "text-amber-400"
                )}>
                  {stats.state.toUpperCase()}
                </div>
              </div>
              <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                <div className="text-[10px] text-white/40 uppercase font-bold mb-1">Latency</div>
                <div className="text-sm font-mono font-bold text-white">
                  {stats.latency}ms
                </div>
              </div>
            </div>

            {/* Signal Levels */}
            <div className="space-y-3">
              <div className="bg-black/20 p-3 rounded-xl border border-white/5">
                <div className="flex justify-between items-center mb-2">
                  <div className="text-[10px] text-white/40 uppercase font-bold">Peak Signal</div>
                  <div className="text-[10px] text-amber-400 font-mono font-bold">{stats.peak}%</div>
                </div>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-gradient-to-r from-emerald-500 via-amber-400 to-red-500"
                    animate={{ width: `${stats.peak}%` }}
                    transition={{ type: 'spring', bounce: 0, duration: 0.1 }}
                  />
                </div>
              </div>

              <div className="bg-black/20 p-3 rounded-xl border border-white/5">
                <div className="flex justify-between items-center mb-2">
                  <div className="text-[10px] text-white/40 uppercase font-bold">Average Level</div>
                  <div className="text-[10px] text-emerald-400 font-mono font-bold">{stats.average}%</div>
                </div>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-emerald-500"
                    animate={{ width: `${stats.average}%` }}
                    transition={{ type: 'spring', bounce: 0, duration: 0.1 }}
                  />
                </div>
              </div>
            </div>

            {/* Hardware Info */}
            <div className="bg-white/5 p-3 rounded-xl border border-white/5 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-white/40 font-bold uppercase">Sample Rate</span>
                <span className="text-[10px] text-white font-mono">{stats.sampleRate} Hz</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-white/40 font-bold uppercase">Active Stream</span>
                <span className={cn(
                  "text-[10px] font-mono font-bold",
                  isSpeaking ? "text-emerald-400" : "text-white/20"
                )}>
                  {isSpeaking ? 'YES' : 'NO'}
                </span>
              </div>
            </div>

            {!isSpeaking && (
              <div className="flex items-start gap-2 p-2 bg-amber-500/10 rounded-lg border border-amber-500/20">
                <ShieldAlert size={14} className="text-amber-500 shrink-0 mt-0.5" />
                <p className="text-[10px] text-amber-200/60 leading-tight">
                  No active signal detected. Peak and average levels will remain flat until speech generation starts.
                </p>
              </div>
            )}
          </div>
          
          <div className="p-3 bg-white/5 text-center">
            <button 
              onClick={() => {
                if (audioContext && audioContext.state === 'suspended') {
                  audioContext.resume();
                }
              }}
              className="text-[10px] font-black uppercase tracking-widest text-amber-400 hover:text-amber-300 transition-colors flex items-center justify-center gap-1 mx-auto"
            >
              Resume Engine <ChevronRight size={10} />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
