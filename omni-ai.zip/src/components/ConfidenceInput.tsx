import React from 'react';
import { ConfidenceRating } from '../modules/metacognition/types';
import { Sparkles, HelpCircle } from 'lucide-react';
import { cn } from '../lib/utils';

export interface ConfidenceInputProps {
  selectedRating: ConfidenceRating | null;
  onSelectRating: (rating: ConfidenceRating) => void;
  className?: string;
  disabled?: boolean;
}

const CONFIDENCE_OPTIONS: Array<{
  rating: ConfidenceRating;
  label: string;
  emoji: string;
  color: string;
  borderColor: string;
}> = [
  { rating: 1, label: 'Guessing', emoji: '🎲', color: 'bg-slate-500/10 text-slate-600 dark:text-slate-400', borderColor: 'border-slate-300 dark:border-slate-700' },
  { rating: 2, label: 'Unsure', emoji: '🤔', color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400', borderColor: 'border-amber-300 dark:border-amber-700/60' },
  { rating: 3, label: 'Fairly Sure', emoji: '👍', color: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400', borderColor: 'border-cyan-300 dark:border-cyan-700/60' },
  { rating: 4, label: 'Confident', emoji: '💪', color: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400', borderColor: 'border-indigo-300 dark:border-indigo-700/60' },
  { rating: 5, label: 'Certain', emoji: '🎯', color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400', borderColor: 'border-emerald-300 dark:border-emerald-700/60' }
];

export const ConfidenceInput: React.FC<ConfidenceInputProps> = ({
  selectedRating,
  onSelectRating,
  className,
  disabled = false
}) => {
  return (
    <div className={cn("flex flex-col gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800", className)}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300">
          <Sparkles size={13} className="text-indigo-500" />
          <span>How confident are you in this answer? (1-Tap Calibration)</span>
        </div>
        <span className="text-[10px] text-slate-400 flex items-center gap-1">
          <HelpCircle size={11} /> Metacognition Check
        </span>
      </div>

      <div className="grid grid-cols-5 gap-1.5">
        {CONFIDENCE_OPTIONS.map((opt) => {
          const isSelected = selectedRating === opt.rating;
          return (
            <button
              key={opt.rating}
              type="button"
              disabled={disabled}
              onClick={() => onSelectRating(opt.rating)}
              className={cn(
                "flex flex-col items-center justify-center p-2 rounded-lg text-xs font-semibold transition-all duration-150 border cursor-pointer",
                isSelected
                  ? `${opt.color} ${opt.borderColor} ring-2 ring-indigo-500/40 font-bold scale-[1.02] shadow-sm`
                  : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700/70 text-slate-600 dark:text-slate-300 hover:border-indigo-400/60",
                disabled && "opacity-50 cursor-not-allowed"
              )}
            >
              <span className="text-base mb-0.5">{opt.emoji}</span>
              <span className="text-[10px] leading-tight text-center font-bold truncate max-w-full">{opt.label}</span>
              <span className="text-[9px] opacity-60 font-mono">({opt.rating})</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
