import React, { useState, useMemo, useEffect } from 'react';
import { 
  Tag, 
  Search, 
  Copy, 
  Check, 
  Grid, 
  List, 
  LayoutList,
  Sidebar,
  ChevronDown, 
  ChevronUp, 
  MapPin, 
  Sparkles,
  Table as TableIcon,
  HelpCircle,
  Eye,
  Pin
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface AnnotationItem {
  label: string;
  description: string;
  x: number;
  y: number;
  category?: string;
  type?: string;
  [key: string]: any;
}

type LegendLayoutMode = 'grid' | 'list' | 'sidebar' | 'table' | 'compact';

interface DiagramLegendBlockProps {
  msgId: string;
  annotations: AnnotationItem[];
  hoveredAnnoIndex: { msgId: string; index: number } | null;
  onHoverAnno: (index: number | null) => void;
  onSelectAnno?: (anno: AnnotationItem, index: number) => void;
  annoColors?: Record<string, string>;
  colorPresets?: { label: string; bg: string; ring: string; shadow: string }[];
  showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void;
  theme?: 'dark' | 'light';
  topicTitle?: string;
  className?: string;
}

const CATEGORY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  organelle: { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/40' },
  anatomy: { bg: 'bg-rose-500/20', text: 'text-rose-300', border: 'border-rose-500/40' },
  structure: { bg: 'bg-sky-500/20', text: 'text-sky-300', border: 'border-sky-500/40' },
  equation: { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-500/40' },
  variable: { bg: 'bg-amber-500/20', text: 'text-amber-300', border: 'border-amber-500/40' },
  process: { bg: 'bg-indigo-500/20', text: 'text-indigo-300', border: 'border-indigo-500/40' },
  step: { bg: 'bg-teal-500/20', text: 'text-teal-300', border: 'border-teal-500/40' },
  default: { bg: 'bg-indigo-500/20', text: 'text-indigo-300', border: 'border-indigo-500/30' }
};

export const DiagramLegendBlock: React.FC<DiagramLegendBlockProps> = ({
  msgId,
  annotations,
  hoveredAnnoIndex,
  onHoverAnno,
  onSelectAnno,
  annoColors = {},
  colorPresets = [],
  showNotification,
  theme = 'dark',
  topicTitle,
  className
}) => {
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);
  const [isPinned, setIsPinned] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<LegendLayoutMode>('grid');
  const [activeSidebarIndex, setActiveSidebarIndex] = useState<number>(0);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Extract categories dynamically
  const categoriesMap = useMemo(() => {
    const cats = new Map<string, number>();
    annotations.forEach((anno) => {
      const cat = (anno.category || anno.type || 'General Node').toLowerCase().trim();
      cats.set(cat, (cats.get(cat) || 0) + 1);
    });
    return cats;
  }, [annotations]);

  const uniqueCategories = useMemo(() => Array.from(categoriesMap.keys()), [categoriesMap]);

  // Filtered annotations list
  const filteredAnnotations = useMemo(() => {
    return annotations.map((anno, origIndex) => ({ anno, origIndex })).filter(({ anno }) => {
      const cat = (anno.category || anno.type || 'General Node').toLowerCase().trim();
      if (selectedCategory !== 'all' && cat !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchLabel = anno.label.toLowerCase().includes(q);
        const matchDesc = (anno.description || '').toLowerCase().includes(q);
        const matchCat = cat.includes(q);
        const matchIndex = (anno.origIndex ?? 0 + 1).toString().includes(q);
        return matchLabel || matchDesc || matchCat || matchIndex;
      }
      return true;
    });
  }, [annotations, selectedCategory, searchQuery]);

  // Sync sidebar active index when hoveredAnnoIndex changes externally
  useEffect(() => {
    if (hoveredAnnoIndex?.msgId === msgId && typeof hoveredAnnoIndex.index === 'number') {
      const idxInFiltered = filteredAnnotations.findIndex(a => a.origIndex === hoveredAnnoIndex.index);
      if (idxInFiltered !== -1) {
        setActiveSidebarIndex(idxInFiltered);
      }
    }
  }, [hoveredAnnoIndex, msgId, filteredAnnotations]);

  const handleCopyLegend = () => {
    if (!annotations || annotations.length === 0) return;
    
    let text = `🏷️ DIAGRAM LEGEND KEY\n`;
    if (topicTitle) text += `Topic: ${topicTitle}\n`;
    text += `Total Hotspots: ${annotations.length}\n`;
    text += `----------------------------------------\n\n`;

    annotations.forEach((anno, i) => {
      text += `[Node #${i + 1}] ${anno.label}\n`;
      if (anno.category || anno.type) text += `Category: ${anno.category || anno.type}\n`;
      text += `Coordinates: X: ${anno.x}%, Y: ${anno.y}%\n`;
      text += `Description: ${anno.description}\n\n`;
    });

    navigator.clipboard.writeText(text);
    setIsCopied(true);
    showNotification?.('Copied complete diagram legend key to clipboard!', 'success');
    setTimeout(() => setIsCopied(false), 2500);
  };

  if (!annotations || annotations.length === 0) return null;

  return (
    <div className={cn(
      "rounded-2xl border transition-all duration-300 shadow-xl overflow-hidden my-3",
      isPinned && "sticky top-4 z-40 shadow-2xl ring-2 ring-amber-500/60 backdrop-blur-xl bg-slate-900/95",
      theme === 'dark' 
        ? "bg-slate-900/90 border-slate-800 text-slate-100" 
        : "bg-white border-slate-200 text-slate-800 shadow-slate-200/50",
      className
    )}>
      {/* Legend Block Header */}
      <div className={cn(
        "px-4 py-3 flex items-center justify-between border-b flex-wrap gap-2 select-none",
        theme === 'dark' ? "bg-slate-950/70 border-slate-800" : "bg-slate-50 border-slate-200"
      )}>
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <Tag size={15} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                Diagram Legend & Node Key
                <Sparkles size={12} className="text-amber-400 animate-pulse" />
              </h4>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-indigo-950/80 border border-indigo-500/30 text-indigo-300">
                {annotations.length} Nodes
              </span>
              {isPinned && (
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/50 text-amber-300 flex items-center gap-1">
                  <Pin size={10} className="fill-amber-300" />
                  Pinned
                </span>
              )}
            </div>
            <p className="text-[10px] text-slate-400">
              Interactive visual node map derived automatically from diagram metadata
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* View Mode Switcher */}
          <div className="flex items-center p-0.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <button
              onClick={() => setViewMode('grid')}
              className={cn(
                "p-1.5 rounded-md text-[10px] font-bold transition flex items-center gap-1 cursor-pointer",
                viewMode === 'grid' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              )}
              title="Grid Card View"
            >
              <Grid size={12} />
              <span className="hidden sm:inline">Grid</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={cn(
                "p-1.5 rounded-md text-[10px] font-bold transition flex items-center gap-1 cursor-pointer",
                viewMode === 'list' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              )}
              title="Vertical List View (Optimal for mobile)"
            >
              <LayoutList size={12} />
              <span className="hidden sm:inline">List</span>
            </button>
            <button
              onClick={() => setViewMode('sidebar')}
              className={cn(
                "p-1.5 rounded-md text-[10px] font-bold transition flex items-center gap-1 cursor-pointer",
                viewMode === 'sidebar' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              )}
              title="Compact Sidebar Inspector Split View"
            >
              <Sidebar size={12} />
              <span className="hidden sm:inline">Sidebar</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={cn(
                "p-1.5 rounded-md text-[10px] font-bold transition flex items-center gap-1 cursor-pointer",
                viewMode === 'table' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              )}
              title="Spreadsheet Table View"
            >
              <TableIcon size={12} />
              <span className="hidden sm:inline">Table</span>
            </button>
            <button
              onClick={() => setViewMode('compact')}
              className={cn(
                "p-1.5 rounded-md text-[10px] font-bold transition flex items-center gap-1 cursor-pointer",
                viewMode === 'compact' ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
              )}
              title="Compact Tag Strip View"
            >
              <Tag size={12} />
              <span className="hidden sm:inline">Pills</span>
            </button>
          </div>

          {/* Pin Legend Toggle Button */}
          <button
            type="button"
            onClick={() => {
              const next = !isPinned;
              setIsPinned(next);
              showNotification?.(next ? '📌 Diagram Legend pinned to top!' : 'Unpinned Diagram Legend', 'info');
            }}
            className={cn(
              "px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1 border cursor-pointer",
              isPinned
                ? "bg-amber-500 text-slate-950 border-amber-400 font-black shadow-md shadow-amber-500/20"
                : "bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border-slate-700"
            )}
            title={isPinned ? 'Unpin Legend (Allow normal inline scroll)' : 'Pin Legend (Keep sticky top position while scrolling)'}
          >
            <Pin size={12} className={cn(isPinned && "fill-slate-950")} />
            <span>{isPinned ? 'Pinned' : 'Pin Legend'}</span>
          </button>

          {/* Copy Legend Button */}
          <button
            onClick={handleCopyLegend}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-[10px] transition flex items-center gap-1 border border-slate-700 cursor-pointer"
            title="Copy formatted legend key text to clipboard for study notes"
          >
            {isCopied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
            <span>{isCopied ? 'Copied!' : 'Copy Legend'}</span>
          </button>

          {/* Expand/Collapse Toggle */}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer border border-slate-700"
            title={isCollapsed ? 'Expand Legend Block' : 'Collapse Legend Block'}
          >
            {isCollapsed ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
          </button>
        </div>
      </div>

      {/* Main Legend Content Area */}
      {!isCollapsed && (
        <div className="p-3.5 space-y-3">
          {/* Filter Bar: Search and Category Pills */}
          <div className="flex items-center gap-2 flex-wrap justify-between">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[180px] max-w-xs">
              <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Filter legend nodes (e.g. Chloroplast)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-medium"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 hover:text-white font-bold"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1 flex-wrap">
              <button
                onClick={() => setSelectedCategory('all')}
                className={cn(
                  "px-2 py-0.5 rounded-lg text-[10px] font-bold transition cursor-pointer border",
                  selectedCategory === 'all'
                    ? "bg-amber-500 text-slate-950 border-amber-400 font-black shadow-sm"
                    : "bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200"
                )}
              >
                All ({annotations.length})
              </button>
              {uniqueCategories.map((cat) => {
                const count = categoriesMap.get(cat) || 0;
                const catStyle = CATEGORY_COLORS[cat] || CATEGORY_COLORS.default;
                const isSelected = selectedCategory === cat;

                return (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={cn(
                      "px-2 py-0.5 rounded-lg text-[10px] font-bold capitalize transition cursor-pointer border flex items-center gap-1",
                      isSelected
                        ? `${catStyle.bg} ${catStyle.text} ${catStyle.border} ring-1 ring-amber-400`
                        : "bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200"
                    )}
                  >
                    <span>{cat}</span>
                    <span className="opacity-60 text-[9px]">({count})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Zero Results State */}
          {filteredAnnotations.length === 0 && (
            <div className="p-6 text-center rounded-xl bg-slate-950/40 border border-slate-800/80">
              <HelpCircle size={24} className="mx-auto text-slate-500 mb-2" />
              <p className="text-xs font-semibold text-slate-300">No legend items match your filter criteria.</p>
              <button
                onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }}
                className="mt-2 text-[11px] font-bold text-amber-400 hover:underline cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          )}

          {/* VIEW MODE 1: GRID CARDS */}
          {viewMode === 'grid' && filteredAnnotations.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {filteredAnnotations.map(({ anno, origIndex }) => {
                const isHighlighted = hoveredAnnoIndex?.msgId === msgId && hoveredAnnoIndex?.index === origIndex;
                const categoryKey = (anno.category || anno.type || 'General Node').toLowerCase().trim();
                const catStyle = CATEGORY_COLORS[categoryKey] || CATEGORY_COLORS.default;
                const customColorKey = `${msgId}-${origIndex}`;
                const chosenPreset = colorPresets.find(p => p.label === annoColors[customColorKey]) || colorPresets[0];

                return (
                  <div
                    key={origIndex}
                    id={`legend-item-${msgId}-${origIndex}`}
                    onMouseEnter={() => onHoverAnno(origIndex)}
                    onMouseLeave={() => onHoverAnno(null)}
                    onClick={() => onSelectAnno?.(anno, origIndex)}
                    className={cn(
                      "p-3 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col justify-between gap-2 group relative overflow-hidden",
                      isHighlighted
                        ? "bg-amber-500/15 border-amber-500/80 shadow-lg scale-[1.02] ring-1 ring-amber-400/50"
                        : "bg-slate-950/50 border-slate-800 hover:border-indigo-500/50 hover:bg-slate-950/80"
                    )}
                  >
                    {/* Highlight indicator strip */}
                    <div className={cn(
                      "absolute top-0 left-0 right-0 h-0.5 transition-all duration-200",
                      isHighlighted ? "bg-amber-400" : "bg-transparent group-hover:bg-indigo-500/50"
                    )} />

                    {/* Card Top Row */}
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1.5">
                        <div className="flex items-center gap-1.5 min-w-0">
                          {/* Node Number Badge */}
                          <span className={cn(
                            "w-5 h-5 rounded-full text-[10px] font-black font-mono shrink-0 flex items-center justify-center text-white shadow-sm border border-white/20",
                            chosenPreset?.bg || "bg-indigo-600"
                          )}>
                            {origIndex + 1}
                          </span>

                          {/* Node Label */}
                          <h5 className="font-extrabold text-xs text-white truncate group-hover:text-amber-300 transition-colors">
                            {anno.label}
                          </h5>
                        </div>

                        {/* Category Tag */}
                        <span className={cn(
                          "text-[9px] font-extrabold px-1.5 py-0.5 rounded-md uppercase tracking-tight border shrink-0",
                          catStyle.bg, catStyle.text, catStyle.border
                        )}>
                          {categoryKey}
                        </span>
                      </div>

                      {/* Description */}
                      <p className="text-[11px] text-slate-300 leading-relaxed font-normal line-clamp-3">
                        {anno.description}
                      </p>
                    </div>

                    {/* Card Footer */}
                    <div className="pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-[9px] text-slate-400 font-mono">
                      <span className="flex items-center gap-1 text-slate-400">
                        <MapPin size={10} className="text-amber-400" />
                        <span>X: {anno.x}%, Y: {anno.y}%</span>
                      </span>
                      <span className="text-indigo-400 font-bold group-hover:underline">
                        Click to Focus 🔬
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* VIEW MODE 2: VERTICAL LIST (Optimized for Mobile/Small Screens) */}
          {viewMode === 'list' && filteredAnnotations.length > 0 && (
            <div className="flex flex-col gap-2">
              {filteredAnnotations.map(({ anno, origIndex }) => {
                const isHighlighted = hoveredAnnoIndex?.msgId === msgId && hoveredAnnoIndex?.index === origIndex;
                const categoryKey = (anno.category || anno.type || 'General Node').toLowerCase().trim();
                const catStyle = CATEGORY_COLORS[categoryKey] || CATEGORY_COLORS.default;
                const customColorKey = `${msgId}-${origIndex}`;
                const chosenPreset = colorPresets.find(p => p.label === annoColors[customColorKey]) || colorPresets[0];

                return (
                  <div
                    key={origIndex}
                    id={`legend-item-${msgId}-${origIndex}`}
                    onMouseEnter={() => onHoverAnno(origIndex)}
                    onMouseLeave={() => onHoverAnno(null)}
                    onClick={() => onSelectAnno?.(anno, origIndex)}
                    className={cn(
                      "p-3 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group relative overflow-hidden",
                      isHighlighted
                        ? "bg-amber-500/15 border-amber-500/80 shadow-md ring-1 ring-amber-400/50"
                        : "bg-slate-950/50 border-slate-800 hover:border-indigo-500/50 hover:bg-slate-950/80"
                    )}
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <span className={cn(
                        "w-6 h-6 rounded-full text-xs font-black font-mono shrink-0 flex items-center justify-center text-white shadow-sm border border-white/20 mt-0.5",
                        chosenPreset?.bg || "bg-indigo-600"
                      )}>
                        {origIndex + 1}
                      </span>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <h5 className="font-extrabold text-xs text-white group-hover:text-amber-300 transition-colors">
                            {anno.label}
                          </h5>
                          <span className={cn(
                            "text-[9px] font-extrabold px-1.5 py-0.5 rounded-md uppercase tracking-tight border shrink-0",
                            catStyle.bg, catStyle.text, catStyle.border
                          )}>
                            {categoryKey}
                          </span>
                          <span className="text-[9px] font-mono text-slate-400 flex items-center gap-1">
                            <MapPin size={10} className="text-amber-400" />
                            ({anno.x}%, {anno.y}%)
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-relaxed font-normal">
                          {anno.description}
                        </p>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center justify-end border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800/80">
                      <button className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 border border-indigo-500/30 text-indigo-300 hover:text-white text-[10px] font-bold transition flex items-center gap-1 cursor-pointer">
                        <Eye size={12} />
                        <span>Focus Node</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* VIEW MODE 3: COMPACT SIDEBAR INSPECTOR (Split Layout) */}
          {viewMode === 'sidebar' && filteredAnnotations.length > 0 && (() => {
            const activeAnnoObj = filteredAnnotations[activeSidebarIndex] || filteredAnnotations[0];
            if (!activeAnnoObj) return null;
            const { anno: activeAnno, origIndex: activeOrigIndex } = activeAnnoObj;
            const activeCatKey = (activeAnno.category || activeAnno.type || 'General Node').toLowerCase().trim();
            const activeCatStyle = CATEGORY_COLORS[activeCatKey] || CATEGORY_COLORS.default;
            const activeColorKey = `${msgId}-${activeOrigIndex}`;
            const activePreset = colorPresets.find(p => p.label === annoColors[activeColorKey]) || colorPresets[0];

            return (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 rounded-xl border border-slate-800 bg-slate-950/60 p-2.5">
                {/* Left Sidebar List */}
                <div className="md:col-span-1 max-h-[280px] overflow-y-auto pr-1 space-y-1 custom-scrollbar">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-1 mb-1 border-b border-slate-800 flex items-center justify-between">
                    <span>Select Node ({filteredAnnotations.length})</span>
                    <Sidebar size={12} className="text-indigo-400" />
                  </div>
                  {filteredAnnotations.map(({ anno, origIndex }, idx) => {
                    const isSelected = activeSidebarIndex === idx;
                    const isHovered = hoveredAnnoIndex?.msgId === msgId && hoveredAnnoIndex?.index === origIndex;

                    return (
                      <button
                        key={origIndex}
                        onClick={() => {
                          setActiveSidebarIndex(idx);
                          onSelectAnno?.(anno, origIndex);
                        }}
                        onMouseEnter={() => onHoverAnno(origIndex)}
                        onMouseLeave={() => onHoverAnno(null)}
                        className={cn(
                          "w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-2 border cursor-pointer",
                          isSelected
                            ? "bg-amber-500/20 border-amber-400 text-white shadow-sm font-bold"
                            : isHovered
                            ? "bg-slate-900 border-indigo-500/50 text-slate-200"
                            : "bg-slate-900/50 border-slate-800/80 text-slate-300 hover:bg-slate-900 hover:text-white"
                        )}
                      >
                        <span className="w-4 h-4 rounded-full text-[9px] font-mono font-black shrink-0 flex items-center justify-center bg-indigo-600 text-white">
                          {origIndex + 1}
                        </span>
                        <span className="truncate flex-1">{anno.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Right Detail Pane */}
                <div className="md:col-span-2 p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between gap-3 shadow-lg">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-800">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className={cn(
                          "w-6 h-6 rounded-full text-xs font-black font-mono shrink-0 flex items-center justify-center text-white border border-white/20",
                          activePreset?.bg || "bg-indigo-600"
                        )}>
                          {activeOrigIndex + 1}
                        </span>
                        <h4 className="font-extrabold text-sm text-white truncate">
                          {activeAnno.label}
                        </h4>
                      </div>

                      <span className={cn(
                        "text-[9px] font-extrabold px-2 py-0.5 rounded-md uppercase tracking-tight border shrink-0",
                        activeCatStyle.bg, activeCatStyle.text, activeCatStyle.border
                      )}>
                        {activeCatKey}
                      </span>
                    </div>

                    <p className="text-xs text-slate-200 leading-relaxed font-normal mb-3">
                      {activeAnno.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2">
                    <span className="flex items-center gap-1 font-mono text-[10px]">
                      <MapPin size={12} className="text-amber-400" />
                      <span>Position: X: {activeAnno.x}%, Y: {activeAnno.y}%</span>
                    </span>

                    <button
                      onClick={() => onSelectAnno?.(activeAnno, activeOrigIndex)}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition flex items-center gap-1.5 shadow cursor-pointer"
                    >
                      <Eye size={13} />
                      <span>Focus Hotspot 🔬</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* VIEW MODE 2: TABLE */}
          {viewMode === 'table' && filteredAnnotations.length > 0 && (
            <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
              <table className="w-full text-left text-xs text-slate-200">
                <thead className="bg-slate-950 text-[10px] uppercase tracking-wider font-extrabold text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Node #</th>
                    <th className="py-2.5 px-3">Label</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">Position</th>
                    <th className="py-2.5 px-3">Academic Function / Description</th>
                    <th className="py-2.5 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredAnnotations.map(({ anno, origIndex }) => {
                    const isHighlighted = hoveredAnnoIndex?.msgId === msgId && hoveredAnnoIndex?.index === origIndex;
                    const categoryKey = (anno.category || anno.type || 'General Node').toLowerCase().trim();
                    const catStyle = CATEGORY_COLORS[categoryKey] || CATEGORY_COLORS.default;
                    const customColorKey = `${msgId}-${origIndex}`;
                    const chosenPreset = colorPresets.find(p => p.label === annoColors[customColorKey]) || colorPresets[0];

                    return (
                      <tr
                        key={origIndex}
                        onMouseEnter={() => onHoverAnno(origIndex)}
                        onMouseLeave={() => onHoverAnno(null)}
                        onClick={() => onSelectAnno?.(anno, origIndex)}
                        className={cn(
                          "transition-colors cursor-pointer group",
                          isHighlighted 
                            ? "bg-amber-500/20 text-white font-semibold" 
                            : "hover:bg-slate-900/90 text-slate-300"
                        )}
                      >
                        <td className="py-2 px-3 font-mono font-bold whitespace-nowrap">
                          <span className={cn(
                            "w-5 h-5 rounded-full text-[10px] font-black shrink-0 inline-flex items-center justify-center text-white mr-1.5",
                            chosenPreset?.bg || "bg-indigo-600"
                          )}>
                            {origIndex + 1}
                          </span>
                        </td>
                        <td className="py-2 px-3 font-extrabold text-white group-hover:text-amber-300 whitespace-nowrap">
                          {anno.label}
                        </td>
                        <td className="py-2 px-3 whitespace-nowrap">
                          <span className={cn(
                            "text-[9px] font-extrabold px-1.5 py-0.5 rounded-md uppercase tracking-tight border",
                            catStyle.bg, catStyle.text, catStyle.border
                          )}>
                            {categoryKey}
                          </span>
                        </td>
                        <td className="py-2 px-3 font-mono text-[10px] text-slate-400 whitespace-nowrap">
                          {anno.x}%, {anno.y}%
                        </td>
                        <td className="py-2 px-3 text-slate-300 leading-relaxed max-w-md">
                          {anno.description}
                        </td>
                        <td className="py-2 px-3 text-right whitespace-nowrap">
                          <span className="text-[10px] font-bold text-indigo-400 group-hover:text-amber-300">
                            Focus 🔬
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* VIEW MODE 3: COMPACT STRIP */}
          {viewMode === 'compact' && filteredAnnotations.length > 0 && (
            <div className="flex flex-wrap gap-1.5 p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              {filteredAnnotations.map(({ anno, origIndex }) => {
                const isHighlighted = hoveredAnnoIndex?.msgId === msgId && hoveredAnnoIndex?.index === origIndex;
                const customColorKey = `${msgId}-${origIndex}`;
                const chosenPreset = colorPresets.find(p => p.label === annoColors[customColorKey]) || colorPresets[0];

                return (
                  <div
                    key={origIndex}
                    onMouseEnter={() => onHoverAnno(origIndex)}
                    onMouseLeave={() => onHoverAnno(null)}
                    onClick={() => onSelectAnno?.(anno, origIndex)}
                    className={cn(
                      "px-2.5 py-1 rounded-lg text-xs font-bold transition-all duration-150 cursor-pointer flex items-center gap-1.5 border group relative",
                      isHighlighted
                        ? "bg-amber-400 text-slate-950 border-amber-300 shadow-md scale-105"
                        : "bg-slate-900 border-slate-800 text-slate-200 hover:border-indigo-500 hover:text-white"
                    )}
                    title={`#${origIndex + 1} ${anno.label}: ${anno.description}`}
                  >
                    <span className={cn(
                      "w-3.5 h-3.5 rounded-full text-[9px] font-black flex items-center justify-center text-white",
                      chosenPreset?.bg || "bg-indigo-600"
                    )}>
                      {origIndex + 1}
                    </span>
                    <span className="font-extrabold">{anno.label}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
