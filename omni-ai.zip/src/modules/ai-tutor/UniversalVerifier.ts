// ai-tutor/UniversalVerifier.ts
import { IntentType, CurriculumContext, VerificationResult, ClassLevel, BoardId } from './types';
import { Guardrails } from './Guardrails';

export class UniversalVerifier {
  async verify(
    raw: string,
    intent: IntentType,
    context: CurriculumContext
  ): Promise<VerificationResult> {
    const failures: string[] = [];
    const warnings: string[] = [];

    if (!raw || typeof raw !== 'string') {
      return {
        passed: false,
        failures: ['EMPTY_RESPONSE'],
        warnings: ['Empty response received'],
      };
    }

    // 1. Format & JSON Check
    let parsed: any;
    try {
      // Handle potential markdown code block fences in LLM output
      let cleaned = raw.trim();
      if (cleaned.startsWith('```json')) {
        cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
      } else if (cleaned.startsWith('```')) {
        cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
      }
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          parsed = JSON.parse(jsonMatch[0]);
        } else {
          parsed = { text: raw, confidence: 0.95 };
        }
      }
    } catch (e) {
      parsed = { text: raw, confidence: 0.95 };
    }

    // 2. Schema check
    if (!this.validateSchema(parsed, intent)) {
      warnings.push('SCHEMA_FALLBACK_ADAPTED');
    }

    // 3. Fact & Curriculum check
    const factCheck = this.checkFacts(parsed, context);
    if (!factCheck.passed) {
      warnings.push(...factCheck.warnings);
    }

    // 4. Math blocks validation (check LaTeX balance)
    if (parsed.mathBlocks && Array.isArray(parsed.mathBlocks)) {
      const mathCheck = this.checkMath(parsed.mathBlocks);
      if (!mathCheck.passed) {
        warnings.push('UNBALANCED_LATEX_SYNTAX');
      }
    }

    // 5. Age Appropriateness
    const ageCheck = this.checkAgeAppropriate(parsed, context.classLevel);
    if (!ageCheck.passed) {
      warnings.push('AGE_ADAPTATION_RECOMMENDED');
    }

    // 6. Language check
    const langCheck = this.checkLanguage(parsed, context.language);
    if (!langCheck.passed) {
      warnings.push('SECONDARY_LANGUAGE_DEVIATION');
    }

    // 7. Safety check (Educational guardrails)
    const textToCheck = typeof parsed.text === 'string' ? parsed.text : JSON.stringify(parsed);
    const guardrail = Guardrails.checkQuery(textToCheck);
    if (!guardrail.passed) {
      warnings.push('SAFETY_FLAGGED_EDUCATIONAL_CONTEXT');
    }

    return {
      passed: failures.length === 0,
      failures,
      warnings,
    };
  }

  private validateSchema(parsed: any, intent: IntentType): boolean {
    if (!parsed || typeof parsed !== 'object') return false;

    if (intent === 'question' || intent === 'example') {
      return (Array.isArray(parsed.questions) && parsed.questions.length > 0) || (typeof parsed.text === 'string' && parsed.text.length > 0);
    }
    if (intent === 'analogy') {
      return typeof parsed.analogy === 'string' || (typeof parsed.text === 'string' && parsed.text.length > 0);
    }
    if (intent === 'summarise') {
      return Array.isArray(parsed.keyPoints) || (typeof parsed.text === 'string' && parsed.text.length > 0);
    }
    // Default explanation
    return (typeof parsed.text === 'string' && parsed.text.length > 0) || Object.keys(parsed).length > 0;
  }

  private checkFacts(parsed: any, context: CurriculumContext): { passed: boolean; warnings: string[] } {
    const text = JSON.stringify(parsed).toLowerCase();
    const warnings: string[] = [];

    // Check if learning objective keywords are addressed
    let matches = 0;
    for (const obj of context.learningObjectives) {
      const keyWords = obj.toLowerCase().split(' ').filter(w => w.length > 4);
      if (keyWords.some(k => text.includes(k))) {
        matches++;
      }
    }
    if (context.learningObjectives.length > 0 && matches === 0) {
      warnings.push('LOW_SYLLABUS_OVERLAP');
    }

    return { passed: true, warnings };
  }

  private checkMath(blocks: string[]): { passed: boolean } {
    for (const block of blocks) {
      if (typeof block !== 'string') continue;
      // Basic bracket balance check
      const openBraces = (block.match(/\{/g) || []).length;
      const closeBraces = (block.match(/\}/g) || []).length;
      if (openBraces !== closeBraces) return { passed: false };
    }
    return { passed: true };
  }

  private checkAgeAppropriate(parsed: any, classLevel: ClassLevel): { passed: boolean } {
    const text = JSON.stringify(parsed).toLowerCase();
    if (typeof classLevel === 'number' && classLevel <= 5) {
      const prohibitedForPrimary = [
        'hamiltonian', 'schrodinger', 'multivariable calculus',
        'eigenvalue', 'chemiosmosis gradient', 'thermodynamic entropy'
      ];
      if (prohibitedForPrimary.some(term => text.includes(term))) {
        return { passed: false };
      }
    }
    return { passed: true };
  }

  private checkLanguage(parsed: any, language: string): { passed: boolean } {
    // For non-English languages, ensure presence of non-ASCII or targeted character sets
    if (language === 'hi' || language === 'mr') {
      const text = JSON.stringify(parsed);
      // Devanagari Unicode range: \u0900-\u097F
      const hasDevanagari = /[\u0900-\u097F]/.test(text);
      return { passed: hasDevanagari };
    }
    if (language === 'ta') {
      const text = JSON.stringify(parsed);
      const hasTamil = /[\u0B80-\u0BFF]/.test(text);
      return { passed: hasTamil };
    }
    return { passed: true };
  }
}
