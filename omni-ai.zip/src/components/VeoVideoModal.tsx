import React, { useState, useEffect } from 'react';
import { Video, Film, Image as ImageIcon, Sparkles, Download, Share2, X, Play, Loader2, CheckCircle2, Ratio, Trash2 } from 'lucide-react';
import { generateVideo } from '../lib/gemini';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, query, where, getDocs, orderBy, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';

interface VeoVideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  showNotification?: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  initialPrompt?: string;
  initialImageBase64?: string;
}

export interface SavedVeoVideo {
  id?: string;
  userId?: string;
  title: string;
  prompt: string;
  videoUri: string;
  aspectRatio: '16:9' | '9:16';
  hasImageInput: boolean;
  createdAt?: any;
}

export const VeoVideoModal: React.FC<VeoVideoModalProps> = ({
  isOpen,
  onClose,
  showNotification,
  initialPrompt = '',
  initialImageBase64 = ''
}) => {
  const [activeTab, setActiveTab] = useState<'text-to-video' | 'image-to-video' | 'gallery'>('text-to-video');
  const [prompt, setPrompt] = useState<string>(initialPrompt || '3D animated scientific simulation of DNA double helix transcription');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [uploadedImageBase64, setUploadedImageBase64] = useState<string>(initialImageBase64);
  const [uploadedImageMimeType, setUploadedImageMimeType] = useState<string>('image/png');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedVideoUri, setGeneratedVideoUri] = useState<string | null>(null);
  const [savedVideos, setSavedVideos] = useState<SavedVeoVideo[]>([]);
  const [isLoadingGallery, setIsLoadingGallery] = useState<boolean>(false);

  useEffect(() => {
    if (initialImageBase64) {
      setUploadedImageBase64(initialImageBase64);
      setActiveTab('image-to-video');
    }
  }, [initialImageBase64]);

  useEffect(() => {
    if (isOpen) {
      loadSavedVideos();
    }
  }, [isOpen]);

  const loadSavedVideos = async () => {
    if (!auth.currentUser) return;
    setIsLoadingGallery(true);
    try {
      const q = query(
        collection(db, 'ai_generated_videos'),
        where('userId', '==', auth.currentUser.uid),
        orderBy('createdAt', 'desc')
      );
      const querySnapshot = await getDocs(q);
      const videos: SavedVeoVideo[] = [];
      querySnapshot.forEach((docSnap) => {
        videos.push({ id: docSnap.id, ...docSnap.data() } as SavedVeoVideo);
      });
      setSavedVideos(videos);
    } catch (err) {
      console.warn("Could not fetch saved videos from Firestore:", err);
    } finally {
      setIsLoadingGallery(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const mimeType = file.type || 'image/png';
    setUploadedImageMimeType(mimeType);
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImageBase64(reader.result as string);
      showNotification?.(`Loaded image: ${file.name}`, 'info');
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      showNotification?.("Please enter a description prompt for Veo 3 video generation", "warning");
      return;
    }

    setIsGenerating(true);
    setGeneratedVideoUri(null);
    showNotification?.(`Starting Veo 3 AI Video Generation (${aspectRatio})...`, "info");

    try {
      const videoUri = await generateVideo(prompt, {
        aspectRatio,
        imageBase64: activeTab === 'image-to-video' ? uploadedImageBase64 : undefined,
        imageMimeType: uploadedImageMimeType
      });

      if (videoUri) {
        setGeneratedVideoUri(videoUri);
        showNotification?.("Veo 3 Video generated successfully!", "success");

        // Save to Firestore if user is authenticated
        if (auth.currentUser) {
          try {
            const videoData = {
              userId: auth.currentUser.uid,
              title: prompt.slice(0, 60),
              prompt,
              videoUri,
              aspectRatio,
              hasImageInput: activeTab === 'image-to-video' && !!uploadedImageBase64,
              createdAt: serverTimestamp()
            };
            const docRef = await addDoc(collection(db, 'ai_generated_videos'), videoData);
            setSavedVideos(prev => [{ id: docRef.id, ...videoData }, ...prev]);
            showNotification?.("Saved video to your Firestore library!", "success");
          } catch (fsErr) {
            console.error("Failed to save video to Firestore:", fsErr);
          }
        }
      } else {
        showNotification?.("Video generation did not return a valid video stream.", "error");
      }
    } catch (err: any) {
      console.error("Veo video generation error:", err);
      showNotification?.("Veo video generation error: " + (err.message || String(err)), "error");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDeleteSavedVideo = async (id?: string) => {
    if (!id || !auth.currentUser) return;
    try {
      await deleteDoc(doc(db, 'ai_generated_videos', id));
      setSavedVideos(prev => prev.filter(v => v.id !== id));
      showNotification?.("Video removed from Firestore library", "info");
    } catch (err) {
      console.error("Failed to delete video:", err);
      handleFirestoreError(err, OperationType.DELETE, `ai_generated_videos/${id}`);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[2200] flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="w-full max-w-4xl max-h-[92vh] bg-slate-900 border border-indigo-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-100">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/90 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
              <Film size={20} className="text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-wide text-white">Veo 3 AI Video Generations</h2>
                <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-purple-500/20 to-indigo-500/20 text-purple-300 text-[10px] font-black border border-purple-400/40 uppercase">
                  veo-3.1-fast-generate-preview
                </span>
              </div>
              <p className="text-xs text-slate-400">Generate high-definition educational videos from text or animate photos into video</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-2 bg-slate-950/60 border-b border-slate-800 shrink-0 overflow-x-auto">
          <button
            onClick={() => setActiveTab('text-to-video')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'text-to-video'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Video size={14} />
            <span>Generate Video from Text</span>
          </button>
          <button
            onClick={() => setActiveTab('image-to-video')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'image-to-video'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <ImageIcon size={14} />
            <span>Animate Photo into Video</span>
          </button>
          <button
            onClick={() => { setActiveTab('gallery'); loadSavedVideos(); }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'gallery'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Film size={14} />
            <span>Saved Video Library ({savedVideos.length})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 flex flex-col gap-5">
          {activeTab !== 'gallery' ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
              {/* Controls Column */}
              <div className="flex flex-col gap-4">
                {activeTab === 'image-to-video' && (
                  <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col gap-3">
                    <label className="text-xs font-extrabold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                      <ImageIcon size={14} />
                      <span>Upload Photo to Animate</span>
                    </label>

                    {uploadedImageBase64 ? (
                      <div className="relative rounded-xl overflow-hidden border border-purple-500/40 max-h-48 group">
                        <img src={uploadedImageBase64} alt="Upload preview" className="w-full h-full object-cover" />
                        <button
                          onClick={() => setUploadedImageBase64('')}
                          className="absolute top-2 right-2 p-1.5 rounded-lg bg-red-600/90 hover:bg-red-500 text-white text-xs font-bold shadow"
                        >
                          Change Photo
                        </button>
                      </div>
                    ) : (
                      <label className="border-2 border-dashed border-slate-700 hover:border-purple-500 rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all bg-slate-900/60 hover:bg-slate-900">
                        <ImageIcon size={28} className="text-purple-400 mb-2" />
                        <span className="text-xs font-bold text-slate-200">Click to select photo / image</span>
                        <span className="text-[10px] text-slate-400 mt-1">PNG, JPG, WebP supported</span>
                        <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                      </label>
                    )}
                  </div>
                )}

                {/* Prompt Input */}
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-extrabold uppercase tracking-wider text-indigo-300 flex items-center justify-between">
                    <span>{activeTab === 'image-to-video' ? 'Animation Description Prompt' : 'Veo 3 Video Description Prompt'}</span>
                    <span className="text-[10px] text-slate-400 font-mono">Model: veo-3.1-fast-generate-preview</span>
                  </label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    rows={3}
                    placeholder={activeTab === 'image-to-video' ? 'Describe how this photo should move, zoom, or animate...' : 'Describe the video you want Veo 3 to generate...'}
                    className="w-full p-3.5 rounded-2xl bg-slate-950 border border-slate-700 focus:border-indigo-500 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 resize-none"
                  />
                </div>

                {/* Aspect Ratio Selector (16:9 landscape vs 9:16 portrait) */}
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-extrabold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5">
                    <Ratio size={14} />
                    <span>Aspect Ratio</span>
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setAspectRatio('16:9')}
                      className={`p-3 rounded-2xl border text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
                        aspectRatio === '16:9'
                          ? 'bg-indigo-600/30 border-indigo-400 text-indigo-200 shadow-md ring-2 ring-indigo-400/40'
                          : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <span className="w-5 h-3 border-2 border-indigo-300 rounded-sm"></span>
                      <span>16:9 Landscape</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setAspectRatio('9:16')}
                      className={`p-3 rounded-2xl border text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
                        aspectRatio === '9:16'
                          ? 'bg-indigo-600/30 border-indigo-400 text-indigo-200 shadow-md ring-2 ring-indigo-400/40'
                          : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <span className="w-3 h-5 border-2 border-indigo-300 rounded-sm"></span>
                      <span>9:16 Portrait</span>
                    </button>
                  </div>
                </div>

                {/* Action Button */}
                <button
                  onClick={handleGenerate}
                  disabled={isGenerating || (activeTab === 'image-to-video' && !uploadedImageBase64)}
                  className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-purple-600/25 transition-all cursor-pointer active:scale-95"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 size={18} className="animate-spin" />
                      <span>Generating with Veo 3...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles size={18} className="text-amber-300" />
                      <span>{activeTab === 'image-to-video' ? 'Animate Photo with Veo 3' : 'Generate Veo 3 Video'}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Video Player Column */}
              <div className="flex flex-col gap-3 bg-slate-950/90 border border-slate-800 rounded-3xl p-4 min-h-[320px] justify-center items-center relative overflow-hidden">
                {isGenerating ? (
                  <div className="flex flex-col items-center justify-center p-8 text-center gap-3">
                    <Loader2 size={36} className="text-purple-400 animate-spin" />
                    <span className="text-sm font-bold text-slate-200">Veo 3 AI Video Generation in Progress...</span>
                    <span className="text-xs text-slate-400 max-w-xs">Applying neural frame synthesis with aspect ratio {aspectRatio}...</span>
                  </div>
                ) : generatedVideoUri ? (
                  <div className="w-full flex flex-col gap-3">
                    <div className="flex items-center justify-between text-xs font-extrabold text-emerald-400">
                      <span className="flex items-center gap-1">
                        <CheckCircle2 size={14} />
                        <span>Veo 3 Video Generated</span>
                      </span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-mono">
                        {aspectRatio}
                      </span>
                    </div>

                    <div className="relative rounded-2xl overflow-hidden bg-black border border-indigo-500/40 shadow-2xl flex items-center justify-center">
                      <video
                        src={generatedVideoUri}
                        controls
                        autoPlay
                        loop
                        className={`w-full ${aspectRatio === '9:16' ? 'max-h-[460px] object-contain' : 'aspect-video object-cover'}`}
                      />
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-1">
                      <a
                        href={generatedVideoUri}
                        download="veo3-video.mp4"
                        target="_blank"
                        rel="noreferrer"
                        className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Download size={14} />
                        <span>Download MP4</span>
                      </a>

                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(generatedVideoUri);
                          showNotification?.("Video link copied to clipboard!", "success");
                        }}
                        className="px-4 py-2 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-400/40 text-indigo-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Share2 size={14} />
                        <span>Copy Link</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center p-8 text-center gap-3 text-slate-500">
                    <Film size={42} className="text-slate-700 mb-1" />
                    <span className="text-sm font-bold text-slate-300">No Video Generated Yet</span>
                    <span className="text-xs text-slate-400 max-w-xs">
                      Enter a prompt or upload a photo to generate an HD video with model <code className="text-purple-300">veo-3.1-fast-generate-preview</code>
                    </span>
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* Saved Video Library Tab */
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                <span>Stored in Firestore Database ({savedVideos.length} videos)</span>
                {auth.currentUser ? (
                  <span className="text-emerald-400 font-mono text-[11px]">Logged in as: {auth.currentUser.email || auth.currentUser.uid}</span>
                ) : (
                  <span className="text-amber-400 text-[11px]">Log in with Google to sync videos to Firestore</span>
                )}
              </div>

              {isLoadingGallery ? (
                <div className="flex items-center justify-center p-12 text-slate-400 text-sm gap-2">
                  <Loader2 size={18} className="animate-spin" />
                  <span>Loading video gallery from Firestore...</span>
                </div>
              ) : savedVideos.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {savedVideos.map((video) => (
                    <div key={video.id} className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-indigo-500/40 transition-all flex flex-col gap-2.5 group">
                      <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center border border-slate-800">
                        <video src={video.videoUri} controls className="w-full h-full object-cover" />
                        <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-[9px] font-mono text-indigo-300 border border-white/20">
                          {video.aspectRatio || '16:9'}
                        </span>
                      </div>

                      <div className="flex flex-col gap-1 min-w-0">
                        <h4 className="text-xs font-bold text-slate-200 truncate" title={video.prompt}>
                          {video.title || video.prompt}
                        </h4>
                        <span className="text-[10px] text-slate-400 truncate">{video.prompt}</span>
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                        <a
                          href={video.videoUri}
                          download="veo3-saved-video.mp4"
                          target="_blank"
                          rel="noreferrer"
                          className="text-[11px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                        >
                          <Download size={12} />
                          <span>Download</span>
                        </a>

                        <button
                          onClick={() => handleDeleteSavedVideo(video.id)}
                          className="p-1 rounded text-slate-500 hover:text-red-400 transition-colors"
                          title="Delete from Firestore"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center p-12 border border-dashed border-slate-800 rounded-3xl text-center text-slate-500 gap-2">
                  <Film size={36} className="text-slate-700" />
                  <span className="text-xs font-bold text-slate-300">Your video library is empty</span>
                  <span className="text-[11px] text-slate-400">Generate a video above and it will be saved to your Firestore database.</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
