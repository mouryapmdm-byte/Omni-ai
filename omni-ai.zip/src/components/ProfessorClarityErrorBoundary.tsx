// src/components/ProfessorClarityErrorBoundary.tsx
/**
 * Professor Clarity Observability Infrastructure - Error Boundary
 * Part 2.3: Production-Grade Error Boundary with Automated Diagnosed Recovery
 */

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { logger } from '../logging/logger';
import { PLAYBOOKS, executeRecovery } from '../recovery/playbooks';
import { safeMode } from '../recovery/safe-mode';
import { AlertTriangle, RefreshCw, ShieldCheck, Sparkles, Activity } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  componentName?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  isRecovering: boolean;
  recoveryAttempts: number;
}

export class ProfessorClarityErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    isRecovering: false,
    recoveryAttempts: 0,
  };

  private unmountTimer: any = null;

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    const comp = this.props.componentName || 'UnknownComponent';
    logger.error('ErrorBoundary', `Component error intercepted in [${comp}]`, {
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
    });

    this.setState({ errorInfo, isRecovering: true });
    this.attemptAutoRecovery(error);
    this.props.onError?.(error, errorInfo);
  }

  componentWillUnmount() {
    if (this.unmountTimer) clearTimeout(this.unmountTimer);
  }

  private async attemptAutoRecovery(error: Error) {
    const playbook = PLAYBOOKS.find(p => p.trigger(error));
    if (playbook) {
      logger.info('ErrorBoundary', `Applying matching playbook [${playbook.id}] to auto-heal component`);
      const recovered = await executeRecovery(playbook, error);
      if (recovered) {
        logger.info('ErrorBoundary', 'Auto-recovery verified. Restoring component tree...');
        this.unmountTimer = setTimeout(() => {
          this.setState({
            hasError: false,
            error: null,
            errorInfo: null,
            isRecovering: false,
            recoveryAttempts: this.state.recoveryAttempts + 1,
          });
        }, 150);
        return;
      }
    }

    // If no playbook or recovery failed, toggle safe mode
    safeMode.activate(`Component [${this.props.componentName || 'Slate'}] error fallback`);
    this.setState({ isRecovering: false });
  }

  private handleManualRetry = () => {
    this.setState({ hasError: false, error: null, errorInfo: null, isRecovering: false });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;

      // Student-friendly, non-intrusive self-healing view
      return (
        <div className="min-h-[220px] w-full bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-3xl p-6 flex flex-col items-center justify-center text-center text-slate-100 font-sans shadow-xl my-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 flex items-center justify-center mb-4">
            {this.state.isRecovering ? (
              <Activity className="w-6 h-6 animate-pulse text-indigo-400" />
            ) : (
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
            )}
          </div>

          <h3 className="text-base font-bold text-white mb-1.5 flex items-center gap-2">
            <span>{this.state.isRecovering ? 'Professor Clarity Auto-Healing Active' : 'Self-Healing Shield Engaged'}</span>
            <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-bold">
              Autonomous Recovery
            </span>
          </h3>

          <p className="text-xs text-slate-400 max-w-md mb-4 leading-relaxed">
            {this.state.isRecovering
              ? 'Executing autonomous diagnostic playbook to restore smooth interactive teaching without losing lecture state...'
              : 'Classroom Slate has stabilized the view in Safe Mode. Your lecture notes and progress remain preserved.'}
          </p>

          <div className="flex items-center gap-2.5">
            <button
              onClick={this.handleManualRetry}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-md shadow-indigo-600/20 cursor-pointer"
            >
              <RefreshCw size={13} />
              <span>Resume Full Lecture</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
