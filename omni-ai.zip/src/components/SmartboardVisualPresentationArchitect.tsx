import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Sparkles, Layers, Sliders, CheckCircle2, AlertTriangle, 
  HelpCircle, ChevronRight, ChevronLeft, RotateCcw, Flame, 
  Trophy, Award, Zap, Target, BookOpen, Clock, Eye, 
  Maximize2, Minimize2, Split, Trash2, ArrowRight, Play, 
  Volume2, Check, RefreshCw, X, ShieldCheck
} from 'lucide-react';
import { cn } from '../lib/utils';
import { 
  PresentationMode, 
  FormulaMasteryDeck, 
  FormulaQuestionItem, 
  MasteryBadge 
} from '../types/visualPresentationArchitect';
import { 
  CURATED_FORMULA_DECKS, 
  CURATED_MASTERY_BADGES, 
  visualPresentationDataService 
} from '../services/visualPresentationDataService';

interface SmartboardVisualPresentationArchitectProps {
  initialDeckId?: string;
  onDeliverToSmartboard?: (markdown: string, title: string) => void;
  onSpeak?: (text: string) => void;
  showNotification?: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  isCompactOverlay?: boolean;
}

export const SmartboardVisualPresentationArchitect: React.FC<SmartboardVisualPresentationArchitectProps> = ({
  initialDeckId = 'newton_second_law',
  onDeliverToSmartboard,
  onSpeak,
  showNotification,
  isCompactOverlay = false
}) => {
  // Active Deck Selection
  const [selectedDeckId, setSelectedDeckId] = useState<string>(initialDeckId);
  const currentDeck: FormulaMasteryDeck = useMemo(() => {
    return visualPresentationDataService.getDeckById(selectedDeckId);
  }, [selectedDeckId]);

  // Presentation Mode: standard_optimized | split_screen | focus_formula | focus_question | focus_solution | focus_mastery
  const [presentationMode, setPresentationMode] = useState<PresentationMode>('standard_optimized');

  // Question & Navigation State
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [revealedStepCount, setRevealedStepCount] = useState<number>(0);
  
  // Progress & Game Mechanics
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [highestStreak, setHighestStreak] = useState<number>(0);
  const [questionResults, setQuestionResults] = useState<Record<string, boolean>>({});
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>([]);
  const [isCelebrating, setIsCelebrating] = useState<boolean>(false);

  // Auto-Clean Board State
  const [isBoardCleaning, setIsBoardCleaning] = useState<boolean>(false);
  const [isSmartRetentionActive, setIsSmartRetentionActive] = useState<boolean>(true);

  // Countdown Timer
  const activeQuestion: FormulaQuestionItem | undefined = currentDeck.questions[currentQuestionIndex];
  const [timeLeft, setTimeLeft] = useState<number>(activeQuestion?.timeAllottedSeconds || 45);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);

  // Reset timer on question change
  useEffect(() => {
    if (activeQuestion) {
      setTimeLeft(activeQuestion.timeAllottedSeconds);
      setSelectedOptionId(null);
      setIsAnswerSubmitted(false);
      setRevealedStepCount(presentationMode === 'focus_solution' ? 1 : 4);
      setIsTimerRunning(true);
    }
  }, [currentQuestionIndex, selectedDeckId, presentationMode]);

  // Timer Tick
  useEffect(() => {
    if (!isTimerRunning || isAnswerSubmitted || timeLeft <= 0) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setIsTimerRunning(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isTimerRunning, isAnswerSubmitted, timeLeft]);

  // Badge Checker
  useEffect(() => {
    const newBadges: string[] = [...unlockedBadges];
    CURATED_MASTERY_BADGES.forEach(badge => {
      if (badge.unlockedAtStreak && streak >= badge.unlockedAtStreak && !newBadges.includes(badge.id)) {
        newBadges.push(badge.id);
        showNotification?.(`Achievement Unlocked: ${badge.title}! ${badge.icon}`, 'success');
      }
      if (badge.unlockedAtScore && score >= badge.unlockedAtScore && !newBadges.includes(badge.id)) {
        newBadges.push(badge.id);
        showNotification?.(`Achievement Unlocked: ${badge.title}! ${badge.icon}`, 'success');
      }
    });
    if (newBadges.length !== unlockedBadges.length) {
      setUnlockedBadges(newBadges);
    }
  }, [streak, score, unlockedBadges, showNotification]);

  // Handle Option Selection
  const handleSelectOption = (optionId: string) => {
    if (isAnswerSubmitted) return;
    setSelectedOptionId(optionId);
  };

  // Submit Answer
  const handleSubmitAnswer = () => {
    if (!activeQuestion || !selectedOptionId || isAnswerSubmitted) return;
    setIsAnswerSubmitted(true);
    setIsTimerRunning(false);

    const chosen = activeQuestion.options.find(o => o.id === selectedOptionId);
    const isCorrect = Boolean(chosen?.isCorrect);

    setQuestionResults(prev => ({ ...prev, [activeQuestion.id]: isCorrect }));

    if (isCorrect) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      if (newStreak > highestStreak) setHighestStreak(newStreak);
      setScore(prev => prev + 1);
      showNotification?.(`Correct! ${activeQuestion.finalAnswer}`, 'success');
      
      const speechText = activeQuestion.conversationalFeedbackSuccess || 
        `Exactly! The answer is ${activeQuestion.finalAnswer}. You're connecting visuals to formulas!`;
      if (onSpeak) onSpeak(speechText);
    } else {
      setStreak(0);
      showNotification?.(`Let's check that step together. Answer: ${activeQuestion.finalAnswer}`, 'warning');
      
      const speechText = activeQuestion.conversationalFeedbackError || 
        `Let me check your working. The answer is ${activeQuestion.finalAnswer}. Let's examine where the mistake happened step by step.`;
      if (onSpeak) onSpeak(speechText);
    }

    // Auto expand solution steps
    setRevealedStepCount(activeQuestion.solutionSteps.length);
  };

  // Auto-Clean Board Action
  const handleAutoCleanBoard = () => {
    setIsBoardCleaning(true);
    showNotification?.("Cleaning Smartboard clutter... Preserving active formula & key context.", 'info');
    setTimeout(() => {
      setSelectedOptionId(null);
      setIsAnswerSubmitted(false);
      setRevealedStepCount(0);
      setIsBoardCleaning(false);
      showNotification?.("Smartboard Refreshed & Optimised!", 'success');
    }, 500);
  };

  // Next Question with smooth transition
  const handleNextQuestion = () => {
    if (currentQuestionIndex < currentDeck.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setPresentationMode('focus_mastery');
      setIsCelebrating(true);
      setTimeout(() => setIsCelebrating(false), 3000);
      showNotification?.("Formula Practice Completed! Outstanding Work!", 'success');
    }
  };

  // Previous Question
  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  // Deliver to 3D Classroom Smartboard Action
  const handleDeliverToSmartboard = () => {
    if (!onDeliverToSmartboard || !activeQuestion) return;

    const formattedMarkdown = `
# 📐 ${currentDeck.formulaTitle}
## Formula: $${currentDeck.formulaLatex}$

### Key Variables
${currentDeck.variables.map(v => `- **${v.symbol}**: ${v.name} (${v.unit}) [${v.dimension || 'SI'}]`).join('\n')}

---

### ❓ Question (${currentQuestionIndex + 1} of ${currentDeck.questions.length})
**${activeQuestion.prompt}**
- Difficulty: **${activeQuestion.difficulty}** | Time: ${activeQuestion.timeAllottedSeconds}s

${activeQuestion.options.map((opt, i) => `${String.fromCharCode(65 + i)}) ${opt.text} ${opt.isCorrect ? '✅' : ''}`).join('\n')}

---

### 📝 Step-by-Step Model Solution
${activeQuestion.solutionSteps.map(s => `**${s.label}**\n$$${s.mathLatex}$$\n*${s.explanation}*`).join('\n\n')}

**✅ Final Answer:** ${activeQuestion.finalAnswer}

💡 **Examiner Tip:** ${activeQuestion.examinerTip}
⚠️ **Common Trap:** ${activeQuestion.commonTrapAvoidance}
    `.trim();

    onDeliverToSmartboard(formattedMarkdown, `${currentDeck.topic} • Practice Session`);
    showNotification?.(`Delivered ${currentDeck.formulaTitle} to 3D Smartboard!`, 'success');
  };

  // Calculations for Progress Indicators
  const completedCount = Object.keys(questionResults).length;
  const progressPercent = Math.round((completedCount / currentDeck.questions.length) * 100);
  const masteryProgress = visualPresentationDataService.calculateFormulaMasteryProgress(currentDeck.id, questionResults);

  return (
    <div className={cn(
      "w-full rounded-2xl bg-slate-950 text-slate-100 flex flex-col overflow-hidden border border-indigo-500/30 shadow-2xl transition-all duration-500",
      isCompactOverlay ? "p-3 space-y-3" : "p-4 sm:p-6 space-y-4"
    )}>
      
      {/* HEADER CONTROLS BAR */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        
        {/* Topic & Deck Picker */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/40">
            <Layers size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 uppercase font-bold">
                {currentDeck.subject}
              </span>
              <h2 className="text-base sm:text-lg font-black text-white tracking-wide">
                {currentDeck.formulaTitle}
              </h2>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Formula: {currentDeck.formulaLatex}
            </p>
          </div>
        </div>

        {/* Deck Selector Dropdown */}
        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={selectedDeckId}
            onChange={(e) => {
              setSelectedDeckId(e.target.value);
              setCurrentQuestionIndex(0);
            }}
            className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bold text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            {CURATED_FORMULA_DECKS.map(deck => (
              <option key={deck.id} value={deck.id}>
                {deck.subject}: {deck.topic} ({deck.formulaLatex})
              </option>
            ))}
          </select>

          {/* Presentation Mode Switcher (Zero extra button friction - integrated smoothly) */}
          <div className="flex items-center bg-slate-900 border border-slate-700 rounded-xl p-0.5">
            <button
              onClick={() => setPresentationMode('standard_optimized')}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                presentationMode === 'standard_optimized' ? "bg-indigo-600 text-white shadow-sm" : "text-slate-400 hover:text-white"
              )}
              title="Optimised 30/25/25/15/5 Smartboard Layout"
            >
              <Layers size={12} />
              <span className="hidden sm:inline">Optimised</span>
            </button>
            <button
              onClick={() => setPresentationMode('split_screen')}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                presentationMode === 'split_screen' ? "bg-cyan-600 text-white shadow-sm" : "text-slate-400 hover:text-white"
              )}
              title="Split Screen: Formula Left + Question Right"
            >
              <Split size={12} />
              <span className="hidden sm:inline">Split Screen</span>
            </button>
            <button
              onClick={() => setPresentationMode('focus_formula')}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                presentationMode === 'focus_formula' ? "bg-blue-600 text-white shadow-sm" : "text-slate-400 hover:text-white"
              )}
              title="Formula Focus Mode (80% Board)"
            >
              <BookOpen size={12} />
              <span className="hidden md:inline">Formula Focus</span>
            </button>
            <button
              onClick={() => setPresentationMode('focus_question')}
              className={cn(
                "px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1",
                presentationMode === 'focus_question' ? "bg-amber-600 text-white shadow-sm" : "text-slate-400 hover:text-white"
              )}
              title="Question Focus Mode"
            >
              <Target size={12} />
              <span className="hidden md:inline">Question Focus</span>
            </button>
          </div>

          {/* Auto-Clean Board Button */}
          <button
            onClick={handleAutoCleanBoard}
            className="p-1.5 sm:px-2.5 sm:py-1 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-rose-400 text-xs font-bold flex items-center gap-1 transition-all cursor-pointer shadow-sm"
            title="Auto-Clean Board: Retain formula, clear solved steps with smooth cross-fade"
          >
            <Trash2 size={13} />
            <span className="hidden sm:inline">Clean Board</span>
          </button>

          {/* Deliver to 3D Smartboard Button */}
          {onDeliverToSmartboard && (
            <button
              onClick={handleDeliverToSmartboard}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-emerald-500/20"
              title="Deliver this complete formula & question presentation to 3D Classroom Smartboard"
            >
              <Sparkles size={13} className="text-amber-300" />
              <span>Deliver to 3D Board</span>
            </button>
          )}
        </div>
      </div>

      {/* AUTO-CLEAN BOARD CROSS-FADE WRAPPER */}
      <div className={cn(
        "transition-opacity duration-300 space-y-4",
        isBoardCleaning ? "opacity-0 scale-[0.99]" : "opacity-100 scale-100"
      )}>

        {/* ========================================================================= */}
        {/* MODE 1: SPLIT SCREEN MODE (Formula on Left, Question & Options on Right) */}
        {/* ========================================================================= */}
        {presentationMode === 'split_screen' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            
            {/* Left Column: 📐 Formula Zone */}
            <div className="lg:col-span-5 p-4 rounded-2xl bg-slate-900/90 border-2 border-[#4A90D9]/50 shadow-lg space-y-3">
              <div className="flex items-center justify-between border-b border-[#4A90D9]/30 pb-2">
                <span className="text-xs font-black uppercase tracking-wider text-[#4A90D9] flex items-center gap-1.5">
                  📐 Formula Zone (Reference)
                </span>
                <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded">
                  Active
                </span>
              </div>

              {/* Big Math Display */}
              <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 text-center">
                <div className="text-2xl sm:text-3xl font-black text-[#4A90D9] font-mono tracking-wider">
                  {currentDeck.formulaLatex}
                </div>
                {currentDeck.expandedFormulaLatex && (
                  <div className="text-xs text-slate-400 font-mono mt-1">
                    {currentDeck.expandedFormulaLatex}
                  </div>
                )}
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {currentDeck.derivationSummary}
              </p>

              {/* Key Variables List */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                  Key Variables & SI Units:
                </span>
                <div className="space-y-1">
                  {currentDeck.variables.map(v => (
                    <div key={v.symbol} className="text-xs p-1.5 rounded-lg bg-slate-950/70 border border-slate-800/80 flex items-center justify-between">
                      <span className="font-mono text-cyan-300 font-bold">{v.symbol} = {v.name}</span>
                      <span className="text-[10px] font-mono text-slate-400">{v.unit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: ❓ Question & Interactive Solver */}
            <div className="lg:col-span-7 space-y-3">
              {activeQuestion && (
                <div className="p-4 rounded-2xl bg-slate-900/90 border-2 border-indigo-500/40 shadow-lg space-y-3">
                  
                  {/* Question Header */}
                  <div className="flex items-center justify-between border-b border-indigo-500/30 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black uppercase tracking-wider text-indigo-400">
                        ❓ Q{activeQuestion.questionNumber} of {activeQuestion.totalQuestions}
                      </span>
                      <span className={cn(
                        "text-[10px] font-bold px-2 py-0.5 rounded-full border",
                        activeQuestion.difficulty === 'Easy' ? "bg-emerald-950 text-emerald-300 border-emerald-700" :
                        activeQuestion.difficulty === 'Medium' ? "bg-amber-950 text-amber-300 border-amber-700" :
                        "bg-rose-950 text-rose-300 border-rose-700"
                      )}>
                        {activeQuestion.difficulty}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs font-mono text-amber-400 bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-800">
                      <Clock size={13} />
                      <span>{Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
                    </div>
                  </div>

                  {/* Prompt */}
                  <h3 className="text-sm sm:text-base font-bold text-white leading-relaxed">
                    {activeQuestion.prompt}
                  </h3>

                  {/* Interactive Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                    {activeQuestion.options.map((opt, oIdx) => {
                      const isSelected = selectedOptionId === opt.id;
                      const isCorrect = opt.isCorrect;
                      return (
                        <button
                          key={opt.id}
                          onClick={() => handleSelectOption(opt.id)}
                          disabled={isAnswerSubmitted}
                          className={cn(
                            "p-3 rounded-xl border-2 text-left font-bold text-xs transition-all cursor-pointer flex items-center justify-between gap-2",
                            isSelected && !isAnswerSubmitted
                              ? "bg-indigo-950 border-indigo-400 text-white shadow-md"
                              : isAnswerSubmitted && isCorrect
                              ? "bg-emerald-950/80 border-[#2ECC71] text-emerald-200"
                              : isAnswerSubmitted && isSelected && !isCorrect
                              ? "bg-rose-950/80 border-[#E74C3C] text-rose-200"
                              : "bg-slate-950/70 border-slate-800 text-slate-300 hover:border-indigo-500/50"
                          )}
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-[10px] font-mono">
                              {String.fromCharCode(65 + oIdx)}
                            </span>
                            <span>{opt.text}</span>
                          </div>
                          {isAnswerSubmitted && isCorrect && <CheckCircle2 size={16} className="text-[#2ECC71] shrink-0" />}
                          {isAnswerSubmitted && isSelected && !isCorrect && <AlertTriangle size={16} className="text-[#E74C3C] shrink-0" />}
                        </button>
                      );
                    })}
                  </div>

                  {/* Submit / Next Buttons */}
                  <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                    {!isAnswerSubmitted ? (
                      <button
                        onClick={handleSubmitAnswer}
                        disabled={!selectedOptionId}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer shadow-md ml-auto",
                          selectedOptionId 
                            ? "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-500/30" 
                            : "bg-slate-800 text-slate-500 cursor-not-allowed"
                        )}
                      >
                        Verify & Reveal Steps ➔
                      </button>
                    ) : (
                      <div className="flex items-center justify-between w-full">
                        <span className="text-xs font-bold text-[#2ECC71] flex items-center gap-1">
                          <Check size={14} /> Answer: {activeQuestion.finalAnswer}
                        </span>
                        <button
                          onClick={handleNextQuestion}
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                        >
                          <span>Next Question</span>
                          <ChevronRight size={14} />
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Step-by-Step Solution Breakdown when Answer Submitted */}
                  {isAnswerSubmitted && (
                    <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2.5 animate-fadeIn">
                      <span className="text-xs font-black uppercase text-indigo-400 tracking-wider flex items-center gap-1.5">
                        📝 Step-by-Step Model Solution
                      </span>
                      <div className="space-y-1.5">
                        {activeQuestion.solutionSteps.map((step) => (
                          <div key={step.stepNumber} className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs">
                            <div className="flex items-center justify-between font-bold text-slate-200">
                              <span>{step.label}</span>
                              <span className="font-mono text-cyan-300 font-bold">{step.mathLatex}</span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5">{step.explanation}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>
              )}
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* MODE 2: STANDARD OPTIMISED SMARTBOARD LAYOUT (30/25/25/15/5 Distribution) */}
        {/* ========================================================================= */}
        {presentationMode === 'standard_optimized' && (
          <div className="space-y-4">
            
            {/* 📐 1. FORMULA ZONE (Top — 30% of Smartboard) */}
            <div className="p-4 rounded-2xl bg-slate-900/95 border-2 border-[#4A90D9]/50 shadow-md space-y-2.5">
              <div className="flex items-center justify-between border-b border-[#4A90D9]/30 pb-2">
                <span className="text-xs font-black uppercase tracking-wider text-[#4A90D9] flex items-center gap-1.5">
                  📐 FORMULA ZONE (Primary Mathematical Blueprint)
                </span>
                <span className="text-[10px] font-mono text-[#4A90D9] bg-slate-950 px-2 py-0.5 rounded border border-[#4A90D9]/30">
                  30% Board Allocation
                </span>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-3 rounded-xl bg-slate-950/80 border border-slate-800/80">
                <div className="text-center sm:text-left">
                  <div className="text-2xl sm:text-3xl font-black text-[#4A90D9] font-mono tracking-wide">
                    {currentDeck.formulaLatex}
                  </div>
                  <div className="text-xs text-slate-300 font-medium mt-1">
                    {currentDeck.formulaTitle}
                  </div>
                </div>

                <div className="flex flex-wrap gap-1.5 justify-center sm:justify-end">
                  {currentDeck.variables.map(v => (
                    <div key={v.symbol} className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 flex items-center gap-1.5">
                      <span className="font-mono text-cyan-300 font-bold">{v.symbol}</span>
                      <span className="text-slate-400">=</span>
                      <span className="text-slate-200">{v.name}</span>
                      <span className="text-[9px] font-mono text-indigo-400">({v.unit})</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* ❓ 2. QUESTION ZONE (Middle — 25% of Smartboard) */}
            {activeQuestion && (
              <div className="p-4 rounded-2xl bg-slate-900/95 border-2 border-indigo-500/40 shadow-md space-y-3">
                <div className="flex items-center justify-between border-b border-indigo-500/30 pb-2 flex-wrap gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-black uppercase tracking-wider text-indigo-400">
                      ❓ INTEGRATED PRACTICE: Q{activeQuestion.questionNumber} of {activeQuestion.totalQuestions}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-700">
                      🎯 Difficulty: {activeQuestion.difficulty}
                    </span>
                    {masteryProgress.adaptiveTier && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-950 text-cyan-300 border border-indigo-700">
                        ⚡ Adaptive: {masteryProgress.adaptiveTier.minQuestions}–{masteryProgress.adaptiveTier.maxQuestions} Qs ({masteryProgress.adaptiveTier.speedMode})
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 text-xs font-mono text-amber-400 bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-800">
                    <Clock size={13} />
                    <span>⏱️ {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')} remaining</span>
                  </div>
                </div>

                {/* Conversational Professor Clarity Teaching Callout */}
                {activeQuestion.conversationalIntroPrompt && (
                  <div className="p-3 rounded-xl bg-indigo-950/80 border border-indigo-500/50 flex items-start gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-indigo-600/30 text-indigo-300 flex items-center justify-center shrink-0 font-bold text-sm">
                      🎓
                    </div>
                    <div>
                      <span className="text-[10px] font-black uppercase text-indigo-300 tracking-wider">
                        Professor Clarity • Integrated Conversational Teaching:
                      </span>
                      <p className="text-xs sm:text-sm font-semibold text-white mt-0.5 leading-relaxed italic">
                        "{activeQuestion.conversationalIntroPrompt}"
                      </p>
                    </div>
                  </div>
                )}

                <p className="text-sm sm:text-base font-bold text-white leading-relaxed">
                  {activeQuestion.prompt}
                </p>

                {/* Multiple-Choice Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 pt-1">
                  {activeQuestion.options.map((opt, oIdx) => {
                    const isSelected = selectedOptionId === opt.id;
                    const isCorrect = opt.isCorrect;
                    return (
                      <button
                        key={opt.id}
                        onClick={() => handleSelectOption(opt.id)}
                        disabled={isAnswerSubmitted}
                        className={cn(
                          "p-2.5 rounded-xl border-2 text-left font-bold text-xs transition-all cursor-pointer flex items-center justify-between gap-1.5",
                          isSelected && !isAnswerSubmitted
                            ? "bg-indigo-950 border-indigo-400 text-white shadow-md scale-[1.02]"
                            : isAnswerSubmitted && isCorrect
                            ? "bg-emerald-950/90 border-[#2ECC71] text-emerald-200"
                            : isAnswerSubmitted && isSelected && !isCorrect
                            ? "bg-rose-950/90 border-[#E74C3C] text-rose-200"
                            : "bg-slate-950/70 border-slate-800 text-slate-300 hover:border-indigo-500/50"
                        )}
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="w-5 h-5 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-[10px] font-mono">
                            {String.fromCharCode(65 + oIdx)}
                          </span>
                          <span>{opt.text}</span>
                        </div>
                        {isAnswerSubmitted && isCorrect && <CheckCircle2 size={15} className="text-[#2ECC71] shrink-0" />}
                      </button>
                    );
                  })}
                </div>

                {/* Verify Button */}
                {!isAnswerSubmitted && (
                  <div className="flex justify-end pt-1">
                    <button
                      onClick={handleSubmitAnswer}
                      disabled={!selectedOptionId}
                      className={cn(
                        "px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer shadow-md",
                        selectedOptionId 
                          ? "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-500/30 active:scale-95" 
                          : "bg-slate-800 text-slate-500 cursor-not-allowed"
                      )}
                    >
                      Calculate & Submit Answer ➔
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* 📝 3. SOLUTION ZONE (Bottom — 25% of Smartboard) */}
            {activeQuestion && (
              <div className="p-4 rounded-2xl bg-slate-900/95 border-2 border-[#2ECC71]/40 shadow-md space-y-3">
                <div className="flex items-center justify-between border-b border-[#2ECC71]/30 pb-2">
                  <span className="text-xs font-black uppercase tracking-wider text-[#2ECC71] flex items-center gap-1.5">
                    📝 SOLUTION ZONE (Mathematical Derivation & Calculation)
                  </span>
                  {isAnswerSubmitted && (
                    <span className="text-xs font-black text-[#2ECC71] bg-emerald-950 px-2.5 py-0.5 rounded-full border border-emerald-700">
                      ✅ Final Answer: {activeQuestion.finalAnswer}
                    </span>
                  )}
                </div>

                {/* Step Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                  {activeQuestion.solutionSteps.slice(0, isAnswerSubmitted ? 4 : revealedStepCount || 2).map((step) => (
                    <div 
                      key={step.stepNumber} 
                      className={cn(
                        "p-3 rounded-xl border transition-all flex flex-col justify-between",
                        step.isKeyMilestone 
                          ? "bg-emerald-950/40 border-emerald-500/60 shadow-md" 
                          : "bg-slate-950/70 border-slate-800"
                      )}
                    >
                      <div>
                        <span className="text-[10px] font-black uppercase text-indigo-400 font-mono">
                          {step.label}
                        </span>
                        <div className="text-sm font-mono font-bold text-white mt-1">
                          {step.mathLatex}
                        </div>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-2 leading-relaxed">
                        {step.explanation}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Next / Navigation Row */}
                {isAnswerSubmitted && (
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                    <button
                      onClick={handlePrevQuestion}
                      disabled={currentQuestionIndex === 0}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <ChevronLeft size={14} />
                      <span>Previous</span>
                    </button>

                    <button
                      onClick={handleNextQuestion}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                    >
                      <span>{currentQuestionIndex < currentDeck.questions.length - 1 ? 'Next Question' : 'Complete Practice'}</span>
                      <ChevronRight size={14} />
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* 💡 4. KEY POINTS & NOTES ZONE (15% of Smartboard) */}
            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black uppercase text-purple-400 tracking-wider flex items-center gap-1.5">
                  <BookOpen size={13} className="text-purple-400" />
                  Key Points & Examiner Vault
                </span>
                <span className="text-[10px] text-slate-400">15% Allocation</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {currentDeck.keyNotes.map((note, idx) => (
                  <div key={idx} className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 flex items-start gap-1.5">
                    <span className="text-purple-400 font-bold">•</span>
                    <span>{note}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* MODE 3: FOCUS MODES (Formula Focus, Question Focus, Mastery Focus)       */}
        {/* ========================================================================= */}
        {presentationMode === 'focus_formula' && (
          <div className="p-6 rounded-3xl bg-slate-900/95 border-2 border-blue-500/60 shadow-2xl space-y-6 text-center animate-fadeIn">
            <span className="text-xs font-black uppercase tracking-wider text-blue-400 bg-blue-950/60 px-3 py-1 rounded-full border border-blue-700">
              📐 Formula Memorisation Focus Mode (80% Smartboard)
            </span>

            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="text-4xl sm:text-6xl font-black text-[#4A90D9] font-mono tracking-wider">
                {currentDeck.formulaLatex}
              </div>
              <h3 className="text-lg font-bold text-white mt-3">
                {currentDeck.formulaTitle}
              </h3>
              {currentDeck.expandedFormulaLatex && (
                <div className="text-sm text-cyan-300 font-mono mt-1">
                  Derivation Path: {currentDeck.expandedFormulaLatex}
                </div>
              )}
            </div>

            {/* Variable Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
              {currentDeck.variables.map(v => (
                <div key={v.symbol} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-base font-black text-cyan-300 font-mono">{v.symbol}</span>
                    <span className="text-[10px] font-mono text-indigo-400">{v.unit}</span>
                  </div>
                  <h4 className="text-xs font-bold text-white mt-1">{v.name}</h4>
                  <p className="text-[11px] text-slate-400 mt-1">{v.description}</p>
                </div>
              ))}
            </div>

            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={() => setPresentationMode('focus_question')}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-black transition-all cursor-pointer shadow-lg"
              >
                Proceed to Practice Questions ➔
              </button>
            </div>
          </div>
        )}

        {presentationMode === 'focus_question' && activeQuestion && (
          <div className="p-6 rounded-3xl bg-slate-900/95 border-2 border-amber-500/60 shadow-2xl space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-black uppercase tracking-wider text-amber-400 bg-amber-950/60 px-3 py-1 rounded-full border border-amber-700">
                ❓ Question Focus Mode (70% Smartboard)
              </span>
              <div className="text-sm font-mono text-amber-300 font-bold">
                ⏱️ {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
              </div>
            </div>

            <h3 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
              {activeQuestion.prompt}
            </h3>

            {/* Big Interactive Option Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {activeQuestion.options.map((opt, oIdx) => {
                const isSelected = selectedOptionId === opt.id;
                const isCorrect = opt.isCorrect;
                return (
                  <button
                    key={opt.id}
                    onClick={() => handleSelectOption(opt.id)}
                    disabled={isAnswerSubmitted}
                    className={cn(
                      "p-4 rounded-2xl border-2 text-left font-bold text-sm transition-all cursor-pointer flex items-center justify-between gap-3",
                      isSelected && !isAnswerSubmitted
                        ? "bg-indigo-950 border-indigo-400 text-white shadow-xl scale-[1.02]"
                        : isAnswerSubmitted && isCorrect
                        ? "bg-emerald-950 border-[#2ECC71] text-emerald-200"
                        : isAnswerSubmitted && isSelected && !isCorrect
                        ? "bg-rose-950 border-[#E74C3C] text-rose-200"
                        : "bg-slate-950/80 border-slate-800 text-slate-300 hover:border-indigo-500/50"
                    )}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-xs font-mono">
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span>{opt.text}</span>
                    </div>
                    {isAnswerSubmitted && isCorrect && <CheckCircle2 size={18} className="text-[#2ECC71] shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-800">
              <span className="text-xs text-slate-400">
                Formula Ref: <span className="font-mono text-cyan-300 font-bold">{currentDeck.formulaLatex}</span>
              </span>
              {!isAnswerSubmitted ? (
                <button
                  onClick={handleSubmitAnswer}
                  disabled={!selectedOptionId}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition-all cursor-pointer shadow-lg disabled:opacity-40"
                >
                  Confirm Answer ➔
                </button>
              ) : (
                <button
                  onClick={handleNextQuestion}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black transition-all cursor-pointer shadow-lg"
                >
                  Next ➔
                </button>
              )}
            </div>
          </div>
        )}

        {presentationMode === 'focus_mastery' && (
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/95 border-2 border-emerald-500/60 shadow-2xl space-y-6 text-center animate-fadeIn relative overflow-hidden">
            
            {/* Confetti celebration effect indicator */}
            {isCelebrating && (
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <span className="text-6xl animate-bounce">🎉 🏆 🌟</span>
              </div>
            )}

            <div className="inline-flex p-3 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              <Trophy size={32} />
            </div>

            <h3 className="text-2xl sm:text-3xl font-black text-white">
              Formula Mastery Complete!
            </h3>
            <p className="text-sm text-slate-300 max-w-lg mx-auto">
              You've demonstrated thorough competence in applying <span className="text-cyan-300 font-mono font-bold">{currentDeck.formulaLatex}</span> across algebraic derivation and competitive exam numericals.
            </p>

            {/* Score & Metrics Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400">Total Score</span>
                <div className="text-xl font-black text-emerald-400 mt-1">{score} / {currentDeck.questions.length}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400">Streak Peak</span>
                <div className="text-xl font-black text-amber-400 mt-1">🔥 {highestStreak}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400">Accuracy</span>
                <div className="text-xl font-black text-cyan-400 mt-1">{Math.round((score / Math.max(1, currentDeck.questions.length)) * 100)}%</div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400">Mastery Level</span>
                <div className="text-xl font-black text-purple-400 mt-1">Expert</div>
              </div>
            </div>

            {/* Badges Earned */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-black uppercase text-slate-400 tracking-wider">
                Earned Mastery Badges:
              </span>
              <div className="flex flex-wrap items-center justify-center gap-2">
                {CURATED_MASTERY_BADGES.map(badge => (
                  <div key={badge.id} className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2 text-xs font-bold text-slate-200">
                    <span>{badge.icon}</span>
                    <span>{badge.title}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-center gap-3 pt-3">
              <button
                onClick={() => {
                  setCurrentQuestionIndex(0);
                  setScore(0);
                  setStreak(0);
                  setQuestionResults({});
                  setPresentationMode('standard_optimized');
                }}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-black transition-all cursor-pointer"
              >
                Restart Deck Practice
              </button>
              {onDeliverToSmartboard && (
                <button
                  onClick={handleDeliverToSmartboard}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black transition-all cursor-pointer shadow-lg"
                >
                  Deliver Report to 3D Smartboard
                </button>
              )}
            </div>
          </div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* 📊 5. STATUS BAR & VISUAL PROGRESS INDICATORS (Bottom — 5% Allocation)     */}
      {/* ========================================================================= */}
      <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* Progress % and Question Dots */}
        <div className="flex items-center gap-3 flex-wrap">
          
          {/* Circular Mini Formula Ring */}
          <div className="flex items-center gap-2">
            <svg className="w-6 h-6 transform -rotate-90">
              <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" className="text-slate-800" fill="transparent" />
              <circle 
                cx="12" 
                cy="12" 
                r="9" 
                stroke="currentColor" 
                strokeWidth="2.5" 
                className="text-emerald-400 transition-all duration-500" 
                fill="transparent"
                strokeDasharray={56.5}
                strokeDashoffset={56.5 - (56.5 * progressPercent) / 100}
              />
            </svg>
            <span className="font-bold text-slate-200">{progressPercent}% Completed</span>
          </div>

          {/* Question Dots */}
          <div className="flex items-center gap-1.5">
            {currentDeck.questions.map((q, idx) => {
              const res = questionResults[q.id];
              const isCurrent = idx === currentQuestionIndex;
              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentQuestionIndex(idx)}
                  className={cn(
                    "w-3 h-3 rounded-full transition-all cursor-pointer",
                    res === true ? "bg-[#2ECC71]" :
                    res === false ? "bg-[#E74C3C]" :
                    isCurrent ? "bg-[#4A90D9] ring-2 ring-blue-400" :
                    "bg-slate-700 hover:bg-slate-600"
                  )}
                  title={`Question ${idx + 1}: ${res === true ? 'Correct' : res === false ? 'Incorrect' : 'Unattempted'}`}
                />
              );
            })}
          </div>

        </div>

        {/* Score, Streak Flame & Badges */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 font-bold text-slate-200">
            <span>Score:</span>
            <span className="font-mono text-emerald-400">{score}/{currentDeck.questions.length}</span>
          </div>

          <div className="flex items-center gap-1 font-bold text-amber-400 px-2 py-0.5 rounded-full bg-amber-950/60 border border-amber-800/80">
            <Flame size={13} className="text-amber-400 animate-bounce" />
            <span>Streak: {streak}</span>
          </div>

          <div className="flex items-center gap-1">
            {unlockedBadges.map(bId => {
              const b = CURATED_MASTERY_BADGES.find(x => x.id === bId);
              return b ? (
                <span key={bId} title={b.title} className="text-sm">
                  {b.icon}
                </span>
              ) : null;
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
