export * from '../../src/modules/projects/MilestoneSubmit';
import { MilestoneSubmit } from '../../src/modules/projects/MilestoneSubmit';
export default MilestoneSubmit;
