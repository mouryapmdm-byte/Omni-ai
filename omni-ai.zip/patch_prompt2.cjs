const fs = require('fs');
const file = 'src/App.tsx';
let content = fs.readFileSync(file, 'utf8');

const oldStr = "CRITICAL AUTOMATED GRAPHING UTILITY: Whenever a mathematical function $f(x)$ or equation is detected in the chat, YOU MUST AUTOMATICALLY output an image prompt in <DRAW_IMAGE>...</DRAW_IMAGE> to visualize the curve and relevant geometric properties.";
const newStr = "CRITICAL AUTOMATED GRAPHING UTILITY: Whenever mathematical functions $f(x)$ or equations are detected in the chat, YOU MUST AUTOMATICALLY output an image prompt in <DRAW_IMAGE>...</DRAW_IMAGE> to visualize the curve and relevant geometric properties. IMPORTANT: You must support multiple functions if requested on the same coordinate plane, and you MUST explicitly include instructions for a legend and axis labels in the generated image prompts to make the visualization clearer. For example: <DRAW_IMAGE>Graph of f(x)=x^2 and g(x)=2x on a coordinate plane with a legend and axis labels</DRAW_IMAGE>";

content = content.split(oldStr).join(newStr);
fs.writeFileSync(file, content);
console.log("Updated App.tsx system prompt");
