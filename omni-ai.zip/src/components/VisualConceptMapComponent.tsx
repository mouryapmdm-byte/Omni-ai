import React, { useState, useEffect } from 'react';
import { cn } from '@/src/lib/utils';
import { 
  Map, 
  Brain, 
  Sparkles, 
  Copy, 
  Check, 
  Maximize2, 
  X, 
  Activity, 
  Layers, 
  Zap, 
  Lightbulb, 
  ArrowRight,
  Target,
  Sliders,
  Clock,
  RotateCcw,
  FastForward,
  Box
} from 'lucide-react';
import { 
  ISC_ECON_MICRO_SUBTOPICS,
  ISC_ECON_MACRO_SUBTOPICS,
  ELECTRIC_CHARGES_SUBTOPICS,
  GAUSS_THEOREM_SUBTOPICS,
  ELECTRIC_POTENTIAL_SUBTOPICS,
  CAPACITORS_DIELECTRICS_SUBTOPICS,
  ELECTRIC_RESISTANCE_SUBTOPICS,
  DC_CIRCUITS_SUBTOPICS,
  MOVING_CHARGES_SUBTOPICS,
  TORQUE_CURRENT_LOOP_SUBTOPICS,
  EARTH_MAGNETISM_SUBTOPICS,
  MAGNETIC_SUBSTANCES_SUBTOPICS,
  ELECTROMAGNETIC_INDUCTION_SUBTOPICS,
  ALTERNATING_CURRENT_SUBTOPICS,
  ELECTROMAGNETIC_WAVES_SUBTOPICS,
  RAY_OPTICS_SUBTOPICS,
  WAVE_OPTICS_SUBTOPICS,
  DUAL_NATURE_SUBTOPICS,
  ATOMS_SUBTOPICS,
  NUCLEI_SUBTOPICS,
  SEMICONDUCTOR_ELECTRONICS_SUBTOPICS,
  COMMUNICATION_SYSTEMS_SUBTOPICS,
  NATIONAL_INCOME_SUBTOPICS,
  MONEY_BANKING_SUBTOPICS,
  INCOME_EMPLOYMENT_SUBTOPICS,
  GOVT_BUDGET_SUBTOPICS,
  BALANCE_PAYMENTS_SUBTOPICS,
  INDIAN_ECON_EVE_SUBTOPICS,
  MACRO_INTRO_SUBTOPICS,
  SOLID_STATE_SUBTOPICS,
  SOLUTIONS_SUBTOPICS,
  ELECTROCHEMISTRY_SUBTOPICS,
  CHEMICAL_KINETICS_SUBTOPICS,
  RELATIONS_FUNCTIONS_SUBTOPICS,
  MATRICES_SUBTOPICS,
  DETERMINANTS_SUBTOPICS,
  INTEGRATION_SUBTOPICS
} from '../lib/constants';
import { VisualMapStudioModal } from './VisualMapStudioModal';
import { VisualMapType } from '../types/visualMap';

export function getLessonSubtopics(lessonTitle: string, subjectName: string = ''): string[] {
  const t = lessonTitle.toLowerCase();
  const s = subjectName.toLowerCase();

  if (t.includes('microeconomics') || t.includes('consumer') || t.includes('demand')) return ISC_ECON_MICRO_SUBTOPICS;
  if (t.includes('macroeconomics') || t.includes('national income') || t.includes('multiplier')) return ISC_ECON_MACRO_SUBTOPICS;
  if (t.includes('money') || t.includes('banking')) return MONEY_BANKING_SUBTOPICS;
  if (t.includes('budget') || t.includes('fiscal')) return GOVT_BUDGET_SUBTOPICS;
  if (t.includes('balance of payments') || t.includes('foreign exchange')) return BALANCE_PAYMENTS_SUBTOPICS;
  if (t.includes('income') || t.includes('employment')) return INCOME_EMPLOYMENT_SUBTOPICS;
  if (t.includes('eve of independence') || t.includes('indian economy')) return INDIAN_ECON_EVE_SUBTOPICS;
  if (t.includes('national income')) return NATIONAL_INCOME_SUBTOPICS;

  if (t.includes('charge') || t.includes('coulomb')) return ELECTRIC_CHARGES_SUBTOPICS;
  if (t.includes('gauss')) return GAUSS_THEOREM_SUBTOPICS;
  if (t.includes('potential')) return ELECTRIC_POTENTIAL_SUBTOPICS;
  if (t.includes('capacitor') || t.includes('dielectric')) return CAPACITORS_DIELECTRICS_SUBTOPICS;
  if (t.includes('resistance') || t.includes('ohm')) return ELECTRIC_RESISTANCE_SUBTOPICS;
  if (t.includes('circuit') || t.includes('kirchhoff')) return DC_CIRCUITS_SUBTOPICS;
  if (t.includes('moving charge') || t.includes('magnetic field')) return MOVING_CHARGES_SUBTOPICS;
  if (t.includes('torque') || t.includes('galvanometer')) return TORQUE_CURRENT_LOOP_SUBTOPICS;
  if (t.includes('earth magnetism') || t.includes('terrestrial')) return EARTH_MAGNETISM_SUBTOPICS;
  if (t.includes('induction') || t.includes('faraday')) return ELECTROMAGNETIC_INDUCTION_SUBTOPICS;
  if (t.includes('alternating current') || t.includes('ac circuit')) return ALTERNATING_CURRENT_SUBTOPICS;
  if (t.includes('electromagnetic wave')) return ELECTROMAGNETIC_WAVES_SUBTOPICS;
  if (t.includes('ray optics') || t.includes('prism') || t.includes('lens')) return RAY_OPTICS_SUBTOPICS;
  if (t.includes('wave optics') || t.includes('interference') || t.includes('diffraction')) return WAVE_OPTICS_SUBTOPICS;
  if (t.includes('dual nature') || t.includes('photoelectric')) return DUAL_NATURE_SUBTOPICS;
  if (t.includes('atom') || t.includes('bohr')) return ATOMS_SUBTOPICS;
  if (t.includes('nuclei') || t.includes('radioactivity')) return NUCLEI_SUBTOPICS;
  if (t.includes('semiconductor') || t.includes('diode')) return SEMICONDUCTOR_ELECTRONICS_SUBTOPICS;
  if (t.includes('communication')) return COMMUNICATION_SYSTEMS_SUBTOPICS;

  if (t.includes('solid state')) return SOLID_STATE_SUBTOPICS;
  if (t.includes('solution')) return SOLUTIONS_SUBTOPICS;
  if (t.includes('electrochemistry')) return ELECTROCHEMISTRY_SUBTOPICS;
  if (t.includes('kinetics')) return CHEMICAL_KINETICS_SUBTOPICS;

  if (t.includes('relation') || t.includes('function')) return RELATIONS_FUNCTIONS_SUBTOPICS;
  if (t.includes('matrix') || t.includes('matrices')) return MATRICES_SUBTOPICS;
  if (t.includes('determinant')) return DETERMINANTS_SUBTOPICS;
  if (t.includes('integral') || t.includes('integration')) return INTEGRATION_SUBTOPICS;

  // Generic fallbacks
  if (s.includes('econ')) {
    return [
      "Foundational Theoretical Axioms",
      "Behavioral & Market Dynamics",
      "Quantitative & Algebraic Models",
      "Policy Implications & Real-World Case Studies"
    ];
  }
  if (s.includes('phys')) {
    return [
      "Physical Laws & Principles",
      "Mathematical Formulations & Derivations",
      "Experimental Setup & Lab Simulations",
      "Engineering & Technology Applications"
    ];
  }

  return [
    "Core Concept & Definitions",
    "Fundamental Axioms & Models",
    "Quantitative Mechanics & Analysis",
    "Practical Real-World Applications"
  ];
}

export interface VisualConceptMapProps {
  lessonTitle: string;
  chapterTitle?: string;
  subtopics?: string[];
  description?: string;
  theme?: 'light' | 'dark' | string;
  onStudyLesson?: (lessonTitle: string, chapterTitle: string) => void;
  onExpandModal?: () => void;
  isModal?: boolean;
  onCloseModal?: () => void;
  onDeliverToSmartboard?: (contentMarkdown: string, topicTitle: string) => void;
}

export const VisualConceptMapComponent: React.FC<VisualConceptMapProps> = ({
  lessonTitle,
  chapterTitle = '',
  subtopics,
  description = 'Interactive visual concept map illustrating the structural hierarchy, key axioms, mathematical relationships, and real-world applications of this lesson module.',
  theme = 'light',
  onStudyLesson,
  onExpandModal,
  isModal = false,
  onCloseModal,
  onDeliverToSmartboard
}) => {
  const [selectedNodeIndex, setSelectedNodeIndex] = useState<number>(0);
  const [copiedMap, setCopiedMap] = useState(false);
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [currentMapType, setCurrentMapType] = useState<VisualMapType>('concept_map');

  const activeSubtopics = subtopics && subtopics.length > 0
    ? subtopics
    : getLessonSubtopics(lessonTitle, chapterTitle);

  const handleCopyMap = () => {
    const text = `🗺️ Visual Concept Summary: ${lessonTitle}\n` +
      `Chapter: ${chapterTitle || 'Syllabus Module'}\n` +
      `Overview: ${description}\n\n` +
      `Key Concept Flow Hierarchy:\n` +
      activeSubtopics.map((node, i) => `${i + 1}. ${node}`).join('\n');

    navigator.clipboard.writeText(text).then(() => {
      setCopiedMap(true);
      setTimeout(() => setCopiedMap(false), 2000);
    });
  };

  return (
    <div className={cn(
      "w-full rounded-2xl border transition-all p-4 md:p-6 space-y-5 animate-fadeIn text-left",
      theme === 'dark'
        ? "bg-slate-900/95 border-cyan-900/70 text-slate-100 shadow-2xl shadow-cyan-950/30"
        : "bg-gradient-to-br from-cyan-50/50 via-white to-slate-50 border-cyan-200 text-slate-900 shadow-xl shadow-cyan-500/10"
    )}>
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-cyan-200/60 dark:border-cyan-800/60">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border border-cyan-500/30 shadow-xs">
            <Map size={20} className="animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-cyan-700 dark:text-cyan-300 bg-cyan-500/15 px-2.5 py-0.5 rounded-full border border-cyan-500/30">
                Visual Concept Blueprint
              </span>
              <span className="text-[10px] opacity-60 font-semibold">({activeSubtopics.length} Node Pillars)</span>
            </div>
            <h4 className="font-extrabold text-sm md:text-base text-slate-900 dark:text-white mt-0.5">
              {lessonTitle}
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsStudioOpen(true)}
            className="px-3 py-1.5 text-xs font-bold rounded-lg bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
            title="Open Full Visual Map & Schematic Breakdown Studio"
          >
            <Sliders size={13} />
            Visual Map Studio (8 Types + Schematics)
          </button>

          <button
            onClick={handleCopyMap}
            className="px-3 py-1.5 text-xs font-bold rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Copy Text Concept Map"
          >
            {copiedMap ? <Check size={13} className="text-emerald-500" /> : <Copy size={13} />}
            {copiedMap ? "Copied!" : "Copy Map"}
          </button>

          {onExpandModal && !isModal && (
            <button
              onClick={onExpandModal}
              className="px-3 py-1.5 text-xs font-bold rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Expand Visual Diagram"
            >
              <Maximize2 size={13} />
              Fullscreen
            </button>
          )}

          {isModal && onCloseModal && (
            <button
              onClick={onCloseModal}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* 8 Visual Map Quick Modes Ribbon */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs select-none">
        {[
          { type: 'concept_map' as VisualMapType, label: 'Concept Map', icon: Brain },
          { type: 'mind_map' as VisualMapType, label: 'Mind Map', icon: Sparkles },
          { type: 'flowchart' as VisualMapType, label: 'Flowchart', icon: FastForward },
          { type: 'venn_diagram' as VisualMapType, label: 'Venn Diagram', icon: Layers },
          { type: 'hierarchy' as VisualMapType, label: 'Hierarchy', icon: Box },
          { type: 'cycle' as VisualMapType, label: 'Closed Cycle', icon: RotateCcw },
          { type: 'timeline' as VisualMapType, label: 'Timeline', icon: Clock },
          { type: 'cause_effect' as VisualMapType, label: 'Cause-Effect', icon: Activity }
        ].map(m => {
          const IconComp = m.icon;
          const isSelected = currentMapType === m.type;
          return (
            <button
              key={m.type}
              onClick={() => {
                setCurrentMapType(m.type);
                setIsStudioOpen(true);
              }}
              className={cn(
                "px-2.5 py-1 rounded-lg font-bold transition-all shrink-0 flex items-center gap-1.5 border cursor-pointer",
                isSelected
                  ? "bg-cyan-500/20 border-cyan-500 text-cyan-700 dark:text-cyan-300"
                  : "bg-slate-100 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-cyan-50 dark:hover:bg-slate-800"
              )}
            >
              <IconComp size={12} />
              <span>{m.label}</span>
            </button>
          );
        })}
      </div>

      {/* Central Topic Hub Card */}
      <div className="flex flex-col items-center justify-center text-center p-4 rounded-xl bg-gradient-to-r from-cyan-500/10 via-indigo-500/10 to-purple-500/10 border border-cyan-500/30 relative shadow-inner">
        <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-cyan-500 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-cyan-500/20 mb-2">
          <Brain size={22} />
        </div>
        <span className="text-[10px] font-black uppercase text-cyan-600 dark:text-cyan-400 tracking-wider">
          Core Topic Anchor
        </span>
        <h3 className="font-extrabold text-base md:text-lg text-slate-900 dark:text-white mt-0.5">
          {lessonTitle}
        </h3>
        <p className="text-xs opacity-80 max-w-xl mt-1.5 leading-relaxed">
          {description}
        </p>

        {/* Dynamic Connector Line */}
        <div className="w-0.5 h-6 bg-gradient-to-b from-cyan-500 via-indigo-500 to-purple-500 mt-3 animate-pulse" />
      </div>

      {/* Node Hierarchy Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Sparkles size={14} className="text-amber-500" />
            Sequential Concept Diagram Flow
          </span>
          <span className="text-[10px] opacity-60">Click node to spotlight details</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {activeSubtopics.map((subtopicTitle, index) => {
            const isSelected = selectedNodeIndex === index;
            return (
              <div
                key={index}
                onClick={() => setSelectedNodeIndex(index)}
                className={cn(
                  "p-3.5 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between gap-2.5 relative group",
                  isSelected
                    ? "bg-cyan-500/15 border-cyan-500 shadow-md shadow-cyan-500/15 text-cyan-950 dark:text-cyan-100 scale-[1.02]"
                    : theme === 'dark'
                      ? "bg-slate-800/80 border-slate-700/80 hover:border-cyan-500/60 hover:bg-slate-800"
                      : "bg-white border-slate-200 hover:border-cyan-400 hover:bg-cyan-50/40"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className={cn(
                    "w-6 h-6 rounded-full text-[11px] font-black flex items-center justify-center transition-all",
                    isSelected
                      ? "bg-cyan-600 text-white shadow-xs"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 group-hover:bg-cyan-100 group-hover:text-cyan-600"
                  )}>
                    {index + 1}
                  </span>
                  <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800">
                    Pillar
                  </span>
                </div>

                <div>
                  <h5 className="font-bold text-xs leading-snug line-clamp-2">
                    {subtopicTitle}
                  </h5>
                </div>

                <div className="flex items-center justify-between text-[10px] opacity-75 border-t border-slate-100 dark:border-slate-800/80 pt-2 mt-1">
                  <span className="flex items-center gap-1 font-semibold text-cyan-600 dark:text-cyan-400">
                    <Activity size={12} /> Concept Node
                  </span>
                  <span className="font-extrabold flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                    Inspect <ArrowRight size={10} />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Node Details Box */}
      {activeSubtopics[selectedNodeIndex] && (
        <div className={cn(
          "p-4 rounded-xl border space-y-3 animate-fadeIn",
          theme === 'dark' ? "bg-slate-950/90 border-cyan-900/60" : "bg-cyan-50/70 border-cyan-200"
        )}>
          <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-cyan-200/50 dark:border-cyan-900/50">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-cyan-600 dark:text-cyan-400 bg-cyan-500/10 px-2.5 py-0.5 rounded-lg border border-cyan-500/20">
                Node {selectedNodeIndex + 1} Deep Breakdown
              </span>
              <h5 className="font-extrabold text-xs md:text-sm text-slate-900 dark:text-white">
                {activeSubtopics[selectedNodeIndex]}
              </h5>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsStudioOpen(true)}
                className="px-3 py-1.5 text-xs font-bold text-cyan-600 dark:text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 rounded-lg transition-colors border border-cyan-500/30 flex items-center gap-1.5 cursor-pointer"
              >
                <Sliders size={13} />
                Schematic Deconstruction
              </button>
              {onStudyLesson && (
                <button
                  onClick={() => onStudyLesson(`${activeSubtopics[selectedNodeIndex]} - ${lessonTitle}`, chapterTitle)}
                  className="px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Brain size={13} />
                  Study Node with AI Tutor
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
            <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1">
              <span className="text-[10px] font-black uppercase text-indigo-500 tracking-wider flex items-center gap-1">
                <Target size={12} /> 🗣️ Plain-English Concept
              </span>
              <p className="opacity-90 leading-relaxed text-[11px] font-medium">
                {activeSubtopics[selectedNodeIndex]} is a core pillar. Think of it as the foundational building block that powers this entire topic in simple human terms.
              </p>
            </div>
            <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1">
              <span className="text-[10px] font-black uppercase text-amber-500 tracking-wider flex items-center gap-1">
                <Zap size={12} /> ☕ Everyday Metaphor
              </span>
              <p className="opacity-90 leading-relaxed text-[11px] font-medium">
                Like a key mechanical component in a high-efficiency engine, it coordinates inputs and outputs seamlessly so the system works flawlessly.
              </p>
            </div>
            <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1">
              <span className="text-[10px] font-black uppercase text-emerald-500 tracking-wider flex items-center gap-1">
                <Lightbulb size={12} /> 🎯 Golden Exam Trap & Tip
              </span>
              <p className="opacity-90 leading-relaxed text-[11px] font-medium">
                Examiners love testing boundary conditions for {activeSubtopics[selectedNodeIndex]}. Keep your unit conversions clean and remember input/output rules!
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Visual Map & Schematic Breakdown Studio Modal */}
      <VisualMapStudioModal
        isOpen={isStudioOpen}
        onClose={() => setIsStudioOpen(false)}
        topicTitle={lessonTitle}
        subjectTitle={chapterTitle || 'STEM & Humanities'}
        theme={theme}
        onDeliverToSmartboard={onDeliverToSmartboard}
      />
    </div>
  );
};
