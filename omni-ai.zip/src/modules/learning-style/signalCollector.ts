import { 
  BehavioralSignals, 
  DiagramInteraction, 
  TextInteraction, 
  AudioInteraction, 
  HandsOnInteraction 
} from './types';

const SIGNALS_STORAGE_KEY = 'omni_vark_signals_v1';

export function getCollectedSignals(): BehavioralSignals {
  try {
    const raw = localStorage.getItem(SIGNALS_STORAGE_KEY);
    if (!raw) {
      return { diagrams: [], texts: [], audios: [], handsOn: [] };
    }
    return JSON.parse(raw);
  } catch {
    return { diagrams: [], texts: [], audios: [], handsOn: [] };
  }
}

export function saveCollectedSignals(signals: BehavioralSignals): void {
  try {
    localStorage.setItem(SIGNALS_STORAGE_KEY, JSON.stringify(signals));
  } catch (e) {
    console.error('Error saving VARK signals:', e);
  }
}

export function recordDiagramInteraction(interaction: Omit<DiagramInteraction, 'timestamp'>): void {
  const signals = getCollectedSignals();
  signals.diagrams.push({
    ...interaction,
    timestamp: new Date().toISOString()
  });
  // Keep last 200 events to prevent unbounded storage growth
  if (signals.diagrams.length > 200) signals.diagrams = signals.diagrams.slice(-200);
  saveCollectedSignals(signals);
}

export function recordTextInteraction(interaction: Omit<TextInteraction, 'timestamp'>): void {
  const signals = getCollectedSignals();
  signals.texts.push({
    ...interaction,
    timestamp: new Date().toISOString()
  });
  if (signals.texts.length > 200) signals.texts = signals.texts.slice(-200);
  saveCollectedSignals(signals);
}

export function recordAudioInteraction(interaction: Omit<AudioInteraction, 'timestamp'>): void {
  const signals = getCollectedSignals();
  signals.audios.push({
    ...interaction,
    timestamp: new Date().toISOString()
  });
  if (signals.audios.length > 200) signals.audios = signals.audios.slice(-200);
  saveCollectedSignals(signals);
}

export function recordHandsOnInteraction(interaction: Omit<HandsOnInteraction, 'timestamp'>): void {
  const signals = getCollectedSignals();
  signals.handsOn.push({
    ...interaction,
    timestamp: new Date().toISOString()
  });
  if (signals.handsOn.length > 200) signals.handsOn = signals.handsOn.slice(-200);
  saveCollectedSignals(signals);
}

export function clearCollectedSignals(): void {
  localStorage.removeItem(SIGNALS_STORAGE_KEY);
}
