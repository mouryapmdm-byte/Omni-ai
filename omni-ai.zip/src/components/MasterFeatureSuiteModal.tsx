import React, { useState } from 'react';
import { 
  X, Sparkles, CheckCircle2, ArrowRight, Brain, Mic, Languages, FileText, 
  Trophy, GraduationCap, Box, Users, BarChart3, WifiOff, Heart, Share2, 
  Eye, Briefcase, Layers, TrendingUp, Zap, Play, Search, HelpCircle, Timer, Clock, Database
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface MasterFeatureItem {
  id: number;
  key: string;
  name: string;
  category: 'Intelligence' | 'Immersion' | 'Assessment' | 'Wellbeing' | 'Community';
  description: string;
  icon: any;
  gradient: string;
  status: 'active' | 'ready';
  toolTarget: string;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onLaunchFeature: (toolTarget: string) => void;
  theme?: 'light' | 'dark';
}

export const MASTER_16_FEATURES: MasterFeatureItem[] = [
  {
    id: 1,
    key: 'adaptive_path',
    name: '1. Personalised Learning Path',
    category: 'Intelligence',
    description: 'Adaptive curriculum builder diagnosing knowledge gaps and generating optimal chapter sequences.',
    icon: Brain,
    gradient: 'from-indigo-600 to-violet-600',
    status: 'active',
    toolTarget: 'adaptive_learning_path'
  },
  {
    id: 2,
    key: 'two_way_voice',
    name: '2. Two-Way Voice Dialogue',
    category: 'Immersion',
    description: 'Low-latency natural vocal conversational exchange with instant interruption / barge-in support.',
    icon: Mic,
    gradient: 'from-emerald-600 to-teal-600',
    status: 'active',
    toolTarget: 'two_way_voice_dialogue'
  },
  {
    id: 3,
    key: 'multilingual_translation',
    name: '3. Multilingual & Real-Time Translation',
    category: 'Immersion',
    description: 'Bilingual classroom subtitles in 20+ languages with colloquial code-switching and cultural analogies.',
    icon: Languages,
    gradient: 'from-cyan-600 to-blue-600',
    status: 'active',
    toolTarget: 'multilingual_translation'
  },
  {
    id: 4,
    key: 'auto_notes',
    name: '4. Automated Note-Taking & Summarisation',
    category: 'Intelligence',
    description: 'Cornell note generator with automatic LaTeX equation extraction, exam rubrics, and active recall cards.',
    icon: FileText,
    gradient: 'from-amber-600 to-orange-600',
    status: 'active',
    toolTarget: 'auto_note_generator'
  },
  {
    id: 5,
    key: 'gamification_rpg',
    name: '5. Gamification & Engagement Engine',
    category: 'Community',
    description: 'Interactive RPG quest learning with XP, streaks, level-ups, boss battles, and competitive leaderboards.',
    icon: Trophy,
    gradient: 'from-yellow-500 to-amber-600',
    status: 'active',
    toolTarget: 'gamification_rpg'
  },
  {
    id: 6,
    key: 'exam_simulator',
    name: '6. AI Exam Simulator & Assessment',
    category: 'Assessment',
    description: 'Official CBSE, JEE Main/Adv, NEET, and SAT timed mock exams with step-by-step partial marking.',
    icon: GraduationCap,
    gradient: 'from-rose-600 to-red-600',
    status: 'active',
    toolTarget: 'exam_simulator_hub'
  },
  {
    id: 7,
    key: 'ar_3d_visualizer',
    name: '7. Interactive 3D & Augmented Reality',
    category: 'Immersion',
    description: 'WebGL spatial models, molecule lattices, Lorentz orbits, and phone AR camera QR projection.',
    icon: Box,
    gradient: 'from-cyan-500 to-indigo-600',
    status: 'active',
    toolTarget: 'ar_3d_visualizer'
  },
  {
    id: 8,
    key: 'collaborative_rooms',
    name: '8. Collaborative & Peer Learning',
    category: 'Community',
    description: 'Virtual study breakout rooms, live co-solving whiteboards, and peer proof battle quests.',
    icon: Users,
    gradient: 'from-purple-600 to-pink-600',
    status: 'active',
    toolTarget: 'collaborative_study_rooms'
  },
  {
    id: 9,
    key: 'parent_teacher_portal',
    name: '9. Parent & Teacher Dashboard',
    category: 'Assessment',
    description: 'Diagnostic performance heatmaps, automated weekly report cards, and homework assignment generators.',
    icon: BarChart3,
    gradient: 'from-blue-600 to-indigo-600',
    status: 'active',
    toolTarget: 'parent_teacher_portal'
  },
  {
    id: 10,
    key: 'offline_mode',
    name: '10. Offline Mode & Low-Bandwidth Suite',
    category: 'Wellbeing',
    description: 'IndexedDB offline pack downloader, zero-buffer cached playback, and 85% data saver mode.',
    icon: WifiOff,
    gradient: 'from-sky-600 to-blue-700',
    status: 'active',
    toolTarget: 'offline_mode_manager'
  },
  {
    id: 11,
    key: 'wellbeing_coach',
    name: '11. Emotional & Well-Being Support',
    category: 'Wellbeing',
    description: 'Guided 4-7-8 diaphragmatic breathing loops, study stress checks, 20-20-20 eye strain timers.',
    icon: Heart,
    gradient: 'from-pink-500 to-rose-600',
    status: 'active',
    toolTarget: 'wellbeing_coach'
  },
  {
    id: 12,
    key: 'platform_integrator',
    name: '12. Educational Platform Integration',
    category: 'Community',
    description: 'Direct export to Google Classroom, Canvas LMS, Notion Study Binder, and Anki Flashcard Decks.',
    icon: Share2,
    gradient: 'from-violet-600 to-purple-700',
    status: 'active',
    toolTarget: 'platform_integrator'
  },
  {
    id: 13,
    key: 'accessibility_suite',
    name: '13. Accessibility & Universal Design',
    category: 'Wellbeing',
    description: 'Dyslexia weighted font, WCAG AAA high contrast, sign language visual cards, and screen reader live regions.',
    icon: Eye,
    gradient: 'from-amber-500 to-yellow-600',
    status: 'active',
    toolTarget: 'accessibility_suite'
  },
  {
    id: 14,
    key: 'career_pathways',
    name: '14. Career & Skill-Based Pathways',
    category: 'Intelligence',
    description: 'Learn-to-Earn industry career roadmaps, real-world portfolio tasks, and verifiable micro-credentials.',
    icon: Briefcase,
    gradient: 'from-emerald-600 to-green-700',
    status: 'active',
    toolTarget: 'career_pathways_hub'
  },
  {
    id: 15,
    key: 'spaced_repetition',
    name: '15. Adaptive Spaced Repetition (SRS)',
    category: 'Assessment',
    description: 'SuperMemo SM-2 interval scheduling engine calculating exact Ebbinghaus forgetting curves.',
    icon: Layers,
    gradient: 'from-indigo-600 to-blue-600',
    status: 'active',
    toolTarget: 'spaced_repetition'
  },
  {
    id: 16,
    key: 'predictive_analytics',
    name: '16. AI Learning Analytics & Insights',
    category: 'Intelligence',
    description: 'Cognitive load tracking, predictive rank projection bands, and comprehensive weekly mastery digests.',
    icon: TrendingUp,
    gradient: 'from-teal-600 to-cyan-700',
    status: 'active',
    toolTarget: 'predictive_analytics'
  },
  {
    id: 17,
    key: 'doubt_board',
    name: '17. Anonymous Chapter Doubt Board',
    category: 'Community',
    description: 'Safe zero-judgment peer & AI Q&A board per chapter with rotating pseudonyms and duplicate resolution.',
    icon: HelpCircle,
    gradient: 'from-amber-500 to-orange-600',
    status: 'active',
    toolTarget: 'doubt_board'
  },
  {
    id: 18,
    key: 'study_buddies',
    name: '18. Study Buddy Matching & Accountability',
    category: 'Community',
    description: 'Algorithmic peer pairing by learning velocity, daily check-ins, shared study goals, and anonymous matching.',
    icon: Users,
    gradient: 'from-purple-600 to-pink-600',
    status: 'active',
    toolTarget: 'study_buddies'
  },
  {
    id: 19,
    key: 'exam_simulator',
    name: '19. Full Official Exam Simulator',
    category: 'Assessment',
    description: 'Realistic exam simulation for CBSE, CISCE, JEE, NEET, SAT & CUET with strict invigilation, virtual answer sheet, and instant auto-evaluation.',
    icon: GraduationCap,
    gradient: 'from-rose-600 to-indigo-600',
    status: 'active',
    toolTarget: 'exam_simulator'
  },
  {
    id: 20,
    key: 'time_coach',
    name: '20. Time Management & Speed Coach',
    category: 'Assessment',
    description: '100ms precision time tracking per question/section, official exam benchmarks, rapid-fire speed runs, and 15s skip strategy drills.',
    icon: Timer,
    gradient: 'from-amber-500 to-indigo-600',
    status: 'active',
    toolTarget: 'time_coach'
  },
  {
    id: 21,
    key: 'pyq_intelligence',
    name: '21. 15+ Years PYQ Intelligence & Weightage Engine',
    category: 'Intelligence',
    description: '15-year past paper intelligence across CBSE, JEE, NEET, SAT & CUET with visual heatmaps, trend alert forensics, topic prediction, and custom priority matrix.',
    icon: Database,
    gradient: 'from-emerald-500 to-teal-600',
    status: 'active',
    toolTarget: 'pyq_intelligence'
  },
  {
    id: 22,
    key: 'mistake_journal',
    name: '22. AI Mistake Journal & Cognitive Error Taxonomy',
    category: 'Assessment',
    description: 'Auto-captures wrong answers with 7-category error classification, detects recurring patterns (sign errors, fatigue spikes), and assigns targeted concept remediation.',
    icon: Brain,
    gradient: 'from-rose-500 to-pink-600',
    status: 'active',
    toolTarget: 'mistake_journal'
  },
  {
    id: 23,
    key: 'device_tier',
    name: '23. Low-End Device Mode & Lite Smartboard',
    category: 'Immersion',
    description: 'Ultra-optimized 2D blackboard canvas, 64kbps audio-only lessons, <50MB/mo data saver, and automatic FPS/RAM progressive downgrade for 1GB RAM budget devices.',
    icon: Zap,
    gradient: 'from-amber-500 to-emerald-600',
    status: 'active',
    toolTarget: 'device_tier'
  }
];

export const MasterFeatureSuiteModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onLaunchFeature,
  theme = 'light'
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  if (!isOpen) return null;

  const filteredFeatures = MASTER_16_FEATURES.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          f.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'all' || f.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const isDark = theme === 'dark';

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className={cn(
        "w-full max-w-5xl h-[88vh] rounded-3xl border shadow-2xl flex flex-col overflow-hidden font-sans",
        isDark ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-900"
      )}>
        {/* Header */}
        <div className={cn(
          "px-6 py-5 border-b flex flex-wrap items-center justify-between gap-4",
          isDark ? "bg-slate-950/80 border-slate-800" : "bg-slate-50 border-slate-200"
        )}>
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Sparkles size={24} className="animate-spin" style={{ animationDuration: '8s' }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight">Professor Clarity Master Feature Suite</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  16 / 16 Features Active
                </span>
              </div>
              <p className="text-xs text-slate-400">
                The world-class AI pedagogical teaching, immersion, assessment & well-being engine
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Filter Bar */}
        <div className={cn(
          "px-6 py-3 border-b flex flex-wrap items-center justify-between gap-3 text-xs",
          isDark ? "bg-slate-950/40 border-slate-800/80" : "bg-white border-slate-100"
        )}>
          <div className="flex items-center gap-2">
            {['all', 'Intelligence', 'Immersion', 'Assessment', 'Wellbeing', 'Community'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={cn(
                  "px-3 py-1.5 rounded-lg font-bold capitalize transition cursor-pointer",
                  selectedCategory === cat
                    ? "bg-indigo-600 text-white shadow-sm"
                    : (isDark ? "bg-slate-800 text-slate-400 hover:text-slate-200" : "bg-slate-100 text-slate-600 hover:bg-slate-200")
                )}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search all 16 features..."
              className={cn(
                "w-full pl-8 pr-3 py-1.5 rounded-lg border text-xs outline-none transition",
                isDark ? "bg-slate-900 border-slate-750 text-slate-100 placeholder-slate-500 focus:border-indigo-500" : "bg-slate-100 border-slate-200 placeholder-slate-400"
              )}
            />
          </div>
        </div>

        {/* 16 Features Grid */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFeatures.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.id}
                className={cn(
                  "p-5 rounded-2xl border flex flex-col justify-between space-y-4 group transition-all duration-200 hover:-translate-y-0.5",
                  isDark 
                    ? "bg-slate-950/60 border-slate-800 hover:border-indigo-500/60 hover:shadow-xl hover:shadow-indigo-500/5" 
                    : "bg-white border-slate-200 hover:border-indigo-400 hover:shadow-md"
                )}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className={cn(
                      "w-10 h-10 rounded-xl bg-gradient-to-tr flex items-center justify-center text-white shadow-md",
                      feat.gradient
                    )}>
                      <Icon size={20} />
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-slate-800 text-slate-300">
                      {feat.category}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-sm font-black tracking-tight text-slate-100 group-hover:text-indigo-400 transition-colors">
                      {feat.name}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {feat.description}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between">
                  <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 size={12} /> Ready
                  </span>

                  <button
                    onClick={() => {
                      onLaunchFeature(feat.toolTarget);
                      onClose();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Play size={11} /> Launch Feature
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
