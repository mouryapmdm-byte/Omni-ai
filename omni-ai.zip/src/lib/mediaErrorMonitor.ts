import { useState, useEffect, useCallback, useRef } from 'react';
import { getPlaybackDiagnostics, PlaybackDiagnostic } from './videoHealth';

export type RecoveryStrategy = 'original' | 'proxy' | 'fallback' | 'native';

export interface TelemetryEvent {
  componentId: string;
  timestamp: number;
  src: string;
  errorCode: number;
  errorMessage: string;
  strategyAttempted: RecoveryStrategy;
  success: boolean;
}

/**
 * Singleton Class to monitor global media playback errors and track telemetry across all player instances.
 */
class CentralizedMediaErrorMonitor {
  private static instance: CentralizedMediaErrorMonitor;
  private listeners: Set<(events: TelemetryEvent[]) => void> = new Set();
  private telemetryLogs: TelemetryEvent[] = [];

  private constructor() {
    // Attempt to load historical logs from localStorage
    try {
      const stored = localStorage.getItem('omni_media_error_telemetry');
      if (stored) {
        this.telemetryLogs = JSON.parse(stored).slice(-50); // Keep last 50 events
      }
    } catch (e) {
      console.warn("Failed to load historical media telemetry logs:", e);
    }
  }

  public static getInstance(): CentralizedMediaErrorMonitor {
    if (!CentralizedMediaErrorMonitor.instance) {
      CentralizedMediaErrorMonitor.instance = new CentralizedMediaErrorMonitor();
    }
    return CentralizedMediaErrorMonitor.instance;
  }

  public logEvent(event: Omit<TelemetryEvent, 'timestamp'>) {
    const fullEvent: TelemetryEvent = {
      ...event,
      timestamp: Date.now()
    };
    this.telemetryLogs.push(fullEvent);
    if (this.telemetryLogs.length > 100) {
      this.telemetryLogs.shift();
    }

    try {
      localStorage.setItem('omni_media_error_telemetry', JSON.stringify(this.telemetryLogs));
    } catch (e) {
      // Ignore storage errors in full mode
    }

    this.notifyListeners();
  }

  public getLogs(): TelemetryEvent[] {
    return [...this.telemetryLogs];
  }

  public clearLogs() {
    this.telemetryLogs = [];
    localStorage.removeItem('omni_media_error_telemetry');
    this.notifyListeners();
  }

  public subscribe(listener: (events: TelemetryEvent[]) => void): () => void {
    this.listeners.add(listener);
    listener([...this.telemetryLogs]);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners() {
    const logsCopy = [...this.telemetryLogs];
    this.listeners.forEach(listener => {
      try {
        listener(logsCopy);
      } catch (err) {
        console.error("Telemetry listener error:", err);
      }
    });
  }
}

export const mediaErrorMonitor = CentralizedMediaErrorMonitor.getInstance();

export interface UseMediaMonitorProps {
  componentId: string;
  initialSrc: string;
  fallbackSrc: string;
  onSourceChange: (newSrc: string) => void;
}

export function useMediaErrorMonitor({
  componentId,
  initialSrc,
  fallbackSrc,
  onSourceChange
}: UseMediaMonitorProps) {
  const [strategy, setStrategy] = useState<RecoveryStrategy>('original');
  const [retryCount, setRetryCount] = useState(0);
  const [isRetrying, setIsRetrying] = useState(false);
  const [playbackError, setPlaybackError] = useState<string | null>(null);
  const [diagnosticReport, setDiagnosticReport] = useState<PlaybackDiagnostic | null>(null);
  const [recoveryNotice, setRecoveryNotice] = useState<string | null>(null);

  const retryTimerRef = useRef<NodeJS.Timeout | null>(null);
  const currentSrcRef = useRef(initialSrc);

  useEffect(() => {
    currentSrcRef.current = initialSrc;
  }, [initialSrc]);

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
    };
  }, []);

  const resetMonitor = useCallback(() => {
    setStrategy('original');
    setRetryCount(0);
    setIsRetrying(false);
    setPlaybackError(null);
    setDiagnosticReport(null);
    setRecoveryNotice(null);
    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
  }, []);

  const triggerRecovery = useCallback((
    targetSrc: string,
    errorCode: number,
    errorMessage: string
  ) => {
    const diag = getPlaybackDiagnostics({ code: errorCode, message: errorMessage } as MediaError, targetSrc);
    setDiagnosticReport(diag);

    const isBlob = targetSrc.startsWith('blob:');
    const isProxyUrl = targetSrc.includes('/api/proxy-video');

    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
    }

    // Logging event to global centralized monitor
    mediaErrorMonitor.logEvent({
      componentId,
      src: targetSrc,
      errorCode,
      errorMessage,
      strategyAttempted: strategy,
      success: false
    });

    // Strategy Sequence State Machine
    if (isBlob) {
      // Blob format error: Immediately fallback since proxying is impossible
      setStrategy('fallback');
      setPlaybackError(`Native playback failed for local blob container: ${errorMessage}`);
      setRecoveryNotice("Blob container codec error. Rerouting to a stable high-quality fallback stream.");
      onSourceChange(fallbackSrc);
    } else if (strategy === 'original' && !isProxyUrl) {
      // Attempt 1: Stream Proxy Recovery (exponential backoff)
      setIsRetrying(true);
      setRetryCount(1);
      setStrategy('proxy');
      setPlaybackError(`Attempt 1 failed: Codec or CORS error. Initiating secure stream proxy routing...`);

      const proxyUrl = `/api/proxy-video?url=${encodeURIComponent(targetSrc)}`;
      
      retryTimerRef.current = setTimeout(() => {
        setIsRetrying(false);
        onSourceChange(proxyUrl);
        setRecoveryNotice("Optimizing: Stream rerouted via server-side video proxy.");
      }, 1000); // 1 second backoff
    } else if (strategy === 'proxy' || isProxyUrl) {
      // Attempt 2: Full Standard Fallback (exponential backoff)
      setIsRetrying(true);
      setRetryCount(2);
      setStrategy('fallback');
      setPlaybackError(`Attempt 2 failed: Proxy routing failed. Falling back to default same-origin stream...`);

      retryTimerRef.current = setTimeout(() => {
        setIsRetrying(false);
        onSourceChange(fallbackSrc);
        setRecoveryNotice("Safe Fallback: Activated high-compatibility backup lecture stream.");
      }, 2000); // 2 second backoff
    } else {
      // Terminal Fallback State: Suggest native external player
      setStrategy('native');
      setPlaybackError(`Playback completely unavailable natively. Please use an external player or verify file formatting.`);
      setRecoveryNotice("Codec incompatibility detected. Open in separate window or try standard MP4 conversion.");
    }
  }, [componentId, strategy, fallbackSrc, onSourceChange]);

  const handleSuccessLoad = useCallback(() => {
    if (playbackError || diagnosticReport) {
      // Mark current strategy as successful in the log tracker
      mediaErrorMonitor.logEvent({
        componentId,
        src: currentSrcRef.current,
        errorCode: 0,
        errorMessage: 'Handshake complete',
        strategyAttempted: strategy,
        success: true
      });
    }
    setPlaybackError(null);
    setDiagnosticReport(null);
    setIsRetrying(false);
  }, [componentId, strategy, playbackError, diagnosticReport]);

  const forceStrategy = useCallback((newStrategy: RecoveryStrategy) => {
    if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
    setIsRetrying(false);
    setStrategy(newStrategy);

    if (newStrategy === 'original') {
      onSourceChange(initialSrc);
      setRecoveryNotice("Reset: Attempting playback with raw source stream.");
    } else if (newStrategy === 'proxy') {
      const proxyUrl = `/api/proxy-video?url=${encodeURIComponent(initialSrc)}`;
      onSourceChange(proxyUrl);
      setRecoveryNotice("Forced Recovery: Rerouting stream through proxy server.");
    } else if (newStrategy === 'fallback') {
      onSourceChange(fallbackSrc);
      setRecoveryNotice("Forced Fallback: Loading same-origin standard lecture backup.");
    } else if (newStrategy === 'native') {
      setRecoveryNotice("Direct play request initialized.");
    }
  }, [initialSrc, fallbackSrc, onSourceChange]);

  return {
    strategy,
    retryCount,
    isRetrying,
    playbackError,
    diagnosticReport,
    recoveryNotice,
    setRecoveryNotice,
    resetMonitor,
    triggerRecovery,
    handleSuccessLoad,
    forceStrategy
  };
}
