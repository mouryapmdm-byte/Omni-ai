import React, { useState } from 'react';
import { Globe, Check, Search, Sparkles, BookOpen, Layers, Volume2 } from 'lucide-react';
import { SupportedLanguageCode } from './types';
import { SUPPORTED_LANGUAGES } from './i18nConfig';
import { useI18n } from './useI18n';

interface LanguageSelectorProps {
  isDark?: boolean;
  onClose?: () => void;
  showNotification?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  isDark = true,
  onClose,
  showNotification
}) => {
  const { 
    language, 
    setLanguage, 
    bilingualMode, 
    toggleBilingualMode,
    prefersRegionalExamples,
    setPrefersRegionalExamples,
    formatNumber,
    formatCurrency,
    formatDate
  } = useI18n();

  const [searchQuery, setSearchQuery] = useState('');

  const languagesList = Object.values(SUPPORTED_LANGUAGES);

  const filteredLanguages = languagesList.filter(l => 
    l.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    l.nativeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    l.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelectLanguage = (code: SupportedLanguageCode) => {
    setLanguage(code);
    const meta = SUPPORTED_LANGUAGES[code];
    showNotification?.(`Language switched to ${meta.name} (${meta.nativeName})`, 'success');
  };

  return (
    <div className={`p-6 rounded-2xl border space-y-6 ${
      isDark ? 'bg-slate-900/90 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
    }`}>
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800/60">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold">Language & Cultural Localization</h2>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                11 Regional Languages
              </span>
            </div>
            <p className="text-xs opacity-60">Instant UI localization, bilingual side-by-side view, and Indian cultural analogies</p>
          </div>
        </div>
      </div>

      {/* Feature Mode Toggles */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Bilingual Mode Toggle */}
        <div className={`p-4 rounded-2xl border flex items-center justify-between gap-3 ${
          bilingualMode
            ? 'bg-indigo-950/20 border-indigo-500/50 text-indigo-100'
            : isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-xs">Bilingual Parallel Mode</h4>
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                English + Regional
              </span>
            </div>
            <p className="text-[11px] opacity-70 mt-0.5">
              Displays English and regional script side-by-side while preserving universal scientific formulas.
            </p>
          </div>
          <button
            onClick={toggleBilingualMode}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shadow ${
              bilingualMode
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {bilingualMode ? 'Active' : 'Off'}
          </button>
        </div>

        {/* Cultural Adaptation Toggle */}
        <div className={`p-4 rounded-2xl border flex items-center justify-between gap-3 ${
          prefersRegionalExamples
            ? 'bg-amber-950/20 border-amber-500/50 text-amber-100'
            : isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-xs">Cultural Scenario Adaptation</h4>
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                Cricket & Food
              </span>
            </div>
            <p className="text-[11px] opacity-70 mt-0.5">
              Adapts textbook physics & biology scenarios to Indian cricket, festival circuits, and culinary science.
            </p>
          </div>
          <button
            onClick={() => setPrefersRegionalExamples(!prefersRegionalExamples)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shadow ${
              prefersRegionalExamples
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {prefersRegionalExamples ? 'Active' : 'Off'}
          </button>
        </div>
      </div>

      {/* Language Search */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-3 opacity-50" />
        <input
          type="text"
          placeholder="Search language name (e.g. Hindi, Tamil, Telugu, Marathi)..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className={`w-full pl-9 pr-4 py-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
            isDark ? 'bg-slate-950/80 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
          }`}
        />
      </div>

      {/* Grid of Languages */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredLanguages.map(lang => {
          const isSelected = language === lang.code;

          return (
            <button
              key={lang.code}
              onClick={() => handleSelectLanguage(lang.code)}
              className={`p-3.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                isSelected
                  ? 'bg-indigo-600/20 border-indigo-500 text-white ring-2 ring-indigo-500 shadow-md'
                  : isDark ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300' : 'bg-slate-50 border-slate-200 hover:border-slate-400 text-slate-800'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="text-xl shrink-0">{lang.flagEmoji}</span>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs">{lang.name}</span>
                    {lang.dir === 'rtl' && (
                      <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-purple-500/20 text-purple-300">
                        RTL
                      </span>
                    )}
                  </div>
                  <span className="text-xs opacity-75 font-semibold block">{lang.nativeName}</span>
                </div>
              </div>

              {isSelected && (
                <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0">
                  <Check className="w-3.5 h-3.5" />
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Live Formats Preview */}
      <div className={`p-4 rounded-xl border text-xs grid grid-cols-1 sm:grid-cols-3 gap-3 ${
        isDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
      }`}>
        <div>
          <span className="text-[10px] uppercase font-bold opacity-60 block">Indian Numbering:</span>
          <span className="font-mono font-bold text-indigo-400">{formatNumber(1500000)}</span>
          <span className="text-[10px] opacity-60 block">(15 Lakhs)</span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold opacity-60 block">Currency Format:</span>
          <span className="font-mono font-bold text-emerald-400">{formatCurrency(49999)}</span>
          <span className="text-[10px] opacity-60 block">Rupees (₹)</span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold opacity-60 block">Standard Date Format:</span>
          <span className="font-mono font-bold text-amber-400">{formatDate(Date.now())}</span>
          <span className="text-[10px] opacity-60 block">DD/MM/YYYY</span>
        </div>
      </div>
    </div>
  );
};
