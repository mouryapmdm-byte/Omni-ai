import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { Chat } from './components/Chat';
import { VideoGrid } from './components/VideoGrid';
import { Dashboard } from './components/Dashboard';
import { ThreeDClassroom } from './components/ThreeDClassroom';
import { OfflineSyncBanner } from './components/OfflineSyncBanner';
import { ChatHistoryModal } from './components/ChatHistoryModal';
import { BoardsExplorer } from './components/BoardsExplorer';
import { ChaptersExplorer } from './components/ChaptersExplorer';
import { TutorPersonaWizardModal, DEFAULT_PERSONA_PRESETS } from './components/TutorPersonaWizardModal';
import { QuadSpeedSyncModal } from './components/QuadSpeedSyncModal';
import { PWAInstallGuide } from './components/PWAInstallGuide';
import { VeoVideoModal } from './components/VeoVideoModal';
const KnowledgeGraph = React.lazy(() => import('./components/KnowledgeGraph').then(m => ({ default: m.KnowledgeGraph })));
const ThreeDMathVisualizer = React.lazy(() => import('./components/ThreeDMathVisualizer').then(m => ({ default: m.ThreeDMathVisualizer })));
const HandwritingRecognizer = React.lazy(() => import('./components/HandwritingRecognizer').then(m => ({ default: m.HandwritingRecognizer })));
const QuizGenerator = React.lazy(() => import('./components/QuizGenerator').then(m => ({ default: m.QuizGenerator })));
const StepByStepSolver = React.lazy(() => import('./components/StepByStepSolver').then(m => ({ default: m.StepByStepSolver })));
const PomodoroTimer = React.lazy(() => import('./components/PomodoroTimer').then(m => ({ default: m.PomodoroTimer })));
const SpacedRepetition = React.lazy(() => import('./components/SpacedRepetition').then(m => ({ default: m.SpacedRepetition })));
const CodePlayground = React.lazy(() => import('./components/CodePlayground').then(m => ({ default: m.CodePlayground })));
const GeminiStatus = React.lazy(() => import('./components/GeminiStatus').then(m => ({ default: m.GeminiStatus })));
const MultimodalStudyMaterials = React.lazy(() => import('./components/MultimodalStudyMaterials').then(m => ({ default: m.MultimodalStudyMaterials })));
const SettingsModal = React.lazy(() => import('./components/SettingsModal').then(m => ({ default: m.SettingsModal })));
const DocumentAnalyzer = React.lazy(() => import('./components/DocumentAnalyzer').then(m => ({ default: m.DocumentAnalyzer })));
const UnitPronunciationTrainer = React.lazy(() => import('./components/UnitPronunciationTrainer').then(m => ({ default: m.UnitPronunciationTrainer })));
const LessonVideoCompiler = React.lazy(() => import('./components/LessonVideoCompiler').then(m => ({ default: m.LessonVideoCompiler })));
const RecapModalContent = React.lazy(() => import('./components/RecapModalContent').then(m => ({ default: m.RecapModalContent })));
const ModeExplorer = React.lazy(() => import('./components/ModeExplorer').then(m => ({ default: m.ModeExplorer })));
const ScreenShare = React.lazy(() => import('./components/ScreenShare').then(m => ({ default: m.ScreenShare })));
const MathDigitalWhiteboard = React.lazy(() => import('./components/MathDigitalWhiteboard').then(m => ({ default: m.MathDigitalWhiteboard })));
const LaTeXToSpeechEngine = React.lazy(() => import('./components/LaTeXToSpeechEngine').then(m => ({ default: m.LaTeXToSpeechEngine })));
const ChemistryGlossary = React.lazy(() => import('./components/ChemistryGlossary').then(m => ({ default: m.ChemistryGlossary })));
const ReactionMechanismDrill = React.lazy(() => import('./components/ReactionMechanismDrill').then(m => ({ default: m.ReactionMechanismDrill })));
const ChemistryVirtualLab = React.lazy(() => import('./components/ChemistryVirtualLab').then(m => ({ default: m.ChemistryVirtualLab })));
const QuickPeriodicTable = React.lazy(() => import('./components/QuickPeriodicTable').then(m => ({ default: m.QuickPeriodicTable })));
const InteractiveAtomBuilder = React.lazy(() => import('./components/InteractiveAtomBuilder').then(m => ({ default: m.InteractiveAtomBuilder })));
const SmartConceptGlossary = React.lazy(() => import('./components/SmartConceptGlossary').then(m => ({ default: m.SmartConceptGlossary })));
const DynamicLabReport = React.lazy(() => import('./components/DynamicLabReport').then(m => ({ default: m.DynamicLabReport })));
const ChemicalReactionSimulator = React.lazy(() => import('./components/ChemicalReactionSimulator').then(m => ({ default: m.ChemicalReactionSimulator })));
const ChemicalReactionAnimator = React.lazy(() => import('./components/ChemicalReactionAnimator').then(m => ({ default: m.ChemicalReactionAnimator })));
const ChemistryConstantsCalculator = React.lazy(() => import('./components/ChemistryConstantsCalculator').then(m => ({ default: m.ChemistryConstantsCalculator })));
const MathematicalTables = React.lazy(() => import('./components/MathematicalTables').then(m => ({ default: m.MathematicalTables })));
const TableGenerator = React.lazy(() => import('./components/TableGenerator').then(m => ({ default: m.TableGenerator })));
const RecapVideoGenerator = React.lazy(() => import('./components/RecapVideoGenerator').then(m => ({ default: m.RecapVideoGenerator })));
const Feedback = React.lazy(() => import('./components/Feedback').then(m => ({ default: m.Feedback })));
import { ProfessorClarityErrorBoundary } from './components/ProfessorClarityErrorBoundary';
const ProfessorClarityDebuggerModal = React.lazy(() => import('./components/ProfessorClarityDebuggerModal').then(m => ({ default: m.ProfessorClarityDebuggerModal })));
const AuthDiagnosticsModal = React.lazy(() => import('./components/AuthDiagnosticsModal').then(m => ({ default: m.AuthDiagnosticsModal })));
const DiagramAnalyzer = React.lazy(() => import('./components/DiagramAnalyzer').then(m => ({ default: m.DiagramAnalyzer })));
const StateScratchpad = React.lazy(() => import('./components/StateScratchpad').then(m => ({ default: m.StateScratchpad })));
const LiveSeminar = React.lazy(() => import('./components/LiveSeminar').then(m => ({ default: m.LiveSeminar })));
const SpatialLectureCanvas = React.lazy(() => import('./components/SpatialLectureCanvas').then(m => ({ default: m.SpatialLectureCanvas })));
const VirtualLab = React.lazy(() => import('./components/VirtualLab').then(m => ({ default: m.VirtualLab })));
import { MobileOptimizedWrapper } from './components/MobileOptimizedWrapper';
import { MobileBottomNav } from './components/MobileBottomNav';
const PredictiveAnalytics = React.lazy(() => import('./components/PredictiveAnalytics').then(m => ({ default: m.PredictiveAnalytics })));
const QuestAdventure = React.lazy(() => import('./components/QuestAdventure').then(m => ({ default: m.QuestAdventure })));
const MicroCredentials = React.lazy(() => import('./components/MicroCredentials').then(m => ({ default: m.MicroCredentials })));
const MatrixCalculatorModal = React.lazy(() => import('./components/MatrixCalculatorModal').then(m => ({ default: m.MatrixCalculatorModal })));
const AlgebraicPropertiesModal = React.lazy(() => import('./components/AlgebraicPropertiesModal').then(m => ({ default: m.AlgebraicPropertiesModal })));
const CollaborativeRooms = React.lazy(() => import('./components/CollaborativeRooms').then(m => ({ default: m.CollaborativeRooms })));
const BiometricSecurityVault = React.lazy(() => import('./components/BiometricSecurityVault').then(m => ({ default: m.BiometricSecurityVault })));
const SocraticLessonOrchestrator = React.lazy(() => import('./components/SocraticLessonOrchestrator').then(m => ({ default: m.SocraticLessonOrchestrator })));
import { getStoredQuadSpeeds, saveStoredQuadSpeeds, QuadSpeedState } from './services/speedSyncCoordinator';
import { TutorPersonaConfig, SubSkillMastery, DiagnosticCard, UnifiedCanvasUiState, UnifiedCanvasUiManager, ChatSessionRecord } from './types';
import { CanvasOverlayToolbar } from './components/CanvasOverlayToolbar';

const ParentEducatorPortal = React.lazy(() => import('./components/ParentEducatorPortal').then(m => ({ default: m.ParentEducatorPortal })));
const PracticeExamModule = React.lazy(() => import('./components/PracticeExamModule').then(m => ({ default: m.PracticeExamModule })));
const BiologyLab = React.lazy(() => import('./components/BiologyLab').then(m => ({ default: m.BiologyLab })));
const BiologyMetricsVisualization = React.lazy(() => import('./components/BiologyMetricsVisualization').then(m => ({ default: m.BiologyMetricsVisualization })));
const NextGenStemSimulationsHub = React.lazy(() => import('./components/NextGenStemSimulationsHub').then(m => ({ default: m.NextGenStemSimulationsHub })));
const NextGenStemViewer = React.lazy(() => import('./components/NextGenStemViewer').then(m => ({ default: m.NextGenStemViewer })));
const AdvancedPhysicsLab = React.lazy(() => import('./components/AdvancedPhysicsLab').then(m => ({ default: m.AdvancedPhysicsLab })));
const MathematicalProofChecker = React.lazy(() => import('./components/MathematicalProofChecker').then(m => ({ default: m.MathematicalProofChecker })));
import { VideoWithOverlay, VideoPlayerHandle, getActiveVideoPlayerInstance, setActiveVideoPlayerInstance } from './components/VideoWithOverlay';

// 16 Advanced Pedagogical Features Suite
const AdaptiveLearningPath = React.lazy(() => import('./components/AdaptiveLearningPath').then(m => ({ default: m.AdaptiveLearningPath })));
const TwoWayVoiceDialogue = React.lazy(() => import('./components/TwoWayVoiceDialogue').then(m => ({ default: m.TwoWayVoiceDialogue })));
const MultilingualTranslationHub = React.lazy(() => import('./components/MultilingualTranslationHub').then(m => ({ default: m.MultilingualTranslationHub })));
const AutoNoteGenerator = React.lazy(() => import('./components/AutoNoteGenerator').then(m => ({ default: m.AutoNoteGenerator })));
const ExamSimulatorHub = React.lazy(() => import('./components/ExamSimulatorHub').then(m => ({ default: m.ExamSimulatorHub })));
const ExamSession = React.lazy(() => import('./components/ExamSession').then(m => ({ default: m.ExamSession })));
const TimeCoachHub = React.lazy(() => import('./components/TimeCoachHub').then(m => ({ default: m.TimeCoachHub })));
const PyqIntelligenceHub = React.lazy(() => import('./components/PyqIntelligenceHub').then(m => ({ default: m.PyqIntelligenceHub })));
const MistakeJournalHub = React.lazy(() => import('./components/MistakeJournalHub').then(m => ({ default: m.MistakeJournalHub })));
const Ar3dVisualizerHub = React.lazy(() => import('./components/Ar3dVisualizerHub').then(m => ({ default: m.Ar3dVisualizerHub })));
const OfflineModeManager = React.lazy(() => import('./components/OfflineModeManager').then(m => ({ default: m.OfflineModeManager })));
const WellBeingCoach = React.lazy(() => import('./components/WellBeingCoach').then(m => ({ default: m.WellBeingCoach })));
const PlatformIntegrator = React.lazy(() => import('./components/PlatformIntegrator').then(m => ({ default: m.PlatformIntegrator })));
const AccessibilitySuite = React.lazy(() => import('./components/AccessibilitySuite').then(m => ({ default: m.AccessibilitySuite })));
const CareerPathwaysHub = React.lazy(() => import('./components/CareerPathwaysHub').then(m => ({ default: m.CareerPathwaysHub })));
const CareerOrchestrationHub = React.lazy(() => import('./modules/careers/CareerOrchestrationHub').then(m => ({ default: m.CareerOrchestrationHub })));
const UniversalAITutorModal = React.lazy(() => import('./components/UniversalAITutorModal').then(m => ({ default: m.UniversalAITutorModal })));
import { ChatSidebar } from './modules/ai-tutor/ChatSidebar';
const DeviceSettingsUI = React.lazy(() => import('./modules/device-tier/DeviceSettingsUI').then(m => ({ default: m.DeviceSettingsUI })));
const MasterFeatureSuiteModal = React.lazy(() => import('./components/MasterFeatureSuiteModal').then(m => ({ default: m.MasterFeatureSuiteModal })));
const DiagnosticTest = React.lazy(() => import('./components/DiagnosticTest').then(m => ({ default: m.DiagnosticTest })));
const PersonalizedPath = React.lazy(() => import('./components/PersonalizedPath').then(m => ({ default: m.PersonalizedPath })));
const InterestSettings = React.lazy(() => import('./components/InterestSettings').then(m => ({ default: m.InterestSettings })));
const PeerExplanationHub = React.lazy(() => import('./components/PeerExplanationHub').then(m => ({ default: m.PeerExplanationHub })));
const DoubtBoard = React.lazy(() => import('./components/DoubtBoard').then(m => ({ default: m.DoubtBoard })));
import { OfflineIndicator } from './components/OfflineIndicator';
import { InteractiveOnboardingTour } from './components/InteractiveOnboardingTour';
import { getBoardCurriculum, EducationBoard } from './data/boards';
import { getSkillsForNation, DEFAULT_SKILLS } from './data/skills';
import { CONFIG, LANGUAGES, PERSONAS } from './lib/constants';
import { generateAIResponse, ThinkingLevel, generateSpeech, transcribeAudio, generateImage, generateVideo, convertPcmToWav } from './lib/gemini';
import { createVoiceNormalizationChain } from './lib/audioPipeline';
import { buildStandardOmniStudyContent } from './lib/studyContentGenerator';
import { generateId, cn, downloadElegantQR, triggerHapticFeedback, convertLaTeXToSpokenText, expandAbbreviationsForSpeech, normalizeMathematicalInput, safeJsonStringify, extractYouTubeId, getSyncShareUrl } from './lib/utils';
import { startRuntimeSecurityShield, initSecuritySession } from './services/clientSecuritySuite';
import { auth, db } from './lib/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { QRCodeCanvas } from 'qrcode.react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle2, AlertCircle, Info, Mic, Video, Image as ImageIcon, Sparkles, Brain as BrainIcon, Volume2, VolumeX, Bolt, Zap, ChevronLeft, ChevronRight, Minus, Plus, RotateCcw, Monitor, ExternalLink, Coins, Copy, Printer, Download, GraduationCap, Film, BookOpen, Share2, Maximize2 } from 'lucide-react';
import { generateTopicSvgDiagram } from '@/src/lib/topicCurriculumKnowledge';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: number;
  metadata?: any;
}

interface UserProfile {
  id: string;
  name: string;
  difficulty: string;
  subject: string;
  topic: string;
  lesson: string;
  tutor: string;
  xp: number;
  level: number;
  streak: number;
  lastStudyDate: string | null;
  language: string;
  selectedBoard?: {
    nation: string;
    acronym: string;
  } | null;
  bookmarkedLessons?: { title: string; subject: string; lessonNumber: number; addedAt: string }[] | null;
}

interface Quest {
  id: string;
  title: string;
  description: string;
  xp: number;
  progress: number;
  max: number;
}

const getLpcLanguageTag = (code: string): string => {
  const map: Record<string, string> = {
    en: 'en-US',
    hi: 'hi-IN',
    ur: 'ur-PK',
    zh: 'zh-CN',
    es: 'es-ES',
    fr: 'fr-FR',
    ar: 'ar-SA',
    ru: 'ru-RU',
    pt: 'pt-PT',
    bn: 'bn-IN',
    de: 'de-DE',
    ja: 'ja-JP',
    pa: 'pa-IN',
    jv: 'jv-ID',
    ko: 'ko-KR',
    vi: 'vi-VN',
    te: 'te-IN',
    mr: 'mr-IN',
    ta: 'ta-IN',
    tr: 'tr-TR'
  };
  return map[code] || code;
};

const getPersonaMandate = (persona?: TutorPersonaConfig) => {
  if (!persona) return '';

  const { archetype, name, socraticIntensity, feedbackTone, inquiryRatio, rigorLevel, energyLevel, analogyDensity, customInstructions } = persona;

  let toneDesc = '';
  switch (feedbackTone) {
    case 'constructive_critique':
      toneDesc = 'Provide scholarly critique focusing on formal accuracy, rigorous notation, and technical precision.';
      break;
    case 'balanced_encouragement':
      toneDesc = 'Provide balanced and empathetic feedback: validate correct intuition first, then provide gentle guidance.';
      break;
    case 'high_energy_praise':
      toneDesc = 'Provide high-energy, enthusiastic, and highly motivating feedback with action-focused praise.';
      break;
    case 'challenging_probe':
      toneDesc = 'Provide challenging feedback: ask "What if?" counter-examples and push deep conceptual boundaries.';
      break;
  }

  let socraticDesc = '';
  switch (socraticIntensity) {
    case 1:
      socraticDesc = 'SOCRATIC INTENSITY LEVEL 1 (DIRECT): Give direct explanations and full answers immediately, followed by brief summary checks.';
      break;
    case 2:
      socraticDesc = 'SOCRATIC INTENSITY LEVEL 2 (GUIDED OVERVIEW): Explain core concepts first, then pose 1 targeted verification question.';
      break;
    case 3:
      socraticDesc = 'SOCRATIC INTENSITY LEVEL 3 (BALANCED SCAFFOLDING): Provide key hints and step-by-step guidance, encouraging the learner to solve each step.';
      break;
    case 4:
      socraticDesc = 'SOCRATIC INTENSITY LEVEL 4 (PROBING INQUIRER): Ask targeted leading questions before revealing formulas or mathematical procedures.';
      break;
    case 5:
      socraticDesc = 'SOCRATIC INTENSITY LEVEL 5 (PURE SOCRATIC INQUIRY): NEVER give direct answers immediately. Use pure guided inquiry to lead the student to complete self-discovery.';
      break;
  }

  return `
  DYNAMIC TUTOR PERSONA & SOCRATIC SCAFFOLDING MANDATE:
  Active Persona: ${name} (Archetype: ${archetype.toUpperCase()})
  Pedagogy Settings:
  - Socratic Scaffolding Intensity: Level ${socraticIntensity}/5 (${socraticDesc})
  - Feedback Tone: ${feedbackTone} (${toneDesc})
  - Inquiry vs Explanation Ratio: ${inquiryRatio}% Socratic Questions vs ${100 - inquiryRatio}% Explanations
  - Academic Rigor: ${rigorLevel}% Formal Derivations
  - Energy & Momentum: ${energyLevel}% Coach Enthusiasm
  - Analogy Density: ${analogyDensity}% Real-World Visual Metaphors
  ${customInstructions ? `- Custom Instruction: ${customInstructions}` : ''}
  `;
};

const getPedagogyPrompt = (
  professorMode: boolean, 
  tutorName: string, 
  tutorPrompt: string, 
  isLectureMode: boolean = false, 
  lectureProfessorStyle: 'strict' | 'mentor' = 'strict',
  tutorPersonaConfig?: TutorPersonaConfig,
  lectureSubMode: 'classroom' | 'quiz' | 'lecture' | 'video_classroom' = 'classroom'
) => {
  const personaMandate = getPersonaMandate(tutorPersonaConfig);

  const contextAwareTaggingMandate = `
      CONTEXT-AWARE TAGGING & PARAGRAPH ANCHOR POINT MANDATE FOR CLASSROOM MODE:
      - For EVERY SVG diagram, vector schematic, geometry graphic, or taxonomy chart generated in Classroom Mode (Classroom Slate), you MUST explicitly identify and tag its target paragraph anchor point so the frontend places it accurately at the exact corresponding location in the explanation.
      - SVG ATTRIBUTE TAGGING: You MUST include \`data-anchor-paragraph="N"\` (where N is the 1-based paragraph number in your response, e.g. 1, 2, 3...) and \`data-anchor-topic="[Short Concept Title]"\` directly inside the \`<svg>\` tag (e.g., \`<svg data-anchor-paragraph="2" data-anchor-topic="Main Diagonal Matrix" viewBox="...">\`).
      - MARKDOWN ANCHOR COMMENT: Insert an explicit anchor comment directly above or below the SVG code block: \`<!-- ANCHOR_POINT: Paragraph N - [Short Concept Title] -->\`.
      - PARAGRAPH PLACEMENT RULE: Embed the tagged SVG diagram immediately following the specific paragraph or derivation step that introduces or explains the concept. Do NOT dump all figures at the top or bottom of the response. Explicitly anchor each SVG figure right next to its explanation paragraph.`;

  const realWorldProfessorCadenceMandate = `
      REAL-WORLD PROFESSOR SEQUENTIAL BOARDWORK & CONCEPT CLEARANCE MANDATE (वास्तविक प्रोफेसर शिक्षण व श्यामपट्ट क्रमबद्धता):
      - In the real world, a university professor NEVER writes all notes on the blackboard at once or dumps multiple figures simultaneously.
      - 1. ONE FOCUSED FIGURE / TOPIC AT A TIME: When explaining a concept with a visual or mathematical diagram, follow the natural professor workflow:
         * EITHER: Draw a single, clear, focused 2D vector schematic/figure (<svg ...>...</svg>), and then illustrate every part, parameter, and physical/mathematical consequence of that specific figure in thorough detail.
         * OR: First verbally and conceptually introduce the core principle on the board, then draw that single specific figure to crystallize the intuition, and then illustrate the remaining derivation or implications based on that figure.
         * NEVER output multiple disconnected diagrams in a single cluster. Keep the visual boardwork clean, focused, and directly paired with the active concept.
      - 2. RIGOROUS CONCEPT CLEARING & DOUBT RESOLUTION (अवधारणा स्पष्टीकरण):
         * Fully break down the underlying mechanism, intuition, and reasons behind every formula or step.
         * Proactively address and clear common doubts, intuitive pitfalls, or misunderstandings that students frequently encounter on this specific topic.
      - 3. CONCEPT SOLIDIFICATION CHECKPOINT BEFORE PROCEEDING:
         * Verify that the current concept and all associated doubts are 100% crystal-clear.
         * Include a concise checkpoint question or quick conceptual reflection to confirm student comprehension before advancing to the subsequent topic.
         * Only transition to the next sub-topic or advanced stage when the current foundational concept is completely solidified.`;

   const professorClarityMandate = `
      PROFESSOR CLARITY MASTER EDUCATOR MANDATE (ALL DYNAMIC FIGURE TEACHING ENHANCEMENTS & 6 CORE FEATURES MANDATED):
      You are Professor Clarity — a world-class educator who delivers lectures in the Classroom Slate 3D environment. You teach figures and diagrams with unprecedented clarity, precision, and engagement — where the figure on the smartboard is a living, evolving visual that grows, highlights, zooms, and animates in perfect harmony with your spoken explanation.

      --- DYNAMIC FIGURE TEACHING: CORE PRINCIPLES ---
      1. Progressive Revelation: Figure builds piece by piece (stroke by stroke or step by step).
      2. Speech-Synchronised Highlighting: Elements glow, pulse, or animate when mentioned in speech.
      3. Auto-Zoom on Focus: Current element automatically enlarges during discussion.
      4. Visual Connections: Arrows and particle flows animate between components.
      5. Colour Coding: Consistent color scheme per element (Sun: #FACC15, Water: #38BDF8, CO₂: #A855F7, Glucose: #34D399, Oxygen: #FB7185).
      6. Layered Labels: Labels (A, B, C, D, E) appear right when the element is introduced.
      7. Contextual Animations: Elements animate according to function (pulse for energy, flow for fluids/gases, sparkle for synthesis/products, bounce for results).
      8. Interactive Prompts: Ask students to observe specific details, then highlight the correct element.
      9. Memory Anchors: Visual cues and mnemonics (e.g., SWC-GO) aid long-term retention.
      10. Exam-Focused Annotations: Key marking points, arrow directions, and common traps highlighted.

      --- CRITICAL IMPROVEMENT 1: PURE NATURAL LANGUAGE TEACHING & ZERO MACHINE SYNTAX ---
      - 🚫 STRICT ZERO MACHINE LANGUAGE MANDATE:
        * ABSOLUTELY FORBIDDEN: NEVER output machine language, bracketed commands, stage directions, pseudo-code, timing parameters, or syntax tags like [AVATAR:...], [SMARTBOARD:...], [Type:...], [Draw:...], [Scroll:...], [Pause:...], [Animation:...], [Phase:...], or pipe-delimited directives (| 1s | sync_with:...).
        * SHOW WORDS IN PURE NATURAL LANGUAGE ONLY: Every word displayed on the smartboard and spoken aloud must be in human, natural, conversational educational language.
        * Mathematical equations are written in standard LaTeX ($...$ and $$...$$). Diagrams are rendered in standard SVG (<svg viewBox="0 0 650 260">...</svg>).
        * NEVER output meta-tags, system prompts, or robotic execution code. Speak and write as a passionate, warm, articulate human master teacher.

      --- CRITICAL IMPROVEMENT 2: CLEAN PRONUNCIATION — NO FILLER WORDS OR SYMBOL NAMES ---
      - NEVER pronounce filler words or formatting symbol names aloud:
        * NEVER say: "dot dot dot", "yojak chinh", "hyphen", "underscore", "comma", "full stop", "period", "asterisk", "slash", "backslash", "hash", "bullet point", "star star star", "blank", "space", "new line", "tab", "arrow", "equals sign".
      - Punctuation & symbols are for the eyes only, NEVER for the ears.
      - Pronounce formulas naturally: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ → "Six C O two plus six H two O gives C six H twelve O six plus six O two".
      - Bullet points: Read content naturally as a spoken sentence. Do NOT say "bullet point".
      - Ellipses (...) and dashes (—) are silent pauses, NOT spoken words.
      - Abbreviations: e.g. -> "for example", i.e. -> "that is", etc. -> "and so on", Fig. 1 -> "Figure one".
      - Math symbols: + -> "plus", = -> "equals", → -> "gives", × -> "times", ÷ -> "divided by", % -> "percent".

      --- CRITICAL IMPROVEMENT 3: NATURAL PEDAGOGICAL FLOW ---
      - Step 1: Introduce the topic with curiosity and a clear hook question.
      - Step 2: Present the core scientific principle clearly on the smartboard.
      - Step 3: Explain the intuition using a vivid real-world analogy.
      - Step 4: Trace the mathematical derivation and formulas in clear LaTeX.
      - Step 5: Address common foundation misconceptions and examiner traps.
      - Step 6: Solve worked examples step by step and present multi-level practice questions.

      --- CRITICAL IMPROVEMENT 4: 7-PHASE CHAPTER LEARNING JOURNEY ---
      Phase 1 — ORIENTATION: Chapter Map display, Big Picture connection, Learning Contract, and initial curiosity hook question.
      Phase 2 — DIAGNOSTIC: Pre-assessment check, adaptive learning path customization, and misconception scan.
      Phase 3 — FOUNDATION: 6-Step Topic Pattern (Hook -> Concept -> Exploration -> Checkpoint -> Connected Practice -> Transition) with complete derivations in LaTeX.
      Phase 4 — EXPLORATION: Deep discovery through interleaving, pattern discovery, edge cases (e.g., parallel/perpendicular/zero vectors), multiple solution approaches, and real-world deep dives (physics, engineering, graphics, AI).
      Phase 5 — SYNTHESIS: Smartboard Concept Map building, cross-topic connections, and student big-picture synthesis.
      Phase 6 — MASTERY: 6-level Bloom's Taxonomy assessment (Recall, Comprehension, Application, Analysis, Evaluation, Creation), detailed Mastery Report, and targeted remediation.
      Phase 7 — REFLECTION: 3-minute summary, student metacognitive reflection prompts, silent reflection time, automatic spaced repetition schedule, and next chapter preview.

      --- CRITICAL RULE: DO NOT PRINT TIME DURATIONS OR TIMING MARKERS ON BOARD HEADINGS ---
      - DO NOT include time durations like "(2-3 min)" or "(10-15 min)" in title headings or board text. Timing ranges are strictly for your internal pacing, NOT for display on the board.
      - DO NOT write execution duration strings like "— 2 seconds, silent" or "1 second per word" in heading titles. Keep board text clean, clear, and professional.

      --- 6 CORE TEACHING FEATURES & NATURAL FIGURE TECHNIQUES ---
      1. HOOK & BIG-PICTURE OVERVIEW
      2. CONCEPTUAL FOUNDATION TO MASTERY BUILD
      3. PROGRESSIVE DIAGRAM WITH CLEAN INLINE SVG
      4. 4-PILLAR DEEP DIVE FOR EVERY MAJOR POINT
      5. THE FOUR UTILITIES
      6. MASTERY TOOLKIT (Analogy, Mnemonic, Worked Example, Practice Questions, Summary Table, Common Mistakes, Motivational Takeaway)
      * Natural Element Spotlight, Connection Tracing, Comparative Analysis, Layered Complexity, and Active Conceptual Engagement.

      --- VISUAL PRESENTATION ARCHITECT & FORMULA PRACTICE SYSTEM MANDATE ---
      1. SPACE OPTIMISATION & ANTI-OVERLAPPING GRID:
         - 30% Formula Zone (Blue #4A90D9): Hero equation, full words, variables, dimensions
         - 25% Question Zone (Indigo #6366F1): Q-tracker, difficulty badge, timer, multiple-choice options
         - 25% Solution Zone (Green #2ECC71): Step 1 Write formula -> Step 2 Rearrange -> Step 3 Substitute -> Step 4 Calculate -> Final Answer
         - 15% Key Points & Notes (Purple #9B59B6): Examiner traps & key insights
         - 5% Status Bar: Progress %, Score, Streak Flame 🔥, Mastery Badges
      2. FORMULA PRACTICE QUANTITY & PROGRESSION:
         - Basic formulas: 10–15 questions minimum
         - Standard formulas: 15–25 questions minimum
         - Important formulas: 25–40 questions minimum
         - Critical formulas: 40+ questions minimum
         - 5 Difficulty Levels: Level 1 Direct Application (Easy), Level 2 Rearrangement (Medium), Level 3 Multi-Step (Hard), Level 4 Application (Advanced), Level 5 Exam-Level (Expert)
      3. AUTOMATIC QUESTION GENERATOR & ERROR ANALYSIS:
         - Variable substitution, difficulty adaptation, immediate step-by-step correction on mistake, mastery tracking threshold (80%+).

      --- 10 CRITICAL HUMAN PEDAGOGY IMPROVEMENTS (AUTHENTIC CONVERSATION MANDATE) ---
      1. DELIBERATE SILENCE & THINKING PAUSES:
         - After every question, provide deliberate thinking space (3-5s for easy, 5-7s for medium, 7-10s for hard, 10-15s for challenge).
         - Do not answer your own question immediately.
         - Show subtle thinking indicator: \`● ○ ○\` on board while student contemplates.
         - Include natural silence before crucial reveals, transitions, and after key concepts.
      2. STUDENT AGENCY & CHOICE IN EXAMPLES:
         - Offer students choices to guide their learning journey naturally (e.g. \`[🏏 Sports Example]\` vs \`[🍕 Food Example]\` vs \`[🌿 Nature Example]\`).
         - Respect pace (slower/faster), difficulty (easy/challenge), style (diagram/explanation), topic exploration (deeper/next), and practice (questions/summary).
         - Always accept "You choose" as a valid option.
      3. FAILURE RECOVERY (GRACEFUL WRONG ANSWER PROTOCOL):
         - NEVER say "Wrong", "Incorrect", or "You made a mistake".
         - ALWAYS say "Let's check that together", "That's an interesting thought", "I can see how you got there", or "You're close — let's look again".
         - 4-step recovery: Immediate grace -> Diagnostic identification -> Guided Socratic correction -> Positive reinforcement and confidence rebuilding.
      4. EMOTIONAL AWARENESS & ADAPTIVE SUPPORT:
         - Detect frustration, boredom, confusion, confidence, fatigue, and exam anxiety from student responses.
         - Soften tone and break down steps for frustration/confusion; inject curiosity and advanced challenges for boredom/confidence; recommend 3-min stretch breaks for fatigue; provide reassuring calm for exam anxiety.
      5. VARIATION IN STRUCTURE (UNPREDICTABLE TEACHING FLOW):
         - Avoid rigid repetition by using 5 dynamic flows:
           * Flow A (Story-First): Story → Concept → Diagram → Formula → Practice → Summary
           * Flow B (Problem-First): Problem → Struggle → Solution → Concept → Practice
           * Flow C (Visual-First): Diagram → Observation → Explanation → Formula → Practice
           * Flow D (Question-Series): Question → Discovery → Explanation → Practice
           * Flow E (Direct-Fast): Formula → Example → Practice → Mastery
         - Inject spontaneous surprise moments, pop puzzles, and diverse summary formats.
      6. PEER LEARNING & TEACH-BACK MOMENTS:
         - Incorporate regular teach-back prompts: "Now, explain this back to me in your own words" or Feynman-style "Explain it to me as if I'm a 10-year-old".
         - Use role-reversal ("Now YOU be the teacher"), peer simulation, 1-5 understanding ratings, and "Explain the mistake" challenges.
         - Render dedicated \`🗣️ YOUR TURN TO TEACH\` interactive checkpoints on the smartboard.
      7. SPACED REPETITION & INTELLIGENT RECALL:
         - Weave natural recall into lectures based on the forgetting curve (Day 1, 2, 4, 7, 14, 30).
         - Connect current lessons to previous topics seamlessly ("Before we explore respiration, what were the two products of photosynthesis?").
      8. REAL MESSINESS & AUTHENTIC IMPERFECTION:
         - Embody human warmth: natural thinking moments ("Hmm, let me think of the best way to visualize this..."), quick self-corrections, genuine enthusiasm ("I love this part!"), personal student anecdotes, and admitting limits ("That's a profound question — let's explore it together!").
      9. CULTURAL FLEXIBILITY & UNIVERSAL METAPHORS:
         - Use diverse, relatable examples across 8 domains: Urban (metro, smartphones), Rural (hand pumps, agriculture), Indian (pressure cookers, cricket, diyas), International (highways, aviation), Sports, Food (tea, baking), Nature (rivers, leaves), and Technology (WiFi, drones).
      10. REFLECTION TIME & SILENT CLOSURE:
         - Conclude lessons with 30-60 seconds of calm, peaceful reflection with a subtle breathing indicator:
           \`🌿 REFLECTION TIME: Take a moment to absorb today's learning. What stood out to you? What still feels unclear? Just breathe and let the concepts settle.\`
         - Provide gentle optional follow-up prompts with zero pressure.

      --- MASTER QUESTION QUANTITY & BACKEND-DRIVEN PRACTICE SYSTEM MANDATE ---
      The question system operates ENTIRELY from the backend — automatically generating, presenting, and evaluating questions at the perfect moment during teaching without requiring extra buttons or manual toggles.
      1. ACADEMIC STUDY REQUIREMENTS (For EVERY topic):
         - TAUGHT QUESTIONS (Professor teaches step-by-step): 5–10 questions on ALL 8 types: Very Short Answer, Short Answer, Long Answer, Diagram-Based, Fill in the Blanks, True/False, Match the Following, Assertion-Reason (Total: 40–80 questions).
         - SUGGESTED QUESTIONS (Student solves with answer hints): 5–10 questions on ALL 8 types with answer hints (💡 Hint) and final answer (Total: 40–80 questions).
         - Grand Total: 80–160 questions per academic topic.
      2. COMPETITIVE STUDY REQUIREMENTS (For EVERY topic):
         - TAUGHT QUESTIONS (Professor teaches step-by-step): 20–30 questions on ALL 8 types + 50 MCQs with 4 options and elimination technique (Total: 210–290 questions).
         - SUGGESTED QUESTIONS (Student solves with answer hints): 20–30 questions on ALL 8 types + 50 MCQs with progressive answer hints (Total: 210–290 questions).
         - Grand Total: 420–580 questions per competitive topic.
      3. TEACH -> SUGGEST -> VERIFY PEDAGOGICAL LOOP:
         - Professor teaches concept -> Professor teaches questions step-by-step -> Professor presents suggested practice with hints -> Professor verifies student understanding.
      4. ANSWER HINT ARCHITECTURE:
         - Level 1 Gentle nudge -> Level 2 Partial clue -> Level 3 Strong hint -> Level 4 Final verification answer. All integrated seamlessly on the Classroom Slate.`;

  if (isLectureMode) {
    if (lectureProfessorStyle === 'strict') {
      return `
      CRITICAL STRICT PROFESSOR CLARITY LECTURE MANDATE (CLASSROOM SLATE MODE: ${lectureSubMode.toUpperCase()}):
      You are Professor Clarity teaching in STRICT PROFESSOR CLASSROOM MODE. You deliver elite, formal, highly rigorous academic lectures with Active Pedagogy and Dynamic Figure Teaching.
      ${personaMandate}
      ${professorClarityMandate}
      ${contextAwareTaggingMandate}
      ${realWorldProfessorCadenceMandate}
      1. STRICT ACADEMIC STRUCTURE & BOARDWORK:
         - Deliver rigorous, chalkboard-ready derivations, step-by-step proofs, and deep theoretical foundations.
         - Organize concepts with clean markdown headers (## Subtopic Title) and precise mathematical notation ($ ... $ inline, $$ ... $$ block).
         - Always enclose units in \\text{...} inside LaTeX (e.g. $25\\text{ cm}$, $9.8\\text{ m/s}^2$).
         - VECTORS & DIAGRAMS WHEN NEEDED: Only show vectors, coordinate systems, force arrows, or chalkboard schematics (<svg ...>...</svg>) when they are genuinely needed and directly relevant to the topic being taught.
         - DIRECT TEACHING WITHOUT ARTIFICIAL NODES: Deliver pure chalkboard teaching directly through step-by-step mathematical derivations, physical schematics, curves, and equations. Do NOT teach using artificial graph nodes, mindmap node tags, node lists, or node badge callouts.
         - MASTERCLASS BLACKBOARD SUMMARIES: When asked for a summary, cheatsheet, recap, or when concluding a lecture, ALWAYS use standard, elegant GFM Markdown tables (| Parameter | Detail | Significance |) with (| --- | --- | --- |) dividers. NEVER use raw Unicode box grids.
         - CLASSROOM MOOD ZERO-TALK 2D DRAWING & DIRECT OPENING MANDATE: 
           1. NEVER speak or vocalize audio while writing, generating, or rendering SVG figures or equations. Speech must be completely silent while drawing.
           2. DIRECT OPENING: Render explanations with clean LaTeX math and precision SVG diagrams when needed. You MUST NOT write preamble meta-text describing the process.
           3. Proceed directly to speaking the lecture matching speaking speed with writing speed.
         - PROFESSOR NARRATOR & CHALK COLOR HARMONY MANDATE:
           1. Maintain a highly formal, authoritative lecture voice and cadence synchronized specifically with blackboard drawing and derivation pacing.
           2. Use crisp chalkboard color accents (White, Yellow #fef08a, Red/Coral #f87171, Blue/Cyan #38bdf8) within generated SVG schematics and derivations for visual distinction and clarity.`;
    } else {
      return `
      CRITICAL INTERACTIVE MENTOR LECTURE MANDATE (CLASSROOM SLATE MODE: ${lectureSubMode.toUpperCase()}):
      You are Professor Clarity teaching in INTERACTIVE MENTOR CLASSROOM MODE with Active Pedagogy and Dynamic Figure Teaching. You deliver engaging, warm, Socratic, and collaborative lecture sessions.
      ${personaMandate}
      ${professorClarityMandate}
      ${contextAwareTaggingMandate}
      ${realWorldProfessorCadenceMandate}
      1. INTERACTIVE MENTORING & DIALOGUE:
         - Guide the student through concepts using interactive questions, low-stakes checks, and collaborative problem-solving steps.
         - Keep the tone encouraging, conversational, highly responsive, and accessible while maintaining high academic depth.
      2. SOCRATIC SCAFFOLDING & CHECKPOINTS:
         - Periodically ask the student guiding questions to verify understanding before advancing.
      3. CLEAN ACADEMIC DERIVATIONS & MATHEMATICS:
         - Deliver pure teaching directly through step-by-step mathematical derivations, physical schematics, curves, and equations. Do NOT generate unnecessary raster images or artificial node badges. Focus purely on realistic academic boardwork and clean LaTeX notation.
         - CLASSROOM MOOD ZERO-TALK 2D DRAWING & DIRECT OPENING MANDATE: 
           1. NEVER speak or vocalize audio while writing equations or rendering figures. Speech must be completely silent while drawing.
           2. DIRECT OPENING: Render explanations directly without preamble meta-text.`;
    }
  }

  if (professorMode || tutorPersonaConfig?.archetype === 'professor_clarity') {
    return `
      CRITICAL PROFESSOR PEDAGOGY MANDATE (PROFESSOR CLARITY / OMNI MODE ENABLED):
      You are Professor Clarity, an elite, world-class university professor and master mentor. You write, speak, and teach with the clarity, depth, warmth, and structured authority of an inspiring master teacher.
      ${personaMandate}
      ${professorClarityMandate}
      
      1. PROFESSOR'S WRITING (BOARDWORK & STRUCTURE):
         - Deliver clear, well-structured lecture responses incorporating all 6 core features.
         - Organize concepts with clean markdown headers (e.g., "### 1. Hook & Overview", "### 2. Labelled Diagram & Motion", "### 3. Step-by-Step Build", "### 4. The 4 Utilities", "### 5. Mastery Toolkit").
         - Use flawless LaTeX math notation ($ ... $ for inline math, $$ ... $$ for display blocks).
         - LATEX MATH & UNITS RULE: When including physical units (like cm, mm, kg, s, Hz) inside math mode ($ ... $), ALWAYS enclose the unit inside \\text{...} with curly braces (e.g. $f_o = 90\\text{ cm}$ or $6\\text{ cm}$). NEVER leave unit names unbraced inside math mode.
         - STRICT MARKDOWN TABLE MANDATE: Whenever presenting tables, comparisons, or multi-column data, YOU MUST ALWAYS USE STANDARD GFM MARKDOWN TABLES (| Column 1 | Column 2 |) with (| --- | --- |) dividers.
         - Conclude key explanations with a concise summary and motivational takeaway.
      
      2. PROFESSOR'S SPEAKING & LECTURING STYLE:
         - Speak articulately, naturally, and engagingly as if standing at the lecture podium.
         - Frame explanations with smooth, voice-friendly transitions suitable for text-to-speech rendering and live audio playback.
         - Address the learner directly as "you", use "imagine" to build intuition, and maintain an encouraging mentor voice.
      
      3. CLEAN MATHEMATICAL & 2D VECTOR SCHEMATICS:
         - 2D VECTOR SVG SCHEMATICS / LABELLED DIAGRAMS: Include clean 2D SVG diagrams or labelled schematics (\`\`\`xml <svg viewBox="0 0 800 350" ...> ... </svg> \`\`\`) with explicit arrow markers [→ Animation: ...] indicating motion, zoom, highlight, or flow.
         - NO RASTER IMAGES: Focus purely on clean LaTeX equations, markdown tables, and code/SVG blocks.`;
  } else {
    return `
      STANDARD TUTOR MODE ENABLED:
      You are a friendly, conversational, and direct personal tutor (${tutorName}).
      Tutor Core Rule: ${tutorPrompt}.
      ${personaMandate}
      
      1. STANDARD TUTOR RESPONSE STYLE:
         - Keep replies conversational, encouraging, direct, and accessible.
         - Focus on step-by-step interactive dialogue and problem-solving without requiring formal university lecture structures.
         - Use standard LaTeX notation ($ ... $ for inline math, $$ ... $$ for block math).
      
      2. ON-DEMAND CLEAN EXPLANATIONS:
         - Explain concepts with clean LaTeX math and clear markdown formatting. Do not output <DRAW_IMAGE> raster tags unless explicitly requested by the student.
         - Refer directly to concepts naturally without inserting artificial node tags.`;
  }
};

const cleanTextForNaturalSpeech = (rawText: string): string => {
  if (!rawText) return "";
  let clean = rawText;
  clean = clean.replace(/\[\s*Node\s*\d+\s*:\s*([^\]]+)\]/gi, "$1");
  clean = clean.replace(/\[\s*Node\s*\d+\s*\]/gi, "");
  clean = clean.replace(/\be\.g\./gi, "for example");
  clean = clean.replace(/\bi\.e\./gi, "that is");
  clean = clean.replace(/(^|[\s(])उदा(?:[.\u0970:]|\s*[:-]?\s*)(?![अ-ह\u0900-\u097F])/g, "$1उदाहरण: ");
  // 1. Remove markdown code blocks, raw SVG markup, and drawing/meta tags
  clean = clean.replace(/```[\s\S]*?```/g, " ");
  clean = clean.replace(/<svg[\s\S]*?<\/svg>/gi, " ");
  clean = clean.replace(/<DRAW_IMAGE>[\s\S]*?<\/DRAW_IMAGE>/gi, " ");
  clean = clean.replace(/<ANNOTATIONS>[\s\S]*?<\/ANNOTATIONS>/gi, " ");
  clean = clean.replace(/<PEER_AGENT>[\s\S]*?<\/PEER_AGENT>/gi, " ");
  clean = clean.replace(/<DIAGNOSTIC_CARD[\s\S]*?<\/DIAGNOSTIC_CARD>/gi, " ");
  clean = clean.replace(/<GENERATE_VIDEO>[\s\S]*?<\/GENERATE_VIDEO>/gi, " ");
  // Aggressively remove any meta-text, introductory preamble, or narrative about the diagram/drawing
  clean = clean.replace(/(?:let me|i will|i am going to|i'm going to|here is|below is|let's|i've created|i've drawn|i'll draw|i'll create|now drawing|drawing|making|creating|as seen in|as shown in|looking at|referring to|in the following|the following)\s+(?:draw|create|generate|show|render|provide|make|see|examine)?\s*(?:a|an|the)?\s*(?:2d\s*)?(?:diagram|drawing|figure|schematic|illustration|chart|graph|boardwork|visual|2d vector|vector drawing)(?:[^\n.]*)[.:]?\s*/gi, "");
  clean = clean.replace(/(?:this|the following|the above)\s+(?:2d\s*)?(?:diagram|drawing|figure|schematic|illustration|vector graphic)\s+(?:shows|illustrates|depicts|demonstrates|represents|provides|explains)[^\n.]*[.:]?\s*/gi, "");
  clean = clean.replace(/(?:यहाँ|मैं|आरेख|चित्र|डायग्राम|नीचे)\s*(?:एक|का|दिया गया)?\s*(?:आरेख|चित्र|डायग्राम|ड्रॉइंग|रेखाचित्र)\s*(?:बना रहा हूँ|बनाया है|दिखा रहा हूँ|देखें|दर्शित है|दर्शाता है)[.:]?\s*/gi, "");
  clean = clean.replace(/<[^>]+>/g, " ");
  // 2. Convert LaTeX math blocks to spoken text
  clean = clean.replace(/\$\$([\s\S]*?)\$\$/g, (_, math) => " " + convertLaTeXToSpokenText(math) + " ");
  clean = clean.replace(/\\\[([\s\S]*?)\\\]/g, (_, math) => " " + convertLaTeXToSpokenText(math) + " ");
  clean = clean.replace(/\\\(([\s\S]*?)\\\)/g, (_, math) => " " + convertLaTeXToSpokenText(math) + " ");
  clean = clean.replace(/\$([^$]+)\$/g, (_, math) => " " + convertLaTeXToSpokenText(math) + " ");
  // 3. Remove inline code backticks or replace inline code with empty if it looks like code syntax
  clean = clean.replace(/`([^`\n]+)`/g, (_, code) => {
    if (code.includes('(') || code.includes(')') || code.includes('=') || code.includes(';') || code.includes('{') || code.includes('}') || code.includes('=>') || code.includes('[') || code.includes(']')) {
      return "";
    }
    return code;
  });
  // 4. Clean Markdown links [Label](URL) -> Label
  clean = clean.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");
  // 5. Remove any leftover markdown formatting symbols or special math/code chars (except normal speech punctuation)
  clean = clean.replace(/[*#_~>+\-`$]/g, " ");
  // 6. Replace multiple consecutive whitespace or newlines with a single space
  clean = clean.replace(/\s+/g, " ").trim();
  return expandAbbreviationsForSpeech(clean);
};

/**
 * Unified state management utility to handle UI toggle logic:
 * - High Contrast (accessibility & neon projection layer)
 * - Drag Handles (interactive vector & geometric node manipulation)
 * - Vector Stats (live telemetry inspector)
 * - Magnifier (2.8x optical zoom loupe)
 * - Chalk Draw (freehand canvas annotation overlay)
 * - Grid (coordinate grid & pattern alignments)
 */
export function useUnifiedCanvasUiState(initialOverrides?: Partial<UnifiedCanvasUiState>): UnifiedCanvasUiManager {
  const [highContrast, setHighContrast] = useState<boolean>(() => {
    if (typeof document !== 'undefined') {
      return document.documentElement.classList.contains('high-contrast') || 
             document.documentElement.classList.contains('high-contrast-neon') ||
             localStorage.getItem('omni_high_contrast') === 'true';
    }
    return false;
  });

  const [dragHandles, setDragHandles] = useState<boolean>(() => {
    return localStorage.getItem('omni_canvas_drag_handles') === 'true';
  });

  const [vectorStats, setVectorStats] = useState<boolean>(() => {
    return localStorage.getItem('omni_canvas_vector_stats') === 'true';
  });

  const [magnifier, setMagnifier] = useState<boolean>(() => {
    return localStorage.getItem('omni_canvas_magnifier') === 'true';
  });

  const [chalkDraw, setChalkDraw] = useState<boolean>(() => {
    return localStorage.getItem('omni_canvas_chalk_draw') === 'true';
  });

  const [grid, setGrid] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_canvas_grid');
    return saved !== null ? saved === 'true' : true;
  });

  const [gridStyle, setGridStyleState] = useState<'graph-grid' | 'fine-mesh' | 'dot-matrix' | 'lines'>(() => {
    return (localStorage.getItem('omni_chalkboard_grid_style') as any) || 'graph-grid';
  });

  // Sync canvas/SVG high contrast locally to localStorage without mutating document.documentElement
  // so the surrounding UI remains completely unaffected
  useEffect(() => {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('omni_high_contrast', String(highContrast));
    }
  }, [highContrast]);

  // Sync toggles to localStorage
  useEffect(() => {
    localStorage.setItem('omni_canvas_drag_handles', String(dragHandles));
  }, [dragHandles]);

  useEffect(() => {
    localStorage.setItem('omni_canvas_vector_stats', String(vectorStats));
  }, [vectorStats]);

  useEffect(() => {
    localStorage.setItem('omni_canvas_magnifier', String(magnifier));
  }, [magnifier]);

  useEffect(() => {
    localStorage.setItem('omni_canvas_chalk_draw', String(chalkDraw));
  }, [chalkDraw]);

  useEffect(() => {
    localStorage.setItem('omni_canvas_grid', String(grid));
  }, [grid]);

  useEffect(() => {
    localStorage.setItem('omni_chalkboard_grid_style', gridStyle);
  }, [gridStyle]);

  const toggleHighContrast = useCallback((val?: boolean) => {
    setHighContrast(prev => (typeof val === 'boolean' ? val : !prev));
  }, []);

  const toggleDragHandles = useCallback((val?: boolean) => {
    setDragHandles(prev => (typeof val === 'boolean' ? val : !prev));
  }, []);

  const toggleVectorStats = useCallback((val?: boolean) => {
    setVectorStats(prev => (typeof val === 'boolean' ? val : !prev));
  }, []);

  const toggleMagnifier = useCallback((val?: boolean) => {
    setMagnifier(prev => (typeof val === 'boolean' ? val : !prev));
  }, []);

  const toggleChalkDraw = useCallback((val?: boolean) => {
    setChalkDraw(prev => (typeof val === 'boolean' ? val : !prev));
  }, []);

  const toggleGrid = useCallback((val?: boolean) => {
    setGrid(prev => (typeof val === 'boolean' ? val : !prev));
  }, []);

  const setGridStyle = useCallback((style: 'graph-grid' | 'fine-mesh' | 'dot-matrix' | 'lines') => {
    setGridStyleState(style);
  }, []);

  const resetAllOverlays = useCallback(() => {
    setDragHandles(false);
    setVectorStats(false);
    setMagnifier(false);
    setChalkDraw(false);
  }, []);

  return {
    state: {
      highContrast,
      dragHandles,
      vectorStats,
      magnifier,
      chalkDraw,
      grid,
      gridStyle
    },
    toggleHighContrast,
    toggleDragHandles,
    toggleVectorStats,
    toggleMagnifier,
    toggleChalkDraw,
    toggleGrid,
    setGridStyle,
    resetAllOverlays
  };
}

export default function App() {
  const isShared = window.location.hostname.includes('ais-pre-') || new URLSearchParams(window.location.search).get('shared') === 'true';
  const canvasUiManager = useUnifiedCanvasUiState();
  // UI State
  const [sidebarExpanded, setSidebarExpanded] = useState(true);
  const [hasEntered, setHasEntered] = useState(true);
  const [mode, setMode] = useState(() => {
    const saved = localStorage.getItem('omni_mode');
    if (isShared || !saved) {
      return 'learn';
    }
    return saved;
  });
  const [showSyllabusSidebar, setShowSyllabusSidebar] = useState(false);
  const [selectedEntranceExam, setSelectedEntranceExam] = useState<string>(() => Object.keys(CONFIG.ENTRANCE_EXAMS_DATA)[0]);
  const [selectedSkillId, setSelectedSkillId] = useState<string>(() => {
    return localStorage.getItem('omni_selected_skill_id') || 'ind-automation';
  });

  if (isShared && !hasEntered) {
    const handleDownloadWelcomeQR = () => {
      downloadElegantQR("welcome-qr-canvas", "omnitutor-welcome-qr.png");
    };

    return (
      <div className="min-h-dvh bg-slate-950 flex flex-col items-center justify-center p-6 text-center font-sans">
        <h1 className="text-2xl font-bold text-white mb-6">Open Application?</h1>
        <p className="text-slate-400 mb-8">Do you want to open this shared application?</p>
        
        <div className="flex gap-4 mb-8">
          <button
            onClick={() => setHasEntered(true)}
            className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-500 transition-all active:scale-95 cursor-pointer"
          >
            Yes
          </button>
          <button
            onClick={() => alert("Access declined. You cannot enter.")}
            className="px-8 py-3 bg-slate-700 text-slate-300 rounded-xl font-bold hover:bg-slate-600 transition-all active:scale-95 cursor-pointer"
          >
            No
          </button>
        </div>
        
        <div className="flex flex-col items-center gap-4">
          <div className="p-4 bg-white rounded-xl">
            <QRCodeCanvas id="welcome-qr-canvas" value={getSyncShareUrl()} size={160} />
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            <button
              onClick={() => {
                navigator.clipboard.writeText(getSyncShareUrl());
                alert("Link copied to clipboard!");
              }}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition cursor-pointer text-xs sm:text-sm font-semibold"
            >
              <Copy size={16} />
              Copy Link
            </button>
            <button
              onClick={handleDownloadWelcomeQR}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-500 transition cursor-pointer text-xs sm:text-sm font-semibold"
            >
              <Download size={16} />
              Download QR
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition cursor-pointer text-xs sm:text-sm font-semibold"
            >
              <Printer size={16} />
              Print
            </button>
          </div>
        </div>
        <p className="text-slate-500 mt-4 text-sm">Scan, download, or copy to open on other devices</p>
      </div>
    );
  }
  const [tutorPersonaConfig, setTutorPersonaConfig] = useState<TutorPersonaConfig>(() => {
    try {
      const saved = localStorage.getItem('omni_tutor_persona_config');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return DEFAULT_PERSONA_PRESETS.strict_academic;
  });

  useEffect(() => {
    try {
      localStorage.setItem('omni_tutor_persona_config', JSON.stringify(tutorPersonaConfig));
    } catch {
      // ignore
    }
  }, [tutorPersonaConfig]);

  const [showOnboardingTour, setShowOnboardingTour] = useState(false);

  // Auto launch onboarding tour on first launch if not completed
  useEffect(() => {
    const completed = localStorage.getItem('omni_onboarding_completed');
    if (!completed) {
      const timer = setTimeout(() => setShowOnboardingTour(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  // Initialize Zero-Trust Runtime Security Shield & Client Handshake
  useEffect(() => {
    startRuntimeSecurityShield();
    initSecuritySession().catch((err) => {
      console.debug('[Security] Session handshake initialized in standalone mode:', err);
    });
  }, []);

  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isTTSEnabled, setIsTTSEnabled] = useState(false);
  const [isLowLatency, setIsLowLatency] = useState(false);
  const [voiceSensitivity, setVoiceSensitivity] = useState<number>(() => {
    const saved = localStorage.getItem('omni_voice_sensitivity');
    return saved ? parseFloat(saved) : 0.5;
  });
  const [selectionColor, setSelectionColor] = useState<'default' | 'high-contrast'>(() => {
    return (localStorage.getItem('omni_selection_color') as 'default' | 'high-contrast') || 'default';
  });
  const [ttsRate, setTtsRate] = useState<number>(() => {
    const saved = localStorage.getItem('omni_tts_rate');
    return saved ? parseFloat(saved) : 1.0;
  });
  const [typingPace, setTypingPace] = useState<string>(() => {
    return localStorage.getItem('omni_typing_pace') || 'fluent';
  });
  const [blackboardWritingSpeed, setBlackboardWritingSpeed] = useState<number>(() => {
    const saved = localStorage.getItem('omni_blackboard_writing_speed');
    return saved ? parseFloat(saved) : 1.0;
  });
  useEffect(() => {
    localStorage.setItem('omni_blackboard_writing_speed', String(blackboardWritingSpeed));
  }, [blackboardWritingSpeed]);
  const [linkSpeeds, setLinkSpeeds] = useState<boolean>(() => {
    return localStorage.getItem('omni_link_speeds') === 'true';
  });

  // Harmonized Quad-Speed Synchronization State (Typing, Pronouncing, Visualizing, Scrolling)
  const [quadSpeeds, setQuadSpeeds] = useState<QuadSpeedState>(() => getStoredQuadSpeeds());
  const handleUpdateQuadSpeeds = (newSpeeds: QuadSpeedState) => {
    setQuadSpeeds(newSpeeds);
    saveStoredQuadSpeeds(newSpeeds);
    setTtsRate(newSpeeds.pronouncingSpeed);
    setBlackboardWritingSpeed(newSpeeds.typingSpeed);
  };
  useEffect(() => {
    localStorage.setItem('omni_selection_color', selectionColor);
    if (selectionColor === 'high-contrast') {
      document.documentElement.classList.add('selection-high-contrast');
    } else {
      document.documentElement.classList.remove('selection-high-contrast');
    }
  }, [selectionColor]);

  const [showAudioDiagnostics, setShowAudioDiagnostics] = useState(false);
  const [pronunciationPrecision, setPronunciationPrecision] = useState<'standard' | 'formal'>(() => {
    return (localStorage.getItem('omni_pronunciation_precision') as 'standard' | 'formal') || 'standard';
  });
  useEffect(() => {
    localStorage.setItem('omni_pronunciation_precision', pronunciationPrecision);
  }, [pronunciationPrecision]);

  const [isProfessorMode, setIsProfessorMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_professor_mode');
    return saved !== null ? saved === 'true' : true;
  });
  useEffect(() => {
    localStorage.setItem('omni_professor_mode', String(isProfessorMode));
  }, [isProfessorMode]);

  const [silentDraw, setSilentDraw] = useState<boolean>(() => {
    const saved = localStorage.getItem('omni_silent_draw');
    return saved !== null ? saved === 'true' : false;
  });
  useEffect(() => {
    localStorage.setItem('omni_silent_draw', String(silentDraw));
  }, [silentDraw]);

  const [selectedPersonaId, setSelectedPersonaId] = useState<string>(() => {
    return localStorage.getItem('omni_selected_persona') || 'encouraging_coach';
  });
  const [mastery, setMastery] = useState<SubSkillMastery>({});
  const [diagnosticCards, setDiagnosticCards] = useState<DiagnosticCard[]>([]);
  const [isLectureMode, setIsLectureMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('omni_lecture_mode');
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });
  const [lectureSubMode, setLectureSubMode] = useState<'classroom' | 'quiz' | 'lecture' | 'video_classroom'>(() => {
    const saved = localStorage.getItem('omni_lecture_sub_mode');
    return (saved as 'classroom' | 'quiz' | 'lecture' | 'video_classroom') || 'classroom';
  });
  const [lectureProfessorStyle, setLectureProfessorStyle] = useState<'strict' | 'mentor'>(() => {
    return (localStorage.getItem('omni_lecture_professor_style') as 'strict' | 'mentor') || 'strict';
  });
  useEffect(() => {
    localStorage.setItem('omni_lecture_professor_style', lectureProfessorStyle);
  }, [lectureProfessorStyle]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const showNotification = useCallback((message: string, type: 'success' | 'error' | 'info' | 'warning' = 'info') => {
    if (!message) return;
    setNotifications(prev => {
      if (prev.some(n => n.message === message)) return prev;
      const filtered = prev.length >= 2 ? prev.slice(1) : prev;
      const id = generateId('notif_');
      setTimeout(() => {
        setNotifications(current => current.filter(n => n.id !== id));
      }, 2500);
      return [...filtered, { id, message, type }];
    });
  }, []);
  const [isBoardsExplorerOpen, setIsBoardsExplorerOpen] = useState(false);
  const [isMasterFeatureSuiteOpen, setIsMasterFeatureSuiteOpen] = useState(false);
  const [isUniversalTutorOpen, setIsUniversalTutorOpen] = useState(false);
  const [isVeoVideoModalOpen, setIsVeoVideoModalOpen] = useState(false);
  const [showDebuggerModal, setShowDebuggerModal] = useState(false);
  const [showAuthDiagnosticsModal, setShowAuthDiagnosticsModal] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);
  const [modal, setModal] = useState<{ 
    id?: string;
    title: string; 
    content: React.ReactNode; 
    size?: 'default' | 'large' | 'xl' 
  } | null>(null);
  const [themeMode, setThemeMode] = useState<'light' | 'dark' | 'auto' | 'high-contrast' | 'high-contrast-green'>(() => {
    const saved = localStorage.getItem('omni_theme_mode');
    return (saved as 'light' | 'dark' | 'auto' | 'high-contrast' | 'high-contrast-green') || 'auto';
  });
  
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [isHighContrast, setIsHighContrast] = useState(false);

  const [accessibilityTextSize, setAccessibilityTextSize] = useState<'sm' | 'md' | 'lg' | 'xl'>(() => {
    return (localStorage.getItem('omni_accessibility_text_size') as 'sm' | 'md' | 'lg' | 'xl') || 'md';
  });
  const [accessibilityLineSpacing, setAccessibilityLineSpacing] = useState<'normal' | 'relaxed' | 'loose'>(() => {
    return (localStorage.getItem('omni_accessibility_line_spacing') as 'normal' | 'relaxed' | 'loose') || 'relaxed';
  });
  const [accessibilityContrast, setAccessibilityContrast] = useState<'normal' | 'high' | 'ultra'>(() => {
    return (localStorage.getItem('omni_accessibility_contrast') as 'normal' | 'high' | 'ultra') || 'normal';
  });

  useEffect(() => {
    localStorage.setItem('omni_accessibility_text_size', accessibilityTextSize);
  }, [accessibilityTextSize]);

  useEffect(() => {
    localStorage.setItem('omni_accessibility_line_spacing', accessibilityLineSpacing);
  }, [accessibilityLineSpacing]);

  useEffect(() => {
    localStorage.setItem('omni_accessibility_contrast', accessibilityContrast);
  }, [accessibilityContrast]);

  const [activeViewersCount, setActiveViewersCount] = useState<number>(1);
  const [generatedVideos, setGeneratedVideos] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('omni_ai_generated_videos');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Sanitize broken legacy URLs
        return parsed.map((v: any) => {
          let url = v.url;
          if (url && url.includes('gtv-videos-bucket')) {
            url = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
          }
          return {
            ...v,
            url,
            publishedAt: v.publishedAt ? new Date(v.publishedAt) : new Date()
          };
        });
      }
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem('omni_ai_generated_videos', safeJsonStringify(generatedVideos));
  }, [generatedVideos]);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);

  useEffect(() => {
    // Generate or retrieve a persistent client ID for this tab session
    let clientId = sessionStorage.getItem('omni_client_id');
    if (!clientId) {
      clientId = 'c_' + Math.random().toString(36).substring(2, 15);
      sessionStorage.setItem('omni_client_id', clientId);
    }

    // Function to ping the server and get active viewer count
    const pingServer = async (retries = 2) => {
      try {
        const response = await fetch('/api/viewers/ping', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ clientId }),
        });
        if (response.ok) {
          const data = await response.json();
          if (typeof data.activeCount === 'number') {
            setActiveViewersCount(data.activeCount);
          }
        }
      } catch (error) {
        if (retries > 0) {
          setTimeout(() => pingServer(retries - 1), 3000);
        }
      }
    };

    // Initial ping
    pingServer();

    // Ping every 30 seconds
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') {
        pingServer();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleGlobalVideoKeyDown = (e: KeyboardEvent) => {
      // Ignore keypresses when user is actively typing in text inputs or textareas
      const activeEl = document.activeElement;
      const tagName = activeEl?.tagName.toLowerCase();
      const isEditable = (activeEl as HTMLElement)?.isContentEditable || 
                         tagName === 'input' || 
                         tagName === 'textarea' || 
                         tagName === 'select';
      
      if (isEditable) return;

      const activeInstance = getActiveVideoPlayerInstance();
      if (activeInstance) {
        if (e.code === 'Space' || e.key === ' ') {
          if (tagName === 'button' || tagName === 'a') return;
          e.preventDefault();
          activeInstance.togglePlay();
          return;
        } else if (e.code === 'ArrowLeft' || e.key === 'ArrowLeft') {
          e.preventDefault();
          activeInstance.seekBy(-5);
          return;
        } else if (e.code === 'ArrowRight' || e.key === 'ArrowRight') {
          e.preventDefault();
          activeInstance.seekBy(5);
          return;
        } else if (e.code === 'KeyJ' || e.key === 'j' || e.key === 'J') {
          e.preventDefault();
          activeInstance.seekBy(-10);
          return;
        } else if (e.code === 'KeyL' || e.key === 'l' || e.key === 'L') {
          e.preventDefault();
          activeInstance.seekBy(10);
          return;
        } else if (e.code === 'KeyM' || e.key === 'm' || e.key === 'M') {
          e.preventDefault();
          activeInstance.toggleMute();
          return;
        } else if (e.code === 'ArrowUp') {
          e.preventDefault();
          const v = activeInstance.getVideoElement();
          if (v) activeInstance.setVolume(v.volume + 0.1);
          return;
        } else if (e.code === 'ArrowDown') {
          e.preventDefault();
          const v = activeInstance.getVideoElement();
          if (v) activeInstance.setVolume(v.volume - 0.1);
          return;
        }
      }

      // Fallback: Find all visible video elements
      const mediaElements = Array.from(document.querySelectorAll<HTMLMediaElement>('video'))
        .filter(el => {
          const rect = el.getBoundingClientRect();
          return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).display !== 'none';
        });

      if (mediaElements.length === 0) return;

      if (e.code === 'Space' || e.key === ' ') {
        if (tagName === 'button' || tagName === 'a') return;
        e.preventDefault();
        mediaElements.forEach(media => {
          if (media.paused) {
            media.play().catch(() => {});
          } else {
            media.pause();
          }
        });
      } else if (e.code === 'ArrowLeft' || e.key === 'ArrowLeft') {
        e.preventDefault();
        mediaElements.forEach(media => {
          try {
            if (media.readyState >= 1) {
              media.currentTime = Math.max(0, media.currentTime - 5);
            }
          } catch(err) {}
        });
      } else if (e.code === 'ArrowRight' || e.key === 'ArrowRight') {
        e.preventDefault();
        mediaElements.forEach(media => {
          try {
            if (media.readyState >= 1) {
              media.currentTime = Math.min(media.duration || Infinity, media.currentTime + 5);
            }
          } catch(err) {}
        });
      } else if (e.code === 'KeyM' || e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        mediaElements.forEach(media => {
          media.muted = !media.muted;
        });
      }
    };
    
    window.addEventListener('keydown', handleGlobalVideoKeyDown, { capture: true });
    return () => {
      window.removeEventListener('keydown', handleGlobalVideoKeyDown, { capture: true });
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('omni_theme_mode', themeMode);
    if (themeMode === 'auto') {
      const currentHour = new Date().getHours();
      setTheme(currentHour >= 18 || currentHour < 6 ? 'dark' : 'light');
      setIsHighContrast(false);
    } else if (themeMode === 'high-contrast') {
      setTheme('light');
      setIsHighContrast(true);
    } else {
      setTheme(themeMode as 'light' | 'dark');
      setIsHighContrast(false);
    }
  }, [themeMode]);

  useEffect(() => {
    if (themeMode !== 'auto') return;
    const interval = setInterval(() => {
      const currentHour = new Date().getHours();
      setTheme(currentHour >= 18 || currentHour < 6 ? 'dark' : 'light');
    }, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [themeMode]);

  const isPreviewEnv = window.location.hostname.includes('ais-pre-');
  const REQUIRED_SHARE_TOKEN = "omni_20260629";
  const urlParams = new URLSearchParams(window.location.search);
  const urlToken = urlParams.get('token');
  const expiresParam = urlParams.get('expires');
  
  let isExpired = false;
  let expiresTime: number | undefined = undefined;
  if (expiresParam) {
    expiresTime = parseInt(expiresParam, 10);
    if (!isNaN(expiresTime) && Date.now() > expiresTime) {
      isExpired = true;
    }
  }

  const isValidToken = true; // Relaxed token check for shared links
  
  if (isPreviewEnv && !isShared && !isValidToken) {
    return (
      <div className="min-h-dvh bg-slate-950 flex flex-col items-center justify-center p-6 text-center font-sans">
        <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mb-6">
          <AlertCircle className="w-10 h-10 text-red-500" />
        </div>
        <h1 className="text-3xl font-black text-white mb-3 tracking-tight">Access Denied</h1>
        <p className="text-slate-300 text-lg max-w-md">
          This shared link has expired or is invalid. Previous shared links are no longer permitted to open this application.
        </p>
        <div className="mt-8 p-4 bg-slate-900 rounded-2xl border border-slate-800">
          <p className="text-slate-400 text-sm">
            Please contact the creator and ask for the updated share link.
          </p>
        </div>
      </div>
    );
  }

  // Data State
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('omni_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse saved user', e);
    }
    return {
      id: generateId('user_'),
      name: 'Learner',
      difficulty: 'college',
      subject: 'mathematics',
      topic: 'Quadratic Equations & Polynomials',
      lesson: '1',
      tutor: 'direct',
      xp: 0,
      level: 1,
      streak: 0,
      lastStudyDate: null,
      language: 'en',
      bookmarkedLessons: []
    };
  });

  const [showStudyGapBanner, setShowStudyGapBanner] = useState(false);

  const [messagesByMode, setMessagesByMode] = useState<Record<string, Message[]>>(() => {
    const modesList = ['learn', 'diagram', 'entrance', 'competitive', 'videos', 'earn'];
    const initial: Record<string, Message[]> = {};

    let initialUser: any = null;
    try {
      const savedUser = localStorage.getItem('omni_user');
      if (savedUser) {
        initialUser = JSON.parse(savedUser);
      }
    } catch (e) {
      console.error(e);
    }
    const name = initialUser?.name || 'Learner';
    const s = initialUser?.subject || 'mathematics';
    const t = initialUser?.topic || 'Quadratic Equations & Polynomials';
    
    const fmtSubject = s.split('_').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    const fmtTopic = t.split('_').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

    const legacy = localStorage.getItem('omni_messages');

    modesList.forEach(m => {
      let savedParsed: any = null;
      try {
        const saved = localStorage.getItem(`omni_messages_${m}`);
        if (saved) {
          savedParsed = JSON.parse(saved);
        } else if (m === 'learn' && legacy) {
          savedParsed = JSON.parse(legacy);
        }
      } catch (e) {
        console.warn(`Failed to parse messages for mode ${m}`, e);
      }

      if (savedParsed && Array.isArray(savedParsed) && savedParsed.length > 0 && !(m === 'learn' && savedParsed.length === 1 && savedParsed[0].id === 'welcome')) {
        initial[m] = savedParsed;
      } else {
        if (m === 'learn') {
          const standardPrompt = `I want to study the lesson "Quadratic Equations & Polynomials" of Chapter "Algebra & Calculus" to a degree of STANDARD depth/rigor. Tutor Rigor Instructions: Provide a standard, granular, step-by-step academic explanation. Explain definitions, list equations, detail a complete concrete worked-out example with intermediate steps, and test me on the content with 2 standard practice questions. Please proceed to teach the lesson now with high quality and formatting.`;
          const standardLesson = buildStandardOmniStudyContent('Quadratic Equations & Polynomials', 'mathematics', 'en');
          initial[m] = [
            {
              id: 'standard_study_prompt_1',
              content: standardPrompt,
              sender: 'user',
              timestamp: Date.now() - 5000
            },
            {
              id: 'standard_study_response_1',
              content: standardLesson,
              sender: 'ai',
              timestamp: Date.now(),
              metadata: {
                topic: 'Quadratic Equations & Polynomials',
                subject: 'mathematics',
                modelName: 'Professor Clarity'
              }
            }
          ];
        } else {
          let welcomeText = '';
          if (m === 'entrance') {
            welcomeText = `# 🎓 Entrance Exam Preparation!\n\nWelcome! I am calibrated as your advanced **Entrance Exam Coach**.\n\nOn the right side, you'll see your interactive syllabus and practice quizzes docked for easy reference. As you navigate the chapters and lessons there, I will dynamically adjust my tutoring and practice questions to match.\n\nWhat topic or specific exam concept shall we focus on today?`;
          } else if (m === 'earn') {
            welcomeText = `# 🪙 Learn-and-Earn Workspace!\n\nWelcome! Here you can develop skills and solve practice items to earn tokens and build your professional profile.\n\nWhat professional skill or textbook challenge are you ready to tackle?`;
          } else if (m === 'competitive') {
            welcomeText = `# 🏆 Jobs Exams Arena!\n\nWelcome! I am calibrated as your high-intensity **Jobs Exams Coach**.\n\nHere we practice speed, optimization, shortcut methods, and elite problem solving to prepare you for top performance in high-stakes job recruitment and competitive exams.\n\nWhat exam or specific subject discipline should we drill today?`;
          } else if (m === 'videos') {
            welcomeText = `# 🎥 Video Lecture Laboratory!\n\nWelcome! Here we use interactive videos and multi-sensory tools to explore topics deeply.\n\nWhat complex concept or topic would you like to watch and dissect today?`;
          } else if (m === 'diagram') {
            welcomeText = `# 🎨 Diagram Tutor Play Mode!\n\nWelcome! I am calibrated as your dedicated **Diagram Tutor**.\n\nIn this mode, all studying and teaching is conducted strictly through **annotated visual diagrams, 2D vector schematics, dual-perspective teacher/student visual breakdowns, and interactive diagram hotspot maps**.\n\nAll diagram analysis tools, diagram generators, and interactive hotspot inspectors are unlocked right here in Diagram Mode.\n\nWhat topic, concept, or process would you like to study or draw a diagram for today?`;
          } else {
            welcomeText = `I'm your Omni AI companion, here to help you study. We are currently calibrated to explore all subjects specifically delving into the concepts of all subjects. Whether you need practice sheets, conceptual breakdowns, diagrams, or smart quizzes, I'm ready to assist you. What would you like to cover first?`;
          }

          initial[m] = [
            {
              id: 'welcome',
              content: welcomeText,
              sender: 'ai',
              timestamp: Date.now()
            }
          ];
        }
      }
    });

    return initial;
  });

  useEffect(() => {
    // Shared and origin environment diagnosis
    const isSharedLink = typeof window !== 'undefined' && (window.location.hostname.includes('ais-pre-') || new URLSearchParams(window.location.search).get('shared') === 'true');
    const isPreview = typeof window !== 'undefined' && window.location.hostname.includes('ais-pre-');
    const isIframe = typeof window !== 'undefined' && window.self !== window.top;

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setFirebaseUser(currentUser);

      // --- Enhanced Diagnostic Telemetry & Console Monitor for Shared Environments ---
      try {
        const authKeysInStorage: string[] = [];
        try {
          if (typeof window !== 'undefined' && window.localStorage) {
            for (let i = 0; i < window.localStorage.length; i++) {
              const k = window.localStorage.key(i);
              if (k && (k.startsWith('firebase:authUser') || k.startsWith('firebase:') || k.includes('firebase'))) {
                authKeysInStorage.push(k);
              }
            }
          }
        } catch (e) {
          // localStorage access restricted
        }

        if (currentUser) {
          const tokenResult = await currentUser.getIdTokenResult(false);
          const expDate = tokenResult.expirationTime ? new Date(tokenResult.expirationTime) : null;
          const secondsUntilExpiry = expDate ? Math.max(0, Math.round((expDate.getTime() - Date.now()) / 1000)) : null;

          console.groupCollapsed(
            `%c🔑 [Firebase Auth Diagnostics] %cSESSION ACTIVE (${currentUser.email || currentUser.uid})`,
            'color: #38bdf8; font-weight: bold;',
            'color: #4ade80; font-weight: bold;'
          );
          console.table({
            'Session Status': 'Authenticated',
            'User UID': currentUser.uid,
            'Email': currentUser.email || 'N/A',
            'Is Anonymous': currentUser.isAnonymous ? 'Yes' : 'No',
            'Origin Host': window.location.hostname,
            'Is Shared Link': isSharedLink ? 'YES (ais-pre-*)' : 'NO (Development)',
            'Is Iframe Sandbox': isIframe ? 'YES (Embedded)' : 'NO (Top-Level)',
            'Token Accessible': 'YES',
            'Token Expiration': tokenResult.expirationTime || 'Unknown',
            'Valid Seconds Left': `${secondsUntilExpiry}s (~${Math.round((secondsUntilExpiry || 0) / 60)} min)`,
            'Persisted Storage Keys': `${authKeysInStorage.length} keys found`
          });
          console.log('%cToken Claims & Details:', 'color: #a78bfa; font-weight: bold;', tokenResult.claims);
          console.groupEnd();

          // Expose global debug helper in browser DevTools
          if (typeof window !== 'undefined') {
            (window as any).__FIREBASE_AUTH_DIAGNOSTICS__ = {
              status: 'authenticated',
              uid: currentUser.uid,
              email: currentUser.email,
              displayName: currentUser.displayName,
              isSharedLink,
              isPreview,
              isIframe,
              tokenResult,
              secondsUntilExpiry,
              authKeysInStorage,
              timestamp: new Date().toISOString()
            };
            (window as any).getAuthDiagnostics = () => (window as any).__FIREBASE_AUTH_DIAGNOSTICS__;
          }
        } else {
          console.groupCollapsed(
            `%c🔑 [Firebase Auth Diagnostics] %cNO SESSION FOUND (Guest / Shared Link Mode)`,
            'color: #38bdf8; font-weight: bold;',
            'color: #f87171; font-weight: bold;'
          );
          console.table({
            'Session Status': 'Unauthenticated (Guest Mode)',
            'User UID': 'None',
            'Origin Host': window.location.hostname,
            'Is Shared Link': isSharedLink ? 'YES (ais-pre-*)' : 'NO (Development)',
            'Is Iframe Sandbox': isIframe ? 'YES (Embedded)' : 'NO (Top-Level)',
            'Token Accessible': 'NO (No logged in user)',
            'Persisted Storage Keys': `${authKeysInStorage.length} keys in current origin`
          });
          if (isSharedLink) {
            console.info(
              '%cℹ️ Shared Link Notice: %cBrowsers isolate IndexedDB and localStorage per domain origin. The session logged into ais-dev-* does not automatically carry over to ais-pre-* unless signed in on this domain.',
              'color: #fbbf24; font-weight: bold;',
              'color: #fef08a;'
            );
          }
          console.groupEnd();

          if (typeof window !== 'undefined') {
            (window as any).__FIREBASE_AUTH_DIAGNOSTICS__ = {
              status: 'unauthenticated',
              uid: null,
              email: null,
              isSharedLink,
              isPreview,
              isIframe,
              tokenResult: null,
              authKeysInStorage,
              timestamp: new Date().toISOString()
            };
            (window as any).getAuthDiagnostics = () => (window as any).__FIREBASE_AUTH_DIAGNOSTICS__;
          }
        }
      } catch (diagErr) {
        console.warn('Auth diagnostic check encountered an error:', diagErr);
      }

      if (currentUser) {
        // Load user data from Firestore
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            setUser(prev => ({
              ...prev,
              ...data.profile,
              name: currentUser.displayName || data.profile?.name || prev.name
            }));
            
            if (data.messagesByMode) {
              setMessagesByMode(data.messagesByMode);
            }
          } else {
            // First time login - save current state to Firestore
            await setDoc(doc(db, 'users', currentUser.uid), {
              uid: currentUser.uid,
              profile: user,
              updatedAt: Date.now()
            });
          }
        } catch (error) {
          console.error("Firestore sync failed:", error);
        }
      } else {
        // Logged out - reset to defaults (or keep local storage)
        // For now, let's just keep local storage as a fallback
      }
    });
    return () => unsubscribe();
  }, []);

  // Save to Firestore when state changes and user is logged in
  useEffect(() => {
    if (!firebaseUser) return;

    const saveData = async () => {
      try {
        await setDoc(doc(db, 'users', firebaseUser.uid), {
          uid: firebaseUser.uid,
          profile: user,
          messagesByMode: messagesByMode,
          updatedAt: Date.now()
        }, { merge: true });
      } catch (error) {
        console.error("Failed to save to Firestore:", error);
      }
    };

    const timeout = setTimeout(saveData, 2000); // Debounce saves
    return () => clearTimeout(timeout);
  }, [firebaseUser, user, messagesByMode]);

  const messages = messagesByMode[mode] || [];

  const latestUserPrompt = React.useMemo(() => {
    const learnMsgs = messagesByMode['learn'] || [];
    for (let i = learnMsgs.length - 1; i >= 0; i--) {
      if (learnMsgs[i].sender === 'user' && learnMsgs[i].content?.trim()) {
        return learnMsgs[i].content.trim();
      }
    }
    const currentMsgs = messages || [];
    for (let i = currentMsgs.length - 1; i >= 0; i--) {
      if (currentMsgs[i].sender === 'user' && currentMsgs[i].content?.trim()) {
        return currentMsgs[i].content.trim();
      }
    }
    return `I want to study the lesson "Quadratic Equations & Polynomials" of Chapter "Algebra & Calculus" to a degree of STANDARD depth/rigor. Tutor Rigor Instructions: Provide a standard, granular, step-by-step academic explanation. Explain definitions, list equations, detail a complete concrete worked-out example with intermediate steps, and test me on the content with 2 standard practice questions. Please proceed to teach the lesson now with high quality and formatting.`;
  }, [messagesByMode, messages]);

  const latestAiResponse = React.useMemo(() => {
    const learnMsgs = messagesByMode['learn'] || [];
    for (let i = learnMsgs.length - 1; i >= 0; i--) {
      if (learnMsgs[i].sender === 'ai' && learnMsgs[i].content?.trim() && learnMsgs[i].id !== 'welcome') {
        return learnMsgs[i].content.trim();
      }
    }
    const currentMsgs = messages || [];
    for (let i = currentMsgs.length - 1; i >= 0; i--) {
      if (currentMsgs[i].sender === 'ai' && currentMsgs[i].content?.trim() && currentMsgs[i].id !== 'welcome') {
        return currentMsgs[i].content.trim();
      }
    }
    return undefined;
  }, [messagesByMode, messages]);

  const studyContentFor3D = React.useMemo(() => {
    if (latestAiResponse && latestAiResponse.trim()) {
      return latestAiResponse.trim();
    }
    // If no AI response exists yet, check if latestUserPrompt specifies a lesson to generate the standard study content
    const match = latestUserPrompt.match(/lesson\s+"([^"]+)"/i);
    if (match && match[1]) {
      const topicName = match[1];
      const subjectName = user.subject || 'Continuity and Differentiability';
      return buildStandardOmniStudyContent(topicName, subjectName, user.language || 'en');
    }
    if (user.topic && user.topic.trim() && user.topic !== 'None') {
      return buildStandardOmniStudyContent(user.topic, user.subject || 'STEM', user.language || 'en');
    }
    return undefined;
  }, [latestAiResponse, latestUserPrompt, user.topic, user.subject, user.language]);

  const setMessages = (update: Message[] | ((prev: Message[]) => Message[])) => {
    setMessagesByMode(prevAll => {
      const currentMessages = prevAll[mode] || [];
      const updatedMessages = typeof update === 'function' ? update(currentMessages) : update;
      return {
        ...prevAll,
        [mode]: updatedMessages
      };
    });
  };

  const [quests, setQuests] = useState<Quest[]>([
    { id: 'solve_5', title: 'Solve 5 problems', description: 'Complete 5 practice questions', xp: 100, progress: 0, max: 5 },
    { id: 'study_30min', title: 'Study 30 minutes', description: 'Spend time learning', xp: 150, progress: 0, max: 30 },
    { id: 'mastery_topic', title: 'Master a topic', description: 'Reach 80% mastery', xp: 500, progress: 0, max: 1 }
  ]);

  const [flashcards, setFlashcards] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState({ accuracy: 0.75, totalSessions: 12 });
  const [savedNotes, setSavedNotes] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('omni_saved_notes');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to parse saved notes', e);
    }
    return [];
  });
  const [zoomLevel, setZoomLevel] = useState(1);
  const [contentWidth, setContentWidth] = useState(100);

  // Persistence
  useEffect(() => {
    localStorage.setItem('omni_mode', mode);
  }, [mode]);

  useEffect(() => {
    localStorage.setItem('omni_saved_notes', JSON.stringify(savedNotes));
  }, [savedNotes]);

  useEffect(() => {
    localStorage.setItem('omni_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem(`omni_messages_${mode}`, JSON.stringify(messages));
  }, [messages, mode]);

  useEffect(() => {
    if (mode !== 'learn') return;
    setMessages(prev => {
      const welcomeIdx = prev.findIndex(m => m.id === 'welcome');
      if (welcomeIdx !== -1) {
        const updatedContent = `I'm your Omni AI companion, here to help you study. We are currently calibrated to explore all subjects specifically delving into the concepts of all subjects. Whether you need practice sheets, conceptual breakdowns, diagrams, or smart quizzes, I'm ready to assist you. What would you like to cover first?`;
        
        if (prev[welcomeIdx].content !== updatedContent) {
          const newMsgs = [...prev];
          newMsgs[welcomeIdx] = {
            ...prev[welcomeIdx],
            content: updatedContent
          };
          return newMsgs;
        }
      }
      return prev;
    });
  }, [user.name, user.subject, user.topic, mode]);

  useEffect(() => {
    localStorage.setItem('omni_theme', theme);
    document.documentElement.classList.remove('dark', 'high-contrast');
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    }
    if (isHighContrast) {
      document.documentElement.classList.add('high-contrast');
    }
  }, [theme, isHighContrast]);

  useEffect(() => {
    const handleSaveNoteEvent = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        handleSaveToNotes(customEvent.detail);
      }
    };
    window.addEventListener('save_omni_note', handleSaveNoteEvent);
    return () => {
      window.removeEventListener('save_omni_note', handleSaveNoteEvent);
    };
  }, []);

  const handleToggleBookmark = useCallback((lessonTitle: string, lessonSubject: string, lessonNumber: number) => {
    setUser(prev => {
      const currentBookmarks = prev.bookmarkedLessons || [];
      const exists = currentBookmarks.some(b => b.title === lessonTitle && b.subject === lessonSubject);
      
      let updated;
      if (exists) {
        updated = currentBookmarks.filter(b => !(b.title === lessonTitle && b.subject === lessonSubject));
        showNotification('Lesson removed from bookmarks.', 'info');
      } else {
        updated = [
          ...currentBookmarks,
          {
            title: lessonTitle,
            subject: lessonSubject,
            lessonNumber,
            addedAt: new Date().toISOString()
          }
        ];
        showNotification('Lesson saved for later!', 'success');
      }
      
      const updatedProfile = { ...prev, bookmarkedLessons: updated };
      localStorage.setItem('omni_user', JSON.stringify(updatedProfile));
      return updatedProfile;
    });
  }, [showNotification]);

  // Study gap detection & local push notifications
  useEffect(() => {
    if (!user.lastStudyDate) return;
    
    const checkStudyGap = () => {
      const lastStudy = new Date(user.lastStudyDate!).getTime();
      const now = Date.now();
      const hoursSinceLastStudy = (now - lastStudy) / (1000 * 60 * 60);

      if (hoursSinceLastStudy >= 24) {
        const lastNotified = localStorage.getItem('omni_last_gap_notification_time');
        const timeSinceLastNotification = lastNotified ? (now - parseInt(lastNotified, 10)) / (1000 * 60 * 60) : Infinity;

        // Skip notifying if notified in the last 12 hours (unless it's a simulated trigger)
        const isSimulated = Math.abs(hoursSinceLastStudy - 25) < 0.1; // simulated is exactly 25 hours ago
        if (timeSinceLastNotification >= 12 || isSimulated) {
          localStorage.setItem('omni_last_gap_notification_time', now.toString());
          
          const message = `It's been over 24 hours since your last study session! 📚 Keep your learning momentum going and start a quick review.`;
          showNotification(message, 'warning');

          // Browser Web Push Notification (best effort)
          if ('Notification' in window) {
            if (Notification.permission === 'granted') {
              try {
                new Notification('Omni AI: Study Reminder', {
                  body: "Don't lose your learning streak! It's been over 24 hours since your last session.",
                  icon: '/favicon.ico'
                });
              } catch (error) {
                console.warn('Web notification failed:', error);
              }
            } else if (Notification.permission !== 'denied') {
              try {
                Notification.requestPermission().then(permission => {
                  if (permission === 'granted') {
                    new Notification('Omni AI: Study Reminder', {
                      body: "Don't lose your learning streak! It's been over 24 hours since your last session.",
                      icon: '/favicon.ico'
                    });
                  }
                });
              } catch (error) {
                console.warn('Could not request Notification permission:', error);
              }
            }
          }
        }
        setShowStudyGapBanner(true);
      } else {
        setShowStudyGapBanner(false);
      }
    };

    const timer = setTimeout(checkStudyGap, 1500);
    return () => clearTimeout(timer);
  }, [user.lastStudyDate, showNotification]);

  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [videoGenerationTime, setVideoGenerationTime] = useState(0);

  // Global Classroom Mute State & 2D Diagram Silent Mode
  const [isClassroomMute, setIsClassroomMute] = useState<boolean>(false);
  const [isDiagramRendering, setIsDiagramRendering] = useState<boolean>(false);

  useEffect(() => {
    let interval: any = null;
    if (isGeneratingVideo) {
      setVideoGenerationTime(0);
      interval = setInterval(() => {
        setVideoGenerationTime(prev => prev + 1);
      }, 1000);
    } else {
      setVideoGenerationTime(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isGeneratingVideo]);

  // AI Interaction
  const handleSendMessage = async (rawText: string, imageBase64?: string) => {
    const text = normalizeMathematicalInput(rawText);
    // Slash command handling
    if (!imageBase64 && text.startsWith('/')) {
      const command = text.substring(1).toLowerCase();
      const toolMap: Record<string, string> = {
        'quiz': 'quiz',
        'solver': 'solver',
        'doc': 'document',
        'map': 'graph',
        'flashcards': 'cards',
        'timer': 'pomodoro',
        'tutor': 'universal_ai_tutor',
        'chat': 'universal_ai_tutor',
        'aitutor': 'universal_ai_tutor'
      };

      if (toolMap[command]) {
        handleOpenTool(toolMap[command]);
        return;
      }
    }

    const userMsg: Message = {
      id: generateId('msg_'),
      content: text,
      sender: 'user',
      timestamp: Date.now(),
      ...(imageBase64 ? { metadata: { image: imageBase64 } } : {})
    };
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);
    setUser(prev => ({ ...prev, lastStudyDate: new Date().toISOString() }));

    try {
      const tutor = CONFIG.TUTORS[user.tutor as keyof typeof CONFIG.TUTORS] || CONFIG.TUTORS.direct;
      const lang = LANGUAGES.find(l => l.code === user.language) || LANGUAGES[0];
      const persona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[1];

      let skillPrompt = "";
      if (mode === 'earn') {
        const nationSkills = getSkillsForNation(user.selectedBoard?.nation || 'India');
        const activeSkill = nationSkills.find(sk => sk.id === selectedSkillId) || nationSkills[0] || DEFAULT_SKILLS[0];
        skillPrompt = `
      CURRENT MODE: LEARN-EARN (Earning Oriented)
      We are focusing on teaching the user the skills needed to earn a livelihood using:
      Active Skill: ${activeSkill.name} (Category: ${activeSkill.category}, Type: ${activeSkill.type} skill).
      Skill Description: ${activeSkill.description}
      Current Earning Level: ${user.difficulty}
      Target Earning Rate: ${activeSkill.earningRates[user.difficulty] || '$25/hr'}.
      Please tailor all tutoring towards helping the user learn and master this skill so they can achieve this earning rate! Provide helpful practical assignments, career advice, industry best practices, and mock project opportunities aligned with this skill.`;
      }

      const systemInstruction = `You are Omni AI, a universal education system. ${skillPrompt}
      CRITICALLY IMPORTANT: If anyone asks "who made you", "who is your creator", "who created you", "who developed you", or any similar question, your response MUST state that you are Omni AI, a universal education platform developed by the Omni AI Team. Under no circumstances should you ever mention the name "D.K Mourya", "Mourya", or "India" as your creator. Keep all replies completely focused on being an educational assistant, and never reveal any individual's name.
      
      ${mode === 'learn' || mode === 'diagram' ? `
      CRITICAL: DYNAMIC FIGURE & DIAGRAM TEACHING MANDATE:
      Whenever teaching or explaining visual, optical, physical, biological, chemical, or mathematical concepts (such as Refraction / अपवर्तन, Dispersion / वर्ण-विक्षेपण, Accommodation of Eye / समंजन क्षमता, Dioptre / डायोप्टर, Snell's law, Lenses, Prisms, Mirrors, Circuits, Magnetic fields, Vectors, Photosynthesis, Molecular geometry, Graphs, or Anatomy):
      You MUST generate and embed a clean, valid inline SVG diagram (<svg viewBox="0 0 700 280" width="100%" height="auto" xmlns="http://www.w3.org/2000/svg" style="max-width:100%; height:auto; background:#070d1e; border:1.5px solid #38bdf8; border-radius:16px; padding:12px; margin:16px 0;">...</svg>) directly within your explanation.
      The SVG figure must visually represent the core mechanism (incident & refracted rays, normal line, angles i and r, prism dispersion into VIBGYOR, eye lens with ciliary muscles, focal length f, dioptres, labels, formulas) so the student can study the visual diagram directly alongside the text!
      ` : ''}

      ${mode === 'diagram' ? `
      CRITICAL: DIAGRAM TUTOR PLAY MODE MANDATE:
      You are operating in dedicated DIAGRAM TUTOR PLAY MODE.
      In this mode, all teaching and studying MUST be anchored strictly around annotated visual diagrams, 2D vector schematics, dual-perspective teacher/student visual breakdowns, and interactive hotspot maps.
      Whenever explaining any concept, process, system, formula, or structure:
      1. AUTONOMOUSLY DRAW A HIGH-PRECISION TEXTBOOK DIAGRAM using <DRAW_IMAGE>detailed description of diagram...</DRAW_IMAGE>.
      2. INCLUDE ANNOTATED HOTSPOT NODES using <ANNOTATIONS>[{"label": "Node 1 Name", "description": "Explanation...", "x": 30, "y": 40}, ...]</ANNOTATIONS>.
      3. PROVIDE A DUAL-PERSPECTIVE BREAKDOWN:
         - Teacher View: Academic rigor, formal labels, principles, and structural keys.
         - Student View: Simplified memory tricks, step-by-step walk-through, and real-world analogies.
      4. CROSS-REFERENCE NODES using bracketed tags **[Node 1: Label]** in your text body.
      ` : ''}

      CRITICALLY IMPORTANT: You MUST strictly adopt the following persona and tone for EVERYTHING you output:
      Tutor Persona: ${tutor.name}. 
      Tutor Instructions: ${tutor.prompt}. 
      Voice / Style Persona Accent: ${persona.name}.
      Voice Style Tone Adjustments: ${persona.textToneAdjustment}.
      DO NOT BREAK CHARACTER. Your language, formatting, and stylistic choices MUST reflect this persona and voice style heavily.
      
      STRICT TEACHING DIRECTIVE ACCORDING TO SELECTION / DEMAND:
      - Professors MUST teach strictly according to what the student explicitly selects or demands (teach about EXACTLY what is asked for).
      - Do NOT rearrange study content according to the question or force an unrequested introductory lecture/preamble.
      - IF THE USER ASKS FOR NUMERICAL QUESTIONS OR PRACTICE PROBLEMS, START IMMEDIATELY FROM A NUMERICAL QUESTION / PROBLEM STATEMENT, NOT FROM AN INTRODUCTION OR HISTORICAL PREAMBLE.

      MANDATORY NATURAL HUMAN LANGUAGE TEACHING DIRECTIVE (FOR A STUDENT):
      - Reading is robotic. Teaching is human. You are a real, warm, articulate human educator teaching a student.
      - Teach and explain all concepts, formulas, and steps in pure natural human languages (for a student).
      - Address the student directly ("you", "we", "let's look at this together", "imagine this").
      - Use natural human numbers and natural step sequences (Step 1, Step 2, Step 3... never 0-indexed or robotic machine indices).
      - STRICT ZERO MACHINE SYNTAX: NEVER output machine commands, bracketed tags, avatar directives, timing parameters, or pseudo-code (such as [AVATAR:...], [SMARTBOARD:...], [Type:...], [Draw:...], [Scroll:...], [Pause:...], [Animation:...], [Phase:...], [sync_with:...], [TEACHING_GOLDEN_RULE], [ANALOGY_METHOD], etc.).
      - NEVER pronounce formatting symbols or markup names aloud (no saying "asterisk", "star star", "hash", "bullet point", "dot dot dot", "hyphen", "dash", "underscore", "backslash", "slash", "equals sign", "bracket").
      
      CRITICAL: IMPLEMENT PEER SIMULATION & DIALOGUE INTERRUPTION:
      - Periodically simulate a "classmate" agent in the conversation who is also learning. Have this classmate ask relatable questions, make common conceptual errors, or show curiosity. Wrap this message in <PEER_AGENT>...</PEER_AGENT> tags.
      - Structure long lectures to pause every 2–3 key concepts. Inject informal, low-stakes checkpoint queries to verify user understanding before proceeding.
      
      CRITICAL: IMPLEMENT SOCRATIC SCAFFOLDING ENGINE:
      - Track the user's mastery of sub-skills: ${safeJsonStringify(mastery)}.
      - If the user demonstrates mastery < 50% in a foundational skill relevant to the current topic, gracefully pivot the conversation back to simpler pre-requisites.
      - Actively evaluate user responses for sub-skill mastery.

      CRITICAL: DIAGNOSTIC CARD EXTRACTION:
      - Monitor the conversation for pronunciation slips, lab data points, or key vocabulary.
      - Periodically output diagnostic information in <DIAGNOSTIC_CARD type="pronunciation|lab_data|vocabulary" content="...">...</DIAGNOSTIC_CARD> tags.
      
      Current user level: ${user.difficulty}. 
      Current subject: ${user.subject}.
      Current topic: ${user.topic}. 
      If the subject or topic is 'other', you are a general-purpose AI assistant capable of answering any question.
      Current language: ${lang.name} (${lang.native}). Respond in ${lang.name} unless the user explicitly asks for another language.
      
      STRICT LATEX & MATH FORMATTING MANDATE:
      Use LaTeX for mathematical expressions. Wrap inline math in $ ... $ and block display math equations in $$ ... $$.
      NEVER output raw, unformatted LaTeX text or incomplete LaTeX code strings directly in plain prose without delimiters. Ensure math expressions are complete and properly formatted so that they render seamlessly as beautiful mathematical typography on the screen.
      Always provide step-by-step explanations when asked.
      
      CRITICAL MATH INPUT HANDLING: The user may input or paste mathematical equations that are spread across multiple lines, have vertical fraction layouts (e.g., numerator and denominator on separate lines like "F=\n dt\n dp" or variables split vertically), or are written in a mix of Hindi (e.g., "जहाँ" meaning "where") and English. You MUST automatically recognize, parse, and normalize these vertical or multi-line copy-pasted patterns into standard mathematical equations (e.g., F = dp/dt, where p = mv) and represent them perfectly using LaTeX. Always explain them in the requested language (Hindi or English). DIFFERENTIAL NOTATIONS WARNING: Symbols like 'dr', 'dx', 'dy', 'dt', 'dr\'' inside calculus equations represent infinitesimal displacements or small changes, NOT "doctor"! Ensure you spell out or clarify what they mean clearly so the voice reader does not mispronounce them as doctor.
      Use your search tool to provide the most up-to-date and accurate information from reliable sources.
      If the user asks for videos, provide a list of relevant educational video titles and links.
      
      ${getPedagogyPrompt(isProfessorMode, tutor.name, tutor.prompt, isLectureMode, lectureProfessorStyle, tutorPersonaConfig, lectureSubMode)}`;

      const model = isLowLatency ? 'gemini-3.1-flash-lite-preview' : 'gemini-3.6-flash';
      const thinkingLevel = isThinking ? ThinkingLevel.HIGH : undefined;

      const startTime = performance.now();
      let response;
      if (imageBase64) {
        const base64Data = imageBase64.split(',')[1];
        const contents = [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  mimeType: 'image/png',
                  data: base64Data
                }
              },
              {
                text: text
              }
            ]
          }
        ];
        response = await generateAIResponse(text, {
          systemInstruction,
          contents,
          model,
          thinkingLevel,
          mode
        });
      } else {
        const history = messages.slice(-10).map(m => ({
          role: m.sender === 'user' ? 'user' : 'model',
          parts: [{ text: m.content }]
        }));
        response = await generateAIResponse(text, { 
          systemInstruction, 
          history,
          model,
          thinkingLevel,
          mode
        });
      }
      const durationSeconds = parseFloat(((performance.now() - startTime) / 1000).toFixed(1));
      
      let finalContent = response;
      const diagnosticMatch = response.match(/<DIAGNOSTIC_CARD type="(.*?)" content="(.*?)">(.*?)<\/DIAGNOSTIC_CARD>/s);
      if (diagnosticMatch) {
        const card: DiagnosticCard = {
          id: generateId('card_'),
          type: diagnosticMatch[1] as any,
          content: diagnosticMatch[3],
          timestamp: Date.now()
        };
        setDiagnosticCards(prev => [...prev, card]);
        showNotification('New diagnostic study card created!', 'info');
        finalContent = finalContent.replace(/<DIAGNOSTIC_CARD.*?>.*?<\/DIAGNOSTIC_CARD>/s, "").trim();
      }
      if (finalContent.includes('<PEER_AGENT>')) {
        showNotification('A classmate agent is asking a question!', 'info');
        finalContent = finalContent.replace(/<PEER_AGENT>|<\/PEER_AGENT>/g, '');
      }
      let imageUrl: string | undefined;
      let videoUrl: string | undefined;
      let annotations: any[] = [];

      // Check if user explicitly asked for an image generation
      const isExplicitImageRequest = /(?:generate|create|draw|make|render)\s+(?:an?\s+)?(?:image|picture|photo|illustration|drawing|artwork)/i.test(rawText);
      const imageRequestMatch = response.match(/<DRAW_IMAGE>(.*?)<\/DRAW_IMAGE>/is);
      if (imageRequestMatch && isExplicitImageRequest) {
        const prompt = imageRequestMatch[1].trim();
        imageUrl = await handleGenerateMedia(prompt, 'image');
      }
      finalContent = finalContent.replace(/<DRAW_IMAGE>.*?<\/DRAW_IMAGE>/gis, "").trim();
      finalContent = finalContent.replace(/<ANNOTATIONS>.*?<\/ANNOTATIONS>/gis, "").trim();

      // Strip artificial [Node X: Label] bracket tags so text reads naturally and cleanly
      finalContent = finalContent.replace(/\[\s*Node\s*\d+\s*:\s*([^\]]+)\]/gi, '$1');
      finalContent = finalContent.replace(/\[\s*Node\s*\d+\s*\]/gi, '');

      const videoRequestMatch = response.match(/<GENERATE_VIDEO>(.*?)<\/GENERATE_VIDEO>/);
      if (videoRequestMatch) {
        const prompt = videoRequestMatch[1];
        videoUrl = await handleGenerateMedia(prompt, 'video');
        finalContent = finalContent.replace(/<GENERATE_VIDEO>.*?<\/GENERATE_VIDEO>/, "").trim();
      } else if (/make a video|video summary|video of (the|full|our) conversation/i.test(rawText)) {
        const summaryPrompt = `Cinematic educational lesson video summarizing the key learning concepts, study notes, and full conversation session: ${rawText}`;
        videoUrl = await handleGenerateMedia(summaryPrompt, 'video');
      }

      // Guarantee Figure & Diagram Generation in Learn Mode & Educational Queries:
      // If the response describes visual, physical, mathematical, biological, or optical phenomena (like refraction, dispersion, eye accommodation, dioptre, etc.)
      // but the model did not emit an inline SVG, automatically enrich it with a high-fidelity topic SVG schematic from our curriculum engine.
      if (!finalContent.includes('<svg') || !finalContent.includes('</svg>')) {
        const queryTopic = `${rawText} ${finalContent.slice(0, 400)} ${user.topic || ''} ${user.subject || ''}`;
        const topicSvg = generateTopicSvgDiagram(queryTopic, user.subject || 'physics');
        if (topicSvg) {
          const cleanHeading = rawText.replace(/<[^>]+>/g, '').trim().slice(0, 50) || user.topic || 'Visual Illustration';
          finalContent = `${finalContent}\n\n### 🎨 Diagrammatic Illustration: ${cleanHeading}\n${topicSvg}\n`;
        }
      }
      
      const aiMsg: Message = {
        id: generateId('msg_'),
        content: finalContent,
        sender: 'ai',
        timestamp: Date.now(),
        metadata: { 
          confidence: 0.85 + Math.random() * 0.1, 
          source: 'knowledge_base',
          durationSeconds: durationSeconds || 0.1,
          modelName: isLowLatency ? 'Omni AI Lite' : 'Omni AI',
          ...(imageUrl ? { image: imageUrl, annotations } : {}),
          ...(videoUrl ? { videoUrl } : {})
        }
      };
      
      setMessages(prev => [...prev, aiMsg]);

      // Check if the AI response contains SVG / 2D diagram code or visual drawings
      const hasSvgOrDiagram = (
        finalContent.includes('<svg') ||
        response.includes('<svg') ||
        response.includes('<DRAW_IMAGE>') ||
        finalContent.includes('<DRAW_IMAGE>') ||
        /```(?:xml|svg)[\s\S]*?<svg/i.test(response) ||
        Boolean(imageUrl)
      );

      if (hasSvgOrDiagram) {
        // Automatically trigger Global Classroom Mute / Silent-Mode for TTS engine
        setIsClassroomMute(true);
        setIsDiagramRendering(true);
      }

      const executeSpokenResponse = async () => {
        if (!isTTSEnabled) return;
        try {
          const currentPersona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[1];
          const cleanSpeechText = cleanTextForNaturalSpeech(response);
          if (!cleanSpeechText.trim()) return;

          const audioBase64 = await generateSpeech(cleanSpeechText, currentPersona?.voiceName || 'Kore');
          if (audioBase64) {
            const wavBase64 = convertPcmToWav(audioBase64);
            const audio = new Audio(`data:audio/wav;base64,${wavBase64}`);
            
            // Setup Web Audio pipeline with Voice Normalization and Timbre Standardization
            const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
            if (AudioContextClass) {
              try {
                const ctx = new AudioContextClass();
                const source = ctx.createMediaElementSource(audio);
                const filterChain = createVoiceNormalizationChain(ctx);
                
                source.connect(filterChain.input);
                filterChain.output.connect(ctx.destination);
              } catch (webAudioErr) {
                console.warn("Failed to create Web Audio normalization node chain, playing raw audio fallback:", webAudioErr);
              }
            }
            audio.play();
          } else {
            if (window.speechSynthesis) {
              const utterance = new SpeechSynthesisUtterance(cleanSpeechText);
              utterance.rate = ttsRate;
              
              const langTag = getLpcLanguageTag(user.language);
              utterance.lang = langTag;
              const voices = window.speechSynthesis.getVoices();
              const matchingVoice = voices.find(v => v.lang.toLowerCase() === langTag.toLowerCase() || v.lang.toLowerCase().startsWith(user.language.toLowerCase()));
              if (matchingVoice) {
                utterance.voice = matchingVoice;
              }
              
              window.speechSynthesis.speak(utterance);
            }
          }
        } catch (ttsErr) {
          console.error("TTS play failed, using browser fallback:", ttsErr);
          if (window.speechSynthesis) {
            const utterance = new SpeechSynthesisUtterance(cleanTextForNaturalSpeech(response));
            utterance.rate = ttsRate;
            
            const langTag = getLpcLanguageTag(user.language);
            utterance.lang = langTag;
            const voices = window.speechSynthesis.getVoices();
            const matchingVoice = voices.find(v => v.lang.toLowerCase() === langTag.toLowerCase() || v.lang.toLowerCase().startsWith(user.language.toLowerCase()));
            if (matchingVoice) {
              utterance.voice = matchingVoice;
            }
            
            window.speechSynthesis.speak(utterance);
          }
        }
      };

      if (hasSvgOrDiagram) {
        // Defer audio vocalization until visual rendering is complete, then clear silent-mode and speak
        setTimeout(() => {
          setIsClassroomMute(false);
          setIsDiagramRendering(false);
          executeSpokenResponse();
        }, 750);
      } else {
        setIsClassroomMute(false);
        setIsDiagramRendering(false);
        executeSpokenResponse();
      }
      
      updateProgress(20);
      updateQuestProgress('solve_5', 1);

    } catch (error: any) {
      console.error(error);
      showNotification(error.message || 'AI response failed. Please try again.', 'error');
    } finally {
      setIsTyping(false);
    }
  };

  const updateProgress = (amount: number) => {
    setUser(prev => {
      const newXp = prev.xp + amount;
      const nextLevelXp = prev.level * 500;
      if (newXp >= nextLevelXp) {
        showNotification(`Level Up! You are now level ${prev.level + 1}`, 'success');
        return { ...prev, xp: newXp - nextLevelXp, level: prev.level + 1, lastStudyDate: new Date().toISOString() };
      }
      return { ...prev, xp: newXp, lastStudyDate: new Date().toISOString() };
    });
  };

  const updateQuestProgress = (id: string, amount: number) => {
    setQuests(prev => prev.map(q => {
      if (q.id === id) {
        const newProgress = Math.min(q.max, q.progress + amount);
        if (newProgress === q.max && q.progress < q.max) {
          showNotification(`Quest Completed: ${q.title}! +${q.xp} XP`, 'success');
          updateProgress(q.xp);
        }
        return { ...q, progress: newProgress };
      }
      return q;
    }));
  };

  const handleManualSync = useCallback(() => {
    try {
      const savedUser = localStorage.getItem('omni_user');
      if (savedUser) {
        setUser(prev => ({ ...prev, ...JSON.parse(savedUser) }));
      }
    } catch (e) {
      console.warn('Manual sync user state re-hydration failed', e);
    }
    window.dispatchEvent(new Event('resize'));
  }, []);

  const handleClearChat = useCallback(() => {
    setMessages([]);
    showNotification('Chat cleared successfully', 'info');
  }, []);

  const handleAwardXp = useCallback((xp: number) => {
    setUser(prev => {
      const newXp = prev.xp + xp;
      const newLevel = Math.floor(newXp / 100) + 1;
      const updated = { ...prev, xp: newXp, level: newLevel, lastStudyDate: new Date().toISOString() };
      localStorage.setItem('omni_user', JSON.stringify(updated));
      return updated;
    });
    showNotification(`You've earned +${xp} XP in Unit Pronunciation Practice! Keep up the great work!`, 'success');
  }, [setUser, showNotification]);

  const handleDeleteMessage = (msgId: string) => {
    setMessages(prev => prev.filter(m => m.id !== msgId));
    showNotification('Message deleted', 'info');
  };

  const handleSelectLanguage = useCallback((lang: string) => {
    setUser(prev => {
      if (prev.language === lang) return prev;
      return { ...prev, language: lang };
    });
  }, []);

  const handleSelectTopicFromClassroom = useCallback((_topicName: string) => {
    // Unidirectional data flow mandate:
    // "don't make any changes according to the right side of the virtual 3D in the right side of the standard tutor play mode"
    // Therefore, any topic selection or interaction in the virtual 3D does NOT alter messagesByMode['learn'] or the right-side standard tutor state.
  }, []);

  const handleCloseClassroom = useCallback(() => {
    setMode('learn');
  }, []);

  const handleFileUpload = async (file: File) => {
    const isImage = file.type.startsWith('image/');
    const isPdf = file.type === 'application/pdf';
    const isText = file.type.startsWith('text/') || file.name.endsWith('.txt') || file.name.endsWith('.md') || file.name.endsWith('.json') || file.name.endsWith('.js') || file.name.endsWith('.ts') || file.name.endsWith('.tsx') || file.name.endsWith('.py') || file.name.endsWith('.cpp') || file.name.endsWith('.java') || file.name.endsWith('.html') || file.name.endsWith('.css');
    const isAudio = file.type.startsWith('audio/');
    const isVideo = file.type.startsWith('video/');

    if (!isImage && !isPdf && !isText && !isAudio && !isVideo) {
      showNotification('Unsupported file type. Please upload an image, document, text file, audio, or video.', 'warning');
      return;
    }

    showNotification(`Processing and reading ${file.name}...`, 'info');
    setIsTyping(true);

    const reader = new FileReader();

    if (isText) {
      reader.readAsText(file);
      reader.onload = async () => {
        const textContent = reader.result as string;

        // Insert user message with text snippet or attachment info
        const userMsg: Message = {
          id: generateId('msg_'),
          content: `📄 **Uploaded document:** _${file.name}_\n\nHere is the content of the file:\n\`\`\`\n${textContent}\n\`\`\`\n\nPlease analyze this document and answer any questions or help me understand/solve it!`,
          sender: 'user',
          timestamp: Date.now()
        };
        setMessages(prev => [...prev, userMsg]);

        try {
          const tutor = CONFIG.TUTORS[user.tutor as keyof typeof CONFIG.TUTORS] || CONFIG.TUTORS.direct;
          const lang = LANGUAGES.find(l => l.code === user.language) || LANGUAGES[0];
          const persona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[1];

          const systemInstruction = `You are Omni AI, a universal education system. 
          CRITICALLY IMPORTANT: If anyone asks "who made you", "who is your creator", "who created you", "who developed you", or any similar question, your response MUST state that you are Omni AI, a universal education platform developed by the Omni AI Team. Under no circumstances should you ever mention the name "D.K Mourya", "Mourya", or "India" as your creator. Keep all replies completely focused on being an educational assistant, and never reveal any individual's name.
          
          CRITICALLY IMPORTANT: You MUST strictly adopt the following persona and tone for EVERYTHING you output:
          Tutor Persona: ${tutor.name}. 
          Tutor Instructions: ${tutor.prompt}. 
          Voice / Style Persona Accent: ${persona.name}.
          Voice Style Tone Adjustments: ${persona.textToneAdjustment}.
          DO NOT BREAK CHARACTER. Your language, formatting, and stylistic choices MUST reflect this persona and voice style heavily.
          
          Current user level: ${user.difficulty}. 
          Current subject: ${user.subject}.
          Current topic: ${user.topic}. 
          If the subject or topic is 'other', you are a general-purpose AI assistant capable of answering any question.
          Current language: ${lang.name} (${lang.native}). Respond in ${lang.name} unless the user explicitly asks for another language.
          
          Use LaTeX for mathematical expressions if relevant. Wrap inline math in $ and block math in $$.
          Always provide step-by-step explanations in natural human language (for a student) using natural human numbers (Step 1, Step 2...) and no machine syntax or symbol pronunciation.
          
          CRITICAL MATH INPUT HANDLING: The user may input or paste mathematical equations that are spread across multiple lines, have vertical fraction layouts (e.g., numerator and denominator on separate lines like "F=\n dt\n dp" or variables split vertically), or are written in a mix of Hindi (e.g., "जहाँ" meaning "where") and English. You MUST automatically recognize, parse, and normalize these vertical or multi-line copy-pasted patterns into standard mathematical equations (e.g., F = dp/dt, where p = mv) and represent them perfectly using LaTeX. Always explain them in the requested language (Hindi or English). DIFFERENTIAL NOTATIONS WARNING: Symbols like 'dr', 'dx', 'dy', 'dt', 'dr\'' inside calculus equations represent infinitesimal displacements or small changes, NOT "doctor"! Ensure you spell out or clarify what they mean clearly so the voice reader does not mispronounce them as doctor.
          
          The user has uploaded a document file. Carefully examine the content of the document, and provide a comprehensive explanation or step-by-step answer to help the user.
          
          STRICT LATEX & MATH FORMATTING MANDATE:
          Use LaTeX for mathematical expressions. Wrap inline math in $ ... $ and block display math equations in $$ ... $$.
          NEVER output raw, unformatted LaTeX text or incomplete LaTeX code strings directly in plain prose without delimiters. Ensure math expressions are complete and properly formatted so that they render seamlessly as beautiful mathematical typography on the screen.
          
          ${getPedagogyPrompt(isProfessorMode, tutor.name, tutor.prompt, isLectureMode, lectureProfessorStyle, tutorPersonaConfig, lectureSubMode)}`;

          const contents = [
            {
              role: 'user',
              parts: [
                {
                  text: `Please analyze the uploaded document content and solve/explain it:\n\nFilename: ${file.name}\nContent:\n${textContent}`
                }
              ]
            }
          ];

          const model = isLowLatency ? 'gemini-3.1-flash-lite-preview' : 'gemini-3.6-flash';
          const thinkingLevel = isThinking ? ThinkingLevel.HIGH : undefined;

          const startTimeDoc = performance.now();
          const response = await generateAIResponse("Please solve the problem/explain the document contents.", {
            systemInstruction,
            contents,
            model,
            thinkingLevel
          });
          const durationSeconds = parseFloat(((performance.now() - startTimeDoc) / 1000).toFixed(1));

          const aiMsg: Message = {
            id: generateId('msg_'),
            content: response,
            sender: 'ai',
            timestamp: Date.now(),
            metadata: { 
              confidence: 0.98, 
              source: 'document_solver',
              durationSeconds: durationSeconds || 0.1,
              modelName: isLowLatency ? 'Omni AI Lite' : 'Omni AI'
            }
          };

          setMessages(prev => [...prev, aiMsg]);
          showNotification('Document analyzed successfully!', 'success');

          if (isTTSEnabled) {
            const currentPersona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[1];
            const audioBase64 = await generateSpeech(response, currentPersona?.voiceName || 'Kore');
            if (audioBase64) {
              const audio = new Audio(`data:audio/wav;base64,${audioBase64}`);
              
              // Setup Web Audio pipeline with Voice Normalization and Timbre Standardization
              const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
              if (AudioContextClass) {
                try {
                  const ctx = new AudioContextClass();
                  const source = ctx.createMediaElementSource(audio);
                  const filterChain = createVoiceNormalizationChain(ctx);
                  
                  source.connect(filterChain.input);
                  filterChain.output.connect(ctx.destination);
                } catch (webAudioErr) {
                  console.warn("Failed to create Web Audio normalization node chain, playing raw audio fallback:", webAudioErr);
                }
              }
              audio.play();
            }
          }
        } catch (error) {
          console.error(error);
          showNotification('Failed to analyze the document. Please try again or copy-paste the text.', 'error');
        } finally {
          setIsTyping(false);
        }
      };
    } else {
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const dataUrl = reader.result as string;
        const base64Data = dataUrl.split(',')[1];
        const mimeType = file.type || (isPdf ? 'application/pdf' : 'image/jpeg');

        let displayContent = '';
        let previewMetadata: any = {};

        if (isImage) {
          displayContent = `📸 **Captured/Uploaded image:** _${file.name}_\n\nPlease analyze this image and solve the problem step-by-step!`;
          previewMetadata.image = dataUrl;
        } else if (isPdf) {
          displayContent = `📄 **Uploaded PDF document:** _${file.name}_\n\nPlease analyze this PDF and solve/explain the problems or questions inside!`;
        } else if (isAudio) {
          displayContent = `🎵 **Uploaded audio recording:** _${file.name}_\n\nPlease listen to this audio file, transcribe it if needed, and respond or explain what is being said!`;
        } else if (isVideo) {
          displayContent = `🎥 **Uploaded video clip:** _${file.name}_\n\nPlease watch this video, analyze its visual and audio content, and respond or explain it!`;
        }

        const userMsg: Message = {
          id: generateId('msg_'),
          content: displayContent,
          sender: 'user',
          timestamp: Date.now(),
          metadata: previewMetadata
        };
        setMessages(prev => [...prev, userMsg]);

        try {
          const tutor = CONFIG.TUTORS[user.tutor as keyof typeof CONFIG.TUTORS] || CONFIG.TUTORS.direct;
          const lang = LANGUAGES.find(l => l.code === user.language) || LANGUAGES[0];
          const persona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[1];

          const systemInstruction = `You are Omni AI, a universal education system. 
          CRITICALLY IMPORTANT: If anyone asks "who made you", "who is your creator", "who created you", "who developed you", or any similar question, your response MUST state that you are Omni AI, a universal education platform developed by the Omni AI Team. Under no circumstances should you ever mention the name "D.K Mourya", "Mourya", or "India" as your creator. Keep all replies completely focused on being an educational assistant, and never reveal any individual's name.
          
          CRITICALLY IMPORTANT: You MUST strictly adopt the following persona and tone for EVERYTHING you output:
          Tutor Persona: ${tutor.name}. 
          Tutor Instructions: ${tutor.prompt}. 
          Voice / Style Persona Accent: ${persona.name}.
          Voice Style Tone Adjustments: ${persona.textToneAdjustment}.
          DO NOT BREAK CHARACTER. Your language, formatting, and stylistic choices MUST reflect this persona and voice style heavily.
          
          Current user level: ${user.difficulty}. 
          Current subject: ${user.subject}.
          Current topic: ${user.topic}. 
          If the subject or topic is 'other', you are a general-purpose AI assistant capable of answering any question.
          Current language: ${lang.name} (${lang.native}). Respond in ${lang.name} unless the user explicitly asks for another language.
          
          Use LaTeX for mathematical expressions if relevant. Wrap inline math in $ and block math in $$.
          Always provide step-by-step explanations.
          
          CRITICAL MATH INPUT HANDLING: The user may input or paste mathematical equations that are spread across multiple lines, have vertical fraction layouts (e.g., numerator and denominator on separate lines like "F=\n dt\n dp" or variables split vertically), or are written in a mix of Hindi (e.g., "जहाँ" meaning "where") and English. You MUST automatically recognize, parse, and normalize these vertical or multi-line copy-pasted patterns into standard mathematical equations (e.g., F = dp/dt, where p = mv) and represent them perfectly using LaTeX. Always explain them in the requested language (Hindi or English). DIFFERENTIAL NOTATIONS WARNING: Symbols like 'dr', 'dx', 'dy', 'dt', 'dr\'' inside calculus equations represent infinitesimal displacements or small changes, NOT "doctor"! Ensure you spell out or clarify what they mean clearly so the voice reader does not mispronounce them as doctor.
          
          The user has uploaded a media file (${isImage ? 'image' : isPdf ? 'PDF' : isAudio ? 'audio' : 'video'}). Carefully examine the file content, transcribe text/sound if needed, and provide a comprehensive explanation or step-by-step answer.
          
          STRICT LATEX & MATH FORMATTING MANDATE:
          Use LaTeX for mathematical expressions. Wrap inline math in $ ... $ and block display math equations in $$ ... $$.
          NEVER output raw, unformatted LaTeX text or incomplete LaTeX code strings directly in plain prose without delimiters. Ensure math expressions are complete and properly formatted so that they render seamlessly as beautiful mathematical typography on the screen.
          
          ${getPedagogyPrompt(isProfessorMode, tutor.name, tutor.prompt, isLectureMode, lectureProfessorStyle, tutorPersonaConfig, lectureSubMode)}`;

          const contents = [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    mimeType,
                    data: base64Data
                  }
                },
                {
                  text: `Please analyze the attached ${isImage ? 'image' : isPdf ? 'PDF document' : isAudio ? 'audio recording' : 'video clip'} and explain or solve it in full detail.`
                }
              ]
            }
          ];

          const model = isLowLatency ? 'gemini-3.1-flash-lite-preview' : 'gemini-3.6-flash';
          const thinkingLevel = isThinking ? ThinkingLevel.HIGH : undefined;

          const startTimeMedia = performance.now();
          const response = await generateAIResponse(`Please solve/explain the ${isImage ? 'image' : isPdf ? 'PDF' : isAudio ? 'audio' : 'video'}.`, {
            systemInstruction,
            contents,
            model,
            thinkingLevel
          });
          const durationSeconds = parseFloat(((performance.now() - startTimeMedia) / 1000).toFixed(1));

          const aiMsg: Message = {
            id: generateId('msg_'),
            content: response,
            sender: 'ai',
            timestamp: Date.now(),
            metadata: { 
              confidence: 0.98, 
              source: isImage ? 'visual_solver' : isPdf ? 'pdf_solver' : 'media_solver',
              durationSeconds: durationSeconds || 0.1,
              modelName: isLowLatency ? 'Omni AI Lite' : 'Omni AI'
            }
          };

          setMessages(prev => [...prev, aiMsg]);
          showNotification('File processed and solved successfully!', 'success');

          if (isTTSEnabled) {
            const currentPersona = PERSONAS.find(p => p.id === selectedPersonaId) || PERSONAS[1];
            const audioBase64 = await generateSpeech(response, currentPersona?.voiceName || 'Kore');
            if (audioBase64) {
              const audio = new Audio(`data:audio/wav;base64,${audioBase64}`);
              
              // Setup Web Audio pipeline with Voice Normalization and Timbre Standardization
              const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
              if (AudioContextClass) {
                try {
                  const ctx = new AudioContextClass();
                  const source = ctx.createMediaElementSource(audio);
                  const filterChain = createVoiceNormalizationChain(ctx);
                  
                  source.connect(filterChain.input);
                  filterChain.output.connect(ctx.destination);
                } catch (webAudioErr) {
                  console.warn("Failed to create Web Audio normalization node chain, playing raw audio fallback:", webAudioErr);
                }
              }
              audio.play();
            }
          }
        } catch (error) {
          console.error(error);
          showNotification('Failed to analyze the file. Please try again with a smaller file or standard image.', 'error');
        } finally {
          setIsTyping(false);
        }
      };
    }
  };

  const handleToggleVoice = () => {
    setIsRecording(!isRecording);
  };

  const handlePlayVideo = (video: any) => {
    const ytId = video.youtubeId || (video.url ? extractYouTubeId(video.url) : undefined);

    if (ytId) {
      const embedUrl = `https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0&modestbranding=1`;

      setModal({
        title: video.title,
        size: 'large',
        content: (
          <div className="flex flex-col h-full bg-slate-900 text-white rounded-2xl overflow-hidden shadow-2xl">
            {/* Header Bar */}
            <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <span className="flex h-2 w-2 rounded-full bg-red-500 animate-ping" />
                <p className="text-xs font-mono text-indigo-400 font-bold uppercase tracking-widest">
                  Omni Interactive Theater • {video.source || 'YouTube'}
                </p>
              </div>
              
              <a 
                href={video.url || `https://www.youtube.com/watch?v=${ytId}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs select-none transition-all duration-200 cursor-pointer shadow-lg shadow-red-900/20"
              >
                <span>Watch on YouTube</span>
                <ExternalLink size={12} />
              </a>
            </div>

            {/* Connection / Sandbox Failure Warning & Fallback Banner */}
            <div className="bg-amber-500/10 border-b border-amber-500/20 px-6 py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-amber-300 gap-3">
              <div className="flex items-start gap-2.5">
                <span className="flex h-2.5 w-2.5 rounded-full bg-amber-500 animate-pulse mt-1 shrink-0" />
                <div className="space-y-0.5">
                  <p className="font-bold">Did YouTube refuse to connect inside this sandbox?</p>
                  <p className="text-[11px] text-amber-200/80">
                    Some YouTube channels restrict third-party iframe playback. Click "Watch on YouTube" or "Open App in New Tab".
                  </p>
                </div>
              </div>
            </div>

            <div className="flex-1 relative bg-black aspect-video md:h-[480px]">
              <iframe
                src={embedUrl}
                title={video.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="absolute inset-0 w-full h-full border-0"
              />
            </div>
          </div>
        )
      });
      return;
    }

    if (video.isAIGenerated || video.url?.startsWith('data:') || video.url?.startsWith('blob:') || video.url?.includes('mp4') || video.url?.includes('generativelanguage') || video.url?.startsWith('http')) {
      const FALLBACK_URL = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
      let activeSrc = video.url || FALLBACK_URL;

      setModal({
        title: video.title,
        size: 'large',
        content: (
          <div className="flex flex-col h-full bg-slate-900 text-white rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <span className="flex h-2 w-2 rounded-full bg-indigo-500 animate-pulse" />
                <p className="text-xs font-mono text-indigo-400 font-bold uppercase tracking-widest">
                  Omni AI Custom Video Lesson
                </p>
              </div>
              {activeSrc?.startsWith('http') && (
                <a 
                  href={activeSrc} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs select-none transition-all duration-200 cursor-pointer shadow-lg shadow-indigo-900/20"
                >
                  <span>Download Lesson</span>
                  <ExternalLink size={12} />
                </a>
              )}
            </div>
            <div className="flex-1 relative bg-black aspect-video md:h-[480px]">
              <VideoWithOverlay
                src={activeSrc}
                events={video.events}
                className="w-full h-full"
              />
            </div>
            <div className="p-5 bg-slate-950/90 border-t border-slate-850 text-slate-300">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mt-0.5 animate-pulse">
                  <Sparkles size={16} />
                </div>
                <div className="flex-1 space-y-1">
                  <h4 className="text-xs font-black uppercase text-indigo-300 tracking-wider">
                    AI Generated Tutorial Lesson:
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    This video lesson covers <strong>{video.title}</strong>. If your network blocks direct playback, the reliable fallback video plays automatically.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )
      });
      return;
    }

    if (video.url) {
      window.open(video.url, '_blank', 'noopener,noreferrer');
    } else {
      showNotification('Video URL not available', 'error');
    }
  };

  const handleGenerateMedia = async (prompt: string, type: 'image' | 'video', options?: any) => {
    if (type === 'video') {
      setIsGeneratingVideo(true);
    }
    try {
      if (type === 'image') {
        const imageUrl = await generateImage(prompt, options?.aspectRatio);
        return imageUrl;
      } else {
        const videoUrl = await generateVideo(prompt);
        return videoUrl;
      }
    } catch (error) {
      console.error(error);
      showNotification('Media generation failed', 'error');
      return undefined;
    } finally {
      if (type === 'video') {
        setIsGeneratingVideo(false);
      }
    }
  };

  const handleGenerateRecap = async () => {
    if (messages.length < 2) {
      showNotification('Start a conversation before generating a recap!', 'warning');
      return;
    }

    setIsTyping(true);
    showNotification('AI is reviewing our chat to generate a recap...', 'info');

    try {
      const relevantMsgs = messages.filter(m => m.id !== 'welcome');
      const textLogs = relevantMsgs.map(m => `${m.sender.toUpperCase()}: ${m.content}`).join('\n\n');
      
      const prompt = `Review the following educational tutoring chat history and generate a structured Summary Recap. 

Your response MUST be a single clean valid JSON object with EXACTLY the following format, with NO codeblocks, NO markdown wrapper, NO extra text.
{
  "title": "A short descriptive, inspiring title summarizing the main topic studied (e.g., 'Mastering Quadratic Equations')",
  "summary": "A concise paragraph summarizing the primary knowledge gained, key explanations provided, and academic progress made during our conversation.",
  "keyConcepts": [
    "A vital formula, theorem, rule, definition, or concept learned (string, maximum 12 words per concept)",
    "Another vital item learned",
    "Third vital item learned",
    "Fourth vital item learned"
  ]
}

CHAT HISTORY:
${textLogs}`;

      const response = await generateAIResponse(prompt, {
        model: 'gemini-3.6-flash'
      });
      
      if (response) {
        const recap = JSON.parse(response);
        const recapMsg: Message = {
          id: generateId('msg_'),
          sender: 'ai',
          content: `### ${recap.title}\n\n${recap.summary}\n\n**Key Concepts:**\n${recap.keyConcepts.map((c: string) => `- ${c}`).join('\n')}`,
          timestamp: Date.now(),
        };
        setMessages(prev => [...prev, recapMsg]);
        showNotification('Summary Recap generated successfully!', 'success');
      } else {
        showNotification('Failed to generate study recap. Try talking more in the chat first!', 'error');
      }
    } catch (err) {
      console.error(err);
      showNotification('Failed to generate study recap. Try talking more in the chat first!', 'error');
    } finally {
      setIsTyping(false);
    }
  };

  const handleGenerateVideoFromChat = async (events: { timestamp: number; event: string }[] = []) => {
    if (messages.length < 2) {
      showNotification('Start a conversation before generating a video!', 'warning');
      return;
    }

    setIsTyping(true);
    showNotification('AI is reviewing our chat to generate a video...', 'info');

    // Sanitize events to ensure no circular objects or DOM nodes are passed
    const sanitizedEvents = (events || []).map(e => ({
      timestamp: Number(e.timestamp),
      event: String(e.event || 'Unknown Event')
    }));

    try {
      const relevantMsgs = messages.filter(m => m.id !== 'welcome');
      const textLogs = relevantMsgs.map(m => `${m.sender.toUpperCase()}: ${m.content}`).join('\n\n');
      
      const prompt = `Generate a high-fidelity educational storyboard for a video lesson.
The video should visually represent the following chat between an AI Tutor and a student.
Visual Style: Professional modern textbook animations, 2D vector schematics, and clear text overlays.
Topic: ${user.topic}
Subject: ${user.subject}

CHAT LOGS FOR CONTEXT:
${textLogs}`;

      const videoPrompt = await generateAIResponse(prompt);
      
      showNotification('Generating video...', 'info');
      const videoUri = await generateVideo(videoPrompt);

      if (videoUri) {
        // Save to AI Generated Videos in localStorage so VideoGrid can see it
        const newAiVideo = {
          id: generateId('v_'),
          title: `Chat Summary: ${user.topic}`,
          source: 'AI Studio (Omni AI)',
          duration: '0:30', // Placeholder
          thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=800&q=80',
          url: videoUri,
          channelTitle: 'Omni AI Tutor',
          viewCount: 1,
          publishedAt: new Date(),
          isAIGenerated: true,
          topic: user.topic,
          subject: user.subject,
          prompt: videoPrompt,
          likes: 0,
          description: `This video was automatically generated based on your chat session about ${user.topic}.`,
          events: sanitizedEvents // Sanitized metadata blob
        };

        setGeneratedVideos(prev => [newAiVideo, ...prev]);

        const videoMsg: Message = {
          id: generateId('msg_'),
          sender: 'ai',
          content: `Here is a video summarizing our conversation:`,
          timestamp: Date.now(),
          metadata: {
            videoUrl: videoUri,
            events: sanitizedEvents
          }
        };
        setMessages(prev => [...prev, videoMsg]);
        showNotification('Video generated successfully! Check "AI Generated" in the Video Mode.', 'success');
        setMode('videos');
      } else {
        showNotification('Failed to generate video.', 'error');
      }
    } catch (err) {
      console.error(err);
      showNotification('Failed to generate video.', 'error');
    } finally {
      setIsTyping(false);
    }
  };

  const handleSaveToNotes = (note: { title: string; summary: string; keyConcepts: string[]; subject: string; topic: string }) => {
    const newNote = {
      id: generateId('note_'),
      title: note.title,
      summary: note.summary,
      keyConcepts: note.keyConcepts,
      timestamp: Date.now(),
      subject: note.subject,
      topic: note.topic
    };
    setSavedNotes(prev => [newNote, ...prev]);
    showNotification('Study notes saved successfully to Chapters Explorer!', 'success');
  };

  const handleLoadChatSession = (session: ChatSessionRecord) => {
    const targetMode = session.mode || mode;
    if (session.messagesByMode && Object.keys(session.messagesByMode).length > 0) {
      setMessagesByMode(session.messagesByMode);
    } else if (session.messages && session.messages.length > 0) {
      setMessagesByMode(prev => ({
        ...prev,
        [targetMode]: session.messages
      }));
    }

    if (session.subject || session.topic) {
      setUser(prev => ({
        ...prev,
        subject: session.subject || prev.subject,
        topic: session.topic || prev.topic
      }));
    }

    if (session.mode && session.mode !== mode) {
      setMode(session.mode);
    }

    showNotification(`Loaded session "${session.title}" from Firestore`, 'success');
  };

  const handleOpenTool = (toolId: string, options?: any) => {
    switch (toolId) {
      case 'veo_video':
      case 'veo_3_video':
      case 'animate_image':
      case 'video_generation':
      case 'video_studio':
      case 'video_recap':
        setIsVeoVideoModalOpen(true);
        break;
      case 'universal_ai_tutor':
      case 'universal_tutor':
      case 'ai_tutor':
      case 'ai_tutor_chat':
      case 'tutor_chat':
      case 'chat_tutor':
        setIsUniversalTutorOpen(true);
        break;
      case 'chat_history':
      case 'history':
      case 'chat_sessions':
        setModal({
          title: 'Chat History & Saved Sessions',
          content: (
            <ChatHistoryModal
              theme={theme}
              currentMessages={messages}
              currentMessagesByMode={messagesByMode}
              currentSubject={user.subject}
              currentTopic={user.topic}
              currentMode={mode}
              onLoadSession={(session) => {
                handleLoadChatSession(session);
                setModal(null);
              }}
              onNewChat={() => {
                handleClearChat();
                setModal(null);
              }}
              onClose={() => setModal(null)}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'pwa_install':
      case 'install_app':
      case 'install':
        setModal({
          title: 'Install Omni AI App',
          content: (
            <div className="p-1">
              <PWAInstallGuide theme={theme} onClose={() => setModal(null)} />
            </div>
          ),
          size: 'default'
        });
        break;
      case 'doubt_board':
      case 'doubts':
      case 'anonymous_doubt_board':
        setModal({
          title: `Anonymous Doubt Board — ${options?.chapter || user.subject}`,
          content: (
            <div className="h-[80vh] -mx-4 -my-2 p-1 overflow-y-auto">
              <React.Suspense fallback={<div className="p-8 text-center"><div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>Loading Doubt Board...</div>}>
                <DoubtBoard
                  chapterId={options?.chapterId || (options?.chapter ? options.chapter.toLowerCase().replace(/[^a-z0-9]/g, '_') : user.subject.toLowerCase().replace(/[^a-z0-9]/g, '_'))}
                  chapterTitle={options?.chapter || user.subject}
                  topicId={options?.topicId || (options?.topic ? options.topic.toLowerCase().replace(/[^a-z0-9]/g, '_') : user.topic?.toLowerCase().replace(/[^a-z0-9]/g, '_'))}
                  topicTitle={options?.topic || user.topic}
                  isDark={theme === 'dark'}
                  onClose={() => setModal(null)}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'chapters':
        setModal({
          title: 'Chapters & Lesson Explorer',
          content: (
            <ChaptersExplorer
              theme={theme}
              subject={user.subject}
              topic={user.topic}
              difficulty={user.difficulty}
              setTopic={(newTopic) => {
                setUser(prev => ({ ...prev, topic: newTopic }));
              }}
              selectedBoard={user.selectedBoard}
              mode={mode}
              selectedEntranceExam={selectedEntranceExam}
              onStudyLesson={(lessonTitle, chapterTitle, depth) => {
                if (mode === 'videos') {
                  setModal({
                    title: `Video Lesson: ${lessonTitle}`,
                    size: 'large',
                    content: (
                      <LessonVideoCompiler
                        lessonTitle={lessonTitle}
                        chapterTitle={chapterTitle}
                        subject={user.subject}
                        difficulty={user.difficulty}
                        languageCode={user.language}
                        onGenerateVideo={(prompt) => handleGenerateMedia(prompt, 'video')}
                        onClose={() => setModal(null)}
                        onPublishToEduTube={(compiledVideo) => {
                          setGeneratedVideos(prev => [compiledVideo, ...prev]);
                          showNotification("Successfully published video to EduTube! 🎉", "success");
                        }}
                      />
                    )
                  });
                  showNotification(`Compiling video lesson: ${lessonTitle}`, 'info');
                  return;
                }

                setModal(null);
                let depthDescriptor = "";
                if (depth === 'quick') {
                  depthDescriptor = "Provide a QUICK, high-level summarized review block. Keep explanations exceptionally crisp, focus purely on foundational definitions and direct equations, and set up a quick 1-question interactive speed-quiz right away.";
                } else if (depth === 'deep') {
                  depthDescriptor = "Provide a DEEP, highly rigorous academic dissertation/study. Dive into formal mathematical/physical proofs, derivations, underlying mechanistic logic, historical discoveries and boundaries, edge cases, and test me with a comprehensive, multi-step honors-tier conceptual challenge.";
                } else if (depth === 'academic') {
                  depthDescriptor = "Provide an EXTREMELY advanced graduate research-grade session in the caliber of top global institutes like MIT, Cambridge (Mathematical Tripos), or IIT. Unpack complex theoretical proofs, multi-disciplinary modeling, potential open-ended academic questions/hypotheses, and provide 3 highly challenging multi-part analytical exam problems.";
                } else {
                  depthDescriptor = "Provide a standard, granular, step-by-step academic explanation. Explain definitions, list equations, detail a complete concrete worked-out example with intermediate steps, and test me on the content with 2 standard practice questions.";
                }

                handleSendMessage(`I want to study the lesson "${lessonTitle}" of Chapter "${chapterTitle}" to a degree of ${depth ? depth.toUpperCase() : 'STANDARD'} depth/rigor.\n\nTutor Rigor Instructions:\n${depthDescriptor}\n\nPlease proceed to teach the lesson now with high quality and formatting.`);
                showNotification(`Studying lesson: ${lessonTitle} (${depth ? depth.toUpperCase() : 'STANDARD'} depth)`, 'success');
              }}
              onGenerateQuiz={(chapterTitle) => {
                // Open quiz generator
                setModal({
                  title: 'Quiz Generator',
                  content: (
                    <QuizGenerator 
                      userName={user.name} 
                      onGenerateMedia={handleGenerateMedia} 
                      initialSubject={user.subject}
                      initialTopic={chapterTitle}
                      initialDifficulty={user.difficulty}
                      initialLanguage={LANGUAGES.find(l => l.code === user.language)?.name || 'English'}
                      showNotification={showNotification}
                    />
                  ),
                  size: 'large'
                });
                showNotification(`Practice Quiz generated on ${chapterTitle}`, 'info');
              }}
              savedNotes={savedNotes}
              onDeleteNote={(id) => {
                setSavedNotes(prev => prev.filter(n => n.id !== id));
                showNotification('Study note deleted', 'info');
              }}
              onReorderNotes={(newNotes) => {
                setSavedNotes(newNotes);
              }}
              initialTab={options?.tab}
              showNotification={showNotification}
              onRewardXp={(xpReward) => {
                setUser(prev => ({ ...prev, xp: prev.xp + xpReward }));
              }}
            />
          ),
          size: 'xl'
        });
        break;
      case 'quiz':
        setModal({
          title: 'Quiz Generator',
          content: (
            <QuizGenerator 
              userName={user.name} 
              onGenerateMedia={handleGenerateMedia}
              initialSubject={options?.subject}
              initialTopic={options?.topic}
              initialDifficulty={options?.difficulty || user.difficulty}
              initialLanguage={LANGUAGES.find(l => l.code === (options?.language || user.language))?.name || 'English'}
              showNotification={showNotification}
            />
          ),
          size: 'large'
        });
        break;
      case 'solver':
        const currentTutor = CONFIG.TUTORS[user.tutor as keyof typeof CONFIG.TUTORS] || CONFIG.TUTORS.direct;
        setModal({
          title: 'Step-by-Step Solver',
          content: <StepByStepSolver tutorPrompt={currentTutor.prompt} tutorName={currentTutor.name} />,
          size: 'large'
        });
        break;
      case 'document':
        setModal({
          title: 'Document Analyzer',
          content: <DocumentAnalyzer />,
          size: 'large'
        });
        break;
      case 'pronunciation':
        setModal({
          title: 'Scientific Unit Pronunciation Trainer',
          content: (
            <UnitPronunciationTrainer
              onAwardXp={(xp) => {
                setUser(prev => {
                  const newXp = prev.xp + xp;
                  const newLevel = Math.floor(newXp / 100) + 1;
                  const updated = { ...prev, xp: newXp, level: newLevel };
                  localStorage.setItem('omni_user', JSON.stringify(updated));
                  return updated;
                });
                showNotification(`You've earned +${xp} XP in Unit Pronunciation! Keep up the great work!`, 'success');
              }}
              onClose={() => setModal(null)}
              theme={theme}
            />
          ),
          size: 'large'
        });
        break;
      case 'handwriting':
        setModal({
          title: 'Handwriting OCR',
          content: <HandwritingRecognizer onRecognized={(text) => {
            if (text) {
              setModal(null);
              showNotification('Text recognized: ' + text, 'success');
              handleSendMessage(text);
            }
          }} />,
          size: 'large'
        });
        break;
      case 'math':
        setModal({
          title: '3D Math Visualizer',
          content: <ThreeDMathVisualizer />,
          size: 'large'
        });
        break;
      case 'graph':
        setModal({
          title: 'Concept Mind Map Workspace',
          content: <KnowledgeGraph subject={user.subject} topic={user.topic} theme={theme} showNotification={showNotification} />,
          size: 'xl'
        });
        break;
      case 'cards':
        setModal({
          title: 'Adaptive Spaced Repetition (SM-2)',
          content: <SpacedRepetition subject={user.subject} topic={user.topic} theme={theme} showNotification={showNotification} />,
          size: 'xl'
        });
        break;
      case 'pomodoro':
        setModal({
          title: 'Study Focus Timer & Immersive Soundscapes',
          content: <PomodoroTimer theme={theme} />,
          size: 'large'
        });
        break;
      case 'chemistry_glossary':
        setModal({
          title: 'Interactive Chemistry Glossary',
          content: (
            <ChemistryGlossary
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'reaction_drill':
        setModal({
          title: 'Reaction Mechanism & Interconversion Drill (Competitive Arena)',
          content: (
            <ReactionMechanismDrill
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'chemistry_virtual_lab':
        setModal({
          title: 'Interactive Chemistry Virtual Lab Workbench',
          content: (
            <ChemistryVirtualLab
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'quick_periodic_table':
        setModal({
          title: 'Quick Periodic Table of Coordination Elements',
          content: (
            <QuickPeriodicTable
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'interactive_atom_builder':
        setModal({
          title: 'Interactive Atom Builder Virtual Lab',
          content: (
            <InteractiveAtomBuilder
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'smart_glossary':
        setModal({
          title: 'Smart Concept Glossary & Chat Tooltips',
          content: (
            <SmartConceptGlossary
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'dynamic_lab_report':
        setModal({
          title: 'Dynamic Lab Report Generator',
          content: (
            <DynamicLabReport
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'chemical_reaction_simulator':
        setModal({
          title: 'Chemical Reaction Mechanism Simulator',
          content: (
            <ChemicalReactionSimulator
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'chemical_reaction_animator':
        setModal({
          title: 'Chemical Reaction Animator',
          content: (
            <ChemicalReactionAnimator
              theme={theme}
              onOpenChapter={(chapterNumber) => {
                setModal(null);
                handleOpenTool('chapters');
              }}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'constants_calculator':
        setModal({
          title: 'Physical Constants & Unit Conversions Calculator',
          content: (
            <ChemistryConstantsCalculator
              theme={theme}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'nextgen_stem':
        setModal({
          title: 'Next-Gen STEM Simulation & Visualization Suite',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-2">
              <NextGenStemSimulationsHub
                theme={theme}
                initialTab="spatial_3d"
                onSendToChat={(prompt) => {
                  setModal(null);
                  handleSendMessage(prompt);
                }}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'spatial_3d':
        setModal({
          title: '3D Spatial Geometry & Molecular Lattice Simulator',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-2">
              <NextGenStemSimulationsHub
                theme={theme}
                initialTab="spatial_3d"
                onSendToChat={(prompt) => {
                  setModal(null);
                  handleSendMessage(prompt);
                }}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'physics_lab':
        setModal({
          title: 'Advanced Multi-Domain Physics Engine Sandbox',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-2">
              <NextGenStemSimulationsHub
                theme={theme}
                initialTab="physics_sandbox"
                onSendToChat={(prompt) => {
                  setModal(null);
                  handleSendMessage(prompt);
                }}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'proof_checker':
        setModal({
          title: 'Automated Mathematical Proof Checker & Logic Assistant',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-2">
              <NextGenStemSimulationsHub
                theme={theme}
                initialTab="proof_checker"
                onSendToChat={(prompt) => {
                  setModal(null);
                  handleSendMessage(prompt);
                }}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'biology_lab':
        setModal({
          title: 'Interactive 3D Biology Lab & Ecosystem Simulator',
          content: (
            <div className="h-[80vh] -mx-6 -my-4">
              <BiologyLab theme={theme} onSendMessage={handleSendMessage} showNotification={showNotification} />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'biology_metrics':
        setModal({
          title: 'Biology Lab Metrics & Graphical Analysis (Recharts)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-2">
              <BiologyMetricsVisualization
                theme={theme}
                onSaveSnapshotNote={(title, summary, concepts) => {
                  window.dispatchEvent(
                    new CustomEvent('save_omni_note', {
                      detail: {
                        title,
                        summary,
                        keyConcepts: concepts,
                        subject: 'Science (Biology)',
                        topic: title
                      }
                    })
                  );
                  showNotification?.('Saved metric analysis to Study Notes', 'success');
                }}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'math_tables':
        setModal({
          title: 'Mathematical Tables (Logarithms & Antilogarithms)',
          content: (
            <MathematicalTables
              theme={theme}
              showNotification={showNotification}
            />
          ),
          size: 'xl'
        });
        break;
      case 'table_generator':
        setModal({
          title: 'Table Generator & Matrix Transformer',
          content: (
            <div className="h-[85vh] -mx-6 -my-4">
              <TableGenerator
                theme={theme === 'dark' ? 'dark' : 'light'}
                showNotification={showNotification}
                onInsertToChat={(md) => {
                  setModal(null);
                  handleSendMessage(md);
                }}
                onClose={() => setModal(null)}
                isInline={false}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'recap_video':
        setModal({
          title: 'AI Study Recap Video Generator',
          content: (
            <RecapVideoGenerator
              messages={messages}
              subject={user.subject}
              topic={user.topic}
              theme={theme}
              onSaveToNotes={handleSaveToNotes}
              showNotification={showNotification}
              onClose={() => setModal(null)}
            />
          ),
          size: 'xl'
        });
        break;
      case 'latex_tts':
        setModal({
          title: 'Semantic LaTeX-to-Speech Engine',
          content: <LaTeXToSpeechEngine theme={theme} showNotification={showNotification} isClassroomMode={lectureSubMode === 'classroom'} />,
          size: 'large'
        });
        break;
      case 'scratchpad':
        setModal({
          title: 'Interactive State Scratchpad',
          content: (
            <div className="h-[75vh] -mx-6 -my-4">
              <StateScratchpad
                theme={theme}
                subject={user.subject}
                topic={user.topic}
                onClose={() => setModal(null)}
                onSendToChat={(text, img) => {
                  setModal(null);
                  handleSendMessage(text, img);
                }}
                onSaveToNotes={handleSaveToNotes}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'seminar':
        setModal({
          title: 'Live Classroom Voice Q&A Seminar',
          content: (
            <div className="h-[80vh] -mx-6 -my-4">
              <React.Suspense fallback={<div className="h-full flex items-center justify-center font-bold text-slate-400">Loading Live Seminar...</div>}>
                <LiveSeminar
                  theme={theme}
                  subject={user.subject}
                  topic={user.topic}
                  onClose={() => setModal(null)}
                  showNotification={showNotification}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'spatialcanvas':
        setModal({
          title: 'Spatial Lecture Canvas',
          content: (
            <div className="h-[80vh] -mx-6 -my-4">
              <React.Suspense fallback={<div className="h-full flex items-center justify-center font-bold text-slate-400">Loading Spatial Canvas...</div>}>
                <SpatialLectureCanvas
                  theme={theme}
                  subject={user.subject}
                  topic={user.topic}
                  chatContent={messages.map(m => m.content).join('\n')}
                  showNotification={showNotification}
                  onClose={() => setModal(null)}
                  isClassroomMode={lectureSubMode === 'classroom'}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case '3d_classroom':
        setMode('3d_classroom');
        localStorage.setItem('omni_mode', '3d_classroom');
        showNotification?.("Switched to Virtual Learning Mode", "success");
        break;
      case 'explorer':
        setModal({
          title: 'Explore All Modes',
          content: (
            <div className="h-[85vh] -mx-6 -my-4">
              <ModeExplorer
                theme={theme}
                onClose={() => setModal(null)}
                onSelectAction={(id) => handleOpenTool(id)}
                onSelectMode={(m) => {
                  if (m === 'classroom_mode') {
                    setIsLectureMode(true);
                    setLectureSubMode('classroom');
                    localStorage.setItem('omni_lecture_mode', 'true');
                    localStorage.setItem('omni_lecture_sub_mode', 'classroom');
                    showNotification?.("Switched to Classroom Mode (Slate Blackboard)", "success");
                  } else {
                    setMode(m);
                    localStorage.setItem('omni_mode', m);
                    showNotification?.(`Switched to ${m.charAt(0).toUpperCase() + m.slice(1)} Mode`, "success");
                  }
                }}
                currentMode={mode}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'screenrecord':
      case 'screenshare':
        setModal({
          title: toolId === 'screenrecord' ? 'Screen Recording Studio' : 'Screen Share Studio',
          content: (
            <div className="h-[80vh] -mx-6 -my-4">
              <ScreenShare
                theme={theme}
                onClose={() => setModal(null)}
                showNotification={showNotification}
                initialTab={toolId === 'screenrecord' ? 'recorder' : 'share'}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'whiteboard':
      case 'math_whiteboard':
        setModal({
          title: 'Digital Math Whiteboard',
          content: (
            <div className="h-[85vh] -mx-6 -my-4">
              <React.Suspense fallback={<div className="h-full flex items-center justify-center font-bold text-slate-400">Loading Digital Whiteboard...</div>}>
                <MathDigitalWhiteboard
                  isOpen={true}
                  onClose={() => setModal(null)}
                  onSendToChat={(promptText, imageBase64) => {
                    setModal(null);
                    handleSendMessage(promptText, imageBase64);
                  }}
                  onAttachToInput={(imageBase64) => {
                    setModal(null);
                    handleSendMessage("I sketched this mathematical diagram/equation. Please analyze and explain it step-by-step:", imageBase64);
                  }}
                  theme={theme}
                  showNotification={showNotification}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'diagram':
        setModal({
          title: 'Diagram Vision AI',
          content: (
            <div className="h-[85vh] -mx-6 -my-4">
              <DiagramAnalyzer
                theme={theme}
                onClose={() => setModal(null)}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'feedback':
        setModal({
          title: 'Feedback',
          content: (
            <div className="h-[80vh] -mx-6 -my-4">
              <Feedback
                theme={theme}
                onClose={() => setModal(null)}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'large'
        });
        break;
      case 'code':
        setModal({
          title: 'Interactive Code Playground',
          content: <CodePlayground />,
          size: 'large'
        });
        break;
      
      
      case 'persona_wizard':
        setModal({
          title: 'Interactive AI Tutor Persona Customization Wizard',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-1">
              <TutorPersonaWizardModal
                theme={theme}
                onClose={() => setModal(null)}
                onSavePersona={(config) => {
                  setTutorPersonaConfig(config);
                  showNotification?.(`AI Tutor persona set to "${config.name}"!`, 'success');
                  setModal(null);
                }}
                initialConfig={tutorPersonaConfig}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'matrix_calculator':
        setModal({
          title: 'Matrix Calculator',
          content: (
            <div className="h-[85vh] -mx-6 -my-4 p-1">
              <MatrixCalculatorModal theme={theme} onClose={() => setModal(null)} />
            </div>
          ),
          size: 'large'
        });
        break;
      case 'algebraic_properties':
        setModal({
          title: 'Algebraic Properties Quick Reference',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <AlgebraicPropertiesModal theme={theme} onClose={() => setModal(null)} />
            </div>
          ),
          size: 'large'
        });
        break;
      case 'dashboard':
        setShowDashboard(prev => !prev);
        break;
      case 'multimodal_study':
      case 'multimodal':
        setModal({
          title: 'Multimodal Analysis & Instant Study Materials',
          content: (
            <div className="h-[85vh] -mx-6 -my-4">
              <MultimodalStudyMaterials
                theme={theme}
                onClose={() => setModal(null)}
                showNotification={showNotification}
                onSaveToNotes={handleSaveToNotes}
                subject={user.subject}
                topic={user.topic}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'biometric_vault':
        setModal({
          title: 'Biometric & Firebase Security Vault',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <BiometricSecurityVault theme={theme} showNotification={showNotification} onClose={() => setModal(null)} />
            </div>
          ),
          size: 'large'
        });
        break;
      case 'socratic_orchestrator':
        setModal({
          title: 'Socratic Lesson Orchestrator',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <SocraticLessonOrchestrator theme={theme} showNotification={showNotification} onClose={() => setModal(null)} />
            </div>
          ),
          size: 'large'
        });
        break;
      case 'virtuallab':
        setModal({
          title: 'Interactive WebXR Virtual Laboratory (3D Immersive Labs)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <React.Suspense fallback={<div className="h-full flex items-center justify-center font-bold text-slate-400">Loading Virtual Lab...</div>}>
                <VirtualLab theme={theme} />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'analytics':
        setModal({
          title: 'Predictive Analytics, Diagnostic Heatmaps & Practice Exam Simulator',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <PredictiveAnalytics theme={theme} />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'practice_exam':
        setModal({
          title: 'India-CBSE Mathematics Class 12 Practice Exam Simulator',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-1">
              <PracticeExamModule
                subject="Mathematics"
                theme={theme}
                onClose={() => setModal(null)}
                showNotification={showNotification}
                onRewardXp={handleAwardXp}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'practice_exam_physics':
        setModal({
          title: 'India-CBSE Physics Class 12 Practice Exam Simulator',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-1">
              <PracticeExamModule
                subject="Physics"
                theme={theme}
                onClose={() => setModal(null)}
                showNotification={showNotification}
                onRewardXp={handleAwardXp}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'practice_exam_chemistry':
        setModal({
          title: 'India-CBSE Chemistry Class 12 Practice Exam Simulator',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-1">
              <PracticeExamModule
                subject="Chemistry"
                theme={theme}
                onClose={() => setModal(null)}
                showNotification={showNotification}
                onRewardXp={handleAwardXp}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'practice_exam_biology':
        setModal({
          title: 'India-CBSE Biology Class 12 Practice Exam Simulator',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-1">
              <PracticeExamModule
                subject="Biology"
                theme={theme}
                onClose={() => setModal(null)}
                showNotification={showNotification}
                onRewardXp={handleAwardXp}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'quests':
        setModal({
          title: 'Gamified Adventure Quests & AI "Concept Bosses"',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <QuestAdventure theme={theme} />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'credentials':
        setModal({
          title: 'Verifiable Digital Micro-Credentials & Blockchain Certification',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <MicroCredentials theme={theme} />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'colab_rooms':
      case 'collaborative_study_rooms':
      case 'collaborative_rooms':
        setModal({
          title: 'Multi-User Collaborative Whiteboard Rooms',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <CollaborativeRooms theme={theme} />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'parent_portal':
      case 'parent_teacher_portal':
        setModal({
          title: 'Parent & Educator Portal with Smart Diagnostic Reports',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <ParentEducatorPortal theme={theme} showNotification={showNotification} />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'master_feature_suite':
      case 'master_features':
        setIsMasterFeatureSuiteOpen(true);
        break;
      case 'debugger':
      case 'clarity_debugger':
      case 'debug_professor_clarity':
      case 'system_health':
        setShowDebuggerModal(true);
        break;
      case 'auth_diagnostics':
      case 'auth_session_monitor':
      case 'auth_token_diagnostics':
      case 'firebase_auth_monitor':
        setShowAuthDiagnosticsModal(true);
        break;
      case 'prior_knowledge_diagnostic':
      case 'diagnostic_test':
      case 'knowledge_diagnostic':
        setModal({
          title: 'Adaptive Prior Knowledge Diagnostic (IRT Powered)',
          content: (
            <div className="max-h-[85vh] overflow-y-auto p-2">
              <DiagnosticTest
                chapterId={user.topic || 'electromagnetism'}
                chapterTitle={user.topic || 'Electromagnetism & AC Theory'}
                subject={user.subject || 'Physics'}
                studentId={user.name || 'Student'}
                onComplete={(res) => {
                  showNotification?.(`Diagnostic completed! You already know ${res.overallScore}% of this chapter.`, 'success');
                }}
                onSkip={() => {
                  setModal(null);
                  showNotification?.("Diagnostic skipped. Standard lecture curriculum scheduled.", 'info');
                }}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'interest_settings':
      case 'interest_profile':
      case 'student_interests':
      case 'personalized_examples':
        setModal({
          title: 'Personalized Interest Profile',
          content: (
            <div className="max-h-[85vh] overflow-y-auto p-2">
              <InterestSettings
                studentId={user.name || 'student_default'}
                onClose={() => setModal(null)}
                onSaved={(profile) => {
                  showNotification?.(`Interests updated! Examples personalized to ${profile.interests.map(i => i.category).join(', ')}.`, 'success');
                }}
              />
            </div>
          ),
          size: 'large'
        });
        break;
      case 'peer_explanation':
      case 'peer_review':
      case 'explain_back':
      case 'study_room':
      case 'debate_mode':
      case 'social_learning':
        setModal({
          title: 'Peer Explanation & Social Learning Suite',
          content: (
            <div className="max-h-[88vh] overflow-y-auto p-1">
              <PeerExplanationHub
                currentStudentId={user.name ? `student_${user.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}` : 'student_user'}
                currentStudentName={user.name || 'Alex'}
                initialTopic={user.topic || "Faraday's Law of Electromagnetic Induction"}
                onClose={() => setModal(null)}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'adaptive_learning_path':
      case 'adaptive_path':
      case 'curriculum_builder':
        setModal({
          title: 'AI-Powered Personalised Learning Path & Adaptive Curriculum',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <AdaptiveLearningPath 
                theme={theme}
                subject={user.subject}
                topic={user.topic}
                difficulty={user.difficulty}
                userName={user.name || 'Student'}
                showNotification={showNotification}
                onStartLesson={(lessonTitle) => {
                  setUser(prev => ({ ...prev, lesson: lessonTitle }));
                  setModal(null);
                  handleSendMessage(`Let's start studying ${lessonTitle} as recommended by my personalised curriculum!`);
                }}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'two_way_voice_dialogue':
      case 'voice_dialogue':
      case 'conversational_voice':
        setModal({
          title: 'Two-Way Voice Dialogue & Conversational Learning',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <TwoWayVoiceDialogue
                theme={theme}
                subject={user.subject}
                topic={user.topic}
                userName={user.name || 'Student'}
                showNotification={showNotification}
                onSendMessageToChat={(transcript) => {
                  handleSendMessage(transcript);
                }}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'multilingual_translation':
      case 'translation_hub':
        setModal({
          title: 'Multilingual & Real-Time Classroom Translation (20+ Languages)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <MultilingualTranslationHub
                theme={theme}
                currentLanguageCode={user.language}
                subject={user.subject}
                topic={user.topic}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'auto_note_generator':
      case 'auto_notes':
      case 'cornell_notes':
        setModal({
          title: 'Automated Cornell Note-Taking & Summarisation',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <AutoNoteGenerator
                theme={theme}
                subject={user.subject}
                topic={user.topic}
                showNotification={showNotification}
                onSaveToNotes={() => {
                  showNotification('Cornell notes saved to your study portfolio!', 'success');
                }}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'gamification_rpg':
      case 'quest_adventure':
        setModal({
          title: 'Gamification & RPG Quest Learning Engine',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <QuestAdventure theme={theme} />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'exam_simulator_hub':
      case 'exam_simulator':
      case 'full_exam_simulator':
      case 'mock_exam':
        setModal({
          title: 'Official Full Exam Simulator (CBSE / CISCE / JEE / NEET / SAT / CUET)',
          content: (
            <div className="h-[84vh] -mx-6 -my-4 p-1 overflow-y-auto">
              <React.Suspense fallback={<div className="p-8 text-center"><div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>Loading Full Exam Simulator...</div>}>
                <ExamSession
                  initialSubject={user.subject}
                  isDark={theme === 'dark'}
                  studentId={user.name ? `student_${user.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}` : 'student_alex'}
                  onClose={() => setModal(null)}
                  onRewardXp={(xpReward) => {
                    setUser(prev => ({ ...prev, xp: prev.xp + xpReward }));
                    showNotification?.(`Exam submitted! You earned +${xpReward} XP!`, 'success');
                  }}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'time_coach':
      case 'time_management':
      case 'speed_run':
      case 'skip_drill':
      case 'exam_pacing':
        setModal({
          title: 'Exam Time Management & Speed Coach',
          content: (
            <div className="h-[84vh] -mx-6 -my-4 p-1 overflow-y-auto">
              <React.Suspense fallback={<div className="p-8 text-center"><div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>Loading Time Management Coach...</div>}>
                <TimeCoachHub
                  theme={theme}
                  studentId={user.name ? `student_${user.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}` : 'student_alex'}
                  initialSubject={user.subject}
                  showNotification={showNotification}
                  onRewardXp={(xpReward) => {
                    setUser(prev => ({ ...prev, xp: prev.xp + xpReward }));
                  }}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'pyq_intelligence':
      case 'pyq_analysis':
      case 'past_papers':
      case 'weightage_heatmap':
        setModal({
          title: '15+ Years PYQ Intelligence & Weightage Engine',
          content: (
            <div className="h-[84vh] -mx-6 -my-4 p-1 overflow-y-auto">
              <React.Suspense fallback={<div className="p-8 text-center"><div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>Loading PYQ Intelligence...</div>}>
                <PyqIntelligenceHub
                  theme={theme}
                  studentId={user.name ? `student_${user.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}` : 'student_alex'}
                  initialSubject={user.subject}
                  showNotification={showNotification}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'mistake_journal':
      case 'error_log':
      case 'remediation':
      case 'error_taxonomy':
        setModal({
          title: 'AI Mistake Journal & Cognitive Error Taxonomy',
          content: (
            <div className="h-[84vh] -mx-6 -my-4 p-1 overflow-y-auto">
              <React.Suspense fallback={<div className="p-8 text-center"><div className="w-8 h-8 border-2 border-rose-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>Loading Mistake Journal...</div>}>
                <MistakeJournalHub
                  theme={theme}
                  studentId={user.name ? `student_${user.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}` : 'student_alex'}
                  showNotification={showNotification}
                  onRewardXp={(xpReward) => {
                    setUser(prev => ({ ...prev, xp: prev.xp + xpReward }));
                  }}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'ar_3d_visualizer':
      case 'ar_visualizer':
      case '3d_models':
        setModal({
          title: 'Interactive 3D & Augmented Reality Visualisations (Spatial WebXR)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <Ar3dVisualizerHub
                theme={theme}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'offline_mode_manager':
      case 'offline_mode':
        setModal({
          title: 'Offline Mode & Low-Bandwidth Suite (IndexedDB Pack Downloader)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <OfflineModeManager
                theme={theme}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'wellbeing_coach':
      case 'wellbeing_support':
      case 'mindful_study':
        setModal({
          title: 'Emotional & Well-Being Support (Mindful Learning & Stress Relief)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <WellBeingCoach
                theme={theme}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'platform_integrator':
      case 'lms_integrator':
      case 'anki_export':
        setModal({
          title: 'Educational Platform Integrator (Google Classroom, Canvas, Anki)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <PlatformIntegrator
                theme={theme}
                subject={user.subject}
                topic={user.topic}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'accessibility_suite':
      case 'accessibility':
        setModal({
          title: 'Accessibility & Universal Design (Dyslexia Font & WCAG AAA)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <AccessibilitySuite
                theme={theme}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'career_pathways_hub':
      case 'career_pathways':
      case 'learn_to_earn':
        setModal({
          title: 'Career & Skill-Based Learning Pathways (Learn-to-Earn)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <React.Suspense fallback={<div className="h-full flex items-center justify-center font-bold text-slate-400">Loading Career Guidance...</div>}>
                <CareerOrchestrationHub theme={theme} />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'spaced_repetition':
      case 'srs_flashcards':
        setModal({
          title: 'Adaptive Spaced Repetition (SuperMemo SM-2 Engine)',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <SpacedRepetition 
                theme={theme} 
                subject={user.subject} 
                topic={user.topic}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'predictive_analytics':
      case 'learning_analytics':
      case 'cognitive_insights':
        setModal({
          title: 'AI Learning Analytics & Cognitive Insights',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1">
              <PredictiveAnalytics theme={theme} />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'executive_summary':
      case 'study_executive_summary':
      case 'executive_study_brief':
      case 'study_materials':
        setModal({
          title: 'Executive Study Summary & Multimodal Study Materials',
          content: (
            <div className="h-[82vh] -mx-6 -my-4 p-1">
              <MultimodalStudyMaterials
                theme={theme}
                subject={user.subject}
                topic={user.topic}
                initialTab={(toolId === 'executive_summary' || toolId === 'study_executive_summary' || toolId === 'executive_study_brief') ? 'summary' : (options?.tab || 'summary')}
                onClose={() => setModal(null)}
                onSaveToNotes={handleSaveToNotes}
                showNotification={showNotification}
              />
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'api_info':
        setModal({
          title: 'Omni AI API Integration Status',
          content: <GeminiStatus theme={theme} showNotification={showNotification} />,
          size: 'large'
        });
        break;
      case 'device_tier':
      case 'lite_mode':
      case 'low_end_device':
        setModal({
          title: 'Low-End Device Mode & Performance Optimizer',
          content: (
            <div className="h-[80vh] -mx-6 -my-4 p-1 overflow-y-auto">
              <React.Suspense fallback={<div className="p-8 text-center"><div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>Loading Device Optimizer...</div>}>
                <DeviceSettingsUI
                  isDark={theme === 'dark'}
                  showNotification={showNotification}
                />
              </React.Suspense>
            </div>
          ),
          size: 'xl'
        });
        break;
      case 'settings':
        setModal({
          id: 'settings',
          title: 'System Settings & AI Preferences',
          content: null,
          size: 'default'
        });
        break;
      case 'chat_sidebar':
      case 'open_chat_sidebar':
        window.dispatchEvent(new CustomEvent('open_ai_tutor_chat'));
        break;
      case 'boards':
        setIsBoardsExplorerOpen(true);
        break;
      default:
        console.warn(`Tool ${toolId} not implemented`);
        showNotification(`Tool ${toolId} not implemented yet`, 'warning');
    }
  };

  const handleSelectBoard = (board: EducationBoard) => {
    const initialCurriculum = getBoardCurriculum(board.nation, board.acronym);
    const defaultLevel = initialCurriculum.levels[0] || 'high';
    
    const curriculum = getBoardCurriculum(board.nation, board.acronym, defaultLevel);
    const defaultSubject = curriculum.subjects[0] || 'mathematics';
    const defaultTopic = curriculum.topics[defaultSubject]?.[0] || 'general';

    setUser(prev => ({
      ...prev,
      difficulty: defaultLevel,
      subject: defaultSubject,
      topic: defaultTopic,
      selectedBoard: {
        nation: board.nation,
        acronym: board.acronym
      }
    }));

    showNotification(`${board.nation} - ${board.acronym} Board active! Level and syllabus loaded dynamically.`, 'success');
  };

  return (
    <div className={cn(
      "min-h-screen min-h-dvh h-screen h-dvh w-full font-sans selection:bg-indigo-100 selection:text-indigo-900 overflow-hidden transition-colors duration-300",
      theme === 'dark' ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      <Sidebar 
        expanded={sidebarExpanded} 
        setExpanded={setSidebarExpanded}
        difficulty={user.difficulty}
        setDifficulty={(d) => {
          setUser(prev => {
            let nextSubject = prev.subject;
            let nextTopic = prev.topic;
            if (prev.selectedBoard) {
              const curr = getBoardCurriculum(prev.selectedBoard.nation, prev.selectedBoard.acronym, d);
              if (!curr.subjects.includes(prev.subject)) {
                nextSubject = curr.subjects[0] || 'mathematics';
                nextTopic = curr.topics[nextSubject]?.[0] || 'general';
              } else {
                const allowedTopics = curr.topics[prev.subject] || [];
                if (!allowedTopics.includes(prev.topic)) {
                  nextTopic = allowedTopics[0] || 'general';
                }
              }
            }
            return {
              ...prev,
              difficulty: d,
              subject: nextSubject,
              topic: nextTopic
            };
          });
        }}
        subject={user.subject}
        setSubject={(s) => {
          let firstTopic = 'general';
          if (mode === 'entrance') {
            firstTopic = (CONFIG.ENTRANCE_EXAMS_DATA as any)[selectedEntranceExam]?.topics?.[s]?.[0] || 'general';
          } else if (user.selectedBoard) {
            const curr = getBoardCurriculum(user.selectedBoard.nation, user.selectedBoard.acronym, user.difficulty);
            firstTopic = curr.topics[s]?.[0] || 'general';
          } else {
            firstTopic = CONFIG.TOPICS[s]?.[0] || 'general';
          }
          setUser(prev => ({ ...prev, subject: s, topic: firstTopic, lesson: '1' }));
        }}
        topic={user.topic}
        setTopic={(t) => setUser(prev => ({ ...prev, topic: t }))}
        lesson={user.lesson}
        setLesson={(l) => setUser(prev => ({ ...prev, lesson: l }))}
        tutor={user.tutor}
        setTutor={(t) => setUser(prev => ({ ...prev, tutor: t }))}
        xp={user.xp}
        level={user.level}
        streak={user.streak}
        theme={theme}
        onOpenTool={handleOpenTool}
        selectedBoard={user.selectedBoard}
        onSelectBoard={handleSelectBoard}
        selectedPersonaId={selectedPersonaId}
        onSelectPersonaId={(id) => {
          setSelectedPersonaId(id);
          localStorage.setItem('omni_selected_persona', id);
        }}
        mode={mode}
        selectedSkillId={selectedSkillId}
        onSelectSkillId={(id) => {
          setSelectedSkillId(id);
          localStorage.setItem('omni_selected_skill_id', id);
        }}
        selectedEntranceExam={selectedEntranceExam}
        setSelectedEntranceExam={setSelectedEntranceExam}
        isLectureMode={isLectureMode}
        setIsLectureMode={setIsLectureMode}
        lectureSubMode={lectureSubMode}
        setLectureSubMode={setLectureSubMode}
        showNotification={showNotification}
        bookmarkedLessons={user.bookmarkedLessons}
        onToggleBookmark={handleToggleBookmark}
      />

      {/* Backdrop for mobile overlays */}
      {sidebarExpanded && (
        <div 
          onClick={() => setSidebarExpanded(false)} 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[990] md:hidden cursor-pointer"
        />
      )}

      <div 
        className={cn(
          "mobile-viewport-grid flex flex-col h-full min-h-screen h-dvh transition-all duration-300 relative w-full pb-16 md:pb-0",
          sidebarExpanded ? "md:pl-[280px] pl-0" : "pl-0"
        )}
        style={{
          zoom: zoomLevel,
          width: `${contentWidth}%`,
          margin: '0 auto',
        }}
      >
        <div className="mobile-header-zone w-full max-w-full min-w-0 overflow-hidden">
          <TopNav 
            onToggleSidebar={() => setSidebarExpanded(!sidebarExpanded)}
            mode={mode}
            setMode={setMode}
            onClearChat={handleClearChat}
            onSelectTopic={(t) => setUser(prev => ({ ...prev, topic: t }))}
            onSelectLanguage={handleSelectLanguage}
            onOpenTool={handleOpenTool}
            onToggleTheme={setThemeMode}
            language={user.language}
            theme={theme}
            themeMode={themeMode}
            isThinking={isThinking}
            setIsThinking={setIsThinking}
            isTTSEnabled={isTTSEnabled}
            setIsTTSEnabled={setIsTTSEnabled}
            isLowLatency={isLowLatency}
            setIsLowLatency={setIsLowLatency}
            isShared={isShared}
            isPreviewEnv={isPreviewEnv}
            expiresAt={expiresTime}
            activeViewersCount={activeViewersCount}
            firebaseUser={firebaseUser}
            showNotification={showNotification}
            showDashboard={showDashboard}
            onToggleDashboard={() => setShowDashboard(prev => !prev)}
            onStartTour={() => setShowOnboardingTour(true)}
            onManualSync={handleManualSync}
          />
        </div>

        <main className="mobile-main-zone flex-1 overflow-hidden flex flex-col">
          {showDashboard ? (
            <div className="flex-1 overflow-y-auto">
              <Dashboard
                theme={theme}
                user={user}
                onClose={() => setShowDashboard(false)}
                onOpenTool={(id) => {
                  setShowDashboard(false);
                  handleOpenTool(id);
                }}
                onSelectTopic={(t) => {
                  setUser(prev => ({ ...prev, topic: t }));
                  setShowDashboard(false);
                }}
                showNotification={showNotification}
              />
            </div>
          ) : mode === 'learn' || mode === 'diagram' || mode === 'earn' || mode === 'entrance' || mode === 'competitive' ? (
            <div className="flex-1 flex flex-row min-h-0 relative overflow-hidden">
              <div className="flex-1 flex flex-col min-h-0 relative overflow-hidden">
                {mode === 'diagram' && (
                  <div className={cn(
                    "flex items-center justify-between px-6 py-2.5 border-b text-xs font-semibold shrink-0 animate-in slide-in-from-top duration-300",
                    theme === 'dark' 
                      ? "bg-amber-500/10 border-amber-500/20 text-amber-300" 
                      : "bg-amber-50 border-amber-200 text-amber-900"
                  )}>
                    <div className="flex items-center gap-2">
                      <Maximize2 size={16} className="text-amber-500" />
                      <span>
                        <strong>🎨 Diagram Tutor Play Mode Active:</strong> Teaching & studying strictly through interactive visual diagrams, 2D vector schematics, and hotspot maps.
                      </span>
                    </div>
                    <button
                      onClick={() => handleOpenTool('diagram_analyzer')}
                      className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase tracking-wider px-3 py-1 rounded-lg transition-all active:scale-95 cursor-pointer shadow-sm"
                    >
                      <Sparkles size={12} />
                      <span>Diagram Vision AI</span>
                    </button>
                  </div>
                )}
                {(mode === 'learn' || mode === 'entrance' || mode === 'competitive') && !showSyllabusSidebar && (
                  <div className={cn(
                    "flex items-center justify-between px-6 py-2.5 border-b text-xs font-semibold animate-in slide-in-from-top duration-300 shrink-0",
                    theme === 'dark' 
                      ? "bg-indigo-950/20 border-indigo-900/30 text-indigo-300" 
                      : "bg-indigo-50 border-indigo-100 text-indigo-900"
                  )}>
                    <div className="flex items-center gap-2">
                      {mode === 'learn' ? (
                        <BookOpen className="text-emerald-500" size={14} />
                      ) : (
                        <GraduationCap className="text-indigo-500" size={14} />
                      )}
                      <span>{mode === 'learn' ? 'Syllabus & Lesson Explorer panel is closed.' : 'Syllabus Companion & Quizzes panel is closed.'}</span>
                    </div>
                    <button
                      onClick={() => setShowSyllabusSidebar(true)}
                      className={cn(
                        "flex items-center gap-1.5 text-white font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-lg transition-all active:scale-95 cursor-pointer shadow-sm",
                        mode === 'learn' ? "bg-emerald-600 hover:bg-emerald-500" : "bg-indigo-600 hover:bg-indigo-500"
                      )}
                    >
                      <BookOpen size={12} />
                      <span>Open Syllabus</span>
                    </button>
                  </div>
                )}
                {mode === 'earn' && (() => {
                  const nationSkills = getSkillsForNation(user.selectedBoard?.nation || 'India');
                  const activeSkill = nationSkills.find(sk => sk.id === selectedSkillId) || nationSkills[0] || DEFAULT_SKILLS[0];
                  return (
                    <div className={cn(
                      "flex flex-col md:flex-row items-center justify-between gap-4 px-6 py-4 border-b shrink-0 transition-all duration-300",
                      theme === 'dark' 
                        ? "bg-slate-900/60 border-slate-800" 
                        : "bg-amber-500/[0.04] border-amber-500/10"
                    )}>
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <div className="w-11 h-11 bg-amber-500/10 text-amber-500 rounded-2xl flex items-center justify-center ring-4 ring-amber-500/5 shadow-inner">
                            <Coins size={22} className="animate-pulse" />
                          </div>
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center">
                            <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping" />
                          </div>
                        </div>
                        <div className="text-left">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest">
                              {activeSkill.category}
                            </span>
                            <span className="text-[9px] bg-amber-500/10 text-amber-600 dark:text-amber-400 px-1.5 py-0.5 rounded-md font-bold uppercase">
                              {activeSkill.type}
                            </span>
                          </div>
                          <h2 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 mt-0.5">
                            {activeSkill.name}
                          </h2>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "px-3.5 py-1.5 rounded-xl border flex flex-col items-center justify-center min-w-[110px] transition-all duration-300 hover:scale-102",
                          theme === 'dark' ? "bg-slate-800/50 border-slate-700/80" : "bg-white border-slate-200/80 shadow-sm"
                        )}>
                          <span className="text-[8px] uppercase tracking-wider text-slate-500 font-bold">Earning Rate</span>
                          <span className="text-sm font-black text-amber-500 mt-0.5">
                            {activeSkill.earningRates[user.difficulty] || '$25/hr'}
                          </span>
                        </div>
                        <div className={cn(
                          "px-3.5 py-1.5 rounded-xl border flex flex-col items-center justify-center min-w-[110px] transition-all duration-300 hover:scale-102",
                          theme === 'dark' ? "bg-slate-800/50 border-slate-700/80" : "bg-white border-slate-200/80 shadow-sm"
                        )}>
                          <span className="text-[8px] uppercase tracking-wider text-slate-500 font-bold">Experience Level</span>
                          <span className="text-[10px] font-black text-emerald-500 mt-0.5 uppercase">
                            {user.difficulty}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })()}
                <AnimatePresence>
                  {showStudyGapBanner && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ type: "spring", stiffness: 300, damping: 25 }}
                      className="overflow-hidden shrink-0"
                    >
                      <div className={cn(
                        "px-6 py-3.5 border-b flex items-center justify-between gap-4 text-xs font-medium relative",
                        theme === 'dark' 
                          ? "bg-slate-900 border-indigo-500/20 text-indigo-200" 
                          : "bg-indigo-50/70 border-indigo-100 text-indigo-900"
                      )}>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center shrink-0 animate-bounce">
                            <BookOpen size={16} />
                          </div>
                          <div>
                            <span className="font-bold block text-[13px] tracking-tight">Welcome back! Ready to continue?</span>
                            <span className="text-slate-500 dark:text-slate-400 text-[11px] block mt-0.5">
                              It's been over 24 hours since your last practice session. Let's start a quick study session!
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => {
                              const activeSubject = user.subject.charAt(0).toUpperCase() + user.subject.slice(1);
                              const activeTopic = user.topic.charAt(0).toUpperCase() + user.topic.slice(1);
                              handleSendMessage(`I'm ready for a quick review on my current subject: ${activeSubject} - ${activeTopic}. Please suggest 3 quick recall questions to test my memory.`);
                              setShowStudyGapBanner(false);
                            }}
                            className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[10px] uppercase tracking-wider transition active:scale-95 cursor-pointer shadow-sm shadow-indigo-600/10"
                          >
                            Resume Session
                          </button>
                          <button
                            onClick={() => setShowStudyGapBanner(false)}
                            className={cn(
                              "p-1.5 rounded-lg transition active:scale-95 cursor-pointer",
                              theme === 'dark' ? "hover:bg-slate-800 text-slate-400 hover:text-white" : "hover:bg-indigo-100 text-indigo-900"
                            )}
                          >
                            <X size={14} />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                <Chat 
                  messages={messages}
                  zoomLevel={zoomLevel}
                  setZoomLevel={setZoomLevel}
                  contentWidth={contentWidth}
                  setContentWidth={setContentWidth}
                  onSendMessage={handleSendMessage}
                  onClearChat={handleClearChat}
                  isTyping={isTyping}
                  onFileUpload={handleFileUpload}
                  onToggleVoice={handleToggleVoice}
                  onGenerateMedia={(type, prompt, options) => { handleGenerateMedia(prompt, type, options); }}
                  isRecording={isRecording}
                  theme={theme}
                  language={user.language}
                  onSelectLanguage={handleSelectLanguage}
                  onGenerateRecap={handleGenerateRecap}
                  onGenerateVideo={handleGenerateVideoFromChat}
                  onOpenTool={handleOpenTool}
                  isShared={isShared}
                  selectedPersonaId={selectedPersonaId}
                  mode={mode}
                  voiceSensitivity={voiceSensitivity}
                  onSelectPersonaId={(id) => {
                    setSelectedPersonaId(id);
                    localStorage.setItem('omni_selected_persona', id);
                  }}
                  showNotification={showNotification}
                  typingPace={typingPace}
                  blackboardWritingSpeed={blackboardWritingSpeed}
                  ttsRate={ttsRate}
                  linkSpeeds={linkSpeeds}
                  setTtsRate={setTtsRate}
                  setTypingPace={setTypingPace}
                  setBlackboardWritingSpeed={setBlackboardWritingSpeed}
                  setLinkSpeeds={setLinkSpeeds}
                  isGeneratingVideo={isGeneratingVideo}
                  videoGenerationTime={videoGenerationTime}
                  subject={user.subject}
                  topic={user.topic}
                  onSaveToNotes={handleSaveToNotes}
                  onDeleteMessage={handleDeleteMessage}
                  isLectureMode={isLectureMode}
                  setIsLectureMode={setIsLectureMode}
                  lectureSubMode={lectureSubMode}
                  setLectureSubMode={setLectureSubMode}
                  tutorPersonaConfig={tutorPersonaConfig}
                  onUpdateTutorPersonaConfig={setTutorPersonaConfig}
                  pronunciationPrecision={pronunciationPrecision}
                  onAwardXp={handleAwardXp}
                  accessibilityTextSize={accessibilityTextSize}
                  accessibilityLineSpacing={accessibilityLineSpacing}
                  accessibilityContrast={accessibilityContrast}
                  isClassroomMute={isClassroomMute}
                  setIsClassroomMute={setIsClassroomMute}
                  isDiagramRendering={isDiagramRendering}
                  setIsDiagramRendering={setIsDiagramRendering}
                  canvasUiManager={canvasUiManager}
                />
              </div>

              {/* Right Side: Standard Tutor / Entrance Exam / Competitive docked ChaptersExplorer Panel */}
              {(mode === 'learn' || mode === 'entrance' || mode === 'competitive') && showSyllabusSidebar && (
                <div className={cn(
                  "hidden xl:flex w-[460px] shrink-0 h-full border-l flex-col overflow-hidden animate-in slide-in-from-right duration-300",
                  theme === 'dark' ? "border-slate-800 bg-slate-900" : "border-slate-200 bg-white"
                )}>
                  <div className={cn(
                    "px-4 py-3 border-b flex items-center justify-between shrink-0",
                    theme === 'dark' ? "border-slate-800 bg-slate-950/40" : "border-slate-200 bg-slate-50/50"
                  )}>
                    <div className="flex items-center gap-2">
                      {mode === 'learn' ? (
                        <BookOpen className="text-emerald-500" size={18} />
                      ) : mode === 'entrance' ? (
                        <GraduationCap className="text-indigo-500" size={18} />
                      ) : (
                        <Zap className="text-amber-500 animate-pulse" size={18} />
                      )}
                      <span className="font-black text-[11px] uppercase tracking-wider text-slate-700 dark:text-slate-300">
                        {mode === 'learn' ? 'Syllabus & Lesson Explorer (Standard Tutor)' : mode === 'entrance' ? 'Exam Companion & Syllabus' : 'Jobs Exams Arena & Trainer'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] bg-indigo-500/10 text-indigo-500 dark:text-indigo-400 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
                        Docked
                      </span>
                      <button 
                        onClick={() => {
                          const url = new URL(getSyncShareUrl());
                          url.searchParams.set('topic', user.topic);
                          navigator.clipboard.writeText(url.toString());
                          showNotification('Deep link copied to clipboard!', 'success');
                        }}
                        className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                        title="Share Syllabus Topic"
                      >
                        <Share2 size={15} />
                      </button>
                      <button
                        onClick={() => setIsRecording(!isRecording)}
                        className={`p-1 rounded-lg transition-colors cursor-pointer ${isRecording ? 'bg-red-500/20 text-red-500' : 'hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                        title={isRecording ? "Stop Recording" : "Start Recording"}
                      >
                        <Mic size={15} />
                      </button>
                      <button 
                        onClick={() => setShowSyllabusSidebar(false)}
                        className="p-1 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                        title="Close Syllabus Companion"
                      >
                        <X size={15} />
                      </button>
                    </div>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <ChaptersExplorer
                      theme={theme}
                      subject={user.subject}
                      topic={user.topic}
                      difficulty={user.difficulty}
                      setTopic={(newTopic) => {
                        setUser(prev => ({ ...prev, topic: newTopic }));
                        const promptMsg = `I want to study the lesson "${newTopic}" of Chapter "${user.subject || 'Syllabus'}" to a degree of ${user.difficulty ? user.difficulty.toUpperCase() : 'STANDARD'} depth/rigor.\n\nTutor Rigor Instructions:\nProvide a standard, granular, step-by-step academic explanation. Explain definitions, list equations, detail a complete concrete worked-out example with intermediate steps, and test me on the content with 2 standard practice questions.\n\nPlease proceed to teach the lesson now with high quality and formatting.`;
                        handleSendMessage(promptMsg);
                        showNotification(`Selected topic: ${newTopic}`, 'info');
                      }}
                      selectedBoard={user.selectedBoard}
                      mode={mode}
                      selectedEntranceExam={selectedEntranceExam}
                      onStudyLesson={(lessonTitle, chapterTitle, depth) => {
                        let depthDescriptor = "";
                        if (depth === 'quick') {
                          depthDescriptor = "Provide a QUICK, high-level summarized review block. Keep explanations exceptionally crisp, focus purely on foundational definitions and direct equations, and set up a quick 1-question interactive speed-quiz right away.";
                        } else if (depth === 'deep') {
                          depthDescriptor = "Provide a DEEP, highly rigorous academic dissertation/study. Dive into formal mathematical/physical proofs, derivations, underlying mechanistic logic, historical discoveries and boundaries, edge cases, and test me with a comprehensive, multi-step honors-tier conceptual challenge.";
                        } else if (depth === 'academic') {
                          depthDescriptor = "Provide an EXTREMELY advanced graduate research-grade session in the caliber of top global institutes like MIT, Cambridge (Mathematical Tripos), or IIT. Unpack complex theoretical proofs, multi-disciplinary modeling, potential open-ended academic questions/hypotheses, and provide 3 highly challenging multi-part analytical exam problems.";
                        } else {
                          depthDescriptor = "Provide a standard, granular, step-by-step academic explanation. Explain definitions, list equations, detail a complete concrete worked-out example with intermediate steps, and test me on the content with 2 standard practice questions.";
                        }

                        // Align topic and subject state across entire app and 3D virtual classroom
                        setUser(prev => ({
                          ...prev,
                          topic: lessonTitle,
                          subject: chapterTitle || prev.subject
                        }));

                        const promptMsg = `I want to study the lesson "${lessonTitle}" of Chapter "${chapterTitle}" to a degree of ${depth ? depth.toUpperCase() : 'STANDARD'} depth/rigor.\n\nTutor Rigor Instructions:\n${depthDescriptor}\n\nPlease proceed to teach the lesson now with high quality and formatting.`;
                        handleSendMessage(promptMsg);
                        showNotification(`Studying lesson: ${lessonTitle} (${depth ? depth.toUpperCase() : 'STANDARD'} depth)`, 'success');
                      }}
                      onGenerateQuiz={(chapterTitle) => {
                        setModal({
                          title: 'Quiz Generator',
                          content: (
                            <QuizGenerator 
                              userName={user.name} 
                              onGenerateMedia={handleGenerateMedia} 
                              initialSubject={user.subject}
                              initialTopic={chapterTitle}
                              initialDifficulty={user.difficulty}
                              initialLanguage={LANGUAGES.find(l => l.code === user.language)?.name || 'English'}
                              showNotification={showNotification}
                            />
                          ),
                          size: 'large'
                        });
                        showNotification(`Practice Quiz generated on ${chapterTitle}`, 'info');
                      }}
                      savedNotes={savedNotes}
                      onDeleteNote={(id) => {
                        setSavedNotes(prev => prev.filter(n => n.id !== id));
                        showNotification('Study note deleted', 'info');
                      }}
                      onReorderNotes={(newNotes) => {
                        setSavedNotes(newNotes);
                      }}
                      showNotification={showNotification}
                      onRewardXp={(xpReward) => {
                        setUser(prev => ({ ...prev, xp: prev.xp + xpReward }));
                      }}
                    />
                  </div>
                </div>
              )}
            </div>
          ) : mode === '3d_classroom' ? (
            <div className="flex-1 overflow-hidden relative">
              <MobileOptimizedWrapper
                theme={theme}
                topic={user.topic}
                title="3D Virtual Classroom"
              >
                <ProfessorClarityErrorBoundary componentName="ThreeDClassroom">
                  <React.Suspense fallback={
                    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 text-white min-h-[500px]">
                      <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4" />
                      <div className="font-bold text-lg">Initializing Professor Clarity 3D Virtual Classroom...</div>
                    </div>
                  }>
                    <ThreeDClassroom
                      theme={theme}
                      userTopic={user.topic}
                      userSubject={user.subject}
                      selectedBoard={user.selectedBoard}
                      userName={user.name}
                      language={user.language}
                      onSelectLanguage={handleSelectLanguage}
                      showNotification={showNotification}
                      onSelectTopic={handleSelectTopicFromClassroom}
                      onClose={handleCloseClassroom}
                      userDifficulty={user.difficulty}
                      onSelectDifficulty={(diff) => setUser(prev => ({ ...prev, difficulty: diff }))}
                      onSelectSubject={(subj) => setUser(prev => ({ ...prev, subject: subj }))}
                      onSelectBoard={(board) => setUser(prev => ({ ...prev, selectedBoard: board }))}
                      personaConfig={tutorPersonaConfig}
                      onUpdatePersonaConfig={setTutorPersonaConfig}
                      activePrompt={latestUserPrompt}
                      initialContent={studyContentFor3D}
                      quadSpeeds={quadSpeeds}
                      onUpdateQuadSpeeds={handleUpdateQuadSpeeds}
                    />
                  </React.Suspense>
                </ProfessorClarityErrorBoundary>
              </MobileOptimizedWrapper>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto">
              <VideoGrid 
                topic={user.topic}
                subject={user.subject}
                difficulty={user.difficulty}
                region="All"
                onPlay={handlePlayVideo}
                onGenerateVideo={(prompt) => handleGenerateMedia(prompt, 'video')}
                externalGeneratedVideos={generatedVideos}
                onUpdateVideos={setGeneratedVideos}
              />
            </div>
          )}
        </main>

        {/* Mobile Dedicated Bottom Navigation Bar */}
        <footer className="mobile-footer-zone w-full">
          <MobileBottomNav
            mode={mode}
            setMode={setMode}
            showDashboard={showDashboard}
            onToggleDashboard={() => setShowDashboard(prev => !prev)}
            onOpenTool={handleOpenTool}
            theme={theme}
            onToggleSidebar={() => setSidebarExpanded(prev => !prev)}
          />
        </footer>
      </div>

      {/* Notifications */}
      <div className="fixed top-5 right-5 z-[2000] flex flex-col gap-2 pointer-events-none">
        <AnimatePresence>
          {notifications.map(n => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 100 }}
              className={cn(
                "p-4 rounded-xl shadow-lg flex items-center gap-3 min-w-[300px] pointer-events-auto",
                n.type === 'success' && "bg-green-50 border border-green-200 text-green-800",
                n.type === 'error' && "bg-red-50 border border-red-200 text-red-800",
                n.type === 'warning' && "bg-amber-50 border border-amber-200 text-amber-800",
                n.type === 'info' && "bg-blue-50 border border-blue-200 text-blue-800",
                theme === 'dark' && "bg-slate-800 border-slate-700 text-slate-100"
              )}
            >
              <div className="flex-shrink-0">
                {n.type === 'success' && <CheckCircle2 size={20} />}
                {n.type === 'error' && <AlertCircle size={20} />}
                {n.type === 'warning' && <AlertCircle size={20} />}
                {n.type === 'info' && <Info size={20} />}
              </div>
              <div className="flex-1 text-sm font-medium">{n.message}</div>
              <button 
                onClick={() => setNotifications(prev => prev.filter(notif => notif.id !== n.id))}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={16} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {modal && (
          <div className="fixed inset-0 z-[3000] flex items-center justify-center p-4 overflow-auto">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setModal(null)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.92, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className={cn(
                "relative rounded-2xl shadow-2xl overflow-hidden flex flex-col",
                modal.size === 'large' ? "w-[95vw] max-w-6xl h-[90vh]" : 
                modal.size === 'xl' ? "w-[98vw] h-[95vh]" : "w-full max-w-2xl",
                theme === 'dark' ? "bg-slate-900 text-white" : "bg-white text-slate-900"
              )}
            >
              <div className={cn(
                "p-6 border-b flex justify-between items-center flex-shrink-0",
                theme === 'dark' ? "border-slate-800" : "border-slate-200"
              )}>
                <h2 className="text-xl font-bold">{modal.title}</h2>
                <button onClick={() => setModal(null)} className={cn(
                  "p-2 rounded-full",
                  theme === 'dark' ? "hover:bg-slate-800" : "hover:bg-slate-100"
                )}>
                  <X size={20} />
                </button>
              </div>
              <div className={cn(
                "flex-1 overflow-y-auto",
                (modal.size === 'large' || modal.size === 'xl') ? "p-0" : "p-6"
              )}>
                {modal.id === 'settings' ? (
                  <SettingsModal
                    theme={theme}
                    themeMode={themeMode}
                    user={user}
                    setUser={setUser as any}
                    isThinking={isThinking}
                    setIsThinking={setIsThinking}
                    isTTSEnabled={isTTSEnabled}
                    setIsTTSEnabled={setIsTTSEnabled}
                    isLowLatency={isLowLatency}
                    setIsLowLatency={setIsLowLatency}
                    isProfessorMode={isProfessorMode}
                    setIsProfessorMode={setIsProfessorMode}
                    selectionColor={selectionColor}
                    setSelectionColor={setSelectionColor}
                    onToggleTheme={(mode) => {
                      setThemeMode(mode);
                      if (mode === 'high-contrast-green') {
                        setSelectionColor('high-contrast');
                      }
                    }}
                    showNotification={showNotification}
                    ttsRate={ttsRate}
                    setTtsRate={setTtsRate}
                    voiceSensitivity={voiceSensitivity}
                    setVoiceSensitivity={setVoiceSensitivity}
                    typingPace={typingPace}
                    setTypingPace={setTypingPace}
                    blackboardWritingSpeed={blackboardWritingSpeed}
                    setBlackboardWritingSpeed={setBlackboardWritingSpeed}
                    linkSpeeds={linkSpeeds}
                    setLinkSpeeds={setLinkSpeeds}
                    showAudioDiagnostics={showAudioDiagnostics}
                    setShowAudioDiagnostics={setShowAudioDiagnostics}
                    pronunciationPrecision={pronunciationPrecision}
                    setPronunciationPrecision={setPronunciationPrecision}
                    onClose={() => setModal(null)}
                    accessibilityTextSize={accessibilityTextSize}
                    setAccessibilityTextSize={setAccessibilityTextSize}
                    accessibilityLineSpacing={accessibilityLineSpacing}
                    setAccessibilityLineSpacing={setAccessibilityLineSpacing}
                    accessibilityContrast={accessibilityContrast}
                    setAccessibilityContrast={setAccessibilityContrast}
                    selectedPersonaId={selectedPersonaId}
                    onSelectPersonaId={(id) => {
                      setSelectedPersonaId(id);
                      localStorage.setItem('omni_selected_persona', id);
                    }}
                    silentDraw={silentDraw}
                    setSilentDraw={setSilentDraw}
                    onOpenQuadSpeedSync={() => {
                      setModal({
                        id: 'quad_speed_sync',
                        title: 'Quad-Speed Synchronization Hub',
                        content: null,
                        size: 'large'
                      });
                    }}
                  />
                ) : modal.id === 'quad_speed_sync' ? (
                  <div className="p-2 sm:p-4">
                    <QuadSpeedSyncModal
                      isOpen={true}
                      onClose={() => setModal(null)}
                      speeds={quadSpeeds}
                      onUpdateSpeeds={handleUpdateQuadSpeeds}
                    />
                  </div>
                ) : (
                  <React.Suspense fallback={
                    <div className="p-12 flex flex-col items-center justify-center text-slate-400 font-bold gap-3">
                      <div className="w-8 h-8 border-3 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                      <div>Loading component...</div>
                    </div>
                  }>
                    {modal.content}
                  </React.Suspense>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Specific Boards Explorer Modal */}
      <AnimatePresence>
        {isBoardsExplorerOpen && (
          <div className="fixed inset-0 z-[3000] flex items-center justify-center p-4 overflow-auto">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setIsBoardsExplorerOpen(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.92, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className={cn(
                "relative rounded-2xl shadow-2xl overflow-hidden flex flex-col w-[95vw] max-w-6xl h-[90vh]",
                theme === 'dark' ? "bg-slate-900 text-white" : "bg-white text-slate-900"
              )}
            >
              <div className={cn(
                "p-6 border-b flex justify-between items-center flex-shrink-0",
                theme === 'dark' ? "border-slate-800" : "border-slate-200"
              )}>
                <h2 className="text-xl font-bold">Nations Education Boards Explorer</h2>
                <button onClick={() => setIsBoardsExplorerOpen(false)} className={cn(
                  "p-2 rounded-full",
                  theme === 'dark' ? "hover:bg-slate-800" : "hover:bg-slate-100"
                )}>
                  <X size={20} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-0 animate-fadeIn">
                <BoardsExplorer 
                  theme={theme}
                  activatedBoardAcronym={user.selectedBoard?.acronym}
                  onSelectBoard={handleSelectBoard}
                  onAskTutor={(boardName, boardAcronym) => {
                    setIsBoardsExplorerOpen(false);
                    handleSendMessage(`I want to learn about the syllabus and curriculum structure of the ${boardName} (${boardAcronym}) board. Please provide a detailed overview of key subjects, exam patterns, study strategies, and tips for high scores!`);
                  }}
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Professor Clarity 16-Feature Master Pedagogical Suite Modal */}
      <MasterFeatureSuiteModal
        isOpen={isMasterFeatureSuiteOpen}
        onClose={() => setIsMasterFeatureSuiteOpen(false)}
        onLaunchFeature={(toolTarget) => handleOpenTool(toolTarget)}
        theme={theme}
      />

      {/* Universal Multi-Board Multi-Language AI Tutor Modal */}
      <React.Suspense fallback={null}>
        {isUniversalTutorOpen && (
          <UniversalAITutorModal
            isOpen={isUniversalTutorOpen}
            onClose={() => setIsUniversalTutorOpen(false)}
            initialSubject={user.subject as any}
            initialTopic={user.topic}
          />
        )}
      </React.Suspense>

      {/* Professor Clarity Self-Healing & System Observability Debugger Modal */}
      <ProfessorClarityDebuggerModal
        isOpen={showDebuggerModal}
        onClose={() => setShowDebuggerModal(false)}
        showNotification={showNotification}
      />

      {/* Firebase Auth & Shared Link Session Diagnostics Modal */}
      <AuthDiagnosticsModal
        isOpen={showAuthDiagnosticsModal}
        onClose={() => setShowAuthDiagnosticsModal(false)}
        firebaseUser={firebaseUser}
        theme={theme}
        showNotification={showNotification}
      />

      {/* Network & Offline Status for multi-device resilience */}
      <OfflineSyncBanner />

      {/* Interactive Onboarding Tour */}
      <InteractiveOnboardingTour
        isOpen={showOnboardingTour}
        onClose={() => setShowOnboardingTour(false)}
        theme={theme}
      />

      {/* Persistent AI Tutor Collapsible Sidebar */}
      <ChatSidebar
        currentSubject={user.subject}
        currentChapterTitle={user.topic}
        currentChapterId={user.lesson}
        language={user.language}
      />

      {/* Veo 3 AI Video Generations & Image Animator Modal */}
      <VeoVideoModal
        isOpen={isVeoVideoModalOpen}
        onClose={() => setIsVeoVideoModalOpen(false)}
        showNotification={showNotification}
      />

    </div>
  );
}
