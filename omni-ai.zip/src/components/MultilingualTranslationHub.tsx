import React, { useState } from 'react';
import { 
  Languages, Globe, Volume2, Sparkles, Copy, Download, RefreshCw, 
  ArrowRight, CheckCircle2, BookOpen, Layers, Sliders, ShieldCheck
} from 'lucide-react';
import { generateAIResponse, generateSpeech } from '../lib/gemini';
import { cn } from '../lib/utils';
import { SUPPORTED_LANGUAGES } from '../modules/i18n/i18nConfig';
import { useI18n } from '../modules/i18n/useI18n';
import { LanguageSelector } from '../modules/i18n/LanguageSelector';
import { CulturalAdaptation } from '../modules/i18n/CulturalAdaptation';
import { TranslationService } from '../modules/i18n/TranslationService';
import { SupportedLanguageCode } from '../modules/i18n/types';

interface TranslationPair {
  id: string;
  sourceText: string;
  translatedText: string;
  codeSwitchedText: string;
  culturalAnalogy: string;
  vocabulary: { term: string; translation: string; pronunciation: string }[];
}

interface Props {
  theme?: 'light' | 'dark';
  currentLanguageCode?: string;
  subject?: string;
  topic?: string;
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const MultilingualTranslationHub: React.FC<Props> = ({
  theme = 'light',
  currentLanguageCode = 'hi',
  subject = 'Physics',
  topic = "Newton's Second Law of Motion",
  showNotification
}) => {
  const { 
    language, 
    setLanguage, 
    bilingualMode, 
    toggleBilingualMode, 
    prefersRegionalExamples,
    dir,
    t
  } = useI18n();

  const [activeTab, setActiveTab] = useState<'translate' | 'languages' | 'cultural'>('translate');
  const [loading, setLoading] = useState(false);
  const [inputText, setInputText] = useState(
    "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass (F = ma)."
  );

  const [translationResult, setTranslationResult] = useState<TranslationPair>({
    id: 'tp-1',
    sourceText: "The acceleration of an object is directly proportional to the net force acting upon it and inversely proportional to its mass (F = ma).",
    translatedText: "किसी वस्तु का त्वरण (Acceleration) उस पर लगने वाले कुल बल (Force) के समानुपाती और उसके द्रव्यमान (Mass) के व्युत्क्रमानुपाती होता है (F = ma)।",
    codeSwitchedText: "Kisi object ka acceleration us par lagne wale net force ke directly proportional hota hai aur uske mass ke inversely proportional (F = ma).",
    culturalAnalogy: "जैसे एक हल्की साइकिल को तेज चलाना आसान है, लेकिन भारी ट्रक या बैलगाड़ी को धक्का देने के लिए बहुत ज्यादा बल लगाना पड़ता है।",
    vocabulary: [
      { term: "Acceleration", translation: "त्वरण", pronunciation: "Tvaran" },
      { term: "Force", translation: "बल", pronunciation: "Bal" },
      { term: "Mass", translation: "द्रव्यमान", pronunciation: "Dravyamaan" },
      { term: "Inversely Proportional", translation: "व्युत्क्रमानुपाती", pronunciation: "Vyutkramaanupati" }
    ]
  });

  const [activeVoiceLoading, setActiveVoiceLoading] = useState(false);

  const handleTranslate = async () => {
    if (!inputText.trim()) return;
    setLoading(true);
    showNotification?.("Translating with pedagogical nuance and cultural analogies...", "info");

    const targetLangObj = SUPPORTED_LANGUAGES[language] || SUPPORTED_LANGUAGES['hi'];

    try {
      const prompt = `You are Professor Clarity's Multilingual Educational Translation Engine.
Translate the following academic concept into ${targetLangObj.name} (${targetLangObj.nativeName}).
Strictly preserve mathematical formulas, symbols, and scientific notations (e.g. F = ma, E = mc^2) in standard Latin/universal notation while explaining concepts clearly.

Source Text: "${inputText}"
Subject: "${subject}"
Topic: "${topic}"

Provide a JSON output with:
{
  "sourceText": "${inputText}",
  "translatedText": "Formal, high-accuracy textbook academic translation in ${targetLangObj.name} with key technical terms in English in parentheses",
  "codeSwitchedText": "Natural colloquial conversational explanation blending everyday conversational terms with technical terminology (e.g. Hinglish, Tanglish, or friendly spoken dialect)",
  "culturalAnalogy": "A culturally relatable Indian daily-life analogy (e.g. cricket, dosa batter fermentation, festival lighting) that students immediately understand",
  "vocabulary": [
    { "term": "Key English Term 1", "translation": "Term in ${targetLangObj.name}", "pronunciation": "Phonetic romanized spelling" },
    { "term": "Key English Term 2", "translation": "Term in ${targetLangObj.name}", "pronunciation": "Phonetic romanized spelling" },
    { "term": "Key English Term 3", "translation": "Term in ${targetLangObj.name}", "pronunciation": "Phonetic romanized spelling" }
  ]
}
Return ONLY valid JSON with no markdown tags.`;

      const response = await generateAIResponse(prompt, { model: 'gemini-3.6-flash' });
      if (response) {
        const cleaned = response.replace(/```json/g, '').replace(/```/g, '').trim();
        const parsed: TranslationPair = JSON.parse(cleaned);
        parsed.id = `tp-${Date.now()}`;
        setTranslationResult(parsed);
        showNotification?.(`Translated to ${targetLangObj.name} successfully!`, "success");
      }
    } catch (e) {
      console.error(e);
      // Fallback to local pedagogical engine
      const lesson = TranslationService.getBilingualLesson('newtons_second_law', language);
      setTranslationResult({
        id: 'tp-fb-' + Date.now(),
        sourceText: lesson.conceptDefinitionEnglish,
        translatedText: lesson.conceptDefinitionRegional,
        codeSwitchedText: `${lesson.termRegional}: ${lesson.culturalAnalogy}`,
        culturalAnalogy: lesson.culturalAnalogy,
        vocabulary: [
          { term: "Force", translation: "बल", pronunciation: "Bal" },
          { term: "Mass", translation: "द्रव्यमान", pronunciation: "Dravyamaan" },
          { term: "Acceleration", translation: "त्वरण", pronunciation: "Tvaran" }
        ]
      });
      showNotification?.("Translation completed using cached linguistic models.", "info");
    } finally {
      setLoading(false);
    }
  };

  const handlePlayVoice = async (text: string) => {
    setActiveVoiceLoading(true);
    try {
      await TranslationService.speakText(text, language);
    } catch (e) {
      console.warn("Speech playback error:", e);
    } finally {
      setActiveVoiceLoading(false);
    }
  };

  const isDark = theme === 'dark';
  const currentLangObj = SUPPORTED_LANGUAGES[language] || SUPPORTED_LANGUAGES['en'];
  const culturalRules = CulturalAdaptation.getRules();

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )} dir={dir}>
      {/* Top Bar */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center text-white shadow-md">
            <Languages size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Multilingual Classroom & Cultural Localization</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                11 Regional Languages + RTL
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Side-by-side bilingual display &bull; Universal formula preservation &bull; Indian cultural analogies
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('translate')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
              activeTab === 'translate'
                ? "bg-cyan-600 text-white shadow"
                : isDark ? "bg-slate-800 text-slate-400 hover:text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            )}
          >
            <Sparkles size={13} /> Classroom Studio
          </button>

          <button
            onClick={() => setActiveTab('languages')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
              activeTab === 'languages'
                ? "bg-indigo-600 text-white shadow"
                : isDark ? "bg-slate-800 text-slate-400 hover:text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            )}
          >
            <Globe size={13} /> Language Settings
          </button>

          <button
            onClick={() => setActiveTab('cultural')}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer",
              activeTab === 'cultural'
                ? "bg-amber-500 text-slate-950 font-black shadow"
                : isDark ? "bg-slate-800 text-slate-400 hover:text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            )}
          >
            <BookOpen size={13} /> Cultural Rules
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {activeTab === 'translate' && (
          <>
            {/* Quick Language Switcher Banner */}
            <div className={cn(
              "p-4 rounded-xl border flex flex-wrap items-center justify-between gap-3",
              isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200"
            )}>
              <div className="flex items-center gap-2">
                <Globe size={16} className="text-cyan-400" />
                <span className="text-xs font-bold">Current Target Language:</span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {currentLangObj.flagEmoji} {currentLangObj.name} ({currentLangObj.nativeName})
                </span>
                {currentLangObj.dir === 'rtl' && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                    RTL Layout
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as SupportedLanguageCode)}
                  className={cn(
                    "px-3 py-1.5 rounded-lg border text-xs font-bold outline-none cursor-pointer",
                    isDark ? "bg-slate-800 border-slate-700 text-slate-100" : "bg-white border-slate-200 text-slate-800"
                  )}
                >
                  {Object.values(SUPPORTED_LANGUAGES).map((l) => (
                    <option key={l.code} value={l.code}>
                      {l.flagEmoji} {l.name} ({l.nativeName})
                    </option>
                  ))}
                </select>

                <button
                  onClick={handleTranslate}
                  disabled={loading}
                  className="px-4 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
                  {loading ? "Translating..." : "Translate Concept"}
                </button>
              </div>
            </div>

            {/* Source Input Area */}
            <div className={cn(
              "p-4 rounded-xl border space-y-2",
              isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200"
            )}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Source English Academic Text</span>
                <button
                  onClick={() => setInputText(`The gravitational force between two masses is directly proportional to the product of their masses and inversely proportional to the square of the distance between their centers (F = G * m1 * m2 / r^2).`)}
                  className="text-[11px] text-cyan-400 hover:underline font-semibold cursor-pointer"
                >
                  Load Gravitation Formula
                </button>
              </div>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                rows={2}
                className={cn(
                  "w-full p-3 rounded-lg border text-xs sm:text-sm outline-none font-medium leading-relaxed resize-none",
                  isDark ? "bg-slate-900 border-slate-750 text-slate-100" : "bg-slate-50 border-slate-200 text-slate-900"
                )}
                placeholder="Type or paste any scientific concept, law, or equation to translate..."
              />
            </div>

            {/* Side-by-Side Bilingual Display */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Column 1: Formal Regional Translation with Bilingual Terminology */}
              <div className={cn(
                "p-5 rounded-2xl border space-y-3 flex flex-col justify-between",
                isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200 shadow-sm"
              )}>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-blue-500/10 text-blue-400 border border-blue-500/20">
                      {currentLangObj.name} Academic Translation (Bilingual Terms)
                    </span>
                    <button
                      onClick={() => handlePlayVoice(translationResult.translatedText)}
                      disabled={activeVoiceLoading}
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
                      title="Listen in Native Accent"
                    >
                      <Volume2 size={15} />
                    </button>
                  </div>

                  <p className="text-sm sm:text-base font-semibold leading-relaxed pt-2">
                    {translationResult.translatedText}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
                  <span>Preserved Formula Notation: 100%</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(translationResult.translatedText);
                      showNotification?.("Copied to clipboard!", "success");
                    }}
                    className="hover:text-cyan-400 flex items-center gap-1 font-bold cursor-pointer"
                  >
                    <Copy size={12} /> Copy
                  </button>
                </div>
              </div>

              {/* Column 2: Code-Switched / Conversational Explanation */}
              <div className={cn(
                "p-5 rounded-2xl border space-y-3 flex flex-col justify-between",
                isDark ? "bg-slate-950/80 border-cyan-900/40" : "bg-cyan-50/40 border-cyan-200 shadow-sm"
              )}>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                      Conversational Pedagogical Code-Switching
                    </span>
                    <button
                      onClick={() => handlePlayVoice(translationResult.codeSwitchedText)}
                      disabled={activeVoiceLoading}
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
                      title="Listen Conversational Pronunciation"
                    >
                      <Volume2 size={15} />
                    </button>
                  </div>

                  <p className="text-sm sm:text-base font-medium leading-relaxed pt-2 text-cyan-200">
                    "{translationResult.codeSwitchedText}"
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
                  <span>Intuitive Classroom Cadence</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(translationResult.codeSwitchedText);
                      showNotification?.("Copied to clipboard!", "success");
                    }}
                    className="hover:text-cyan-400 flex items-center gap-1 font-bold cursor-pointer"
                  >
                    <Copy size={12} /> Copy
                  </button>
                </div>
              </div>
            </div>

            {/* Cultural Real-World Analogy Block */}
            <div className={cn(
              "p-4 rounded-xl border flex items-start gap-3.5",
              isDark ? "bg-amber-950/20 border-amber-800/40 text-amber-200" : "bg-amber-50 border-amber-200 text-amber-950"
            )}>
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
                <Sparkles size={18} />
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-black uppercase tracking-wider text-amber-400">
                  Regional Cultural Analogy (Connecting to Daily Life Intuition):
                </h4>
                <p className="text-xs sm:text-sm leading-relaxed">
                  {translationResult.culturalAnalogy}
                </p>
              </div>
            </div>

            {/* Key Bilingual Glossary & Pronunciation */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <BookOpen size={14} /> Bilingual Scientific Vocabulary Index
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {translationResult.vocabulary.map((v, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "p-3.5 rounded-xl border space-y-1",
                      isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200"
                    )}
                  >
                    <div className="text-xs font-bold text-slate-200">{v.term}</div>
                    <div className="text-sm font-black text-cyan-400">{v.translation}</div>
                    <div className="text-[11px] text-slate-400 font-mono italic">"{v.pronunciation}"</div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === 'languages' && (
          <LanguageSelector
            isDark={isDark}
            showNotification={showNotification}
          />
        )}

        {activeTab === 'cultural' && (
          <div className="space-y-6">
            <div className={cn(
              "p-4 rounded-2xl border flex items-center justify-between",
              isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
            )}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Sparkles size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-base">Cultural Adaptation Matrix</h3>
                  <p className="text-xs opacity-60">Automatic mapping of Western textbook scenarios to relatable Indian daily life contexts</p>
                </div>
              </div>
              <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                Active in All Lessons
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {culturalRules.map((rule, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "p-5 rounded-2xl border space-y-3",
                    isDark ? "bg-slate-950/60 border-slate-800" : "bg-white border-slate-200"
                  )}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px]">
                      Category: {rule.category}
                    </span>
                    <span className="text-amber-400 font-semibold text-[11px]">
                      {rule.explanation}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs opacity-70">
                      <span className="font-bold text-rose-400">Western Textbook Term: </span>
                      <span className="font-mono">{rule.westernTerm}</span>
                    </div>

                    <div className="text-xs opacity-90 p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="font-bold text-emerald-400 block mb-1">Adapted Regional Scenarios:</span>
                      <div className="grid grid-cols-2 gap-1 text-[11px]">
                        <div><strong className="text-cyan-300">Hindi: </strong>{rule.indianEquivalents.hi}</div>
                        <div><strong className="text-cyan-300">Tamil: </strong>{rule.indianEquivalents.ta}</div>
                        <div><strong className="text-cyan-300">Telugu: </strong>{rule.indianEquivalents.te}</div>
                        <div><strong className="text-cyan-300">Bengali: </strong>{rule.indianEquivalents.bn}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
