import React, { useState, useEffect, useRef } from 'react';
import { 
  ExplanationSubmission, 
  AIEvaluationBreakdown 
} from '../modules/social/types';
import { ExplainBackService } from '../modules/social/explainBack';
import { PeerReviewService, AnonymousReviewItem, BestExplanationItem } from '../modules/social/peerReview';
import { ModerationLayer, ModerationEngine } from './ModerationLayer';
import { 
  Users, 
  Sparkles, 
  Mic, 
  MicOff, 
  Send, 
  CheckCircle2, 
  Star, 
  Award, 
  BookOpen, 
  ThumbsUp, 
  MessageSquare, 
  Eye, 
  Lock, 
  RefreshCw,
  Trophy,
  ArrowRight
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface ExplainBackCardProps {
  conceptId?: string;
  conceptTitle?: string;
  studentId?: string;
  studentName?: string;
  onSubmissionSuccess?: (sub: ExplanationSubmission) => void;
  className?: string;
}

export const ExplainBackCard: React.FC<ExplainBackCardProps> = ({
  conceptId = 'faradays_law',
  conceptTitle = "Faraday's Law of Electromagnetic Induction",
  studentId = 'student_default',
  studentName = 'Alex',
  onSubmissionSuccess,
  className
}) => {
  const [activeTab, setActiveTab] = useState<'explain' | 'review' | 'best'>('explain');
  const [explanationInput, setExplanationInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [optInPeerReview, setOptInPeerReview] = useState(true);
  const [latestSubmission, setLatestSubmission] = useState<ExplanationSubmission | null>(null);

  // Peer review queue
  const [reviewQueue, setReviewQueue] = useState<AnonymousReviewItem[]>([]);
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0);
  const [ratings, setRatings] = useState({ clarity: 5, accuracy: 5, helpfulness: 5 });
  const [reviewComment, setReviewComment] = useState('');
  const [reviewedSuccess, setReviewedSuccess] = useState(false);

  // Best explanations leaderboard
  const [bestExplanations, setBestExplanations] = useState<BestExplanationItem[]>([]);

  // Speech recognition ref
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Load existing submission if any
    const all = ExplainBackService.getAllSubmissions();
    const mySub = all.find(s => s.studentId === studentId && s.conceptId === conceptId);
    if (mySub) {
      setLatestSubmission(mySub);
      setExplanationInput(mySub.explanationText);
    }

    // Load review queue and best list
    loadCommunityData();
  }, [conceptId, studentId]);

  const loadCommunityData = () => {
    setReviewQueue(PeerReviewService.getReviewQueue(studentId, conceptId));
    setBestExplanations(PeerReviewService.getBestExplanations(conceptId));
  };

  // Speech recognition toggle
  const toggleSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech dictation is not supported by your current browser. You can type directly.');
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onresult = (event: any) => {
          let currentTranscript = '';
          for (let i = 0; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript + ' ';
          }
          setExplanationInput(prev => (prev ? prev + ' ' : '') + currentTranscript.trim());
        };

        recognition.onerror = (e: any) => {
          console.warn('Speech error:', e);
          setIsRecording(false);
        };

        recognition.onend = () => {
          setIsRecording(false);
        };

        recognition.start();
        recognitionRef.current = recognition;
        setIsRecording(true);
      } catch (e) {
        console.error('Failed to start speech dictation:', e);
        setIsRecording(false);
      }
    }
  };

  // Handle Explain-Back submission
  const handleSubmitExplanation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!explanationInput.trim() || isEvaluating) return;

    // Safety screen
    const mod = ModerationEngine.screenContent(explanationInput);
    if (!mod.isSafe) {
      alert(mod.suggestion || 'Please provide a respectful explanation.');
      return;
    }

    setIsEvaluating(true);
    try {
      const sub = await ExplainBackService.submitExplanation(
        studentId,
        conceptId,
        conceptTitle,
        explanationInput.trim(),
        optInPeerReview
      );
      setLatestSubmission(sub);
      loadCommunityData();
      onSubmissionSuccess?.(sub);
    } catch (e) {
      console.error('Explanation submission failed:', e);
    } finally {
      setIsEvaluating(false);
    }
  };

  // Handle Peer Review submission
  const handleSubmitPeerReview = (e: React.FormEvent) => {
    e.preventDefault();
    const currentItem = reviewQueue[currentReviewIndex];
    if (!currentItem) return;

    PeerReviewService.submitReview(currentItem.id, studentId, {
      clarity: ratings.clarity,
      accuracy: ratings.accuracy,
      helpfulness: ratings.helpfulness,
      comment: reviewComment
    });

    setReviewedSuccess(true);
    setTimeout(() => {
      setReviewedSuccess(false);
      setReviewComment('');
      setRatings({ clarity: 5, accuracy: 5, helpfulness: 5 });
      // Move to next in queue
      if (currentReviewIndex + 1 < reviewQueue.length) {
        setCurrentReviewIndex(prev => prev + 1);
      } else {
        loadCommunityData();
        setCurrentReviewIndex(0);
      }
    }, 900);
  };

  return (
    <div className={cn(
      "rounded-3xl border overflow-hidden shadow-xl bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800",
      className
    )}>
      {/* Top Banner */}
      <div className="p-5 sm:p-6 bg-gradient-to-r from-indigo-900/10 via-violet-900/10 to-transparent border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/30 shrink-0">
            <Users size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                Social Learning & Peer Explanation Mode
              </h3>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 uppercase tracking-wider">
                Feynman Technique
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              "If you want to master something, teach it to a classmate."
            </p>
          </div>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800">
          <button
            onClick={() => setActiveTab('explain')}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer",
              activeTab === 'explain'
                ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            )}
          >
            1. Explain-Back
          </button>
          <button
            onClick={() => setActiveTab('review')}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5",
              activeTab === 'review'
                ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            )}
          >
            <span>2. Peer Review</span>
            {reviewQueue.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('best')}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1",
              activeTab === 'best'
                ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
            )}
          >
            <Trophy size={13} />
            <span>Best Explanations</span>
          </button>
        </div>
      </div>

      {/* TAB 1: EXPLAIN-BACK MODE */}
      {activeTab === 'explain' && (
        <div className="p-5 sm:p-6 space-y-5">
          <div className="p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-900/50 flex items-start justify-between gap-3">
            <div>
              <h4 className="text-xs sm:text-sm font-extrabold text-indigo-900 dark:text-indigo-200 flex items-center gap-1.5">
                <Sparkles size={16} className="text-indigo-500" />
                Prompt: "Explain this to me like I'm a classmate"
              </h4>
              <p className="text-xs text-indigo-700/80 dark:text-indigo-300/80 mt-1">
                Target concept: <span className="font-bold underline">{conceptTitle}</span>. Use your own metaphors, analogies, and simple language.
              </p>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-600 text-white font-bold shrink-0">
              Exam Predictor
            </span>
          </div>

          <form onSubmit={handleSubmitExplanation} className="space-y-3">
            <div className="relative">
              <textarea
                rows={4}
                value={explanationInput}
                onChange={(e) => setExplanationInput(e.target.value)}
                placeholder="Type or dictate your explanation here... e.g., 'Imagine when a magnet approaches a coil of wire...'"
                className="w-full p-4 rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-xs sm:text-sm text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none font-normal leading-relaxed"
              />

              {/* Dictate Voice Button */}
              <button
                type="button"
                onClick={toggleSpeechRecognition}
                className={cn(
                  "absolute bottom-3 right-3 p-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm",
                  isRecording 
                    ? "bg-rose-500 text-white animate-pulse" 
                    : "bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600 hover:bg-slate-100"
                )}
                title="Dictate with microphone"
              >
                {isRecording ? <MicOff size={15} /> : <Mic size={15} />}
                <span>{isRecording ? 'Listening...' : 'Dictate'}</span>
              </button>
            </div>

            {/* Moderation & Opt-In Layer */}
            <ModerationLayer
              isOptedIn={optInPeerReview}
              onToggleOptIn={(v) => setOptInPeerReview(v)}
            />

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-slate-400">
                AI evaluates: Accuracy (40%), Clarity (30%), Completeness (30%)
              </span>

              <button
                type="submit"
                disabled={!explanationInput.trim() || isEvaluating}
                className="px-6 py-2.5 rounded-xl text-xs font-extrabold bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-lg shadow-indigo-600/30 flex items-center gap-2 cursor-pointer transition disabled:opacity-40"
              >
                {isEvaluating ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" /> Evaluating...
                  </>
                ) : (
                  <>
                    <Send size={14} /> Submit Explanation
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Evaluation Results Card */}
          {latestSubmission && latestSubmission.aiBreakdown && (
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 text-white font-black text-sm flex items-center justify-center shadow-md shadow-emerald-500/20">
                    {latestSubmission.aiScore}
                  </div>
                  <div>
                    <h5 className="text-sm font-black text-slate-800 dark:text-slate-100">
                      Overall Score: {latestSubmission.aiScore}/100
                    </h5>
                    <p className="text-[11px] text-slate-500">
                      Strongly correlates with top tier {latestSubmission.aiScore >= 85 ? 'Grade A*' : 'Grade A'} exam retention.
                    </p>
                  </div>
                </div>

                {/* Score Meters */}
                <div className="flex items-center gap-4 text-xs font-mono">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Accuracy</span>
                    <span className="font-bold text-emerald-500">
                      {latestSubmission.aiBreakdown.accuracyScore}%
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Clarity</span>
                    <span className="font-bold text-indigo-500">
                      {latestSubmission.aiBreakdown.clarityScore}%
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Completeness</span>
                    <span className="font-bold text-violet-500">
                      {latestSubmission.aiBreakdown.completenessScore}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Feedback Text */}
              <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed italic bg-white dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                "{latestSubmission.aiFeedback}"
              </p>

              {/* Strengths & Improvements */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/50 dark:border-emerald-900/30">
                  <span className="font-bold text-emerald-700 dark:text-emerald-400 block mb-1">
                    Strengths:
                  </span>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-300">
                    {latestSubmission.aiBreakdown.strengths.map((s, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <CheckCircle2 size={13} className="text-emerald-500 shrink-0 mt-0.5" />
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/50 dark:border-amber-900/30">
                  <span className="font-bold text-amber-700 dark:text-amber-400 block mb-1">
                    Areas for Growth:
                  </span>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-300">
                    {latestSubmission.aiBreakdown.improvements.map((imp, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <ArrowRight size={13} className="text-amber-500 shrink-0 mt-0.5" />
                        <span>{imp}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: ANONYMOUS PEER REVIEW */}
      {activeTab === 'review' && (
        <div className="p-5 sm:p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                <Eye size={16} className="text-indigo-500" />
                Anonymous Peer Review Queue
              </h4>
              <p className="text-xs text-slate-500">
                Rate classmate explanations anonymously to sharpen your own critical assessment.
              </p>
            </div>

            <span className="text-xs font-bold text-slate-400">
              {reviewQueue.length > 0 ? `${currentReviewIndex + 1} of ${reviewQueue.length}` : '0 pending'}
            </span>
          </div>

          {reviewQueue.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-400">
              <CheckCircle2 size={28} className="mx-auto mb-2 text-emerald-500" />
              All caught up! No pending peer explanations awaiting review right now.
            </div>
          ) : (
            <div className="space-y-4">
              {/* Submission to Review */}
              <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 relative">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                    {reviewQueue[currentReviewIndex]?.anonymousAuthorLabel}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    Concept: {reviewQueue[currentReviewIndex]?.conceptTitle}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-normal">
                  "{reviewQueue[currentReviewIndex]?.explanationText}"
                </p>
              </div>

              {/* Review Rating Form */}
              <form onSubmit={handleSubmitPeerReview} className="space-y-4 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <h5 className="text-xs font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Your Constructive Evaluation:
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Clarity */}
                  <div>
                    <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1.5">
                      Clarity (1-5): {ratings.clarity} ⭐
                    </label>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={ratings.clarity}
                      onChange={(e) => setRatings({ ...ratings, clarity: Number(e.target.value) })}
                      className="w-full accent-indigo-600 cursor-pointer"
                    />
                  </div>

                  {/* Accuracy */}
                  <div>
                    <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1.5">
                      Accuracy (1-5): {ratings.accuracy} ⭐
                    </label>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={ratings.accuracy}
                      onChange={(e) => setRatings({ ...ratings, accuracy: Number(e.target.value) })}
                      className="w-full accent-indigo-600 cursor-pointer"
                    />
                  </div>

                  {/* Helpfulness */}
                  <div>
                    <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1.5">
                      Helpfulness (1-5): {ratings.helpfulness} ⭐
                    </label>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={ratings.helpfulness}
                      onChange={(e) => setRatings({ ...ratings, helpfulness: Number(e.target.value) })}
                      className="w-full accent-indigo-600 cursor-pointer"
                    />
                  </div>
                </div>

                <input
                  type="text"
                  placeholder="Optional supportive constructive comment (e.g. 'Loved the elevator analogy!')..."
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl text-xs font-extrabold bg-indigo-600 hover:bg-indigo-500 text-white transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/20"
                  >
                    {reviewedSuccess ? (
                      <>
                        <CheckCircle2 size={14} /> Review Submitted!
                      </>
                    ) : (
                      <>
                        <Send size={14} /> Submit Anonymous Review
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BEST EXPLANATIONS LEADERBOARD */}
      {activeTab === 'best' && (
        <div className="p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                <Trophy size={16} className="text-amber-500" />
                Community Hall of Fame: "Best Explanations"
              </h4>
              <p className="text-xs text-slate-500">
                Top student explanations surfaced by peer review ratings and AI accuracy verification.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {bestExplanations.map((item, idx) => (
              <div 
                key={item.id}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 space-y-2.5"
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 font-black text-xs flex items-center justify-center border border-amber-500/20">
                      #{idx + 1}
                    </span>
                    <span className="font-bold text-xs text-slate-800 dark:text-slate-200">
                      {item.anonymousAuthorLabel}
                    </span>
                    <div className="flex items-center gap-1">
                      {item.featuredBadges.map(badge => (
                        <span key={badge} className="px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                          {badge}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-xs font-mono">
                    <span className="text-amber-500 font-bold flex items-center gap-1">
                      <Star size={12} className="fill-current" /> {item.compositeScore}/100
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      {item.reviewCount} peer reviews
                    </span>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
                  "{item.explanationText}"
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
