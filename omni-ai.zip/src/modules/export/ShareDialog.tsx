import React from 'react';
import { Copy } from 'lucide-react';

export const ShareDialog: React.FC<{ resourceId: string; onClose: () => void }> = ({ resourceId, onClose }) => {
  const shareLink = `${window.location.origin}/share/${resourceId}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareLink);
    alert('Link copied!');
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-slate-900 p-6 rounded-2xl w-full max-w-sm space-y-4">
        <h3 className="text-lg font-bold text-white">Share Content</h3>
        <div className="flex items-center gap-2 bg-slate-950 p-2 rounded">
          <input readOnly value={shareLink} className="bg-transparent flex-1 text-xs text-slate-300" />
          <button onClick={copyToClipboard} className="text-indigo-400"><Copy size={16} /></button>
        </div>
        <button onClick={onClose} className="w-full bg-slate-800 text-slate-300 p-2 rounded">Close</button>
      </div>
    </div>
  );
};
