import React from 'react';
import { useLearningStyle } from '../hooks/useLearningStyle';
import { VARKStyle } from '../modules/learning-style/types';
import { 
  Eye, 
  Volume2, 
  BookOpen, 
  Hand, 
  Sparkles, 
  Settings, 
  RotateCcw, 
  CheckCircle2, 
  HelpCircle, 
  BrainCircuit, 
  Sliders 
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface LearningStyleCardProps {
  className?: string;
}

export const LearningStyleCard: React.FC<LearningStyleCardProps> = ({ className }) => {
  const { profile, adaptation, setManualOverride, resetAutoDetect } = useLearningStyle();

  const getStyleIcon = (style: VARKStyle) => {
    switch (style) {
      case 'visual': return <Eye size={18} className="text-cyan-400" />;
      case 'auditory': return <Volume2 size={18} className="text-indigo-400" />;
      case 'reading': return <BookOpen size={18} className="text-emerald-400" />;
      case 'kinaesthetic': return <Hand size={18} className="text-amber-400" />;
      default: return <BrainCircuit size={18} className="text-violet-400" />;
    }
  };

  const getStyleColor = (style: VARKStyle) => {
    switch (style) {
      case 'visual': return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
      case 'auditory': return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30';
      case 'reading': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'kinaesthetic': return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      default: return 'bg-violet-500/10 text-violet-400 border-violet-500/30';
    }
  };

  return (
    <div className={cn("flex flex-col gap-5 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm", className)}>
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-300 border border-indigo-500/20">
              VARK Learning Style Engine
            </span>
            {profile.isManualOverride && (
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                Manual Override Active
              </span>
            )}
          </div>
          <h3 className="text-base font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            {getStyleIcon(profile.dominantStyle)}
            Adaptive Learning Style: <span className="capitalize text-indigo-600 dark:text-indigo-400">{profile.dominantStyle}</span>
          </h3>
        </div>

        {/* Confidence Badge */}
        <div className="flex items-center gap-2 shrink-0 bg-slate-50 dark:bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700/60">
          <Sparkles size={14} className="text-indigo-500" />
          <div className="flex flex-col text-right">
            <span className="text-[10px] text-slate-400 font-semibold uppercase">Detection Confidence</span>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">{profile.confidence}%</span>
          </div>
        </div>
      </div>

      {/* VARK Breakdown Bars */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Visual */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span className="flex items-center gap-1"><Eye size={13} className="text-cyan-400" /> Visual</span>
            <span>{profile.visualScore}%</span>
          </div>
          <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div className="bg-cyan-400 h-full transition-all duration-300" style={{ width: `${profile.visualScore}%` }} />
          </div>
        </div>

        {/* Auditory */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span className="flex items-center gap-1"><Volume2 size={13} className="text-indigo-400" /> Auditory</span>
            <span>{profile.auditoryScore}%</span>
          </div>
          <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div className="bg-indigo-400 h-full transition-all duration-300" style={{ width: `${profile.auditoryScore}%` }} />
          </div>
        </div>

        {/* Reading */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span className="flex items-center gap-1"><BookOpen size={13} className="text-emerald-400" /> Reading</span>
            <span>{profile.readingScore}%</span>
          </div>
          <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-400 h-full transition-all duration-300" style={{ width: `${profile.readingScore}%` }} />
          </div>
        </div>

        {/* Kinaesthetic */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/50 flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span className="flex items-center gap-1"><Hand size={13} className="text-amber-400" /> Kinaesthetic</span>
            <span>{profile.kinaestheticScore}%</span>
          </div>
          <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div className="bg-amber-400 h-full transition-all duration-300" style={{ width: `${profile.kinaestheticScore}%` }} />
          </div>
        </div>
      </div>

      {/* Adaptation Description */}
      <div className={cn("p-3.5 rounded-xl border text-xs leading-relaxed font-medium", getStyleColor(profile.dominantStyle))}>
        <div className="flex items-center gap-1.5 font-bold mb-1">
          <CheckCircle2 size={14} />
          Active Content Adaptation:
        </div>
        {adaptation.description}
      </div>

      {/* Manual Override Controls */}
      <div className="flex flex-col gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
            <Sliders size={13} />
            "Actually, I learn better this way" (Manual Override)
          </span>
          {profile.isManualOverride && (
            <button
              onClick={resetAutoDetect}
              className="text-[11px] font-semibold text-indigo-500 hover:text-indigo-600 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw size={11} /> Reset to Auto-Detect
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
          {(['visual', 'auditory', 'reading', 'kinaesthetic', 'balanced'] as VARKStyle[]).map((style) => (
            <button
              key={style}
              type="button"
              onClick={() => setManualOverride(style)}
              className={cn(
                "px-2.5 py-1.5 rounded-lg text-xs font-semibold capitalize transition cursor-pointer border text-center",
                profile.dominantStyle === style && profile.isManualOverride
                  ? "bg-indigo-600 text-white border-indigo-600 shadow-sm"
                  : "bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-indigo-400"
              )}
            >
              {style}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
