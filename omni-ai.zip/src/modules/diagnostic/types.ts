export type MasteryLevel = 'mastered' | 'proficient' | 'developing' | 'beginner';

export interface DiagnosticQuestion {
  id: string;
  chapterId: string;
  subtopicId: string;
  subtopicTitle: string;
  difficulty: number; // IRT difficulty parameter 'b' (-2.0 to +2.0)
  discrimination: number; // IRT discrimination parameter 'a' (0.8 to 1.8)
  pseudoGuessing: number; // IRT guessing parameter 'c' (typically 0.25)
  questionText: string;
  formulaOrCode?: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
}

export interface UserResponse {
  questionId: string;
  subtopicId: string;
  selectedOptionIndex: number;
  isCorrect: boolean;
  timeSpentSeconds: number;
  thetaEstimateAfter: number;
  standardErrorAfter: number;
}

export interface TopicAssessment {
  subtopicId: string;
  subtopicTitle: string;
  score: number; // 0 - 100 percentage
  masteryLevel: MasteryLevel;
  totalAsked: number;
  correctCount: number;
  standardLectureMinutes: number;
  adaptedLectureMinutes: number;
  minutesSaved: number;
  recommendation: string;
}

export interface DiagnosticResult {
  studentId: string;
  chapterId: string;
  chapterTitle: string;
  subject: string;
  topicScores: Record<string, {
    score: number;
    masteryLevel: MasteryLevel;
  }>;
  detailedTopics: Record<string, TopicAssessment>;
  overallScore: number; // 0 - 100
  masteryPercentage: number;
  abilityTheta: number; // Final IRT θ (-3.0 to +3.0)
  standardError: number;
  confidenceInterval: [number, number]; // [lower, upper]
  totalQuestionsAnswered: number;
  timeTaken: number; // in seconds
  totalMinutesSaved: number;
  skippedMinutes: number;
  isSkipped: boolean; // if student chose to skip diagnostic
  completedAt: string;
}

export interface LecturePathStep {
  stepNumber: number;
  subtopicId: string;
  subtopicTitle: string;
  masteryLevel: MasteryLevel;
  action: 'skip' | 'quick_review' | 'full_teaching' | 'foundation';
  durationMinutes: number;
  originalDurationMinutes: number;
  timeSavedMinutes: number;
  description: string;
}
