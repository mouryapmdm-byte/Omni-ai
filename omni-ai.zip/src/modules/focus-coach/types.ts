export interface StudySession {
  id: string;
  studentId: string;
  startedAt: string;
  endedAt?: string;
  durationMinutes: number;
  focusScore: number; // 0-100
  tabSwitches: number;
  idleMinutes: number;
  pomodoroCount: number;
  breakCount: number;
  subjects: string[];
  mode: 'pomodoro' | 'shortBreak' | 'longBreak' | 'customFocus';
  notes?: string;
}

export interface FocusInsight {
  studentId: string;
  bestStudyHour: number; // 0-23 (e.g. 9 = 9 AM)
  bestStudyWindowLabel: string; // e.g. "Morning (8:00 AM - 11:30 AM)"
  avgSessionDuration: number; // minutes
  avgFocusScore: number; // 0-100
  focusDropAfterHour?: number; // e.g. 20 = 8 PM
  topDistractions: string[];
  recommendedBreakIntervalMinutes: number;
  updatedAt: string;
}

export type AmbientSoundType = 'lofi' | 'whitenoise' | 'rain' | 'forest' | 'binaural';

export interface AmbientSoundTrack {
  id: AmbientSoundType;
  name: string;
  category: 'Music' | 'Noise' | 'Nature' | 'Therapy';
  description: string;
  iconName: string;
  volume: number; // 0 to 1
  isPlaying: boolean;
}

export interface RecommendedScheduleSlot {
  dayName: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';
  timeRange: string; // e.g., "09:00 AM - 10:30 AM"
  startHour: number;
  subjectRecommendation: string;
  energyLevel: 'Peak Focus' | 'Steady Endurance' | 'Light Review';
  reasoning: string;
}
