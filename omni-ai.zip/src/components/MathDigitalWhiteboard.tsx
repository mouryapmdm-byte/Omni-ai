import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Pencil, 
  Eraser, 
  RotateCcw, 
  RotateCw, 
  Trash2, 
  Download, 
  Send, 
  Paperclip, 
  Type, 
  Square, 
  Circle, 
  Triangle, 
  Maximize2, 
  Grid, 
  Sparkles, 
  Palette, 
  X, 
  Check, 
  Copy,
  Ruler,
  TrendingUp,
  Activity,
  Zap,
  HelpCircle,
  Mic
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

export interface MathDigitalWhiteboardProps {
  isOpen: boolean;
  onClose: () => void;
  onSendToChat: (text: string, imageBase64?: string) => void;
  onAttachToInput?: (imageBase64: string) => void;
  theme?: 'light' | 'dark';
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

type ToolMode = 'pen' | 'highlighter' | 'eraser' | 'line' | 'arrow' | 'axes' | 'circle' | 'rectangle' | 'triangle' | 'parabola' | 'text' | 'symbol';

type CanvasBackground = 'chalkboard' | 'grid' | 'blue-grid' | 'dot-grid' | 'white' | 'polar';

interface DrawingPoint {
  x: number;
  y: number;
  pressure?: number;
}

interface DrawingPath {
  id: string;
  type: 'freehand' | 'highlighter' | 'shape' | 'text' | 'symbol';
  tool: ToolMode;
  points: DrawingPoint[];
  color: string;
  size: number;
  text?: string;
  startPoint?: DrawingPoint;
  endPoint?: DrawingPoint;
}

const MATH_SYMBOLS = [
  { symbol: 'π', label: 'Pi' },
  { symbol: '∑', label: 'Summation' },
  { symbol: '∫', label: 'Integral' },
  { symbol: '√', label: 'Square Root' },
  { symbol: 'θ', label: 'Theta' },
  { symbol: '∞', label: 'Infinity' },
  { symbol: 'Δ', label: 'Delta' },
  { symbol: 'α', label: 'Alpha' },
  { symbol: 'β', label: 'Beta' },
  { symbol: '±', label: 'Plus-Minus' },
  { symbol: '≠', label: 'Not Equal' },
  { symbol: '≈', label: 'Approximate' },
  { symbol: '≤', label: 'Less or Equal' },
  { symbol: '≥', label: 'Greater or Equal' },
  { symbol: '∈', label: 'Element Of' },
  { symbol: 'f(x)', label: 'Function' },
  { symbol: 'dy/dx', label: 'Derivative' },
  { symbol: 'x²', label: 'Squared' },
  { symbol: 'x³', label: 'Cubed' },
  { symbol: '∠', label: 'Angle' },
];

const PALETTE_COLORS = [
  { name: 'Chalk White', hex: '#FFFFFF', class: 'bg-white' },
  { name: 'Golden Yellow', hex: '#FACC15', class: 'bg-yellow-400' },
  { name: 'Cyan Electric', hex: '#38BDF8', class: 'bg-sky-400' },
  { name: 'Emerald Math', hex: '#34D399', class: 'bg-emerald-400' },
  { name: 'Vibrant Rose', hex: '#FB7185', class: 'bg-rose-400' },
  { name: 'Purple Proof', hex: '#C084FC', class: 'bg-purple-400' },
  { name: 'Bright Orange', hex: '#FB923C', class: 'bg-orange-400' },
  { name: 'Slate Dark', hex: '#0F172A', class: 'bg-slate-900' },
];

export const MathDigitalWhiteboard: React.FC<MathDigitalWhiteboardProps> = ({
  isOpen,
  onClose,
  onSendToChat,
  onAttachToInput,
  theme = 'dark',
  showNotification
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [tool, setTool] = useState<ToolMode>('pen');
  const [strokeColor, setStrokeColor] = useState<string>('#FFFFFF');
  const [strokeWidth, setStrokeWidth] = useState<number>(3);
  const [background, setBackground] = useState<CanvasBackground>('chalkboard');
  
  // Undo/Redo Stacks
  const [paths, setPaths] = useState<DrawingPath[]>([]);
  const [redoStack, setRedoStack] = useState<DrawingPath[]>([]);
  
  // Drawing States
  const isDrawing = useRef<boolean>(false);
  const currentPathRef = useRef<DrawingPath | null>(null);
  const [selectedSymbol, setSelectedSymbol] = useState<string>('π');
  const [textInput, setTextInput] = useState<string>('');
  const [activeTextPos, setActiveTextPos] = useState<{ x: number; y: number } | null>(null);
  const [promptText, setPromptText] = useState<string>('');
  const [isStylusDetected, setIsStylusDetected] = useState<boolean>(false);
  const [isDictating, setIsDictating] = useState<boolean>(false);

  const handleWhiteboardDictation = () => {
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showNotification?.("Speech recognition is not supported in this browser.", "warning");
      return;
    }
    if (isDictating) {
      setIsDictating(false);
      return;
    }
    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsDictating(true);
        showNotification?.("🎙️ Dictation active on Whiteboard! Speak math formulas or notes...", "info");
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript.trim()) {
          setPromptText((prev) => {
            const separator = prev ? ' ' : '';
            return prev + separator + transcript.trim();
          });
        }
      };

      recognition.onerror = (err: any) => {
        console.warn("Speech recognition error:", err);
        setIsDictating(false);
      };

      recognition.onend = () => {
        setIsDictating(false);
      };

      recognition.start();
    } catch (e) {
      console.error("Dictation start error:", e);
      setIsDictating(false);
    }
  };

  // Measure canvas scale
  const getCanvasCoordinates = useCallback((e: React.PointerEvent<HTMLCanvasElement>): DrawingPoint => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    // pressure detection for stylus
    const pressure = e.pressure && e.pressure > 0 ? e.pressure : 0.5;
    if (e.pointerType === 'pen') {
      setIsStylusDetected(true);
    }

    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
      pressure
    };
  }, []);

  // Render Grid / Background
  const drawBackground = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number) => {
    switch (background) {
      case 'chalkboard':
        ctx.fillStyle = '#0f172a'; // slate-900
        ctx.fillRect(0, 0, width, height);
        
        // Subtle grid
        ctx.strokeStyle = '#1e293b'; // slate-800
        ctx.lineWidth = 1;
        const gridSize = 30;
        ctx.beginPath();
        for (let x = 0; x <= width; x += gridSize) {
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
        }
        for (let y = 0; y <= height; y += gridSize) {
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
        }
        ctx.stroke();
        break;

      case 'grid':
        ctx.fillStyle = '#f8fafc'; // slate-50
        ctx.fillRect(0, 0, width, height);
        
        ctx.strokeStyle = '#cbd5e1'; // slate-300
        ctx.lineWidth = 0.75;
        const gSize = 25;
        ctx.beginPath();
        for (let x = 0; x <= width; x += gSize) {
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
        }
        for (let y = 0; y <= height; y += gSize) {
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
        }
        ctx.stroke();
        break;

      case 'blue-grid':
        ctx.fillStyle = '#030712'; // gray-950
        ctx.fillRect(0, 0, width, height);

        ctx.strokeStyle = '#1e3a8a'; // blue-900
        ctx.lineWidth = 1;
        const bSize = 30;
        ctx.beginPath();
        for (let x = 0; x <= width; x += bSize) {
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
        }
        for (let y = 0; y <= height; y += bSize) {
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
        }
        ctx.stroke();
        break;

      case 'dot-grid':
        ctx.fillStyle = '#111827';
        ctx.fillRect(0, 0, width, height);

        ctx.fillStyle = '#4b5563';
        const dSize = 30;
        for (let x = dSize / 2; x < width; x += dSize) {
          for (let y = dSize / 2; y < height; y += dSize) {
            ctx.beginPath();
            ctx.arc(x, y, 1.5, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        break;

      case 'polar':
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, width, height);

        const centerX = width / 2;
        const centerY = height / 2;
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 1;

        // Concentric circles
        for (let r = 30; r < Math.max(width, height); r += 40) {
          ctx.beginPath();
          ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Radial lines
        for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 6) {
          ctx.beginPath();
          ctx.moveTo(centerX, centerY);
          ctx.lineTo(
            centerX + Math.cos(angle) * Math.max(width, height),
            centerY + Math.sin(angle) * Math.max(width, height)
          );
          ctx.stroke();
        }
        break;

      case 'white':
      default:
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        break;
    }
  }, [background]);

  // Render path onto canvas context
  const renderPath = useCallback((ctx: CanvasRenderingContext2D, pathItem: DrawingPath) => {
    ctx.save();
    ctx.strokeStyle = pathItem.color;
    ctx.fillStyle = pathItem.color;
    ctx.lineWidth = pathItem.size;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (pathItem.tool === 'highlighter') {
      ctx.globalAlpha = 0.35;
      ctx.lineWidth = pathItem.size * 3.5;
    } else {
      ctx.globalAlpha = 1.0;
    }

    if (pathItem.tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineWidth = pathItem.size * 4;
      ctx.beginPath();
      if (pathItem.points.length > 0) {
        ctx.moveTo(pathItem.points[0].x, pathItem.points[0].y);
        for (let i = 1; i < pathItem.points.length; i++) {
          ctx.lineTo(pathItem.points[i].x, pathItem.points[i].y);
        }
        ctx.stroke();
      }
      ctx.restore();
      return;
    }

    ctx.globalCompositeOperation = 'source-over';

    if (pathItem.type === 'freehand' || pathItem.type === 'highlighter') {
      if (pathItem.points.length < 2) {
        if (pathItem.points.length === 1) {
          ctx.beginPath();
          ctx.arc(pathItem.points[0].x, pathItem.points[0].y, pathItem.size / 2, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        return;
      }

      ctx.beginPath();
      ctx.moveTo(pathItem.points[0].x, pathItem.points[0].y);
      for (let i = 1; i < pathItem.points.length - 1; i++) {
        const xc = (pathItem.points[i].x + pathItem.points[i + 1].x) / 2;
        const yc = (pathItem.points[i].y + pathItem.points[i + 1].y) / 2;
        ctx.quadraticCurveTo(pathItem.points[i].x, pathItem.points[i].y, xc, yc);
      }
      const lastPoint = pathItem.points[pathItem.points.length - 1];
      ctx.lineTo(lastPoint.x, lastPoint.y);
      ctx.stroke();

    } else if (pathItem.type === 'shape' && pathItem.startPoint && pathItem.endPoint) {
      const { x: x1, y: y1 } = pathItem.startPoint;
      const { x: x2, y: y2 } = pathItem.endPoint;

      if (pathItem.tool === 'line') {
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();

      } else if (pathItem.tool === 'arrow') {
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();

        // Arrow head
        const angle = Math.atan2(y2 - y1, x2 - x1);
        const headLen = Math.max(12, pathItem.size * 3);
        ctx.beginPath();
        ctx.moveTo(x2, y2);
        ctx.lineTo(x2 - headLen * Math.cos(angle - Math.PI / 6), y2 - headLen * Math.sin(angle - Math.PI / 6));
        ctx.lineTo(x2 - headLen * Math.cos(angle + Math.PI / 6), y2 - headLen * Math.sin(angle + Math.PI / 6));
        ctx.closePath();
        ctx.fill();

      } else if (pathItem.tool === 'axes') {
        // Cartesian Coordinate Axes
        ctx.lineWidth = Math.max(2, pathItem.size);
        // X-axis
        ctx.beginPath();
        ctx.moveTo(x1, y2);
        ctx.lineTo(x2, y2);
        ctx.stroke();

        // Y-axis
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x1, y2);
        ctx.stroke();

        // Axis labels
        ctx.font = 'bold 12px monospace';
        ctx.fillText('X', x2 + 6, y2 + 4);
        ctx.fillText('Y', x1 - 4, y1 - 8);
        ctx.fillText('(0,0)', x1 - 18, y2 + 16);

      } else if (pathItem.tool === 'rectangle') {
        ctx.beginPath();
        ctx.rect(x1, y1, x2 - x1, y2 - y1);
        ctx.stroke();

      } else if (pathItem.tool === 'circle') {
        const radius = Math.hypot(x2 - x1, y2 - y1);
        ctx.beginPath();
        ctx.arc(x1, y1, radius, 0, Math.PI * 2);
        ctx.stroke();

      } else if (pathItem.tool === 'triangle') {
        ctx.beginPath();
        ctx.moveTo(x1, y2);
        ctx.lineTo((x1 + x2) / 2, y1);
        ctx.lineTo(x2, y2);
        ctx.closePath();
        ctx.stroke();

      } else if (pathItem.tool === 'parabola') {
        // Quadratic Curve Parabola
        ctx.beginPath();
        ctx.moveTo(x1, y2);
        ctx.quadraticCurveTo((x1 + x2) / 2, y1 - Math.abs(y2 - y1), x2, y2);
        ctx.stroke();
      }

    } else if ((pathItem.type === 'text' || pathItem.type === 'symbol') && pathItem.text && pathItem.startPoint) {
      const fontSize = Math.max(16, pathItem.size * 6);
      ctx.font = `bold ${fontSize}px "KaTeX_Main", "STIX Two Math", monospace, sans-serif`;
      ctx.fillText(pathItem.text, pathItem.startPoint.x, pathItem.startPoint.y);
    }

    ctx.restore();
  }, []);

  // Redraw All Paths
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    drawBackground(ctx, canvas.width, canvas.height);

    paths.forEach(p => renderPath(ctx, p));

    if (currentPathRef.current) {
      renderPath(ctx, currentPathRef.current);
    }
  }, [background, paths, drawBackground, renderPath]);

  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  // Adjust Canvas Resolution on Resize/Mount
  useEffect(() => {
    if (!isOpen) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const parent = canvas.parentElement;
    if (parent) {
      const rect = parent.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.scale(1, 1);
      }
      redrawCanvas();
    }
  }, [isOpen, redrawCanvas]);

  // Pointer Down Event
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    canvasRef.current?.setPointerCapture(e.pointerId);
    isDrawing.current = true;

    const pt = getCanvasCoordinates(e);

    if (tool === 'text') {
      setActiveTextPos(pt);
      return;
    }

    if (tool === 'symbol') {
      const newPath: DrawingPath = {
        id: `sym-${Date.now()}`,
        type: 'symbol',
        tool: 'symbol',
        points: [pt],
        color: strokeColor,
        size: strokeWidth,
        text: selectedSymbol,
        startPoint: pt
      };
      setPaths(prev => [...prev, newPath]);
      setRedoStack([]);
      isDrawing.current = false;
      return;
    }

    const isShape = ['line', 'arrow', 'axes', 'circle', 'rectangle', 'triangle', 'parabola'].includes(tool);

    const newPath: DrawingPath = {
      id: `path-${Date.now()}`,
      type: isShape ? 'shape' : tool === 'highlighter' ? 'highlighter' : 'freehand',
      tool,
      points: [pt],
      color: strokeColor,
      size: strokeWidth,
      startPoint: pt,
      endPoint: pt
    };

    currentPathRef.current = newPath;
    redrawCanvas();
  };

  // Pointer Move Event
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current || !currentPathRef.current) return;
    e.preventDefault();

    const pt = getCanvasCoordinates(e);

    if (currentPathRef.current.type === 'shape') {
      currentPathRef.current.endPoint = pt;
    } else {
      currentPathRef.current.points.push(pt);
    }

    redrawCanvas();
  };

  // Pointer Up Event
  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current || !currentPathRef.current) return;
    e.preventDefault();
    canvasRef.current?.releasePointerCapture(e.pointerId);

    isDrawing.current = false;
    const completedPath = { ...currentPathRef.current };
    currentPathRef.current = null;

    setPaths(prev => [...prev, completedPath]);
    setRedoStack([]);
    redrawCanvas();
  };

  // Commit Text Tool
  const handleAddText = () => {
    if (!activeTextPos || !textInput.trim()) {
      setActiveTextPos(null);
      setTextInput('');
      return;
    }

    const newPath: DrawingPath = {
      id: `text-${Date.now()}`,
      type: 'text',
      tool: 'text',
      points: [activeTextPos],
      color: strokeColor,
      size: strokeWidth,
      text: textInput.trim(),
      startPoint: activeTextPos
    };

    setPaths(prev => [...prev, newPath]);
    setRedoStack([]);
    setActiveTextPos(null);
    setTextInput('');
  };

  // Undo / Redo / Clear Handlers
  const handleUndo = () => {
    if (paths.length === 0) return;
    const last = paths[paths.length - 1];
    setPaths(prev => prev.slice(0, prev.length - 1));
    setRedoStack(prev => [last, ...prev]);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const first = redoStack[0];
    setRedoStack(prev => prev.slice(1));
    setPaths(prev => [...prev, first]);
  };

  const handleClear = () => {
    if (paths.length === 0) return;
    setPaths([]);
    setRedoStack([]);
    showNotification?.('Whiteboard cleared!', 'info');
  };

  // Export Canvas to Base64
  const getCanvasDataUrl = (): string | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    return canvas.toDataURL('image/png');
  };

  // Send Sketch Directly to AI Tutor in Chat
  const handleSendSketchToAI = () => {
    const imgDataUrl = getCanvasDataUrl();
    if (!imgDataUrl || paths.length === 0) {
      showNotification?.('Please sketch something on the whiteboard before sending!', 'warning');
      return;
    }

    const prompt = promptText.trim() || 'Please analyze my sketched mathematical diagram/equation and explain it step-by-step with formulas and solution.';
    onSendToChat(prompt, imgDataUrl);
    showNotification?.('Submitted math sketch to AI Tutor!', 'success');
    onClose();
  };

  // Attach Sketch to Chat Input
  const handleAttachToInput = () => {
    const imgDataUrl = getCanvasDataUrl();
    if (!imgDataUrl || paths.length === 0) {
      showNotification?.('Whiteboard is empty! Draw something to attach.', 'warning');
      return;
    }

    if (onAttachToInput) {
      onAttachToInput(imgDataUrl);
      showNotification?.('Sketch attached to chat input message preview!', 'success');
      onClose();
    }
  };

  // Download Sketch as PNG
  const handleDownload = () => {
    const imgDataUrl = getCanvasDataUrl();
    if (!imgDataUrl) return;

    const a = document.createElement('a');
    a.href = imgDataUrl;
    a.download = `math_whiteboard_sketch_${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showNotification?.('Whiteboard sketch downloaded as PNG!', 'success');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className={cn(
        "w-full max-w-6xl h-[92vh] rounded-3xl border shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95",
        theme === 'dark' ? "bg-slate-950 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
      )}>
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/60 bg-slate-900/80 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white flex items-center justify-center font-black shadow-md shadow-indigo-500/20">
              <Pencil size={18} />
            </div>
            <div>
              <h2 className="text-base font-black tracking-tight text-white flex items-center gap-2">
                Digital Math Whiteboard
                {isStylusDetected && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-extrabold border border-emerald-500/30 flex items-center gap-1">
                    <Zap size={10} /> Stylus / Pen Active
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-slate-400">Sketch equations, geometry, and formulas with mouse or digital stylus</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Background Selector */}
            <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
              <span className="text-[10px] text-slate-400 font-bold px-1 uppercase tracking-wider">Canvas:</span>
              {[
                { id: 'chalkboard', label: 'Chalkboard', icon: Grid },
                { id: 'grid', label: 'Graph Paper', icon: Grid },
                { id: 'blue-grid', label: 'Blue Grid', icon: Grid },
                { id: 'dot-grid', label: 'Dot Grid', icon: Activity },
                { id: 'polar', label: 'Polar Grid', icon: Activity },
                { id: 'white', label: 'White', icon: Square },
              ].map((bg) => (
                <button
                  key={bg.id}
                  onClick={() => setBackground(bg.id as CanvasBackground)}
                  className={cn(
                    "px-2 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer",
                    background === bg.id
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-400 hover:text-white hover:bg-slate-700"
                  )}
                  title={`Background: ${bg.label}`}
                >
                  {bg.label}
                </button>
              ))}
            </div>

            {/* Undo / Redo / Clear */}
            <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
              <button
                onClick={handleUndo}
                disabled={paths.length === 0}
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                title="Undo (Ctrl+Z)"
              >
                <RotateCcw size={16} />
              </button>
              <button
                onClick={handleRedo}
                disabled={redoStack.length === 0}
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                title="Redo"
              >
                <RotateCw size={16} />
              </button>
              <button
                onClick={handleClear}
                disabled={paths.length === 0}
                className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/60 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
                title="Clear Whiteboard"
              >
                <Trash2 size={16} />
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Primary Toolbar & Canvas Row */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Main Tool Palette */}
          <div className="w-60 border-r border-slate-800/60 bg-slate-900/60 p-3 space-y-4 overflow-y-auto shrink-0 select-none">
            {/* Draw Tools */}
            <div className="space-y-1.5">
              <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block px-1">Drawing Tools</span>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'pen', label: 'Pencil / Pen', icon: Pencil },
                  { id: 'highlighter', label: 'Marker', icon: Palette },
                  { id: 'eraser', label: 'Eraser', icon: Eraser },
                  { id: 'text', label: 'Math Text', icon: Type },
                ].map((t) => {
                  const Icon = t.icon;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setTool(t.id as ToolMode)}
                      className={cn(
                        "p-2 rounded-xl flex flex-col items-center justify-center gap-1 text-[11px] font-bold border transition-all cursor-pointer",
                        tool === t.id
                          ? "bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/20"
                          : "bg-slate-800/60 border-slate-700/60 text-slate-300 hover:border-slate-600 hover:text-white"
                      )}
                    >
                      <Icon size={16} />
                      <span>{t.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Geometric Shapes */}
            <div className="space-y-1.5 border-t border-slate-800/60 pt-3">
              <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block px-1">Math & Shapes</span>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'line', label: 'Line', icon: Ruler },
                  { id: 'arrow', label: 'Vector Arrow', icon: TrendingUp },
                  { id: 'axes', label: 'X-Y Axes', icon: Activity },
                  { id: 'circle', label: 'Circle', icon: Circle },
                  { id: 'rectangle', label: 'Rectangle', icon: Square },
                  { id: 'triangle', label: 'Triangle', icon: Triangle },
                  { id: 'parabola', label: 'Parabola', icon: Activity },
                  { id: 'symbol', label: 'Symbol Stamp', icon: Sparkles },
                ].map((s) => {
                  const Icon = s.icon;
                  return (
                    <button
                      key={s.id}
                      onClick={() => setTool(s.id as ToolMode)}
                      className={cn(
                        "p-2 rounded-xl flex flex-col items-center justify-center gap-1 text-[10px] font-bold border transition-all cursor-pointer",
                        tool === s.id
                          ? "bg-purple-600 border-purple-500 text-white shadow-md shadow-purple-600/20"
                          : "bg-slate-800/60 border-slate-700/60 text-slate-300 hover:border-slate-600 hover:text-white"
                      )}
                    >
                      <Icon size={15} />
                      <span>{s.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Color Palette */}
            <div className="space-y-1.5 border-t border-slate-800/60 pt-3">
              <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400 block px-1">Stroke Color</span>
              <div className="grid grid-cols-4 gap-1.5">
                {PALETTE_COLORS.map((c) => (
                  <button
                    key={c.hex}
                    onClick={() => setStrokeColor(c.hex)}
                    className={cn(
                      "w-full h-8 rounded-lg border flex items-center justify-center transition-all cursor-pointer",
                      c.class,
                      strokeColor === c.hex ? "ring-2 ring-indigo-400 ring-offset-2 ring-offset-slate-900 border-white scale-110" : "border-slate-700 opacity-80 hover:opacity-100"
                    )}
                    title={c.name}
                  >
                    {strokeColor === c.hex && <Check size={12} className={c.hex === '#FFFFFF' ? 'text-black' : 'text-white'} />}
                  </button>
                ))}
              </div>
            </div>

            {/* Stroke Thickness */}
            <div className="space-y-1.5 border-t border-slate-800/60 pt-3">
              <div className="flex items-center justify-between px-1">
                <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">Stroke Weight</span>
                <span className="text-[11px] font-mono font-bold text-indigo-400">{strokeWidth}px</span>
              </div>
              <div className="grid grid-cols-4 gap-1">
                {[2, 4, 8, 14].map((sw) => (
                  <button
                    key={sw}
                    onClick={() => setStrokeWidth(sw)}
                    className={cn(
                      "py-1 rounded-lg border text-[10px] font-extrabold transition-all cursor-pointer text-center",
                      strokeWidth === sw
                        ? "bg-indigo-600 border-indigo-500 text-white"
                        : "bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white"
                    )}
                  >
                    {sw}px
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Math Stamps Palette */}
            <div className="space-y-1.5 border-t border-slate-800/60 pt-3">
              <span className="text-[10px] uppercase tracking-wider font-extrabold text-amber-400 block px-1">LaTeX Math Stamps</span>
              <div className="grid grid-cols-4 gap-1">
                {MATH_SYMBOLS.slice(0, 12).map((sym) => (
                  <button
                    key={sym.symbol}
                    onClick={() => {
                      setSelectedSymbol(sym.symbol);
                      setTool('symbol');
                      showNotification?.(`Selected math stamp: ${sym.symbol} (${sym.label})`, 'info');
                    }}
                    className={cn(
                      "p-1.5 rounded-lg border text-xs font-black font-mono transition-all cursor-pointer text-center",
                      tool === 'symbol' && selectedSymbol === sym.symbol
                        ? "bg-amber-500 border-amber-400 text-slate-950 font-black shadow-md"
                        : "bg-slate-800/80 border-slate-700 text-amber-200 hover:border-amber-400 hover:text-white"
                    )}
                    title={sym.label}
                  >
                    {sym.symbol}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Interactive Canvas Canvas Area */}
          <div className="flex-1 relative bg-slate-950 flex items-center justify-center overflow-hidden touch-none">
            <canvas
              ref={canvasRef}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerLeave={handlePointerUp}
              className="w-full h-full cursor-crosshair touch-none select-none"
              style={{ touchAction: 'none' }}
            />

            {/* Interactive Text Input Overlay */}
            {activeTextPos && (
              <div
                className="absolute z-50 p-2 rounded-xl bg-slate-900 border border-indigo-500 shadow-2xl flex items-center gap-2"
                style={{
                  left: `${(activeTextPos.x / (canvasRef.current?.width || 1000)) * 100}%`,
                  top: `${(activeTextPos.y / (canvasRef.current?.height || 800)) * 100}%`
                }}
              >
                <input
                  type="text"
                  autoFocus
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleAddText();
                    if (e.key === 'Escape') setActiveTextPos(null);
                  }}
                  placeholder="Type math formula or text..."
                  className="bg-slate-800 text-white text-sm px-3 py-1.5 rounded-lg border border-slate-700 outline-none w-56 font-mono"
                />
                <button
                  onClick={handleAddText}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-500 cursor-pointer"
                >
                  Place
                </button>
                <button
                  onClick={() => setActiveTextPos(null)}
                  className="p-1.5 text-slate-400 hover:text-white cursor-pointer"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Stylus & Instruction Floating Hint */}
            <div className="absolute top-3 left-3 pointer-events-none bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-[11px] text-slate-300 flex items-center gap-2 shadow-lg">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>
                {tool === 'pen' && 'Sketch freehand math diagram or formula'}
                {tool === 'highlighter' && 'Highlight values or formulas'}
                {tool === 'eraser' && 'Stroke eraser active'}
                {tool === 'text' && 'Click anywhere on canvas to type text/math'}
                {tool === 'symbol' && `Click canvas to stamp "${selectedSymbol}"`}
                {['line', 'arrow', 'axes', 'circle', 'rectangle', 'triangle', 'parabola'].includes(tool) && 'Click and drag to draw geometry shape'}
              </span>
            </div>
          </div>
        </div>

        {/* Bottom AI Tutor Action Bar */}
        <div className="px-4 py-3 border-t border-slate-800/60 bg-slate-900/90 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex-1 flex items-center gap-2 w-full sm:w-auto">
            <Sparkles size={16} className="text-indigo-400 shrink-0" />
            <input
              type="text"
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder="Ask AI tutor about your sketch (e.g., 'Solve this integral' or 'Explain this diagram')..."
              className="flex-1 bg-slate-800/80 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
            <button
              onClick={handleWhiteboardDictation}
              className={cn(
                "px-3 py-2 rounded-xl font-bold text-xs border transition flex items-center gap-1.5 cursor-pointer shrink-0",
                isDictating
                  ? "bg-rose-600 text-white border-rose-400 animate-pulse shadow-md shadow-rose-500/30"
                  : "bg-indigo-900/80 hover:bg-indigo-800 text-indigo-200 border-indigo-700/80"
              )}
              title="Dictation - Speak math formulas or notes"
            >
              <Mic size={14} className={isDictating ? "animate-bounce text-white" : "text-indigo-400"} />
              <span>Dictation</span>
            </button>

            <button
              onClick={handleDownload}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
              title="Download PNG image"
            >
              <Download size={14} />
              <span>Save PNG</span>
            </button>

            {onAttachToInput && (
              <button
                onClick={handleAttachToInput}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 font-bold text-xs border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
                title="Attach sketch to chat message input"
              >
                <Paperclip size={14} />
                <span>Attach to Message</span>
              </button>
            )}

            <button
              onClick={handleSendSketchToAI}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-extrabold text-xs shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Send size={14} />
              <span>Send Sketch to AI Tutor</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
