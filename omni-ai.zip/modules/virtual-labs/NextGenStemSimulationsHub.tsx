export * from '../../src/modules/virtual-labs/NextGenStemSimulationsHub';
import { NextGenStemSimulationsHub } from '../../src/modules/virtual-labs/NextGenStemSimulationsHub';
export default NextGenStemSimulationsHub;
