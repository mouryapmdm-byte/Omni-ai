import React, { useState, useMemo, useEffect } from 'react';
import { X, Sparkles, BookOpen, Calculator, CheckCircle2, AlertTriangle, Lightbulb, Play, Volume2, Target, Award, Trophy, Zap, ChevronDown, ChevronUp, Layers, HelpCircle, ArrowRight } from 'lucide-react';
import { cn } from '../lib/utils';
import { SmartboardVisualPresentationArchitect } from './SmartboardVisualPresentationArchitect';
import { visualPresentationDataService } from '../services/visualPresentationDataService';

export interface FormulaPracticeLevelItem {
  level: number;
  levelName: string;
  badge: string;
  question: string;
  formula: string;
  solution: string;
  answer: string;
}

export interface FormulaPedagogyItem {
  id: string;
  deckId?: string;
  name: string;
  latex: string;
  subject: string;
  spokenForm: string;
  steps: {
    1: { title: '1. Introduce & Contextualize'; content: string };
    2: { title: '2. Symbol-by-Symbol Breakdown'; symbols: Array<{ symbol: string; meaning: string; unit: string; dimensions?: string }> };
    3: { title: '3. Derivation & First Principles'; content: string; keyProof?: string };
    4: { title: '4. Algebraic Step-by-Step Anatomy'; steps: string[] };
    5: { title: '5. Numerical Demonstration'; problem: string; substitution: string; answer: string };
    6: { title: '6. Everyday Life Analogy'; content: string };
    7: { title: '7. Memory Aid & Mnemonic'; mnemonic: string; rule: string };
    8: { title: '8. Exam Traps & Marking Criteria'; traps: string[]; markingSteps: string[] };
    9: { title: '9. Active Understanding Check'; question: string; answer: string; hint: string };
    10: { title: '10. Practice Problem'; question: string; solution: string };
  };
}

export const SAMPLE_FORMULAS: FormulaPedagogyItem[] = [
  {
    id: 'einstein_photoelectric',
    deckId: 'einstein_photoelectric_deck',
    name: "Einstein's Photoelectric Equation",
    latex: "K_{\\max} = h\\nu - \\Phi_0 = h(\\nu - \\nu_0)",
    subject: 'Physics',
    spokenForm: 'K max equals h nu minus phi nought, which equals h times nu minus nu nought',
    steps: {
      1: {
        title: '1. Introduce & Contextualize',
        content: 'Explains how single light packets (photons) transfer all their energy instantaneously to individual bound electrons on a metal surface, proving the particle nature of electromagnetic radiation.'
      },
      2: {
        title: '2. Symbol-by-Symbol Breakdown',
        symbols: [
          { symbol: 'K_max', meaning: 'Maximum Kinetic Energy of emitted photoelectrons', unit: 'Joules (J) or electron-volts (eV)', dimensions: '[M L² T⁻²]' },
          { symbol: 'h', meaning: "Planck's Constant (6.626 × 10⁻³⁴)", unit: 'Joule-seconds (J·s)', dimensions: '[M L² T⁻¹]' },
          { symbol: 'ν (nu)', meaning: 'Frequency of incident electromagnetic wave', unit: 'Hertz (Hz = s⁻¹)', dimensions: '[T⁻¹]' },
          { symbol: 'Φ₀ (phi nought)', meaning: 'Work Function of the metal target', unit: 'Joules (J) or eV', dimensions: '[M L² T⁻²]' },
          { symbol: 'ν₀ (nu nought)', meaning: 'Threshold Frequency required for emission', unit: 'Hertz (Hz)', dimensions: '[T⁻¹]' }
        ]
      },
      3: {
        title: '3. Derivation & First Principles',
        content: 'From Conservation of Energy: Total Photon Energy In = Energy to Liberate Electron (Work Function) + Surplus Kinetic Energy.',
        keyProof: 'E_{photon} = W_0 + K.E. \\implies h\\nu = \\Phi_0 + K_{\\max} \\implies K_{\\max} = h\\nu - \\Phi_0'
      },
      4: {
        title: '4. Algebraic Step-by-Step Anatomy',
        steps: [
          'Step 1: Calculate incident photon energy: E = h·ν = h·c / λ',
          'Step 2: Subtract the material-dependent threshold work function: Φ₀ = h·ν₀',
          'Step 3: Relate surplus kinetic energy to stopping potential: K_max = e·V₀'
        ]
      },
      5: {
        title: '5. Numerical Demonstration',
        problem: 'Light of frequency 8 × 10¹⁴ Hz strikes a metal plate with work function 2.14 eV. Find K_max in eV.',
        substitution: 'hν = (4.136 × 10⁻¹⁵ eV·s)(8 × 10¹⁴ s⁻¹) = 3.31 eV. K_max = 3.31 eV - 2.14 eV',
        answer: 'K_max = 1.17 eV (Stopping potential V₀ = 1.17 Volts)'
      },
      6: {
        title: '6. Everyday Life Analogy',
        content: 'Think of a toll booth with a $5 fee (Work function). You arrive with a $10 bill (Photon energy). The booth takes $5 to let your car pass; you drive out onto the open highway with the remaining $5 in your pocket as speed!'
      },
      7: {
        title: '7. Memory Aid & Mnemonic',
        mnemonic: '"High Frequency Photon Pays Toll First, Runs Away With Rest"',
        rule: 'Remember: 1 photon interacts with only 1 electron. Intensity only increases number of electrons, NOT their maximum kinetic energy!'
      },
      8: {
        title: '8. Exam Traps & Marking Criteria',
        traps: [
          'Trap 1: Confusing Frequency (affects K_max) with Intensity (affects photoelectric current only).',
          'Trap 2: Forgetting to convert electron-volts (eV) to Joules (1 eV = 1.6 × 10⁻¹⁹ J) when using SI units with mass.'
        ],
        markingSteps: [
          '1 Mark: Stating Einstein conservation law: Energy in = Work function + K_max',
          '1 Mark: Correct substitution with units',
          '1 Mark: Final answer with correct SI units and threshold check'
        ]
      },
      9: {
        title: '9. Active Understanding Check',
        question: 'If you double the intensity of light without changing its frequency, what happens to K_max?',
        hint: 'Does intensity change the energy of individual photons?',
        answer: 'K_max remains completely unchanged! Doubling intensity doubles the number of photons per second, thus doubling the current, but individual photon energy hν remains constant.'
      },
      10: {
        title: '10. Practice Problem',
        question: 'Monochromatic light of wavelength 400 nm is incident on Caesium (Φ₀ = 1.9 eV). Calculate stopping potential.',
        solution: 'λ = 400 nm. Energy E = 1240 / 400 = 3.10 eV. K_max = 3.10 - 1.90 = 1.20 eV. Therefore Stopping Potential V₀ = 1.20 V.'
      }
    }
  },
  {
    id: 'newton_second_law',
    deckId: 'newton_second_law',
    name: "Newton's Second Law of Motion",
    latex: "F = ma = \\frac{dp}{dt}",
    subject: 'Physics',
    spokenForm: 'F equals m a, force equals mass times acceleration',
    steps: {
      1: {
        title: '1. Introduce & Contextualize',
        content: 'Relates net unbalanced force applied to a body with its mass and resulting linear acceleration.'
      },
      2: {
        title: '2. Symbol-by-Symbol Breakdown',
        symbols: [
          { symbol: 'F', meaning: 'Net External Unbalanced Force', unit: 'Newtons (N = kg·m/s²)', dimensions: '[M L T⁻²]' },
          { symbol: 'm', meaning: 'Inertial Mass of object', unit: 'Kilograms (kg)', dimensions: '[M]' },
          { symbol: 'a', meaning: 'Linear Acceleration produced', unit: 'Meters / second² (m/s²)', dimensions: '[L T⁻²]' }
        ]
      },
      3: {
        title: '3. Derivation & First Principles',
        content: 'Force is rate of change of momentum: F = dp/dt = d(mv)/dt = m(dv/dt) = ma (for constant mass).',
        keyProof: 'F = \\frac{dp}{dt} = m \\frac{dv}{dt} = m a'
      },
      4: {
        title: '4. Algebraic Step-by-Step Anatomy',
        steps: [
          'Step 1: Write equation F = ma',
          'Step 2: Isolate acceleration: a = F / m',
          'Step 3: Insert force in N and mass in kg'
        ]
      },
      5: {
        title: '5. Numerical Demonstration',
        problem: 'A net horizontal force of 24 N acts on a mass of 6 kg. What is the acceleration?',
        substitution: 'a = F / m = 24 N / 6 kg = 4 m/s²',
        answer: 'a = 4 m/s²'
      },
      6: {
        title: '6. Everyday Life Analogy',
        content: 'Pushing a light shopping cart vs a heavy truck: the lighter cart accelerates fast with a small push, while the truck requires immense force!'
      },
      7: {
        title: '7. Memory Aid & Mnemonic',
        mnemonic: '"Force Makes Acceleration (F = m × a)"',
        rule: 'Acceleration always points in the exact direction of the net unbalanced force.'
      },
      8: {
        title: '8. Exam Traps & Marking Criteria',
        traps: [
          'Trap 1: Forgetting to convert grams to kilograms before calculating.',
          'Trap 2: Forgetting that F is the NET force, not just any single applied force.'
        ],
        markingSteps: [
          '1 Mark: Formula a = F/m',
          '1 Mark: Unit check (kg and N)',
          '1 Mark: Correct answer with m/s²'
        ]
      },
      9: {
        title: '9. Active Understanding Check',
        question: 'If the net force on a body is zero, what is its acceleration?',
        hint: 'Apply F = ma when F = 0.',
        answer: 'Acceleration is zero! The body either remains at rest or continues moving with constant velocity (Newton’s 1st Law).'
      },
      10: {
        title: '10. Practice Problem',
        question: 'A rocket of mass 2000 kg experiences 36000 N thrust against 19600 N weight. Find acceleration.',
        solution: 'Net Force = 36000 - 19600 = 16400 N. a = 16400 / 2000 = 8.2 m/s².'
      }
    }
  },
  {
    id: 'ideal_gas_law',
    deckId: 'ideal_gas_deck',
    name: 'Ideal Gas Law',
    latex: "PV = nRT",
    subject: 'Chemistry / Physics',
    spokenForm: 'P V equals n R T, pressure times volume equals moles times R times temperature in Kelvin',
    steps: {
      1: {
        title: '1. Introduce & Contextualize',
        content: 'Equation of state relating pressure, volume, chemical quantity, and thermodynamic temperature for ideal gas particles.'
      },
      2: {
        title: '2. Symbol-by-Symbol Breakdown',
        symbols: [
          { symbol: 'P', meaning: 'Gas Pressure', unit: 'atm or Pascals (Pa)', dimensions: '[M L⁻¹ T⁻²]' },
          { symbol: 'V', meaning: 'Enclosed Volume', unit: 'Liters (L) or m³', dimensions: '[L³]' },
          { symbol: 'n', meaning: 'Moles of gas', unit: 'moles (mol)' },
          { symbol: 'R', meaning: 'Universal Gas Constant', unit: '0.0821 L·atm/(mol·K)' },
          { symbol: 'T', meaning: 'Absolute Temperature', unit: 'Kelvin (K)' }
        ]
      },
      3: {
        title: '3. Derivation & First Principles',
        content: 'Combines Boyle’s Law (V ∝ 1/P), Charles’s Law (V ∝ T), and Avogadro’s Law (V ∝ n).',
        keyProof: 'V \\propto \\frac{nT}{P} \\implies PV = nRT'
      },
      4: {
        title: '4. Algebraic Step-by-Step Anatomy',
        steps: [
          'Step 1: Write PV = nRT',
          'Step 2: Convert Celsius to Kelvin: T = °C + 273.15',
          'Step 3: Rearrange V = nRT / P'
        ]
      },
      5: {
        title: '5. Numerical Demonstration',
        problem: 'Find volume of 2 moles of gas at 300 K and 1 atm (R = 0.0821 L·atm/mol·K).',
        substitution: 'V = (2 × 0.0821 × 300) / 1.0 = 49.26 L',
        answer: 'V = 49.26 Liters'
      },
      6: {
        title: '6. Everyday Life Analogy',
        content: 'Pumping air into a bicycle tire on a hot day: heating the gas (T) increases pressure (P) until the tire explodes!'
      },
      7: {
        title: '7. Memory Aid & Mnemonic',
        mnemonic: '"PerVneRT (PV = nRT)"',
        rule: 'Temperature MUST be in Kelvin!'
      },
      8: {
        title: '8. Exam Traps & Marking Criteria',
        traps: ['Trap: Using Celsius temperature directly without adding 273!'],
        markingSteps: ['1 Mark: °C to K conversion', '1 Mark: PV=nRT substitution', '1 Mark: Volume with units']
      },
      9: {
        title: '9. Active Understanding Check',
        question: 'What is the molar volume of an ideal gas at STP (0°C, 1 atm)?',
        hint: 'Substitute n=1, T=273 K, P=1 atm in PV = nRT.',
        answer: 'Exactly 22.4 Liters per mole!'
      },
      10: {
        title: '10. Practice Problem',
        question: 'Calculate pressure when 3 moles occupy 10 L at 400 K.',
        solution: 'P = nRT / V = (3 × 0.0821 × 400) / 10 = 9.85 atm.'
      }
    }
  },
  {
    id: 'carnot_efficiency',
    deckId: 'carnot_engine_deck',
    name: 'Carnot Heat Engine Efficiency',
    latex: "\\eta = 1 - \\frac{T_C}{T_H} = \\frac{W}{Q_H}",
    subject: 'Thermodynamics',
    spokenForm: 'eta equals 1 minus T cold over T hot',
    steps: {
      1: {
        title: '1. Introduce & Contextualize',
        content: 'Upper theoretical limit of thermal efficiency for any heat engine operating between two temperatures.'
      },
      2: {
        title: '2. Symbol-by-Symbol Breakdown',
        symbols: [
          { symbol: 'η', meaning: 'Carnot Efficiency', unit: 'Fraction or %' },
          { symbol: 'T_H', meaning: 'Hot Reservoir Temperature', unit: 'Kelvin (K)' },
          { symbol: 'T_C', meaning: 'Cold Reservoir Temperature', unit: 'Kelvin (K)' }
        ]
      },
      3: {
        title: '3. Derivation & First Principles',
        content: 'From 2nd Law of Thermodynamics: Q_C/Q_H = T_C/T_H for reversible engine.',
        keyProof: '\\eta = \\frac{W}{Q_H} = \\frac{Q_H - Q_C}{Q_H} = 1 - \\frac{T_C}{T_H}'
      },
      4: {
        title: '4. Algebraic Step-by-Step Anatomy',
        steps: ['Step 1: Write η = 1 - T_C / T_H', 'Step 2: Convert reservoir temps to Kelvin', 'Step 3: Multiply result by 100%']
      },
      5: {
        title: '5. Numerical Demonstration',
        problem: 'Engine operates between 500 K and 300 K. Find max efficiency.',
        substitution: 'η = 1 - (300/500) = 1 - 0.6 = 0.40 = 40%',
        answer: 'Efficiency = 40%'
      },
      6: {
        title: '6. Everyday Life Analogy',
        content: 'A water wheel driven by water falling from height T_H to T_C: higher drop means more useful power.'
      },
      7: {
        title: '7. Memory Aid & Mnemonic',
        mnemonic: '"1 minus Cold over Hot"',
        rule: 'Cold sink is always in numerator!'
      },
      8: {
        title: '8. Exam Traps & Marking Criteria',
        traps: ['Trap: Swapping T_C and T_H! T_C must be smaller than T_H.'],
        markingSteps: ['1 Mark: Formula', '1 Mark: Kelvin check', '1 Mark: Percentage']
      },
      9: {
        title: '9. Active Understanding Check',
        question: 'Can efficiency ever reach 100%?',
        hint: 'What value of T_C would be required for 1 - T_C/T_H = 1?',
        answer: 'Only if T_C = 0 K (Absolute Zero), which is impossible according to the 3rd Law of Thermodynamics.'
      },
      10: {
        title: '10. Practice Problem',
        question: 'Find efficiency if hot reservoir is 600 K and cold is 150 K.',
        solution: 'η = 1 - 150/600 = 1 - 0.25 = 0.75 = 75%.'
      }
    }
  },
  {
    id: 'quadratic_formula',
    deckId: 'quadratic_formula_deck',
    name: 'Quadratic Formula & Discriminant',
    latex: "x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}",
    subject: 'Mathematics',
    spokenForm: 'x equals negative b plus or minus square root of b squared minus 4 a c, all over 2 a',
    steps: {
      1: {
        title: '1. Introduce & Contextualize',
        content: 'Solves any quadratic equation ax² + bx + c = 0 and classifies root nature via discriminant D = b² - 4ac.'
      },
      2: {
        title: '2. Symbol-by-Symbol Breakdown',
        symbols: [
          { symbol: 'a', meaning: 'x² coefficient (a ≠ 0)', unit: 'Constant' },
          { symbol: 'b', meaning: 'x coefficient', unit: 'Constant' },
          { symbol: 'c', meaning: 'Constant term', unit: 'Constant' },
          { symbol: 'D', meaning: 'Discriminant b² - 4ac', unit: 'Root indicator' }
        ]
      },
      3: {
        title: '3. Derivation & First Principles',
        content: 'Completing the square on ax² + bx + c = 0.',
        keyProof: 'a\\left(x + \\frac{b}{2a}\\right)^2 = \\frac{b^2 - 4ac}{4a} \\implies x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}'
      },
      4: {
        title: '4. Algebraic Step-by-Step Anatomy',
        steps: ['Step 1: Identify a, b, c', 'Step 2: Calculate D = b² - 4ac', 'Step 3: Evaluate x = (-b ± √D)/(2a)']
      },
      5: {
        title: '5. Numerical Demonstration',
        problem: 'Solve x² + 5x + 6 = 0.',
        substitution: 'a=1, b=5, c=6. D = 25 - 24 = 1. x = (-5 ± 1)/2',
        answer: 'x = -2 and x = -3'
      },
      6: {
        title: '6. Everyday Life Analogy',
        content: 'Calculating the landing point or flight path time of a thrown basketball projectile.'
      },
      7: {
        title: '7. Memory Aid & Mnemonic',
        mnemonic: '"Negative Boy Was Undecided (±) To Go To Radical Party (√)..."',
        rule: 'Check sign of b when forming -b!'
      },
      8: {
        title: '8. Exam Traps & Marking Criteria',
        traps: ['Trap: Forgetting sign of -b or dividing only √D by 2a instead of whole expression!'],
        markingSteps: ['1 Mark: D calculation', '1 Mark: Substitution', '1 Mark: Both roots']
      },
      9: {
        title: '9. Active Understanding Check',
        question: 'What happens when b² - 4ac = 0?',
        hint: 'What is √0?',
        answer: 'There is exactly ONE repeated real root: x = -b / (2a).'
      },
      10: {
        title: '10. Practice Problem',
        question: 'If roots of x² - 6x + k = 0 are equal, find k.',
        solution: 'Equal roots imply D = 0 -> 36 - 4k = 0 -> k = 9.'
      }
    }
  },
  {
    id: 'ohms_law',
    deckId: 'ohms_law_deck',
    name: "Ohm's Law & Circuit Resistance",
    latex: "V = IR",
    subject: 'Physics / Circuits',
    spokenForm: 'V equals I R, voltage equals current times resistance',
    steps: {
      1: {
        title: '1. Introduce & Contextualize',
        content: 'Fundamental linear relationship between potential difference, electric current, and circuit resistance.'
      },
      2: {
        title: '2. Symbol-by-Symbol Breakdown',
        symbols: [
          { symbol: 'V', meaning: 'Potential Difference', unit: 'Volts (V)' },
          { symbol: 'I', meaning: 'Electric Current', unit: 'Amperes (A)' },
          { symbol: 'R', meaning: 'Electrical Resistance', unit: 'Ohms (Ω)' }
        ]
      },
      3: {
        title: '3. Derivation & First Principles',
        content: 'Drift velocity relationship: I = n A e v_d = n A e (e E τ / m) -> V = I (m L / n A e² τ) = I R.',
        keyProof: 'V = I R'
      },
      4: {
        title: '4. Algebraic Step-by-Step Anatomy',
        steps: ['Step 1: Write V = IR', 'Step 2: Isolate target (R = V/I or I = V/R)', 'Step 3: Substitute SI units']
      },
      5: {
        title: '5. Numerical Demonstration',
        problem: 'Heater connected to 220 V draws 5 A. Find resistance.',
        substitution: 'R = V / I = 220 V / 5 A = 44 Ω',
        answer: 'R = 44 Ohms'
      },
      6: {
        title: '6. Everyday Life Analogy',
        content: 'Water pipe: Voltage is water pressure, current is flow rate, resistance is pipe narrowness.'
      },
      7: {
        title: '7. Memory Aid & Mnemonic',
        mnemonic: '"Vir (V = I × R)"',
        rule: 'Ohm’s law applies at constant physical conditions (temperature).'
      },
      8: {
        title: '8. Exam Traps & Marking Criteria',
        traps: ['Trap: Forgetting to check if current is in mA (must convert to A)!'],
        markingSteps: ['1 Mark: Formula R = V/I', '1 Mark: Unit conversion', '1 Mark: Answer in Ω']
      },
      9: {
        title: '9. Active Understanding Check',
        question: 'What is the slope of a V vs I graph for an ohmic resistor?',
        hint: 'Graph has V on vertical axis and I on horizontal axis.',
        answer: 'Slope = ΔV / ΔI = Resistance R!'
      },
      10: {
        title: '10. Practice Problem',
        question: 'Find current drawn by a 100 Ω resistor connected across 12 V battery.',
        solution: 'I = V / R = 12 / 100 = 0.12 Amperes (120 mA).'
      }
    }
  }
];

export const FORMULA_PRACTICE_LEVELS: Record<string, FormulaPracticeLevelItem[]> = {
  einstein_photoelectric: [
    {
      level: 1,
      levelName: 'Direct Substitution & Formula Familiarity (Easy)',
      badge: '🟢 Level 1: Foundation',
      question: 'Light of frequency ν = 1.0 × 10¹⁵ Hz falls on cesium with work function Φ₀ = 2.14 eV. Given h = 4.136 × 10⁻¹⁵ eV·s, calculate the maximum kinetic energy K_max of photoelectrons in eV.',
      formula: 'K_{\\max} = h\\nu - \\Phi_0',
      solution: 'Step 1: Calculate incident photon energy:\nE = hν = (4.136 × 10⁻¹⁵ eV·s) × (1.0 × 10¹⁵ s⁻¹) = 4.136 eV\nStep 2: Apply Einstein\'s equation:\nK_max = E - Φ₀ = 4.136 eV - 2.14 eV = 1.996 eV ≈ 2.00 eV',
      answer: 'K_max = 1.996 eV (or 2.00 eV)',
    },
    {
      level: 2,
      levelName: 'Variable Rearrangement & Unknown Isolation (Medium)',
      badge: '🟡 Level 2: Intermediate',
      question: 'A photosensitive surface has a threshold wavelength λ₀ = 500 nm. Calculate the threshold frequency ν₀ and the work function Φ₀ in eV (c = 3.0 × 10⁸ m/s, h = 6.626 × 10⁻³⁴ J·s).',
      formula: '\\nu_0 = \\frac{c}{\\lambda_0}, \\quad \\Phi_0 = h\\nu_0',
      solution: 'Step 1: Isolate ν₀ = c / λ₀:\nν₀ = (3.0 × 10⁸ m/s) / (500 × 10⁻⁹ m) = 6.0 × 10¹⁴ Hz\nStep 2: Work function in Joules:\nΦ₀ = hν₀ = (6.626 × 10⁻³⁴) × (6.0 × 10¹⁴) = 3.976 × 10⁻¹⁹ J\nStep 3: Convert to eV (divide by 1.6 × 10⁻¹⁹):\nΦ₀ = (3.976 × 10⁻¹⁹) / (1.602 × 10⁻¹⁹) = 2.48 eV',
      answer: 'ν₀ = 6.0 × 10¹⁴ Hz, Φ₀ = 2.48 eV',
    },
    {
      level: 3,
      levelName: 'Multi-Step Unit Conversions & Metric Traps (Hard)',
      badge: '🟠 Level 3: Advanced',
      question: 'Photoelectrons are emitted with maximum kinetic energy K_max = 1.6 eV. What is the maximum velocity v_max of these photoelectrons? (Electron mass m_e = 9.11 × 10⁻³¹ kg, 1 eV = 1.6 × 10⁻¹⁹ J).',
      formula: 'K_{\\max} = \\frac{1}{2} m_e v_{\\max}^2 \\implies v_{\\max} = \\sqrt{\\frac{2 K_{\\max}}{m_e}}',
      solution: 'Step 1: TRAP ALERT - Convert eV to Joules first:\nK_max = 1.6 eV × (1.602 × 10⁻¹⁹ J/eV) = 2.563 × 10⁻¹⁹ J\nStep 2: Isolate velocity:\nv_max = √(2 × 2.563 × 10⁻¹⁹ / 9.11 × 10⁻³¹) = √(5.627 × 10¹¹)\nv_max = 7.50 × 10⁵ m/s (750 km/s)',
      answer: 'v_max = 7.50 × 10⁵ m/s',
    },
    {
      level: 4,
      levelName: 'Physical Constraints & Real-World Application (Advanced)',
      badge: '🔴 Level 4: Board Standard',
      question: 'Ultraviolet light of wavelength λ = 300 nm irradiates a metal surface. The stopping potential needed to halt all photoelectrons is measured to be V₀ = 1.85 V. Find the work function Φ₀ of the metal in eV (hc = 1240 eV·nm).',
      formula: 'e V_0 = \\frac{hc}{\\lambda} - \\Phi_0 \\implies \\Phi_0 = \\frac{hc}{\\lambda} - e V_0',
      solution: 'Step 1: Incident photon energy:\nE = hc / λ = (1240 eV·nm) / (300 nm) = 4.133 eV\nStep 2: Maximum kinetic energy equals e × V₀:\nK_max = 1.85 eV\nStep 3: Solve for work function:\nΦ₀ = E - K_max = 4.133 eV - 1.85 eV = 2.28 eV',
      answer: 'Φ₀ = 2.28 eV',
    },
    {
      level: 5,
      levelName: 'Competitive & Board Exam Level Challenge (Mastery)',
      badge: '🟣 Level 5: NEET / JEE Ranker',
      question: 'In a photoelectric experiment, stopping potential V₀ is plotted against incident frequency ν. The line passes through (6.0 × 10¹⁴ Hz, 0.40 V) and (10.0 × 10¹⁴ Hz, 2.05 V). From this experimental slope, calculate the experimental value of Planck\'s constant h.',
      formula: 'V_0 = \\left(\\frac{h}{e}\\right)\\nu - \\frac{\\Phi_0}{e} \\implies \\text{Slope } s = \\frac{\\Delta V_0}{\\Delta \\nu} = \\frac{h}{e}',
      solution: 'Step 1: Calculate experimental slope:\nSlope s = (2.05 V - 0.40 V) / (10.0 × 10¹⁴ - 6.0 × 10¹⁴ Hz) = 1.65 / (4.0 × 10¹⁴) = 4.125 × 10⁻¹⁵ V·s\nStep 2: Isolate h = s × e:\nh = (4.125 × 10⁻¹⁵ V·s) × (1.602 × 10⁻¹⁹ C) = 6.608 × 10⁻³⁴ J·s\nStep 3: Compare with standard (6.626 × 10⁻³⁴ J·s) → Within 0.27% experimental error!',
      answer: 'h = 6.61 × 10⁻³⁴ J·s (Slope s = h/e = 4.13 × 10⁻¹⁵ V·s)',
    },
  ],
  newton_second_law: [
    {
      level: 1,
      levelName: 'Direct Substitution & Formula Familiarity (Easy)',
      badge: '🟢 Level 1: Foundation',
      question: 'A racecar with total mass m = 1200 kg is accelerated down a straight track by a net forward engine thrust of F = 4800 N. Calculate its acceleration a.',
      formula: 'F_{\\text{net}} = m a \\implies a = \\frac{F}{m}',
      solution: 'Step 1: Identify given variables: F = 4800 N, m = 1200 kg.\nStep 2: Direct formula substitution: a = 4800 N / 1200 kg = 4.0 m/s².',
      answer: 'a = 4.0 m/s²',
    },
    {
      level: 2,
      levelName: 'Variable Rearrangement & Unknown Isolation (Medium)',
      badge: '🟡 Level 2: Intermediate',
      question: 'A spacecraft thruster delivers a constant force of 1500 N, accelerating an unknown probe mass from rest to 30 m/s over 10 seconds. Determine the mass of the probe.',
      formula: 'a = \\frac{\\Delta v}{\\Delta t}, \\quad m = \\frac{F}{a}',
      solution: 'Step 1: Calculate acceleration a = (30 - 0) / 10 = 3.0 m/s².\nStep 2: Rearrange Newton\'s 2nd Law for mass: m = F / a.\nStep 3: Substitute: m = 1500 N / 3.0 m/s² = 500 kg.',
      answer: 'm = 500 kg',
    },
    {
      level: 3,
      levelName: 'Multi-Step Unit Conversions & Metric Traps (Hard)',
      badge: '🟠 Level 3: Advanced',
      question: 'A 25 kg delivery box is pushed across a rough warehouse floor with horizontal force F = 95 N. The coefficient of kinetic friction is μ_k = 0.30. Find the acceleration (g = 9.8 m/s²).',
      formula: 'F_{\\text{net}} = F_{\\text{applied}} - \\mu_k m g = m a',
      solution: 'Step 1: Normal force N = mg = 25 kg × 9.8 m/s² = 245 N.\nStep 2: Friction force f_k = μ_k N = 0.30 × 245 N = 73.5 N.\nStep 3: Net force = 95 N - 73.5 N = 21.5 N.\nStep 4: Acceleration a = F_net / m = 21.5 N / 25 kg = 0.86 m/s².',
      answer: 'a = 0.86 m/s²',
    },
    {
      level: 4,
      levelName: 'Physical Constraints & Real-World Application (Advanced)',
      badge: '🔴 Level 4: Board Standard',
      question: 'Atwood Machine: Two masses m₁ = 3.0 kg and m₂ = 5.0 kg hang over a frictionless, massless pulley. Find the common acceleration of the system and string tension T (g = 9.8 m/s²).',
      formula: 'a = \\frac{(m_2 - m_1)g}{m_1 + m_2}, \\quad T = \\frac{2 m_1 m_2 g}{m_1 + m_2}',
      solution: 'Step 1: Net driving force = (m₂ - m₁)g = (5.0 - 3.0)(9.8) = 19.6 N.\nStep 2: Total inertia = m₁ + m₂ = 8.0 kg.\nStep 3: a = 19.6 / 8.0 = 2.45 m/s².\nStep 4: Tension T = m₁(g + a) = 3.0(9.8 + 2.45) = 36.75 N.',
      answer: 'a = 2.45 m/s², T = 36.75 N',
    },
    {
      level: 5,
      levelName: 'Competitive & Board Exam Level Challenge (Mastery)',
      badge: '🟣 Level 5: NEET / JEE Ranker',
      question: 'A research rocket has initial launch mass m₀ = 4000 kg. Fuel is consumed and ejected at rate dm/dt = 40 kg/s with exhaust speed relative to rocket u = 1500 m/s. Calculate the upward thrust force and the net upward acceleration at t = 0 (g = 9.8 m/s²).',
      formula: 'F_{\\text{thrust}} = u \\frac{dm}{dt}, \\quad a_{\\text{net}} = \\frac{F_{\\text{thrust}} - m g}{m}',
      solution: 'Step 1: Calculate thrust: F_thrust = u (dm/dt) = 1500 m/s × 40 kg/s = 60,000 N.\nStep 2: Initial weight W₀ = m₀ g = 4000 kg × 9.8 m/s² = 39,200 N.\nStep 3: Net force at t = 0: F_net = 60,000 N - 39,200 N = 20,800 N.\nStep 4: Acceleration: a = 20,800 N / 4000 kg = 5.20 m/s².',
      answer: 'Thrust = 60,000 N (60 kN), a = 5.20 m/s²',
    },
  ],
  ideal_gas_law: [
    {
      level: 1,
      levelName: 'Direct Substitution & Formula Familiarity (Easy)',
      badge: '🟢 Level 1: Foundation',
      question: 'Calculate the pressure exerted by 2.0 moles of argon gas held inside a rigid 0.050 m³ chamber at temperature T = 300 K (Universal gas constant R = 8.314 J/(mol·K)).',
      formula: 'P V = n R T \\implies P = \\frac{n R T}{V}',
      solution: 'Step 1: Given: n = 2.0 mol, R = 8.314 J/(mol·K), T = 300 K, V = 0.050 m³.\nStep 2: P = (2.0 × 8.314 × 300) / 0.050 = 4988.4 / 0.050 = 99,768 Pa ≈ 99.8 kPa.',
      answer: 'P = 99.8 kPa (0.985 atm)',
    },
    {
      level: 2,
      levelName: 'Variable Rearrangement & Unknown Isolation (Medium)',
      badge: '🟡 Level 2: Intermediate',
      question: 'Determine the molar volume of an ideal gas at standard STP conditions (P = 1.013 × 10⁵ Pa, T = 273.15 K, R = 8.314 J/(mol·K)). Express your answer in Liters.',
      formula: 'V_{\\text{molar}} = \\frac{R T}{P}',
      solution: 'Step 1: Isolate V = RT / P for n = 1 mole.\nStep 2: V = (8.314 × 273.15) / (1.013 × 10⁵) = 2270.97 / 101,300 = 0.022414 m³.\nStep 3: Multiply by 1000 L/m³: V = 22.414 Liters.',
      answer: 'V_molar = 22.414 L',
    },
    {
      level: 3,
      levelName: 'Multi-Step Unit Conversions & Metric Traps (Hard)',
      badge: '🟠 Level 3: Advanced',
      question: 'A 5.0 Liter sealed flask holds a gas sample at pressure P = 2.4 atm and temperature T = 27°C. Find the number of moles n. (Trap: Convert atm to Pa or use R = 0.0821 L·atm/(mol·K)).',
      formula: 'n = \\frac{P V}{R T}',
      solution: 'Step 1: TRAP ALERT - Convert Celsius to Kelvin: T = 27 + 273.15 = 300.15 K.\nStep 2: Using gas constant in L·atm: R = 0.08206 L·atm/(mol·K).\nStep 3: n = (2.4 atm × 5.0 L) / (0.08206 × 300.15) = 12.0 / 24.63 = 0.487 moles.',
      answer: 'n = 0.487 moles',
    },
    {
      level: 4,
      levelName: 'Physical Constraints & Real-World Application (Advanced)',
      badge: '🔴 Level 4: Board Standard',
      question: 'Combined Gas Law: A weather balloon has volume V₁ = 12.0 m³ at ground level where P₁ = 1.0 atm and T₁ = 20°C (293 K). High in the troposphere, P₂ = 0.35 atm and T₂ = -45°C (228 K). Find the expanded volume V₂.',
      formula: '\\frac{P_1 V_1}{T_1} = \\frac{P_2 V_2}{T_2} \\implies V_2 = V_1 \\left(\\frac{P_1}{P_2}\\right) \\left(\\frac{T_2}{T_1}\\right)',
      solution: 'Step 1: Pressure ratio: P₁ / P₂ = 1.0 / 0.35 = 2.857.\nStep 2: Absolute temperature ratio: T₂ / T₁ = 228 K / 293 K = 0.778.\nStep 3: V₂ = 12.0 m³ × 2.857 × 0.778 = 26.68 m³.',
      answer: 'V₂ = 26.7 m³',
    },
    {
      level: 5,
      levelName: 'Competitive & Board Exam Level Challenge (Mastery)',
      badge: '🟣 Level 5: NEET / JEE Ranker',
      question: 'A 10.0 L rigid cylinder contains a mixture of 28.0 g of Nitrogen gas (N₂, molar mass = 28 g/mol) and 64.0 g of Oxygen gas (O₂, molar mass = 32 g/mol) at 300 K. Compute the total pressure and partial pressure of Oxygen.',
      formula: 'n_{\\text{total}} = n_{N_2} + n_{O_2}, \\quad P_{\\text{total}} = \\frac{n_{\\text{total}} R T}{V}, \\quad P_{O_2} = X_{O_2} P_{\\text{total}}',
      solution: 'Step 1: Moles: n(N₂) = 28/28 = 1.0 mol; n(O₂) = 64/32 = 2.0 mol → n_total = 3.0 mol.\nStep 2: P_total = (3.0 mol × 0.08206 L·atm/(mol·K) × 300 K) / 10.0 L = 73.85 / 10 = 7.39 atm (748.4 kPa).\nStep 3: Mole fraction of O₂ = 2.0 / 3.0 = 2/3.\nStep 4: Partial pressure P(O₂) = (2/3) × 7.39 atm = 4.92 atm (499 kPa).',
      answer: 'P_total = 7.39 atm, P(O₂) = 4.92 atm',
    },
  ],
  carnot_efficiency: [
    {
      level: 1,
      levelName: 'Direct Substitution & Formula Familiarity (Easy)',
      badge: '🟢 Level 1: Foundation',
      question: 'A reversible heat engine operates between hot reservoir T_H = 600 K and cold reservoir T_C = 300 K. Calculate its theoretical Carnot efficiency η.',
      formula: '\\eta = 1 - \\frac{T_C}{T_H}',
      solution: 'Step 1: Given T_H = 600 K, T_C = 300 K.\nStep 2: η = 1 - (300 / 600) = 1 - 0.50 = 0.50 (50%).',
      answer: 'η = 0.50 (50%)',
    },
    {
      level: 2,
      levelName: 'Variable Rearrangement & Unknown Isolation (Medium)',
      badge: '🟡 Level 2: Intermediate',
      question: 'A Carnot engine has efficiency η = 0.40 and absorbs Q_H = 3000 J of thermal energy per cycle from the furnace. How much mechanical work W does it deliver per cycle?',
      formula: 'W = \\eta \\cdot Q_H',
      solution: 'Step 1: W = 0.40 × 3000 J = 1200 J.\nStep 2: Heat rejected to sink = Q_H - W = 3000 - 1200 = 1800 J.',
      answer: 'W = 1200 Joules',
    },
    {
      level: 3,
      levelName: 'Multi-Step Unit Conversions & Metric Traps (Hard)',
      badge: '🟠 Level 3: Advanced',
      question: 'A steam turbine is claimed to operate between steam at 227°C and condenser river water at 27°C with an efficiency of 45%. Prove whether this claim violates the Second Law of Thermodynamics.',
      formula: '\\eta_{\\max} = 1 - \\frac{T_C}{T_H}',
      solution: 'Step 1: TRAP ALERT - Convert to Kelvin:\nT_H = 227 + 273 = 500 K; T_C = 27 + 273 = 300 K.\nStep 2: Maximum theoretical Carnot efficiency:\nη_max = 1 - (300 / 500) = 1 - 0.60 = 0.40 (40%).\nStep 3: Conclusion: A claimed efficiency of 45% exceeds the absolute theoretical maximum of 40%, making it physically impossible and a violation of the 2nd Law of Thermodynamics!',
      answer: 'Impossible (Max η = 40% < Claimed 45%)',
    },
    {
      level: 4,
      levelName: 'Physical Constraints & Real-World Application (Advanced)',
      badge: '🔴 Level 4: Board Standard',
      question: 'A domestic Carnot heat pump maintains an indoor temperature of 21°C (294 K) when outside temperature is -3°C (270 K). If it consumes 1.5 kW of electrical power, what is the maximum heating rate delivered indoors?',
      formula: 'COP_{\\text{heating}} = \\frac{T_H}{T_H - T_C}, \\quad \\dot{Q}_H = COP \\times \\dot{W}',
      solution: 'Step 1: COP = 294 / (294 - 270) = 294 / 24 = 12.25.\nStep 2: Delivered thermal power:\nQ_H = 12.25 × 1.5 kW = 18.375 kW.',
      answer: 'Delivered Heating = 18.38 kW (COP = 12.25)',
    },
    {
      level: 5,
      levelName: 'Competitive & Board Exam Level Challenge (Mastery)',
      badge: '🟣 Level 5: NEET / JEE Ranker',
      question: 'Two Carnot engines A and B operate in series: Engine A receives heat at T₁ and rejects to reservoir at T₂; Engine B receives the rejected heat at T₂ and exhausts to sink at T₃. If both engines produce equal amounts of mechanical work (W_A = W_B), derive T₂ in terms of T₁ and T₃.',
      formula: 'W_A = Q_1 \\left(1 - \\frac{T_2}{T_1}\\right), \\quad W_B = Q_2 \\left(1 - \\frac{T_3}{T_2}\\right) = Q_1 \\left(\\frac{T_2}{T_1}\\right) \\left(1 - \\frac{T_3}{T_2}\\right)',
      solution: 'Step 1: Set W_A = W_B:\n1 - T₂/T₁ = (T₂/T₁) - (T₃/T₁).\nStep 2: Multiply both sides by T₁:\nT₁ - T₂ = T₂ - T₃.\nStep 3: Rearrange: 2 T₂ = T₁ + T₃ ⟹ T₂ = (T₁ + T₃) / 2 (Arithmetic Mean!).',
      answer: 'T₂ = (T₁ + T₃) / 2',
    },
  ],
  quadratic_formula: [
    {
      level: 1,
      levelName: 'Direct Substitution & Formula Familiarity (Easy)',
      badge: '🟢 Level 1: Foundation',
      question: 'Find the real roots of the quadratic equation x² - 5x + 6 = 0 using the quadratic formula.',
      formula: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}',
      solution: 'Step 1: Coefficients: a = 1, b = -5, c = 6.\nStep 2: Discriminant D = (-5)² - 4(1)(6) = 25 - 24 = 1.\nStep 3: Roots: x = (-(-5) ± √1) / (2 × 1) = (5 ± 1) / 2.\nx₁ = 6/2 = 3, x₂ = 4/2 = 2.',
      answer: 'x = 3, x = 2',
    },
    {
      level: 2,
      levelName: 'Variable Rearrangement & Unknown Isolation (Medium)',
      badge: '🟡 Level 2: Intermediate',
      question: 'Analyze the discriminant D of 2x² - 4x + 5 = 0 and determine the nature of its roots.',
      formula: 'D = b^2 - 4ac',
      solution: 'Step 1: a = 2, b = -4, c = 5.\nStep 2: D = (-4)² - 4(2)(5) = 16 - 40 = -24.\nStep 3: Since D < 0, there are no real roots. The roots are two complex conjugates: x = (4 ± 2i√6)/4 = 1 ± (i√6)/2.',
      answer: 'D = -24 < 0 (Two complex conjugate roots)',
    },
    {
      level: 3,
      levelName: 'Multi-Step Unit Conversions & Metric Traps (Hard)',
      badge: '🟠 Level 3: Advanced',
      question: 'Solve the equation: (1/3)x² - (5/6)x + (1/2) = 0. Clear all fractions before applying the formula.',
      formula: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}',
      solution: 'Step 1: Multiply entire equation by LCD = 6:\n2x² - 5x + 3 = 0.\nStep 2: a = 2, b = -5, c = 3.\nStep 3: D = (-5)² - 4(2)(3) = 25 - 24 = 1.\nStep 4: x = (5 ± 1) / (2 × 2) = (5 ± 1) / 4.\nx₁ = 6/4 = 3/2 (1.5), x₂ = 4/4 = 1.',
      answer: 'x = 3/2, x = 1',
    },
    {
      level: 4,
      levelName: 'Physical Constraints & Real-World Application (Advanced)',
      badge: '🔴 Level 4: Board Standard',
      question: 'A ball is launched vertically upward with trajectory h(t) = -4.9t² + 19.6t + 2.0 (height in meters, time in seconds). At what time does it hit the ground (h = 0)? Discard non-physical negative time.',
      formula: '-4.9 t^2 + 19.6 t + 2.0 = 0',
      solution: 'Step 1: a = -4.9, b = 19.6, c = 2.0.\nStep 2: D = (19.6)² - 4(-4.9)(2.0) = 384.16 + 39.2 = 423.36.\n√D = 20.575.\nStep 3: t = (-19.6 ± 20.575) / (2 × -4.9) = (-19.6 ± 20.575) / (-9.8).\nt₁ = (-19.6 - 20.575) / -9.8 = -40.175 / -9.8 = +4.10 seconds.\nt₂ = (-19.6 + 20.575) / -9.8 = -0.10 seconds (discard negative time).',
      answer: 't = 4.10 seconds',
    },
    {
      level: 5,
      levelName: 'Competitive & Board Exam Level Challenge (Mastery)',
      badge: '🟣 Level 5: NEET / JEE Ranker',
      question: 'Find all values of the parameter k such that the quadratic equation (k - 1)x² + 2kx + (k + 2) = 0 has real and equal roots.',
      formula: 'D = b^2 - 4ac = 0, \\quad k - 1 \\neq 0',
      solution: 'Step 1: Quadratic condition: a = k - 1 ≠ 0 ⟹ k ≠ 1.\nStep 2: Condition for equal roots: D = 0.\nD = (2k)² - 4(k - 1)(k + 2) = 0\n4k² - 4(k² + k - 2) = 0\n4k² - 4k² - 4k + 8 = 0\n-4k + 8 = 0 ⟹ 4k = 8 ⟹ k = 2.\nStep 3: Verify: for k = 2, equation becomes x² + 4x + 4 = 0 ⟹ (x + 2)² = 0, root x = -2.',
      answer: 'k = 2 (Root x = -2)',
    },
  ],
  ohms_law: [
    {
      level: 1,
      levelName: 'Direct Substitution & Formula Familiarity (Easy)',
      badge: '🟢 Level 1: Foundation',
      question: 'An electric toaster with heating element resistance R = 44 Ω draws a steady current of I = 5.0 A. Calculate the voltage drop V across the toaster.',
      formula: 'V = I R',
      solution: 'Step 1: Given: I = 5.0 A, R = 44 Ω.\nStep 2: V = 5.0 A × 44 Ω = 220 Volts.',
      answer: 'V = 220 Volts',
    },
    {
      level: 2,
      levelName: 'Variable Rearrangement & Unknown Isolation (Medium)',
      badge: '🟡 Level 2: Intermediate',
      question: 'A portable DC fan operates from a 12.0 V battery and draws 0.75 A of current. What is the internal resistance of the fan?',
      formula: 'R = \\frac{V}{I}',
      solution: 'Step 1: Isolate R = V / I.\nStep 2: R = 12.0 V / 0.75 A = 16.0 Ω.',
      answer: 'R = 16.0 Ω',
    },
    {
      level: 3,
      levelName: 'Multi-Step Unit Conversions & Metric Traps (Hard)',
      badge: '🟠 Level 3: Advanced',
      question: 'A circuit micro-sensor operates at 3.3 V and draws a current of 25 mA. Calculate its effective resistance in Ohms and kilo-Ohms (Trap: Convert mA to A).',
      formula: 'R = \\frac{V}{I}',
      solution: 'Step 1: TRAP ALERT - Convert mA to A: I = 25 mA = 25 × 10⁻³ A = 0.025 A.\nStep 2: R = 3.3 V / 0.025 A = 132 Ω.\nStep 3: In kΩ: R = 0.132 kΩ.',
      answer: 'R = 132 Ω (0.132 kΩ)',
    },
    {
      level: 4,
      levelName: 'Physical Constraints & Real-World Application (Advanced)',
      badge: '🔴 Level 4: Board Standard',
      question: 'A cylindrical copper power cable is 250 m long with cross-sectional area A = 2.5 mm². Given resistivity of copper ρ = 1.72 × 10⁻⁸ Ω·m, find the total cable resistance and voltage drop when carrying 15 A.',
      formula: 'R = \\rho \\frac{L}{A}, \\quad V_{\\text{drop}} = I R',
      solution: 'Step 1: Convert area to m²: A = 2.5 mm² = 2.5 × 10⁻⁶ m².\nStep 2: R = (1.72 × 10⁻⁸ Ω·m × 250 m) / (2.5 × 10⁻⁶ m²) = 4.3 × 10⁻⁶ / 2.5 × 10⁻⁶ = 1.72 Ω.\nStep 3: Voltage drop: V_drop = 15 A × 1.72 Ω = 25.8 Volts.',
      answer: 'R = 1.72 Ω, V_drop = 25.8 V',
    },
    {
      level: 5,
      levelName: 'Competitive & Board Exam Level Challenge (Mastery)',
      badge: '🟣 Level 5: NEET / JEE Ranker',
      question: 'A tungsten filament lamp has resistance R₀ = 25 Ω at room temperature T₀ = 20°C. When plugged into 230 V mains, it draws 0.92 A at steady white heat. Calculate the filament operating temperature (Temperature coefficient of resistance of tungsten α = 0.0045 °C⁻¹).',
      formula: 'R(T) = \\frac{V}{I} = R_0 [1 + \\alpha (T - T_0)] \\implies T = T_0 + \\frac{R/R_0 - 1}{\\alpha}',
      solution: 'Step 1: Operating resistance: R = 230 V / 0.92 A = 250 Ω.\nStep 2: Resistance ratio: R / R₀ = 250 / 25 = 10.0.\nStep 3: Temperature increase:\nΔT = (10.0 - 1) / 0.0045 = 9 / 0.0045 = 2000°C.\nStep 4: Operating temperature:\nT = T₀ + ΔT = 20°C + 2000°C = 2020°C (2293 K).',
      answer: 'T = 2020°C (2293 K)',
    },
  ],
};

interface FormulaTeachingModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeFormulaId?: string;
  activeTopic?: string;
  subject?: string;
  onSpeak?: (text: string) => void;
  showNotification?: (msg: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export const FormulaTeachingModal: React.FC<FormulaTeachingModalProps> = ({
  isOpen,
  onClose,
  activeFormulaId,
  activeTopic,
  onSpeak,
  showNotification
}) => {
  const [selectedFormulaId, setSelectedFormulaId] = useState<string>(
    activeFormulaId || SAMPLE_FORMULAS[0].id
  );
  const [activeStepTab, setActiveStepTab] = useState<number>(1);
  const [activeMainMode, setActiveMainMode] = useState<'pedagogy' | 'practice_engine'>('pedagogy');
  const [revealedHint, setRevealedHint] = useState<boolean>(false);
  const [revealedAnswer, setRevealedAnswer] = useState<boolean>(false);
  const [expandedPracticeLevel, setExpandedPracticeLevel] = useState<number | null>(1);

  useEffect(() => {
    if (isOpen && activeFormulaId) {
      const match = SAMPLE_FORMULAS.find(f => f.id === activeFormulaId);
      if (match) {
        setSelectedFormulaId(match.id);
      }
    }
  }, [isOpen, activeFormulaId]);

  if (!isOpen) return null;

  const currentFormula = SAMPLE_FORMULAS.find(f => f.id === selectedFormulaId) || SAMPLE_FORMULAS[0];
  const steps = currentFormula.steps;
  const targetDeckId = currentFormula.deckId || currentFormula.id;
  const practiceQuestionsList = FORMULA_PRACTICE_LEVELS[currentFormula.id] || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-5xl max-h-[94vh] bg-slate-900 border-2 border-indigo-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/90 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-600 flex items-center justify-center text-xl shadow-lg shrink-0">
              <Calculator size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-base sm:text-xl font-black text-white flex flex-wrap items-center gap-2">
                10-Step Formula Mastery & Practice Engine
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Active Pedagogy
                </span>
                {activeTopic && (
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-bold">
                    Chapter: {activeTopic}
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-400">
                Stepwise derivation, active pedagogy explanation, and multi-level practice questions
              </p>
            </div>
          </div>

          {/* Mode Selector Toggle */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-2xl p-1 gap-1 flex-wrap">
            <button
              onClick={() => setActiveMainMode('pedagogy')}
              className={cn(
                "px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer",
                activeMainMode === 'pedagogy'
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-950"
                  : "text-slate-400 hover:text-slate-200"
              )}
            >
              <BookOpen size={14} />
              <span>📖 10-Step Pedagogy</span>
            </button>
            <button
              onClick={() => setActiveMainMode('practice_engine')}
              className={cn(
                "px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer",
                activeMainMode === 'practice_engine'
                  ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md font-black shadow-emerald-950"
                  : "text-emerald-400 hover:bg-emerald-500/10"
              )}
            >
              <Target size={14} />
              <span>🎯 Practice (5 Levels & Slides)</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
          >
            <X size={20} />
          </button>
        </div>

        {/* Formula Selection Pill Bar */}
        <div className="p-3 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between gap-2 overflow-x-auto">
          <div className="flex items-center gap-2 shrink-0">
            {SAMPLE_FORMULAS.map((f) => {
              return (
                <button
                  key={f.id}
                  onClick={() => {
                    setSelectedFormulaId(f.id);
                    setActiveStepTab(1);
                    setRevealedHint(false);
                    setRevealedAnswer(false);
                  }}
                  className={cn(
                    "px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5",
                    selectedFormulaId === f.id
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-950"
                      : "bg-slate-800/80 text-slate-300 hover:bg-slate-700"
                  )}
                >
                  <span>{f.name}</span>
                  <span className="text-[10px] opacity-75">({f.subject})</span>
                </button>
              );
            })}
          </div>

          <button
            onClick={() => onSpeak?.(currentFormula.spokenForm)}
            className="px-3 py-1 rounded-xl bg-cyan-600/30 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-600/50 text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer"
            title="Hear natural spoken formula pronunciation"
          >
            <Volume2 size={13} />
            <span>Hear Spoken Formula</span>
          </button>
        </div>

        {/* Big Formula Display Hero Banner */}
        <div className="p-3.5 bg-slate-950 border-b border-slate-800 text-center flex items-center justify-between px-6 flex-wrap gap-2">
          <div className="text-left">
            <div className="font-mono text-base sm:text-xl font-black text-amber-300 tracking-wide">
              {currentFormula.latex}
            </div>
            <p className="text-xs text-slate-400 italic mt-0.5">
              🗣️ Spoken: "{currentFormula.spokenForm}"
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveMainMode('practice_engine')}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 hover:scale-105 transition-all cursor-pointer"
            >
              <Zap size={14} className="fill-slate-950" />
              <span>🎯 5-Level Practice & Slides</span>
            </button>
          </div>
        </div>

        {/* Content Mode Display */}
        {activeMainMode === 'practice_engine' ? (
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-slate-950 space-y-5">
            <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-teal-950/40 to-slate-950 border border-emerald-500/30 flex flex-wrap items-center justify-between gap-3 text-xs text-emerald-200">
              <div className="flex items-center gap-2">
                <Target className="text-emerald-400 shrink-0" size={18} />
                <span><strong>5 Progressive Adaptive Practice Levels for {currentFormula.name}:</strong> Transition naturally from direct substitution to competitive Olympiad and board challenges.</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveMainMode('pedagogy')}
                  className="px-3 py-1 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 hover:bg-slate-800 text-xs font-bold transition-all cursor-pointer"
                >
                  ← 10-Step Pedagogy
                </button>
              </div>
            </div>

            {/* 5 Topic-Specific Practice Question Cards */}
            <div className="space-y-3">
              <h3 className="text-sm font-black text-emerald-300 flex items-center gap-2">
                <Trophy size={16} />
                <span>Adaptive Multi-Level Question Suite ({currentFormula.name})</span>
              </h3>

              <div className="space-y-3">
                {practiceQuestionsList.map((pq) => {
                  const isExpanded = expandedPracticeLevel === pq.level;
                  return (
                    <div
                      key={pq.level}
                      className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 transition-all space-y-2.5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 font-extrabold border border-emerald-500/30">
                            {pq.badge}
                          </span>
                          <span className="text-xs text-slate-400 font-semibold">{pq.levelName}</span>
                        </div>
                        <button
                          onClick={() => setExpandedPracticeLevel(isExpanded ? null : pq.level)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-bold flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <span>{isExpanded ? 'Hide Solution' : 'Show Step-by-Step Solution'}</span>
                          {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                        </button>
                      </div>

                      <p className="text-sm text-slate-100 font-medium leading-relaxed">
                        {pq.question}
                      </p>

                      <div className="text-xs text-amber-300/90 font-mono bg-slate-950/60 px-3 py-1.5 rounded-xl border border-amber-500/20">
                        Governing Formula: {pq.formula}
                      </div>

                      {isExpanded && (
                        <div className="pt-2 border-t border-slate-800/80 space-y-2 animate-fadeIn">
                          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                            Step-by-Step Derivation & Solution:
                          </div>
                          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 whitespace-pre-line font-mono leading-relaxed">
                            {pq.solution}
                          </div>
                          <div className="p-2.5 bg-emerald-950/50 border border-emerald-500/40 rounded-xl text-xs font-bold text-emerald-300 flex items-center gap-2">
                            <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                            <span>Verified Answer: {pq.answer}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Visual Presentation Architect Interactive Deck */}
            <div className="pt-4 border-t border-slate-800/80">
              <div className="mb-2 text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Sparkles size={14} className="text-cyan-400" />
                <span>Interactive Visual Practice Stage & Slides:</span>
              </div>
              <SmartboardVisualPresentationArchitect
                initialDeckId={targetDeckId}
                isCompactOverlay={true}
                onSpeak={onSpeak}
                showNotification={showNotification}
              />
            </div>
          </div>
        ) : (
          <>
            {/* 10 Step Navigation Pills */}
            <div className="px-4 py-2 bg-slate-900/90 border-b border-slate-800 overflow-x-auto flex items-center gap-1.5">
              {[
                { step: 1, label: '1. Context' },
                { step: 2, label: '2. Symbols' },
                { step: 3, label: '3. Derivation' },
                { step: 4, label: '4. Anatomy' },
                { step: 5, label: '5. Demo' },
                { step: 6, label: '6. Analogy' },
                { step: 7, label: '7. Mnemonic' },
                { step: 8, label: '8. Exam Traps' },
                { step: 9, label: '9. Quick Check' },
                { step: 10, label: '10. Practice' }
              ].map((s) => (
                <button
                  key={s.step}
                  onClick={() => setActiveStepTab(s.step)}
                  className={cn(
                    "px-2.5 py-1 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer",
                    activeStepTab === s.step
                      ? "bg-amber-500 text-slate-950 shadow"
                      : "bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-800"
                  )}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* Main Step Content Area */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
              {activeStepTab === 1 && (
                <div className="space-y-3">
                  <h3 className="text-base font-black text-amber-300 flex items-center gap-2">
                    <Sparkles size={18} />
                    {steps[1].title}
                  </h3>
                  <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 text-slate-200 leading-relaxed text-sm">
                    {steps[1].content}
                  </div>
                </div>
              )}

              {activeStepTab === 2 && (
                <div className="space-y-3">
                  <h3 className="text-base font-black text-cyan-300 flex items-center gap-2">
                    <BookOpen size={18} />
                    {steps[2].title}
                  </h3>
                  <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-950/80">
                    <table className="w-full text-left border-collapse text-xs sm:text-sm">
                      <thead className="bg-slate-900 text-cyan-300 font-bold border-b border-slate-800">
                        <tr>
                          <th className="p-3">Symbol</th>
                          <th className="p-3">Scientific Meaning</th>
                          <th className="p-3">Standard SI Unit</th>
                          {steps[2].symbols[0]?.dimensions && <th className="p-3">Dimensions</th>}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-slate-200 font-medium">
                        {steps[2].symbols.map((sym, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/50">
                            <td className="p-3 font-mono font-bold text-amber-300">{sym.symbol}</td>
                            <td className="p-3">{sym.meaning}</td>
                            <td className="p-3 text-emerald-300 font-mono">{sym.unit}</td>
                            {sym.dimensions && <td className="p-3 text-slate-400 font-mono">{sym.dimensions}</td>}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeStepTab === 3 && (
                <div className="space-y-3">
                  <h3 className="text-base font-black text-indigo-300 flex items-center gap-2">
                    <Lightbulb size={18} />
                    {steps[3].title}
                  </h3>
                  <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 text-slate-200 leading-relaxed text-sm space-y-2">
                    <p>{steps[3].content}</p>
                    <div className="p-3 bg-indigo-950/40 rounded-xl border border-indigo-500/30 font-mono text-cyan-300 font-bold">
                      {steps[3].keyProof}
                    </div>
                  </div>
                </div>
              )}

              {activeStepTab === 4 && (
                <div className="space-y-3">
                  <h3 className="text-base font-black text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 size={18} />
                    {steps[4].title}
                  </h3>
                  <div className="space-y-2">
                    {steps[4].steps.map((st, idx) => (
                      <div key={idx} className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-slate-200 text-sm flex items-start gap-3">
                        <span className="w-6 h-6 rounded-full bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 flex items-center justify-center text-xs font-black shrink-0">
                          {idx + 1}
                        </span>
                        <span>{st}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeStepTab === 5 && (
                <div className="space-y-3">
                  <h3 className="text-base font-black text-amber-300 flex items-center gap-2">
                    <Calculator size={18} />
                    {steps[5].title}
                  </h3>
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3 text-sm">
                    <div>
                      <span className="text-xs uppercase font-bold text-slate-400 block mb-1">Scenario Problem:</span>
                      <p className="text-slate-100 font-semibold">{steps[5].problem}</p>
                    </div>
                    <div className="p-3 bg-slate-900 rounded-xl font-mono text-xs text-amber-200 border border-slate-800">
                      {steps[5].substitution}
                    </div>
                    <div className="flex items-center gap-2 text-emerald-400 font-bold">
                      <CheckCircle2 size={16} />
                      <span>Final Result: {steps[5].answer}</span>
                    </div>
                  </div>
                </div>
              )}

              {activeStepTab === 6 && (
                <div className="space-y-3">
                  <h3 className="text-base font-black text-purple-300 flex items-center gap-2">
                    <Sparkles size={18} />
                    {steps[6].title}
                  </h3>
                  <div className="bg-purple-950/30 border border-purple-500/30 p-4 rounded-2xl text-slate-200 text-sm leading-relaxed">
                    {steps[6].content}
                  </div>
                </div>
              )}

              {activeStepTab === 7 && (
                <div className="space-y-3">
                  <h3 className="text-base font-black text-amber-300 flex items-center gap-2">
                    <Lightbulb size={18} />
                    {steps[7].title}
                  </h3>
                  <div className="bg-amber-950/30 border border-amber-500/40 p-4 rounded-2xl space-y-2">
                    <div className="text-lg font-black text-amber-300">
                      {steps[7].mnemonic}
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {steps[7].rule}
                    </p>
                  </div>
                </div>
              )}

              {activeStepTab === 8 && (
                <div className="space-y-3">
                  <h3 className="text-base font-black text-rose-300 flex items-center gap-2">
                    <AlertTriangle size={18} />
                    {steps[8].title}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-3.5 bg-rose-950/30 border border-rose-500/30 rounded-2xl space-y-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-rose-300 block">
                        Common Student Traps:
                      </span>
                      <ul className="space-y-1.5 text-xs text-slate-300">
                        {steps[8].traps.map((tr, idx) => (
                          <li key={idx} className="flex items-start gap-1.5">
                            <span className="text-rose-400 font-bold">⚠️</span>
                            <span>{tr}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-3.5 bg-emerald-950/30 border border-emerald-500/30 rounded-2xl space-y-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 block">
                        Board Marking Criteria:
                      </span>
                      <ul className="space-y-1.5 text-xs text-slate-300">
                        {steps[8].markingSteps.map((mk, idx) => (
                          <li key={idx} className="flex items-start gap-1.5">
                            <span className="text-emerald-400 font-bold">📋</span>
                            <span>{mk}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {activeStepTab === 9 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-black text-cyan-300 flex items-center gap-2">
                      <CheckCircle2 size={18} />
                      {steps[9].title}
                    </h3>
                    <button
                      onClick={() => setActiveMainMode('practice_engine')}
                      className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-extrabold hover:bg-emerald-500/30 transition-all cursor-pointer flex items-center gap-1"
                    >
                      <Target size={12} />
                      <span>Launch Full Interactive Quiz Deck →</span>
                    </button>
                  </div>
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3 text-sm">
                    <p className="font-bold text-slate-100">{steps[9].question}</p>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setRevealedHint(!revealedHint)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 text-xs font-bold text-amber-300 hover:bg-slate-700 transition-all cursor-pointer"
                      >
                        {revealedHint ? 'Hide Hint' : '💡 Show Conceptual Hint'}
                      </button>
                      <button
                        onClick={() => setRevealedAnswer(!revealedAnswer)}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600 text-xs font-bold text-white hover:bg-indigo-500 transition-all cursor-pointer"
                      >
                        {revealedAnswer ? 'Hide Solution' : 'Check Explanation'}
                      </button>
                    </div>
                    {revealedHint && (
                      <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-xl text-xs text-amber-200">
                        {steps[9].hint}
                      </div>
                    )}
                    {revealedAnswer && (
                      <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-200">
                        {steps[9].answer}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {activeStepTab === 10 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-black text-emerald-300 flex items-center gap-2">
                      <BookOpen size={18} />
                      {steps[10].title}
                    </h3>
                    <button
                      onClick={() => setActiveMainMode('practice_engine')}
                      className="px-3 py-1 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs hover:bg-emerald-400 transition-all cursor-pointer flex items-center gap-1 shadow-md"
                    >
                      <Zap size={12} className="fill-slate-950" />
                      <span>Start Adaptive Question Suite →</span>
                    </button>
                  </div>
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3 text-sm">
                    <div>
                      <span className="text-xs uppercase font-bold text-slate-400 block mb-1">Exam-Level Practice:</span>
                      <p className="text-slate-100 font-semibold">{steps[10].question}</p>
                    </div>
                    <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed font-mono">
                      {steps[10].solution}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </>
        )}

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <button
              disabled={activeStepTab <= 1 || activeMainMode !== 'pedagogy'}
              onClick={() => setActiveStepTab(prev => Math.max(1, prev - 1))}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-all disabled:opacity-40 cursor-pointer"
            >
              Previous Step
            </button>
            <button
              disabled={activeStepTab >= 10 || activeMainMode !== 'pedagogy'}
              onClick={() => setActiveStepTab(prev => Math.min(10, prev + 1))}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition-all disabled:opacity-40 cursor-pointer"
            >
              Next Step ({activeStepTab}/10)
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

