export * from '../../../../src/modules/virtual-labs/labs/chemistry/ChemistryLabSuite';
import { ChemistryLabSuite } from '../../../../src/modules/virtual-labs/labs/chemistry/ChemistryLabSuite';
export default ChemistryLabSuite;
