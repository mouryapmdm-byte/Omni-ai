import React, { useState, useEffect, useRef } from 'react';
import { 
  Volume2, Play, Pause, RotateCcw, Sparkles, HelpCircle, ArrowRight, 
  Settings2, RefreshCw, Layers, Check, Info, FileAudio, Disc, Activity
} from 'lucide-react';
import { generateAIResponse } from '../lib/gemini';
import { cn, expandAbbreviationsForSpeech, normalizeMathematicalInput } from '../lib/utils';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

interface LaTeXSample {
  title: string;
  latex: string;
  category: 'Math' | 'Physics' | 'Chemistry' | 'Information';
  description: string;
}

const LATEX_SAMPLES: LaTeXSample[] = [
  {
    title: "Quadratic Formula",
    latex: "x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}",
    category: "Math",
    description: "Determines the roots of a quadratic equation $ax^2 + bx + c = 0$."
  },
  {
    title: "Schrödinger Wave Equation",
    latex: "i\\hbar\\frac{\\partial}{\\partial t}\\Psi(x,t) = \\left[-\\frac{\\hbar^2}{2m}\\frac{\\partial^2}{\\partial x^2} + V(x,t)\\right]\\Psi(x,t)",
    category: "Physics",
    description: "The fundamental equation of quantum mechanics describing wave function evolution."
  },
  {
    title: "Maxwell's Ampere Equation",
    latex: "\\nabla \\times \\mathbf{B} = \\mu_0\\left(\\mathbf{J} + \\varepsilon_0\\frac{\\partial\\mathbf{E}}{\\partial t}\\right)",
    category: "Physics",
    description: "Relates magnetic fields to electric currents and changing electric fields."
  },
  {
    title: "Gaussian Normal Distribution",
    latex: "f(x) = \\frac{1}{\\sigma\\sqrt{2\\pi}} e^{-\\frac{1}{2}\\left(\\frac{x-\\mu}{\\sigma}\\right)^2}",
    category: "Math",
    description: "The probability density function for a normal distribution."
  },
  {
    title: "Arrhenius Rate Equation",
    latex: "k = A e^{-\\frac{E_a}{R T}}",
    category: "Chemistry",
    description: "Expresses the dependence of the rate constant of chemical reactions on temperature."
  },
  {
    title: "Shannon Entropy",
    latex: "H(X) = -\\sum_{i=1}^{n} P(x_i) \\log_2 P(x_i)",
    category: "Information",
    description: "Measures the expected value of the information contained in a message."
  }
];

interface PhoneticStep {
  word: string;
  latexSegment: string;
  syllableCount: number;
}

interface TTSModel {
  spokenText: string;
  steps: PhoneticStep[];
  semanticExplanation: string;
}

export const LaTeXToSpeechEngine: React.FC<{ theme?: string; showNotification?: (msg: string, type: 'success' | 'info' | 'warning' | 'error') => void; isClassroomMode?: boolean }> = ({ theme, showNotification, isClassroomMode }) => {
  const [latexInput, setLatexInput] = useState<string>(LATEX_SAMPLES[0].latex);
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [ttsData, setTtsData] = useState<TTSModel | null>({
    spokenText: "x equals, fraction, minus b, plus or minus, square root of, b squared minus four a c, all over two a",
    steps: [
      { word: "x", latexSegment: "x", syllableCount: 1 },
      { word: "equals", latexSegment: "=", syllableCount: 2 },
      { word: "fraction", latexSegment: "\\frac{", syllableCount: 2 },
      { word: "minus b", latexSegment: "-b", syllableCount: 2 },
      { word: "plus or minus", latexSegment: "\\pm", syllableCount: 3 },
      { word: "square root of", latexSegment: "\\sqrt{", syllableCount: 3 },
      { word: "b squared", latexSegment: "b^2", syllableCount: 2 },
      { word: "minus four a c", latexSegment: "- 4ac", syllableCount: 4 },
      { word: "all over", latexSegment: "}{", syllableCount: 2 },
      { word: "two a", latexSegment: "2a}", syllableCount: 2 }
    ],
    semanticExplanation: "This formula solves the quadratic equation ax^2 + bx + c = 0. The symbol \\pm implies two distinct solutions, corresponding to the addition or subtraction of the determinant root."
  });

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentWordIdx, setCurrentWordIdx] = useState<number>(-1);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(0.9); // speed/rate
  const [voicePitch, setVoicePitch] = useState<number>(1.0); // pitch
  const [selectedVoice, setSelectedVoice] = useState<string>('default');
  const [voicesList, setVoicesList] = useState<SpeechSynthesisVoice[]>([]);
  
  // Waveform state
  const [waveformPeaks, setWaveformPeaks] = useState<number[]>([]);
  const [scrubPosition, setScrubPosition] = useState<number>(0); // 0 to 100
  const waveformContainerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<any>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Load standard voices
  useEffect(() => {
    const loadVoices = () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        const list = window.speechSynthesis.getVoices();
        setVoicesList(list.filter(v => v.lang.startsWith('en')));
      }
    };
    loadVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  // Regenerate simulated high-fidelity waveform peaks based on the word steps
  useEffect(() => {
    if (!ttsData) return;
    
    // Create random but reproducible peak heights based on word syllable counts to make it look highly structured and real!
    const peaks: number[] = [];
    ttsData.steps.forEach((step, idx) => {
      const stepSeed = idx + step.word.length + step.syllableCount;
      const numPoints = step.syllableCount * 4 + 2;
      for (let i = 0; i < numPoints; i++) {
        const factor = Math.sin((i / numPoints) * Math.PI);
        const rand = 0.4 + 0.6 * Math.sin(stepSeed * (i + 1));
        peaks.push(Math.max(10, Math.floor(factor * rand * 85)));
      }
      // Add a small gap/pause peak (zero or low height) between words
      peaks.push(4, 4);
    });

    setWaveformPeaks(peaks);
    setScrubPosition(0);
    setCurrentWordIdx(-1);
    stopSpeech();
  }, [ttsData]);

  const stopSpeech = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
    setCurrentWordIdx(-1);
    setScrubPosition(0);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopSpeech();
    };
  }, []);

  const handleTranslateLatex = async () => {
    if (!latexInput.trim()) return;
    setIsTranslating(true);
    stopSpeech();

    try {
      const normalizedInput = normalizeMathematicalInput(latexInput);
      const prompt = `Translate and deconstruct this mathematical input into its standard LaTeX form and semantic phonetic speech components.
      The input might be standard LaTeX, OR it might be raw copy-pasted text, vertically-aligned multi-line formulas (such as vertical fractions with newlines), or mixed-language math text (such as Hindi words like 'जहाँ' meaning 'where').
      
      Raw Input: "${latexInput}"
      Pre-normalized Math Expression: "${normalizedInput}"
      
      First, automatically normalize this input into a clean, single-line LaTeX mathematical expression.
      Then, generate a response as a JSON object of type TTSModel with the following format:
      {
        "spokenText": "Full flowing phonetic spoken string of the formula",
        "steps": [
          { "word": "spoken representation", "latexSegment": "matching LaTeX code snippet", "syllableCount": 2 }
        ],
        "semanticExplanation": "A short, beautiful explanation of what the formula achieves. Highlight the meaning of symbols (for example, in Hindi if the input has Hindi text, or in English by default)."
      }
      Ensure "steps" strictly follows the reading flow of the LaTeX equation and covers all its mathematical operations semantically.`;

      const response = await generateAIResponse(prompt, {
        systemInstruction: "You are a master LaTeX-to-speech rendering and math input normalization system. Your task is to clean up any messy, copy-pasted, or multi-line mathematical text into a beautiful standard LaTeX equation, and then provide a phonetically perfect, natural, flowing spoken representation and explanation. Be robust against vertical layouts and mixed languages.",
        responseMimeType: "application/json"
      });

      const parsed = JSON.parse(response);
      if (parsed.spokenText && parsed.steps) {
        setTtsData(parsed);
        if (showNotification) {
          showNotification("Equation semantically translated to speech!", "success");
        }
      }
    } catch (err) {
      console.error(err);
      if (showNotification) {
        showNotification("Translation error. Using local synthesis fallback.", "warning");
      }
    } finally {
      setIsTranslating(false);
    }
  };

  const handlePlayTTS = () => {
    if (!ttsData || ttsData.steps.length === 0) return;
    
    stopSpeech();
    setIsPlaying(true);

    const textToSpeak = expandAbbreviationsForSpeech(ttsData.spokenText);
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utteranceRef.current = utterance;

    // Apply voice settings
    utterance.rate = playbackSpeed;
    utterance.pitch = voicePitch;

    if (selectedVoice !== 'default') {
      const voiceObj = voicesList.find(v => v.name === selectedVoice);
      if (voiceObj) utterance.voice = voiceObj;
    }

    // Map time tracking using syllables and character limits
    let stepIndex = 0;
    const totalSteps = ttsData.steps.length;
    
    // Estimate total speaking duration based on characters and rate
    // Average word is 150-180 words per minute at rate 1.0
    const wpm = 160 * playbackSpeed;
    const words = textToSpeak.split(/\s+/);
    const estDurationMs = (words.length / wpm) * 60000;
    const intervalMs = estDurationMs / waveformPeaks.length;

    let peakIdx = 0;
    const totalPeaks = waveformPeaks.length;

    // Set up timer to sweep scrubPosition and highlight active phonetic word
    const startTime = Date.now();
    
    timerRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, (elapsed / estDurationMs) * 100);
      setScrubPosition(pct);

      // Determine active word idx based on percentage of completion
      const activeWordProgressIdx = Math.min(
        totalSteps - 1,
        Math.floor((pct / 100) * totalSteps)
      );
      setCurrentWordIdx(activeWordProgressIdx);

      if (pct >= 100) {
        stopSpeech();
      }
    }, 100);

    // Utterance boundary event handlers
    utterance.onend = () => {
      stopSpeech();
    };

    utterance.onerror = () => {
      stopSpeech();
    };

    window.speechSynthesis.speak(utterance);
  };

  const handleWaveformClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!waveformContainerRef.current || !ttsData) return;
    const rect = waveformContainerRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (clickX / rect.width) * 100));
    setScrubPosition(percentage);

    const targetStepIdx = Math.min(
      ttsData.steps.length - 1,
      Math.floor((percentage / 100) * ttsData.steps.length)
    );
    setCurrentWordIdx(targetStepIdx);

    // If already playing, we can restart speech from that word segment
    if (isPlaying) {
      stopSpeech();
      // Speak remainder text
      const remainderText = ttsData.steps.slice(targetStepIdx).map(s => s.word).join(' ');
      setIsPlaying(true);
      const utterance = new SpeechSynthesisUtterance(expandAbbreviationsForSpeech(remainderText));
      utteranceRef.current = utterance;
      utterance.rate = playbackSpeed;
      utterance.pitch = voicePitch;
      
      if (selectedVoice !== 'default') {
        const voiceObj = voicesList.find(v => v.name === selectedVoice);
        if (voiceObj) utterance.voice = voiceObj;
      }

      const remainderSteps = ttsData.steps.length - targetStepIdx;
      const wpm = 160 * playbackSpeed;
      const wordsCount = remainderText.split(/\s+/).length;
      const estDurationMs = (wordsCount / wpm) * 60000;
      const startTime = Date.now();

      timerRef.current = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const currentPct = Math.min(100, (elapsed / estDurationMs) * 100);
        const totalPct = percentage + (currentPct * ((100 - percentage) / 100));
        setScrubPosition(totalPct);

        const currentRemainderIdx = Math.min(
          remainderSteps - 1,
          Math.floor((currentPct / 100) * remainderSteps)
        );
        setCurrentWordIdx(targetStepIdx + currentRemainderIdx);

        if (totalPct >= 100) {
          stopSpeech();
        }
      }, 100);

      utterance.onend = () => stopSpeech();
      utterance.onerror = () => stopSpeech();
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="flex flex-col gap-5 p-5 bg-slate-50 dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
      
      {/* Title & Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-150 dark:border-slate-800 pb-4">
        <div>
          <span className="text-[9px] font-black tracking-widest text-indigo-500 uppercase flex items-center gap-1">
            <Sparkles size={10} className="animate-pulse text-yellow-400 fill-yellow-400" />
            AI Generative Synthesis
          </span>
          <h2 className="text-lg font-black text-slate-800 dark:text-slate-100 flex items-center gap-2">
            🌌 Semantic LaTeX-to-Speech Engine
          </h2>
          <p className="text-[10px] text-slate-500 mt-0.5 leading-normal">
            Generatively translate complex math formulas, chemical notation, and algorithms into clean semantic vocalizations paired with a custom scrubbable waveform.
          </p>
        </div>
      </div>

      {/* Main interactive grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left Column: Equation Editor & Presets (Col 5) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          
          {/* Section: Preset Equations selection */}
          <div className="p-3 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl">
            <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-2">Preset Equation Library</span>
            <div className="grid grid-cols-2 gap-2">
              {LATEX_SAMPLES.map((sample, sIdx) => {
                const isActive = latexInput === sample.latex;
                return (
                  <button
                    key={sIdx}
                    onClick={() => {
                      setLatexInput(sample.latex);
                      stopSpeech();
                    }}
                    className={cn(
                      "p-2 text-left rounded-xl border text-[10px] font-medium transition-all cursor-pointer flex flex-col justify-between h-[75px]",
                      isActive 
                        ? "bg-indigo-600/10 border-indigo-500 text-indigo-600 dark:text-indigo-400 ring-1 ring-indigo-500/20" 
                        : "bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300"
                    )}
                  >
                    <div className="flex justify-between items-center w-full">
                      <span className="font-extrabold truncate max-w-[80%]">{sample.title}</span>
                      <span className="text-[7px] font-black px-1 rounded bg-slate-200 dark:bg-slate-800 uppercase tracking-wider scale-90">{sample.category}</span>
                    </div>
                    <div className="text-[9px] font-mono text-slate-500 truncate w-full mt-1">{sample.latex}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section: Formula LaTeX Input Area */}
          <div className="p-4 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl flex flex-col gap-2.5">
            <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">LaTeX Expression Editor</span>
            <textarea
              value={latexInput}
              onChange={(e) => {
                setLatexInput(e.target.value);
                stopSpeech();
              }}
              placeholder="Enter LaTeX formula e.g. \int f(x) dx..."
              rows={4}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono placeholder-slate-400 outline-none focus:border-indigo-500"
            />
            
            <button
              onClick={handleTranslateLatex}
              disabled={isTranslating || !latexInput.trim()}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              {isTranslating ? (
                <>
                  <RefreshCw size={12} className="animate-spin" />
                  <span>Translating Formula...</span>
                </>
              ) : (
                <>
                  <Sparkles size={12} className="text-yellow-300 fill-yellow-300" />
                  <span>Generatively Translate & Read</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Right Column: Audio Sandbox, Waveform & Explanation (Col 7) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          
          {/* Main TTS Visual Sandbox */}
          <div className="p-4 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl flex flex-col gap-4">
            
            {/* Equation LaTeX Preview */}
            <div className="p-4 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-center min-h-[90px] relative overflow-hidden select-none">
              <div className="absolute top-1 right-2 text-[7px] font-bold text-slate-400 uppercase">Live Preview</div>
              <div className="text-center overflow-x-auto max-w-full font-sans text-lg text-slate-800 dark:text-slate-100">
                <Markdown remarkPlugins={[remarkMath]} rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}>
                  {`$$${latexInput}$$`}
                </Markdown>
              </div>
            </div>

            {/* Config controls: Speed & Pitch */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                  <Activity size={10} className="text-indigo-500" /> Speech Rate
                </label>
                <div className="flex items-center gap-2 mt-1">
                  <input
                    type="range"
                    min="0.5"
                    max="1.5"
                    step="0.1"
                    value={playbackSpeed}
                    onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500"
                  />
                  <span className="text-[10px] font-mono text-slate-500 font-bold w-7 text-right">{playbackSpeed}x</span>
                </div>
              </div>

              <div>
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                  <Layers size={10} className="text-indigo-500" /> Voice Pitch
                </label>
                <div className="flex items-center gap-2 mt-1">
                  <input
                    type="range"
                    min="0.5"
                    max="1.5"
                    step="0.1"
                    value={voicePitch}
                    onChange={(e) => setVoicePitch(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500"
                  />
                  <span className="text-[10px] font-mono text-slate-500 font-bold w-7 text-right">{voicePitch}x</span>
                </div>
              </div>

              <div>
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                  <Settings2 size={10} className="text-indigo-500" /> Synthesizer Voice
                </label>
                <select
                  value={selectedVoice}
                  onChange={(e) => setSelectedVoice(e.target.value)}
                  className="w-full mt-1 p-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-[10px] text-slate-600 dark:text-slate-300 outline-none"
                >
                  <option value="default">Default OS Synth Voice</option>
                  {voicesList.map((v, idx) => (
                    <option key={idx} value={v.name}>{v.name} ({v.lang})</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Interactive Audio Waveform Canvas Box */}
            <div className="hidden md:block">
              {!isClassroomMode && (
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Interactive Audio Waveform Spectrum</span>
                    <span className="text-[8px] font-mono text-slate-500">Click peaks to seek/scrub</span>
                  </div>

                  <div 
                    ref={waveformContainerRef}
                    onClick={handleWaveformClick}
                    className="relative h-24 bg-slate-950 rounded-2xl overflow-hidden flex items-center justify-center cursor-ew-resize border border-slate-800"
                  >
                    {/* Background decorative coordinate mesh */}
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-950/20 via-slate-950 to-slate-950 opacity-90" />
                    <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:24px_16px] opacity-10" />

                    {/* Vertical Waveform Bars */}
                    <div className="absolute inset-0 flex items-center justify-around px-4 gap-[2px]">
                      {waveformPeaks.map((peak, idx) => {
                        const barPct = (idx / waveformPeaks.length) * 100;
                        const isPlayed = barPct <= scrubPosition;
                        
                        return (
                          <div
                            key={idx}
                            className={cn(
                              "w-1 rounded-full transition-all duration-300",
                              isPlayed 
                                ? "bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.6)]" 
                                : "bg-slate-800"
                            )}
                            style={{ 
                              height: `${peak}%`,
                              opacity: isPlayed ? 1.0 : 0.4 
                            }}
                          />
                        );
                      })}
                    </div>

                    {/* Red/Blue Scrub playhead pointer */}
                    <div 
                      className="absolute top-0 bottom-0 w-[2px] bg-red-500 shadow-[0_0_8px_#f43f5e] z-10 pointer-events-none transition-all duration-100"
                      style={{ left: `${scrubPosition}%` }}
                    />

                    {/* Live Voice Indicator status */}
                    {isPlaying && (
                      <div className="absolute bottom-2 left-3 z-20 flex items-center gap-1.5 px-2 py-1 bg-indigo-600/90 text-white rounded-lg text-[8px] font-mono tracking-widest">
                        <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                        <span>SYNTHESIZING...</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Playback Controls & Waveform scrub text */}
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {isPlaying ? (
                  <button
                    onClick={stopSpeech}
                    className="p-3 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 text-[10px] font-black uppercase tracking-wider"
                  >
                    <Pause size={14} />
                    Stop
                  </button>
                ) : (
                  <button
                    onClick={handlePlayTTS}
                    disabled={!ttsData}
                    className="p-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 text-[10px] font-black uppercase tracking-wider"
                  >
                    <Play size={14} className="fill-current" />
                    Synthesize Speak
                  </button>
                )}

                <button
                  onClick={() => {
                    stopSpeech();
                    if (ttsData) {
                      setScrubPosition(0);
                    }
                  }}
                  className="p-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-900 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-xl transition-all cursor-pointer"
                  title="Reset playhead"
                >
                  <RotateCcw size={14} />
                </button>
              </div>

              <div className="text-right">
                <span className="text-[8px] font-black text-slate-400 uppercase block">Active Reading Pointer</span>
                <span className="text-[10px] font-mono text-slate-600 dark:text-slate-400 font-bold">
                  {scrubPosition.toFixed(0)}% Complete
                </span>
              </div>
            </div>

            {/* Active Highlight word-by-word transcription block */}
            <div className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-150 dark:border-slate-800 rounded-xl">
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1.5">Phonetic Word-by-Word Sequence</span>
              <div className="flex flex-wrap gap-1.5 leading-relaxed">
                {ttsData?.steps.map((step, idx) => {
                  const isActive = idx === currentWordIdx;
                  return (
                    <span
                      key={idx}
                      onClick={() => {
                        // Click word to seek!
                        const targetPct = (idx / ttsData.steps.length) * 100;
                        setScrubPosition(targetPct);
                        setCurrentWordIdx(idx);
                        if (isPlaying) {
                          stopSpeech();
                        }
                      }}
                      className={cn(
                        "px-2 py-1 rounded text-[11px] font-medium transition-all duration-200 cursor-pointer border",
                        isActive 
                          ? "bg-indigo-600 text-white border-indigo-700 shadow-sm scale-105 font-extrabold" 
                          : "bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100"
                      )}
                    >
                      {step.word}
                    </span>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Semantic Deconstruction / Meaning Explanation */}
          {ttsData?.semanticExplanation && (
            <div className="p-4 bg-indigo-500/5 dark:bg-indigo-500/10 border border-indigo-500/25 rounded-2xl flex items-start gap-3">
              <span className="text-lg leading-none">🧠</span>
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider text-indigo-500 dark:text-indigo-400">Semantic Formula Meaning</h4>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-normal mt-1">
                  {ttsData.semanticExplanation}
                </p>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
