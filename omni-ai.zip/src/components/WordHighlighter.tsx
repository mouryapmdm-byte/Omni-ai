import React from "react";
import { cn } from "@/src/lib/utils";

interface WordHighlighterProps {
  words: string[];
  currentWordIndex: number;
}

export function WordHighlighter({ words, currentWordIndex }: WordHighlighterProps) {
  return (
    <>
      {words.map((word, index) => (
        <span
          key={index}
          className={cn(
            "transition-colors duration-200 inline-block",
            index === currentWordIndex 
              ? "text-amber-200 font-extrabold bg-amber-400/25 px-1 py-0.5 rounded ring-1 ring-amber-400/40 shadow-sm opacity-100" 
              : "text-amber-50 font-medium opacity-100"
          )}
        >
          {word}{" "}
        </span>
      ))}
    </>
  );
}
