import React, { useState, useEffect, useRef } from 'react';
import { VoiceInput } from './VoiceInput';
import { RecallFeedback } from './RecallFeedback';
import { 
  getModelAnswerForTopic 
} from '../modules/retrieval-practice/modelAnswersData';
import { 
  evaluateFreeRecall 
} from '../modules/retrieval-practice/evaluator';
import { 
  saveRecallAttempt, 
  getRecallAttempts, 
  getRecallProgressMetrics,
  queueOfflineRecall,
  processOfflineQueue
} from '../modules/retrieval-practice/storage';
import { RecallAttempt, ModelAnswerTopic } from '../modules/retrieval-practice/types';
import { 
  Brain, 
  Clock, 
  Send, 
  RotateCcw, 
  Sparkles, 
  TrendingUp, 
  History, 
  Zap, 
  Award,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { cn } from '../lib/utils';

export interface FreeRecallProps {
  subject: string;
  chapterId: string;
  chapterTitle: string;
  onRewardXp?: (xp: number) => void;
  showNotification?: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onClose?: () => void;
}

export const FreeRecall: React.FC<FreeRecallProps> = ({
  subject,
  chapterId,
  chapterTitle,
  onRewardXp,
  showNotification,
  onClose
}) => {
  const [response, setResponse] = useState('');
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [activeAttempt, setActiveAttempt] = useState<RecallAttempt | null>(null);
  const [attemptsHistory, setAttemptsHistory] = useState<RecallAttempt[]>([]);
  const [activeTab, setActiveTab] = useState<'recall' | 'history'>('recall');

  // Timed mode state
  const [isTimedMode, setIsTimedMode] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState<number>(180); // 3 minutes default
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const timerRef = useRef<any>(null);

  const topic: ModelAnswerTopic = getModelAnswerForTopic(subject, chapterId, chapterTitle);

  // Load history & process offline queue on mount
  useEffect(() => {
    const history = getRecallAttempts().filter(a => a.chapterId === chapterId || a.subject === subject);
    setAttemptsHistory(history);

    // Try processing any offline items in background
    processOfflineQueue().catch(() => {});
  }, [chapterId, subject]);

  // Handle timer
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
      if (isTimedMode) {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isTimedMode]);

  // Auto submit when time runs out in timed mode
  useEffect(() => {
    if (isTimedMode && timeRemaining === 0 && !isEvaluating && !activeAttempt && response.trim().length > 0) {
      handleSubmit();
    }
  }, [isTimedMode, timeRemaining, isEvaluating, activeAttempt, response]);

  const handleSubmit = async () => {
    if (!response.trim() || response.trim().length < 5) {
      if (showNotification) {
        showNotification('Please write or speak a few words before submitting.', 'warning');
      }
      return;
    }

    setIsEvaluating(true);

    try {
      const startTime = Date.now();
      const evalResult = await evaluateFreeRecall(topic, response);
      const durationInSeconds = elapsedSeconds || 10;

      const newAttempt: RecallAttempt = {
        id: `recall_${Date.now()}`,
        chapterId,
        topicId: topic.topicId,
        topicTitle: topic.topicTitle,
        subject,
        studentResponse: response,
        modelAnswer: topic.modelAnswerText,
        score: evalResult.score,
        coverage: evalResult.coverage,
        accuracy: evalResult.accuracy,
        depth: evalResult.depth,
        organization: evalResult.organization,
        coveredConcepts: evalResult.coveredConcepts,
        missedConcepts: evalResult.missedConcepts,
        wrongConcepts: evalResult.wrongConcepts,
        feedbackSuggestions: evalResult.feedbackSuggestions,
        duration: durationInSeconds,
        createdAt: new Date().toISOString()
      };

      saveRecallAttempt(newAttempt);
      setActiveAttempt(newAttempt);
      setAttemptsHistory(prev => [newAttempt, ...prev]);

      if (onRewardXp) {
        const xp = Math.round(evalResult.score * 1.5) + 30;
        onRewardXp(xp);
        if (showNotification) {
          showNotification(`Free Recall Evaluation Complete! Earned ${xp} XP! 🎓`, 'success');
        }
      }
    } catch (err) {
      console.error('Error during free recall submission:', err);
      // Queue offline
      queueOfflineRecall({
        id: `offline_recall_${Date.now()}`,
        topic,
        studentResponse: response,
        duration: elapsedSeconds,
        createdAt: new Date().toISOString()
      });
      if (showNotification) {
        showNotification('Network offline. Your recall attempt was queued for evaluation when online.', 'info');
      }
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleReset = () => {
    setResponse('');
    setActiveAttempt(null);
    setElapsedSeconds(0);
    setTimeRemaining(180);
  };

  const metrics = getRecallProgressMetrics(chapterId);

  // If active attempt evaluated, show side-by-side feedback
  if (activeAttempt) {
    return (
      <RecallFeedback 
        attempt={activeAttempt} 
        onRetry={handleReset} 
        onClose={onClose} 
      />
    );
  }

  return (
    <div className="flex flex-col gap-6 w-full max-w-5xl mx-auto p-1">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 p-6 rounded-2xl text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Retrieval Practice Engine
            </span>
            <span className="text-xs text-slate-400">
              {subject} • Chapter {chapterTitle}
            </span>
          </div>
          <h2 className="text-xl font-extrabold tracking-tight text-white mb-1 flex items-center gap-2">
            <Brain className="text-indigo-400 shrink-0" size={22} />
            Write everything you remember about <span className="text-indigo-300">{topic.topicTitle}</span>
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Free Recall forces your brain to reconstruct knowledge from memory without prompts or cues — building robust long-term retrieval neural pathways.
          </p>
        </div>

        {/* Timed Mode Toggle */}
        <div className="flex items-center gap-3 bg-slate-800/80 p-2.5 rounded-xl border border-indigo-500/30 shrink-0">
          <button
            type="button"
            onClick={() => setIsTimedMode(!isTimedMode)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer",
              isTimedMode ? "bg-amber-500/20 text-amber-300 border border-amber-500/40" : "text-slate-300 hover:text-white"
            )}
          >
            <Clock size={14} className={isTimedMode ? "text-amber-400 animate-pulse" : "text-slate-400"} />
            {isTimedMode ? `Timed Mode (${Math.floor(timeRemaining / 60)}:${(timeRemaining % 60).toString().padStart(2, '0')})` : 'Enable Timed Challenge'}
          </button>
        </div>
      </div>

      {/* Tabs Bar: Recall vs History */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('recall')}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer",
            activeTab === 'recall' 
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20" 
              : "bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800"
          )}
        >
          <Zap size={14} />
          Active Recall Exercise
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer",
            activeTab === 'history' 
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20" 
              : "bg-slate-100 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800"
          )}
        >
          <History size={14} />
          Recall History & Progress ({attemptsHistory.length})
        </button>
      </div>

      {activeTab === 'recall' ? (
        <div className="flex flex-col gap-4">
          {/* Voice Input & Main Textarea */}
          <VoiceInput 
            currentValue={response} 
            onTranscriptChange={setResponse} 
            placeholder="Type or dictate freely... Include key definitions, formulas, conditions, derivations, and examples."
          />

          {/* Word count & Submit Bar */}
          <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
              <span>Words: <strong className="text-slate-800 dark:text-slate-200">{response.trim() ? response.trim().split(/\s+/).length : 0}</strong></span>
              <span>•</span>
              <span>Time: <strong className="text-slate-800 dark:text-slate-200">{Math.floor(elapsedSeconds / 60)}m {elapsedSeconds % 60}s</strong></span>
            </div>

            <button
              onClick={handleSubmit}
              disabled={isEvaluating || !response.trim()}
              className={cn(
                "flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold text-white transition shadow-md cursor-pointer",
                isEvaluating || !response.trim()
                  ? "bg-slate-400 cursor-not-allowed opacity-60"
                  : "bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-indigo-500/20"
              )}
            >
              {isEvaluating ? (
                <>
                  <Brain size={15} className="animate-spin" />
                  AI Evaluating Coverage & Depth...
                </>
              ) : (
                <>
                  <Send size={15} />
                  Submit for AI Evaluation
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        /* Progress History View */
        <div className="flex flex-col gap-6">
          {/* Progress Metrics Row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col gap-1">
              <span className="text-xs text-slate-500 dark:text-slate-400">Average Recall Score</span>
              <span className="text-2xl font-black text-indigo-500">{metrics.averageScore}/100</span>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col gap-1">
              <span className="text-xs text-slate-500 dark:text-slate-400">Total Recall Attempts</span>
              <span className="text-2xl font-black text-emerald-500">{metrics.totalAttempts}</span>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col gap-1">
              <span className="text-xs text-slate-500 dark:text-slate-400">Self Improvement Rate</span>
              <span className="text-2xl font-black text-violet-500">
                {metrics.improvementRate >= 0 ? `+${metrics.improvementRate}%` : `${metrics.improvementRate}%`}
              </span>
            </div>
          </div>

          {/* List of Past Attempts */}
          {attemptsHistory.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              No previous recall attempts recorded for this chapter yet. Complete your first exercise!
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {attemptsHistory.map((attempt) => (
                <div
                  key={attempt.id}
                  onClick={() => setActiveAttempt(attempt)}
                  className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-500/50 transition cursor-pointer flex items-center justify-between gap-4 shadow-sm"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {attempt.topicTitle}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(attempt.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 max-w-lg">
                      {attempt.studentResponse}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className={cn(
                      "px-3 py-1 rounded-lg text-xs font-extrabold border",
                      attempt.score >= 75 ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/30" : "bg-indigo-500/10 text-indigo-500 border-indigo-500/30"
                    )}>
                      {attempt.score}/100
                    </span>
                    <span className="text-xs text-indigo-500 font-semibold flex items-center gap-1">
                      View Feedback <Award size={13} />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
