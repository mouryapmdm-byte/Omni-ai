import React, { useState, useEffect, useRef } from 'react';
import { 
  Box, Eye, Layers, Compass, RotateCcw, Maximize2, QrCode, 
  Sparkles, Camera, Sliders, Play, Pause, RefreshCw, ZoomIn, ZoomOut
} from 'lucide-react';
import { cn } from '../lib/utils';

interface Model3D {
  id: string;
  name: string;
  category: 'chemistry' | 'physics' | 'biology' | 'geometry';
  description: string;
  nodes: { x: number; y: number; z: number; color: string; label: string; radius: number }[];
  connections: [number, number][];
}

interface Props {
  theme?: 'light' | 'dark';
  initialModelCategory?: string;
  showNotification?: (message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const Ar3dVisualizerHub: React.FC<Props> = ({
  theme = 'light',
  initialModelCategory = 'chemistry',
  showNotification
}) => {
  const [selectedModelId, setSelectedModelId] = useState('dna_helix');
  const [isRotating, setIsRotating] = useState(true);
  const [rotation, setRotation] = useState({ x: 25, y: 45, z: 0 });
  const [zoomLevel, setZoomLevel] = useState(1.0);
  const [showArQrModal, setShowArQrModal] = useState(false);
  const [activeLayer, setActiveLayer] = useState<'all' | 'atoms' | 'bonds' | 'fields'>('all');
  const [crossSectionCut, setCrossSectionCut] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const models: Record<string, Model3D> = {
    dna_helix: {
      id: 'dna_helix',
      name: 'DNA Double Helix & Hydrogen Base Pairing',
      category: 'biology',
      description: 'Antiparallel double helix showing Adenine-Thymine (2 H-bonds) and Guanine-Cytosine (3 H-bonds) spatial conformation.',
      nodes: [
        { x: -50, y: -80, z: -20, color: '#3b82f6', label: 'Sugar-P', radius: 10 },
        { x: 50, y: -80, z: 20, color: '#ef4444', label: 'Base A', radius: 8 },
        { x: -30, y: -40, z: 40, color: '#10b981', label: 'Base T', radius: 8 },
        { x: 30, y: -40, z: -40, color: '#3b82f6', label: 'Sugar-P', radius: 10 },
        { x: 40, y: 0, z: 50, color: '#8b5cf6', label: 'Base G', radius: 8 },
        { x: -40, y: 0, z: -50, color: '#f59e0b', label: 'Base C', radius: 8 },
        { x: -50, y: 40, z: -20, color: '#3b82f6', label: 'Sugar-P', radius: 10 },
        { x: 50, y: 40, z: 20, color: '#ef4444', label: 'Base A', radius: 8 },
        { x: -30, y: 80, z: 40, color: '#10b981', label: 'Base T', radius: 8 },
        { x: 30, y: 80, z: -40, color: '#3b82f6', label: 'Sugar-P', radius: 10 },
      ],
      connections: [
        [0, 1], [1, 2], [2, 3],
        [3, 4], [4, 5],
        [5, 6], [6, 7], [7, 8], [8, 9]
      ]
    },
    nacl_lattice: {
      id: 'nacl_lattice',
      name: 'NaCl Face-Centered Cubic (FCC) Lattice',
      category: 'chemistry',
      description: 'Face-Centered Cubic crystal lattice showing alternating $Na^+$ (violet) and $Cl^-$ (emerald) electrostatic coordination (6:6).',
      nodes: [
        { x: -60, y: -60, z: -60, color: '#8b5cf6', label: 'Na+', radius: 9 },
        { x: 60, y: -60, z: -60, color: '#10b981', label: 'Cl-', radius: 14 },
        { x: -60, y: 60, z: -60, color: '#10b981', label: 'Cl-', radius: 14 },
        { x: 60, y: 60, z: -60, color: '#8b5cf6', label: 'Na+', radius: 9 },
        { x: -60, y: -60, z: 60, color: '#10b981', label: 'Cl-', radius: 14 },
        { x: 60, y: -60, z: 60, color: '#8b5cf6', label: 'Na+', radius: 9 },
        { x: -60, y: 60, z: 60, color: '#8b5cf6', label: 'Na+', radius: 9 },
        { x: 60, y: 60, z: 60, color: '#10b981', label: 'Cl-', radius: 14 },
        { x: 0, y: 0, z: 0, color: '#f59e0b', label: 'Center Na+', radius: 9 }
      ],
      connections: [
        [0, 1], [1, 3], [3, 2], [2, 0],
        [4, 5], [5, 7], [7, 6], [6, 4],
        [0, 4], [1, 5], [2, 6], [3, 7]
      ]
    },
    lorentz_forces: {
      id: 'lorentz_forces',
      name: 'Charged Particle Helical Motion in B-Field',
      category: 'physics',
      description: 'Lorentz force $\\mathbf{F} = q(\\mathbf{v} \\times \\mathbf{B})$ generating cyclotron helical trajectories in magnetic fields.',
      nodes: [
        { x: 0, y: -90, z: 0, color: '#ef4444', label: 'q+ Entry', radius: 11 },
        { x: 45, y: -60, z: 30, color: '#3b82f6', label: 'B-Flux Vector', radius: 7 },
        { x: 60, y: -20, z: -10, color: '#f59e0b', label: 'v Velocity', radius: 7 },
        { x: 10, y: 20, z: -40, color: '#10b981', label: 'F_L Lorentz', radius: 7 },
        { x: -50, y: 60, z: 0, color: '#8b5cf6', label: 'Cyclotron Orbit', radius: 8 },
        { x: 0, y: 90, z: 30, color: '#ef4444', label: 'Helical Exit', radius: 11 }
      ],
      connections: [
        [0, 1], [1, 2], [2, 3], [3, 4], [4, 5]
      ]
    }
  };

  const currentModel = models[selectedModelId] || models.dna_helix;

  // Auto-rotation animation loop
  useEffect(() => {
    let animationFrameId: number;
    const render = () => {
      if (isRotating) {
        setRotation(prev => ({
          x: prev.x + 0.3,
          y: prev.y + 0.6,
          z: prev.z
        }));
      }
      drawCanvas();
      animationFrameId = requestAnimationFrame(render);
    };
    animationFrameId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isRotating, rotation, zoomLevel, selectedModelId, activeLayer]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;

    const radX = (rotation.x * Math.PI) / 180;
    const radY = (rotation.y * Math.PI) / 180;

    // Project 3D nodes to 2D
    const projectedNodes = currentModel.nodes.map(node => {
      // Rotate Y
      let x1 = node.x * Math.cos(radY) - node.z * Math.sin(radY);
      let z1 = node.x * Math.sin(radY) + node.z * Math.cos(radY);

      // Rotate X
      let y2 = node.y * Math.cos(radX) - z1 * Math.sin(radX);
      let z2 = node.y * Math.sin(radX) + z1 * Math.cos(radX);

      const fov = 400;
      const scale = (fov / (fov + z2)) * zoomLevel;

      const px = cx + x1 * scale;
      const py = cy + y2 * scale;

      return {
        ...node,
        px,
        py,
        scale,
        depth: z2
      };
    });

    // Draw connecting bonds
    if (activeLayer === 'all' || activeLayer === 'bonds') {
      ctx.lineWidth = 2.5 * zoomLevel;
      currentModel.connections.forEach(([n1Idx, n2Idx]) => {
        const p1 = projectedNodes[n1Idx];
        const p2 = projectedNodes[n2Idx];
        if (!p1 || !p2) return;

        ctx.strokeStyle = theme === 'dark' ? 'rgba(99, 102, 241, 0.4)' : 'rgba(79, 70, 229, 0.3)';
        ctx.beginPath();
        ctx.moveTo(p1.px, p1.py);
        ctx.lineTo(p2.px, p2.py);
        ctx.stroke();
      });
    }

    // Sort by depth for correct 3D occlusions
    const sorted = [...projectedNodes].sort((a, b) => b.depth - a.depth);

    // Draw Atoms / Spheres
    if (activeLayer === 'all' || activeLayer === 'atoms') {
      sorted.forEach(node => {
        const r = node.radius * node.scale;
        
        // Sphere shadow/glow gradient
        const grad = ctx.createRadialGradient(
          node.px - r * 0.3,
          node.py - r * 0.3,
          r * 0.1,
          node.px,
          node.py,
          r
        );
        grad.addColorStop(0, '#ffffff');
        grad.addColorStop(0.4, node.color);
        grad.addColorStop(1, '#000000');

        ctx.beginPath();
        ctx.arc(node.px, node.py, Math.max(2, r), 0, Math.PI * 2);
        ctx.fillStyle = grad;
        ctx.shadowColor = node.color;
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Label
        ctx.fillStyle = theme === 'dark' ? '#cbd5e1' : '#1e293b';
        ctx.font = `bold ${Math.max(9, 11 * node.scale)}px sans-serif`;
        ctx.fillText(node.label, node.px + r + 3, node.py + 3);
      });
    }
  };

  const isDark = theme === 'dark';

  return (
    <div className={cn(
      "w-full h-full flex flex-col rounded-2xl overflow-hidden font-sans",
      isDark ? "bg-slate-900 text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Header */}
      <div className={cn(
        "px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4",
        isDark ? "bg-slate-950/80 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md">
            <Box size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black tracking-tight">Interactive 3D & Augmented Reality</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                WebXR Ready
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Spatial manipulation &bull; Cross-section slicing &bull; Phone AR QR projection
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <select
            value={selectedModelId}
            onChange={(e) => setSelectedModelId(e.target.value)}
            className={cn(
              "px-3 py-1.5 rounded-lg border text-xs font-bold outline-none cursor-pointer",
              isDark ? "bg-slate-800 border-slate-700 text-slate-100" : "bg-white border-slate-200 text-slate-800"
            )}
          >
            <option value="dna_helix">DNA Double Helix</option>
            <option value="nacl_lattice">NaCl FCC Crystal Lattice</option>
            <option value="lorentz_forces">Lorentz Cyclotron Motion</option>
          </select>

          <button
            onClick={() => setShowArQrModal(true)}
            className="px-3 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer"
          >
            <QrCode size={13} /> Project in AR
          </button>
        </div>
      </div>

      {/* Main 3D Canvas Viewport */}
      <div className="flex-1 relative flex flex-col md:flex-row overflow-hidden">
        {/* Left Side 3D Canvas Stage */}
        <div className="flex-1 relative flex items-center justify-center bg-slate-950/40 p-4">
          <canvas
            ref={canvasRef}
            width={600}
            height={440}
            className="w-full max-w-[600px] h-[400px] rounded-2xl cursor-grab active:cursor-grabbing"
            onMouseDown={(e) => {
              // drag rotation
              const startX = e.clientX;
              const startY = e.clientY;
              const handleMouseMove = (moveEv: MouseEvent) => {
                setRotation(r => ({
                  x: r.x + (moveEv.clientY - startY) * 0.15,
                  y: r.y + (moveEv.clientX - startX) * 0.15,
                  z: r.z
                }));
              };
              const handleMouseUp = () => {
                window.removeEventListener('mousemove', handleMouseMove);
                window.removeEventListener('mouseup', handleMouseUp);
              };
              window.addEventListener('mousemove', handleMouseMove);
              window.addEventListener('mouseup', handleMouseUp);
            }}
          />

          {/* Floating Canvas Overlay Tools */}
          <div className="absolute bottom-6 left-6 flex items-center gap-2 bg-slate-900/80 backdrop-blur-md p-1.5 rounded-xl border border-slate-800 shadow-xl">
            <button
              onClick={() => setIsRotating(!isRotating)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer"
              title={isRotating ? "Pause Spin" : "Auto Spin"}
            >
              {isRotating ? <Pause size={14} /> : <Play size={14} />}
            </button>
            <button
              onClick={() => setZoomLevel(z => Math.min(2.0, z + 0.15))}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn size={14} />
            </button>
            <button
              onClick={() => setZoomLevel(z => Math.max(0.6, z - 0.15))}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut size={14} />
            </button>
            <button
              onClick={() => {
                setRotation({ x: 25, y: 45, z: 0 });
                setZoomLevel(1.0);
              }}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer"
              title="Reset Angle"
            >
              <RotateCcw size={14} />
            </button>
          </div>
        </div>

        {/* Right Side Model Specification & Spatial Controls */}
        <div className="w-full md:w-80 border-t md:border-t-0 md:border-l border-slate-800 p-5 space-y-4 overflow-y-auto bg-slate-950/60">
          <div className="space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400">
              Active Simulation
            </span>
            <h3 className="text-sm font-black text-slate-100">{currentModel.name}</h3>
            <p className="text-xs text-slate-400 leading-relaxed pt-1">
              {currentModel.description}
            </p>
          </div>

          {/* Layer toggles */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Layers size={13} /> Visual Layers
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
              <button
                onClick={() => setActiveLayer('all')}
                className={cn(
                  "p-2 rounded-lg border transition cursor-pointer",
                  activeLayer === 'all' ? "bg-cyan-500/20 border-cyan-500 text-cyan-300" : "bg-slate-900 border-slate-800 text-slate-400"
                )}
              >
                Complete Model
              </button>
              <button
                onClick={() => setActiveLayer('atoms')}
                className={cn(
                  "p-2 rounded-lg border transition cursor-pointer",
                  activeLayer === 'atoms' ? "bg-cyan-500/20 border-cyan-500 text-cyan-300" : "bg-slate-900 border-slate-800 text-slate-400"
                )}
              >
                Atoms Only
              </button>
              <button
                onClick={() => setActiveLayer('bonds')}
                className={cn(
                  "p-2 rounded-lg border transition cursor-pointer",
                  activeLayer === 'bonds' ? "bg-cyan-500/20 border-cyan-500 text-cyan-300" : "bg-slate-900 border-slate-800 text-slate-400"
                )}
              >
                Bonds / Lattices
              </button>
            </div>
          </div>

          {/* Spatial Info & Stats */}
          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs text-slate-400">
            <div className="flex justify-between">
              <span>Nodes / Atoms:</span>
              <strong className="text-slate-200">{currentModel.nodes.length}</strong>
            </div>
            <div className="flex justify-between">
              <span>Bonds / Vectors:</span>
              <strong className="text-slate-200">{currentModel.connections.length}</strong>
            </div>
            <div className="flex justify-between">
              <span>Pitch / Yaw / Roll:</span>
              <strong className="text-cyan-400 font-mono">
                {Math.round(rotation.x)}° / {Math.round(rotation.y)}°
              </strong>
            </div>
          </div>
        </div>
      </div>

      {/* AR Modal */}
      {showArQrModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 p-6 rounded-2xl max-w-sm w-full space-y-4 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-xl bg-cyan-600 text-white flex items-center justify-center mx-auto">
              <Camera size={24} />
            </div>
            <h3 className="text-base font-black text-slate-100">Project into Real-World AR</h3>
            <p className="text-xs text-slate-400">
              Scan with your smartphone camera to place this 3D {currentModel.name} on your physical desk in WebXR.
            </p>

            <div className="p-4 bg-white rounded-xl mx-auto w-48 h-48 flex items-center justify-center">
              {/* QR Code visual simulation */}
              <div className="w-40 h-40 border-4 border-slate-900 flex flex-col justify-between p-2">
                <div className="flex justify-between">
                  <div className="w-8 h-8 bg-slate-900" />
                  <div className="w-8 h-8 bg-slate-900" />
                </div>
                <div className="text-center font-mono text-[9px] font-bold text-slate-900">
                  AR 3D HOLOGRAM
                </div>
                <div className="flex justify-between">
                  <div className="w-8 h-8 bg-slate-900" />
                  <div className="w-4 h-4 bg-slate-900" />
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowArQrModal(false)}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs transition cursor-pointer"
            >
              Done / Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
